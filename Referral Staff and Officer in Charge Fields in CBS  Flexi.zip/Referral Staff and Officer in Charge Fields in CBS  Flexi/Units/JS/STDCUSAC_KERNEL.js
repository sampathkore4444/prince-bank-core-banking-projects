/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2015  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
------------------------
CHANGE HISTORY:
----------------------------------------------------------------------------------------------------

Changed By		: Jayanth
SFR No		: -
Change Desc	: Initial Checkin
Search Tag		: -

Changed By		: Jayanth
SFR No		: 632
Change Desc	: Added code to default the interest start date on the Deposit tab visit in IC special condition screen
			  Function added: fnInTab_TAB_DEPOSIT_KERNEL
Search Tag		: FC10.3 - SFR#632

Changed By		: Jayanth
SFR No		: 757
Change Desc	: Added code to clear the audit fields in fnpostcopy and fnpostunlock
Search Tag		: FC10.3 - SFR#757

Changed By		: Jayanth
SFR No		: 924
Change Desc	: Added code to assign the prev action on faile
Search Tag		: FC10.3 - SFR#924

Changed By		: Jayanth
SFR No		: 609
Change Desc	: Changed fields in fnPostLoad_CVS_ACNO_KERNEL()
Search Tag		: FC10.3 - SFR#609

Changed By		: Jayanth
SFR No		: 897
Change Desc	: Changed prevAction variable in fnpresave_CVS_ACNO_KERNEL()
Search Tag		: FC10.3 - SFR#897

Changed By		: Jayanth
SFR No		: 1188
Change Desc	: Changed the function fnPostLoad_CVS_ACCLIMITS_KERNEL
Search Tag		: FC10.3 - SFR#1188


Changed By	: Naman
SFR No		: 224
Change Desc	: Account number and alternate account number being refreshed from DOM
Search Tag 	: FC10.3 SFR#224

Changed By	: SUHEL MD
SFR No		: 1303
Change Desc	:  button iban should be enabled only after iban required checkbox is checked and vice-versa
Search Tag 	: FC10.35SFR#1303

Changed By	: Sushma S
SFR No		: 2793
Change Desc	:  Changes done to enable following checkbox fields during Creating New TD account,a) Waive Interest b) Generate UDE Change Advice c) Open d) Intergrated ILM Product c) Open (in Effective Date sub screen).
Search Tag 	: FC10.5 - STR1 SFR 2793

Changed By       	: Piyush
Changed On       	: 12-Oct-2009
Change Desc   	: FCUBS V.UM 11.0.0.0.0.0.0 Enhancement (Minimum account opening amount and account opening charges)
Search Tag      	: Kernel 11.0 - Casa - Minimum Account Opening Amount/Account Opening Charges

Changed By         	:  Alok Keshri
Change Description 	:  FCUBS V.UM 11.0.0.0.0.0.0 Enhancement (Debit Card Functionality)
Changed On         	:  14-Oct-2009
Search Tag        	:  Kernel 11.0 - Casa - Debit Card Functionality Changes

Changed By         	:  Naveen Kumar.V
Change Description 	:  FC11.0 - ITR1 SFR-697
Changed On         	:  20-Nov-2009

Changed By         	:  Naveen Kumar.V
Change Description 	:  FC11.0 - ITR1 SFR-834
Changed On         	:  23-Nov-2009

Changed By         	:  Naveen Kumar.V
Change Description 	:  FC11.0 - ITR1 SFR-873
Changed On         	:  24-Nov-2009

Changed By         	:  Sharad Gosain
Change Description 	:  FC11.1 - ITR1 SFR-864
Changed On         	:  29-APR-2010

Changed By         	:  Rohit
Change Description 	:  FC11.1 - ITR1 SFR-984
Changed On         	:  01-may-2010
Changed By         	:  Suhel MD
Change Description 	:  FC11.01 - ITR1 SFR-1543  -- cust name disaperas after populating, Deposit tab dates were not passing
Changed On         	:         24-Nov-2009

Changed By         	:  Siddhartha Patashani
Change Description 	:  FC11.1 - ITR1 SFR#1702 changes
Changed On         	:         12-may-2010

 Changed By         	:  Sharad gosain
Change Description 	:  FC11.1 - ITR1 SFR#2092 changes
Changed On         	:         12-may-2010

 Changed By         	:  Sharad gosain
Change Description 	:  FC11.1 - ITR1 SFR#2952 changes
Changed On         	:         19-may-2010

Changed By         	:  Rohit Bhan
Change Description 	:  FC11.1 - ITR1 SFR#2500
Changed On         	:  27-may-2010

Changed By         	:  Rohit Bhan
Change Description 	:  FC11.1 - ITR1 SFR#2500
Changed On         	:  3-Jun-2010

Changed By         	:  Sharad gosain
Change Description 	:  FC11.1 - ITR1 SFR#4268
Changed On         	:  4-Jun-2010

Changed By         	:  Rakesh R
Change Description 	:  FCUBS 11.1 ITR1 sfr 4463
Changed On         	:  7-Jun-2010

Changed By         	:  Rakesh R
Change Description 	:  FCUBS 11.1 ITR1 sfr 4841
Changed On         	:  11-Jun-2010

Changed By         	:  Rohit
Change Description 	:  FCUBS 11.1 ITR1 sfr 5484
Changed On         	:  21-Jun-2010

Changed By         	:  Edwin
Change Description 	:  Kernel 11.2 Centralization Changes
Changed On         	:  21-Jun-2010
Search String        :  Edwin Added for Kernel11.2

Changed By         	:  Puvi
Change Description 	:  FCUBS 11.2 9NT1428 document check list changes
Changed On         	:  24th Sep 2010
Search String        :  FCUBS11.2 9NT1428 document check list changes starts

Changed By         	:  Venkata Pradeep S
Change Description 	:  Kernel 11.2 Multi Line Linakges
Changed On         	:  08-Nov-2010
Search String           :  FCUBS11.2 ITR1 SFR#408
Changed By                 : Abhishek jain
Changed On                 : 05/10/2010
Description                : FCUBS 11.2 CHANGES FOR Linked Entities
Search string              : FCUBS 11.2 CHANGES FOR Linked Entities

Changed By               	:  IshwaryaR
Change Description 	:  FCUBS 11.2 SFR # 714,ITR-1 
Changed On               	:  11-Nov-2010

Changed By               	:  Aravinth Subramanian
Change Description 	:  Fix for problems in menu enabling during TD creation with payin option as Cheque.
Changed On               	:  18-Nov-2010
Search String		:  FCUBS 11.2 SFR # 838,ITR-1 

Changed By               	:  	Monika Verma
Change Description 	:  Fix for save button getting disabled on click of populate
Changed On               	:  23-Mar-2011
Search String		:  FCUBS11.3 ITR1 SFR# 11891621

Changed By               	: Rojalin Beura
Change Description 	:  FCUBS 11.3.1 Chqbk and Card Request
Changed On               	:  30-June-2011
Search String		:  FCUBS 11.3.1 Chqbk and Card Request

Changed By         :  Sweta Panda
Description        :  360 Degree Customer View Changes
Search String      :  9NT1466 11.3.1 360 Degree Customer View Changes

    Changed  By           : Gokulnath M
    Changed  On           : 9-Aug-2011
    Modified Reason       : 9NT1466 CIF-CASA_11.3.1 IUT changes
    Search String         : 9NT1466 CIF-CASA_11.3.1 IUT changes on 9/8/2011

Changed  By           : Suhas Rekhu
Changed  On           : 30-Aug-2011
Modified Reason       : 9NT1466 IUT sfr#543  BIRDAB sfr#255 changes
Search String         : 9NT1466 IUT sfr#543  BIRDAB sfr#255 changes	 

Changed  By           : Tapas Ranjan Pani
Changed  On           : 05-Sept-2011
Modified Reason       : Documents Tracking	 For sending notification
Search String         : 9NT1462 Standard Documents

Changed By         :  IshwaryaR
Description         :  Account number vanishing while visiting the deposit tab,so added code for retaining the account no.
Search String     :  9NT1462 Changes  by IshwaryaR 

Changed  By           : Arumugam S
Changed  On           : 15-Sep-2011
Modified Reason       : Documents Tracking	For Upload and View Documents
Search String         : 9NT1462 Standard Documents -DMS

Modified By		:	Kundan Verma
Reason			:	Removal Of hardcoded Message
Search String	:	NLS_11.4

Changed  By           : Vinodkumar Subramaniam
Changed  On           : 03-OCT-2011
Modified Reason       : Code included for Branch Code  not Defaultinng
Search String         : 11.4 ITR1 SFR#13052412 VINOD CHANGES

SFR Number           : 13067933
Changed By           : Nitin Harits
Change Description   : Multi Branch Changes
Search String        : FCUBS11.4 ITR1 SFR#13067933	 

Changed  By           : Arumugam S
Changed  On           : 13-Oct-2011
Modified Reason       : 9NT1462 -ITR1 - BUG 13090079 -Upload ,View and Delete buttons are disabled in modify because the exception is occured during the disabling the "cards" subsystem button
Search String         : 9NT1462 -ITR1 - BUG 13090079

    Changed  By           : Gokulnath M
    Changed  On           : 13-Oct-2011
    Modified Reason       : 9NT1462 ITR 13091461 disabled card product and card bin fields
    Search String         : 9NT1462 ITR 13091461 
	
    Changed  By           : Gokulnath M
    Changed  On           : 13-Oct-2011
    Modified Reason       : 9NT1462 ITR 13076898 disabled Debit Card and Cheque Book buttons
    Search String         : 9NT1462 ITR 13076898

	Changed  By            : Arumugam S
	Changed  On            : 15-Oct-2011
	Modified Reason      : 9NT1462-ITR1 -BUG 13090383 Getting multiple rows seleted in nodification
	Search String         : 9NT1462-ITR1 -BUG 13090383
       
       Modified By         : Venkatalakshmi B
       Modified On         : 15-Oct-2011
       Change Description  : 9NT1462 ITR1  SFR#13092488 ,Over-ride messages were not displayed when trying to close a account, called display message manually when response is of 'WARNING'.
       Search String       : 9NT1462 ITR1  SFR#13092488 
	   
    Changed  By           : Gokulnath M
    Changed  On           : 27-Oct-2011
    Modified Reason       : 9NT1462 ITR1 13247536 defaulted the screen arguements
    Search String         : 9NT1462 ITR1 13247536	   
	
   Changed  By            : Surekha James
   Changed  On            : 03-Nov-2011
   Modified Reason      : fnPostLoad_KERNEL of IADCUSAC, IADCUSTD, STDCUSTD moved from children to parent, STDCUSAC_KERNEL.js as fnPostLoad_Child_KERNEL
   Search String         : 9NT1462 ITR1 SFR 13338632 

   Changed  By            : Arumugam S
   Changed  On            : 19-Nov-2011
   Modified Reason      : 9NT1462 -ITR1 -BUG 13400175 :Enabling the view buttion on querying the document
   Search String         : 9NT1462 -ITR1 -BUG 13400175
   
   Changed  By             : Sathish Hariharan	
   Changed  On            :  28-Nov-2011
   Modified Reason      : 9NT1462 ITR1 Calculation of maturity Date based on the tenor entered
   Search String          : 9NT1462 ITR1 SFR# 13412162
   
   Changed  By             : Suhas Rekhu	
   Changed  On             : 09-Dec-2011
   Modified Reason         : 9NT1462 ITR2 SFR# 13475260 nominee details become disappering after the tab out/in , if entry tab after account class population is NOM.
   Search String           : 9NT1462 ITR2 SFR# 13475260 
   
     Changed  By             : Sathish Hariharan	
   Changed  On             :  22-Dec-2011
   Modified Reason       : 9NT1462 ITR2 SFR# 13528412 "PAY-IN DETAILS" AND "TERM DEPOSIT PAY-OUTDETAILS" Are amendable without unlocking
   Search String           : 9NT1462 ITR2 SFR# 13528412 

	Changed  By            : Arumugam S
	Changed  On            : 26-Dec-2011
	Modified Reason      : 9NT1462-ITR2-BUG 13500785 Cross browser issue in Acclimits sub screen
	Search String         : 9NT1462-ITR2-BUG 13500785
	
	Changed  By            : Achelal S
	Changed  On            : 08-Mar-2012
	Modified Reason      : 9nt1501 usability changes for the customer account
	Search String         : 9NT1501 12.0 USABILITY CHANGES

  Last Modified By   : AnjaliSi
  Last modified on   : 25-02-2012
  Full Version       : FCUBS_12.0.0
  Reason             : DMS callform changes
  Search String : FCUBS_12.0.0 DMS changes

	Changed  By            : Surendra Gubba
	Changed  On            : 13-Feb-2012
	Modified Reason      :   DMS Integration Changes - Work Flow Ref # is disappering after Acc Pilcup and clicking on Deposit Tab
	Search String         : FCUBS 12.0 DMS 
	
	Changed  By            : Niranjana R
	Changed  On            : 19-Mar-2012
	Modified Reason      :  Atfer modification and  unlock STDCUSTD screen and click on the interest subsystem the modified interest rate is not populating and it is showing the old interest rate
	Search String         : 9NT1501 PreIT sfr 257
	
    Changed  By           : Gokulnath M
    Changed  On           : 12-Apr-2012
    Modified Reason       : First focus field defaulted to Customer number field
    Search String         : 9NT1501 ITR1 13929880	
	
    Changed  By           : Gokulnath M
    Changed  On           : 17-Apr-2012
    Modified Reason       : Changed the focus fields
    Search String         : 9NT1501 ITR1 13959083
	
    Changed  By           : Surekha James
    Changed  On           : 02-May-2012
    Modified Reason       : Focus not moving to Account no field in safari and chrome browsers
    Search String         : 9NT1501 ITR2 14016935	
	
     Changed  By            : Surendra Gubba
	Changed  On            : 03-May-2012
	Modified Reason      :   Work Flow Ref # is disappering clicking on Compute button 
	Search String         : Sfr No# 14017227  
	
Changed By               	:  NeerajaJ
Change Description 	: In IADCUSAC screen after entering the offset account details in the auxillary tab and on tab out the offset account details get disappeared. IADCUSAC is a child screen of STDCUSAC.
Changed On               	:  10-Aug-2012
Search String		:  9NT1525_Fcubs12.0_ABIBIF_14477378
	
   Modified By                : Hemalatha N
   Modified On               : 10-August-2012
     Modified Reason       : FCUBS 11.4-> CNSL FCUBS11.4->CNSL->IDRBMIFCC0160->CASA->CHECK LIST SYSTEM IS NOT ALLOWING TO ADD T sfrno:14471704                              
  		                      Fix provided to make the add Row and delete Row button in document list multi block to be hidden ,so that the records cannot be added or modified during account creation.
				The document list details should be defaulted only from the account class and it cannot be modified/added  during account creation.
     Search String             :9NT1525_12.0_IDRBMI_CNSL_SFR#14471704   
	 
	 
	 
	Changed  By            : Preethymol S
	Changed  On            : 13-Aug-2012
	Modified Reason        : fn_ChangeTenor to change the Deposit tenor must not happen on account query,Reto done from 11.4
	Search String          : 9NT1525_12.0_TFCBTWD_14471257_RETRO 
	
	Changed  By            : NeerajaJ
	Changed  On            : 14-Aug-2012
	Modified Reason        :Unable to query TD records from ACDCBIRD screen. Added code to populate the TD details which are queried.
	Search String          : 9NT1525_12.0_CBACNY_14492986
	
	Changed By            :  Niranjana R
	Change Description 	  :  Cross Brwoser fix
	Changed On            :  13-Sep-2012
	Search String		  :  9NT1525_12.0RETRO_TZSAMAN_14596405

	Changed  By            : Niranjana R/Lavanya M
	Changed  On            : 21-Aug-2012/17-Oct-2012
	Modified Reason        : Disabling the product fields while quering./Retroed the FIX from 12.0 as it was missing.
	Search String          : 9NT1525_12.0RETRO_FBNLGBP_14519320 / 14755950 Bug no in 12.0.1
	
	Changed  By            : Gokulnath M
	Changed  On            : 17-Oct-2012
	Modified Reason        : Amount and Dates , Interest subscreen not displaying data when queried from ACDCBIRD Account details screen.
	Search String          : 9NT1525_12.0_RETRO_CBACNY_14756024 	
	 	 
	Changed By          :  Lavanya M
	Change Description 	:  Fix for Customer Account in uppercase when typed the value in lower case.Retro done for 14807294.
	Changed On          :  31-Oct-2012
	Search String		:  9NT1525_12.0_RETRO_VNDFCJS_14572018 	

	Changed  By            : Niranjana R
	Changed  On            : 24-Nov-2012
	Modified Reason        : Subsystem pickup was not happening on unlocking a TD. Code modified in fnPostUnlock_KERNEL()
	Search String          : 9NT1576_12.0.1_INTERNAL_15836360 
	
	Changed By          :Prabhat Thakur
    Change Description : Joint holder CIF Signature replication enhancement for 12.0.2
    Search String     : 9NT1587_12.0.2_CIF_SIG_ENHANCEMENT 

	Changed By          :Vinu Priyesh V.A.
    Change Description : Added functions to default tenor, rollover tenor and to calculate maturity date
    Search String     : 9NT1587 FC_DEV_12.0.2 VINU CHANGES
	
** Modified By               : IshwaryaR
** Modified On               : 26-Apr-2013
** Modified Reason           : Code changes done so that fields specific to STDCUSTD is called only for STDCUSTD and does not fails for STDCUSAC.
** Search string             : 9NT1525_12.0.2_CITI121_SFR#16731046

** Modified By               : Achelal Sharma R
** Modified On               : 08-May-2013
** Modified Reason           : Added function and code for the TD Simulation screen enhancement.
** Search string             : 9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES
**
** Modified By               : Thirumoorthy S
** Modified On               : 27-May-2013
** Modified Reason           : Final minute infra change affected all our subscreens, as per their guidance, populating function origin arrays.
** Search string             : Infra Changes - function origin array 

** Modified By               : Poornima Ramasami
** Modified On               : 06-June-2013
** Modified Reason           : Simulation fields was visible after creating TD from simulation screen.
** Search string             : 9NT1587_FCUBS_12.0.2_MAT-16917421

	Changed  By            : Gokulnath M
	Changed  On           : 12-Jan-2013
	Modified Reason      : Initial funding fields was not getting enabled due to the latest INFRA change for amount fields, Added fnPreProcessFields_KERNEL() to solve the issue
	Search String           : 9NT1587_12.0.2_MAT_16926220	  
	
	Changed  By            : Poornima Ramasami
	Changed  On           : 18-June-2013
	Modified Reason      :  interest liquidation grid was editable and rows where able to be added
	Search String           : 9NT1587_ITR1_16975835   
	
		Changed  By         : Poornima Ramasami
	Changed  On             : 20-June-2013
	Modified Reason         : Payin by cheque option was diabled on click of create deposit in TD simulation.
	Search String           : 9NT1587_ITR1_16987739

**   Modified By         : Poornima Ramasami
**   Modified On         : 20-june-2013
**   Modified Reason     : Code added for td simulation  advice
**   Search String       : 9NT1587_ITR_16987774

**   Modified By         : Anju Antony
**   Modified On         : 26-june-2013
**   Modified Reason     : Modified functions fnAccPickup() and fn_ChangeRollTenorPref() for adding tenor change validations in td creation 
                           simulation screen.
**   Search String       : 9NT1587_ITR_17007079

**   Modified By         : Anju Antony
**   Modified On         : 27-june-2013
**   Modified Reason     : Issue No.1)STDTDSIM Screen is Moving back to Simulation on Click of Compute after Create Deposit Button is clicked. 
                           Issue No.4)on Clicking Create deposit and cancelling the same ,New Button is enabled in the STDTDSIM Screen .After Entering Acc Class ,Currency and Customer ,Click on Populate.Screen Moving back to Sim Screen  Where Clear ,View Advice ,Create depsoit is Not present.
**   Search String       : 9NT1587_12.0.2_SFR_NO:17020901

**	Changed By          :  Vinodkumar Subramaniam
**	Change Description 	:  Fix for updating the mod no is provided
**	Changed On          :  28-Jun-2013
**	Search String		:  9NT1587_12.0.2_ITR1_SFR#17023887

**	Changed By          :  Poornima Ramasami
**	Change Description 	:  Payin by cheque enabled on load of TD simulation screen to default the cheque details in td payin details.
**	Changed On          :  2-July-2013
**	Search String		:  9NT1587_12.0.2_ITR1_17028331

**	Changed By          :  Achelal Sharma
**	Change Description 	:  Payin by cheque to be enabled on click of create deposit button.
**	Changed On          :  15-July-2013
**	Search String		:  9NT1587_12.0.2_ITR1_16976099
**
**    Modified By        : Vatsa Narayanan
**    Modified On        : 23rd July,2013
**    Modified Reason    : Through GW IO_PK Request, Tag <DOCUMENT_TYPE> is not available as its a ReadOnly Primary key Field in RAD and hence Primary key cannot be null Issue
**                                Unchecked the field DOCUMENT_TYPE for Read Only in RAD and made as Disabled in the Screen
**    Search String      : 9NT1587_12.0.2_INTERNAL_ITR1_17175911

** Changed By           : Vinu Priyesh V.A.
** Changed On			: 23-July-2013
** Change Description   : Assigned tenor to NULL when changing the rollover tenor preference to independent tenor
** Search String        : 9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17203797

** Changed By           : Vinu Priyesh V.A.
** Changed On			: 31-July-2013
** Change Description   : Fix given to prevent independent from setting NULL when moved to other TAB
** Search String        : 9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700

** Changed By           : Poornima Ramasami
** Changed On			: 12-Aug-2013
** Change Description   : STDTDSIM screen Issues
** Search String        : 9NT1587_12.0.2_ITR1_17299229 

** Changed By           : Nitesh
** Changed On			: 13-Aug-2013
** Change Description   : Added logic to handle U in the customer account mask for Account Number Generation 
** Search String        : 9NT1606_12.0.2_IXOFBRM_RETRO_17267311 Changes

** Changed By           : Vinu Priyesh V.A.
** Changed On			: 22-Aug-2013
** Change Description   : Fix given to move to next field on tab out for rollover tenor.  Fix given to prevent rollover tenor from setting null on unlock
** Search String        : 9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421

** Changed By           : Vinu Priyesh V.A.
** Changed On			: 27-Aug-2013
** Change Description   : Fix given to update the value of maturity date when it is changed in interest subsystem.
** Search String        : 9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17356748

** Changed By           : Naveen A
** Changed On			: 28-Aug-2013
** Change Description   : Changed the focus to Initial deposit amount when the function id is STDCUSTD
** Search String        : 9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17332691

    Changed  By           : Gokulnath M
    Changed  On           : 02-Sep-2013
    Modified Reason       : Unable to view the uploaded documents
    Search String         : 9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17340275


    Modified By            : Poornima Ramasmai
    Modified On            : 14-Oct-2013
    Modified Reason        : Getting value to the new field 'alw_eu_or_comm' which is hidden and cheque book type is enabled or disabled according to the mask maintained.
    Retro Source           : 9NT1606_12.0.1_17495661
    Search string          : 9NT1606_12.0.2_INTERNAL_RETRO_17600251
**
**  Changed By             : Shayam Sundar Ragunathan
**  Changed on             : 08-Feb2013
**  Change Reason          : After visiting the screen STCACLOS,if any error is occurred then again click on close button system  raises Error in Close operation so again calling fnExecuteQuery() if 'msgStatus' is FAILURE.
**  Search String          : 9NT1606_12.0.2_GBPFBN_RETRO_17719893
**
**  Changed By             : Shayam Sundar Ragunathan
**  Changed on             : 06-Nov-2013
**  Change Reason          : Checking whether the account description is null before assigning the Customer name to it...
**  Search String          : 9NT1606_12.0.2_IALLUBT_RETRO_17745912
**
** Modified By             : Shayam Sundar Ragunathan
** Modified On             : 13-Nov-2012
** Modified Reason         : Reverted the fix given for sfr :14471704(9NT1525_12.0_IDRBMI_CNSL_SFR#14471704).
                             since it is restrictring the existing functionality and the end user customization.
** Search string           : 9NT1606_12.0.2_GIBCUST_RETRO_17789049
**
** Modified By             : Shayam Sundar Ragunathan
** Modified On             : 18-Nov-2013
** Modified Reason         : Amounts and Dates button was not getting enabled after authorization of CASA.So,code changes done such that it gets enabled after auth.
** Search string           : 9NT1606_12.0.2_IGIBCUST_RETRO_17812052
**

	Changed  By            : Gokulnath M
	Changed  On            : 15-Nov-2013
	Modified Reason        : NLS changes done for all months and days
	Search String          : 9NT1606_12.0.2_IUSDBOA_RETRO_17786519
	
	Changed  By            : Vinu Priyesh V.A.
	Changed  On            : 26-Nov-2013
	Modified Reason        : Added the currency field values in preload of screen amount and dates to prevent the unwanted related currency information message
	Search String          : 9NT1606_FCUBS12.0.2_RETRO_17631898

	Changed  By            : Mythili Panneerselvam
	Changed  On            : 29-JAN-2014
	Modified Reason        : To launch STDCUSAC in ORDLPTEM
	Search String          : 12.0.3 Origination Changes
	
	Changed  By            : Gokulnath M
	Changed  On            : 05-Mar-2014
	Modified Reason        : Status fields are enabled for modification before first authorization
	Search String          : 9NT1606_12.0.3_UCBL_RETRO_18350748 
	
	Changed By               	: Janardan Jayaraman
	Change Description 	: On copy nullifying the clearing account number and populating the same with the generated account number on acc no. generation.
	Retrod On           : 09-May-2014
	Search String		: 9NT1606_12.0.3_ASKARI-RETRO-18731408
	RETRO From			: 9NT1525_11.3_ASKARI_14502104 
	
	Changed By               	: Janardan Jayaraman
	Change Description 	        : On copy resetting the alternate account number in the response DOM to null.
	Retrod On                	: 09-May-2014
	Search String		        : 9NT1606_12.0.3_IPKRASK-RETRO-18731464
	RETRO From					: 9NT1525_11.3_ASKARI_14209143 Changes
	
    Changed  By            : Viba R 
	Changed  On            : 26-May-2014
	Modified Reason        : User was unable to add rows in order to capture pay-in details as the system was not able to move the 
	                         control to the focus.Handled the same by setting the focus to td amount.
	Search String          : 9NT1606_12.0.3_RETRO_18838183 
**
**  Modified By     	: Narayanan Baskar
**  Modified On       	: 02nd June, 2014
**  Modified Reason   	: In Notice subscreen for field Monthly free amount the related currency field is going as null. And hence assigned the account currency for decimal conversion of Monthly free amount field.
**  Retro Source  	   	: 9NT1606_FCUBS_12.0.1_NEDBANK LIMITED_SFR#18393709
**  Search String      	: 9NT1606_1203_NEDBANKLIMITED_RETRO_18886046
**  
**  Modified By     	: Gokulnath M
**  Modified On       	: 20 June, 2014
**  Modified Reason   	: Exception is raised in js because of the improper code for Copy operation, commented the same
**  Search String      	: 9NT1606_12.0.3_BANQUE_MISR_RETRO_19028052

	Changed  By            : Hemalatha N
	Changed  On            : 24-June-2014
	Modified Reason        : retro bug _18349941:Deposit details are not getting fetched on drill down from the 360 degree view function ID. STDRETVW & STDCUSVW
	Search String          : 9NT1606_12.0.3_RETRO_19052138
	
Changed By           : Anuja.V.S
Changed on           : 30-Jun-2014
Change Reason        : Disabled the modification of Account status at STDCUSAC screen.
Search String        : 9NT1606_12.0.3_RETRO_19125491
Rerto String         : 9NT1606_12.0.2_RETRO_18722224

**  Modified By         : Nalandhan G
**  Modified On       	: 09-Jul-2014
**  Modified Reason   	: Code added to  to enable the Amount and Dates Button after auth without calling the fnexecutequery which cause resizing of the screen. 
**  Search String      	: 9NT1606_12_0_3_RETRO_19142520

**  Modified By     	: Gokulnath M
**  Modified On       	: 09-July-2014
**  Modified Reason   	: Account class type is hidden to avoid user to input the values from the front end
**  Search String      	: 9NT1606_12.0.3_INTERNAL_19179661

**  Modified By     	: Edwin L
**  Modified On       	: 16-July-2014
**  Modified Reason   	: Return true is missing in function end because of that Unable to call Custom,Cluster while account number generation.
**  Search String      	: 9NT1606_12.0.3_IRONVBR_19217026

**  Modified By     	: Gokulnath M
**  Modified On       	: 09-July-2014
**  Modified Reason   	: return true in fnPreSave_CVS_ACNO_KERNEL should be done only when msgStatus is SUCCESS
**  Search String      	: 9NT1606_12.0.3_INTERNAL_19234690

**  Modified By     	: Niranjana R
**  Modified On       	: 05-Aug-2014
**  Modified Reason   	: On querying a TD account and visiting the Statement subsystem,'Please Enter value in Related ccy field of this amount field' message is displayed and Previous statement Balance is not displayed in the screen.
						  Code added in fnPreLoad_CVS_STATEMENT_KERNEL to set the dbDataDOM value for CCY1 of Statement subsytem with the account ccy of TD.
**  Search String      	: 9NT1606_12.0.3_UNION_BANK_19344703 

** Changed By         : Ravi Ranjan
** Changed on         : 11-Aug-2014
** Change Description : For Casa Account Report To Wrong GL
** Search String      : 9NT1606_12.0.3_PVATBJPY_RETRO_19412090

**  Modified By     	: Naveen A
**  Modified On       	: 19-Aug-2014
**  Modified Reason   	: Nominee fields are getting enabled without pressing add row button and disappearing when tab out.
**  Search String      	: 9NT1606_12.0.3_UNION_BANK_19437179

**  Modified By     	: Hemalatha N
**  Modified On       	: 22-Aug-2014
**  Modified Reason   	: Reverted the changes done against bug 19437179 since it is creating issue for STDCUSAC screen.
**  Search String      	: 9NT1606_12.0.3_INTERNAL_19486679

**  Modified By     	: Naveen A
**  Modified On       	: 25-Aug-2014
**  Modified Reason   	: Modified nominees tab condition(Issue caused because of infra changes done against 18474415)
**  Search String      	: 9NT1606_12.0.3_UNION_BANK_19437179_1

**  Modified By     	: Naveen A
**  Modified On       	: 26-Aug-2014
**  Modified Reason   	: Js error is throwing after clicking populate in STDCASAC, hence added code. 
**  Search String      	: 9NT1606_12.0.3_UNION_BANK_19505074

**  Modified By     	: Hemalatha N
**  Modified On       	: 29-Oct-2014
**  Modified Reason   	: On clcik of Unlock button next maturity date is getting disappeared because the value is reset in fn_changerolltenorpref function.Fix provided to correct the same.
**  Search String      	: 9NT1606_12.0.3_TIEN PHONG BANK_19909048 
**
**  Modified By     	: Shayam Sundar Ragunathan
**  Modified On       	: 29-Oct-2014
**  Modified Reason   	: Interest pickup have been restricted for actions other than new and modify.
**  Search String      	: 9NT1606_12.0.3_IRONVBR_19947532

** Changed By         : Poornima Ramasami
** Changed on         : 20-NOV-2014
** Change Description : For copy operation, Check book request and Debit card request subsystems are disabled. 
                        Code changes done to enable the Check book request and Debit card request subsystems for copy operation.
** Retro String       : 9NT1606_12.0.2_CNSL_AUDI_20022217
** Search String      : 9NT1606_12.0.3_RETRO_20067218
**
**  Modified By       : Shayam Sundar Ragunathan
**  Modified On       : 16-Feb-2015
**  Modified Reason   : fnEnableAmendFields() function got modified in FCUBS12.1..retroing fix given by Infra.
**  Search String     : FCUBS_12.1.0_AmmendIssue

**  Modified By       : Monica R
**  Modified On       : 13-Jan-2015
**  Modified Reason   : The field IBANRQD and BTN_CALLIBAN are made invisible and removed from the fieldset.
**  Search String     : FCUBS_12.1.0.0.0_DEV_<IBAN_Enhancements>

**  Modified By       : Monica R
**  Modified On       : 03-Mar-2015
**  Modified Reason   : The account number generation logic is modified for the additional parameter r.
**  Search String     : PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode

**  Modified By       : Althamis Aboobakker
**  Modified On       : 14-May-2015
**  Modified Reason   : 12.1 Sanction check related changes
**  Search String     : FCUBS_12.1.0.0.0_DEV_Sanction_Check  

**  Modified By     		: Preethika R
**  Modified On       	: 29-May-2015
**  Modified Reason   	: INTERIM TRANSACTIONS REPORT TAB. WRONG FLAG USED FOR MT941 VALIDATION   
**  Search String      	: 9NT1606_12.1_BARCLAYS_UAE_21169265

**  Modified By   	  : N S Anirudhan
**  modified on   	  : 26-May-2015
**  Modified Reason   : Customer Landing Page Retro from 12.0.2
**  Search String     : PNTFLX01011: FCUBS12.1.0.0.0_Customer_Landing_Page

**  Modified By       : Niranjana R
**  Modified On       : 05-May-2015
**  Modified Reason   : Changes done to display the tenor details based on tenor preferences- TD Additional Rollover changes.
**  Search String     : 9NT1606_12_1_TD_ADD_ROLLOVER

** Changed by         :  Althamis Aboobakker
** Changed On         :  09-Jun-2015
** Change Description :  Enabling the sacntion check button on inTab of STDCUSAC
** Search String      :  PNTFLX01011_DEV_FCUBS_12.1_IQA_21228412

** Changed by         :  Althamis Aboobakker
** Changed On         :  13-Jun-2015
** Change Description :  Unable to upload the documents. Adding the event in functions.
** Search String      :  PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301
*
**  Modified By       : Preethika R
**  modified on       : 13-Jun-2015
**  Reason            : CASA Landing page changes
**  Search String     : PNTFLX01011_DEV_FCUBS_12.1_IQA_21247255
**
**  Modified By       : Suresh Babu B
**  modified on       : 18-Jun-2015
**  Reason            : Changes made to display products linked with the account class.
**  Search String     : PNTFLX01011_DEV_FCUBS_12.1_IQA_21272136
**
**
**  Modified By       : Shayam Sundar Ragunathan
**  modified on       : 24-Jun-2015
**  Reason            : Commented gAction = '' and gave showProcessMsg = false to avoid multi entry single view error as suggested by INFRA.
**  Search String     : PNTFLX01011_FCUBS_12.1_MAT_21310050
**
**  Modified By       : Althamis Aboobakker
**  modified on       : 2-Jul-2015
**  Reason            : Account number field has to enabled for amending only if mask contains 'a' or 'n'. Modified the code for the same.
**  Search String     : PNTFLX01011_FCUBS_12.1_ITR1_21361038
**
**  Modified By       : Suresh Babu B
**  modified on       : 04-Jul-2015
**  Reason            : UDECCY in interest subsystem will be null after save. Changes done to display the UDECCY.
**  Search String     : PNTFLX01011_FCUBS_12.1_ITR1_21345048
**
**  Modified By       : Suresh Babu B
**  modified on       : 06-Jul-2015
**  Reason            : Changes done to default the Int rate based on Cum amnt & Continu variance on roll flags.
**  Search String     : PNTFLX01011_FCUBS_12.1_ITR1_21371752
**
**  Modified By       : Suresh Babu B
**  modified on       : 15-Jul-2015
**  Reason            : As suggested by infra added fnCalcHgt() inside the function fn_simulation_visibility to overcome the overlapping issue. 
**  Search String     : PNTFLX01011_FCUBS_12.1_ITR1_21348030

**  Modified By       : Monica R
**  modified on       : 22-Jul-2015
**  Reason            : CSRF token should not be passed in the URL. Hence changed the downloadDocument function as suggested by infra to overcome security vulnerability.
**  Search String     : PNTFLX01011_FCUBS_12.1_ITR1_21423515

     **  Modified By           : Althamis Aboobakker
     **  Modified On           : 24-Jul-2015
     **  Modified Reason       : System is enabling TD Payin multigrid on click of fetch. 
     **  Search String         : PNTFLX01016_FCUBS_12_1_0_ITR1_21490825
	 
**  Modified By       : Suresh Babu B
**  modified on       : 24-Jul-2015
**  Reason            : While changing the Rollover tenor details its not getting populated based on the selected tenor preferences. Changes done to
						default the tenor details based on selected tenor preferences.
**  Search String     : PNTFLX01011_FCUBS_12.1_ITR1_21477045

**  Modified By       : Niranjana R
**  modified on       : 03-Aug-2015
**  Reason            : In IADCUSTD screen TD payout details, the BC tab, instrument type is shown as Undefined.
					  : Code included to display instrument type same as STDCUSTD.
**  Search String     : PNTFLX01011_FCUBS_12.1_ITR1_21513631 
**
**
**  Modified By          : Althamis Aboobakker
**  Modified On          : 08-Aug-2015
**  Modified Reason      : Sanction check code roll back. Commenting the related code.
**  Search string        : PNTFLX01016_FCUBS_12.1.0_ITR1_21593910
**
**   Modified By         : Shayam Sundar Ragunathan
**   Modified On         : 13-Aug-2015
**   Modified Reason     : UDE CURRENCY showing as 'UNDEFINED', Restricted the assignment of UDECCY from screen args for functions other than STDCUSTD and IADCUSTD
**   Search String       : PNTFLX01016_FCUBS_12.1.0_ITR1_21625803
**
**  Modified By       : Niranjana R
**  modified on       : 21-Aug-2015
**  Reason            : On Changing rollover options in STDTDSIM screen, the rollover tenor fields are not enabled/disabled as expected. Fix provided to enable/disable the rollover tenor fields. 
**  Search String     : PNTFLX01011_12.1_ITR2_21669908
**
**  Modified By       : Suresh Babu B
**  modified on       : 28-Aug-2015
**  Reason            : Unable to enter the TD payin details in IADCUSTD. Changes done to resolve the same. 
**  Search String     : PNTFLX01011_12.1_ITR2_21690178
**
**  Modified By       : Suresh Babu B
**  modified on       : 03-Sep-2015
**  Reason            : No response from system On click of Delete button. Changes done to delete the uploaded document from server on click of delete.
**  Search String     : PNTFLX01011_12.1_ITR2_21768953
**
**  Modified By       : Suresh Babu B
**  modified on       : 07-Sep-2015
**  Reason            : getting Duplicate clg acc found error, When the TD account is copied from the Deposit tab.
**  Search String     : PNTFLX01011_12.1_ITR2_21776031
**
**Modified By          : Suresh Babu B
**Modified On          : 09-Sep-2015
**Modified Reason      : Made pay in option cheque fields in STDCUSTD screen to be enabled on copy of existing TD account.
**Search String        : PNTFLX01011_12.1_ITR2_21808335
**
**Modified By          : Suresh Babu B
**Modified On          : 11-Sep-2015
**Modified Reason      : Cheque details are enabled even the payin mode is other than cheque.
**Search String        : PNTFLX01011_12.1_ITR2_21821189
**
**
**Modified By          : Althamis Aboobakker
**Modified On          : 15-Sep-2015
**Modified Reason      : Unable to view the uplaoded documents. call to function createTempForwardIframe is present which is part of DMSUtility.js . This JS will not be loaded by default in the list of JS files that are loaded for each of the Function ID. Changes needs to be done in the kernel js to load the same during screen launch.
**Search String        : PNTFLX01011_12.1_ITR2_21828141
**
**  Modified By       : Ravi Ranjan
**  Modified On       : 09-02-2015
**  Modified Reason   : Code changes for FCUBS 12.2.0 CIFCASA_RANGE item
**  Search String     : FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range
**
**  Modified By       : Priya
**  Modified On       : 11-05-2016
**  Modified Reason   : Restricted the call to createTempForwardIframe only for Detailed screen as suggested by infra to overcome 
						the conflict of excel export code when DMSUtility.js is loaded in KERNEL.js file
**  Search String     : [FCUBS12.2-INTERNAL-ITR2-23241803]
**
**  Modified By       : Priya
**  Modified On       : 11-05-2016
**  Modified Reason   : Added space between the variable and condition
**  Search String     : [FCUBS12.2-INTERNAL-OSDC-23289258]
**
**  Modified By         : Nalandhan G 
**  Modified On         : 05-Jul-2016
**  Modified Reason     : When populate is done from the Auxiliary tab, the value of variable 'atmfaclty' in the 
                          function 'fnAtmCheck()' is not set as it is in the Main tab.
**  Retro String        : 9NT1606_12.0.3_CNSL_22460182
**  Search string       : 9NT1606_12_2_RETRO_12_0_3_23655031
**
**  Modified By         : Nalandhan G
**  Modified On         : 05-Jul-2016
**  Modified Reason     : Code modified to enable all other tabs after we launching the account no screen
                          from Main tab
**  Retro String        : 9NT1606_12_0_3_CNSL_MOHANOKOR_22626445
**  Search string       : 9NT1606_12_2_RETRO_12_0_3_23652433

**  Modified By         : Priyanka Vijai   
**  Modified On         : 05-July-2016
**  Modified Reason     : Code Added to Default the Account No as per the length maintained for each Mask parameter
**  Search string       : 9NT1606_12_2_RETRO_12_0_3_23654867 
** Retro String         :  9NT1606_12_0_3_CNSL_21821726 
**
**  Modified By         : Priyanka Vijai   
**  Modified On         : 02-Aug-2016
**  Modified Reason     : Inclusion of pin code in casa screens
**  Search string       : 9NT1606_12_2_RETRO_12_0_3_23657954  
**  Retro String        : 9NT1606_12.0.3_CNSL_21977573 
**
**  Modified By         : Priyanka vijai
**  Modified On       	: 09-Aug-2016
**  Modified Reason   	: Call not going into custom js handler functions because of missing return true in kernel handlers.
**  Retro  String      	: 9NT1606_12_0_3_CNSL_22763219
**  Search  String      : 9NT1606_12_2_RETRO_12_0_3_23658197
**
**  Modified By         : Nalandhan G
**  Modified On       	: 27-Aug-2016
**  Modified Reason   	: Failing in JS while assigning maturity date. Skipping the maturity date 
                          assignment for casa screens. 
**  Retro  String      	: 9NT1606_12.0.2_CNSL_21900812
**  Search  String      : 9NT1606_12_2_RETRO_12_0_2_23657655
**
**  Modified By         : Nalandhan G
**  Modified On       	: 16-Sep-2016
**  Reason              : Code has been commented as the line dbDataDOM,"//BLK_NOTICEPREF/CCY"
                          is getting failed here due to which the funciton 
                          fnPostClose_CVS_AUTHORIZE is not called and screen does not closed.
**  Retro String        : 9NT1606_12.0.2_ACCESS BANK PLC_21338277
**  Search  String      : 9NT1606_12_2_RETRO_12_0_2_23656232
**
**  Modified By         : Nalandhan G
**  Modified On       	: 16-Sep-2016
**  Modified Reason   	: Code added to assign NEW action during Clear
**  Retro String        : 9NT1606_12_0_3_CNSL_AUDI_23061706
**  Search  String      : 9NT1606_12_2_RETRO_12_0_3_23656818


**Modified By          : Anuja.V.S
**Modified On          : 12-Feb-2016
**Modified Reason      : Code changes done to exit the Main screen if the user cancels the account number generation screen
**Search String        : 12.2_SUPPORT_RETRO_23664359

** Modified By          : Monica R
** Modified On          : 29-Sep-2016
** Modified Reason      : Code added to populate UDE values based on product and effective date.
** Retro  String        : 9NT1606_12_0_3_CNSL_23256589
** Search String        : 9NT1606_12_2_RETRO_12_0_3_23652204

** Modified By          : Monica R
** Modified On          : 29-Sep-2016
** Modified Reason      : For supporting islamic casa in customer landing page
** Retro  String        : 23621880
** Search String        : 24344218 

** Modified By          : Aditi
** Modified On          : 12-oct-2016
** Modified Reason      : retro for 24763574
** Search String        : FCUBS_12.2_SUPPORT_24813532

** Modified By          : Priyanka vijai
** Modified On          : 13-Oct-2016
** Modified Reason      : Changes were made in stdcusac_kernel.js in fnPostExecuteQuery_KERNEL, since the query of notice tab is getting failed with 'CCY precision error' for the monthly amount field.
                          Hence the currency value has been assigned for 'STDCUSAC' function id.
** Search String        : 9NT1606_12_2_RETRO_12_0_3_24707021 
** Retro String         : 9NT1606_12.0.3_CNSL_24471496 

** Modified By          : Monica R
** Modified On          : 17-Oct-2016
** Modified Reason      : In STDCUSAC screen DMSUtility.js  is refered in Kernel unit for view document feature. Code changes done to restrict the loading of the JS unit only to detail screen.
** Retro  String        : 23738344
** Search String        : 9NT1606_12_2_RETRO_12_1_24604443 

**  Last Modified By  : Monica R
**  Last modified on  : 28-Nov-2016
**  Retro  String     : 9NT1606_1202_CNSL_NBE_25102205
**  Reason            : Code added to default the Clearing Ac No from DOM
                        Code corrected to default the Clearing Ac No and Alternate Ac No
**  Search String     : 9NT1606_12_2_RETRO_12_0_2_25160035		
**
** Modified By        : Shayam Sundar Ragunathan
** Modified On        : 06-Feb-2017
** Modified Reason    : Clearing account number is not nullyfied on Copy from a tab other than Main.
** Search String      : 9NT1606_12_3_RETRO_12_0_3_25502117

** Modified By           : J.Abinaya
** Modified On           : 9-Mar-2017
** Modified Reason       : multi currency account changes
** Search String         : Fcubs_12.4_multi_currency_accounts
**
** Modified by            : Nalandhan G
** Modified On            : 07-Mar-2017
** Modified Reason        : Currency field enabled after unlock.Fix given to disable the same.
** Retro String           : FCUBS_1203_AUDI_24739594
** Search string          : 9NT1606_12_3_RETRO_12_1_25402429
**
** Modified By           : Nalandhan G
** Modified On           : 24-Jul-2017
** Modified Reason       : For execute query operation, ATM Details are getting enabled.
                           Code changes done to disable the ATM Details during execute 
                           operation.
** Retro String          : FCUBS_12.1_CNSL_PRASAC_MICROFINANCE_SFR#26310077
** Search string         : 9NT1606_12_4_RETRO_12_1_26440939


**Modified By            : Akshara Jorigal
** Modified On           : 21-Sep-2017
** Modified Reason       : UDE Default button is disabled for modify operation, enabling the same.
** Retro String          : 9NT1606_12_3_CNSL_ALPHA_26717130
** Search String         : 9NT1606_12_4_RETRO_12_2_26818184

** Modified By           : Ananth Raj B
** Modified On           : 02-Nov-2017
** Modified Reason       : Change Log subsystem should not be loaded without primary key details. Added validation for the same.
** Search String         : 9NT1606_12_4_INTERNAL_27014222

** Modified By           : Yogendra Moganti
** Modified On           : 02-Mar-2018 / 22-Mar-2018
** Modified Reason       : Bug 27606344 - TD DETAILS ON 360 VIEW SCREEN 
** Search String         : Bug_27606344
				
** Modified By           : Arun V
** Modified On           : 21-May-2018
** Modified Reason       : code added to support special characters others then hyphen in account mask on manual generation
** Search String         : Bug_28054487

** Modified By           : Anju Antony
** Modified On           : 28-June-2018
** Modified Reason       : When a multi-curreny account number is saved and immediately copied without closing the screen, then the multi-curreny account number is getting populated with the old garbage value even though the account class has been changed to non-multi currency account.
** Search String         : FCUBS_12.4_CNSL_PRINCE FINANCE PLC_SFR#28254432
**
** Modified By           : Anuja.V.S
** Modified On           : 05-July-2018
** Modified Reason       : When maturity date is changed then deposit tenor is not getting changed automatically in mozilla browser. 
                           Fix provided to assign the value for maturity date properly inorder to change tenor.
** Search String         : FCUBS_12.4_CNSL_SAIGON_COMMERCIAL_BANK_SFR#28229496

** Modified By           : Arunkumar R
** Modified On           : 12-July-2018
** Modified Reason       : Fix provided to pass the account branch for F6 operation
** Search String         : 28331807
**
** Modified By           : Anuja.V.S
** Modified On           : 17-Sep-2018
** Modified Reason       : When maturity date is changed then Invalid date format error is being displayed.
                           Fix provided to pass the event in fn_ChangeTenor and moved the validateInputDate to the beginning.
						   this will handle the assignment for maturity date for mozilla so commented the explicit assignment.
** Search String         : FCUBS_12.4_CNSL_JOINT_STOCK_SFR#28606694

** Modified By           : Sunny Suman
** Modified On           : 28-July-2019
** Modified Reason       : For Multibranch access user branch code can be inputted twice when STDCUSTD is opened on 360 view screen.
** Search String         : Bug_30075735

** Modified By           : Karthik Krishnamurthy
** Modified On           : 14-Oct-2019
** Modified Reason       : Date comparision while booking TD is happening on display value , which is not wrong - value to be used is DB column value.
** Search String         : 30400832 
*/
//------------------------------------------------------------------------------
// VARIABLE DECLARATIONS
//------------------------------------------------------------------------------

var fcjRequestDOM;
var fcjResponseDOM;
var g_temp = "";  //9NT1587_12.0.2_CIF_SIG_ENHANCEMENT
var g_tempui = "";  //9NT1587_12.0.2_CIF_SIG_ENHANCEMENT
var gChecked; //FC10.3 - SFR#632

var gErrCodes = "";

var gSubsysStat;
var gPrevAct;
//var accgenAmendArr = new Array(); //FCUBS_12.1.0_AmmendIssue - commented
var custname; //FC11.01-ITR1 SFR-1543
var gdbDOM; //FCUBS11.1,SFR#2500,ITR-1
var custname1 = "";  // FCUBS 11.1 ITR1 SFR# 4954 changes
var gscrname; //added for fcubs11.1,sfr#5484,itr-1
var onceAuth = false; //9NT1462 ITR 13076898
var gSkipDeposit = false; // FCUBS 12.0 DMS 
var g_nullify_tenor = true; //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700
var lfnViewChangeLog = fnViewChangeLog;/*9NT1606_12_4_INTERNAL_27014222 CHANGES*/
//Edwin Added for Kernel11.2 Starts

//PNTFLX01011_12.1_ITR2_21828141 Changes starts
if(functionId != 'STSCUSAC'){ //9NT1606_12_2_RETRO_12_1_24604443 added
var jsElement = document.createElement('script');
	jsElement.setAttribute('type','text/javascript');
	jsElement.setAttribute('src','Script\/JS\/DMSUtility.js');
	document.getElementsByTagName("head")[0].appendChild(jsElement);
}	//9NT1606_12_2_RETRO_12_1_24604443 added
//PNTFLX01011_12.1_ITR2_21828141 Changes ends

function fnPreCloseTxnBranch(){
    debugs(" In fnPreCloseTxnBranch", "");
    return true;
}

function fnPostCloseTxnBranch(){
    debugs("In fnPostCloseTxnBranch", "");
    document.getElementsByName("BRN")[0].value = g_txnBranch; //Multi Branch Changes
    return true;
}


function fnPreNew_KERNEL()
{
        var newAction = true;
	debugs("In fnPreNew", "A");
	if (!fnShowTxnBrnScreen())
		newAction = false;

	return true; //fnShowTxnBrnScreen just doing 'retrun'. always returning false. so manually returning true to proceed postnew
}
//Edwin Added for Kernel1.2 Ends

function fnPostNew_KERNEL()
{
	try{ //PNTFLX01011_DEV_FCUBS_12.1_IQA_21247255
if(document.getElementsByName('BRN')[0].value=='')
 //11.4 ITR1 SFR#13052412 VINOD CHANGES starts  
    if(typeof(multiBrnAccessReq)!= "undefined" && multiBrnAccessReq=="Y" && multiBrnScrOpened == false && mainWin.gActiveWindow.screenType != "WB"){
	} else {
		document.getElementsByName('BRN')[0].value = mainWin.CurrentBranch;
		fnDisableElement(document.getElementsByName('BRN')[0]);
	}
//11.4 ITR1 SFR#13052412 VINOD CHANGES ends
      //document.getElementsByName('BRN')[0].value=mainWin.CurrentBranch;
	disableForm();
	fnEnableElement(document.getElementsByName("BTN_EXIT")[0] );
	fnEnableElement(document.getElementsByName("ACCLS")[0]);
	fnEnableElement(document.getElementsByName("CCY")[0]);
	fnEnableElement(document.getElementsByName("CUSTNO")[0]);
	fnEnableElement(document.getElementsByName("BTN_ACCPKP")[0]);
	fnEnableElement(document.getElementsByName("SPL_AC_GEN")[0]);//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range
//9NT1428 FCUBS 11.2 Changes By Aslam Startz
	fnEnableElement(document.getElementsByName("PAYINBYCHQ")[0]);
	//fnEnableElement(document.getElementsByName("PAYINCHQNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnEnableElement(document.getElementsByName("PAYIN_CHQ_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnEnableElement(document.getElementsByName("PAYINCLGBNK")[0]);
	fnEnableElement(document.getElementsByName("PAYINCLGBRN")[0]);
	fnEnableElement(document.getElementsByName("PAYINCLGPRD")[0]);
	//fnEnableElement(document.getElementsByName("PAYINCHQDATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnEnableElement(document.getElementsByName("PAYIN_CHQ_DATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnEnableElement(document.getElementsByName("PAYINDRWACNO")[0]);
	//fnEnableElement(document.getElementsByName("PAYINROUTINGNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnEnableElement(document.getElementsByName("PAYIN_ROUTING_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
//9NT1428 FCUBS 11.2 Changes By Aslam Endz
      document.getElementById('BLK_CUST_ACCOUNT__CASACC').value='N';

		//document.getElementsByName("DIVFooter")[0].children[0].all[45].disabled  = true;  //Kernel 11.0 - Casa - Debit Card Functionality Changes
		// Commented the below code as it was going into exception 
		//document.getElementsByName("DIVFooter")[0].children[0].all[52].disabled  = true;  //Kernel 11.0 - Casa - Debit Card Functionality Changes (Disabling 'Cards' Button) FCUBS 11.1 ITR1 sfr 4463
		fnDisableSubSystemButton(document.getElementById('STCCRDSA').firstChild); //9NT1501 ITR1 13929880 Modified the above code
		document.getElementById("BLK_CUST_ACCOUNT__CUSTNO").focus(); //9NT1501 ITR1 13929880
		 //PNTFLX01011_DEV_FCUBS_12.1_IQA_21247255 starts
    }
    catch (e)
    {}
    if(typeof(mainWin.gCustInfo["CustNo"])!= 'undefined' && mainWin.gCustInfo["CustNo"]!='' && (functionId !='IADCUSAC' && functionId !='IADCUSTD'))
    {
        document.getElementById("BLK_CUST_ACCOUNT__CUSTNO").value = mainWin.gCustInfo["CustNo"];
        //fireHTMLEvent(document.getElementById("BLK_CUST_ACCOUNT__CUSTNO"), "onChange"); // Infra change
        fnCreateOnchangeEvent(document.getElementById("BLK_CUST_ACCOUNT__CUSTNO"));
    }
    //PNTFLX01011_DEV_FCUBS_12.1_IQA_21247255 ends
	//9NT1606_12.0.3_INTERNAL_19179661 starts
	if(functionId=='STDCUSAC') {
		document.getElementById("BLK_CUST_ACCOUNT__ACCLSTYP").previousSibling.parentNode.style.display = "none"; //ACCLSTYP changes	
	}
	//9NT1606_12.0.3_INTERNAL_19179661 ends	
   //fnDisableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]);  //FCUBS_12.1.0.0.0_DEV_Sanction_Check	  //PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes
    return true;
}
// PNTFLX01011_DEV_FCUBS_12_1_Joint_Holder_Display Starts
function fnSetHotKeyBranch_KERNEL(e)
{
	var event=window.event||e;
	var srcElement=getEventSourceElement(event);
	var srcID=srcElement.id;
	if (srcID =='BLK_INTDETAILS__CALCACC')
	hotKeyBrn = document.getElementById("BLK_INTDETAILS__BRN").value;
	else if (srcID =='BLK_INTDETAILS__BOOKACC')
	hotKeyBrn = document.getElementById("BLK_INTDETAILS__BRN").value;
	else if (srcID =='BLK_INTDETAILS__CHGBOOKACC')
	hotKeyBrn = document.getElementById("BLK_INTDETAILS__BRN").value;
	//Fix for 28331807
	else if (srcID =='BLK_CUST_ACCOUNT__ACC')
	hotKeyBrn = document.getElementById("BLK_CUST_ACCOUNT__BRN").value;	
	return true;
}
// PNTFLX01011_DEV_FCUBS_12_1_Joint_Holder_Display Ends
function fnPostUnlock_KERNEL()
{
	//9NT1606_12.0.3_INTERNAL_19179661 starts
	if(functionId=='STDCUSAC') {
		document.getElementById("BLK_CUST_ACCOUNT__ACCLSTYP").previousSibling.parentNode.style.display = "none"; //ACCLSTYP changes	
	}
	//9NT1606_12.0.3_INTERNAL_19179661 ends	
	//9NT1462 ITR 13076898 changes starts
	onceAuth = getNodeText(selectSingleNode(dbDataDOM,"//BLK_CUST_ACCOUNT/ONCEAUTH")) == 'Y';
	if(onceAuth) {
	if(functionId=='STDCUSAC'||functionId=='IADCUSAC'){//9NT1576_12.0.1_INTERNAL_15836360
		fnDisableSubSystemButton(document.getElementById('CVS_CHQBKREQ').firstChild);
		fnDisableSubSystemButton(document.getElementById('CVS_CARDREQ').firstChild);
		//9NT1606_12.0.3_UCBL_RETRO_18350748 starts
	    fnDisableElement(document.getElementsByName("ACSTATNODR")[0]);
      	fnDisableElement(document.getElementsByName("ACSTATNOCR")[0]);
      	fnDisableElement(document.getElementsByName("ACSTATSTPAY")[0]);
      	fnDisableElement(document.getElementsByName("DORM")[0]);
      	fnDisableElement(document.getElementsByName("FROZEN")[0]);
      	fnDisableElement(document.getElementsByName("POSTALLOWED")[0]);
	    fnDisableElement(document.getElementsByName("AUTOSTATCHANGE")[0]);				
		//9NT1606_12.0.3_UCBL_RETRO_18350748 ends
		}//9NT1576_12.0.1_INTERNAL_15836360
	//9NT1606_12_3_RETRO_12_1_25402429 Changes starts
	if(functionId=='STDCUSTD'||functionId=='IADCUSTD'){
      fnDisableElement(document.getElementsByName("ACCLS")[0]);
      fnDisableElement(document.getElementsByName("CCY")[0]);
      fnDisableElement(document.getElementsByName("CUSTNO")[0]);
      fnDisableElement(document.getElementsByName("BTN_ACCPKP")[0]);
      }
	//9NT1606_12_3_RETRO_12_1_25402429 Changes ends
	}
	 //9NT1606_12.0.3_PVATBJPY_RETRO_19412090 starts
	
	 else 
	{
      fnDisableElement(document.getElementsByName("ACCLS")[0]);
      fnDisableElement(document.getElementsByName("CCY")[0]);
      fnDisableElement(document.getElementsByName("CUSTNO")[0]);
      fnDisableElement(document.getElementsByName("BTN_ACCPKP")[0]);
	  fnDisableElement(document.getElementsByName("SPL_AC_GEN")[0]);//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range
        } 
		//9NT1606_12.0.3_PVATBJPY_RETRO_19412090 ENDS
	//9NT1462 ITR 13076898 changes ends
			g_prev_gAction = gAction;
			gAction = 'BUILD_SUBSTAT';
			fcjRequestDOM = buildUBSXml();
		    servletURL = "FCClientHandler";
		    fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
            //PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
            showProcessMsg = false;
			//gAction = '';
            //PNTFLX01011_FCUBS_12.1_MAT_21310050 ends
			if(!fnProcessResponse()){
				gAction=g_prev_gAction; //FC10.3 - SFR#924
				return false;
			}
		    //dlgArg.openerDoc.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value = dbDataDOM.selectSingleNode("//SUBSYSTEMSTAT").text;
			gAction=g_prev_gAction;

			fnEnableElement(document.getElementsByName("BTN_AMTDT")[0]);
			//fnEnableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]);  //FCUBS_12.1.0.0.0_DEV_Sanction_Check  //PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes
			fnEnableElement(document.getElementsByName("BTN_PROVISION")[0]);
			fnEnableElement(document.getElementsByName("BTN_CALLIBAN")[0]);
			fnDisableElement(document.getElementById("BLK_INTPRODMAP__ILPRD"));      //fcubs10.5str2, sfr428
				//SUHEL HERE       FC10.35SFR#1303
				//FCUBS_12.1.0.0.0_DEV_<IBAN_Enhancements> starts
		/*if(document.getElementsByName("IBANRQD")[0].value = 'N')
            {
				fnDisableElement(document.getElementsByName("BTN_CALLIBAN")[0]);
            }
	    else
			{
				fnEnableElement(document.getElementsByName("BTN_CALLIBAN")[0]);
			}*/
			//FCUBS_12.1.0.0.0_DEV_<IBAN_Enhancements> ends

		//SUHEL ENDS  FC10.35SFR#1303
		/*  -------commented the bellow code as ACC_OPENING_AMT was going to undefined and not processing further code
		// Kernel 11.0 - Casa - Minimum Account Opening Amount/Account Opening Charges  Start
		//disabling the initial funding block fields in case account opening amt is null
		if (document.getElementsByName("ACC_OPENING_AMT")[0].value == '')
		{
			for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
			{
				document.getElementsByName("PAY_IN_OPTION")[i].disabled = true;
			}
			fnDisableElement(document.getElementsByName("PAY_IN_OPTION")[0]);
			fnDisableElement(document.getElementsByName("INF_OFFSET_BRANCH")[0]);
			fnDisableElement(document.getElementsByName("INF_OFFSET_ACCOUNT")[0]);
		}
		// Kernel 11.0 - Casa - Minimum Account Opening Amount/Account Opening Charges End */

	 //9NT1466 IUT sfr#543  BIRDAB sfr#255 changes starts
	 //9NT1606_12.0.3_UCBL_RETRO_18350748 starts
	    /*fnDisableElement(document.getElementsByName("ACSTATNODR")[0]);
      	fnDisableElement(document.getElementsByName("ACSTATNOCR")[0]);
      	fnDisableElement(document.getElementsByName("ACSTATSTPAY")[0]);
      	fnDisableElement(document.getElementsByName("DORM")[0]);
      	fnDisableElement(document.getElementsByName("FROZEN")[0]);
      	fnDisableElement(document.getElementsByName("POSTALLOWED")[0]);
	    fnDisableElement(document.getElementsByName("AUTOSTATCHANGE")[0]);*/		
		//9NT1606_12.0.3_UCBL_RETRO_18350748 ends
     //9NT1466 IUT sfr#543  BIRDAB sfr#255 changes changes ends
	fnClearExtAuditFields(); //FC10.3 - SFR#757
	fn_button();  //9NT1462 Standard Documents Added by Tapas  //9NT1462 -ITR1 - BUG 13090079
	//document.getElementsByName("DIVFooter")[0].children[0].all[45].disabled  = true;  //Kernel 11.0 - Casa - Debit Card Functionality Changes
	//document.getElementsByName("DIVFooter")[0].children[0].all[52].disabled  = true;  //Kernel 11.0 - Casa - Debit Card Functionality Changes (Disabling 'Cards' Button) FCUBS 11.1 ITR1 sfr 4841
	 fnDisableElement(document.getElementById("DIVSubSystem").getElementsByTagName("A")[21]);	   //9NT1462 -ITR1 - BUG 13090079
	 document.getElementById("BLK_CUST_ACCOUNT__CUSTNAME").value= custname1;  // FCUBS 11.1 ITR1 SFR# 4954 changes
	//9NT1587 FC_DEV_12.0.2 VINU CHANGES starts
	if(functionId == 'STDCUSTD' || functionId ==  'IADCUSTD')
	{
	g_nullify_tenor = false; //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421
	fn_ChangeRollover();
	g_nullify_tenor = true; //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421
	}
	//9NT1587 FC_DEV_12.0.2 VINU CHANGES ends
	return true;
}
//9NT1606_12.0.2_IGIBCUST_RETRO_17812052 starts
function fnPostClose_CVS_AUTHORIZE(screenArgs) {
 
    //9NT1606_12_0_3_RETRO_19142520 Starts
    //gAction = 'EXECUTEQUERY';
    //fnExecuteQuery();
	dbDataDOM = loadXMLDoc(getXMLString(screenArgs["RETURN_VALUE"].dbDataDOM));
    disableForm();
    viewModeAction = false;
    gAction = "";
    fnSetExitButton();
    showData();
    showToolbar(functionId, '', '');
    fnPostExecuteQuery_KERNEL();
    //9NT1606_12_0_3_RETRO_19142520 Ends
    return true;
}
//9NT1606_12.0.2_IGIBCUST_RETRO_17812052 ends

function fnPostAuthorize_KERNEL()
{
    fnEnableElement(document.getElementsByName("BTN_AMTDT")[0]);   // FC 10.5 # 4042
	//fnEnableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]);  //FCUBS_12.1.0.0.0_DEV_Sanction_Check  //PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes 
    gAction = 'EXECUTEQUERY';
	fnExecuteQuery();

	return true;
}

function fnPostCopy_KERNEL()
{
    var tempaccno =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACC"));
//11.4 ITR1 SFR#13052412 VINOD CHANGES ends
	if(typeof(multiBrnAccessReq)!= "undefined" && multiBrnAccessReq=="Y" && multiBrnScrOpened == false && mainWin.gActiveWindow.screenType != "WB"){
	} else {
		document.getElementsByName('BRN')[0].value = mainWin.CurrentBranch;
		fnDisableElement(document.getElementsByName('BRN')[0]);
	}		   
//11.4 ITR1 SFR#13052412 VINOD CHANGES ends
	//document.getElementsByName('BRN')[0].value=mainWin.CurrentBranch;
    g_prev_gAction = gAction;
    gAction = 'COPY';
    fcjRequestDOM = buildUBSXml();
    servletURL = "FCClientHandler";
    fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
    //PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
    showProcessMsg = false;
    //gAction = '';
    //PNTFLX01011_FCUBS_12.1_MAT_21310050 ends
    if(!fnProcessResponse()){
	  gAction=g_prev_gAction; //FC10.3 - SFR#924
      return false;
    }
    gAction=g_prev_gAction;

    if (document.getElementById("BLK_CUST_ACCOUNT__ACC").value != tempaccno){
      enableForm();
      fnDisableElement(document.getElementsByName("BRN")[0]);
      fnDisableElement(document.getElementsByName("ACC")[0]);
      fnDisableElement(document.getElementsByName("ACCLS")[0]);
      fnDisableElement(document.getElementsByName("CCY")[0]);
      fnDisableElement(document.getElementsByName("CUSTNO")[0]);
      fnDisableElement(document.getElementsByName("BTN_ACCPKP")[0]);
	  fnDisableElement(document.getElementsByName("SPL_AC_GEN")[0]);//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range
//9NT1428 FCUBS 11.2 Changes By Aslam Startz
if(functionId=='STDCUSTD') //9NT1525_12.0.2_CITI121_SFR#16731046
  { //9NT1525_12.0.2_CITI121_SFR#16731046
	fnDisableElement(document.getElementsByName("PAYINBYCHQ")[0]);
	//fnDisableElement(document.getElementsByName("PAYINCHQNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYIN_CHQ_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYINCLGBNK")[0]);
	fnDisableElement(document.getElementsByName("PAYINCLGBRN")[0]);
	fnDisableElement(document.getElementsByName("PAYINCLGPRD")[0]);
	//fnDisableElement(document.getElementsByName("PAYINCHQDATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYIN_CHQ_DATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYINDRWACNO")[0]);
	//fnDisableElement(document.getElementsByName("PAYINROUTINGNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYIN_ROUTING_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	document.getElementById("BLK_CUST_ACCOUNT__PAYINBYCHQ").value = 'O';
	//document.getElementById("BLK_CUST_ACCOUNT__PAYINCHQNO").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
	document.getElementById("BLK_CUST_ACCOUNT__PAYIN_CHQ_NO").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
	document.getElementById("BLK_CUST_ACCOUNT__PAYINCLGBNK").value = '';
	document.getElementById("BLK_CUST_ACCOUNT__PAYINCLGBRN").value = '';
	document.getElementById("BLK_CUST_ACCOUNT__PAYINCLGPRD").value = '';
	//document.getElementById("BLK_CUST_ACCOUNT__PAYINCHQDATE").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
	document.getElementById("BLK_CUST_ACCOUNT__PAYIN_CHQ_DATE").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
	document.getElementById("BLK_CUST_ACCOUNT__PAYINDRWACNO").value = '';
	//document.getElementById("BLK_CUST_ACCOUNT__PAYINROUTINGNO").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
	document.getElementById("BLK_CUST_ACCOUNT__PAYIN_ROUTING_NO").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
   } //9NT1525_12.0.2_CITI121_SFR#16731046
//9NT1428 FCUBS 11.2 Changes By Aslam Endz 
//9NT1606_12.0.3_UNION_BANK_19437179 changes starts
//9NT1606_12.0.3_UNION_BANK_19437179_1 changes starts
//if (typeof(document.getElementById("BLK_ACC_NOMINEES"))!= "undefined" && document.getElementById("BLK_ACC_NOMINEES")!=null){ //9NT1606_12.0.3_INTERNAL_19486679
if(document.getElementById("TBLPageTAB_NOM") && //9NT1606_12.0.3_UNION_BANK_19505074 CHANGES
trim(document.getElementById("TBLPageTAB_NOM").innerHTML) != "") {
//9NT1606_12.0.3_UNION_BANK_19437179_1 changes ends
if((document.getElementsByName("NAM")[0].value != "") || (document.getElementsByName("NADDR1")[0].value != "") || (document.getElementById("BLK_ACC_NOMINEES__DOB").value != "") ||(document.getElementsByName("RELSHIP")[0].value != "")||(document.getElementsByName("NADDR1")[0].value != "")||(document.getElementsByName("NADDR2")[0].value != "")||(document.getElementsByName("NADDR3")[0].value != "")||(document.getElementsByName("NADDR4")[0].value != "")||(document.getElementsByName("GUARDNAM")[0].value != "")||(document.getElementsByName("GUARDRELNSHP")[0].value != "")||(document.getElementsByName("GADDR1")[0].value != "")||(document.getElementsByName("GADDR2")[0].value != "")||(document.getElementsByName("GADDR3")[0].value != "")||(document.getElementsByName("GADDR4")[0].value != "")
||(document.getElementsByName("NPINCODE")[0].value != "") || (document.getElementsByName("GUARD_PINCODE")[0].value != "")) //9NT1606_12_2_RETRO_12_0_3_23657954 added
{
}
else
{
fnDisableElement(document.getElementsByName("NAM")[0]);
fnDisableElement(document.getElementsByName("NADDR1")[0]);
fnDisableElement(document.getElementById("BLK_ACC_NOMINEES__DOB"));
fnDisableElement(document.getElementsByName("RELSHIP")[0]);
fnDisableElement(document.getElementsByName("NADDR1")[0]);
fnDisableElement(document.getElementsByName("NADDR2")[0]);
fnDisableElement(document.getElementsByName("NADDR3")[0]);
fnDisableElement(document.getElementsByName("NADDR4")[0]);
fnDisableElement(document.getElementsByName("NOMMINOR")[0]);
fnDisableElement(document.getElementsByName("GUARDNAM")[0]);
fnDisableElement(document.getElementsByName("GUARDRELNSHP")[0]);
fnDisableElement(document.getElementsByName("GADDR1")[0]);
fnDisableElement(document.getElementsByName("GADDR2")[0]);
fnDisableElement(document.getElementsByName("GADDR3")[0]);
fnDisableElement(document.getElementsByName("GADDR4")[0]);
//9NT1606_12_2_RETRO_12_0_3_23657954   Changes starts
fnDisableElement(document.getElementsByName("NPINCODE")[0]);
fnDisableElement(document.getElementsByName("GUARD_PINCODE")[0]);
//9NT1606_12_2_RETRO_12_0_3_23657954  changes ends
document.getElementById("BLK_ACC_NOMINEES__DOB").nextSibling.nextSibling.nextSibling.disabled = true; 
}
}  //9NT1606_12.0.3_INTERNAL_19486679
//9NT1606_12.0.3_UNION_BANK_19437179 changes ends
    }
    else{
      disableForm();
	  //PNTFLX01011_12.1_ITR2_21808335 Starts
		fnEnableElement(document.getElementsByName("PAYINBYCHQ")[0]);
		fnEnableElement(document.getElementsByName("PAYIN_CHQ_NO")[0]);
		fnEnableElement(document.getElementsByName("PAYINCLGBNK")[0]);
		fnEnableElement(document.getElementsByName("PAYINCLGBRN")[0]);
		fnEnableElement(document.getElementsByName("PAYINCLGPRD")[0]);
		fnEnableElement(document.getElementsByName("PAYIN_CHQ_DATE")[0]);
		fnEnableElement(document.getElementsByName("PAYINDRWACNO")[0]);
		fnEnableElement(document.getElementsByName("PAYIN_ROUTING_NO")[0]);
	  //PNTFLX01011_12.1_ITR2_21808335 Ends
	  document.getElementById("BLK_CUST_ACCOUNT__ACC").value = '';
	  //FC11.0 ITR1 SFR#627 STARTS
	  document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value = '';
	  document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value = '';//9NT1606_12.0.3_ASKARI-RETRO-18731408
	  //FC11.0 ITR1 SFR#627 ENDS
	  //--9NT1606_12.0.3_IPKRASK-RETRO-18731464 Changes Starts
	  setNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ALTACC"),'');
	  setNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/CLRACNO"),'');//9NT1606_12_3_RETRO_12_0_3_25502117
	  //--9NT1606_12.0.3_IPKRASK-RETRO-18731464 Changes Ends
      fnEnableElement(document.getElementsByName("BTN_EXIT")[0]);
      fnEnableElement(document.getElementsByName("ACCLS")[0]);
      fnEnableElement(document.getElementsByName("CCY")[0]);
      fnEnableElement(document.getElementsByName("CUSTNO")[0]);
      fnEnableElement(document.getElementsByName("BTN_ACCPKP")[0]);
	  fnEnableElement(document.getElementsByName("SPL_AC_GEN")[0]);//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range -added
    }

	fnClearExtAuditFields(); //FC10.3 - SFR#757
	//document.getElementsByName("DIVFooter")[0].children[0].all[45].disabled  = true; //Kernel 11.0 - Casa - Debit Card Functionality Changes //9NT1606_12.0.3_BANQUE_MISR_RETRO_19028052
	//9NT1587 FC_DEV_12.0.2 VINU CHANGES starts
	if(functionId == 'STDCUSTD' || functionId ==  'IADCUSTD')
	{
	g_nullify_tenor = false; //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700
	fn_ChangeRollover();
	g_nullify_tenor = true; //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700
	}
	//9NT1587 FC_DEV_12.0.2 VINU CHANGES ends
	//9NT1606_12.0.3_INTERNAL_19179661 starts
	if(functionId=='STDCUSAC') {
		document.getElementById("BLK_CUST_ACCOUNT__ACCLSTYP").previousSibling.parentNode.style.display = "none"; //ACCLSTYP changes	
	}
	//9NT1606_12.0.3_INTERNAL_19179661 ends
    //9NT1606_12.0.3_RETRO_20067218 starts
	if(functionId=='STDCUSAC'||functionId=='IADCUSAC')
	{
    fnEnableSubSystemButton(document.getElementById('CVS_CHQBKREQ').firstChild);
    fnEnableSubSystemButton(document.getElementById('CVS_CARDREQ').firstChild);
	}
	//9NT1606_12.0.3_RETRO_20067218 ends
	//PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes starts
	/*
	//FCUBS_12.1.0.0.0_DEV_Sanction_Check Changes starts
     document.getElementById('BLK_CUST_ACCOUNT__SNCK_STAT').value = 'N';
	 fnDisableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]);   
	 //FCUBS_12.1.0.0.0_DEV_Sanction_Check Changes ends
	 */
	 //PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes ends
   
    return true;
   document.getElementById("BLK_INTDETAILS__BOOKACC").value    = screenArgs['ACC'];
}
//9NT1525_12.0RETRO_TZSAMAN_14596405 chnages ADDED EVENT
//function fnPreClose_KERNEL()
function fnPreClose_KERNEL(event)
{
    customAlertAction = 'LAUNCH_STCACLOS'; //FCUBS11.1 ITR1 SFR#2500
    //FCUBS11.1 ITR1 SFR#2500 STARTS
   relationArray['BLK_ACCCLOSE'] = "";
   relationArray['BLK_CUST_ACCOUNT_CLOSURE'] = "BLK_ACCCLOSE~1";
   //FCUBS11.1 ITR1 SFR#2500  ENDS
   //fnClearExtAuditFields();   //14-7-10 FCUBS11.1 ITR2 SFR#144;  //14403690_Commented; Retroed from 14334845
   /*
   mainWin.CloseID = '';
	fnSubScreenMain('STCACLOS', 'STCACLOS', 'CVS_CLOSE');

	if (mainWin.CloseID == 'CLS'){
		mainWin.CloseID = '';
		gAction = '';
		return false;
	}*/

	return true;
}

//FCUBS11.1 ITR1 SFR#2500 Start
//9NT1606_12.0.2_GBPFBN_RETRO_17719893 Starts
function fnCloseAlertWin_ReExecute()
{
    if (typeof(relationArray['BLK_ACCCLOSE']) != "undefined")
        relationArray['BLK_ACCCLOSE'] = "BLK_CUST_ACCOUNT~1" ;
    gAction = 'EXECUTEQUERY';
    fnExecuteQuery();
}
//9NT1606_12.0.2_GBPFBN_RETRO_17719893 Ends
//9NT1525_12.0RETRO_TZSAMAN_14596405 Changes ADDED EVENT
//function fnCloseAlertWin_LAUNCH_STCACLOS(){
function fnCloseAlertWin_LAUNCH_STCACLOS(event){

   //9NT1587_12.0.2_ITR1_SFR#17023887 starts
	 fnClearExtAuditFields();
	 appendData();
   //9NT1587_12.0.2_ITR1_SFR#17023887 ends
	 mainWin.CloseID = '';
        //Infra Changes - function origin array - starts
        ArrFuncOrigin["STDCUSAC"]="KERNEL";
        ArrPrntFunc["STDCUSAC"]="";
        ArrPrntOrigin["STDCUSAC"]="";
        ArrRoutingType["STDCUSAC"]="X";
	//Infra Changes - function origin array - ends

        fnSubScreenMain('STCACLOS', 'STCACLOS', 'CVS_CLOSE');

	if (mainWin.CloseID == 'CLS'){
		mainWin.CloseID = '';
        //PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
        showProcessMsg = false;
		//gAction = '';
        //PNTFLX01011_FCUBS_12.1_MAT_21310050 ends
		return false;
	}

	//9NT1525_12.0RETRO_TZSAMAN_14596405 Changes  starts
    //gdbDOM = dbDataDOM.cloneNode(true); //FCUBS11.1,SFR#2500,ITR-1
	gdbDOM = dbDataDOM;  //9NT1525_12.0RETRO_TZSAMAN_14596405 Changes ends
    return true;
}

//FCUBS11.1 ITR1 SFR#2500 End

//FCUBS_12.0.0 DMS changes starts
function fnPreLoad_CVS_UPDOC_KERNEL(screenArgs) {
	
	screenArgs['FLAG_STATUS'] = 'true';
	screenArgs['FUNCT_ID'] = functionId;
	return true;
}
// FCUBS_12.0.0 DMS changes ends
//FCUBS11.1 ITR1 SFR#2500 STARTS

//9NT1525_12.0RETRO_TZSAMAN_14596405 Changes ADDED EVENT
 function fnPostClose_CVS_CLOSE_KERNEL(event)
 //function fnPostClose_CVS_CLOSE_KERNEL()
{
     // ADDED FOR FCUBS11.1,SFR#2500,ITR-1 STARTS
       var tempDom = gdbDOM;
       //var temDbDataDOM = tempDom.cloneNode(true);//9NT1525_12.0RETRO_TZSAMAN_14596405 Changes
	   var temDbDataDOM = tempDom;//9NT1525_12.0RETRO_TZSAMAN_14596405 Changes
       //selectNodes(temDbDataDOM ,"//BLK_ACCCLOSE").removeAll();//9NT1525_12.0RETRO_TZSAMAN_14596405 Changes
       temDbDataDOM.documentElement.appendChild(dbDataDOM.documentElement);

       //dbDataDOM=temDbDataDOM.cloneNode(true);//9NT1525_12.0RETRO_TZSAMAN_14596405 Changes
	   dbDataDOM=temDbDataDOM; //9NT1525_12.0RETRO_TZSAMAN_14596405 Changes
     //ADDED FOR FCUBS11.1,SFR#2500,ITR-1 ENDS
    fcjRequestDOM = buildUBSXml();
//  servletURL = "FCClientHandler";
  fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
  //gAction = ''; //COMMENTED FOR FCUBS11.1,SFR#2500,ITR-1
  if(!fnProcessResponse()){
    return false;
  }
    //9NT1462 ITR1  SFR#13092488  Changes Starts
  if(fcjResponseDOM){
    var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
    if (msgStatus == 'WARNING') {
		var l_xPath = "FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP";
		var messageNode = getXMLString(selectSingleNode(fcjResponseDOM, l_xPath));
		displayResponse(messageNode, msgStatus, 'O', l_xPath);
		return true ; 
		}
    // 23098131 Starts
    if (msgStatus == 'SUCCESS') {
		var l_xPath = "FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP";
		var messageNode = getXMLString(selectSingleNode(fcjResponseDOM, l_xPath));
		displayResponse(messageNode, msgStatus, 'I', l_xPath);
		}
    // 23098131 Ends
	}

    //9NT1606_12.0.2_GBPFBN_RETRO_17719893 Starts 
	if (msgStatus == 'FAILURE' || msgStatus == 'SUCCESS')
        { 
            customAlertAction = "ReExecute";
        }
	//9NT1606_12.0.2_GBPFBN_RETRO_17719893 Ends
  //9NT1462 ITR1  SFR#13092488  Changes Ends
  //gAction = ''; //ADDED FOR FCUBS11.1 SFR#2500//PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
    return true;
}
//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes starts
function fnPreEnterQuery_KERNEL()
{
	if(functionId=='STDTDSIM')
	{
	showErrorAlerts('ST-VALS-035');  
	return false;
	}
	return true;
}
//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes ens

//FCUBS11.1 ITR1 SFR#2500 EndS

function fnPostEnterQuery_KERNEL()
{
	if(functionId=='STDTDSIM')
	{
	//showErrorAlerts('ST-VALS-035');  
	return false;
	}
	//document.getElementsByName('BRN')[0].value=mainWin.CurrentBranch;
	//fnDisableElement(document.getElementsByName('BRN')[0]);
	if(typeof(multiBrnAccessReq)!= "undefined" && multiBrnAccessReq=="Y" && multiBrnScrOpened == false && mainWin.gActiveWindow.screenType != "WB"){
	} else {
		document.getElementsByName('BRN')[0].value = mainWin.CurrentBranch;
		fnDisableElement(document.getElementsByName('BRN')[0]);
	}
	fnDisableElement(document.getElementsByName('BTN_ACCPKP')[0]);
	document.getElementsByName('ACC')[0].focus();//9NT1501 ITR2 14016935	
    return true;
}

function fnPostExecuteQuery_KERNEL()
{
    fnEnableElement(document.getElementsByName('BTN_AMTDT')[0]);
	//PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes starts
	/*
	//FCUBS_12.1.0.0.0_DEV_Sanction_Check changes starts
	fnEnableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]); 
	//FCUBS_12.1.0.0.0_DEV_Sanction_Check changes ends
	*/
	//PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes ends
	fnEnableElement(document.getElementsByName('BTN_PROVISION')[0]);
	fnEnableElement(document.getElementsByName('BTN_CALLIBAN')[0]);
	fnDisableElement(document.getElementById("BLK_INTPRODMAP__ILPRD"));  //fcubs10.5str2, sfr428
	custname1 =document.getElementById("BLK_CUST_ACCOUNT__CUSTNAME").value; // FCUBS 11.1 ITR1 SFR# 4954 changes
	//setNodeText(selectSingleNode(dbDataDOM,"//BLK_NOTICEPREF/CCY"),document.getElementById("BLK_CUST_ACCOUNT__CCY").value);//9NT1606_1202_NEDBANKLIMITED_RETRO_18872214 Added //9NT1606_12_2_RETRO_12_0_2_23656232 Commented
	//9NT1606_12_2_RETRO_12_0_3_24707021  Starts
	if (functionId == "STDCUSAC") {
    setNodeText(selectSingleNode(dbDataDOM,"//BLK_NOTICEPREF/CCY"),document.getElementById("BLK_CUST_ACCOUNT__CCY").value);
	}
	//9NT1606_12_2_RETRO_12_0_3_24707021  Ends
	/*if(document.getElementsByName("IBANACNO")[0].value !='')
		document.getElementsByName("IBANRQD")[0].checked=true;*/
		//FCUBS_12.1.0.0.0_DEV_<IBAN_Enhancements> ends

	return true;
}

//9NT1462 -ITR1 -BUG 13400175 Starts
function fnInTab_TAB_CHECKLIST_KERNEL(){
	 if (document.getElementById("BLK_CUST_ACCOUNT__DMS_INSTALLED").value == 'Y' )
		fnEnableElement(document.getElementById("BLK_DOCTYPE_REMARKS__BTN_VIEW")); 
    //9NT1525_12.0.2_GIBCUST_RETRO_17789049 starts - commented below
    /*//9NT1525_12.0_IDRBMI_CNSL_SFR#14471704   changes starts
	document.getElementById("cmdAddRow_BLK_DOCTYPE_CHECKLIST").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_DOCTYPE_CHECKLIST").style.visibility="HIDDEN";
	//9NT1525_12.0_IDRBMI_CNSL_SFR#14471704  changes ends*/
    //9NT1525_12.0.2_GIBCUST_RETRO_17789049 ends
	//9NT1587_12.0.2_INTERNAL_ITR1_17175911 Starts
    for (var i = 0; i < document.getElementsByName("DOCUMENT_TYPE").length; i++)
      {
        document.getElementsByName("DOCUMENT_TYPE")[i].disabled = true;
      }
	//9NT1587_12.0.2_INTERNAL_ITR1_17175911 Ends
	return true;
}
//9NT1462 -ITR1 -BUG 13400175 Ends
function fnPreSave_KERNEL()
{
    var isValid = true;


    if (!isValid)
    {
        var msg = buildMessage(gErrCodes);
        alertMessage(msg);
        return false;
    }

    return isValid;
  fn_check_freq();     //9NT1462 Standard Documents ADDED BY TAPAS
  
}

function fnPreSave_Child_KERNEL()
{
    var isValid = true;


    if (!isValid)
    {
        var msg = buildMessage(gErrCodes);
        alertMessage(msg);
        return false;
    }
    return isValid;
}

function fnPostSave_KERNEL()
{
    fnEnableElement(document.getElementsByName("BTN_AMTDT")[0]);
	//fnEnableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]);  //FCUBS_12.1.0.0.0_DEV_Sanction_Check  //PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes
	fnEnableElement(document.getElementsByName("BTN_PROVISION")[0]);
	fnEnableElement(document.getElementsByName("BTN_CALLIBAN")[0]);

	return true;
}

function getNewSubsysstat(initStr, subsys)
{
    var stat;
    var start;
    var finalstr;
    start = initStr.indexOf(subsys + ':');
	if (start == -1)
    {
        return initStr;
    }
    stat = initStr.substr(start + subsys.length + 1, 1);
    var str1 = subsys+':'+stat;
    var str2 = subsys+':'+'U';
    finalstr = initStr.replace(str1, str2);

	return finalstr;
}

function fnAccPickup()
{
var splAccgen;//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range -added
      if(!fnPreAccPickup()){
                    return;
      }
      appendData(document.getElementById('TBLPageTAB_HEADER'));
      appendData(document.getElementById('TBLPageTAB_AUXILIARY'));
      appendData(document.getElementById('TBLPageTAB_MAIN'));
      g_prev_gAction = gAction;
      gAction='DEFAULT';
      fcjRequestDOM = buildUBSXml();
      servletURL = "FCClientHandler";
      fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	  //gAction = ''; //PNTFLX01011_DEV_FCUBS_12.1_IQA_21272136 commented
	  //9NT1466 Changes for iut sfr#618 
	  //if(!fnProcessResponse()){						//9NT1466 Changes for iut sfr#618
	   var msgStatus=fnProcessResponse();	//9NT1466 Changes for iut sfr#618
	   if(msgStatus!="SUCCESS"){	   		//9NT1466 Changes for iut sfr#618
		gAction=g_prev_gAction; //FC10.3 - SFR#924
		return false;
	  }

	  var autogenflag=document.getElementsByName("ACCAUTOGEN")[0].value ;
	 //  var mcygenflag=document.getElementsByName("MULTI_CURRENCY")[0].value ;
	  //FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range starts
      if (functionId == 'STDCUSAC'||functionId == 'IADCUSAC')
      {
         if (document.getElementsByName("SPL_AC_GEN")[0].checked == true)
            splAccgen = 'Y';
         else
            splAccgen = 'N';
      }
      else
         splAccgen = 'N';
      //FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range ends
          //if(autogenflag=='N') //FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range  - commented
// Fcubs_12.4_multi_currency_accounts		 
 if (functionId == 'STDCUSAC' || functionId=='STDCASAC')
		  {
			   var mcygenflag=document.getElementsByName("MULTI_CURRENCY")[0].value ;
		  if((autogenflag=='N' || splAccgen == 'Y')&& mcygenflag!='Y')//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range added
		//Account Generation Screen
		fnShowAccNoScreen();
		if((autogenflag=='N' || splAccgen == 'Y')&& mcygenflag=='Y')//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range added
		//Account Generation Screen
		fnShowMcyAccNoScreen();
		  }
		  else
		  {
			if(autogenflag=='N' || splAccgen == 'Y')//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range added
		//Account Generation Screen
			fnShowAccNoScreen();  
		  }
// Fcubs_12.4_multi_currency_accounts
	if(msgStatus=="SUCCESS") {//9NT1466 Changes for iut sfr#618
	    fnBuildTabHTML(); //9NT1606_12_2_RETRO_12_0_3_23652433 added
		fnPostAccPickup();		
		//9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17332691 changes starts
if (functionId == 'STDCUSTD'||functionId == 'STDTDSIM')  //9NT1606_12.0.3_RETRO_18838183  changes 
{
if (strCurrentTabId  == 'TAB_MAIN' && document.getElementById('BLK_TDDETAILS__TDAMTI')) //9NT1606_12.0.3_UNION_BANK_19437179 changes
document.getElementById('BLK_TDDETAILS__TDAMTI').focus();
}
else
{
        //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17332691 changes ends
if (strCurrentTabId  == 'TAB_MAIN' &&document.getElementById('BLK_CUST_ACCOUNT__ADESC')) //9NT1606_12.0.3_UNION_BANK_19437179 changes
		document.getElementById('BLK_CUST_ACCOUNT__ADESC').focus(); //9NT1501 ITR1 13959083
}     //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17332691 changes
//PNTFLX01011_12.1_ITR2_21690178 commented the below code
/*//PNTFLX01011_12.1_ITR2_21669908 starts
if (functionId == 'IADCUSTD' && strCurrentTabId  == 'TAB_MAIN')
{
showTabData('TAB_DEPOSIT');
}
//PNTFLX01011_12.1_ITR2_21669908 ends*/
	}
	else {
	document.getElementById('BLK_CUST_ACCOUNT__BTN_ACCPKP').focus(); //9NT1501 ITR1 13959083
	}	
      gAction=g_prev_gAction;
	 //9NT1587 FC_DEV_12.0.2 VINU CHANGES starts
    if (functionId == 'STDCUSTD'||functionId == 'STDTDSIM')  //9NT1587_ITR_17007079
	{
	g_nullify_tenor = false; //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700
	fn_ChangeRollover();	
	g_nullify_tenor = true; //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700
	}
   //9NT1587 FC_DEV_12.0.2 VINU CHANGES ends
   
   //Referral Sampath Starts
   document.getElementById("BLK_CUST_ACC_CUSTOM__SALE_CHANNEL").nextSibling.nextSibling.style.visibility="hidden";
   document.getElementById("BLK_CUST_ACC_CUSTOM__RELATIONSHIP_OFFICER").nextSibling.nextSibling.style.visibility="hidden";
   document.getElementById("BLK_CUST_ACC_CUSTOM__REFERRAL_PERSON").nextSibling.nextSibling.style.visibility="hidden";
   //Referral Sampath Ends

	  return true;
}

function fnPreAccPickup()
{

//9NT1428 FCUBS 11.2 Changes By Aslam Startz
if(functionId=='STDCUSTD')
{
 if(document.getElementsByName("PAYINBYCHQ")[0].value=='O')
	{
		//document.getElementById("BLK_CUST_ACCOUNT__PAYINCHQNO").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
		document.getElementById("BLK_CUST_ACCOUNT__PAYIN_CHQ_NO").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
		document.getElementById("BLK_CUST_ACCOUNT__PAYINCLGBNK").value = '';
		document.getElementById("BLK_CUST_ACCOUNT__PAYINCLGBRN").value = '';
		document.getElementById("BLK_CUST_ACCOUNT__PAYINCLGPRD").value = '';
		//document.getElementById("BLK_CUST_ACCOUNT__PAYINCHQDATE").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
		document.getElementById("BLK_CUST_ACCOUNT__PAYIN_CHQ_DATE").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
		document.getElementById("BLK_CUST_ACCOUNT__PAYINDRWACNO").value = '';
		//document.getElementById("BLK_CUST_ACCOUNT__PAYINROUTINGNO").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
		document.getElementById("BLK_CUST_ACCOUNT__PAYIN_ROUTING_NO").value = ''; //PNTFLX01011_12.1_ITR2_21821189 changes
	}
}
//9NT1428 FCUBS 11.2 Changes By Aslam Endz
    custname =document.getElementsByName("CUSTNAME")[0].value;  //FC11.01 - ITR1 SFR-1543 suhel
	//document.getElementsByName("BTN_EXIT_IMG")[0].src = "Images/Cancel.gif";//FCUBS11.1 ITR2 SFR#74
	document.getElementById("BTN_EXIT_IMG").src = "Images/Cancel.gif";//FCUBS11.1 ITR2 SFR#74
	document.getElementsByName("ACCLS")[0].value= document.getElementsByName("ACCLS")[0].value.toUpperCase();

	return true;

}
//12.2_SUPPORT_RETRO_23664359 Changes Starts
function fnPreExit_CVS_ACNO_KERNEL(){
	var winObj = mainWin.document.getElementById(parent.seqNo);
	mainWin.fnExit(winObj);
	return false;
}
//12.2_SUPPORT_RETRO_23664359 Changes Ends
function fnPostAccPickup()
{
	enableForm();
	//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes starts
 	if(functionId=='STDTDSIM')
	 {
		fn_simulation_visibility("none");
		//9NT1587_12.0.2_SFR_NO:17020901
		document.getElementById("BLK_TDDETAILS__BTN_CLEAR").style.display = "block";
		document.getElementById("BLK_TDDETAILS__BTN_VIEW_PRINT").style.display = "block";
		document.getElementById("BLK_TDDETAILS__BTN_CREATE_DEP").style.display = "block";
		//9NT1587_12.0.2_SFR_NO:17020901
		document.getElementById("BLK_TDDETAILS__BTN_CLEAR").disabled=false;
		document.getElementById("BLK_TDDETAILS__BTN_VIEW_PRINT").disabled=true;
		document.getElementById("BLK_TDDETAILS__BTN_CREATE_DEP").disabled=true;
	 }
	 //9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes ends

    document.getElementsByName("CUSTNAME")[0].value=custname;  //FC11.01 - ITR1 SFR-1543 suhel
	fnDisableElement(document.getElementsByName("ACCLS")[0]);
	fnDisableElement(document.getElementsByName("CUSTNO")[0]);
	fnDisableElement(document.getElementsByName("CCY")[0]);
	fnDisableElement(document.getElementsByName("BTN_ACCPKP")[0]);
	fnDisableElement(document.getElementsByName("SPL_AC_GEN")[0]);//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range -added
	fnDisableElement(document.getElementsByName("BTN_AMTDT")[0]);
	//fnDisableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]); //FCUBS_12.1.0.0.0_DEV_Sanction_Check  //PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes
	fnDisableElement(document.getElementsByName("BTN_CALLIBAN")[0]);
//9NT1428 FCUBS 11.2 Changes By Aslam Startz
	fnDisableElement(document.getElementsByName("PAYINBYCHQ")[0]); 
	//fnDisableElement(document.getElementsByName("PAYINCHQNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changesc
	fnDisableElement(document.getElementsByName("PAYIN_CHQ_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYINCLGBNK")[0]);
	fnDisableElement(document.getElementsByName("PAYINCLGBRN")[0]);
	//fnDisableElement(document.getElementsByName("PAYINCHQDATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYIN_CHQ_DATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYINCLGPRD")[0]);
	fnDisableElement(document.getElementsByName("PAYINDRWACNO")[0]);
	//fnDisableElement(document.getElementsByName("PAYINROUTINGNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYIN_ROUTING_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	//9NT1462 ITR2 SFR# 13475260 starts
//9NT1606_12.0.3_UNION_BANK_19437179_1 changes starts	
	//if (typeof(document.getElementById("BLK_ACC_NOMINEES"))!= "undefined" && document.getElementById("BLK_ACC_NOMINEES")!=null)  {	//9NT1606_12.0.3_INTERNAL_19486679 changes starts
if(document.getElementById("TBLPageTAB_NOM") &&  //9NT1606_12.0.3_UNION_BANK_19505074 CHANGES
trim(document.getElementById("TBLPageTAB_NOM").innerHTML) != "") {
//9NT1606_12.0.3_UNION_BANK_19437179_1 changes ends	

if((document.getElementsByName("NAM")[0].value != "") || (document.getElementsByName("NADDR1")[0].value != "") || (document.getElementById("BLK_ACC_NOMINEES__DOB").value != "") ||(document.getElementsByName("RELSHIP")[0].value != "")||(document.getElementsByName("NADDR1")[0].value != "")||(document.getElementsByName("NADDR2")[0].value != "")||(document.getElementsByName("NADDR3")[0].value != "")||(document.getElementsByName("NADDR4")[0].value != "")||(document.getElementsByName("GUARDNAM")[0].value != "")||(document.getElementsByName("GUARDRELNSHP")[0].value != "")||(document.getElementsByName("GADDR1")[0].value != "")||(document.getElementsByName("GADDR2")[0].value != "")||(document.getElementsByName("GADDR3")[0].value != "")||(document.getElementsByName("GADDR4")[0].value != ""))
{
}
else
{ 
//9NT1606_12.0.3_UNION_BANK_19437179 changes ends
fnDisableElement(document.getElementsByName("NAM")[0]);
fnDisableElement(document.getElementsByName("NADDR1")[0]);
fnDisableElement(document.getElementById("BLK_ACC_NOMINEES__DOB"));
fnDisableElement(document.getElementsByName("RELSHIP")[0]);
fnDisableElement(document.getElementsByName("NADDR1")[0]);
fnDisableElement(document.getElementsByName("NADDR2")[0]);
fnDisableElement(document.getElementsByName("NADDR3")[0]);
fnDisableElement(document.getElementsByName("NADDR4")[0]);
fnDisableElement(document.getElementsByName("NOMMINOR")[0]);
fnDisableElement(document.getElementsByName("GUARDNAM")[0]);
fnDisableElement(document.getElementsByName("GUARDRELNSHP")[0]);
fnDisableElement(document.getElementsByName("GADDR1")[0]);
fnDisableElement(document.getElementsByName("GADDR2")[0]);
fnDisableElement(document.getElementsByName("GADDR3")[0]);
fnDisableElement(document.getElementsByName("GADDR4")[0]);
//9NT1606_12_2_RETRO_12_0_3_23657954   Changes starts
if(functionId == "STDCUSAC") {  
fnDisableElement(document.getElementsByName("NPINCODE")[0]);
fnDisableElement(document.getElementsByName("GUARD_PINCODE")[0]);
} 
//9NT1606_12_2_RETRO_12_0_3_23657954  changes ends
document.getElementById("BLK_ACC_NOMINEES__DOB").nextSibling.nextSibling.nextSibling.disabled = true; 
}		  //9NT1606_12.0.3_UNION_BANK_19437179 changes
	} //9NT1606_12.0.3_INTERNAL_19486679
	//9NT1462 ITR2 SFR# 13475260 ends
	
if(functionId=='STDCUSTD')
{
//FCUBS11.3 ITR1 SFR# 11891621 starts
	//FCUBS 11.2 SFR # 838,ITR-1 changes starts.
	//document.getElementById("cmdAddRow_BLK_TDPAYINDETAILS").style.visibility = "visible";
	//document.getElementById("cmdDelRow_BLK_TDPAYINDETAILS").style.visibility = "visible";
	//document.getElementById("cmdAddRow_BLK_TDPAYINDETAILS").disabled = false;
	//document.getElementById("cmdDelRow_BLK_TDPAYINDETAILS").disabled = false;
	//FCUBS 11.2 SFR # 838,ITR-1 changes ends.
	
	if(document.getElementsByName("PAYINBYCHQ")[0].value=='Q')
	{
	//FCUBS 11.2 SFR # 838,ITR-1 changes starts.
	//document.getElementById("cmdAddRow_BLK_TDPAYINDETAILS").style.visibility = "hidden";
	//document.getElementById("cmdDelRow_BLK_TDPAYINDETAILS").style.visibility = "hidden";
//FCUBS11.3 ITR1 SFR# 11891621 ends	
	/*fnDisableElement(document.getElementById("BLK_TDPAYINDETAILS__MMPAYOPT"));
		for (var i = 0; i < document.getElementsByName("BLK_TDPAYINDETAILS").length; i++)
		{
			document.getElementsByName("BLK_TDPAYINDETAILS")[i].disabled = true;
			//document.getElementsByName("BLK_TDPAYINDETAILS__MMOFFSETACC")[i].nextSibling.disabled = true;  //IshwaryaR commented for  FCUBS 11.2 SFR # 714,ITR-1
	      }*/
	//FCUBS 11.2 SFR # 838,ITR-1 changes ends.
	}
	
}
//9NT1428 FCUBS 11.2 Changes By Aslam Endz

	//Kernel 11.0 - Casa - Minimum Account Opening Amount/Account Opening Charges Start
	for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
	{
		document.getElementsByName("PAY_IN_OPTION")[i].disabled = true;
	}
	fnDisableElement(document.getElementsByName("INF_OFFSET_BRANCH")[0]);
	fnDisableElement(document.getElementsByName("INF_OFFSET_ACCOUNT")[0]);
	//Kernel 11.0 - Casa - Minimum Account Opening Amount/Account Opening Charges  End
    //Assign clearing account  same as new account.
    document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;
  fn_button();     //9NT1462 Standard Documents Added by Tapas
  if(document.getElementById('BLK_CUST_ACCOUNT__ADESC').value == "") //9NT1606_12.0.2_IALLUBT_RETRO_17745912
  {
      //9NT1501 12.0 USABILITY CHANGES changes starts
      document.getElementById('BLK_CUST_ACCOUNT__ADESC').value=document.getElementById('BLK_CUST_ACCOUNT__CUSTNAME').value;
  } //9NT1606_12.0.2_IALLUBT_RETRO_17745912
	//9NT1606_12.0.3_INTERNAL_19179661 starts
	if(functionId=='STDCUSAC') {
		document.getElementById("BLK_CUST_ACCOUNT__ACCLSTYP").previousSibling.parentNode.style.display = "none"; //ACCLSTYP changes	
	}
	//9NT1606_12.0.3_INTERNAL_19179661 ends
	return true;
}

function fnShowAccNoScreen(){
        //Infra Changes - function origin array - starts
        ArrFuncOrigin["STDCUSAC"]="KERNEL";
        ArrPrntFunc["STDCUSAC"]="";
        ArrPrntOrigin["STDCUSAC"]="";
        ArrRoutingType["STDCUSAC"]="X";
	//Infra Changes - function origin array - ends
	fnSubScreenMain('STDCUSAC', 'STDCUSAC', 'CVS_ACNO', strCurrentTabId);
	return true;

}
//Fcubs_12.4_multi_currency_accounts
function fnShowMcyAccNoScreen(){
        //Infra Changes - function origin array - starts
        ArrFuncOrigin["STDCUSAC"]="KERNEL";
        ArrPrntFunc["STDCUSAC"]="";
        ArrPrntOrigin["STDCUSAC"]="";
        ArrRoutingType["STDCUSAC"]="X";
	//Infra Changes - function origin array - ends
	fnSubScreenMain('STDCUSAC', 'STDCUSAC', 'CVS_MULTI_ACNO', strCurrentTabId);
	return true;

}
//Fcubs_12.4_multi_currency_accounts

//9NT1606_12.0.3_IPKRASK-RETRO-18731464 Changes - Start
function fnInTab_TAB_MAIN_KERNEL()
{
	if(document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value == 'DUMMY')
	{
	    document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;
	}	
	//PNTFLX01011_12.1_ITR2_21776031 changes starts
	if(document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value == 'DUMMY' || document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value == '')
	{
	    document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;
	}	
	//PNTFLX01011_12.1_ITR2_21776031 changes ends
    return true; 
}
//9NT1606_12.0.3_IPKRASK-RETRO-18731464 Changes - End

function   fnEnableBTn(){               //new function by suhel        FC10.35SFR#1303
//FCUBS_12.1.0.0.0_DEV_<IBAN_Enhancements> starts
  /* if(document.getElementsByName("IBANRQD")[0].checked==true)
	{
		fnEnableElement(document.getElementsByName("BTN_CALLIBAN")[0]);
    }
	else
	{
		fnDisableElement(document.getElementsByName("BTN_CALLIBAN")[0]);
	}*/
	//FCUBS_12.1.0.0.0_DEV_<IBAN_Enhancements> ends

	return true;

}

function fnPreLoad_CVS_ACNO_KERNEL(screenArgs)
{
	
	screenArgs['ACCLS']      	= document.getElementsByName("ACCLS")[0].value;
	screenArgs['CUSTNO']   	  	= document.getElementsByName("CUSTNO")[0].value;
	screenArgs['CCY'] 	  	  	= document.getElementsByName("CCY")[0].value;
	screenArgs['CCYTYPE']   	= document.getElementsByName("CCYTYPE")[0].value;
	screenArgs['ACCMASK'] 	  	= document.getElementsByName("ACCMASK")[0].value;
	screenArgs['ACODE'] 	  	= document.getElementsByName("ACODE")[0].value;
	screenArgs['ALTBRN'] 	  	= document.getElementsByName("ALTBRANCH")[0].value; //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode added
	return true;
}
//Fcubs_12.4_multi_currency_accounts starts 
function fnPreLoad_CVS_MULTI_ACNO_KERNEL(screenArgs)
{
	screenArgs['ACCLS']      	= document.getElementsByName("ACCLS")[0].value;
	screenArgs['CUSTNO']   	  	= document.getElementsByName("CUSTNO")[0].value;
	screenArgs['CCY'] 	  	  	= document.getElementsByName("CCY")[0].value;
	screenArgs['CCYTYPE']   	= document.getElementsByName("CCYTYPE")[0].value;
	screenArgs['ACCMASK'] 	  	= document.getElementsByName("ACCMASK")[0].value;
	screenArgs['ACODE'] 	  	= document.getElementsByName("ACODE")[0].value;
	screenArgs['ALTBRN'] 	  	= document.getElementsByName("ALTBRANCH")[0].value; //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode added
	return true;
}
//Fcubs_12.4_multi_currency_accounts ends 
function fnPostLoad_CVS_ACNO_KERNEL(screenArgs)
{
	disableForm();
	fnEnableElement(document.getElementsByName("BTN_OK")[0]);

	var mask   	= screenArgs["ACCMASK"];
	var cif    	= screenArgs["CUSTNO"];
	var aclass  = screenArgs["ACCLS"];
	var acode	= screenArgs["ACODE"];
	var ccy		= screenArgs["CCY"];
	var ccytype	= screenArgs["CCYTYPE"];
	var brn		= g_txnBranch;
    var udf = document.getElementsByName("MSKACC")[0].value;     //9NT1606_12.0.2_IXOFBRM_RETRO_17267311 Changes
	var alt_branch = screenArgs["ALTBRN"]; //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode added
	document.getElementsByName("ACCMSK")[0].value    = mask;
	document.getElementsByName("MSKACCCLS")[0].value = aclass;
	document.getElementsByName("MSKCUSTNO")[0].value = cif;
	document.getElementsByName("MSKCCY")[0].value    = ccy;
	document.getElementsByName("MSKACCCD")[0].value  = acode; //FC10.3 - SFR#609
	document.getElementsByName("MSKCCYTYP")[0].value = ccytype; //FC10.3 - SFR#609

	String.prototype.lPad = function (n,c) {var i; var a = this.split(''); for (i = 0; i < n - this.length; i++) {a.unshift (c)}; return a.join('');}
    String.prototype.rPad = function (n,c) {var i; var a = this.split(''); for (i = 0; i < n - this.length; i++) {a.push (c)}; return a.join('');}

	var padded_mask	 = mask.lPad(20,' ');
	var mask_items	 =new Array();
    var tmpMask		 =mask;
    var cifLength    =count(mask,'C') ;
	var aclassLength =count(mask,'L') ;
	var CCYTYPELength =count(mask,'Z') ;
	var bnkLength	 =count(mask,'b')	 ;
	var udfLength	 =count(mask,'U')	;
	var ccyLength	 =count(mask,'$')	;
	var numLength	 =count(mask,'n') ;
	var alphLength	 =count(mask,'a') ;
	var chkdgtLength =count(mask,'d') ;
	var acodeLength	 =count(mask,'T') ;
	var i,ch,str;

	var mask_items_len = new Array();
	var ac_no = '';

	for	(i=0;i<mask.length-1;i++)
	{
	   str='';
	   if (tmpMask.length==0)
	   {
	     break;
	   }
	  ch=tmpMask.charAt(0);
	  while (tmpMask.indexOf(tmpMask.charAt(0)) > -1)
	  {
	   if(ch!=tmpMask.charAt(0)) break;
	   str=str+ch;
       tmpMask = tmpMask.replace(tmpMask.charAt(0),'');
	  }
	  mask_items[i]=str;

	}

	for (i=0;i<mask_items.length ; i++)
    {
	  mask_items_len[i]=mask_items[i].length;
    }

	for (i=0;i<mask_items.length ; i++)
    {
	  if(mask_items[i].charAt(0)=='C')
	  {
	   if (cif==null)
	   {
	      //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
	   cif=cif.substr(cif.length-mask_items[i].length,mask_items[i].length);
	   var indx=padded_mask.indexOf('C')+1;
	   for(j=0;j<cif.length;j++)
	   {
		 if(indx>20) break;
		 document.getElementsByName("T"+indx)[0].value=cif.charAt(j);
		 indx=indx+1;
	   }
	   ac_no = ac_no + cif.substr(cif.length-mask_items[i].length,mask_items[i].length);
	  }

	 //account class
	 else if(mask_items[i].charAt(0)=='L')
	  {
	   if (aclass==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
   aclass=aclass.substr(0,mask_items[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867  changes done
	   var indx=padded_mask.indexOf('L')+1;
	   for(j=0;j<aclass.length;j++)
	   {
		 if(indx>20) break;
		 document.getElementsByName("T"+indx)[0].value=aclass.charAt(j);
		 indx=indx+1;
	   }
	   ac_no = ac_no + aclass.substr(0,mask_items[i].length);
	  }

	  //Ccy type
	  else if(mask_items[i].charAt(0)=='Z')
	  {
	   if (ccytype==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
	   var indx=padded_mask.indexOf('Z')+1;
	   for(j=0;j<3;j++)
	   {
		 if(indx>20) break;
		 document.getElementsByName("T"+indx)[0].value=ccytype.charAt(j);
		 indx=indx+1;
	   }

	   ac_no = ac_no + ccytype;
	  }

	  //cccy
	  else if(mask_items[i].charAt(0)=='$')
	  {
	   if (ccy==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
	   var indx=padded_mask.indexOf('$')+1;
	   for(j=0;j<3;j++)
	   {
		 if(indx>20) break;
		 document.getElementsByName("T"+indx)[0].value=ccy.charAt(j);
		 indx=indx+1;
	   }
	   ac_no = ac_no + ccytype;
	  }
	 else if(mask_items[i].charAt(0)=='T')
	  {
		   if (acode==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
			showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
			  break;
		   }
     acode=acode.substr(0,mask_items[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867  changes
		   var indx=padded_mask.indexOf('T')+1;
		   for(j=0;j<acode.length;j++)
		   {
			 if(indx>20) break;
			 document.getElementsByName("T"+indx)[0].value=acode.charAt(j);
			 indx=indx+1;
		   }
		   ac_no = ac_no + acode;
	  }
	  //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode  starts
	 else if(mask_items[i].charAt(0)=='r')
	  {
		   if (alt_branch==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
			showErrorAlerts('IN-HEAR-357');
			  break;
		   }
		   var indx=padded_mask.indexOf('r')+1;
		   for(j=0;j<alt_branch.length;j++)
		   {
			 if(indx>20) break;
			 document.getElementsByName("T"+indx)[0].value=alt_branch.charAt(j);
			 indx=indx+1;
		   }
		   ac_no = ac_no + alt_branch;
	  }
	  //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode  ends
	  else if(mask_items[i].charAt(0)=='b')
	  {
		   if (brn==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
			  break;
		   }
		   var indx=padded_mask.indexOf('b')+1;
		   for(j=0;j<3;j++)
		   {
			 if(indx>20) break;
			 document.getElementsByName("T"+indx)[0].value=brn.charAt(j);
			 indx=indx+1;
		   }
		   ac_no = ac_no + brn;
	  }
	  
	  //9NT1606_12.0.2_IXOFBRM_RETRO_17267311 Changes changes starts
	  else if(mask_items[i].charAt(0)=='U')
	  {
	      if(udf == null)
		  {
		      showErrorAlerts('IN-HEAR-357');
			  break;
		  }	  
 udf=udf.substr(0,mask_items[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867   changes
		  var indx=padded_mask.indexOf('U')+1;
		  for(j=0;j<udfLength;j++)
		   {
			 if(indx>20) break;
			 document.getElementsByName("T"+indx)[0].value=udf.charAt(j);
			 indx=indx+1;
		   }
		   ac_no = ac_no + udf;
	}
	//9NT1606_12.0.2_IXOFBRM_RETRO_17267311 Changes changes ends
	}
    //FCUBS_12.1.0_AmmendIssue starts
	//var k = 0;
	accgenAmendArr = {};
	var accgenAmdBlk = "";
	var accgenAmdFld = "";
    //FCUBS_12.1.0_AmmendIssue ends
	for (i=0;i<20;i++ )
	{
		document.getElementsByName("L"+(i+1))[0].value= padded_mask.charAt(i);
		if(padded_mask.charAt(i)=='a' ||padded_mask.charAt(i)=='n'){
		  //Building an amendable array
          //FCUBS_12.1.0_AmmendIssue starts
		  var blkFld = document.getElementsByName("T"+(i+1))[0].id;
		  accgenAmdBlk = blkFld.split("__")[0];
		  accgenAmdFld = accgenAmdFld +"\""+ blkFld.split("__")[1] +"\",";
		  //accgenAmendArr[k] = document.getElementsByName("T"+(i+1))[0].id;
		  //k++;
          //FCUBS_12.1.0_AmmendIssue ends
		}
		else if(padded_mask.charAt(i)=='S' ||padded_mask.charAt(i)=='d'||padded_mask.charAt(i)=='D' ||padded_mask.charAt(i)=='.'||padded_mask.charAt(i)=='-'||padded_mask.charAt(i)=='*'||padded_mask.charAt(i)==','||padded_mask.charAt(i)=='/')//Bug_28054487 added
		  document.getElementsByName("T"+(i+1))[0].value= padded_mask.charAt(i);
	}
    //FCUBS_12.1.0_AmmendIssue starts
	if(accgenAmdFld.lastIndexOf(","))
		accgenAmdFld = accgenAmdFld.substring(0, accgenAmdFld.length-1);
	if( accgenAmdBlk != "" && accgenAmdFld != "") {  //PNTFLX01011_FCUBS_12.1_ITR1_21361038 Changes
	var fnEval = new Function("accgenAmendArr =  {" + accgenAmdBlk + ":["+accgenAmdFld+"]}");
	fnEval();
	} //PNTFLX01011_FCUBS_12.1_ITR1_21361038 Changes
    //FCUBS_12.1.0_AmmendIssue ends
	fnEnableAmendFields('accgen');
	return true;
}
//Fcubs_12.4_multi_currency_accounts starts
function fnPostLoad_CVS_MULTI_ACNO_KERNEL(screenArgs)
{
	disableForm();
	
	fnEnableElement(document.getElementsByName("BTN_OK")[0]);

	var mask   	= screenArgs["ACCMASK"];
	var cif    	= screenArgs["CUSTNO"];
	var aclass  = screenArgs["ACCLS"];
	var acode	= screenArgs["ACODE"];
	var ccy		= screenArgs["CCY"];
	var ccytype	= screenArgs["CCYTYPE"];
	var brn		= g_txnBranch;
    var udf = document.getElementsByName("MSKACC")[0].value;     //9NT1606_12.0.2_IXOFBRM_RETRO_17267311 Changes
	var alt_branch = screenArgs["ALTBRN"]; //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode added
	var mask1 = document.getElementsByName("MCYMSK")[0].value;
	document.getElementsByName("ACCMSK")[0].value    = mask;
	document.getElementsByName("MSKACCCLS")[0].value = aclass;
	document.getElementsByName("MSKCUSTNO")[0].value = cif;
	document.getElementsByName("MSKCCY")[0].value    = ccy;
	document.getElementsByName("MSKACCCD")[0].value  = acode; //FC10.3 - SFR#609
	document.getElementsByName("MSKCCYTYP")[0].value = ccytype; //FC10.3 - SFR#609

	String.prototype.lPad = function (n,c) {var i; var a = this.split(''); for (i = 0; i < n - this.length; i++) {a.unshift (c)}; return a.join('');}
    String.prototype.rPad = function (n,c) {var i; var a = this.split(''); for (i = 0; i < n - this.length; i++) {a.push (c)}; return a.join('');}

	var padded_mask	 = mask.lPad(20,' ');
	var mask_items	 =new Array();
    var tmpMask		 =mask;
    var cifLength    =count(mask,'C') ;
	var aclassLength =count(mask,'L') ;
	var CCYTYPELength =count(mask,'Z') ;
	var bnkLength	 =count(mask,'b')	 ;
	var udfLength	 =count(mask,'U')	;
	var ccyLength	 =count(mask,'$')	;
	var numLength	 =count(mask,'n') ;
	var alphLength	 =count(mask,'a') ;
	var chkdgtLength =count(mask,'d') ;
	var acodeLength	 =count(mask,'T') ;
	//MCY
		var padded_mask1	 = mask1.lPad(20,' ');
	var mask_items1	 =new Array();
    var tmpMask1		 =mask1;
    var cifLength1    =count(mask1,'C') ;
	var aclassLength1 =count(mask1,'L') ;
	var CCYTYPELength1 =count(mask1,'Z') ;
	var bnkLength1	 =count(mask1,'b')	 ;
	var udfLength1	 =count(mask1,'U')	;
	var ccyLength1	 =count(mask1,'$')	;
	var numLength1	 =count(mask1,'n') ;
	var alphLength1	 =count(mask1,'a') ;
	var chkdgtLength1 =count(mask1,'d') ;
	var acodeLength1	 =count(mask1,'T') ;
		
	var i,ch1,str1;

	var mask_items_len1 = new Array();
	var ac_no1 = '';
	//MCY ENDS 
		
	var i,ch,str;

	var mask_items_len = new Array();
	var ac_no = '';

	for	(i=0;i<mask.length-1;i++)
	{
	   str='';
	   if (tmpMask.length==0)
	   {
	     break;
	   }
	  ch=tmpMask.charAt(0);
	  while (tmpMask.indexOf(tmpMask.charAt(0)) > -1)
	  {
	   if(ch!=tmpMask.charAt(0)) break;
	   str=str+ch;
       tmpMask = tmpMask.replace(tmpMask.charAt(0),'');
	  }
	  mask_items[i]=str;

	}

	for (i=0;i<mask_items.length ; i++)
    {
	  mask_items_len[i]=mask_items[i].length;
    }

	for (i=0;i<mask_items.length ; i++)
    {
	  if(mask_items[i].charAt(0)=='C')
	  {
	   if (cif==null)
	   {
	      //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
	   cif=cif.substr(cif.length-mask_items[i].length,mask_items[i].length);
	   var indx=padded_mask.indexOf('C')+1;
	   for(j=0;j<cif.length;j++)
	   {
		 if(indx>20) break;
		 document.getElementsByName("T"+indx)[0].value=cif.charAt(j);
		 indx=indx+1;
	   }
	   ac_no = ac_no + cif.substr(cif.length-mask_items[i].length,mask_items[i].length);
	  }

	 //account class
	 else if(mask_items[i].charAt(0)=='L')
	  {
	   if (aclass==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
   aclass=aclass.substr(0,mask_items[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867  changes done
	   var indx=padded_mask.indexOf('L')+1;
	   for(j=0;j<aclass.length;j++)
	   {
		 if(indx>20) break;
		 document.getElementsByName("T"+indx)[0].value=aclass.charAt(j);
		 indx=indx+1;
	   }
	   ac_no = ac_no + aclass.substr(0,mask_items[i].length);
	  }

	  //Ccy type
	  else if(mask_items[i].charAt(0)=='Z')
	  {
	   if (ccytype==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
	   var indx=padded_mask.indexOf('Z')+1;
	   for(j=0;j<3;j++)
	   {
		 if(indx>20) break;
		 document.getElementsByName("T"+indx)[0].value=ccytype.charAt(j);
		 indx=indx+1;
	   }

	   ac_no = ac_no + ccytype;
	  }

	  //cccy
	  else if(mask_items[i].charAt(0)=='$')
	  {
	   if (ccy==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
	   var indx=padded_mask.indexOf('$')+1;
	   for(j=0;j<3;j++)
	   {
		 if(indx>20) break;
		 document.getElementsByName("T"+indx)[0].value=ccy.charAt(j);
		 indx=indx+1;
	   }
	   ac_no = ac_no + ccytype;
	  }
	 else if(mask_items[i].charAt(0)=='T')
	  {
		   if (acode==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
			showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
			  break;
		   }
     acode=acode.substr(0,mask_items[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867  changes
		   var indx=padded_mask.indexOf('T')+1;
		   for(j=0;j<acode.length;j++)
		   {
			 if(indx>20) break;
			 document.getElementsByName("T"+indx)[0].value=acode.charAt(j);
			 indx=indx+1;
		   }
		   ac_no = ac_no + acode;
	  }
	  //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode  starts
	 else if(mask_items[i].charAt(0)=='r')
	  {
		   if (alt_branch==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
			showErrorAlerts('IN-HEAR-357');
			  break;
		   }
		   var indx=padded_mask.indexOf('r')+1;
		   for(j=0;j<alt_branch.length;j++)
		   {
			 if(indx>20) break;
			 document.getElementsByName("T"+indx)[0].value=alt_branch.charAt(j);
			 indx=indx+1;
		   }
		   ac_no = ac_no + alt_branch;
	  }
	  //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranchcode  ends
	  else if(mask_items[i].charAt(0)=='b')
	  {
		   if (brn==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
			  break;
		   }
		   var indx=padded_mask.indexOf('b')+1;
		   for(j=0;j<3;j++)
		   {
			 if(indx>20) break;
			 document.getElementsByName("T"+indx)[0].value=brn.charAt(j);
			 indx=indx+1;
		   }
		   ac_no = ac_no + brn;
	  }
	  
	  //9NT1606_12.0.2_IXOFBRM_RETRO_17267311 Changes changes starts
	  else if(mask_items[i].charAt(0)=='U')
	  {
	      if(udf == null)
		  {
		      showErrorAlerts('IN-HEAR-357');
			  break;
		  }	  
 udf=udf.substr(0,mask_items[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867   changes
		  var indx=padded_mask.indexOf('U')+1;
		  for(j=0;j<udfLength;j++)
		   {
			 if(indx>20) break;
			 document.getElementsByName("T"+indx)[0].value=udf.charAt(j);
			 indx=indx+1;
		   }
		   ac_no = ac_no + udf;
	}
	//9NT1606_12.0.2_IXOFBRM_RETRO_17267311 Changes changes ends
	}
//MCY STARTS
	for	(i=0;i<mask1.length-1;i++)
	{
	   str1='';
	   if (tmpMask1.length==0)
	   {
	     break;
	   }
	  ch1=tmpMask1.charAt(0);
	  while (tmpMask1.indexOf(tmpMask1.charAt(0)) > -1)
	  {
	   if(ch1!=tmpMask1.charAt(0)) break;
	   str1=str1+ch1;
       tmpMask1 = tmpMask1.replace(tmpMask1.charAt(0),'');
	  }
	  mask_items1[i]=str1;

	}

	for (i=0;i<mask_items1.length ; i++)
    {
	  mask_items_len1[i]=mask_items1[i].length;
    }

	for (i=0;i<mask_items1.length ; i++)
    {
	  if(mask_items1[i].charAt(0)=='C')
	  {
	   if (cif==null)
	   {
	      //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
	   cif=cif.substr(cif.length-mask_items1[i].length,mask_items1[i].length);
	   var indx1=padded_mask1.indexOf('C')+1;
	   for(j=0;j<cif.length;j++)
	   {
		 if(indx1>20) break;
		 document.getElementsByName("MT"+indx1)[0].value=cif.charAt(j);
		 indx1=indx1+1;
	   }
	   ac_no1 = ac_no1 + cif.substr(cif.length-mask_items1[i].length,mask_items1[i].length);
	  }

	 //account class
	 else if(mask_items1[i].charAt(0)=='L')
	  {
	   if (aclass==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
		  break;
	   }
   aclass=aclass.substr(0,mask_items1[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867  ch1anges done
	   var indx1=padded_mask1.indexOf('L')+1;
	   for(j=0;j<aclass.length;j++)
	   {
		 if(indx1>20) break;
		 document.getElementsByName("MT"+indx1)[0].value=aclass.charAt(j);
		 indx1=indx1+1;
	   }
	   ac_no1 = ac_no1 + aclass.substr1(0,mask_items1[i].length);
	  }

	  //Ccy type
	  else if(mask_items1[i].charAt(0)=='Z')
	  {
	   if (ccytype==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS ch1ange -Removal of hardcoded alerts
		  break;
	   }
	   var indx1=padded_mask1.indexOf('Z')+1;
	   for(j=0;j<3;j++)
	   {
		 if(indx1>20) break;
		 document.getElementsByName("MT"+indx1)[0].value=ccytype.charAt(j);
		 indx1=indx1+1;
	   }

	   ac_no1 = ac_no1 + ccytype;
	  }

	  //cccy
	  else if(mask_items1[i].charAt(0)=='$')
	  {
	   if (ccy==null)
	   {
	       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS ch1ange -Removal of hardcoded alerts
		  break;
	   }
	   var indx1=padded_mask1.indexOf('$')+1;
	   for(j=0;j<3;j++)
	   {
		 if(indx1>20) break;
		 document.getElementsByName("MT"+indx1)[0].value=ccy.charAt(j);
		 indx1=indx1+1;
	   }
	   ac_no1 = ac_no1 + ccytype;
	  }
	 else if(mask_items1[i].charAt(0)=='T')
	  {
		   if (acode==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
			showErrorAlerts('IN-HEAR-357');//NLS ch1ange -Removal of hardcoded alerts
			  break;
		   }
     acode=acode.substr(0,mask_items1[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867  ch1anges
		   var indx1=padded_mask1.indexOf('T')+1;
		   for(j=0;j<acode.length;j++)
		   {
			 if(indx1>20) break;
			 document.getElementsByName("MT"+indx1)[0].value=acode.charAt(j);
			 indx1=indx1+1;
		   }
		   ac_no1 = ac_no1 + acode;
	  }
	  //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranch1code  starts
	 else if(mask_items1[i].charAt(0)=='r')
	  {
		   if (alt_branch==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
			showErrorAlerts('IN-HEAR-357');
			  break;
		   }
		   var indx1=padded_mask1.indexOf('r')+1;
		   for(j=0;j<alt_branch.length;j++)
		   {
			 if(indx1>20) break;
			 document.getElementsByName("MT"+indx1)[0].value=alt_branch.charAt(j);
			 indx1=indx1+1;
		   }
		   ac_no1 = ac_no1 + alt_branch;
	  }
	  //PNTFLX01011_DEV_FCUBS_12.1_CASA_Alternatebranch1code  ends
	  else if(mask_items1[i].charAt(0)=='b')
	  {
		   if (brn==null)
		   {
		       //alert('Mandatory Fields Null or Invalid');
		  showErrorAlerts('IN-HEAR-357');//NLS change -Removal of hardcoded alerts
			  break;
		   }
		   var indx1=padded_mask1.indexOf('b')+1;
		   for(j=0;j<3;j++)
		   {
			 if(indx1>20) break;
			 document.getElementsByName("MT"+indx1)[0].value=brn.charAt(j);
			 indx1=indx1+1;
		   }
		   ac_no1 = ac_no1 + brn;
	  }
	  
	  //9NT1606_12.0.2_IXOFBRM_RETRO_17267311 ch1anges ch1anges starts
	  else if(mask_items1[i].charAt(0)=='U')
	  {
	      if(udf == null)
		  {
		      showErrorAlerts('IN-HEAR-357');
			  break;
		  }	  
 udf=udf.substr(0,mask_items1[i].length); //9NT1606_12_2_RETRO_12_0_3_23654867   changes
		  var indx1=padded_mask1.indexOf('U')+1;
		  for(j=0;j<udfLength;j++)
		   {
			 if(indx1>20) break;
			 document.getElementsByName("MT"+indx1)[0].value=udf.charAt(j);
			 indx1=indx1+1;
		   }
		   ac_no1 = ac_no1 + udf;
	}
	//9NT1606_12.0.2_IXOFBRM_RETRO_17267311 ch1anges ch1anges ends
	}
    //FCUBS_12.1.0_AmmendIssue starts
//MCY ENDS	

    //FCUBS_12.1.0_AmmendIssue starts
	//var k = 0;
	accgenAmendArr = {};
	var accgenAmdBlk = "";
	var accgenAmdFld = "";
    //FCUBS_12.1.0_AmmendIssue ends
	for (i=0;i<20;i++ )
	{
		document.getElementsByName("L"+(i+1))[0].value= padded_mask.charAt(i);
		if(padded_mask.charAt(i)=='a' ||padded_mask.charAt(i)=='n'){
		  //Building an amendable array
          //FCUBS_12.1.0_AmmendIssue starts
		  var blkFld = document.getElementsByName("T"+(i+1))[0].id;
		  accgenAmdBlk = blkFld.split("__")[0];
		  accgenAmdFld = accgenAmdFld +"\""+ blkFld.split("__")[1] +"\",";
		  //accgenAmendArr[k] = document.getElementsByName("T"+(i+1))[0].id;
		  //k++;
          //FCUBS_12.1.0_AmmendIssue ends
		}
		else if(padded_mask.charAt(i)=='S' ||padded_mask.charAt(i)=='d'||padded_mask.charAt(i)=='D' ||padded_mask.charAt(i)=='.'||padded_mask.charAt(i)=='-'||padded_mask.charAt(i)=='*'||padded_mask.charAt(i)==','||padded_mask.charAt(i)=='/')//Bug_28054487 added
		  document.getElementsByName("T"+(i+1))[0].value= padded_mask.charAt(i);
	}
    //FCUBS_12.1.0_AmmendIssue starts
	if(accgenAmdFld.lastIndexOf(","))
		accgenAmdFld = accgenAmdFld.substring(0, accgenAmdFld.length-1);
	if( accgenAmdBlk != "" && accgenAmdFld != "") {  //PNTFLX01011_FCUBS_12.1_ITR1_21361038 Changes
	var fnEval = new Function("accgenAmendArr =  {" + accgenAmdBlk + ":["+accgenAmdFld+"]}");
	fnEval();
	} //PNTFLX01011_FCUBS_12.1_ITR1_21361038 Changes
	fnEnableAmendFields('accgen');
    //FCUBS_12.1.0_AmmendIssue ends
	//MCY STARTS
		accgenAmendArr = {};
	var accgenAmdBlk1 = "";
	var accgenAmdFld1 = "";
    //FCUBS_12.1.0_AmmendIssue ends
	for (i=0;i<20;i++ )
	{
		document.getElementsByName("ML"+(i+1))[0].value= padded_mask1.charAt(i);
		if(padded_mask1.charAt(i)=='a' ||padded_mask1.charAt(i)=='n'){
		  //Building an amendable array
          //FCUBS_12.1.0_AmmendIssue starts
		  var blkFld1 = document.getElementsByName("MT"+(i+1))[0].id;
		  accgenAmdBlk1 = blkFld1.split("__")[0];
		  accgenAmdFld1 = accgenAmdFld1+"\""+ blkFld1.split("__")[1] +"\",";
		  //accgenAmendArr[k] = document.getElementsByName("MT"+(i+1))[0].id;
		  //k++;
          //FCUBS_12.1.0_AmmendIssue ends
		}
		else if(padded_mask1.charAt(i)=='S' ||padded_mask1.charAt(i)=='d'||padded_mask1.charAt(i)=='D' ||padded_mask1.charAt(i)=='.'||padded_mask1.charAt(i)=='-'||padded_mask.charAt(i)=='*'||padded_mask.charAt(i)==','||padded_mask.charAt(i)=='/')//Bug_28054487 added
		  document.getElementsByName("MT"+(i+1))[0].value= padded_mask1.charAt(i);
	}
    //FCUBS_12.1.0_AmmendIssue starts
	if(accgenAmdFld1.lastIndexOf(","))
		accgenAmdFld1 = accgenAmdFld1.substring(0, accgenAmdFld1.length-1);
	if( accgenAmdBlk1 != "" && accgenAmdFld1 != "") {  //PNTFLX01011_FCUBS_12.1_ITR1_21361038 changes
	var fnEval = new Function("accgenAmendArr =  {" + accgenAmdBlk1 + ":["+accgenAmdFld1+"]}");
	fnEval();
	} //PNTFLX01011_FCUBS_12.1_ITR1_21361038 changes
    //FCUBS_12.1.0_AmmendIssue ends
	fnEnableAmendFields('accgen');
	
	//MCY ENDS
	
//	fnEnableAmendFields('accgen');
	return true;
		
}
//Fcubs_12.4_multi_currency_accounts ENDS 
function count(str,ch)
{
	 var len=str.length;
	 while (str.indexOf(ch) > -1)
	 str = str.replace(ch,'');
	 return len-str.length;
}
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/
var gPreActionAccount = "";
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/

function fnPreSave_CVS_ACNO_KERNEL(screenArgs)
{
	
	var  mask=document.getElementsByName("ACCMSK")[0].value;
    var l_ac_no='';

    for (i=0;i<20;i++ )
	{
	  if (document.getElementsByName("T"+(i+1))[0].value=='')
		l_ac_no=l_ac_no+'#';
	  else
	    l_ac_no=l_ac_no+document.getElementsByName("T"+(i+1))[0].value;
	}

	l_ac_no = l_ac_no.substr((20-mask.length),mask.length);
	document.getElementsByName('MSKACC')[0].value= l_ac_no;
	document.getElementsByName('MSKACC')[0].value= document.getElementsByName('MSKACC')[0].value.toUpperCase(); //9NT1525_12.0_RETRO_VNDFCJS_14572018
	//Setting the gAction temporarily to enable the appendData
	var prevAction = gAction;
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/
        gPreActionAccount = gAction;
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/

	gAction = 'NEW';
	appendData(document.getElementById("TBLPage"+strCurrentTabId));

	//Setting the action to validate the entered account number
	gAction ='ACCVAL';
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/
	processingAction = "AccProcess";
	/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/
	fcjRequestDOM = buildUBSXml();
	servletURL = "FCClientHandler";
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	//gAction = 'prevAction'; //PNTFLX01011_DEV_FCUBS_12.1_IQA_21272136 added //PNTFLX01011_FCUBS_12.1_ITR1_21371752 commented
	gAction = prevAction; //PNTFLX01011_FCUBS_12.1_ITR1_21371752 added
	/*if(!fnProcessResponse()){
			gAction=prevAction; //FC10.3 - SFR#897
			return false;
	}*/
	var msgStatus = fnProcessResponse();
    fnPostProcessResponse(msgStatus);
		//FC10.3 SFR#224 starts
	/*l_ac_no =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACC"))
	parent.document.getElementById("BLK_CUST_ACCOUNT__ACC").value = l_ac_no;
	parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ALTACC"))
	//FC10.3 SFR#224 ends
	if (parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value == ''){
		parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value = l_ac_no;
	}
	gAction = prevAction;
	return true;*/
	if (msgStatus == 'SUCCESS') //9NT1606_12.0.3_INTERNAL_19234690
{

//parent.document.getElementById("BLK_CUST_ACCOUNT__MULTI_CCY_AC_NO").value  =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/MULTI_CCY_AC_NO")); //test//FCUBS_12.4_CNSL_PRINCE FINANCE PLC_SFR#28254432 commented
	return true;//9NT1606_12.0.3_IRONVBR_19217026
}
}
//Fcubs_12.4_multi_currency_accounts starts 
function fnPreSave_CVS_MULTI_ACNO_KERNEL(screenArgs)
{
	
	var  mask=document.getElementsByName("ACCMSK")[0].value;
    var l_ac_no='';
	
	//mca starts
	var l_ac_no1='';
	var mask1 = document.getElementsByName("MCYMSK")[0].value;
	for (i=0;i<20;i++ )
	{
	  if (document.getElementsByName("MT"+(i+1))[0].value=='')
		l_ac_no1=l_ac_no1+'#';
	  else
	    l_ac_no1=l_ac_no1+document.getElementsByName("MT"+(i+1))[0].value;
	}

	l_ac_no1 = l_ac_no1.substr((20-mask1.length),mask1.length);
	//document.getElementsByName('MULTI_CCY_AC_NO')[0].value= l_ac_no1;
parent.document.getElementById("BLK_CUST_ACCOUNT__MULTI_CCY_AC_NO").value = l_ac_no1;
	document.getElementsByName('MSKMCYACC')[0].value= l_ac_no1;
	document.getElementsByName('MSKMCYACC')[0].value= document.getElementsByName('MSKMCYACC')[0].value.toUpperCase();
		
	//mca ends
    for (i=0;i<20;i++ )
	{
	  if (document.getElementsByName("T"+(i+1))[0].value=='')
		l_ac_no=l_ac_no+'#';
	  else
	    l_ac_no=l_ac_no+document.getElementsByName("T"+(i+1))[0].value;
	}

	l_ac_no = l_ac_no.substr((20-mask.length),mask.length);
	document.getElementsByName('MSKACC')[0].value= l_ac_no;
	document.getElementsByName('MSKACC')[0].value= document.getElementsByName('MSKACC')[0].value.toUpperCase(); //9NT1525_12.0_RETRO_VNDFCJS_14572018
	//Setting the gAction temporarily to enable the appendData
	var prevAction = gAction;
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/
        gPreActionAccount = gAction;
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/

	gAction = 'NEW';
	appendData(document.getElementById("TBLPage"+strCurrentTabId));

	//Setting the action to validate the entered account number
	gAction ='ACCVAL';
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/
	processingAction = "AccProcess";
	/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/
	fcjRequestDOM = buildUBSXml();
	servletURL = "FCClientHandler";
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	//gAction = 'prevAction'; //PNTFLX01011_DEV_FCUBS_12.1_IQA_21272136 added //PNTFLX01011_FCUBS_12.1_ITR1_21371752 commented
	gAction = prevAction; //PNTFLX01011_FCUBS_12.1_ITR1_21371752 added
	/*if(!fnProcessResponse()){
			gAction=prevAction; //FC10.3 - SFR#897
			return false;
	}*/
	var msgStatus = fnProcessResponse();
    fnPostProcessResponse(msgStatus);
		//FC10.3 SFR#224 starts
	/*l_ac_no =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACC"))
	parent.document.getElementById("BLK_CUST_ACCOUNT__ACC").value = l_ac_no;
	parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ALTACC"))
	//FC10.3 SFR#224 ends
	if (parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value == ''){
		parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value = l_ac_no;
	}
	gAction = prevAction;
	return true;*/
	if (msgStatus == 'SUCCESS') //9NT1606_12.0.3_INTERNAL_19234690
{
parent.document.getElementById("BLK_CUST_ACCOUNT__MULTI_CCY_AC_NO").value  =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/MULTI_CCY_AC_NO"));

	return true;//9NT1606_12.0.3_IRONVBR_19217026
}
}

//Fcubs_12.4_multi_currency_accounts ends 
//Function to parse the SUBSYSTEMSTAT string
function extractSUBSYSTEMSTAT(statusStr, subsys)
{
    var stat;
    var start;
    start = statusStr.indexOf(subsys + ':');
	if (start == -1)
    {
        return 'NULL';
    }
    stat = statusStr.substr(start + subsys.length + 1, 1);

	return stat;
}

//Function to get the SUBSYSTEMSTAT
function getCurrentSUBSYSTEMSTAT(SUBSYSTEMSTAT, subsys)
{
    var statusStr = SUBSYSTEMSTAT;

	return extractSUBSYSTEMSTAT(statusStr, subsys);
}

//IC Interest Screen
//seperated the interest and deposit calls
function fnInterestProcess(screenArgs)
{

	gChecked = 'N';
	//Added for fcubs11.1,itr-1,sfr# 984 on 1-may-2010 starts
	screenArgs['SUBSYSTEMSTAT'] = parent.document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value;
        //Added for fcubs11.1,itr-1,sfr# 984 on 1-may-2010 ends
	//Code to check the SUBSYSTEMSTAT and set the subsys pkp function based on the stat != U
	if (gAction == "NEW" || gAction == "MODIFY"){
		var SUBSYSTEMSTAT = getCurrentSUBSYSTEMSTAT(screenArgs['SUBSYSTEMSTAT'], "INTDETAILS");
		//if (SUBSYSTEMSTAT != 'U'){
		if (SUBSYSTEMSTAT == 'D'){//9NT1501 PreIT sfr 257
			appendData(document.getElementById('TBLPageTAB_HEADER'));
		    appendData(document.getElementById('TBLPageTAB_MAIN'));
			appendData(document.getElementById('TBLPageTAB_DEPOSIT'));
			g_prev_gAction = gAction;
			gAction = 'ICPKP';
			fcjRequestDOM = buildUBSXml();
		    servletURL = "FCClientHandler";
		    fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);

			gSubsysStat = parent.document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value;
			//gAction = ''; FC10.5 - STR1 SFR 2793
			if(!fnProcessResponse()){
			    gAction=g_prev_gAction; //FC10.3 - SFR#924
				return false;
			}
			var pureXMLDOM = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
			setDataXML(getXMLString(pureXMLDOM));
			showData(dbStrRootTableName, 1);
			showAllData();
		    parent.document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value =getNodeText( selectSingleNode(dbDataDOM,"//SUBSYSTEMSTAT"));
			gAction=g_prev_gAction;
			gChecked = 'Y';
			gscrname ='CVS_INTEREST'; //added for fcubs11.1,sfr#5484,itr-1
		}
	}
    if (gAction == "NEW" || gAction == "MODIFY") //9NT1606_12.0.3_IRONVBR_19947532
    {  // 9NT1606_12_4_RETRO_12_2_26717130 Changes starts
		 fnEnableElement(document.getElementsByName("BTN_UDE_POPULATE")[0]);	
       // 9NT1606_12_4_RETRO_12_2_26717130 Changes ends
	if (gChecked == 'N'){
		g_prev_gAction = gAction;
		gAction = 'POPDT';
		fcjRequestDOM = buildUBSXml();
		servletURL = "FCClientHandler";
		fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
		//gAction = '';//FC11.1 - ITR1 SFR#1565 changes
		if(!fnProcessResponse()){
			gAction=g_prev_gAction; //FC10.3 - SFR#924
			return false;
		}
		//9NT1525_12.0_CBACNY_14492986 start
		var pureXMLDOM = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
			setDataXML(getXMLString(pureXMLDOM));
			showData(dbStrRootTableName, 1);
			resetIndex();
			showAllData();
		//9NT1525_12.0_CBACNY_14492986 end
		gAction=g_prev_gAction;
		gChecked = 'Y';
		//9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17356748 starts
		//PNTFLX01011_FCUBS_12.1_ITR1_21345048 changes added if condition
		if(functionId !='IADCUSTD' && functionId !='STDCUSAC' && functionId !='IADCUSAC') //9NT1606_12_2_RETRO_12_0_2_23657655 added CASA screens
		{
		parent.document.getElementById("BLK_TDDETAILS__MATDT").value = getNodeText(selectSingleNode(dbDataDOM,"//BLK_TDDETAILS/MATDT")); 
        fireHTMLEvent(parent.document.getElementById("BLK_TDDETAILS__MATDT"), "onpropertychange");
		}		
		//9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17356748 ends
	}
    }//9NT1606_12.0.3_IRONVBR_19947532 ends
	//sfr 3105 str1 10.5
	//9NT1525_12.0RETRO_FBNLGBP_14519320 starts
	if (gAction == "")	
	{
              //--9NT1525_11.3_FBNLGBP_14261673 Changes Starts
              disableForm();
              //--9NT1525_11.3_FBNLGBP_14261673 Changes Ends
		fnDisableElement(document.getElementById("BLK_INTPRODMAP__INTPROD"));
		fnDisableElement(document.getElementById("BLK_INTPRODMAP__WAIVEPROD"));
		fnDisableElement(document.getElementById("BLK_INTPRODMAP__GENUDECHNGADV"));
		fnDisableElement(document.getElementById("BLK_INTPRODMAP__PRODMAPSTAT"));
		fnDisableElement(document.getElementById("BLK_INTPRODMAP__ILPRD"));
		fnDisableElement(document.getElementById("BLK_INTPRODMAP__DISPTYP"));
      }
	  // -- 9NT1525_12.0RETRO_FBNLGBP_14519320  ends
	document.getElementById("BLK_INTDETAILS__BRN").value    = screenArgs['BRN'];
	document.getElementById("BLK_INTDETAILS__ACC").value    = screenArgs['ACC'];
	if (functionId =='IADCUSTD' || functionId =='STDCUSTD')//PNTFLX01016_FCUBS_12.1.0_ITR1_21625803
		document.getElementById("BLK_INTPRODMAP__UDECCY1").value = screenArgs['UDECCY1'];//PNTFLX01011_FCUBS_12.1_ITR1_21345048 changes
	return true;
}
//seperated the interest and deposit calls
function fnDepositProcess()
{
	gChecked = 'N';
	//Added for fcubs11.1,itr-1,sfr# 984 on 1-may-2010 starts
	screenArgs['SUBSYSTEMSTAT'] = document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value;
        //Added for fcubs11.1,itr-1,sfr# 984 on 1-may-2010 ends
	//Code to check the SUBSYSTEMSTAT and set the subsys pkp function based on the stat != U
	if (gAction == "NEW" || gAction == "MODIFY"){
		var SUBSYSTEMSTAT = getCurrentSUBSYSTEMSTAT(screenArgs['SUBSYSTEMSTAT'], "INTDETAILS");
		//if (SUBSYSTEMSTAT != 'U'){
		if (SUBSYSTEMSTAT == 'D'){//9NT1501 PreIT sfr 257
			appendData(document.getElementById('TBLPageTAB_HEADER'));
		    appendData(document.getElementById('TBLPageTAB_MAIN'));
			appendData(document.getElementById('TBLPageTAB_DEPOSIT'));
			g_prev_gAction = gAction;
			gAction = 'ICPKP';
			fcjRequestDOM = buildUBSXml();
		    servletURL = "FCClientHandler";
		    fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);

			gSubsysStat = document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value;
			//gAction = ''; FC10.5 - STR1 SFR 2793
			var pureXMLDOM = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
			setDataXML(getXMLString(pureXMLDOM));
			showData(dbStrRootTableName, 1);
			showAllData();
		    document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value =getNodeText(selectSingleNode(dbDataDOM,"//SUBSYSTEMSTAT"));
			gAction=g_prev_gAction;
			gChecked = 'Y';
		}
	//} 9NT1462 ITR2 SFR# 13528412  Commented

//FCUBS 12.0 DMS Changes Starts
//	if (gChecked == 'N'){ 
        if (gChecked == 'N' && gSkipDeposit == 'false' ){
//FCUBS 12.0 DMS Changes Ends

  //9NT1462 Changes  by IshwaryaR  starts
	appendData(document.getElementById('TBLPageTAB_HEADER'));
    appendData(document.getElementById('TBLPageTAB_MAIN'));
    appendData(document.getElementById('TBLPageTAB_DEPOSIT'));
  //9NT1462 Changes  by IshwaryaR  ends			
		g_prev_gAction = gAction;
		gAction = 'POPDT';
		fcjRequestDOM = buildUBSXml();
		servletURL = "FCClientHandler";
		fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
		//gAction = '';//FC11.1 - ITR1 SFR#1565 changes
		var pureXMLDOM = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
		setDataXML(getXMLString(pureXMLDOM));
		showData(dbStrRootTableName, 1);
		showAllData();
		gAction=g_prev_gAction;
		gChecked = 'Y';
		//PNTFLX01011_FCUBS_12.1_ITR1_21345048 changes starts
		parent.document.getElementById("BLK_TDDETAILS__MATDT").value = getNodeText(selectSingleNode(dbDataDOM,"//BLK_TDDETAILS/MATDT")); 
        fireHTMLEvent(parent.document.getElementById("BLK_TDDETAILS__MATDT"), "onpropertychange");
		//PNTFLX01011_FCUBS_12.1_ITR1_21345048 changes ends
	}
	appendData(document.getElementById('TBLPageTAB_DEPOSIT'));
	} //9NT1462 ITR2 SFR# 13528412 Added
	return true;
}

function fnPostLoad_CVS_INTEREST_KERNEL(screenArgs)
{

	fnInterestProcess(screenArgs);
	/*
//FC11.1 - ITR1 SFR#2092 changes strarts
if (gAction == "NEW" || gAction == "MODIFY"){
	for(var i=0;i<document.getElementsByName("EFFDTMAPSTAT").length;i++)
       {
       fnEnableElement(document.getElementsByName("EFFDTMAPSTAT")[i]);
       fnEnableElement(document.getElementsByName("UDEEFFDT")[i]);
       }
 }

//FC11.1 - ITR1 SFR#2092 changes  ends
*/
	return true;
}

//FC10.3 - SFR#632 - Begins

function fnPreSave_CVS_INTEREST_KERNEL(screenArgs)
{

parent.document.getElementsByName("INTSTDT")[0].value=document.getElementById("BLK_INTDETAILS__INTSTARTDT").value;
return true;
}

function fnInTab_TAB_DEPOSIT_KERNEL()
{
	//document.getElementsByName("INTSTDT")[0].value=intStartDate;
		//FC11.01 - ITR1 SFR-1543  --screen args made cross browser compatible
		fnDepositProcess();
		//parent.document.getElementsByName("INTSTDT")[0].value = document.getElementById("BLK_INTDETAILS__INTSTARTDT").value;
   //9NT1587 FC_DEV_12.0.2 VINU CHANGES starts
    if (functionId == 'IADCUSTD' && (gAction == 'NEW' || gAction == 'MODIFY'))
	{
	g_nullify_tenor = false; //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700
	fn_ChangeRollover();  
	g_nullify_tenor = true; //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700
	}
   //9NT1587 FC_DEV_12.0.2 VINU CHANGES ends
	return true;
}
//FC10.3 - SFR#632 - Ends

//Functions for MIS
function fnPreLoad_CVS_ACCOUNT_KERNEL(screenArgs)
{
	appendData(document.getElementById('TBLPageTAB_HEADER'));
	appendData(document.getElementById('TBLPageTAB_MAIN'));
	appendData(document.getElementById('TBLPageTAB_AUXILIARY'));

	var CustName = document.getElementById("BLK_CUST_ACCOUNT__CUSTNAME").value; //FC10.5 STR1 SFR#545
	if (gAction == 'NEW' || gAction == 'MODIFY'){
		var SUBSYSTEMSTAT = getCurrentSUBSYSTEMSTAT(document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value, "MISDETAILS");
		if (SUBSYSTEMSTAT != 'U'){
			var prevAction = gAction;
			gAction = 'MISPKP';
			fcjRequestDOM = buildUBSXml();
			servletURL = "FCClientHandler";
			fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
            //PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
            showProcessMsg = false;
			//gAction = '';
            //PNTFLX01011_FCUBS_12.1_MAT_21310050 ends
			if(!fnProcessResponse()){
				gAction=g_prev_gAction; //FC10.3 - SFR#924
				return false;
			}
			document.getElementById("BLK_CUST_ACCOUNT__CUSTNAME").value =CustName; //FC10.5 STR1 SFR#545
			gAction = prevAction;
		}
	}

	return true;
}

/*As part of cross browser compatibility, confirmation on exiting subscreen should not be given*/
function fnExitSubScreen_DEL()
{
    var confirmClose = false;

	if (gPrevAct == 'QRYAMTDT'){
		var PrevAction = gAction;
		gAction = gPrevAct;
	}

	if (gAction == 'NEW' || gAction == 'MODIFY')
    {
        var strCloseConfirm = mainWin.getItemDesc("LBL_CLOSE_CONFIRM");
        confirmClose = confirm(strCloseConfirm);
    } else confirmClose = true;
    if (confirmClose){
		//To set the original SUBSYSTEMSTAT
		if (typeof(gSubsysStat)!='undefined' || gSubsysStat != null){
			parent.document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value = gSubsysStat;
		}
		if (gAction == gPrevAct){
			gAction = PrevAction;
			gPrevAct = '';
		}
		self.close();
	}
	return true;
}

function  onclickBTN_OPENBRACE()
{

	var when_cond=document.getElementsByName('WHENCOND')[0].value;
	if (when_cond == "1")
		document.getElementsByName('INSTR1WHEN')[0].value=document.getElementsByName('INSTR1WHEN')[0].value+' (';
    else if (when_cond == "2")
	    document.getElementsByName('INSTR2WHEN')[0].value=document.getElementsByName('INSTR2WHEN')[0].value+' (';
    else if (when_cond == "3")
	    document.getElementsByName('INSTR3WHEN')[0].value=document.getElementsByName('INSTR3WHEN')[0].value+' (';
    else if (when_cond == "4")
	    document.getElementsByName('INSTR4WHEN')[0].value=document.getElementsByName('INSTR4WHEN')[0].value+' (';

    return true;
}

function  onclick_BTN_CLOSEBRACE()
{
	var when_cond=document.getElementsByName('WHENCOND')[0].value;
	if (when_cond == "1")
		document.getElementsByName('INSTR1WHEN')[0].value=document.getElementsByName('INSTR1WHEN')[0].value+' )';
    else if (when_cond == "2")
	    document.getElementsByName('INSTR2WHEN')[0].value=document.getElementsByName('INSTR2WHEN')[0].value+' )';
    else if (when_cond == "3")
	    document.getElementsByName('INSTR3WHEN')[0].value=document.getElementsByName('INSTR3WHEN')[0].value+' )';
    else if (when_cond == "4")
	    document.getElementsByName('INSTR4WHEN')[0].value=document.getElementsByName('INSTR4WHEN')[0].value+' )';

	return true;
}

function  onclick_BTN_AND()
{
	var when_cond 	= document.getElementsByName('WHENCOND')[0].value;
	var cond 		= 'AND '+ document.getElementsByName('WHENELEM')[0].value+' '
						+document.getElementsByName('WHENOP')[0].value +' '
						+document.getElementsByName('WHENVAL')[0].value;

	if (when_cond == "1")
		document.getElementsByName('INSTR1WHEN')[0].value=document.getElementsByName('INSTR1WHEN')[0].value+cond;
    else if (when_cond == "2")
	    document.getElementsByName('INSTR2WHEN')[0].value=document.getElementsByName('INSTR2WHEN')[0].value+cond;
    else if (when_cond == "3")
	    document.getElementsByName('INSTR3WHEN')[0].value=document.getElementsByName('INSTR3WHEN')[0].value+cond;
    else if (when_cond == "4")
	    document.getElementsByName('INSTR4WHEN')[0].value=document.getElementsByName('INSTR4WHEN')[0].value+cond;

    document.getElementsByName('WHENELEM')[0].value  ='';
    document.getElementsByName('WHENOP')[0].value ='';
    document.getElementsByName('WHENVAL')[0].value    ='';

	return true;
}

function  onclick_BTN_OR()
{
	var when_cond	= document.getElementsByName('WHENCOND')[0].value;
	var cond		= 'OR '+ document.getElementsByName('WHENELEM')[0].value+' '
						+document.getElementsByName('WHENOP')[0].value +' '
						+document.getElementsByName('WHENVAL')[0].value;

	if (when_cond == "1")
		document.getElementsByName('INSTR1WHEN')[0].value=document.getElementsByName('INSTR1WHEN')[0].value+cond;
  	else if (when_cond == "2")
		document.getElementsByName('INSTR2WHEN')[0].value=document.getElementsByName('INSTR2WHEN')[0].value+cond;
	else if (when_cond == "3")
		document.getElementsByName('INSTR3WHEN')[0].value=document.getElementsByName('INSTR3WHEN')[0].value+cond;
	else if (when_cond == "4")
		document.getElementsByName('INSTR4WHEN')[0].value=document.getElementsByName('INSTR4WHEN')[0].value+cond;

    document.getElementsByName('WHENELEM')[0].value  ='';
    document.getElementsByName('WHENOP')[0].value ='';
    document.getElementsByName('WHENVAL')[0].value    ='';

	return true;
}

function  onclick_BTN_DEL()
{
	var when_cond = document.getElementsByName('WHENCOND')[0].value;
	var len;
	if (when_cond == "1")
	{
		len = document.getElementsByName('INSTR1WHEN')[0].value.length;
		document.getElementsByName('INSTR1WHEN')[0].value = document.getElementsByName('INSTR1WHEN')[0].value.substr(0,len-1);
	}

	else if (when_cond == "2")
	{
		len=document.getElementsByName('INSTR2WHEN')[0].value.length;
		document.getElementsByName('INSTR2WHEN')[0].value = document.getElementsByName('INSTR2WHEN')[0].value.substr(0,len-1);
	}
	else if (when_cond == "3")
	{
		len=document.getElementsByName('INSTR3WHEN')[0].value.length;
		document.getElementsByName('INSTR3WHEN')[0].value = document.getElementsByName('INSTR3WHEN')[0].value.substr(0,len-1);
	}

	else if (when_cond == "4")
	{
		len=document.getElementsByName('INSTR4WHEN')[0].value.length;
		document.getElementsByName('INSTR4WHEN')[0].value = document.getElementsByName('INSTR4WHEN')[0].value.substr(0,len-1);
	}

	document.getElementsByName('WHENELEM')[0].value  = '';
	document.getElementsByName('WHENOP')[0].value = '';
	document.getElementsByName('WHENVAL')[0].value	 = '';

	return true;
}

function  onclick_BTN_WHENPOP()
{
	var when_cond = document.getElementsByName('WHENCOND')[0].value;
	var cond	  = ' '+ document.getElementsByName('WHENELEM')[0].value+' '
					+document.getElementsByName('WHENOP')[0].value +' '
					+document.getElementsByName('WHENVAL')[0].value ;

	if (when_cond == "1")
		document.getElementsByName('INSTR1WHEN')[0].value=document.getElementsByName('INSTR1WHEN')[0].value+cond;
	else if (when_cond == "2")
		document.getElementsByName('INSTR2WHEN')[0].value=document.getElementsByName('INSTR2WHEN')[0].value+cond;
	else if (when_cond == "3")
		document.getElementsByName('INSTR3WHEN')[0].value=document.getElementsByName('INSTR3WHEN')[0].value+cond;
	else if (when_cond == "4")
		document.getElementsByName('INSTR4WHEN')[0].value=document.getElementsByName('INSTR4WHEN')[0].value+cond;

    document.getElementsByName('WHENELEM')[0].value  ='';
    document.getElementsByName('WHENOP')[0].value ='';
    document.getElementsByName('WHENVAL')[0].value    ='';

	return true;
}
//9NT1606_12_2_RETRO_12_0_3_23652204 starts
function fn_PopUde()
{
	g_prev_gAction = gAction;
			gAction = 'UDEPOP';
			appendData(); 
			fcjRequestDOM = buildUBSXml();
			fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
			showProcessMsg = true;
			var l_resp_code = fnProcessResponse();
			var pureXMLDOM = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
			setDataXML(getXMLString(pureXMLDOM));
			showData(dbStrRootTableName, 1);
			gAction=g_prev_gAction;

return true;
}
//9NT1606_12_2_RETRO_12_0_3_23652204 ends
function fnPreLoad_CVS_ICCHSPCN_KERNEL(screenArgs)
{
	screenArgs['BRN'] = document.getElementById('BLK_CUST_ACCOUNT__BRN').value;
	screenArgs['ACC'] = document.getElementById('BLK_CUST_ACCOUNT__ACC').value;
	screenArgs['CUSTNO'] = document.getElementById('BLK_CUST_ACCOUNT__CUSTNO').value;
	screenArgs['ACCLS'] = document.getElementById('BLK_CUST_ACCOUNT__ACCLS').value;
	screenArgs['CCY'] = document.getElementById('BLK_CUST_ACCOUNT__CCY').value;

	//Setting the subsystemstat to its new value here itself
	screenArgs['SUBSYSSTR'] = document.getElementById('BLK_CUST_ACCOUNT__SUBSYSTEMSTAT').value;
	var subsysstr = getSubsysstr('CHGDETAILS');

	return true;
}



function fnPreLoad_CVS_ICCINSTR_KERNEL(screenArgs)
{
	screenArgs['BRN'] = document.getElementById('BLK_CUST_ACCOUNT__BRN').value;
	screenArgs['ACC'] = document.getElementById('BLK_CUST_ACCOUNT__ACC').value;

        //Setting the subsystemstat to its new value here itself
        screenArgs['SUBSYSSTR'] = document.getElementById('BLK_CUST_ACCOUNT__SUBSYSTEMSTAT').value;
        var subsysstr = getSubsysstr('AUTODEPDETAILS');

	return true;
}

function getSubsysstr(subsys)
{
  var subsysstr = document.getElementById('BLK_CUST_ACCOUNT__SUBSYSTEMSTAT').value;
  gSubsysStat = subsysstr;
  var SUBSYSTEMSTAT = getCurrentSUBSYSTEMSTAT(subsysstr, subsys);
        if (SUBSYSTEMSTAT != 'U'){
          subsysstr = getNewSubsysstat(subsysstr, subsys);
          document.getElementById('BLK_CUST_ACCOUNT__SUBSYSTEMSTAT').value = subsysstr;
        }
  return subsysstr;
}

function fnPreLoad_CVS_ICCCSPCN_KERNEL(screenArgs)
{
	screenArgs['BRN'] = document.getElementById('BLK_CUST_ACCOUNT__BRN').value;
	screenArgs['ACC'] = document.getElementById('BLK_CUST_ACCOUNT__ACC').value;
	screenArgs['CUSTNO'] = document.getElementById('BLK_CUST_ACCOUNT__CUSTNO').value;
	screenArgs['ACCLS'] = document.getElementById('BLK_CUST_ACCOUNT__ACCLS').value;
	screenArgs['CCY'] = document.getElementById('BLK_CUST_ACCOUNT__CCY').value;

        //Setting the subsystemstat to its new value here itself
        screenArgs['SUBSYSSTR'] = document.getElementById('BLK_CUST_ACCOUNT__SUBSYSTEMSTAT').value;
        var subsysstr = getSubsysstr('CHGCONDETAILS');

	return true;
}

//9NT1606_12.0.3_UNION_BANK_19344703 starts
function fnPreLoad_CVS_STATEMENT_KERNEL(screenArgs)
{
if(functionId=='STDCUSTD'){
setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUST_ACCOUNT/CCY1"),document.getElementById('BLK_CUST_ACCOUNT__CCY').value);
}
return true;
}
//9NT1606_12.0.3_UNION_BANK_19344703 ends

function fnPostLoad_CVS_STATEMENT_KERNEL(screenArgs)
{
	var stmtDay1 =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACSTMTDAY"));
	var stmtDay2 =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACSTMTDAY2"))  ;
    var stmtDay3 =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACSTMTDAY3")) ;

    var cycle1 =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACSTMTCYCLE")) ;
    var cycle2 =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACSTMTCYCLE2")) ;
    var cycle3 =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACSTMTCYCLE3")) ;

	document.getElementsByName('ACSTMTCYCLE')[0].value = cycle1;
	document.getElementsByName('ACSTMTCYCLE2')[0].value = cycle2;
	document.getElementsByName('ACSTMTCYCLE3')[0].value = cycle3;

	fnpopulate('ACSTMTCYCLE','ACSTMTDAY');
	fnpopulate('ACSTMTCYCLE2','ACSTMTDAY2');
	fnpopulate('ACSTMTCYCLE3','ACSTMTDAY3');

	document.getElementsByName('ACSTMTDAY')[0].value = stmtDay1;
	document.getElementsByName('ACSTMTDAY2')[0].value = stmtDay2;
	document.getElementsByName('ACSTMTDAY3')[0].value = stmtDay3;

	return true;
}

function fnpopulate(fieldname,popfield)
{
	var value,i;
	var field;
	value=document.getElementsByName(fieldname)[0].value;
	field=document.getElementsByName(popfield)[0];
	removeAllOptions(field);
	switch(value)
	{
		case 'A':
		case 'S':
		case 'Q':
		//9NT1606_12.0.2_IUSDBOA_RETRO_17786519 changes starts
			/*addOption(field,"1", "January");
			addOption(field,"2","February");
			addOption(field,"3","March");
			addOption(field,"4","April");
			addOption(field,"5","May");
			addOption(field,"6","June");
			addOption(field,"7","July");
			addOption(field,"8","August");
			addOption(field,"9","September");
			addOption(field,"10","October");
			addOption(field,"11","November");
			addOption(field,"12","December");*/
		  addOption(field,"1", mainWin.getItemDesc("LBL_JAN"));
		  addOption(field,"2",mainWin.getItemDesc("LBL_FEB"));
		  addOption(field,"3",mainWin.getItemDesc("LBL_MAR"));
		  addOption(field,"4",mainWin.getItemDesc("LBL_APR"));
		  addOption(field,"5",mainWin.getItemDesc("LBL_MAY"));
		  addOption(field,"6",mainWin.getItemDesc("LBL_JUN"));
		  addOption(field,"7",mainWin.getItemDesc("LBL_JUL"));
		  addOption(field,"8",mainWin.getItemDesc("LBL_AUG"));
		  addOption(field,"9",mainWin.getItemDesc("LBL_SEP"));
		  addOption(field,"10",mainWin.getItemDesc("LBL_OCT"));
		  addOption(field,"11",mainWin.getItemDesc("LBL_NOV") );
		  addOption(field,"12",mainWin.getItemDesc("LBL_DEC"));		
		//9NT1606_12.0.2_IUSDBOA_RETRO_17786519 changes ends		  
			addOption(field,"","");			
			break;
		case 'M':
			for (i=1;i<=31 ;i++ )
			{
			  addOption(field,""+i, ""+i);
			}
			addOption(field,"","");
			break;
		case 'F':
		case 'W':
		//9NT1606_12.0.2_IUSDBOA_RETRO_17786519 changes starts
			/*addOption(field,"1","Sunday");
			addOption(field,"2","Monday");
			addOption(field,"3","Tuesday");
			addOption(field,"4", "wednesday");
			addOption(field,"5", "Thursday");
			addOption(field,"6", "Friday");
			addOption(field,"7", "Saturday");*/
		  addOption(field,"1",mainWin.getItemDesc("LBL_SUNDAY"));
		  addOption(field,"2",mainWin.getItemDesc("LBL_MONDAY"));
		  addOption(field,"3",mainWin.getItemDesc("LBL_TUESDAY"));
		  addOption(field,"4",mainWin.getItemDesc("LBL_WEDNESDAY"));
		  addOption(field,"5",mainWin.getItemDesc("LBL_THURSDAY"));
		  addOption(field,"6",mainWin.getItemDesc("LBL_FRIDAY"));
		  addOption(field,"7",mainWin.getItemDesc("LBL_SATURDAY"));			
		//9NT1606_12.0.2_IUSDBOA_RETRO_17786519 changes ends	
			addOption(field,"","");
			break;
		case 'D':
			addOption(field,"","");
		break;

		default:
			 addOption(field,"","");
	}
}



function fnPreLoad_CVS_ICCINSTR_KERNEL(screenArgs)
{
	screenArgs['BRN']    = document.getElementById('BLK_CUST_ACCOUNT__BRN').value;
	screenArgs['CUSTNO'] = document.getElementById('BLK_CUST_ACCOUNT__CUSTNO').value;
	screenArgs['ACCLS']  = document.getElementById('BLK_CUST_ACCOUNT__ACCLS').value;
	screenArgs['CCY']    = document.getElementById('BLK_CUST_ACCOUNT__CCY').value;

	return true;
}

function fnPreLoad_CVS_BILLING_KERNEL(screenArgs)
{
	screenArgs['BRN'] = document.getElementById('BLK_CUST_ACCOUNT__BRN').value;
	screenArgs['ACC'] = document.getElementById('BLK_CUST_ACCOUNT__ACC').value;
	screenArgs['CCY'] = document.getElementById('BLK_CUST_ACCOUNT__CCY').value;

	return true;
}

function fnLaunchAmountScreen(screenName)
{
        //Infra Changes - function origin array - starts
        ArrFuncOrigin["STDCUSAC"]="KERNEL";
        ArrPrntFunc["STDCUSAC"]="";
        ArrPrntOrigin["STDCUSAC"]="";
        ArrRoutingType["STDCUSAC"]="X";
	//Infra Changes - function origin array - ends

	fnSubScreenMain('STDCUSAC', 'STDCUSAC', screenName, strCurrentTabId);

	return true;
}
//9NT1606_FCUBS12.0.2_RETRO_17631898
function fnPreLoad_CVS_AMOUNTS_KERNEL(screenArgs)
{
setNodeText(selectSingleNode(dbDataDOM,"//BLK_AMOUNT_DATES/LCY"),mainWin.Lcy);
setNodeText(selectSingleNode(dbDataDOM,"//BLK_AMOUNT_DATES/ACY"),document.getElementById('BLK_CUST_ACCOUNT__CCY').value);
return true;
}
//9NT1606_FCUBS12.0.2_RETRO_17631898

function fnPostLoad_CVS_AMOUNTS_KERNEL(screenArgs)
{

    gPrevAct = '';
	g_prev_gAction = gAction;
	gAction = 'QRYAMTDT';
	gPrevAct = gAction;
	//gPrevAct = gAction;

	//}  FC11.0 - ITR1 SFR-697

	fcjRequestDOM = buildUBSXml();
	servletURL = "FCClientHandler";
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
    //PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
    showProcessMsg = false;
	//gAction = '';
    //PNTFLX01011_FCUBS_12.1_MAT_21310050 ends
	if(!fnProcessResponse()){
		gAction=g_prev_gAction; //FC10.3 - SFR#924
		return false;
	}
	gAction=g_prev_gAction;
	//FCUBS10.5,STR1,SFR#1042
	if(document.getElementById('BLK_AMOUNT_DATES__CCY').value =="")
	{
	 document.getElementById('BLK_AMOUNT_DATES__CCY').value= screenArgs['CCY'];
	}
	return true;
}

function fnPreLoad_CVS_RELATIONSHIP_KERNEL(screenArgs)
{
 //Setting the subsystemstat to its new value here itself
 screenArgs['SUBSYSSTR'] = document.getElementById('BLK_CUST_ACCOUNT__SUBSYSTEMSTAT').value;
 var subsysstr = getSubsysstr('LINKEDENT');
  //FCUBS 11.2 CHANGES FOR Linked Entities STARTS
  screenArgs['CUST_AC_NO'] = document.getElementsByName("ACC")[0].value;
  screenArgs['CATEGORY'] = 'A';
  //FCUBS 11.2 CHANGES FOR Linked Entities ENDS


  return true;
}
//changes by sharad FC11.1 - ITR1 SFR-864
/*
function fnPreLoad_CVS_CLOSE_KERNEL(screenArgs)
{
  screenArgs['BRN']    = document.getElementById('BLK_CUST_ACCOUNT__BRN').value;
  screenArgs['ACC']    = document.getElementById('BLK_CUST_ACCOUNT__ACC').value;
  screenArgs['CCY']    = document.getElementById('BLK_CUST_ACCOUNT__CCY').value;
  screenArgs['BLK_ACCCLOSE'] = "BLK_CUST_ACCOUNT~1";
  screenArgs['BLK_CUST_ACCOUNT_CLOSURE'] = "BLK_ACCCLOSE~1";

  return true;
}
*/
//changes by sharad FC11.1 - ITR1 SFR-864

/*
function fnClose()
{
    debugs("FunctionId=", functionId);

   debugs("calling appendErrorCode with 'FC-MAINT13'", "");
    appendErrorCode('FC-MAINT13', null);
    if (! (confirmAction()))
    {

        gAction = "";
        debugs("User Canceled the Action - Close", "");
        return;
    }

	if (!fnEventsHandler('fnPreClose')) return;

	try
    {
        fcjRequestDOM = buildUBSXml();
    } catch(e)
    {
        displayError("EXTCLS-001");
        return;
    }

    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse())
    {
        fnSetExitButton();
        return;
    }
    gAction = "";
    fnSetExitButton();
    disableForm();
    showToolbar(functionId, '', '');

    if (!fnEventsHandler('fnPostClose')) return;
}*/

//changes by sharad FC11.1 - ITR1 SFR-864
function fnShowIBANScreen(screenName)
{
        //Infra Changes - function origin array - starts
        ArrFuncOrigin["STDCUSAC"]="KERNEL";
        ArrPrntFunc["STDCUSAC"]="";
        ArrPrntOrigin["STDCUSAC"]="";
        ArrRoutingType["STDCUSAC"]="X";
	//Infra Changes - function origin array - ends
	fnSubScreenMain('STDCUSAC', 'STDCUSAC', screenName);

	return true;
}

function fnShowPROVScreen(screenName)
{
        //Infra Changes - function origin array - starts
        ArrFuncOrigin["STDCUSAC"]="KERNEL";
        ArrPrntFunc["STDCUSAC"]="";
        ArrPrntOrigin["STDCUSAC"]="";
        ArrRoutingType["STDCUSAC"]="X";
	//Infra Changes - function origin array - ends
	fnSubScreenMain('STDCUSAC', 'STDCUSAC', screenName);

	return true;
}

function addOption(selectbox, value, text)
{
	var optn = document.createElement("OPTION");
	//optn.text = text;//9NT1462-ITR2-BUG 13500785
	setNodeText(optn,text);//9NT1462-ITR2-BUG 13500785
	optn.value = value;
	selectbox.options.add(optn);

	return true;
}

function removeAllOptions(selectbox)
{
	var i;
	for(i=selectbox.options.length-1;i>=0;i--)
	{
	selectbox.remove(i);
	}
}

//FC10.3 - SFR#1188 - Begins
function fnPostLoad_CVS_ACCLIMITS_KERNEL(screenArgs)
{
	/* The LOV Line ID in the screeen is made as a  select field..its elemtss are passed as a semicolun
	    seperated list on account class pickup ..
		here populating  list into LINEID field.. */
	var lineidlist=document.getElementsByName("LINEIDTSLIST")[0].value;
	var templineidtslist = lineidlist;
	var crline=getNodeText(selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/LINEID"));
	var lineid=document.getElementsByName("LINEID")[0];
	var l_elem ;
	var l_pos  = 1;
	var l_cnt  = 1;
	//showData();
	if(lineidlist != ""){
		while( l_pos > 0 )
		{
			l_pos = lineidlist.indexOf(';');
			l_elem = lineidlist.substr(0,l_pos);
			//if(crline != ""){
				//if (l_elem != crline){
					var optn = document.createElement("OPTION");
					//optn.text = l_elem;  //9NT1462-ITR2-BUG 13500785
					setNodeText(optn,l_elem);  //9NT1462-ITR2-BUG 13500785
					optn.value = l_elem;
					lineid.options.add(optn);
				//}
			//}
			lineidlist = lineidlist.substr(l_pos+1,lineidlist.length-l_elem.length);
		}
	}

	if(templineidtslist == ""){
		if(crline != ""){
			var optn = document.createElement("OPTION");
			//optn.text = crline;   //9NT1462-ITR2-BUG 13500785
			setNodeText(optn,crline);  //9NT1462-ITR2-BUG 13500785
			optn.value = crline;
			lineid.options.add(optn);
		}
	}

	lineid.value=crline;
	//document.getElementsByName("LINEID")[0].value = crline;
	appendData();

	return true;
}
//FC10.3 - SFR#1188 - Ends


//Kernel 11.0 - Casa - Minimum Account Opening Amount/Account Opening Charges  Start
//enabling/disabling the offset fields based on the pay in option
function fnPayInOption()
{
	for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
	{
		if (document.getElementsByName("PAY_IN_OPTION")[i].checked)
		PayInSelect = document.getElementsByName("PAY_IN_OPTION")[i].value;
	}

	if (PayInSelect == 'G')
	{
		fnDisableElement(document.getElementsByName("INF_OFFSET_BRANCH")[0]);
		fnDisableElement(document.getElementsByName("INF_OFFSET_ACCOUNT")[0]);
		document.getElementsByName("INF_OFFSET_BRANCH")[0].value = '';
		document.getElementsByName("INF_OFFSET_ACCOUNT")[0].value = '';
		document.getElementById("BLK_CUST_ACCOUNT__WAIVE_ACCOPEN_CHG").focus(); //9NT1501 ITR1 13959083
	}
	else
	{
		fnEnableElement(document.getElementsByName("INF_OFFSET_BRANCH")[0]);
		fnEnableElement(document.getElementsByName("INF_OFFSET_ACCOUNT")[0]);
		//FC11.0 ITR1 SFR#398 STARTS
		document.getElementsByName("INF_OFFSET_BRANCH")[0].value = '';
		document.getElementsByName("INF_OFFSET_ACCOUNT")[0].value = '';
		document.getElementById("BLK_CUST_ACCOUNT__INF_OFFSET_ACCOUNT").focus(); //9NT1501 ITR1 13959083
		//FC11.0 ITR1 SFR#398 ENDS
	}
}

//enabling/disabling initial funding fields based on the opening amount
function fnaccopenamt()
{
	// FC11.0 - ITR1 SFR-834 Starts
	if ((gAction == 'NEW') || (gAction == 'MODIFY'))
	{
	// FC11.0 - ITR1 SFR-834 Ends
		// FC11.0 - ITR1 SFR-873 Starts
		/*
		if (document.getElementsByName("ACC_OPENING_AMT")[0].value == '')
		{
			fnDisableElement(document.getElementsByName("INF_OFFSET_BRANCH")[0]);
			fnDisableElement(document.getElementsByName("INF_OFFSET_ACCOUNT")[0]);
			for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
				{
					document.getElementsByName("PAY_IN_OPTION")[i].checked = false;
					document.getElementsByName("PAY_IN_OPTION")[i].disabled = true;
				}
			document.getElementsByName("INF_OFFSET_BRANCH")[0].value = '';
			document.getElementsByName("INF_OFFSET_ACCOUNT")[0].value = '';
		}
		else
		{
			for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
			{
				document.getElementsByName("PAY_IN_OPTION")[i].disabled = false;
			}
		}
		*/
		if (document.getElementsByName("ACC_OPENING_AMT")[0].value > 0 )
			{
			for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
				{
					document.getElementsByName("PAY_IN_OPTION")[i].disabled = false;
					document.getElementsByName("PAY_IN_OPTION")[0].focus();	//9NT1501 ITR1 13959083
				}
			}
			else
			{
				fnDisableElement(document.getElementsByName("INF_OFFSET_BRANCH")[0]);
				fnDisableElement(document.getElementsByName("INF_OFFSET_ACCOUNT")[0]);
				for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
					{
						document.getElementsByName("PAY_IN_OPTION")[i].checked = false;
						document.getElementsByName("PAY_IN_OPTION")[i].disabled = true;
					}
				//9NT1525_Fcubs12.0_ABIBIF_14477378 start commented the below code
				//document.getElementsByName("INF_OFFSET_BRANCH")[0].value = '';
				//document.getElementsByName("INF_OFFSET_ACCOUNT")[0].value = '';
				//9NT1525_Fcubs12.0_ABIBIF_14477378 end
			}
			
		// FC11.0 - ITR1 SFR-873 Ends
	}	// FC11.0 - ITR1 SFR-834
}
//Kernel 11.0 - Casa - Minimum Account Opening Amount/Account Opening Charges End

function fnShowTimes()
{
   if ((gAction == 'NEW') || (gAction == 'MODIFY'))
   {
		   //if (document.getElementsByName('GEN_INTERIM_STMT')[0].checked == true)     -- FC11.1 - ITR1 SFR#2952 changes
		   if (document.getElementsByName('GENINTRMSTMT')[0].checked == true)

		   {
                                        //Infra Changes - function origin array - starts
                                        ArrFuncOrigin["STDCUSAC"]="KERNEL";
                                        ArrPrntFunc["STDCUSAC"]="";
                                        ArrPrntOrigin["STDCUSAC"]="";
                                        ArrRoutingType["STDCUSAC"]="X";
                                        //Infra Changes - function origin array - ends

					fnSubScreenMain('STDCUSAC', 'STDCUSAC', 'CVS_MSG_GEN_TIME');
		   }
		   else {
			 //alert("Please select Generate Message");
			 showErrorAlerts('IN-HEAR-412');//NLS change -Removal of hardcoded alerts
		   }
   }
   else
	{
             //Infra Changes - function origin array - starts
             ArrFuncOrigin["STDCUSAC"]="KERNEL";
             ArrPrntFunc["STDCUSAC"]="";
             ArrPrntOrigin["STDCUSAC"]="";
             ArrRoutingType["STDCUSAC"]="X";
            //Infra Changes - function origin array - ends

	    fnSubScreenMain('STDCUSAC', 'STDCUSAC', 'CVS_MSG_GEN_TIME');
	}

	return true;
}

function fnPreLoad_CVS_MSG_GEN_TIME_KERNEL(screenArgs)
{
	screenArgs['MESSAGE_TYPE'] 	= '942';

	return true;
}

function fnPostLoad_CVS_MSG_GEN_TIME_KERNEL(screenArgs)
{
	messageType = screenArgs['MESSAGE_TYPE'];

	return true;
}

function fnPostAddRow_BLK_REPORT_GENTIME1_KERNEL(newRow)
{
	var noOfRows = document.getElementById("BLK_REPORT_GENTIME1").tBodies[0].rows.length;
	newRow.cells[1].getElementsByTagName("INPUT")[0].value = messageType;
	newRow.cells[3].getElementsByTagName("INPUT")[0].value = noOfRows;

	return true;
}

function fnShowTimes1()
{
   if ((gAction == 'NEW') || (gAction == 'MODIFY'))
   {
		   //if (document.getElementsByName('GEN_INTERIM_STMT')[0].checked == true) --   FC11.1 - ITR1 SFR#2952 changes
		   //if (document.getElementsByName('GENINTRMSTMT')[0].checked == true) //9NT1606_12.1_BARCLAYS_UAE_21169265 change
		     if (document.getElementsByName('GENBALRPT')[0].checked == true) //9NT1606_12.1_BARCLAYS_UAE_21169265 change
		   {
                                        //Infra Changes - function origin array - starts
                                        ArrFuncOrigin["STDCUSAC"]="KERNEL";
                                        ArrPrntFunc["STDCUSAC"]="";
                                        ArrPrntOrigin["STDCUSAC"]="";
                                        ArrRoutingType["STDCUSAC"]="X";
                                        //Infra Changes - function origin array - ends
					fnSubScreenMain('STDCUSAC', 'STDCUSAC', 'CVS_MSG_GEN_TIME_2');
		   }
		   else {
			 //alert("Please select Generate Message");
			 //showErrorAlerts('IN-HEAR-412');//NLS change -Removal of hardcoded alerts //9NT1606_12.1_BARCLAYS_UAE_21169265 change
			showErrorAlerts('IN-HEAR-481');	
		   }
   }
   else
	{
             //Infra Changes - function origin array - starts
             ArrFuncOrigin["STDCUSAC"]="KERNEL";
             ArrPrntFunc["STDCUSAC"]="";
             ArrPrntOrigin["STDCUSAC"]="";
             ArrRoutingType["STDCUSAC"]="X";
            //Infra Changes - function origin array - ends
	    fnSubScreenMain('STDCUSAC', 'STDCUSAC', 'CVS_MSG_GEN_TIME_2');
	}

	return true;
}

function fnPreLoad_CVS_MSG_GEN_TIME_2_KERNEL(screenArgs)
{
	screenArgs['MESSAGE_TYPE'] 	= '941';

	return true;
}

function fnPostLoad_CVS_MSG_GEN_TIME_2_KERNEL(screenArgs)
{
	messageType = screenArgs['MESSAGE_TYPE'];

	return true;
}

function fnPostAddRow_BLK_REPORT_GENTIME2_KERNEL(newRow)
{
	var noOfRows = document.getElementById("BLK_REPORT_GENTIME2").tBodies[0].rows.length;
	newRow.cells[1].getElementsByTagName("INPUT")[0].value = messageType;
	newRow.cells[3].getElementsByTagName("INPUT")[0].value = noOfRows;

	return true;
}

function fnPostLoad_CVS_INTERIM_KERNEL(screenArgs)
{
	fnEnableElement(document.getElementsByName("BTN_TIMES")[0]);
	fnEnableElement(document.getElementsByName("BTN_TIMES1")[0]);
		return true;
}

function fnPreLoad_CVS_ACCSIG_KERNEL(screenArgs)
{
	screenArgs['funcId']	= 'STDCUSAC';
	screenArgs['BRN']       = document.getElementById("BLK_CUST_ACCOUNT__BRN").value;
	screenArgs['CCY']       = document.getElementById("BLK_CUST_ACCOUNT__CCY").value; //9NT1587_12.0.2_CIF_SIG_ENHANCEMENT
	screenArgs['ACC']       = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;
	screenArgs['CUSTNO']    = document.getElementById("BLK_CUST_ACCOUNT__CUSTNO").value;
	screenArgs['CUSTNAME']  = document.getElementById("BLK_CUST_ACCOUNT__CUSTNAME").value;
	screenArgs['ADESC'] 	= document.getElementById("BLK_CUST_ACCOUNT__ADESC").value;
	screenArgs['REPL_CUST_SIG'] = document.getElementById("BLK_CUST_ACCOUNT__REPL_CUST_SIG").checked;//SFR#1702 changes 12-may-2010
	screenArgs['JHCIF'] 	= document.getElementById("BLK_CUST_ACCOUNT__JHCIF").value; //9NT1587_12.0.2_CIF_SIG_ENHANCEMENT
	screenArgs['JHREL'] 	= document.getElementById("BLK_CUST_ACCOUNT__JHREL").value; //9NT1587_12.0.2_CIF_SIG_ENHANCEMENT
	           
	return true;
}
function fnPreLoad_CVS_DIARY_KERNEL(screenArgs)
{
	screenArgs['BRN']       = document.getElementById("BLK_CUST_ACCOUNT__BRN").value;
	screenArgs['ACC']       = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;

	return true;
}


//str10.5 sfr#554 - start
function fnPostAddRow_BLK_INTPRODMAP_KERNEL(newRow) {
	fnDisableElement(document.getElementById("BLK_INTPRODMAP__ILPRD"));
	return true; //9NT1606_12_2_RETRO_12_0_3_23658197  added
}
function fnPostDelRow_BLK_INTPRODMAP_KERNEL(newRow) {
fnDisableElement(document.getElementById("BLK_INTPRODMAP__ILPRD"));
	return true;//9NT1606_12_2_RETRO_12_0_3_23658197  added
}
//fcubs10.5str2, sfr428
function fnPostMovePrev_BLK_INTPRODMAP_KERNEL(newRow) {
fnDisableElement(document.getElementById("BLK_INTPRODMAP__ILPRD"));
	return true;//9NT1606_12_2_RETRO_12_0_3_23658197  added
}
function fnPostMoveNext_BLK_INTPRODMAP_KERNEL(newRow) {
fnDisableElement(document.getElementById("BLK_INTPRODMAP__ILPRD"));
	return true;//9NT1606_12_2_RETRO_12_0_3_23658197  added
}
//fcubs10.5str2, sfr428
//str10.5 sfr#554 - end

//Uncomment if required
/*function fnPostLoad_CVS_MAIN()
{

            //NOTE:
            //This function will be called when STDCUSAC is launched as a subscreen from another form.
            //The below specified Datasource and Relation details should be in sync with STDCUSAC's actual
            //Datasource and Relation.


  document.getElementById("STVWS_CUST_ACCOUNT__ACC").value = parent.screenArgs['ACC'];
  document.getElementById("STVWS_CUST_ACCOUNT__BRN").value = parent.screenArgs['BRN'];
  createDOM(dbStrRootTableName);

  gAction = "EXECUTEQUERY";
  var prevval = relationArray['STVWS_CUST_ACCOUNT'] = "";
relationArray['STVWS_PROVDETAILS'] = "STVWS_CUST_ACCOUNT~N";
relationArray['STVWS_AUTHBICDETAILS'] = "STVWS_CUST_ACCOUNT~N";
relationArray['STVWS_ACSTATUSLINES'] = "STVWS_CUST_ACCOUNT~N";
relationArray['STVWS_JOINTHOLDERS'] = "STVWS_CUST_ACCOUNT~N";
relationArray['STVWS_ACCMAINTINSTR'] = "STVWS_CUST_ACCOUNT~1";
relationArray['STVWS_ACCPRDRES'] = "STVWS_CUST_ACCOUNT~N";
relationArray['STVWS_ACCTXNRES'] = "STVWS_CUST_ACCOUNT~N";
relationArray['STVWS_ACCCRDRLMTS'] = "STVWS_CUST_ACCOUNT~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['ICVWS_CHGCONS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['SIVWS_DIARYDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['ICVWS_CHGCONS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['SIVWS_DIARYDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['ICVWS_CHGCONS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['SIVWS_DIARYDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['ICVWS_CHGCONS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['SIVWS_DIARYDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['ICVWS_CHGCONS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['SIVWS_DIARYDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['CSVWS_LINKEDENTITIES'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['MIVWS_MISDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~1";
relationArray['MIVWS_CHANGELOG'] = "MIVWS_MISDETAILS~N";
relationArray['MIVWS_BALTRANSFERLOG'] = "MIVWS_MISDETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['ICVWS_CHGDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['ICVWS_CHGSLABS'] = "ICVWS_CHGDETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['ICVWS_INTDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~1";
relationArray['ICVWS_INTPRODMAP'] = "ICVWS_INTDETAILS~N";
relationArray['ICVWS_INTEFFDTMAP'] = "ICVWS_INTPRODMAP~N";
relationArray['ICVWS_INTSDE'] = "ICVWS_INTEFFDTMAP~N";
relationArray['ICVWS_TDDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~1";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['UDVFS_UDFDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['ICVWS_AUTODEPDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~1";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['STVWS_BILLINGPREFMASTER'] = "STVWS_CUSTACCOUNT_DETAILS~1";
relationArray['STVWS_BILLINGPRODUCTS'] = "STVWS_BILLINGPREFMASTER~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['SVVWS_ACCSIGDETAILS'] = "STVWS_CUSTACCOUNT_DETAILS~1";
relationArray['SVVWS_SIGDETS'] = "SVVWS_ACCSIGDETAILS~N";
relationArray['STVWS_CUSTACCOUNT_DETAILS'] = "STVWS_CUST_ACCOUNT~1";
relationArray['STVWS_BILLINGPREFMASTER'] = "STVWS_CUSTACCOUNT_DETAILS~1";
relationArray['STVWS_BILLINGPRODUCTS'] = "STVWS_BILLINGPREFMASTER~N";

dataSrcLocationArray[0] = "STVWS_CUST_ACCOUNT";
dataSrcLocationArray[1] = "STVWS_PROVDETAILS";
dataSrcLocationArray[2] = "STVWS_AUTHBICDETAILS";
dataSrcLocationArray[3] = "STVWS_ACSTATUSLINES";
dataSrcLocationArray[4] = "STVWS_JOINTHOLDERS";
dataSrcLocationArray[5] = "STVWS_ACCMAINTINSTR";
dataSrcLocationArray[6] = "STVWS_ACCPRDRES";
dataSrcLocationArray[7] = "STVWS_ACCTXNRES";
dataSrcLocationArray[8] = "STVWS_ACCCRDRLMTS";
dataSrcLocationArray[9] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[10] = "ICVWS_CHGCONS";
dataSrcLocationArray[11] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[12] = "SIVWS_DIARYDETAILS";
dataSrcLocationArray[13] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[14] = "ICVWS_CHGCONS";
dataSrcLocationArray[15] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[16] = "SIVWS_DIARYDETAILS";
dataSrcLocationArray[17] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[18] = "ICVWS_CHGCONS";
dataSrcLocationArray[19] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[20] = "SIVWS_DIARYDETAILS";
dataSrcLocationArray[21] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[22] = "ICVWS_CHGCONS";
dataSrcLocationArray[23] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[24] = "SIVWS_DIARYDETAILS";
dataSrcLocationArray[25] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[26] = "ICVWS_CHGCONS";
dataSrcLocationArray[27] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[28] = "SIVWS_DIARYDETAILS";
dataSrcLocationArray[29] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[30] = "CSVWS_LINKEDENTITIES";
dataSrcLocationArray[31] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[32] = "MIVWS_MISDETAILS";
dataSrcLocationArray[33] = "MIVWS_CHANGELOG";
dataSrcLocationArray[34] = "MIVWS_BALTRANSFERLOG";
dataSrcLocationArray[35] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[36] = "ICVWS_CHGDETAILS";
dataSrcLocationArray[37] = "ICVWS_CHGSLABS";
dataSrcLocationArray[38] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[39] = "ICVWS_INTDETAILS";
dataSrcLocationArray[40] = "ICVWS_INTPRODMAP";
dataSrcLocationArray[41] = "ICVWS_INTEFFDTMAP";
dataSrcLocationArray[42] = "ICVWS_INTSDE";
dataSrcLocationArray[43] = "ICVWS_TDDETAILS";
dataSrcLocationArray[44] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[45] = "UDVFS_UDFDETAILS";
dataSrcLocationArray[46] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[47] = "ICVWS_AUTODEPDETAILS";
dataSrcLocationArray[48] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[49] = "STVWS_BILLINGPREFMASTER";
dataSrcLocationArray[50] = "STVWS_BILLINGPRODUCTS";
dataSrcLocationArray[51] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[52] = "SVVWS_ACCSIGDETAILS";
dataSrcLocationArray[53] = "SVVWS_SIGDETS";
dataSrcLocationArray[54] = "STVWS_CUSTACCOUNT_DETAILS";
dataSrcLocationArray[55] = "STVWS_BILLINGPREFMASTER";
dataSrcLocationArray[56] = "STVWS_BILLINGPRODUCTS";

  fcjRequestDOM = buildUBSXml();
  servletURL = "FCClientHandler";
  fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);

  if(fcjResponseDOM)
  {
    var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
    var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
    var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);

    if (msgStatus == 'SUCCESS')
    {
      setDataXML(getXMLString(pureXMLDOM));
      showData(dbStrRootTableName, 1);
    }
    else if (msgStatus == 'FAILURE')
    {
      var returnVal = displayResponse(messageNode);
    }
  }
  relationArray['STVWS_CUST_ACCOUNT'] = prevval;
  launchAsSubscreen = true;

  return true;
}*/


//Uncomment if required
/*//This function is added for EMERGE648
//the function will enable the vhek book freference details in the check
//check box is checked.
function fnEnableChkDetails(elm){
    if(gAction == 'MODIFY'){
        if(elm.checked == true){
            fnEnableElement(document.getElementById("STVWS_CUST_ACCOUNT__CHKNAME1"));
            fnEnableElement(document.getElementById("STVWS_CUST_ACCOUNT__CHKNAME2"));
            fnEnableElement(document.getElementById("STVWS_CUST_ACCOUNT__AUTOREORDERCHKREQ"));
            fnEnableElement(document.getElementById("STVWS_CUST_ACCOUNT__AUTOREORDERCHKLVL"));
            fnEnableElement(document.getElementById("STVWS_CUST_ACCOUNT__AUTOREORDERCHKLVS"));
        }else {
            fnDisableElement(document.getElementById("STVWS_CUST_ACCOUNT__CHKNAME1"));
            fnDisableElement(document.getElementById("STVWS_CUST_ACCOUNT__CHKNAME2"));
            fnDisableElement(document.getElementById("STVWS_CUST_ACCOUNT__AUTOREORDERCHKREQ"));
            fnDisableElement(document.getElementById("STVWS_CUST_ACCOUNT__AUTOREORDERCHKLVL"));
            fnDisableElement(document.getElementById("STVWS_CUST_ACCOUNT__AUTOREORDERCHKLVS"));
        }
    }
	return true;
}*/

//FC10.3 - ITR2 - SFR#5 - Begins
//**

//FC10.3 - ITR2 - SFR#5 - Ends
//Kernel 11.0 - Casa - Debit Card Functionality Changes starts

/* 9NT1462 ITR1 13247536 changes starts
function fnPreLoad_CVS_CARD_SUMMARY_KERNEL(screenArgs){
	if (document.getElementsByName("DIVFooter")[0].children[0].all[45].disabled)
	{
	return  false;
	}
	return true;
}*/
//Kernel 11.0 - Casa - Debit Card Functionality Changes ends

//FCUBS11.0 MULTIMODE CHANGES STARTS
function fnPreLoad_CVS_CARD_SUMMARY_KERNEL(screenArgs){
	screenArgs['BRN']=document.getElementById("BLK_CUST_ACCOUNT__BRN").value;
	screenArgs['CUSTNO']=document.getElementById("BLK_CUST_ACCOUNT__CUSTNO").value;
	/*if (document.getElementsByName("DIVFooter")[0].children[0].all[45].disabled)
	{
	return  false;
	} 9NT1462 ITR1 13247536 changes ends*/
	return true;
}
//Kernel 11.0 - Casa - Debit Card Functionality Changes ends

function fnCompute(){

	/*var meblkName = "BLK_TDPAYINDETAILS";
    var tableObject;
    var rowList;
    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

    var totalcompamt=0;
   // var tdamt = getCalcAmount(document.getElementById("BLK_TDDETAILS__TDAMT").value);
    var tdamt = document.getElementById("BLK_TDDETAILS__TDAMT").value;
    var rowamount = 0;
	var compamt = 0;
	var percentage;
	var totalPercentage = 0.00;

    if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {
			if (rowIndex == (rowList.length-1))
			{
				percentage = 100.00 -  floatingPointMultiplication(totalPercentage,1);
				compamt =   floatingPointMultiplication(tdamt,1) - floatingPointMultiplication(totalcompamt,1);  //code to handle floatpointsubration
				totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(compamt,1);
			}
		   else {
           // percentage = getCalcAmount(rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value);
		    percentage = rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value;
			rowamount = rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value;
		   if((rowamount != "" || rowamount != null) & 	(percentage == "" || percentage ==null))
			   {
				 totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(rowamount,1);
				 compamt = 	rowamount;
				 totalPercentage = floatingPointMultiplication(totalPercentage,1)  + floatingPointMultiplication(percentage,1) ;
			   }
           	else{
            totalPercentage = floatingPointMultiplication(totalPercentage,1) +  floatingPointMultiplication(percentage,1) ;
			compamt = (floatingPointMultiplication(percentage,tdamt))/ 100.00;
           	totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(compamt,1);
		   }

		}
		rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value = compamt;
		}
		document.getElementById("BLK_TDDETAILS__COMPTDAMT").value= totalcompamt;

	}
	/*
	var meblkName = "BLK_TDPAYOUTDETAILS";
    var tableObject;
    var rowList;
	var totalPercentage = 0.00;

    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

	 if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {
			if (rowIndex == (rowList.length-1))
			{
			percentage = 100.00 - totalPercentage;
			}
		   else {
			percentage = rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value;
            totalPercentage = totalPercentage + percentage;

		   }
			rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value = percentage;
		}

	}
	*/ //SFR 1024
	var g_prevAction = gAction;
	gAction = "COMPUTE";  
	appendData();
fcjRequestDOM = buildUBSXml(); 
  fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);

  if(fcjResponseDOM) 
  		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') 
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
		}
		else if (msgStatus == "WARNING" ||msgStatus == "SUCCESS" )       
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
			//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes starts
			if(functionId=='STDTDSIM')
	 {
		//fn_simulation_visibility("none");  9NT1587_12.0.2_SFR_NO:17020901 commenting
		document.getElementById("BLK_TDDETAILS__BTN_CLEAR").disabled=false;
		document.getElementById("BLK_TDDETAILS__BTN_VIEW_PRINT").disabled=false;
		document.getElementById("BLK_TDDETAILS__BTN_CREATE_DEP").disabled=false;

		 } 
	  	 //9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes ends	
}
		var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
		setDataXML(getXMLString(pureXMLDOM));
	    showData(dbStrRootTableName, 1);
		//Sfr No# 14017227   starts
		try 
	{
	   if (gSkipDeposit == 'true' ) 
		document.getElementById("BLK_PROCESS_AUDIT__WF_REF_NO").value =gWorkFlowRefNum; 
	}
	catch(e) 
	{}
		//Sfr No# 14017227   ends
		fnProcessResponse()//9NT1587 FC_DEV_12.0.2 VINU CHANGES
	gAction = g_prevAction; 
return true;
}

function fnPreLoad_CVS_TDPAYOUT_KERNEL(screenArgs)
{	
	//PNTFLX01011_FCUBS_12.1_ITR1_21513631 starts
	/*screenArgs['BRN']        = document.getElementById("BLK_TDDETAILS__BRN").value;
	screenArgs['ACC']        = document.getElementById("BLK_TDDETAILS__ACC").value;
	screenArgs['CCY']        = document.getElementById("BLK_TDDETAILS__CCY").value;
	screenArgs['CUSTNO']     = document.getElementById("BLK_INTDETAILS__CUSTNO").value;
	screenArgs['ACCLS']      = document.getElementById("BLK_INTDETAILS__ACCCLS").value;
	screenArgs['MATDT']      = document.getElementById("BLK_TDDETAILS__MATDT").value;*/
	screenArgs['BRN']        = document.getElementById("BLK_CUST_ACCOUNT__BRN").value;
    screenArgs['ACC']        = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;
    screenArgs['CCY']        = document.getElementById("BLK_CUST_ACCOUNT__CCY").value;
    var meblkName = "BLK_TDPAYOUTDETAILS";
    var tableObject;
    var rowList;
	var ddcnt = 0;
	var bccnt = 0;
	var instrtype = "";
    try
    {
        tableObject = document.getElementById(meblkName);
	    rowList = tableObject.tBodies[0].rows.length;
    } catch(e)
    {}
	
	for (var rowIndex = 0; rowIndex < rowList; rowIndex++)
        {
		if (document.getElementsByName("PAYOUTTYPE")[rowIndex].value == 'B')
		{
		bccnt = bccnt+1;
		}
        }
		if (bccnt > 1)
		{
		
		showErrorAlerts('BRN-VAL-003');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
		
		//alert('In multi mode term deposit payout,type Bankers Cheque Cannot be choosen more than once');
		return false;
		}
		else if (bccnt == 1)
		{
		    instrtype = 'BCA';
		}
	    screenArgs['INSTRTYPE']  = instrtype;
      //PNTFLX01011_FCUBS_12.1_ITR1_21513631 ends

    return true;
}
//FCUBS11.0 MULTIOMODE CHANGES ENDS

function fnPostLoad_KERNEL() {
 try{  // 9NT1606_12.0.3_RETRO_19052138 changes
	//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes starts
	if(functionId=='STDTDSIM')
	 {
		document.getElementById("EnterQuery").style.visibility="hidden";
		fn_simulation_visibility("none");
		document.getElementById("BLK_TDDETAILS__BTN_VIEW_PRINT").disabled=true;
		document.getElementById("BLK_TDDETAILS__BTN_CREATE_DEP").disabled=true;
		//9NT1587_ITR1_16975835 starts
		document.getElementById("cmdAddRow_BLK_INTEREST_PAYOUT").style.visibility="HIDDEN";
		document.getElementById("cmdDelRow_BLK_INTEREST_PAYOUT").style.visibility="HIDDEN";
		//9NT1587_ITR1_16975835 ends
	 }
	 //9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes ends
	//9NT1606_12.0.3_INTERNAL_19179661
	if(functionId=='STDCUSAC') {
		document.getElementById("BLK_CUST_ACCOUNT__ACCLSTYP").previousSibling.parentNode.style.display = "none"; //ACCLSTYP changes	
	}
	//9NT1606_12.0.3_INTERNAL_19179661
	//9NT1466 11.3.1 360 Degree Customer View Changes starts
	var parentWin = fnGetParentWin();
	//9NT1501 12.0 USABILITY CHANGES changes 
	document.getElementById('BLK_CUST_ACCOUNT__PAY_IN_OPTION').value='A';
	if (parentWin.parentWinParams.CALLFORM == 'STDACC' ) { 
	 if (parentWin != "") 
	  {	
	  fnEnterQuery();
	  document.getElementsByName('BRN')[0].value= parentWin.parentWinParams.BRANCH_CODE; 
	  document.getElementsByName('ACC')[0].value= parentWin.parentWinParams.CUST_AC_NO;
	  gAction= "EXECUTEQUERY";
	   fnExecuteQuery();
	   }
	   }
//12.0.3 Origination Changes Starts
       if (parent.screenArgs['PARENT_FUNC_ID'] == "ORDLPCAI")
	{
	fnEnterQuery();
	document.getElementById('BLK_CUST_ACCOUNT__ACC').value	= parent.screenArgs['ACCNUM'];
       gAction= "EXECUTEQUERY";
       fnExecuteQuery();
       }
//12.0.3 Origination Changes ends
	   if (parentWin.parentWinParams.CALLFORM !='STDACC' ){
	//9NT1466 11.3.1 360 Degree Customer View Changes ends
	
	//FCUBS11.2 9NT1428 document check list changes starts
	document.getElementById("cmdAddRow_BLK_DOCTYPE_CHECKLIST").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_DOCTYPE_CHECKLIST").style.visibility="HIDDEN";
	//FCUBS11.2 9NT1428 document check list changes ends
	}
	debugs("In fnPostLoad", "A");

	if (parent.screenArgs['PARENT_FUNC_ID'] == "STDBRREF")
	{
		fnPostLoad_CVS_MAIN_VIEWLOG();
    }
	}catch(e){} //9NT1606_12.0.3_RETRO_19052138
	//Bug_27606344 start
	if (parentWin == "") 
	{
	//Bug_27606344 end
		//PNTFLX01011_DEV_FCUBS_12.1_IQA_21247255 starts	
		if(typeof(mainWin.gCustInfo["CustNo"])!= 'undefined' && mainWin.gCustInfo["CustNo"]!='' && (/*functionId !='IADCUSAC' && 24344218 */functionId !='IADCUSTD') && (document.getElementById("BLK_CUST_ACCOUNT__ACC").value=='' && document.getElementById("BLK_CUST_ACCOUNT__BRN").value=='') && (document.getElementById("New").disabled != true)) //9NT1606_12.0.2_INTERNAL_20901151 checking disable condition for NEW action code  
		{
		  if((typeof(mainWin.gCustInfo["AccntNo"])== 'undefined' || mainWin.gCustInfo["AccntNo"]=='') && (typeof(mainWin.gCustInfo["Branch"])== 'undefined' || mainWin.gCustInfo["Branch"]==''))
		  {
			  gAction = "NEW"; 
			  fireHTMLEvent(document.getElementById("New").children[0], "onclick");
		  }
		}
	}//Bug_27606344
/*if((typeof(mainWin.gCustInfo["AccntNo"])!= 'undefined' && mainWin.gCustInfo["AccntNo"]!='') && (typeof(mainWin.gCustInfo["Branch"])!= 'undefined' && mainWin.gCustInfo["Branch"]!='' ) && (functionId !='IADCUSAC' && functionId !='IADCUSTD') && (document.getElementById("BLK_CUST_ACCOUNT__ACC").value=='' && document.getElementById("BLK_CUST_ACCOUNT__BRN").value==''))*/
if((typeof(mainWin.gCustInfo["AccntNo"])!= 'undefined' && mainWin.gCustInfo["AccntNo"]!='') && (typeof(mainWin.gCustInfo["Branch"])!= 'undefined' && mainWin.gCustInfo["Branch"]!='' ) && (/*functionId !='IADCUSAC' && 24344218 */ functionId !='IADCUSTD') && (document.getElementById("BLK_CUST_ACCOUNT__ACC").value=='' && document.getElementById("BLK_CUST_ACCOUNT__BRN").value=='') && ((mainWin.gCustInfo["FunctionId"]=='STDCUDTD')||(mainWin.gCustInfo["FunctionId"]=='STDCUDRD')||(mainWin.gCustInfo["FunctionId"]=='STDCUDEM')))
{
  gAction = "ENTERQUERY";
  fnEnterQuery(); 
  gAction = "EXECUTEQUERY"; 
  document.getElementById("BLK_CUST_ACCOUNT__ACC").value = mainWin.gCustInfo["AccntNo"];  
  document.getElementById("BLK_CUST_ACCOUNT__BRN").value = mainWin.gCustInfo["Branch"];
  fnExecuteQuery();
}
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21247255 ends
	return true;
}
//Surekha for 9NT1462 ITR1 SFR 13338632 starts
function fnPostLoad_Child_KERNEL(){

//PNTFLX01011: FCUBS12.1.0.0.0_Customer_Landing_Page Starts
if(typeof(mainWin.gCustInfo["AccntNo"])!= 'undefined' && mainWin.gCustInfo["AccntNo"]!='' && typeof(mainWin.gCustInfo["Branch"])!= 'undefined' && 	mainWin.gCustInfo["Branch"]!='' && (mainWin.gCustInfo["FunctionId"]=='STDCUDTD' || mainWin.gCustInfo["FunctionId"]=='STDCUDRD')){
	fnEnterQuery();
	gAction = "EXECUTEQUERY";  
	document.getElementById("BLK_CUST_ACCOUNT__ACC").value = mainWin.gCustInfo["AccntNo"];  
	document.getElementById("BLK_CUST_ACCOUNT__BRN").value = mainWin.gCustInfo["Branch"];
	fnExecuteQuery();
}
var parentWin = fnGetParentWin(); //Bug_27606344
//if((typeof(mainWin.gCustInfo["AccntNo"])== 'undefined' || mainWin.gCustInfo["AccntNo"]=='') && (typeof(mainWin.gCustInfo["Branch"])== 'undefined' || mainWin.gCustInfo["Branch"]=='') &&(typeof(mainWin.gCustInfo["CustNo"])!='undefined' && mainWin.gCustInfo["CustNo"]!='') && ShowSummary =='FALSE' && parentWin.functionId != 'undefined' && parentWin.functionId != '' && (parentWin.functionId != 'STDRETVW' && parentWin.functionId != 'STDCUSVW')){	//Bug_30075735 Commented
  if(parentWin.functionId != undefined &&(typeof(mainWin.gCustInfo["AccntNo"])== 'undefined' || mainWin.gCustInfo["AccntNo"]=='') && (typeof(mainWin.gCustInfo["Branch"])== 'undefined' || mainWin.gCustInfo["Branch"]=='') &&(typeof(mainWin.gCustInfo["CustNo"])!='undefined' && mainWin.gCustInfo["CustNo"]!='') && ShowSummary =='FALSE' && parentWin.functionId != 'undefined' && parentWin.functionId != '' && (parentWin.functionId != 'STDRETVW' && parentWin.functionId != 'STDCUSVW')){ //Bug_30075735 Added
	gAction = "NEW"; 
	fireHTMLEvent(document.getElementById("New").children[0], "onclick");
	document.getElementById("BLK_CUST_ACCOUNT__CUST_NO").value = mainWin.gCustInfo["CustNo"];  
 }
//PNTFLX01011: FCUBS12.1.0.0.0_Customer_Landing_Page Ends
	//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes starts
	if(functionId=='STDTDSIM')
	 {
		
		fn_simulation_visibility("none");

	 }
	 //9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes ends//debugger;
	//var parentWin = fnGetParentWin(); //Bug_27606344 commented and moved up
	if(parentWin.parentWinParams.PARENT_FUNC_ID == 'ACDCBIRD')
      {
	  var parentWin = fnGetParentWin();
	if (parentWin.parentWinParams['DFLT_QRY'] ==  "Y" ) {
	fnEnterQuery(); //9NT1525_12.0_RETRO_CBACNY_14756024 
      document.getElementById("BLK_CUST_ACCOUNT__BRN").value = mainWin.CurrentBranch; 
      document.getElementById("BLK_CUST_ACCOUNT__ACC").value = parentWin.parentWinParams.ACC;
	  			   gFromSummary = false;
			   gAction = "EXECUTEQUERY";			   
			   fnExecuteQuery();
		//9NT1525_12.0_CBACNY_14492986 start
		var pureXMLDOM = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
			setDataXML(getXMLString(pureXMLDOM));
			showData(dbStrRootTableName, 1);
			resetIndex();
			showAllData();
		//9NT1525_12.0_CBACNY_14492986 end
      }
	  }
	  
	var parentWin = fnGetParentWin();
	if (parentWin.parentWinParams.CALLFORM =='STDTD' ) { 
	 if (parentWin != "") 
	  {	
	  fnEnterQuery();
	  document.getElementById("BLK_CUST_ACCOUNT__BRN").value = parentWin.parentWinParams.BRANCH_CODE; 
	  document.getElementById("BLK_CUST_ACCOUNT__ACC").value = parentWin.parentWinParams.CUST_AC_NO;
	  gAction= "EXECUTEQUERY";
	   fnExecuteQuery();
	   }
	   }
	  var parentWin = fnGetParentWin();
	  if (parentWin.parentWinParams.CALLFORM =='DEPALERT'){
	  if (parentWin != "") 
	  {	
	  fnEnterQuery();
	  document.getElementById("BLK_CUST_ACCOUNT__BRN").value = parentWin.parentWinParams.BRANCH; 
	  document.getElementById("BLK_CUST_ACCOUNT__ACC").value = parentWin.parentWinParams.DEP_REF_NO; 
	  gAction= "EXECUTEQUERY";
	   fnExecuteQuery();
	   }
	   }
     var parentWin = fnGetParentWin();	   
	   if (parentWin.parentWinParams.CALLFORM =='IASTDTD' ) { 
	//9NT1462 FIX BY NIRANJANA
	 if (parentWin != "") 
	  {	
	  fnEnterQuery();
	  document.getElementById("BLK_CUST_ACCOUNT__BRN").value = parentWin.parentWinParams.BRANCH_CODE; 
	  document.getElementById("BLK_CUST_ACCOUNT__ACC").value = parentWin.parentWinParams.CUST_AC_NO;
	  gAction= "EXECUTEQUERY";
	   fnExecuteQuery();
	   }
	   }
	   var parentWin = fnGetParentWin();
	if (parentWin.parentWinParams.CALLFORM == 'STDACC' ) { 
	 if (parentWin != "") 
	  {	
	  fnEnterQuery();
	  document.getElementsByName('BRN')[0].value= parentWin.parentWinParams.BRANCH_CODE; 
	  document.getElementsByName('ACC')[0].value= parentWin.parentWinParams.CUST_AC_NO;
	  gAction= "EXECUTEQUERY";
	   fnExecuteQuery();
	   }
	   }
    fn_button();
	return true;
	
}
//Surekha for 9NT1462 ITR1 SFR 13338632 ends
function fnPostLoad_CVS_MAIN_VIEWLOG() {

	 var codes = new Array();

	 createDOM(dbStrRootTableName);

	 codes = parent.screenArgs['KEY'].split("|");

	 if (codes.length > 0)
	 {
		  document.getElementsByName("BRN")[0].value = codes[0];
		  document.getElementsByName("ACC")[0].value = codes[1];
	 }
	  document.getElementsByName("MODNO")[0].value = parent.screenArgs['MOD_NO'];

	  gAction = 'VIEWMNTLOG';
	  functionId = 'STDCUSAC' ;

	var relationArray = new Array();
	relationArray['BLK_CUST_ACCOUNT'] = "";
	relationArray['BLK_PROVISION_MAIN'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_PROVDETAILS'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_REPORT_GENTIME1'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_REPORT_GENTIME2'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_ACCMAINTINSTR'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_ACCOUNT_GENERATION'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_INTERIM_DETAILS'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_PRDTXN'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_ACCPRDRES'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_ACCTXNRES'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_AUTHBICDETAILS_MAIN'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_AUTHBICDETAILS'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_ACCSTATUS_MAIN'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_ACSTATUSLINES'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_JOINTHOLDERS_MAIN'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_JOINTHOLDERS'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_ACCCRDRLMTS_MAIN'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_ACCCRDRLMTS'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_INTDETAILS'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_INTPRODMAP'] = "BLK_INTDETAILS~N";
	relationArray['BLK_INTEFFDTMAP'] = "BLK_INTPRODMAP~N";
	relationArray['BLK_INTSDE'] = "BLK_INTEFFDTMAP~N";
	relationArray['BLK_TDDETAILS'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_STATEMENT'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_AMOUNT_DATES'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_TURNOVERS'] = "BLK_AMOUNT_DATES~1";
	relationArray['BLK_NOTICEPREF'] = "BLK_CUST_ACCOUNT~1";
	relationArray['BLK_ACC_NOMINEES'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_DCDMASTER'] = "BLK_TDDETAILS~1";
	relationArray['BLK_TDPAYINDETAILS'] = "BLK_CUST_ACCOUNT~N";
	relationArray['BLK_TDPAYOUTDETAILS'] = "BLK_CUST_ACCOUNT~N";

	var dataSrcLocationArray = new Array();
	dataSrcLocationArray[0] = "BLK_CUST_ACCOUNT";
	dataSrcLocationArray[1] = "BLK_PROVISION_MAIN";
	dataSrcLocationArray[2] = "BLK_PROVDETAILS";
	dataSrcLocationArray[3] = "BLK_REPORT_GENTIME1";
	dataSrcLocationArray[4] = "BLK_REPORT_GENTIME2";
	dataSrcLocationArray[5] = "BLK_ACCMAINTINSTR";
	dataSrcLocationArray[6] = "BLK_ACCOUNT_GENERATION";
	dataSrcLocationArray[7] = "BLK_INTERIM_DETAILS";
	dataSrcLocationArray[8] = "BLK_PRDTXN";
	dataSrcLocationArray[9] = "BLK_ACCPRDRES";
	dataSrcLocationArray[10] = "BLK_ACCTXNRES";
	dataSrcLocationArray[11] = "BLK_AUTHBICDETAILS_MAIN";
	dataSrcLocationArray[12] = "BLK_AUTHBICDETAILS";
	dataSrcLocationArray[13] = "BLK_ACCSTATUS_MAIN";
	dataSrcLocationArray[14] = "BLK_ACSTATUSLINES";
	dataSrcLocationArray[15] = "BLK_JOINTHOLDERS_MAIN";
	dataSrcLocationArray[16] = "BLK_JOINTHOLDERS";
	dataSrcLocationArray[17] = "BLK_ACCCRDRLMTS_MAIN";
	dataSrcLocationArray[18] = "BLK_ACCCRDRLMTS";
	dataSrcLocationArray[19] = "BLK_INTDETAILS";
	dataSrcLocationArray[20] = "BLK_INTPRODMAP";
	dataSrcLocationArray[21] = "BLK_INTEFFDTMAP";
	dataSrcLocationArray[22] = "BLK_INTSDE";
	dataSrcLocationArray[23] = "BLK_TDDETAILS";
	dataSrcLocationArray[24] = "BLK_STATEMENT";
	dataSrcLocationArray[25] = "BLK_AMOUNT_DATES";
	dataSrcLocationArray[26] = "BLK_TURNOVERS";
	dataSrcLocationArray[27] = "BLK_NOTICEPREF";
	dataSrcLocationArray[28] = "BLK_ACC_NOMINEES";
	dataSrcLocationArray[29] = "BLK_DCDMASTER";
	dataSrcLocationArray[30] = "BLK_TDPAYINDETAILS";
	dataSrcLocationArray[31] = "BLK_TDPAYOUTDETAILS";

	//appendData(document.getElementById("TBLPageAll"));
	appendTextFieldValue(document.getElementsByName('BRN')[0], 1, '"BLK_CUST_ACCOUNT');
	appendTextFieldValue(document.getElementsByName('ACC')[0], 1, '"BLK_CUST_ACCOUNT');
	appendTextFieldValue(document.getElementsByName('MODNO')[0], 1, '');

	//  dbFCJDOM.loadXML(dbDataDOM.xml);
	fcjRequestDOM = buildUBSXml();

	// Post the XML to Server
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);

	if(fcjResponseDOM) {
		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));

		if (msgStatus == 'FAILURE') {
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
		    var returnVal = displayResponse(messageNode);
	    }

		if(msgStatus == 'SUCCESS') {
			var authResDom = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
			setDataXML(getXMLString(authResDom));
			mainWin.Authdom = null;
			resetIndex();
			//showTabData_Viewchg();
			viewMnt = true;
			showData();
	        gAction = "";
		}
	disableForm();
  }
}
//OFAC Black List Check FC 11.1 Starts
function fnPreLoad_CVS_OFACM_KERNEL(screenArgs){

	screenArgs['REQXML']='';//Prepare the request xml in the format of OFAC accepeted Requested xml and pass as
	// screen argument to CSCOFACM

return true; 
}
//OFAC Black List Check FC 11.1 Ends

/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/

function fnAccProcessSuccess(){
    //customAlertAction = "ACCPROESSS_SUCCESS";
	l_ac_no =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACC"))
	parent.document.getElementById("BLK_CUST_ACCOUNT__ACC").value = l_ac_no;
	parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ALTACC"))
	parent.document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/CLRACNO")) //9NT1606_12_2_RETRO_12_0_2_25160035 added
	//FC10.3 SFR#224 ends
	if (parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value == ''
	||parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value == 'DUMMY'){ //9NT1606_12_2_RETRO_12_0_2_25160035 added
		parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value = l_ac_no;
	}
	//9NT1606_12.0.3_ASKARI-RETRO-18731408 - Start	
	//PNTFLX01011_12.1_ITR2_21776031 changes starts
	//if (parent.document.getElementById("BLK_CUST_ACCOUNT__ALTACC").value == '' ||
	if (parent.document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value == '' ||
	//PNTFLX01011_12.1_ITR2_21776031 changes starts
		parent.document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value == 'DUMMY'){
		parent.document.getElementById("BLK_CUST_ACCOUNT__CLRACNO").value = l_ac_no;
	}
	//9NT1606_12.0.3_ASKARI-RETRO-18731408 - End
     gAction = gPreActionAccount;
   //  parent.fnCloseSubScr(evnt);
     //parent.fnExitSubScreen(parentScrID, launcherDIVWidth, launcherIFWidth, launcherDIVHeight, launcherIFHeight, launcherResTreeWidth, launcherResTreeHeight, launcherHeaderWidth, launcherLeft);//12.0.3_IRONVBR_19217026
     return true;//9NT1606_12.0.3_IRONVBR_19217026
}
function fnCloseAlertWin_ACCPROESSS_FAILURE(evnt){
    parent.fnCloseSubScr(evnt);
    parent.fnExitSubScreen(parentScrID, launcherDIVWidth, launcherIFWidth, launcherDIVHeight, launcherIFHeight, launcherResTreeWidth, launcherResTreeHeight, launcherHeaderWidth, launcherLeft);

}
/* FC11.1 - ITR1 SFR#4268 Changes for prompting error msg while doing account population*/


//added for fcubs11.1,sfr#5484,itr-1 starts
function getSubsysstr1(subsys)
{
  var subsysstr = parent.document.getElementById('BLK_CUST_ACCOUNT__SUBSYSTEMSTAT').value;
  gSubsysStat = subsysstr;
  var SUBSYSTEMSTAT = getCurrentSUBSYSTEMSTAT(subsysstr, subsys);
        if (SUBSYSTEMSTAT != 'D'){
          subsysstr = getNewSubsysstat1(subsysstr, subsys);
         // document.getElementById('BLK_CUST_ACCOUNT__SUBSYSTEMSTAT').value = subsysstr;
        }
  return subsysstr;
}



function getNewSubsysstat1(initStr, subsys)
{
    var stat;
    var start;
    var finalstr;
    start = initStr.indexOf(subsys + ':');
	if (start == -1)
    {
        return initStr;
    }
    stat = initStr.substr(start + subsys.length + 1, 1);
    var str1 = subsys+':'+stat;
    var str2 = subsys+':'+'D';
    finalstr = initStr.replace(str1, str2);

	return finalstr;
}

function fnPreExit_KERNEL() {

	//To set the original SUBSYSTEMSTAT
if (gscrname != 'undefined' && gscrname=='CVS_INTEREST')
{

parent.document.getElementById("BLK_CUST_ACCOUNT__SUBSYSTEMSTAT").value  = getSubsysstr1('INTDETAILS');

}
return true;
}
//added for fcubs11.1,sfr#5484,itr-1 ends
//Edwin Added for Kernel11.2 Starts
function fnPreDetailScreen_KERNEL()
{
var iRowIndex=getRowIndex();
var txnBranch=document.getElementById("TBL_QryRslts").tBodies[0].rows[iRowIndex-1].cells[18].innerText;
sumTxnBranch = txnBranch;
return true;
}
/*function fnPostLoad_Summary_KERNEL()
{
     document.getElementsByName("BRANCH")[0].value= dlgArg.mainWin.frames['Global'].CurrentBranch;
    fnDisableElement(document.getElementsByName("BRANCH"));
}	   */
//Edwin Added for Kernel11.2  Ends



//FCUBS11.2 ITR1 SFR#408 Starts
//Sequence no was going null in linkages tab

function fnPostAddRow_BLK_OD_LIMIT_KERNEL()
{
   var rowcount = document.getElementById("BLK_OD_LIMIT").tBodies[0].rows;
   var rows = rowcount.length;
   var l_currPage= parseInt(getInnerText(document.getElementById("CurrPage__BLK_OD_LIMIT")));
   var l_pageSize= parseInt(document.getElementById("BLK_OD_LIMIT").getAttribute("pgsize"));
   if(l_currPage>1){ 
       rows = l_pageSize*(l_currPage-1)+rows;
   }
   var rowNum = document.getElementById("BLK_OD_LIMIT").tBodies[0].rows.length - 1;
   document.getElementById("BLK_OD_LIMIT").tBodies[0].rows[rowNum].cells[9].getElementsByTagName("INPUT")[0].value = rows;
   fireHTMLEvent(document.getElementById("BLK_OD_LIMIT").tBodies[0].rows[rowNum].cells[9].getElementsByTagName("INPUT")[0], "onpropertychange");
     return true;
}

//9NT1606_12.0.3_RETRO_19125491 starts
function fnPostLoad_CVS_ACCSTATUSLINES_KERNEL(screenArgs)
{
    fnDisableElement(document.getElementById("BLK_ACSTATUSLINES__ACSTATUS"));
    return true;
}
//9NT1606_12.0.3_RETRO_19125491 ends

function fnPostDeleteRow_BLK_OD_LIMIT_KERNEL()
{

	var rowcount = document.getElementById("BLK_OD_LIMIT").tBodies[0].rows;
	var rows = rowcount.length;
	var l_currPage= parseInt(getInnerText(document.getElementById("CurrPage__BLK_OD_LIMIT")));
	var l_pageSize= parseInt(document.getElementById("BLK_OD_LIMIT").getAttribute("pgsize"));
	if(l_currPage>1){
       rows = l_pageSize*(l_currPage-1)+rows;
	}
	var rowNum = document.getElementById("BLK_OD_LIMIT").tBodies[0].rows.length - 1;

	for(var i=1;i <= rows ; i++ ){
		document.getElementById("BLK_OD_LIMIT").tBodies[0].rows[i-1].cells[9].getElementsByTagName("INPUT")[0].value = i;
	}
	fireHTMLEvent(document.getElementById("BLK_OD_LIMIT").tBodies[0].rows[rowNum].cells[9].getElementsByTagName("INPUT")[0], "onpropertychange");
    return true;

}

//FCUBS11.2 ITR1 SFR#408 Ends

// --Rosy changes starts FCUBS 11.3.1 Chqbk and Card Request
//Cheque book request screen can be launch only if auto cheque book request is selected
function fnPreLoad_CVS_CHQBKREQ_KERNEL(screenArgs){
	var CHQBOOKREQT = document.getElementById("BLK_CUST_ACCOUNT__CHECK_BOOK_REQUEST").checked;
	if(CHQBOOKREQT == false && gAction != "")
	{
		showErrorAlerts('ST-CIF-AC02'); // 9NT1466 CIF-CASA_11.3.1 IUT changes on 9/8/2011
	return false;
	}
	else
		screenArgs['BRN'] = document.getElementById('BLK_CUST_ACCOUNT__BRN').value; //9NT1466 CIF-CASA_11.3.1 IUT changes on 9/8/2011
		screenArgs['CHQBOOKREQ'] = document.getElementById("BLK_CUST_ACCOUNT__CHECK_BOOK_REQUEST").checked;
		screenArgs['CUST_AC_NO'] = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;
	return true;
}
//defaulting the value : branch code and customer account number
function fnPostLoad_CVS_CHQBKREQ_KERNEL(screenArgs){
	if(screenArgs['CHQBOOKREQ']) {
		if ((gAction == 'NEW') || (gAction == 'DEFAULT') || (gAction == 'MODIFY')){
		enableForm();
		document.getElementById("BLK_CUST_ACC_CHECK__BRANCH_CODE").value = screenArgs['BRN']; //9NT1466 CIF-CASA_11.3.1 IUT changes on 9/8/2011
		document.getElementById("BLK_CUST_ACC_CHECK__CUST_ACC_NO").value = screenArgs['CUST_AC_NO'];
		if (document.getElementById("BLK_CUST_ACC_CHECK__ORDER_DATE").value == "" ){
		document.getElementById("BLK_CUST_ACC_CHECK__ORDER_DATE").value = mainWin.AppDate;
                document.getElementById("BLK_CUST_ACC_CHECK__ORDER_DATEI").value = mainWin.AppDate; //FCUBS_12.2_SUPPORT_24813532 added
		}
		} 	
		else {
		disableForm();
		}
	}
	//9NT1606_12.0.2_INTERNAL_RETRO_17600251 changes starts
	g_prev_gAction = gAction;
	gAction='ALWEUCOMM';
	appendData();
	fcjRequestDOM = buildUBSXml();
	servletURL = "FCClientHandler";
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	showProcessMsg = false;
	 if(fcjResponseDOM) 
  		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') 
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
		}
		else if (msgStatus == "WARNING" ||msgStatus == "SUCCESS" )       
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
		} 
		var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
		setDataXML(getXMLString(pureXMLDOM));
	    //showData(dbStrRootTableName, 1);
		
        try 
	{
	   if (gSkipDeposit == 'true' ) 
		document.getElementById("BLK_PROCESS_AUDIT__WF_REF_NO").value =gWorkFlowRefNum; 
	}
	catch(e) 
	{}
	gAction=g_prev_gAction;
	var l_alw_eu_or_comm = getNodeText(selectSingleNode(dbDataDOM,"//BLK_CUST_ACC_CHECK/ALW_EU_OR_COMM"));//getNodeText(selectSingleNode(fnGetDataXMLFromFCJXML(fcjResponseDOM, 1), "//BLK_CUST_ACC_CHECK"));
	if (l_alw_eu_or_comm == 'Y')
	{
	    document.getElementById("BLK_CUST_ACC_CHECK__ALW_EU_OR_COMM").checked = true;
	    fnEnableElement(document.getElementById("BLK_CUST_ACC_CHECK__CHQ_TYPE2"));
	    fnEnableElement(document.getElementsByName("CHQ_TYPE")[0]);
		}
    else 
	 {
	    document.getElementById("BLK_CUST_ACC_CHECK__ALW_EU_OR_COMM").checked =false;
        document.getElementById("BLK_CUST_ACC_CHECK__CHQ_TYPE2").checked = false;
		fnDisableElement(document.getElementById("BLK_CUST_ACC_CHECK__CHQ_TYPE2"));
	    fnDisableElement(document.getElementsByName("CHQ_TYPE")[0]);
	 }
    //9NT1606_12.0.2_INTERNAL_RETRO_17600251 changes ends
	return true;
}
//Card request screen can be launch only if auto auto debit card request is selected
function fnPreLoad_CVS_CARDREQ_KERNEL(screenArgs){
	var CARDREQT = document.getElementById("BLK_CUST_ACCOUNT__DEBIT_CARD_REQUEST").checked;
	if(CARDREQT == false && gAction != "")
	{
		showErrorAlerts('ST-CIF-AC01'); //9NT1466 CIF-CASA_11.3.1 IUT changes on 9/8/2011
		return false;
	}
	else
		screenArgs['BRN'] = document.getElementById('BLK_CUST_ACCOUNT__BRN').value;
		screenArgs['CARDREQ'] = document.getElementById("BLK_CUST_ACCOUNT__DEBIT_CARD_REQUEST").checked;
		screenArgs['CUST_AC_NO'] = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;
		screenArgs['CUST_NO'] = document.getElementById("BLK_CUST_ACCOUNT__CUSTNO").value;
	return true;
}
//defaulting the value : barnch code,customer account number,customer number,card status
function fnPostLoad_CVS_CARDREQ_KERNEL(screenArgs){

	if(screenArgs['CARDREQ']) {
		if ((gAction == 'NEW') || (gAction == 'DEFAULT') || (gAction == 'MODIFY')){
			enableForm();
			document.getElementById("BLK_CUST_ACC_CARD__BRANCH_CODE").value = screenArgs['BRN']; //9NT1466 CIF-CASA_11.3.1 IUT changes on 9/8/2011
			document.getElementById("BLK_CUST_ACC_CARD__CUST_AC_NO").value = screenArgs['CUST_AC_NO'];
			document.getElementById("BLK_CUST_ACC_CARD__CUST_NO").value = screenArgs['CUST_NO'];
			document.getElementById("BLK_CUST_ACC_CARD__CARD_STATUS").value = "R";
			//9NT1462 ITR 13091461 changes starts
			var refno = document.getElementById("BLK_CUST_ACC_CARD__REQUEST_REFERENCE_NO").value
			if (refno)
			{
				var dfltButton  = document.getElementsByName("BTN_DEFAULT")[0];
				var prod = document.getElementsByName("CARD_PRODUCT")[0];
				var bin = document.getElementsByName("CARD_BIN")[0];
				fnDisableElement(dfltButton);
				fnDisableElement(prod);
				fnDisableElement(bin);
			}
			//9NT1462 ITR 13091461 changes ends
		} 
		else {
			disableForm();
		}
	}
	return true;
}
//enabling/disabling the DEBIT_CARD_REQUEST field based on the atmfacility
function fnAtmCheck() {
	if ((gAction == 'NEW') || (gAction == 'MODIFY')) {
		var atmfaclty = document.getElementById("BLK_CUST_ACCOUNT__ATM").checked;
		var debitcard = document.getElementById("BLK_CUST_ACCOUNT__DEBIT_CARD_REQUEST").checked;
		if (atmfaclty == false && debitcard == true && gAction != "")
		{
			showErrorAlerts('ST-CIF-AC05'); //9NT1466 CIF-CASA_11.3.1 IUT changes on 9/8/2011
			document.getElementById("BLK_CUST_ACCOUNT__DEBIT_CARD_REQUEST").checked = false;
			return false;
		}
	} 
    return true; //9NT1606_12_2_RETRO_12_0_3_23655031 added
}
//enabling/disabling the CHECK_BOOK_REQUEST field based on the chequefacility
function fnChequeBookCheck(){
	if ((gAction == 'NEW') || (gAction == 'MODIFY')){
		var chequebkfac = document.getElementById("BLK_CUST_ACCOUNT__CHQBOOK").checked;
		var Autochk = document.getElementById("BLK_CUST_ACCOUNT__CHECK_BOOK_REQUEST").checked;
		if (chequebkfac == false && Autochk == true && gAction != "")
		{
			showErrorAlerts('ST-CIF-AC04'); // 9NT1466 CIF-CASA_11.3.1 IUT changes on 9/8/2011
			document.getElementById("BLK_CUST_ACCOUNT__CHECK_BOOK_REQUEST").checked = false;
			return false;
		}
	}
} 
//defaulting the request reference number for card request
function fnDefault_Ref_No()
{   
	if (document.getElementsByName("CARD_PRODUCT")[0].value !='')
	{		 
		g_prev_gAction = gAction;	
		if (gAction =="NEW")
		{ 
			gAction = "MOD_DEFAULT";
		}
		document.getElementById("BLK_CUST_ACC_CARD__BRANCH_CODE").disabled = false;
		fncrdDefault();	  
		flag=0;
		gAction = g_prev_gAction;
		var dfltButton  = document.getElementsByName("BTN_DEFAULT")[0];
		fnDisableElement(dfltButton);

	}	
	else
	{
	//alert('Card Product cannot be null');
	showErrorAlerts('CO-VALS-004');  // NLS_11.4
	}
}
function fncrdDefault()
{   
  appendData(document.getElementById('TBLPageAll'));
  fcjRequestDOM = buildUBSXml(); 
  fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
  if(fcjResponseDOM) 
  {
       var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
      if (msgStatus == 'FAILURE') 
      {
      	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
      }
      else if (msgStatus == "WARNING" ||msgStatus == "SUCCESS" )       
      {     
      	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");     
      } 
        
     var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
     setDataXML(getXMLString(pureXMLDOM));
     showData(dbStrRootTableName, 1); 
 }  
 if(msgStatus == 'FAILURE')
  {
      var returnVal = displayResponse(messageNode);
  }

  if (msgStatus == "SUCCESS" )  
  {
	document.getElementsByName("CARD_PRODUCT")[0].disabled = true;
	document.getElementsByName("CARD_BIN")[0].disabled = true; //9NT1462 ITR 13091461 changes
	document.getElementsByName("BRANCH_CODE")[0].disabled = true;
	document.getElementsByName("CUST_NO")[0].disabled = true;
	document.getElementsByName("CUST_AC_NO")[0].disabled = true;
	document.getElementsByName("REQUEST_REFERENCE_NO")[0].disabled = true;
	document.getElementsByName("PRIMARY_CARD")[0].disabled = true;       	
  }
}
// --Rosy changes Ends FCUBS 11.3.1 Chqbk and Card Request

function fnPreSave_CVS_ACCLIMITS_KERNEL() {
	// FCUBS11.3.1 IUT SFR #607 start - null value in releated currency field of amount field throws error.
	if (!(document.getElementById('BLK_CUST_ACCOUNT__LMTCCY').value)) {
		var empty = '';
		try {
			document.getElementById('BLK_CUST_ACCOUNT__SUBLIMITI').value = empty;
			document.getElementById('BLK_CUST_ACCOUNT__UNCOLFUNDLIMITI').value = empty;
			document.getElementById('BLK_CUST_ACCOUNT__TODLIMITI').value = empty;
			document.getElementById('BLK_CUST_ACCOUNT__CRTXNLMTI').value = empty;
		} catch(e) {}
		document.getElementById('BLK_CUST_ACCOUNT__SUBLIMIT').value = empty;
		document.getElementById('BLK_CUST_ACCOUNT__UNCOLFUNDLIMIT').value = empty;
		document.getElementById('BLK_CUST_ACCOUNT__TODLIMIT').value = empty;
		document.getElementById('BLK_CUST_ACCOUNT__CRTXNLMT').value = empty;
	}
	// FCUBS11.3.1 IUT SFR #607 end
	return true;
}  
//9NT1462 Standard Documents Starts
//for checking no of selected rows
function Fn_ValidateCheckbox () {
//9NT1462-ITR1 -BUG 13090383 Starts
/*	var chkBoxList = document.getElementsByName('chkDeleteRow');
	var cntSelected = 0;
	for(i = 0; i < chkBoxList.length; i++) {
		if(chkBoxList[i].checked) {
			cntSelected++;
		}
	}
*/
	var tableRef =document.getElementById("BLK_DOCTYPE_CHECKLIST");
	var rowRef = tableRef.tBodies[0].rows;
	var totalRows = rowRef.length;
	var cntSelected =0;	
	for( i=0 ; i < totalRows ; i++ ) 
	{	   
		if(rowRef[i].cells[0].getElementsByTagName("INPUT")[0].checked){
	//9NT1462-ITR1 -BUG 13090383 Ends
			cntSelected++;
		}
	}
	if (cntSelected < 1) {
		//alert("No Rows Selected");
		showErrorAlerts('IA-VAL-01');  // NLS_11.4
	} else if (cntSelected > 1) {
		//alert("Multiple Rows selected");
		showErrorAlerts('IA-VAL-02');  // NLS_11.4
	} else {
		return true;
	}
	return false;
}
//for uploading documents	
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes starts
//function fn_upload()
function fn_upload(event)
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes ends
{  
   if (Fn_ValidateCheckbox()) {
       //PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes starts
        //var rowIndex = Fn_GetCheckboxRowIndex();//getRowIndex();	//9NT1462 Standard Documents -DMS Starts
		var rowIndex = Fn_GetCheckboxRowIndex(event);
	  //PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes ends
		if(document.getElementById('BLK_DOCTYPE_CHECKLIST').tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value !=null && document.getElementById('BLK_DOCTYPE_CHECKLIST').tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value !=""){
			//alert("Please delete the uploaded document to upload a new document");
			showErrorAlerts('CO-VAL-080');  // NLS_11.4
			return false;
		}
		else{
		    var dmsRefNo = uploadDocument(rowIndex); //The function available from DMSUtility.js
		//document.getElementById('BLK_DOCTYPE_CHECKLIST').tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value = dmsRefNo; //9NT1462-ITR1 -BUG 13090383
		return true;
		} //9NT1462 Standard Documents -DMS Ends
	}
	return false;
}

//for view uploaded documents
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 changes starts
//function fn_view()
function fn_view(event)
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 changes ends
{
 if (Fn_ValidateCheckbox()) {
   //PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 changes starts
	//var rowIndex = Fn_GetCheckboxRowIndex();//getRowIndex();
	var rowIndex = Fn_GetCheckboxRowIndex(event);
  //PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes ends
    var dmsRefNo = document.getElementById('BLK_DOCTYPE_CHECKLIST').tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value;//document.getElementsByName('BLK_DOCTYPE_CHECKLIST__DOCREFNO')[getRowIndex()-1].value;
    if (dmsRefNo == null || dmsRefNo == "") { //9NT1462 Standard Documents -DMS Starts
	    //alert('The selected document is already Deleted or not yet uploaded');
		showErrorAlerts('CO-VAL-081');  // NLS_11.4
		return false;
    }//9NT1462 Standard Documents -DMS ends
	//PNTFLX01011_12.1_ITR2_21828141 Changes starts commenting the below function call as the same function is getting invoked from DMSUtility.js	
	//downloadDocument(dmsRefNo,event); //PNTFLX01011_FCUBS_12.1_ITR1_21423515 added the parameter event
    event= window.event || event;
    var srcElement = getEventSourceElement(event);
	//[FCUBS12.2-INTERNAL-ITR2-23241803] starts
	var thirdChar = functionId.charAt(3);
	// [FCUBS12.2-INTERNAL-OSDC-23289258] starts
	//if thirdChar!= 'S'
	if (thirdChar != 'S')
	//[FCUBS12.2-INTERNAL-OSDC-23289258] ends
	{ 
	//[FCUBS12.2-INTERNAL-ITR2-23241803] ends
	createTempForwardIframe( "FCDocumentControllerServlet?actionType=Download Document&documentID=" + dmsRefNo, srcElement);
	} //[FCUBS12.2-INTERNAL-ITR2-23241803]
	//PNTFLX01011_12.1_ITR2_21828141 Changes ends
	return true;
	}
	return false;
}
// For Deleting uploaded documents
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 changes starts
//function fn_delete()
function fn_delete(event)
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301

{
if (Fn_ValidateCheckbox()) {

    var noOfRows = document.getElementById('BLK_DOCTYPE_CHECKLIST').tBodies[0].rows.length;
	//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes starts
    //var rowIndex = Fn_GetCheckboxRowIndex();
	var rowIndex = Fn_GetCheckboxRowIndex(event);
	//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes ends
	var isDeleteSuccessful = true;
    var documentID = document.getElementById('BLK_DOCTYPE_CHECKLIST').tBodies[0].rows[rowIndex -1 ].cells[6].getElementsByTagName("INPUT")[0].value
            if (documentID == null || documentID == "") { //9NT1462 Standard Documents -DMS Starts
                 //alert('The selected document is already Deleted or not yet uploaded');
				 showErrorAlerts('CO-VAL-081');  // NLS_11.4
				 return; //9NT1462 Standard Documents -DMS Ends
            }
			else {
	            var parameters = encodeURI("Action=Delete Document&documentID=" + documentID);
	            var xmlHttp = createHTTPActiveXObject();
	            xmlHttp.open("POST", "FCDocumentControllerServlet", false);
	            xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	            xmlHttp.setRequestHeader("Content-length", parameters.length);
	            xmlHttp.setRequestHeader("Connection", "close");
	            //bjHTTP.setRequestHeader("X-CSRFTOKEN", mainWin.CSRFtoken);
	            xmlHttp.setRequestHeader("X-CSRFTOKEN", mainWin.CSRFtoken); 
				xmlHttp.send(parameters);
	            var csrfNode = selectSingleNode(xmlHttp.responseXML, "//CSRF");
	            if (csrfNode != null && getNodeText(csrfNode) == "SM-00420") {
	                alert(getNodeText(csrfNode) + mainWin.getItemDesc("LBL_REQUEST_TAMPERED"));
	            }
	            else {
	                var xmlHttpResponse = xmlHttp.responseXML;
	                if (xmlHttpResponse != null) {
	                    var responseDOM = xmlHttpResponse;
	                    responseDOM.setProperty("SelectionNamespaces", "xmlns:dms='http://webservices.iflex.com'");
	                    var exceptionMessage = selectSingleNode(responseDOM, "//dms:ExceptionMessage");
						if (exceptionMessage != null){ //PNTFLX01011_12.1_ITR2_21768953 added if condition
	                    var exceptionText = getNodeText(exceptionMessage);
	                    if (exceptionMessage != null && exceptionText != null && exceptionText != "") {
	                        isDeleteSuccessful = false;
	                    }
						} //PNTFLX01011_12.1_ITR2_21768953 added
	                    else {
	                        var deletionStatus = selectSingleNode(responseDOM, "//dms:DeletionStatus");
	                        if (deletionStatus != null && getNodeText(deletionStatus) != null && getNodeText(deletionStatus) == "false") {
	                            isDeleteSuccessful = false;
	                        }
	                    }
	                }                
	            }
			}
  
    if (isDeleteSuccessful == true) {
		document.getElementById('BLK_DOCTYPE_CHECKLIST').tBodies[0].rows[rowIndex-1].cells[7].getElementsByTagName("INPUT")[0].checked = false;
		document.getElementById('BLK_DOCTYPE_CHECKLIST').tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value ="";
        //alert('The selected document has been deleted from the Document Management System.');
		showErrorAlerts('IA-VAL-04');  // NLS_11.4
    }
    else if (isDeleteSuccessful == false) {
        //alert('Documents could not be deleted.');
		showErrorAlerts('IA-VAL-05');  // NLS_11.4
    }
    else {       
        return true;
    }
    	
      } 
	return true;	
	  
}
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes starts
//function Fn_GetCheckboxRowIndex () {
function Fn_GetCheckboxRowIndex (event) {
//PNTFLX01011_DEV_FCUBS_12.1_IQA_21245301 Changes ends

	//9NT1462-ITR1 -BUG 13090383 Starts
/*	var chkBoxList = document.getElementsByName('chkDeleteRow');
	var cntSelected = 0;
	for(i = 0; i < chkBoxList.length; i++) {
		if(chkBoxList[i].checked) {
			break;
		}
	}
*/
  var tableRef =document.getElementById("BLK_DOCTYPE_CHECKLIST");
  var totalRows = tableRef.tBodies[0].rows.length;
  var RowIndex = getRowIndex(event);
  var rowRef = tableRef.tBodies[0].rows;
  var count =0;
  for( i=0 ; i < totalRows ; i++ ) 
	{	   
		if(rowRef[i].cells[0].getElementsByTagName("INPUT")[0].checked) break;
  //9NT1462-ITR1 -BUG 13090383 Ends
	}
	return i+1;
}
function fn_check_freq()
{

if (!document.getElementById("BLK_DOCTYPE_REMARKS__SEND_NOTIFICATION").checked)
	{
	document.getElementById("BLK_DOCTYPE_REMARKS__FREQUENCY").value = '';
	document.getElementById("BLK_DOCTYPE_REMARKS__DAYS").value = '';
	
		fnDisableElement(document.getElementById("BLK_DOCTYPE_REMARKS__FREQUENCY"));
		fnDisableElement(document.getElementById("BLK_DOCTYPE_REMARKS__DAYS"));
	}	
else
       {
  		fnEnableElement(document.getElementById("BLK_DOCTYPE_REMARKS__FREQUENCY"));
		fnEnableElement(document.getElementById("BLK_DOCTYPE_REMARKS__DAYS"));	
       }
}
function fn_button()
     { 
	  if (document.getElementById("BLK_CUST_ACCOUNT__DMS_INSTALLED").value == 'Y' ) 
		{ 
			fnEnableElement( document.getElementById("BLK_DOCTYPE_REMARKS__BTN_UPLOAD"));
			fnEnableElement( document.getElementById("BLK_DOCTYPE_REMARKS__BTN_DELETE")); 			
			fnEnableElement(document.getElementById("BLK_DOCTYPE_REMARKS__BTN_VIEW")); 
			appendData();
		} 
		else
		{ 
			fnDisableElement( document.getElementById("BLK_DOCTYPE_REMARKS__BTN_UPLOAD"));
			fnDisableElement( document.getElementById("BLK_DOCTYPE_REMARKS__BTN_DELETE")); 			
			fnDisableElement(document.getElementById("BLK_DOCTYPE_REMARKS__BTN_VIEW")); 
			appendData();
		} 
	return true;			 
  
	}
//9NT1462 Standard Documents End
//9NT1462 Standard Documents -DMS Starts
var isDocUpLWin = false;
var gDMSRefNo;
var docSubmitDlgArg = new Object();
function uploadDocument(rowIndex) {
    docSubmitDlgArg.docUplScreenWin = window;
    docSubmitDlgArg.rowIndex = rowIndex;
    if (isDocUpLWin == false) {
        isDocUpLWin = true;
        loadSubScreenDIV("ChildWin", "DocumentUpload.jsp");
        isDocUpLWin = false;
    }
}
//9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17340275 starts
/*
function downloadDocument(documentId) {
    var objwindow = mainWin.open("FCDocumentControllerServlet?Action=Download Document&documentID=" + documentId, null, "width=640px,height=480px,resizable=yes,scrollbars=yes,status=1,toolbar=no", false);
}*/
//PNTFLX01011_FCUBS_12.1_ITR1_21423515 changes starts 
/*function downloadDocument(documentId) {
    var objwindow = mainWin.open("FCDocumentControllerServlet?Action=Download Document&documentID=" + documentId+"&X-CSRFTOKEN="+mainWin.CSRFtoken, null, "width=640px,height=480px,resizable=yes,scrollbars=yes,status=1,toolbar=no", false);
}*/

//PNTFLX01011_12.1_ITR2_21828141 Changes
/*
function downloadDocument(documentId, evnt) {
    evnt= window.event || evnt;
    var srcElement = getEventSourceElement(evnt);
	createTempForwardIframe( "FCDocumentControllerServlet?actionType=Download Document&documentID=" + documentId, srcElement);
}*/
//PNTFLX01011_12.1_ITR2_21828141 Changes ends
//PNTFLX01011_FCUBS_12.1_ITR1_21423515 changes ends
//9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17340275 ends
//9NT1462 Standard Documents -DMS Ends
//9NT1462 ITR 13076898 changes starts
function fnDisableSubSystemButton(elem) {
	if (elem.onclick) {
		elem.onmouseover0 = elem.onmouseover;
		elem.onfocus0 = elem.onfocus;
		elem.onmouseout0 = elem.onmouseout;
		elem.onblur0 = elem.onblur;
		elem.onkeydown0 = elem.onkeydown;
		elem.onclick0 = elem.onclick;
		elem.onmouseover = elem.onfocus = elem.onmouseout = elem.onblur = elem.onkeydown = elem.onclick = null;
		elem.className = 'AbuttonD';
	}
}
//9NT1462 ITR 13076898 changes ends
//9NT1462-ITR1 -BUG 13090383 Starts
function fnMouseDownEvents(event){
  try{
  var tableRef =document.getElementById("BLK_DOCTYPE_CHECKLIST");
  var totalRows = tableRef.tBodies[0].rows.length;
  var RowIndex = getRowIndex(event);
  var rowRef = tableRef.tBodies[0].rows;
  var count =0;
  var evnt = window.event || e;
  var srcElement = getEventSourceElement(evnt);  
  if(srcElement.tagName.toUpperCase() == 'INPUT'){
	  for( i=0 ; i < totalRows ; i++ ) 
		{	   
			rowRef[i].cells[0].getElementsByTagName("INPUT")[0].checked = false;
		}
	}
	}catch(err){}
  return true;

}
//9NT1462-ITR1 -BUG 13090383Ends

//9NT1462 ITR1 SFR# 13412162 begin

function fn_ChangeTenor(e) //FCUBS_12.4_CNSL_JOINT_STOCK_SFR#28606694 Added e
{
//FCUBS_12.4_CNSL_JOINT_STOCK_SFR#28606694 Changes Starts
var event = window.event || e;
try
{
validateInputDate('MATDT', event); 
}
catch(exp){}
//FCUBS_12.4_CNSL_SAIGON_COMMERCIAL_BANK_SFR#28229496 Changes Starts	
/*if (document.getElementById("BLK_TDDETAILS__MATDTI").value) 
{ 
document.getElementById("BLK_TDDETAILS__MATDT").value = document.getElementById("BLK_TDDETAILS__MATDTI").value ; 
} 
//FCUBS_12.4_CNSL_SAIGON_COMMERCIAL_BANK_SFR#28229496 Changes Ends
*/
//FCUBS_12.4_CNSL_JOINT_STOCK_SFR#28606694 Changes Ends
//9NT1525_12.0_TFCBTWD_14471257_RETRO  Starts 
if(gAction != 'EXECUTEQUERY' && gAction != '') 
{
//9NT1525_12.0_TFCBTWD_14471257_RETRO Ends 
if (document.getElementById("BLK_TDDETAILS__MATDT").readonly != true )
{
if ((document.getElementById("BLK_CUST_ACCOUNT__ACCOPENDT").value != '') && (document.getElementById("BLK_TDDETAILS__MATDT").value != ''))
{ 
// -- 9NT1587 FC_DEV_12.0.2 VINU CHANGES starts --
// 9NT1587 FC_DEV_12.0.2 VINU CHANGES commented below
/*
var myBasedate =document.getElementById("BLK_CUST_ACCOUNT__ACCOPENDT").value;
var myBaseDateArray = new Array();
myBaseDateArray = myBasedate.split("-");
var basDate = getDateObject();
basDate.setYear(myBaseDateArray[0]);
basDate.setMonth(myBaseDateArray[1] - 1);
basDate.setDate(myBaseDateArray[2]) ;
var myMatdate =document.getElementsByName("MATDT")[0].value;
var myMatDateArray = new Array();
myMatDateArray = myMatdate.split("-");
var matDate = getDateObject();
matDate.setYear(myMatDateArray[0]);
matDate.setMonth(myMatDateArray[1] - 1);
matDate.setDate(myMatDateArray[2]) ;
document.getElementById("BLK_TDDETAILS__DEPTENOR").value = Math.round((matDate.valueOf() - basDate.valueOf())/(60 * 60 * 24 * 1000));
*/
//9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17203797 starts
//FCUBS_12.4_CNSL_JOINT_STOCK_SFR#28606694 Comment Starts
/*
try
{
validateInputDate('MATDT', event); 
}
catch(exp){}
*/
//FCUBS_12.4_CNSL_JOINT_STOCK_SFR#28606694 Comment Ends
//9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17203797 ends
var g_prevAction = gAction;
	gAction = "CHANGETENOR";  
	appendData();
fcjRequestDOM = buildUBSXml(); 
  fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);

  if(fcjResponseDOM) 
  		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') 
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
			fnProcessResponse();
		}
		else if (msgStatus == "WARNING" ||msgStatus == "SUCCESS" )       
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
		} 
		var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
		setDataXML(getXMLString(pureXMLDOM));
	    showData(dbStrRootTableName, 1);	
		
	gAction = g_prevAction; 
//--9NT1587 FC_DEV_12.0.2 VINU CHANGES ends--
}

}
}
}//9NT1525_12.0_TFCBTWD_14471257_RETRO  Changes

//9NT1587 FC_DEV_12.0.2 VINU CHANGES starts
function fn_ChangeRollover()
{
//PNTFLX01011_FCUBS_12.1_ITR1_21477045 starts reverted
/*if(parent.document.getElementById('BLK_TDDETAILS__AUTOROLL').checked == true)
{
fn_ChangeRollTenorPref();
}*/
return true;
//PNTFLX01011_FCUBS_12.1_ITR1_21477045 ends
//9NT1606_12_1_TD_ADD_ROLLOVER commented
/*
 //if(document.getElementById('BLK_TDDETAILS__AUTOROLL').checked == true)//9NT1606_12_1_TD_ADD_ROLLOVER commented
 if(parent.document.getElementById('BLK_TDDETAILS__AUTOROLL').checked == true)//9NT1606_12_1_TD_ADD_ROLLOVER added
 {
    document.getElementsByName('ROLLTENORPREF')[0].disabled = false;
    document.getElementsByName('ROLLTENORPREF')[1].disabled = false;
    document.getElementsByName('ROLLTENORPREF')[2].disabled = false;
	fn_ChangeRollTenorPref();
  }
  else
  {
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARS").value="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYS").value="";
  //document.getElementById("BLK_TDDETAILS__NEXTMATDT").value="";//9NT1606_12_1_TD_ADD_ROLLOVER changes
  parent.document.getElementById("BLK_TDDETAILS__NEXTMATDT").value="";//9NT1606_12_1_TD_ADD_ROLLOVER changes
    document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").value="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").value="";
  //document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value="";//9NT1606_12_1_TD_ADD_ROLLOVER changes
  parent.document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value="";//9NT1606_12_1_TD_ADD_ROLLOVER changes
  
  document.getElementsByName('ROLLTENORPREF')[0].disabled = true;
  document.getElementsByName('ROLLTENORPREF')[1].disabled = true;
  document.getElementsByName('ROLLTENORPREF')[2].disabled = true;
	
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").className = "TXTro numeric";
 
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("readOnly","readonly");
  
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("READONLY1","true");
  }*/
}
//9NT1587 FC_DEV_12.0.2 VINU CHANGES ends
function fn_ChangeMatDate()
{
if (document.getElementById("BLK_TDDETAILS__DEPTENORYEAR").readonly != true) 
{
	if((document.getElementById("BLK_CUST_ACCOUNT__ACCOPENDT").value != '') && (document.getElementById("BLK_TDDETAILS__MATDT").value != ''))
{
// -- 9NT1587 FC_DEV_12.0.2 VINU CHANGES starts --
// --9NT1587 FC_DEV_12.0.2 VINU CHANGES commented below
/* 
var Monthly = /M/;
var HalfYearly = /H/;
var Quarterly = /Q/;
var Yearly = /Y/;
var Days = /D/;
var Weeks = /W/;
var TENOR = document.getElementById("BLK_TDDETAILS__DEPTENOR").value;
var TENOR = TENOR.toUpperCase();
var Month = TENOR.search(Monthly);
var Half = TENOR.search(HalfYearly);
var Quarter = TENOR.search(Quarterly);
var Year = TENOR.search(Yearly);
var Day = TENOR.search(Days);
var Week = TENOR.search(Weeks);

var tenorMon = 0;
if (Month != -1)
	{
var strLen = TENOR.length;
tenorMon = TENOR.slice(0,strLen-1);
var tenorMon = tenorMon*1;
var tenornum = 0;
}
else if (Half != -1)
	{
var strLen = TENOR.length;
tenorMon = TENOR.slice(0,strLen-1);
var tenorMon = tenorMon*6;
tenorMon = tenorMon*1;
var tenornum = 0;
}
else if (Quarter != -1)
	{
var strLen = TENOR.length;
tenorMon = TENOR.slice(0,strLen-1);
var tenorMon = tenorMon*3;
tenorMon = tenorMon*1;
var tenornum = 0;
}
else if (Year != -1)
	{
	var strLen = TENOR.length;
tenorMon = TENOR.slice(0,strLen-1);
var tenorMon = tenorMon*12;
tenorMon = tenorMon*1;
var tenornum = 0;
}
else if (Day != -1)
	{
var strLen = TENOR.length;
tenornum = TENOR.slice(0,strLen-1);
var tenornum = tenornum*1;
var tenorMon = 0;
}
else if (Week != -1)
	{
var strLen = TENOR.length;
tenornum = TENOR.slice(0,strLen-1);
var tenornum = tenornum*7;
var tenornum = tenornum*1;
var tenorMon = 0;

}
else
	{
	var strLen = TENOR.length;
tenornum = document.getElementById("BLK_TDDETAILS__DEPTENOR").value;
var tenornum = tenornum*1;
var tenorMon = 0;
	}

var myBasedate =document.getElementById("BLK_CUST_ACCOUNT__ACCOPENDT").value;
var myBaseDateArray = new Array();
myBaseDateArray = myBasedate.split("-");
var matDate = getDateObject();
matDate.setYear(myBaseDateArray[0]);
matDate.setMonth(myBaseDateArray[1] - 1);
if(tenorMon != 0)
matDate.setMonth(matDate.getMonth() + tenorMon);
matDate.setDate(myBaseDateArray[2]) ;
if(tenornum != 0)
matDate.setDate(matDate.getDate() + tenornum );

var matmonth = matDate.getMonth() + 1;

document.getElementById("BLK_TDDETAILS__MATDT").value = matDate.getFullYear() + '-' + matmonth + '-' + matDate.getDate();
if (document.getElementById("BLK_TDDETAILS__AUTOROLL").checked == true)
{
var myBasedate1 =document.getElementById("BLK_TDDETAILS__MATDT").value;
var myBaseDateArray1 = new Array();
myBaseDateArray1 = myBasedate1.split("-");
var matDate1 = getDateObject();
matDate1.setYear(myBaseDateArray1[0]);
matDate1.setMonth(myBaseDateArray1[1] - 1);
if(tenorMon != 0)
matDate1.setMonth(matDate1.getMonth() + tenorMon);
matDate1.setDate(myBaseDateArray1[2]) ;
if(tenornum != 0)
matDate1.setDate(matDate1.getDate() + tenornum );

var matmonth1 = matDate1.getMonth() + 1;

document.getElementById("BLK_TDDETAILS__NEXTMATDT").value = matDate1.getFullYear() + '-' + matmonth1 + '-' + matDate1.getDate();
}
}  
*/
if (!checkNumberValidation(document.getElementById("BLK_TDDETAILS__DEPTENORYEAR").value))
{
document.getElementById("BLK_TDDETAILS__DEPTENORYEAR").value = 0;
}
if (!checkNumberValidation(document.getElementById("BLK_TDDETAILS__DEPTENORMON").value))
{
document.getElementById("BLK_TDDETAILS__DEPTENORMON").value = 0;
}
if (!checkNumberValidation(document.getElementById("BLK_TDDETAILS__DEPTENORDAY").value))
{
document.getElementById("BLK_TDDETAILS__DEPTENORDAY").value = 0;
}
var g_prevAction = gAction;
	gAction = "CHANGEMATDT";  
	appendData();
fcjRequestDOM = buildUBSXml(); 
  fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);

  if(fcjResponseDOM) 
  		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') 
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
			fnProcessResponse();
		}
		else if (msgStatus == "WARNING" ||msgStatus == "SUCCESS" )       
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
		} 
		var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
		setDataXML(getXMLString(pureXMLDOM));
	    showData(dbStrRootTableName, 1);	
		
	gAction = g_prevAction; 
	


}
}
}
//PNTFLX01011_12.1_ITR2_21669908 starts
function fn_ChangeRollTenorSimulation()
{
if ((document.getElementById("BLK_CUST_ACCOUNT__ACCOPENDT").value != '') && (document.getElementById("BLK_TDDETAILS__MATDT").value != ''))
{
if(document.getElementsByName("ROLLTENORPREF")[0].checked)
{
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").className = "TXTro numeric";
 
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("readOnly","readonly");    
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("READONLY1","true");
  if ( g_nullify_tenor == true) 
   {
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARS").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYS").value ="";
  document.getElementById("BLK_TDDETAILS__NEXTMATDT").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").value ="";
  document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value ="";
  }
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").tabIndex = "-1";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").tabIndex = "-1";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").tabIndex = "-1";
}
if(document.getElementsByName("ROLLTENORPREF")[1].checked)
{  
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").className = "TXTro numeric";    
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("readOnly","readonly");  
  
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("READONLY1","true");  
   if ( g_nullify_tenor == true) 
   {
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARS").value = document.getElementById("BLK_TDDETAILS__ORIGTENORYEAR").value;
  if (functionId == 'STDCUSTD'|| functionId == 'STDTDSIM') 
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value = document.getElementById("BLK_TDDETAILS__ORIGTENORMON").value;
  else
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value = document.getElementById("BLK_TDDETAILS__ORIGTENORMONTH").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYS").value = document.getElementById("BLK_TDDETAILS__ORIGTENORDAY").value;
  document.getElementById("BLK_TDDETAILS__NEXTMATDT").value = "";  
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").value = document.getElementById("BLK_TDDETAILS__ORIGTENORYEARI").value;
  if (functionId == 'STDCUSTD'|| functionId == 'STDTDSIM')
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value = document.getElementById("BLK_TDDETAILS__ORIGTENORMONI").value;
  else
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value = document.getElementById("BLK_TDDETAILS__ORIGTENORMONTHI").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").value = document.getElementById("BLK_TDDETAILS__ORIGTENORDAYI").value;
  document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value = ""; 
  }
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").tabIndex = "-1";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").tabIndex = "-1";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").tabIndex = "-1";
}
if(document.getElementsByName("ROLLTENORPREF")[2].checked)
{      
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").className = "TXTstd numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").className = "TXTstd numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").className = "TXTstd numeric";    
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").removeAttribute("readOnly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").removeAttribute("readOnly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").removeAttribute("readOnly");    
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").removeAttribute("READONLY1");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").removeAttribute("READONLY1");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").removeAttribute("READONLY1");  
  if ( g_nullify_tenor == true)  
  {
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").value = "";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value = "";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").value = "";  
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARS").value = "";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value = "";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYS").value = "";
  document.getElementById("BLK_TDDETAILS__NEXTMATDT").value = ""; 
  document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value = ""; 
  }
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").tabIndex = "0";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").tabIndex = "0";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").tabIndex = "0";
}
}
}
//PNTFLX01011_12.1_ITR2_21669908 ends

function fn_ChangeRollTenorPref()
{
//PNTFLX01011_12.1_ITR2_21669908 starts
if (functionId == 'STDTDSIM') 
{
fn_ChangeRollTenorSimulation();
return true;
}
//PNTFLX01011_12.1_ITR2_21669908 ends
//if ((document.getElementById("BLK_CUST_ACCOUNT__ACCOPENDT").value != '') && (document.getElementById("BLK_TDDETAILS__MATDT").value != ''))//9NT1606_12_1_TD_ADD_ROLLOVER 
if ((parent.document.getElementById("BLK_CUST_ACCOUNT__ACCOPENDT").value!='') && (parent.document.getElementById("BLK_TDDETAILS__MATDT").value!=''))//9NT1606_12_1_TD_ADD_ROLLOVER added
{
if(document.getElementsByName("ROLLTENORPREF")[0].checked)
{
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").className = "TXTro numeric";
 
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("readOnly","readonly");    
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("READONLY1","true");
  if ( g_nullify_tenor == true) //9NT1606_12.0.3_TIEN PHONG BANK_19909048
   {//9NT1606_12.0.3_TIEN PHONG BANK_19909048
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARS").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYS").value ="";
  //document.getElementById("BLK_TDDETAILS__NEXTMATDT").value ="";//9NT1606_12_1_TD_ADD_ROLLOVER changes
  parent.document.getElementById("BLK_TDDETAILS__NEXTMATDT").value ="";//9NT1606_12_1_TD_ADD_ROLLOVER changes
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value ="";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").value ="";
  //document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value ="";//9NT1606_12_1_TD_ADD_ROLLOVER changes
  parent.document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value ="";//9NT1606_12_1_TD_ADD_ROLLOVER changes
  }//9NT1606_12.0.3_TIEN PHONG BANK_19909048
  //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421 starts
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").tabIndex = "-1";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").tabIndex = "-1";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").tabIndex = "-1";
  //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421 ends
}
if(document.getElementsByName("ROLLTENORPREF")[1].checked)
{  
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").className = "TXTro numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").className = "TXTro numeric";    
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("readOnly","readonly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("readOnly","readonly");  
  
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").setAttribute("READONLY1","true");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").setAttribute("READONLY1","true");  
   if ( g_nullify_tenor == true) //9NT1606_12.0.3_TIEN PHONG BANK_19909048
   {//9NT1606_12.0.3_TIEN PHONG BANK_19909048
  //document.getElementById("BLK_TDDETAILS__ROLLTENORYEARS").value = document.getElementById("BLK_TDDETAILS__ORIGTENORYEAR").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARS").value = parent.document.getElementById("BLK_TDDETAILS__ORIGTENORYEAR").value;//9NT1606_12_1_TD_ADD_ROLLOVER changes
  if (functionId == 'STDCUSTD'|| functionId == 'STDTDSIM')  //9NT1587_ITR_17007079
  //document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value = document.getElementById("BLK_TDDETAILS__ORIGTENORMON").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value = parent.document.getElementById("BLK_TDDETAILS__ORIGTENORMON").value;//9NT1606_12_1_TD_ADD_ROLLOVER changes
  else
  //document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value = document.getElementById("BLK_TDDETAILS__ORIGTENORMONTH").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value = parent.document.getElementById("BLK_TDDETAILS__ORIGTENORMONTH").value;//9NT1606_12_1_TD_ADD_ROLLOVER changes
  //document.getElementById("BLK_TDDETAILS__ROLLTENORDAYS").value = document.getElementById("BLK_TDDETAILS__ORIGTENORDAY").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYS").value = parent.document.getElementById("BLK_TDDETAILS__ORIGTENORDAY").value;//9NT1606_12_1_TD_ADD_ROLLOVER changes
  //document.getElementById("BLK_TDDETAILS__NEXTMATDT").value = "";  
  parent.document.getElementById("BLK_TDDETAILS__NEXTMATDT").value = "";  //9NT1606_12_1_TD_ADD_ROLLOVER changes
  //document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").value = document.getElementById("BLK_TDDETAILS__ORIGTENORYEARI").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").value = parent.document.getElementById("BLK_TDDETAILS__ORIGTENORYEARI").value;//9NT1606_12_1_TD_ADD_ROLLOVER changes
  if (functionId == 'STDCUSTD'|| functionId == 'STDTDSIM')   //9NT1587_ITR_17007079
  //document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value = document.getElementById("BLK_TDDETAILS__ORIGTENORMONI").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value = parent.document.getElementById("BLK_TDDETAILS__ORIGTENORMONI").value;//9NT1606_12_1_TD_ADD_ROLLOVER changes
  else
  //document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value = document.getElementById("BLK_TDDETAILS__ORIGTENORMONTHI").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value = parent.document.getElementById("BLK_TDDETAILS__ORIGTENORMONTHI").value;//9NT1606_12_1_TD_ADD_ROLLOVER changes
  //document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").value = document.getElementById("BLK_TDDETAILS__ORIGTENORDAYI").value;
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").value = parent.document.getElementById("BLK_TDDETAILS__ORIGTENORDAYI").value;//9NT1606_12_1_TD_ADD_ROLLOVER changes
  //document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value = ""; 
  parent.document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value = ""; //9NT1606_12_1_TD_ADD_ROLLOVER changes
  }//9NT1606_12.0.3_TIEN PHONG BANK_19909048
  //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421 starts
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").tabIndex = "-1";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").tabIndex = "-1";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").tabIndex = "-1";
  //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421 ends
}
if(document.getElementsByName("ROLLTENORPREF")[2].checked)
{      
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").className = "TXTstd numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").className = "TXTstd numeric";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").className = "TXTstd numeric";    
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").removeAttribute("readOnly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").removeAttribute("readOnly");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").removeAttribute("readOnly");    
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").removeAttribute("READONLY1");
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").removeAttribute("READONLY1");
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").removeAttribute("READONLY1");  
  if ( g_nullify_tenor == true)  //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17240700
  {
  //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17203797 starts
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").value = "";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").value = "";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").value = "";  
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARS").value = "";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHS").value = "";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYS").value = "";
  //document.getElementById("BLK_TDDETAILS__NEXTMATDT").value = ""; 
  //document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value = ""; 
  parent.document.getElementById("BLK_TDDETAILS__NEXTMATDT").value = ""; //9NT1606_12_1_TD_ADD_ROLLOVER changes
  parent.document.getElementById("BLK_TDDETAILS__NEXTMATDTI").value = ""; //9NT1606_12_1_TD_ADD_ROLLOVER changes
  //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17203797 ends
  }
  //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421 starts
  document.getElementById("BLK_TDDETAILS__ROLLTENORYEARSI").tabIndex = "0";
  document.getElementById("BLK_TDDETAILS__ROLLTENORMONTHSI").tabIndex = "0";
  document.getElementById("BLK_TDDETAILS__ROLLTENORDAYSI").tabIndex = "0";
  //9NT1587_FCUBS_12.0.2_DEV_ITR2_SFR#17297421 ends
}
}
}
//--9NT1587 FC_DEV_12.0.2 VINU CHANGES end--

//9NT1462 ITR1 SFR# 13412162 end

//9NT1501 12.0 USABILITY CHANGES STARTS
//9NT1606_12_4_RETRO_12_1_26440939 Comments Starts

/*
function fnInTab_AUXILIARY_KERNEL()
{
  var atm=document.getElementById('BLK_CUST_ACCOUNT__ATM').checked;
  //PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes starts
  /*
  //PNTFLX01011_DEV_FCUBS_12.1_IQA_21228412 Changes starts
  if(gAction!='NEW' && dbDataDOM != null){
  fnEnableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]); 
  }
  else{
  fnDisableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]); 
  }
  //PNTFLX01011_DEV_FCUBS_12.1_IQA_21228412 Changes ends
  *\
  //PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes ends
  if(!atm)
  {
  fnDisableElement(document.getElementById('BLK_CUST_ACCOUNT__ATMBRN'));
  fnDisableElement(document.getElementById('BLK_CUST_ACCOUNT__ATMACC'));
  fnDisableElement(document.getElementById('BLK_CUST_ACCOUNT__ATMDLIMI'));
  fnDisableElement(document.getElementById('BLK_CUST_ACCOUNT__ATMDCNTLIMI'));
  fnDisableElement(document.getElementById('BLK_CUST_ACCOUNT__DEBIT_CARD_REQUEST'));
  }
  else
  {
  fnEnableElement(document.getElementById('BLK_CUST_ACCOUNT__ATMBRN'));
  fnEnableElement(document.getElementById('BLK_CUST_ACCOUNT__ATMACC'));
  fnEnableElement(document.getElementById('BLK_CUST_ACCOUNT__ATMDLIMI'));
  fnEnableElement(document.getElementById('BLK_CUST_ACCOUNT__ATMDCNTLIMI'));
  fnEnableElement(document.getElementById('BLK_CUST_ACCOUNT__DEBIT_CARD_REQUEST'));
  }
  return true;
}
*/
//9NT1606_12_4_RETRO_12_1_26440939 Comments Ends
function fnChangeAccountType()
{
if (document.getElementsByName('ACCTYPE')[1].checked == true)
fnEnableMEBlock('BLK_JOINTHOLDERS', true);
else
fnEnableMEBlock('BLK_JOINTHOLDERS', false);
}
//9NT1501 12.0 USABILITY CHANGES ENDS
//9NT1587_12.0.2_CIF_SIG_ENHANCEMENT Starts
function fnPreSave_CVS_JNTACCHLD_KERNEL(screenArgs)
{
//debugger;
//alert('thakur is here');
appendData();

                var currRow;
                var totalRows;
				g_prev_gAction = '';
g_prev_gAction = gAction;
gAction = 'REP_ALL';
fcjRequestDOM = buildUBSXml();
servletURL = "FCClientHandler";
fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
//PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
showProcessMsg = false;
//gAction = '';
//PNTFLX01011_FCUBS_12.1_MAT_21310050 ends
if(!fnProcessResponse()){
gAction=g_prev_gAction;
return false;
}

gAction=g_prev_gAction; 
appendData();
                                if (document.getElementById('BLK_JOINTHOLDERS'))
                {

            
                                if (document.getElementById('BLK_JOINTHOLDERS').tBodies[0].rows.length > 0)
                                {
                                                totalRows = document.getElementById('BLK_JOINTHOLDERS').tBodies[0].rows.length;
                                                for (var i = 0; i < totalRows; i++)
                                                {

							 if(i != totalRows -1)
								{
                                                      g_temp =   g_temp + document.getElementsByName("JNTHLDCDE")[i].value + '@';
                                                      g_tempui =   g_tempui + document.getElementsByName("JNTHLDTYP")[i].value + '@';    
								}
							else
								{
								 g_temp =   g_temp + document.getElementsByName("JNTHLDCDE")[i].value;
								 g_tempui =   g_tempui + document.getElementsByName("JNTHLDTYP")[i].value;
								}	
                                                }
                                }

}
parent.document.getElementById("BLK_CUST_ACCOUNT__JHCIF").value = g_temp;
parent.document.getElementById("BLK_CUST_ACCOUNT__JHREL").value = g_tempui;
return true;
}
//9NT1587_12.0.2_CIF_SIG_ENHANCEMENT ends
//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes starts
function fn_create_deposit()
{       
if (document.getElementById("BLK_CUST_ACCOUNT__PAYINBYCHQ").value != 'Q') //9NT1587_12.0.2_ITR1_17028331 for float days
 {
 var a = mainWin.AppDate;
if (document.getElementById("BLK_CUST_ACCOUNT__ACCOPENDT").value > a)//30400832
		{
		showErrorAlerts('ST-VALS-041','E');
		return false;
		}
		
		}
		//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes starts for minimum and maximum tenor
		var g_prevAction = gAction;
	gAction = "MAXMIN";  
	appendData();
fcjRequestDOM = buildUBSXml(); 
  fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
  showProcessMsg = false;
if(fcjResponseDOM) 
  		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') 
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
			fnProcessResponse();
		}
		else if (msgStatus == "WARNING" ||msgStatus == "SUCCESS" )       
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
			
			//9NT1587_12.0.2_ITR1_17028331 starts 
			//9NT1587_ITR1_16987739 starts
		//9NT1587_12.0.2_ITR1_16976099 changes un commented the code 
		fnEnableElement(document.getElementsByName("PAYINBYCHQ")[0]);
		//fnEnableElement(document.getElementsByName("PAYINCHQNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
		fnEnableElement(document.getElementsByName("PAYIN_CHQ_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
		fnEnableElement(document.getElementsByName("PAYINCLGBNK")[0]);
		fnEnableElement(document.getElementsByName("PAYINCLGBRN")[0]);
		//fnEnableElement(document.getElementsByName("PAYINCHQDATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
		fnEnableElement(document.getElementsByName("PAYIN_CHQ_DATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
		fnEnableElement(document.getElementsByName("PAYINCLGPRD")[0]);
		fnEnableElement(document.getElementsByName("PAYINDRWACNO")[0]);
		//fnEnableElement(document.getElementsByName("PAYINROUTINGNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
		fnEnableElement(document.getElementsByName("PAYIN_ROUTING_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
		fnEnableElement(document.getElementsByName("BTN_DEFAULT")[0]);
		//9NT1587_12.0.2_ITR1_16976099 changes ends
		//9NT1587_ITR1_16987739 ends 
		
		//9NT1587_12.0.2_ITR1_17028331 ends 
			fn_simulation_visibility("block");
			//9NT1587_FCUBS_12.0.2_MAT-16917421
		document.getElementById("BLK_TDDETAILS__BTN_CLEAR").style.display = "none";
		document.getElementById("BLK_TDDETAILS__BTN_VIEW_PRINT").style.display = "none";
		document.getElementById("BLK_TDDETAILS__BTN_CREATE_DEP").style.display = "none";
		//9NT1587_FCUBS_12.0.2_MAT-16917421
		} 
		var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
		setDataXML(getXMLString(pureXMLDOM));
	    showData(dbStrRootTableName, 1);	
	gAction = g_prevAction; 
	    //9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes ends for minimum and maximum tenor
		//fn_simulation_visibility("block");
		
	//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes starts
 	
		/*document.getElementById("BLK_TDDETAILS__BTN_VIEW_PRINT").disabled=true;
		document.getElementById("BLK_TDDETAILS__BTN_CLEAR").disabled=true;
		document.getElementById("BLK_TDDETAILS__BTN_CREATE_DEP").disabled=true;*/
		//9NT1587_FCUBS_12.0.2_MAT-16917421
		//document.getElementById("BLK_TDDETAILS__BTN_CLEAR").style.display = "none";
		//document.getElementById("BLK_TDDETAILS__BTN_VIEW_PRINT").style.display = "none";
		//document.getElementById("BLK_TDDETAILS__BTN_CREATE_DEP").style.display = "none";
		//9NT1587_FCUBS_12.0.2_MAT-16917421
		//9NT1587_ITR1_16975835 starts
		var tabRef = document.getElementById("BLK_INTEREST_PAYOUT").tBodies[0] ; 
		var totalRows =document.getElementById("BLK_INTEREST_PAYOUT").rows.length;
for(var i=0 ; i < totalRows ; i++ ) 
{
fnDisableElement(tabRef.rows[i].cells[1].getElementsByTagName("INPUT")[0]);
fnDisableElement(tabRef.rows[i].cells[4].getElementsByTagName("INPUT")[0]);
fnDisableElement(tabRef.rows[i].cells[5].getElementsByTagName("INPUT")[0]);
}
        //9NT1587_ITR1_16975835 ends
	//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes ends


return true;
}

function fn_simulation_visibility(property)
{
	document.getElementById("TBLPageTAB_HEADER").children[0].children[2].style.display = property; 
	//document.getElementById("TBLPageTAB_MAIN").children[1].children[1].style.display = property; //9NT1587_12.0.2_ITR1_17299229  commented
	document.getElementById("TBLPageTAB_MAIN").children[1].children[2].style.display = property;
	document.getElementById("BLK_CUST_ACCOUNT__ACC").previousSibling.parentNode.style.display = property;
	document.getElementById("BLK_CUST_ACCOUNT__SDREFNO").previousSibling.parentNode.style.display = property;
	document.getElementById("dataContainer_BLK_TDPAYINDETAILS").style.display = property;
	document.getElementById("dataContainer_BLK_TDPAYOUTDETAILS").style.display = property;
	document.getElementById("TBLPageTAB_MAIN").children[5].style.display = property;
	document.getElementById("TBLPageTAB_MAIN").children[6].style.display = property;
	document.getElementById("TBLPageTAB_MAIN").children[7].style.display = property;
	document.getElementById("STCDENDP").style.display = property;
	document.getElementById("ICCHSPCN").style.display = property;
	document.getElementById("CSCCUSLN").style.display = property;
	document.getElementById("CVS_PRDTXNRES").style.display = property;
	document.getElementById("MICACCTM").style.display = property;
	document.getElementById("CVS_STATEMENT").style.display = property;
	document.getElementById("CVS_JNTACCHLD").style.display = property;
	document.getElementById("CSCFNUDF").style.display = property;
	document.getElementById("SVCACSIG").style.display = property;
	document.getElementById("ICCTDFPO").style.display = property;
	document.getElementById("STDACSTC").style.display = property;
	document.getElementById("ICCINTPO").style.display = property;
	document.getElementById("STCRLHIS").style.display = property;
	document.getElementById("CSCUPDOC").style.display = property;
	document.getElementById("TAB_NOM").style.display = property;
	document.getElementById("TAB_CHECKLIST").style.display = property;
	document.getElementById("TAB_DUAL_CCY_DEPOSIT").style.display = property;
    //9NT1587_12.0.2_ITR1_17299229 changes starts
    document.getElementById("TBLPageTAB_MAIN").children[1].children[0].children[1].style.display = property; 
	document.getElementById("TBLPageTAB_MAIN").children[1].children[1].children[1].style.display = property;
	document.getElementById("TBLPageTAB_MAIN").children[1].children[1].children[2].style.display = property;
	document.getElementById("SYS_TBL_TABS").style.display = property;
	document.getElementById("BLK_TDDETAILS__PRINCIPAL_AMTI").previousSibling.parentNode.style.display = property;
	//9NT1587_12.0.2_ITR1_17299229  changes ends
	fnCalcHgt(); //PNTFLX01011_FCUBS_12.1_ITR1_21348030
    return true;
}
function fn_view_print()
{
	g_prev_gAction = gAction;
	gAction='GEN_TD_ADV';
	appendData();
	fcjRequestDOM = buildUBSXml();
	servletURL = "FCClientHandler";
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	showProcessMsg = false;
	 if(fcjResponseDOM) 
  		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') 
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
		}
		else if (msgStatus == "WARNING" ||msgStatus == "SUCCESS" )       
		{
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
		} 
		var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
		setDataXML(getXMLString(pureXMLDOM));
	    showData(dbStrRootTableName, 1);	
		//Sfr No# 14017227   starts
		try 
	{
	   if (gSkipDeposit == 'true' ) 
		document.getElementById("BLK_PROCESS_AUDIT__WF_REF_NO").value =gWorkFlowRefNum; 
	}
	catch(e) 
	{}
	gAction=g_prev_gAction; 
	if (msgStatus == "FAILURE")
	{
		return false;
	}
	/*option = 'View'; //Changes Related to Print Statement. //9NT1587_ITR_16987774 commented for adding print button	
	g_AccselectType ="S";
	fnShow_MSDVWMSG(option);	//Changes Related to Print Statement */
	//9NT1587_ITR_16987774 starts
	screenArgs = new Array();
	screenArgs['DCN'] = document.getElementById('BLK_TDDETAILS__DCN').value;
	screenArgs['PR_FUNCTION']='STDTDSIM';
	screenArgs['FCCREF'] = document.getElementById('BLK_CUST_ACCOUNT__ACC').value;
	screenArgs['SCREEN_NAME'] = 'CVS_MAIN';
	screenArgs['FUNCTION_ID'] = 'MSCVWTDC';
	screenArgs['ACTION']='Print';
	screenArgs['UI_XML'] = 'CVS_MAIN';
	screenArgs['LANG'] = mainWin.LangCode;
	screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+mainWin.LangCode+'/'+'MSCVWTDC'+'.xml',screenArgs['SCREEN_NAME']);
	funcid= 'MSCVWTDC';
	parent.screenArgs=screenArgs;
	 //Infra Changes - function origin array - starts
        ArrFuncOrigin[functionId]="KERNEL";
        ArrPrntFunc[functionId]="";
        ArrPrntOrigin[functionId]="";
        ArrRoutingType[functionId]="X";
	//Infra Changes - function origin array - ends

        fnSubScreenMain(funcid, funcid, 'CVS_MAIN');

	//fnShowSubScreen(screenArgs);
	//9NT1587_ITR_16987774 ends
	gAction = g_prev_gAction;
	return true;
}
/* //9NT1587_ITR_16987774	commented for adding print button
function fnShow_MSDVWMSG(option) {		//Changes Related to Print Statement	
		screenArgs['SCREEN_NAME'] = 'CVS_MESSAGE';
		screenArgs['FUNCTION_ID'] = 'MSDVWMSG';
		screenArgs['FCCREF'] = document.getElementById("BLK_CUST_ACCOUNT__ACC").value;
		screenArgs['DCN'] = document.getElementById("BLK_TDDETAILS__DCN").value;
		screenArgs['CALLING_FUNC_ID'] = "STDTDSIM";
		screenArgs['MSGTYPE'] = "";
		screenArgs['DESCRIPTION'] = option; //Changes Related to Print Statement	
		screenArgs['OPERATION'] = option; //Changes Related to Print Statement
		screenArgs['ACCSLTTYPE'] = g_AccselectType;
		mainWin.screenArgs=screenArgs;          
        fnShowLaunchForm("MSDVWMSG", "MSDVWMSG", "CVS_MESSAGE");
		return true;
}*/
function fnClear()
{
gAction = "NEW"; //9NT1606_12_2_RETRO_12_0_3_23656818 added
fnNew();
}
//9NT1587_FCUBS_12.0.2_TD_SIMULATION_CHANGES changes ends
//9NT1587_12.0.2_MAT_16926220 changes starts
function fnPreProcessFields_KERNEL()
{
	if (document.getElementsByName("ACC_OPENING_AMT")[0].value > 0 )
		{
		for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
			{
				document.getElementsByName("PAY_IN_OPTION")[i].disabled = false;
				document.getElementsByName("PAY_IN_OPTION")[0].focus();
			}
		}
		else
		{
			fnDisableElement(document.getElementsByName("INF_OFFSET_BRANCH")[0]);
			fnDisableElement(document.getElementsByName("INF_OFFSET_ACCOUNT")[0]);
			for (var i = 0; i < document.getElementsByName("PAY_IN_OPTION").length; i++)
				{
					document.getElementsByName("PAY_IN_OPTION")[i].checked = false;
					document.getElementsByName("PAY_IN_OPTION")[i].disabled = true;
				}
		}
	return false;
}
//9NT1587_12.0.2_MAT_16926220 changes ends
//9NT1587_12.0.2_ITR1_16976099 changes starts
function fn_default_cheque(event){
	var g_prevAction = gAction;
	gAction = "DFLTCHQ";  
	appendData();
	fcjRequestDOM = buildUBSXml(); 
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	if(fcjResponseDOM) 
	var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == 'FAILURE') 
	{
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	}
	else if (msgStatus == "WARNING" ||msgStatus == "SUCCESS" )       
	{
	showProcessMsg = false;
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");	
	fnDisableElement(document.getElementsByName("PAYINBYCHQ")[0]);
	//fnDisableElement(document.getElementsByName("PAYINCHQNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYIN_CHQ_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYINCLGBNK")[0]);
	fnDisableElement(document.getElementsByName("PAYINCLGBRN")[0]);
	//fnDisableElement(document.getElementsByName("PAYINCHQDATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYIN_CHQ_DATE")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYINCLGPRD")[0]);
	fnDisableElement(document.getElementsByName("PAYINDRWACNO")[0]);
	//fnDisableElement(document.getElementsByName("PAYINROUTINGNO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("PAYIN_ROUTING_NO")[0]); //PNTFLX01011_12.1_ITR2_21821189 changes
	fnDisableElement(document.getElementsByName("BTN_DEFAULT")[0]);
	}
			if(!fnProcessResponse()){
			gAction=g_prevAction;
			return false;
			}
			gAction=g_prevAction;

	return true;
}
//9NT1587_12.0.2_ITR1_16976099 changes ends

//9NT1606_12.0.3_RETRO_20067218 starts
function fnEnableSubSystemButton(elem) {
	 if (elem.onclick0) {
		elem.onmouseover = elem.onmouseover0;
		elem.onfocus = elem.onfocus0;
		elem.onmouseout = elem.onmouseout0;
		elem.onblur = elem.onblur0;
		elem.onkeydown = elem.onkeydown0;
		elem.onclick = elem.onclick0;
		elem.className = 'Abutton';
	}
}
/*9NT1606_12_4_INTERNAL_27014222 STARTS*/
fnViewChangeLog = function(){
	if(!document.getElementById("BLK_CUST_ACCOUNT__CUSTNO").value == ""){
	lfnViewChangeLog();
	}else{
		showErrorAlerts("CO-VAL-010");
	}
}
/*9NT1606_12_4_INTERNAL_27014222 ENDS*/

//9NT1606_12.0.3_RETRO_20067218 ends
//PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes
/*
//FCUBS_12.1.0.0.0_DEV_Sanction_Check Changes starts
function fnPostReOpen_KERNEL()
{
	fnEnableElement(document.getElementsByName("BTN_SNCK_STATUS")[0]); 
	return true;
}

function fnDisplaySnck() {
g_prev_gAction = gAction;
gAction = 'DISPSNCK';
appendData();
fcjRequestDOM = buildUBSXml();
servletURL = "FCClientHandler";
fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
//PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
showProcessMsg = false;
//gAction = '';
//PNTFLX01011_FCUBS_12.1_MAT_21310050 ends
//PNTFLX01016_FCUBS_12_1_0_ITR1_21490825 Changes starts
var pureXMLDOM = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
document.getElementById('BLK_CUST_ACCOUNT__SNCK_STAT').value = getNodeText(selectSingleNode(pureXMLDOM,"//BLK_CUST_ACCOUNT/SNCK_STAT"));
//PNTFLX01016_FCUBS_12_1_0_ITR1_21490825 changes ends
gAction=g_prev_gAction; 
return true;
}
//FCUBS_12.1.0.0.0_DEV_Sanction_Check Changes ends
*/
//PNTFLX01016_FCUBS_12.1.0_ITR1_21593910 Changes endss
