-- Create table
create table CLTB_ACCOUNT_REFERRAL_CUSTOM
(
  loan_account_number  VARCHAR2(35) not null,
  branch_code          VARCHAR2(3) not null,
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255)
)
/
alter table CLTB_ACCOUNT_REFERRAL_CUSTOM add primary key (LOAN_ACCOUNT_NUMBER, BRANCH_CODE)
/
-- Create table
create table CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST
(
  loan_account_number  VARCHAR2(35),
  branch_code          VARCHAR2(3),
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255),
  unique_seq_no        VARCHAR2(25)
)
/

-- Create table
create table STTM_CUST_ACCOUNT_CUSTOM
(
  branch_code          VARCHAR2(3) not null,
  cust_ac_no           VARCHAR2(20) not null,
  ccy                  VARCHAR2(3),
  cust_no              VARCHAR2(9),
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255)
)
/
alter table STTM_CUST_ACCOUNT_CUSTOM add primary key (BRANCH_CODE, CUST_AC_NO)
/
-- Create table
create table STTM_CUST_TD_REFERRAL_CUSTOM
(
  brn                  VARCHAR2(3) not null,
  acc                  VARCHAR2(20) not null,
  ccy                  VARCHAR2(3) not null,
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255)
)
/
alter table STTM_CUST_TD_REFERRAL_CUSTOM add primary key (BRN, ACC, CCY)
/
-- Create table
create table STTM_CUST_TD_REFERRAL_TEMP_CUSTOM
(
  brn                  VARCHAR2(3) not null,
  acc                  VARCHAR2(20) not null,
  ccy                  VARCHAR2(3) not null,
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255)
)
/
alter table STTM_CUST_TD_REFERRAL_TEMP_CUSTOM add primary key (BRN, ACC, CCY)
/
ALTER TABLE STTM_CUSTOMER_CUSTOM ADD (REFERRAL_PERSON VARCHAR2(105), RELATIONSHIP_OFFICER VARCHAR2(105), SALE_CHANNEL VARCHAR2(105))
/