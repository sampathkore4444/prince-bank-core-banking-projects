prompt Importing table LMTM_TYPE_VALUES...
set feedback off
set define off
insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'BFS (Business Financial Service)', 'BFS');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'Branches', 'BRN');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'Direct Sales', 'DS');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'MB (Mobile Banking)', 'MB');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'Merchant Team', 'MT');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'PCP (Private Client Portfolio)', 'PCP');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'PFS (Priority Financial Service)', 'PFS');

prompt Done.
