prompt Importing table LMTM_TYPE_OF_TYPES...
set feedback off
set define off
insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('SALE_CHANNEL', 'Types of sale channels', 'SAMPATH2', 'SAMPATH2', to_date('25-01-2022 16:14:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-01-2022 16:14:40', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

prompt Done.
