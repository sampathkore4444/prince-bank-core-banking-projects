CREATE OR REPLACE PACKAGE BODY clpks_cldaccnt_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : clpks_cldaccnt_custom.sql
  **
  ** Module     : Retail Lending
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2022 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'clpks_cldaccnt_Custom ==>' || p_Msg;
      Debug.Pr_Debug('CL', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION Fn_Post_Build_Type_Structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_cldaccnt         IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_Type_Structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Build_Type_Structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;
  
   --referral changes starts
  FUNCTION FN_GET_CUST_NAME(P_PERSON_TYPE IN VARCHAR2,
                            P_CUST_NO     IN VARCHAR2)
    RETURN STTM_CUSTOMER.CUSTOMER_NAME1%TYPE AS
  
    L_CUST_NAME STTM_CUSTOMER.CUSTOMER_NAME1%TYPE;
  
    L_REFERRAL_PERSON      STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;
    L_RELATIONSHIP_OFFICER STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;
  
  BEGIN
  
    IF P_PERSON_TYPE = 'RP' THEN
    
      DBG('P_CUST_NO=' || P_CUST_NO);
    
      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_CUST_NAME
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO = P_CUST_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NAME := NULL;
      END;
    
    END IF;
  
    IF P_PERSON_TYPE = 'RO' THEN
    
      DBG('P_CUST_NO=' || P_CUST_NO);
    
      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_CUST_NAME
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO = P_CUST_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NAME := NULL;
      END;
    
    END IF;
  
    DBG('L_CUST_NAME=' || L_CUST_NAME);
  
    RETURN L_CUST_NAME;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING THE CUSTOMER NAME');
    
      L_CUST_NAME := NULL;
      RETURN L_CUST_NAME;
    
  END FN_GET_CUST_NAME;
  --referral changes ends

  --sampath starts
  FUNCTION FN_GET_MID_RATE RETURN CYTM_RATES.MID_RATE%TYPE AS
    L_MID_RATE CYTM_RATES.MID_RATE%TYPE;
  BEGIN
    SELECT MID_RATE
      INTO L_MID_RATE
      FROM CYTM_RATES
     WHERE BRANCH_CODE = GLOBAL.current_branch
       AND CCY1 = 'USD'
       AND CCY2 = 'KHR'
       AND RATE_TYPE = 'STANDARD';

    RETURN L_MID_RATE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING MID RATE');
      DBG('ERROR CODE IN FN_GET_MID_RATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MID_RATE=' || SQLERRM);
      RETURN L_MID_RATE;
  END FN_GET_MID_RATE;
  --sampath ends

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                  p_cldaccnt         IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
    --sampath starts
    L_COUNT                       NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends

   --main and sub sector changes starts
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    L_SECTOR_COUNT                 NUMBER := 0;
    --main and sub sector changes ends
	
	 --referral changes starts
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM CLTB_ACCOUNT_REFERRAL_CUSTOM%ROWTYPE;
    L_REFERRAL_COUNT               NUMBER := 0;
    L_CUST_REF_COUNT               NUMBER := 0;
    L_CUST_REL_OFF_COUNT           NUMBER := 0;
    --referral changes ends

  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory..=' || P_ACTION_CODE);
    DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.SUBSYSTEMSTAT='||p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.SUBSYSTEMSTAT);

    IF Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED THEN
      DBG('SAVE CLICKED');
    ELSE
       DBG('SAVE NOT CLICKED');
    END IF;
    --sampath starts
    IF P_ACTION_CODE = 'NEW' /*AND Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED*/ THEN

      DBG('p_cldaccnt.v_loan_risk_score_custom.exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.term_conditions=' ||
          p_cldaccnt.v_loan_risk_score_custom.term_conditions);
      DBG('p_cldaccnt.v_loan_risk_score_custom.percentage_ltv=' ||
          p_cldaccnt.v_loan_risk_score_custom.percentage_ltv);
      DBG('p_cldaccnt.v_loan_risk_score_custom.purchased_prop=' ||
          p_cldaccnt.v_loan_risk_score_custom.purchased_prop);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_agency=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_agency);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_approach=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_approach);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_class=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_class);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_weight=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_weight);
      DBG('p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia=' ||
          p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia);
      DBG('p_cldaccnt.v_loan_risk_score_custom.remark=' ||
          p_cldaccnt.v_loan_risk_score_custom.remark);

      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);

        p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING,
                                                               0);
      END IF;

      IF p_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN

        L_LCY_OUTSTANDING := L_OUTSTANDING / FN_GET_MID_RATE;

        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);

        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;

        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);

        p_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                  0);

      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                  0);

      END IF;

      --Get Colltaeral Pool Amount

      BEGIN
        FOR G IN (SELECT *

                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCNT.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP

          IF G.POOL_CCY = 'KHR' THEN

            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;

          ELSE

            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;

          END IF;

        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;

      END;

      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);

      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;

      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);

      p_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := NVL(L_POOL_AMOUNT,
                                                               0);

      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;

      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;

      IF L_COUNT > 0 /*OR
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.exposure_type, '*')

                                                                                                                           AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.SUB_EXPOSURE_TYPE, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.percentage_ltv, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.percentage_ltv, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop_usd, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.total_collat_pool, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.total_collat_pool, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_agency, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.rating_agency, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_approach, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.rating_approach, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_class, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.risk_class, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_weight, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.risk_weight, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.out_in_cambodia, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.remark, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.remark, '*')*/
       THEN

        INSERT INTO CLTB_LOAN_RISK_SCORE_HIST (loan_account_number,
        branch_code,
        exposure_type,
        sub_exposure_type,
        term_conditions,
        percentage_ltv,
        purchased_prop,
        purchased_prop_usd,
        rating_agency,
        rating_approach,
        risk_class,
        risk_weight,
        out_in_cambodia,
        remark
        )
          SELECT *
            FROM CLTB_LOAN_RISK_SCORE_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);

        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type      = p_cldaccnt.v_loan_risk_score_custom.exposure_type,
               sub_exposure_type  = p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
               term_conditions    = p_cldaccnt.v_loan_risk_score_custom.term_conditions,
               percentage_ltv     = p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
               purchased_prop     = p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
               purchased_prop_usd = p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
               --total_collat_pool  = p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
               rating_agency   = p_cldaccnt.v_loan_risk_score_custom.rating_agency,
               rating_approach = p_cldaccnt.v_loan_risk_score_custom.rating_approach,
               risk_class      = p_cldaccnt.v_loan_risk_score_custom.risk_class,
               risk_weight     = p_cldaccnt.v_loan_risk_score_custom.risk_weight,
               out_in_cambodia = p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
               --lcy_outstanding    = p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
               remark = p_cldaccnt.v_loan_risk_score_custom.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;

      ELSE

        DBG('INSIDE ELSE CONDITION');

     /*   --Sub Exposure Type Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type

           AND SUB_EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-003', '');

          RETURN FALSE;

        END IF;

        --Term & Conditions Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type

           AND term_conditions =
               p_cldaccnt.v_loan_risk_score_custom.term_conditions;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-004', '');

          RETURN FALSE;

        END IF;

        --% LTV Validation pls check

        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '11_Exposures to Real Estate' THEN

          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_LOAN_RISK_SCORE_CUSTOM
           WHERE EXPOSURE_TYPE =
                 p_cldaccnt.v_loan_risk_score_custom.exposure_type
             AND percentage_ltv =
                 p_cldaccnt.v_loan_risk_score_custom.percentage_ltv;

          IF L_COUNT = 0 THEN

            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-005', '');

            RETURN FALSE;

          END IF;

        END IF;

        --Purchased Property Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND purchased_prop =
               p_cldaccnt.v_loan_risk_score_custom.purchased_prop;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-006', '');

          RETURN FALSE;

        END IF;

        --Purchased Property(USD) Field Validation
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '11_Exposures to Real Estate' THEN

          IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD IS NULL OR
             p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <= 0 THEN

            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-009', '');

            RETURN FALSE;

          END IF;

          --p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD := 0;

        ELSE

          IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <> 0 THEN

            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-010', '');

            RETURN FALSE;

          END IF;

        END IF;

        --Rating Agency Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_agency =
               p_cldaccnt.v_loan_risk_score_custom.rating_agency;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-007', '');

          RETURN FALSE;

        END IF;

        --Rating Approach Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_approach =
               p_cldaccnt.v_loan_risk_score_custom.rating_approach;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-008', '');

          RETURN FALSE;

        END IF;

        --Risk Class Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_approach =
               p_cldaccnt.v_loan_risk_score_custom.rating_approach

           AND risk_class = p_cldaccnt.v_loan_risk_score_custom.risk_class;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-001', '');

          RETURN FALSE;

        END IF;

        --Risk Weight Validation
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '5_Exposures to Non-Deposit Taking Institutions' THEN

          IF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
             'Short term (Up to 3month)' THEN

            IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
               ('40%', '75%', '100%', '150%') THEN

              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');

              RETURN FALSE;

            END IF;

          ELSIF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
                'Longer than 3 months' THEN

            IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
               ('20%', '50%', '100%', '150%') THEN

              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');

              RETURN FALSE;

            END IF;

          END IF;

        ELSE

          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_LOAN_RISK_SCORE_CUSTOM
           WHERE ((EXPOSURE_TYPE NOT IN
                 (select value
                      from lmtm_type_values
                     where type = 'RISK_SCORE') AND
                 EXPOSURE_TYPE =
                 p_cldaccnt.v_loan_risk_score_custom.exposure_type) OR
                 (EXPOSURE_TYPE IN
                 (select value
                      from lmtm_type_values
                     where type = 'RISK_SCORE') AND
                 TERM_CONDITIONS =
                 p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS))
             AND RISK_WEIGHT =
                 p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT;

          IF L_COUNT = 0 THEN

            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');

            RETURN FALSE;

          END IF;

        END IF;*/

        BEGIN
          insert into CLTB_LOAN_RISK_SCORE_CUSTOM
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             purchased_prop_usd,
             --total_collat_pool,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             --lcy_outstanding,
             REMARK)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_risk_score_custom.exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.term_conditions,
             p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
             --p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
             p_cldaccnt.v_loan_risk_score_custom.rating_agency,
             p_cldaccnt.v_loan_risk_score_custom.rating_approach,
             p_cldaccnt.v_loan_risk_score_custom.risk_class,
             p_cldaccnt.v_loan_risk_score_custom.risk_weight,
             p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
             --p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
             p_cldaccnt.v_loan_risk_score_custom.remark);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');

        END;
      END IF;

    --main and sub sector changes starts
      BEGIN
        SELECT COUNT(1)
          INTO L_SECTOR_COUNT
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_SECTOR_COUNT := 0;
      END;

      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;

      IF L_SECTOR_COUNT > 0 THEN

        INSERT INTO CLTB_LOAN_SECTOR_DTLS_CUSTOM
          (loan_account_number,
           branch_code,
           main_sector,
           sub_sector,
           of_which_sector)
          SELECT *
            FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);

        UPDATE CLTB_LOAN_SECTOR_DTLS_CUSTOM
           SET main_sector     = p_cldaccnt.v_loan_sector_dtls_custom.main_sector,
               sub_sector      = p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,
               of_which_sector = p_cldaccnt.v_loan_sector_dtls_custom.of_which_sector

         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;

      ELSE

        DBG('INSIDE ELSE CONDITION');

        BEGIN
          insert into CLTB_LOAN_SECTOR_DTLS_CUSTOM
            (loan_account_number,
             branch_code,
             main_sector,
             sub_sector,
             of_which_sector)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_sector_dtls_custom.main_sector,
             p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,
             p_cldaccnt.v_loan_sector_dtls_custom.of_which_sector);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');

        END;

         /*p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,1,instr(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,' ') - 1);
         p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC:= SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,instr(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,' ') + 1);

         p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,1,instr(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,' ') - 1);
         p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC:= SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,instr(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,' ') + 1);
*/

      END IF;
      --main and sub sector changes ends
	  
	  --referral changes starts
      BEGIN
        SELECT COUNT(1)
          INTO L_REFERRAL_COUNT
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_REFERRAL_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      IF L_REFERRAL_COUNT > 0 THEN
      
        INSERT INTO CLTB_ACCOUNT_REFERRAL_CUSTOM
          (loan_account_number,
           branch_code,
           referral_person,
           relationship_officer,
           sale_channel)
          SELECT *
            FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        UPDATE CLTB_ACCOUNT_REFERRAL_CUSTOM
           SET referral_person      = p_cldaccnt.v_account_referral_custom.referral_person,
               relationship_officer = p_cldaccnt.v_account_referral_custom.relationship_officer,
               sale_channel         = p_cldaccnt.v_account_referral_custom.sale_channel
        
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        --apple apple referral starts
        DBG('p_cldaccnt.v_cltbs_account_master.account_number=' ||
            p_cldaccnt.v_cltbs_account_master.account_number);
        DBG('p_cldaccnt.v_cltbs_account_master.branch_code=' ||
            p_cldaccnt.v_cltbs_account_master.branch_code);
        BEGIN
          SELECT *
            INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
            FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
            DBG('ERROR LINE NUMBER=' ||
                DBMS_UTILITY.format_error_backtrace);
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
        END;
      
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER);
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE);
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.REFERRAL_PERSON=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.REFERRAL_PERSON);
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER);
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.SALE_CHANNEL=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.SALE_CHANNEL);
        DBG('G_REFERRAL_PERSON=' || G_REFERRAL_PERSON);
        DBG('G_RELATIONSHIP_OFFICER=' || G_RELATIONSHIP_OFFICER);
      
        SELECT COUNT(1)
          INTO L_CUST_REF_COUNT
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO =
               p_cldaccnt.v_account_referral_custom.referral_person;
      
        DBG('L_CUST_REF_COUNT=' || L_CUST_REF_COUNT);
      
        SELECT COUNT(1)
          INTO L_CUST_REL_OFF_COUNT
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO =
               p_cldaccnt.v_account_referral_custom.relationship_officer;
      
        DBG('L_CUST_REL_OFF_COUNT=' || L_CUST_REL_OFF_COUNT);
      
        IF L_CUST_REF_COUNT = 0 AND L_CUST_REL_OFF_COUNT = 0 THEN
        
          BEGIN
            insert into CLTB_ACCOUNT_REFERRAL_CUSTOM
              (loan_account_number,
               branch_code,
               referral_person,
               relationship_officer,
               sale_channel)
            values
              (p_cldaccnt.v_cltbs_account_master.account_number,
               p_cldaccnt.v_cltbs_account_master.branch_code,
               G_REFERRAL_PERSON, --L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person,
               G_RELATIONSHIP_OFFICER, --L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer,
               p_cldaccnt.v_account_referral_custom.sale_channel);
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED WHILE INSERTING');
            
          END;
        
        ELSE
          --apple apple referral changes
        
          BEGIN
            insert into CLTB_ACCOUNT_REFERRAL_CUSTOM
              (loan_account_number,
               branch_code,
               referral_person,
               relationship_officer,
               sale_channel)
            values
              (p_cldaccnt.v_cltbs_account_master.account_number,
               p_cldaccnt.v_cltbs_account_master.branch_code,
               p_cldaccnt.v_account_referral_custom.referral_person,
               p_cldaccnt.v_account_referral_custom.relationship_officer,
               p_cldaccnt.v_account_referral_custom.sale_channel);
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED WHILE INSERTING');
            
          END;
        
        END IF; --apple apple referral changes
      
        /*p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,1,instr(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,' ') - 1);
                 p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC:= SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,instr(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,' ') + 1);
        
                 p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,1,instr(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,' ') - 1);
                 p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC:= SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,instr(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,' ') + 1);
        */
      
      END IF;
      --referral changes ends

    END IF;

    IF P_ACTION_CODE = 'DELETE' THEN

      DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_RISK_SCORE_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --and a.event_seq_no = p_cldpymnt.v_cltbs_liq.event_seq_no;

    --main and sub sector changes starts
      DELETE FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --main and sub sector changes ends
	  
	   --referral changes starts
      dbg('before deleting from CLTB_ACCOUNT_REFERRAL_CUSTOM');
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
          DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      G_REFERRAL_PERSON      := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.Referral_Person;
      G_RELATIONSHIP_OFFICER := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER;
    
      DELETE FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --referral changes ends

    END IF;

    --sampath ends

    Dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_cldaccnt         IN clpks_cldaccnt_Main.ty_cldaccnt,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

    Dbg('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    Dbg('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                      p_Source_Operation IN VARCHAR2,
                                      p_Function_Id      IN VARCHAR2,
                                      p_Action_Code      IN VARCHAR2,
                                      p_cldaccnt         IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                      p_Err_Code         IN OUT VARCHAR2,
                                      p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    Dbg('In Fn_Pre_Resolve_Ref_Numbers..');

    Dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Resolve_Ref_Numbers;
  FUNCTION Fn_Post_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_cldaccnt         IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    Dbg('In Fn_Post_Resolve_Ref_Numbers..');

    Dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of clpks_cldaccnt_Main.Fn_Post_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Resolve_Ref_Numbers;
  FUNCTION Fn_Pre_Product_Default(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                  p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Product_Default..');

    Dbg('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Product_Default;

  FUNCTION Fn_Post_Product_Default(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                   p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Product_Default..');

    Dbg('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Product_Default;

  FUNCTION Fn_Pre_Unlock(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN OUT VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Unlock..');

    Dbg('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Unlock;

  FUNCTION Fn_Post_Unlock(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN OUT VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Unlock');

    Dbg('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Unlock;

  FUNCTION Fn_Pre_Subsys_Pickup(p_Source           IN VARCHAR2,
                                p_Source_Operation IN VARCHAR2,
                                p_Function_Id      IN VARCHAR2,
                                p_Action_code      IN VARCHAR2,
                                p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Err_Code         IN OUT VARCHAR2,
                                p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Subsys_Pickup..');

    Dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Subsys_Pickup;

  FUNCTION Fn_Post_Subsys_Pickup(p_Source           IN VARCHAR2,
                                 p_Source_Operation IN VARCHAR2,
                                 p_Function_Id      IN VARCHAR2,
                                 p_Action_code      IN VARCHAR2,
                                 p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Err_Code         IN OUT VARCHAR2,
                                 p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Subsys_Pickup..');

    Dbg('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Subsys_Pickup;

  FUNCTION Fn_Pre_Enrich(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_id      IN VARCHAR2,
                         p_Action_code      IN VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Enrich..');

    Dbg('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Enrich ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Enrich;

  FUNCTION Fn_Post_Enrich(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Enrich..');

    Dbg('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Enrich ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Enrich;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
	
	 --referral changes starts
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM CLTB_ACCOUNT_REFERRAL_CUSTOM%ROWTYPE;
    --referral changes ends
	
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..');
	
	 --referral changes starts
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER);
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE);
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person);
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer);
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel);
    
      IF L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE IS NOT NULL THEN
      
        p_Wrk_cldaccnt.v_account_referral_custom.referral_person      := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person;
        p_Wrk_cldaccnt.v_account_referral_custom.relationship_officer := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer;
        p_Wrk_cldaccnt.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
      
      END IF;
    
      DBG('p_Wrk_cldaccnt.v_account_referral_custom.referral_person=' ||
          p_Wrk_cldaccnt.v_account_referral_custom.referral_person);
      DBG('p_Wrk_cldaccnt.v_account_referral_custom.relationship_officer=' ||
          p_Wrk_cldaccnt.v_account_referral_custom.relationship_officer);
      DBG('p_Wrk_cldaccnt.v_account_referral_custom.sale_channel=' ||
          p_Wrk_cldaccnt.v_account_referral_custom.sale_channel);
    
    END IF;
    --referral changes ends

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Process(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_Child_Function   IN VARCHAR2,
                          p_Multi_Trip_Id    IN VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Process..');

    Dbg('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Process;

  FUNCTION Fn_Post_Process(p_Source           IN VARCHAR2,
                           p_Source_Operation IN VARCHAR2,
                           p_Function_id      IN VARCHAR2,
                           p_Action_Code      IN VARCHAR2,
                           p_Child_Function   IN VARCHAR2,
                           p_Multi_Trip_Id    IN VARCHAR2,
                           p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Err_Code         IN OUT VARCHAR2,
                           p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS

   --sampath starts
    L_COUNT                       NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends

  --main and sub sector changes starts
    L_SECTOR_COUNT                 NUMBER := 0;
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    --main and sub sector changes ends
	
	--referral changes starts
    L_REFERRAL_COUNT               NUMBER := 0;
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM CLTB_ACCOUNT_REFERRAL_CUSTOM%ROWTYPE;
    L_CUST_REF_COUNT               NUMBER := 0;
    L_CUST_REL_OFF_COUNT           NUMBER := 0;
    --referral changes ends

  BEGIN

    Dbg('In Fn_Post_Process..='||p_Action_Code);

    --sampath starts

    IF P_ACTION_CODE = 'NEW' AND Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED THEN

      DBG('p_cldaccnt.v_loan_risk_score_custom.exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.term_conditions=' ||
          p_cldaccnt.v_loan_risk_score_custom.term_conditions);
      DBG('p_cldaccnt.v_loan_risk_score_custom.percentage_ltv=' ||
          p_cldaccnt.v_loan_risk_score_custom.percentage_ltv);
      DBG('p_cldaccnt.v_loan_risk_score_custom.purchased_prop=' ||
          p_cldaccnt.v_loan_risk_score_custom.purchased_prop);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_agency=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_agency);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_approach=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_approach);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_class=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_class);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_weight=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_weight);
      DBG('p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia=' ||
          p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia);
      DBG('p_cldaccnt.v_loan_risk_score_custom.remark=' ||
          p_cldaccnt.v_loan_risk_score_custom.remark);

          --Sub Exposure Type Validation
    SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type

           AND SUB_EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-003', '');

          RETURN FALSE;

        END IF;

        --Term & Conditions Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type

           AND term_conditions =
               p_cldaccnt.v_loan_risk_score_custom.term_conditions;

        IF L_COUNT = 0 THEN

 PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-004', '');

          RETURN FALSE;

        END IF;

        --% LTV Validation pls check

        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '11_Exposures to Real Estate' THEN

          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_LOAN_RISK_SCORE_CUSTOM
           WHERE EXPOSURE_TYPE =
                 p_cldaccnt.v_loan_risk_score_custom.exposure_type
             AND percentage_ltv =
                 p_cldaccnt.v_loan_risk_score_custom.percentage_ltv;

          IF L_COUNT = 0 THEN

            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-005', '');

            RETURN FALSE;

          END IF;

        END IF;

        --Purchased Property Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND purchased_prop =
               p_cldaccnt.v_loan_risk_score_custom.purchased_prop;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-006', '');

          RETURN FALSE;

        END IF;

        --Purchased Property(USD) Field Validation
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '11_Exposures to Real Estate' THEN

          IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD IS NULL OR
             p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <= 0 THEN

            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-009', '');

            RETURN FALSE;

          END IF;

          --p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD := 0;

        ELSE

          IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <> 0 THEN

            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-010', '');

            RETURN FALSE;

          END IF;

        END IF;

        --Rating Agency Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_agency =
               p_cldaccnt.v_loan_risk_score_custom.rating_agency;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-007', '');

          RETURN FALSE;

        END IF;

        --Rating Approach Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_approach =
               p_cldaccnt.v_loan_risk_score_custom.rating_approach;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-008', '');

          RETURN FALSE;

        END IF;

        --Risk Class Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_approach =
               p_cldaccnt.v_loan_risk_score_custom.rating_approach

           AND risk_class = p_cldaccnt.v_loan_risk_score_custom.risk_class;

        IF L_COUNT = 0 THEN

          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-001', '');

          RETURN FALSE;

        END IF;

        --Risk Weight Validation
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '5_Exposures to Non-Deposit Taking Institutions' THEN

          IF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
             'Short term (Up to 3month)' THEN

            IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
               --('40%', '75%', '100%', '150%') THEN
               ('20%', '50%', '100%', '150%') THEN

              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');

              RETURN FALSE;

            END IF;

          ELSIF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
                'Longer than 3 months' THEN

            IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
               --('20%', '50%', '100%', '150%') THEN
               ('40%', '75%', '100%', '150%') THEN

              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');

              RETURN FALSE;

            END IF;

          END IF;

        ELSE

          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_LOAN_RISK_SCORE_CUSTOM
           WHERE ((EXPOSURE_TYPE NOT IN
                 (select value
                      from lmtm_type_values
                     where type = 'RISK_SCORE') AND
                 EXPOSURE_TYPE =
                 p_cldaccnt.v_loan_risk_score_custom.exposure_type) OR
                 (EXPOSURE_TYPE IN
                 (select value
                      from lmtm_type_values
                     where type = 'RISK_SCORE') AND
                 TERM_CONDITIONS =
                 p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS))
             AND RISK_WEIGHT =
                 p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT;

          IF L_COUNT = 0 THEN

            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');

            RETURN FALSE;

          END IF;

        END IF;


      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER='||p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE='||p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);

      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);

        p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING,
                                                               0);
      END IF;

      IF p_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN

        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING,0) / FN_GET_MID_RATE;

        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);

        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;

        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);

        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                  0);

      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                  0);

      END IF;

      --Get Colltaeral Pool Amount

      BEGIN
        FOR G IN (SELECT *

                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCNT.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP

          IF G.POOL_CCY = 'KHR' THEN

            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;

          ELSE

            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;

          END IF;

        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;

      END;

      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);

      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;

      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);

      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := NVL(L_POOL_AMOUNT,
                                                               0);

      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;

      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;

      IF L_COUNT > 0 /*OR
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.exposure_type, '*')

                                                                                                                           AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.SUB_EXPOSURE_TYPE, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.percentage_ltv, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.percentage_ltv, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop_usd, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.total_collat_pool, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.total_collat_pool, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_agency, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.rating_agency, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_approach, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.rating_approach, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_class, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.risk_class, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_weight, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.risk_weight, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.out_in_cambodia, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.remark, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.remark, '*')*/
       THEN

        INSERT INTO CLTB_LOAN_RISK_SCORE_HIST(loan_account_number,
        branch_code,
        exposure_type,
        sub_exposure_type,
        term_conditions,
        percentage_ltv,
        purchased_prop,
        purchased_prop_usd,
        rating_agency,
        rating_approach,
        risk_class,
        risk_weight,
        out_in_cambodia,
        remark)
          SELECT *
            FROM CLTB_LOAN_RISK_SCORE_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);

        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type      = p_cldaccnt.v_loan_risk_score_custom.exposure_type,
               sub_exposure_type  = p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
               term_conditions    = p_cldaccnt.v_loan_risk_score_custom.term_conditions,
               percentage_ltv     = p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
               purchased_prop     = p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
               purchased_prop_usd = p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
               --total_collat_pool  = p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24,
               rating_agency   = p_cldaccnt.v_loan_risk_score_custom.rating_agency,
               rating_approach = p_cldaccnt.v_loan_risk_score_custom.rating_approach,
               risk_class      = p_cldaccnt.v_loan_risk_score_custom.risk_class,
               risk_weight     = p_cldaccnt.v_loan_risk_score_custom.risk_weight,
               out_in_cambodia = p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
               --lcy_outstanding    = p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25,
               remark = p_cldaccnt.v_loan_risk_score_custom.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;

      ELSE

        DBG('INSIDE ELSE CONDITION');



        BEGIN
          insert into CLTB_LOAN_RISK_SCORE_CUSTOM
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             purchased_prop_usd,
             --total_collat_pool,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             --lcy_outstanding,
             REMARK)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_risk_score_custom.exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.term_conditions,
             p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
             --p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
             p_cldaccnt.v_loan_risk_score_custom.rating_agency,
             p_cldaccnt.v_loan_risk_score_custom.rating_approach,
             p_cldaccnt.v_loan_risk_score_custom.risk_class,
             p_cldaccnt.v_loan_risk_score_custom.risk_weight,
             p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
             --p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
             p_cldaccnt.v_loan_risk_score_custom.remark);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');

        END;
      END IF;

    --main and sub sector changes starts

      --Sub Sector Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SECTOR_DETAILS
       WHERE MAIN_SECTOR_CODE || ' ' || MAIN_SECTOR_DESC =
             p_cldaccnt.v_loan_sector_dtls_custom.main_sector

         AND SUB_SECTOR_CODE || ' ' || SUB_SECTOR_DESC =
             p_cldaccnt.v_loan_sector_dtls_custom.SUB_SECTOR;

      IF L_COUNT = 0 THEN

        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-011', '');

        RETURN FALSE;

      END IF;

      --of-which Sector Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SECTOR_DETAILS
       WHERE MAIN_SECTOR_CODE || ' ' || MAIN_SECTOR_DESC =
             p_cldaccnt.v_loan_sector_dtls_custom.main_sector

         AND SUB_SECTOR_CODE || ' ' || SUB_SECTOR_DESC =
             p_cldaccnt.v_loan_sector_dtls_custom.SUB_SECTOR
        AND DECODE(OF_WHICH_SECTOR_CODE, NULL,OF_WHICH_SECTOR_DESC, OF_WHICH_SECTOR_CODE || ' ' || OF_WHICH_SECTOR_DESC) =
             p_cldaccnt.v_loan_sector_dtls_custom.OF_WHICH_SECTOR;

      IF L_COUNT = 0 THEN

        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-012', '');

        RETURN FALSE;

      END IF;

      BEGIN
        SELECT COUNT(1)
          INTO L_SECTOR_COUNT
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_SECTOR_COUNT := 0;
      END;

      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;

      IF L_SECTOR_COUNT > 0 THEN

        INSERT INTO CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
          (loan_account_number,
           branch_code,
           main_sector,
           sub_sector,
           of_which_sector)
          SELECT *
            FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);

        UPDATE CLTB_LOAN_SECTOR_DTLS_CUSTOM
           SET main_sector     = p_cldaccnt.v_loan_sector_dtls_custom.main_sector,
               sub_sector      = p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,
               of_which_sector = p_cldaccnt.v_loan_sector_dtls_custom.of_which_sector

         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;

      ELSE

        DBG('INSIDE ELSE CONDITION');

        BEGIN
          insert into CLTB_LOAN_SECTOR_DTLS_CUSTOM
            (loan_account_number,
             branch_code,
             main_sector,
             sub_sector,
             of_which_Sector)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_sector_dtls_custom.main_sector,
             p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,
             p_cldaccnt.v_loan_sector_dtls_custom.of_which_sector);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');

        END;
      END IF;
      --main and sub sector changes ends
	  
	  --referral changes starts
    
      --referral Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO =
             p_cldaccnt.v_account_referral_custom.referral_person;
    
      -- IF L_COUNT = 0 THEN
    
      --     PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-011', '');
    
      --   RETURN FALSE;
    
      -- END IF;
    
      --relationship_officer Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO =
             p_cldaccnt.v_account_referral_custom.relationship_officer;
    
      -- IF L_COUNT = 0 THEN
    
      -- PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-012', '');
    
      --  RETURN FALSE;
    
      --  END IF;
    
      IF p_cldaccnt.v_account_referral_custom.SALE_CHANNEL IS NULL THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-013', '');
      
        RETURN FALSE;
      
      END IF;
      
      /* IF p_cldaccnt.v_account_referral_custom.REFERRAL_PERSON IS NULL THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-014', '');
      
        RETURN FALSE;
        
        END IF;
        */
        IF p_cldaccnt.v_account_referral_custom.RELATIONSHIP_OFFICER IS NULL THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-015', '');
      
        RETURN FALSE;
        
        END IF;
    
      BEGIN
        SELECT COUNT(1)
          INTO L_REFERRAL_COUNT
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_REFERRAL_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      IF L_REFERRAL_COUNT > 0 THEN
      
        INSERT INTO CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST
          (loan_account_number,
           branch_code,
           referral_person,
           relationship_officer,
           sale_channel)
          SELECT *
            FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        DBG('Before updating CLTB_ACCOUNT_REFERRAL_CUSTOM');
      
        SELECT COUNT(1)
          INTO L_CUST_REF_COUNT
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO =
               p_cldaccnt.v_account_referral_custom.referral_person;
      
        DBG('L_CUST_REF_COUNT=' || L_CUST_REF_COUNT);
      
        SELECT COUNT(1)
          INTO L_CUST_REL_OFF_COUNT
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO =
               p_cldaccnt.v_account_referral_custom.relationship_officer;
      
        DBG('L_CUST_REL_OFF_COUNT=' || L_CUST_REL_OFF_COUNT);
      
        IF L_CUST_REF_COUNT = 0 AND L_CUST_REL_OFF_COUNT = 0 THEN
        
          UPDATE CLTB_ACCOUNT_REFERRAL_CUSTOM
             SET referral_person      = G_REFERRAL_PERSON, -- p_cldaccnt.v_account_referral_custom.referral_person,
                 relationship_officer = G_RELATIONSHIP_OFFICER, --p_cldaccnt.v_account_referral_custom.relationship_officer,
                 sale_channel         = p_cldaccnt.v_account_referral_custom.sale_channel
          
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code;
        
        ELSE
        
          UPDATE CLTB_ACCOUNT_REFERRAL_CUSTOM
             SET referral_person      = p_cldaccnt.v_account_referral_custom.referral_person,
                 relationship_officer = p_cldaccnt.v_account_referral_custom.relationship_officer,
                 sale_channel         = p_cldaccnt.v_account_referral_custom.sale_channel
          
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code;
        
        END IF;
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_ACCOUNT_REFERRAL_CUSTOM
            (loan_account_number,
             branch_code,
             referral_person,
             relationship_officer,
             sale_channel)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_account_referral_custom.referral_person,
             p_cldaccnt.v_account_referral_custom.relationship_officer,
             p_cldaccnt.v_account_referral_custom.sale_channel);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
          
        END;
      END IF;
      --referral changes ends

    END IF;

    IF P_ACTION_CODE = 'DELETE' THEN

      DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_RISK_SCORE_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --and a.event_seq_no = p_cldpymnt.v_cltbs_liq.event_seq_no;

    --main and sub sector changes starts
      DELETE FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --main and sub sector changes ends
	  
	  --referral changes starts
      dbg('before deleting from CLTB_ACCOUNT_REFERRAL_CUSTOM');
      DELETE FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --referral changes ends

    END IF;

    --sampath ends



    Dbg('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Process;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                        p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS

    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends

   --main and sub sector changes starts
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;

    --main and sub sector changes ends
	
	--referral changes starts
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM CLTB_ACCOUNT_REFERRAL_CUSTOM%ROWTYPE;
    --referral changes ends
	

  BEGIN

    Dbg('In Fn_Pre_Query..');

    --sampath starts
    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN

      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);

      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;

      --Get Colltaeral Pool Amount

      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID);

      BEGIN
        FOR G IN (SELECT *

                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP

          IF G.POOL_CCY = 'KHR' THEN

            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;

          ELSE

            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;

          END IF;

        END LOOP;

      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;

      END;

      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);

      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;

      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);

      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := L_POOL_AMOUNT;

    --main and sub sector changes starts
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);

      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;

      --main and sub sector changes ends

		
		--referral changes starts
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      --referral changes ends
	  
      --LCY Outstanding
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);

        --p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING, 0);
      END IF;

      IF p_Wrk_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN

        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING, 0) / FN_GET_MID_RATE;

        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);

        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;

        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);

        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);

      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);

      END IF;

      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);

        p_Wrk_cldaccnt.v_loan_risk_score_custom.exposure_type      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.sub_exposure_type  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.term_conditions    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.percentage_ltv     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP_USD;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.total_collat_pool  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TOTAL_COLLAT_POOL;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_agency   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_approach := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_class      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_weight     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.out_in_cambodia := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.lcy_outstanding    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;

     --main and sub sector changes starts
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.main_sector     := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector;
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.sub_sector      := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.SUB_SECTOR;
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.of_which_sector := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.OF_WHICH_SECTOR;

        DBG('ORANGE100');
      -- DBG(P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR);
       --DBG(P_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR);

        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') + 1); --L_TB_UDF(L_UDF_IDX).FIELD_DESC;
        --P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIELD_CHAR_8 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') + 1);

         --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') - 1);
         --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR := 'apple1';
         --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LOV_FIELD_CHAR := 'apple2';
         --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC:= SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') + 1);
         --P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIELD_CHAR_8 := 'apple1';

         --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,' ') - 1);
         --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC:= SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,' ') + 1);


        --DBG('ORANGE100='||P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIELD_CHAR_8);
        --DBG(P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR);

        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).NAME_FIELD_CHAR := L_TB_UDF(L_UDF_IDX)
        --                                                             .FIELD_NAME;

        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LOV_FIELD_CHAR := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') - 1); --FN_UDF_LOV_REQUIRED(L_TB_UDF(L_UDF_IDX).FIELD_NAME);

        --main and sub sector changes ends
		
		--referral changes starts
        --IF P_ACTION_CODE NOT IN ('EXECUTEQUERY') THEN
      
        p_Wrk_cldaccnt.v_account_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person);
        p_Wrk_cldaccnt.v_account_referral_custom.relationship_officer := FN_GET_CUST_NAME('RO',
                                                                                          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer);
        p_Wrk_cldaccnt.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
      
        --  END IF;
        --referral changes ends

      END IF;

    END IF;
	
	--referral changes starts
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      p_Wrk_cldaccnt.v_account_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                        L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person);
      p_Wrk_cldaccnt.v_account_referral_custom.relationship_officer := FN_GET_CUST_NAME('RO',
                                                                                        L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer);
      p_Wrk_cldaccnt.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
    
    END IF;
    --referral changes ends

    --sampath ends

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Query ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS

    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends

  --main and sub sector changes starts
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;

    --main and sub sector changes ends
	
	--referral changes starts
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM CLTB_ACCOUNT_REFERRAL_CUSTOM%ROWTYPE;
    --referral changes ends

  BEGIN

    dbg('In Fn_Post_Query=' || P_ACTION_CODE);

    --sampath starts
    IF P_ACTION_CODE IN ('NEW', 'SUBSYSPKP_NEW', 'EXECUTEQUERY', 'SUBSYSPKP_MODIFY') THEN --referral changes added SUBSYSPKP_MODIFY

      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);

      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;

      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID1=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID);

      --Get Colltaeral Pool Amount

      BEGIN
        FOR G IN (SELECT *

                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP

          IF G.POOL_CCY = 'KHR' THEN

            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;

          ELSE

            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;

          END IF;

        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;

      END;

      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);

      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;

      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);

      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := L_POOL_AMOUNT;

      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);

      --LCY Outstanding
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);

        -- p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING, 0);
      END IF;

      IF p_Wrk_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN

        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING, 0) / FN_GET_MID_RATE;

        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);

        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;

        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);

        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);

      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);

      END IF;

    --main and sub sector changes starts
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);

      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;

      --main and sub sector changes ends
	  
	  --referral changes starts
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      --referral changes ends
	  

      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);

        p_Wrk_cldaccnt.v_loan_risk_score_custom.exposure_type      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.sub_exposure_type  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.term_conditions    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.percentage_ltv     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP_USD;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.total_collat_pool  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TOTAL_COLLAT_POOL;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_agency   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_approach := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_class      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_weight     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.out_in_cambodia := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.lcy_outstanding    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;

    --main and sub sector changes starts
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.main_sector     := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector;
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.sub_sector      := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.SUB_SECTOR;
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.of_which_sector := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.OF_WHICH_SECTOR;

       -- DBG('P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR=' || P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8)
        --    .LBL_FIELD_CHAR);

      --  P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector; --L_TB_UDF(L_UDF_IDX).FIELD_DESC;

      --  DBG('P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR=' || P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8)
        --    .LBL_FIELD_CHAR);

        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).NAME_FIELD_CHAR := L_TB_UDF(L_UDF_IDX)
        --                                                             .FIELD_NAME;

      --  DBG('P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).LOV_FIELD_CHAR=' || P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4)
       --     .LOV_FIELD_CHAR);

       -- P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).LBL_FIELD_CHAR := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.SUB_SECTOR; --FN_UDF_LOV_REQUIRED(L_TB_UDF(L_UDF_IDX).FIELD_NAME);

       -- DBG('P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).LBL_FIELD_CHAR=' || P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4)
        --    .LBL_FIELD_CHAR);

         /*P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') - 1);
         --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR := 'apple1';
         --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LOV_FIELD_CHAR := 'apple2';
         P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC:= SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') + 1);
         --P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIELD_CHAR_8 := 'apple1';

         P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,' ') - 1);
         P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC:= SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,' ') + 1);
*/

        --main and sub sector changes ends
		
		--referral changes starts
        IF P_ACTION_CODE NOT IN ('SUBSYSPKP_NEW') THEN
        
          p_Wrk_cldaccnt.v_account_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person);
          p_Wrk_cldaccnt.v_account_referral_custom.relationship_officer := FN_GET_CUST_NAME('RO',
                                                                                            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer);
          p_Wrk_cldaccnt.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
        
        ELSE
        
          p_Wrk_cldaccnt.v_account_referral_custom.referral_person      := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person;
          p_Wrk_cldaccnt.v_account_referral_custom.relationship_officer := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer;
          p_Wrk_cldaccnt.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
        
        END IF;
        --referral changes ends    

      END IF;
	  
	  --referral changes starts
      IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      
        BEGIN
          SELECT *
            INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
            FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
           where a.LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             and a.branch_code =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             and rowid in
                 (SELECT MAX(ROWID)
                    FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
        
        EXCEPTION
          WHEN OTHERS THEN
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
        END;
      
        p_Wrk_cldaccnt.v_account_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person);
        p_Wrk_cldaccnt.v_account_referral_custom.relationship_officer := FN_GET_CUST_NAME('RO',
                                                                                          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer);
        p_Wrk_cldaccnt.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
      
      END IF;
      --referral changes ends

    END IF;

    --sampath ends

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_post_query;

END clpks_cldaccnt_custom;
