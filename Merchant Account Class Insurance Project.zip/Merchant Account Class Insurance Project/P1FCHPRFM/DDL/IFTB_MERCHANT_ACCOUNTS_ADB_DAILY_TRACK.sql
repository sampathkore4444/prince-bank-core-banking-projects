-- Create table
create table IFTB_MERCHANT_ACCOUNTS_ADB_DAILY_TRACK
(
  customer_no                   VARCHAR2(9),
  cust_ac_no                    VARCHAR2(20),
  cust_ac_brn                   VARCHAR2(3),
  ccy                           VARCHAR2(3),
  adb_calc_date                 DATE,
  acy_withdrawable_bal          NUMBER(22,3),
  days_from_today_till_monthend NUMBER(5),
  bal_as_of_yesterday           NUMBER(22,3),
  no_of_days_in_month           NUMBER(5),
  adb_result_in_usd             NUMBER(22,3),
  adb_result_in_khr             NUMBER(22,3),
  insurance_coverage            CHAR(1),
  job_run_time                  DATE
)
/
alter table IFTB_MERCHANT_ACCOUNTS_ADB_DAILY_TRACK add primary key (CUSTOMER_NO, CUST_AC_NO, CUST_AC_BRN, CCY, ADB_CALC_DATE)
/