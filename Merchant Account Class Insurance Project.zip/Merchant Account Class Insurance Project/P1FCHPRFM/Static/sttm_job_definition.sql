prompt Importing table sttm_job_definition...
set feedback off
set define off
insert into sttm_job_definition (JOB_CODE, JOB_GROUP, JOB_DESCRIPTION, SCHEDULER, TRG_TYPE, CRON_EXPR, JOB_TYPE, JOB_CLASS_OR_PROC, SIMPLE_TRG_REPEAT, SIMPLE_TRG_FREQUENCY, TRIGGER_LISTENER, ACTIVE, JNDI_NAME, LOGGING_REQD, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID, SCHED_TYPE, VETO_BLK_TRG, PRIORITY, MSG_QUEUE, MAX_NO_INSTANCES, STARTUP_MODE)
values ('PR_PROCESS_MER_ACCOUNTS_ADB', 'PLSQL', 'Job to process Merchant-Accounts for Personal Accident Coverage', 'SchedulerFactory', 'C', '0 13 8 1/1 * ? *', 'PLSQL', 'IFPKS_MERCHANT_PA_UTILS.PR_PROCESS_MERCHANTACCS_ADB', -1, null, null, 'Y', 'jdbc/fcjdevDS', 'Y', 'A', to_date('31-10-2022 08:10:37', 'dd-mm-yyyy hh24:mi:ss'), 'CSOTTHORN', to_date('31-10-2022 08:10:37', 'dd-mm-yyyy hh24:mi:ss'), 34, 'Y', 'O', 'CSOTTHORN', 'QUARTZ', 'N', 5, null, 1, 'M');

prompt Done.
