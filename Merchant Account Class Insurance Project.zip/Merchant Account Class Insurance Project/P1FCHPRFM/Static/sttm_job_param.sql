prompt Importing table sttm_job_param...
set feedback off
set define off
insert into sttm_job_param (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('PR_PROCESS_MER_ACCOUNTS_ADB', 'NAME', 'VARCHAR', 'OFSS');

prompt Done.
