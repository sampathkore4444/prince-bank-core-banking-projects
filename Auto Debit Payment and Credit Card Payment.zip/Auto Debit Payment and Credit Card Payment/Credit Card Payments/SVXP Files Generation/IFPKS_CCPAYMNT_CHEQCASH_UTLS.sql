CREATE OR REPLACE PACKAGE BODY IFPKS_CCPAYMNT_CHEQCASH_UTLS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_CCPAYMNT_CHEQCASH_UTLS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_GET_SVXP_TEMPLATE RETURN CLOB IS
  
    L_CLOB CLOB;
  
  BEGIN
    DBG('START OF FN_GET_SVXP_TEMPLATE');
  
    L_CLOB := '<clearing xmlns="http://bpc.ru/sv/SVXP/clearing">
  <file_type>FLTP1700</file_type>
  <operation>
    <oper_type>OPTP0028</oper_type>
    <msg_type>MSGTPRES</msg_type>
    <sttl_type>STTT0000</sttl_type>
    <oper_date>$L_DATE</oper_date>
    <oper_amount>
      <amount_value>$L_AMOUNT</amount_value>
      <currency>$L_ISO_CCY_CODE</currency>
    </oper_amount>
    <status>OPST0100</status>
    <is_reversal>0</is_reversal>
    <originator_refnum>$L_REFERENCE_NO</originator_refnum>
    <issuer>
      <client_id_type>CITPACCT</client_id_type>
      <client_id_value>$L_CREDIT_CARD_AC_NO</client_id_value>
      <inst_id>1001</inst_id>
      <network_id>1001</network_id>
    </issuer>
    <note>
      <note_type>NTTPUSER </note_type>
      <note_content language="LANGENG">
        <note_header>Payment from CBS</note_header>
        <note_text>Customer did payment from cbs</note_text>
      </note_content>
    </note>
  </operation>
</clearing>';
  
    RETURN L_CLOB;
  
    DBG('END OF FN_GET_SVXP_TEMPLATE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_SVXP_TEMPLATE');
      DBG('ERROR CODE IN FN_GET_SVXP_TEMPLATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_SVXP_TEMPLATE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN FN_GET_SVXP_TEMPLATE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
  END FN_GET_SVXP_TEMPLATE;

  PROCEDURE PR_WRITE_CLOB_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                  P_IN_FILE_NAME IN VARCHAR2,
                                  P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_CLOB_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_CLOB_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_CLOB_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_CLOB_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_CLOB_TO_FILE;

  --Simple Job to process incoming fast transactions
  PROCEDURE PR_PROCESS_CCPAYMENTS(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    DEBUG.PR_DEBUG('IF', 'Inside PR_PROCESS_CCPAYMENTS');
  
    DEBUG.PR_DEBUG('IF', 'paramName = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'paramValue = ' || PARAMVALUE);
  
    PR_GEN_CCPAYMNT_SVXP_FILE;
  
    DEBUG.PR_DEBUG('IF', 'Successful return from PR_PROCESS_CCPAYMENTS');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'Exception during PR_PROCESS_CCPAYMENTS' || SQLERRM);
  END PR_PROCESS_CCPAYMENTS;

  PROCEDURE PR_GEN_CCPAYMNT_SVXP_FILE IS
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
    L_RESP_CODE     VARCHAR2(10);
  BEGIN
  
    GLOBAL.pr_init('001', 'SYSTEM');
    DBG('START OF PR_GEN_CCPAYMNT_SVXP_FILE');
  
    FOR G IN (SELECT A.*, B.CHAR_FIELD6
                FROM IFTB_CREDIT_CARD_PYMNT_BY_CASH A, CSTB_UI_COLUMNS B
               WHERE A.TRN_REF_NO = B.CHAR_FIELD1
                 AND A.AUTH_STAT = 'A') LOOP
    
      L_RESP_TEMPLATE := FN_GET_SVXP_TEMPLATE;
    
      L_FILE_NAME := 'SVXP_OUTGOING_PAYMENT_' || GLOBAL.APPLICATION_DATE;
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_DATE',
                                 G.PAYMENT_DATE);
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_AMOUNT',
                                 G.payment_amt /*G.TXN_AMOUNT*/);
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 '840' /*G.ISO_CCY_CODE*/);
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_REFERENCE_NO',
                                 G.trn_ref_no /*G.TXN_AMOUNT*/);
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_CREDIT_CARD_AC_NO',
                                 G.CREDIT_CARD_AC_NO /*G.TXN_AMOUNT*/);
    
      L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
    
    --L_RESP_TEMPLATE := NULL;
    
    END LOOP;
  
    DBG('DONE WITH GENERATING CLOB RESPONSE');
  
    --Write to output file
    DBG('START OF WRITING CLOB TO AN XML FILE');
    PR_WRITE_CLOB_TO_FILE('/u01/fcubs/interfaces',
                          REPLACE(L_FILE_NAME, 'REQ', 'RES') || '.XML',
                          L_RESP_CLOB);
  
    DBG('END OF WRITING CLOB TO AN XML FILE');
  
    DBG('END OF PR_GEN_CCPAYMNT_SVXP_FILE');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GEN_CCPAYMNT_SVXP_FILE');
      DBG('ERROR CODE IN PR_GEN_CCPAYMNT_SVXP_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GEN_CCPAYMNT_SVXP_FILE=' || SQLERRM);
  END PR_GEN_CCPAYMNT_SVXP_FILE;

END IFPKS_CCPAYMNT_CHEQCASH_UTLS;
/