insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFDCCPCD', 'Teller', 'Credit Card Payment', 'Payment By In House Cheque Deposit', null, null, null, 'Credit Card Payment By In House Cheque Deposit', 'IFDCCPCD');

insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFSCCPCD', 'Teller', 'View', 'Credit Card Payment By In House Cheque Deposit Summary', null, null, null, 'Payment By In House Cheque Deposit Summary', 'IFDCCPCD');

COMMIT;
