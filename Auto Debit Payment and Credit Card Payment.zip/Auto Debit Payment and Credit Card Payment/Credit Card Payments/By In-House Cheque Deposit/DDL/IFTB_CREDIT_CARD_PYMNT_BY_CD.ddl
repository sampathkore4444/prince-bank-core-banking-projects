-- Create table
create table IFTB_CREDIT_CARD_PYMNT_BY_CD
(
  trn_ref_no        VARCHAR2(16) PRIMARY KEY,
  txn_gl_no         VARCHAR2(20),
  txn_gl_ccy        VARCHAR2(3),
  off_acc           VARCHAR2(20),
  off_ccy           VARCHAR2(3),
  off_check_no      VARCHAR2(16),
  off_check_date    DATE,
  off_amount        NUMBER(22,3),
  paymnt_ccy        VARCHAR2(3),
  payment_amt       NUMBER(22,3),
  narrative         VARCHAR2(250),
  record_stat       CHAR(1),
  auth_stat         CHAR(1),
  mod_no            NUMBER(4),
  maker_id          VARCHAR2(12),
  maker_dt_stamp    DATE,
  checker_id        VARCHAR2(12),
  checker_dt_stamp  DATE,
  once_auth         CHAR(1),
  exch_rate         NUMBER(24,12),
  credit_card_ac_no VARCHAR2(20),
  payment_date      DATE
)
/
CREATE OR REPLACE SYNONYM IFTBS_CREDIT_CARD_PYMNT_BY_CD FOR IFTB_CREDIT_CARD_PYMNT_BY_CD
/