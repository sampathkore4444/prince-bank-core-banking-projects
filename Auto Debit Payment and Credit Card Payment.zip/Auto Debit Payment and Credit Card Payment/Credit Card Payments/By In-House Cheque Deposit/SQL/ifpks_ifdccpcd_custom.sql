CREATE OR REPLACE PACKAGE BODY ifpks_ifdccpcd_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdccpcd_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2019 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdccpcd_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    --This is for makeReverse API
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>',
                              NULL);
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns:ns4="http://sv.bpc.in/SVAP/iss" xmlns:ns3="http://bpc.ru/SVIS/ewallet/v1.0/" xmlns:ns2="http://bpc.ru/common/types/v0.1/" xmlns="http://bpc.ru/SVIS/cmsSvng/v1.1/"',
                              NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML, 'ns2:', NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</soap:Body></soap:Envelope>',
                              NULL);
  
  END PR_RETURN_COSMETIC_XML;
  
  FUNCTION FN_GET_MAS_VIS_GL_CREDIT_CARD(P_CARD_TYPE IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.VALUE%TYPE IS
    L_MAS_VIS_CARD_GL LMTM_TYPE_VALUES.VALUE%TYPE;
  BEGIN
    BEGIN
      SELECT B.VALUE
        INTO L_MAS_VIS_CARD_GL
        FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
       WHERE A.TYPE = B.TYPE
         AND A.TYPE = 'CREDIT_CARD_ACCS'
         AND B.CODE = P_CARD_TYPE
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A';
    EXCEPTION
      WHEN OTHERS THEN
        L_MAS_VIS_CARD_GL := NULL;
    END;
    RETURN L_MAS_VIS_CARD_GL;
  EXCEPTION
    WHEN OTHERS THEN
      L_MAS_VIS_CARD_GL := NULL;
    
      RETURN L_MAS_VIS_CARD_GL;
  END FN_GET_MAS_VIS_GL_CREDIT_CARD;

  FUNCTION FN_GET_ISO_CURRENCY_CODE(P_ISO_CCY IN VARCHAR2)
    RETURN CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE AS
    L_CCY_CODE CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE;
  BEGIN
    BEGIN
      SELECT CCY_CODE
        INTO L_CCY_CODE
        FROM CYTMS_CCY_DEFN_MASTER
       WHERE ISO_NUM_CCY_CODE = P_ISO_CCY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      RETURN L_CCY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN L_CCY_CODE;
    END;
    RETURN L_CCY_CODE;
  END FN_GET_ISO_CURRENCY_CODE;

  FUNCTION FN_GET_SVXP_TEMPLATE RETURN CLOB IS
  
    L_CLOB CLOB;
  
  BEGIN
    DBG('START OF FN_GET_SVXP_TEMPLATE');
  
    L_CLOB := '<clearing xmlns="http://bpc.ru/sv/SVXP/clearing">
  <file_type>FLTP1700</file_type>
  <operation>
    <oper_type>OPTP0028</oper_type>
    <msg_type>MSGTPRES</msg_type>
    <sttl_type>STTT0000</sttl_type>
    <oper_date>$L_DATE</oper_date>
    <oper_amount>
      <amount_value>$L_AMOUNT</amount_value>
      <currency>$L_ISO_CCY_CODE</currency>
    </oper_amount>
    <status>OPST0100</status>
    <is_reversal>0</is_reversal>
    <originator_refnum>$L_REFERENCE_NO</originator_refnum>
    <terminal_number>EPIN0001</terminal_number>
    <merchant_number>EPIN_MERCHANT</merchant_number>
    <issuer>
      <client_id_type>CITPACCT</client_id_type>
      <client_id_value>$L_CREDIT_CARD_AC_NO</client_id_value>
      <inst_id>1001</inst_id>
      <network_id>1001</network_id>
    </issuer>
    <acquirer>
            <inst_id>1001</inst_id>
    </acquirer>
    <note>
      <note_type>NTTPUSER </note_type>
      <note_content language="LANGENG">
        <note_header>Payment from CBS</note_header>
        <note_text>Customer did payment from cbs</note_text>
      </note_content>
    </note>
  </operation>
</clearing>';
  
    RETURN L_CLOB;
  
    DBG('END OF FN_GET_SVXP_TEMPLATE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_SVXP_TEMPLATE');
      DBG('ERROR CODE IN FN_GET_SVXP_TEMPLATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_SVXP_TEMPLATE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN FN_GET_SVXP_TEMPLATE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
  END FN_GET_SVXP_TEMPLATE;

  PROCEDURE PR_WRITE_CLOB_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                  P_IN_FILE_NAME IN VARCHAR2,
                                  P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_CLOB_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_CLOB_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_CLOB_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_CLOB_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_CLOB_TO_FILE;

  PROCEDURE PR_GEN_CCPAYMNT_SVXP_FILE(p_ifdccpcd IN OUT ifpks_ifdccpcd_Main.ty_ifdccpcd) IS
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
    L_RESP_CODE     VARCHAR2(10);
  BEGIN
  
    --GLOBAL.pr_init('001', 'SYSTEM');
    DBG('START OF PR_GEN_CCPAYMNT_SVXP_FILE');
  
    /*FOR G IN (SELECT A.*, B.CHAR_FIELD6
     FROM IFTB_CREDIT_CARD_PYMNT_BY_CASH A, CSTB_UI_COLUMNS B
    WHERE A.TRN_REF_NO = B.CHAR_FIELD1
      AND A.AUTH_STAT = 'A') LOOP*/
  
    L_RESP_TEMPLATE := FN_GET_SVXP_TEMPLATE;
  
    L_FILE_NAME := 'SVXP_OUT_PMNT_' ||
                   p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no || '_' ||
                   GLOBAL.APPLICATION_DATE;
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_DATE',
                               SUBSTR(TO_CHAR(p_ifdccpcd.v_credit_card_pymnt_by_cd.maker_dt_stamp,
                                              Cspks_Req_Global.g_Ws_Date_Time_Format),
                                      1,
                                      10) || 'T' ||
                               SUBSTR(TO_CHAR(p_ifdccpcd.v_credit_card_pymnt_by_cd.maker_dt_stamp,
                                              Cspks_Req_Global.g_Ws_Date_Time_Format),
                                      12));
    --SUBSTR(p_ifdccpcd.v_credit_card_pymnt_by_cd.checker_dt_stamp,1,10)||'T'||SUBSTR(p_ifdccpcd.v_credit_card_pymnt_by_cd.checker_dt_stamp,12));
    --p_ifdccpcd.v_credit_card_pymnt_by_cd.payment_date);
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_AMOUNT',
                               p_ifdccpcd.v_credit_card_pymnt_by_cd.payment_amt * 100 /*G.TXN_AMOUNT*/);
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_ISO_CCY_CODE',
                               '840' /*G.ISO_CCY_CODE*/);
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_REFERENCE_NO',
                               p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no /*G.TXN_AMOUNT*/);
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_CREDIT_CARD_AC_NO',
                               p_ifdccpcd.v_credit_card_pymnt_by_cd.CREDIT_CARD_AC_NO /*G.TXN_AMOUNT*/);
  
    L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
  
    --L_RESP_TEMPLATE := NULL;
  
    --END LOOP;
  
    DBG('DONE WITH GENERATING CLOB RESPONSE');
  
    --Write to output file
    DBG('START OF WRITING CLOB TO AN XML FILE');
    PR_WRITE_CLOB_TO_FILE('/u01/fcubs/interfaces',
                          REPLACE(L_FILE_NAME, 'REQ', 'RES') || '.XML',
                          L_RESP_CLOB);
  
    DBG('END OF WRITING CLOB TO AN XML FILE');
  
    DBG('END OF PR_GEN_CCPAYMNT_SVXP_FILE');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GEN_CCPAYMNT_SVXP_FILE');
      DBG('ERROR CODE IN PR_GEN_CCPAYMNT_SVXP_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GEN_CCPAYMNT_SVXP_FILE=' || SQLERRM);
  END PR_GEN_CCPAYMNT_SVXP_FILE;

  FUNCTION get_param_val(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END get_param_val;

  FUNCTION FN_CREDIT_CARD_HTTP_CALL(p_out_msg VARCHAR2,
                                    p_in_resp IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_buffer_size   NUMBER(10) := 512;
    l_substring_msg VARCHAR2(32767);
    l_raw_data      RAW(2000);
    l_clob_response CLOB;
    l_url           cstb_param.param_val%TYPE;
    l_resp_ok       BOOLEAN;
    l_resp_num      NUMBER;
  
  BEGIN
  
    debug.pr_DebuG('IF', 'In FN_FAST_HTTP_CALL');
    dbms_lob.createtemporary(lob_loc => l_clob_response, cache => TRUE);
  
    --Get URL of Smart Vista
    l_url := get_param_val('PGW_SMART_VISTA_WS');
  
    --l_url := 'http://10.80.80.68:7026/svis/CmsSvng';
  
    debug.pr_DebuG('IF', 'l_url-->' || l_url);
    l_http_request := utl_http.begin_request(url          => l_url,
                                             method       => 'POST',
                                             http_version => 'HTTP/1.1');
    utl_http.set_header(l_http_request, 'User-Agent', 'Mozilla/4.0');
    utl_http.set_header(l_http_request, 'Connection', 'close');
    utl_http.set_header(l_http_request,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    -- UTL_HTTP.set_header (l_http_request, 'Content-Length', lengthb(CONVERT(p_out_msg, 'UTF8')));
  
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
    <<request_loop>>
  
    FOR i IN 0 .. ceil(length(p_out_msg) / l_buffer_size) - 1 LOOP
      l_substring_msg := substr(p_out_msg,
                                i * l_buffer_size + 1,
                                l_buffer_size);
      BEGIN
        l_raw_data := utl_raw.cast_to_raw(l_substring_msg);
        utl_http.write_raw(r => l_http_request, data => l_raw_data);
      EXCEPTION
        WHEN no_data_found THEN
          debug.pr_DebuG('IF', 'Request Loop NDF');
          EXIT request_loop;
      END;
    END LOOP request_loop;
    l_http_response := utl_http.get_response(l_http_request);
    debug.pr_DebuG('IF',
                   'Response> status_code: "' ||
                   l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      BEGIN
        <<response_loop>>
        LOOP
          utl_http.read_raw(l_http_response, l_raw_data, l_buffer_size);
          l_clob_response := l_clob_response ||
                             utl_raw.cast_to_varchar2(l_raw_data);
        END LOOP response_loop;
      EXCEPTION
        WHEN utl_http.end_of_body THEN
          utl_http.end_response(l_http_response);
        WHEN OTHERS THEN
          debug.pr_DebuG('IF', 'Inside Exception others in response');
          debug.pr_DebuG('IF', SQLERRM);
          debug.pr_DebuG('IF', dbms_utility.format_error_backtrace);
          utl_http.end_response(l_http_response);
      END;
      debug.pr_DebuG('IF', 'Out of Loop');
    
      p_in_resp := l_clob_response;
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    dbms_lob.freetemporary(l_clob_response);
  
    IF l_resp_ok THEN
      debug.pr_DebuG('IF', 'OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      debug.pr_DebuG('IF', 'PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_DebuG('IF', 'In WOT...Return false now...' || SQLERRM);
      RETURN FALSE;
  END FN_CREDIT_CARD_HTTP_CALL;

  FUNCTION FN_POST_ACC_ENTRY(p_ifdccpcd  IN OUT ifpks_ifdccpcd_Main.ty_ifdccpcd,
                             P_CARD_TYPE IN VARCHAR2) RETURN BOOLEAN IS
  
    pkg_detb_rtl_teller_rec detbs_rtl_teller%ROWTYPE;
    L_CUST_AC               STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    l_rate                  NUMBER;
    P_ERR_CODE              VARCHAR2(255);
    P_ERR_PARAMS            VARCHAR2(255);
    L_TILL_CASH_GL          DETMS_TIL_VLT_CCY_PARAMS.CASH_GL%TYPE;
    L_TILL_ID               SMTB_USER_TILLS.TILL_ID%TYPE;
    L_LMTM_TYPE_VALUES      LMTM_TYPE_VALUES%ROWTYPE;
    L_TILL_VLT_IND          FBTB_TILL_MASTER.TIL_VLT_IND%TYPE;
    L_ARC_MAINT             IFTM_ARC_MAINT%ROWTYPE;
  BEGIN
  
    pkg_detb_rtl_teller_rec.xref := p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no;
  
    IF P_CARD_TYPE = 'M' THEN
    
      pkg_detb_rtl_teller_rec.product_code := 'CCLC';
      BEGIN
        SELECT B.*
          INTO L_LMTM_TYPE_VALUES
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CREDIT_CARD_ACCS'
           AND B.CODE = 'MCCP'
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';
      EXCEPTION
        WHEN OTHERS THEN
          L_LMTM_TYPE_VALUES := NULL;
      END;
    ELSE
      pkg_detb_rtl_teller_rec.product_code := 'CCLV';
      BEGIN
        SELECT B.*
          INTO L_LMTM_TYPE_VALUES
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CREDIT_CARD_ACCS'
           AND B.CODE = 'VCCP'
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';
      EXCEPTION
        WHEN OTHERS THEN
          L_LMTM_TYPE_VALUES := NULL;
      END;
    END IF;
  
    --Get Arc Maintenance
    SELECT *
      INTO L_ARC_MAINT
      FROM IFTM_ARC_MAINT A
     WHERE A.COD_PROD_ACC_CLS = pkg_detb_rtl_teller_rec.product_code AND ROWNUM=1;
  
    --Get Acc Details
    SELECT x.*
      INTO l_cust_ac
      FROM sttm_cust_account x
     WHERE x.cust_ac_no = p_ifdccpcd.v_credit_card_pymnt_by_cd.OFF_ACC;
  
    --GET BEN CUSTOMER DETAILS
    BEGIN
      SELECT X.*
        INTO L_CUST
        FROM STTM_CUSTOMER X
       WHERE X.CUSTOMER_NO = p_ifdccpcd.v_credit_card_pymnt_by_cd.OFF_ACC;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN GETTING CUSTOMER DETAILS');
    END;
  
    --pkg_detb_rtl_teller_rec.product_code := 'CCBC';
  
    pkg_detb_rtl_teller_rec.branch_code := GLOBAL.CURRENT_BRANCH;
    pkg_detb_rtl_teller_rec.trn_ref_no  := p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no;
  
    pkg_detb_rtl_teller_rec.txn_acc := p_ifdccpcd.v_credit_card_pymnt_by_cd.txn_gl_no;
    pkg_detb_rtl_teller_rec.txn_ccy := p_ifdccpcd.v_credit_card_pymnt_by_cd.txn_gl_ccy;
    --pkg_detb_rtl_teller_rec.txn_branch := p_ifdccpcd.v_credit_card_pymnt_by_cd.branch_code;
    --pkg_detb_rtl_teller_rec.txn_branch := pkg_detb_rtl_teller_rec.ofs_branch;
  
    /*--Get Till id
    BEGIN
      SELECT A.TILL_ID
        INTO L_TILL_ID
        FROM SMTB_USER_TILLS A
       WHERE USER_ID = GLOBAL.USER_ID
         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    EXCEPTION
      WHEN OTHERS THEN
        L_TILL_ID := NULL;
    END;
  
    --Till has not been maintained for this user id
    IF L_TILL_ID IS NULL THEN
      pr_log_error('IFDOFAST', 'FLEXCUBE', 'DE-DENX01', NULL);
      RETURN FALSE;
    END IF;
  
    --Checking if Till Id opened
    BEGIN
      SELECT TIL_ID, TIL_VLT_IND
        INTO L_TILL_ID, L_TILL_VLT_IND
        FROM FBTB_TILL_MASTER
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND USER_ID = GLOBAL.USER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  
    IF L_TILL_ID IS NULL OR L_TILL_VLT_IND IS NULL THEN
      pr_log_error('IFDOFAST', 'FLEXCUBE', 'WF-2027', NULL);
      RETURN FALSE;
    END IF;*/
  
    pkg_detb_rtl_teller_rec.ofs_acc    := p_ifdccpcd.v_credit_card_pymnt_by_cd.off_acc;
    pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdccpcd.v_credit_card_pymnt_by_cd.off_ccy;
    pkg_detb_rtl_teller_rec.ofs_amount := p_ifdccpcd.v_credit_card_pymnt_by_cd.off_amount;
  
    pkg_detb_rtl_teller_rec.ofs_branch := l_cust_ac.Branch_Code; --GLOBAL.CURRENT_BRANCH;
  
    pkg_detb_rtl_teller_rec.txn_amount := p_ifdccpcd.v_credit_card_pymnt_by_cd.payment_amt;
  
    pkg_detb_rtl_teller_rec.txn_trn_code       := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'LOC'; --transacion code
    pkg_detb_rtl_teller_rec.ofs_trn_code       := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'LOC'; --transacion code
    pkg_detb_rtl_teller_rec.exch_rate          := p_ifdccpcd.v_credit_card_pymnt_by_cd.exch_rate;
    pkg_detb_rtl_teller_rec.trn_dt             := p_ifdccpcd.v_credit_card_pymnt_by_cd.payment_date;
    pkg_detb_rtl_teller_rec.value_dt           := p_ifdccpcd.v_credit_card_pymnt_by_cd.payment_date;
    pkg_detb_rtl_teller_rec.rel_customer       := L_CUST.customer_no;
    pkg_detb_rtl_teller_rec.benef_name         := L_CUST.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1        := L_CUST.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2        := L_CUST.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3        := L_CUST.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4        := L_CUST.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt            := p_ifdccpcd.v_credit_card_pymnt_by_cd.payment_date;
    pkg_detb_rtl_teller_rec.record_stat        := 'A';
    pkg_detb_rtl_teller_rec.auth_stat          := 'U';
    pkg_detb_rtl_teller_rec.maker_id           := p_ifdccpcd.v_credit_card_pymnt_by_cd.maker_id;
    pkg_detb_rtl_teller_rec.maker_dt_stamp     := p_ifdccpcd.v_credit_card_pymnt_by_cd.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id         := p_ifdccpcd.v_credit_card_pymnt_by_cd.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp   := p_ifdccpcd.v_credit_card_pymnt_by_cd.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no             := p_ifdccpcd.v_credit_card_pymnt_by_cd.mod_no;
    pkg_detb_rtl_teller_rec.scode              := 'FLEXCUBE';
    pkg_detb_rtl_teller_rec.dr_acc             := 'OFS';
    pkg_detb_rtl_teller_rec.module             := 'RT';
    pkg_detb_rtl_teller_rec.esn                := 1;
    pkg_detb_rtl_teller_rec.event_code         := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable   := 'N';
    pkg_detb_rtl_teller_rec.time_received      := SYSDATE;
    pkg_detb_rtl_teller_rec.DR_INSTRUMENT_CODE := p_ifdccpcd.v_credit_card_pymnt_by_cd.off_check_no;
  
    dbg('Calling depks_rtl_teller.fn_save');
  
    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      PR_LOG_ERROR('IFDCCPCD', 'FLEXCUBE', p_err_code, p_err_params);
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN FALSE;
  END FN_POST_ACC_ENTRY;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdccpcd         IN OUT ifpks_ifdccpcd_Main.ty_ifdccpcd,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdccpcd_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdccpcd         IN OUT ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
    l_serial_no  VARCHAR2(16);
    l_trn_ref_no IFTB_CREDIT_CARD_PYMNT_BY_CASH.trn_ref_no%TYPE;
    e_update_error EXCEPTION;
    l_formatted_msg    CLOB;
    L_FORMATTED_MSG1   CLOB;
    l_in_resp          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_CARD_ID          VARCHAR2(100);
    L_CARD_TYPE        VARCHAR2(100);
    L_CARD_STATUS      VARCHAR2(100);
    L_NAME_ON_CARD     VARCHAR2(100);
    L_TOTAL_AMOUNT_DUE VARCHAR2(100);
    L_PAYMENT_CCY      VARCHAR2(100);
    L_EXCH_RATE        IFTB_FAST_MASTER.EXCH_RATE%TYPE;
    L_RATE_FLAG        NUMBER;
    L_TXN_AMT          IFTB_CREDIT_CARD_PYMNT_BY_CASH.PAYMENT_AMT%TYPE;
    L_COUNT            NUMBER;
    L_CREDIT_ACC_NO    VARCHAR2(20);
    L_PRODUCT_CODE     CSTM_PRODUCT.PRODUCT_CODE%TYPE;
    L_MOD_NO           NUMBER;
    L_ERROR_CODE       VARCHAR2(255);
    L_ERROR_DESC       VARCHAR2(255);
    L_CARD_GL   LMTM_TYPE_VALUES.VALUE%TYPE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    IF p_Action_Code = 'PICKUP' THEN
    
      DBG('I am in PICKUP');
    
      IF p_ifdccpcd.V_CSTBS_UI_COLUMNS.CHAR_FIELD6 IS NULL OR
         p_ifdccpcd.V_CSTBS_UI_COLUMNS.CHAR_FIELD2 IS NULL OR
         p_ifdccpcd.V_CSTBS_UI_COLUMNS.CHAR_FIELD3 IS NULL OR
         p_ifdccpcd.V_CSTBS_UI_COLUMNS.CHAR_FIELD4 IS NULL OR
         p_ifdccpcd.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 IS NULL OR
         p_ifdccpcd.v_credit_card_pymnt_by_cd.PAYMNT_CCY IS NULL OR
         p_ifdccpcd.v_credit_card_pymnt_by_cd.OFF_CCY IS NULL OR
         p_ifdccpcd.v_credit_card_pymnt_by_cd.OFF_AMOUNT IS NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IF-SVCC001', NULL);
        RETURN FALSE;
      END IF;
    
      --Currency Conversion
      IF p_ifdccpcd.v_credit_card_pymnt_by_cd.OFF_CCY <>
         p_ifdccpcd.v_credit_card_pymnt_by_cd.PAYMNT_CCY THEN
      
        --Get Exchange Rate
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                 p_ifdccpcd.v_credit_card_pymnt_by_cd.PAYMNT_CCY,
                                 p_ifdccpcd.v_credit_card_pymnt_by_cd.OFF_CCY, --L_AC_CCY,--l_ccy2, --L_AC_CCY,                                                                         
                                 'STANDARD',
                                 'S', --l_prod.rate_code_preferred, 
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        END IF;
      
      ELSE
        L_EXCH_RATE := 1;
      END IF;
    
      DBG('L_EXCH_RATE=' || L_EXCH_RATE);
    
      p_ifdccpcd.v_credit_card_pymnt_by_cd.EXCH_RATE := L_EXCH_RATE;
    
      --Using above rate..convert khr to usd amount 
      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdccpcd.v_credit_card_pymnt_by_cd.OFF_CCY,
                                    p_ifdccpcd.v_credit_card_pymnt_by_cd.PAYMNT_CCY,
                                    p_ifdccpcd.v_credit_card_pymnt_by_cd.off_amount,
                                    L_EXCH_RATE,
                                    'Y',
                                    L_TXN_AMT,
                                    P_ERR_PARAMS) THEN
        DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
      END IF;
      dbg('FINAL L_TXN_AMT=' || L_TXN_AMT);
    
      p_ifdccpcd.v_credit_card_pymnt_by_cd.payment_amt := L_TXN_AMT;
    
      --Post Accouting Entry
    
    END IF;
  
    IF p_Action_Code = 'INVOKESV' THEN
    
      DBG('I am in INVOKESV');
    
      IF p_ifdccpcd.v_cstbs_ui_columns.char_field6 IS NULL THEN
        Pr_Log_Error(p_Function_id, p_Source, 'IF-SVCC002', NULL);
        RETURN FALSE;
      END IF;
    
      --Assign Payment Date
      p_ifdccpcd.v_credit_card_pymnt_by_cd.payment_Date   := GLOBAL.application_date;
      p_ifdccpcd.v_credit_card_pymnt_by_cd.off_check_Date := GLOBAL.application_date;
    
      L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://bpc.ru/SVIS/cmsSvng/v1.1/">
   <soapenv:Header>
      <wsse:Security  xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
         <wsse:UsernameToken wsu:Id="UsernameToken-1">
            <wsse:Username>' ||
                         get_param_val('PGW_SMART_VISTA_WS_UID') ||
                         '</wsse:Username>
            <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">' ||
                         get_param_val('PGW_SMART_VISTA_WS_PWD') ||
                         '</wsse:Password>        
         </wsse:UsernameToken>
      </wsse:Security>
 </soapenv:Header>
   <soapenv:Body>
      <v1:getCardInfoRequest>
          <v1:cardNumber>' ||
                         p_ifdccpcd.v_cstbs_ui_columns.char_field6 ||
                         '</v1:cardNumber>
      </v1:getCardInfoRequest>
   </soapenv:Body>
</soapenv:Envelope>';
    
      dbg('l_formatted_msg for fast' || L_FORMATTED_MSG);
    
      --Invoke SV Credit Card System
      IF NOT FN_CREDIT_CARD_HTTP_CALL(L_FORMATTED_MSG, L_IN_RESP) THEN
        DBG('failed to invoke Smart vista call');
        RAISE E_UPDATE_ERROR;
      END IF;
    
      DBG('RESPONSE=' || L_IN_RESP);
    
      --Get Cosmetic XML
      PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);
    
      DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    
      P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
    
      --Check if returned error or success
      L_ERROR_CODE := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/errorCode/text()')
                      .GETSTRINGVAL;
    
      IF L_ERROR_CODE <> 'SUCCESS' THEN
        L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/errorDesc/text()')
                        .GETSTRINGVAL;
      
        Pr_Log_Error(p_Function_id, p_Source, 'IF-SVCC003', L_ERROR_DESC);
        RETURN FALSE;
      END IF;
    
      L_CREDIT_ACC_NO := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardAccounts/account/text()')
                         .GETSTRINGVAL;
    
      DBG('L_CREDIT_ACC_NO=' || L_CREDIT_ACC_NO);
    
      L_CARD_ID := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardId/text()')
                   .GETSTRINGVAL;
    
      DBG('L_CARD_ID=' || L_CARD_ID);
    
      L_CARD_TYPE := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardType/text()')
                     .GETSTRINGVAL;
    
      DBG('L_CARD_TYPE=' || L_CARD_TYPE);
    
      L_CARD_STATUS := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardStatusDesc/text()')
                       .GETSTRINGVAL;
    
      DBG('L_CARD_STATUS=' || L_CARD_STATUS);
    
      L_NAME_ON_CARD := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/embossName/text()')
                        .GETSTRINGVAL;
    
      DBG('L_NAME_ON_CARD=' || L_NAME_ON_CARD);
    
      --Call Second API to get Amount Due
      L_FORMATTED_MSG1 := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://bpc.ru/SVIS/cmsSvng/v1.1/">
   <soapenv:Header>
      <wsse:Security  xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
         <wsse:UsernameToken wsu:Id="UsernameToken-1">
            <wsse:Username>svwi</wsse:Username>
            <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">svwiadmin</wsse:Password>        
         </wsse:UsernameToken>
      </wsse:Security>
 </soapenv:Header>
   <soapenv:Body>
      <v1:getCreditCardInfoRequest>
         <v1:cardId>' || L_CARD_ID ||
                          '</v1:cardId>
      </v1:getCreditCardInfoRequest>
   </soapenv:Body>
</soapenv:Envelope>';
    
      dbg('l_formatted_msg1' || L_FORMATTED_MSG1);
    
      --Invoke SV Credit Card System
      IF NOT FN_CREDIT_CARD_HTTP_CALL(L_FORMATTED_MSG1, L_IN_RESP) THEN
        DBG('failed to invoke Smart vista call');
        RAISE E_UPDATE_ERROR;
      END IF;
    
      DBG('RESPONSE=' || L_IN_RESP);
    
      --Get Cosmetic XML
      PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);
      DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    
      P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
    
      --check if it is already refunded by other bank since message id is different
      L_TOTAL_AMOUNT_DUE := P_DOCUMENT_XML.EXTRACT('/getCreditCardInfoResponse/totalAmountDue/text()')
                            .GETSTRINGVAL;
    
      L_PAYMENT_CCY := P_DOCUMENT_XML.EXTRACT('/getCreditCardInfoResponse/accountCurrency/text()')
                       .GETSTRINGVAL;
    
      --Generate Reference No
      L_PRODUCT_CODE := CASE L_CARD_TYPE
                          WHEN '33' THEN
                           'CCLC'
                          ELSE --WHEN 'V' THEN
                           'CCLV'
                        END;
      IF p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no IS NULL THEN
        IF NOT trpkss.fn_get_product_refno(GLOBAL.current_branch,
                                           L_PRODUCT_CODE,
                                           GLOBAL.application_date,
                                           l_serial_no,
                                           l_trn_ref_no,
                                           p_err_code) THEN
          dbg('Failed in generation Transaction Ref No');
          RETURN FALSE;
        ELSE
          dbg('l_trn_ref_no=' || l_trn_ref_no);
          p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no := l_trn_ref_no;
        
        END IF;
      END IF;
    
      --Default Values
      DBG('Defaulting Values');
      p_ifdccpcd.v_credit_card_pymnt_by_cd.credit_card_ac_no := L_CREDIT_ACC_NO;
      p_ifdccpcd.v_cstbs_ui_columns.char_field2 := CASE
                                                     WHEN L_CARD_TYPE = '31' OR
                                                          L_CARD_TYPE = '33' THEN
                                                      'M'
                                                     WHEN L_CARD_TYPE = '51' OR
                                                          L_CARD_TYPE = '53' THEN
                                                      'V'
                                                     ELSE
                                                      NULL
                                                   END;
    
      p_ifdccpcd.v_cstbs_ui_columns.char_field3       := L_CARD_STATUS;
      p_ifdccpcd.v_cstbs_ui_columns.char_field4       := L_NAME_ON_CARD;
      p_ifdccpcd.v_cstbs_ui_columns.char_field5       := L_TOTAL_AMOUNT_DUE / 100;
      p_ifdccpcd.v_credit_card_pymnt_by_cd.PAYMNT_CCY := FN_GET_ISO_CURRENCY_CODE(L_PAYMENT_CCY);
    
    END IF;
  
    IF p_Action_Code = cspks_req_global.p_modify THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM IFTB_CREDIT_CARD_PYMNT_BY_CASH
         WHERE TRN_REF_NO = p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no
              -- AND AUTH_STAT = 'A'
           AND ONCE_AUTH = 'Y';
      
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      IF L_COUNT > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-VALS-007',
                     'Transaction No:' ||
                     p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF p_Action_Code = cspks_req_global.p_new THEN
      
    --Validation against Master Card Type and GL that we use while paying payment
      IF p_ifdccpcd.v_cstbs_ui_columns.char_field2 = 'M' THEN
        L_CARD_GL := FN_GET_MAS_VIS_GL_CREDIT_CARD('MCCP');
        IF L_CARD_GL <> p_ifdccpcd.v_credit_card_pymnt_by_cd.TXN_GL_NO THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IF-SVCC004', Null);
          RETURN FALSE;
        END IF;
      END IF;
      IF p_ifdccpcd.v_cstbs_ui_columns.char_field2 = 'V' THEN
        L_CARD_GL := FN_GET_MAS_VIS_GL_CREDIT_CARD('VCCP');
        IF L_CARD_GL <> p_ifdccpcd.v_credit_card_pymnt_by_cd.TXN_GL_NO THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IF-SVCC005', Null);
          RETURN FALSE;
        END IF;
      
      END IF;
      
      IF NOT FN_POST_ACC_ENTRY(p_ifdccpcd,
                               p_ifdccpcd.v_cstbs_ui_columns.char_field2) THEN
        --p_ifdccpft.v_cstbs_ui_columns.char_field2) THEN
      
        DBG('FAILED IN CREDITING TO GL');
        RETURN FALSE;
      ELSE
        DBG('SUCCESS IN CREDITING TO GL');
        RETURN TRUE;
      END IF;
    END IF;
  
    IF p_Action_Code = cspks_req_global.p_auth THEN
    
      --Check if already authorised
    
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM IFTB_CREDIT_CARD_PYMNT_BY_CASH
         WHERE TRN_REF_NO = p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no
              -- AND AUTH_STAT = 'A'
           AND ONCE_AUTH = 'Y';
      
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      IF L_COUNT > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-VALS-007',
                     'Transaction No:' ||
                     p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no);
        RETURN FALSE;
      END IF;
    
      --AUTH TRANSACTION
      DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
      IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.current_branch,
                                                  p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no,
                                                  GLOBAL.USER_ID,
                                                  GLOBAL.LCY,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
        DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
        PR_LOG_ERROR('IFDCCPCD', 'FLEXCUBE', p_err_code, p_err_params);
        RETURN FALSE;
      ELSE
        --generate SVXP File
        PR_GEN_CCPAYMNT_SVXP_FILE(p_ifdccpcd);
        dbg('done with generating SVXP File');
      
        --Process Check Details
      
        /*BEGIN
          DEBUG.PR_DEBUG('AC', 'Inserting into CATM_CHECK_DETAIL_HISTORY');
          INSERT INTO CATM_CHECK_DETAIL_HISTORY
            (BRANCH,
             ACCOUNT,
             CHECK_BOOK_NO,
             CHECK_NO,
             MOD_NO,
             STATUS,
             AMOUNT,
             BENEFICIARY,
             PRESENTATION_DATE,
             VALUE_DATE,
             CLAIM_AMOUNT)
            SELECT BRANCH,
                   ACCOUNT,
                   CHECK_BOOK_NO,
                   CHECK_NO,
                   MOD_NO,
                   STATUS,
                   AMOUNT,
                   BENEFICIARY,
                   PRESENTATION_DATE,
                   VALUE_DATE,
                   CLAIM_AMOUNT
              FROM CATMS_CHECK_DETAILS
             WHERE BRANCH = GLOBAL.current_branch
               AND CHECK_NO = p_ifdccpcd.v_credit_card_pymnt_by_cd.check_no
               AND MOD_NO = L_MOD_NO + 1
               AND ACCOUNT = P_ACCOUNT
               AND DECODE(L_CHECK_DIGIT, '0', CHECK_DIGIT, L_CHECK_DIGIT) =
                   CHECK_DIGIT;
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('AC',
                           'Failed in inserting CATM_CHECK_DETAIL_HISTORY ');
            DEBUG.PR_DEBUG('AC', 'Sql Err message ' || SQLERRM);
        END;*/
      
      END IF;
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdccpcd_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdccpcd         IN ifpks_ifdccpcd_Main.ty_ifdccpcd,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdccpcd_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdccpcd         IN ifpks_ifdccpcd_Main.ty_ifdccpcd,
                                       p_Prev_ifdccpcd    IN OUT ifpks_ifdccpcd_Main.ty_ifdccpcd,
                                       p_Wrk_ifdccpcd     IN OUT ifpks_ifdccpcd_Main.ty_ifdccpcd,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdccpcd_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdccpcd         IN ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                                        p_Prev_ifdccpcd    IN OUT ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                                        p_Wrk_ifdccpcd     IN OUT ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdccpcd_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdccpcd         IN ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                            p_Prev_ifdccpcd    IN ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                            p_Wrk_ifdccpcd     IN OUT ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdccpcd_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdccpcd         IN ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                             p_prev_ifdccpcd    IN ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                             p_wrk_ifdccpcd     IN OUT ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    --Mask the card no
    UPDATE CSTB_UI_COLUMNS
       SET CHAR_FIELD6 = SUBSTR(CHAR_FIELD6, 1, 6) || 'XXXXXXXXXX'
     WHERE CHAR_FIELD1 = p_ifdccpcd.v_credit_card_pymnt_by_cd.trn_ref_no;
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdccpcd_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdccpcd         IN ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                        p_Wrk_ifdccpcd     IN OUT ifpks_ifdccpcd_Main.Ty_ifdccpcd,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdccpcd_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdccpcd         IN ifpks_ifdccpcd_Main.ty_ifdccpcd,
                         p_wrk_ifdccpcd     IN OUT ifpks_ifdccpcd_Main.ty_ifdccpcd,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdccpcd_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdccpcd_custom;
/