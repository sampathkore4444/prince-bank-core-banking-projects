insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFDCCCAS', 'Credit Card Payment', 'Operations', 'Payment By Cash', null, null, null, 'Credit Card Payment By Cash', 'IFDCCCAS');

insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFSCCCAS', 'Credit Card Payment', 'View', 'Payment By Cash Summary', null, null, null, 'Credit Card Payment By Cash Summary', 'IFDCCCAS');

COMMIT;
