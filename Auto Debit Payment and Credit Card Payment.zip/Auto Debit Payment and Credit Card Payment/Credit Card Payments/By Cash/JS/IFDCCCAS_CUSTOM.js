var g_PickupClicked = 0;
var n =0;

function fnPostNew_CUSTOM(){
	debugs("In fnPostNew_CUSTOM", "A");
	fnDisableElement(document.getElementById("BLK_CREDIT_CARD_PYMNT__OFF_CCY"));
	fnDisableElement(document.getElementById("BLK_CREDIT_CARD_PYMNT__OFF_AMOUNT"));
	fnDisableElement(document.getElementById("BLK_CREDIT_CARD_PYMNT__BTN_ENRICH"));
	return true;	
}

function fnPickup() {
	debugs("In fnPickup", "A");
	g_prevAction = gAction;
	gAction = "PICKUP";
	appendData();
	gAction = "PICKUP";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}

function fnInvokeSV() {
	debugs("In fnInvokeSV", "A");
	g_prevAction = gAction;
	gAction = "INVOKESV";
	appendData();
	gAction = "INVOKESV";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	fnEnableElement(document.getElementById("BLK_CREDIT_CARD_PYMNT__OFF_CCY"));
	fnEnableElement(document.getElementById("BLK_CREDIT_CARD_PYMNT__OFF_AMOUNT"));
	fnEnableElement(document.getElementById("BLK_CREDIT_CARD_PYMNT__BTN_ENRICH"));
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}

function fnPreSave_CUSTOM(){
	debugs("In fnPreSave_CUSTOM", "A");

	if (document.getElementById("BLK_CREDIT_CARD_PYMNT").value == "" || g_PickupClicked != 1) {			
		debugs("In Please click on Pick up before save", "A");
		alert("Please click on Pick up before save");
		return false;
	}
	return true;	
}