CREATE OR REPLACE PACKAGE BODY depks_rtl_teller_custom IS

  /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
  
     Changed By         : Kore Sampath Kumar
  Change Description : Prince Bank Credit Card Payment by Cash GL Changes
    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'depks_rtl_teller_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('DE', L_MSG);
  END DBG;

  FUNCTION FN_SAVE(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                   P_ERR_CODE            IN OUT VARCHAR2,
                   P_ERR_PARAM           IN OUT VARCHAR2,
                   P_FN_CALL_ID          IN OUT NUMBER,
                   P_TB_CUSTOM_DATA      IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of fn_save');
  
    DBG('Returning Successfuly from fn_save');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed inside when others of fn_save' || SQLERRM);
      RETURN FALSE;
  END;

  PROCEDURE PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND       IN OUT ACPKS.TBL_ACHOFF,
                                    P_RET            IN OUT NUMBER,
                                    P_FN_CALL_ID     IN OUT NUMBER,
                                    P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('In depks_rtl_teller_custom.pr_build_acctng_entries--> p_Fn_Call_Id --> ' ||
        P_FN_CALL_ID);
  
    DBG('Returning from depks_rtl_teller_custom.pr_build_acctng_entries');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.pr_build_acctng_entries ..');
      P_RET := -1;
      RETURN;
  END PR_BUILD_ACCTNG_ENTRIES;

  FUNCTION FN_ONLINE_PRE(P_BRN      IN VARCHAR2,
                         P_PRD      IN VARCHAR2,
                         P_CUST     IN VARCHAR2,
                         P_CCY      IN VARCHAR2,
                         P_AMT      IN NUMBER,
                         P_ERR_CODE IN OUT VARCHAR2,
                         P_PROD_ROW IN OUT CSTMS_PRODUCT%ROWTYPE,
                         P_ARC_ROW  IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                         P_AC_NO    IN VARCHAR2,
                         P_AC_BRN   IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_online_Pre');
  
    DBG('Returning success from fn_online_Pre');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.fn_online_Pre ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_ONLINE_PRE;

  FUNCTION FN_ONLINE_POST(P_BRN      IN VARCHAR2,
                          P_PRD      IN VARCHAR2,
                          P_CUST     IN VARCHAR2,
                          P_CCY      IN VARCHAR2,
                          P_AMT      IN NUMBER,
                          P_ERR_CODE IN OUT VARCHAR2,
                          P_PROD_ROW IN OUT CSTMS_PRODUCT%ROWTYPE,
                          P_ARC_ROW  IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                          P_AC_NO    IN VARCHAR2,
                          P_AC_BRN   IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_online_Post');
  
    DBG('Returning success from fn_online_Post');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.fn_online_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_ONLINE_POST;

  FUNCTION FN_ONLINE_PRE(P_BRN      IN VARCHAR2,
                         P_PRD      IN VARCHAR2,
                         P_CUST     IN VARCHAR2,
                         P_CCY      IN VARCHAR2,
                         P_AMT      IN NUMBER,
                         P_PERIOD   IN NUMBER,
                         P_ERR_CODE IN OUT VARCHAR2,
                         P_PROD_ROW IN OUT CSTMS_PRODUCT%ROWTYPE,
                         P_ARC_ROW  IN OUT IFTMS_ARC_MAINT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_online_Pre');
  
    DBG('Returning success from fn_online_Pre');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.fn_online_Pre ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_ONLINE_PRE;

  FUNCTION FN_ONLINE_POST(P_BRN      IN VARCHAR2,
                          P_PRD      IN VARCHAR2,
                          P_CUST     IN VARCHAR2,
                          P_CCY      IN VARCHAR2,
                          P_AMT      IN NUMBER,
                          P_PERIOD   IN NUMBER,
                          P_ERR_CODE IN OUT VARCHAR2,
                          P_PROD_ROW IN OUT CSTMS_PRODUCT%ROWTYPE,
                          P_ARC_ROW  IN OUT IFTMS_ARC_MAINT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_online_Post');
  
    DBG('Returning success from fn_online_Post');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.fn_online_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_ONLINE_POST;
  PROCEDURE PR_SET_GLOBAL_PRE(P_ERR_CODE IN OUT VARCHAR2) IS
  BEGIN
    DBG('Inside pr_set_global_Pre');
  
    DBG('Returning success from pr_set_global_Pre');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.pr_set_global_Pre ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := SQLERRM;
      RETURN;
  END PR_SET_GLOBAL_PRE;

  PROCEDURE PR_SET_GLOBAL_POST(P_ERR_CODE IN OUT VARCHAR2) IS
  BEGIN
    DBG('Inside pr_set_global_Post');
  
    DBG('Returning success from pr_set_global_Post');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.pr_set_global_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := SQLERRM;
      RETURN;
  END PR_SET_GLOBAL_POST;

  PROCEDURE PR_SUPERSCRIBE_ARC(P_FN_CALL_ID     IN OUT NUMBER,
                               P_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                               PKG_PROD         IN OUT CSTMS_PRODUCT.RATE_CODE_PREFERRED%TYPE,
                               P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_ERR_PARAM      IN OUT VARCHAR2) IS
  BEGIN
    DBG('Inside Custom Pr_Superscribe_Arc ...');
  
    DBG('Returning Successfully from Custom Pr_Superscribe_Arc..');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.Pr_Superscribe_Arc ..');
      DBG(SQLERRM);
      RETURN;
  END PR_SUPERSCRIBE_ARC;
  FUNCTION FN_VALIDATE(P_FN_CALL_ID     IN OUT NUMBER,
                       P_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                       PKG_PROD         IN OUT CSTMS_PRODUCT.RATE_CODE_PREFERRED%TYPE,
                       P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                       P_ERR_CODE       IN OUT VARCHAR2,
                       P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Custom fn_validate exchange rate ...');
  
    DBG('Returning Successfully from Custom fn_validate exchange rate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.fn_validate exchange rate ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE;

  FUNCTION FN_SAVE(P_DETB_RTL_TELLER_REC IN OUT NOCOPY DETBS_RTL_TELLER%ROWTYPE,
                   P_ARC_ROW             IN IFTMS_ARC_MAINT%ROWTYPE,
                   P_LCY                 IN VARCHAR2,
                   P_TXNAMT_FLAG         IN BOOLEAN,
                   P_OFSAMT_FLAG         IN BOOLEAN,
                   P_FN_CALL_ID          IN OUT NUMBER,
                   P_TB_CUSTOM_DATA      IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                   P_ERR_CODE            IN OUT VARCHAR2,
                   P_ERR_PARAM           IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside depks_rtl_teller_custom.fn_save2......');
    DBG('Returning successfully from depks_rtl_teller_custom.fn_save2......');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed inside when others of fn_save2' || SQLERRM);
      RETURN FALSE;
  END FN_SAVE;

  FUNCTION FN_SAVE(P_DETB_RTL_TELLER_REC IN OUT NOCOPY DETBS_RTL_TELLER%ROWTYPE,
                   P_ARC_ROW             IN IFTMS_ARC_MAINT%ROWTYPE,
                   P_LCY                 IN VARCHAR2,
                   P_ACC_HAND            IN OUT ACPKS.TBL_ACHOFF,
                   P_FN_CALL_ID          IN OUT NUMBER,
                   P_TB_CUSTOM_DATA      IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                   P_ERR_CODE            IN OUT VARCHAR2,
                   P_ERR_PARAM           IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside depks_rtl_teller_custom.fn_save3......');
    DBG('Returning successfully from depks_rtl_teller_custom.fn_save3......');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed inside when others of fn_save3' || SQLERRM);
      RETURN FALSE;
  END FN_SAVE;

  PROCEDURE PR_BUILD_CHG_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                 
                                 P_CHG_ROW IN IFTMS_ARC_MAINT%ROWTYPE,
                                 I         IN NUMBER,
                                 P_RET     IN OUT NUMBER,
                                 
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_FN_CALL_ID     IN OUT NUMBER,
                                 P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of pr_build_chg_entries with call id :::: ' || P_FN_CALL_ID);
  
    DBG('Returning Successfully from pr_build_chg_entries....');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.pr_build_chg_entries....' ||
          P_ERR_CODE);
    
      DBG('The error message is:' || SQLERRM);
      P_RET      := -1;
      P_ERR_CODE := SQLERRM;
    
      RETURN;
  END PR_BUILD_CHG_ENTRIES;

  FUNCTION FN_REVERSE(P_TRN_REF_NO     IN DETB_RTL_TELLER.TRN_REF_NO%TYPE,
                      P_ERR_CODE       IN OUT VARCHAR2,
                      P_ERR_PARAM      IN OUT VARCHAR2,
                      P_FN_CALL_ID     IN OUT NUMBER,
                      P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside depks_rtl_teller_custom.fn_reverse ....');
    DBG('Returning Successfully from depks_rtl_teller_custom.fn_reverse ....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.fn_reverse .... ' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REVERSE;

  FUNCTION FN_USER_ALLOWED_ACC(PKG_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                               P_ERR_CODE         IN OUT VARCHAR2,
                               P_ERR_PARAM        IN OUT VARCHAR2,
                               P_FN_CALL_ID       IN OUT NUMBER,
                               L_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('IF',
                   'Inside depks_rtl_teller_custom.Fn_User_Allowed_Acc. ...');
  
    DEBUG.PR_DEBUG('IF',
                   'Returning Successfully from depks_rtl_teller_custom.Fn_User_Allowed_Acc...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of depks_rtl_teller_custom.Fn_User_Allowed_Acc. ..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
  END FN_USER_ALLOWED_ACC;

  PROCEDURE PR_INS_MSG_HANDOFF(P_DRCR           IN VARCHAR2,
                               P_FN_CALL_ID     IN OUT NUMBER,
                               P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) IS
  
  BEGIN
    DBG('inside pr_ins_msg_handoff with call id as:' || P_FN_CALL_ID);
  END PR_INS_MSG_HANDOFF;

  PROCEDURE PR_UPDATE_REC(P_FN_CALL_ID     IN NUMBER,
                          P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) IS
  
  BEGIN
    DBG('Entered depks_rtl_teller_custom.pr_update_rec');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.pr_update_rec ..');
      DBG(SQLERRM);
  END PR_UPDATE_REC;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_TRNSBYFT_PRE(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                           P_ARC_ROW             IN IFTMS_ARC_MAINT%ROWTYPE,
                           P_FTTXNDETS_REC       IN OUT CSTB_UI_COLUMNS%ROWTYPE,
                           P_ERR_CODE            IN OUT VARCHAR2,
                           P_ERR_PARAM           IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_trnsbyft_Pre');
  
    DBG('Returning success from fn_trnsbyft_Pre');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of depks_rtl_teller_custom.fn_trnsbyft_Pre..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
  END FN_TRNSBYFT_PRE;

  FUNCTION FN_TRNSBYFT_POST(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                            P_ARC_ROW             IN IFTMS_ARC_MAINT%ROWTYPE,
                            P_FTTXNDETS_REC       IN OUT CSTB_UI_COLUMNS%ROWTYPE,
                            P_ERR_CODE            IN OUT VARCHAR2,
                            P_ERR_PARAM           IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_trnsbyft_Post');
  
    DBG('Returning success from fn_trnsbyft_Post');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.fn_trnsbyft_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_TRNSBYFT_POST;

  FUNCTION FN_GET_CASHAMT(P_ACC_HAND       IN ACPKS.TBL_ACHOFF,
                          P_TXNLEGCASHAMT  IN OUT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
                          P_OFSLEGCASHAMT  IN OUT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
                          P_FN_CALL_ID     IN OUT NUMBER,
                          P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                          P_ERR_CODE       IN OUT VARCHAR2,
                          P_ERR_PARAM      IN OUT VARCHAR2
                          
                          ) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside FN_GET_CASHAMT');
  
    DBG('Returning success from FN_GET_CASHAMT');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.FN_GET_CASHAMT ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_GET_CASHAMT;

  FUNCTION FN_SAVE_HANDOFF(PKG_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                           P_ACC_HAND         IN OUT ACPKS.TBL_ACHOFF,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAM        IN OUT VARCHAR2,
                           P_FN_CALL_ID       IN OUT NUMBER,
                           P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_save_handoff');
  
    DBG('Returning success from fn_save_handoff');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.fn_save_handoff ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_SAVE_HANDOFF;

  PROCEDURE PR_CHECK_NOT_NULLS(P_RET            OUT NUMBER,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_PARAM          IN OUT VARCHAR2,
                               P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                               P_FN_CALL_ID     IN OUT NUMBER) IS
  
  BEGIN
    DEBUG.PR_DEBUG('',
                   'Inside depks_rtl_teller_custom.pr_check_not_nulls...');
    DEBUG.PR_DEBUG('', 'Returning Successfully from pr_check_not_nulls..');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('',
                     'In When Others of depks_rtl_teller_custom.pr_check_not_nulls ...');
      DEBUG.PR_DEBUG('', SQLERRM);
  END PR_CHECK_NOT_NULLS;

  PROCEDURE PR_PRE_BUILD_ACCTNG_ENTRIES(P_ACC_HAND       IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                        P_RET            IN OUT NUMBER,
                                        P_FN_CALL_ID     IN OUT NUMBER,
                                        P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of pr_pre_build_acctng_entries with call id:' ||
        P_FN_CALL_ID);
    DEBUG.PR_DEBUG('IF',
                   'Returning Successfully from pr_pre_build_acctng_entries..');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of depks_rtl_teller_custom.pr_pre_build_acctng_entries ..');
      RETURN;
  END PR_PRE_BUILD_ACCTNG_ENTRIES;
  PROCEDURE PR_PRE_BUILD_CHG_ENTRIES(P_ACC_HAND       IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                     P_CHG_ROW        IN IFTMS_ARC_MAINT%ROWTYPE,
                                     I                IN NUMBER,
                                     P_RET            IN OUT NUMBER,
                                     P_ERR_CODE       IN OUT VARCHAR2,
                                     P_FN_CALL_ID     IN OUT NUMBER,
                                     P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of pr_pre_build_chg_entries with call id :::: ' ||
        P_FN_CALL_ID);
    DBG('Returning Successfully from pr_pre_build_chg_entries....');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.pr_pre_build_chg_entries....' ||
          P_ERR_CODE);
      RETURN;
  END PR_PRE_BUILD_CHG_ENTRIES;

  FUNCTION FN_SAVE(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                   P_FN_CALL_ID          IN OUT NUMBER,
                   P_TB_CUSTOM_DATA      IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                   P_ERR_CODE            IN OUT VARCHAR2,
                   P_ERR_PARAM           IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_save ...');
  
    DBG('Returning Successfully from fn_save..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.fn_save ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_SAVE;

  PROCEDURE PR_BUILD_CHG_ENTRIES(P_ACC_HAND       IN OUT ACPKS.TBL_ACHOFF,
                                 P_CHG_ROW        IN IFTMS_ARC_MAINT%ROWTYPE,
                                 I                IN NUMBER,
                                 P_FN_CALL_ID     IN OUT NUMBER,
                                 P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_RET            IN OUT NUMBER) IS
  
  BEGIN
  
    DBG('In depks_rtl_teller_custom.pr_build_chg_entries');
  
    DBG('Returning from depks_rtl_teller_custom.pr_build_chg_entries');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.pr_build_chg_entries ..');
      P_RET := -1;
      RETURN;
  END PR_BUILD_CHG_ENTRIES;

  FUNCTION FN_SAVE(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                   P_ACC_HAND            IN ACPKS.TBL_ACHOFF,
                   P_ARC_ROW             IN IFTMS_ARC_MAINT%ROWTYPE,
                   P_ERR_CODE            IN OUT VARCHAR2,
                   P_ERR_PARAM           IN OUT VARCHAR2,
                   P_FN_CALL_ID          IN OUT NUMBER,
                   P_TB_CUSTOM_DATA      IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'Inside depks_rtl_teller_custom.Fn_Save 6 ...');
  
    DEBUG.PR_DEBUG('IF',
                   'Returning Successfully from depks_rtl_teller_custom.Fn_Save 6..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of depks_rtl_teller_custom.Fn_Save 6 ..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
  END FN_SAVE;

  PROCEDURE PR_RESOLVE_CHG_WHOM(P_CHG_ROW         IN IFTMS_ARC_MAINT%ROWTYPE,
                                P_THEIR_CHGS      IN VARCHAR2,
                                P_CHG_ACC_CCY     IN OUT VARCHAR2,
                                P_CHG_ACC         IN OUT VARCHAR2,
                                P_CHG_ACC_BRN     IN OUT VARCHAR2,
                                P_FN_CALL_ID      IN OUT NUMBER,
                                P_TB_CLUSTER_DATA IN OUT NOCOPY GLOBAL.TY_TB_CLUSTER_DATA) IS
  BEGIN
    DBG('Start of pr_resolve_chg_whom with call id :::: ' || P_FN_CALL_ID);
    DBG('Returning Successfully from pr_resolve_chg_whom....');
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLERRM);
      RAISE;
  END PR_RESOLVE_CHG_WHOM;

  FUNCTION FN_POST_GET_ACTAMT(P_ACC_HAND  IN ACPKS.TBL_ACHOFF,
                              P_ERR_CODE  OUT VARCHAR2,
                              P_ERR_PARAM OUT VARCHAR2) RETURN BOOLEAN IS
    --Prince Bank Credit Card Payment by Cash GL Changes starts
    L_CASHDRCR_IND         ACTB_DAILY_LOG.DRCR_IND%TYPE;
    L_CASHDRCR_MUL         NUMBER;
    L_FINALACC             ACTB_DAILY_LOG.AC_NO%TYPE;
    IS_ACCGL1              VARCHAR2(1);
    IS_ACCGL2              VARCHAR2(1);
    L_MAINLEGACC1          ACTB_DAILY_LOG.AC_NO%TYPE;
    L_MAINLEGACC2          ACTB_DAILY_LOG.AC_NO%TYPE;
    L_MAINLEGACC1_DRCR_IND ACTB_DAILY_LOG.DRCR_IND%TYPE;
    L_MAINLEGACC2_DRCR_IND ACTB_DAILY_LOG.DRCR_IND%TYPE;
    L_ACTAMT               ACTB_DAILY_LOG.LCY_AMOUNT%TYPE := 0;
    L_ACTAMT_TEMP          ACTB_DAILY_LOG.LCY_AMOUNT%TYPE := 0;
    L_MAINLEGCCY1          ACTB_DAILY_LOG.AC_CCY%TYPE;
    L_MAINLEGCCY2          ACTB_DAILY_LOG.AC_CCY%TYPE;
    L_MAINLEGBRN1          ACTB_DAILY_LOG.AC_BRANCH%TYPE;
    L_MAINLEGBRN2          ACTB_DAILY_LOG.AC_BRANCH%TYPE;
    L_FINALCCY             ACTB_DAILY_LOG.AC_CCY%TYPE;
    L_FINALBRN             ACTB_DAILY_LOG.AC_BRANCH%TYPE;
    --Prince Bank Credit Card Payment by Cash GL Changes ends
  BEGIN
    DBG('Inside fn_post_get_actAmt ...');
  
    --Prince Bank Credit Card Payment by Cash GL Changes starts
    DBG(' gwpks_util.pkg_func ' || GWPKS_UTIL.PKG_FUNC);
    DBG(' Before getting the value of Account/GL in main Leg ');
    FOR I IN 1 .. 2 LOOP
    
      DBG('I am inside loop i ' || I);
      IF I = 1 THEN
        L_MAINLEGACC1          := P_ACC_HAND(I).AC_NO;
        L_MAINLEGACC1_DRCR_IND := P_ACC_HAND(I).DRCR_IND;
        L_MAINLEGCCY1          := P_ACC_HAND(I).AC_CCY;
        L_MAINLEGBRN1          := P_ACC_HAND(I).AC_BRANCH;
      ELSE
      
        L_MAINLEGACC2          := P_ACC_HAND(I).AC_NO;
        L_MAINLEGACC2_DRCR_IND := P_ACC_HAND(I).DRCR_IND;
        L_MAINLEGCCY2          := P_ACC_HAND(I).AC_CCY;
        L_MAINLEGBRN2          := P_ACC_HAND(I).AC_BRANCH;
      END IF;
    
    END LOOP;
    DBG('After loop ');
    DBG('l_MainLegAcc1 ' || L_MAINLEGACC1);
    DBG('l_MainLegAcc1_drcr_ind ' || L_MAINLEGACC1_DRCR_IND);
    DBG('l_mainlegCcy1 ' || L_MAINLEGCCY1);
    DBG('l_mainlegBrn1 ' || L_MAINLEGBRN1);
  
    DBG('l_MainLegAcc2 ' || L_MAINLEGACC2);
    DBG('l_MainLegAcc2_drcr_ind ' || L_MAINLEGACC2_DRCR_IND);
    DBG('l_mainlegCcy2 ' || L_MAINLEGCCY2);
    DBG('l_mainlegBrn2 ' || L_MAINLEGBRN2);
  
    BEGIN
    
      SELECT AC_OR_GL
        INTO IS_ACCGL1
        FROM STTB_ACCOUNT
       WHERE AC_GL_NO = L_MAINLEGACC1
         AND BRANCH_CODE = L_MAINLEGBRN1;
    
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
        DBG('NO DATA FOUND HENCE SETTTING l_MainLegAcc1 TYPE AS GL');
        IS_ACCGL1 := 'G';
      
      WHEN OTHERS THEN
        DBG('Failed While getting Acc/GL for ' || L_MAINLEGACC1);
        RETURN FALSE;
    END;
    DBG('Is_AccGL1 ' || IS_ACCGL1);
    BEGIN
    
      SELECT AC_OR_GL
        INTO IS_ACCGL2
        FROM STTB_ACCOUNT
       WHERE AC_GL_NO = L_MAINLEGACC2
         AND BRANCH_CODE = L_MAINLEGBRN2;
    
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
        DBG('NO DATA FOUND HENCE SETTTING l_MainLegAcc2 TYPE AS GL');
        IS_ACCGL2 := 'G';
      
      WHEN OTHERS THEN
        DBG('Failed While getting Acc/GL for ' || L_MAINLEGACC2);
        RETURN FALSE;
    END;
    DBG('Is_AccGL2 ' || IS_ACCGL2);
  
    IF (IS_ACCGL1 = 'A' AND IS_ACCGL2 = 'A') OR
       (IS_ACCGL1 = 'G' AND IS_ACCGL2 = 'G') THEN
      IF L_MAINLEGACC1_DRCR_IND = 'D' THEN
        L_FINALACC := L_MAINLEGACC1;
        L_FINALCCY := L_MAINLEGCCY1;
        L_FINALBRN := L_MAINLEGBRN1;
      ELSE
        L_FINALACC := L_MAINLEGACC2;
        L_FINALCCY := L_MAINLEGCCY2;
        L_FINALBRN := L_MAINLEGBRN2;
      END IF;
      DBG(' l_FinalAcc  ' || L_FINALACC);
    
    END IF;
  
    IF IS_ACCGL1 <> IS_ACCGL2 THEN
    
      IF IS_ACCGL1 = 'A' THEN
        L_FINALACC := L_MAINLEGACC1;
        L_FINALCCY := L_MAINLEGCCY1;
        L_FINALBRN := L_MAINLEGBRN1;
      ELSE
        L_FINALACC := L_MAINLEGACC2;
        L_FINALCCY := L_MAINLEGCCY2;
        L_FINALBRN := L_MAINLEGBRN2;
      END IF;
    
    END IF;
  
    DBG('For Special CASE function:' || GWPKS_UTIL.PKG_FUNC);
    IF GWPKS_UTIL.PKG_FUNC IN ('CCCG') OR
       NVL(GWPKS_CREATERETAILTLR.G_PARENT_FUNCTIONID, '*.*') IN ('CCCG') THEN
      L_FINALACC := L_MAINLEGACC2;
      L_FINALCCY := L_MAINLEGCCY2;
      L_FINALBRN := L_MAINLEGBRN2;
    
      DBG(' l_FinalBrn  ' || L_FINALBRN);
      DBG(' l_FinalCcy  ' || L_FINALCCY);
      DBG(' l_FinalAcc  ' || L_FINALACC);
      DBG(' Now before itrrating handoff and finding total amount for the Account ');
      FOR J IN 1 .. P_ACC_HAND.COUNT LOOP
        DBG('Inside Loop..' || J);
        DBG('p_acc_hand(' || J || ').amount_tag in fn_get_actAmt::::: ' || P_ACC_HAND(J)
            .AMOUNT_TAG);
        IF P_ACC_HAND(J).AMOUNT_TAG NOT IN ('REVL_AMT') THEN
          DBG('The account number in account amount computation is:' || P_ACC_HAND(J)
              .AC_NO);
          DBG('The debit credit indicator is:' || P_ACC_HAND(J).DRCR_IND);
          DBG('The acpks account currency is:' || P_ACC_HAND(J).AC_CCY ||
              ' and account branch is:' || P_ACC_HAND(J).AC_BRANCH);
        
          IF L_MAINLEGACC1 = L_MAINLEGACC2 THEN
            IF P_ACC_HAND(J)
             .AC_BRANCH = L_FINALBRN AND P_ACC_HAND(J).AC_NO = L_FINALACC AND P_ACC_HAND(J)
               .AC_CCY = L_FINALCCY THEN
              IF P_ACC_HAND(J).DRCR_IND = 'C' THEN
                L_CASHDRCR_MUL := 1;
              ELSE
                L_CASHDRCR_MUL := -1;
              END IF;
              DBG('The fcy amount is:' || P_ACC_HAND(J).FCY_AMOUNT ||
                  ' with lcy amount as:' || P_ACC_HAND(J).LCY_AMOUNT);
              L_ACTAMT_TEMP := NVL(P_ACC_HAND(J).FCY_AMOUNT,
                                   P_ACC_HAND(J).LCY_AMOUNT);
              L_ACTAMT      := L_ACTAMT + (L_ACTAMT_TEMP * L_CASHDRCR_MUL);
            
            END IF;
          ELSE
            IF P_ACC_HAND(J).AC_NO = L_FINALACC THEN
              IF P_ACC_HAND(J).DRCR_IND = 'C' THEN
                L_CASHDRCR_MUL := 1;
              ELSE
                L_CASHDRCR_MUL := -1;
              END IF;
              DBG('The fcy amount is:' || P_ACC_HAND(J).FCY_AMOUNT ||
                  ' with lcy amount as:' || P_ACC_HAND(J).LCY_AMOUNT);
              L_ACTAMT_TEMP := NVL(P_ACC_HAND(J).FCY_AMOUNT,
                                   P_ACC_HAND(J).LCY_AMOUNT);
              L_ACTAMT      := L_ACTAMT + (L_ACTAMT_TEMP * L_CASHDRCR_MUL);
            
            END IF;
          END IF;
        END IF;
      END LOOP;
      DEPKS_RTL_TELLER.PKG_TXNACTAMT := ABS(L_ACTAMT);
      DBG(' pkg_TxnactAmt ' || DEPKS_RTL_TELLER.PKG_TXNACTAMT);
    
    END IF;
  
    --Prince Bank Credit Card Payment by Cash GL Changes ends
  
    DBG('Returning Successfully from fn_post_get_actAmt..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_rtl_teller_custom.fn_post_get_actAmt ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_POST_GET_ACTAMT;

  PROCEDURE PR_SET_GLOBAL(P_ERR_CODE       IN OUT VARCHAR2,
                          P_FN_CALL_ID     IN OUT NUMBER,
                          P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Inside pr_set_global');
  
    DBG('Returning success from pr_set_global');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_rtl_teller_custom.pr_set_global ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := SQLERRM;
      RETURN;
  END PR_SET_GLOBAL;

  FUNCTION FN_ONLINE(P_BRN            IN VARCHAR2,
                     P_PRD            IN VARCHAR2,
                     P_CUST           IN VARCHAR2,
                     P_CCY            IN VARCHAR2,
                     P_AMT            IN NUMBER,
                     P_ERR_CODE       IN OUT VARCHAR2,
                     P_PROD_ROW       IN OUT CSTMS_PRODUCT%ROWTYPE,
                     P_ARC_ROW        IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                     P_AC_NO          IN VARCHAR2,
                     P_AC_BRN         IN VARCHAR2,
                     P_FN_CALL_ID     IN OUT NUMBER,
                     P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'Inside depks_rtl_teller_custom.fn_online. ...');
  
    DEBUG.PR_DEBUG('IF',
                   'Returning Successfully from depks_rtl_teller_custom.fn_online...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of depks_rtl_teller_custom.fn_online. ..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
  END FN_ONLINE;

  FUNCTION FN_ONLINE(P_BRN            IN VARCHAR2,
                     P_PRD            IN VARCHAR2,
                     P_CUST           IN VARCHAR2,
                     P_CCY            IN VARCHAR2,
                     P_AMT            IN NUMBER,
                     P_PERIOD         IN NUMBER,
                     P_ERR_CODE       IN OUT VARCHAR2,
                     P_PROD_ROW       IN OUT CSTMS_PRODUCT%ROWTYPE,
                     P_ARC_ROW        IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                     P_FN_CALL_ID     IN OUT NUMBER,
                     P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'Inside depks_rtl_teller_custom.fn_online. ...');
  
    DEBUG.PR_DEBUG('IF',
                   'Returning Successfully from depks_rtl_teller_custom.fn_online...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of depks_rtl_teller_custom.fn_online. ..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
  END FN_ONLINE;

  PROCEDURE PR_PRE_SUPERSCRIBE_ARC(P_FN_CALL_ID     IN OUT NUMBER,
                                   P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Inside pr_pre_superscribe_arc');
  
    DBG('Returning success from pr_pre_superscribe_arc');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of depks_rtl_teller_custom.pr_pre_superscribe_arc..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
  END PR_PRE_SUPERSCRIBE_ARC;

  FUNCTION FN_SAVE(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                   P_ARC_ROW             IN IFTMS_ARC_MAINT%ROWTYPE,
                   P_ERR_CODE            IN OUT VARCHAR2,
                   P_ERR_PARAM           IN OUT VARCHAR2,
                   P_FN_CALL_ID          IN OUT NUMBER,
                   P_TB_CUSTOM_DATA      IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of fn_save');
  
    DBG('Returning Successfuly from fn_save');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed inside when others of fn_save' || SQLERRM);
      RETURN FALSE;
  END;

END DEPKS_RTL_TELLER_CUSTOM;
/