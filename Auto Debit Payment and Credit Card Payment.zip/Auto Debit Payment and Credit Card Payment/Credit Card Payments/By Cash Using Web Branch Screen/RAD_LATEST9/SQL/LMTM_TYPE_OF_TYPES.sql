insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CREDIT_CARD_ACCS', 'Suspense Accounts for Credit Card - Master & Visa', 'SAMPATH1', 'SAMPATH2', to_date('20-02-2019 10:43:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-02-2019 10:43:32', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
