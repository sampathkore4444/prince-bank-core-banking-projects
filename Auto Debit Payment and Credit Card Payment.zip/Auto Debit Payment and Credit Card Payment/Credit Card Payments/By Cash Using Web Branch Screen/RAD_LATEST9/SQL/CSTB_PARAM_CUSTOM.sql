insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_SMART_VISTA_WS', 'http://10.80.80.68:7026/svis/CmsSvng?wsdl', 'Y');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_SMART_VISTA_WS_PWD', 'svwiadmin', 'N');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_SMART_VISTA_WS_UID', 'svwi', 'N');

COMMIT;
