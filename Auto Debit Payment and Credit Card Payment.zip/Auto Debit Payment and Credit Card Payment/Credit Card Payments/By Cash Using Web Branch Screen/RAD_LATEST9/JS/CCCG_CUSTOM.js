function fnPreReverse_CUSTOM(){
	appendTabData(document.getElementById("TBLPage"+"TAB_MAIN"));
	appendData(document.getElementById("TBLPageTAB_MAIN"));	
	msgxml = parent.msgxml;
	parent.fcjResponseDOM = fcjResponseDOM;
	return true;
}
function fnPostReverse_CUSTOM(){
	appendTabData(document.getElementById("TBLPage"+"TAB_MAIN"));
	appendData(document.getElementById("TBLPageTAB_MAIN"));	
	msgxml = parent.msgxml;
	parent.fcjResponseDOM = fcjResponseDOM;
	return true;
}