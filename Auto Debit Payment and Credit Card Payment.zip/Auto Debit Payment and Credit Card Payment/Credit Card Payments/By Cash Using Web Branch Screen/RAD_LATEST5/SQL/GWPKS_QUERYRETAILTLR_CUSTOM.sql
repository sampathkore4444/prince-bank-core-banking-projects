CREATE OR REPLACE PACKAGE BODY GWPKS_QUERYRETAILTLR_CUSTOM AS
  /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Change Tag        : PRF_CUSTOM_05_03072018
   **    Changes By        : Aniket
   **    Changes on        : 03-JUL-2018
   **    Description       : Changes related to teller advices specific to Prince Finance
    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'gwpks_queryretailtlr_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('RT', L_MSG);
  END DBG;

  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN
    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('IF',
                     '[ERROR] ' || 'gwpks_queryretailtlr_custom :' || P_DBG);
    ELSE
      DEBUG.PR_DEBUG('IF',
                     '[DEBUG] ' || 'gwpks_queryretailtlr_custom :' || P_DBG);
    END IF;
  END DBG;

  FUNCTION FN_BUILD_RTDETAILS(P_SOURCE         IN VARCHAR2,
                              P_PARENT_RES     IN VARCHAR2,
                              P_REFERENCE_NO   IN VARCHAR2,
                              P_TY_RTUPLD      IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                              P_PARENT         IN OUT VARCHAR2,
                              P_KEY            IN OUT VARCHAR2,
                              P_DATA           IN OUT VARCHAR2,
                              P_FORMAT         IN OUT VARCHAR2,
                              P_NODE           IN OUT VARCHAR2,
                              P_FN_CALL_ID     IN NUMBER,
                              P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    IF P_FN_CALL_ID = 1 THEN

      DBG('IF', 'Inside fn_build_rtdetails ...');
        
      --sampath starts
        IF GWPKS_UTIL.PKG_FUNC IN ('CCCG') THEN
          
        P_KEY := 'CHAR_FIELD3' || '~' || 'CHAR_FIELD4' || '~' ||
                   'CHAR_FIELD5' || '~' || 'CHAR_FIELD6' || '~' ||
                   'CHAR_FIELD7' || '~' || 'CHAR_FIELD8' || '~' || 'CHAR_FIELD9' || '~' || P_KEY;
                   
        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field7 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field8 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field9 || '~' ||
                    P_DATA;            
       
        END IF;
        --sampath ends

    END IF;
    DBG('IF', 'Returning Successfully from fn_build_rtdetails..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of gwpks_queryretailtlr_custom.fn_build_rtdetails ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_BUILD_RTDETAILS;

  FUNCTION FN_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                            P_PARENT_RES     IN VARCHAR2,
                            P_FCCREF         IN VARCHAR2,
                            P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                            P_XREF           IN VARCHAR2,
                            P_PARENT         IN OUT VARCHAR2,
                            P_TAG            IN OUT VARCHAR2,
                            P_DATA           IN OUT VARCHAR2,
                            P_FORMAT         IN OUT VARCHAR2,
                            P_FN_CALL_ID     IN NUMBER,
                            P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside CUSTOM function fn_build_fsreply..');

    DBG('**',
        'Returning successfully from the CUSTOM function fn_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of CUSTOM fn_build_fsreply..');
      RETURN FALSE;
  END FN_BUILD_FSREPLY;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_REPLY_FTDETAILS_PRE(P_TY_RTUPLD IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                  P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                                  P_DATA      IN OUT VARCHAR2,
                                  P_KEY       IN OUT VARCHAR2,
                                  P_PARENT    IN OUT VARCHAR2,
                                  P_FORMAT    IN OUT VARCHAR2,
                                  P_NODE      IN OUT VARCHAR2,
                                  P_CNT_LVL   IN OUT VARCHAR2,
                                  P_ERR_CODE  IN OUT VARCHAR2,
                                  P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_reply_ftdetails_Pre');

    DBG('Returning success from fn_reply_ftdetails_Pre');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of gwpks_queryretailtlr_custom.fn_reply_ftdetails_Pre..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
  END FN_REPLY_FTDETAILS_PRE;

  FUNCTION FN_REPLY_FTDETAILS_POST(P_TY_RTUPLD IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                   P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                                   P_DATA      IN OUT VARCHAR2,
                                   P_KEY       IN OUT VARCHAR2,
                                   P_PARENT    IN OUT VARCHAR2,
                                   P_FORMAT    IN OUT VARCHAR2,
                                   P_NODE      IN OUT VARCHAR2,
                                   P_CNT_LVL   IN OUT VARCHAR2,
                                   P_ERR_CODE  IN OUT VARCHAR2,
                                   P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_reply_ftdetails_Post');

    DBG('Returning success from fn_reply_ftdetails_Post');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_queryretailtlr_custom.fn_reply_ftdetails_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_REPLY_FTDETAILS_POST;

  FUNCTION FN_REPLY_CHGDETS(P_SOURCE         IN VARCHAR2,
                            P_FCCREF         IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                            P_DATA           IN OUT VARCHAR2,
                            P_KEY            IN OUT VARCHAR2,
                            P_PARENT         IN OUT VARCHAR2,
                            P_FORMAT         IN OUT VARCHAR2,
                            P_NODE           IN OUT VARCHAR2,
                            P_CNT_LVL        IN OUT VARCHAR2,
                            P_TS_LIST        IN OUT VARCHAR2,
                            P_TS_LIST1       IN OUT VARCHAR2,
                            P_TS_VALUE       IN OUT VARCHAR2,
                            P_TS_VALUE1      IN OUT VARCHAR2,
                            P_COUNT          IN INTEGER,
                            P_FN_CALL_ID     IN OUT NUMBER,
                            P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN
    DBG('Inside Custom function fn_reply_chgdets ...');

    DBG('Returning success from Custom function Fn_reply_chgdets');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of fn_reply_chgdets..');
      RETURN FALSE;

  END FN_REPLY_CHGDETS;

  FUNCTION FN_PRE_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                                P_PARENT_RES     IN VARCHAR2,
                                P_FCCREF         IN VARCHAR2,
                                P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                P_XREF           IN VARCHAR2,
                                P_PARENT         IN OUT VARCHAR2,
                                P_TAG            IN OUT VARCHAR2,
                                P_DATA           IN OUT VARCHAR2,
                                P_FORMAT         IN OUT VARCHAR2,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAM      IN OUT VARCHAR2,
                                P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                P_FN_CALL_ID     IN NUMBER) RETURN BOOLEAN IS

  BEGIN
    DBG('Inside the function Gwpks_Queryretailtlr_Custom.fn_pre_build_fsreply..');

    DBG('Returning successfully from the function fn_pre_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_pre_build_fsreply..');
      RETURN FALSE;
  END FN_PRE_BUILD_FSREPLY;

  FUNCTION FN_POST_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                                 P_PARENT_RES     IN VARCHAR2,
                                 P_FCCREF         IN VARCHAR2,
                                 P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                 P_XREF           IN VARCHAR2,
                                 P_PARENT         IN OUT VARCHAR2,
                                 P_TAG            IN OUT VARCHAR2,
                                 P_DATA           IN OUT VARCHAR2,
                                 P_FORMAT         IN OUT VARCHAR2,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAM      IN OUT VARCHAR2,
                                 P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                 P_FN_CALL_ID     IN NUMBER) RETURN BOOLEAN IS
    --PRF_CUSTOM_05_03072018 changes starts
    L_TB_EMPTY_TBL     GWPKS_CREATERETAILTLR.TY_RECS_TBL;
    L_TB_NAME_VAL_PAIR GWPKS_CREATERETAILTLR.TY_RECS_TBL;

    L_TS_TAG_VALUES VARCHAR2(32767);
    L_TS_TAG_NAMES  VARCHAR2(32767);
    L_NODE_NAME     VARCHAR2(50);
    L_CURR_TAG      VARCHAR2(255);
    L_P_CNT         INTEGER;
    L_TAG           VARCHAR2(32767);
    L_DATA          VARCHAR2(32767);
    L_NAME          VARCHAR2(650);
    L_F_NAME        VARCHAR2(200);
    L_M_NAME        VARCHAR2(200);
    L_L_NAME        VARCHAR2(200);
    L_DEP_TYPE      VARCHAR2(50);
    L_BEN_NAME      VARCHAR2(500);
    L_AMT_WORDS     VARCHAR2(4000);
    L_RTL_TELLER    DETBS_RTL_TELLER%ROWTYPE;
    L_ADV_TOP       VARCHAR2(500);
    L_MOB_NO        VARCHAR2(50);
    --PRF_CUSTOM_05_03072018 changes ends
  BEGIN
    DBG('Inside the function Gwpks_Queryretailtlr_Custom.fn_post_build_fsreply..');

    --PRF_CUSTOM_05_03072018 CHANGES STARTS
    DBG('PROD :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE);
    DBG('ANIKET WIL BE MODFYING THE TAGS HERE');

    L_TAG  := '';
    L_DATA := '';

    L_P_CNT := 1;

    L_NODE_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_PARENT,
                                               NULL,
                                               'N',
                                               L_P_CNT,
                                               '>'),
                       '??');

    WHILE L_NODE_NAME <> 'EOPL' LOOP
      DBG('Processing the node: ' || L_NODE_NAME);
      L_TB_NAME_VAL_PAIR := L_TB_EMPTY_TBL;
      L_TS_TAG_NAMES     := NVL(CSPKES_MISC.FN_GETPARAM(P_TAG,
                                                        P_TAG,
                                                        'N',
                                                        L_P_CNT,
                                                        '>'),
                                '??');

      IF L_TS_TAG_NAMES <> '??' THEN
        L_TAG := L_TAG || L_TS_TAG_NAMES;
      END IF;

      L_TS_TAG_VALUES := NVL(CSPKES_MISC.FN_GETPARAM(P_DATA,
                                                     P_DATA,
                                                     'N',
                                                     L_P_CNT,
                                                     '>'),
                             '??');

      IF L_TS_TAG_VALUES <> '??' THEN
        L_DATA := L_DATA || L_TS_TAG_VALUES;
      END IF;

      DBG('L_NODE_NAME :' || L_NODE_NAME);

      IF L_NODE_NAME = 'Blk-Transaction-Details' THEN
        DBG('before L_DATA :' || L_DATA);
        DBG('XREF :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF || '~' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);

        BEGIN
          SELECT *
            INTO L_RTL_TELLER
            FROM DETBS_RTL_TELLER
           WHERE XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED SELECTING FROM THE RTL TELLER ' || SQLERRM);
            BEGIN
              SELECT *
                INTO L_RTL_TELLER
                FROM DETBS_RTL_TELLER
               WHERE TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('FAILED AGAIN ' || SQLERRM);
                L_RTL_TELLER := NULL;
            END;
        END;

        DBG('TXN AMT :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT || '~' ||
            L_RTL_TELLER.TXN_AMOUNT);
        IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'TXN_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        ELSIF L_RTL_TELLER.TXN_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  L_RTL_TELLER.TXN_AMOUNT,
                                                  L_RTL_TELLER.TXN_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'TXN_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        END IF;

        DBG('OFS AMT :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT);
        IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'OFS_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        ELSIF L_RTL_TELLER.OFS_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  L_RTL_TELLER.OFS_AMOUNT,
                                                  L_RTL_TELLER.OFS_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'OFS_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        END IF;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                             L_RTL_TELLER.TXN_BRANCH)) LOOP
          L_TAG  := L_TAG || 'TXN_BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH,
                             L_RTL_TELLER.OFS_BRANCH)) LOOP
          L_TAG  := L_TAG || 'OFS_BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                             L_RTL_TELLER.BRANCH_CODE)) LOOP
          L_TAG  := L_TAG || 'BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE);
        FOR X IN (SELECT *
                    FROM CSTMS_PRODUCT
                   WHERE PRODUCT_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE,
                             L_RTL_TELLER.PRODUCT_CODE)) LOOP
          L_TAG     := L_TAG || 'PRODUCT_DESC~';
          L_DATA    := L_DATA || X.PRODUCT_DESCRIPTION || '~';
          L_ADV_TOP := X.PRODUCT_DESCRIPTION;
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
        FOR X IN (SELECT DECODE(ACCOUNT_TYPE,
                                'N',
                                'NOSTRO',
                                'S',
                                'SAVINGS',
                                'U',
                                'CHECKING',
                                'Y',
                                'TERM DEPOSIT',
                                '') AS AC_TYPE
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO = NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC,
                                          L_RTL_TELLER.TXN_ACC)
                     AND BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                             L_RTL_TELLER.TXN_BRANCH)) LOOP
          L_TAG  := L_TAG || 'TXN_AC_TYPE~';
          L_DATA := L_DATA || X.AC_TYPE || '~';
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
        FOR X IN (SELECT DECODE(ACCOUNT_TYPE,
                                'N',
                                'NOSTRO',
                                'S',
                                'SAVINGS',
                                'U',
                                'CHECKING',
                                'Y',
                                'TERM DEPOSIT',
                                '') AS AC_TYPE
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO = NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC,
                                          L_RTL_TELLER.OFS_ACC)
                     AND BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH,
                             L_RTL_TELLER.OFS_BRANCH)) LOOP
          L_TAG  := L_TAG || 'OFS_AC_TYPE~';
          L_DATA := L_DATA || X.AC_TYPE || '~';
        END LOOP;

        IF P_TY_RTUPLD.TBL_UDFDETAILS.COUNT > 0 THEN
          FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
            DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X)
                .FIELD_VAL);
            IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'BENEFICIARY_NAME' THEN
              L_TAG  := L_TAG || 'UD_BENF_NAME~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            ELSIF P_TY_RTUPLD.TBL_UDFDETAILS(X)
             .FIELD_NAME = 'BENEFICIARY_ID_TYPE' THEN
              L_TAG  := L_TAG || 'UD_BENF_ID_TYPE~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            ELSIF P_TY_RTUPLD.TBL_UDFDETAILS(X)
             .FIELD_NAME = 'BENEFICIARY_ID_NO' THEN
              L_TAG  := L_TAG || 'UD_BENF_ID_NO~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            END IF;
          END LOOP;
        END IF;
      END IF;

      DBG('ACTION TYPE IS :' || GWPKS_UTIL.PKG_ACTTYPE);
      IF GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
        L_ADV_TOP := L_ADV_TOP || ' REVERSAL';
      END IF;

      L_TAG  := L_TAG || 'ADV_TOP~';
      L_DATA := L_DATA || L_ADV_TOP || '~';

      IF L_TS_TAG_NAMES <> '??' THEN
        L_TAG := L_TAG || '>';
      END IF;

      IF L_TS_TAG_VALUES <> '??' THEN
        L_DATA := L_DATA || '>';
      END IF;

      L_P_CNT     := L_P_CNT + 1;
      L_NODE_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_PARENT, L_P_CNT, '>'),
                         '??');
    END LOOP;
    DBG('P_TAG :' || P_TAG);
    DBG('L_TAG :' || L_TAG);
    DBG('P_DATA :' || P_DATA);
    DBG('L_DATA :' || L_DATA);
    P_TAG  := L_TAG;
    P_DATA := L_DATA;
    DBG('Completed the data preparation into PL/SQL collection');
    --PRF_CUSTOM_05_03072018 CHANGES ENDS

    DBG('Returning successfully from the function fn_post_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_post_build_fsreply..');
      RETURN FALSE;
  END FN_POST_BUILD_FSREPLY;

  FUNCTION FN_PRE_BUILD_RTDETL_DEDQUERY(P_SOURCE       IN VARCHAR2,
                                        P_PARENT_RES   IN VARCHAR2,
                                        P_REFERENCE_NO IN VARCHAR2,
                                        P_PARENT       IN OUT VARCHAR2,
                                        P_TAG          IN OUT VARCHAR2,
                                        P_DATA         IN OUT VARCHAR2,
                                        P_FORMAT       IN OUT VARCHAR2,
                                        P_ERR_CODE     IN OUT VARCHAR2,
                                        P_ERR_PARAM    IN OUT VARCHAR2)

   RETURN BOOLEAN IS
  BEGIN
    DBG('**',
        'Inside the function gwpks_queryretailtlr_custom.fn_pre_build_rtdetl_dedquery..');

    DBG('**',
        'Returning successfully from the function fn_pre_build_rtdetl_dedquery..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of fn_pre_build_rtdetl_dedquery..');
      RETURN FALSE;
  END FN_PRE_BUILD_RTDETL_DEDQUERY;

END GWPKS_QUERYRETAILTLR_CUSTOM;
/