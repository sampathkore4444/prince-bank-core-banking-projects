CREATE OR REPLACE PACKAGE BODY gwpks_createretailtlr_custom AS

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF',
                   '[DEBUG] ' || 'Gwpks_CreateRetailTlr_Custom :' || P_DBG);
  END DBG;
  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN
    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('IF',
                     '[ERROR] ' || 'Gwpks_CreateRetailTlr_Custom :' ||
                     P_DBG);
    ELSE
      DEBUG.PR_DEBUG('IF',
                     '[DEBUG] ' || 'Gwpks_CreateRetailTlr_Custom :' ||
                     P_DBG);
    END IF;
  END DBG;

  --sampath starts
  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>',
                              NULL);
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns:ns4="http://sv.bpc.in/SVAP/iss" xmlns:ns3="http://bpc.ru/SVIS/ewallet/v1.0/" xmlns:ns2="http://bpc.ru/common/types/v0.1/" xmlns="http://bpc.ru/SVIS/cmsSvng/v1.1/"',
                              NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML, 'ns2:', NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</soap:Body></soap:Envelope>',
                              NULL);
  
  END PR_RETURN_COSMETIC_XML;

  FUNCTION get_param_val(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END get_param_val;

  FUNCTION FN_GET_ISO_CURRENCY_CODE(P_ISO_CCY IN VARCHAR2)
    RETURN CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE AS
    L_CCY_CODE CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE;
  BEGIN
    BEGIN
      SELECT CCY_CODE
        INTO L_CCY_CODE
        FROM CYTMS_CCY_DEFN_MASTER
       WHERE ISO_NUM_CCY_CODE = P_ISO_CCY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      RETURN L_CCY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN L_CCY_CODE;
    END;
    RETURN L_CCY_CODE;
  END FN_GET_ISO_CURRENCY_CODE;

  FUNCTION FN_CREDIT_CARD_HTTP_CALL(p_out_msg VARCHAR2,
                                    p_in_resp IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_buffer_size   NUMBER(10) := 512;
    l_substring_msg VARCHAR2(32767);
    l_raw_data      RAW(2000);
    l_clob_response CLOB;
    l_url           cstb_param.param_val%TYPE;
    l_resp_ok       BOOLEAN;
    l_resp_num      NUMBER;
  
  BEGIN
  
    debug.pr_DebuG('IF', 'In FN_FAST_HTTP_CALL');
    dbms_lob.createtemporary(lob_loc => l_clob_response, cache => TRUE);
  
    --Get URL of Smart Vista
    l_url := get_param_val('PGW_SMART_VISTA_WS');
  
    l_url := 'http://10.80.80.68:7026/svis/CmsSvng';
  
    debug.pr_DebuG('IF', 'l_url-->' || l_url);
    l_http_request := utl_http.begin_request(url          => l_url,
                                             method       => 'POST',
                                             http_version => 'HTTP/1.1');
    utl_http.set_header(l_http_request, 'User-Agent', 'Mozilla/4.0');
    utl_http.set_header(l_http_request, 'Connection', 'close');
    utl_http.set_header(l_http_request,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    -- UTL_HTTP.set_header (l_http_request, 'Content-Length', lengthb(CONVERT(p_out_msg, 'UTF8')));
  
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
    <<request_loop>>
  
    FOR i IN 0 .. ceil(length(p_out_msg) / l_buffer_size) - 1 LOOP
      l_substring_msg := substr(p_out_msg,
                                i * l_buffer_size + 1,
                                l_buffer_size);
      BEGIN
        l_raw_data := utl_raw.cast_to_raw(l_substring_msg);
        utl_http.write_raw(r => l_http_request, data => l_raw_data);
      EXCEPTION
        WHEN no_data_found THEN
          debug.pr_DebuG('IF', 'Request Loop NDF');
          EXIT request_loop;
      END;
    END LOOP request_loop;
    l_http_response := utl_http.get_response(l_http_request);
    debug.pr_DebuG('IF',
                   'Response> status_code: "' ||
                   l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      BEGIN
        <<response_loop>>
        LOOP
          utl_http.read_raw(l_http_response, l_raw_data, l_buffer_size);
          l_clob_response := l_clob_response ||
                             utl_raw.cast_to_varchar2(l_raw_data);
        END LOOP response_loop;
      EXCEPTION
        WHEN utl_http.end_of_body THEN
          utl_http.end_response(l_http_response);
        WHEN OTHERS THEN
          debug.pr_DebuG('IF', 'Inside Exception others in response');
          debug.pr_DebuG('IF', SQLERRM);
          debug.pr_DebuG('IF', dbms_utility.format_error_backtrace);
          utl_http.end_response(l_http_response);
      END;
      debug.pr_DebuG('IF', 'Out of Loop');
    
      p_in_resp := l_clob_response;
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    dbms_lob.freetemporary(l_clob_response);
  
    IF l_resp_ok THEN
      debug.pr_DebuG('IF', 'OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      debug.pr_DebuG('IF', 'PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_DebuG('IF', 'In WOT...Return false now...' || SQLERRM);
      RETURN FALSE;
  END FN_CREDIT_CARD_HTTP_CALL;
  --sampath ends

  FUNCTION FN_POP_PLSQL_TBL(P_NODE_NAME         IN VARCHAR2,
                            P_DTF               IN VARCHAR2,
                            P_TBL_NAME_VAL_PAIR IN OUT NOCOPY GWPKS_CREATERETAILTLR.TY_RECS_TBL,
                            P_TY_RTUPLD         IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                            P_ERR_CODE          IN OUT VARCHAR2,
                            P_ERR_PARAM         IN OUT VARCHAR2,
                            P_FN_CALL_ID        IN OUT NUMBER,
                            P_TB_CUSTOM_DATA    IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    --sampath starts
    l_formatted_msg    CLOB;
    L_FORMATTED_MSG1   CLOB;
    l_in_resp          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_CARD_ID          VARCHAR2(100);
    L_CARD_TYPE        VARCHAR2(100);
    L_CARD_STATUS      VARCHAR2(100);
    L_NAME_ON_CARD     VARCHAR2(100);
    L_TOTAL_AMOUNT_DUE VARCHAR2(100);
    L_PAYMENT_CCY      VARCHAR2(100);
  
    L_CREDIT_ACC_NO VARCHAR2(20);
    L_ERROR_CODE    VARCHAR2(255);
    L_ERROR_DESC    VARCHAR2(255);
    --sampath ends
  BEGIN
    IF P_FN_CALL_ID = 1 THEN
    
      DBG('IF', 'Inside fn_pop_plsql_tbl ...');
    
      --sampath starts for credit card payment by cash
      IF GWPKS_UTIL.PKG_FUNC IN ('CCCG') THEN
        IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH','SAVEAUTOAUTH') THEN
        
        IF P_TBL_NAME_VAL_PAIR.EXISTS('CHAR_FIELD3') THEN
            DBG('CREDIT CARD NUMBER=' || P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                .TYP_VAR_VALUE);
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 := P_TBL_NAME_VAL_PAIR('CHAR_FIELD3')
                                                            .TYP_VAR_VALUE;
          
        END IF;  
        
        
        
        
        DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3='||P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3);
          IF P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 IS NULL THEN
            --DBG('Participant Name Should not be null');
            P_ERR_CODE := '';
            OVPKSS.PR_APPENDTBL('IF-SVCC002', null);
            --Pr_Log_Error(p_Function_id, p_Source, 'IF-SVCC002', NULL);
            RETURN FALSE;
          END IF;
        
          L_FORMATTED_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://bpc.ru/SVIS/cmsSvng/v1.1/">
   <soapenv:Header>
      <wsse:Security  xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
         <wsse:UsernameToken wsu:Id="UsernameToken-1">
            <wsse:Username>' ||
                             get_param_val('PGW_SMART_VISTA_WS_UID') ||
                             '</wsse:Username>
            <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">' ||
                             get_param_val('PGW_SMART_VISTA_WS_PWD') ||
                             '</wsse:Password>
         </wsse:UsernameToken>
      </wsse:Security>
 </soapenv:Header>
   <soapenv:Body>
      <v1:getCardInfoRequest>
          <v1:cardNumber>' ||
                             P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 ||
                             '</v1:cardNumber>
      </v1:getCardInfoRequest>
   </soapenv:Body>
</soapenv:Envelope>';
        
          dbg('l_formatted_msg for fast' || L_FORMATTED_MSG);
        
          --Invoke SV Credit Card System
          IF NOT FN_CREDIT_CARD_HTTP_CALL(L_FORMATTED_MSG, L_IN_RESP) THEN
            DBG('failed to invoke Smart vista call');
            --RAISE E_UPDATE_ERROR;
            P_ERR_CODE := '';
            OVPKSS.PR_APPENDTBL('IF-SVCC003', null);
            RETURN FALSE;
          END IF;
        
          DBG('RESPONSE=' || L_IN_RESP);
        
          --Get Cosmetic XML
          PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);
        
          DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
        
          P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
        
          --Check if returned error or success
          L_ERROR_CODE := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/errorCode/text()')
                          .GETSTRINGVAL;
        
          IF L_ERROR_CODE <> 'SUCCESS' THEN
            L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/errorDesc/text()')
                            .GETSTRINGVAL;
          
            P_ERR_CODE := '';
            OVPKSS.PR_APPENDTBL('IF-SVCC003', null);
            --Pr_Log_Error(p_Function_id, p_Source, 'IF-SVCC003',    L_ERROR_DESC);
            RETURN FALSE;
          END IF;
        
          L_CREDIT_ACC_NO := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardAccounts/account/text()')
                             .GETSTRINGVAL;
        
          DBG('L_CREDIT_ACC_NO=' || L_CREDIT_ACC_NO);
        
          L_CARD_ID := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardId/text()')
                       .GETSTRINGVAL;
        
          DBG('L_CARD_ID=' || L_CARD_ID);
        
          L_CARD_TYPE := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardType/text()')
                         .GETSTRINGVAL;
        
          DBG('L_CARD_TYPE=' || L_CARD_TYPE);
        
          L_CARD_STATUS := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/cardStatusDesc/text()')
                           .GETSTRINGVAL;
        
          DBG('L_CARD_STATUS=' || L_CARD_STATUS);
        
          L_NAME_ON_CARD := P_DOCUMENT_XML.EXTRACT('/getCardInfoResponse/embossName/text()')
                            .GETSTRINGVAL;
        
          DBG('L_NAME_ON_CARD=' || L_NAME_ON_CARD);
        
          --Call Second API to get Amount Due
          L_FORMATTED_MSG1 := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://bpc.ru/SVIS/cmsSvng/v1.1/">
   <soapenv:Header>
      <wsse:Security  xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
         <wsse:UsernameToken wsu:Id="UsernameToken-1">
            <wsse:Username>svwi</wsse:Username>
            <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">svwiadmin</wsse:Password>
         </wsse:UsernameToken>
      </wsse:Security>
 </soapenv:Header>
   <soapenv:Body>
      <v1:getCreditCardInfoRequest>
         <v1:cardId>' || L_CARD_ID ||
                              '</v1:cardId>
      </v1:getCreditCardInfoRequest>
   </soapenv:Body>
</soapenv:Envelope>';
        
          dbg('l_formatted_msg1' || L_FORMATTED_MSG1);
        
          --Invoke SV Credit Card System
          IF NOT FN_CREDIT_CARD_HTTP_CALL(L_FORMATTED_MSG1, L_IN_RESP) THEN
            DBG('failed to invoke Smart vista call');
            --RAISE E_UPDATE_ERROR;
            P_ERR_CODE := '';
            OVPKSS.PR_APPENDTBL('IF-SVCC003', null);
            RETURN FALSE;
          END IF;
        
          DBG('RESPONSE=' || L_IN_RESP);
        
          --Get Cosmetic XML
          PR_RETURN_COSMETIC_XML(L_IN_RESP, L_COSMETIC_RES_MSG);
          DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
        
          P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
        
          --check if it is already refunded by other bank since message id is different
          L_TOTAL_AMOUNT_DUE := P_DOCUMENT_XML.EXTRACT('/getCreditCardInfoResponse/totalAmountDue/text()')
                                .GETSTRINGVAL;
        
          L_PAYMENT_CCY := P_DOCUMENT_XML.EXTRACT('/getCreditCardInfoResponse/accountCurrency/text()')
                           .GETSTRINGVAL;
        
          --Default Values
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4 := L_CREDIT_ACC_NO;
          --p_ifdcccas.v_credit_card_pymnt_by_cash.credit_card_ac_no := L_CREDIT_ACC_NO;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 := CASE
                                                           WHEN L_CARD_TYPE = '31' OR
                                                                L_CARD_TYPE = '33' THEN
                                                            'M'
                                                           WHEN L_CARD_TYPE = '51' OR
                                                                L_CARD_TYPE = '53' THEN
                                                            'V'
                                                           ELSE
                                                            NULL
                                                         END;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6 := L_CARD_STATUS;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field7 := L_NAME_ON_CARD;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field8 := L_TOTAL_AMOUNT_DUE / 100;
          P_TY_RTUPLD.ty_cstbs_ui_columns.char_field9 := FN_GET_ISO_CURRENCY_CODE(L_PAYMENT_CCY);
          
          --Default Product Code
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE := CASE
                                                           WHEN L_CARD_TYPE = '31' OR
                                                                L_CARD_TYPE = '33' THEN
                                                            'CCCH'
                                                           WHEN L_CARD_TYPE = '51' OR
                                                                L_CARD_TYPE = '53' THEN
                                                            'CCCV'
                                                           ELSE
                                                            NULL
                                                         END;
          P_TBL_NAME_VAL_PAIR('PRD').TYP_VAR_VALUE := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE;
          
        END IF;
      
      END IF;
      --sampath ends for credit card payment by cash
    
    END IF;
  
    IF P_FN_CALL_ID = 2 THEN
    
      DBG('IF', 'Inside fn_pop_plsql_tbl ...');
    
    END IF;
  
    DBG('IF', 'Returning Successfully from fn_pop_plsql_tbl..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of Gwpks_CreateRetailTlr_Custom.fn_pop_plsql_tbl ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_POP_PLSQL_TBL;

  PROCEDURE PR_PROCESS_MSG(P_IS_IN_MSG_CLOB  IN VARCHAR2,
                           P_REC_MSG_HEADER  IN GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                           P_IS_OUT_MSG_CLOB IN OUT VARCHAR2,
                           P_INSTR_REC       IN OUT NOCOPY GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                           P_TY_RTUPLD       IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                           P_FLAG            IN OUT NUMBER,
                           P_ERR_CODE        IN OUT VARCHAR2,
                           P_ERR_PARAM       IN OUT VARCHAR2,
                           P_FN_CALL_ID      IN OUT NUMBER,
                           P_TBL_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Inside the procedure gwpks_createretailtlr_custom.Pr_Process_Msg..');
  
    DBG('Returning successfully from the procedure gwpks_createretailtlr_custom.Pr_Process_Msg..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of the procedure gwpks_createretailtlr_custom.Pr_Process_Msg..');
  END PR_PROCESS_MSG;

  FUNCTION FN_TS_TO_TYPE(P_NODES_LIST         IN VARCHAR2,
                         P_TS_TAG_NAMES       IN VARCHAR2,
                         P_TS_TAG_VALUES      IN VARCHAR2,
                         P_TS_CLOB_TAG_NAMES  IN CLOB,
                         P_TS_CLOB_TAG_VALUES IN CLOB,
                         P_IS_IN_MSG_CLOB     IN VARCHAR2,
                         P_TY_RTUPLD          IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                         P_DTF                IN VARCHAR2,
                         P_FN_CALL_ID         IN OUT NUMBER,
                         P_TB_CUSTOM_DATA     IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                         P_ERR_CODE           IN OUT VARCHAR2,
                         P_ERR_PARAM          IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('IF',
                   'Inside gwpks_createretailtlr_custom.fn_ts_to_type ...');
    IF P_FN_CALL_ID = 1 THEN
    
      DBG('IF', 'Inside fn_ts_to_type ...');
    
    END IF;
    DBG('IF', 'Returning Successfully from fn_ts_to_type..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of gwpks_createretailtlr_custom.fn_ts_to_type ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_TS_TO_TYPE;

  FUNCTION FN_BUILD_CONTRACT_PCDETAILS(PKEY             IN VARCHAR2,
                                       PDATA            IN VARCHAR2,
                                       P_TBL_PC_DET     IN OUT NOCOPY DETB_PCTRN%ROWTYPE,
                                       P_FN_CALL_ID     IN OUT NUMBER,
                                       P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                       P_ERR_CODE       IN OUT VARCHAR2,
                                       P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('IF',
                   'Inside gwpks_createretailtlr_custom.fn_build_contract_pcdetails ...');
  
    DBG('IF', 'Returning Successfully from fn_build_contract_pcdetails..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of gwpks_createretailtlr_custom.fn_build_contract_pcdetails ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_BUILD_CONTRACT_PCDETAILS;

END GWPKS_CREATERETAILTLR_CUSTOM;
