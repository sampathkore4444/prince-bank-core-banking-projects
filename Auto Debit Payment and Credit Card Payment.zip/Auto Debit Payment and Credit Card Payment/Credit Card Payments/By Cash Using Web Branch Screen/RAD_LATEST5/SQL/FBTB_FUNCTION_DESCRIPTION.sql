insert into FBTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'CCCG', 'Teller', 'Cash Transactions', 'Credit Card Payment By Cash GL', null, 'WB', '0', 'Credit Card Payment By Cash GL', null);

COMMIT;
