insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFDCCPFT', 'Teller', 'Credit Card Payment', 'Payment By Fund Transfer', null, null, null, 'Credit Card Payment By Fund Transfer', 'IFDCCPFT');

insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'IFSCCPFT', 'Teller', 'View', 'Credit Card Payment Fund Transfer Summary', null, null, null, 'Credit Card Payment By Fund Transfer Summary', 'IFDCCPFT');

COMMIT;
