import java.io.File;
import java.io.IOException;
public class createDDFiles {
 public static void create(String[] args) {
  File file = new File("/u01/BPC_SVXP_Files/"); //initialize File object and passing path as argument  
  boolean result;
  try {
   result = file.createNewFile(); //creates a new file
   file.setReadOnly();
   if (result) // test if successfully created a new file  
   {
    System.out.println("file created " + file.getCanonicalPath()); //returns the path string  
   } else {
    System.out.println("File already exist at location: " + file.getCanonicalPath());
   }
  } catch (IOException e) {
   e.printStackTrace(); //prints exception if any  
  }
 }
}