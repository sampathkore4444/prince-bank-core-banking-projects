DECLARE
  x XMLType := XMLType('<?xml version="1.0" encoding="UTF-8"?>
<payment_orders>
    <inst_id>1001</inst_id>
    <file_date>2019-10-13</file_date>
    <file_number>1</file_number>
    <payment_order>
        <order_id>1910130000022410</order_id>
        <customer_number>100004261385</customer_number>
        <amount>9082</amount>
        <currency>840</currency>
        <order_date>2019-10-13T00:00:00</order_date>
        <parameter>
            <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
            <param_value>Auto Derect debit</param_value>
        </parameter>
        <parameter>
            <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
            <param_value>1000000001</param_value>
        </parameter>
        <purpose_id>10000004</purpose_id>
    </payment_order>
    <payment_order>
        <order_id>1910130000022411</order_id>
        <customer_number>100004261385</customer_number>
        <amount>9082</amount>
        <currency>840</currency>
        <order_date>2019-10-13T00:00:00</order_date>
        <parameter>
            <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
            <param_value>Auto Derect debit</param_value>
        </parameter>
        <parameter>
            <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
            <param_value>1000000001</param_value>
        </parameter>
        <purpose_id>10000004</purpose_id>
    </payment_order>
    <payment_order>
        <order_id>1910130000022412</order_id>
        <customer_number>100004261385</customer_number>
        <amount>9082</amount>
        <currency>840</currency>
        <order_date>2019-10-13T00:00:00</order_date>
        <parameter>
            <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
            <param_value>Auto Derect debit</param_value>
        </parameter>
        <parameter>
            <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
            <param_value>1000000001</param_value>
        </parameter>
        <purpose_id>10000004</purpose_id>
    </payment_order>
</payment_orders>');
BEGIN
  FOR r IN (SELECT ExtractValue(Value(p),
                                '/payment_order/order_id/text()') as order_id,
                   ExtractValue(Value(p),
                                '/payment_order/customer_number/text()') as customer_number,
                   ExtractValue(Value(p),
                                '/payment_order/amount/text()') as amount
              FROM TABLE(XMLSequence(Extract(x,
                                             '/payment_orders/payment_order'))) p) LOOP
    DBMS_OUTPUT.PUT_LINE(r.order_id);
  END LOOP;
END;



DECLARE

  L_RESPONSE         VARCHAR2(32767);
  L_SNIPPET          XMLTYPE;
  L_IX               BINARY_INTEGER;
  L_TEXT             CLOB;
  L_START            NUMBER := 1;
  L_END              NUMBER := 0;
  L_NO_OF_PAY_ORDERS NUMBER := 0;
  L_PAY_ORDER        CLOB;
  L_REQ_MSG          CLOB := '<?xml version="1.0" encoding="UTF-8"?>
<payment_orders>
    <inst_id>1001</inst_id>
    <file_date>2019-10-13</file_date>
    <file_number>1</file_number>
    <payment_order>
        <order_id>1910130000022410</order_id>
        <customer_number>100004261385</customer_number>
        <amount>9082</amount>
        <currency>840</currency>
        <order_date>2019-10-13T00:00:00</order_date>
        <parameter>
            <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
            <param_value>Auto Derect debit</param_value>
        </parameter>
        <parameter>
            <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
            <param_value>1000000001</param_value>
        </parameter>
        <purpose_id>10000004</purpose_id>
    </payment_order>
    <payment_order>
        <order_id>1910130000022411</order_id>
        <customer_number>100004261385</customer_number>
        <amount>9082</amount>
        <currency>840</currency>
        <order_date>2019-10-13T00:00:00</order_date>
        <parameter>
            <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
            <param_value>Auto Derect debit</param_value>
        </parameter>
        <parameter>
            <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
            <param_value>1000000001</param_value>
        </parameter>
        <purpose_id>10000004</purpose_id>
    </payment_order>
    <payment_order>
        <order_id>1910130000022412</order_id>
        <customer_number>100004261385</customer_number>
        <amount>9082</amount>
        <currency>840</currency>
        <order_date>2019-10-13T00:00:00</order_date>
        <parameter>
            <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
            <param_value>Auto Derect debit</param_value>
        </parameter>
        <parameter>
            <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
            <param_value>1000000001</param_value>
        </parameter>
        <purpose_id>10000004</purpose_id>
    </payment_order>
</payment_orders>';
  E_UPDATE_ERROR EXCEPTION;
  P_ERR_CODE   VARCHAR2(1000);
  P_ERR_PARAMS VARCHAR2(1000);

BEGIN

  L_NO_OF_PAY_ORDERS := (LENGTH(L_REQ_MSG) -
                        LENGTH(REPLACE(L_REQ_MSG, '</payment_order>', ''))) /
                        length('</payment_order>');

  DBMS_OUTPUT.PUT_LINE('L_NO_OF_PAY_ORDERS=' || L_NO_OF_PAY_ORDERS);

  FOR G IN 1 .. L_NO_OF_PAY_ORDERS LOOP
    
    DBMS_OUTPUT.PUT_LINE('G value=' || G);
    DBMS_OUTPUT.PUT_LINE('BEGIN L_START=' || L_START);
    DBMS_OUTPUT.PUT_LINE('BEGIN L_END=' || L_END);
    
    L_START := INSTR(L_REQ_MSG, '<payment_order>', L_START, G);
    L_END   := INSTR(L_REQ_MSG, '</payment_order>', L_START, 1);
    
    DBMS_OUTPUT.PUT_LINE('AFTER L_START=' || L_START);
    DBMS_OUTPUT.PUT_LINE('AFTER L_END=' || L_END);
  
    --DBMS_OUTPUT.PUT_LINE('FINAL SUB END=' || L_END - L_START + LENGTH('</payment_order>'));
  
    L_PAY_ORDER := SUBSTR(L_REQ_MSG,
                          L_START,
                          L_END - L_START + LENGTH('</payment_order>'));
  
    DBMS_OUTPUT.PUT_LINE('L_PAY_ORDER=' || L_PAY_ORDER);
    
    L_START := 1;
  
    DBMS_OUTPUT.PUT_LINE('-------------------');
  
  END LOOP;

  -- RETURN TRUE;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR CODE=' || SQLCODE);
    DBMS_OUTPUT.PUT_LINE('ERROR MESSAGE=' || SQLERRM);
    -- RETURN FALSE;
END;
