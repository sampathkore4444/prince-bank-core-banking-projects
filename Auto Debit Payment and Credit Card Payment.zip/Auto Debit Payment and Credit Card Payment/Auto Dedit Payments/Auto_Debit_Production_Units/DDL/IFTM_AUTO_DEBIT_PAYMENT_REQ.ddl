-- Create table
create table IFTM_AUTO_DEBIT_PAYMENT_REQ
(
  order_id    VARCHAR2(16) not null,
  cust_name   VARCHAR2(200),
  amount      NUMBER(22,3),
  currency    VARCHAR2(3),
  order_date  DATE,
  cust_ac_no  VARCHAR2(20),
  purpose_id  VARCHAR2(8),
  request_msg CLOB,
  status      CHAR(1)
)
/