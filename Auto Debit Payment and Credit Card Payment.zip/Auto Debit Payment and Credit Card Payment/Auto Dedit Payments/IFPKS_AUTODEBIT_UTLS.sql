CREATE OR REPLACE PACKAGE BODY IFPKS_AUTODEBIT_UTLS AS

  /*PROCEDURE PR_INSERT_AUTO_DEBIT_PAYMNTS(P_ORDER_ID    IFTM_AUTO_DEBIT_PAYMENT_REQ.ORDER_ID%TYPE,
                                         P_CUST_NAME   IFTM_AUTO_DEBIT_PAYMENT_REQ.CUST_NAME%TYPE,
                                         P_AMOUNT      IFTM_AUTO_DEBIT_PAYMENT_REQ.AMOUNT%TYPE,
                                         P_CURRENCY    IFTM_AUTO_DEBIT_PAYMENT_REQ.CURRENCY%TYPE,
                                         P_ORDER_DATE  IFTM_AUTO_DEBIT_PAYMENT_REQ.ORDER_DATE%TYPE,
                                         P_CUST_AC_NO  IFTM_AUTO_DEBIT_PAYMENT_REQ.CUST_AC_NO%TYPE,
                                         P_PURPOSE_ID  IFTM_AUTO_DEBIT_PAYMENT_REQ.PURPOSE_ID%TYPE,
                                         P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE,
                                         P_STATUS      IFTM_AUTO_DEBIT_PAYMENT_REQ.STATUS%TYPE) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    INSERT INTO IFTM_AUTO_DEBIT_PAYMENT_REQ
    VALUES
      (P_ORDER_ID,
       P_CUST_NAME,
       P_AMOUNT,
       P_CURRENCY,
       P_ORDER_DATE,
       P_CUST_AC_NO,
       P_PURPOSE_ID,
       P_REQUEST_MSG,
       P_STATUS);
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF', 'FAILED IN PR_INSERT_AUTO_DEBIT_PAYMNTS');
      DEBUG.PR_DEBUG('IF', 'ERROR CODE=' || SQLCODE);
      DEBUG.PR_DEBUG('IF', 'ERROR MESSAGE=' || SQLERRM);
    
  END PR_INSERT_AUTO_DEBIT_PAYMNTS;*/

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_AUTODEBIT_UTLS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_INSERT_ORDER_ID_INVOKE_LOG(P_ORDER_ID          IN VARCHAR2,
                                          P_REF_NO            IN VARCHAR2,
                                          P_INVOKE_START_DATE IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_ORDER_ID_INVOKE_LOG');
  
    INSERT INTO IFTB_AUTO_DEBIT_ORDER_ID_LOG
      (ORDER_ID, TRN_REF_NO, INVOKE_DATE_START)
    VALUES
      (P_ORDER_ID, P_REF_NO, P_INVOKE_START_DATE);
  
    COMMIT;
    DBG('END OF PR_INSERT_ORDER_ID_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_ORDER_ID_INVOKE_LOG');
      DBG('ERROR CODE IN PR_INSERT_ORDER_ID_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_ORDER_ID_INVOKE_LOG=' || SQLERRM);
    
  END PR_INSERT_ORDER_ID_INVOKE_LOG;

  PROCEDURE PR_UPDATE_ORDER_ID_INVOKE_LOG(P_ORDER_ID        IN VARCHAR2,
                                          P_REF_NO          IN VARCHAR2,
                                          P_STATUS          IN CHAR,
                                          P_ERR_CODE        IN VARCHAR2,
                                          P_ERR_PARAM       IN VARCHAR2,
                                          P_INVOKE_DATE_END IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_ORDER_ID_INVOKE_LOG');
  
    UPDATE IFTB_AUTO_DEBIT_ORDER_ID_LOG
       SET STATUS          = P_STATUS,
           ERROR_CODE      = P_ERR_CODE,
           ERROR_PARAM     = P_ERR_PARAM,
           INVOKE_DATE_END = P_INVOKE_DATE_END
     WHERE ORDER_ID = P_ORDER_ID
       AND TRN_REF_NO = P_REF_NO;
    COMMIT;
    DBG('END OF PR_UPDATE_ORDER_ID_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_ORDER_ID_INVOKE_LOG');
      DBG('ERROR CODE IN PR_UPDATE_ORDER_ID_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_ORDER_ID_INVOKE_LOG=' || SQLERRM);
  END PR_UPDATE_ORDER_ID_INVOKE_LOG;

  PROCEDURE PR_UPDATE_AUTO_DEBIT_TRACKER(P_ORDER_ID IN VARCHAR2,
                                         P_STATUS   IN CHAR) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_AUTO_DEBIT_TRACKER');
  
    UPDATE IFTB_AUTO_DEBIT_INCOMING_TRACK
       SET STATUS = P_STATUS
     WHERE ORDER_ID = P_ORDER_ID;
  
    COMMIT;
    DBG('END OF PR_UPDATE_AUTO_DEBIT_TRACKER');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_AUTO_DEBIT_TRACKER');
      DBG('ERROR CODE IN PR_UPDATE_AUTO_DEBIT_TRACKER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_AUTO_DEBIT_TRACKER=' || SQLERRM);
  END PR_UPDATE_AUTO_DEBIT_TRACKER;

  FUNCTION FN_GET_AUTODEBIT_RES_CLOB RETURN CLOB IS
    L_CLOB CLOB;
  BEGIN
  
    L_CLOB := '<payment_order>
    <order_id>$L_ORDER_ID</order_id>
    <resp_code>$L_RESP_CODE</resp_code>
    <amount>
         <amount_value>$L_AMOUNT</amount_value>
         <currency>$L_ISO_CCY</currency>
    </amount>
    <currency>$L_ISO_CCY</currency>
    <resp_amount>
         <amount_value>$L_AMOUNT</amount_value>
         <currency>$L_ISO_CCY</currency>			
    </resp_amount>
</payment_order>';
  
    RETURN L_CLOB;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN RETURNING FN_GET_AUTODEBIT_RES_CLOB');
      DBG('ERROR CODE IN FN_GET_AUTODEBIT_RES_CLOB=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AUTODEBIT_RES_CLOB=' || SQLERRM);
  END FN_GET_AUTODEBIT_RES_CLOB;

  FUNCTION FN_GET_ISO_CURRENCY_CODE(P_ISO_CCY IN VARCHAR2)
    RETURN CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE AS
    L_CCY_CODE CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE;
  BEGIN
    BEGIN
      SELECT CCY_CODE
        INTO L_CCY_CODE
        FROM CYTMS_CCY_DEFN_MASTER
       WHERE ISO_NUM_CCY_CODE = P_ISO_CCY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      RETURN L_CCY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN L_CCY_CODE;
    END;
    RETURN L_CCY_CODE;
  END FN_GET_ISO_CURRENCY_CODE;

  FUNCTION FN_GET_PARAMS RETURN CSTB_PARAM_CUSTOM%ROWTYPE RESULT_CACHE RELIES_ON(CSTB_PARAM_CUSTOM) IS
  BEGIN
    DBG('Inside FN_GET_PARAMS');
    SELECT *
      INTO g_cstb_params
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = 'AUTO_DEBIT_PAYMENT_DTLS';
    DBG('Returing from FN_GET_PARAMS');
    RETURN g_cstb_params;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in FN_GET_PARAMS' || SQLERRM);
      DBG('Error ' || dbms_utility.format_error_backtrace);
      g_cstb_params := NULL;
      RETURN g_cstb_params;
  END;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<?xml version="1.0" encoding="UTF-8"?>',
                              NULL);
  
  END PR_RETURN_COSMETIC_XML;

  PROCEDURE PR_WRITE_CLOB_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                  P_IN_FILE_NAME IN VARCHAR2,
                                  P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_CLOB_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_CLOB_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_CLOB_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_CLOB_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_CLOB_TO_FILE;

  PROCEDURE PR_GENERATE_AUTODEBIT_RESPONSE IS
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
    L_RESP_CODE     VARCHAR2(10);
  BEGIN
  
    DBG('START OF PR_GENERATE_AUTODEBIT_RESPONSE');
  
    FOR G IN (SELECT * FROM IFTB_AUTODEBIT_INC_TRACK) LOOP
    
      L_RESP_TEMPLATE := FN_GET_AUTODEBIT_RES_CLOB;
    
      L_FILE_NAME := G.FILE_NAME;
    
      L_RESP_CODE := CASE G.STATUS
                       WHEN 'P' THEN
                        'PORC0001'
                       WHEN 'E' THEN
                        'PORC0002'
                       ELSE
                        'PORC0003'
                     END;
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_ORDER_ID', G.ORDER_ID);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_RESP_CODE',
                                 L_RESP_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_AMOUNT', G.TXN_AMOUNT);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_AMOUNT', G.TXN_AMOUNT);
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_ISO_CCY',
                                 G.ISO_CCY_CODE);
    
      L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
    
      L_RESP_TEMPLATE := NULL;
    
    END LOOP;
  
    DBG('DONE WITH GENERATING CLOB RESPONSE');
  
    --Write to output file
    DBG('START OF WRITING CLOB TO AN XML FILE');
    PR_WRITE_CLOB_TO_FILE('/u01/fcubs/interfaces/Auto_Debit_Payment/Incoming/comp',
                          REPLACE(L_FILE_NAME, 'REQ', 'RES') || '.XML',
                          L_RESP_CLOB);
  
    DBG('END OF WRITING CLOB TO AN XML FILE');
  
    DBG('DELETING FROM TEMP TABLE:IFTB_AUTODEBIT_INC_TRACK');
    DELETE FROM IFTB_AUTODEBIT_INC_TRACK;
    COMMIT;
  
    DBG('END OF PR_GENERATE_AUTODEBIT_RESPONSE');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GENERATE_AUTODEBIT_RESPONSE');
      DBG('ERROR CODE IN PR_GENERATE_AUTODEBIT_RESPONSE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GENERATE_AUTODEBIT_RESPONSE=' || SQLERRM);
  END PR_GENERATE_AUTODEBIT_RESPONSE;

  PROCEDURE PR_INIT_MSG IS
    FILE      VARCHAR2(32767);
    FILE_NAME VARCHAR2(100);
    FPATH     VARCHAR2(100);
  BEGIN
    --global.pr_init('000', 'SYSTEM');
    --debug.pr_close;
    DBG('entered  ');
    g_cstb_params := FN_GET_PARAMS;
    DBG('Income path :' || g_cstb_params.PARAM_VAL);
    SELECT DIRECTORY_PATH
      INTO FPATH
      FROM DBA_DIRECTORIES
     WHERE DIRECTORY_NAME = g_cstb_params.PARAM_VAL;
  
    DBG('FPATH  - ' || FPATH);
    FILE_NAME := DIRLIST_FILE('/u01/fcubs/interfaces/Auto_Debit_Payment/Incoming/ready');
    DBG('FILE_NAME  - ' || FILE_NAME);
    /*LOOP
     EXIT WHEN FILE IS NULL;
     P_FILE_NAME := SUBSTR(FILE, INSTR(FILE, ',', -1) + 1);
     DBG('FILE NAME IS: ' || P_FILE_NAME);
      
      --FOR G IN (SELECT * FROM )
      
      --P_FILE_NAME := 'DIRECT_DEBIT_REQ_'|| TO_CHAR(SYSDATE,'YYYYMMDD')||'_';
      
      
      --FILE := SUBSTR(FILE, 1, INSTR(FILE, ',', -1) - 1);
    END LOOP;*/
    PR_MOVE_FILE(FILE_NAME);
    DBG('Success  ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INIT_MSG ' || SQLERRM);
  END PR_INIT_MSG;

  PROCEDURE PR_MOVE_FILE(P_FILE_NAME IN VARCHAR2) IS
    L_XML XMLTYPE;
  BEGIN
  
    --GLOBAL.PR_INIT('002', 'SYSTEM');
  
    DBG('INSIDE PR_MOVE_FILE');
  
    IF P_FILE_NAME IS NOT NULL THEN
      UTL_FILE.FRENAME('AUTO_DEBIT_READY',
                       P_FILE_NAME,
                       'AUTO_DEBIT_WIP',
                       P_FILE_NAME,
                       TRUE);
      DBG('moved to wip');
      DBG('File name: ' || P_FILE_NAME);
    
      SELECT XMLTYPE(BFILENAME('AUTO_DEBIT_WIP', P_FILE_NAME),
                     NLS_CHARSET_ID('AL32UTF16'))
        INTO L_XML
        FROM DUAL;
    
      PR_AUTO_DEBIT_INC_HANDOFF(L_XML, P_FILE_NAME);
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN WOT OF PR_MOVE_FILE=' || SQLERRM);
  END PR_MOVE_FILE;

  PROCEDURE PR_PROCESS_AUTO_DEBIT_ORDER_ID IS
    --Accounting Entry Table Building
    l_init_acc_hoff   actbs_handoff%ROWTYPE;
    l_acc_hoff        acpkss.tbl_achoff;
    l_hoff_count      INTEGER := 0;
    L_error_code      VARCHAR2(200);
    L_error_parameter VARCHAR2(200);
    l_contract_ref_no cstbs_contract.contract_ref_no%TYPE;
    l_event_sr_no     cstbs_contract_event_log.event_seq_no%TYPE := '1';
    --l_ac_no           sttm_cust_account.cust_ac_no%TYPE := '000002756';
    l_ac_no sttm_cust_account.cust_ac_no%TYPE;
    --l_ac_ccy          sttm_cust_account.ccy%TYPE := 'USD';
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_fcy_amount   actbs_daily_log.fcy_amount%TYPE := '';
    l_counterparty sttm_cust_account.cust_no%TYPE := '';
    l_mishead      actbs_daily_log.mis_head%TYPE := '';
    l_amount_tag   actbs_daily_log.amount_tag%TYPE := 'TXN_AMT';
    l_event        actbs_daily_log.event%TYPE := 'INIT';
    l_drcrind      VARCHAR2(1) := 'D';
    l_trn_code     sttms_trn_code.trn_code%TYPE := 'CCI'; --check with team
  
    L_ORDER_ID   IFTB_AUTO_DEBIT_INCOMING_TRACK.ORDER_ID%TYPE;
    L_CUST_NO    IFTM_AUTO_DEBIT_INC_PAYMENT.CUSTOMER_NO%TYPE;
    L_AMOUNT     IFTM_AUTO_DEBIT_INC_PAYMENT.AMOUNT%TYPE;
    L_CURRENCY   IFTM_AUTO_DEBIT_INC_PAYMENT.CURRENCY%TYPE;
    L_ORDER_DATE IFTM_AUTO_DEBIT_INC_PAYMENT.ORDER_DATE%TYPE;
    L_PURPOSE_ID IFTM_AUTO_DEBIT_INC_PAYMENT.PURPOSE_ID %TYPE;
  
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
  
    L_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
    L_EXCH_RATE    ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG    NUMBER;
    L_TXN_AMT      IFTM_AUTO_DEBIT_INC_PAYMENT.AMOUNT%TYPE;
    L_CCY_CODE     CYTM_CCY_DEFN_MASTER.CCY_CODE%TYPE;
    L_SERIAL_NO    VARCHAR2(16);
    L_TRN_REF_NO   Actb_Daily_Log.TRN_REF_NO%TYPE;
    P_ERR_CODE     VARCHAR2(255);
  
    CURSOR C1 IS
      SELECT *
        FROM IFTB_AUTO_DEBIT_INCOMING_TRACK
       WHERE STATUS IN ('U', 'E');
  
  BEGIN
  
    --GLOBAL.PR_INIT('001', 'SYSTEM');
  
    DBG('INSIDE PR_PROCESS_AUTO_DEBIT_ORDER_ID');
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        PR_RETURN_COSMETIC_XML(G.REQUEST_MSG, L_COSMETIC_RES_MSG);
      
        DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
      
        P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
      
        --Get Order id
      
        L_ORDER_ID := P_DOCUMENT_XML.EXTRACT('/payment_order/order_id/text()')
                      .GETSTRINGVAL;
        DBG('L_ORDER_ID=' || L_ORDER_ID);
      
        --Get Customer No
        L_CUST_NO := P_DOCUMENT_XML.EXTRACT('/payment_order/customer_number/text()')
                     .GETSTRINGVAL;
        DBG('L_CUST_NO=' || L_CUST_NO);
      
        --Get Amount
        L_AMOUNT := P_DOCUMENT_XML.EXTRACT('/payment_order/amount/text()')
                    .GETSTRINGVAL;
        DBG('L_AMOUNT=' || L_AMOUNT);
      
        --Get Currency
        L_CURRENCY := P_DOCUMENT_XML.EXTRACT('/payment_order/currency/text()')
                      .GETSTRINGVAL;
        DBG('L_CURRENCY=' || L_CURRENCY);
      
        --Get Iso Numeric Currency Code
        L_CCY_CODE := FN_GET_ISO_CURRENCY_CODE(L_CURRENCY);
      
        DBG('L_CCY_CODE=' || L_CCY_CODE);
      
        --Get Order Date                           
        L_ORDER_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/payment_order/order_date/text()')
                                                  .GETSTRINGVAL,
                                                  'YYYY-MM-DD"T"HH24:mi:ss') AS DATE),
                                'YYYY-MM-DD');
      
        /*L_ORDER_DATE := P_DOCUMENT_XML.EXTRACT('/payment_order/order_date/text()')
        .GETSTRINGVAL;*/
      
        DBG('L_ORDER_DATE=' || L_ORDER_DATE);
      
        --Get Savings Account
        L_AC_NO := P_DOCUMENT_XML.EXTRACT('/payment_order/parameter[2]/param_value/text()')
                   .GETSTRINGVAL;
        DBG('L_AC_NO=' || L_AC_NO);
      
        --Get Purpose Id
        L_PURPOSE_ID := P_DOCUMENT_XML.EXTRACT('/payment_order/purpose_id/text()')
                        .GETSTRINGVAL;
        DBG('L_PURPOSE_ID=' || L_PURPOSE_ID);
      
        --Get Account details
        BEGIN
          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_AC_NO;
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;
      
        GLOBAL.PR_INIT(L_CUST_ACCOUNT.BRANCH_CODE, 'SYSTEM');
      
        --XRATE CALCULATION STARTS
        IF L_CURRENCY <> L_CUST_ACCOUNT.CCY THEN
          /*
          BEGIN
            SELECT DECODE(L_PROD.RATE_CODE_PREFERRED,
                          'B',
                          'S',
                          'S',
                          'B',
                          'M',
                          'M',
                          L_PROD.RATE_TYPE_PREFERRED)
              INTO L_RATE_CODE1
              FROM DUAL;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Exception found l_rate_code-> ' || L_RATE_CODE1);
          END;
          DBG('L_RATE_CODE1=' || L_RATE_CODE1);
          DBG('l_prod.rate_type_preferred=' || L_PROD.RATE_TYPE_PREFERRED);
          */
        
          IF NOT CYPKSS.FN_GETRATE(L_CUST_ACCOUNT.BRANCH_CODE,
                                   L_CUST_ACCOUNT.CCY,
                                   L_CCY_CODE, --'KHR', --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                   'STANDARD', --L_PROD.RATE_TYPE_PREFERRED,
                                   'B', --L_RATE_CODE1, --l_prod.rate_code_preferred,
                                   GLOBAL.APPLICATION_DATE,
                                   GLOBAL.APPLICATION_DATE,
                                   L_EXCH_RATE,
                                   L_RATE_FLAG,
                                   L_ERROR_CODE) THEN
            DBG('FAILED IN FN_GETRATE');
            ROLLBACK;
          END IF;
        ELSE
          L_EXCH_RATE := 1;
        END IF;
      
        DBG('L_EXCH_RATE=' || L_EXCH_RATE);
      
        --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CCY_CODE,
                                      L_CUST_ACCOUNT.CCY,
                                      L_AMOUNT,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_TXN_AMT,
                                      L_ERROR_PARAMETER) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
          ROLLBACK;
        END IF;
        DBG('FINAL L_TXN_AMT=' || L_TXN_AMT);
      
        --GET REFERENCE NO
        IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                           'SAMP',
                                           GLOBAL.APPLICATION_DATE,
                                           L_SERIAL_NO,
                                           L_TRN_REF_NO,
                                           P_ERR_CODE) THEN
          DBG('FAILED IN GENERATION TRANSACTION REF NO');
          ROLLBACK TO A;
        ELSE
          DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
        END IF;
      
        --Log Auto Debit Accounting Entry Log
        PR_INSERT_ORDER_ID_INVOKE_LOG(L_ORDER_ID, L_TRN_REF_NO, SYSDATE);
      
        --Building Accounting entry table
        L_INIT_ACC_HOFF := NULL;
        L_ACC_HOFF(L_HOFF_COUNT) := L_INIT_ACC_HOFF;
        L_ACC_HOFF(L_HOFF_COUNT).MODULE := 'IF';
        L_ACC_HOFF(L_HOFF_COUNT).TRN_REF_NO := L_TRN_REF_NO;
        L_ACC_HOFF(L_HOFF_COUNT).EVENT_SR_NO := L_EVENT_SR_NO;
        L_ACC_HOFF(L_HOFF_COUNT).EVENT := L_EVENT;
        L_ACC_HOFF(L_HOFF_COUNT).AC_BRANCH := L_CUST_ACCOUNT.BRANCH_CODE;
        L_ACC_HOFF(L_HOFF_COUNT).AC_NO := L_AC_NO;
      
        L_ACC_HOFF(L_HOFF_COUNT).AC_CCY := L_CUST_ACCOUNT.CCY;
        L_ACC_HOFF(L_HOFF_COUNT).DRCR_IND := L_DRCRIND;
        L_ACC_HOFF(L_HOFF_COUNT).TRN_CODE := L_TRN_CODE;
        L_ACC_HOFF(L_HOFF_COUNT).AMOUNT_TAG := L_AMOUNT_TAG;
      
        IF L_CURRENCY <> L_CUST_ACCOUNT.CCY THEN
          L_ACC_HOFF(L_HOFF_COUNT).FCY_AMOUNT := L_TXN_AMT;
          L_ACC_HOFF(L_HOFF_COUNT).LCY_AMOUNT := L_AMOUNT;
        ELSE
          L_ACC_HOFF(L_HOFF_COUNT).FCY_AMOUNT := L_FCY_AMOUNT;
          L_ACC_HOFF(L_HOFF_COUNT).LCY_AMOUNT := L_TXN_AMT;
        
        END IF;
      
        --L_ACC_HOFF(L_HOFF_COUNT).EXCH_RATE := 4020;
        L_ACC_HOFF(L_HOFF_COUNT).EXCH_RATE := L_EXCH_RATE;
        --L_ACC_HOFF(L_HOFF_COUNT).LCY_AMOUNT := L_AMOUNT;
        --L_ACC_HOFF(L_HOFF_COUNT).LCY_AMOUNT := L_TXN_AMT;
        L_ACC_HOFF(L_HOFF_COUNT).RELATED_CUSTOMER := L_COUNTERPARTY;
        L_ACC_HOFF(L_HOFF_COUNT).TRN_DT := GLOBAL.APPLICATION_DATE;
        L_ACC_HOFF(L_HOFF_COUNT).VALUE_DT := GLOBAL.APPLICATION_DATE;
        L_ACC_HOFF(L_HOFF_COUNT).INSTRUMENT_CODE := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).NETTING_IND := 'N';
        L_ACC_HOFF(L_HOFF_COUNT).USER_ID := GLOBAL.USER_ID;
        L_ACC_HOFF(L_HOFF_COUNT).MIS_HEAD := L_MISHEAD;
        L_ACC_HOFF(L_HOFF_COUNT).FINANCIAL_CYCLE := NULL; -- INPUT BOTH THE FINANCIAL CYCLE AND PERIOD CODE TO POST BACK PERIOD ENTRIES
        L_ACC_HOFF(L_HOFF_COUNT).PERIOD_CODE := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).AUTH_ID := GLOBAL.USER_ID;
        L_ACC_HOFF(L_HOFF_COUNT).BATCH_NO := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).CURR_NO := 0;
        L_ACC_HOFF(L_HOFF_COUNT).BANK_CODE := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).AVLDAYS := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).BALANCE_UPD := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).AUTH_STAT := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).DELETE_STAT := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).TYPE := NULL;
        L_ACC_HOFF(L_HOFF_COUNT).PRINT_STAT := 'N';
        L_ACC_HOFF(L_HOFF_COUNT).ON_LINE := 'Y';
      
        IF NOT ACPKSS.FN_ACHANDOFF(L_TRN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   L_ACC_HOFF,
                                   'B', -- PUT U TO POST THE ENTRY AS UNAUTHORIZED
                                   'N', --SUSPENSE
                                   'N', --BALANCING
                                   GLOBAL.USER_ID,
                                   L_ERROR_CODE,
                                   L_ERROR_PARAMETER) THEN
          DBG('FAILED IN ACCOUNTING HANDOFF FUNCTION');
          DBG('ERROR CODE --> ' || L_ERROR_CODE);
          DBG('ERROR PARAMETER --> ' || L_ERROR_PARAMETER);
          ROLLBACK;
          PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
                                        L_TRN_REF_NO,
                                        'E',
                                        L_ERROR_CODE,
                                        L_ERROR_PARAMETER,
                                        SYSDATE);
          PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'E');
        ELSE
          DBG('SUCCESS - ACC ENTRY');
        
          COMMIT;
        
          PR_UPDATE_ORDER_ID_INVOKE_LOG(L_ORDER_ID,
                                        L_TRN_REF_NO,
                                        'P',
                                        null,
                                        null,
                                        SYSDATE);
          PR_UPDATE_AUTO_DEBIT_TRACKER(L_ORDER_ID, 'P');
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PROCESSING CURRENT INCOMING ORDER ID=' ||
              L_ORDER_ID);
          DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
          CONTINUE;
      END;
    
    END LOOP;
  
    --Done processing order ids
  
    --Generate Outgoing Auto Debit Respnse xml file
    PR_GENERATE_AUTODEBIT_RESPONSE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_AUTO_DEBIT_ORDER_ID');
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
  END PR_PROCESS_AUTO_DEBIT_ORDER_ID;

  FUNCTION FN_GET_INST_ID(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN VARCHAR2 IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_INST_ID          VARCHAR2(100);
  BEGIN
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_INST_ID := P_DOCUMENT_XML.EXTRACT('/payment_orders/inst_id/text()')
                 .GETSTRINGVAL;
  
    DBG('L_INST_ID=' || L_INST_ID);
  
    RETURN L_INST_ID;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_INST_ID');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_INST_ID;
  END FN_GET_INST_ID;

  FUNCTION FN_GET_FILE_DATE(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN DATE IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_FILE_DATE        VARCHAR2(100);
  BEGIN
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_FILE_DATE := TO_DATE(P_DOCUMENT_XML.EXTRACT('/payment_orders/file_date/text()')
                           .GETSTRINGVAL,
                           'YYYY-MM-DD');
    DBG('L_FILE_DATE=' || L_FILE_DATE);
    RETURN L_FILE_DATE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_FILE_DATE');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_FILE_DATE;
  END FN_GET_FILE_DATE;

  FUNCTION FN_GET_FILE_NO(P_REQUEST_MSG IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE)
    RETURN VARCHAR2 IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_FILE_NO          VARCHAR2(100);
  BEGIN
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_FILE_NO := P_DOCUMENT_XML.EXTRACT('/payment_orders/file_number/text()')
                 .GETSTRINGVAL;
    DBG('L_FILE_NO=' || L_FILE_NO);
    RETURN L_FILE_NO;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_FILE_NO');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_FILE_NO;
  END FN_GET_FILE_NO;

  PROCEDURE PR_AUTO_DEBIT_INC_HANDOFF(P_REQ_MSG   IN XMLTYPE,
                                      P_FILE_NAME IN VARCHAR2) IS
  
    L_RESPONSE         VARCHAR2(32767);
    L_SNIPPET          XMLTYPE;
    L_IX               BINARY_INTEGER;
    L_TEXT             CLOB;
    L_START            NUMBER := 1;
    L_END              NUMBER := 0;
    L_NO_OF_PAY_ORDERS NUMBER := 0;
    L_PAY_ORDER        CLOB;
    L_INST_ID          VARCHAR2(100);
    L_FILE_DATE        DATE;
    L_FILE_NUMBER      VARCHAR2(100);
    /*L_REQ_MSG          CLOB := '<?xml version="1.0" encoding="UTF-8"?>
    <payment_orders>
        <inst_id>1001</inst_id>
        <file_date>2019-10-13</file_date>
        <file_number>1</file_number>
        <payment_order>
            <order_id>1910130000022410</order_id>
            <customer_number>100004261385</customer_number>
            <amount>9082</amount>
            <currency>840</currency>
            <order_date>2019-10-13T00:00:00</order_date>
            <parameter>
                <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
                <param_value>Auto Derect debit</param_value>
            </parameter>
            <parameter>
                <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
                <param_value>1000000001</param_value>
            </parameter>
            <purpose_id>10000004</purpose_id>
        </payment_order>
        <payment_order>
            <order_id>1910130000022411</order_id>
            <customer_number>100004261385</customer_number>
            <amount>9082</amount>
            <currency>840</currency>
            <order_date>2019-10-13T00:00:00</order_date>
            <parameter>
                <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
                <param_value>Auto Derect debit</param_value>
            </parameter>
            <parameter>
                <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
                <param_value>1000000001</param_value>
            </parameter>
            <purpose_id>10000004</purpose_id>
        </payment_order>
        <payment_order>
            <order_id>1910130000022412</order_id>
            <customer_number>100004261385</customer_number>
            <amount>9082</amount>
            <currency>840</currency>
            <order_date>2019-10-13T00:00:00</order_date>
            <parameter>
                <param_name>CBS_TRANSFER_PAYMENT_PURPOSE</param_name>
                <param_value>Auto Derect debit</param_value>
            </parameter>
            <parameter>
                <param_name>CBS_TRANSFER_PAYER_ACCOUNT</param_name>
                <param_value>1000000001</param_value>
            </parameter>
            <purpose_id>10000004</purpose_id>
        </payment_order>
    </payment_orders>';*/
  
    E_UPDATE_ERROR EXCEPTION;
    P_ERR_CODE     VARCHAR2(1000);
    P_ERR_PARAMS   VARCHAR2(1000);
    P_REQ_MSG_CLOB CLOB;
  
  BEGIN
  
    DBG('START OF PR_AUTO_DEBIT_INC_HANDOFF');
  
    P_REQ_MSG_CLOB := P_REQ_MSG.getClobVal();
  
    DBG('P_REQ_MSG_CLOB=' || P_REQ_MSG_CLOB);
  
    L_INST_ID := FN_GET_INST_ID(P_REQ_MSG_CLOB);
  
    DBG('L_INST_ID=' || L_INST_ID);
  
    L_FILE_DATE := FN_GET_FILE_DATE(P_REQ_MSG_CLOB);
  
    DBG('L_FILE_DATE=' || L_FILE_DATE);
  
    L_FILE_NUMBER := FN_GET_FILE_NO(P_REQ_MSG_CLOB);
  
    DBG('L_FILE_NUMBER=' || L_FILE_NUMBER);
  
    L_NO_OF_PAY_ORDERS := (LENGTH(P_REQ_MSG_CLOB) -
                          LENGTH(REPLACE(P_REQ_MSG_CLOB,
                                          '</payment_order>',
                                          ''))) /
                          length('</payment_order>');
  
    DBG('L_NO_OF_PAY_ORDERS=' || L_NO_OF_PAY_ORDERS);
  
    FOR G IN 1 .. L_NO_OF_PAY_ORDERS LOOP
    
      DBG('G value=' || G);
      DBG('BEGIN L_START=' || L_START);
      DBG('BEGIN L_END=' || L_END);
    
      L_START := INSTR(P_REQ_MSG_CLOB, '<payment_order>', L_START, G);
      L_END   := INSTR(P_REQ_MSG_CLOB, '</payment_order>', L_START, 1);
    
      DBG('AFTER L_START=' || L_START);
      DBG('AFTER L_END=' || L_END);
    
      --DBMS_OUTPUT.PUT_LINE('FINAL SUB END=' || L_END - L_START + LENGTH('</payment_order>'));
    
      L_PAY_ORDER := SUBSTR(P_REQ_MSG_CLOB,
                            L_START,
                            L_END - L_START + LENGTH('</payment_order>'));
    
      --DBMS_OUTPUT.PUT_LINE('L_PAY_ORDER=' || L_PAY_ORDER);
    
      PR_INSERT_AUTO_DEBIT_TRACKER(L_INST_ID,
                                   L_FILE_DATE,
                                   L_FILE_NUMBER,
                                   L_PAY_ORDER,
                                   P_FILE_NAME);
    
      L_START := 1;
    
      DBG('-------------------');
    
    END LOOP;
  
    -- RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      -- RETURN FALSE;
  END PR_AUTO_DEBIT_INC_HANDOFF;

  PROCEDURE PR_INSERT_AUTO_DEBIT_TRACKER(P_INST_ID     IN VARCHAR2,
                                         P_FILE_DATE   IN VARCHAR2,
                                         P_FILE_NO     IN VARCHAR2,
                                         P_REQUEST_MSG IN IFTM_AUTO_DEBIT_PAYMENT_REQ.REQUEST_MSG%TYPE,
                                         P_FILE_NAME   IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_ORDER_ID         IFTM_AUTO_DEBIT_PAYMENT_REQ.ORDER_ID%TYPE;
    L_CUST_NO          IFTB_AUTO_DEBIT_INCOMING_TRACK.CUST_NO%TYPE;
    L_TXN_AMOUNT       IFTB_AUTO_DEBIT_INCOMING_TRACK.TXN_AMOUNT%TYPE;
    L_ISO_CCY_CODE     IFTB_AUTO_DEBIT_INCOMING_TRACK.ISO_CCY_CODE%TYPE;
    L_CCY_CODE         IFTB_AUTO_DEBIT_INCOMING_TRACK.CCY_CODE%TYPE;
    L_ORDER_DATE       IFTB_AUTO_DEBIT_INCOMING_TRACK.ORDER_DATE%TYPE;
    L_AC_NO            IFTB_AUTO_DEBIT_INCOMING_TRACK.CUST_AC_NO%TYPE;
    L_PURPOSE_ID       IFTB_AUTO_DEBIT_INCOMING_TRACK.PURPOSE_ID%TYPE;
    L_COUNT            NUMBER;
  
  BEGIN
  
    DBG('BEFORE START OF PR_INSERT_AUTO_DEBIT_TRACKER');
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
  
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
  
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_ORDER_ID := P_DOCUMENT_XML.EXTRACT('/payment_order/order_id/text()')
                  .GETSTRINGVAL;
  
    L_CUST_NO := P_DOCUMENT_XML.EXTRACT('/payment_order/customer_number/text()')
                 .GETSTRINGVAL;
  
    L_TXN_AMOUNT := P_DOCUMENT_XML.EXTRACT('/payment_order/amount/text()')
                    .GETSTRINGVAL;
  
    L_ISO_CCY_CODE := P_DOCUMENT_XML.EXTRACT('/payment_order/currency/text()')
                      .GETSTRINGVAL;
  
    L_CCY_CODE := FN_GET_ISO_CURRENCY_CODE(L_ISO_CCY_CODE);
  
    L_ORDER_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/payment_order/order_date/text()')
                                              .GETSTRINGVAL,
                                              'YYYY-MM-DD"T"HH24:mi:ss') AS DATE),
                            'YYYY-MM-DD');
  
    L_AC_NO := P_DOCUMENT_XML.EXTRACT('/payment_order/parameter[2]/param_value/text()')
               .GETSTRINGVAL;
  
    L_PURPOSE_ID := P_DOCUMENT_XML.EXTRACT('/payment_order/purpose_id/text()')
                    .GETSTRINGVAL;
  
    --Check if above ORDER ID already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTB_AUTO_DEBIT_INCOMING_TRACK
       WHERE ORDER_ID = L_ORDER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;
  
    IF L_COUNT = 0 THEN
      INSERT INTO IFTB_AUTO_DEBIT_INCOMING_TRACK
        (INST_ID,
         FILE_DATE,
         FILE_NO,
         ORDER_ID,
         REQUEST_MSG,
         STATUS,
         TIME_IN,
         CUST_NO,
         TXN_AMOUNT,
         ISO_CCY_CODE,
         CCY_CODE,
         ORDER_DATE,
         CUST_AC_NO,
         PURPOSE_ID,
         FILE_NAME)
      VALUES
        (P_INST_ID,
         P_FILE_DATE,
         P_FILE_NO,
         L_ORDER_ID,
         P_REQUEST_MSG,
         'U',
         SYSDATE,
         L_CUST_NO,
         L_TXN_AMOUNT,
         L_ISO_CCY_CODE,
         L_CCY_CODE,
         L_ORDER_DATE,
         L_AC_NO,
         L_PURPOSE_ID,
         P_FILE_NAME);
    
      --Temp table
      INSERT INTO IFTB_AUTODEBIT_INC_TRACK
        (INST_ID,
         FILE_DATE,
         FILE_NO,
         ORDER_ID,
         REQUEST_MSG,
         STATUS,
         TIME_IN,
         CUST_NO,
         TXN_AMOUNT,
         ISO_CCY_CODE,
         CCY_CODE,
         ORDER_DATE,
         CUST_AC_NO,
         PURPOSE_ID,
         FILE_NAME)
      VALUES
        (P_INST_ID,
         P_FILE_DATE,
         P_FILE_NO,
         L_ORDER_ID,
         P_REQUEST_MSG,
         'U',
         SYSDATE,
         L_CUST_NO,
         L_TXN_AMOUNT,
         L_ISO_CCY_CODE,
         L_CCY_CODE,
         L_ORDER_DATE,
         L_AC_NO,
         L_PURPOSE_ID,
         P_FILE_NAME);
    END IF;
  
    DBG('AFTER INSERTING INTO PR_INSERT_AUTO_DEBIT_TRACKER');
    DBG('COMMITTING');
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_AUTO_DEBIT_TRACKER');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_AUTO_DEBIT_TRACKER');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
    
  END PR_INSERT_AUTO_DEBIT_TRACKER;

  PROCEDURE PR_AUTO_DEBIT_UPLOAD(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    --GLOBAL.PR_INIT('001', 'SYSTEM');
  
    DBG('Inside PR_AUTO_DEBIT_UPLOAD');
  
    PR_INIT_MSG;
    DBG('Successful return from PR_AUTO_DEBIT_UPLOAD');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception during PR_AUTO_DEBIT_UPLOAD' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
  END PR_AUTO_DEBIT_UPLOAD;

  PROCEDURE PR_PROCESS_AUTO_DEBIT(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    --GLOBAL.PR_INIT('000', 'SYSTEM');
  
    PR_PROCESS_AUTO_DEBIT_ORDER_ID;
  
    DBG('SUCCESSFUL RETURN FROM PR_PROCESS_AUTO_DEBIT');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_AUTO_DEBIT');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
  END PR_PROCESS_AUTO_DEBIT;

END IFPKS_AUTODEBIT_UTLS;
/