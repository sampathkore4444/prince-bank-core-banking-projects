create table IFTM_AUTO_DEBIT_INC_PAYMENT
(
  order_id    VARCHAR2(16) primary key,
  customer_no VARCHAR2(200),
  amount      NUMBER(22,3),
  currency    VARCHAR2(3),
  order_date  DATE,
  cust_ac_no  VARCHAR2(20),
  purpose_id  VARCHAR2(8),
  request_msg CLOB,
  status      CHAR(1)
)
/
CREATE OR REPLACE FUNCTION DIRLIST_FILE
(p_dir IN VARCHAR2) RETURN VARCHAR2
AS LANGUAGE JAVA NAME
'DirectoryListner.getFileList
  (java.lang.String)
  return String';
/
-- Create table
create table IFTB_AUTO_DEBIT_ORDER_ID_LOG
(
  order_id          VARCHAR2(16),
  trn_ref_no        VARCHAR2(16),
  status            CHAR(1),
  error_code        VARCHAR2(11),
  error_param       VARCHAR2(4000),
  invoke_date_start DATE,
  invoke_date_end   DATE
)
/
alter table IFTB_AUTO_DEBIT_ORDER_ID_LOG
  add primary key (ORDER_ID, TRN_REF_NO)
/
create table IFTB_AUTO_DEBIT_INCOMING_TRACK
(
  inst_id      VARCHAR2(16),
  file_date    DATE,
  file_no      VARCHAR2(16),
  order_id     VARCHAR2(16) not null,
  request_msg  CLOB,
  status       CHAR(1),
  time_in      DATE,
  cust_no      VARCHAR2(15),
  txn_amount   NUMBER,
  iso_ccy_code NUMBER,
  ccy_code     VARCHAR2(3),
  order_date   DATE,
  cust_ac_no   VARCHAR2(15),
  file_name    VARCHAR2(100),
  purpose_id   VARCHAR2(15),
  card_type    CHAR(1)
)
/
-- Create table
create table IFTB_AUTODEBIT_INC_TRACK
(
  inst_id      VARCHAR2(16),
  file_date    DATE,
  file_no      VARCHAR2(16),
  order_id     VARCHAR2(16),
  request_msg  CLOB,
  status       CHAR(1),
  time_in      DATE,
  cust_no      VARCHAR2(15),
  txn_amount   NUMBER,
  iso_ccy_code NUMBER,
  ccy_code     VARCHAR2(3),
  order_date   DATE,
  cust_ac_no   VARCHAR2(15),
  file_name    VARCHAR2(100),
  purpose_id   VARCHAR2(15),
  card_type    CHAR(1)
)
