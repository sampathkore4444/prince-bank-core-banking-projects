CREATE OR REPLACE PACKAGE BODY STPKS_GEN_CUSTOM AS

  FUNCTION FN_GEN_PROC_STAT(PACCLS           VARCHAR2,
                            P_FN_CALL_ID     NUMBER,
                            P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
  
   RETURN BOOLEAN IS
  
  BEGIN
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC', 'Failed in sql generation' || SQLERRM);
      RETURN FALSE;
  END FN_GEN_PROC_STAT;

  FUNCTION FN_BLD_CONDITION(PSTR             IN OUT VARCHAR2,
                            P_FN_CALL_ID     NUMBER,
                            P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC',
                     'In the exception of the function build condition');
      RETURN FALSE;
  END FN_BLD_CONDITION;

END STPKS_GEN_CUSTOM;
