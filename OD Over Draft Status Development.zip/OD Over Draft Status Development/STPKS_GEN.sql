CREATE OR REPLACE PACKAGE BODY STPKS_GEN AS

  TYPE ELEMENT_TYPE IS TABLE OF NUMBER INDEX BY VARCHAR2(30);
  ELEMENTS ELEMENT_TYPE;

  FUNCTION FN_BLD_BODY(PACCLS VARCHAR2,
                       PRULE  VARCHAR2,
                       PSTAT  VARCHAR2,
                       PSTR   IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_STR      VARCHAR2(1000);
    S          VARCHAR2(32767);
    PDAYSOVD   NUMBER;
    PDAYSINACT NUMBER;
    LCNT       NUMBER := 2;

    PROCEDURE GEN(L VARCHAR2) IS
    BEGIN
      S := S || L || CHR(9);
      DEBUG.PR_DEBUG('IC', 'HERE 16  ' || S);

    END GEN;

    PROCEDURE GENL(L VARCHAR2, I NUMBER) IS
    BEGIN
      IF I > 0 THEN
        FOR L IN 1 .. I LOOP
          S := S || CHR(9);
        END LOOP;
      END IF;

      S := S || L || CHR(10);
      DEBUG.PR_DEBUG('IC', 'HERE 17 ' || S);

    END GENL;

  BEGIN
    S := PSTR;

    DEBUG.PR_DEBUG('IC', 'HERE 4' || PRULE);
    L_STR := PRULE;
    L_STR := 'IF ' || L_STR;

    IF NOT FN_BLD_CONDITION(L_STR) THEN
      RETURN FALSE;
      DEBUG.PR_DEBUG('IC', 'Failed in generating the condition');
    ELSE
      DEBUG.PR_DEBUG('IC', 'HERE 7  ' || L_STR);

      GENL(L_STR, 0);
      GENL(CHR(9) || 'THEN', 0);

      DEBUG.PR_DEBUG('IC', 'HERE 8  ' || S);

    END IF;

    DEBUG.PR_DEBUG('IC', 'HERE 9  ' || S);
    GENL('l_count := l_count +1 ;', LCNT);
    GENL('P_stat := ' || CHR(39) || PSTAT || CHR(39) || ';', LCNT);
    GENL('pnew_stat := P_stat;', (LCNT + 1));
    GENL('RETURN ;', (LCNT + 1));

    IF PDAYSOVD > 0 THEN
      GENL('END IF;', (LCNT - 1));
    END IF;

    IF PDAYSINACT > 0 THEN
      GENL('END IF;', (LCNT - 2));
    END IF;

    GENL('END IF;', 1);

    S := S || CHR(10) || CHR(9);

    PSTR := S;

    DEBUG.PR_DEBUG('IC', 'HERE 10  ' || S);

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC', 'HERE 11 ' || SQLERRM);
      RETURN FALSE;
  END FN_BLD_BODY;

  FUNCTION FN_ELEMENT_EXISTS(PACCLS VARCHAR2) RETURN BOOLEAN IS
    I            NUMBER := 1;
    L_COUNT      NUMBER := 0;
    ELEMENT_LIST VARCHAR2(1000) := 'OD_DAYS~OVERLINE_DAYS~TOD_DAYS~INACTIVE_DAYS~SOD_DUE_COUNT~SOD_OVERDUE_DAYS~CUSTOMER_CREDIT_RATING~DEBIT_INTEREST_OD_DAYS~OD_LIMIT_BREACH_DAYS~OD_EXPIRY_DAYS~OD_NO_CREDIT_DAYS~INTEREST_OVERDUE_DAYS~INTEREST_OVERDUE_AMOUNT~PRINCIPAL_OVERDUE_DAYS~PRINCIPAL_OVERDUE_AMOUNT~CHARGE_OVERDUE_DAYS~CHARGE_OVERDUE_AMOUNT~INTEREST_OVERDUE_LCY_EQV~PRINCIPAL_OVERDUE_LCY_EQV~CHARGE_OVERDUE_LCY_EQV~CUST_CLASSIFICATION~AVAILABLE_BALANCE'; --sampath added AVAILABLE_BALANCE
    --ELEMENT_LIST VARCHAR2(1000) := 'OD_DAYS~OVERLINE_DAYS~TOD_DAYS~INACTIVE_DAYS~SOD_DUE_COUNT~SOD_OVERDUE_DAYS~CUSTOMER_CREDIT_RATING~DEBIT_INTEREST_OD_DAYS~OD_LIMIT_BREACH_DAYS~OD_EXPIRY_DAYS~OD_NO_CREDIT_DAYS~INTEREST_OVERDUE_DAYS~INTEREST_OVERDUE_AMOUNT~PRINCIPAL_OVERDUE_DAYS~PRINCIPAL_OVERDUE_AMOUNT~CHARGE_OVERDUE_DAYS~CHARGE_OVERDUE_AMOUNT~INTEREST_OVERDUE_LCY_EQV~PRINCIPAL_OVERDUE_LCY_EQV~CHARGE_OVERDUE_LCY_EQV~CUST_CLASSIFICATION'; --sampath commented

	ELEMENT      VARCHAR2(30);
  BEGIN
    DEBUG.PR_DEBUG('IC', 'Inside Function FN_ELEMENT_EXISTS');
    DEBUG.PR_DEBUG('IC', 'paccls: ' || PACCLS);
    WHILE CSPKES_MISC.FN_GETPARAM(ELEMENT_LIST, I, '~') <> 'EOPL' LOOP
      ELEMENT := CSPKES_MISC.FN_GETPARAM(ELEMENT_LIST, I, '~');
      DEBUG.PR_DEBUG('IC', 'element: ' || ELEMENT);
      IF ELEMENT IS NOT NULL THEN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTM_AC_STAT_DRV
         WHERE ACCOUNT_CLASS = PACCLS
           AND (STATUS_RULE1 || STATUS_RULE2 || STATUS_RULE3 ||
               STATUS_RULE4 || STATUS_RULE5) LIKE '%' || ELEMENT || '%';
        DEBUG.PR_DEBUG('IC', 'l_count: ' || L_COUNT);
        IF L_COUNT > 0 THEN
          ELEMENTS(ELEMENT) := 1;
        ELSE
          ELEMENTS(ELEMENT) := 0;
        END IF;
        DEBUG.PR_DEBUG('IC', 'element exists: ' || ELEMENTS(ELEMENT));
      END IF;
      I := I + 1;
    END LOOP;
    DEBUG.PR_DEBUG('IC', 'Returning TRUE from FN_ELEMENT_EXISTS');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC',
                     'In the exception of the function FN_ELEMENT_EXISTS: SQLERRM: ' ||
                     SQLERRM);
      RETURN FALSE;
  END FN_ELEMENT_EXISTS;

  FUNCTION FN_GEN_PROC_STAT(PACCLS VARCHAR2)

   RETURN BOOLEAN IS
    C          INTEGER := DBMS_SQL.OPEN_CURSOR;
    L_STAT_DRV STTM_AC_STAT_DRV%ROWTYPE;
    S          VARCHAR2(32767);
    PROC_NAME  VARCHAR2(30) := 'STPR#_' || LTRIM(RTRIM(PACCLS));
    PDAYSOVD   NUMBER;
    PDAYSINACT NUMBER;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    CURSOR CR_STAT_DRV IS
      SELECT *
        FROM STTM_AC_STAT_DRV
       WHERE ACCOUNT_CLASS = PACCLS
       ORDER BY SEQ_NO DESC;

    PROCEDURE GEN(L VARCHAR2) IS
    BEGIN
      S := S || CHR(10) || L;
    END GEN;

    PROCEDURE PR_PARSE_SQL IS
      PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
      DBMS_SQL.PARSE(C, S, DBMS_SQL.NATIVE);

      COMMIT;

    EXCEPTION
      WHEN OTHERS THEN
        IF DBMS_SQL.IS_OPEN(C) THEN
          DBMS_SQL.CLOSE_CURSOR(C);
        END IF;

    END;

  BEGIN

    IF NOT FN_ELEMENT_EXISTS(PACCLS) THEN
      DEBUG.PR_DEBUG('IC', 'Failed in FN_ELEMENT_EXISTS');
    END IF;

    GEN('CREATE OR REPLACE PROCEDURE ' || PROC_NAME);
    GEN('(pbranch  Sttm_cust_account.Branch_code%TYPE,pcustacno Sttm_cust_account.Cust_ac_no%TYPE,pnew_stat OUT VARCHAR2)');
    GEN('IS');
    GEN('cust_rec    Sttm_cust_account%ROWTYPE;');
    GEN('bal_rec     sttm_account_balance%ROWTYPE;');
    
    --sampath starts
    GEN('AVAILABLE_BALANCE	Number;');
    GEN('L_ACCOUNT_BALANCE	Number;');
    
    
    --sampath ends

    GEN('P_stat        Sttm_ac_stat_drv.Status%TYPE;');

    IF ELEMENTS('OD_DAYS') = 1 OR ELEMENTS('OVERLINE_DAYS') = 1 OR
       ELEMENTS('TOD_DAYS') = 1 OR ELEMENTS('INACTIVE_DAYS') = 1 OR
       ELEMENTS('OD_LIMIT_BREACH_DAYS') = 1 OR
       ELEMENTS('OD_NO_CREDIT_DAYS') = 1 OR
       ELEMENTS('DEBIT_INTEREST_OD_DAYS') = 1 OR
       ELEMENTS('OD_EXPIRY_DAYS') = 1 OR
       ELEMENTS('PRINCIPAL_OVERDUE_DAYS') = 1 OR
       ELEMENTS('INTEREST_OVERDUE_DAYS') = 1 OR
       ELEMENTS('CHARGE_OVERDUE_DAYS') = 1 THEN

      GEN('Nwd        Date;');
    END IF;
    IF ELEMENTS('OD_DAYS') = 1 THEN
      GEN('OD_DAYS    Number;');
    END IF;
    IF ELEMENTS('OVERLINE_DAYS') = 1 THEN
      GEN('OVERLINE_DAYS    Number;');
    END IF;
    IF ELEMENTS('TOD_DAYS') = 1 THEN
      GEN('TOD_DAYS        NUMBER;');
    END IF;
    GEN('L_COUNT         Number :=0;');
    IF ELEMENTS('INACTIVE_DAYS') = 1 THEN
      GEN('INACTIVE_DAYS    Number;' || CHR(10));
    END IF;
    IF ELEMENTS('SOD_DUE_COUNT') = 1 THEN
      GEN('SOD_DUE_COUNT         NUMBER;');
    END IF;
    IF ELEMENTS('SOD_OVERDUE_DAYS') = 1 THEN
      GEN('SOD_OVERDUE_DAYS NUMBER;');
    END IF;
    IF ELEMENTS('CUSTOMER_CREDIT_RATING') = 1 THEN
      GEN('CUSTOMER_CREDIT_RATING  STTM_CUSTOMER.CREDIT_RATING%TYPE;');
    END IF;
    IF ELEMENTS('DEBIT_INTEREST_OD_DAYS') = 1 THEN
      GEN('DEBIT_INTEREST_OD_DAYS NUMBER;');
    END IF;
    IF ELEMENTS('OD_LIMIT_BREACH_DAYS') = 1 THEN
      GEN('OD_LIMIT_BREACH_DAYS NUMBER;');
    END IF;
    IF ELEMENTS('OD_EXPIRY_DAYS') = 1 THEN
      GEN('OD_EXPIRY_DAYS    NUMBER;');
    END IF;
    IF ELEMENTS('OD_NO_CREDIT_DAYS') = 1 THEN
      GEN('OD_NO_CREDIT_DAYS   NUMBER;');
    END IF;

    IF ELEMENTS('DEBIT_INTEREST_OD_DAYS') = 1 THEN
      GEN('l_last_int_paiddate   DATE;');
    END IF;
    IF ELEMENTS('OD_EXPIRY_DAYS') = 1 THEN
      GEN('l_line_expiry_date   DATE;');
    END IF;

    IF ELEMENTS('PRINCIPAL_OVERDUE_DAYS') = 1 OR
       ELEMENTS('INTEREST_OVERDUE_DAYS') = 1 OR
       ELEMENTS('CHARGE_OVERDUE_DAYS') = 1 OR
       ELEMENTS('PRINCIPAL_OVERDUE_AMOUNT') = 1 OR
       ELEMENTS('INTEREST_OVERDUE_AMOUNT') = 1 OR
       ELEMENTS('CHARGE_OVERDUE_AMOUNT') = 1 OR
       ELEMENTS('PRINCIPAL_OVERDUE_LCY_EQV') = 1 OR
       ELEMENTS('INTEREST_OVERDUE_LCY_EQV') = 1 OR
       ELEMENTS('CHARGE_OVERDUE_LCY_EQV') = 1 THEN

      GEN('l_min_duedt_int   DATE;');
      GEN('l_min_duedt_princ   DATE;');
      GEN('l_min_duedt_chg   DATE;');
      GEN('l_od_amt_int   NUMBER;');
      GEN('l_od_amt_princ   NUMBER;');
      GEN('l_od_amt_chg   NUMBER;');
      IF ELEMENTS('INTEREST_OVERDUE_LCY_EQV') = 1 THEN
        GEN('l_Lcy_Amount_int   NUMBER;');
      END IF;
      IF ELEMENTS('PRINCIPAL_OVERDUE_LCY_EQV') = 1 THEN
        GEN('l_Lcy_Amount_princ   NUMBER;');
      END IF;
      IF ELEMENTS('CHARGE_OVERDUE_LCY_EQV') = 1 THEN
        GEN('l_Lcy_Amount_chg   NUMBER;');
      END IF;
      GEN('l_Rate   NUMBER;');
      GEN('p_Err_Code   VARCHAR2(255);');
    END IF;

    IF ELEMENTS('INTEREST_OVERDUE_DAYS') = 1 THEN
      GEN('INTEREST_OVERDUE_DAYS NUMBER;');
    END IF;
    IF ELEMENTS('INTEREST_OVERDUE_AMOUNT') = 1 THEN
      GEN('INTEREST_OVERDUE_AMOUNT  NUMBER;');
    END IF;
    IF ELEMENTS('PRINCIPAL_OVERDUE_DAYS') = 1 THEN
      GEN('PRINCIPAL_OVERDUE_DAYS   NUMBER;');
    END IF;
    IF ELEMENTS('PRINCIPAL_OVERDUE_AMOUNT') = 1 THEN
      GEN('PRINCIPAL_OVERDUE_AMOUNT   NUMBER;');
    END IF;
    IF ELEMENTS('CHARGE_OVERDUE_DAYS') = 1 THEN
      GEN('CHARGE_OVERDUE_DAYS   NUMBER;');
    END IF;
    IF ELEMENTS('CHARGE_OVERDUE_AMOUNT') = 1 THEN
      GEN('CHARGE_OVERDUE_AMOUNT  NUMBER;');
    END IF;
    IF ELEMENTS('INTEREST_OVERDUE_LCY_EQV') = 1 THEN
      GEN('INTEREST_OVERDUE_LCY_EQV   NUMBER;');
    END IF;
    IF ELEMENTS('PRINCIPAL_OVERDUE_LCY_EQV') = 1 THEN
      GEN('PRINCIPAL_OVERDUE_LCY_EQV   NUMBER;');
    END IF;
    IF ELEMENTS('CHARGE_OVERDUE_LCY_EQV') = 1 THEN
      GEN('CHARGE_OVERDUE_LCY_EQV   NUMBER;' || CHR(10));
    END IF;

    IF ELEMENTS('CUST_CLASSIFICATION') = 1 OR
       ELEMENTS('OD_EXPIRY_DAYS') = 1 THEN
      GEN('l_liab_no   STTM_CUSTOMER.LIABILITY_NO%TYPE;');
      GEN('CUST_CLASSIFICATION  VARCHAR2(20);');
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID := 1;
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      L_TB_CLUSTER_DATA('S') := S;

      IF NOT STPKSS_GEN_CLUSTER.FN_GEN_PROC_STAT(PACCLS,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('IC',
                       'Failed in stpkss_gen_cluster.Fn_Gen_Proc_Stat');
        RAISE_APPLICATION_ERROR(-20010, 'Error in stpks_gen_cluster');
      END IF;

      S := L_TB_CLUSTER_DATA('S');
    END IF;

    GEN('BEGIN' || CHR(10));

    GEN('BEGIN' || CHR(10));
    GEN(CHR(9) || ' SELECT *');
    GEN(CHR(9) || ' INTO cust_rec');
    GEN(CHR(9) || ' FROM STTM_CUST_ACCOUNT');
    GEN(CHR(9) || ' WHERE BRANCH_CODE = pbranch');
    GEN(CHR(9) || ' AND CUST_AC_NO = pcustacno;');
    GEN('EXCEPTION WHEN NO_DATA_FOUND THEN');
    GEN(CHR(9) || CHR(9) ||
        'DEBUG.PR_DEBUG(''ST'',''NO Rows found in sttm_cust_account'');');
    GEN(CHR(9) || ' RETURN ;');
    GEN('END;' || CHR(10));

    GEN('BEGIN' || CHR(10));
    GEN(CHR(9) || ' SELECT *');
    GEN(CHR(9) || ' INTO   bal_rec');
    GEN(CHR(9) || ' FROM   STTM_ACCOUNT_BALANCE');
    GEN(CHR(9) || ' WHERE  CUST_AC_BRN = pbranch');
    GEN(CHR(9) || ' AND    CUST_AC_NO  = pcustacno;');
    GEN('EXCEPTION WHEN NO_DATA_FOUND THEN');
    GEN(CHR(9) || CHR(9) ||
        'DEBUG.PR_DEBUG(''ST'',''NO Rows found in sttm_account_balance'');');
    GEN(CHR(9) || ' RETURN ;');
    GEN('END;' || CHR(10));

    IF ELEMENTS('CUST_CLASSIFICATION') = 1 OR
       ELEMENTS('OD_EXPIRY_DAYS') = 1 THEN
      GEN('BEGIN' || CHR(10));
      GEN(CHR(9) || ' SELECT cust_classification,liability_no');
      GEN(CHR(9) || ' INTO cust_classification,l_liab_no');
      GEN(CHR(9) || ' FROM STTM_CUSTOMER');
      GEN(CHR(9) || ' WHERE customer_no = cust_rec.cust_no;');
      GEN('EXCEPTION WHEN NO_DATA_FOUND THEN');
      GEN(CHR(9) || CHR(9) ||
          'DEBUG.PR_DEBUG(''ST'',''NO Rows found in sttm_customer for this customer'');');
      GEN(CHR(9) || ' RETURN ;');
      GEN('END;' || CHR(10));
    END IF;

    IF ELEMENTS('OD_DAYS') = 1 OR ELEMENTS('TOD_DAYS') = 1 OR
       ELEMENTS('OVERLINE_DAYS') = 1 OR ELEMENTS('INACTIVE_DAYS') = 1 OR
       ELEMENTS('OD_LIMIT_BREACH_DAYS') = 1 OR
       ELEMENTS('OD_NO_CREDIT_DAYS') = 1 OR
       ELEMENTS('DEBIT_INTEREST_OD_DAYS') = 1 OR
       ELEMENTS('OD_EXPIRY_DAYS') = 1 OR
       ELEMENTS('PRINCIPAL_OVERDUE_DAYS') = 1 OR
       ELEMENTS('INTEREST_OVERDUE_DAYS') = 1 OR
       ELEMENTS('CHARGE_OVERDUE_DAYS') = 1 THEN

      GEN(CHR(9) || 'SELECT Next_working_day - 1 INTO Nwd');
      GEN(CHR(9) || 'FROM  STTMS_DATES');
      GEN(CHR(9) || 'WHERE Branch_code = pbranch;' || CHR(10));
    END IF;

    IF ELEMENTS('OD_DAYS') = 1 THEN
      GEN(CHR(9) ||
          'OD_DAYS   := (Nwd  - NVL(Cust_rec.overdraft_since,(Nwd + 1))) + 1;');
    END IF;
    IF ELEMENTS('TOD_DAYS') = 1 THEN
      GEN(CHR(9) ||
          'TOD_DAYS   := (Nwd  - NVL(Cust_rec.tod_since,(Nwd + 1))) + 1;');
    END IF;
    IF ELEMENTS('OVERLINE_DAYS') = 1 THEN

      GEN(CHR(9) || ' IF Cust_rec.overline_od_since is null ');
      GEN(CHR(9) || ' THEN ');
      GEN(CHR(9) || ' OVERLINE_DAYS   := 0; ');
      GEN(CHR(9) || ' ELSE ');
      GEN(CHR(9) ||
          'OVERLINE_DAYS   := (Nwd  - Cust_rec.overline_od_since) +1  ;');
      GEN(CHR(9) || ' END IF; ');

    END IF;
    IF ELEMENTS('INACTIVE_DAYS') = 1 THEN
      GEN(CHR(9) ||
          'INACTIVE_DAYS := (Nwd  - GREATEST(NVL(Cust_rec.Date_last_dr_activity,Cust_rec.ac_open_date),NVL(Cust_rec.Date_last_cr_activity,Cust_rec.ac_open_date)));' ||
          CHR(10));
    END IF;
    IF ELEMENTS('OD_LIMIT_BREACH_DAYS') = 1 THEN

      GEN(CHR(9) ||
          'OD_LIMIT_BREACH_DAYS := (Nwd - NVL(Cust_rec.overline_od_since,(Nwd + 1))) + 1;');

    END IF;
    
    --sampath starts
    
    GEN('BEGIN' || CHR(10));
    GEN(CHR(9) || ' IF NOT ACPKSS_MISC.FN_GETAVLBAL(Cust_rec.BRANCH_CODE,
                                          Cust_rec.CUST_aC_NO,
                                          L_ACCOUNT_BALANCE,
                                          ''Y'',''Y'',''N'') THEN');
     GEN(CHR(9) || CHR(9) ||
          'DEBUG.PR_DEBUG(''ST'',''Unable to fetch Transaction account Amount'');');
     
    GEN(CHR(9) || ' ELSE');
    GEN(CHR(9) || CHR(9) ||
          'DEBUG.PR_DEBUG(''ST'',''GOT BALANCE OF AN ACCOUNT'');');
    
    GEN(CHR(9) || ' END IF;');
    GEN(CHR(9) || ' EXCEPTION
          WHEN OTHERS THEN');
     GEN(CHR(9) || CHR(9) ||
          'DEBUG.PR_DEBUG(''ST'',''Failure in fetching the Available balance fr the transaction account'');');
  
    GEN('END;' || CHR(10));
    
    --Check Balance of an account
       /* BEGIN
          IF NOT ACPKSS_MISC.FN_GETAVLBAL(pbranch,
                                          P_CLG_REC.REM_ACCOUNT,
                                          L_ACCOUNT_BALANCE,
                                          'Y') THEN
            DBG('Unable to fetch Transaction account Amount');
          ELSE
            DBG('BALANCE OF AN ACCOUNT=' || L_ACCOUNT_BALANCE);
          END IF;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('The error occured at line:' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          
            DBG('Failure in fetching the Available balance fr the transaction account');
        END;*/
      
    
    
    IF ELEMENTS('AVAILABLE_BALANCE') = 1 THEN

      GEN(CHR(9) ||
          'AVAILABLE_BALANCE := L_ACCOUNT_BALANCE;');-- + bal_rec.ACY_WITHDRAWABLE_BAL;');

    END IF;
    --sampath ends

    IF ELEMENTS('OD_NO_CREDIT_DAYS') = 1 THEN
      GEN(CHR(9) ||
          'OD_NO_CREDIT_DAYS := (Nwd - NVL(Cust_rec.date_last_cr_activity,Cust_rec.ac_open_date)) + 1;');

      DEBUG.PR_DEBUG('IC', 'HERE 1');
    END IF;

    IF ELEMENTS('SOD_DUE_COUNT') = 1 THEN

      GEN(CHR(9) || 'SELECT count(amt_due) INTO SOD_DUE_COUNT');
      GEN(CHR(9) || 'FROM ICTB_SODDR_INT_DUE ');
      GEN(CHR(9) || 'WHERE  BRN=pbranch ');

      GEN(CHR(9) || 'AND   ACC=pcustacno ');
      GEN(CHR(9) || 'AND  amt_due<>AMT_SETTLD; ');

    END IF;

    IF ELEMENTS('SOD_OVERDUE_DAYS') = 1 THEN
      GEN(CHR(9) ||
          'SELECT global.application_date- min(ent_dt) INTO SOD_OVERDUE_DAYS');
      GEN(CHR(9) || 'FROM ICTB_SODDR_INT_DUE ');
      GEN(CHR(9) || 'WHERE  BRN=pbranch ');

      GEN(CHR(9) || 'AND   ACC=pcustacno ');
      GEN(CHR(9) || 'AND  amt_due<>AMT_SETTLD;');

    END IF;
    IF ELEMENTS('CUSTOMER_CREDIT_RATING') = 1 THEN

      GEN(CHR(9) ||
          'select  credit_rating into CUSTOMER_CREDIT_RATING  from STTMS_CUSTOMER
  WHERE CUSTOMER_NO=(select cust_no from sttm_cust_account where cust_ac_no=pcustacno and branch_code=pbranch);');

    END IF;

    IF ELEMENTS('DEBIT_INTEREST_OD_DAYS') = 1 THEN

      GEN('BEGIN' || CHR(10));
      GEN(CHR(9) || 'SELECT MIN(IOIB.ent_dt)');
      GEN(CHR(9) || ' INTO l_last_int_paiddate ');
      GEN(CHR(9) || ' FROM ICTBS_OD_INTEREST_BREAKUP IOIB');
      GEN(CHR(9) || ' WHERE IOIB.brn = pbranch');
      GEN(CHR(9) || ' AND IOIB.acc = pcustacno');
      GEN(CHR(9) || ' AND IOIB.int_paid = ''N'';');
      GEN('EXCEPTION WHEN NO_DATA_FOUND THEN');
      GEN(CHR(9) || CHR(9) ||
          'DEBUG.PR_DEBUG(''ST'',''No rows found in ICTB_OD_INTEREST_BREAKUP for this acc'');');
      GEN('END;');

      GEN(CHR(9) ||
          'DEBIT_INTEREST_OD_DAYS := ((Nwd - l_last_int_paiddate) + 1);');
    END IF;

    IF ELEMENTS('OD_EXPIRY_DAYS') = 1 THEN
      GEN('BEGIN' || CHR(10));
      GEN(CHR(9) || 'SELECT min(nvl(fac.line_expiry_date,Nwd+1))');
      GEN(CHR(9) || ' INTO l_line_expiry_date ');
      GEN(CHR(9) || ' FROM getm_facility fac ');
      GEN(CHR(9) || ' WHERE EXISTS (SELECT 1');
      GEN(CHR(9) || ' FROM sttm_cust_account_linkages scal');
      GEN(CHR(9) ||
          ' WHERE scal.linked_ref_no = fac.line_code || fac.line_serial');
      GEN(CHR(9) || ' AND scal.branch_code = pbranch');
      GEN(CHR(9) || ' AND scal.cust_ac_no = pcustacno');
      GEN(CHR(9) || ' AND scal.linkage_type = ''F'')');
      GEN(CHR(9) ||
          ' AND fac.liab_id IN (SELECT id FROM getm_liab WHERE liab_no = l_liab_no);');
      GEN('EXCEPTION WHEN NO_DATA_FOUND THEN');
      GEN(CHR(9) || CHR(9) ||
          'DEBUG.PR_DEBUG(''ST'',''No data found in getm_facility for this acc'');');
      GEN(CHR(9) || ' l_line_expiry_date := NULL;');
      GEN('END;');

      GEN(CHR(9) || 'OD_EXPIRY_DAYS := ((Nwd - l_line_expiry_date)) + 1;');
    END IF;

    GEN(CHR(9) || '' || CHR(10));

    IF ELEMENTS('PRINCIPAL_OVERDUE_DAYS') = 1 OR
       ELEMENTS('INTEREST_OVERDUE_DAYS') = 1 OR
       ELEMENTS('CHARGE_OVERDUE_DAYS') = 1 OR
       ELEMENTS('PRINCIPAL_OVERDUE_AMOUNT') = 1 OR
       ELEMENTS('INTEREST_OVERDUE_AMOUNT') = 1 OR
       ELEMENTS('CHARGE_OVERDUE_AMOUNT') = 1 OR
       ELEMENTS('PRINCIPAL_OVERDUE_LCY_EQV') = 1 OR
       ELEMENTS('INTEREST_OVERDUE_LCY_EQV') = 1 OR
       ELEMENTS('CHARGE_OVERDUE_LCY_EQV') = 1 THEN

      GEN(CHR(9) ||
          'SELECT MIN(DECODE(component_type, ''P'',SODD.due_dt,NULL)),NVL(SUM(DECODE(component_type, ''P'',SODD.amt_not_settled,0)),0),');
      GEN(CHR(9) ||
          'MIN(DECODE(component_type, ''C'',SODD.due_dt,NULL)),NVL(SUM(DECODE(component_type, ''C'',SODD.amt_not_settled,0)),0),');
      GEN(CHR(9) ||
          'MIN(DECODE(component_type, ''I'',SODD.due_dt,NULL)),NVL(SUM(DECODE(component_type, ''I'',SODD.amt_not_settled,0)),0)');
      GEN(CHR(9) ||
          'INTO l_min_duedt_princ,l_od_amt_princ,l_min_duedt_chg,l_od_amt_chg,l_min_duedt_int,l_od_amt_int');
      GEN(CHR(9) || 'FROM Sttb_Od_Due_Details SODD');
      GEN(CHR(9) || 'WHERE SODD.branch_code = pbranch');
      GEN(CHR(9) || 'AND SODD.cust_ac_no = pcustacno');
      GEN(CHR(9) || 'AND SODD.amt_not_settled > 0 ;' || CHR(10));

      IF ELEMENTS('PRINCIPAL_OVERDUE_AMOUNT') = 1 THEN
        GEN(CHR(9) || 'PRINCIPAL_OVERDUE_AMOUNT:= l_od_amt_princ;');
      END IF;
      IF ELEMENTS('PRINCIPAL_OVERDUE_DAYS') = 1 THEN
        GEN(CHR(9) ||
            'PRINCIPAL_OVERDUE_DAYS  := (Nwd - NVL(l_min_duedt_princ,(Nwd + 1))) + 1;' ||
            CHR(10));
      END IF;
      IF ELEMENTS('INTEREST_OVERDUE_AMOUNT') = 1 THEN
        GEN(CHR(9) || 'INTEREST_OVERDUE_AMOUNT := l_od_amt_int;');
      END IF;
      IF ELEMENTS('INTEREST_OVERDUE_DAYS') = 1 THEN
        GEN(CHR(9) ||
            'INTEREST_OVERDUE_DAYS   := (Nwd - NVL(l_min_duedt_int,(Nwd + 1))) + 1;' ||
            CHR(10));
      END IF;
      IF ELEMENTS('CHARGE_OVERDUE_AMOUNT') = 1 THEN
        GEN(CHR(9) || 'CHARGE_OVERDUE_AMOUNT   := l_od_amt_chg;');
      END IF;
      IF ELEMENTS('CHARGE_OVERDUE_DAYS') = 1 THEN
        GEN(CHR(9) ||
            'CHARGE_OVERDUE_DAYS     := (Nwd - NVL(l_min_duedt_chg,(Nwd + 1))) + 1;' ||
            CHR(10));
      END IF;

      IF ELEMENTS('PRINCIPAL_OVERDUE_LCY_EQV') = 1 OR
         ELEMENTS('INTEREST_OVERDUE_LCY_EQV') = 1 OR
         ELEMENTS('CHARGE_OVERDUE_LCY_EQV') = 1 THEN
        GEN(CHR(9) || ' IF cust_rec.ccy <> Global.lcy THEN' || CHR(10));
        IF ELEMENTS('PRINCIPAL_OVERDUE_LCY_EQV') = 1 THEN
          GEN(CHR(9) || 'l_Rate:= NULL;');
          GEN(CHR(9) || 'p_Err_Code:= NULL;' || CHR(10));
          GEN(CHR(9) || ' IF NOT cypks.fn_amt1_to_amt2(pbranch,');
          GEN(CHR(9) || ' cust_rec.ccy,');
          GEN(CHR(9) || ' Global.lcy,');
          GEN(CHR(9) || ' ''STANDARD'',');
          GEN(CHR(9) || ' ''M'',');
          GEN(CHR(9) || ' l_od_amt_princ,');
          GEN(CHR(9) || ' ''Y'',');
          GEN(CHR(9) || ' l_Lcy_Amount_princ,');
          GEN(CHR(9) || ' l_Rate,');
          GEN(CHR(9) || ' p_Err_Code) THEN');
          GEN(CHR(9) ||
              'DEBUG.PR_DEBUG(''ST'',''Exception in Ex rate Conversion...'');');
          GEN(CHR(9) || 'END IF;' || CHR(10));

          GEN(CHR(9) || 'PRINCIPAL_OVERDUE_LCY_EQV := l_Lcy_Amount_princ;');
        END IF;
        IF ELEMENTS('INTEREST_OVERDUE_LCY_EQV') = 1 THEN
          GEN(CHR(9) || 'l_Rate:= NULL;');
          GEN(CHR(9) || 'p_Err_Code:= NULL;' || CHR(10));

          GEN(CHR(9) || ' IF NOT cypks.fn_amt1_to_amt2(pbranch,');
          GEN(CHR(9) || ' cust_rec.ccy,');
          GEN(CHR(9) || ' Global.lcy,');
          GEN(CHR(9) || ' ''STANDARD'',');
          GEN(CHR(9) || ' ''M'',');
          GEN(CHR(9) || ' l_od_amt_int,');
          GEN(CHR(9) || ' ''Y'',');
          GEN(CHR(9) || ' l_Lcy_Amount_int,');
          GEN(CHR(9) || ' l_Rate,');
          GEN(CHR(9) || ' p_Err_Code) THEN');
          GEN(CHR(9) ||
              'DEBUG.PR_DEBUG(''ST'',''Exception in Ex rate Conversion...'');');
          GEN(CHR(9) || 'END IF;' || CHR(10));

          GEN(CHR(9) || 'INTEREST_OVERDUE_LCY_EQV := l_Lcy_Amount_int;');
        END IF;
        IF ELEMENTS('CHARGE_OVERDUE_LCY_EQV') = 1 THEN
          GEN(CHR(9) || 'l_Rate:= NULL;');
          GEN(CHR(9) || 'p_Err_Code:= NULL;' || CHR(10));

          GEN(CHR(9) || ' IF NOT cypks.fn_amt1_to_amt2(pbranch,');
          GEN(CHR(9) || ' cust_rec.ccy,');
          GEN(CHR(9) || ' Global.lcy,');
          GEN(CHR(9) || ' ''STANDARD'',');
          GEN(CHR(9) || ' ''M'',');
          GEN(CHR(9) || ' l_od_amt_chg,');
          GEN(CHR(9) || ' ''Y'',');
          GEN(CHR(9) || ' l_Lcy_Amount_chg,');
          GEN(CHR(9) || ' l_Rate,');
          GEN(CHR(9) || ' p_Err_Code) THEN');
          GEN(CHR(9) ||
              'DEBUG.PR_DEBUG(''ST'',''Exception in Ex rate Conversion...'');');
          GEN(CHR(9) || 'END IF;' || CHR(10));

          GEN(CHR(9) || 'CHARGE_OVERDUE_LCY_EQV := l_Lcy_Amount_chg;');
        END IF;

        GEN(CHR(9) || 'ELSE' || CHR(10));
        IF ELEMENTS('PRINCIPAL_OVERDUE_LCY_EQV') = 1 THEN
          GEN(CHR(9) || 'PRINCIPAL_OVERDUE_LCY_EQV := l_od_amt_princ;');
        END IF;
        IF ELEMENTS('INTEREST_OVERDUE_LCY_EQV') = 1 THEN
          GEN(CHR(9) || 'INTEREST_OVERDUE_LCY_EQV  := l_od_amt_int;');
        END IF;
        IF ELEMENTS('CHARGE_OVERDUE_LCY_EQV') = 1 THEN
          GEN(CHR(9) || 'CHARGE_OVERDUE_LCY_EQV    := l_od_amt_chg;' ||
              CHR(10));
        END IF;
        GEN(CHR(9) || 'END IF;' || CHR(10));
      END IF;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID := 2;
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      L_TB_CLUSTER_DATA('S') := S;

      IF NOT STPKSS_GEN_CLUSTER.FN_GEN_PROC_STAT(PACCLS,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('IC',
                       'Failed in stpkss_gen_cluster.Fn_Gen_Proc_Stat');
        RAISE_APPLICATION_ERROR(-20010, 'Error in stpks_gen_cluster');
      END IF;

      S := L_TB_CLUSTER_DATA('S');
    END IF;

    FOR L_STAT_DRV IN CR_STAT_DRV LOOP

      S := S || CHR(10) || CHR(9);

      IF L_STAT_DRV.STATUS_RULE1 IS NOT NULL THEN

        IF NOT FN_BLD_BODY(L_STAT_DRV.ACCOUNT_CLASS,
                           L_STAT_DRV.STATUS_RULE1,
                           L_STAT_DRV.STATUS,
                           S) THEN
          DEBUG.PR_DEBUG('IC', 'Failed in building the body');
          DEBUG.PR_DEBUG('IC', 'HERE 2');

          IF DBMS_SQL.IS_OPEN(C) THEN
            DBMS_SQL.CLOSE_CURSOR(C);
          END IF;

          RETURN FALSE;
        END IF;
      END IF;

      IF L_STAT_DRV.STATUS_RULE2 IS NOT NULL THEN
        S := CHR(10) || CHR(9) || S;

        IF NOT FN_BLD_BODY(L_STAT_DRV.ACCOUNT_CLASS,
                           L_STAT_DRV.STATUS_RULE2,
                           L_STAT_DRV.STATUS,
                           S) THEN
          DEBUG.PR_DEBUG('IC',
                         'Failed in building the body for the condition2 ::' ||
                         L_STAT_DRV.STATUS_RULE2);

          IF DBMS_SQL.IS_OPEN(C) THEN
            DBMS_SQL.CLOSE_CURSOR(C);
          END IF;

          RETURN FALSE;
        END IF;
      END IF;

      IF L_STAT_DRV.STATUS_RULE3 IS NOT NULL THEN
        IF NOT FN_BLD_BODY(L_STAT_DRV.ACCOUNT_CLASS,
                           L_STAT_DRV.STATUS_RULE3,
                           L_STAT_DRV.STATUS,
                           S) THEN
          DEBUG.PR_DEBUG('IC',
                         'Failed in building the body for the condition3 ::' ||
                         L_STAT_DRV.STATUS_RULE3);
          RETURN FALSE;
        END IF;
      END IF;

      IF L_STAT_DRV.STATUS_RULE4 IS NOT NULL THEN
        IF NOT FN_BLD_BODY(L_STAT_DRV.ACCOUNT_CLASS,
                           L_STAT_DRV.STATUS_RULE4,
                           L_STAT_DRV.STATUS,
                           S) THEN
          DEBUG.PR_DEBUG('IC',
                         'Failed in building the body for the condition4 ::' ||
                         L_STAT_DRV.STATUS_RULE4);
          RETURN FALSE;
        END IF;
      END IF;

      IF L_STAT_DRV.STATUS_RULE5 IS NOT NULL THEN
        IF NOT FN_BLD_BODY(L_STAT_DRV.ACCOUNT_CLASS,
                           L_STAT_DRV.STATUS_RULE5,
                           L_STAT_DRV.STATUS,
                           S) THEN
          DEBUG.PR_DEBUG('IC',
                         'Failed in building the body for the condition5 ::' ||
                         L_STAT_DRV.STATUS_RULE5);
          RETURN FALSE;
        END IF;
      END IF;

      DEBUG.PR_DEBUG('IC', 'HERE 2  ' || S);

    END LOOP;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID := 3;
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      L_TB_CLUSTER_DATA('S') := S;
      IF NOT STPKSS_GEN_CLUSTER.FN_GEN_PROC_STAT(PACCLS,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('IC',
                       'Failed in stpkss_gen_cluster.Fn_Gen_Proc_Stat');
        RAISE_APPLICATION_ERROR(-20010, 'Error in stpks_gen_cluster');
      END IF;
      S := L_TB_CLUSTER_DATA('S');
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      GEN(CHR(9) || 'pnew_stat := ' || CHR(39) || 'NORM' || CHR(39) || ';');

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    GEN(CHR(9) || 'RETURN ;');
    GEN('EXCEPTION');
    GEN(CHR(9) || 'WHEN OTHERS THEN');
    GEN(CHR(9) || CHR(9) || 'debug.pr_debug(' || CHR(39) || 'IC' ||
        CHR(39) || ',' || CHR(39) || 'Here in the exception' || CHR(39) || ');');
    GEN(CHR(9) || CHR(9) || 'RETURN ;');

    GEN('END ' || PROC_NAME || ';');

    DEBUG.PR_DEBUG('IC', 'HERE 3' || S);

    PR_PARSE_SQL;

    DEBUG.PR_DEBUG('IC', 'HERE 4');
      
    --sampath starts
      IF DBMS_SQL.IS_OPEN( C ) THEN
      DBMS_SQL.CLOSE_CURSOR( C);
      END IF;
      --sampath ends

   --DBMS_SQL.CLOSE_CURSOR(C); --sampath commented

    DEBUG.PR_DEBUG('IC', 'HERE 5');

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC', 'Failed in sql generation' || SQLERRM);
      DEBUG.PR_DEBUG('IC', 'ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);

      IF DBMS_SQL.IS_OPEN(C) THEN
        DBMS_SQL.CLOSE_CURSOR(C);
      END IF;
      RETURN FALSE;
  END FN_GEN_PROC_STAT;

  FUNCTION FN_BLD_CONDITION(PSTR IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_STR VARCHAR2(1000);

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN

    L_STR := PSTR;
    SELECT REPLACE(L_STR,
                   'FROZEN',
                   'NVL(Cust_rec.Ac_stat_frozen,' || CHR(39) || 'N' ||
                   CHR(39) || ') = ' || CHR(39) || 'Y' || CHR(39))
      INTO L_STR
      FROM DUAL;

    SELECT REPLACE(L_STR,
                   'DORMANT',
                   'NVL(bal_rec.Ac_stat_dormant,' || CHR(39) || 'N' ||
                   CHR(39) || ') = ' || CHR(39) || 'Y' || CHR(39))
      INTO L_STR
      FROM DUAL;

    SELECT REPLACE(L_STR,
                   'NODEBITS',
                   'NVL(Cust_rec.Ac_stat_no_dr,' || CHR(39) || 'N' ||
                   CHR(39) || ') = ' || CHR(39) || 'Y' || CHR(39))
      INTO L_STR
      FROM DUAL;

    SELECT REPLACE(L_STR,
                   'NOCREDITS',
                   'NVL(Cust_rec.Ac_stat_no_cr,' || CHR(39) || 'N' ||
                   CHR(39) || ') = ' || CHR(39) || 'Y' || CHR(39))
      INTO L_STR
      FROM DUAL;

    SELECT REPLACE(L_STR,
                   'STOPPAYMENT',
                   'NVL(Cust_rec.Ac_stat_stop_pay,' || CHR(39) || 'N' ||
                   CHR(39) || ') = ' || CHR(39) || 'Y' || CHR(39))
      INTO L_STR
      FROM DUAL;

    SELECT REPLACE(L_STR, 'CURRSTAT', 'Cust_rec.Acc_status')
      INTO L_STR
      FROM DUAL;

    SELECT REPLACE(L_STR, 'OD_DAYS', 'OD_DAYS') INTO L_STR FROM DUAL;

    SELECT REPLACE(L_STR, 'TOD_DAYS', 'TOD_DAYS') INTO L_STR FROM DUAL;

    SELECT REPLACE(L_STR, 'OVERLINE_DAYS', 'OVERLINE_DAYS')
      INTO L_STR
      FROM DUAL;

    SELECT REPLACE(L_STR, 'INACTIVE_DAYS', 'INACTIVE_DAYS')
      INTO L_STR
      FROM DUAL;

    SELECT REPLACE(L_STR, '"', CHR(39)) INTO L_STR FROM DUAL;

    SELECT REPLACE(L_STR, 'CUST_CLASSIFICATION', 'CUST_CLASSIFICATION')
      INTO L_STR
      FROM DUAL;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID := 1;
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      L_TB_CLUSTER_DATA('L_STR') := L_STR;

      IF NOT STPKSS_GEN_CLUSTER.FN_BLD_CONDITION(PSTR,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('IC',
                       'Failed in stpkss_gen_cluster.Fn_Bld_Condition');
        RAISE_APPLICATION_ERROR(-20010, 'Error in stpks_gen_cluster');
      END IF;

      L_STR := L_TB_CLUSTER_DATA('L_STR');
    END IF;

    DEBUG.PR_DEBUG('IC',
                   'In function build condition and the final string is' ||
                   L_STR);

    PSTR := L_STR;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC',
                     'In the exception of the function build condition');
      RETURN FALSE;
  END FN_BLD_CONDITION;

END;
