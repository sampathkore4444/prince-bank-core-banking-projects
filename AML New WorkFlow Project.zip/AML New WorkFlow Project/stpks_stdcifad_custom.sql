CREATE OR REPLACE PACKAGE BODY STPKS_STDCIFAD_CUSTOM AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcifad_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2019 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

    Changed By         : Kore Sampath Kumar
  Change Description : Prince Bank AML Changes

  Changed By         : Kore Sampath Kumar
  Change Description : Coral Integration with Flexcube Changes

  Changed By         : Kore Sampath Kumar
  Change Description : AML New Workflow changes
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdcifad_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdcifad         IN OUT stpks_stdcifad_Main.ty_stdcifad,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_type_structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdcifad_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  --Prince Bank AML Changes Starts
  FUNCTION Phone_validate(P_NUMBER IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    IF P_NUMBER IS NOT NULL THEN
      IF REGEXP_LIKE(P_NUMBER, '^[0-9_\(\)]+$') THEN
        RETURN TRUE;
      ELSE
        RETURN FALSE;
      END IF;
    ELSE
      RETURN TRUE;
    END IF;
  END PHONE_VALIDATE;
  --Prince Bank AML Changes Starts

  --Coral Integration with Flexcube Changes Starts
  FUNCTION FN_GET_FUNC_FIELD_VAL(P_TBL_UPL_UDF     IN COPKSS_UDF_UPLOAD.TY_UPL_FUNC_UDF,
                                 P_FUNCTIONID      IN VARCHAR2,
                                 P_FIELD_NAME      IN VARCHAR2,
                                 P_FIELD_NUM       OUT NUMBER,
                                 P_FIELD_VAL       OUT VARCHAR2,
                                 P_ERROR_CODE      IN OUT VARCHAR2,
                                 P_ERROR_PARAMETER IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_FIELD_NAME VARCHAR2(100);
  BEGIN
    DBG('In Fn_Get_Func_Field_Val..Multi..');

    FOR I IN P_TBL_UPL_UDF.FIRST .. P_TBL_UPL_UDF.LAST LOOP
      L_FIELD_NAME := P_TBL_UPL_UDF(I).FIELD_NAME;
      IF SUBSTR(L_FIELD_NAME, 1, 10) = 'FIELD_VAL_' THEN
        BEGIN
          SELECT FIELD_NAME
            INTO L_FIELD_NAME
            FROM CSTMS_FUNCTION_UDF_FIELDS_MAP A
           WHERE FUNCTION_ID = P_FUNCTIONID
             AND A.FIELD_NUM = SUBSTR(L_FIELD_NAME, 11)
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Field is not Linked for the product..');
            P_ERROR_CODE      := 'UV-UDFUP004';
            P_ERROR_PARAMETER := P_FIELD_NAME;
            RETURN FALSE;
        END;
      END IF;
      IF L_FIELD_NAME = P_FIELD_NAME THEN
        P_FIELD_VAL := P_TBL_UPL_UDF(I).FIELD_VAL;
        EXIT;
      END IF;
    END LOOP;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  Fn_Get_Func_Field_Val..');
      DBG(SQLERRM);
      P_ERROR_CODE      := 'UV-UDFUPOTH';
      P_ERROR_PARAMETER := 'Fn_Get_Func_Field_Val~' || SQLCODE;
      RETURN FALSE;
  END FN_GET_FUNC_FIELD_VAL;

  FUNCTION FN_GET_RISK_LEVEL_CNT(P_COUNTRY_CODE IN VARCHAR2) RETURN NUMBER IS
    L_VALUE NUMBER;
  BEGIN
    SELECT DECODE(CODE, 'P', 5, 'V', 4, 'H', 3, 'M', '2', 'L', 1, 5)
      INTO L_VALUE
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = 'RISK_LEVEL_CNT'
       AND VALUE = P_COUNTRY_CODE;

    RETURN L_VALUE;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_VALUE;
  END FN_GET_RISK_LEVEL_CNT;

  FUNCTION FN_GET_LMTM_TYPE_CODE(P_CODE IN VARCHAR2, P_TYPE IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.CODE%TYPE IS
    L_CODE LMTM_TYPE_VALUES.CODE%TYPE;
  BEGIN
    SELECT CODE
      INTO L_CODE
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = P_TYPE
       AND VALUE = P_CODE;

    RETURN L_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_CODE;
  END FN_GET_LMTM_TYPE_CODE;

  FUNCTION FN_HTTP_CALL_PRINCE(P_OUT_MSG        CLOB,
                               P_IN_RESP        IN OUT CLOB,
                               P_url            IN VARCHAR2,
                               p_soapaction_url in varchar2,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_BUFFER_SIZE    NUMBER(10) := 1024;
    L_SUBSTRING_MSG  VARCHAR2(32767);
    L_RAW_DATA       RAW(2000);
    L_CLOB_RESPONSE  CLOB;
    L_URL            CSTB_PARAM.PARAM_VAL%TYPE;
    L_RESP_OK        BOOLEAN;
    L_RESP_NUM       NUMBER;
    l_soapaction_url CSTB_PARAM.PARAM_VAL%TYPE;
  BEGIN

    DEBUG.PR_DEBUG('IF', 'In PR_HTTP_CALL');
    DEBUG.PR_DEBUG('IF', '~' || LENGTH(P_OUT_MSG));
    debug.pr_cdebug('IF', 'XML is ' || P_OUT_MSG);

    DBMS_LOB.CREATETEMPORARY(LOB_LOC => L_CLOB_RESPONSE, CACHE => TRUE);
    UTL_HTTP.SET_TRANSFER_TIMEOUT(60);

    SELECT PARAM_VAL
      INTO l_url
      FROM CSTB_PARAM_CUSTOM
     WHERE param_name = uPPER(P_url); --'CORAL_VALIDATION_WS_URL';
    --L_URL := CSPKS_OS_PARAM.GET_PARAM_VAL('CORAL_VALIDATION_WS_URL');

    SELECT param_VAL
      INTO l_soapaction_url
      FROM cstb_param_custom
     where param_name = p_soapaction_url;

    DEBUG.PR_DEBUG('IF', 'l_url-->' || L_URL);
    L_HTTP_REQUEST := UTL_HTTP.BEGIN_REQUEST(URL          => L_URL,
                                             METHOD       => 'POST',
                                             HTTP_VERSION => 'HTTP/1.1');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST, 'User-Agent', 'Mozilla/4.0');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST, 'Connection', 'close');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST,
                        'Content-Length',
                        LENGTH(P_OUT_MSG));
    UTL_HTTP.set_header(l_http_request, 'SOAPAction', l_soapaction_url);
    <<REQUEST_LOOP>>
    FOR I IN 0 .. CEIL(LENGTH(P_OUT_MSG) / L_BUFFER_SIZE) - 1 LOOP
      L_SUBSTRING_MSG := SUBSTR(P_OUT_MSG,
                                I * L_BUFFER_SIZE + 1,
                                L_BUFFER_SIZE);
      DEBUG.PR_DEBUG('FOR', 'L_SUBSTRING_MSG-->' || i || '--' || L_URL);

      BEGIN
        L_RAW_DATA := UTL_RAW.CAST_TO_RAW(L_SUBSTRING_MSG);
        UTL_HTTP.WRITE_RAW(R => L_HTTP_REQUEST, DATA => L_RAW_DATA);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('IF', 'Request Loop NDF');
          EXIT REQUEST_LOOP;
      END;
    END LOOP REQUEST_LOOP;
    L_HTTP_RESPONSE := UTL_HTTP.GET_RESPONSE(L_HTTP_REQUEST);
    DEBUG.PR_DEBUG('IF',
                   'Response> status_code: "' ||
                   L_HTTP_RESPONSE.STATUS_CODE || '"');
    L_RESP_OK := FALSE;
    SELECT DECODE(L_HTTP_RESPONSE.STATUS_CODE, 200, 1, 0)
      INTO L_RESP_NUM
      FROM DUAL;
    -- IF l_http_response.status_code = 200 THEN
    IF L_RESP_NUM = 1 THEN
      L_RESP_OK := TRUE;
    ELSIF L_RESP_NUM = 0 THEN
      L_RESP_OK := FALSE;
    END IF;

    IF L_RESP_OK THEN
      BEGIN

        LOOP
          UTL_HTTP.READ_RAW(L_HTTP_RESPONSE, L_RAW_DATA, L_BUFFER_SIZE);
          L_CLOB_RESPONSE := L_CLOB_RESPONSE ||
                             UTL_RAW.CAST_TO_VARCHAR2(L_RAW_DATA);
        END LOOP RESPONSE_LOOP;
      EXCEPTION
        WHEN UTL_HTTP.END_OF_BODY THEN
          UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IF', SQLERRM);
          DEBUG.PR_DEBUG('IF', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
      END;
      --  DBG('Out of Loop');
      DEBUG.PR_DEBUG('IF',
                     'Length of response-->' ||
                     DBMS_LOB.GETLENGTH(L_CLOB_RESPONSE));
      DEBUG.PR_DEBUG('IF',
                     'value of response-->' ||
                     DBMS_LOB.SUBSTR(L_CLOB_RESPONSE, 32767));
      P_IN_RESP := L_CLOB_RESPONSE;

    END IF;

    IF L_HTTP_REQUEST.PRIVATE_HNDL IS NOT NULL THEN
      UTL_HTTP.END_REQUEST(L_HTTP_REQUEST);
    END IF;

    IF L_HTTP_RESPONSE.PRIVATE_HNDL IS NOT NULL THEN
      UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
    END IF;

    DBMS_LOB.FREETEMPORARY(L_CLOB_RESPONSE);

    IF L_RESP_OK THEN
      DEBUG.PR_DEBUG('IF', 'OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      DEBUG.PR_DEBUG('IF', 'PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In WOT...Return false now...' || SQLERRM ||
                     dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_HTTP_CALL_PRINCE;
  --Coral Integration with Flexcube Changes Ends

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdcifad         IN OUT stpks_stdcifad_Main.Ty_stdcifad,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
    --Prince Bank AML Changes Starts
    L_COUNT NUMBER;
    --Prince Bank AML Changes Ends
    --Coral Integration with Flexcube Changes Starts
    L_FULL_NAME_CHK  STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_DATE_CHK       STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
	L_DATE_CHK1      VARCHAR2(100);
    L_COUNTRY_CHK    STTMS_CUSTOMER.COUNTRY%TYPE;
    L_OUT_MSG        CLOB;
    L_IN_RESP        CLOB;
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_ATTR_NODES     DBMS_XMLDOM.DOMNAMEDNODEMAP;
    L_ATTR_NODE      DBMS_XMLDOM.DOMNODE;
    L_ATTRIBUTE_NAME VARCHAR2(50);
    L_NODE_NAME      VARCHAR2(50);
    L_NODE_VALUE     VARCHAR2(100);
    P                DBMS_XMLPARSER.PARSER;
    L_DOC            DBMS_XMLDOM.DOMDOCUMENT;
    L_ROOT_ELEMENT   DBMS_XMLDOM.DOMELEMENT;
    L_CHILD_NODES    DBMS_XMLDOM.DOMNODELIST;
    L_CHILD_NODE     DBMS_XMLDOM.DOMNODE;
    L_TEXT_NODE      DBMS_XMLDOM.DOMNODE;
    L_BASE_NODES     DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODES1    DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODE      DBMS_XMLDOM.DOMNODE;
    -- V_XML_DATA         CLOB;
    L_HIT_VALUE           VARCHAR2(100);
    L_RTN_SCAN_ID         VARCHAR2(4000);
    L_RTN_ENCRYPT_SCAN_ID VARCHAR2(4000);
    L_SEARCH_NAME         VARCHAR2(4000);
    L_RETURN_STATUS       VARCHAR2(100);
    L_RISK_LEVEL          CHAR(1);

    L_PEP_FLAG           VARCHAR2(2);
    L_NATIONALITY        VARCHAR2(100);
    L_ADVERSE_MEDIA_FLAG VARCHAR2(2);
    L_REL_HIGH_RISK_FLAG VARCHAR2(2);
    L_CHANNEL            VARCHAR2(5);
    L_PROD_RISK          VARCHAR2(2);
    L_ASSET_VALUE        VARCHAR2(2);
    L_STR                VARCHAR2(2);
    L_BEHAVIOUR_TREND    VARCHAR2(2);
    L_OCCUPATION         VARCHAR2(1000);

    L_RISK_FACTORS VARCHAR2(1000);
    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE TYPE_RISK_SCORE;
    L_MAX_INDEX  NUMBER;
    L_MAX_VALUE  NUMBER;
    L_REF        VARCHAR2(16);
    L_SEQ        NUMBER;

    L_FIELD_NUM     NUMBER;
    L_SECURITY_NO_1 CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_3%type;
    L_SECURITY_NO_2 CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_4%type;
    --Coral Integration with Flexcube Changes Ends

  --AML New Workflow changes Starts
    L_STTB_CORAL_WS_LOG STTB_CORAL_WS_LOG%ROWTYPE;
    --AML New Workflow changes Ends

  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory');

    --Prince Bank AML Changes Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      --Validations for Individual Customers
      IF P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

        IF P_STDCIFAD.V_STTMS_CUST_PERSONAL.RESIDENT_STATUS IS NULL THEN
          DBG('Resident Status should not be null for Individual customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-007', '');
        END IF;

        IF P_STDCIFAD.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER IS NULL THEN
          DBG('Mobile Number should not be null for Individual customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-005', '');
        END IF;

        /* IF P_STDCIFAD.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY IS NULL THEN
          DBG('Birth Country should not be null for Individual customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-006', '');
        END IF;*/

        --MOBILE NUMBER VALIDATION
        IF P_STDCIFAD.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER IS NOT NULL THEN
          IF NOT
              PHONE_VALIDATE(P_STDCIFAD.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER) THEN
            DBG('Invalid Phone Number ');
            P_ERR_CODE := 'LSVAL-01';
            RETURN FALSE;

          END IF;
        END IF;

        --VALIDATIONS FOR ISSUE AND EXPIRY DATES FOR PASSPORT AND NATIONAL ID AND CIVIL SERVANT CARD AND DRIVER LICENSE
        IF P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('PASSPORT') THEN
          IF /*P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR*/
           P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN
            DBG('Passport issue date or passport expiry date cannot be null.');
            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-MAN011', '');
          END IF;
        END IF;

        IF P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('NATIONAL ID') THEN
          IF /*P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR*/
           P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN

            DBG('National ID Issue date or National ID Expiry date cannot be null.');
            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-001', '');
          END IF;
        END IF;

        IF P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN
           ('CIVIL SERVANT CARD') THEN
          IF /*P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR*/
           P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN

            DBG('CIVIL SERVANT CARD Issue date or National ID Expiry date cannot be null.');
            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-001', '');
          END IF;
        END IF;

        IF P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('DRIVER LICENSE') THEN
          IF /*P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR*/
           P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN

            DBG('DRIVER LICENSE Issue date or National ID Expiry date cannot be null.');
            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-001', '');
          END IF;
        END IF;

        --Duplicate validation on Unique identifiers
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTM_CUSTOMER
           WHERE UNIQUE_ID_NAME =
                 P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME
             AND UNIQUE_ID_VALUE =
                 P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE;

        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;

        IF L_COUNT <> 0 THEN
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-016', '');
          RETURN FALSE; --Coral Integration with Flexcube Changes
        END IF;

      END IF;

      --Coral Integration with Flexcube Changes Starts
      IF P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

        L_FULL_NAME_CHK := TRIM(P_STDCIFAD.V_STTMS_CUSTOMER.FULL_NAME);

        L_DATE_CHK := TO_DATE(P_STDCIFAD.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                              'DD/MM/RRRR');
        
		DBG('DATE IN FORMAT1=' ||
            TO_CHAR(P_STDCIFAD.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                    Cspks_Req_Global.g_Ws_Date_Format));
      
        DBG('DATE IN FORMAT2=' || SUBSTR(TO_CHAR(P_STDCIFAD.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                                 Cspks_Req_Global.g_Ws_Date_Format),
                                         1,
                                         4));
		L_DATE_CHK1 := SUBSTR(TO_CHAR(P_STDCIFAD.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                      Cspks_Req_Global.g_Ws_Date_Format),
                              1,
                              4);
							  
        L_COUNTRY_CHK := P_STDCIFAD.V_STTMS_CUSTOMER.NATIONALITY;

        DBG('(P_STDCIFAD.V_STTMS_CUSTOMER.COUNTRY=' ||
            P_STDCIFAD.V_STTMS_CUSTOMER.COUNTRY);
        DBG('P_STDCIFAD.V_STTMS_CUSTOMER.NATIONALITY=' ||
            P_STDCIFAD.V_STTMS_CUSTOMER.NATIONALITY);
        DBG('P_STDCIFAD.V_STTMS_CUST_PERSONAL.P_COUNTRY=' ||
            P_STDCIFAD.V_STTMS_CUST_PERSONAL.P_COUNTRY);

        --Risk Factors
        L_PEP_FLAG := '0|';

        L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIFAD.V_STTMS_CUSTOMER.COUNTRY),
                                        FN_GET_RISK_LEVEL_CNT(P_STDCIFAD.V_STTMS_CUSTOMER.NATIONALITY),
                                        FN_GET_RISK_LEVEL_CNT(P_STDCIFAD.V_STTMS_CUST_PERSONAL.P_COUNTRY));

        L_MAX_INDEX := 1;
        L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

        FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

          IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
            L_MAX_VALUE := L_RISK_SCORE(G);
            L_MAX_INDEX := G;
          END IF;
        END LOOP;

        DBG('L_MAX_INDEX=' || L_MAX_INDEX);

        -- IF L_MAX_INDEX = 1 THEN
        -- L_NATIONALITY := P_STDCIFAD.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY;
        IF L_MAX_INDEX = 1 THEN
          L_NATIONALITY := P_STDCIFAD.V_STTMS_CUSTOMER.COUNTRY;
        ELSIF L_MAX_INDEX = 2 THEN
          L_NATIONALITY := P_STDCIFAD.V_STTMS_CUSTOMER.NATIONALITY;
        ELSE
          L_NATIONALITY := P_STDCIFAD.V_STTMS_CUST_PERSONAL.P_COUNTRY;
        END IF;

        DBG('L_NATIONALITY=' || L_NATIONALITY);

        --L_ADVERSE_MEDIA_FLAG := '0';
        L_REL_HIGH_RISK_FLAG := '2|';
        L_CHANNEL            := 'BFTF|';
        L_PROD_RISK          := '0|';
        L_ASSET_VALUE        := '0|';
        L_STR                := '0|';
        L_BEHAVIOUR_TREND    := '1|';
        L_OCCUPATION         := '0';

        DBG('L_NATIONALITY=' || L_NATIONALITY);

        /*L_RISK_FACTORS := L_PEP_FLAG || L_NATIONALITY || '|' ||
        L_ADVERSE_MEDIA_FLAG || L_REL_HIGH_RISK_FLAG ||
        L_CHANNEL || L_PROD_RISK || L_ASSET_VALUE ||
        L_STR || L_BEHAVIOUR_TREND || L_OCCUPATION;*/

        L_RISK_FACTORS := L_PEP_FLAG || L_NATIONALITY || '|' ||
                          L_REL_HIGH_RISK_FLAG || L_CHANNEL || L_PROD_RISK ||
                          L_ASSET_VALUE || L_STR || L_BEHAVIOUR_TREND ||
                          L_OCCUPATION;

        DBG('L_RISK_FACTORS=' || L_RISK_FACTORS);

        --Get SECURITY_NO_1 UDF Field Value
        IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIFAD.UDF_DETAILS,
                                     P_FUNCTION_ID,
                                     'PASS_SECURITY_NO_1',
                                     L_FIELD_NUM,
                                     L_SECURITY_NO_1,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
          DBG('Failed in Fetching the Field Value..');
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --RETURN FALSE;
        END IF;

        DBG('UDF Field - PASS_SECURITY_NO_1 L_SECURITY_NO_1=' ||
            L_SECURITY_NO_1);

        --Get SECURITY_NO_1 UDF Field Value
        IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIFAD.UDF_DETAILS,
                                     P_FUNCTION_ID,
                                     'PASS_SECURITY_NO_2',
                                     L_FIELD_NUM,
                                     L_SECURITY_NO_2,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
          DBG('Failed in Fetching the Field Value..');
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --RETURN FALSE;
        END IF;

        DBG('UDF Field - PASS_SECURITY_NO_1 L_SECURITY_NO_2=' ||
            L_SECURITY_NO_2);

        DBG('L_SECURITY_NO_1=' || L_SECURITY_NO_1);
        DBG('L_SECURITY_NO_2=' || L_SECURITY_NO_2);

        IF P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('PASSPORT') AND
           (L_SECURITY_NO_1 IS NULL OR L_SECURITY_NO_2 IS NULL) THEN
          DBG('Passport Security Numbers should be input by user');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-008', '');
          RETURN FALSE;
        END IF;

      END IF;

      IF L_FULL_NAME_CHK IS NULL THEN

        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := 'Full Name';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        OVPKS.PR_APPENDTBL('ST-MAN01', 'Full Name');
      END IF;

      IF L_DATE_CHK IS NULL THEN

        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := 'Date of Birth';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        OVPKS.PR_APPENDTBL('ST-MAN01', 'Date of Birth');
      END IF;

      IF (L_FULL_NAME_CHK IS NULL OR L_DATE_CHK IS NULL OR
         L_COUNTRY_CHK IS NULL) THEN

        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := 'Country';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        OVPKS.PR_APPENDTBL('ST-MAN01', 'Country');
      END IF;

    --AML New Workflow changes Commented Starts
    /*
      L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
         <soapenv:Header/>
         <soapenv:Body>
            <tem:OnlineScan>

               <tem:AuthUser>AMLSVC</tem:AuthUser>

               <tem:AuthPswd>AMLSVC</tem:AuthPswd>

               <tem:Username>' || GLOBAL.USER_ID ||
                   '</tem:Username>

               <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                   '</tem:BrCode>

               <tem:SysName>FCUBS</tem:SysName>

               <tem:ScanOption>3|3</tem:ScanOption>

               <tem:UniqueNo>' ||
                   P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_NO ||
                   '</tem:UniqueNo>

               <tem:SearchName>' || L_FULL_NAME_CHK ||
                   '</tem:SearchName>

               <tem:SearchCountry>' || L_COUNTRY_CHK ||
                   '</tem:SearchCountry>

               <tem:SearchDOB>' ||
                   TO_CHAR(L_DATE_CHK, 'RRRR') || '</tem:SearchDOB>

               <tem:SearchID>' || CASE
                     WHEN P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                          P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                          'PASSPORT' THEN
                      P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE
                     ELSE
                      NULL
                   END || '</tem:SearchID>

               <tem:PassportVerify>' || CASE
                     WHEN P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                          P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                          'PASSPORT' THEN
                      1
                     ELSE
                      NULL
                   END || '</tem:PassportVerify>

               <tem:SecurityNo1></tem:SecurityNo1>

               <tem:PassExpiryDtVerify>' || CASE
                     WHEN P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                          P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                          'PASSPORT' THEN
                      1
                     ELSE
                      NULL
                   END || '</tem:PassExpiryDtVerify>

               <tem:PassExpiryDate>' || CASE
                     WHEN P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                          P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                          'PASSPORT' THEN
                      TO_CHAR(P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT,
                              'YYMMDD')
                     ELSE
                      NULL
                   END || '</tem:PassExpiryDate>

               <tem:SecurityNo2></tem:SecurityNo2>

               <tem:RiskFactors>' || '1#' || L_RISK_FACTORS ||
                   '</tem:RiskFactors>

               <tem:Content></tem:Content>

               <tem:RtnHit>1</tem:RtnHit>

               <tem:RtnScanID>0</tem:RtnScanID>

               <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
            </tem:OnlineScan>
         </soapenv:Body>
      </soapenv:Envelope>';*/
      --AML New Workflow changes Commented Ends

    --AML New Workflow changes Starts
      L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
         <soapenv:Header/>
         <soapenv:Body>
            <tem:OnlineScan>

               <tem:AuthUser>AMLSVC</tem:AuthUser>

               <tem:AuthPswd>AMLSVC</tem:AuthPswd>

               <tem:Username>' || GLOBAL.USER_ID ||
                   '</tem:Username>

               <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                   '</tem:BrCode>

               <tem:SysName>FCUBS</tem:SysName>

               <tem:ScanOption>1|3</tem:ScanOption>

               <tem:UniqueNo>' ||
                   P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_NO ||
                   '</tem:UniqueNo>

               <tem:SearchName>' || L_FULL_NAME_CHK ||
                   '</tem:SearchName>

               <tem:SearchCountry>' || L_COUNTRY_CHK ||
                   '</tem:SearchCountry>

               <tem:SearchDOB>' || L_DATE_CHK1 || '</tem:SearchDOB>

               <tem:SearchID>' || CASE
                     WHEN P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                          P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                          'PASSPORT' THEN
                      P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE
                     ELSE
                      NULL
                   END || '</tem:SearchID>

               <tem:PassportVerify>' || CASE
                     WHEN P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                          P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                          'PASSPORT' THEN
                      1
                     ELSE
                      NULL
                   END || '</tem:PassportVerify>

               <tem:SecurityNo1>'||L_SECURITY_NO_1||'</tem:SecurityNo1>

               <tem:PassExpiryDtVerify>' || CASE
                     WHEN P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                          P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                          'PASSPORT' THEN
                      1
                     ELSE
                      NULL
                   END || '</tem:PassExpiryDtVerify>

               <tem:PassExpiryDate>' || CASE
                     WHEN P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                          P_STDCIFAD.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                          'PASSPORT' THEN
                      TO_CHAR(P_STDCIFAD.V_STTMS_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT,
                              'YYMMDD')
                     ELSE
                      NULL
                   END || '</tem:PassExpiryDate>

               <tem:SecurityNo2>'||L_SECURITY_NO_2|| '</tem:SecurityNo2>

               <tem:RiskFactors>' || '1#' || L_RISK_FACTORS ||
                   '</tem:RiskFactors>

               <tem:Content></tem:Content>

               <tem:RtnHit>1</tem:RtnHit>

               <tem:RtnScanID>0</tem:RtnScanID>

               <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
            </tem:OnlineScan>
         </soapenv:Body>
      </soapenv:Envelope>';

      --AML New Workflow changes Ends

      --Log ONLINE_SCAN request xml
      SELECT FC_CORAL_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

      L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

      DBG('L_REF=' || L_REF);

      --Condition not to log second time
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_CORAL_WS_LOG
         WHERE ACTION = P_ACTION_CODE
           AND CUSTOMER_NO = P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_NO;
        --AND SCAN_ID IS NOT NULL
        --AND ACTION <> 'NEW';
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;

      DBG('L_COUNT=' || L_COUNT);

      IF L_COUNT = 0 THEN

        STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_WS_LOG(L_REF,
                                                  P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                  GLOBAL.APPLICATION_DATE,
                                                  'ONLINE_SCAN',
                                                  P_ACTION_CODE,
                                                  L_OUT_MSG);

        IF NOT FN_HTTP_CALL_PRINCE(L_OUT_MSG,
                                   L_IN_RESP,
                                   'CORAL_VALIDATION_WS_URL',
                                   'CORAL_SOAPACTION_WS_URL',
                                   P_ERR_CODE,
                                   P_ERR_PARAMS)

         THEN

          DBG('FAILED DURING INVOCATION OF CORAL WEBSERVICES');
          DBG('P_ERR_CODE=' || P_ERR_CODE);
          DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);

          P_ERR_CODE := 'ST-CRL-003';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        END IF;

        DBG('L_IN_RESP=' || L_IN_RESP);

        P := DBMS_XMLPARSER.NEWPARSER;
        DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
        DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
        L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
        L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
        L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                           'Fault');
        --Parsing failure response from coral
        IF (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) THEN

          FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
            L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
            L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
            L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
            --
            FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
              L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
              L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
              L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
              L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
              IF L_NODE_NAME = 'faultcode' THEN
                P_ERR_CODE := L_NODE_VALUE;
              ELSIF L_NODE_NAME = 'faultstring' THEN
                P_ERR_PARAMS := L_NODE_VALUE;
              END IF;

              P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                              '-- The Webservices returned a fail XML';
            END LOOP;
          END LOOP;

          OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);

        ELSE

          --Parsing Success Response from coral
          L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                           'OnlineScanResponse');

          FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) - 1 LOOP
            L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
            L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
            L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
            --
            FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
              L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
              L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
              L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
              L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
              --
              IF L_NODE_NAME = 'RtnHit' THEN
                L_HIT_VALUE := L_NODE_VALUE;
              ELSIF L_NODE_NAME = 'RtnScanID' THEN
                L_RTN_SCAN_ID := L_NODE_VALUE;
              ELSIF L_NODE_NAME = 'RtnEnCryptScanID' THEN
                L_RTN_ENCRYPT_SCAN_ID := L_NODE_VALUE;
              END IF;

            END LOOP;
          END LOOP;

          DBG('L_HIT_VALUE=' || L_HIT_VALUE);
          DBG('L_RTN_SCAN_ID=' || L_RTN_SCAN_ID);
          DBG('L_RTN_ENCRYPT_SCAN_ID=' || L_RTN_ENCRYPT_SCAN_ID);

          IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 OR
             INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'F') > 0 THEN
            L_RETURN_STATUS := 'HIT';
          ELSE
            L_RETURN_STATUS := 'NO HIT';
          END IF;

          SELECT /*DECODE(UPPER(SUBSTR(L_HIT_VALUE, 0, 1)),
                                                                                    'Y',
                                                                                    'HIT',
                                                                                    'NO HIT'),*/
          --SUBSTR(L_HIT_VALUE, 1, 1)
           SUBSTR(L_HIT_VALUE, INSTR(L_HIT_VALUE, '|') + 1, 1)
            INTO /*L_RETURN_STATUS,*/ L_RISK_LEVEL
            FROM DUAL;

          --Update ONLINE_SCAN xml ws response
          STPKS_CORAL_WS_LOG.PR_UPDATE_CORAL_WS_LOG(L_REF,
                                                    L_RTN_SCAN_ID,
                                                    L_RETURN_STATUS,
                                                    L_RISK_LEVEL,
                                                    L_HIT_VALUE,
                                                    L_IN_RESP);

          BEGIN

            DBG('L_RETURN_STATUS=' || L_RETURN_STATUS);

            IF L_RETURN_STATUS = 'HIT' OR L_RISK_LEVEL = 'H' THEN

              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'ST-PRIN-023',
                           L_RTN_SCAN_ID);

            END IF;

            INSERT INTO STTM_CORAL_DATA_CUSTOM
              (SCAN_ID,
               HIT_TYPE,
               FULL_NAME,
               DATEOFBIRTH,
               COUNTRY,
               MAKER_DT,
               STATUS,
               BRANCH_CODE)
            VALUES
              (L_RTN_SCAN_ID,
               L_RETURN_STATUS,
               L_FULL_NAME_CHK,
               L_DATE_CHK,
               L_COUNTRY_CHK,
               GLOBAL.APPLICATION_DATE,
               'open',
               GLOBAL.CURRENT_BRANCH);
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              UPDATE STTMS_CORAL_DATA_CUSTOM
                 SET HIT_TYPE = L_RETURN_STATUS, SCAN_ID = L_RTN_SCAN_ID
               WHERE FULL_NAME =
                     TRIM(P_STDCIFAD.V_STTMS_CUSTOMER.FULL_NAME)
                 AND DATEOFBIRTH = TO_DATE(P_STDCIFAD.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                           'DD/MM/RRRR')
                 AND COUNTRY = L_COUNTRY_CHK
                 AND MAKER_DT = GLOBAL.APPLICATION_DATE
                 AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
          END;

        END IF;

    ELSE
          --added to show same alert again if we click second time

          BEGIN
            SELECT *
              INTO L_STTB_CORAL_WS_LOG
              FROM STTB_CORAL_WS_LOG
             WHERE ACTION = P_ACTION_CODE
               AND CUSTOMER_NO = P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_NO
               AND SCAN_ID IS NOT NULL;
          EXCEPTION
            WHEN OTHERS THEN
              L_STTB_CORAL_WS_LOG := NULL;
          END;

          IF L_STTB_CORAL_WS_LOG.STATUS = 'HIT' OR
             L_STTB_CORAL_WS_LOG.RISK_LEVEL = 'H' THEN

            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'ST-PRIN-023',
                         L_STTB_CORAL_WS_LOG.SCAN_ID);

          END IF;

      END IF;

    END IF;

    --Second API call during auth
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) THEN
      DBG('INSIDE AUTH ACTION');
      /*--Get the scan id
      BEGIN
        SELECT SCAN_ID
          INTO L_RTN_SCAN_ID
          FROM STTM_CORAL_DATA_CUSTOM
         WHERE FULL_NAME = TRIM(P_STDCIFAD.V_STTMS_CUSTOMER.FULL_NAME)
           AND DATEOFBIRTH = TO_DATE(P_STDCIFAD.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                     'DD/MM/RRRR')
           AND COUNTRY = P_STDCIFAD.V_STTMS_CUSTOMER.COUNTRY
           AND BRANCH_CODE = P_STDCIFAD.V_STTMS_CUSTOMER.LOCAL_BRANCH
           AND MAKER_DT = P_STDCIFAD.V_STTMS_CUSTOMER.MAKER_DT_STAMP;
      EXCEPTION
        WHEN OTHERS THEN
          L_RTN_SCAN_ID := NULL;
      END;*/

      BEGIN
        SELECT SCAN_ID, HIT_VALUE
          INTO L_RTN_SCAN_ID, L_HIT_VALUE
          FROM STTB_CORAL_WS_LOG
         WHERE CUSTOMER_NO = P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND UNIQUE_REFERENCE_NO =
               (SELECT MAX(UNIQUE_REFERENCE_NO)
                  FROM STTB_CORAL_WS_LOG
                 WHERE CUSTOMER_NO = P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND ACTION <> 'AUTH'); --AML New Workflow changes added last condition
      EXCEPTION
        WHEN OTHERS THEN
          L_RTN_SCAN_ID := NULL;
      END;

      DBG('L_RTN_SCAN_ID=' || L_RTN_SCAN_ID);
      DBG('L_HIT_VALUE=' || L_HIT_VALUE);

      IF L_HIT_VALUE NOT IN ('NNN|L', 'NNN|M') THEN
        IF L_RTN_SCAN_ID IS NULL THEN

          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-022', '');

          RETURN FALSE;

        END IF;

        L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
       <soapenv:Header/>
       <soapenv:Body>
          <tem:OnlineStatus>

             <tem:AuthUser>AMLSVC</tem:AuthUser>

             <tem:AuthPass>AMLSVC</tem:AuthPass>

             <tem:Username>' || GLOBAL.USER_ID ||
                     '</tem:Username>

             <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                     '</tem:BrCode>

             <tem:SysName>FCUBS</tem:SysName>

             <tem:ScanOption>3</tem:ScanOption>
             <tem:UniqueNo></tem:UniqueNo>


             <tem:scanID>' || L_RTN_SCAN_ID ||
                     '</tem:scanID>

             <tem:rtnResult></tem:rtnResult>
          </tem:OnlineStatus>
       </soapenv:Body>
    </soapenv:Envelope>';

        --Log ONLINE_STATUS request xml
        SELECT FC_CORAL_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

        L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

        DBG('L_REF=' || L_REF);

        STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_WS_LOG(L_REF,
                                                  P_STDCIFAD.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                  GLOBAL.APPLICATION_DATE,
                                                  'ONLINE_STATUS',
                                                  P_ACTION_CODE,
                                                  L_OUT_MSG);

        IF NOT FN_HTTP_CALL_PRINCE(L_OUT_MSG,
                                   L_IN_RESP,
                                   'CORAL_VALIDATION_CONFIRM_URL',
                                   'CORAL_SOAPACTION_CONFIRM_URL',
                                   P_ERR_CODE,
                                   P_ERR_PARAMS)

         THEN

          DBG(SQLERRM || ' Failed during Invocation of Coral Webservices ' ||
              P_ERR_CODE);
          P_ERR_CODE := 'ST-CRL-003';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        END IF;

        DBG('L_IN_RESP=' || L_IN_RESP);
        P := DBMS_XMLPARSER.NEWPARSER;
        DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
        DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
        L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
        L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
        L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                           'Fault');
        if (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) then

          FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
            L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
            L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
            L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
            --
            FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
              l_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
              L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
              L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
              L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);

              IF L_NODE_NAME = 'faultcode' THEN
                P_ERR_CODE := L_NODE_VALUE;
              ELSIF L_NODE_NAME = 'faultstring' THEN
                P_ERR_PARAMS := L_NODE_VALUE;
              END IF;
              dbg('The Webservices returned a Failed Webservice XML ' ||
                  P_ERR_CODE || P_ERR_PARAMS);
              P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                              '-- The Webservices returned a fail XML';
            END LOOP;
          END LOOP;
          OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);

        Else
          L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                           'OnlineStatusResponse');

          FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) LOOP
            L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
            L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
            L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
            --
            FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
              L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
              L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
              L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
              L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
              --
              IF L_NODE_NAME = 'rtnResult' THEN
                L_HIT_VALUE := L_NODE_VALUE;
                DBG('L_HIT_VALUE DURING SECOND WEBSERVICE CALL=' ||
                    L_HIT_VALUE);

              END IF;
            END LOOP;
          END LOOP;
          SELECT DECODE(L_HIT_VALUE,
                        'P',
                        'PENDING',
                        'R',
                        'REJECTED',
                        'G',
                        'APPROVED',
                        L_HIT_VALUE)
            INTO L_RETURN_STATUS
            FROM DUAL;
          dbg('L_RETURN_STATUS=' || L_RETURN_STATUS);

          --Update ONLINE_SCAN xml ws response
          STPKS_CORAL_WS_LOG.PR_UPDATE_CORAL_WS_LOG(L_REF,
                                                    L_RTN_SCAN_ID,
                                                    L_RETURN_STATUS,
                                                    L_IN_RESP);

          UPDATE STTMS_CORAL_DATA_CUSTOM
             SET HIT_TYPE = L_RETURN_STATUS
           WHERE SCAN_ID = L_RTN_SCAN_ID
             AND FULL_NAME = TRIM(P_STDCIFAD.V_STTMS_CUSTOMER.FULL_NAME)
             AND DATEOFBIRTH = TO_DATE(P_STDCIFAD.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                       'DD/MM/RRRR')
             AND COUNTRY = P_STDCIFAD.V_STTMS_CUSTOMER.COUNTRY
             AND BRANCH_CODE = P_STDCIFAD.V_STTMS_CUSTOMER.LOCAL_BRANCH
             AND MAKER_DT = P_STDCIFAD.V_STTMS_CUSTOMER.MAKER_DT_STAMP;

          DBG(SQL%ROWCOUNT || L_RTN_SCAN_ID);

          IF L_RETURN_STATUS IN ('REJECTED') THEN
            P_ERR_CODE := 'ST-PRIN-010';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

          IF L_RETURN_STATUS IN ('PENDING') THEN
            P_ERR_CODE := 'ST-PRIN-011';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

        END IF;
      END IF;
    END IF;
    --Coral Integration with Flexcube Changes Ends
    --Prince Bank AML Changes Ends

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcifad_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdcifad         IN stpks_stdcifad_Main.ty_stdcifad,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcifad_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdcifad         IN stpks_stdcifad_Main.ty_stdcifad,
                                       p_Prev_stdcifad    IN OUT stpks_stdcifad_Main.ty_stdcifad,
                                       p_Wrk_stdcifad     IN OUT stpks_stdcifad_Main.ty_stdcifad,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcifad_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdcifad         IN stpks_stdcifad_Main.Ty_stdcifad,
                                        p_Prev_stdcifad    IN OUT stpks_stdcifad_Main.Ty_stdcifad,
                                        p_Wrk_stdcifad     IN OUT stpks_stdcifad_Main.Ty_stdcifad,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcifad_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdcifad         IN stpks_stdcifad_Main.Ty_stdcifad,
                            p_Prev_stdcifad    IN stpks_stdcifad_Main.Ty_stdcifad,
                            p_Wrk_stdcifad     IN OUT stpks_stdcifad_Main.Ty_stdcifad,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..');

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcifad_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdcifad         IN stpks_stdcifad_Main.Ty_stdcifad,
                             p_prev_stdcifad    IN stpks_stdcifad_Main.Ty_stdcifad,
                             p_wrk_stdcifad     IN OUT stpks_stdcifad_Main.Ty_stdcifad,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcifad_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdcifad         IN stpks_stdcifad_Main.Ty_stdcifad,
                        p_Wrk_stdcifad     IN OUT stpks_stdcifad_Main.Ty_stdcifad,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Query..');

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcifad_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdcifad         IN stpks_stdcifad_Main.ty_stdcifad,
                         p_wrk_stdcifad     IN OUT stpks_stdcifad_Main.ty_stdcifad,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Query..');

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdcifad_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdcifad_custom;
