CREATE OR REPLACE PACKAGE BODY STPKS_CORAL_WS_LOG IS

  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : STPKS_CORAL_WS_LOG.sql
  **
  ** Module     : Static Maintenance
  
  CHANGE HISTORY
  
  
  Changed By         : Kore Sampath Kumar
  Change Description : Coral Integration with Flexcube Changes
  
  Changed By         : Kore Sampath Kumar
  Change Description : Delete CIF from coral table to avoid passing old scan id to AML
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'STPKS_CORAL_WS_LOG ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  FUNCTION FN_RETURN_COSMETIC_XML(P_XML IN VARCHAR2) RETURN VARCHAR2 IS
  
    P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><soap:Body>',
                              '');
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              'xmlns="http://tempuri.org/"',
                              NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '</soap:Body></soap:Envelope>',
                              NULL);
  
    RETURN P_COSMETIC_XML;
  
  END FN_RETURN_COSMETIC_XML;

  PROCEDURE PR_INSERT_MODIFY_IND_CUST(P_UNIQUE_REF_NO      IN VARCHAR2,
                                      P_CUSTOMER_NO        IN VARCHAR2,
                                      P_ACTION_CODE        IN VARCHAR2,
                                      P_CUST_CATEGORY      VARCHAR2,
                                      P_CURR_FULL_NAME_CHK VARCHAR2,
                                      P_CURR_DATE_CHK      VARCHAR2,
                                      P_CURR_COUNTRY_CHK   VARCHAR2,
                                      P_CURR_BIRTH_COUNTRY VARCHAR2,
                                      P_CURR_COUNTRY       VARCHAR2,
                                      P_CURR_NATIONALITY   VARCHAR2,
                                      P_CURR_P_COUNTRY     VARCHAR2,
                                      P_CURR_ECO_SECTOR    VARCHAR2,
                                      P_CURR_OCCUPATION    VARCHAR2,
                                      P_CURR_SECURITY_NO_1 VARCHAR2,
                                      P_CURR_SECURITY_NO_2 VARCHAR2,
                                      P_MODIFY_TIME        DATE,
                                      P_MOD_NO             NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    INSERT INTO STTB_MODIFY_IND_CUST
    VALUES
      (P_UNIQUE_REF_NO,
       P_CUSTOMER_NO,
       P_ACTION_CODE,
       P_CUST_CATEGORY,
       P_CURR_FULL_NAME_CHK,
       P_CURR_DATE_CHK,
       P_CURR_COUNTRY_CHK,
       P_CURR_BIRTH_COUNTRY,
       P_CURR_COUNTRY,
       P_CURR_NATIONALITY,
       P_CURR_P_COUNTRY,
       P_CURR_ECO_SECTOR,
       P_CURR_OCCUPATION,
       P_CURR_SECURITY_NO_1,
       P_CURR_SECURITY_NO_2,
       P_MODIFY_TIME,
       P_MOD_NO);
  
    COMMIT;
  
  END PR_INSERT_MODIFY_IND_CUST;

  PROCEDURE PR_DELETE_MODIFY_IND_CUST(P_CUSTOMER_NO IN VARCHAR2,
                                      P_MOD_NO      NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DELETE FROM STTB_MODIFY_IND_CUST
     WHERE CUSTOMER_NO = P_CUSTOMER_NO
       AND MOD_NO = P_MOD_NO;
    COMMIT;
  END PR_DELETE_MODIFY_IND_CUST;

  PROCEDURE PR_DELETE_MODIFY_CORP_CUST(P_CUSTOMER_NO IN VARCHAR2,
                                       P_MOD_NO      NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DELETE FROM STTB_MODIFY_CORP_CUST
     WHERE CUSTOMER_NO = P_CUSTOMER_NO
       AND MOD_NO = P_MOD_NO;
    COMMIT;
  END PR_DELETE_MODIFY_CORP_CUST;

  PROCEDURE PR_INSERT_MODIFY_CORP_CUST(P_UNIQUE_REF_NO      IN VARCHAR2,
                                       P_CUSTOMER_NO        IN VARCHAR2,
                                       P_ACTION_CODE        IN VARCHAR2,
                                       P_CUST_CATEGORY      VARCHAR2,
                                       P_CURR_FULL_NAME_CHK VARCHAR2,
                                       P_CURR_DATE_CHK      VARCHAR2,
                                       P_CURR_COUNTRY_CHK   VARCHAR2,
                                       P_COMPLEX_STRUCT     VARCHAR2,
                                       P_COUNTRY            VARCHAR2,
                                       P_R_COUNTRY          VARCHAR2,
                                       P_INCORP_COUNTRY     VARCHAR2,
                                       P_ECO_SECTOR         VARCHAR2,
                                       P_OCCUPATION         VARCHAR2,
                                       P_MODIFY_TIME        DATE,
                                       P_MOD_NO             NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    INSERT INTO STTB_MODIFY_CORP_CUST
    VALUES
      (P_UNIQUE_REF_NO,
       P_CUSTOMER_NO,
       P_ACTION_CODE,
       P_CUST_CATEGORY,
       P_CURR_FULL_NAME_CHK,
       P_CURR_DATE_CHK,
       P_CURR_COUNTRY_CHK,
       P_COMPLEX_STRUCT,
       P_COUNTRY,
       P_R_COUNTRY,
       P_INCORP_COUNTRY,
       P_ECO_SECTOR,
       P_OCCUPATION,
       P_MODIFY_TIME,
       P_MOD_NO);
  
    COMMIT;
  
  END PR_INSERT_MODIFY_CORP_CUST;

  PROCEDURE PR_INSERT_CORAL_WS_LOG(P_UNIQUE_REF_NO IN VARCHAR2,
                                   P_CUST_NO       IN VARCHAR2,
                                   P_DATE          IN DATE,
                                   P_REQ_TYPE      IN VARCHAR2,
                                   P_ACTION_CODE   IN VARCHAR2,
                                   P_REQ_MSG       IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('WHO CALLED ME=' || DBMS_UTILITY.format_call_stack);
    INSERT INTO STTB_CORAL_WS_LOG
      (UNIQUE_REFERENCE_NO,
       CUSTOMER_NO,
       INVOKE_DATE,
       REQ_TYPE,
       REQ_MSG,
       ACTION)
    VALUES
      (P_UNIQUE_REF_NO,
       P_CUST_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ACTION_CODE);
  
    COMMIT;
  
  END PR_INSERT_CORAL_WS_LOG;
  
  --Delete CIF from coral table to avoid passing old scan id to AML Starts
  PROCEDURE PR_DELETE_CORAL_WS_LOG_OVD(P_CUST_NO IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    
    DBG('INSIDE PR_DELETE_CORAL_WS_LOG_OVD');
  
    DELETE FROM STTB_CORAL_WS_LOG
    
     WHERE CUSTOMER_NO = P_CUST_NO;
  
    COMMIT;
  
  EXCEPTION
  WHEN OTHERS THEN
    DBG('FAILED IN PR_DELETE_CORAL_WS_LOG_OVD');
    DBG('ERROR CODE='||SQLCODE);
    DBG('ERROR MESSAGE='||SQLERRM);
  
  END PR_DELETE_CORAL_WS_LOG_OVD;
  --Delete CIF from coral table to avoid passing old scan id to AML Ends

  PROCEDURE PR_DELETE_CORAL_WS_LOG(P_REFERENCE_NO IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('WHO CALLED ME=' || DBMS_UTILITY.format_call_stack);
  
    DELETE FROM STTB_CORAL_WS_LOG
    
     WHERE UNIQUE_REFERENCE_NO = P_REFERENCE_NO;
  
    COMMIT;
  
  END PR_DELETE_CORAL_WS_LOG;

  PROCEDURE PR_INSERT_CORAL_DATA(L_RTN_SCAN_ID   IN VARCHAR2,
                                 L_RETURN_STATUS IN VARCHAR2,
                                 L_FULL_NAME_CHK IN VARCHAR2,
                                 L_DATE_CHK      IN DATE,
                                 L_COUNTRY_CHK   IN VARCHAR2,
                                 L_DATE          IN DATE,
                                 L_STAT          IN VARCHAR2,
                                 L_BRN           IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    BEGIN
    
      DBG('L_RETURN_STATUS=' || L_RETURN_STATUS);
      DBG('BEFORE INSERTING INTO STTM_CORAL_DATA_CUSTOM');
      INSERT INTO STTM_CORAL_DATA_CUSTOM
        (SCAN_ID,
         HIT_TYPE,
         FULL_NAME,
         DATEOFBIRTH,
         COUNTRY,
         MAKER_DT,
         STATUS,
         BRANCH_CODE)
      VALUES
        (L_RTN_SCAN_ID,
         L_RETURN_STATUS,
         L_FULL_NAME_CHK,
         L_DATE_CHK,
         L_COUNTRY_CHK,
         L_DATE,
         L_STAT,
         L_BRN);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        DBG('DUP_VAL_ON_INDEX ERROR');
        /* UPDATE STTMS_CORAL_DATA_CUSTOM
          SET HIT_TYPE = L_RETURN_STATUS, SCAN_ID = L_RTN_SCAN_ID
        WHERE FULL_NAME = TRIM(p_stdcif.V_STTMS_CUSTOMER.FULL_NAME)
          AND DATEOFBIRTH = TO_DATE(p_stdcif.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                    'DD/MM/RRRR')
          AND COUNTRY = L_COUNTRY_CHK
          AND MAKER_DT = GLOBAL.APPLICATION_DATE
          AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;*/
    END;
    COMMIT;
  
    DBG('ROW COUNT=' || SQL%ROWCOUNT);
  END PR_INSERT_CORAL_DATA;

  PROCEDURE PR_UPDATE_CORAL_WS_LOG(P_REFERENCE_NO IN VARCHAR2,
                                   P_SCAN_ID      IN VARCHAR2,
                                   P_STATUS       IN CHAR,
                                   P_RISK_LEVEL   IN CHAR,
                                   P_HIT_VALUE    IN VARCHAR2, --added for temp fix
                                   P_RES_MSG      IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('P_REFERENCE_NO=' || P_REFERENCE_NO);
    UPDATE STTB_CORAL_WS_LOG
       SET SCAN_ID    = P_SCAN_ID,
           RISK_LEVEL = P_RISK_LEVEL,
           HIT_VALUE  = P_HIT_VALUE,
           STATUS     = P_STATUS,
           RES_MSG    = P_RES_MSG
     WHERE UNIQUE_REFERENCE_NO = P_REFERENCE_NO;
  
    COMMIT;
  
  END PR_UPDATE_CORAL_WS_LOG;

  PROCEDURE PR_UPDATE_CORAL_WS_LOG(P_REFERENCE_NO IN VARCHAR2,
                                   P_SCAN_ID      IN VARCHAR2,
                                   P_STATUS       IN CHAR,
                                   P_RES_MSG      IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('P_REFERENCE_NO=' || P_REFERENCE_NO);
    UPDATE STTB_CORAL_WS_LOG
       SET SCAN_ID = P_SCAN_ID, STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE UNIQUE_REFERENCE_NO = P_REFERENCE_NO;
  
    COMMIT;
  
  END PR_UPDATE_CORAL_WS_LOG;

END STPKS_CORAL_WS_LOG;
/