ACCEPT POS PROMPT 'Enter the position reference no ==> '
SET array 1
SET head on
SET trimspool on
SET lines 10000
SET pagesize 50000
SET numformat 9999999999999.99999
SET colsep ';'
SET feedback on

Col WALKIN_NAME NoPrint 
Col WALKIN_ADDRESS_LINE1 NoPrint
Col WALKIN_ADDRESS_LINE2 NoPrint
Col WALKIN_ADDRESS_LINE3 NoPrint
Col WALKIN_ADDRESS_LINE4 NoPrint

SPOOL SE_position_data.SPL

PROMPT setm_security_master
SELECT *
  FROM setm_security_master
 WHERE internal_sec_id IN (SELECT security_id
                             FROM setb_position_ref
                            WHERE position_ref_no = '&POS');
PROMPT   setbs_int_component
SELECT *
  FROM setbs_int_component
 WHERE internal_sec_id IN (SELECT security_id
                             FROM setb_position_ref
                            WHERE position_ref_no = '&POS');
PROMPT  setm_portfolio_master
SELECT *
  FROM setm_portfolio_master
 WHERE portfolio_id IN (SELECT portfolio_id
                          FROM setb_position_ref
                         WHERE position_ref_no = '&POS');
PROMPT setb_deal_Master

SELECT   a.deal_reference_no, a.leg_reference_no, a.event_code, a.buy_sell,
         b.*
    FROM setb_deal_detail a, setb_deal_master b
   WHERE a.deal_reference_no = b.deal_reference AND a.position_ref_no = '&POS'
ORDER BY dstl_date, deal_reference_no, b.VERSION;

PROMPT  setb_deal_Master

SELECT   b.*
    FROM setb_deal_detail a, setb_deal_master b
   WHERE a.deal_reference_no = b.deal_reference AND a.position_ref_no = '&POS'
ORDER BY dstl_date, deal_reference_no, b.VERSION;


PROMPT  setb_deal_detail

SELECT   a.*
    FROM setb_deal_detail a, setb_deal_master b
   WHERE a.deal_reference_no = b.deal_reference AND a.position_ref_no = '&POS'
ORDER BY dstl_date, deal_reference_no, a.VERSION;


PROMPT  setb_dstl_master

SELECT *
  FROM setb_dstl_master
 WHERE leg_reference_no IN (
          SELECT leg_reference_no
            FROM setb_deal_detail
           WHERE deal_reference_no IN (
                    SELECT deal_reference_no
                      FROM setb_deal_detail
                     WHERE leg_reference_no IN (
                                               SELECT event_reference
                                                 FROM setb_event_log
                                                WHERE rel_reference_no =
                                                                        '&POS'))
          UNION
          SELECT '&POS'
            FROM DUAL);

PROMPT Event log


PROMPT cstb_contract_event_log

SELECT   *
    FROM cstb_contract_event_log
   WHERE contract_ref_no IN (
            SELECT leg_reference_no
              FROM setb_deal_detail
             WHERE deal_reference_no IN (
                      SELECT deal_reference_no
                        FROM setb_deal_detail
                       WHERE leg_reference_no IN (
                                               SELECT event_reference
                                                 FROM setb_event_log
                                                WHERE rel_reference_no =
                                                                        '&POS'))
            UNION
            SELECT '&POS'
              FROM DUAL)
ORDER BY contract_ref_no, event_date, event_seq_no;


PROMPT setb_event_log

SELECT   *
    FROM setb_event_log
   WHERE event_reference IN (
            SELECT leg_reference_no
              FROM setb_deal_detail
             WHERE deal_reference_no IN (
                      SELECT deal_reference_no
                        FROM setb_deal_detail
                       WHERE leg_reference_no IN (
                                               SELECT event_reference
                                                 FROM setb_event_log
                                                WHERE rel_reference_no =
                                                                        '&POS'))
            UNION
            SELECT '&POS'
              FROM DUAL)
ORDER BY event_val_date, esn;


PROMPT setbs_txn_log
SELECT *
  FROM setbs_txn_log
 WHERE position_ref_no = '&POS';
PROMPT Matching
PROMPT ------------------

PROMPT SELL SETBS_MATCHED_DEAL

SELECT *
  FROM setbs_matched_deal
 WHERE sell_leg_reference IN (
          SELECT DISTINCT leg_reference_no
                     FROM setbs_dstl_master
                    WHERE leg_reference_no IN (
                             SELECT leg_reference_no
                               FROM setb_deal_detail
                              WHERE deal_reference_no IN (
                                       SELECT deal_reference_no
                                         FROM setb_deal_detail
                                        WHERE leg_reference_no IN (
                                                 SELECT event_reference
                                                   FROM setb_event_log
                                                  WHERE rel_reference_no =
                                                                        '&POS'))));


PROMPT BUY SETBS_MATCHED_DEAL

SELECT *
  FROM setbs_matched_deal
 WHERE buy_leg_reference IN (
          SELECT DISTINCT leg_reference_no
                     FROM setbs_dstl_master
                    WHERE leg_reference_no IN (
                             SELECT leg_reference_no
                               FROM setb_deal_detail
                              WHERE deal_reference_no IN (
                                       SELECT deal_reference_no
                                         FROM setb_deal_detail
                                        WHERE leg_reference_no IN (
                                                 SELECT event_reference
                                                   FROM setb_event_log
                                                  WHERE rel_reference_no =
                                                                        '&POS'))));

PROMPT SETBS_UNREL_UNMATCH

SELECT *
  FROM setbs_unrel_unmatch
 WHERE leg_reference_no IN (
          SELECT DISTINCT leg_reference_no
                     FROM setbs_dstl_master
                    WHERE leg_reference_no IN (
                             SELECT leg_reference_no
                               FROM setb_deal_detail
                              WHERE deal_reference_no IN (
                                       SELECT deal_reference_no
                                         FROM setb_deal_detail
                                        WHERE leg_reference_no IN (
                                                 SELECT event_reference
                                                   FROM setb_event_log
                                                  WHERE rel_reference_no =
                                                                        '&POS'))));


PROMPT  setb_pfolio_skacbalances

SELECT *
  FROM setb_pfolio_skacbalances
 WHERE position_ref_no = '&POS';

PROMPT setb_pfolio_bdated_skmovmnts

SELECT *
  FROM setb_pfolio_bdated_skmovmnts
 WHERE position_ref_no = '&POS';
PROMPT setb_pfolio_vdated_skmovmnts

PROMPT setb_pfolio_vdated_skmovmnts

SELECT *
  FROM setb_pfolio_vdated_skmovmnts
 WHERE position_ref_no = '&POS';

PROMPT setb_pfolio_bdated_skbalances

SELECT *
  FROM setb_pfolio_bdated_skbalances
 WHERE position_ref_no = '&POS';

PROMPT setb_pfolio_vdated_skbalances

SELECT *
  FROM setb_pfolio_vdated_skbalances
 WHERE position_ref_no = '&POS';
PROMPT  int info
PROMPT ------------------
PROMPT   setb_int_qty_mov
SELECT *
  FROM setb_int_qty_mov
 WHERE portfolio_id IN (SELECT portfolio_id
                          FROM setb_position_ref
                         WHERE position_ref_no = '&POS')
   AND internal_security_id IN (SELECT security_id
                                  FROM setb_position_ref
                                 WHERE position_ref_no = '&POS');
PROMPT   setb_int_pur_sld
SELECT *
  FROM setb_int_pur_sld
 WHERE portfolio_id IN (SELECT portfolio_id
                          FROM setb_position_ref
                         WHERE position_ref_no = '&POS')
   AND internal_security_id IN (SELECT security_id
                                  FROM setb_position_ref
                                 WHERE position_ref_no = '&POS');
PROMPT  SETBS_INT_ACCR
SELECT *
  FROM setbs_int_accr
 WHERE position_ref_no = '&POS';

PROMPT  dprp info
PROMPT ------------------
PROMPT  setb_dprp_accr_master

SELECT *
  FROM setb_dprp_accr_master
 WHERE position_ref_no = '&POS';

PROMPT  setb_dprp_accr_calc
SELECT *
  FROM setb_dprp_accr_calc
 WHERE position_ref_no = '&POS';

PROMPT  setb_bep
SELECT *
  FROM setb_bep
 WHERE position_ref_no = '&POS';

PROMPT  cstbs_contract_exception

SELECT *
  FROM cstbs_contract_exception
 WHERE contract_ref_no IN (
          SELECT leg_reference_no
            FROM setb_deal_detail
           WHERE deal_reference_no IN (
                    SELECT deal_reference_no
                      FROM setb_deal_detail
                     WHERE leg_reference_no IN (
                                               SELECT event_reference
                                                 FROM setb_event_log
                                                WHERE rel_reference_no =
                                                                        '&POS'))
          UNION
          SELECT '&POS'
            FROM DUAL);

PROMPT  acvws_all_ac_entries	POS


SELECT *
  FROM acvws_all_ac_entries
 WHERE trn_ref_no = '&POS';
 
PROMPT  CSTBS_CONTRACT
SELECT   *
    FROM cstbs_contract
   WHERE contract_ref_no IN (
            SELECT leg_reference_no
              FROM setb_deal_detail
             WHERE deal_reference_no IN (
                      SELECT deal_reference_no
                        FROM setb_deal_detail
                       WHERE leg_reference_no IN (
                                               SELECT event_reference
                                                 FROM setb_event_log
                                                WHERE rel_reference_no =
                                                                        '&POS'))
            UNION
            SELECT '&POS'
              FROM DUAL)
ORDER BY contract_ref_no;

Prompt getting skref details

select * from SETB_POSITION_SK_REF where POSITION_REF_NO = '&POS';

Prompt getting sevw details

select * from SEvw_pfolio_skacbalances where POSITION_REF_NO = '&POS';

Prompt Getting Amount Due for zpsk ref no

select * from cstb_amount_due where contract_ref_no = (select POSITION_SK_REF_NO from SETB_POSITION_SK_REF 
									where POSITION_REF_NO = '&POS');

Prompt Getting Corp Action Details from setbs_branch_corporate_action

select * from setbs_branch_corporate_action 
where INTERNAL_SECURITY_ID = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) ;

Prompt getting sk loc details

select * from setms_sk_location where SK_LOCATION_ID in (select SK_LOCATION_ID from SEvw_pfolio_skacbalances
where POSITION_REF_NO  = '&POS');

Prompt getting corp actions due
select * from SETM_CORP_ACTIONS_DUE 
where BRANCH_CODE = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
and security_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) ;

Prompt getting coupon due
select * from sevw_coupon_due 
where BRANCH_CODE = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
and security_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) ;

Prompt getting SEVW_BONUS_DUE
select * from SEVW_BONUS_DUE 
where BRANCH_CODE = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
and security_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) ;

Prompt getting SEVW_DIVIDEND_DUE
select * from SEVW_DIVIDEND_DUE 
where BRANCH_CODE = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
and security_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) ;

Prompt getting SEVW_REDEMPTION_DUE
select * from SEVW_REDEMPTION_DUE 
where BRANCH_CODE = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
and security_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) ;

Prompt getting SEVW_INTEREST_ACCR
select * from SEVW_INTEREST_ACCR 
where BRANCH_CODE = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
and INTERNAL_SEC_ID = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) ;

PROMPT ACCTING ENTRIES DEFN for PF product
SELECT * FROM cstms_product_event_acct_entry
WHERE product_code = (SELECT PORTFOLIO_PRODUCT_CODE FROM setm_portfolio_master
WHERE portfolio_id IN (SELECT portfolio_id
                       FROM setb_position_ref
                       WHERE position_ref_no = '&POS'));

Prompt getting Corp Action exception log SETB_CAEVENT_EXCEPTION

select * from SETB_CAEVENT_EXCEPTION 
where BRANCH = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
and internal_security_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) ;


Prompt special for accrual problems
Prompt ==================================================================================================

PROMPT SETB_DSTL_MASTER
SELECT	*
FROM		SETB_DSTL_MASTER
WHERE		SECURITY_ID	=	(select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' )
AND		PORTFOLIO_ID = 	(select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/

PROMPT POSITIONS_TO_BE_ACCRUED
SELECT	b.internal_sec_id				internal_security_id,
		b.quantity_quotation_method		quantity_quotation,
		b.security_ccy					security_ccy,
		a.position_ref_no				position_ref_no
FROM	setbs_position_ref a,
	setms_security_master b
WHERE	a.branch_code = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
AND		a.portfolio_id = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
AND		a.security_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
AND		b.internal_sec_id = a.security_id
AND		(b.record_stat = 'O' AND b.auth_stat = 'A')
AND		b.security_type = 'B'
ORDER BY	a.security_id
/

PROMPT PREV_ACCRUAL_TO_DATE
SELECT 	*
FROM	setbs_position_int_accr a
WHERE	a.branch = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
AND a.portfolio_id = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
AND	a.internal_security_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/

PROMPT	PREV_COUPON_DETAILS
SELECT	a.prev_coupon_date,
		a.next_coupon_date,
		a.coupon_period_type,
		a.virtual_prev_coupon_date_1,
		a.virtual_prev_coupon_date_2,
		a.virtual_next_coupon_date_1,
		a.virtual_next_coupon_date_2,
		a.record_date
FROM	setbs_branch_interest a
WHERE	a.branch = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
AND	a.internal_sec_id = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' )
/

PROMPT SETB_PERIOD_INT_ACCR
SELECT	*
FROM		SETB_PERIOD_INT_ACCR
WHERE		BRANCH	=	(select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and 		portfolio_id = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )
AND		INTERNAL_SECURITY_ID	=	(select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/

PROMPT INT_QTY_MOV
SELECT	*
FROM		SETB_INT_QTY_MOV
WHERE		branch			=	(select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and		portfolio_id		=	(select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )
and		INTERNAL_SECURITY_ID	=	(select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/


PROMPT	INT_ACCR
SELECT	* 
FROM 		SETB_INT_ACCR
WHERE		branch			=	(select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
and		portfolio_id		=	(select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )
and		INTERNAL_SECURITY_ID	=	(select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
ORDER BY	VALUE_DATE
/

PROMPT	SETB_DPRP_ACCR_MASTER
SELECT * FROM SETB_DPRP_ACCR_MASTER
where PORTFOLIO_ID   =(select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )
AND SECURITY_ID   =(select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/

PROMPT 	SETB_DPRP_ACCR_CALC
SELECT * FROM SETB_DPRP_ACCR_CALC
where PORTFOLIO_ID   =(select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' )
AND SECURITY_ID   =(select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/

PROMPT 	CSTM_PRODUCT_EVENT_ACCT_ENTRY
SELECT * FROM CSTM_PRODUCT_EVENT_ACCT_ENTRY
WHERE 	PRODUCT_CODE 	= 	( SELECT PORTFOLIO_PRODUCT_CODE FROM SETM_PORTFOLIO_MASTER
								WHERE PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) )
AND 		EVENT_CODE IN ( 'SPLP','SSLP', 'ACRP' )
ORDER BY EVENT_CODE
/

PROMPT 	CSTM_PRODUCT_ACCROLE
SELECT * FROM CSTM_PRODUCT_ACCROLE
WHERE 	PRODUCT_CODE 	= 	( SELECT PORTFOLIO_PRODUCT_CODE FROM SETM_PORTFOLIO_MASTER
								WHERE PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) )
ORDER BY 	ACCOUNTING_ROLE
/


PROMPT ACVW_ALL_AC_ENTRIES
SELECT	*
FROM 		ACVW_ALL_AC_ENTRIES
WHERE		TRN_REF_NO	=	(SELECT POSITION_REF_NO FROM SETB_POSITION_REF WHERE BRANCH_CODE = (select branch_code FROM setb_position_ref WHERE position_ref_no = '&POS' )  
						AND SECURITY_ID = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  
						AND PORTFOLIO_ID = (select portfolio_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) )
AND		EVENT		IN	( 'IACR', 'ACRD' )
ORDER BY	EVENT_SR_NO,
		VALUE_DT
/

PROMPT SETB_INTEREST_RATE
SELECT * FROM SETB_INTEREST_RATE
WHERE INTERNAL_SEC_ID = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/

PROMPT SETB_BRANCH_INTEREST
SELECT * FROM SETB_BRANCH_INTEREST
WHERE INTERNAL_SEC_ID = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/

PROMPT SETB_INT_COMPONENT
SELECT * FROM SETB_INT_COMPONENT
WHERE INTERNAL_SEC_ID = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' ) 
/

PROMPT CFTB_INTEREST_ASSOC
SELECT * FROM CFTB_INTEREST_ASSOC 
WHERE CONTRACT_REF_NO = ( SELECT SECURITY_REF_NO FROM SETM_SECURITY_MASTER WHERE INTERNAL_SEC_ID = (select security_id FROM setb_position_ref WHERE position_ref_no = '&POS' )  )
/

PROMPT ROLE TO HEAD MAPPING for SP Module
SELECT * FROM CSTM_ROLE_TO_HEAD_CLASS where module = 'SP';

PROMPT ROLE TO HEAD MAPPING for SD Module
SELECT * FROM CSTM_ROLE_TO_HEAD_CLASS where module = 'SD';

SET echo off
SPOOL off