accept int_sec_id PROMPT 'Enter the INTERNAL SECURITY_ID ==> '
set array 1
set head on
set feedback on
set line 32267
set pagesize 10000
set echo on
set colsep ";"
set trimspool on
set numformat 99999999999999999999.9999

SPOOL SE_internalID_setup.SPL

Prompt SETMS_SECURITY_MASTER
select * from SETMS_SECURITY_MASTER where INTERNAL_SEC_ID=upper('&int_sec_id');

Prompt SETMS_COUPON
select * from SETMS_COUPON where INTERNAL_SECURITY_ID=upper('&int_sec_id');

Prompt SETMS_COUPON_PERIOD
select * from SETMS_COUPON_PERIOD WHERE INTERNAL_SEC_ID=upper('&int_sec_id');

Prompt SETMS_COUPON_SCHED
select * from SETMS_COUPON_SCHED where  INTERNAL_SEC_ID=upper('&int_sec_id');

Prompt SETMS_REVISION_SCHED
select * from SETMS_REVISION_SCHED where  INTERNAL_SEC_ID=upper('&int_sec_id');

Prompt SETMS_REVISION_DATE_MASTER
select * from SETMS_REVISION_DATE_MASTER where  INTERNAL_SEC_ID=upper('&int_sec_id');

Prompt SETMS_REDEMPTION
select * from SETMS_REDEMPTION  where  INTERNAL_SEC_ID=upper('&int_sec_id');

Prompt sevws_redemption_due
select * from sevws_redemption_due where SECURITY_ID = upper('&int_sec_id');

Prompt SETMS_INTEREST
select * from SETMS_INTEREST where INTERNAL_SEC_ID=upper('&int_sec_id');

PROMPT SETB_INTEREST_RATE
SELECT * FROM SETB_INTEREST_RATE
WHERE INTERNAL_SEC_ID = upper('&int_sec_id')
/

PROMPT SETB_BRANCH_INTEREST
SELECT * FROM SETB_BRANCH_INTEREST
WHERE INTERNAL_SEC_ID = upper('&int_sec_id')
/

PROMPT SETB_INT_COMPONENT
SELECT * FROM SETB_INT_COMPONENT
WHERE INTERNAL_SEC_ID = upper('&int_sec_id')
/

PROMPT CFTB_INTEREST_ASSOC
SELECT * FROM CFTB_INTEREST_ASSOC 
WHERE CONTRACT_REF_NO = ( SELECT SECURITY_REF_NO FROM SETM_SECURITY_MASTER WHERE INTERNAL_SEC_ID = upper('&int_sec_id') )
/

Prompt SETMS_INTEREST_REVISION
select * from SETMS_INTEREST_REVISION where INTERNAL_SECURITY_ID=upper('&int_sec_id');

Prompt SETM_INTEREST_REVISION_HISTORY
select * from SETM_INTEREST_REVISION_HISTORY where INT_SECURITY_ID =upper('&int_sec_id');

Prompt setbs_security_face_value
select * from setbs_security_face_value where internal_sec_id	=upper('&int_sec_id');


Select  	se.PRODUCT Product,
		pos.POSITION_REF_NO Ref, SE.ISSUER_ID Cust,
		se.RECORD_STAT Status, se.SECURITY_CCY Ccy, se.REDEMPTION_OR_EXPIRY_DATE MATURITY_DATE,
		pos.branch_code branch, se.SECURITY_TYPE Product_type, cs.LIABILITY_NO Liab,
		DIRECT_EXPOSURE_LINE Line,0 Balance,'ISSUER EXPOSURE' Amount_tag
from  setms_security_master se,
		  setbs_position_ref pos, sttms_customer cs
Where se.INTERNAL_SEC_ID = pos.security_id
and 	se.INTERNAL_SEC_ID = upper('&int_sec_id')
And	se.issuer_id = cs.customer_no;

Prompt SETB_CAEVENT_EXCEPTION
select * from SETB_CAEVENT_EXCEPTION where internal_security_id = upper('&int_sec_id');

Prompt CSTB_CONTRACT_EXCEPTION

select * from CSTB_CONTRACT_EXCEPTION where MODULE in ('SD','SP') and CONTRACT_REF_NO in ( select SECURITY_REF_NO from SETM_SECURITY_MASTER where internal_sec_id = upper('&int_sec_id') );

Prompt Getting SK acct
select * from SETM_SK_ACCOUNT         ;

Prompt Getting SK Loc
select * from SETM_SK_LOCATION        ;

Prompt Getting Settlements
select * from istm_instr  where module = 'SP' and record_stat = 'O' and auth_stat = 'A';

SPOOL OFF