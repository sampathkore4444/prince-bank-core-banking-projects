accept PRC PROMPT 'Enter the product code ==> '
set linesize 10000
set array 1
set head on
set pagesize 10000
set long 10000
set trimspool on

SPOOL LC_product_setup.SPL

prompt LCTMS_PRODUCT_DEFINITION
select * from LCTMS_PRODUCT_DEFINITION where product_code = UPPER('&PRC');

prompt CSTM_PRODUCT
select * from CSTM_PRODUCT where product_code = UPPER('&PRC');

prompt CFTMS_PRODUCT_ICCF
select * from CFTMS_PRODUCT_ICCF where product = UPPER('&PRC');

prompt CFTMS_PRODUCT_CURRENCY_LIMITS
select * from CFTMS_PRODUCT_CURRENCY_LIMITS where product = UPPER('&PRC');

prompt LCTMS_PRODUCT_DOCUMENTS
select * from LCTMS_PRODUCT_DOCUMENTS where product_code = UPPER('&PRC');

prompt LCTMS_PRODUCT_DOC_CLAUSE
select * from LCTMS_PRODUCT_DOC_CLAUSE where product_code = UPPER('&PRC');

prompt LCTMS_PRODUCT_FFT
select * from LCTMS_PRODUCT_FFT where product_code = UPPER('&PRC');

prompt LCTMS_PRODUCT_TRACERS
select * from LCTMS_PRODUCT_TRACERS where product_code = UPPER('&PRC');

prompt TATMS_PRODUCT_TAX
select * from TATMS_PRODUCT_TAX where product = UPPER('&PRC');

prompt CSTM_PRODUCT_EVENT_ACCT_ENTRY
select * from CSTM_PRODUCT_EVENT_ACCT_ENTRY where product_code = UPPER('&PRC')
ORDER BY EVENT_CODE;

prompt CSTM_PRODUCT_EVENT_ADVICE
select * from CSTM_PRODUCT_EVENT_ADVICE where product_code = UPPER('&PRC')
ORDER BY EVENT_CODE;

prompt CSTMS_PRODUCT_ACCROLE
select * from CSTMS_PRODUCT_ACCROLE where product_code = UPPER('&PRC');

prompt CSTMS_PRODUCT_CLASS_LINK
select * from CSTMS_PRODUCT_CLASS_LINK where product = UPPER('&PRC');

prompt CSTMS_PRODUCT_UDF_FIELDS_MAP
select * from CSTMS_PRODUCT_UDF_FIELDS_MAP where product_code = UPPER('&PRC');

prompt CSTM_PRODUCT_USERDEF_FIELDS
select * from CSTM_PRODUCT_USERDEF_FIELDS where product_code = UPPER('&PRC');

prompt MITMS_PRODUCT_DEFAULT
select * from MITMS_PRODUCT_DEFAULT  where product_code = UPPER('&PRC');

rem added iccf details here
PROMPT CFTMS_PRODUCT_CHARGE
SELECT * FROM CFTMS_PRODUCT_CHARGE
WHERE product = UPPER('&PRC');

PROMPT CFTMS_RULE
SELECT * FROM CFTMS_RULE
WHERE rule IN ( SELECT default_rule from CFTMS_PRODUCT_CHARGE
WHERE product = UPPER('&PRC'));

PROMPT CFTMS_BRACKET
SELECT * FROM CFTMS_BRACKET
WHERE rule IN ( SELECT default_rule from CFTMS_PRODUCT_CHARGE
WHERE product = UPPER('&PRC'));

spool off
