accept Format prompt 'Enter the format name ==> '
accept MsgType prompt 'Enter the Msg Type ==> '
accept CUSTOMER_NO prompt 'Enter the Customer No ==> '
set head on
set array 1
set linesize 10000
set pagesize 50000
set long 1000000
set echo on
set trimspool on


COL ADDRESS1 NoPrint
COL ADDRESS2 noprint
COL ADDRESS3 noprint
COL ADDRESS4 noprint
COL DELIVERY_BY noprint
COL ORDERING_CUSTADD1 noprint
col ORDERING_CUSTADD2 noprint
col ORDERING_CUSTADD3 noprint
col cust_name noprint
col NAME noprint
col ORDERING_CUSTNAME noprint
col PRIMARY_ADDRESS noprint


SPOOL MS_format_setup.SPL

Prompt mstms_msg_format
select * from mstms_msg_format where msg_type = '&MsgType';

Prompt mstms_adv_format
select * from mstms_adv_format where format = '&Format';

Prompt mstm_adv_format_det
select * from mstms_adv_format_det where format = '&Format';

prompt mstm_msg_media
select * from mstms_msg_media where msg_type = '&MsgType';

Prompt cust_address
select * from mstms_cust_address
where customer_no='&CUSTOMER_NO';

Prompt msg_address
select * from mstms_msg_address
where customer_no='&CUSTOMER_NO';

spool off