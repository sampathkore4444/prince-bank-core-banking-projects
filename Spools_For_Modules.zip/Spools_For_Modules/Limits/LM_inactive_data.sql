SET TRIMSPOOL ON
SET HEAD ON
SET PAGESIZE 10000
SPOOL LM_inactive_data.SPL

 
select s.cust_ac_no, s.line_id, l.availability_flag, l.record_stat
from sttm_cust_account s, lmtms_limits l, sttms_customer c
where s.cust_no = c.customer_no
and c.liability_no = l.liab_id
AND ltrim(rtrim(s.line_id)) = l.line_cd || to_char(l.line_serial)
and ( l.record_stat <> 'O'
	     or l.availability_flag <> 'Y'
	 )
/


SPOOL OFF
