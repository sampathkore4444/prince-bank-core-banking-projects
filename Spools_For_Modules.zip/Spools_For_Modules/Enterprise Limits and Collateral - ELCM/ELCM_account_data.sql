set serveroutput on size 1000000
set head on
set array 1
set linesize 10000
set pagesize 50000
set long 10000
set echo on
set trimspool on
set colsep ';'
set numformat 9999999999999999.999
Col Full_Name NoPrint
Col Short_name2 NoPrint
Col Ac_Desc NoPrint
Col ADDRESS1 noprint
Col ADDRESS2 noprint
Col ADDRESS3 noprint
Col ADDRESS4 noprint
Col ADDRESS_LINE1 NoPrint
Col ADDRESS_LINE2 NoPrint
Col ADDRESS_LINE3 NoPrint
Col ADDRESS_LINE4 NoPrint
Col AC_DESC noprint
Col AC_GL_DESC noprint
Col CUST_NAME1 noprint
Col CUST_NAME NoPrint
Col CUSTOMER_NAME NoPrint
Col CUSTNAME NoPrint
Col SHORT_NAME NoPrint
Col UNIQUE_ID_VALUE noprint
column PASSPORT_NO noprint
accept LIAB_NO PROMPT 'Enter Liability number ==>'
accept ACC PROMPT 'Pls enter the account no. ==> '
define lv_ttstamp=date
column ttstamp new_value lv_ttstamp noprint
select to_char(sysdate,'RRRRMMDDHH24MISS') as ttstamp from dual;

SPOOL ELCM_account_data.SPL

show user;
exec dbms_session.set_nls('NLS_DATE_FORMAT','''DD/MM/RRRR HH24:MI:SS''');
exec dbms_session.set_nls('NLS_NUMERIC_CHARACTERS','''.,''');
Prompt 'ELCM INFORMATION'
PROMPT ****************GETM_LIAB**************
select ID , PROCESS_NO , LIAB_NO , LIAB_BRANCH , LIAB_CCY , UTIL_AMT , REVISION_DATE , CREDIT_RATING , OVERALL_SCORE , USER_DEFINE_STATUS , OVERALL_LIMIT , UNADVISED , NETTING_REQUIRED , CATEGORY , CONVERSION_DATE , RECORD_STAT , AUTH_STAT , MOD_NO , MAKER_ID , MAKER_DT_STAMP , CHECKER_ID ,
CHECKER_DT_STAMP , ONCE_AUTH , SOURCE , USER_REFNO , FX_CLEAN_RISK_LIMIT , SEC_CLEAN_RISK_LIMIT , SEC_PSTL_RISK_LIMIT , MAIN_LIAB_ID
from getm_liab where liab_no='&LIAB_NO' ;
PROMPT
PROMPT ***************GETM_LIAB_CUST***************
select ID , BRANCH_CODE , CUSTOMER_NO , LIAB_ID , RECORD_STAT , AUTH_STAT , MOD_NO , MAKER_ID , MAKER_DT_STAMP , CHECKER_ID , CHECKER_DT_STAMP , ONCE_AUTH , SOURCE , USER_REFNO , FX_CUST_CLEAN_RISK_LIMIT
FROM GETM_LIAB_CUST WHERE LIAB_ID = (SELECT ID FROM GETM_LIAB where liab_no='&LIAB_NO');
PROMPT
PROMPT ***************GETM_FACILITY****************
select ID , LIAB_ID , LINE_CODE , LINE_SERIAL , MAIN_LINE_ID , CCY_RESTRICTION , LINE_CURRENCY , REVOLVING_LINE , LINE_START_DATE , LINE_EXPIRY_DATE , LAST_NEW_UTIL_DATE , AVAILABILITY_FLAG , LIMIT_AMOUNT , COLLATERAL_CONTRIBUTION , UNCOLLECTED_FUNDS_LIMIT , REPORTING_AMOUNT , AVAILABLE_AMOUNT , DATE_OF_FIRST_OD , DATE_OF_LAST_OD , AMOUNT_UTILISED_TODAY , AMOUNT_REINSTATED_TODAY , UNCOLLECTED_AMOUNT , EXCESS_TENOR , UTILISATION , LIAB_BR , COLLATERAL_PCT , NETTING_REQUIRED , BRN , LMT_AMT_BASIS , UNADVISED , TRANSFER_AMOUNT , DSP_EFF_LINE_AMOUNT , FUNDED , BLOCK_AMOUNT , TANKED_UTIL , NETTING_AMOUNT , AVAILMENT_DATE , EXCEP_TXN_AMT , EXCEP_BREACH , USER_DEFINE_STATUS , CATEGORY , EXTERNAL_REFNO , PROCESS_NO , USER_REFNO , CONVERSION_DATE , RECORD_STAT , AUTH_STAT , MOD_NO , MAKER_ID , MAKER_DT_STAMP , CHECKER_ID , CHECKER_DT_STAMP , ONCE_AUTH , MATURED_UTIL , SOURCE , TENOR_REST_TYPE , CUSTOMER_REST_TYPE , PRODUCT_REST_TYPE , BRANCH_REST_TYPE , CCY_REST_TYPE , EXT_SYSTEM_REST_TYPE , DESCRIPTION , SHADOW_LIMIT , EXP_REST_TYPE , REVOLVING_AMT , APPROVED_AMT , SCHEDULE_PROCESS_DATE , DAY_LIGHT_LIMIT , USER_DEF_STAT_CHANGED_DT , DAY_LIGHT_ST_DT , DAY_LIGHT_ED_DT , DAYLIGHT_OD_LIMIT , COMMITMENT_PRODUCT , COMMITMENT_REF_NO , COMMITMENT_SETTL_BRN , COMMITMENT_SETTL_ACC , LENDING_CATEGORY_CODE , PRODUCT_TYPE , BULK_PMT_REQD , INTEREST_REQD , INTEREST_CALC_ACC , PPC_REF_NO , PPC_PROJECT_ID
from getm_facility where liab_id in (select id from getm_liab where liab_no='&LIAB_NO');
PROMPT
PROMPT ****************GETB_UTILS******************
SELECT * FROM GETB_UTILS WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB where liab_no='&LIAB_NO');
PROMPT
PROMPT ***************GETB_UTILS_LOG***************
select * from GETB_UTILS_LOG WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB where liab_no='&LIAB_NO');
PROMPT
PROMPT *****************geth_utils*****************
SELECT * FROM geth_utils WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB where liab_no='&LIAB_NO');
PROMPT
PROMPT *****************GETH_UTILS_LOG*****************
SELECT * FROM GETH_UTILS_LOG WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB where liab_no='&LIAB_NO');
SELECT * FROM GETM_FACILITY_BLOCK WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_BRN_REST WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_CCY_REST WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_CHARGE WHERE FACILITY_ID in(SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_COVENANT WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_CUST_REST WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_EXPOSURE WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_EXP_REST WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_OFF_LIMIT WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_PROD_REST WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_SCHEDULES WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_SYSTEM_REST WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_TENOR_REST WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_UDE_VALUES WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_VD_DETAILS WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETB_POOL_LINK WHERE FACILITY_ID in (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_POOL WHERE liab_id in (select id from getm_liab where liab_no='&LIAB_NO');
SELECT * FROM GETM_POOL_COLL_LINKAGES WHERE liab_id in (select id from getm_liab where liab_no='&LIAB_NO');
SELECT * FROM GETM_COLLAT WHERE liab_id in (select id from getm_liab where liab_no='&LIAB_NO');
SELECT * FROM ELTB_UTIL_TXN_LOG WHERE liab_id in (select id from getm_liab where liab_no='&LIAB_NO');
SELECT * FROM STTM_CUST_ACCOUNT_LINKAGES WHERE BRANCH_CODE IN (SELECT LIAB_BRANCH from getm_liab where liab_no='&LIAB_NO' );
SELECT * FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO');
SELECT * FROM GETM_FACILITY_BLOCK WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_BRN_REST WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_CCY_REST WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_CHARGE WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_COVENANT WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_CUST_REST WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_EXPOSURE WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_EXP_REST WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_OFF_LIMIT WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_PROD_REST WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_SCHEDULES WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_SYSTEM_REST WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_TENOR_REST WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_UDE_VALUES WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_FACILITY_VD_DETAILS WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETB_POOL_LINK WHERE FACILITY_ID = (SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_POOL WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO');
SELECT * FROM GETM_POOL_COLL_LINKAGES WHERE POOL_ID = (SELECT ID FROM GETM_POOL WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_COLLAT WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO');
SELECT * FROM GETM_COLLAT_CONT_CONTRIB WHERE COLL_ID = (SELECT ID FROM GETM_COLLAT WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_COLLAT_SHARE WHERE COLL_ID = (SELECT ID FROM GETM_COLLAT WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_COLL_COVENANT WHERE COLLATERAL_ID = (SELECT ID FROM GETM_COLLAT WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
SELECT * FROM GETM_COLL_INSURANCE WHERE COLLATERAL_ID = (SELECT ID FROM GETM_COLLAT WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB WHERE LIAB_NO='&LIAB_NO'));
Prompt 'ACCOUNT INFORMATION'
Prompt 'ACCOUNT CLASS DETAILS'
Prompt sttm_account_class
select * from sttm_account_class where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_account_class_status
Select * from sttm_account_class_status where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt cstm_accprod_status_gl
Select * from cstm_accprod_status_gl where accls_or_prod = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_accls_cat_restr
Select * from sttms_accls_cat_restr where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_accls_cus_restr
Select * from sttms_accls_cus_restr where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_accls_ccy_restr
Select * from sttms_accls_ccy_restr where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_accls_ccy_balances
Select * from sttms_accls_ccy_balances where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_amtblk_order
Select * from sttm_aclass_amtblk_order where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_ac_stat_drv
Select * from sttm_ac_stat_drv where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_aclass_products
Select * from sttms_aclass_products where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_txncode
Select * from sttm_aclass_txncode where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_interim_dr_amt
Select * from sttm_aclass_interim_dr_amt where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_interim_cr_amt
Select * from sttm_aclass_interim_cr_amt where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_report_gen_time
Select * from sttm_aclass_report_gen_time where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
PROMPT 'ACCOUNT CLASS CHANGE'
select * from sttm_cusacc_aclass where cust_ac_no = '&Account'
Prompt 'CUSTOMER DETAILS'
Prompt sttm_customer
Select * from sttm_customer where customer_no = (select cust_no from sttm_cust_account where cust_ac_no = '&acc');
Prompt 'ACCOUNT DETAILS'
Prompt sttms_cust_account
Select * from sttms_cust_account where cust_ac_no = '&acc';
Prompt sttbs_account
Select * from sttbs_account where ac_gl_no = '&acc';
Prompt sttm_accstat_replines_detail
Select * from sttm_accstat_replines_detail where cust_ac_no = '&acc';
Prompt actbs_funcol
Select * from actbs_funcol where account ='&acc';
Prompt actbs_funcol_history
Select * from actbs_funcol_history where account ='&acc';
Prompt catms_amount_blocks
Select * from catms_amount_blocks where account ='&acc';
Prompt cstb_auto_settle_block
Select * from cstb_auto_settle_block where account_no ='&acc';
Prompt sttm_cust_account_linkages
Select * from sttm_cust_account_linkages where cust_ac_no = '&acc';
Prompt sttm_cust_account_dormancy
Select * from sttm_cust_account_dormancy where cust_ac_no = '&acc';
Prompt 'ACCOUNT BALANCES'
Prompt actbs_vd_bal
Select * from actbs_vd_bal where acc = '&acc';
Prompt actbs_accbal_history
Select * from actbs_accbal_history where account = '&acc';
Prompt actb_daily_log
Select * from actb_daily_log where ac_no = '&acc';
Prompt acvws_all_ac_entries
Select * from acvws_all_ac_entries where ac_no = '&acc';
Prompt Sum of acvws_all_ac_entries
Select sum(decode(drcr_ind,'D',-lcy_amount,lcy_amount)) from acvw_all_ac_entries where ac_no = '&acc';
Prompt 'ACCOUNT AUDIT DETAILS'
Prompt sttb_record_master
Select * from sttb_record_master where key_id like '~STTM_CUST_ACCOUNT~' || '%' || '~' || '&acc' || '~';
Prompt sttb_record_log
Select * from sttb_record_log where key_id like '~STTM_CUST_ACCOUNT~' || '%' || '~' || '&acc' || '~';
Prompt sttb_field_log
Select * from sttb_field_log where detail_key like '~STTM_CUST_ACCOUNT~' || '%' || '~' || '&acc' || '~';
Prompt sttm_account_balance
select * from sttm_account_balance where cust_ac_no = '&acc';
Prompt actb_entries_handoff
select * from actb_entries_handoff where ac_no = '&acc';
Prompt actb_entries_history
select * from actb_entries_history where ac_no = '&acc';
Prompt catb_entries
select * from catb_entries where ac_no = '&acc';
set termout on
set echo off
SPOOL OFF