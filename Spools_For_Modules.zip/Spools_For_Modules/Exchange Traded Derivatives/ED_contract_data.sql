PROMPT Basket related details.  
ACCEPT bref PROMPT 'Enter the basket reference no displayed above -> '

SET LINE 10000
SET PAGESIZE 50000
SET HEAD ON
SET ECHO ON
SET TRIMSPOOL ON
SPOOL ED_contract_data.spl

SELECT * FROM edtbs_long_short_deals 
WHERE Basket_Reference = UPPER('&bref')
ORDER BY deal_reference,version
/

SELECT * FROM edtbs_liqd_deals 
WHERE  Basket_Reference = UPPER('&bref')
ORDER BY deal_reference,version
/

SELECT * FROM cstbs_contract 
WHERE contract_ref_no = UPPER('&bref')
/

SELECT * FROM cstbs_contract_event_log WHERE contract_ref_no = UPPER('&bref')
ORDER BY event_seq_no
/

SELECT * FROM edtbs_deal_basket_esn_link WHERE Basket_Reference = UPPER('&bref')
ORDER BY deal_reference
/

SELECT * FROM edtbs_deal_matching WHERE Basket_Reference = UPPER('&bref')
/

SELECT * FROM edtbs_basket_reference WHERE basket_reference = UPPER('&bref')
/

SELECT i.* FROM edtms_instrument i, edtbs_basket_reference b
WHERE i.instrument_id = b.instrument_id
AND b.basket_reference = UPPER('&bref')
/

SELECT s.* FROM edtms_instrument_series s, edtbs_basket_reference b
WHERE s.series_id = b.series_id
AND b.basket_reference = UPPER('&bref')
/

SELECT p.* FROM edtms_instrument_product p, edtms_instrument i, edtbs_basket_reference b
WHERE p.instrument_product = i.instrument_product
AND i.instrument_id = b.instrument_id
AND b.basket_reference = UPPER('&bref')
/

SELECT c.* FROM edtms_commodity_definition c, edtms_instrument i, edtbs_basket_reference b
WHERE c.commodity = i.commodity
AND i.instrument_id = b.instrument_id
AND b.basket_reference = UPPER('&bref')
/

SELECT p.* FROM edtms_portfolio p, edtbs_basket_reference b
WHERE p.portfolio_id = b.portfolio_id
AND b.basket_reference = UPPER('&bref')
/

SELECT p.* FROM edtms_portfolio_broker_acc p, edtbs_basket_reference b
WHERE p.portfolio_id = b.portfolio_id
AND b.basket_reference = UPPER('&bref')
/

SELECT c.* FROM cstms_product_event_acct_entry c, edtms_portfolio p, edtbs_basket_reference b
WHERE c.product_code = p.portfolio_product
AND p.portfolio_id = b.portfolio_id
AND b.basket_reference = UPPER('&bref')
ORDER BY event_code
/

SELECT c.* FROM cstms_product_accrole c, edtms_portfolio p, edtbs_basket_reference b
WHERE c.product_code = p.portfolio_product
AND p.portfolio_id = b.portfolio_id
AND b.basket_reference = UPPER('&bref')
/

SELECT c.* FROM cstms_product_event_advice c, edtms_portfolio p, edtbs_basket_reference b
WHERE c.product_code = p.portfolio_product
AND p.portfolio_id = b.portfolio_id
AND b.basket_reference = UPPER('&bref')
/

SELECT r.* FROM edtms_role_to_head1 r, edtbs_basket_reference b
WHERE r.portfolio_id = b.portfolio_id
AND b.basket_reference = UPPER('&bref')
/

SELECT c.* FROM cstms_role_to_head_class c, edtms_role_to_head1 r, edtbs_basket_reference b
WHERE c.class_code = r.role_to_head_class
AND r.portfolio_id = b.portfolio_id
AND b.basket_reference = UPPER('&bref')
/

SELECT r.* FROM edtms_role_to_head2 r, edtms_instrument i, edtbs_basket_reference b
WHERE r.portfolio_id = b.portfolio_id
AND i.instrument_id = b.instrument_id
AND r.instrument_product = i.instrument_product
AND b.basket_reference = UPPER('&bref')
/

SELECT c.* FROM cstms_role_to_head_class c, edtms_role_to_head2 r, edtms_instrument i, edtbs_basket_reference b
WHERE c.class_code = r.role_to_head_class
AND r.portfolio_id = b.portfolio_id
AND i.instrument_id = b.instrument_id
AND r.instrument_product = i.instrument_product
AND b.basket_reference = UPPER('&bref')
/

SELECT r.* FROM edtms_role_to_head3 r, edtms_instrument i, edtbs_basket_reference b
WHERE r.portfolio_id = b.portfolio_id
AND i.instrument_id = b.instrument_id
AND b.basket_reference = UPPER('&bref')
/

SELECT c.* FROM cstms_role_to_head_class c, edtms_role_to_head3 r, edtms_instrument i, edtbs_basket_reference b
WHERE c.class_code = r.role_to_head_class
AND r.portfolio_id = b.portfolio_id
AND i.instrument_id = b.instrument_id
AND b.basket_reference = UPPER('&bref')
/

SELECT * FROM edtbs_balance  
WHERE basket_reference = UPPER('&bref')
ORDER BY portfolio_id, instrument_id, series_id, broker_cm_id, broker_account
/

SELECT * FROM edtbs_vd_bal
WHERE basket_reference = UPPER('&bref')
ORDER BY value_date
/

SELECT * FROM edtbs_basket_wac
WHERE basket_reference = UPPER('&bref')
/

SELECT * FROM edtbs_basket_wac_movements
WHERE basket_reference = UPPER('&bref')
ORDER BY movement_esn
/

SELECT * FROM edtbs_basket_reval
WHERE basket_reference = UPPER('&bref')
ORDER BY related_deal_reference
/

SELECT * FROM edtbs_reval_master
WHERE basket_reference = UPPER('&bref')
ORDER BY related_deal_reference, revaluation_sequence, revaluation_date
/

SELECT * FROM edtms_bank_parameters
/

SELECT * FROM edtb_branch_batch_status
WHERE branch = SUBSTR(UPPER('&bref'),1,3)
/

select * from edtb_basket_event_queue
where basket_reference = UPPER('&bref') 
/

select * from edtbs_deal_queue
WHERE basket_reference = UPPER('&bref')
ORDER BY deal_reference
/

SET ECHO OFF
SPOOL OFF
