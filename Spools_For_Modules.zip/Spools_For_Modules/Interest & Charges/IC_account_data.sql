--First Script
accept Branch  PROMPT 'Enter the Branch  >'
accept Account PROMPT 'Enter the Account >'
set array 1024
set head on
set feedback on
set line 32767
set pagesize 32767
set colsep ";"
set trimspool on
set verify off
set feedback on
set numformat 99999999999999999999D999
set termout off
set echo on

column SHORT_NAME noprint
column address1 noprint
column address2 noprint
column address3 noprint
column address4 noprint
column ADDR1 noprint
column ADDR2  noprint
column PASSPORT_NO  noprint
column address_line1 noprint
column address_line2 noprint
column address_line3 noprint
column address_line4 noprint
column SHORT_NAME2  noprint
column customer_name1 noprint 
column FULL_NAME noprint
column CUST_NAME1 noprint
column UNIQUE_ID_VALUE noprint
column BENEF_NAME  noprint
column BENFNAME   noprint
column AC_GL_DESC NoPrint
column SWIFT_CODE NoPrint
column AC_DESC NoPrint
column CHECKBOOK_NAME_1 NoPrint
column CHECKBOOK_NAME_2 NoPrint



define lv_ttstamp=date
column ttstamp new_value lv_ttstamp noprint
select to_char(sysdate,'RRRRMMDDHH24MISS') as ttstamp from dual;

column from_date new_value From_date
/
select to_char(today,'DD/MM/RRRR') FROM_DATE from sttm_dates where branch_code = '&branch'
/

column aclass new_value aclass
/
select account_class aclass from sttm_cust_account where branch_code = '&branch' and cust_ac_no='&account'
/

column currency new_value currency
/
select ccy currency from sttm_cust_account where branch_code = '&branch' and cust_ac_no='&account'
/

column customer_no new_value customer_no
/
select cust_no customer_no from sttm_cust_account where branch_code = '&branch' and cust_ac_no='&account'
/


SPOOL IC_account_data.SPL

show user;


Prompt Assign Process No
BEGIN
SELECT SEQ_NO INTO icpks_partition_info.g_this_part from CSTB_CUSTACSEQ where CUST_AC_NO = '&account'
AND ROWNUM = 1;
exception when others then
icpks_partition_info.g_this_part:=1;
END;
/

Prompt Dates
SELECT * FROM STTM_DATES WHERE BRANCH_CODE='&branch';

prompt ictms_product_definition
select * from ictms_product_definition
where product_code IN (select distinct prod from ictbs_acc_pr where brn ='&branch' and acc = '&account')
order by product_code
/

prompt ictbs_acc_pr
select * from ictbs_acc_pr where acc = '&Account'
/
prompt accpr history 
select * from ICTB_ACC_PR_HISTORY  where acc = '&Account'
/

prompt icvws_acc_pr
select * from icvws_acc_pr where acc = '&Account'
/

prompt entries
select * from ictbs_entries where acc = '&Account'
/

prompt entries history
select * from ictbs_entries_history 
where acc = '&Account' 
and to_date(ent_dt,'DD/MM/RRRR') > trunc(add_months(to_date('&From_date','DD/MM/RRRR'),-6),'MM')
order by ent_dt
/

prompt ictbs_adj_interest 
select * from ictbs_adj_interest where brn='&branch' and acc = '&account' 
/

prompt ictbs_adj_interest_history
select * from ictbs_adj_interest_history where brn='&branch' and acc = '&account' 
/


prompt is_vals
select * from ictbs_is_vals where acc = '&Account'
and to_date(frm_dt,'DD/MM/RRRR') > trunc(add_months(to_date('&From_date','DD/MM/RRRR'),-6),'MM')
/


prompt ictbs_book_err
select * from ictbs_book_err  where acc = '&Account'
/

prompt ictbs_calc_err
select * from ictbs_calc_err  where acc = '&Account'
/

prompt acvw_all_ac_entries
select * from acvws_all_ac_entries 
where ac_branch='&Branch'
and '&Account' in (ac_no,related_account)
and to_date(trn_dt,'DD/MM/RRRR') > trunc(add_months(to_date('&From_date','DD/MM/RRRR'),-6),'MM')
order by ac_entry_sr_no
/

prompt vd_bal
select * from actbs_vd_bal where brn= '&Branch'
and acc = '&Account'
order by val_dt
/

prompt udevals
select * from ictbs_udevals where cond_key like '%'||'&aclass' ||'%'
/

prompt ictbs_udevals
select * from ictbs_udevals 
where cond_key like '%&Account%' order by prod   ,ude_eff_dt
/

prompt ictbs_udevals_hist
select * from ictbs_udevals_history 
where cond_key like '%&Account%' order by prod,ude_eff_dt
/


prompt ictbs_udeval_row SC
select * from ictbs_udeval_row 
where cond_key  like '%&Account%'
order by prod, ude_eff_dt
/

prompt ictbs_udeval_row GC
select * from ictbs_udeval_row where cond_key like '%'||'&aclass' ||'%'
/

Prompt Ictb_itm_tov
select * from ictbs_itm_tov where acc ='&account'
/

prompt ictbs_back_dated_udevals
select * from ictbs_back_dated_udevals
where cond_key like '%'||'&aclass' ||'%'


select * from ictbs_back_dated_udevals
where cond_key like '%&account%'
/

prompt back valued events
select * from ictbs_back_dated_events
where acc like '&Account'
/

prompt cust_account
select * from sttms_cust_account where cust_ac_no = '&Account'
/

Prompt Dormancy Field
Select * From Sttm_Cust_Account_Dormancy Where Cust_Ac_No = '&account' 
/

prompt sttbs_account
select * from sttbs_account where ac_gl_no = '&Account'
/

Prompt Sttm_customer
SELECT * FROM STTMS_CUSTOMER WHERE CUSTOMER_NO = '&customer_no'
/


Prompt Account_Class
select * from sttm_account_class a WHERE a.account_class = (SELECT b.account_class FROM STTM_CUST_ACCOUNT b where cust_ac_no = '&account')
/

prompt ictms_acc
select * from ictms_acc where acc = '&Account'
/

prompt ictms_acc_pr
select * from ictms_acc_pr where acc = '&Account'
/

prompt ictms_acc_effdt
select * from ictms_acc_effdt where acc = '&Account'
/

prompt acc_udevals
select * from ictms_acc_udevals where acc = '&Account'
/

Prompt Debit Int Due
select * from ictb_dr_int_due where acc = '&Account'
/

Prompt Debit Int Paid
select * from ictb_dr_int_paid where acc = '&Account'
/

prompt ICTB_CHG_VAL
SELECT * FROM ICTB_CHG_VAL where acc ='&account'
/

prompt ICTB_CHG_VAL_HISTORY
SELECT * from ICTB_CHG_VAL_HISTORY where acc ='&Account'
/

prompt ictb_chg_due
select * from ictb_chg_due where acc = '&Account'
/


prompt ICTB_CHG_ERR
select * from ICTB_CHG_ERR where acc = '&account'
/

PROMPT ICtms_BRANCH_PARAMETERS
SELECT * FROM ictms_branch_parameters WHERE branch_CODE = '&Branch'
/

PROMPT cstms_product_event_acct_entry
SELECT * FROM CStms_PRODUCT_EVENT_ACCT_ENTRY 
WHERE product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
Union
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
) 
ORDER BY product_code,event_code, amt_tag, dr_cr_indicator
/

PROMPT CSTMS_PRODUCT_ACCROLE
SELECT * FROM CSTMS_PRODUCT_ACCROLE
WHERE product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
Union
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
) 
ORDER BY product_code
/

Prompt sttm_trn_code
select * from sttm_trn_code where trn_code in
(SELECT   transaction_code FROM cstms_product_event_acct_entry
WHERE product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass ='&aclass'
   and a.ccy =  '&currency'
   and a.record_stat <> 'C'
Union
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
))
/


Prompt 'IC transaction count'
select * from sttm_trn_code where ic_txn_count ='Y' or ic_tover_inclusion ='Y'
/

Prompt 'CSTMS_PRODUCT_STATUS_GL'
select * from CSTMS_PRODUCT_STATUS_GL where product in ( select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
Union
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
)
/

Prompt 'INTEREST PROD DETAILS'
prompt ictms_pr_int
select * from ictms_pr_int 
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
) 
order by product_code
/

prompt ictbs_pr_int_aclass
select * from ictms_pr_int_aclass 
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass ='&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
)
order by product_code
/


prompt pr_int_effdt
select * from ICTMS_PR_INT_EFFDT where product_code in ( select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&aclass'
   and a.ccy ='&currency'
   and a.record_stat <> 'C'
)
/


prompt ictms_pr_int_udevals
select * from ictms_pr_int_udevals where product_code in (select product_code
  from ictm_pr_int_aclass a
 where a.aclass =  '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
) 
/


Prompt 'CHARGE PROD DETAILS'

prompt ictms_pr_chg
select * from ictms_pr_chg where product_code  IN (
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
) 
/

Prompt ICTM_PR_CHG_ACLASS
select A.*
  from ictm_pr_chg_aclass a
 where a.aclass ='&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
order by product_code
/

prompt ICTM_PR_CHG_CONSOL
select * from ICTM_PR_CHG_CONSOL
where prod IN (
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
)
order by prod 
/

prompt ICTM_PR_CHG_SLAB
select * from ICTM_PR_CHG_SLAB
where product_code IN (
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
)
order by product_code
/
prompt ICTM_PR_CHG_TXN
select * from ICTM_PR_CHG_TXN
where prod IN (
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&aclass'
   and a.ccy ='&currency'
   and a.record_stat <> 'C'
)
order by prod
/

PROMPT 'ALL RULES LINKED TO THE ACCOUNT'


SELECT * FROM ictms_rule WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass =  '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C')
) 
/

SELECT * FROM ictms_rule_frm WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass =  '&aclass'
   and a.ccy ='&currency'
   and a.record_stat <> 'C') ) order by rule_id, frm_no
/

select * from ictm_expr where rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass =  '&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C')) order by rule_id, frm_no, expr_line
/


SELECT * FROM ictms_rule_frm_elements WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&aclass'
   and a.ccy =  '&currency'
   and a.record_stat <> 'C'))
/

SELECT * FROM ictms_rule_sde WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass ='&aclass'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'))
/

SELECT * FROM ictms_rule_ude WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&aclass'
   and a.ccy ='&currency'
   and a.record_stat <> 'C'))
/


PROMPT HOLIDAY

SELECT * FROM STTM_LCL_HOLIDAY WHERE BRANCH_CODE='&branch' AND YEAR = ( SELECT TO_CHAR(TODAY,'YYYY') 
FROM STTM_DATES WHERE BRANCH_CODE='&branch');

Prompt 'LIMITS/ELCM DETAILS'

prompt icvw_line_Det
select * from icvw_line_Det where brn ='&branch' and acc = '&account'
/

PROMPT GETM_FACILITY
SELECT * FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB, sttm_cust_account WHERE LIAB_NO=cust_no and cust_ac_no = '&account')
/

select * from GETM_FACILITY_VD_DETAILS where id in 
(SELECT ID FROM GETM_FACILITY WHERE LIAB_ID =(SELECT ID FROM GETM_LIAB, sttm_cust_account WHERE LIAB_NO=cust_no and cust_ac_no = '&account'))
/

select * from GETB_UTILS where LIAB_ID = (SELECT ID FROM GETM_LIAB, sttm_cust_account WHERE LIAB_NO=cust_no and cust_ac_no = '&account')
/

SELECT i.* FROM GETM_LIAB i, sttm_cust_account j WHERE i.LIAB_NO=j.cust_no and j.cust_ac_no = '&account'
/

prompt lmtb_lineacc_util 
select * from lmtb_lineacc_util where acc = '&account'
/
PROMPT STTM_AC_STAT_CHANGE 
select * from STTM_AC_STAT_CHANGE where branch_code='&branch' and cust_ac_no='&Account'
/

PROMPT CSTB_AUTO_SETTLE_BLOCK
select * from CSTB_AUTO_SETTLE_BLOCK where module='IC' and account_no='&account'
/

set echo off
set termout on
spool off

