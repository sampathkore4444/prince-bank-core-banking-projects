accept PROD PROMPT 'Enter the Product code ==> '
set head on
set array 1
set linesize 10000
set pagesize 50000
set long 10000
set echo on
set trimspool on
set colsep ';'

COL CUSTOMER_NAME NoPrint
COL payment_details noprint
COL clause_descr noprint
COL doc_descr noprint
COL doc_reference noprint
COL address1 noprint
col address2 noprint
col address3 noprint
col warehouse_address noprint
col cust_name noprint
col cust_address_lin1 noprint
col cust_address_lin2 noprint
col cust_address_lin3 noprint
col cust_address_lin4 noprint
col tracer_code noprint
Col ADDRESS4 NoPrint

SPOOL SI_product_setup.SPL

PROMPT SITM_PRODUCT_PRF
SELECT * FROM SITM_PRODUCT_PRF WHERE PRODUCT_CODE = '&PROD';

PROMPT CSTMS_PRODUCT
SELECT * FROM CSTMS_PRODUCT WHERE PRODUCT_CODE = '&PROD';

PROMPT CFTM_PRODUCT_ICCF
SELECT * FROM CFTM_PRODUCT_ICCF WHERE PRODUCT = '&PROD';


PROMPT CSTMS_PRODUCT_EVENT_ACCT_ENTRY
SELECT * FROM CSTMS_PRODUCT_EVENT_ACCT_ENTRY WHERE PRODUCT_CODE = '&PROD'
order by event_code,amt_tag,dr_cr_indicator;

PROMPT CSTMS_PRODUCT_EVENT_ADVICE
SELECT * FROM CSTMS_PRODUCT_EVENT_ADVICE WHERE PRODUCT_CODE = '&PROD'
ORDER BY PRODUCT_CODE, EVENT_CODE, MSG_TYPE ;


PROMPT CSTMS_PRODUCT_STATUS_ADVICES
SELECT * FROM CSTMS_PRODUCT_STATUS_ADVICES WHERE PRODUCT ='&PROD';

PROMPT CSTMS_PRODUCT_STATUS_COMPS
SELECT * FROM CSTMS_PRODUCT_STATUS_COMPS WHERE PRODUCT ='&PROD';

PROMPT CSTMS_PRODUCT_STATUS_MASTER
SELECT * FROM CSTMS_PRODUCT_STATUS_MASTER WHERE PRODUCT ='&PROD';

PROMPT CSTMS_PRODUCT_STATUS_GL
SELECT * FROM CSTMS_PRODUCT_STATUS_GL WHERE PRODUCT ='&PROD'; 

PROMPT cstms_product_accrole
SELECT * FROM cstms_product_accrole WHERE product_code = UPPER('&PROD')
ORDER BY PRODUCT_CODE, ACCOUNTING_ROLE, STATUS ;

PROMPT cstms_product_accrole
SELECT * FROM cftms_product_iccf WHERE product = UPPER('&PROD');

PROMPT tatms_product_tax
SELECT * FROM tatms_product_tax WHERE product = '&PROD';

PROMPT TATMS_SCHEME_DETAIL
SELECT * FROM TATMS_SCHEME_DETAIL;

PROMPT tatm_rule
SELECT * FROM tatm_rule;

PROMPT tatm_slab
SELECT * FROM tatm_slab;

Prompt CFTM_PRODUCT_CURRENCY_LIMITS
SELECT * FROM CFTM_PRODUCT_CURRENCY_LIMITS WHERE product = '&PROD';

Prompt CSTM_PRODUCT_EVENT
SELECT * FROM CSTM_PRODUCT_EVENT WHERE product_code = '&PROD';

Prompt CSTBS_EVENT_TAGS
SELECT * FROM CSTBS_EVENT_TAGS WHERE MODULE ='SI';

Prompt CSTBS_AMOUNT_TAG
SELECT * FROM CSTBS_AMOUNT_TAG WHERE MODULE ='SI';

set echo off
spool off
