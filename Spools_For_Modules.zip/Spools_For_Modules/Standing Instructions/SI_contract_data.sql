accept Contract		PROMPT 'Enter the Contract Reference Number  >'
accept Instruction  	PROMPT 'Enter the Instruction Number >'
set array 1
set head on
set feedback on
set line 10000
set pagesize 50000
set echo on
set trimspool on
set colsep ';'

COL CUSTOMER_NAME NoPrint
COL payment_details noprint
COL clause_descr noprint
COL doc_descr noprint
COL doc_reference noprint
COL address1 noprint
col address2 noprint
col address3 noprint
col warehouse_address noprint
col cust_name noprint
col cust_address_lin1 noprint
col cust_address_lin2 noprint
col cust_address_lin3 noprint
col cust_address_lin4 noprint
col tracer_code noprint
Col ADDRESS4 NoPrint

SPOOL SI_contract_data.SPL

prompt STTM_CUST_ACCOUNT_DR_AC

select * from sttm_cust_account where cust_ac_no in
(select Dr_account from sitb_contract_master where contract_ref_no  = '&Contract')
/

prompt STTM_CUST_ACCOUNT_CR_AC

select * from sttm_cust_account where cust_ac_no in
(select Cr_account from sitb_contract_master where contract_ref_no  = '&Contract')
/

prompt STTB_ACCOUNT_DR_AC

select * from sttb_account where ac_gl_no in
(select Dr_account from sitb_contract_master where contract_ref_no  = '&Contract')
/

prompt STTB_ACCOUNT_CR_AC

select * from sttb_account where ac_gl_no in
(select Cr_account from sitb_contract_master where contract_ref_no  = '&Contract')
/


prompt ACTB_ALL_AC_ENTRY_DR_AC

select * from acvws_all_ac_entries where  ac_no in
(select Dr_account from sitb_contract_master where contract_ref_no  = '&Contract')
and module='SI'
/

prompt ACTB_ALL_AC_ENTRY_CR_AC

select * from acvws_all_ac_entries where  ac_no in
(select Cr_account from sitb_contract_master where contract_ref_no  = '&Contract')
and module='SI'
/

prompt ACTB_VD_BAL_DR_AC

select * from actb_vd_bal where  acc in
(select Dr_account from sitb_contract_master where contract_ref_no  = '&Contract')
/

prompt ACTB_VD_BAL_CR_AC

select * from actb_vd_bal where  acc in
(select Dr_account from sitb_contract_master where contract_ref_no  = '&Contract')
/

SELECT * FROM CSTMS_PRODUCT WHERE PRODUCT_CODE =SUBSTR('&Contract',4,4);

prompt SITB_CONTRACT_MASTER

select * from sitb_contract_master where contract_ref_no  = '&Contract'
/

prompt SITB_INSTRUCTION

select * from sitb_instruction where instruction_no = '&Instruction'
/

prompt  CSTB_CONTRACT_EVENT_LOG

select * from cstb_contract_event_log where contract_ref_no = '&Contract'
/

prompt CSTB_CONTRACT_EXCEPTION

select * from cstb_contract_exception where contract_ref_no  = '&Contract'
/

prompt SITBS_CYCLE_DUE_EXEC

SELECT * FROM SITBS_CYCLE_DUE_EXEC WHERE INSTRUCTION_NO='&Instruction'
/

prompt  CSTB_CONTRACT_CHANGE_LOG

select * from cstb_contract_change_log where contract_ref_no = '&Contract'
/

prompt  CSTB_CONTRACT_EVENT_ADVICE

select * from cstb_contract_event_advice where contract_ref_no = '&Contract'
/

prompt  ISTBS_CONTRACTIS

select * from ISTBS_CONTRACTIS where contract_ref_no = '&Contract'
/
prompt  ISTBS_MSGHO

select * from ISTBS_MSGHO where contract_ref_no = '&Contract'
/

select * from mstb_dly_msg_out where reference_no = '&Contract'
/

select * from mstb_archive_out where reference_no = '&Contract'
/

select * from cstbs_contract_info where contract_ref_no = '&Contract'
/

select * from mitbs_class_mapping where unit_ref_no = '&Contract'
/

spool off 
