accept ACC PROMPT 'Pls enter the account no. ==> '
set serveroutput on size 1000000
set head on
set array 1
set linesize 10000
set pagesize 50000
set long 10000
set echo on
set trimspool on
set colsep ';'
set numformat 9999999999999999.999
Col ADDRESS1 noprint
Col ADDRESS2 noprint
Col ADDRESS3 noprint
Col ADDRESS4 noprint
Col ADDRESS_LINE1 NoPrint
Col ADDRESS_LINE2 NoPrint
Col ADDRESS_LINE3 NoPrint
Col ADDRESS_LINE4 NoPrint
Col AC_DESC noprint
Col AC_GL_DESC noprint
Col CUST_NAME1 noprint
Col CUST_NAME NoPrint
Col CUSTOMER_NAME NoPrint
Col CUSTNAME NoPrint
Col SHORT_NAME NoPrint
Col UNIQUE_ID_VALUE noprint
column PASSPORT_NO noprint
define lv_ttstamp=date
column ttstamp new_value lv_ttstamp noprint
select to_char(sysdate,'RRRRMMDDHH24MISS') as ttstamp from dual;
SPOOL CASA_account_data.spl
show user;
exec dbms_session.set_nls('NLS_DATE_FORMAT','''DD/MM/RRRR HH24:MI:SS''');
exec dbms_session.set_nls('NLS_NUMERIC_CHARACTERS','''.,''');
Prompt 'ACCOUNT CLASS DETAILS'
Prompt sttm_account_class
select * from sttm_account_class where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_account_class_status
Select * from sttm_account_class_status where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt cstm_accprod_status_gl
Select * from cstm_accprod_status_gl where accls_or_prod = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_accls_cat_restr
Select * from sttms_accls_cat_restr where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_accls_cus_restr
Select * from sttms_accls_cus_restr where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_accls_ccy_restr
Select * from sttms_accls_ccy_restr where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_accls_ccy_balances
Select * from sttms_accls_ccy_balances where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_amtblk_order
Select * from sttm_aclass_amtblk_order where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_ac_stat_drv
Select * from sttm_ac_stat_drv where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttms_aclass_products
Select * from sttms_aclass_products where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_txncode
Select * from sttm_aclass_txncode where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_interim_dr_amt
Select * from sttm_aclass_interim_dr_amt where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_interim_cr_amt
Select * from sttm_aclass_interim_cr_amt where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
Prompt sttm_aclass_report_gen_time
Select * from sttm_aclass_report_gen_time where account_class = (select account_class from sttm_cust_account where cust_ac_no = '&acc');
PROMPT 'ACCOUNT CLASS CHANGE'
select * from sttm_cusacc_aclass where cust_ac_no = '&acc';
Prompt 'CUSTOMER DETAILS'
Prompt sttm_customer
Select * from sttm_customer where customer_no = (select cust_no from sttm_cust_account where cust_ac_no = '&acc');
Prompt 'ACCOUNT DETAILS'
Prompt sttms_cust_account
Select * from sttms_cust_account where cust_ac_no = '&acc';
Prompt sttbs_account
Select * from sttbs_account where ac_gl_no = '&acc';
Prompt sttm_accstat_replines_detail
Select * from sttm_accstat_replines_detail where cust_ac_no = '&acc';
Prompt actbs_funcol
Select * from actbs_funcol where account ='&acc';
Prompt actbs_funcol_history
Select * from actbs_funcol_history where account ='&acc';
Prompt catms_amount_blocks
Select * from catms_amount_blocks where account ='&acc';
Prompt cstb_auto_settle_block
Select * from cstb_auto_settle_block where account_no ='&acc';
Prompt sttm_cust_account_linkages
Select * from sttm_cust_account_linkages where cust_ac_no = '&acc';
Prompt sttm_cust_account_dormancy
Select * from sttm_cust_account_dormancy where cust_ac_no = '&acc';
Prompt 'ACCOUNT BALANCES'
Prompt actbs_vd_bal
Select * from actbs_vd_bal where acc = '&acc';
Prompt actbs_accbal_history
Select * from actbs_accbal_history where account = '&acc';
Prompt actb_daily_log
Select * from actb_daily_log where ac_no = '&acc';
Prompt acvws_all_ac_entries
Select * from acvws_all_ac_entries where ac_no = '&acc';
Prompt Sum of acvws_all_ac_entries
Select sum(decode(drcr_ind,'D',-lcy_amount,lcy_amount)) from acvw_all_ac_entries where ac_no = '&acc';
Prompt 'ACCOUNT AUDIT DETAILS'
Prompt sttb_record_master
Select * from sttb_record_master where key_id like '~STTM_CUST_ACCOUNT~' || '%' || '~' || '&acc' || '~';
Prompt sttb_record_log
Select * from sttb_record_log where key_id like '~STTM_CUST_ACCOUNT~' || '%' || '~' || '&acc' || '~';
Prompt sttb_field_log
Select * from sttb_field_log where detail_key like '~STTM_CUST_ACCOUNT~' || '%' || '~' || '&acc' || '~';
Prompt sttm_account_balance
select * from sttm_account_balance where cust_ac_no = '&acc';
Prompt actb_entries_handoff
select * from actb_entries_handoff where ac_no = '&acc';
Prompt actb_entries_history
select * from actb_entries_history where ac_no = '&acc';
Prompt catb_entries
select * from catb_entries where ac_no = '&acc';
set echo off
spool off