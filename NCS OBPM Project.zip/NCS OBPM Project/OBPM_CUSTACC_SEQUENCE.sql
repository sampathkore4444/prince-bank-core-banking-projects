-- Create sequence 
create sequence OBPM_CUSTACC_SEQUENCE
minvalue 1
maxvalue 9999999999
start with 1
increment by 1
cache 20
cycle;
