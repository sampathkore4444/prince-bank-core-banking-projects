var g_PickupClicked = 0;
var n =0;

function fnPickupReqd(){
	debugs("In fnPickupReqd", "A");
	g_PickupClicked = 0;
	n=0;
	return true;
}

function fnPickup() {
	debugs("In fnPickup", "A");
	g_prevAction = gAction;
	gAction = "PICKUP";
	appendData();
	gAction = "PICKUP";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	fnDisableElement(document.getElementById("BLK_NCS_MASTER__TXN_CCY"));
	
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}

function fnPreSave_CUSTOM(){
	debugs("In fnPreSave_CUSTOM", "A");

	if (document.getElementById("BLK_NCS_MASTER__NET_TXN_AMT").value == "" || g_PickupClicked != 1) {			
		debugs("In Please click on Pick up before save", "A");
		alert("Please click on Pick up before save");
		return false;
	}
	return true;	
}