CREATE OR REPLACE PACKAGE BODY ifpks_ifdncsft_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdncsft_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2022 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdncsft_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  
  FUNCTION FN_GET_ACCOUNT_DTLS(P_CUSTAC_NO IN VARCHAR2)
    RETURN STTM_CORE_ACCOUNT%ROWTYPE AS
  
    L_STTM_CORE_ACCOUNT STTM_CORE_ACCOUNT%ROWTYPE;
  
  BEGIN
    BEGIN
      SELECT *
        INTO L_STTM_CORE_ACCOUNT
        FROM STTM_CORE_ACCOUNT A
       WHERE A.CUST_ACCOUNT_NO = P_CUSTAC_NO;
    
      RETURN L_STTM_CORE_ACCOUNT;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('ERROR CODE IN FN_GET_ACCOUNT_DTLS=' || SQLCODE);
        DBG('ERROR MESSAGE IN FN_GET_ACCOUNT_DTLS=' || SQLERRM);
        L_STTM_CORE_ACCOUNT := NULL;
        RETURN L_STTM_CORE_ACCOUNT;
    END;
    
    RETURN L_STTM_CORE_ACCOUNT;
  
  END FN_GET_ACCOUNT_DTLS;
  
  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN

    SELECT TRSQ_NCS_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 12, '0');

    RETURN L_REF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;
  
  FUNCTION FN_GET_EXTERNAL_CODE(P_BIC_CODE IN IFTB_NCS_PARTICIPANTS.BIC_CODE%TYPE)
    RETURN IFTB_NCS_PARTICIPANTS.EXTERNAL_CODE%TYPE
    AS
    L_EXTERNAL_CODE IFTB_NCS_PARTICIPANTS.EXTERNAL_CODE%TYPE;
    BEGIN
      SELECT A.EXTERNAL_CODE INTO L_EXTERNAL_CODE FROM IFTB_NCS_PARTICIPANTS A WHERE A.BIC_CODE = P_BIC_CODE;
      
      RETURN L_EXTERNAL_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN FN_GET_EXTERNAL_CODE');
        DBG('ERROR CODE IN FN_GET_EXTERNAL_CODE='||SQLCODE);
        DBG('ERROR MESSAGE IN FN_GET_EXTERNAL_CODE='||SQLERRM);
        RETURN L_EXTERNAL_CODE;
      END FN_GET_EXTERNAL_CODE;

  FUNCTION FN_GET_SDR_TEMPLATE RETURN CLOB IS
  
    L_CLOB CLOB;
  
  BEGIN
    DBG('START OF FN_GET_SDR_TEMPLATE');
  
    L_CLOB := '<SDRFile>
     <Payment>
      <PaymentTypeCode>$L_PAYTYPE_CODE</PaymentTypeCode>
      <SerialNo>$L_SERIAL_NO</SerialNo>
      <PaymentDate>$L_PAYMNT_DATE</PaymentDate>
      <PayerBank>096100</PayerBank>
      <PayerCheckDigit>3</PayerCheckDigit>
      <PayerAccountNo>$L_DR_ACC_NO</PayerAccountNo>
      <CurrencyCode>$L_CUST_DRAC_CCY</CurrencyCode>
      <Amount>$L_TXN_AMOUNT</Amount>
      <SecurityCode/>
      <PayerName>$PAYER_NAME</PayerName>
      <PayerRef>PRINCE BANK PLC</PayerRef>
      <PayeeBank>$L_BEN_BIC</PayeeBank>
      <PayeeCheckDigit>6</PayeeCheckDigit>
      <PayeeAccountNo>$L_CR_ACC_NO</PayeeAccountNo>
      <PayeeName>$L_CR_CUST_NAME</PayeeName>
      <PayeeRef/>
      <ReturnCode/>
      <InputDate/>
      <ProcessingDate>$L_PROC_DATE</ProcessingDate>
      <InputBatchNo/>
      <OutputBatchNo/>
    </Payment>
  </SDRFile>';
  
    RETURN L_CLOB;
  
    DBG('END OF FN_GET_SDR_TEMPLATE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_SDR_TEMPLATE');
      DBG('ERROR CODE IN FN_GET_SDR_TEMPLATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_SDR_TEMPLATE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN FN_GET_SDR_TEMPLATE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
  END FN_GET_SDR_TEMPLATE;

  PROCEDURE PR_WRITE_SDR_TXN_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                     P_IN_FILE_NAME IN VARCHAR2,
                                     P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_SDR_TXN_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_SDR_TXN_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_SDR_TXN_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_SDR_TXN_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_SDR_TXN_TO_FILE;

  PROCEDURE PR_GET_FORMATTED_XML(P_XML           IN VARCHAR2,
                                 P_FORMATTED_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_FORMATTED_XML := P_XML;
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '<S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSCcyService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSRTService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '   </S:Body>', NULL);
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Envelope>', NULL);
  
  END PR_GET_FORMATTED_XML;

  FUNCTION FN_FC_PM_CALL(p_RIA_call in varchar2,
                         p_out_msg  VARCHAR2,
                         p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
    l_length   number;
  
  BEGIN
    dbg('START OF FN_FC_PM_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
  
    /*IF p_RIA_call = 'I' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_RIA_OUT_ENQ_URL');
    
    ELSIF p_RIA_call = 'C' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_RIA_PAYCONFIRM_OUT_URL');
    
    END IF;*/
  
    L_URL := '';
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
  
    utl_http.set_authentication(l_http_request,
                                '', --FN_GET_PARAM_VAL('PGW_RIA_AUTH_UID'),
                                '', --FN_GET_PARAM_VAL('PGW_RIA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
  
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
  
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/json;charset=UTF-8');
  
    debug.pr_debug('IF', 'l_length=' || l_length);
  
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg) + l_length);
  
    --UTL_HTTP.SET_BODY_CHARSET(l_http_request,'UTF-8');
  
    utl_http.set_transfer_timeout(300);
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    DBG('l_resp_num=' || l_resp_num);
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    --dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_FC_PM_CALL;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdncsft         IN OUT ifpks_ifdncsft_Main.ty_ifdncsft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdncsft_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdncsft         IN OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
    l_serial_no      VARCHAR2(16);
    L_RELATED_REF_NO iftb_ncs_master.RELATED_REF_NO%TYPE;
  
    L_XML            VARCHAR2(32767);
    L_RESPONSE       VARCHAR2(32767) := '';
    L_SETTLEMENT_ACC IFTB_NCS_MASTER.REM_ACC%TYPE;
    L_CUST_DRAC_CCY  STTM_CORE_ACCOUNT.CUST_AC_CCY%TYPE;
    L_BRN            STTM_CORE_ACCOUNT.SOURCE_SYSTEM_ACC_BRN%TYPE;
  
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
  
    L_MID_RATE  CYTM_RATES.MID_RATE%TYPE;
    L_BUY_RATE  CYTM_RATES.BUY_RATE%TYPE;
    L_SALE_RATE CYTM_RATES.SALE_RATE%TYPE;
    L_EXCH_RATE IFTB_NCS_MASTER.EXCH_RATE%TYPE;
  
    l_txn_amt IFTB_NCS_MASTER.txn_amt%TYPE;
  
    L_COMM_FEE_P         IFTB_NCS_MASTER.txn_amt%TYPE;
    L_COMM_MIN_FEE       IFTB_NCS_MASTER.txn_amt%TYPE;
    L_COMM_FEE           IFTB_NCS_MASTER.txn_amt%TYPE;
    l_chg_amt            IFTB_NCS_MASTER.txn_amt%TYPE;
    l_final_chg_amt      IFTB_NCS_MASTER.txn_amt%TYPE;
    l_chg_amt_in_acc_ccy IFTB_NCS_MASTER.txn_amt%TYPE;
    L_EQUIVALENT_USD_AMT IFTB_NCS_MASTER.txn_amt%TYPE;
  
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
  
    L_STATUS_MSG VARCHAR2(105);
    L_ERROR_DESC VARCHAR2(255);
  
    TYPE TYPE_EXCHANGE_RATES_LIST IS TABLE OF CYTB_RATES_CUSTOM%ROWTYPE;
    L_EXCHANGE_RATES_LIST TYPE_EXCHANGE_RATES_LIST;
  
    L_TRN_REF_NO IFTB_NCS_MASTER.TRN_REF_NO%TYPE;
    L_XREF VARCHAR2(15);
    
    
    
    L_STTM_CORE_ACCOUNT STTM_CORE_ACCOUNT%ROWTYPE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory='||P_ACTION_CODE);
    
    IF P_ACTION_CODE = 'NEW' THEN
    
    IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'KHR' THEN
        
      L_EQUIVALENT_USD_AMT := p_ifdncsft.v_iftbs_ncs_master.TXN_AMT / P_IFDNCSFT.V_IFTBS_NCS_MASTER.EXCH_RATE;
      
      IF L_EQUIVALENT_USD_AMT < 0.01 THEN
        
        OVPKSS.PR_APPENDTBL('DE-PRI-SC01', P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY);
        
              RETURN FALSE;
        
        
        
      END IF;
      
      END IF;  
      
      L_STTM_CORE_ACCOUNT := FN_GET_ACCOUNT_DTLS(P_IFDNCSFT.V_IFTBS_NCS_MASTER.REM_ACC);
      
      IF NVL(L_STTM_CORE_ACCOUNT.AC_STAT_FROZEN,'N') = 'Y' THEN
        
      
      
      Pr_Log_Error(p_Function_id, p_Source, 'CS-UPD-016', P_IFDNCSFT.V_IFTBS_NCS_MASTER.REM_ACC);
      
        RETURN FALSE;
        
      END IF;
      
      IF NVL(L_STTM_CORE_ACCOUNT.AC_STAT_DORMANT,'N') = 'Y' THEN
        
        
        Pr_Log_Error(p_Function_id, p_Source, 'CS-UPD-017', P_IFDNCSFT.V_IFTBS_NCS_MASTER.REM_ACC); 
      
        RETURN FALSE;
      END IF;
      
      IF NVL(L_STTM_CORE_ACCOUNT.AC_STAT_NO_DR,'N') = 'Y' THEN
        
        
        Pr_Log_Error(p_Function_id, p_Source, 'CS-TRFR-51', P_IFDNCSFT.V_IFTBS_NCS_MASTER.REM_ACC); 
      
        RETURN FALSE;
      END IF;
     
    END IF;
  
    IF P_ACTION_CODE = 'PICKUP' THEN
      
    P_IFDNCSFT.V_IFTBS_NCS_MASTER.trn_ref_no := NULL;
    P_IFDNCSFT.V_IFTBS_NCS_MASTER.transfer_date  := GLOBAL.application_date;
    
      IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.related_ref_no IS NULL THEN
        IF NOT trpks_core.fn_get_product_refno(GLOBAL.current_branch,
                                               'OBPM',
                                               GLOBAL.application_date,
                                               l_serial_no,
                                               L_RELATED_REF_NO,
                                               p_err_code) THEN
          dbg('Failed in generation Transaction Ref No');
          RETURN FALSE;
        ELSE
          dbg('L_RELATED_REF_NO=' || L_RELATED_REF_NO);
          p_ifdncsft.V_IFTBS_NCS_MASTER.RELATED_REF_NO := L_RELATED_REF_NO;
        
        END IF;
      END IF;
      
      IF p_ifdncsft.v_iftbs_ncs_master.EXCH_RATE IS NULL THEN
      
      L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSCcyService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:QUERYCYDRATEE_IOFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>OBPAY</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:USERID>OBPAYUSER</fcub:USERID>
            <fcub:BRANCH>000</fcub:BRANCH>
            <fcub:SERVICE>FCUBSCcyService</fcub:SERVICE>
            <fcub:OPERATION>QueryCYDRATEE</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Ccy-Rate-Master-IO>
               <fcub:CCY1>USD</fcub:CCY1>
               <fcub:CCY2>KHR</fcub:CCY2>
            </fcub:Ccy-Rate-Master-IO>
         </fcub:FCUBS_BODY>
      </fcub:QUERYCYDRATEE_IOFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
      
      L_RESPONSE := process_http('http://10.80.80.79:8007/' ||
                                 'FCUBSCcyService/FCUBSCcyService',
                                 L_XML,
                                 'text/xml;charset=utf-8');
    
      DBG('L_RESPONSE OF EXCHANGE RATES=' || L_RESPONSE);
    
      PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
    
      DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
    
      P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
    
      --Check if returned error or success
      L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                      .GETSTRINGVAL;
    
      IF L_STATUS_MSG <> 'SUCCESS' THEN
      
        L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                        .GETSTRINGVAL;
      
        Pr_Log_Error(p_Function_id, p_Source, 'IF-NCS001', L_ERROR_DESC); --pls put the error code
      
        RETURN FALSE;
      
      ELSE
      
        --Get list of rates      
      
        BEGIN
          WITH t(xml) AS
           (SELECT xmltype(L_FORMATTED_RES_MSG) FROM DUAL)
          SELECT x.*
            BULK COLLECT
            INTO L_EXCHANGE_RATES_LIST
            FROM t,
                 xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                        "nq1"),
                          '/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details'
                          passing t.xml columns RATE_TYPE varchar2(50) PATH
                          'RATETYPE',
                          MID_RATE varchar2(50) PATH 'MIDRATE',
                          BUY_RATE VARCHAR2(50) PATH 'BUYRATE',
                          SALE_RATE VARCHAR2(50) PATH 'SALERATE') x;
        
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('IF',
                           'ERROR CODE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                           SQLCODE);
            DEBUG.PR_DEBUG('IF',
                           'ERROR MESSAGE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                           SQLERRM);
        END;
        Debug.Pr_Debug('IF', 'COUNT=' || L_EXCHANGE_RATES_LIST.COUNT);
      
        DBG('L_EXCHANGE_RATES_LIST.RATE_TYPE=' || L_EXCHANGE_RATES_LIST(1)
            .RATE_TYPE);
        DBG('L_EXCHANGE_RATES_LIST.BUY_RATE=' || L_EXCHANGE_RATES_LIST(1)
            .BUY_RATE);
        DBG('L_EXCHANGE_RATES_LIST.MID_RATE=' || L_EXCHANGE_RATES_LIST(1)
            .MID_RATE);
        DBG('L_EXCHANGE_RATES_LIST.SALE_RATE=' || L_EXCHANGE_RATES_LIST(1)
            .SALE_RATE);
      
        IF L_EXCHANGE_RATES_LIST.COUNT > 0 THEN
        
          BEGIN
            FOR K IN 1 .. L_EXCHANGE_RATES_LIST.COUNT LOOP
              Debug.Pr_Debug('IF',
                             'RATE_TYPE=' || L_EXCHANGE_RATES_LIST(K)
                             .RATE_TYPE || ' ' || 'MID RATE=' || L_EXCHANGE_RATES_LIST(K)
                             .MID_RATE || ' ' || 'BUY RATE=' || L_EXCHANGE_RATES_LIST(K)
                             .BUY_RATE || ' ' || 'SALE RATE=' || L_EXCHANGE_RATES_LIST(K)
                             .SALE_RATE);
            
              IF L_EXCHANGE_RATES_LIST(K).RATE_TYPE = 'COMM' THEN
              
                L_MID_RATE  := L_EXCHANGE_RATES_LIST(K).MID_RATE;
                L_BUY_RATE  := L_EXCHANGE_RATES_LIST(K).BUY_RATE;
                G_BUY_RATE := L_EXCHANGE_RATES_LIST(K).BUY_RATE;
                L_SALE_RATE := L_EXCHANGE_RATES_LIST(K).SALE_RATE;
                G_SALE_RATE := L_EXCHANGE_RATES_LIST(K).SALE_RATE;
              
              END IF;
            
            END LOOP;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
              DBG('ERROR CODE=' || SQLCODE);
              DBG('ERROR MESSAGE=' || SQLERRM);
          END;
        
        END IF;
      
        --Get Mid Rate    
        /*  L_MID_RATE := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details/MIDRATE//text()')
        .GETSTRINGVAL;*/
        DBG('L_MID_RATE=' || L_MID_RATE);
      
        --Get Buy Rate    
        /* L_BUY_RATE := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details/BUYRATE//text()')
        .GETSTRINGVAL;*/
        DBG('L_BUY_RATE=' || L_BUY_RATE);
      
        --Get Sale Rate    
        /*L_SALE_RATE := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details/SALERATE//text()')
        .GETSTRINGVAL;*/
        DBG('L_SALE_RATE=' || L_SALE_RATE);
      
      END IF;
      
     
      
      DBG('p_ifdncsft.v_iftbs_ncs_master.rem_acc='||p_ifdncsft.v_iftbs_ncs_master.rem_acc);
    
      BEGIN
      
        SELECT A.CUST_AC_CCY
          INTO L_CUST_DRAC_CCY
          FROM STTM_CORE_ACCOUNT A
         WHERE A.CUST_ACCOUNT_NO = p_ifdncsft.v_iftbs_ncs_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_DRAC_CCY := NULL;
      END;
      
      
      
    
      IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'KHR' AND
         L_CUST_DRAC_CCY = 'KHR' 
        THEN
         
     
        L_EXCH_RATE := 1;--L_MID_RATE;
      
      ELSIF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'KHR' AND
            L_CUST_DRAC_CCY = 'USD' THEN
      
        L_EXCH_RATE := L_BUY_RATE;
      
      ELSIF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'USD' AND
            L_CUST_DRAC_CCY = 'KHR' THEN
      
        L_EXCH_RATE := L_SALE_RATE;
      
      ELSE
      
        L_EXCH_RATE := 1;
      
      END IF;
    
      DBG('L_EXCH_RATE=' || L_EXCH_RATE);
    
      P_IFDNCSFT.V_IFTBS_NCS_MASTER.EXCH_RATE := L_EXCH_RATE;
      
      ELSE
        
      L_EXCH_RATE := P_IFDNCSFT.V_IFTBS_NCS_MASTER.EXCH_RATE;
      
      P_IFDNCSFT.V_IFTBS_NCS_MASTER.EXCH_RATE := L_EXCH_RATE;
      
      BEGIN
      
        SELECT A.CUST_AC_CCY
          INTO L_CUST_DRAC_CCY
          FROM STTM_CORE_ACCOUNT A
         WHERE A.CUST_ACCOUNT_NO = p_ifdncsft.v_iftbs_ncs_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_DRAC_CCY := NULL;
      END;
        
      END IF;
      
      DBG('P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY='||P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY);
      DBG('L_CUST_DRAC_CCY='||L_CUST_DRAC_CCY);
      DBG('P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT='||P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT);
      
      IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'KHR' THEN
        
      L_EQUIVALENT_USD_AMT := p_ifdncsft.v_iftbs_ncs_master.TXN_AMT / P_IFDNCSFT.V_IFTBS_NCS_MASTER.EXCH_RATE;
      
      IF L_EQUIVALENT_USD_AMT < 0.01 THEN
        
        OVPKSS.PR_APPENDTBL('DE-PRI-SC01', P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY);
        
              RETURN FALSE;
        
        
        
      END IF;
      
      END IF;
      
    
      --Main Transaction Calculation
      IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY <> L_CUST_DRAC_CCY THEN
      
        IF NOT cypkss.FN_AMT1_TO_AMT2(P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY,
                                      L_CUST_DRAC_CCY,
                                      P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT,
                                      P_IFDNCSFT.V_IFTBS_NCS_MASTER.exch_rate,
                                      'Y',
                                      l_txn_amt,
                                      p_err_params) THEN
         
        DBG('WHO CALLED ME='||DBMS_UTILITY.format_call_stack);
         RETURN FALSE;
        
        ELSE
        
          DBG('l_txn_amt after =' || l_txn_amt);
          
          P_IFDNCSFT.V_IFTBS_NCS_MASTER.DR_AMOUNT := l_txn_amt; --pls check
        
        END IF;
      
        /*--Fee Processing
        IF P_IFDNCSFT.v_iftbs_ncs_master.WAIVE_CHARGE = 'Y' THEN 
          
          l_final_chg_amt := 0;
        
        ELSE  
          
        IF NOT cypkss.FN_AMT1_TO_AMT2(P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY,
                                      L_CUST_DRAC_CCY,
                                      l_chg_amt,
                                      P_IFDNCSFT.V_IFTBS_NCS_MASTER.exch_rate,
                                      'Y',
                                      l_final_chg_amt,
                                      p_err_params) THEN
          RETURN FALSE;
        
        ELSE
        
          DBG('l_final_chg_amt after =' || l_final_chg_amt);
        
        END IF;
        END IF;*/
      
      ELSE
      
        l_txn_amt := P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT;-- * P_IFDNCSFT.V_IFTBS_NCS_MASTER.exch_rate;
      
        DBG('l_txn_amt =' || l_txn_amt);
      
        P_IFDNCSFT.V_IFTBS_NCS_MASTER.DR_AMOUNT := l_txn_amt; --pls check
      
      END IF;
    
      --Charge Calculation
    
      IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT > 0 THEN
      
        --Get Percentage
        L_COMM_FEE_P := FN_GET_PARAM_VAL('NCS_MIN_FEE_PERCENTAGE');
      
        --Get Min Fee
        L_COMM_MIN_FEE := FN_GET_PARAM_VAL('NCS_MIN_FEE_USD');
      
        IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY <> L_CUST_DRAC_CCY THEN
        
          IF L_CUST_DRAC_CCY = 'USD' THEN
            --here transaction currency is KHR and account currency is USD
            
            IF P_IFDNCSFT.v_iftbs_ncs_master.WAIVE_CHARGE = 'Y' THEN
              
              l_chg_amt := 0;
            
            ELSE
          
            L_COMM_FEE := (L_COMM_FEE_P * l_txn_amt) / 100;
          
            IF L_COMM_FEE > L_COMM_MIN_FEE THEN
            
              l_chg_amt := L_COMM_FEE;
            
            ELSE
            
              l_chg_amt := L_COMM_MIN_FEE;
            
            END IF;
            END IF;
          
            DBG('l_chg_amt IN USD=' || l_chg_amt);
          
          ELSE
            --here transaction currency is USD and account currency is KHR
            
            IF P_IFDNCSFT.v_iftbs_ncs_master.WAIVE_CHARGE = 'Y' THEN
            
            l_chg_amt := 0;  
            
            ELSE
          
            L_COMM_FEE := (L_COMM_FEE_P *
                          P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT) / 100;
          
            IF L_COMM_FEE > L_COMM_MIN_FEE THEN
            
              l_chg_amt := L_COMM_FEE;
            
            ELSE
            
              l_chg_amt := L_COMM_MIN_FEE;
            
            END IF;
          
            --Get Equivalent charge from account currency
            l_chg_amt_in_acc_ccy := (L_EXCH_RATE) * l_chg_amt;
          
            l_chg_amt := l_chg_amt_in_acc_ccy;
            
            END IF;
          
            DBG('l_chg_amt IN KHR=' || l_chg_amt);
          
          END IF;
        
        ELSE
          
        IF P_IFDNCSFT.v_iftbs_ncs_master.WAIVE_CHARGE = 'Y' THEN
            
            l_chg_amt := 0;  
            
            ELSE
            
            IF   P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'USD' AND L_CUST_DRAC_CCY = 'USD' THEN
            
            L_COMM_FEE := (L_COMM_FEE_P * l_txn_amt) / 100; 
            
            ELSE
              
              DBG('INSIDE ELSE');
              
            L_COMM_FEE := (L_COMM_FEE_P * l_txn_amt) / 100;
            
            DBG('L_COMM_FEE='||L_COMM_FEE);
            
            L_COMM_MIN_FEE := L_COMM_MIN_FEE * G_SALE_RATE;
            
            DBG('L_COMM_MIN_FEE='||L_COMM_MIN_FEE);
               
            END IF;
            
          
        
          IF L_COMM_FEE > L_COMM_MIN_FEE THEN
          
            l_chg_amt := L_COMM_FEE;
          
          ELSE
          
            l_chg_amt := L_COMM_MIN_FEE;
          
          END IF;
          
          END IF;
        
          DBG('l_chg_amt IN USD=' || l_chg_amt);
          
          
                 
        
        END IF;   
        
        IF NOT
                cypks.fn_amt_round(L_CUST_DRAC_CCY,
                                   l_chg_amt,
                                   l_chg_amt) THEN
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING=' || l_chg_amt);  
      
        
         P_IFDNCSFT.V_IFTBS_NCS_MASTER.TOT_CHG_AMT := l_chg_amt;
         
          P_IFDNCSFT.V_IFTBS_NCS_MASTER.NET_TXN_AMT := nvl(P_IFDNCSFT.V_IFTBS_NCS_MASTER.DR_AMOUNT,
                                                           0) +
                                                       nvl(l_chg_amt, 0);
      
      END IF;
    
    END IF;
    
    IF p_Action_Code = 'AUTH' THEN
    
      --call ws
      L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSRTService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:CREATETRANSACTION_FSFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>OBPAY</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:MSGID></fcub:MSGID>
            <fcub:CORRELID></fcub:CORRELID>
            <fcub:USERID>OBPAYUSER</fcub:USERID>
            <fcub:ENTITY></fcub:ENTITY>
            <fcub:BRANCH>' || GLOBAL.current_branch ||
               '</fcub:BRANCH>
            <fcub:MODULEID></fcub:MODULEID>
            <fcub:SERVICE>FCUBSRTService</fcub:SERVICE>
            <fcub:OPERATION>CreateTransaction</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Transaction-Details>
               <fcub:XREF>$L_XREF</fcub:XREF>
               <fcub:FCCREF></fcub:FCCREF>
               <fcub:PRD>NCSF</fcub:PRD>
               <fcub:ESN></fcub:ESN>
               <fcub:EVNTCD></fcub:EVNTCD>
               <fcub:BRN>BRN</fcub:BRN>
               <fcub:MODULE></fcub:MODULE>
               <fcub:TXNBRN>$L_BRN</fcub:TXNBRN>
               <fcub:TXNACC>$L_CUST_DRAC_NO</fcub:TXNACC>
               <fcub:TXNCCY>$L_CUST_DRAC_CCY</fcub:TXNCCY>
               <fcub:TXNAMT>$L_TXN_AMT</fcub:TXNAMT>
               <fcub:TXNTRN></fcub:TXNTRN>
               <fcub:CREDITCARDNO></fcub:CREDITCARDNO>
               <fcub:CC_HOLDER_NAME></fcub:CC_HOLDER_NAME>
               <fcub:OFFSETBRN>991</fcub:OFFSETBRN>
               <fcub:OFFSETACC>$L_SETTLEMENT_ACC</fcub:OFFSETACC>
               <fcub:OFFSETCCY>$L_SETTLEMENT_CCY</fcub:OFFSETCCY>
               <fcub:OFFSETAMT>$L_CREDIT_AMT</fcub:OFFSETAMT>
               <fcub:OFFSETTRN></fcub:OFFSETTRN>
               <fcub:XRATE>1</fcub:XRATE>
               <fcub:SDBREFNO></fcub:SDBREFNO>
               <fcub:Charge-Details>
                  <fcub:CHGCOMP>NCS FEE</fcub:CHGCOMP>
                  <fcub:WAIVER></fcub:WAIVER>
                  <fcub:CHGAMT>$L_CHG_AMT</fcub:CHGAMT>
                  <fcub:CHGCCY>$L_CHG_CCY</fcub:CHGCCY>
               </fcub:Charge-Details>
               
               <fcub:Udf-Details>
          <fcub:FUNCTIONID>NCSF</fcub:FUNCTIONID>
          <fcub:FIELD_NAME>REQUESTORS_BRANCH_NCS</fcub:FIELD_NAME>
          <fcub:FIELD_VALUE>$L_REQUESTORS_BRANCH</fcub:FIELD_VALUE>
         </fcub:Udf-Details>
         
          <fcub:Udf-Details>
          <fcub:FUNCTIONID>NCSF</fcub:FUNCTIONID>
          <fcub:FIELD_NAME>EXCHANGE_RATE_NCS</fcub:FIELD_NAME>
          <fcub:FIELD_VALUE>$L_EXCHANGE_RATE</fcub:FIELD_VALUE>
         </fcub:Udf-Details>
         
         
               
            </fcub:Transaction-Details>
         </fcub:FCUBS_BODY>
      </fcub:CREATETRANSACTION_FSFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
    
      IF p_ifdncsft.v_iftbs_ncs_master.txn_ccy = 'KHR' THEN
      
        BEGIN
        
          SELECT A.PARAM_VAL
            INTO L_SETTLEMENT_ACC
            FROM CSTB_PARAM_CUSTOM A
           WHERE A.PARAM_NAME = 'NCS_TXN_ACC_KHR';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_SETTLEMENT_ACC := '000021069';
        END;
      
      ELSIF p_ifdncsft.v_iftbs_ncs_master.txn_ccy = 'USD' THEN
      
        BEGIN
        
          SELECT A.PARAM_VAL
            INTO L_SETTLEMENT_ACC
            FROM CSTB_PARAM_CUSTOM A
           WHERE A.PARAM_NAME = 'NCS_TXN_ACC_USD';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_SETTLEMENT_ACC := '000021058';
        END;
      
      END IF;
    
      --L_XML := REPLACE(L_XML, '$L_BRANCH_CODE', L_CUST_ACCOUNT.BRANCH_CODE);
      
      L_XREF :=  FN_RETURN_SEQ_NO; 
      
     
      
      L_XML := REPLACE(L_XML, '$L_XREF', L_XREF);
    
      L_XML := REPLACE(L_XML,
                       '$L_CUST_DRAC_NO',
                       p_ifdncsft.v_iftbs_ncs_master.rem_acc);
    
      BEGIN
      
        SELECT A.CUST_AC_CCY
          INTO L_CUST_DRAC_CCY
          FROM STTM_CORE_ACCOUNT A
         WHERE A.CUST_ACCOUNT_NO = p_ifdncsft.v_iftbs_ncs_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_DRAC_CCY := NULL;
      END;
    
      DBG('L_CUST_DRAC_CCY=' || L_CUST_DRAC_CCY);
    
      L_XML := REPLACE(L_XML, '$L_CUST_DRAC_CCY', L_CUST_DRAC_CCY);
      
      BEGIN
      
        SELECT A.SOURCE_SYSTEM_ACC_BRN
          INTO L_BRN
          FROM STTM_CORE_ACCOUNT A
         WHERE A.CUST_ACCOUNT_NO = p_ifdncsft.v_iftbs_ncs_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_BRN := NULL;
      END;
      
       DBG('L_BRN=' || L_BRN);
      
       L_XML := REPLACE(L_XML, '$L_BRN', L_BRN);
    
      L_XML := REPLACE(L_XML,
                       '$L_TXN_AMT',
                       p_ifdncsft.v_iftbs_ncs_master.DR_AMOUNT);
    
      L_XML := REPLACE(L_XML, '$L_SETTLEMENT_ACC', L_SETTLEMENT_ACC);
      
      L_XML := REPLACE(L_XML, '$L_CREDIT_AMT', p_ifdncsft.v_iftbs_ncs_master.TXN_AMT);
      
      L_XML := REPLACE(L_XML,
                       '$L_SETTLEMENT_CCY',
                       p_ifdncsft.v_iftbs_ncs_master.TXN_CCY);
    
      L_XML := REPLACE(L_XML,
                       '$L_CHG_AMT',
                       P_IFDNCSFT.V_IFTBS_NCS_MASTER.TOT_CHG_AMT);
    
      L_XML := REPLACE(L_XML, '$L_CHG_CCY', L_CUST_DRAC_CCY);
      
      L_XML := REPLACE(L_XML, '$L_REQUESTORS_BRANCH', P_IFDNCSFT.v_iftbs_ncs_master.REQUESTOR_BRANCH);
      L_XML := REPLACE(L_XML, '$L_EXCHANGE_RATE', P_IFDNCSFT.v_iftbs_ncs_master.EXCH_RATE);
    
      DBG('Final Request xml=' || L_XML);
    
      L_RESPONSE := process_http('http://10.80.80.79:8007/' ||
                                 'FCUBSRTService/FCUBSRTService',
                                 L_XML,
                                 'text/xml;charset=utf-8');
    
      DBG('L_RESPONSE=' || L_RESPONSE);
    
      --Get Cosmetic XML
      PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
    
      DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
    
      P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
    
      --Check if returned error or success
      L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                      .GETSTRINGVAL;
    
      IF L_STATUS_MSG <> 'SUCCESS' THEN
        
      DBG('INSIDE FAILED');
        
      p_Err_Code := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/ECODE/text()')
                        .GETSTRINGVAL;
      
        p_Err_Params := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                        .GETSTRINGVAL;
                        
                        DBG('p_Err_Code='||p_Err_Code);
                        DBG('p_Err_Params='||p_Err_Params);
      
        Pr_Log_Error(p_Function_id, p_Source, 'IF-NCS-001', p_Err_Params); --pls put the error code
      
        RETURN FALSE;
      
      ELSE
      
        L_TRN_REF_NO := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/FCCREF/text()')
                        .GETSTRINGVAL;
      
        DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
      
        p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO := L_XREF;--L_TRN_REF_NO;
      
        DBG('p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO=' ||
            p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO);
      
        L_RESP_TEMPLATE := FN_GET_SDR_TEMPLATE;
      
        --File Name
        L_FILE_NAME := 'NCSF_SDR_FILE_' ||
                       REPLACE(TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF'), ':');
      
        --Payment Type Code
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_PAYTYPE_CODE',
                                   CASE L_CUST_DRAC_CCY
                                     WHEN 'USD' THEN
                                      FN_GET_PARAM_VAL('NCS_PAY_TYPE_CODE_USD')
                                     WHEN 'KHR' THEN
                                      FN_GET_PARAM_VAL('NCS_PAY_TYPE_CODE_KHR')
                                   
                                   END);
      
        --Serial No
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_SERIAL_NO',
                                   --'ODT' || TO_CHAR(G.TRN_DATE, 'YYMMDD') || '0001'
                                   p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO);
      
        --Payment Date
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_PAYMNT_DATE',
                                   --TO_CHAR(G.TRN_DATE, 'DDMMYYYY')
                                   TO_CHAR(SYSDATE, 'DDMMYYYY'));
      
        --Payer Account No
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_DR_ACC_NO',
                                   p_ifdncsft.v_iftbs_ncs_master.REM_ACC);
      
        --Currency Code
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_CUST_DRAC_CCY',
                                   L_CUST_DRAC_CCY);
      
        --Amount
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_TXN_AMOUNT',
                                   p_ifdncsft.v_iftbs_ncs_master.TXN_AMT);
      
        --Payer Name
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$PAYER_NAME',
                                   p_ifdncsft.v_iftbs_ncs_master.rem_name);
      
        --Payee Name
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_CR_CUST_NAME',
                                   p_ifdncsft.v_iftbs_ncs_master.ben_name);
      
        --Credit Account
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_CR_ACC_NO',
                                   p_ifdncsft.v_iftbs_ncs_master.ben_acc);
      
        --Payee Bank
        
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_BEN_BIC',
                                   FN_GET_EXTERNAL_CODE(p_ifdncsft.v_iftbs_ncs_master.ben_bic));
      
        --Processing Date
        /*IF TO_CHAR(G.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') >= '08:00' AND
        
           TO_CHAR(G.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') <= '12:00' THEN
        
          L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                     '$L_PROC_DATE',
                                     TO_CHAR(G.VALUE_DATE, 'DDMMYYYY'));
        
        ELSE
        
          L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                     '$L_PROC_DATE',
                                     TO_CHAR(G.VALUE_DATE + 1, 'DDMMYYYY'));
        
        END IF;*/
      
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_PROC_DATE',
                                   --TO_CHAR(G.PROCESSING_DATE, 'DDMMYYYY') --see value date from webservice response
                                   TO_CHAR(SYSDATE, 'DDMMYYYY'));
      
        L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
      
        DBG('DONE WITH GENERATING CLOB RESPONSE');
      
        --Write to output file
        DBG('START OF WRITING CLOB TO AN XML FILE');
      
        PR_WRITE_SDR_TXN_TO_FILE('NCS_SDR_OUT_FILE_GEN',
                                 L_FILE_NAME || '.xml',
                                 L_RESP_CLOB);
      
        --Write to Archive Path
        DBG('START OF WRITING CLOB TO AN XML FILE FOR ARCHIVE PATH');
      
        PR_WRITE_SDR_TXN_TO_FILE('NCS_SDR_OUT_FILE_GEN_AR',
                                 L_FILE_NAME || '.xml',
                                 L_RESP_CLOB);
      
        DBG('END OF WRITING CLOB TO AN XML FILE');
      
      END IF;
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdncsft_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdncsft         IN ifpks_ifdncsft_Main.ty_ifdncsft,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdncsft_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdncsft         IN ifpks_ifdncsft_Main.ty_ifdncsft,
                                       p_Prev_ifdncsft    IN OUT ifpks_ifdncsft_Main.ty_ifdncsft,
                                       p_Wrk_ifdncsft     IN OUT ifpks_ifdncsft_Main.ty_ifdncsft,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_XML            VARCHAR2(32767);
    L_RESPONSE       VARCHAR2(32767) := '';
    L_SETTLEMENT_ACC IFTB_NCS_MASTER.REM_ACC%TYPE;
    L_CUST_DRAC_CCY  STTM_CORE_ACCOUNT.CUST_AC_CCY%TYPE;
  
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
  
    /* L_MID_RATE  CYTM_RATES.MID_RATE%TYPE;
    L_BUY_RATE  CYTM_RATES.BUY_RATE%TYPE;
    L_SALE_RATE CYTM_RATES.SALE_RATE%TYPE;
    L_EXCH_RATE IFTB_NCS_MASTER.EXCH_RATE%TYPE;*/
  
    l_txn_amt IFTB_NCS_MASTER.txn_amt%TYPE;
  
    L_COMM_FEE_P         IFTB_NCS_MASTER.txn_amt%TYPE;
    L_COMM_MIN_FEE       IFTB_NCS_MASTER.txn_amt%TYPE;
    L_COMM_FEE           IFTB_NCS_MASTER.txn_amt%TYPE;
    l_chg_amt            IFTB_NCS_MASTER.txn_amt%TYPE;
    l_final_chg_amt      IFTB_NCS_MASTER.txn_amt%TYPE;
    l_chg_amt_in_acc_ccy IFTB_NCS_MASTER.txn_amt%TYPE;
  
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
  
    L_STATUS_MSG VARCHAR2(105);
    L_ERROR_DESC VARCHAR2(255);
  
    /*  TYPE TYPE_EXCHANGE_RATES_LIST IS TABLE OF CYTB_RATES_CUSTOM%ROWTYPE;
    L_EXCHANGE_RATES_LIST TYPE_EXCHANGE_RATES_LIST;
    
    */
  
    L_TRN_REF_NO IFTB_NCS_MASTER.TRN_REF_NO%TYPE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    IF P_ACTION_CODE = 'PICKUP' THEN
    
      /* --Default Account Name Enquiry
      --Get RFT Out Payment Account Enquiry
      L_FORMATTED_MSG := FN_RETURN_FORMATTED_ACC_ENQ(P_IFDRFTPM);
      
      DBG('AFTER REPLACEMENT OF RFT OUT ACC ENQUIRY JSON=' ||
          L_FORMATTED_MSG);
      
      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
      
      L_MSG_TYPE  := 'ACCENQUIRY';
      L_ADDL_INFO := 'Account Enquiry Call';
      
      DBG('CALLING RFT ACCOUNT ENQUIRY WEBSERVICE');
      
      IF NOT FN_MSG_UPLOAD(P_SOURCE,
                           P_FUNCTION_ID,
                           P_IFDRFTPM,
                           L_FORMATTED_MSG,
                           'I', --ACCOUNT ENQUIRY
                           L_MSG_TYPE,
                           L_ADDL_INFO,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      
        DBG('FAILED IN ACCOUNT ENQUIRY CALL');
      
        --Update the table
        PR_UPDATE_RFT_WS_LOG(P_IFDRFTPM.V_IFTBS_RFT_MASTER.TRN_REF_NO,
                             L_GEN_SEQ_NO,
                             P_ERR_CODE,
                             P_ERR_PARAMS);
      
        RETURN FALSE;
      
      ELSE
      
        DBG('SUCCESS IN ACCOUNT ENQUIRY CALL');
      
        IF p_ifdrftpm.v_iftbs_rft_master.ben_name IS NULL THEN
        
          DBG('FAILED IN ACCOUNT ENQUIRY CALL');
          pr_log_error(p_function_id, p_source, 'IF-RFT-018', NULL);
          RETURN FALSE;
        
        END IF;
      
      END IF;*/
    
      /*  L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSCcyService">
         <soapenv:Header/>
         <soapenv:Body>
            <fcub:QUERYCYDRATEE_IOFS_REQ>
               <fcub:FCUBS_HEADER>
                  <fcub:SOURCE>OBPAY</fcub:SOURCE>
                  <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
                  <fcub:USERID>OBPAYUSER</fcub:USERID>
                  <fcub:BRANCH>001</fcub:BRANCH>
                  <fcub:SERVICE>FCUBSCcyService</fcub:SERVICE>
                  <fcub:OPERATION>QueryCYDRATEE</fcub:OPERATION>
               </fcub:FCUBS_HEADER>
               <fcub:FCUBS_BODY>
                  <fcub:Ccy-Rate-Master-IO>
                     <fcub:CCY1>USD</fcub:CCY1>
                     <fcub:CCY2>KHR</fcub:CCY2>
                  </fcub:Ccy-Rate-Master-IO>
               </fcub:FCUBS_BODY>
            </fcub:QUERYCYDRATEE_IOFS_REQ>
         </soapenv:Body>
      </soapenv:Envelope>';
          
            L_RESPONSE := process_http('http://10.80.80.79:8007/' ||
                                       'FCUBSCcyService/FCUBSCcyService',
                                       L_XML,
                                       'text/xml;charset=utf-8');
          
            DBG('L_RESPONSE OF EXCHANGE RATES=' || L_RESPONSE);
          
            PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
          
            DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
          
            P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
          
            --Check if returned error or success
            L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                            .GETSTRINGVAL;
          
            IF L_STATUS_MSG <> 'SUCCESS' THEN
            
              L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                              .GETSTRINGVAL;
            
              Pr_Log_Error(p_Function_id, p_Source, 'IF-NCS001', L_ERROR_DESC); --pls put the error code
            
              RETURN FALSE;
            
            ELSE
              
             --Get list of bank ids and names
             
             
                BEGIN
                  WITH t(xml) AS
                   (SELECT xmltype(L_FORMATTED_RES_MSG) FROM DUAL)
                  SELECT x.*
                    BULK COLLECT
                    INTO L_EXCHANGE_RATES_LIST
                    FROM t,
                         xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                                "nq1"),
                                  '/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details' passing
                                  t.xml columns 
                                  RATE_TYPE varchar2(50) PATH 'RATETYPE',
                                  MID_RATE varchar2(50) PATH 'MIDRATE',
                                  BUY_RATE VARCHAR2(50) PATH 'BUYRATE',
                                  SALE_RATE VARCHAR2(50) PATH 'SALERATE') x;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    DEBUG.PR_DEBUG('IF',
                                   'ERROR CODE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                                   SQLCODE);
                    DEBUG.PR_DEBUG('IF',
                                   'ERROR MESSAGE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                                   SQLERRM);
                END;
                Debug.Pr_Debug('IF', 'COUNT=' || L_EXCHANGE_RATES_LIST.COUNT);
                
                DBG('L_EXCHANGE_RATES_LIST.RATE_TYPE='||L_EXCHANGE_RATES_LIST(1).RATE_TYPE);
                DBG('L_EXCHANGE_RATES_LIST.BUY_RATE='||L_EXCHANGE_RATES_LIST(1).BUY_RATE);
                DBG('L_EXCHANGE_RATES_LIST.MID_RATE='||L_EXCHANGE_RATES_LIST(1).MID_RATE);
                DBG('L_EXCHANGE_RATES_LIST.SALE_RATE='||L_EXCHANGE_RATES_LIST(1).SALE_RATE);
                
                IF L_EXCHANGE_RATES_LIST.COUNT > 0 THEN
                  
                BEGIN
                    FOR K IN 1 .. L_EXCHANGE_RATES_LIST.COUNT LOOP
                    Debug.Pr_Debug('IF',
                                     'RATE_TYPE=' || L_EXCHANGE_RATES_LIST(K).RATE_TYPE || ' ' ||
                                     'MID RATE=' || L_EXCHANGE_RATES_LIST(K).MID_RATE || ' '||
                                     'BUY RATE=' || L_EXCHANGE_RATES_LIST(K).BUY_RATE || ' '||
                                     'SALE RATE=' || L_EXCHANGE_RATES_LIST(K).SALE_RATE);
                
                IF   L_EXCHANGE_RATES_LIST(K).RATE_TYPE = 'COMM' THEN
                
                  L_MID_RATE := L_EXCHANGE_RATES_LIST(K).MID_RATE;
                  L_BUY_RATE := L_EXCHANGE_RATES_LIST(K).BUY_RATE;
                  L_SALE_RATE := L_EXCHANGE_RATES_LIST(K).SALE_RATE;
                  
                
                END IF;
                
                END LOOP;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
                      DBG('ERROR CODE=' || SQLCODE);
                      DBG('ERROR MESSAGE=' || SQLERRM);
                  END;
                  
                END IF;
                
               
                
            
              --Get Mid Rate    
            \*  L_MID_RATE := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details/MIDRATE//text()')
                            .GETSTRINGVAL;*\
              DBG('L_MID_RATE=' || L_MID_RATE);
            
              --Get Buy Rate    
             \* L_BUY_RATE := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details/BUYRATE//text()')
                            .GETSTRINGVAL;*\
              DBG('L_BUY_RATE=' || L_BUY_RATE);
            
              --Get Sale Rate    
              \*L_SALE_RATE := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details/SALERATE//text()')
                             .GETSTRINGVAL;*\
              DBG('L_SALE_RATE=' || L_SALE_RATE);
            
            END IF;
          
            BEGIN
            
              SELECT A.CUST_AC_CCY
                INTO L_CUST_DRAC_CCY
                FROM STTM_CORE_ACCOUNT A
               WHERE A.CUST_ACCOUNT_NO = p_ifdncsft.v_iftbs_ncs_master.rem_acc;
            
            EXCEPTION
              WHEN OTHERS THEN
                L_CUST_DRAC_CCY := NULL;
            END;
          
            IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'KHR' AND
               L_CUST_DRAC_CCY = 'KHR' THEN
            
              L_EXCH_RATE := L_MID_RATE;
            
            ELSIF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'KHR' AND
                  L_CUST_DRAC_CCY = 'USD' THEN
            
              L_EXCH_RATE := L_BUY_RATE;
            
            ELSIF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY = 'USD' AND
                  L_CUST_DRAC_CCY = 'KHR' THEN
            
              L_EXCH_RATE := L_SALE_RATE;
            
            ELSE
            
              L_EXCH_RATE := 1;
            
            END IF;
            
            DBG('L_EXCH_RATE='||L_EXCH_RATE);
          
            P_WRK_IFDNCSFT.V_IFTBS_NCS_MASTER.EXCH_RATE := L_EXCH_RATE;
          
            --Main Transaction Calculation
            IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY <> L_CUST_DRAC_CCY THEN
            
              IF NOT cypkss.FN_AMT1_TO_AMT2(P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY,
                                            L_CUST_DRAC_CCY,
                                            P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT,
                                            P_IFDNCSFT.V_IFTBS_NCS_MASTER.exch_rate,
                                            'Y',
                                            l_txn_amt,
                                            p_err_params) THEN
                RETURN FALSE;
              
              ELSE
              
                DBG('l_txn_amt after =' || l_txn_amt);
              
              END IF;
            
              --Fee Processing
              IF NOT cypkss.FN_AMT1_TO_AMT2(P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY,
                                            L_CUST_DRAC_CCY,
                                            l_chg_amt,
                                            P_IFDNCSFT.V_IFTBS_NCS_MASTER.exch_rate,
                                            'Y',
                                            l_final_chg_amt,
                                            p_err_params) THEN
                RETURN FALSE;
              
              ELSE
              
                DBG('l_final_chg_amt after =' || l_final_chg_amt);
              
              END IF;
            
            ELSE
            
              l_txn_amt := P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT;
            
              DBG('l_txn_amt =' || l_txn_amt);
            
            END IF;
          
            --Charge Calculation
            IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_CCY <> L_CUST_DRAC_CCY THEN
            
              IF P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT > 0 THEN
              
                --Get Percentage
                L_COMM_FEE_P := FN_GET_PARAM_VAL('NCS_MIN_FEE_PERCENTAGE');
              
                --Get Min Fee
                L_COMM_MIN_FEE := FN_GET_PARAM_VAL('NCS_MIN_FEE_USD');
              
                IF L_CUST_DRAC_CCY = 'USD' THEN
                  --here transaction currency is KHR and account currency is USD
                
                  L_COMM_FEE := (L_COMM_FEE_P * l_txn_amt) / 100;
                
                  IF L_COMM_FEE > L_COMM_MIN_FEE THEN
                  
                    l_chg_amt := L_COMM_FEE;
                  
                  ELSE
                  
                    l_chg_amt := L_COMM_MIN_FEE;
                  
                  END IF;
                
                  DBG('l_chg_amt IN USD=' || l_chg_amt);
                
                ELSE
                  --here transaction currency is USD and account currency is KHR
                
                  L_COMM_FEE := (L_COMM_FEE_P *
                                P_IFDNCSFT.V_IFTBS_NCS_MASTER.TXN_AMT) / 100;
                
                  IF L_COMM_FEE > L_COMM_MIN_FEE THEN
                  
                    l_chg_amt := L_COMM_FEE;
                  
                  ELSE
                  
                    l_chg_amt := L_COMM_MIN_FEE;
                  
                  END IF;
                
                  --Get Equivalent charge from account currency
                  l_chg_amt_in_acc_ccy := (L_EXCH_RATE) * l_chg_amt;
                
                  l_chg_amt := l_chg_amt_in_acc_ccy;
                
                  DBG('l_chg_amt IN KHR=' || l_chg_amt);
                
                END IF;
              
              END IF;
            
            END IF;*/
      null;
    
    END IF;
  
    /*IF p_Action_Code = 'AUTH' THEN
        
          --call ws
          L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSRTService">
       <soapenv:Header/>
       <soapenv:Body>
          <fcub:CREATETRANSACTION_FSFS_REQ>
             <fcub:FCUBS_HEADER>
                <fcub:SOURCE>OBPAY</fcub:SOURCE>
                <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
                <fcub:MSGID></fcub:MSGID>
                <fcub:CORRELID></fcub:CORRELID>
                <fcub:USERID>OBPAYUSER</fcub:USERID>
                <fcub:ENTITY></fcub:ENTITY>
                <fcub:BRANCH>'||GLOBAL.current_branch||'</fcub:BRANCH>
                <fcub:MODULEID></fcub:MODULEID>
                <fcub:SERVICE>FCUBSRTService</fcub:SERVICE>
                <fcub:OPERATION>CreateTransaction</fcub:OPERATION>
             </fcub:FCUBS_HEADER>
             <fcub:FCUBS_BODY>
                <fcub:Transaction-Details>
                   <fcub:XREF></fcub:XREF>
                   <fcub:FCCREF></fcub:FCCREF>
                   <fcub:PRD>NCSF</fcub:PRD>
                   <fcub:ESN></fcub:ESN>
                   <fcub:EVNTCD></fcub:EVNTCD>
                   <fcub:BRN>BRN</fcub:BRN>
                   <fcub:MODULE></fcub:MODULE>
                   <fcub:TXNBRN>BRN</fcub:TXNBRN>
                   <fcub:TXNACC>$L_CUST_DRAC_NO</fcub:TXNACC>
                   <fcub:TXNCCY>$L_CUST_DRAC_CCY</fcub:TXNCCY>
                   <fcub:TXNAMT>$L_TXN_AMT</fcub:TXNAMT>
                   <fcub:TXNTRN></fcub:TXNTRN>
                   <fcub:CREDITCARDNO></fcub:CREDITCARDNO>
                   <fcub:CC_HOLDER_NAME></fcub:CC_HOLDER_NAME>
                   <fcub:OFFSETBRN>991</fcub:OFFSETBRN>
                   <fcub:OFFSETACC>$L_SETTLEMENT_ACC</fcub:OFFSETACC>
                   <fcub:OFFSETCCY>$L_SETTLEMENT_CCY</fcub:OFFSETCCY>
                   <fcub:OFFSETAMT></fcub:OFFSETAMT>
                   <fcub:OFFSETTRN></fcub:OFFSETTRN>
                   <fcub:XRATE>1</fcub:XRATE>
                   <fcub:SDBREFNO></fcub:SDBREFNO>
                   <fcub:Charge-Details>
                      <fcub:CHGCOMP>NCS FEE</fcub:CHGCOMP>
                      <fcub:WAIVER></fcub:WAIVER>
                      <fcub:CHGAMT>$L_CHG_AMT</fcub:CHGAMT>
                      <fcub:CHGCCY>$L_CHG_CCY</fcub:CHGCCY>
                   </fcub:Charge-Details>
                   
                </fcub:Transaction-Details>
             </fcub:FCUBS_BODY>
          </fcub:CREATETRANSACTION_FSFS_REQ>
       </soapenv:Body>
    </soapenv:Envelope>';
        
          IF p_ifdncsft.v_iftbs_ncs_master.txn_ccy = 'KHR' THEN
          
            BEGIN
            
              SELECT A.PARAM_VAL
                INTO L_SETTLEMENT_ACC
                FROM CSTB_PARAM_CUSTOM A
               WHERE A.PARAM_NAME = 'NCS_TXN_ACC_KHR';
            
            EXCEPTION
              WHEN OTHERS THEN
                L_SETTLEMENT_ACC := '000021069';
            END;
          
          ELSIF p_ifdncsft.v_iftbs_ncs_master.txn_ccy = 'USD' THEN
          
            BEGIN
            
              SELECT A.PARAM_VAL
                INTO L_SETTLEMENT_ACC
                FROM CSTB_PARAM_CUSTOM A
               WHERE A.PARAM_NAME = 'NCS_TXN_ACC_USD';
            
            EXCEPTION
              WHEN OTHERS THEN
                L_SETTLEMENT_ACC := '000021058';
            END;
          
          END IF;
        
          --L_XML := REPLACE(L_XML, '$L_BRANCH_CODE', L_CUST_ACCOUNT.BRANCH_CODE);
        
          L_XML := REPLACE(L_XML,
                           '$L_CUST_DRAC_NO',
                           p_ifdncsft.v_iftbs_ncs_master.rem_acc);
        
          BEGIN
          
            SELECT A.CUST_AC_CCY
              INTO L_CUST_DRAC_CCY
              FROM STTM_CORE_ACCOUNT A
             WHERE A.CUST_ACCOUNT_NO = p_ifdncsft.v_iftbs_ncs_master.rem_acc;
          
          EXCEPTION
            WHEN OTHERS THEN
              L_CUST_DRAC_CCY := NULL;
          END;
        
          DBG('L_CUST_DRAC_CCY=' || L_CUST_DRAC_CCY);
        
          L_XML := REPLACE(L_XML, '$L_CUST_DRAC_CCY', L_CUST_DRAC_CCY);
        
          L_XML := REPLACE(L_XML,
                           '$L_TXN_AMT',
                           p_ifdncsft.v_iftbs_ncs_master.TXN_AMT);
        
          L_XML := REPLACE(L_XML, '$L_SETTLEMENT_ACC', L_SETTLEMENT_ACC);
          L_XML := REPLACE(L_XML,
                           '$L_SETTLEMENT_CCY',
                           p_ifdncsft.v_iftbs_ncs_master.TXN_CCY);
        
          L_XML := REPLACE(L_XML,
                           '$L_CHG_AMT',
                           P_IFDNCSFT.V_IFTBS_NCS_MASTER.TOT_CHG_AMT);
        
          L_XML := REPLACE(L_XML, '$L_CHG_CCY', L_CUST_DRAC_CCY);
        
          DBG('Final Request xml=' || L_XML);
        
          L_RESPONSE := process_http('http://10.80.80.79:8007/' ||
                                     'FCUBSRTService/FCUBSRTService',
                                     L_XML,
                                     'text/xml;charset=utf-8');
        
          DBG('L_RESPONSE=' || L_RESPONSE);
        
          --Get Cosmetic XML
          PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
        
          DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
        
          P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
        
          --Check if returned error or success
          L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                          .GETSTRINGVAL;
          
          
          
          IF L_STATUS_MSG <> 'SUCCESS' THEN
          
            L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                            .GETSTRINGVAL;
          
            Pr_Log_Error(p_Function_id, p_Source, 'IF-NCS001', L_ERROR_DESC); --pls put the error code
          
            RETURN FALSE;
          
          ELSE
            
           
           L_TRN_REF_NO := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/FCCREF/text()')
                            .GETSTRINGVAL;
          
           p_WRK_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO := L_TRN_REF_NO;
           
            L_RESP_TEMPLATE := FN_GET_SDR_TEMPLATE;
          
            --File Name
            L_FILE_NAME := 'NCSF_SDR_FILE_' ||
                           REPLACE(TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF'), ':');
          
            --Payment Type Code
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_PAYTYPE_CODE',
                                       CASE L_CUST_DRAC_CCY
                                         WHEN 'USD' THEN
                                          FN_GET_PARAM_VAL('NCS_PAY_TYPE_CODE_USD')
                                         WHEN 'KHR' THEN
                                          FN_GET_PARAM_VAL('NCS_PAY_TYPE_CODE_KHR')
                                       
                                       END);
          
            --Serial No
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_SERIAL_NO',
                                       --'ODT' || TO_CHAR(G.TRN_DATE, 'YYMMDD') || '0001'
                                       p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO);
          
            --Payment Date
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_PAYMNT_DATE',
                                       --TO_CHAR(G.TRN_DATE, 'DDMMYYYY')
                                       TO_CHAR(SYSDATE, 'DDMMYYYY'));
          
            --Payer Account No
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_DR_ACC_NO',
                                       p_ifdncsft.v_iftbs_ncs_master.REM_ACC);
          
            --Currency Code
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_CUST_DRAC_CCY',
                                       L_CUST_DRAC_CCY);
          
            --Amount
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_TXN_AMOUNT',
                                       p_ifdncsft.v_iftbs_ncs_master.TXN_AMT);
          
            --Payer Name
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$PAYER_NAME',
                                       p_ifdncsft.v_iftbs_ncs_master.rem_name);
          
            --Payee Name
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_CR_CUST_NAME',
                                       p_ifdncsft.v_iftbs_ncs_master.ben_name);
          
            --Credit Account
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_CR_ACC_NO',
                                       p_ifdncsft.v_iftbs_ncs_master.ben_acc);
          
            --Payee Bank
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_BEN_BIC',
                                       p_ifdncsft.v_iftbs_ncs_master.ben_bic);
          
            --Processing Date
            \*IF TO_CHAR(G.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') >= '08:00' AND
            
               TO_CHAR(G.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') <= '12:00' THEN
            
              L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                         '$L_PROC_DATE',
                                         TO_CHAR(G.VALUE_DATE, 'DDMMYYYY'));
            
            ELSE
            
              L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                         '$L_PROC_DATE',
                                         TO_CHAR(G.VALUE_DATE + 1, 'DDMMYYYY'));
            
            END IF;*\
          
            L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                       '$L_PROC_DATE',
                                       --TO_CHAR(G.PROCESSING_DATE, 'DDMMYYYY') --see value date from webservice response
                                       TO_CHAR(SYSDATE, 'DDMMYYYY'));
          
            L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
          
            DBG('DONE WITH GENERATING CLOB RESPONSE');
          
            --Write to output file
            DBG('START OF WRITING CLOB TO AN XML FILE');
          
            PR_WRITE_SDR_TXN_TO_FILE('NCS_SDR_OUT_FILE_GEN',
                                     L_FILE_NAME || '.xml',
                                     L_RESP_CLOB);
          
            --Write to Archive Path
            DBG('START OF WRITING CLOB TO AN XML FILE FOR ARCHIVE PATH');
          
            PR_WRITE_SDR_TXN_TO_FILE('NCS_SDR_OUT_FILE_GEN_AR',
                                     L_FILE_NAME || '.xml',
                                     L_RESP_CLOB);
          
            DBG('END OF WRITING CLOB TO AN XML FILE');
          
          END IF;
        
        END IF;*/
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdncsft_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdncsft         IN ifpks_ifdncsft_Main.Ty_ifdncsft,
                                        p_Prev_ifdncsft    IN OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
                                        p_Wrk_ifdncsft     IN OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
   
  
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdncsft_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdncsft         IN ifpks_ifdncsft_Main.Ty_ifdncsft,
                            p_Prev_ifdncsft    IN ifpks_ifdncsft_Main.Ty_ifdncsft,
                            p_Wrk_ifdncsft     IN OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_TRN_REF_NO IFTB_NCS_MASTER.TRN_REF_NO%TYPE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdncsft_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdncsft         IN ifpks_ifdncsft_Main.Ty_ifdncsft,
                             p_prev_ifdncsft    IN ifpks_ifdncsft_Main.Ty_ifdncsft,
                             p_wrk_ifdncsft     IN OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
    
    IF P_ACTION_CODE = 'AUTH' THEN
    DBG('p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO=' || p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO);
    
    UPDATE IFTB_NCS_MASTER A SET A.TRN_REF_NO = p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO
    WHERE A.RELATED_REF_NO = p_ifdncsft.v_iftbs_ncs_master.RELATED_REF_NO;
    END IF;
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdncsft_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdncsft         IN ifpks_ifdncsft_Main.Ty_ifdncsft,
                        p_Wrk_ifdncsft     IN OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
   
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdncsft_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdncsft         IN ifpks_ifdncsft_Main.ty_ifdncsft,
                         p_wrk_ifdncsft     IN OUT ifpks_ifdncsft_Main.ty_ifdncsft,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
    
     
    DBG('p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO='||p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO);
    
 
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdncsft_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdncsft_custom;
