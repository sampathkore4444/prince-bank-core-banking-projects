prompt Importing table cotm_source...
set feedback off
set define off
insert into cotm_source (SOURCE_CODE, SOURCE_DESC, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, BASE_DATA_FROM_FC, SYS_AUTH_REQ)
values ('OBPAY', 'Oracle Banking Payment Source', 'O', 'A', 'Y', 1, 'SAMPATH2', to_date('03-04-2021 10:22:07', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('03-04-2021 10:22:07', 'dd-mm-yyyy hh24:mi:ss'), 'N', 'N');

prompt Done.
