prompt Importing table GWTM_EXT_SYS_FUNCTIONS...
set feedback off
set define off
insert into GWTM_EXT_SYS_FUNCTIONS (EXT_SYSTEM, FUNCTION_ID, ACTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, ONCE_AUTH, AUTH_STAT, RECORD_STAT, MOD_NO, BULK_SMS_CHK_REQ)
values ('OBPAY', 'CYQRATEE', 'VIEW', 'SAMPATH2', 'SAMPATH2', to_date('03-04-2021 10:22:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-04-2021 10:22:05', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'A', 'O', 1, 'N');

insert into GWTM_EXT_SYS_FUNCTIONS (EXT_SYSTEM, FUNCTION_ID, ACTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, ONCE_AUTH, AUTH_STAT, RECORD_STAT, MOD_NO, BULK_SMS_CHK_REQ)
values ('OBPAY', 'DEGRTTLR', 'AUTHORIZE', 'SAMPATH2', 'SAMPATH2', to_date('03-04-2021 10:30:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-04-2021 10:30:49', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'A', 'O', 1, 'N');

insert into GWTM_EXT_SYS_FUNCTIONS (EXT_SYSTEM, FUNCTION_ID, ACTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, ONCE_AUTH, AUTH_STAT, RECORD_STAT, MOD_NO, BULK_SMS_CHK_REQ)
values ('OBPAY', 'DEGRTTLR', 'NEW', 'SAMPATH2', 'SAMPATH2', to_date('03-04-2021 10:25:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-04-2021 10:25:56', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'A', 'O', 1, 'N');

insert into GWTM_EXT_SYS_FUNCTIONS (EXT_SYSTEM, FUNCTION_ID, ACTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, ONCE_AUTH, AUTH_STAT, RECORD_STAT, MOD_NO, BULK_SMS_CHK_REQ)
values ('OBPAY', 'DEGRTTLR', 'VIEW', 'SAMPATH2', 'SAMPATH2', to_date('03-04-2021 10:30:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-04-2021 10:30:39', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'A', 'O', 1, 'N');

prompt Done.
