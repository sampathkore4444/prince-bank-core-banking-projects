create or replace and compile java source named directorylistner as
import java.io.File;
import java.util.Arrays;
public class DirectoryListner
{
  public static String getFileList(String idir)
  {

  String result = "";
    try
  {
  File aDirectory = new File(idir);
    File[] filesInDir = aDirectory.listFiles();

    for ( int i=0; i<filesInDir.length; i++ )
    {
        if ( filesInDir[i].isFile()
             & !filesInDir[i].isHidden() )
        {
            result = result + filesInDir[i].getName();
        }
    }

  }
  catch(Exception e)
  {
    result = result + e.toString();
  }

  return result;

  }
}


