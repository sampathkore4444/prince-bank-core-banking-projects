-- Create table
create table IFTB_NCS_INCOMING_TRACK
(
  serial_no         VARCHAR2(105),
  payment_type_code VARCHAR2(25),
  payment_date      DATE,
  payer_bank        VARCHAR2(25),
  payer_check_digit VARCHAR2(10),
  payer_account_no  VARCHAR2(25),
  txn_ccy           VARCHAR2(3),
  txn_amount        NUMBER(22,3),
  security_code     VARCHAR2(25),
  payer_name        VARCHAR2(255),
  payer_ref         VARCHAR2(105),
  payee_bank        VARCHAR2(25),
  payee_check_digit VARCHAR2(10),
  payee_account_no  VARCHAR2(25),
  payee_name        VARCHAR2(255),
  payee_ref         VARCHAR2(105),
  return_code       VARCHAR2(25),
  input_date        DATE,
  processing_date   DATE,
  input_batch_no    VARCHAR2(25),
  output_batch_no   VARCHAR2(25),
  file_name         VARCHAR2(100),
  time_in           DATE,
  request_msg       CLOB,
  status            CHAR(1),
  file_date         DATE
)
/
alter table IFTB_NCS_INCOMING_TRACK add primary key (SERIAL_NO)
/
-- Create table
create table IFTB_NCS_INC_TRACK
(
  serial_no         VARCHAR2(105),
  payment_type_code VARCHAR2(25),
  payment_date      DATE,
  payer_bank        VARCHAR2(25),
  payer_check_digit VARCHAR2(10),
  payer_account_no  VARCHAR2(25),
  txn_ccy           VARCHAR2(3),
  txn_amount        NUMBER(22,3),
  security_code     VARCHAR2(25),
  payer_name        VARCHAR2(255),
  payer_ref         VARCHAR2(105),
  payee_bank        VARCHAR2(25),
  payee_check_digit VARCHAR2(10),
  payee_account_no  VARCHAR2(25),
  payee_name        VARCHAR2(255),
  payee_ref         VARCHAR2(105),
  return_code       VARCHAR2(25),
  input_date        DATE,
  processing_date   DATE,
  input_batch_no    VARCHAR2(25),
  output_batch_no   VARCHAR2(25),
  file_name         VARCHAR2(100),
  time_in           DATE,
  request_msg       CLOB,
  status            CHAR(1),
  file_date         DATE
)
/
-- Create table
create table IFTB_NCS_SERIAL_NO_LOG
(
  serial_no         VARCHAR2(16),
  trn_ref_no        VARCHAR2(16),
  status            CHAR(1),
  error_code        VARCHAR2(11),
  error_param       VARCHAR2(4000),
  invoke_date_start DATE,
  invoke_date_end   DATE
)
/
alter table IFTB_NCS_SERIAL_NO_LOG add primary key (SERIAL_NO)
/