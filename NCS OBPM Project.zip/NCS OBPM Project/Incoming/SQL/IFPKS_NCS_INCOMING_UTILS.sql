CREATE OR REPLACE PACKAGE BODY IFPKS_NCS_INCOMING_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_NCS_INCOMING_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE PR_GET_FORMATTED_XML(P_XML           IN VARCHAR2,
                                 P_FORMATTED_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_FORMATTED_XML := P_XML;
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '<S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSCcyService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSRTService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '   </S:Body>', NULL);
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Envelope>', NULL);
  
  END PR_GET_FORMATTED_XML;

  FUNCTION FN_GET_PAYMENT_REQ_FORMAT RETURN CLOB IS
  
    L_XML CLOB;
  
  BEGIN
  
    L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSRTService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:CREATETRANSACTION_FSFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>DIGIBANK</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:MSGID></fcub:MSGID>
            <fcub:CORRELID></fcub:CORRELID>
            <fcub:USERID>DIGIUSER1</fcub:USERID>
            <fcub:ENTITY></fcub:ENTITY>
            <fcub:BRANCH>' || GLOBAL.current_branch ||
             '</fcub:BRANCH>
            <fcub:MODULEID></fcub:MODULEID>
            <fcub:SERVICE>FCUBSRTService</fcub:SERVICE>
            <fcub:OPERATION>CreateTransaction</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Transaction-Details>
               <fcub:XREF></fcub:XREF>
               <fcub:FCCREF></fcub:FCCREF>
               <fcub:PRD>NCSI</fcub:PRD>
               <fcub:ESN></fcub:ESN>
               <fcub:EVNTCD></fcub:EVNTCD>
               <fcub:BRN>BRN</fcub:BRN>
               <fcub:MODULE></fcub:MODULE>
               <fcub:TXNBRN>BRN</fcub:TXNBRN>
               <fcub:TXNACC>$L_CUST_CRAC_NO</fcub:TXNACC>
               <fcub:TXNCCY>$L_CUST_CRAC_CCY</fcub:TXNCCY>
               <fcub:TXNAMT>$L_TXN_AMT</fcub:TXNAMT>
               <fcub:TXNTRN></fcub:TXNTRN>
               <fcub:CREDITCARDNO></fcub:CREDITCARDNO>
               <fcub:CC_HOLDER_NAME></fcub:CC_HOLDER_NAME>
               <fcub:OFFSETBRN>991</fcub:OFFSETBRN>
               <fcub:OFFSETACC>$L_SETTLEMENT_ACC</fcub:OFFSETACC>
               <fcub:OFFSETCCY>$L_SETTLEMENT_CCY</fcub:OFFSETCCY>
               <fcub:OFFSETAMT>$L_OFFSET_AMT</fcub:OFFSETAMT>
               <fcub:OFFSETTRN></fcub:OFFSETTRN>
               <fcub:XRATE>$L_EXCH_RATE</fcub:XRATE>
               <fcub:SDBREFNO></fcub:SDBREFNO>
               
               
            </fcub:Transaction-Details>
         </fcub:FCUBS_BODY>
      </fcub:CREATETRANSACTION_FSFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
  
    RETURN L_XML;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_PAYMENT_REQ_FORMAT');
      DBG('ERROR CODE IN FN_GET_PAYMENT_REQ_FORMAT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_PAYMENT_REQ_FORMAT=' || SQLERRM);
    
  END FN_GET_PAYMENT_REQ_FORMAT;

  FUNCTION FN_GET_RELATED_REF_NO RETURN IFTBS_NCS_MASTER.RELATED_REF_NO%TYPE AS
  
    l_serial_no      VARCHAR2(16);
    L_RELATED_REF_NO IFTBS_NCS_MASTER.RELATED_REF_NO%TYPE;
    p_Err_Code       VARCHAR2(16);
  
  BEGIN
  
    IF NOT trpks_core.fn_get_product_refno(GLOBAL.current_branch,
                                           'OBPM',
                                           GLOBAL.application_date,
                                           l_serial_no,
                                           L_RELATED_REF_NO,
                                           p_err_code) THEN
      dbg('Failed in generation Transaction Ref No');
      RETURN L_RELATED_REF_NO;
    ELSE
      dbg('L_RELATED_REF_NO=' || L_RELATED_REF_NO);
    
      RETURN L_RELATED_REF_NO;
    
    END IF;
  
  EXCEPTION
  
    WHEN OTHERS THEN
    
      DBG('FAILED IN FN_GET_RELATED_REF_NO');
      DBG('ERROR CODE IN FN_GET_RELATED_REF_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_RELATED_REF_NO=' || SQLERRM);
    
      RETURN L_RELATED_REF_NO;
    
  END FN_GET_RELATED_REF_NO;

  FUNCTION FN_GET_ONLINE_EXCHANGE_RATES(P_CCY1          IN VARCHAR2, --txn ccy sdr file currency
                                        P_CCY2          IN VARCHAR2,
                                        P_EXCHANGE_RATE OUT NUMBER)
    RETURN BOOLEAN AS
  
    L_XML               VARCHAR2(32767);
    L_RESPONSE          VARCHAR2(32767) := '';
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
  
    L_MID_RATE  CYTM_RATES.MID_RATE%TYPE;
    L_BUY_RATE  CYTM_RATES.BUY_RATE%TYPE;
    L_SALE_RATE CYTM_RATES.SALE_RATE%TYPE;
    L_EXCH_RATE IFTB_NCS_MASTER.EXCH_RATE%TYPE;
  
    L_STATUS_MSG VARCHAR2(105);
    L_ERROR_DESC VARCHAR2(255);
  
    TYPE TYPE_EXCHANGE_RATES_LIST IS TABLE OF CYTB_RATES_CUSTOM%ROWTYPE;
    L_EXCHANGE_RATES_LIST TYPE_EXCHANGE_RATES_LIST;
  
  BEGIN
  
    L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSCcyService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:QUERYCYDRATEE_IOFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>DIGIBANK</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:USERID>DIGIUSER1</fcub:USERID>
            <fcub:BRANCH>001</fcub:BRANCH>
            <fcub:SERVICE>FCUBSCcyService</fcub:SERVICE>
            <fcub:OPERATION>QueryCYDRATEE</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Ccy-Rate-Master-IO>
               <fcub:CCY1>USD</fcub:CCY1>
               <fcub:CCY2>KHR</fcub:CCY2>
            </fcub:Ccy-Rate-Master-IO>
         </fcub:FCUBS_BODY>
      </fcub:QUERYCYDRATEE_IOFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
  
    L_RESPONSE := process_http('http://10.80.80.79:8007/' ||
                               'FCUBSCcyService/FCUBSCcyService',
                               L_XML,
                               'text/xml;charset=utf-8');
  
    DBG('L_RESPONSE OF EXCHANGE RATES=' || L_RESPONSE);
  
    PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
  
    DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
  
    P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
  
    --Check if returned error or success
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                    .GETSTRINGVAL;
  
    IF L_STATUS_MSG <> 'SUCCESS' THEN
    
      L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                      .GETSTRINGVAL;
    
      RETURN FALSE;
    
    ELSE
    
      --Get list of rates      
    
      BEGIN
        WITH t(xml) AS
         (SELECT xmltype(L_FORMATTED_RES_MSG) FROM DUAL)
        SELECT x.*
          BULK COLLECT
          INTO L_EXCHANGE_RATES_LIST
          FROM t,
               xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                      "nq1"),
                        '/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details'
                        passing t.xml columns RATE_TYPE varchar2(50) PATH
                        'RATETYPE',
                        MID_RATE varchar2(50) PATH 'MIDRATE',
                        BUY_RATE VARCHAR2(50) PATH 'BUYRATE',
                        SALE_RATE VARCHAR2(50) PATH 'SALERATE') x;
      
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IF',
                         'ERROR CODE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                         SQLCODE);
          DEBUG.PR_DEBUG('IF',
                         'ERROR MESSAGE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                         SQLERRM);
      END;
      Debug.Pr_Debug('IF', 'COUNT=' || L_EXCHANGE_RATES_LIST.COUNT);
    
      DBG('L_EXCHANGE_RATES_LIST.RATE_TYPE=' || L_EXCHANGE_RATES_LIST(1)
          .RATE_TYPE);
      DBG('L_EXCHANGE_RATES_LIST.BUY_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .BUY_RATE);
      DBG('L_EXCHANGE_RATES_LIST.MID_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .MID_RATE);
      DBG('L_EXCHANGE_RATES_LIST.SALE_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .SALE_RATE);
    
      IF L_EXCHANGE_RATES_LIST.COUNT > 0 THEN
      
        BEGIN
          FOR K IN 1 .. L_EXCHANGE_RATES_LIST.COUNT LOOP
            Debug.Pr_Debug('IF',
                           'RATE_TYPE=' || L_EXCHANGE_RATES_LIST(K)
                           .RATE_TYPE || ' ' || 'MID RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .MID_RATE || ' ' || 'BUY RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .BUY_RATE || ' ' || 'SALE RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .SALE_RATE);
          
            IF L_EXCHANGE_RATES_LIST(K).RATE_TYPE = 'COMM' THEN
            
              L_MID_RATE  := L_EXCHANGE_RATES_LIST(K).MID_RATE;
              L_BUY_RATE  := L_EXCHANGE_RATES_LIST(K).BUY_RATE;
              L_SALE_RATE := L_EXCHANGE_RATES_LIST(K).SALE_RATE;
            
            END IF;
          
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;
      
      END IF;
    
      IF P_CCY1 = 'KHR' AND P_CCY2 = 'KHR' THEN
      
        L_EXCH_RATE := L_MID_RATE;
      
      ELSIF P_CCY1 = 'KHR' AND P_CCY2 = 'USD' THEN
      
        L_EXCH_RATE := L_BUY_RATE;
      
      ELSIF P_CCY1 = 'USD' AND P_CCY2 = 'KHR' THEN
      
        L_EXCH_RATE := L_SALE_RATE;
      
      ELSE
      
        L_EXCH_RATE := 1;
      
      END IF;
    
      DBG('L_EXCH_RATE=' || L_EXCH_RATE);
    
      P_EXCHANGE_RATE := L_EXCH_RATE;
    
      RETURN TRUE;
    
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_ONLINE_EXCHANGE_RATES');
      DBG('ERROR CODE IN FN_GET_ONLINE_EXCHANGE_RATES=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_ONLINE_EXCHANGE_RATES=' || SQLCODE);
      RETURN FALSE;
  END FN_GET_ONLINE_EXCHANGE_RATES;

  PROCEDURE PR_INSERT_NCS_TXN_MASTER(P_branch_code      IN IFTB_NCS_MASTER.BRANCH_CODE%TYPE,
                                     P_msg_flow         IN IFTB_NCS_MASTER.MSG_FLOW%TYPE,
                                     P_trn_ref_no       IN IFTB_NCS_MASTER.TRN_REF_NO%TYPE,
                                     P_related_ref_no   IN IFTB_NCS_MASTER.RELATED_REF_NO%TYPE,
                                     P_transfer_date    IN IFTB_NCS_MASTER.TRANSFER_DATE%TYPE,
                                     P_txn_ccy          IN IFTB_NCS_MASTER.TXN_CCY%TYPE,
                                     P_txn_amt          IN IFTB_NCS_MASTER.TXN_AMT%TYPE,
                                     P_tot_chg_amt      IN IFTB_NCS_MASTER.TOT_CHG_AMT%TYPE,
                                     P_net_txn_amt      IN IFTB_NCS_MASTER.NET_TXN_AMT%TYPE,
                                     P_exch_rate        IN IFTB_NCS_MASTER.EXCH_RATE%TYPE,
                                     P_rem_acc          IN IFTB_NCS_MASTER.REM_ACC%TYPE,
                                     P_REM_ACC_BRN      IN IFTB_NCS_MASTER.REM_ACC_BRANCH%TYPE,
                                     P_rem_name         IN IFTB_NCS_MASTER.REM_NAME%TYPE,
                                     P_dr_acc_ccy       IN IFTB_NCS_MASTER.DR_ACC_CCY%TYPE,
                                     P_dr_amount        IN IFTB_NCS_MASTER.DR_AMOUNT%TYPE,
                                     P_ben_acc          IN IFTB_NCS_MASTER.BEN_ACC%TYPE,
                                     P_ben_bic          IN IFTB_NCS_MASTER.BEN_BIC%TYPE,
                                     P_ben_name         IN IFTB_NCS_MASTER.BEN_NAME%TYPE,
                                     P_ben_add1         IN IFTB_NCS_MASTER.BEN_ADD1%TYPE,
                                     P_ben_add2         IN IFTB_NCS_MASTER.BEN_ADD2%TYPE,
                                     P_ben_add3         IN IFTB_NCS_MASTER.BEN_ADD3%TYPE,
                                     P_ben_add4         IN IFTB_NCS_MASTER.BEN_ADD4%TYPE,
                                     P_bank_name        IN IFTB_NCS_MASTER.BANK_NAME%TYPE,
                                     P_maker_id         IN IFTB_NCS_MASTER.MAKER_ID%TYPE,
                                     P_maker_dt_stamp   IN IFTB_NCS_MASTER.MAKER_DT_STAMP%TYPE,
                                     P_checker_id       IN IFTB_NCS_MASTER.CHECKER_ID%TYPE,
                                     P_checker_dt_stamp IN IFTB_NCS_MASTER.CHECKER_DT_STAMP%TYPE,
                                     P_auth_stat        IN IFTB_NCS_MASTER.AUTH_STAT%TYPE,
                                     P_record_stat      IN IFTB_NCS_MASTER.RECORD_STAT%TYPE,
                                     P_once_auth        IN IFTB_NCS_MASTER.ONCE_AUTH%TYPE,
                                     P_mod_no           IN IFTB_NCS_MASTER.MOD_NO%TYPE,
                                     P_purpose_of_trf   IN IFTB_NCS_MASTER.PURPOSE_OF_TRF%TYPE,
                                     p_requestors_branch   IN IFTB_NCS_MASTER.REQUESTOR_BRANCH%type,
                                     P_WAIVE_FLAG          IN IFTB_NCS_MASTER.WAIVE_CHARGE%type,
                                     P_INC_TXN_STATUS      IN IFTB_NCS_MASTER.INC_TXN_STATUS%TYPE,
                                     P_INC_TXN_FAIL_REASON IN IFTB_NCS_MASTER.INC_TXN_FAIL_REASON%TYPE,
                                     P_BATCH_NO            IN IFTB_NCS_MASTER.BATCH_NO%TYPE
                                     ) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_NCS_TXN_MASTER');
  
    INSERT INTO IFTB_NCS_MASTER
    VALUES
      (P_branch_code,
       P_msg_flow,
       P_trn_ref_no,
       P_related_ref_no,
       P_transfer_date,
       P_txn_ccy,
       P_txn_amt,
       P_tot_chg_amt,
       P_net_txn_amt,
       P_exch_rate,
       P_rem_acc,
       P_REM_ACC_BRN,
       P_rem_name,
       P_dr_acc_ccy,
       P_dr_amount,
       P_ben_acc,
       P_ben_bic,
       P_ben_name,
       P_ben_add1,
       P_ben_add2,
       P_ben_add3,
       P_ben_add4,
       P_bank_name,
       P_maker_id,
       P_maker_dt_stamp,
       P_checker_id,
       P_checker_dt_stamp,
       P_auth_stat,
       P_record_stat,
       P_once_auth,
       P_mod_no,
       P_purpose_of_trf,
       p_requestors_branch,
       P_WAIVE_FLAG,
       P_BATCH_NO,
       P_INC_TXN_STATUS,
       P_INC_TXN_FAIL_REASON
       
       );
  
    COMMIT;
  
    DBG('END OF PR_INSERT_NCS_TXN_MASTER');
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('FAILED IN PR_INSERT_NCS_TXN_MASTER');
      DBG('ERROR CODE IN PR_INSERT_NCS_TXN_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_NCS_TXN_MASTER=' || SQLCODE);
    
  END PR_INSERT_NCS_TXN_MASTER;

  PROCEDURE PR_INSERT_SERIAL_NO_INVOKE_LOG(P_SERIAL_NO         IN VARCHAR2,
                                           P_REF_NO            IN VARCHAR2,
                                           P_INVOKE_START_DATE IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_SERIAL_NO_INVOKE_LOG');
  
    INSERT INTO IFTB_NCS_SERIAL_NO_LOG
      (SERIAL_NO, TRN_REF_NO, INVOKE_DATE_START)
    VALUES
      (P_SERIAL_NO, P_REF_NO, P_INVOKE_START_DATE);
  
    COMMIT;
    DBG('END OF PR_INSERT_SERIAL_NO_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_SERIAL_NO_INVOKE_LOG');
      DBG('ERROR CODE IN PR_INSERT_SERIAL_NO_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_SERIAL_NO_INVOKE_LOG=' || SQLERRM);
    
  END PR_INSERT_SERIAL_NO_INVOKE_LOG;

  PROCEDURE PR_UPDATE_SERIAL_NO_INVOKE_LOG(P_SERIAL_NO       IN VARCHAR2,
                                           P_REF_NO          IN VARCHAR2,
                                           P_STATUS          IN CHAR,
                                           P_ERR_CODE        IN VARCHAR2,
                                           P_ERR_PARAM       IN VARCHAR2,
                                           P_INVOKE_DATE_END IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_SERIAL_NO_INVOKE_LOG');
    DBG('P_ERR_CODE='||P_ERR_CODE);
    DBG('P_ERR_PARAM='||P_ERR_PARAM);
  
    UPDATE IFTB_NCS_SERIAL_NO_LOG
       SET STATUS          = P_STATUS,
           TRN_REF_NO      = P_REF_NO,
           ERROR_CODE      = P_ERR_CODE,
           ERROR_PARAM     = P_ERR_PARAM,
           INVOKE_DATE_END = P_INVOKE_DATE_END
     WHERE SERIAL_NO = P_SERIAL_NO;
    -- AND TRN_REF_NO = P_REF_NO;
    COMMIT;
    DBG('END OF PR_UPDATE_SERIAL_NO_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_SERIAL_NO_INVOKE_LOG');
      DBG('ERROR CODE IN PR_UPDATE_SERIAL_NO_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_SERIAL_NO_INVOKE_LOG=' || SQLERRM);
  END PR_UPDATE_SERIAL_NO_INVOKE_LOG;

  PROCEDURE PR_UPDATE_NCS_TRACKER(P_SERIAL_NO IN VARCHAR2,
                                  P_STATUS    IN CHAR) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_NCS_TRACKER');
  
    UPDATE IFTB_NCS_INCOMING_TRACK
       SET STATUS = P_STATUS
     WHERE SERIAL_NO = P_SERIAL_NO;
  
    UPDATE IFTB_NCS_INC_TRACK
       SET STATUS = P_STATUS
     WHERE SERIAL_NO = P_SERIAL_NO;
    COMMIT;
    DBG('END OF PR_UPDATE_NCS_TRACKER');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_NCS_TRACKER');
      DBG('ERROR CODE IN PR_UPDATE_NCS_TRACKER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_NCS_TRACKER=' || SQLERRM);
  END PR_UPDATE_NCS_TRACKER;

  FUNCTION FN_GET_PARAMS RETURN CSTB_PARAM_CUSTOM%ROWTYPE RESULT_CACHE RELIES_ON(CSTB_PARAM_CUSTOM) IS
  BEGIN
    DBG('Inside FN_GET_PARAMS');
    SELECT *
      INTO g_cstb_params
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = 'NCS_PAYMENT_DTLS';
    DBG('Returing from FN_GET_PARAMS');
    RETURN g_cstb_params;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in FN_GET_PARAMS' || SQLERRM);
      DBG('Error ' || dbms_utility.format_error_backtrace);
      g_cstb_params := NULL;
      RETURN g_cstb_params;
  END;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<?xml version="1.0" encoding="UTF-8"?>',
                              NULL);
  
  END PR_RETURN_COSMETIC_XML;

  PROCEDURE PR_PROCESS_NCS_SDR_SERIAL_NO IS
  
    CURSOR C1 IS
      SELECT * FROM IFTB_NCS_INCOMING_TRACK WHERE STATUS IN ('U');
  
    L_COSMETIC_RES_MSG  CLOB;
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
    L_SETTLEMENT_ACC    STTM_CORE_ACCOUNT.CUST_ACCOUNT_NO%TYPE;
    L_CUST_ACC_BRN      STTM_CORE_ACCOUNT.SOURCE_SYSTEM_ACC_BRN%TYPE;
    L_XML               VARCHAR2(32767);
    L_CUST_CRAC_CCY     STTM_CORE_ACCOUNT.CUST_AC_CCY%TYPE;
    L_RESPONSE          VARCHAR2(32767) := '';
    L_STATUS_MSG        VARCHAR2(105);
    L_ERROR_CODE        VARCHAR2(255);
    L_ERROR_DESC        VARCHAR2(255);
    L_TRN_REF_NO        IFTB_NCS_MASTER.TRN_REF_NO%TYPE;
    L_AMOUNT_CREDITED   PMTB_ACCOUNTING_DETAIL.AMOUNT%TYPE;
    L_EXCH_RATE         NUMBER(24, 12);
  
    L_BENEF_NAME          IFTB_NCS_MASTER.BEN_NAME%TYPE;
    L_SETTLEMENT_ACC_NAME IFTB_NCS_MASTER.REM_NAME%TYPE;
    L_BENEF_ADDR_1        IFTB_NCS_MASTER.BEN_ADD1%TYPE;
    L_BENEF_ADDR_2        IFTB_NCS_MASTER.BEN_ADD2%TYPE;
    L_BENEF_ADDR_3        IFTB_NCS_MASTER.BEN_ADD3%TYPE;
    L_BENEF_ADDR_4        IFTB_NCS_MASTER.BEN_ADD4%TYPE;
    L_RELATED_REF_NO      IFTB_NCS_MASTER.RELATED_REF_NO%TYPE;
  
  BEGIN
  
    --GLOBAL.PR_INIT('001', 'SYSTEM');
  
    DBG('INSIDE PR_PROCESS_NCS_SDR_SERIAL_NO');
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        --Initialize Branch
        --GLOBAL.pr_init('000', 'SYSTEM');
      
        SAVEPOINT A;
      
        PR_RETURN_COSMETIC_XML(G.REQUEST_MSG, L_COSMETIC_RES_MSG);
      
        DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
      
        P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
      
        IF G.TXN_CCY = 'KHR' THEN
        
          BEGIN
          
            SELECT A.PARAM_VAL
              INTO L_SETTLEMENT_ACC
              FROM CSTB_PARAM_CUSTOM A
             WHERE A.PARAM_NAME = 'NCS_TXN_ACC_KHR';
          
          EXCEPTION
            WHEN OTHERS THEN
              L_SETTLEMENT_ACC := '000021069';
          END;
        
          L_SETTLEMENT_ACC_NAME := 'NBC Settlement Account-000-0000-17302';
        
        ELSIF G.TXN_CCY = 'USD' THEN
        
          BEGIN
          
            SELECT A.PARAM_VAL
              INTO L_SETTLEMENT_ACC
              FROM CSTB_PARAM_CUSTOM A
             WHERE A.PARAM_NAME = 'NCS_TXN_ACC_USD';
          
          EXCEPTION
            WHEN OTHERS THEN
              L_SETTLEMENT_ACC := '000021058';
          END;
        
          L_SETTLEMENT_ACC_NAME := 'NBC Settlement Account-000-0000-17303';
        
        END IF;
      
        --L_XML := REPLACE(L_XML, '$L_BRANCH_CODE', L_CUST_ACCOUNT.BRANCH_CODE);
      
        L_XML := FN_GET_PAYMENT_REQ_FORMAT;
      
        L_XML := REPLACE(L_XML, '$L_CUST_CRAC_NO', G.PAYEE_ACCOUNT_NO);
        
        BEGIN
        
          SELECT A.SOURCE_SYSTEM_ACC_BRN
            INTO L_CUST_ACC_BRN
            FROM STTM_CORE_ACCOUNT A
           WHERE A.CUST_ACCOUNT_NO = G.PAYEE_ACCOUNT_NO;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACC_BRN := NULL;
        END;
      
        DBG('L_CUST_ACC_BRN=' || L_CUST_ACC_BRN);
      
        BEGIN
        
          SELECT A.CUST_AC_CCY
            INTO L_CUST_CRAC_CCY
            FROM STTM_CORE_ACCOUNT A
           WHERE A.CUST_ACCOUNT_NO = G.PAYEE_ACCOUNT_NO;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_CRAC_CCY := NULL;
        END;
      
        DBG('L_CUST_CRAC_CCY=' || L_CUST_CRAC_CCY);
      
        L_XML := REPLACE(L_XML, '$L_CUST_CRAC_CCY', L_CUST_CRAC_CCY);
      
        --L_XML := REPLACE(L_XML, '$L_TXN_AMT', G.TXN_AMOUNT);
      
        L_XML := REPLACE(L_XML, '$L_OFFSET_AMT', G.TXN_AMOUNT);
      
        L_XML := REPLACE(L_XML, '$L_SETTLEMENT_ACC', L_SETTLEMENT_ACC);
        L_XML := REPLACE(L_XML, '$L_SETTLEMENT_CCY', G.TXN_CCY);
      
        DBG('G.SERIAL_NO=' || G.SERIAL_NO);
        DBG('G.TXN_CCY=' || G.TXN_CCY);
        DBG('G.L_CUST_CRAC_CCY=' || L_CUST_CRAC_CCY);
      
        IF L_CUST_CRAC_CCY <> G.TXN_CCY THEN
        
          --Get Exchange rate
        
          IF NOT FN_GET_ONLINE_EXCHANGE_RATES(G.TXN_CCY,
                                              L_CUST_CRAC_CCY,
                                              L_EXCH_RATE) THEN
          
            L_XML := REPLACE(L_XML, '$L_EXCH_RATE', L_EXCH_RATE);
          
          END IF;
        
        ELSE
          L_EXCH_RATE := 1;
          L_XML       := REPLACE(L_XML, '$L_EXCH_RATE', L_EXCH_RATE);
        
        END IF;
      
        DBG('Final Request xml=' || L_XML);
      
        PR_INSERT_SERIAL_NO_INVOKE_LOG(G.SERIAL_NO, NULL, SYSDATE);
      
        L_RESPONSE := process_http('http://10.80.80.79:8007/' ||
                                   'FCUBSRTService/FCUBSRTService',
                                   L_XML,
                                   'text/xml;charset=utf-8');
      
        DBG('L_RESPONSE=' || L_RESPONSE);
      
        --Get Cosmetic XML
        PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
      
        DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
      
        P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
      
        --Check if returned error or success
        L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                        .GETSTRINGVAL;
      
        IF L_STATUS_MSG <> 'SUCCESS' THEN
        
          L_ERROR_CODE := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/ECODE/text()')
                          .GETSTRINGVAL;
        
          L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                          .GETSTRINGVAL;
        
          PR_UPDATE_NCS_TRACKER(G.SERIAL_NO, 'E');
        
          PR_UPDATE_SERIAL_NO_INVOKE_LOG(G.SERIAL_NO,
                                         NULL,
                                         'E',
                                         L_ERROR_CODE,
                                         L_ERROR_DESC,
                                         SYSDATE);
        
          L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
          
          PR_INSERT_NCS_TXN_MASTER(SUBSTR(L_TRN_REF_NO, 1, 3),
                                   'I',
                                   L_TRN_REF_NO,
                                   L_RELATED_REF_NO,
                                   SYSDATE,
                                   L_CUST_CRAC_CCY,
                                   L_AMOUNT_CREDITED,
                                   
                                   0,
                                   0,
                                   L_EXCH_RATE,
                                   L_SETTLEMENT_ACC,
                                   L_CUST_ACC_BRN,
                                   L_SETTLEMENT_ACC_NAME,
                                   
                                   G.TXN_CCY,
                                   G.TXN_AMOUNT,
                                   G.PAYEE_ACCOUNT_NO,
                                   'PINCKHPPXXXX',
                                   L_BENEF_NAME,
                                   L_BENEF_ADDR_1,
                                   L_BENEF_ADDR_2,
                                   L_BENEF_ADDR_3,
                                   L_BENEF_ADDR_4,
                                   'PRINCE BANK PLC',
                                   'SYSTEM',
                                   GLOBAL.application_date,
                                   NULL,--'SYSTEM',
                                   NULL,--GLOBAL.application_date,
                                   'U',
                                   'O',
                                   'N',
                                   1,
                                   NULL,
                                   L_CUST_ACC_BRN,
                                   'N',
                                   'FAILED',
                                   L_ERROR_DESC,
                                   G.OUTPUT_BATCH_NO);
                                   
          ROLLBACK TO A;
          CONTINUE;
        
        ELSE
        
          L_TRN_REF_NO := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/FCCREF/text()')
                          .GETSTRINGVAL;
        
          DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
        
          L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
        
          L_AMOUNT_CREDITED := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/TXNAMT/text()')
                               .GETSTRINGVAL;
        
          DBG('L_AMOUNT_CREDITED=' || L_AMOUNT_CREDITED);
        
          L_BENEF_NAME := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFNAME/text()')
                          .GETSTRINGVAL;
        
          DBG('L_BENEF_NAME=' || L_BENEF_NAME);
        
          L_BENEF_ADDR_1 := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFADDR1/text()')
                            .GETSTRINGVAL;
        
          DBG('L_BENEF_ADDR_1=' || L_BENEF_ADDR_1);
        
          L_BENEF_ADDR_2 := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFADDR2/text()')
                            .GETSTRINGVAL;
        
          DBG('L_BENEF_ADDR_2=' || L_BENEF_ADDR_2);
        
          L_BENEF_ADDR_3 := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFADDR3/text()')
                            .GETSTRINGVAL;
        
          DBG('L_BENEF_ADDR_3=' || L_BENEF_ADDR_3);
        
          L_BENEF_ADDR_4 := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFADDR4/text()')
                            .GETSTRINGVAL;
        
          DBG('L_BENEF_ADDR_4=' || L_BENEF_ADDR_4);
        
          PR_UPDATE_NCS_TRACKER(G.SERIAL_NO, 'P');
        
          PR_UPDATE_SERIAL_NO_INVOKE_LOG(G.SERIAL_NO,
                                         L_TRN_REF_NO,
                                         'P',
                                         NULL,
                                         NULL,
                                         GLOBAL.application_date);
        
          PR_INSERT_NCS_TXN_MASTER(SUBSTR(L_TRN_REF_NO, 1, 3),
                                   'I',
                                   L_TRN_REF_NO,
                                   L_RELATED_REF_NO,
                                   SYSDATE,
                                   L_CUST_CRAC_CCY,
                                   L_AMOUNT_CREDITED,
                                   
                                   0,
                                   0,
                                   L_EXCH_RATE,
                                   L_SETTLEMENT_ACC,
                                   L_CUST_ACC_BRN,
                                   L_SETTLEMENT_ACC_NAME,
                                   G.TXN_CCY,
                                   G.TXN_AMOUNT,
                                   G.PAYEE_ACCOUNT_NO,
                                   'PINCKHPPXXXX',
                                   L_BENEF_NAME,
                                   L_BENEF_ADDR_1,
                                   L_BENEF_ADDR_2,
                                   L_BENEF_ADDR_3,
                                   L_BENEF_ADDR_4,
                                   'PRINCE BANK PLC',
                                   'SYSTEM',
                                   GLOBAL.application_date,
                                   'SYSTEM',
                                   GLOBAL.application_date,
                                   'A',
                                   'O',
                                   'Y',
                                   1,
                                   NULL,
                                   L_CUST_ACC_BRN,
                                   'N',
                                   'SUCCESS',
                                   NULL,
                                   G.OUTPUT_BATCH_NO);
        
          COMMIT;
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PROCESSING CURRENT INCOMING ORDER ID=' ||
              G.SERIAL_NO);
          DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
          ROLLBACK TO A;
          CONTINUE;
      END;
    
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_NCS_SDR_SERIAL_NO');
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE IN PR_PROCESS_NCS_SDR_SERIAL_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_NCS_SDR_SERIAL_NO=' || SQLERRM);
  END PR_PROCESS_NCS_SDR_SERIAL_NO;

  PROCEDURE PR_INIT_MSG IS
    FILE      VARCHAR2(32767);
    FILE_NAME VARCHAR2(100);
    FPATH     VARCHAR2(1000);
  BEGIN
    global.pr_init('000', 'SYSTEM');
    --debug.pr_close;
    DBG('entered  ');
    DBMS_OUTPUT.PUT_LINE('entered  ');
  
    g_cstb_params := FN_GET_PARAMS;
  
    DBG('Income path :' || g_cstb_params.PARAM_VAL);
    DBMS_OUTPUT.PUT_LINE('Income path :' || g_cstb_params.PARAM_VAL);
  
    SELECT DIRECTORY_PATH
      INTO FPATH
      FROM DBA_DIRECTORIES
     WHERE DIRECTORY_NAME = g_cstb_params.PARAM_VAL;
  
    DBG('FPATH  - ' || FPATH);
    DBMS_OUTPUT.PUT_LINE('FPATH=' || FPATH);
  
    FILE_NAME := FN_READ_NCS_FILE('/u01/fcubs/interfaces/NCS_Payments/Incoming/ready');
  
    DBG('FILE_NAME  - ' || FILE_NAME);
    DBMS_OUTPUT.PUT_LINE('FILE_NAME=' || FILE_NAME);
  
    PR_MOVE_FILE(FILE_NAME);
  
    DBG('Success  ');
    DBMS_OUTPUT.PUT_LINE('Success');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INIT_MSG ' || SQLERRM);
      DBMS_OUTPUT.PUT_LINE('FAILED IN PR_INIT_MSG=' || SQLERRM);
  END PR_INIT_MSG;

  PROCEDURE PR_MOVE_FILE(P_FILE_NAME IN VARCHAR2) IS
    L_XML XMLTYPE;
  BEGIN
  
    --GLOBAL.PR_INIT('002', 'SYSTEM');
  
    DBG('INSIDE PR_MOVE_FILE=' || P_FILE_NAME);
    DBMS_OUTPUT.PUT_LINE('INSIDE PR_MOVE_FILE=' || P_FILE_NAME);
  
    IF P_FILE_NAME IS NOT NULL THEN
      UTL_FILE.FRENAME('NCS_PAY_INCOMING_READY',
                       P_FILE_NAME,
                       'NCS_PAY_INCOMING_WIP',
                       P_FILE_NAME,
                       TRUE);
      DBG('moved to wip');
      DBMS_OUTPUT.PUT_LINE('moved to wip');
      DBG('File name: ' || P_FILE_NAME);
      DBMS_OUTPUT.PUT_LINE('File name:');
    
      SELECT XMLTYPE(BFILENAME('NCS_PAY_INCOMING_WIP', P_FILE_NAME),
                     NLS_CHARSET_ID('AL32UTF16'))
        INTO L_XML
        FROM DUAL;
    
      --Handle Handoff
      PR_NCS_SDR_INC_HANDOFF(L_XML, P_FILE_NAME);
    
      --Handle Process
      PR_PROCESS_NCS_SDR_SERIAL_NO;
    
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN WOT OF PR_MOVE_FILE=' || SQLERRM);
      DBMS_OUTPUT.PUT_LINE('FAILED IN WOT OF PR_MOVE_FILE=' || SQLERRM);
  END PR_MOVE_FILE;

  PROCEDURE PR_NCS_SDR_INC_HANDOFF(P_REQ_MSG   IN XMLTYPE,
                                   P_FILE_NAME IN VARCHAR2) IS
  
    L_RESPONSE           VARCHAR2(32767);
    L_SNIPPET            XMLTYPE;
    L_IX                 BINARY_INTEGER;
    L_TEXT               CLOB;
    L_START              NUMBER := 1;
    L_END                NUMBER := 0;
    L_NO_OF_SDR_PAYMENTS NUMBER := 0;
    L_SERIAL_NO_PAYMENT  CLOB;
  
    E_UPDATE_ERROR EXCEPTION;
    P_ERR_CODE     VARCHAR2(1000);
    P_ERR_PARAMS   VARCHAR2(1000);
    P_REQ_MSG_CLOB CLOB;
  
  BEGIN
  
    DBG('START OF PR_NCS_SDR_INC_HANDOFF');
  
    P_REQ_MSG_CLOB := P_REQ_MSG.getClobVal();
  
    --DBG('P_REQ_MSG_CLOB=' || P_REQ_MSG_CLOB);
  
    L_NO_OF_SDR_PAYMENTS := (LENGTH(P_REQ_MSG_CLOB) -
                            LENGTH(REPLACE(P_REQ_MSG_CLOB,
                                            '</Payment>',
                                            ''))) / length('</Payment>');
  
    DBG('L_NO_OF_SDR_PAYMENTS=' || L_NO_OF_SDR_PAYMENTS);
  
    FOR G IN 1 .. L_NO_OF_SDR_PAYMENTS LOOP
    
      DBG('G value=' || G);
      DBG('BEGIN L_START=' || L_START);
      DBG('BEGIN L_END=' || L_END);
    
      L_START := INSTR(P_REQ_MSG_CLOB, '<Payment>', L_START, G);
      L_END   := INSTR(P_REQ_MSG_CLOB, '</Payment>', L_START, 1);
    
      DBG('AFTER L_START=' || L_START);
      DBG('AFTER L_END=' || L_END);
    
      --DBMS_OUTPUT.PUT_LINE('FINAL SUB END=' || L_END - L_START + LENGTH('</payment_order>'));
    
      L_SERIAL_NO_PAYMENT := SUBSTR(P_REQ_MSG_CLOB,
                                    L_START,
                                    L_END - L_START + LENGTH('</Payment>'));
    
      --DBMS_OUTPUT.PUT_LINE('L_NO_OF_SDR_PAYMENTS=' || L_NO_OF_SDR_PAYMENTS);
    
      PR_INSERT_NCS_TRACKER(SYSDATE, L_SERIAL_NO_PAYMENT, P_FILE_NAME);
    
      L_START := 1;
    
      DBG('-------------------');
    
    END LOOP;
  
    DBG('DONE WITH HANDOFF');
  
    -- RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE IN PR_NCS_SDR_INC_HANDOFF=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_NCS_SDR_INC_HANDOFF=' || SQLERRM);
      -- RETURN FALSE;
  END PR_NCS_SDR_INC_HANDOFF;

  PROCEDURE PR_INSERT_NCS_TRACKER(P_FILE_DATE   IN VARCHAR2,
                                  P_REQUEST_MSG IN CLOB,
                                  P_FILE_NAME   IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
  
    L_SERIAL_NO         IFTB_NCS_INCOMING_TRACK.SERIAL_NO%TYPE;
    L_PAYMENT_TYPE_CODE IFTB_NCS_INCOMING_TRACK.PAYMENT_TYPE_CODE%TYPE;
    L_PAYMENT_DATE      IFTB_NCS_INCOMING_TRACK.PAYMENT_DATE%TYPE;
    L_PAYER_BANK        IFTB_NCS_INCOMING_TRACK.PAYER_BANK%TYPE;
    L_PAYER_CHECK_DIGIT IFTB_NCS_INCOMING_TRACK.PAYER_CHECK_DIGIT%TYPE;
    L_PAYER_ACCOUNT_NO  IFTB_NCS_INCOMING_TRACK.PAYER_ACCOUNT_NO%TYPE;
    L_TXN_CCY_CODE      IFTB_NCS_INCOMING_TRACK.TXN_CCY%TYPE;
    L_TXN_AMOUNT        IFTB_NCS_INCOMING_TRACK.TXN_AMOUNT%TYPE;
    L_PAYER_NAME        IFTB_NCS_INCOMING_TRACK.PAYER_NAME%TYPE;
    L_PAYER_REF         IFTB_NCS_INCOMING_TRACK.PAYER_REF%TYPE;
    L_PAYEE_BANK        IFTB_NCS_INCOMING_TRACK.PAYEE_BANK%TYPE;
    L_PAYEE_CHECK_DIGIT IFTB_NCS_INCOMING_TRACK.PAYEE_CHECK_DIGIT%TYPE;
    L_PAYEE_ACCOUNT_NO  IFTB_NCS_INCOMING_TRACK.PAYEE_ACCOUNT_NO%TYPE;
    L_PAYEE_NAME        IFTB_NCS_INCOMING_TRACK.PAYEE_NAME%TYPE;
    L_PAYEE_REF         IFTB_NCS_INCOMING_TRACK.PAYEE_REF%TYPE;
    L_INPUT_DATE        IFTB_NCS_INCOMING_TRACK.INPUT_DATE%TYPE;
    L_PROCESSING_DATE   IFTB_NCS_INCOMING_TRACK.PROCESSING_DATE%TYPE;
    L_INPUT_BATCH_NO    IFTB_NCS_INCOMING_TRACK.INPUT_BATCH_NO%TYPE;
    L_OUTPUT_BATCH_NO   IFTB_NCS_INCOMING_TRACK.OUTPUT_BATCH_NO%TYPE;
  
    L_COUNT NUMBER;
  
  BEGIN
  
    DBG('BEFORE START OF PR_INSERT_NCS_TRACKER');
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
  
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
  
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_PAYMENT_TYPE_CODE := P_DOCUMENT_XML.EXTRACT('/Payment/PaymentTypeCode/text()')
                           .GETSTRINGVAL;
  
    DBG('L_PAYMENT_TYPE_CODE=' || L_PAYMENT_TYPE_CODE);
  
    L_SERIAL_NO := P_DOCUMENT_XML.EXTRACT('/Payment/SerialNo/text()')
                   .GETSTRINGVAL;
  
    DBG('L_SERIAL_NO=' || L_SERIAL_NO);
  
    L_PAYMENT_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/Payment/PaymentDate/text()')
                                                .GETSTRINGVAL,
                                                'DD-MM-YYYY') AS DATE),
                              'YYYY-MM-DD');
  
    DBG('L_PAYMENT_DATE=' || L_PAYMENT_DATE);
  
    L_PAYER_BANK := P_DOCUMENT_XML.EXTRACT('/Payment/PayerBank/text()')
                    .GETSTRINGVAL;
  
    DBG('L_PAYER_BANK=' || L_PAYER_BANK);
  
    L_PAYER_CHECK_DIGIT := P_DOCUMENT_XML.EXTRACT('/Payment/PayerCheckDigit/text()')
                           .GETSTRINGVAL;
  
    DBG('L_PAYER_CHECK_DIGIT=' || L_PAYER_CHECK_DIGIT);
  
    L_PAYER_ACCOUNT_NO := P_DOCUMENT_XML.EXTRACT('/Payment/PayerAccountNo/text()')
                          .GETSTRINGVAL;
  
    DBG('L_PAYER_ACCOUNT_NO=' || L_PAYER_ACCOUNT_NO);
  
    L_TXN_CCY_CODE := P_DOCUMENT_XML.EXTRACT('/Payment/CurrencyCode/text()')
                      .GETSTRINGVAL;
  
    DBG('L_TXN_CCY_CODE=' || L_TXN_CCY_CODE);
  
    L_TXN_AMOUNT := P_DOCUMENT_XML.EXTRACT('/Payment/Amount/text()')
                    .GETSTRINGVAL;
  
    DBG('L_TXN_AMOUNT=' || L_TXN_AMOUNT);
  
    L_PAYER_NAME := (P_DOCUMENT_XML.EXTRACT('/Payment/PayerName/text()')
                    .GETSTRINGVAL);
  
    DBG('L_PAYER_NAME=' || L_PAYER_NAME);
  
    IF INSTR(P_REQUEST_MSG, '<PayerRef>') > 0 THEN
    
      L_PAYER_REF := P_DOCUMENT_XML.EXTRACT('/Payment/PayerRef/text()')
                     .GETSTRINGVAL;
    
      DBG('L_PAYER_REF=' || L_PAYER_REF);
    
    END IF;
  
    L_PAYEE_BANK := P_DOCUMENT_XML.EXTRACT('/Payment/PayeeBank/text()')
                    .GETSTRINGVAL;
  
    DBG('L_PAYEE_BANK=' || L_PAYEE_BANK);
  
    L_PAYEE_CHECK_DIGIT := P_DOCUMENT_XML.EXTRACT('/Payment/PayeeCheckDigit/text()')
                           .GETSTRINGVAL;
  
    DBG('L_PAYEE_CHECK_DIGIT=' || L_PAYEE_CHECK_DIGIT);
  
    L_PAYEE_ACCOUNT_NO := P_DOCUMENT_XML.EXTRACT('/Payment/PayeeAccountNo/text()')
                          .GETSTRINGVAL;
  
    DBG('L_PAYEE_ACCOUNT_NO=' || L_PAYEE_ACCOUNT_NO);
  
    L_PAYEE_NAME := P_DOCUMENT_XML.EXTRACT('/Payment/PayeeName/text()')
                    .GETSTRINGVAL;
  
    DBG('L_PAYEE_NAME=' || L_PAYEE_NAME);
  
    IF INSTR(P_REQUEST_MSG, '<PayeeRef>') > 0 THEN
      L_PAYEE_REF := P_DOCUMENT_XML.EXTRACT('/Payment/PayeeRef/text()')
                     .GETSTRINGVAL;
    
      DBG('L_PAYEE_REF=' || L_PAYEE_REF);
    END IF;
  
    L_INPUT_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/Payment/InputDate/text()')
                                              .GETSTRINGVAL,
                                              'DD-MM-YYYY"T"HH24:mi:ss') AS DATE),
                            'YYYY-MM-DD');
  
    DBG('L_INPUT_DATE=' || L_INPUT_DATE);
  
    L_PROCESSING_DATE := TO_DATE(CAST(TO_TIMESTAMP(P_DOCUMENT_XML.EXTRACT('/Payment/ProcessingDate/text()')
                                                   .GETSTRINGVAL,
                                                   'DD-MM-YYYY"T"HH24:mi:ss') AS DATE),
                                 'YYYY-MM-DD');
  
    DBG('L_PROCESSING_DATE=' || L_PROCESSING_DATE);
  
    L_INPUT_BATCH_NO := P_DOCUMENT_XML.EXTRACT('/Payment/InputBatchNo/text()')
                        .GETSTRINGVAL;
  
    DBG('L_INPUT_BATCH_NO=' || L_INPUT_BATCH_NO);
  
    L_OUTPUT_BATCH_NO := P_DOCUMENT_XML.EXTRACT('/Payment/OutputBatchNo/text()')
                         .GETSTRINGVAL;
  
    DBG('L_OUTPUT_BATCH_NO=' || L_OUTPUT_BATCH_NO);
  
    --Check if above ORDER ID already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTB_NCS_INCOMING_TRACK
       WHERE SERIAL_NO = L_SERIAL_NO;
      -- AND STATUS = 'P';
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;
  
    IF L_COUNT = 0 THEN
      INSERT INTO IFTB_NCS_INCOMING_TRACK
        (serial_no,
         payment_type_code,
         payment_date,
         payer_bank,
         payer_check_digit,
         payer_account_no,
         txn_ccy,
         txn_amount,
         security_code,
         payer_name,
         payer_ref,
         payee_bank,
         payee_check_digit,
         payee_account_no,
         payee_name,
         payee_ref,
         return_code,
         input_date,
         processing_date,
         input_batch_no,
         output_batch_no,
         file_name,
         TIME_IN,
         REQUEST_MSG,
         FILE_DATE,
         status)
      VALUES
        (L_SERIAL_NO,
         L_PAYMENT_TYPE_CODE,
         L_PAYMENT_DATE,
         L_PAYER_BANK,
         L_PAYER_CHECK_DIGIT,
         L_PAYER_ACCOUNT_NO,
         L_TXN_CCY_CODE,
         L_TXN_AMOUNT,
         NULL, --SECURITY CODE pls check
         L_PAYER_NAME,
         L_PAYER_REF,
         L_PAYEE_BANK,
         L_PAYEE_CHECK_DIGIT,
         L_PAYEE_ACCOUNT_NO,
         L_PAYEE_NAME,
         L_PAYEE_REF,
         NULL, --RETURN CODE PLS CHECK
         L_INPUT_DATE,
         L_PROCESSING_DATE,
         L_INPUT_BATCH_NO,
         L_OUTPUT_BATCH_NO,
         P_FILE_NAME,
         SYSDATE,
         P_REQUEST_MSG,
         P_FILE_DATE,
         'U');
    
      --Temp table
      INSERT INTO IFTB_NCS_INC_TRACK
        (serial_no,
         payment_type_code,
         payment_date,
         payer_bank,
         payer_check_digit,
         payer_account_no,
         txn_ccy,
         txn_amount,
         security_code,
         payer_name,
         payer_ref,
         payee_bank,
         payee_check_digit,
         payee_account_no,
         payee_name,
         payee_ref,
         return_code,
         input_date,
         processing_date,
         input_batch_no,
         output_batch_no,
         file_name,
         time_in,
         REQUEST_MSG,
         FILE_DATE,
         status)
      VALUES
        (L_SERIAL_NO,
         L_PAYMENT_TYPE_CODE,
         L_PAYMENT_DATE,
         L_PAYER_BANK,
         L_PAYER_CHECK_DIGIT,
         L_PAYER_ACCOUNT_NO,
         L_TXN_CCY_CODE,
         L_TXN_AMOUNT,
         NULL, --SECURITY CODE pls check
         L_PAYER_NAME,
         L_PAYER_REF,
         L_PAYEE_BANK,
         L_PAYEE_CHECK_DIGIT,
         L_PAYEE_ACCOUNT_NO,
         L_PAYEE_NAME,
         L_PAYEE_REF,
         NULL, --RETURN CODE PLS CHECK
         L_INPUT_DATE,
         L_PROCESSING_DATE,
         L_INPUT_BATCH_NO,
         L_OUTPUT_BATCH_NO,
         P_FILE_NAME,
         SYSDATE,
         P_REQUEST_MSG,
         P_FILE_DATE,
         'U');
    END IF;
  
    DBG('AFTER INSERTING INTO PR_INSERT_NCS_TRACKER');
    DBG('COMMITTING');
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_NCS_TRACKER');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_NCS_TRACKER');
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
    
  END PR_INSERT_NCS_TRACKER;

  PROCEDURE PR_NCS_SDR_UPLOAD(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    GLOBAL.PR_INIT('001', 'SYSTEM');
  
    DBG('Inside PR_NCS_SDR_UPLOAD');
  
    PR_INIT_MSG;
  
    DBG('Successful return from PR_NCS_SDR_UPLOAD');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception during PR_NCS_SDR_UPLOAD' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
  END PR_NCS_SDR_UPLOAD;

  PROCEDURE PR_PROCESS_NCS_SDR(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    GLOBAL.PR_INIT('000', 'SYSTEM');
  
    PR_PROCESS_NCS_SDR_SERIAL_NO;
  
    DBG('SUCCESSFUL RETURN FROM PR_PROCESS_NCS_SDR');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_NCS_SDR');
      DBG('ERROR CODE IN PR_PROCESS_NCS_SDR=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_NCS_SDR=' || SQLERRM);
  END PR_PROCESS_NCS_SDR;

END IFPKS_NCS_INCOMING_UTILS;
