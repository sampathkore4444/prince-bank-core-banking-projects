CREATE OR REPLACE FUNCTION FN_READ_NCS_FILE
(p_dir IN VARCHAR2) RETURN VARCHAR2
AS LANGUAGE JAVA NAME
'DirectoryListner.getFileList
  (java.lang.String)
  return String';
