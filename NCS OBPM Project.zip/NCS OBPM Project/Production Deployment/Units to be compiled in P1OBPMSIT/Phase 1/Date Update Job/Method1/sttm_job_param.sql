insert into sttm_job_param (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('OBPM_APP_DATE_PROCESS', 'NAME', 'VARCHAR', 'OFSS');

COMMIT;
