BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM (
program_name      => 'PROG_PROCESS_OBPM_APP_DATE',
program_action    => 'PR_UPDATE_DATE',
program_type      => 'STORED_PROCEDURE');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_DAILY_OBPM_APP_DATE',
 start_date    => TRUNC(SYSDATE, 'HH'),
 repeat_interval  => 'FREQ=DAILY;BYHOUR=22;BYMINUTE=01',
 comments     => 'Daily at 22:01 PM');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_PROCESS_OBPM_APP_DATE',
  program_name   => 'PROG_PROCESS_OBPM_APP_DATE',
  schedule_name   => 'SCH_DAILY_OBPM_APP_DATE',
  enabled            =>  true);
END;
/

--enable job
begin
dbms_scheduler.enable('JOB_PROCESS_OBPM_APP_DATE');
end;

begin
DBMS_SCHEDULER.ENABLE('PROG_PROCESS_OBPM_APP_DATE');
end;