CREATE OR REPLACE PROCEDURE PR_PROCESS_NCS_PAYMENTS_MORNING AS

  CURSOR C1 IS
    SELECT *
      FROM IFTB_NCS_MASTER A
     WHERE A.MSG_FLOW = 'O'
       AND AUTH_STAT = 'A'
       AND (TRUNC(CHECKER_DT_STAMP) = TRUNC(SYSDATE) - 1 AND
           (TO_CHAR(CHECKER_DT_STAMP, 'HH24:MI') <= TO_CHAR('13:30')))
        OR (TRUNC(CHECKER_DT_STAMP) = TRUNC(SYSDATE) AND
           TO_CHAR(CHECKER_DT_STAMP, 'HH24:MI') <= TO_CHAR('09:30'));

  L_RESP_CLOB     CLOB;
  L_RESP_TEMPLATE CLOB;
  L_FILE_NAME     VARCHAR2(32767);
  L_RESP_CODE     VARCHAR2(10);

  FUNCTION FN_GET_EXTERNAL_CODE(P_BIC_CODE IN IFTB_NCS_PARTICIPANTS.BIC_CODE%TYPE)
    RETURN IFTB_NCS_PARTICIPANTS.EXTERNAL_CODE%TYPE AS
    L_EXTERNAL_CODE IFTB_NCS_PARTICIPANTS.EXTERNAL_CODE%TYPE;
  BEGIN
    SELECT A.EXTERNAL_CODE
      INTO L_EXTERNAL_CODE
      FROM IFTB_NCS_PARTICIPANTS A
     WHERE A.BIC_CODE = P_BIC_CODE;
  
    RETURN L_EXTERNAL_CODE;
  
  EXCEPTION
  
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN FN_GET_EXTERNAL_CODE');
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN FN_GET_EXTERNAL_CODE=' || SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN FN_GET_EXTERNAL_CODE=' || SQLERRM);
      RETURN L_EXTERNAL_CODE;
    
  END FN_GET_EXTERNAL_CODE;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DEBUG.PR_DEBUG('AC', 'retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_GET_SDR_TEMPLATE RETURN CLOB IS
  
    L_CLOB CLOB;
  
  BEGIN
    DEBUG.PR_DEBUG('AC', 'START OF FN_GET_SDR_TEMPLATE');
  
    L_CLOB := '<Payment>
      <PaymentTypeCode>$L_PAYTYPE_CODE</PaymentTypeCode>
      <SerialNo>$L_SERIAL_NO</SerialNo>
      <PaymentDate>$L_PAYMNT_DATE</PaymentDate>
      <PayerBank>096001</PayerBank>
      <PayerCheckDigit>3</PayerCheckDigit>
      <PayerAccountNo>$L_DR_ACC_NO</PayerAccountNo>
      <CurrencyCode>$L_CUST_DRAC_CCY</CurrencyCode>
      <Amount>$L_TXN_AMOUNT</Amount>
      <SecurityCode/>
      <PayerName>$PAYER_NAME</PayerName>
      <PayerRef>PRINCE BANK PLC</PayerRef>
      <PayeeBank>$L_BEN_BIC</PayeeBank>
      <PayeeCheckDigit>6</PayeeCheckDigit>
      <PayeeAccountNo>$L_CR_ACC_NO</PayeeAccountNo>
      <PayeeName>$L_CR_CUST_NAME</PayeeName>
      <PayeeRef/>
      <ReturnCode/>
      <InputDate/>
      <ProcessingDate>$L_PROC_DATE</ProcessingDate>
      <InputBatchNo/>
      <OutputBatchNo/>
    </Payment>';
  
    RETURN L_CLOB;
  
    DEBUG.PR_DEBUG('AC', 'END OF FN_GET_SDR_TEMPLATE');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN FN_GET_SDR_TEMPLATE');
      DEBUG.PR_DEBUG('AC', 'ERROR CODE IN FN_GET_SDR_TEMPLATE=' || SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN FN_GET_SDR_TEMPLATE=' || SQLERRM);
      DEBUG.PR_DEBUG('AC',
                     'ERROR LINE NUMBER IN FN_GET_SDR_TEMPLATE=' ||
                     DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
  END FN_GET_SDR_TEMPLATE;

  PROCEDURE PR_WRITE_SDR_TXN_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                     P_IN_FILE_NAME IN VARCHAR2,
                                     P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN PR_WRITE_SDR_TXN_TO_FILE');
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN PR_WRITE_SDR_TXN_TO_FILE=' || SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN PR_WRITE_SDR_TXN_TO_FILE=' ||
                     SQLERRM);
      DEBUG.PR_DEBUG('AC',
                     'ERROR LINE NUMBER IN PR_WRITE_SDR_TXN_TO_FILE=' ||
                     DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_SDR_TXN_TO_FILE;

BEGIN
  DEBUG.PR_DEBUG('AC', 'START OF PR_PROCESS_NCS_PAYMENTS_MORNING');
  
  GLOBAL.pr_init('993','SYSTEM');

  ---FOR G IN C1 LOOP
  
    --File Name
    L_FILE_NAME := 'NCSF_SDR_FILE_' ||
                   REPLACE(TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF'), ':');
  
   /* FOR G IN (SELECT *
      FROM IFTB_NCS_MASTER A
     WHERE A.MSG_FLOW = 'O'
       AND AUTH_STAT = 'A'
       AND (TRUNC(CHECKER_DT_STAMP) = TRUNC(GLOBAL.application_date) - 1 AND
           (TO_CHAR(CHECKER_DT_STAMP, 'HH24:MI') <= TO_CHAR('13:30')))
        OR (TRUNC(CHECKER_DT_STAMP) = TRUNC(GLOBAL.application_date) AND
           TO_CHAR(CHECKER_DT_STAMP, 'HH24:MI') <= TO_CHAR('09:30'))) LOOP*/
    
    FOR G IN (SELECT *
      FROM IFTB_NCS_MASTER A
     WHERE A.MSG_FLOW = 'O'
       AND AUTH_STAT = 'A'
       AND (TRUNC(CHECKER_DT_STAMP) = TRUNC(GLOBAL.application_date) AND
           TO_CHAR(CHECKER_DT_STAMP, 'HH24:MI') >= TO_CHAR('09:25'))) LOOP
           
      L_RESP_TEMPLATE := FN_GET_SDR_TEMPLATE; --FN_GET_NCS_TEMPLATE;
    
      --Payment Type Code
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_PAYTYPE_CODE',
                                 CASE G.TXN_CCY
                                   WHEN 'USD' THEN
                                    FN_GET_PARAM_VAL('NCS_PAY_TYPE_CODE_USD')
                                   WHEN 'KHR' THEN
                                    FN_GET_PARAM_VAL('NCS_PAY_TYPE_CODE_KHR')
                                 
                                 END);
    
      --Serial No
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_SERIAL_NO',
                                 --'ODT' || TO_CHAR(G.TRN_DATE, 'YYMMDD') || '0001'
                                 G.TRN_REF_NO);
    
      --Payment Date
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_PAYMNT_DATE',
                                 --TO_CHAR(G.TRN_DATE, 'DDMMYYYY')
                                 TO_CHAR(SYSDATE, 'DDMMYYYY'));
    
      --Payer Account No
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_DR_ACC_NO', G.REM_ACC);
    
      --Currency Code
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_CUST_DRAC_CCY',
                                 --G.DR_ACC_CCY
                                 G.TXN_CCY
                                 );
    
      --Amount
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_TXN_AMOUNT',
                                 G.TXN_AMT);
    
      --Payer Name
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$PAYER_NAME', G.rem_name);
    
      --Payee Name
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_CR_CUST_NAME',
                                 G.ben_name);
    
      --Credit Account
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_CR_ACC_NO', G.ben_acc);
    
      --Payee Bank
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_BEN_BIC',
                                 FN_GET_EXTERNAL_CODE(G.ben_bic));
    
      --Processing Date
      /*IF TO_CHAR(G.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') >= '08:00' AND
      
         TO_CHAR(G.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') <= '12:00' THEN
      
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_PROC_DATE',
                                   TO_CHAR(G.VALUE_DATE, 'DDMMYYYY'));
      
      ELSE
      
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_PROC_DATE',
                                   TO_CHAR(G.VALUE_DATE + 1, 'DDMMYYYY'));
      
      END IF;*/
    
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_PROC_DATE',
                                 --TO_CHAR(G.PROCESSING_DATE, 'DDMMYYYY') --see value date from webservice response
                                 TO_CHAR(SYSDATE, 'DDMMYYYY'));
    
      L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
    
      L_RESP_CLOB := L_RESP_CLOB || CHR(10);
    
      L_RESP_TEMPLATE := NULL;
    
    END LOOP;
  
    DEBUG.PR_DEBUG('AC',
                   'DONE WITH GENERATING CLOB RESPONSE=' || L_RESP_CLOB);
  
    --Appending Header, Body and Tailer
    L_RESP_CLOB := /*'<?xml version="1.0" encoding="UTF-16"?>'*/
'<SDRFile>' || CHR(10) || L_RESP_CLOB || '</SDRFile>';
  
    DEBUG.PR_DEBUG('AC', 'L_RESP_CLOB==' || L_RESP_CLOB);
  
    --Write to output file
    DEBUG.PR_DEBUG('AC', 'START OF WRITING CLOB TO AN XML FILE');
    /*PR_WRITE_CLOB_TO_FILE('IBFT_SDR_FILE_GEN',
    L_FILE_NAME || '.xml',
    L_RESP_CLOB);*/
  
    PR_WRITE_SDR_TXN_TO_FILE('NCS_SDR_OUT_FILE_GEN',
                             L_FILE_NAME || '.xml',
                             L_RESP_CLOB);
  
    DEBUG.PR_DEBUG('AC', 'END OF WRITING CLOB TO AN XML FILE');
    
      --Write to Archive Path
        DEBUG.PR_DEBUG('AC', 'START OF WRITING CLOB TO AN XML FILE FOR ARCHIVE PATH');
      
        PR_WRITE_SDR_TXN_TO_FILE('NCS_SDR_OUT_FILE_GEN_AR',
                                 L_FILE_NAME || '.xml',
                                 L_RESP_CLOB);
  
    --DELETE FROM IFTB_INTERBANK_TRANSFER_TXNS_T WHERE AUTH_STAT = 'A';
  
    DEBUG.PR_DEBUG('AC', 'END OF PR_GEN_NCS_UPLOAD_FILE');
  
    COMMIT;
  
 -- END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    DEBUG.PR_DEBUG('AC', 'FAILED IN PR_PROCESS_NCS_PAYMENTS_MORNING');
    DEBUG.PR_DEBUG('AC',
                   'ERROR CODE IN PR_PROCESS_NCS_PAYMENTS_MORNING=' ||
                   SQLCODE);
    DEBUG.PR_DEBUG('AC',
                   'ERROR MESSAGE IN PR_PROCESS_NCS_PAYMENTS_MORNING=' ||
                   SQLERRM);
END PR_PROCESS_NCS_PAYMENTS_MORNING;
