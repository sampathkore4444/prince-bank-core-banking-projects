/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2022, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : IFDNCSFT_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = 'N';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_NCS_MASTER":"BRANCH_CODE~RELATED_REF_NO~TRN_REF_NO~TRANSFER_DATE~TXN_AMT~TOT_CHG_AMT~NET_TXN_AMT~EXCH_RATE~REM_ACC~REM_NAME~BEN_ACC~BEN_BIC~BEN_NAME~BEN_ADD1~BEN_ADD2~BEN_ADD3~BEN_ADD4~TXN_CCY~PURPOSE_OF_TRF~BANK_NAME~DR_AMOUNT~DR_ACC_CCY~MSG_FLOW~REQUESTOR_BRANCH~WAIVE_CHARGE~INC_TXN_STATUS~INC_TXN_FAIL_REASON~BATCH_NO~REM_ACC_BRANCH~PAYER_BIC_CODE~PAYER_BANK_NAME~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH","BLK_NCS_CHARGE":"CHG1_TYPE~CHG1_IN_TXN~CHG1_IN_ACC~CHG2_TYPE~CHG2_IN_TXN~CHG2_IN_ACC~CHG3_TYPE~CHG3_IN_TXN~CHG3_IN_ACC~OTH_CCY~TXN_XRATE~ACC_XRATE~RELATED_REF_NO~TRN_REF_NO~CHG_SRNO~CHG1_DESC~CHG1_WAIVER~CHG1_AMT~CHG1_CCY~LCY_CHG1~FCY_CHG1~CHG1_GL~CHG2_DESC~CHG2_WAIVER~CHG2_AMT~CHG2_CCY~LCY_CHG2~FCY_CHG2~CHG2_GL~CHG3_DESC~CHG3_WAIVER~CHG3_AMT~CHG3_CCY~LCY_CHG3~FCY_CHG3~CHG3_GL~NETTING_REQ~XRATE~TXN_CODE"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_NCS_MASTER">BRANCH_CODE~RELATED_REF_NO~TRN_REF_NO~TRANSFER_DATE~TXN_AMT~TOT_CHG_AMT~NET_TXN_AMT~EXCH_RATE~REM_ACC~REM_NAME~BEN_ACC~BEN_BIC~BEN_NAME~BEN_ADD1~BEN_ADD2~BEN_ADD3~BEN_ADD4~TXN_CCY~PURPOSE_OF_TRF~BANK_NAME~DR_AMOUNT~DR_ACC_CCY~MSG_FLOW~REQUESTOR_BRANCH~WAIVE_CHARGE~INC_TXN_STATUS~INC_TXN_FAIL_REASON~BATCH_NO~REM_ACC_BRANCH~PAYER_BIC_CODE~PAYER_BANK_NAME~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH</FN>'; 
msgxml += '      <FN PARENT="BLK_NCS_MASTER" RELATION_TYPE="N" TYPE="BLK_NCS_CHARGE">CHG1_TYPE~CHG1_IN_TXN~CHG1_IN_ACC~CHG2_TYPE~CHG2_IN_TXN~CHG2_IN_ACC~CHG3_TYPE~CHG3_IN_TXN~CHG3_IN_ACC~OTH_CCY~TXN_XRATE~ACC_XRATE~RELATED_REF_NO~TRN_REF_NO~CHG_SRNO~CHG1_DESC~CHG1_WAIVER~CHG1_AMT~CHG1_CCY~LCY_CHG1~FCY_CHG1~CHG1_GL~CHG2_DESC~CHG2_WAIVER~CHG2_AMT~CHG2_CCY~LCY_CHG2~FCY_CHG2~CHG2_GL~CHG3_DESC~CHG3_WAIVER~CHG3_AMT~CHG3_CCY~LCY_CHG3~FCY_CHG3~CHG3_GL~NETTING_REQ~XRATE~TXN_CODE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR SUMMARY SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml_sum=""; 
msgxml_sum += '    <FLD>'; 
msgxml_sum += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_NCS_MASTER">AUTHSTAT~TXNSTAT~TRN_REF_NO~REM_ACC~REM_NAME~BEN_ACC~BEN_NAME~TXN_AMT~BRANCH_CODE~TRANSFER_DATE~RELATED_REF_NO~MSG_FLOW~INC_TXN_STATUS~BATCH_NO~PAYER_BIC_CODE~PAYER_BANK_NAME</FN>'; 
msgxml_sum += '    </FLD>'; 

var detailFuncId = "IFDNCSFT";
var defaultWhereClause = "";
var defaultOrderByClause ="";
var multiBrnWhereClause ="";
var g_SummaryType ="S";
var g_SummaryBtnCount =0;
var g_SummaryBlock ="BLK_NCS_MASTER";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_NCS_MASTER" : "","BLK_NCS_CHARGE" : "BLK_NCS_MASTER~N"}; 

 var dataSrcLocationArray = new Array("BLK_NCS_MASTER","BLK_NCS_CHARGE"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside IFDNCSFT.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside IFDNCSFT.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_NCS_MASTER__RELATED_REF_NO";
pkFields[0] = "BLK_NCS_MASTER__RELATED_REF_NO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_NCS_MASTER":["BEN_ACC","BEN_ADD1","BEN_ADD2","BEN_ADD3","BEN_ADD4","BEN_BIC","BEN_NAME","REM_ACC","REM_NAME"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_NCS_MASTER__REM_ACC__LOV_ACCNO":["BLK_NCS_MASTER__REM_ACC~BLK_NCS_MASTER__REM_NAME~~BLK_NCS_MASTER__DR_ACC_CCY~BLK_NCS_MASTER__REM_ACC_BRANCH~","","N~N~N~N~N",""],"BLK_NCS_MASTER__BEN_BIC__LOV_BENBIC":["BLK_NCS_MASTER__BEN_BIC~BLK_NCS_MASTER__BANK_NAME~","","N~N",""],"BLK_NCS_MASTER__TXN_CCY__LOV_TXNCCY":["BLK_NCS_MASTER__TXN_CCY~","","N",""],"BLK_NCS_MASTER__REQUESTOR_BRANCH__LOV_REQUESTOR_BRANCH":["BLK_NCS_MASTER__REQUESTOR_BRANCH~~","","N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array(); 

 var CallFormRelat=new Array(); 

 var CallRelatType= new Array(); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["IFDNCSFT"]="CUSTOM";
ArrPrntFunc["IFDNCSFT"]="";
ArrPrntOrigin["IFDNCSFT"]="";
ArrRoutingType["IFDNCSFT"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["IFDNCSFT"]="N";
ArrCustomModified["IFDNCSFT"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CSDMSGVW":""};
var scrArgSource = {"CSDMSGVW":""};
var scrArgVals = {"CSDMSGVW":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"2"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------