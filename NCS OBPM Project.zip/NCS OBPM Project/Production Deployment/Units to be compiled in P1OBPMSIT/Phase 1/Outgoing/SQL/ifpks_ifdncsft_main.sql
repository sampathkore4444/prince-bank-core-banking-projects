CREATE OR REPLACE PACKAGE BODY ifpks_ifdncsft_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : ifpks_ifdncsft_main.sql
     **
     ** Module     : Interfaces
     **
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2022 , Oracle and/or its affiliates.  All rights reserved
     **
     **
     ** No part of this work may be reproduced, stored in a retrieval system, adopted
     ** or transmitted in any form or by any means, electronic, mechanical,
     ** photographic, graphic, optic recording or otherwise, translated in any
     ** language or computer language, without the prior written permission of
     ** Oracle and/or its affiliates.
     **
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East),
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY

     SFR Number         :
     Changed By         :
     Change Description :

     -------------------------------------------------------------------------------------------------------
     */


   g_Ui_Name            VARCHAR2(50) := 'IFDNCSFT';
   g_ifdncsft         ifpks_ifdncsft_Main.ty_ifdncsft;
   g_Req_Key                 VARCHAR2(32767);
   g_Key_Id                  VARCHAR2(32767);
   g_Post_Upl_Stat     VARCHAR2(1);
   g_Curr_Stage        VARCHAR2(20);
   g_Tanking_Status      VARCHAR2(1);
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'ifpks_ifdncsft_Main ==>'||p_Msg;
         Debug.Pr_Debug('IF' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'IFDNCSFT';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   FUNCTION  Fn_Get_Curr_Stage RETURN VARCHAR2 IS
   BEGIN
      RETURN g_Curr_Stage;
   END  Fn_Get_Curr_Stage;
   FUNCTION  Fn_Get_Tanked_Stat RETURN VARCHAR2 IS
   BEGIN
      RETURN g_Tanking_Status;
   END  Fn_get_tanked_stat;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      ifpks_ifdncsft_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF g_curr_stage IS NOT NULL THEN
         RETURN G_Skip_Custom;
      ELSIF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdncsft       IN   OUT ifpks_ifdncsft_Main.ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_NCS_MASTER' THEN
            p_ifdncsft.v_iftbs_ncs_master.BRANCH_CODE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.RELATED_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_ifdncsft.v_iftbs_ncs_master.TRANSFER_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_ifdncsft.v_iftbs_ncs_master.TRANSFER_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_ifdncsft.v_iftbs_ncs_master.TXN_AMT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.TOT_CHG_AMT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.NET_TXN_AMT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.EXCH_RATE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.REM_ACC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.REM_NAME := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BEN_ACC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BEN_BIC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BEN_NAME := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BEN_ADD1 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BEN_ADD2 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BEN_ADD3 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BEN_ADD4 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.TXN_CCY := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.PURPOSE_OF_TRF := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BANK_NAME := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.DR_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.DR_ACC_CCY := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.MSG_FLOW := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.REQUESTOR_BRANCH := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.WAIVE_CHARGE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.INC_TXN_STATUS := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.INC_TXN_FAIL_REASON := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.BATCH_NO := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.REM_ACC_BRANCH := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.PAYER_BIC_CODE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.PAYER_BANK_NAME := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.MAKER_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_ifdncsft.v_iftbs_ncs_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_ifdncsft.v_iftbs_ncs_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_ifdncsft.v_iftbs_ncs_master.CHECKER_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_ifdncsft.v_iftbs_ncs_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_ifdncsft.v_iftbs_ncs_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_ifdncsft.v_iftbs_ncs_master.MOD_NO := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.RECORD_STAT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.AUTH_STAT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_master.ONCE_AUTH := Cspks_Req_Global.Fn_GetVal;
         ELSIF  l_Node = 'BLK_NCS_CHARGE' THEN
            l_Dsn_Rec_Cnt_2 :=  p_ifdncsft.v_iftbs_ncs_charge.count +1 ;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_TYPE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_IN_TXN := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_IN_ACC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_TYPE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_IN_TXN := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_IN_ACC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_TYPE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_IN_TXN := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_IN_ACC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).OTH_CCY := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).TXN_XRATE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).ACC_XRATE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).RELATED_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).TRN_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG_SRNO := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_DESC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_WAIVER := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_AMT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_CCY := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).LCY_CHG1 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).FCY_CHG1 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_GL := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_DESC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_WAIVER := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_AMT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_CCY := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).LCY_CHG2 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).FCY_CHG2 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_GL := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_DESC := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_WAIVER := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_AMT := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_CCY := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).LCY_CHG3 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).FCY_CHG3 := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_GL := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).NETTING_REQ := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).XRATE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).TXN_CODE := Cspks_Req_Global.Fn_GetVal;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).related_ref_no :=p_ifdncsft.v_iftbs_ncs_master.related_ref_no;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_ifdncsft.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdncsft_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdncsft       IN   OUT ifpks_ifdncsft_Main.ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_NCS_MASTER','Fast-Master-Full','Fast-Master-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'BRANCH_CODE' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BRANCH_CODE := l_Val;
               ELSIF l_Key = 'RELATED_REF_NO' THEN
                  p_ifdncsft.v_iftbs_ncs_master.RELATED_REF_NO := l_Val;
               ELSIF l_Key IN( 'TRN_REF_NO1','TRN_REF_NO')  THEN
                  p_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO := l_Val;
               ELSIF l_Key = 'TRANSFER_DATE' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_ifdncsft.v_iftbs_ncs_master.TRANSFER_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_ifdncsft.v_iftbs_ncs_master.TRANSFER_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'TXN_AMT' THEN
                  p_ifdncsft.v_iftbs_ncs_master.TXN_AMT := l_Val;
               ELSIF l_Key IN( 'TOTCHGAMT','TOT_CHG_AMT')  THEN
                  p_ifdncsft.v_iftbs_ncs_master.TOT_CHG_AMT := l_Val;
               ELSIF l_Key IN( 'TOTAL_CASA_DR','NET_TXN_AMT')  THEN
                  p_ifdncsft.v_iftbs_ncs_master.NET_TXN_AMT := l_Val;
               ELSIF l_Key = 'EXCH_RATE' THEN
                  p_ifdncsft.v_iftbs_ncs_master.EXCH_RATE := l_Val;
               ELSIF l_Key = 'REM_ACC' THEN
                  p_ifdncsft.v_iftbs_ncs_master.REM_ACC := l_Val;
               ELSIF l_Key = 'REM_NAME' THEN
                  p_ifdncsft.v_iftbs_ncs_master.REM_NAME := l_Val;
               ELSIF l_Key = 'BEN_ACC' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BEN_ACC := l_Val;
               ELSIF l_Key IN( 'BANK_BIC','BEN_BIC')  THEN
                  p_ifdncsft.v_iftbs_ncs_master.BEN_BIC := l_Val;
               ELSIF l_Key = 'BEN_NAME' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BEN_NAME := l_Val;
               ELSIF l_Key = 'BEN_ADD1' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BEN_ADD1 := l_Val;
               ELSIF l_Key = 'BEN_ADD2' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BEN_ADD2 := l_Val;
               ELSIF l_Key = 'BEN_ADD3' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BEN_ADD3 := l_Val;
               ELSIF l_Key = 'BEN_ADD4' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BEN_ADD4 := l_Val;
               ELSIF l_Key = 'TXN_CCY' THEN
                  p_ifdncsft.v_iftbs_ncs_master.TXN_CCY := l_Val;
               ELSIF l_Key = 'PURPOSE_OF_TRF' THEN
                  p_ifdncsft.v_iftbs_ncs_master.PURPOSE_OF_TRF := l_Val;
               ELSIF l_Key = 'BANK_NAME' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BANK_NAME := l_Val;
               ELSIF l_Key IN( 'DR_AMOUNT1','DR_AMOUNT')  THEN
                  p_ifdncsft.v_iftbs_ncs_master.DR_AMOUNT := l_Val;
               ELSIF l_Key IN( 'ACCUR','DR_ACC_CCY')  THEN
                  p_ifdncsft.v_iftbs_ncs_master.DR_ACC_CCY := l_Val;
               ELSIF l_Key = 'MSG_FLOW' THEN
                  p_ifdncsft.v_iftbs_ncs_master.MSG_FLOW := l_Val;
               ELSIF l_Key = 'REQUESTOR_BRANCH' THEN
                  p_ifdncsft.v_iftbs_ncs_master.REQUESTOR_BRANCH := l_Val;
               ELSIF l_Key = 'WAIVE_CHARGE' THEN
                  p_ifdncsft.v_iftbs_ncs_master.WAIVE_CHARGE := l_Val;
               ELSIF l_Key = 'INC_TXN_STATUS' THEN
                  p_ifdncsft.v_iftbs_ncs_master.INC_TXN_STATUS := l_Val;
               ELSIF l_Key = 'INC_TXN_FAIL_REASON' THEN
                  p_ifdncsft.v_iftbs_ncs_master.INC_TXN_FAIL_REASON := l_Val;
               ELSIF l_Key = 'BATCH_NO' THEN
                  p_ifdncsft.v_iftbs_ncs_master.BATCH_NO := l_Val;
               ELSIF l_Key IN( 'ACC_BRANCH','REM_ACC_BRANCH')  THEN
                  p_ifdncsft.v_iftbs_ncs_master.REM_ACC_BRANCH := l_Val;
               ELSIF l_Key = 'PAYER_BIC_CODE' THEN
                  p_ifdncsft.v_iftbs_ncs_master.PAYER_BIC_CODE := l_Val;
               ELSIF l_Key = 'PAYER_BANK_NAME' THEN
                  p_ifdncsft.v_iftbs_ncs_master.PAYER_BANK_NAME := l_Val;
               ELSIF l_Key = 'MAKER' THEN
                  p_ifdncsft.v_iftbs_ncs_master.MAKER_ID := l_Val;
               ELSIF l_Key = 'MAKERSTAMP' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_ifdncsft.v_iftbs_ncs_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_ifdncsft.v_iftbs_ncs_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'CHECKER' THEN
                  p_ifdncsft.v_iftbs_ncs_master.CHECKER_ID := l_Val;
               ELSIF l_Key = 'CHECKERSTAMP' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_ifdncsft.v_iftbs_ncs_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_ifdncsft.v_iftbs_ncs_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'MODNO' THEN
                  p_ifdncsft.v_iftbs_ncs_master.MOD_NO := l_Val;
               ELSIF l_Key = 'TXNSTAT' THEN
                  p_ifdncsft.v_iftbs_ncs_master.RECORD_STAT := l_Val;
               ELSIF l_Key = 'AUTHSTAT' THEN
                  p_ifdncsft.v_iftbs_ncs_master.AUTH_STAT := l_Val;
               ELSIF l_Key = 'ONCEAUTH' THEN
                  p_ifdncsft.v_iftbs_ncs_master.ONCE_AUTH := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         ELSIF  l_Node IN ( 'BLK_NCS_CHARGE','Rft-Charge') THEN
            l_Dsn_Rec_Cnt_2 :=  p_ifdncsft.v_iftbs_ncs_charge.count +1 ;
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'CHG1_TYPE' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_TYPE := l_Val;
               ELSIF l_Key = 'CHG1_IN_TXN' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_IN_TXN := l_Val;
               ELSIF l_Key = 'CHG1_IN_ACC' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_IN_ACC := l_Val;
               ELSIF l_Key = 'CHG2_TYPE' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_TYPE := l_Val;
               ELSIF l_Key = 'CHG2_IN_TXN' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_IN_TXN := l_Val;
               ELSIF l_Key = 'CHG2_IN_ACC' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_IN_ACC := l_Val;
               ELSIF l_Key = 'CHG3_TYPE' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_TYPE := l_Val;
               ELSIF l_Key = 'CHG3_IN_TXN' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_IN_TXN := l_Val;
               ELSIF l_Key = 'CHG3_IN_ACC' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_IN_ACC := l_Val;
               ELSIF l_Key = 'OTH_CCY' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).OTH_CCY := l_Val;
               ELSIF l_Key = 'TXN_XRATE' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).TXN_XRATE := l_Val;
               ELSIF l_Key = 'ACC_XRATE' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).ACC_XRATE := l_Val;
               ELSIF l_Key = 'RELATED_REF_NO' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).RELATED_REF_NO := l_Val;
               ELSIF l_Key = 'TRN_REF_NO' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).TRN_REF_NO := l_Val;
               ELSIF l_Key = 'CHG_SRNO' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG_SRNO := l_Val;
               ELSIF l_Key = 'CHG1_DESC' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_DESC := l_Val;
               ELSIF l_Key = 'CHG1_WAIVER' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_WAIVER := l_Val;
               ELSIF l_Key = 'CHG1_AMT' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_AMT := l_Val;
               ELSIF l_Key = 'CHG1_CCY' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_CCY := l_Val;
               ELSIF l_Key = 'LCY_CHG1' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).LCY_CHG1 := l_Val;
               ELSIF l_Key = 'FCY_CHG1' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).FCY_CHG1 := l_Val;
               ELSIF l_Key = 'CHG1_GL' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG1_GL := l_Val;
               ELSIF l_Key = 'CHG2_DESC' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_DESC := l_Val;
               ELSIF l_Key = 'CHG2_WAIVER' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_WAIVER := l_Val;
               ELSIF l_Key = 'CHG2_AMT' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_AMT := l_Val;
               ELSIF l_Key = 'CHG2_CCY' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_CCY := l_Val;
               ELSIF l_Key = 'LCY_CHG2' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).LCY_CHG2 := l_Val;
               ELSIF l_Key = 'FCY_CHG2' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).FCY_CHG2 := l_Val;
               ELSIF l_Key = 'CHG2_GL' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG2_GL := l_Val;
               ELSIF l_Key = 'CHG3_DESC' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_DESC := l_Val;
               ELSIF l_Key = 'CHG3_WAIVER' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_WAIVER := l_Val;
               ELSIF l_Key = 'CHG3_AMT' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_AMT := l_Val;
               ELSIF l_Key = 'CHG3_CCY' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_CCY := l_Val;
               ELSIF l_Key = 'LCY_CHG3' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).LCY_CHG3 := l_Val;
               ELSIF l_Key = 'FCY_CHG3' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).FCY_CHG3 := l_Val;
               ELSIF l_Key = 'CHG3_GL' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).CHG3_GL := l_Val;
               ELSIF l_Key = 'NETTING_REQ' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).NETTING_REQ := l_Val;
               ELSIF l_Key = 'XRATE' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).XRATE := l_Val;
               ELSIF l_Key = 'TXN_CODE' THEN
                  p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).TXN_CODE := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).related_ref_no :=p_ifdncsft.v_iftbs_ncs_master.related_ref_no;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_ifdncsft.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdncsft_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdncsft          IN ifpks_ifdncsft_Main.ty_ifdncsft,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_1_Lvl_Counter := 0;
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_NCS_MASTER',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','BRANCH_CODE',p_ifdncsft.v_iftbs_ncs_master.branch_code);
      Cspks_Req_Global.Pr_Write('V','RELATED_REF_NO',p_ifdncsft.v_iftbs_ncs_master.related_ref_no);
      Cspks_Req_Global.Pr_Write('V','TRN_REF_NO',p_ifdncsft.v_iftbs_ncs_master.trn_ref_no);
      IF trunc(p_ifdncsft.v_iftbs_ncs_master.transfer_date) <>
            p_ifdncsft.v_iftbs_ncs_master.transfer_date THEN
         l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.transfer_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.transfer_date,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','TRANSFER_DATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','TXN_AMT',p_ifdncsft.v_iftbs_ncs_master.txn_amt);
      Cspks_Req_Global.Pr_Write('V','TOT_CHG_AMT',p_ifdncsft.v_iftbs_ncs_master.tot_chg_amt);
      Cspks_Req_Global.Pr_Write('V','NET_TXN_AMT',p_ifdncsft.v_iftbs_ncs_master.net_txn_amt);
      Cspks_Req_Global.Pr_Write('V','EXCH_RATE',p_ifdncsft.v_iftbs_ncs_master.exch_rate);
      Cspks_Req_Global.Pr_Write('V','REM_ACC',p_ifdncsft.v_iftbs_ncs_master.rem_acc);
      Cspks_Req_Global.Pr_Write('V','REM_NAME',p_ifdncsft.v_iftbs_ncs_master.rem_name);
      Cspks_Req_Global.Pr_Write('V','BEN_ACC',p_ifdncsft.v_iftbs_ncs_master.ben_acc);
      Cspks_Req_Global.Pr_Write('V','BEN_BIC',p_ifdncsft.v_iftbs_ncs_master.ben_bic);
      Cspks_Req_Global.Pr_Write('V','BEN_NAME',p_ifdncsft.v_iftbs_ncs_master.ben_name);
      Cspks_Req_Global.Pr_Write('V','BEN_ADD1',p_ifdncsft.v_iftbs_ncs_master.ben_add1);
      Cspks_Req_Global.Pr_Write('V','BEN_ADD2',p_ifdncsft.v_iftbs_ncs_master.ben_add2);
      Cspks_Req_Global.Pr_Write('V','BEN_ADD3',p_ifdncsft.v_iftbs_ncs_master.ben_add3);
      Cspks_Req_Global.Pr_Write('V','BEN_ADD4',p_ifdncsft.v_iftbs_ncs_master.ben_add4);
      Cspks_Req_Global.Pr_Write('V','TXN_CCY',p_ifdncsft.v_iftbs_ncs_master.txn_ccy);
      Cspks_Req_Global.Pr_Write('V','PURPOSE_OF_TRF',p_ifdncsft.v_iftbs_ncs_master.purpose_of_trf);
      Cspks_Req_Global.Pr_Write('V','BANK_NAME',p_ifdncsft.v_iftbs_ncs_master.bank_name);
      Cspks_Req_Global.Pr_Write('V','DR_AMOUNT',p_ifdncsft.v_iftbs_ncs_master.dr_amount);
      Cspks_Req_Global.Pr_Write('V','DR_ACC_CCY',p_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy);
      Cspks_Req_Global.Pr_Write('V','MSG_FLOW',p_ifdncsft.v_iftbs_ncs_master.msg_flow);
      Cspks_Req_Global.Pr_Write('V','REQUESTOR_BRANCH',p_ifdncsft.v_iftbs_ncs_master.requestor_branch);
      Cspks_Req_Global.Pr_Write('V','WAIVE_CHARGE',p_ifdncsft.v_iftbs_ncs_master.waive_charge);
      Cspks_Req_Global.Pr_Write('V','INC_TXN_STATUS',p_ifdncsft.v_iftbs_ncs_master.inc_txn_status);
      Cspks_Req_Global.Pr_Write('V','INC_TXN_FAIL_REASON',p_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason);
      Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_ifdncsft.v_iftbs_ncs_master.batch_no);
      Cspks_Req_Global.Pr_Write('V','REM_ACC_BRANCH',p_ifdncsft.v_iftbs_ncs_master.rem_acc_branch);
      Cspks_Req_Global.Pr_Write('V','PAYER_BIC_CODE',p_ifdncsft.v_iftbs_ncs_master.payer_bic_code);
      Cspks_Req_Global.Pr_Write('V','PAYER_BANK_NAME',p_ifdncsft.v_iftbs_ncs_master.payer_bank_name);
      Cspks_Req_Global.Pr_Write('V','MAKER',p_ifdncsft.v_iftbs_ncs_master.maker_id);
      IF trunc(p_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp) <>
            p_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','MAKERSTAMP',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','CHECKER',p_ifdncsft.v_iftbs_ncs_master.checker_id);
      IF trunc(p_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp) <>
            p_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','CHECKERSTAMP',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','MODNO',p_ifdncsft.v_iftbs_ncs_master.mod_no);
      Cspks_Req_Global.Pr_Write('V','TXNSTAT',p_ifdncsft.v_iftbs_ncs_master.record_stat);
      Cspks_Req_Global.Pr_Write('V','AUTHSTAT',p_ifdncsft.v_iftbs_ncs_master.auth_stat);
      Cspks_Req_Global.Pr_Write('V','ONCEAUTH',p_ifdncsft.v_iftbs_ncs_master.once_auth);

      --Dbg('Building Childs Of :BLK_NCS_MASTER..');
      l_Dsn_Rec_Cnt_2 := 0;
      IF p_ifdncsft.v_iftbs_ncs_charge.COUNT > 0 THEN
         FOR i_2 IN  1..p_ifdncsft.v_iftbs_ncs_charge.COUNT LOOP
            l_Dsn_Rec_Cnt_2 := i_2;
            l_Master_Childs  :=  l_Master_Childs +1;
            l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','BLK_NCS_CHARGE',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','CHG1_TYPE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_type);
            Cspks_Req_Global.Pr_Write('V','CHG1_IN_TXN',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_in_txn);
            Cspks_Req_Global.Pr_Write('V','CHG1_IN_ACC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_in_acc);
            Cspks_Req_Global.Pr_Write('V','CHG2_TYPE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_type);
            Cspks_Req_Global.Pr_Write('V','CHG2_IN_TXN',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_in_txn);
            Cspks_Req_Global.Pr_Write('V','CHG2_IN_ACC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_in_acc);
            Cspks_Req_Global.Pr_Write('V','CHG3_TYPE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_type);
            Cspks_Req_Global.Pr_Write('V','CHG3_IN_TXN',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_in_txn);
            Cspks_Req_Global.Pr_Write('V','CHG3_IN_ACC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_in_acc);
            Cspks_Req_Global.Pr_Write('V','OTH_CCY',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).oth_ccy);
            Cspks_Req_Global.Pr_Write('V','TXN_XRATE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).txn_xrate);
            Cspks_Req_Global.Pr_Write('V','ACC_XRATE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).acc_xrate);
            Cspks_Req_Global.Pr_Write('V','RELATED_REF_NO',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).related_ref_no);
            Cspks_Req_Global.Pr_Write('V','TRN_REF_NO',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).trn_ref_no);
            Cspks_Req_Global.Pr_Write('V','CHG_SRNO',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg_srno);
            Cspks_Req_Global.Pr_Write('V','CHG1_DESC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_desc);
            Cspks_Req_Global.Pr_Write('V','CHG1_WAIVER',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_waiver);
            Cspks_Req_Global.Pr_Write('V','CHG1_AMT',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_amt);
            Cspks_Req_Global.Pr_Write('V','CHG1_CCY',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_ccy);
            Cspks_Req_Global.Pr_Write('V','LCY_CHG1',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).lcy_chg1);
            Cspks_Req_Global.Pr_Write('V','FCY_CHG1',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).fcy_chg1);
            Cspks_Req_Global.Pr_Write('V','CHG1_GL',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_gl);
            Cspks_Req_Global.Pr_Write('V','CHG2_DESC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_desc);
            Cspks_Req_Global.Pr_Write('V','CHG2_WAIVER',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_waiver);
            Cspks_Req_Global.Pr_Write('V','CHG2_AMT',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_amt);
            Cspks_Req_Global.Pr_Write('V','CHG2_CCY',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_ccy);
            Cspks_Req_Global.Pr_Write('V','LCY_CHG2',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).lcy_chg2);
            Cspks_Req_Global.Pr_Write('V','FCY_CHG2',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).fcy_chg2);
            Cspks_Req_Global.Pr_Write('V','CHG2_GL',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_gl);
            Cspks_Req_Global.Pr_Write('V','CHG3_DESC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_desc);
            Cspks_Req_Global.Pr_Write('V','CHG3_WAIVER',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_waiver);
            Cspks_Req_Global.Pr_Write('V','CHG3_AMT',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_amt);
            Cspks_Req_Global.Pr_Write('V','CHG3_CCY',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_ccy);
            Cspks_Req_Global.Pr_Write('V','LCY_CHG3',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).lcy_chg3);
            Cspks_Req_Global.Pr_Write('V','FCY_CHG3',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).fcy_chg3);
            Cspks_Req_Global.Pr_Write('V','CHG3_GL',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_gl);
            Cspks_Req_Global.Pr_Write('V','NETTING_REQ',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).netting_req);
            Cspks_Req_Global.Pr_Write('V','XRATE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).xrate);
            Cspks_Req_Global.Pr_Write('V','TXN_CODE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).txn_code);
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_ifdncsft          IN ifpks_ifdncsft_Main.ty_ifdncsft,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF (  p_ifdncsft.v_iftbs_ncs_master.related_ref_no IS NOT NULL
          )
          THEN
            l_1_Lvl_Counter := 0;
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Fast-Master-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','RELATED_REF_NO',p_ifdncsft.v_iftbs_ncs_master.related_ref_no);
            Cspks_Req_Global.Pr_Write('V','TRN_REF_NO1',p_ifdncsft.v_iftbs_ncs_master.trn_ref_no);
            IF trunc(p_ifdncsft.v_iftbs_ncs_master.transfer_date) <>
                  p_ifdncsft.v_iftbs_ncs_master.transfer_date THEN
               l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.transfer_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.transfer_date,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','TRANSFER_DATE',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','TXN_AMT',p_ifdncsft.v_iftbs_ncs_master.txn_amt);
            Cspks_Req_Global.Pr_Write('V','TOTCHGAMT',p_ifdncsft.v_iftbs_ncs_master.tot_chg_amt);
            Cspks_Req_Global.Pr_Write('V','TOTAL_CASA_DR',p_ifdncsft.v_iftbs_ncs_master.net_txn_amt);
            Cspks_Req_Global.Pr_Write('V','EXCH_RATE',p_ifdncsft.v_iftbs_ncs_master.exch_rate);
            Cspks_Req_Global.Pr_Write('V','REM_ACC',p_ifdncsft.v_iftbs_ncs_master.rem_acc);
            Cspks_Req_Global.Pr_Write('V','REM_NAME',p_ifdncsft.v_iftbs_ncs_master.rem_name);
            Cspks_Req_Global.Pr_Write('V','BEN_ACC',p_ifdncsft.v_iftbs_ncs_master.ben_acc);
            Cspks_Req_Global.Pr_Write('V','BANK_BIC',p_ifdncsft.v_iftbs_ncs_master.ben_bic);
            Cspks_Req_Global.Pr_Write('V','BEN_NAME',p_ifdncsft.v_iftbs_ncs_master.ben_name);
            Cspks_Req_Global.Pr_Write('V','BEN_ADD1',p_ifdncsft.v_iftbs_ncs_master.ben_add1);
            Cspks_Req_Global.Pr_Write('V','BEN_ADD2',p_ifdncsft.v_iftbs_ncs_master.ben_add2);
            Cspks_Req_Global.Pr_Write('V','BEN_ADD3',p_ifdncsft.v_iftbs_ncs_master.ben_add3);
            Cspks_Req_Global.Pr_Write('V','BEN_ADD4',p_ifdncsft.v_iftbs_ncs_master.ben_add4);
            Cspks_Req_Global.Pr_Write('V','TXN_CCY',p_ifdncsft.v_iftbs_ncs_master.txn_ccy);
            Cspks_Req_Global.Pr_Write('V','PURPOSE_OF_TRF',p_ifdncsft.v_iftbs_ncs_master.purpose_of_trf);
            Cspks_Req_Global.Pr_Write('V','BANK_NAME',p_ifdncsft.v_iftbs_ncs_master.bank_name);
            Cspks_Req_Global.Pr_Write('V','DR_AMOUNT1',p_ifdncsft.v_iftbs_ncs_master.dr_amount);
            Cspks_Req_Global.Pr_Write('V','ACCUR',p_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy);
            Cspks_Req_Global.Pr_Write('V','MSG_FLOW',p_ifdncsft.v_iftbs_ncs_master.msg_flow);
            Cspks_Req_Global.Pr_Write('V','REQUESTOR_BRANCH',p_ifdncsft.v_iftbs_ncs_master.requestor_branch);
            Cspks_Req_Global.Pr_Write('V','WAIVE_CHARGE',p_ifdncsft.v_iftbs_ncs_master.waive_charge);
            Cspks_Req_Global.Pr_Write('V','INC_TXN_STATUS',p_ifdncsft.v_iftbs_ncs_master.inc_txn_status);
            Cspks_Req_Global.Pr_Write('V','INC_TXN_FAIL_REASON',p_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason);
            Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_ifdncsft.v_iftbs_ncs_master.batch_no);
            Cspks_Req_Global.Pr_Write('V','ACC_BRANCH',p_ifdncsft.v_iftbs_ncs_master.rem_acc_branch);
            Cspks_Req_Global.Pr_Write('V','PAYER_BIC_CODE',p_ifdncsft.v_iftbs_ncs_master.payer_bic_code);
            Cspks_Req_Global.Pr_Write('V','PAYER_BANK_NAME',p_ifdncsft.v_iftbs_ncs_master.payer_bank_name);
            Cspks_Req_Global.Pr_Write('V','MAKER',p_ifdncsft.v_iftbs_ncs_master.maker_id);
            IF trunc(p_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp) <>
                  p_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','MAKERSTAMP',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','CHECKER',p_ifdncsft.v_iftbs_ncs_master.checker_id);
            IF trunc(p_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp) <>
                  p_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','CHECKERSTAMP',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','MODNO',p_ifdncsft.v_iftbs_ncs_master.mod_no);
            Cspks_Req_Global.Pr_Write('V','TXNSTAT',p_ifdncsft.v_iftbs_ncs_master.record_stat);
            Cspks_Req_Global.Pr_Write('V','AUTHSTAT',p_ifdncsft.v_iftbs_ncs_master.auth_stat);

            --Dbg('Building Childs Of :BLK_NCS_MASTER..');
            l_Dsn_Rec_Cnt_2 := 0;
            IF p_ifdncsft.v_iftbs_ncs_charge.COUNT > 0 THEN
               FOR i_2 IN  1..p_ifdncsft.v_iftbs_ncs_charge.COUNT LOOP
                  l_Dsn_Rec_Cnt_2 := i_2;
                  l_Master_Childs  :=  l_Master_Childs +1;
                  l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
                  l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
                  Cspks_Req_Global.Pr_Write('P','Rft-Charge',l_Level_Format);
                  Cspks_Req_Global.Pr_Write('V','CHG1_TYPE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_type);
                  Cspks_Req_Global.Pr_Write('V','CHG1_IN_TXN',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_in_txn);
                  Cspks_Req_Global.Pr_Write('V','CHG1_IN_ACC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_in_acc);
                  Cspks_Req_Global.Pr_Write('V','CHG2_TYPE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_type);
                  Cspks_Req_Global.Pr_Write('V','CHG2_IN_TXN',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_in_txn);
                  Cspks_Req_Global.Pr_Write('V','CHG2_IN_ACC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_in_acc);
                  Cspks_Req_Global.Pr_Write('V','CHG3_TYPE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_type);
                  Cspks_Req_Global.Pr_Write('V','CHG3_IN_TXN',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_in_txn);
                  Cspks_Req_Global.Pr_Write('V','CHG3_IN_ACC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_in_acc);
                  Cspks_Req_Global.Pr_Write('V','OTH_CCY',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).oth_ccy);
                  Cspks_Req_Global.Pr_Write('V','TXN_XRATE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).txn_xrate);
                  Cspks_Req_Global.Pr_Write('V','ACC_XRATE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).acc_xrate);
                  Cspks_Req_Global.Pr_Write('V','RELATED_REF_NO',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).related_ref_no);
                  Cspks_Req_Global.Pr_Write('V','TRN_REF_NO',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).trn_ref_no);
                  Cspks_Req_Global.Pr_Write('V','CHG_SRNO',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg_srno);
                  Cspks_Req_Global.Pr_Write('V','CHG1_DESC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_desc);
                  Cspks_Req_Global.Pr_Write('V','CHG1_WAIVER',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_waiver);
                  Cspks_Req_Global.Pr_Write('V','CHG1_AMT',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_amt);
                  Cspks_Req_Global.Pr_Write('V','CHG1_CCY',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_ccy);
                  Cspks_Req_Global.Pr_Write('V','LCY_CHG1',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).lcy_chg1);
                  Cspks_Req_Global.Pr_Write('V','FCY_CHG1',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).fcy_chg1);
                  Cspks_Req_Global.Pr_Write('V','CHG1_GL',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg1_gl);
                  Cspks_Req_Global.Pr_Write('V','CHG2_DESC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_desc);
                  Cspks_Req_Global.Pr_Write('V','CHG2_WAIVER',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_waiver);
                  Cspks_Req_Global.Pr_Write('V','CHG2_AMT',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_amt);
                  Cspks_Req_Global.Pr_Write('V','CHG2_CCY',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_ccy);
                  Cspks_Req_Global.Pr_Write('V','LCY_CHG2',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).lcy_chg2);
                  Cspks_Req_Global.Pr_Write('V','FCY_CHG2',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).fcy_chg2);
                  Cspks_Req_Global.Pr_Write('V','CHG2_GL',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg2_gl);
                  Cspks_Req_Global.Pr_Write('V','CHG3_DESC',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_desc);
                  Cspks_Req_Global.Pr_Write('V','CHG3_WAIVER',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_waiver);
                  Cspks_Req_Global.Pr_Write('V','CHG3_AMT',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_amt);
                  Cspks_Req_Global.Pr_Write('V','CHG3_CCY',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_ccy);
                  Cspks_Req_Global.Pr_Write('V','LCY_CHG3',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).lcy_chg3);
                  Cspks_Req_Global.Pr_Write('V','FCY_CHG3',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).fcy_chg3);
                  Cspks_Req_Global.Pr_Write('V','CHG3_GL',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).chg3_gl);
                  Cspks_Req_Global.Pr_Write('V','NETTING_REQ',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).netting_req);
                  Cspks_Req_Global.Pr_Write('V','XRATE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).xrate);
                  Cspks_Req_Global.Pr_Write('V','TXN_CODE',p_ifdncsft.v_iftbs_ncs_charge(l_Dsn_Rec_Cnt_2).txn_code);
               END LOOP;
            END IF;
         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Fast-Master-PK','1');
         l_Key_Cols := 'RELATED_REF_NO~';
         l_Key_Vals := p_ifdncsft.v_iftbs_ncs_master.related_ref_no||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_ifdncsft IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'IFTBS_NCS_MASTER.RELATED_REF_NO';
      IF p_ifdncsft.v_iftbs_ncs_master.related_ref_no IS Null THEN
         Dbg('Field related_ref_no is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'IFTBS_NCS_MASTER';
         l_Fld := 'IFTBS_NCS_MASTER.TXN_CCY';
         IF p_ifdncsft.v_iftbs_ncs_master.txn_ccy IS Null THEN
            Dbg('Mandatory Key Column txn_ccy Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'IFTBS_NCS_MASTER.TXN_AMT';
         IF p_ifdncsft.v_iftbs_ncs_master.txn_amt IS Null THEN
            Dbg('Mandatory Key Column txn_amt Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'IFTBS_NCS_MASTER.REM_ACC';
         IF p_ifdncsft.v_iftbs_ncs_master.rem_acc IS Null THEN
            Dbg('Mandatory Key Column rem_acc Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'IFTBS_NCS_MASTER.REM_NAME';
         IF p_ifdncsft.v_iftbs_ncs_master.rem_name IS Null THEN
            Dbg('Mandatory Key Column rem_name Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'IFTBS_NCS_MASTER.BEN_ACC';
         IF p_ifdncsft.v_iftbs_ncs_master.ben_acc IS Null THEN
            Dbg('Mandatory Key Column ben_acc Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'IFTBS_NCS_MASTER.BEN_BIC';
         IF p_ifdncsft.v_iftbs_ncs_master.ben_bic IS Null THEN
            Dbg('Mandatory Key Column ben_bic Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;
         l_Fld := 'IFTBS_NCS_MASTER.REQUESTOR_BRANCH';
         IF p_ifdncsft.v_iftbs_ncs_master.requestor_branch IS Null THEN
            Dbg('Mandatory Key Column requestor_branch Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;

         l_Blk := 'IFTBS_NCS_CHARGE';
         l_Count := p_ifdncsft.v_iftbs_ncs_charge.COUNT;
         IF l_Count > 0 THEN
            FOR l_index IN 1 .. p_ifdncsft.v_iftbs_ncs_charge.COUNT LOOP
               l_Fld := 'IFTBS_NCS_CHARGE.CHG_SRNO';
               IF p_ifdncsft.v_iftbs_ncs_charge(l_Index).chg_srno IS Null THEN
                  Dbg('Primary Key Column chg_srno Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
            END LOOP;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_ifdncsft     IN  ifpks_ifdncsft_Main.ty_ifdncsft,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      IF p_ifdncsft.v_iftbs_ncs_master.MSG_FLOW IS NOT NULL THEN
         IF p_ifdncsft.v_iftbs_ncs_master.MSG_FLOW NOT IN ('O','I') THEN
            dbg('Invalid Value For The Field  :MSG_FLOW:'||p_ifdncsft.v_iftbs_ncs_master.MSG_FLOW);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_ifdncsft.v_iftbs_ncs_master.MSG_FLOW||'~@IFTBS_NCS_MASTER.MSG_FLOW~@IFTBS_NCS_MASTER') ;
         END IF;
      END IF;
      IF p_ifdncsft.v_iftbs_ncs_master.WAIVE_CHARGE IS NOT NULL THEN
         IF p_ifdncsft.v_iftbs_ncs_master.WAIVE_CHARGE NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :WAIVE_CHARGE:'||p_ifdncsft.v_iftbs_ncs_master.WAIVE_CHARGE);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_ifdncsft.v_iftbs_ncs_master.WAIVE_CHARGE||'~@IFTBS_NCS_MASTER.WAIVE_CHARGE~@IFTBS_NCS_MASTER') ;
         END IF;
      END IF;
      Dbg('Duplicate Records Check For :v_iftbs_ncs_charge..');
      l_Count      := p_ifdncsft.v_iftbs_ncs_charge.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_count LOOP
            l_key := NULL;
            IF l_index < l_Count THEN
               FOR l_index1 IN l_index+1 .. l_Count LOOP
                  IF (NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).related_ref_no,'@')=  NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index1).related_ref_no,'@')) AND (NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno,-1)=  NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index1).chg_srno,-1)) THEN
                     Dbg('Duplicare Record Found for :'||l_Key);
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_CHARGE.RELATED_REF_NO')||'-'||
                     p_ifdncsft.v_iftbs_ncs_charge(l_index).related_ref_no||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_CHARGE.CHG_SRNO')||'-'||
                     p_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno;
                     Pr_Log_Error(p_Source,'ST-VALS-009','@IFTBS_NCS_CHARGE~'||l_Key);
                  END IF;
               END LOOP;
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_ifdncsft     IN  OUT ifpks_ifdncsft_Main.ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Merge_Amendables        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_ifdncsft     IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Prev_ifdncsft IN ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Wrk_ifdncsft IN OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Wrk_Count      NUMBER := 0 ;
      l_Deleted_Recs   NUMBER := 0;
      l_Modified_Flds  VARCHAR2(32000):= NULL;
      l_Key            VARCHAR2(5000):= NULL;
      l_Mod_Fld        VARCHAR2(100):= NULL;
      i                NUMBER := 1;
      l_Rec_Found      BOOLEAN := FALSE;
      l_Rec_Modified   BOOLEAN := FALSE;
      l_Rec_Sent       BOOLEAN := FALSE;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Pk_Or_Full     VARCHAR2(5) :='FULL';
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Mod_No         NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Amendable_Nodes Cspks_Req_Global.Ty_Amend_Nodes;
      l_Amendable_Fields Cspks_Req_Global.Ty_Amend_Fields;
      N_v_iftbs_ncs_charge       ifpks_ifdncsft_Main.Ty_Tb_v_iftbs_ncs_charge;

      FUNCTION Fn_Amendable(p_Item IN VARCHAR2) RETURN BOOLEAN IS
      BEGIN
         IF l_Amendable_Fields.EXISTS(p_Item) THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END Fn_Amendable;
   BEGIN

      Dbg('In Fn_Sys_Merge_Amendables');

      Dbg('Calling Cspks_Req_Utils.Fn_Get_Amendable_Details..');
      IF NOT Cspks_Req_Utils.Fn_Get_Amendable_Details(p_source ,
         p_Source_Operation,
         l_Amendable_Nodes,
         l_Amendable_Fields,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      l_Blk := 'IFTBS_NCS_MASTER';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_fld := 'IFTBS_NCS_MASTER.BRANCH_CODE';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BRANCH_CODE') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.branch_code := p_ifdncsft.v_iftbs_ncs_master.branch_code;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.branch_code IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.branch_code,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.branch_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.TRN_REF_NO';
      IF Fn_Amendable('IFTBS_NCS_MASTER.TRN_REF_NO') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.trn_ref_no := p_ifdncsft.v_iftbs_ncs_master.trn_ref_no;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.trn_ref_no IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.trn_ref_no,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.trn_ref_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.TRANSFER_DATE';
      IF Fn_Amendable('IFTBS_NCS_MASTER.TRANSFER_DATE') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.transfer_date := p_ifdncsft.v_iftbs_ncs_master.transfer_date;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.transfer_date IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.transfer_date,global.min_date) <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.transfer_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.TXN_CCY';
      IF Fn_Amendable('IFTBS_NCS_MASTER.TXN_CCY') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.txn_ccy := p_ifdncsft.v_iftbs_ncs_master.txn_ccy;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.txn_ccy IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.txn_ccy,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.txn_ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.TXN_AMT';
      IF Fn_Amendable('IFTBS_NCS_MASTER.TXN_AMT') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.txn_amt := p_ifdncsft.v_iftbs_ncs_master.txn_amt;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.txn_amt IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.txn_amt,-1) <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.txn_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.TOT_CHG_AMT';
      IF Fn_Amendable('IFTBS_NCS_MASTER.TOT_CHG_AMT') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.tot_chg_amt := p_ifdncsft.v_iftbs_ncs_master.tot_chg_amt;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.tot_chg_amt IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.tot_chg_amt,-1) <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.tot_chg_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.NET_TXN_AMT';
      IF Fn_Amendable('IFTBS_NCS_MASTER.NET_TXN_AMT') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.net_txn_amt := p_ifdncsft.v_iftbs_ncs_master.net_txn_amt;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.net_txn_amt IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.net_txn_amt,-1) <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.net_txn_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.EXCH_RATE';
      IF Fn_Amendable('IFTBS_NCS_MASTER.EXCH_RATE') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.exch_rate := p_ifdncsft.v_iftbs_ncs_master.exch_rate;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.exch_rate IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.exch_rate,-1) <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.exch_rate,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.REM_ACC';
      IF Fn_Amendable('IFTBS_NCS_MASTER.REM_ACC') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_acc := p_ifdncsft.v_iftbs_ncs_master.rem_acc;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.rem_acc IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_acc,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.rem_acc,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.REM_NAME';
      IF Fn_Amendable('IFTBS_NCS_MASTER.REM_NAME') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_name := p_ifdncsft.v_iftbs_ncs_master.rem_name;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.rem_name IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_name,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.rem_name,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BEN_ACC';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BEN_ACC') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_acc := p_ifdncsft.v_iftbs_ncs_master.ben_acc;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.ben_acc IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_acc,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.ben_acc,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BEN_BIC';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BEN_BIC') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_bic := p_ifdncsft.v_iftbs_ncs_master.ben_bic;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.ben_bic IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_bic,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.ben_bic,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BEN_NAME';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BEN_NAME') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_name := p_ifdncsft.v_iftbs_ncs_master.ben_name;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.ben_name IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_name,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.ben_name,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BEN_ADD1';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BEN_ADD1') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add1 := p_ifdncsft.v_iftbs_ncs_master.ben_add1;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.ben_add1 IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add1,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.ben_add1,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BEN_ADD2';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BEN_ADD2') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add2 := p_ifdncsft.v_iftbs_ncs_master.ben_add2;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.ben_add2 IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add2,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.ben_add2,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BEN_ADD3';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BEN_ADD3') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add3 := p_ifdncsft.v_iftbs_ncs_master.ben_add3;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.ben_add3 IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add3,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.ben_add3,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BEN_ADD4';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BEN_ADD4') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add4 := p_ifdncsft.v_iftbs_ncs_master.ben_add4;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.ben_add4 IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add4,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.ben_add4,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.PURPOSE_OF_TRF';
      IF Fn_Amendable('IFTBS_NCS_MASTER.PURPOSE_OF_TRF') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.purpose_of_trf := p_ifdncsft.v_iftbs_ncs_master.purpose_of_trf;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.purpose_of_trf IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.purpose_of_trf,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.purpose_of_trf,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BANK_NAME';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BANK_NAME') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.bank_name := p_ifdncsft.v_iftbs_ncs_master.bank_name;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.bank_name IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.bank_name,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.bank_name,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.DR_AMOUNT';
      IF Fn_Amendable('IFTBS_NCS_MASTER.DR_AMOUNT') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.dr_amount := p_ifdncsft.v_iftbs_ncs_master.dr_amount;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.dr_amount IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.dr_amount,-1) <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.dr_amount,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.DR_ACC_CCY';
      IF Fn_Amendable('IFTBS_NCS_MASTER.DR_ACC_CCY') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy := p_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.MSG_FLOW';
      IF Fn_Amendable('IFTBS_NCS_MASTER.MSG_FLOW') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.msg_flow := p_ifdncsft.v_iftbs_ncs_master.msg_flow;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.msg_flow IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.msg_flow,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.msg_flow,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.REQUESTOR_BRANCH';
      IF Fn_Amendable('IFTBS_NCS_MASTER.REQUESTOR_BRANCH') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.requestor_branch := p_ifdncsft.v_iftbs_ncs_master.requestor_branch;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.requestor_branch IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.requestor_branch,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.requestor_branch,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.WAIVE_CHARGE';
      IF Fn_Amendable('IFTBS_NCS_MASTER.WAIVE_CHARGE') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.waive_charge := p_ifdncsft.v_iftbs_ncs_master.waive_charge;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.waive_charge IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.waive_charge,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.waive_charge,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.INC_TXN_STATUS';
      IF Fn_Amendable('IFTBS_NCS_MASTER.INC_TXN_STATUS') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.inc_txn_status := p_ifdncsft.v_iftbs_ncs_master.inc_txn_status;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.inc_txn_status IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.inc_txn_status,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.inc_txn_status,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.INC_TXN_FAIL_REASON';
      IF Fn_Amendable('IFTBS_NCS_MASTER.INC_TXN_FAIL_REASON') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason := p_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.BATCH_NO';
      IF Fn_Amendable('IFTBS_NCS_MASTER.BATCH_NO') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.batch_no := p_ifdncsft.v_iftbs_ncs_master.batch_no;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.batch_no IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.batch_no,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.batch_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.REM_ACC_BRANCH';
      IF Fn_Amendable('IFTBS_NCS_MASTER.REM_ACC_BRANCH') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_acc_branch := p_ifdncsft.v_iftbs_ncs_master.rem_acc_branch;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.rem_acc_branch IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_acc_branch,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.rem_acc_branch,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.PAYER_BIC_CODE';
      IF Fn_Amendable('IFTBS_NCS_MASTER.PAYER_BIC_CODE') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.payer_bic_code := p_ifdncsft.v_iftbs_ncs_master.payer_bic_code;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.payer_bic_code IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.payer_bic_code,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.payer_bic_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'IFTBS_NCS_MASTER.PAYER_BANK_NAME';
      IF Fn_Amendable('IFTBS_NCS_MASTER.PAYER_BANK_NAME') THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.payer_bank_name := p_ifdncsft.v_iftbs_ncs_master.payer_bank_name;
      ELSE
         IF p_ifdncsft.v_iftbs_ncs_master.payer_bank_name IS NOT NULL THEN
            IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.payer_bank_name,'@') <>
               NVL(p_ifdncsft.v_iftbs_ncs_master.payer_bank_name,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;

      l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
      IF  l_Rec_Modified THEN
         IF l_Modified_Flds IS NOT NULL THEN
            i :=  1;
            l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
            WHILE l_Mod_Fld <> 'EOPL' LOOP
               Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
               i := i +1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
            END LOOP;
         END IF;
      END IF;
      l_Blk := 'IFTBS_NCS_CHARGE';
      l_Count      := p_ifdncsft.v_iftbs_ncs_charge.COUNT;
      l_Wrk_Count  := p_Wrk_ifdncsft.v_iftbs_ncs_charge.COUNT;
      IF l_Count > 0 THEN
         FOR l_index IN 1..l_Count  LOOP
            l_Rec_Found := FALSE;
            l_Rec_Modified := FALSE;
            l_Modified_Flds := NULL;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno,-1)=  NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg_srno,-1)) THEN
                     Dbg('Record Found..');
                     l_Rec_Found := TRUE;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG1_TYPE';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG1_TYPE') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_type := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_type;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_type IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_type,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_type,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG1_IN_TXN';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG1_IN_TXN') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_in_txn := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_in_txn;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_in_txn IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_in_txn,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_in_txn,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG1_IN_ACC';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG1_IN_ACC') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_in_acc := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_in_acc;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_in_acc IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_in_acc,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_in_acc,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG2_TYPE';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG2_TYPE') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_type := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_type;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_type IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_type,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_type,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG2_IN_TXN';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG2_IN_TXN') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_in_txn := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_in_txn;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_in_txn IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_in_txn,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_in_txn,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG2_IN_ACC';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG2_IN_ACC') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_in_acc := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_in_acc;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_in_acc IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_in_acc,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_in_acc,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG3_TYPE';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG3_TYPE') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_type := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_type;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_type IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_type,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_type,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG3_IN_TXN';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG3_IN_TXN') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_in_txn := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_in_txn;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_in_txn IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_in_txn,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_in_txn,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG3_IN_ACC';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG3_IN_ACC') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_in_acc := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_in_acc;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_in_acc IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_in_acc,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_in_acc,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.OTH_CCY';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.OTH_CCY') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).oth_ccy := p_ifdncsft.v_iftbs_ncs_charge(l_index).oth_ccy;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).oth_ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).oth_ccy,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).oth_ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.TXN_XRATE';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.TXN_XRATE') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).txn_xrate := p_ifdncsft.v_iftbs_ncs_charge(l_index).txn_xrate;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).txn_xrate IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).txn_xrate,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).txn_xrate,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.ACC_XRATE';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.ACC_XRATE') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).acc_xrate := p_ifdncsft.v_iftbs_ncs_charge(l_index).acc_xrate;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).acc_xrate IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).acc_xrate,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).acc_xrate,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.TRN_REF_NO';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.TRN_REF_NO') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).trn_ref_no := p_ifdncsft.v_iftbs_ncs_charge(l_index).trn_ref_no;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).trn_ref_no IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).trn_ref_no,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).trn_ref_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG1_DESC';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG1_DESC') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_desc := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_desc;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_desc IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_desc,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_desc,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG1_WAIVER';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG1_WAIVER') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_waiver := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_waiver;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_waiver IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_waiver,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_waiver,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG1_AMT';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG1_AMT') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_amt := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_amt;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_amt IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_amt,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_amt,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG1_CCY';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG1_CCY') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_ccy := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_ccy;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_ccy,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.LCY_CHG1';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.LCY_CHG1') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).lcy_chg1 := p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg1;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg1 IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).lcy_chg1,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg1,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.FCY_CHG1';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.FCY_CHG1') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).fcy_chg1 := p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg1;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg1 IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).fcy_chg1,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg1,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG1_GL';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG1_GL') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_gl := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_gl;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_gl IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg1_gl,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg1_gl,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG2_DESC';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG2_DESC') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_desc := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_desc;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_desc IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_desc,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_desc,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG2_WAIVER';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG2_WAIVER') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_waiver := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_waiver;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_waiver IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_waiver,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_waiver,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG2_AMT';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG2_AMT') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_amt := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_amt;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_amt IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_amt,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_amt,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG2_CCY';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG2_CCY') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_ccy := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_ccy;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_ccy,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.LCY_CHG2';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.LCY_CHG2') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).lcy_chg2 := p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg2;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg2 IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).lcy_chg2,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg2,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.FCY_CHG2';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.FCY_CHG2') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).fcy_chg2 := p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg2;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg2 IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).fcy_chg2,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg2,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG2_GL';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG2_GL') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_gl := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_gl;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_gl IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg2_gl,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg2_gl,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG3_DESC';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG3_DESC') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_desc := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_desc;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_desc IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_desc,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_desc,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG3_WAIVER';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG3_WAIVER') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_waiver := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_waiver;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_waiver IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_waiver,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_waiver,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG3_AMT';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG3_AMT') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_amt := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_amt;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_amt IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_amt,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_amt,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG3_CCY';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG3_CCY') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_ccy := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_ccy;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_ccy,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.LCY_CHG3';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.LCY_CHG3') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).lcy_chg3 := p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg3;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg3 IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).lcy_chg3,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).lcy_chg3,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.FCY_CHG3';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.FCY_CHG3') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).fcy_chg3 := p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg3;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg3 IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).fcy_chg3,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).fcy_chg3,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.CHG3_GL';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.CHG3_GL') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_gl := p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_gl;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_gl IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg3_gl,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).chg3_gl,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.NETTING_REQ';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.NETTING_REQ') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).netting_req := p_ifdncsft.v_iftbs_ncs_charge(l_index).netting_req;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).netting_req IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).netting_req,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).netting_req,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.XRATE';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.XRATE') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).xrate := p_ifdncsft.v_iftbs_ncs_charge(l_index).xrate;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).xrate IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).xrate,-1) <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).xrate,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'IFTBS_NCS_CHARGE.TXN_CODE';
                     IF Fn_Amendable('IFTBS_NCS_CHARGE.TXN_CODE') THEN
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).txn_code := p_ifdncsft.v_iftbs_ncs_charge(l_index).txn_code;
                     ELSE
                        IF p_ifdncsft.v_iftbs_ncs_charge(l_index).txn_code IS NOT NULL THEN
                           IF NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).txn_code,'@') <>
                              NVL(p_ifdncsft.v_iftbs_ncs_charge(l_index).txn_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;

                     l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
                     IF  l_Rec_modified THEN
                        IF l_Modified_Flds IS NOT NULL THEN
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_CHARGE.CHG_SRNO')||'-'||
                           p_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno;
                           i :=  1;
                           l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           WHILE l_mod_fld <> 'EOPL' LOOP
                              Pr_Log_Error(p_Source,'ST-AMND-003','@'||l_Mod_Fld||'~@'||l_Blk||'~'||l_Key );
                              i := i +1;
                              l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           END LOOP;
                        END IF;
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               p_Wrk_ifdncsft.v_iftbs_ncs_charge(p_Wrk_ifdncsft.v_iftbs_ncs_charge.COUNT +1 ) :=  p_ifdncsft.v_iftbs_ncs_charge(l_index);
               IF l_Amendable_Nodes.EXISTS('IFTBS_NCS_CHARGE') THEN
                  IF l_Amendable_Nodes('IFTBS_NCS_CHARGE').New_Allowed = 'N' THEN
                     Dbg('New Record Cannot Be Added..');
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_CHARGE.CHG_SRNO')||'-'||
                     p_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno;
                     Pr_Log_Error(p_source,'ST-AMND-004',l_key||'~@'||l_blk);
                  END IF;
               ELSE
                  Dbg('New Record Cannot Be Added..');
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_CHARGE.CHG_SRNO')||'-'||
                  p_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno;
                  Pr_Log_Error(p_Source,'ST-AMND-004',l_key||'~@'||l_blk);
               END IF;
            END IF;
         END LOOP;
      END IF;

      IF l_Amendable_Nodes.EXISTS('IFTBS_NCS_CHARGE') THEN
         IF l_Amendable_Nodes('IFTBS_NCS_CHARGE').All_Records = 'Y' THEN
            Dbg('Logic For Deleting Some Records From Work Record  if Not sent..');
            l_Wrk_Count := p_Wrk_ifdncsft.v_iftbs_ncs_charge.COUNT;
            l_Count     := p_ifdncsft.v_iftbs_ncs_charge.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_count  LOOP
                  l_Rec_Found := FALSE;
                  IF l_Count > 0 THEN
                     FOR l_index IN 1..l_Count  LOOP
                        IF (NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg_srno,-1)=  NVL(p_ifdncsft.v_iftbs_ncs_charge  (l_index).chg_srno,-1)) THEN
                           Dbg('Record Found..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_Rec_Found THEN
                     Dbg('Adding  a Record...');
                     N_v_iftbs_ncs_charge(N_v_iftbs_ncs_charge.COUNT +1 ) :=  p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index1);
                  ELSE
                     l_Deleted_Recs := l_Deleted_Recs +1;
                     IF l_Amendable_Nodes.EXISTS('IFTBS_NCS_CHARGE') THEN
                        IF l_Amendable_Nodes('IFTBS_NCS_CHARGE').Delete_Allowed = 'N' THEN
                           Dbg('Record Cannot Be Deleted..');
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_CHARGE.CHG_SRNO')||'-'||
                           p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg_srno;
                           Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                        END IF;
                     ELSE
                        Dbg('Record Cannot Be Deleted..');
                        l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_CHARGE.CHG_SRNO')||'-'||
                        p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index1).chg_srno;
                        Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            p_Wrk_ifdncsft.v_iftbs_ncs_charge:= N_v_iftbs_ncs_charge;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Merge_Amendables..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Merge_Amendables..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Merge_Amendables;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_ifdncsft IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_ifdncsft     IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      l_Blk := 'IFTBS_NCS_MASTER';
      l_Fld := 'IFTBS_NCS_MASTER.TXN_CCY';
      IF p_wrk_ifdncsft.v_iftbs_ncs_master.TXN_CCY IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT PARAM_VAL FROM CSTB_PARAM_CUSTOM WHERE PARAM_NAME IN ('NCS_TXN_CCY_KHR','NCS_TXN_CCY_USD')) WHERE PARAM_VAL = P_wrk_ifdncsft.v_iftbs_ncs_master.TXN_CCY;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :TXN_CCY:'||p_Wrk_ifdncsft.v_iftbs_ncs_master.TXN_CCY);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_ifdncsft.v_iftbs_ncs_master.TXN_CCY||'~@IFTBS_NCS_MASTER.TXN_CCY~@IFTBS_NCS_MASTER') ;
         END IF;
      END IF;
      l_Fld := 'IFTBS_NCS_MASTER.REM_ACC';
      IF p_wrk_ifdncsft.v_iftbs_ncs_master.REM_ACC IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT CUST_ACCOUNT_NO, CUST_AC_NAME, CUSTOMER_NO, CUST_AC_CCY, SOURCE_SYSTEM_ACC_BRN FROM STTM_CORE_ACCOUNT WHERE RECORD_STAT = 'O' AND AUTH_STAT = 'A') WHERE CUST_ACCOUNT_NO = P_wrk_ifdncsft.v_iftbs_ncs_master.REM_ACC;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :REM_ACC:'||p_Wrk_ifdncsft.v_iftbs_ncs_master.REM_ACC);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_ifdncsft.v_iftbs_ncs_master.REM_ACC||'~@IFTBS_NCS_MASTER.REM_ACC~@IFTBS_NCS_MASTER') ;
         END IF;
      END IF;
      l_Fld := 'IFTBS_NCS_MASTER.BEN_BIC';
      IF p_wrk_ifdncsft.v_iftbs_ncs_master.BEN_BIC IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT BIC_CODE, BANK_NAME FROM IFTB_NCS_PARTICIPANTS WHERE STATUS = 'ACTIVE') WHERE BIC_CODE = P_wrk_ifdncsft.v_iftbs_ncs_master.BEN_BIC;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :BEN_BIC:'||p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_BIC);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_BIC||'~@IFTBS_NCS_MASTER.BEN_BIC~@IFTBS_NCS_MASTER') ;
         END IF;
      END IF;
      l_Fld := 'IFTBS_NCS_MASTER.REQUESTOR_BRANCH';
      IF p_wrk_ifdncsft.v_iftbs_ncs_master.REQUESTOR_BRANCH IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT DISTINCT BRANCH_CODE, BRANCH_NAME FROM STTM_CORE_BRANCH WHERE RECORD_STAT = 'O' AND AUTH_STAT = 'A' ORDER BY BRANCH_CODE) WHERE BRANCH_CODE = P_wrk_ifdncsft.v_iftbs_ncs_master.REQUESTOR_BRANCH;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :REQUESTOR_BRANCH:'||p_Wrk_ifdncsft.v_iftbs_ncs_master.REQUESTOR_BRANCH);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_ifdncsft.v_iftbs_ncs_master.REQUESTOR_BRANCH||'~@IFTBS_NCS_MASTER.REQUESTOR_BRANCH~@IFTBS_NCS_MASTER') ;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_ifdncsft     IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Prev_ifdncsft IN OUT  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Wrk_ifdncsft IN OUT  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Prev_Key_Tags       VARCHAR2(32767);
      l_Prev_Key_Vals       VARCHAR2(32767);
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      IF p_Source <> 'FLEXCUBE'  THEN
         BEGIN
            SELECT Base_Data_From_Fc
            INTO   l_Base_Data_From_Fc
            FROM   Cotms_Source
            WHERE  Source_Code = p_Source;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               Dbg('Failed in Selecting Source '||p_Source);
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-VALS-002';
               p_Err_Params  := p_Source;
               RETURN FALSE;
         END;
      END IF;
      l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_MASTER.RELATED_REF_NO')||'-'||
      p_ifdncsft.v_iftbs_ncs_master.related_ref_no;
      l_Prev_Key_Tags := 'RELATED_REF_NO~';
      l_Prev_Key_Vals := p_prev_ifdncsft.v_iftbs_ncs_master.related_ref_no||'~';
      Dbg('Calling Cspks_Req_Utils.Fn_Maint_Basic_Validations..');
      IF NOT Cspks_Req_Utils.Fn_Maint_Basic_Validations (p_source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Prev_ifdncsft.v_iftbs_ncs_master.Mod_No,
         p_ifdncsft.v_iftbs_ncs_master.Mod_No,
         p_Prev_ifdncsft.v_iftbs_ncs_master.Auth_Stat,
         p_Prev_ifdncsft.v_iftbs_ncs_master.Record_Stat,
         p_Prev_ifdncsft.v_iftbs_ncs_master.Once_Auth,
         l_Prev_Key_Tags,
         l_Prev_Key_Vals,
         g_Key_Id,
         l_Key,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Maint_Basic_Validations..');
         RETURN FALSE;
      END IF;
      IF ( p_Action_Code IN (Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Delete,Cspks_Req_Global.p_Version_Delete,Cspks_Req_Global.p_Query) OR
            ( p_Action_Code = Cspks_Req_Global.p_Modify AND NVL(p_Prev_ifdncsft.v_iftbs_ncs_master.Once_Auth,'N') = 'Y')) THEN
         p_Wrk_ifdncsft := p_Prev_ifdncsft;
         p_wrk_ifdncsft.v_iftbs_ncs_master.Mod_No := p_ifdncsft.v_iftbs_ncs_master.Mod_No;
         p_Wrk_ifdncsft.Addl_Info := p_ifdncsft.Addl_Info ;
      ELSE
         p_Wrk_ifdncsft := p_ifdncsft;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Auth THEN
         IF p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No IS NULL THEN
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No           := p_prev_ifdncsft.v_iftbs_ncs_master.Mod_No;
         END IF;
         p_Wrk_ifdncsft.v_iftbs_ncs_master.Checker_dt_stamp   := fn_mntstamp;
         p_Wrk_ifdncsft.v_iftbs_ncs_master.Checker_id         := Global.user_id;
      ELSIF p_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen) THEN
         p_Wrk_ifdncsft.v_iftbs_ncs_master.Auth_Stat        := 'U';
         IF NOT Cspks_Req_Global.Fn_UnTanking THEN
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Maker_Id         := Global.User_Id;
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Maker_Dt_Stamp   := Fn_Mntstamp;
         ELSE
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Maker_Id         := NVL(p_ifdncsft.v_iftbs_ncs_master.Maker_Id,Global.User_Id);
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Maker_Dt_Stamp   := NVL(p_ifdncsft.v_iftbs_ncs_master.Maker_Dt_Stamp,Fn_Mntstamp);
         END IF;

         IF p_Action_Code = Cspks_Req_Global.p_New THEN
            IF NOT Cspks_Req_Global.Fn_UnTanking THEN
               p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No           := 1;
            ELSE
               p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No := NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No,1);
            END IF;
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Record_Stat      := 'O';
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Once_Auth        := 'N';
         ELSE
            IF NOT Cspks_Req_Global.Fn_UnTanking THEN
               p_wrk_ifdncsft.v_iftbs_ncs_master.Mod_No           := NVL(p_prev_ifdncsft.v_iftbs_ncs_master.Mod_No,0)+1;
            ELSE
               p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No           := NVL(p_ifdncsft.v_iftbs_ncs_master.Mod_No,1);
            END IF;
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Once_Auth           := NVL(p_Prev_ifdncsft.v_iftbs_ncs_master.Once_Auth,'N');
            p_wrk_ifdncsft.v_iftbs_ncs_master.Record_Stat           := NVL(p_prev_ifdncsft.v_iftbs_ncs_master.Record_Stat,'O');
         END IF;
         IF p_Action_Code = Cspks_Req_Global.p_Close THEN
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Record_Stat      := 'C';
         ELSIF p_Action_Code = Cspks_Req_Global.p_Reopen THEN
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Record_Stat      := 'O';
         END IF;
         p_Wrk_ifdncsft.v_iftbs_ncs_master.Checker_id         := Null;
         p_Wrk_ifdncsft.v_iftbs_ncs_master.Checker_Dt_Stamp         := Null;
      ELSIF p_Action_Code IN ( Cspks_Req_Global.p_Delete,Cspks_Req_Global.p_Version_Delete) THEN
         IF p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No IS NULL THEN
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No           := p_Prev_ifdncsft.v_iftbs_ncs_master.Mod_No;
         END IF;
      END IF;
      IF p_Action_Code in  (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify) THEN
         Dbg('Calling .Fn_Sys_Basic_Vals..');
         IF NOT Fn_Sys_Basic_Vals(p_Source,
            p_ifdncsft,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Basic_Vals..');
            RETURN FALSE;
         END IF;

         IF p_Action_Code = Cspks_Req_Global.p_New OR  ( p_Action_Code = Cspks_Req_Global.p_Modify AND p_Prev_ifdncsft.v_iftbs_ncs_master.Once_Auth = 'N') THEN
            Dbg('Calling .Fn_Sys_Default_Vals..');
            IF NOT Fn_Sys_Default_Vals(p_Source,
               p_Wrk_ifdncsft,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in .Fn_Sys_Default_Vals..');
               RETURN FALSE;
            END IF;

         END IF;
         IF p_Action_Code = Cspks_Req_Global.p_Modify AND p_Prev_ifdncsft.v_iftbs_ncs_master.Once_Auth = 'Y'THEN
            Dbg('Calling Fn_Sys_Merge_Amendables..');
            IF NOT Fn_Sys_Merge_Amendables(p_Source,
               p_Source_Operation,
               p_ifdncsft,
               p_Prev_ifdncsft,
               p_Wrk_ifdncsft,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in .Fn_Sys_Merge_Amendables..');
               RETURN FALSE;
            END IF;
         END IF;

         Dbg('Calling .Fn_Sys_Check_Mandatory_Nodes..');
         IF NOT Fn_Sys_Check_Mandatory_Nodes(p_source,
            p_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Check_Mandatory_Nodes..');
            RETURN FALSE;
         END IF;

         Dbg('Calling  .Fn_Sys_Lov_Vals..');
         IF NOT Fn_Sys_Lov_Vals(p_source,
            p_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Lov_Vals..');
            RETURN FALSE;
         END IF;

      END IF;
      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdncsft_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_ifdncsft  IN   OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Sys_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_ifdncsft         IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Wrk_ifdncsft  IN   OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Wrk_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists        BOOLEAN := TRUE;
      RECORD_LOCKED    EXCEPTION;
      PRAGMA EXCEPTION_INIT( RECORD_LOCKED, -54 );
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      Cursor c_v_iftbs_ncs_charge IS
      SELECT *
      FROM   IFTB_NCS_CHARGE
      WHERE related_ref_no = p_wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no
      ;
   BEGIN
      Dbg('In Fn_Sys_Query..');
      IF p_QryData_Reqd = 'Q' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_ifdncsft,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      ELSE
         l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_MASTER.RELATED_REF_NO')||'-'||
         p_ifdncsft.v_iftbs_ncs_master.related_ref_no;
         Dbg('Get The Master Record...');
         IF NVL(p_With_Lock,'N') = 'Y' THEN
            BEGIN
               SELECT *
               INTO   p_wrk_ifdncsft.v_iftbs_ncs_master
               FROM  IFTB_NCS_MASTER
               WHERE related_ref_no = p_ifdncsft.v_iftbs_ncs_master.related_ref_no
                FOR UPDATE NOWAIT;
            EXCEPTION
               WHEN RECORD_LOCKED THEN
                  Dbg('Failed to Obtain the Lock..');
                  Pr_Log_Error(p_Source,'ST-LOCK-001',NULL);
                  RETURN FALSE;
               WHEN No_Data_Found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  l_Rec_Exists := FALSE;
            END;

         ELSE
            BEGIN
               SELECT *
               INTO   p_Wrk_ifdncsft.v_iftbs_ncs_master
               FROM  IFTB_NCS_MASTER
               WHERE related_ref_no = p_ifdncsft.v_iftbs_ncs_master.related_ref_no
               ;
            EXCEPTION
               WHEN no_data_found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  p_Err_Code    := 'ST-VALS-002';
                  p_Err_Params  := l_Key;
                  RETURN FALSE;
            END;

         END IF;
         IF p_Full_Data = 'Y' AND l_Rec_Exists THEN
            Dbg('Get the Record For :IFTBS_NCS_MASTER');
            BEGIN
               SELECT *
               INTO p_Wrk_ifdncsft.v_iftbs_ncs_master
               FROM   IFTB_NCS_MASTER
               WHERE related_ref_no = p_wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :IFTBS_NCS_MASTER');
            END;
            Dbg('Get the Record For :IFTBS_NCS_CHARGE');
            OPEN c_v_iftbs_ncs_charge;
            LOOP
               FETCH c_v_iftbs_ncs_charge
               BULK COLLECT INTO p_Wrk_ifdncsft.v_iftbs_ncs_charge;
                EXIT WHEN c_v_iftbs_ncs_charge%NOTFOUND;
            END LOOP;
            CLOSE c_v_iftbs_ncs_charge;

         END IF;
         IF p_QryData_Reqd = 'Y' THEN
            Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
            IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Wrk_ifdncsft,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
               RETURN FALSE;
            END IF;
         END IF;

      END IF;
      Dbg('Returning Success From Fn_Sys_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         IF  c_v_iftbs_ncs_charge%ISOPEN THEN
            CLOSE c_v_iftbs_ncs_charge;
         END IF;
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query;
   FUNCTION Fn_Sys_Upload_Db         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdncsft     IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Prev_ifdncsft     IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Wrk_ifdncsft      IN OUT  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Count             NUMBER:= 0;
      l_Ins_Count         NUMBER:= 0;
      l_Upd_Count         NUMBER:= 0;
      l_Del_Count         NUMBER:= 0;
      l_Wrk_Count         NUMBER:= 0;
      l_Prev_Count        NUMBER:= 0;
      l_Rec_Found         BOOLEAN:= FALSE;
      l_Row_Id            ROWID;
      l_Key               VARCHAR2(5000):= NULL;
      l_Auth_Stat         VARCHAR2(1) := 'A';
      l_Base_Data_From_Fc VARCHAR2(1):= 'Y';
      I_v_iftbs_ncs_charge       ifpks_ifdncsft_Main.Ty_Tb_v_iftbs_ncs_charge;
      U_v_iftbs_ncs_charge       ifpks_ifdncsft_Main.Ty_Tb_v_iftbs_ncs_charge;
      D_v_iftbs_ncs_charge       ifpks_ifdncsft_Main.Ty_Tb_v_iftbs_ncs_charge;
   BEGIN
      Dbg('In Fn_Sys_Upload_Db..');
      IF p_Action_Code = Cspks_Req_Global.p_new THEN

         Dbg('Inserting Into IFTBS_NCS_MASTER..');
         BEGIN
            IF  p_wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  IFTB_NCS_MASTER
               VALUES p_wrk_ifdncsft.v_iftbs_ncs_master;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoIFTBS_NCS_MASTER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@IFTBS_NCS_MASTER';
               RETURN FALSE;
         END;

         Dbg('Inserting Into IFTBS_NCS_CHARGE..');
         BEGIN
            l_Count      := p_wrk_ifdncsft.v_iftbs_ncs_charge.COUNT;
            FORALL l_index IN  1..l_count
            INSERT INTO IFTB_NCS_CHARGE
            VALUES p_wrk_ifdncsft.v_iftbs_ncs_charge(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoIFTBS_NCS_CHARGE..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@IFTBS_NCS_CHARGE';
               RETURN FALSE;
         END;
      ELSIF p_Action_Code = Cspks_Req_Global.p_modify THEN

         Dbg('Updating Single Record Node :  IFTBS_NCS_MASTER..');
         BEGIN
            UPDATE IFTB_NCS_MASTER
            SET
            BRANCH_CODE = p_Wrk_ifdncsft.v_iftbs_ncs_master.BRANCH_CODE,
            TRN_REF_NO = p_Wrk_ifdncsft.v_iftbs_ncs_master.TRN_REF_NO,
            TRANSFER_DATE = p_Wrk_ifdncsft.v_iftbs_ncs_master.TRANSFER_DATE,
            TXN_CCY = p_Wrk_ifdncsft.v_iftbs_ncs_master.TXN_CCY,
            TXN_AMT = p_Wrk_ifdncsft.v_iftbs_ncs_master.TXN_AMT,
            TOT_CHG_AMT = p_Wrk_ifdncsft.v_iftbs_ncs_master.TOT_CHG_AMT,
            NET_TXN_AMT = p_Wrk_ifdncsft.v_iftbs_ncs_master.NET_TXN_AMT,
            EXCH_RATE = p_Wrk_ifdncsft.v_iftbs_ncs_master.EXCH_RATE,
            REM_ACC = p_Wrk_ifdncsft.v_iftbs_ncs_master.REM_ACC,
            REM_NAME = p_Wrk_ifdncsft.v_iftbs_ncs_master.REM_NAME,
            BEN_ACC = p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_ACC,
            BEN_BIC = p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_BIC,
            BEN_NAME = p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_NAME,
            BEN_ADD1 = p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_ADD1,
            BEN_ADD2 = p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_ADD2,
            BEN_ADD3 = p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_ADD3,
            BEN_ADD4 = p_Wrk_ifdncsft.v_iftbs_ncs_master.BEN_ADD4,
            PURPOSE_OF_TRF = p_Wrk_ifdncsft.v_iftbs_ncs_master.PURPOSE_OF_TRF,
            BANK_NAME = p_Wrk_ifdncsft.v_iftbs_ncs_master.BANK_NAME,
            DR_AMOUNT = p_Wrk_ifdncsft.v_iftbs_ncs_master.DR_AMOUNT,
            DR_ACC_CCY = p_Wrk_ifdncsft.v_iftbs_ncs_master.DR_ACC_CCY,
            MSG_FLOW = p_Wrk_ifdncsft.v_iftbs_ncs_master.MSG_FLOW,
            REQUESTOR_BRANCH = p_Wrk_ifdncsft.v_iftbs_ncs_master.REQUESTOR_BRANCH,
            WAIVE_CHARGE = p_Wrk_ifdncsft.v_iftbs_ncs_master.WAIVE_CHARGE,
            INC_TXN_STATUS = p_Wrk_ifdncsft.v_iftbs_ncs_master.INC_TXN_STATUS,
            INC_TXN_FAIL_REASON = p_Wrk_ifdncsft.v_iftbs_ncs_master.INC_TXN_FAIL_REASON,
            BATCH_NO = p_Wrk_ifdncsft.v_iftbs_ncs_master.BATCH_NO,
            REM_ACC_BRANCH = p_Wrk_ifdncsft.v_iftbs_ncs_master.REM_ACC_BRANCH,
            PAYER_BIC_CODE = p_Wrk_ifdncsft.v_iftbs_ncs_master.PAYER_BIC_CODE,
            PAYER_BANK_NAME = p_Wrk_ifdncsft.v_iftbs_ncs_master.PAYER_BANK_NAME,
            MAKER_ID = p_Wrk_ifdncsft.v_iftbs_ncs_master.MAKER_ID,
            MAKER_DT_STAMP = p_Wrk_ifdncsft.v_iftbs_ncs_master.MAKER_DT_STAMP,
            CHECKER_ID = p_Wrk_ifdncsft.v_iftbs_ncs_master.CHECKER_ID,
            CHECKER_DT_STAMP = p_Wrk_ifdncsft.v_iftbs_ncs_master.CHECKER_DT_STAMP,
            MOD_NO = p_Wrk_ifdncsft.v_iftbs_ncs_master.MOD_NO,
            RECORD_STAT = p_Wrk_ifdncsft.v_iftbs_ncs_master.RECORD_STAT,
            AUTH_STAT = p_Wrk_ifdncsft.v_iftbs_ncs_master.AUTH_STAT,
            ONCE_AUTH = p_Wrk_ifdncsft.v_iftbs_ncs_master.ONCE_AUTH
WHERE related_ref_no = p_Wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no
;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert Into IFTBS_NCS_MASTER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@IFTBS_NCS_MASTER';
               RETURN FALSE;
         END;


         Dbg('Preapring Insert and Update Types for  IFTBS_NCS_CHARGE..');
         l_Wrk_Count  := p_Wrk_ifdncsft.v_iftbs_ncs_charge.COUNT;
         l_Prev_Count := p_Prev_ifdncsft.v_iftbs_ncs_charge.COUNT;
         IF l_Wrk_Count > 0 THEN
            FOR l_index IN 1 .. l_Wrk_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Prev_Count >  0 THEN
                  FOR l_index1 IN 1..l_Prev_Count  LOOP
                     IF (NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno,-1)=  NVL(p_Prev_ifdncsft.v_iftbs_ncs_charge  (l_index1).chg_srno,-1)) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_rec_found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF l_rec_found THEN
                  Dbg('Record is Modified...');
                  U_v_iftbs_ncs_charge(U_v_iftbs_ncs_charge.COUNT +1 ) :=  p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index);
               ELSE
                  Dbg('Record is Added...');
                  I_v_iftbs_ncs_charge(I_v_iftbs_ncs_charge.COUNT +1 ) :=  p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index);
               END IF;
            END LOOP;
         END IF;

         Dbg('Preapring Delete Types for  IFTBS_NCS_CHARGE..');
         l_Wrk_Count  := p_wrk_ifdncsft.v_iftbs_ncs_charge.COUNT;
         l_Prev_Count := p_prev_ifdncsft.v_iftbs_ncs_charge.COUNT;
         IF l_Prev_Count > 0 THEN
            FOR l_index1 IN 1 .. l_Prev_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Wrk_Count >  0 THEN
                  FOR l_index IN 1..l_Wrk_Count  LOOP
                     IF (NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno,-1)=  NVL(p_Prev_ifdncsft.v_iftbs_ncs_charge  (l_index1).chg_srno,-1)) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_Rec_Found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF NOT l_Rec_Found THEN
                  Dbg('Record is Deleted...');
                  D_v_iftbs_ncs_charge(D_v_iftbs_ncs_charge.COUNT +1 ) :=  p_Prev_ifdncsft.v_iftbs_ncs_charge(l_index1);
               END IF;
            END LOOP;
         END IF;
         l_Del_Count  := D_v_iftbs_ncs_charge.COUNT;
         Dbg('Records Deleted  :'||l_Del_Count);
         IF l_Del_Count > 0 THEN
            FOR l_index IN 1 .. l_del_count LOOP
               Dbg('Deleting Record...');
               DELETE IFTB_NCS_CHARGE
               WHERE related_ref_no = D_v_iftbs_ncs_charge(l_index).related_ref_no
                AND chg_srno = D_v_iftbs_ncs_charge(l_index).chg_srno
               ;
            END LOOP;
         END IF;
         l_Ins_Count  := I_v_iftbs_ncs_charge.COUNT;
         Dbg('New Records Added  :'||l_ins_count);
         BEGIN
            l_Count      := I_v_iftbs_ncs_charge.COUNT;
            FORALL l_Index IN  1..l_count
            INSERT INTO IFTB_NCS_CHARGE
            VALUES I_v_iftbs_ncs_charge(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert IntoIFTBS_NCS_CHARGE..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@IFTBS_NCS_CHARGE';
               RETURN FALSE;
         END;
         l_Upd_Count  := U_v_iftbs_ncs_charge.COUNT;
         Dbg('Records Modified  :'||l_Upd_Count);
         IF l_Upd_Count > 0 THEN
            FOR l_index IN 1 .. l_Upd_Count LOOP
               Dbg('Updating The  Record...');
               BEGIN
                  UPDATE IFTB_NCS_CHARGE
                  SET
                  CHG1_TYPE = U_v_iftbs_ncs_charge(l_index).CHG1_TYPE,
                  CHG1_IN_TXN = U_v_iftbs_ncs_charge(l_index).CHG1_IN_TXN,
                  CHG1_IN_ACC = U_v_iftbs_ncs_charge(l_index).CHG1_IN_ACC,
                  CHG2_TYPE = U_v_iftbs_ncs_charge(l_index).CHG2_TYPE,
                  CHG2_IN_TXN = U_v_iftbs_ncs_charge(l_index).CHG2_IN_TXN,
                  CHG2_IN_ACC = U_v_iftbs_ncs_charge(l_index).CHG2_IN_ACC,
                  CHG3_TYPE = U_v_iftbs_ncs_charge(l_index).CHG3_TYPE,
                  CHG3_IN_TXN = U_v_iftbs_ncs_charge(l_index).CHG3_IN_TXN,
                  CHG3_IN_ACC = U_v_iftbs_ncs_charge(l_index).CHG3_IN_ACC,
                  OTH_CCY = U_v_iftbs_ncs_charge(l_index).OTH_CCY,
                  TXN_XRATE = U_v_iftbs_ncs_charge(l_index).TXN_XRATE,
                  ACC_XRATE = U_v_iftbs_ncs_charge(l_index).ACC_XRATE,
                  TRN_REF_NO = U_v_iftbs_ncs_charge(l_index).TRN_REF_NO,
                  CHG1_DESC = U_v_iftbs_ncs_charge(l_index).CHG1_DESC,
                  CHG1_WAIVER = U_v_iftbs_ncs_charge(l_index).CHG1_WAIVER,
                  CHG1_AMT = U_v_iftbs_ncs_charge(l_index).CHG1_AMT,
                  CHG1_CCY = U_v_iftbs_ncs_charge(l_index).CHG1_CCY,
                  LCY_CHG1 = U_v_iftbs_ncs_charge(l_index).LCY_CHG1,
                  FCY_CHG1 = U_v_iftbs_ncs_charge(l_index).FCY_CHG1,
                  CHG1_GL = U_v_iftbs_ncs_charge(l_index).CHG1_GL,
                  CHG2_DESC = U_v_iftbs_ncs_charge(l_index).CHG2_DESC,
                  CHG2_WAIVER = U_v_iftbs_ncs_charge(l_index).CHG2_WAIVER,
                  CHG2_AMT = U_v_iftbs_ncs_charge(l_index).CHG2_AMT,
                  CHG2_CCY = U_v_iftbs_ncs_charge(l_index).CHG2_CCY,
                  LCY_CHG2 = U_v_iftbs_ncs_charge(l_index).LCY_CHG2,
                  FCY_CHG2 = U_v_iftbs_ncs_charge(l_index).FCY_CHG2,
                  CHG2_GL = U_v_iftbs_ncs_charge(l_index).CHG2_GL,
                  CHG3_DESC = U_v_iftbs_ncs_charge(l_index).CHG3_DESC,
                  CHG3_WAIVER = U_v_iftbs_ncs_charge(l_index).CHG3_WAIVER,
                  CHG3_AMT = U_v_iftbs_ncs_charge(l_index).CHG3_AMT,
                  CHG3_CCY = U_v_iftbs_ncs_charge(l_index).CHG3_CCY,
                  LCY_CHG3 = U_v_iftbs_ncs_charge(l_index).LCY_CHG3,
                  FCY_CHG3 = U_v_iftbs_ncs_charge(l_index).FCY_CHG3,
                  CHG3_GL = U_v_iftbs_ncs_charge(l_index).CHG3_GL,
                  NETTING_REQ = U_v_iftbs_ncs_charge(l_index).NETTING_REQ,
                  XRATE = U_v_iftbs_ncs_charge(l_index).XRATE,
                  TXN_CODE = U_v_iftbs_ncs_charge(l_index).TXN_CODE
WHERE related_ref_no = U_v_iftbs_ncs_charge(l_index).related_ref_no
 AND chg_srno = U_v_iftbs_ncs_charge(l_index).chg_srno
;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Updating IFTBS_NCS_CHARGE..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@IFTBS_NCS_CHARGE';
                     RETURN FALSE;
               END;
            END LOOP;
         END IF;
      ELSIF p_Action_Code = Cspks_Req_Global.p_delete THEN
         Dbg('Action Code '||p_Action_Code);
         Dbg('Deleting The Data..');


         DELETE IFTB_NCS_CHARGE
         WHERE related_ref_no = p_Wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no
         ;

         DELETE IFTB_NCS_MASTER WHERE related_ref_no = p_Wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no
         ;


      ELSIF p_Action_Code IN (Cspks_Req_Global.p_Auth,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen ) THEN
         l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'IFTBS_NCS_MASTER.RELATED_REF_NO')||'-'||
         p_Wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no;
         BEGIN
            SELECT ROWID
            INTO   l_row_id
            FROM  IFTB_NCS_MASTER
            WHERE related_ref_no = p_Wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no
            ;
         EXCEPTION
            WHEN No_Data_Found THEN
               Dbg('Failed in Selecting The Previous Master Recotrd..');
               p_Err_Code    := 'ST-VALS-002';
               p_Err_Params  := l_key;
               RETURN FALSE;
         END;

         IF NOT Cspks_Req_Utils.Fn_Maint_Operations(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            'IFTB_NCS_MASTER',
            l_Row_Id,
            p_Wrk_ifdncsft.v_iftbs_ncs_master.mod_no,
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Maker_dt_Stamp,
            p_Wrk_ifdncsft.v_iftbs_ncs_master.Checker_dt_Stamp,
            g_Key_Id,
            l_Key,
            p_Err_Code,
            p_Err_params) THEN
            Dbg('Failed in Cspks_Req_Utils.Fn_Maint_Basic_Validations');
            RETURN FALSE;
         END IF;

      END IF;

      Dbg('Returning Success From Fn_Sys_Upload_Db');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Upload_Db;
   FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdncsft       IN   OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Build_Ws_Type..');

      IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
         IF NOT Fn_Sys_Build_Fc_Type(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_IFDNCSFT,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Fc_Type..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT Fn_Sys_Build_Ws_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_IFDNCSFT,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Ws_Type..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTTYPE');
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdncsft_Custom.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_IFDNCSFT,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Build_Type..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdncsft_Main.Fn_Build_Type ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Type;
   FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_exchange_pattern   IN  VARCHAR2,
      p_ifdncsft          IN ifpks_ifdncsft_Main.ty_ifdncsft,
      p_err_code        IN OUT VARCHAR2,
      p_err_params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

   BEGIN

      dbg('In Fn_Build_Ts_List..');

      IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
         IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_ifdncsft,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Fc_Ts');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            p_ifdncsft,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Ws_Ts');
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning from Fn_Build_Ts_List');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of ifpks_ifdncsft_Main.Fn_Build_Ts_List ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Build_Ts_List;
   FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdncsft       IN  OUT ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Key_Cols        VARCHAR2(32767);
      l_Key_Vals        VARCHAR2(32767);
      l_Func_Type       VARCHAR2(32767);
   BEGIN

      Dbg('In Fn_Get_Key_Information..');
      l_Key_Cols := 'RELATED_REF_NO~';
      l_Key_Vals := p_ifdncsft.v_iftbs_ncs_master.related_ref_no||'~';
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
      IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code ,
         'FCCMAINTENANCE',
         'IFTBS_NCS_MASTER',
         'BLK_NCS_MASTER',
         'Fast-Master',
         l_Key_Cols,
         l_Key_Vals,
         p_ifdncsft.Addl_Info,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
         RETURN FALSE;
      END IF;
      IF p_ifdncsft.Addl_Info.EXISTS('RECORD_KEY') THEN
         G_Req_Key :=  p_ifdncsft.Addl_Info('RECORD_KEY');
      END IF;
      IF p_ifdncsft.Addl_Info.EXISTS('KEY_ID') THEN
         G_Key_Id :=  p_ifdncsft.Addl_Info('KEY_ID');
      END IF;
      p_ifdncsft.Addl_Info('SENT_MOD_NO') :=p_ifdncsft.v_iftbs_ncs_master.Mod_No;
      Dbg('Returning Succsess From Fn_Get_Key_Information..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdncsft_Main.Fn_Get_Key_Information..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Key_Information;
   FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_ifdncsft IN OUT  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
     RETURN BOOLEAN IS

      l_Pk_Or_Full      VARCHAR2(10) :=  'FULL';
      l_Blk      VARCHAR2(100) ;
      l_Fld      VARCHAR2(100) ;
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation      VARCHAR2(100) := p_Source_Operation;

   BEGIN

      Dbg('In Fn_Check_Mandatory..');

      IF p_Pk_Or_Full = 'FULL' OR p_Action_Code = Cspks_Req_Global.p_New THEN
         l_Pk_Or_Full := 'FULL';
      ELSE
         l_Pk_Or_Full := p_Pk_Or_Full;
      END IF;
      Pr_Skip_Handler('PREMAND');
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdncsft_Custom.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_ifdncsft,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  ifpks_ifdncsft_Custom.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;

      IF NOT ifpks_ifdncsft_Main.Fn_Skip_Sys THEN
         Dbg('Calling   Fn_Sys_Check_Mandatory..');
         IF NOT Fn_Sys_Check_Mandatory(p_Source,
            l_Pk_Or_Full,
            p_ifdncsft,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;

      Pr_Skip_Handler('POSTMAND');
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdncsft_Custom.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            l_Pk_Or_Full,
            p_ifdncsft,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  ifpks_ifdncsft_Custom.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdncsft_Main.Fn_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Check_Mandatory;
   FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_ifdncsft         IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Wrk_ifdncsft  IN   OUT  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Key_Vals VARCHAR2(32767);
      l_Tanked_data_Found             BOOLEAN := FALSE;
      l_Bld_Type_From_Tanked_Data     BOOLEAN := FALSE;
      l_Mod_No                        NUMBER;
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Skip_custom      BOOLEAN := FALSE;

   BEGIN

      Dbg('In Fn_Query..');

      l_Mod_No := p_ifdncsft.v_iftbs_ncs_master.Mod_No;
      Dbg('Calling Cspks_Req_Utils.Fn_Get_From_Tanked.');
      IF NOT Cspks_Req_Utils.Fn_Get_Tanked_Data (p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         g_Key_Id,
         l_Mod_No,
         NVL(p_With_Lock,'N'),
         l_Tanked_data_Found,
         l_Bld_Type_From_Tanked_Data,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_From_Tanked.');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      IF l_Tanked_data_Found THEN
         IF l_Bld_Type_From_Tanked_Data THEN
            IF NOT  Fn_Sys_Build_Fc_Type(p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_ifdncsft.Addl_Info,
               p_Wrk_ifdncsft,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Sys_Build_Fc_Type..');
               l_Tanked_data_Found      := FALSE;
               Pr_Log_Error(p_Source,'ST-TANK-001',NULL);
            END IF;
            g_Curr_Stage := 'POSTTANKQRY' ;
            l_Skip_custom:= g_Skip_custom;
            ifpks_ifdncsft_Main.Pr_Set_Skip_custom;
            Pr_Skip_Handler('POSTTANKQRY');
            Dbg('Calling Post Query Hooks After Query Of Tanked Data');
            IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
               IF NOT ifpks_ifdncsft_Custom.Fn_Post_Query (p_Source,
                  p_Source_operation,
                  p_Function_id,
                  p_Action_Code,
                  p_Function_Id  ,
                  p_Full_Data,
                  p_With_Lock,
                  p_Qrydata_Reqd,
                  p_ifdncsft,
                  p_Wrk_ifdncsft,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Post_Query of Tanked Data');
                  RETURN FALSE;
               END IF;
            END IF;
            g_Skip_custom:= l_Skip_custom;
            g_Curr_Stage := NULL ;
         END IF ;
      ELSE
         Dbg('Query From Base Tables..');
         Pr_Skip_Handler('PREQRY');
         IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
            IF NOT ifpks_ifdncsft_Custom.Fn_Pre_Query (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               p_Full_Data  ,
               p_With_Lock,
               p_QryData_Reqd,
               p_ifdncsft,
               p_Wrk_ifdncsft,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Pre_Query..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT ifpks_ifdncsft_Main.Fn_Skip_Sys THEN
            IF NOT Fn_Sys_Query (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Full_Data  ,
               p_With_Lock,
               p_QryData_Reqd,
               p_ifdncsft,
               p_Wrk_ifdncsft,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query..');
               RETURN FALSE;
            END IF;
         END IF;
         Pr_Skip_Handler('POSTQRY');
         IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
            IF NOT ifpks_ifdncsft_Custom.Fn_Post_Query (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               p_Full_Data  ,
               p_With_Lock,
               p_QryData_Reqd,
               p_ifdncsft,
               p_Wrk_ifdncsft,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Post_Query..');
               RETURN FALSE;
            END IF;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Query..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Query;
   FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdncsft     IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Prev_ifdncsft IN OUT  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Wrk_ifdncsft IN OUT  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Check_Amendables  VARCHAR2(1) := 'N';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Full_data    VARCHAR2(1) := 'N';
      l_With_Lock    VARCHAR2(1) := 'Y';
      l_Qrydata_Reqd    VARCHAR2(1) := 'N';
      l_Pk_Or_Full      VARCHAR2(10) := 'FULL';


   BEGIN

      Dbg('In Fn_Default_And_Validate..');

      l_Full_data   := 'Y';
      Dbg('Calling  Fn_Query..');
      IF NOT Fn_Query(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Full_data,
         l_With_Lock,
         l_Qrydata_Reqd,
         p_ifdncsft,
         p_Prev_ifdncsft,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Query..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('PREDFLT');
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdncsft_Custom.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_ifdncsft,
            p_Prev_ifdncsft,
            p_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Pre_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_Sys THEN
         Dbg('Calling in Fn_Sys_Default_and_Validate..');
         IF NOT Fn_Sys_Default_and_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdncsft,
            p_Prev_ifdncsft,
            p_Wrk_ifdncsft,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Default_and_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTDFLT');
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdncsft_Custom.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_ifdncsft,
            p_Prev_ifdncsft,
            p_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
         Dbg('Calling  Fn_Check_Mandatory..');
         IF NOT Fn_Check_Mandatory(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Pk_Or_Full,
            p_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdncsft_Main.Fn_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Default_And_Validate;
   FUNCTION Fn_Upload_Db  (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Post_Upl_Stat    IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_ifdncsft     IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Prev_ifdncsft     IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Wrk_ifdncsft      IN OUT  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Upload_Db..');

      Pr_Skip_Handler('PREUPLD');
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdncsft_Custom.Fn_Pre_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_ifdncsft,
            p_Prev_ifdncsft,
            p_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_Sys THEN
         IF NOT Fn_Sys_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_ifdncsft,
            p_Prev_ifdncsft,
            p_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;

      Pr_Skip_Handler('POSTUPLD');
      IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdncsft_Custom.Fn_Post_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_ifdncsft,
            p_Prev_ifdncsft,
            p_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success  From Fn_Upload_Db..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdncsft_Main.Fn_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Upload_Db;
   FUNCTION Fn_Populate_Record_Master (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_ifdncsft          IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
                              p_Record_Master     IN OUT Sttbs_Record_Master%ROWTYPE,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Summary_Rec     IFTB_NCS_MASTER%ROWTYPE;
      l_Summary_Rec_Found BOOLEAN := TRUE;
   BEGIN

      Dbg('In Fn_Populate_Record_Master..');

      IF  p_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen) THEN
         Dbg('Populating Record Master ..');
         IF g_Key_Id IS NOT NULL THEN
            l_Summary_Rec := p_ifdncsft.v_iftbs_ncs_master;
            IF l_Summary_Rec_Found THEN
               Dbg('Summary Record Found..');
               p_Record_Master.Key_Id := g_Key_Id;
               p_Record_Master.AUTH_STAT := l_Summary_Rec.AUTH_STAT;
               p_Record_Master.RECORD_STAT := l_Summary_Rec.RECORD_STAT;
               p_Record_Master.CHAR_FLD_1 := l_Summary_Rec.TRN_REF_NO;
               p_Record_Master.CHAR_FLD_2 := l_Summary_Rec.REM_ACC;
               p_Record_Master.CHAR_FLD_3 := l_Summary_Rec.REM_NAME;
               p_Record_Master.CHAR_FLD_4 := l_Summary_Rec.BEN_ACC;
               p_Record_Master.CHAR_FLD_5 := l_Summary_Rec.BEN_NAME;
               p_Record_Master.NUM_FLD_1 := l_Summary_Rec.TXN_AMT;
               p_Record_Master.CHAR_FLD_6 := l_Summary_Rec.BRANCH_CODE;
               p_Record_Master.DATE_FLD_1 := l_Summary_Rec.TRANSFER_DATE;
               p_Record_Master.CHAR_FLD_7 := l_Summary_Rec.RELATED_REF_NO;
               p_Record_Master.CHAR_FLD_8 := l_Summary_Rec.MSG_FLOW;
               p_Record_Master.CHAR_FLD_9 := l_Summary_Rec.INC_TXN_STATUS;
               p_Record_Master.CHAR_FLD_10 := l_Summary_Rec.BATCH_NO;
               p_Record_Master.CHAR_FLD_11 := l_Summary_Rec.PAYER_BIC_CODE;
               p_Record_Master.CHAR_FLD_12 := l_Summary_Rec.PAYER_BANK_NAME;
            END IF;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Populate_Record_Master..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of Fn_Populate_Record_Master ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Populate_Record_Master;

   FUNCTION Fn_Tank_Modification   (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Tanking_Status    IN OUT VARCHAR2,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

   BEGIN

      Dbg('In Fn_Tank_Modification..');
      p_Tanking_Status := 'N';
      IF Cspks_Req_Utils.Fn_Tank_Modification(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Rolling Back The Modification..');
         p_Tanking_Status := 'T';
         g_Tanking_Status := 'T';
         ROLLBACK TO Sp_Main_Ifdncsft;
      END IF;

      Dbg('Returning Success From Fn_Tank_Modification..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Tank_Modification ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Tank_Modification;

   FUNCTION Fn_Maint_Log (p_Source            IN     VARCHAR2,
                              p_Source_Operation IN     VARCHAR2,
                              p_Function_Id      IN     VARCHAR2,
                              p_Action_Code      IN     VARCHAR2,
                              p_Multi_Trip_Id       IN     VARCHAR2,
                              p_Request_No          IN     VARCHAR2,
                              p_Record_Master     IN  Sttbs_Record_Master%ROWTYPE,
                              p_ifdncsft          IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
                              p_Prev_ifdncsft          IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
                              p_wrk_ifdncsft          IN  ifpks_ifdncsft_Main.Ty_ifdncsft,
      p_Tanking_Status IN VARCHAR2,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function VARCHAR2(50) := p_Function_id;
      l_Auth_Stat       VARCHAR2(32767):= NULL;
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Id         VARCHAR2(32767):= g_Key_Id;
      l_Mod_No          NUMBER := 1;
      l_Blk             VARCHAR2(32767):= NULL;
      l_Fld             VARCHAR2(32767):= NULL;
      l_Dbt             VARCHAR2(32767):= NULL;
      l_Dbc             VARCHAR2(32767):= NULL;
      l_Rec_Action      VARCHAR2(32767):= 'M';
      l_Dtl_Key          VARCHAR2(32767):= NULL;
      l_Prev_Count      NUMBER := 0;
      l_Wrk_Count      NUMBER := 0;
      l_Count          NUMBER := 0;
      l_Log_Count       NUMBER := 0;
      l_Fld_Count       NUMBER := 0;
      l_Matched_Rec     NUMBER := 0;
      l_Rec_Found       BOOLEAN:= FALSE;
      l_Prev_Found       BOOLEAN:= FALSE;
      l_Wrk_Found       BOOLEAN:= FALSE;
      l_Rec_Modified    BOOLEAN:= FALSE;
      l_Record_log      Sttbs_Record_Log%ROWTYPE;
      l_Field_log       Sttbs_Field_log%ROWTYPE;
      l_wrk_ifdncsft      ifpks_ifdncsft_Main.Ty_ifdncsft;
      l_Skip_custom      BOOLEAN := FALSE;
      l_Tb_Field_Log    Cspks_Req_Global.Ty_Tb_Fld_Log;

      PROCEDURE Pr_Log_Change(p_Dbc     IN VARCHAR2,
                                 p_Action  IN VARCHAR2,
                                 p_Old_Val IN VARCHAR2,
                                 p_New_Val IN VARCHAR2) IS
      BEGIN
         IF NVL(p_Old_Val,'@') <> NVL(p_New_Val,'@') THEN
             l_Fld_Count := l_Fld_Count +1;
            l_Log_Count := NVL(l_Tb_Field_Log.COUNT,0) +1;
            l_Field_log.Detail_Key := l_Dtl_Key;
            l_Field_log.Block_Name := l_Blk;
            l_Field_log.Field_Name := p_Dbc;
            l_Field_log.Table_Name := l_Dbt;
            l_Field_log.Item_no := l_Fld_Count;
            l_Field_log.Record_Stat := p_Action;
            IF length(p_Old_Val)>2000 THEN
               l_Field_log.Old_Value := Substr(p_Old_Val,1,2000);
            ELSE
               l_Field_log.Old_Value := p_Old_Val;
            END IF;
            IF length(p_New_Val)>2000 THEN
               l_Field_log.New_Value := Substr(p_New_Val,1,2000);
            ELSE
               l_Field_log.New_Value := p_New_Val;
            END IF;
            l_Tb_Field_Log(l_Log_Count) := l_Field_log;
         END IF;
      END Pr_Log_Change;

   BEGIN

      Dbg('In Fn_Maint_Log');

      IF  p_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Auth,Cspks_Req_Global.p_Delete,Cspks_Req_Global.p_Version_Delete) THEN
         Dbg('Maintenance Log is Required ..');
         IF l_Key_Id IS NOT NULL THEN
            IF p_Action_Code IN( Cspks_Req_Global.p_auth,Cspks_Req_Global.p_Delete,Cspks_Req_Global.p_Version_Delete) THEN
               IF p_ifdncsft.v_iftbs_ncs_master.Mod_no IS NOT NULL THEN
                  l_Mod_No           := p_ifdncsft.v_iftbs_ncs_master.Mod_No;
               ELSE
                  l_Mod_No           := p_Wrk_ifdncsft.v_iftbs_ncs_master.Mod_No;
               END IF;
            ELSE
               l_mod_no           := p_wrk_ifdncsft.v_iftbs_ncs_master.mod_no;
            END IF;
              l_Auth_Stat := NVL(p_Wrk_ifdncsft.v_iftbs_ncs_master.Auth_Stat,'U') ;
            IF NOT Cspks_Req_Utils.Fn_Maint_Log(p_Source,
                p_Source_Operation  ,
                p_Function_Id ,
                p_Action_Code,
                p_Multi_Trip_Id ,
                p_Request_No ,
               'IFTBS_NCS_MASTER',
               l_Key_Id,
               l_Mod_No,
               l_Auth_Stat,
               p_Tanking_Status ,
               p_Record_Master ,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in   Cspks_Req_Utils.Fn_Maint_Log..');
               RETURN FALSE;
            END IF;
            IF Cspks_Req_Utils.Fn_Field_Log_Reqd(p_Function_Id,p_Action_Code) THEN
               l_Field_log.Key_id := l_Key_Id;
               l_Field_log.Mod_No := l_Mod_No;
               l_Field_log.Function_id := p_Function_Id;

               l_Dbt := 'IFTB_NCS_MASTER';

               l_Blk := 'IFTBS_NCS_MASTER';
               l_Rec_Modified := FALSE;
               l_Prev_Found := FALSE;
               l_Wrk_Found := FALSE;

               IF p_Prev_ifdncsft.v_iftbs_ncs_master.related_ref_no IS NOT NULL THEN
                  Dbg('Record Has Been Sent..');
                  l_prev_found := TRUE;
               END IF;
               IF p_Wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no IS NOT NULL THEN
                  Dbg('Record Has Been Sent..');
                  l_Wrk_Found := TRUE;
               END IF;
               IF l_Prev_Found   THEN
                  l_Dtl_key := '~IFTB_NCS_MASTER~'||p_Prev_ifdncsft.v_iftbs_ncs_master.related_ref_no||'~';
               ELSIF l_Wrk_Found   THEN
                  l_Dtl_key := '~IFTB_NCS_MASTER~'||p_Wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no||'~';
               END IF;
               IF l_Wrk_Found  OR l_Prev_Found THEN
                  IF l_Wrk_Found  AND l_Prev_Found THEN
                     l_rec_action := 'M';
                  ELSIF l_wrk_found  AND ( NOT l_Prev_Found) THEN
                     l_Rec_Action := 'N';
                  ELSIF (NOT l_wrk_Found)  AND l_Prev_Found THEN
                     l_Rec_Action := 'D';
                  END IF;
                  Pr_Log_Change('BRANCH_CODE',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.branch_code,p_Wrk_ifdncsft.v_iftbs_ncs_master.branch_code);
Pr_Log_Change('RELATED_REF_NO',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.related_ref_no,p_Wrk_ifdncsft.v_iftbs_ncs_master.related_ref_no);
Pr_Log_Change('TRN_REF_NO',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.trn_ref_no,p_Wrk_ifdncsft.v_iftbs_ncs_master.trn_ref_no);
Pr_Log_Change('TRANSFER_DATE',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.transfer_date,p_Wrk_ifdncsft.v_iftbs_ncs_master.transfer_date);
Pr_Log_Change('TXN_CCY',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.txn_ccy,p_Wrk_ifdncsft.v_iftbs_ncs_master.txn_ccy);
Pr_Log_Change('TXN_AMT',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.txn_amt,p_Wrk_ifdncsft.v_iftbs_ncs_master.txn_amt);
Pr_Log_Change('TOT_CHG_AMT',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.tot_chg_amt,p_Wrk_ifdncsft.v_iftbs_ncs_master.tot_chg_amt);
Pr_Log_Change('NET_TXN_AMT',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.net_txn_amt,p_Wrk_ifdncsft.v_iftbs_ncs_master.net_txn_amt);
Pr_Log_Change('EXCH_RATE',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.exch_rate,p_Wrk_ifdncsft.v_iftbs_ncs_master.exch_rate);
Pr_Log_Change('REM_ACC',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.rem_acc,p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_acc);
Pr_Log_Change('REM_NAME',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.rem_name,p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_name);
Pr_Log_Change('BEN_ACC',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.ben_acc,p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_acc);
Pr_Log_Change('BEN_BIC',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.ben_bic,p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_bic);
Pr_Log_Change('BEN_NAME',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.ben_name,p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_name);
Pr_Log_Change('BEN_ADD1',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.ben_add1,p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add1);
Pr_Log_Change('BEN_ADD2',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.ben_add2,p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add2);
Pr_Log_Change('BEN_ADD3',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.ben_add3,p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add3);
Pr_Log_Change('BEN_ADD4',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.ben_add4,p_Wrk_ifdncsft.v_iftbs_ncs_master.ben_add4);
Pr_Log_Change('PURPOSE_OF_TRF',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.purpose_of_trf,p_Wrk_ifdncsft.v_iftbs_ncs_master.purpose_of_trf);
Pr_Log_Change('BANK_NAME',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.bank_name,p_Wrk_ifdncsft.v_iftbs_ncs_master.bank_name);
Pr_Log_Change('DR_AMOUNT',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.dr_amount,p_Wrk_ifdncsft.v_iftbs_ncs_master.dr_amount);
Pr_Log_Change('DR_ACC_CCY',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy,p_Wrk_ifdncsft.v_iftbs_ncs_master.dr_acc_ccy);
Pr_Log_Change('MSG_FLOW',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.msg_flow,p_Wrk_ifdncsft.v_iftbs_ncs_master.msg_flow);
Pr_Log_Change('REQUESTOR_BRANCH',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.requestor_branch,p_Wrk_ifdncsft.v_iftbs_ncs_master.requestor_branch);
Pr_Log_Change('WAIVE_CHARGE',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.waive_charge,p_Wrk_ifdncsft.v_iftbs_ncs_master.waive_charge);
Pr_Log_Change('INC_TXN_STATUS',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.inc_txn_status,p_Wrk_ifdncsft.v_iftbs_ncs_master.inc_txn_status);
Pr_Log_Change('INC_TXN_FAIL_REASON',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason,p_Wrk_ifdncsft.v_iftbs_ncs_master.inc_txn_fail_reason);
Pr_Log_Change('BATCH_NO',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.batch_no,p_Wrk_ifdncsft.v_iftbs_ncs_master.batch_no);
Pr_Log_Change('REM_ACC_BRANCH',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.rem_acc_branch,p_Wrk_ifdncsft.v_iftbs_ncs_master.rem_acc_branch);
Pr_Log_Change('PAYER_BIC_CODE',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.payer_bic_code,p_Wrk_ifdncsft.v_iftbs_ncs_master.payer_bic_code);
Pr_Log_Change('PAYER_BANK_NAME',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.payer_bank_name,p_Wrk_ifdncsft.v_iftbs_ncs_master.payer_bank_name);
Pr_Log_Change('MAKER_ID',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.maker_id,p_Wrk_ifdncsft.v_iftbs_ncs_master.maker_id);
Pr_Log_Change('MAKER_DT_STAMP',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp,p_Wrk_ifdncsft.v_iftbs_ncs_master.maker_dt_stamp);
Pr_Log_Change('CHECKER_ID',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.checker_id,p_Wrk_ifdncsft.v_iftbs_ncs_master.checker_id);
Pr_Log_Change('CHECKER_DT_STAMP',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp,p_Wrk_ifdncsft.v_iftbs_ncs_master.checker_dt_stamp);
Pr_Log_Change('MOD_NO',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.mod_no,p_Wrk_ifdncsft.v_iftbs_ncs_master.mod_no);
Pr_Log_Change('RECORD_STAT',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.record_stat,p_Wrk_ifdncsft.v_iftbs_ncs_master.record_stat);
Pr_Log_Change('AUTH_STAT',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.auth_stat,p_Wrk_ifdncsft.v_iftbs_ncs_master.auth_stat);
Pr_Log_Change('ONCE_AUTH',l_Rec_Action,p_Prev_ifdncsft.v_iftbs_ncs_master.once_auth,p_Wrk_ifdncsft.v_iftbs_ncs_master.once_auth);


                              END IF;


               l_Dbt := 'IFTB_NCS_CHARGE';
               l_Blk := 'IFTBS_NCS_CHARGE';
               l_Wrk_Count  := p_Wrk_ifdncsft.v_iftbs_ncs_charge.COUNT;
               l_Prev_Count      := p_Prev_ifdncsft.v_iftbs_ncs_charge.COUNT;
               IF l_Wrk_count > 0 THEN
                  FOR l_Index IN 1..l_Wrk_count  LOOP
                     l_Dtl_key := '~IFTB_NCS_CHARGE~'||p_wrk_ifdncsft.v_iftbs_ncs_charge(l_index).related_ref_no||'~'||p_wrk_ifdncsft.v_iftbs_ncs_charge(l_index).chg_srno||'~';
                     l_Rec_Found := FALSE;
                     l_Rec_Modified := FALSE;
                     IF l_Prev_count > 0 THEN
                        FOR l_Index1 IN 1..l_Prev_count  LOOP
                           IF (NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg_srno,-1)=  NVL(p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg_srno,-1)) THEN
                              Dbg('Record Found..');
                              l_Rec_Found := TRUE;
                              l_Matched_Rec := l_Index1;
                              Pr_Log_Change('CHG1_TYPE','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg1_type,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_type);
Pr_Log_Change('CHG1_IN_TXN','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg1_in_txn,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_in_txn);
Pr_Log_Change('CHG1_IN_ACC','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg1_in_acc,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_in_acc);
Pr_Log_Change('CHG2_TYPE','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg2_type,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_type);
Pr_Log_Change('CHG2_IN_TXN','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg2_in_txn,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_in_txn);
Pr_Log_Change('CHG2_IN_ACC','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg2_in_acc,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_in_acc);
Pr_Log_Change('CHG3_TYPE','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg3_type,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_type);
Pr_Log_Change('CHG3_IN_TXN','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg3_in_txn,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_in_txn);
Pr_Log_Change('CHG3_IN_ACC','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg3_in_acc,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_in_acc);
Pr_Log_Change('OTH_CCY','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).oth_ccy,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).oth_ccy);
Pr_Log_Change('TXN_XRATE','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).txn_xrate,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).txn_xrate);
Pr_Log_Change('ACC_XRATE','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).acc_xrate,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).acc_xrate);
Pr_Log_Change('TRN_REF_NO','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).trn_ref_no,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).trn_ref_no);
Pr_Log_Change('CHG_SRNO','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg_srno,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg_srno);
Pr_Log_Change('CHG1_DESC','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg1_desc,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_desc);
Pr_Log_Change('CHG1_WAIVER','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg1_waiver,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_waiver);
Pr_Log_Change('CHG1_AMT','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg1_amt,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_amt);
Pr_Log_Change('CHG1_CCY','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg1_ccy,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_ccy);
Pr_Log_Change('LCY_CHG1','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).lcy_chg1,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg1);
Pr_Log_Change('FCY_CHG1','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).fcy_chg1,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg1);
Pr_Log_Change('CHG1_GL','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg1_gl,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_gl);
Pr_Log_Change('CHG2_DESC','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg2_desc,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_desc);
Pr_Log_Change('CHG2_WAIVER','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg2_waiver,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_waiver);
Pr_Log_Change('CHG2_AMT','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg2_amt,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_amt);
Pr_Log_Change('CHG2_CCY','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg2_ccy,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_ccy);
Pr_Log_Change('LCY_CHG2','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).lcy_chg2,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg2);
Pr_Log_Change('FCY_CHG2','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).fcy_chg2,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg2);
Pr_Log_Change('CHG2_GL','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg2_gl,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_gl);
Pr_Log_Change('CHG3_DESC','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg3_desc,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_desc);
Pr_Log_Change('CHG3_WAIVER','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg3_waiver,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_waiver);
Pr_Log_Change('CHG3_AMT','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg3_amt,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_amt);
Pr_Log_Change('CHG3_CCY','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg3_ccy,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_ccy);
Pr_Log_Change('LCY_CHG3','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).lcy_chg3,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg3);
Pr_Log_Change('FCY_CHG3','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).fcy_chg3,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg3);
Pr_Log_Change('CHG3_GL','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg3_gl,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_gl);
Pr_Log_Change('NETTING_REQ','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).netting_req,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).netting_req);
Pr_Log_Change('XRATE','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).xrate,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).xrate);
Pr_Log_Change('TXN_CODE','M',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index1).txn_code,p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).txn_code);



                                                      END IF;
                        END LOOP;
                     END IF;
                     IF NOT l_rec_found THEN
                        Dbg('New Record Found..');
                        Pr_Log_Change('CHG1_TYPE','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_type);
Pr_Log_Change('CHG1_IN_TXN','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_in_txn);
Pr_Log_Change('CHG1_IN_ACC','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_in_acc);
Pr_Log_Change('CHG2_TYPE','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_type);
Pr_Log_Change('CHG2_IN_TXN','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_in_txn);
Pr_Log_Change('CHG2_IN_ACC','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_in_acc);
Pr_Log_Change('CHG3_TYPE','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_type);
Pr_Log_Change('CHG3_IN_TXN','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_in_txn);
Pr_Log_Change('CHG3_IN_ACC','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_in_acc);
Pr_Log_Change('OTH_CCY','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).oth_ccy);
Pr_Log_Change('TXN_XRATE','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).txn_xrate);
Pr_Log_Change('ACC_XRATE','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).acc_xrate);
Pr_Log_Change('TRN_REF_NO','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).trn_ref_no);
Pr_Log_Change('CHG_SRNO','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg_srno);
Pr_Log_Change('CHG1_DESC','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_desc);
Pr_Log_Change('CHG1_WAIVER','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_waiver);
Pr_Log_Change('CHG1_AMT','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_amt);
Pr_Log_Change('CHG1_CCY','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_ccy);
Pr_Log_Change('LCY_CHG1','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg1);
Pr_Log_Change('FCY_CHG1','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg1);
Pr_Log_Change('CHG1_GL','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_gl);
Pr_Log_Change('CHG2_DESC','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_desc);
Pr_Log_Change('CHG2_WAIVER','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_waiver);
Pr_Log_Change('CHG2_AMT','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_amt);
Pr_Log_Change('CHG2_CCY','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_ccy);
Pr_Log_Change('LCY_CHG2','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg2);
Pr_Log_Change('FCY_CHG2','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg2);
Pr_Log_Change('CHG2_GL','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_gl);
Pr_Log_Change('CHG3_DESC','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_desc);
Pr_Log_Change('CHG3_WAIVER','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_waiver);
Pr_Log_Change('CHG3_AMT','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_amt);
Pr_Log_Change('CHG3_CCY','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_ccy);
Pr_Log_Change('LCY_CHG3','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg3);
Pr_Log_Change('FCY_CHG3','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg3);
Pr_Log_Change('CHG3_GL','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_gl);
Pr_Log_Change('NETTING_REQ','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).netting_req);
Pr_Log_Change('XRATE','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).xrate);
Pr_Log_Change('TXN_CODE','N',NULL,p_wrk_ifdncsft.v_iftbs_ncs_charge(l_Index).txn_code);


                                          END IF;
                  END LOOP;
               END IF;
               l_Prev_count      := p_Prev_ifdncsft.v_iftbs_ncs_charge.COUNT;
               l_Wrk_Count  := p_Wrk_ifdncsft.v_iftbs_ncs_charge.COUNT;
               IF l_Prev_Count > 0 THEN
                  FOR l_Index IN 1..l_Prev_count  LOOP
                     l_Rec_Found := FALSE;
                     l_Rec_Modified := FALSE;
                     IF l_Wrk_Count > 0 THEN
                        FOR l_Index1 IN 1..l_Wrk_Count  LOOP
                           IF (NVL(p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg_srno,-1)=  NVL(p_Wrk_ifdncsft.v_iftbs_ncs_charge(l_Index1).chg_srno,-1)) THEN
                              Dbg('Record Found..');
                              l_Rec_Found := TRUE;
                              EXIT;

                           END IF;
                        END LOOP;
                     END IF;
                     IF NOT l_Rec_Found THEN
                        Dbg('Record Deleted..');
                        l_Dtl_key := '~IFTB_NCS_CHARGE~'||p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).related_ref_no||'~'||p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg_srno||'~';
                        Pr_Log_Change('CHG1_TYPE','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_type,NULL);
Pr_Log_Change('CHG1_IN_TXN','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_in_txn,NULL);
Pr_Log_Change('CHG1_IN_ACC','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_in_acc,NULL);
Pr_Log_Change('CHG2_TYPE','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_type,NULL);
Pr_Log_Change('CHG2_IN_TXN','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_in_txn,NULL);
Pr_Log_Change('CHG2_IN_ACC','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_in_acc,NULL);
Pr_Log_Change('CHG3_TYPE','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_type,NULL);
Pr_Log_Change('CHG3_IN_TXN','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_in_txn,NULL);
Pr_Log_Change('CHG3_IN_ACC','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_in_acc,NULL);
Pr_Log_Change('OTH_CCY','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).oth_ccy,NULL);
Pr_Log_Change('TXN_XRATE','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).txn_xrate,NULL);
Pr_Log_Change('ACC_XRATE','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).acc_xrate,NULL);
Pr_Log_Change('TRN_REF_NO','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).trn_ref_no,NULL);
Pr_Log_Change('CHG_SRNO','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg_srno,NULL);
Pr_Log_Change('CHG1_DESC','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_desc,NULL);
Pr_Log_Change('CHG1_WAIVER','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_waiver,NULL);
Pr_Log_Change('CHG1_AMT','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_amt,NULL);
Pr_Log_Change('CHG1_CCY','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_ccy,NULL);
Pr_Log_Change('LCY_CHG1','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg1,NULL);
Pr_Log_Change('FCY_CHG1','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg1,NULL);
Pr_Log_Change('CHG1_GL','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg1_gl,NULL);
Pr_Log_Change('CHG2_DESC','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_desc,NULL);
Pr_Log_Change('CHG2_WAIVER','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_waiver,NULL);
Pr_Log_Change('CHG2_AMT','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_amt,NULL);
Pr_Log_Change('CHG2_CCY','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_ccy,NULL);
Pr_Log_Change('LCY_CHG2','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg2,NULL);
Pr_Log_Change('FCY_CHG2','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg2,NULL);
Pr_Log_Change('CHG2_GL','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg2_gl,NULL);
Pr_Log_Change('CHG3_DESC','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_desc,NULL);
Pr_Log_Change('CHG3_WAIVER','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_waiver,NULL);
Pr_Log_Change('CHG3_AMT','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_amt,NULL);
Pr_Log_Change('CHG3_CCY','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_ccy,NULL);
Pr_Log_Change('LCY_CHG3','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).lcy_chg3,NULL);
Pr_Log_Change('FCY_CHG3','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).fcy_chg3,NULL);
Pr_Log_Change('CHG3_GL','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).chg3_gl,NULL);
Pr_Log_Change('NETTING_REQ','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).netting_req,NULL);
Pr_Log_Change('XRATE','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).xrate,NULL);
Pr_Log_Change('TXN_CODE','D',p_Prev_ifdncsft.v_iftbs_ncs_charge(l_Index).txn_code,NULL);


                                          END IF;
                  END LOOP;
               END IF;

               l_Count      := l_Tb_Field_Log.COUNT;
               IF l_Count   > 0 THEN
                  Dbg('Inserting Into Field Log..');
                  BEGIN
                     FORALL l_Index IN  1..l_count
                     INSERT INTO STTBS_FIELD_LOG
                     VALUES l_Tb_Field_Log(l_index);
                  EXCEPTION
                     WHEN OTHERS THEN
                        Dbg('Failed in Insert into Field Log..');
                        Dbg(SQLERRM);
                        p_Err_Code    := 'ST-UPLD-001';
                        p_Err_Params  := '@STTBS_FIELD_LOG';
                  END;
               END IF;

            END IF;
            g_curr_stage := 'POSTMAINTLOG';
            l_Skip_custom:= g_Skip_custom;
            ifpks_ifdncsft_Main.Pr_Set_Skip_CUSTOM;
            l_Wrk_ifdncsft:=p_Wrk_ifdncsft;
            Pr_Skip_Handler('POSTMAINTLOG');
            Dbg('Calling Post Upload Hooks For any Additional Logging');
            IF NOT ifpks_ifdncsft_Main.Fn_Skip_custom  THEN
               IF NOT ifpks_ifdncsft_Custom.Fn_Post_Upload_Db (p_Source,
                  p_Source_operation,
                  p_Function_id,
                  p_Action_Code,
                  p_function_Id  ,
                  g_Post_Upl_Stat,
                  p_Multi_Trip_Id,
                  p_ifdncsft,
                  p_Prev_ifdncsft,
                  l_Wrk_ifdncsft,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in ifpks_ifdncsft_Custom.Fn_Post_Upload_Db After Logging');
                  RETURN FALSE;
               END IF;
            END IF;
            g_Skip_custom:= l_Skip_custom;
            g_curr_stage := NULL;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Maint_Log..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Maint_Log ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Maint_Log;

   FUNCTION Fn_Extract_Custom_Data (p_Source   IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      l_ifdncsft     ifpks_ifdncsft_Main.Ty_ifdncsft;

   BEGIN

      Dbg('In Fn_Extract_Custom_Data.. ');
      IF NOT  Fn_Build_Type(p_source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Addl_Info,
         l_ifdncsft,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_Status      := 'F';
         RAISE e_Failure_Exception;
      END IF;
      Dbg('Calling  Fn_Get_Key_Information..');
      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_ifdncsft,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      p_Addl_Info := l_ifdncsft.Addl_Info;
      Dbg('Returning from Fn_Extract_Custom_Data..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Extract_Custom_Data..');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Extract_Custom_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Extract_Custom_Data;

   FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;

   BEGIN

      Dbg('In Fn_Rebuild_Ts_List ');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         g_ifdncsft,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Dbg('Returning Success From Fn_Rebuild_Ts_List..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Rebuild_Ts_List..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Rebuild_Ts_List;

   FUNCTION Fn_Get_Node_Data (
      p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Cntr NUMBER := 0;
   BEGIN

      Dbg('In Fn_Get_Node_Data..');
      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_NCS_MASTER';
      p_Node_Data(l_Cntr).Xsd_Node := 'Fast-Master';
      p_Node_Data(l_Cntr).Node_Parent := '';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'BRANCH_CODE~RELATED_REF_NO~TRN_REF_NO~TRANSFER_DATE~TXN_AMT~TOT_CHG_AMT~NET_TXN_AMT~EXCH_RATE~REM_ACC~REM_NAME~BEN_ACC~BEN_BIC~BEN_NAME~BEN_ADD1~BEN_ADD2~BEN_ADD3~BEN_ADD4~TXN_CCY~PURPOSE_OF_TRF~BANK_';
      p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'NAME~DR_AMOUNT~DR_ACC_CCY~MSG_FLOW~REQUESTOR_BRANCH~WAIVE_CHARGE~INC_TXN_STATUS~INC_TXN_FAIL_REASON~BATCH_NO~REM_ACC_BRANCH~PAYER_BIC_CODE~PAYER_BANK_NAME~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~T';
      p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'XNSTAT~AUTHSTAT~ONCEAUTH~';
      p_Node_Data(l_Cntr).Node_Tags := 'BRANCH_CODE~RELATED_REF_NO~TRN_REF_NO1~TRANSFER_DATE~TXN_AMT~TOTCHGAMT~TOTAL_CASA_DR~EXCH_RATE~REM_ACC~REM_NAME~BEN_ACC~BANK_BIC~BEN_NAME~BEN_ADD1~BEN_ADD2~BEN_ADD3~BEN_ADD4~TXN_CCY~PURPOSE_OF_TRF~BAN';
      p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'K_NAME~DR_AMOUNT1~ACCUR~MSG_FLOW~REQUESTOR_BRANCH~WAIVE_CHARGE~INC_TXN_STATUS~INC_TXN_FAIL_REASON~BATCH_NO~ACC_BRANCH~PAYER_BIC_CODE~PAYER_BANK_NAME~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT';
      p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'~AUTHSTAT~ONCEAUTH~';

      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_NCS_CHARGE';
      p_Node_Data(l_Cntr).Xsd_Node := 'Rft-Charge';
      p_Node_Data(l_Cntr).Node_Parent := 'BLK_NCS_MASTER';
      p_Node_Data(l_Cntr).Node_Relation_Type := 'N';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'CHG1_TYPE~CHG1_IN_TXN~CHG1_IN_ACC~CHG2_TYPE~CHG2_IN_TXN~CHG2_IN_ACC~CHG3_TYPE~CHG3_IN_TXN~CHG3_IN_ACC~OTH_CCY~TXN_XRATE~ACC_XRATE~RELATED_REF_NO~TRN_REF_NO~CHG_SRNO~CHG1_DESC~CHG1_WAIVER~CHG1_AMT~CHG1';
      p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'_CCY~LCY_CHG1~FCY_CHG1~CHG1_GL~CHG2_DESC~CHG2_WAIVER~CHG2_AMT~CHG2_CCY~LCY_CHG2~FCY_CHG2~CHG2_GL~CHG3_DESC~CHG3_WAIVER~CHG3_AMT~CHG3_CCY~LCY_CHG3~FCY_CHG3~CHG3_GL~NETTING_REQ~XRATE~TXN_CODE~';
      p_Node_Data(l_Cntr).Node_Tags := 'CHG1_TYPE~CHG1_IN_TXN~CHG1_IN_ACC~CHG2_TYPE~CHG2_IN_TXN~CHG2_IN_ACC~CHG3_TYPE~CHG3_IN_TXN~CHG3_IN_ACC~OTH_CCY~TXN_XRATE~ACC_XRATE~RELATED_REF_NO~TRN_REF_NO~CHG_SRNO~CHG1_DESC~CHG1_WAIVER~CHG1_AMT~CHG1';
      p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'_CCY~LCY_CHG1~FCY_CHG1~CHG1_GL~CHG2_DESC~CHG2_WAIVER~CHG2_AMT~CHG2_CCY~LCY_CHG2~FCY_CHG2~CHG2_GL~CHG3_DESC~CHG3_WAIVER~CHG3_AMT~CHG3_CCY~LCY_CHG3~FCY_CHG3~CHG3_GL~NETTING_REQ~XRATE~TXN_CODE~';

      Dbg('Returning From Fn_Get_Node_Data.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of ifpks_ifdncsft_Main.Fn_Get_Node_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Node_Data;
   FUNCTION Fn_Int_Main   (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_ifdncsft          IN OUT ifpks_ifdncsft_Main.ty_ifdncsft,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;
      l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
      l_Post_Upl_Stat         VARCHAR2(1) :='A';
      l_Prev_Auth_Stat        VARCHAR2(1) :='U';
      l_Wrk_ifdncsft    ifpks_ifdncsft_Main.Ty_ifdncsft;
      l_Prev_ifdncsft    ifpks_ifdncsft_Main.Ty_ifdncsft;
      l_Dmy_ifdncsft    ifpks_ifdncsft_Main.Ty_ifdncsft;
      l_Pk_Or_Full    VARCHAR2(5) :='PK';
      l_Full_Data    VARCHAR2(1) := 'Y';
      l_With_Lock    VARCHAR2(1) := 'N';
      l_Qrydata_Reqd    VARCHAR2(1) := 'Y';
      l_Count         NUMBER;
      l_Action_Code       VARCHAR2(100):= p_Action_Code;
      l_Record_Master     Sttbs_Record_Master%ROWTYPE;
      l_Sent_Mod_No                NUMBER;
      l_Tanking_Status                VARCHAR2(1) := 'N';

   BEGIN

      Dbg('In Fn_Int_Main..');

      SAVEPOINT Sp_Int_Main_Ifdncsft;
      p_Status := 'S';
      g_Tanking_Status := l_Tanking_Status;
      g_ifdncsft := p_ifdncsft;
      l_Wrk_ifdncsft := p_ifdncsft;

      Dbg('Calling  Fn_Check_Mandatory..');
      IF NOT Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Pk_Or_Full,
         p_ifdncsft,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_ifdncsft,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      l_Sent_Mod_No := p_ifdncsft.v_iftbs_ncs_master.Mod_No;
      Dbg('Calling Cspks_Req_Utils.Fn_Process_Tanked_Entries..');
      IF NOT Cspks_Req_Utils.Fn_Process_Tanked_Entries(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         g_Key_Id,
         l_Sent_Mod_No,
         l_Action_Code,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in  Cspks_Req_Utils.Fn_Process_Tanked_Entries..');
         RAISE E_Failure_Exception;
      END IF;

      IF p_Action_Code = Cspks_Req_Global.p_query THEN
         Dbg('Calling in Fn_Query..');
         IF NOT Fn_Query(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Full_data,
            l_with_lock,
            l_Qrydata_Reqd,
            p_ifdncsft,
            l_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Query..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
      ELSE
         Dbg('Calling  Fn_Default_And_Validate..');
         IF NOT Fn_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_ifdncsft,
            l_Prev_ifdncsft,
            l_Wrk_ifdncsft,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Default_And_Validate..');
            pr_log_error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         -- Get Resultant Error Type
         l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
         IF l_Resultant_Error_Type <> 'E' THEN
            Dbg('Calling  Fn_Upload_Db..');
            IF NOT Fn_Upload_Db (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               l_Post_Upl_Stat,
               p_Multi_Trip_Id,
               p_ifdncsft,
               l_Prev_ifdncsft,
               l_Wrk_ifdncsft,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Upload_Db..');
               pr_log_error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            IF  l_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen) THEN
               l_Prev_Auth_Stat := NVL(l_Prev_ifdncsft.v_iftbs_ncs_master.Auth_Stat,'A') ;
               --Get Upload Status
               Dbg('Calling Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
               IF NOT Cspks_Req_Utils.Fn_Get_Auto_Auth_Status (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  l_Action_Code,
                  l_Prev_Auth_Stat,
                  p_Multi_Trip_Id,
                  P_Request_No,
                  l_Post_Upl_Stat,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
                  Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
                  RAISE E_Failure_Exception;
               END IF;

               IF l_Post_Upl_Stat NOT IN ('A','U','O') THEN
                  Dbg('Cannot Proceed Further..');
                  RAISE E_Failure_Exception;
               ELSE
                  IF l_post_upl_stat = 'A'THEN
                     Dbg('Calling  Fn_Upload_Db..');
                     IF NOT Fn_Upload_Db (p_Source,
                        p_Source_Operation,
                        p_Function_Id,
                        Cspks_Req_Global.p_auth,
                        l_Post_Upl_Stat,
                        p_Multi_Trip_Id,
                        p_ifdncsft,
                        l_Prev_ifdncsft,
                        l_Wrk_ifdncsft,
                        p_Err_Code,
                        p_Err_Params) THEN
                        Dbg('Failed in Fn_Upload_Db..');
                        Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                        RAISE E_Failure_Exception;
                     END IF;
                  END IF;
               END IF;
            END IF;
            --Get Upload Status
            Dbg('Calling  Cspks_Req_Utils.Fn_Get_Upload_Status..');
            IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
               p_source_operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               P_Request_No,
               l_Post_Upl_Stat,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
               Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;

            IF l_Post_Upl_Stat IN ('A','U') THEN
               Dbg('Success Case...');
               IF l_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Auth,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Query,Cspks_Req_Global.p_Version_Delete ) THEN
                  IF NOT Fn_Query(p_Source,
                     p_Source_Operation,
                     p_Function_Id,
                     l_Action_Code,
                     l_Full_Data,
                     l_With_Lock,
                     l_Qrydata_Reqd,
                     l_Wrk_ifdncsft,
                     l_Wrk_ifdncsft,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in Fn_Query..');
                     Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                     RAISE E_Failure_Exception;
                  END IF;
               END IF;
            ELSIF l_Post_Upl_Stat ='O' THEN
               Dbg('Raising Override Exception..');
               RAISE E_Override_Exception;
            ELSE
               Dbg('Not Feasible to Proceed..');
               RAISE E_Failure_Exception;
            END IF;
         ELSE
            Dbg('Encountered Errros..');
            RAISE E_Failure_Exception;
         END IF;
         Dbg('Calling Fn_Populate_Record_Master..');
         IF NOT Fn_Populate_Record_Master(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Wrk_ifdncsft,
            l_Record_Master,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Populate_Record_Master..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
         IF NOT Fn_Tank_Modification(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Tanking_Status,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Rolling Back the Modification..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      END IF; -- Action Code

      Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
      Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      g_ifdncsft := l_wrk_ifdncsft;
      g_post_upl_stat := l_Post_Upl_Stat;
      Dbg('Calling  Cspks_Req_Utils.Fn_Maint_Log..');
      IF NOT Fn_Maint_Log(p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_Multi_Trip_Id,
         p_Request_No,
         l_Record_Master,
         p_ifdncsft,
         l_Prev_ifdncsft,
         l_Wrk_ifdncsft,
         l_Tanking_Status,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in   Cspks_Req_Utils.Fn_Maint_Log..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;
      IF l_Action_Code = Cspks_Req_Global.p_Delete AND p_Source = 'FLEXCUBE'  THEN
         l_Wrk_ifdncsft := l_Dmy_ifdncsft;
      END IF;
      p_ifdncsft := l_wrk_ifdncsft;
      Dbg('Errors     :'||p_Err_Code);
      Dbg('Parameters :'||p_Err_Params);

      Dbg('Returning Success From Fn_Int_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Int_Main..');
         ROLLBACK TO Sp_Int_Main_Ifdncsft;
         p_Status        := 'F';
         l_Post_Upl_Stat := 'F';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Int_Main');
         p_Status        := 'O';
         l_post_upl_stat := 'O';
         IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
            Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
         END IF;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Int_Main ..');
         Debug.Pr_Debug('**',SQLERRM);
         ROLLBACK TO Sp_Int_Main_Ifdncsft;
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Int_Main;

   FUNCTION Fn_Main   (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_ifdncsft          IN OUT ifpks_ifdncsft_Main.ty_ifdncsft,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;

   BEGIN

      Dbg('In Fn_Main..');
      SAVEPOINT Sp_Main_Ifdncsft;
      Dbg('Calling  Fn_Int_Main..');
      IF NOT  Fn_Int_Main(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Multi_Trip_Id,
         p_Request_No,
         p_ifdncsft,
         p_Status,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Int_Main..');
         RAISE E_Failure_Exception;
      END IF;
      IF p_Status = 'F' THEN
         RAISE E_Failure_Exception;
      ELSIF p_Status = 'O' THEN
         RAISE E_Override_Exception;
      END IF;
      Dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Main');
         ROLLBACK TO Sp_Main_Ifdncsft;
         p_Status      := 'F';
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Main..');
         p_Status      := 'O';
         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Main ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         ROLLBACK TO Sp_Main_Ifdncsft;
         RETURN FALSE;
   END Fn_Main;

   FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_ifdncsft     ifpks_ifdncsft_Main.ty_ifdncsft;

   BEGIN

      Dbg('In Fn_Process_Request ');
      IF NOT  Fn_Build_Type(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Addl_Info,
         l_ifdncsft,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_status      := 'F';
         RETURN FALSE;
      END IF;
      IF Cspks_Req_Global.Fn_UnTanking THEN
         IF NOT  Fn_Int_Main(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Multi_Trip_Id,
            p_Request_No,
            l_ifdncsft,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Main(p_source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Multi_Trip_Id,
            p_Request_No,
            l_ifdncsft,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;
      END IF;

      p_addl_info := l_ifdncsft.Addl_Info;
      IF Cspks_Req_Global.Fn_Build_Resp THEN
         Cspks_Req_Global.Pr_Reset;
         IF NOT  Fn_Build_Ts_List(p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Exchange_Pattern,
            l_ifdncsft,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Build_Ts_List..');
            p_Status      := 'F';
            RETURN FALSE;
         END IF;
         Cspks_Req_Global.Pr_Close_Ts;
      END IF;
      Dbg('Returning Success From Fn_Process_Request..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Process_Request;

END ifpks_ifdncsft_main;

