insert into IFTB_JOB_DEFINITION (JOB_CODE, JOB_DESCRIPTION, ENABLE, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID)
values ('NCS Outgoing Morning Slot(09:35 AM)', 'NCS Outgoing Morning Slot(09:35 AM)', 'Y', 'A', to_date('19-09-2022', 'dd-mm-yyyy'), 'ADMINUSER2', to_date('19-09-2022', 'dd-mm-yyyy'), 1, 'Y', 'O', 'ADMINUSER2');

insert into IFTB_JOB_DEFINITION (JOB_CODE, JOB_DESCRIPTION, ENABLE, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID)
values ('NCS Outgoing Lunch Slot(01:35 PM)', 'NCS Outgoing Lunch Slot(01:35 PM)', 'N', 'A', to_date('19-09-2022', 'dd-mm-yyyy'), 'ADMINUSER2', to_date('19-09-2022', 'dd-mm-yyyy'), 1, 'Y', 'O', 'ADMINUSER2');

insert into IFTB_JOB_DEFINITION (JOB_CODE, JOB_DESCRIPTION, ENABLE, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID)
values ('NCS Incoming', 'NCS Incoming', 'Y', 'A', to_date('19-09-2022', 'dd-mm-yyyy'), 'ADMINUSER2', to_date('19-09-2022', 'dd-mm-yyyy'), 1, 'Y', 'O', 'ADMINUSER2');

COMMIT;
