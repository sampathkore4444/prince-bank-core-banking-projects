insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ABAAKHPPXXXX', '036100', 'Advanced Bank of Asia Ltd HQ-100', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ACLBKHPPXXXX', '041001', 'ACLEDA Bank Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ADEOKHPPXXXX', '103001', 'Asia-Pacific Development Bank Plc-HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('BKCHKHPPXXXX', '071001', 'Bank of China (Hong Kong) Limited Phnom Penh Branch HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('BKKBKHPPXXXX', '082001', 'Bangkok Bank Plc. Br. Cambodia HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('BREDKHP2XXXX', '092001', 'Bred Bank Cambodia Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CABCKHPPXXXX', '016010', 'Cambodia Asia Bank Ltd HQ-010', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CADIKHPPXXXX', '005001', 'Canadia Bank Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CHNOKHPPXXXX', '099001', 'Chip Mong Commercial Bank Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CIBBKHPPXXXX', '072121', 'CIMB Bank Cambodia Plc HQ-121', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CPBLKHPPXXXX', '004010', 'Cambodian Public Bank Plc HQ-010', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CPBPKHP2XXXX', '079001', 'Cambodia Post Bank Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CSBCKHPPXXXX', '080011', 'Cathay United Bank Cambodia Co, Ltd HQ-011', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CZNBKHPPXXXX', '066001', 'Kookmin Bank Cambodia Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('DAEBKHPPXXXX', '106001', 'DGB Bank Plc-HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('FCBKKHPPXXXX', '040001', 'First Commercial Bank Phnom Penh Branch HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('FTCCKHPPXXXX', '001010', 'Foreign Trade Bank of Cambodia HQ-010', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('HDSBKHPPXXXX', '081005', 'Phillip Bank Plc HQ-005', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('HKLBKHPPXXXX', '085001', 'HATTHA Bank Plc-HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('HLBBKHPPXXXX', '077001', 'Hong Leong Bank Cambodia PLC HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ICBCKHPPXXXX', '073001', 'Mega International Commercial Bank HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ICBKKHPPXXXX', '069001', 'ICBC Limited Phnom Penh Branch HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('IDBCKHPPXXXX', '068001', 'Bank for Invest and Deve of Cambodia Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('KASIKHPPXXXX', '091002', 'Branch of KASIKORN Bank Public Company Ltd PP-002', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('KRTHTHBKXXXX', '009999', 'Krung Thai Bank Public Co, Ltd HQ-999', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('MBBEKHPPXXXX', '020001', 'May Bank Phnom Penh Branch Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('MSCBVNVXXXXX', '074001', 'MB Bank Plc., Cambodia Branch HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('NCAMKHPPXXXX', '100001', 'National Bank of Cambodia HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('OSKIKHPPXXXX', '078002', 'RHB Bank (Cambodia) Plc. HQ-002', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('PINCKHPPXXXX', '096001', 'PRINCE Bank Plc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('PPCBKHPPXXXX', '058111', 'Phnom Penh Commercial Bank HQ-111', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('SBHRKHPPXXXX', '105999', 'SBI Ly Hour Bank Plc HQ-999', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('SBPLKHPPXXXX', '056099', 'Sathapana Bank Plc HQ-099', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('SGTTVNVXXXXX', '064001', 'Sacom Bank Cambodia PLc HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('SHBKKHPPXXXX', '053001', 'Shinhan Bank (Cambodia) Plc. HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('SICOKHPPXXXX', '003001', 'Cambodian Commercial Bank Ltd HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('TACBKHPPXXXX', '076001', 'Taiwan Cooperative Bank Phnom Penh Branch HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('TCABKHPPXXXX', '102010', 'JTrust Royal Bank Plc HQ-010', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('UCBPKHPPXXXX', '026100', 'Union Commercial Bank Plc HQ-100', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('VBLCKHPPXXXX', '043050', 'Vattanac Bank HQ-050', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('WIGCKHPPXXXX', '109001', 'WING Bank (Cambodia) Plc-HQ-001', 'ACTIVE', 'Direct Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('CADIKHPPX300', '005300', 'Canadia Bank Plc Ind. ARDB-PP, BR-300', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('IDBCKHPPX601', '068601', 'BIDC Ind. AGRIBANK BR-601', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('PPCBKHPPX201', '058201', 'Phnom Penh Commercial Bank.Ind.BKB.BR-201', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('PPCBKHPPX202', '058202', 'Phnom Penh Commercial Bank.Ind.PANDA.BR-202', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('PPCBKHPPX203', '058203', 'Phnom Penh Commercial Bank.Ind.RUI LI.BR-203', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('SBPLKHPPX301', '056301', 'Sathapana Bank Plc Ind. ALPHA Bank BR-301', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('SBPLKHPPX304', '056304', 'Sathapana Bank Plc Ind. Mohanokor BR-304', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ACLBKHPPX901', '041901', 'ACLEDA Bank Plc.Ind.BIC.BR-901', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ACLBKHPPX902', '041902', 'ACLEDA Bank Plc.Ind.IBK.BR-902', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ACLBKHPPX904', '041904', 'ACLEDA Bank Plc.Ind.CHIEF.BR-904', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ACLBKHPPX905', '041905', 'ACLEDA Bank Plc.Ind.SHB.BR-905', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ACLBKHPPX910', '041910', 'ACLEDA Bank Plc.Ind.SME BR-910', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ACLBKHPPX911', '041911', 'ACLEDA Bank Plc.Ind.HENG HE BR-911', 'ACTIVE', 'Sub-Participant', 'KH');

insert into iftb_ncs_participants (BIC_CODE, EXTERNAL_CODE, BANK_NAME, STATUS, PARTICIPANT_TYPE, COUNTRY)
values ('ACLBKHPPX912', '041912', 'ACLEDA Bank Plc.Ind.ORIENTAL BR-912', 'ACTIVE', 'Sub-Participant', 'KH');

COMMIT;
