CREATE OR REPLACE PACKAGE BODY DEPKS_RET_TELR_UPLD_CUSTOM AS

 /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Change Tag        : PRF_CUSTOM_11_19072018
   **    Changes By        : Aniket
   **    Changes on        : 19-Jul-2018
   **    Description       : re initialize the error table else in cspks_charge it will again append with existing error code.Changes specific to prince.

   **    Changes By        : Kore Sampath Kumar
   **    Changes on        : 15-March-2020
   **    Description       : Pending Transaction Servcie for mobile banking
   **    Change Tag        : Pending Transaction Servcie for mobile banking

   ** Modified By         : Kore Sampath Kumar
   ** Modified On         : 15-July-2020
   ** Modified Reason     : NBC RFT Changes
   ** Search String       : NBC RFT Changes

   ** Modified By         : Kore Sampath Kumar
   ** Modified On         : 15-Nov-2021
   ** Modified Reason     : AIA Payment
   ** Search String       : AIA Payment



  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'depks_ret_telr_upld_custom ==>' || P_DBG);
  END DBG;

  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN
    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('DE',
                     '[error] ' || 'depks_ret_telr_upld_custom ==>' ||
                     P_DBG);
    ELSIF P_DBG_IND = 'O' THEN
      DEBUG.PR_DEBUG('DE',
                     '[override] ' || 'depks_ret_telr_upld_custom ==>' ||
                     P_DBG);
    ELSE
      DEBUG.PR_DEBUG('DE',
                     '[debug] ' || 'depks_ret_telr_upld_custom ==>' ||
                     P_DBG);
    END IF;
  END DBG;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
  RETURN;
  END PR_SKIP_HANDLER;
  
  --NCS Outgoing Payment Sampath Starts
  FUNCTION FN_GET_MID_RATE(P_BRANCH_CODE IN VARCHAR2)
    RETURN CYTM_RATES.MID_RATE%TYPE AS
  
    L_MID_RATE CYTM_RATES.MID_RATE%TYPE;
  BEGIN
  
    SELECT MID_RATE
      INTO L_MID_RATE
      FROM CYTM_RATES
     WHERE BRANCH_CODE = P_BRANCH_CODE
       AND RATE_TYPE = 'STANDARD'
       AND CCY1 = 'USD'
       AND CCY2 = 'KHR';
  
    RETURN L_MID_RATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE IN FN_GET_MID_RATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MID_RATE=' || SQLERRM);
      RETURN L_MID_RATE;
    
  END FN_GET_MID_RATE;

  FUNCTION FN_GET_COMM_SALE_RATE(P_BRANCH_CODE IN VARCHAR2)
    RETURN CYTM_RATES.MID_RATE%TYPE AS
  
    L_COMM_SALE_RATE CYTM_RATES.SALE_RATE%TYPE;
  BEGIN
  
    SELECT SALE_RATE
      INTO L_COMM_SALE_RATE
      FROM CYTM_RATES
     WHERE BRANCH_CODE = P_BRANCH_CODE
       AND RATE_TYPE = 'COMM'
       AND CCY1 = 'USD'
       AND CCY2 = 'KHR';
  
    RETURN L_COMM_SALE_RATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE IN FN_GET_COMM_SALE_RATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_COMM_SALE_RATE=' || SQLERRM);
      RETURN L_COMM_SALE_RATE;
    
  END FN_GET_COMM_SALE_RATE;
  --NCS Outgoing Payment Sampath Ends

   FUNCTION FN_DEFAULT_CHGDETS_PRE(P_TBL_CHGDETS  IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_TBLCHGDETS,
                              P_DETB_RTL_TLR IN DETBS_RTL_TELLER%ROWTYPE,
                              P_RET          IN OUT NUMBER)
   RETURN BOOLEAN IS
  BEGIN
  DBG('Inside fn_default_chgdets_Pre');

  DBG('Returning success from fn_default_chgdets_Pre');
  RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_ret_telr_upld_custom.fn_default_chgdets_Pre ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
     P_RET := -1;
      RETURN FALSE;
  END FN_DEFAULT_CHGDETS_PRE;

    FUNCTION FN_DEFAULT_CHGDETS_POST(P_TBL_CHGDETS  IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_TBLCHGDETS,
                              P_DETB_RTL_TLR IN DETBS_RTL_TELLER%ROWTYPE,
                              P_RET          IN OUT NUMBER)
   RETURN BOOLEAN IS
  BEGIN
  DBG('Inside fn_default_chgdets_Post');

  DBG('Returning success from fn_default_chgdets_Post');
  RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_ret_telr_upld_custom.fn_default_chgdets_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
     P_RET := -1;
      RETURN FALSE;
  END FN_DEFAULT_CHGDETS_POST;

  --Pending Transaction Servcie for mobile banking starts
  PROCEDURE PR_INSERT_UNAUTH_ENTRIES_DIG(P_DETB_RTL_TELLER IN DETB_RTL_TELLER%ROWTYPE) IS

    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COUNT NUMBER := 0;

  BEGIN


    IF P_DETB_RTL_TELLER.PRODUCT_CODE IN ('CHWL', 'CHDP') THEN
      INSERT INTO DETB_RTL_TELLER_UNAUTH_DIGITAL
        (XREF,
         TRN_REF_NO,
         PRODUCT_CODE,
         BRANCH_CODE,
         TXN_ACC,
         TXN_CCY,
         TXN_AMOUNT,
         TXN_BRANCH,
         TXN_TRN_CODE,
         OFS_ACC,
         OFS_CCY,
         OFS_AMOUNT,
         OFS_BRANCH,
         OFS_TRN_CODE,
         LCY_AMOUNT,
         TRN_DT,
         VALUE_DT,
         REL_CUSTOMER,
         CHARGE_ACCOUNT,
         AUTH_STAT,
         TIME_RECEIVED,
         RECORD_STAT,
         MAKER_ID,
         MAKER_DT_STAMP,
         MODULE,
         EXCH_RATE,
         NARRATIVE)
      VALUES
        (P_DETB_RTL_TELLER.XREF,
         P_DETB_RTL_TELLER.TRN_REF_NO,
         P_DETB_RTL_TELLER.PRODUCT_CODE,
         P_DETB_RTL_TELLER.BRANCH_CODE,
         P_DETB_RTL_TELLER.TXN_ACC,
         P_DETB_RTL_TELLER.TXN_CCY,
         P_DETB_RTL_TELLER.TXN_AMOUNT,
         P_DETB_RTL_TELLER.TXN_BRANCH,
         P_DETB_RTL_TELLER.TXN_TRN_CODE,
         P_DETB_RTL_TELLER.OFS_ACC,
         P_DETB_RTL_TELLER.OFS_CCY,
         P_DETB_RTL_TELLER.OFS_AMOUNT,
         P_DETB_RTL_TELLER.OFS_BRANCH,
         P_DETB_RTL_TELLER.OFS_TRN_CODE,
         P_DETB_RTL_TELLER.LCY_AMOUNT,
         P_DETB_RTL_TELLER.TRN_DT,
         P_DETB_RTL_TELLER.VALUE_DT,
         P_DETB_RTL_TELLER.REL_CUSTOMER,
         P_DETB_RTL_TELLER.CHARGE_ACCOUNT,
         P_DETB_RTL_TELLER.AUTH_STAT,
         P_DETB_RTL_TELLER.TIME_RECEIVED,
         P_DETB_RTL_TELLER.RECORD_STAT,
         P_DETB_RTL_TELLER.MAKER_ID,
         P_DETB_RTL_TELLER.MAKER_DT_STAMP,
         'RT',
         P_DETB_RTL_TELLER.EXCH_RATE,
         P_DETB_RTL_TELLER.NARRATIVE);

    ELSIF P_DETB_RTL_TELLER.PRODUCT_CODE IN ('FTRQ') THEN



      INSERT INTO DETB_RTL_TELLER_UNAUTH_DIGITAL
        (XREF,
         TRN_REF_NO,
         PRODUCT_CODE,
         BRANCH_CODE,
         TXN_ACC,
         TXN_CCY,
         TXN_AMOUNT,
         TXN_BRANCH,
         TXN_TRN_CODE,
         OFS_ACC,
         OFS_CCY,
         OFS_AMOUNT,
         OFS_BRANCH,
         OFS_TRN_CODE,
         LCY_AMOUNT,
         TRN_DT,
         VALUE_DT,
         REL_CUSTOMER,
         CHARGE_ACCOUNT,
         AUTH_STAT,
         TIME_RECEIVED,
         RECORD_STAT,
         MAKER_ID,
         MAKER_DT_STAMP,
         MODULE,
         EXCH_RATE,
         NARRATIVE)
      VALUES
        (P_DETB_RTL_TELLER.XREF,
         P_DETB_RTL_TELLER.TRN_REF_NO,
         P_DETB_RTL_TELLER.PRODUCT_CODE,
         P_DETB_RTL_TELLER.BRANCH_CODE,
         P_DETB_RTL_TELLER.TXN_ACC,
         P_DETB_RTL_TELLER.TXN_CCY,
         P_DETB_RTL_TELLER.TXN_AMOUNT,
         P_DETB_RTL_TELLER.TXN_BRANCH,
         P_DETB_RTL_TELLER.TXN_TRN_CODE,
         P_DETB_RTL_TELLER.OFS_ACC,
         P_DETB_RTL_TELLER.OFS_CCY,
         P_DETB_RTL_TELLER.OFS_AMOUNT,
         P_DETB_RTL_TELLER.OFS_BRANCH,
         P_DETB_RTL_TELLER.OFS_TRN_CODE,
         P_DETB_RTL_TELLER.LCY_AMOUNT,
         P_DETB_RTL_TELLER.TRN_DT,
         P_DETB_RTL_TELLER.VALUE_DT,
         P_DETB_RTL_TELLER.REL_CUSTOMER,
         P_DETB_RTL_TELLER.CHARGE_ACCOUNT,
         P_DETB_RTL_TELLER.AUTH_STAT,
         P_DETB_RTL_TELLER.TIME_RECEIVED,
         P_DETB_RTL_TELLER.RECORD_STAT,
         P_DETB_RTL_TELLER.MAKER_ID,
         P_DETB_RTL_TELLER.MAKER_DT_STAMP,
         'RT',
         P_DETB_RTL_TELLER.EXCH_RATE,
         P_DETB_RTL_TELLER.NARRATIVE);

      DELETE FROM DETB_RTL_TELLER_UNAUTH_DIGITAL
       WHERE ROWID NOT IN (SELECT MAX(ROWID)
                             FROM DETB_RTL_TELLER_UNAUTH_DIGITAL
                            GROUP BY XREF)
         AND XREF = P_DETB_RTL_TELLER.XREF;

    END IF;



    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      NULL;

  END PR_INSERT_UNAUTH_ENTRIES_DIG;
  --Pending Transaction Servcie for mobile banking ends



  FUNCTION FN_UPLOAD(  P_TY_RETAILTLR_UPD IN OUT NOCOPY DETB_UPLOAD_RTL_TELLER%ROWTYPE,
            P_TBL_CHGDETS      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_TBLCHGDETS,
            P_UPL_MIS_DET      IN OUT NOCOPY MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
            P_UPL_UDF_DET      IN OUT NOCOPY UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
            P_UPL_PCDETAILS    IN OUT NOCOPY DETB_PCTRN%ROWTYPE,
            P_TY_MCKDETAILS    IN OUT NOCOPY ISTB_UPLOAD_CONTRACTIS%ROWTYPE,
            P_TY_MSGDETS       IN OUT NOCOPY CSTB_UPLOAD_ARC_SETTLE%ROWTYPE,
            P_TBL_NODE_REC     IN DEPKS_RETAILTELLERUPLOAD.TYP_NODE_TBL,
            P_SOURCE           IN VARCHAR2,
                        P_OVERRIDE_FLAG    IN OUT CHAR,
            P_AUTH_STAT        IN OUT CHAR,
            P_RET              IN OUT NUMBER,
            P_TYP_ERR          IN OUT NOCOPY OVPKSS.TBL_ERROR,
            P_FN_CALL_ID       IN NUMBER,
            P_TB_CLUSTER_DATA  IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)

  RETURN BOOLEAN IS

  --Pending Transaction Servcie for mobile banking starts
    L_COUNT           number := 0;
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    --Pending Transaction Servcie for mobile banking ends

  BEGIN
    DBG('Inside depks_ret_telr_upld_custom.fn_upload ...');

   DBG('CALL ID IS :' || P_FN_CALL_ID);
    DBG('ACTION CODE=' || GWPKS_UTIL.PKG_ACTTYPE);

  --AIA Payment by cash starts
    IF GWPKS_UTIL.PKG_FUNC IN ('AIAC') THEN

    BEGIN
      SELECT A.AC_GL_NO
        INTO P_TY_RETAILTLR_UPD.TXN_BRANCH
        FROM STTB_ACCOUNT A
       WHERE A.AC_GL_NO = P_TY_RETAILTLR_UPD.TXN_ACC
         AND A.RECON_TYPE = 'O';
      EXCEPTION
      WHEN OTHERS THEN
        P_TY_RETAILTLR_UPD.TXN_BRANCH := '032';
    END;

    /*BEGIN
      SELECT A.AC_GL_NO
        INTO P_TY_RETAILTLR_UPD.OFS_BRANCH
        FROM STTB_ACCOUNT A
       WHERE A.AC_GL_NO = P_TY_RETAILTLR_UPD.OFS_ACC
         AND A.RECON_TYPE = 'O';
      EXCEPTION
      WHEN OTHERS THEN
        P_TY_RETAILTLR_UPD.OFS_BRANCH := NULL;
    END;*/

      --P_TY_RETAILTLR_UPD.TXN_BRANCH := '991';
      --P_TY_RETAILTLR_UPD.OFS_BRANCH := '001';
    END IF;
  --AIA Payment by cash ends

  --NBC RFT Changes Starts
    IF GWPKS_UTIL.PKG_FUNC IN ('RFTM') THEN

      BEGIN
        SELECT A.AC_GL_NO
          INTO P_TY_RETAILTLR_UPD.TXN_BRANCH
          FROM STTB_ACCOUNT A
         WHERE A.AC_GL_NO = P_TY_RETAILTLR_UPD.TXN_ACC
           AND A.RECON_TYPE = 'O';
      EXCEPTION
        WHEN OTHERS THEN
          P_TY_RETAILTLR_UPD.TXN_BRANCH := '993';
      END;

    END IF;
    --NBC RFT Changes Ends

   --DBG('P_TYP_ERR='||P_TYP_ERR);

   --Pending Transaction Servcie for mobile banking starts
    IF P_FN_CALL_ID = '2' AND
       GWPKS_UTIL.PKG_FUNC IN ('1001', '1401', '1006') AND
       GWPKS_UTIL.pkg_actType IN ('SAVEAUTOAUTH') THEN
      --Cash Withdrawal, Cash Deposit and Fund Transfer Request

      SELECT COUNT(1)
        INTO L_COUNT
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_TY_RETAILTLR_UPD.TRN_REF_NO;

      dbg('L_COUNT L_COUNT L_COUNT=' || L_COUNT);

      SELECT *
        INTO L_DETB_RTL_TELLER
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_TY_RETAILTLR_UPD.TRN_REF_NO;

      DBG('L_DETB_RTL_TELLER.XREF;=' || L_DETB_RTL_TELLER.XREF);
      DBG('L_DETB_RTL_TELLER.TRN_REF_NO;=' || L_DETB_RTL_TELLER.TRN_REF_NO);
      DBG('L_DETB_RTL_TELLER.PRODUCT_CODE;=' ||
          L_DETB_RTL_TELLER.PRODUCT_CODE);
      DBG('L_DETB_RTL_TELLER.BRANCH_CODE;=' ||
          L_DETB_RTL_TELLER.BRANCH_CODE);
      DBG('L_DETB_RTL_TELLER.TXN_ACC;=' || L_DETB_RTL_TELLER.TXN_ACC);
      DBG('L_DETB_RTL_TELLER.TXN_CCY;=' || L_DETB_RTL_TELLER.TXN_CCY);
      DBG('L_DETB_RTL_TELLER.TXN_AMOUNT;=' || L_DETB_RTL_TELLER.TXN_AMOUNT);
      DBG('L_DETB_RTL_TELLER.TXN_BRANCH;=' || L_DETB_RTL_TELLER.TXN_BRANCH);
      DBG('L_DETB_RTL_TELLER.TXN_TRN_CODE;=' ||
          L_DETB_RTL_TELLER.TXN_TRN_CODE);
      DBG('L_DETB_RTL_TELLER.OFS_ACC;=' || L_DETB_RTL_TELLER.OFS_ACC);
      DBG('L_DETB_RTL_TELLER.OFS_CCY;=' || L_DETB_RTL_TELLER.OFS_CCY);
      DBG('L_DETB_RTL_TELLER.OFS_AMOUNT;=' || L_DETB_RTL_TELLER.OFS_AMOUNT);
      DBG('L_DETB_RTL_TELLER.OFS_BRANCH;=' || L_DETB_RTL_TELLER.OFS_BRANCH);
      DBG('L_DETB_RTL_TELLER.OFS_TRN_CODE;=' ||
          L_DETB_RTL_TELLER.OFS_TRN_CODE);
      DBG('L_DETB_RTL_TELLER.LCY_AMOUNT;=' || L_DETB_RTL_TELLER.LCY_AMOUNT);
      DBG('L_DETB_RTL_TELLER.TRN_DT;=' || L_DETB_RTL_TELLER.TRN_DT);
      DBG('L_DETB_RTL_TELLER.VALUE_DT;=' || L_DETB_RTL_TELLER.VALUE_DT);



      DBG('L_DETB_RTL_TELLER.REL_CUSTOMER;=' ||
          L_DETB_RTL_TELLER.REL_CUSTOMER);
      DBG('L_DETB_RTL_TELLER.CHARGE_ACCOUNT;=' ||
          L_DETB_RTL_TELLER.CHARGE_ACCOUNT);



      DBG('L_DETB_RTL_TELLER.AUTH_STAT;=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.AUTH_STAT;=' ||
          L_DETB_RTL_TELLER.MAKER_DT_STAMP);

      DBG('L_DETB_RTL_TELLER.AUTH_STAT;=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.TIME_RECEIVED;=' ||
          L_DETB_RTL_TELLER.TIME_RECEIVED);
      DBG('L_DETB_RTL_TELLER.RECORD_STAT;=' ||
          L_DETB_RTL_TELLER.RECORD_STAT);



      PR_INSERT_UNAUTH_ENTRIES_DIG(L_DETB_RTL_TELLER);



    END IF;
    --Pending Transaction Servcie for mobile banking ends

    --PRF_CUSTOM_11_19072018 starts

    DBG('CALL ID IS :' || P_FN_CALL_ID);
    IF P_FN_CALL_ID = '4' THEN
      IF CSPKS_CHARGE.g_action_code IS NOT NULL AND CSPKS_CHARGE.g_action_code = 'CLOSE' THEN
        DBG('ABOUT TO RE-INITIALIZE THE ERROR TABLE ONLY IN CASE OF ACCOUNT_CLOSURE');
        ovpkss.Pr_Initerrtbl;
      ELSE
        DBG('NOTHING TO DO');
      END IF;
    END IF;
    ---PRF_CUSTOM_11_19072018 changes ends
	
	--NCS Outgoing Payment Sampath Starts
    IF P_TY_RETAILTLR_UPD.PRODUCT_CODE IN ('NCSF', 'NCSI') THEN
    
      DBG('P_TY_RETAILTLR_UPD.PRODUCT_CODE=' ||
          P_TY_RETAILTLR_UPD.PRODUCT_CODE);
    
      DBG('P_TY_RETAILTLR_UPD.TXN_ACC=' || P_TY_RETAILTLR_UPD.TXN_ACC);
    
      BEGIN
        SELECT BRANCH_CODE
          INTO L_BRANCH_CODE
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC;
      EXCEPTION
        WHEN OTHERS THEN
          L_BRANCH_CODE := NULL;
      END;
    
      P_TY_RETAILTLR_UPD.TXN_BRANCH := L_BRANCH_CODE;
    
      P_TY_RETAILTLR_UPD.Branch_Code := L_BRANCH_CODE;
    
      DBG('L_BRANCH_CODE=' || L_BRANCH_CODE);
    
      IF P_TY_RETAILTLR_UPD.PRODUCT_CODE NOT IN ('NCSI') THEN
      
        DBG('P_UPL_UDF_DET.FIELD_NAME=' || P_UPL_UDF_DET(1).FIELD_NAME);
        DBG('P_UPL_UDF_DET.FIELD_VALUE=' || P_UPL_UDF_DET(1).FIELD_VAL);
        
        G_REQUESTORS_BRANCH := P_UPL_UDF_DET(1).FIELD_VAL;
    
      IF P_TY_RETAILTLR_UPD.TXN_CCY = 'KHR' AND
         P_TY_RETAILTLR_UPD.OFS_CCY = 'KHR' THEN
      
        L_EXCH_RATE_FLAG := TRUE;
        G_EXCHANGE_RATE  := FN_GET_MID_RATE(P_TY_RETAILTLR_UPD.TXN_BRANCH);
        G_EXCHANGE_RATE1 := FN_GET_COMM_SALE_RATE(P_TY_RETAILTLR_UPD.TXN_BRANCH);
      
      ELSIF P_TY_RETAILTLR_UPD.TXN_CCY = 'KHR' AND
            P_TY_RETAILTLR_UPD.OFS_CCY = 'USD' THEN
      
        L_EXCH_RATE_FLAG := TRUE;
        G_EXCHANGE_RATE  := P_UPL_UDF_DET(2).FIELD_VAL;
        G_EXCHANGE_RATE1 := FN_GET_COMM_SALE_RATE(P_TY_RETAILTLR_UPD.TXN_BRANCH);
      
      ELSE
      
        G_EXCHANGE_RATE := P_UPL_UDF_DET(2).FIELD_VAL;
      
      END IF;
      
      END IF;
    
      
    
    END IF;
    --NCS outgoing payment Sampath ends

    DBG('Returning Successfully from depks_ret_telr_upld_custom.fn_upload..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of depks_ret_telr_upld_custom.fn_upload ..'||SQLERRM);
      RETURN FALSE;
  END FN_UPLOAD;


 FUNCTION FN_VALIDATE(P_TY_RETAILTLR_UPD IN OUT NOCOPY DETB_UPLOAD_RTL_TELLER%ROWTYPE
                      ,P_TBL_CHGDETS      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_TBLCHGDETS
                      ,P_UPL_MIS_DET      IN OUT NOCOPY MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE
                      ,P_UPL_UDF_DET      IN OUT NOCOPY UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF
                      ,P_TY_MCKDETAILS    IN OUT NOCOPY ISTB_UPLOAD_CONTRACTIS%ROWTYPE
                      ,P_TY_MSGDETS       IN OUT NOCOPY CSTB_UPLOAD_ARC_SETTLE%ROWTYPE
                      ,P_TBL_NODE_REC     IN DEPKS_RETAILTELLERUPLOAD.TYP_NODE_TBL
                      ,P_RET              IN OUT NUMBER
                      ,P_FN_CALL_ID       IN OUT NUMBER
                      ,P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS

  --RIA Incoming Payment Starts
    L_CUST_NO        STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    L_RATE_CODE      CSTM_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_RATE_TYPE      CSTM_PRODUCT.RATE_TYPE_PREFERRED%TYPE;
    L_X_RATE_DERIVED CYTM_RATES.MID_RATE%TYPE;
    L_RATE_FLAG      NUMBER;
    l_txn_amt        DETB_RTL_TELLER.TXN_AMOUNT%TYPE;
    L_AMOUNT         STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_AMOUNT1        STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    P_ERR_CODE       VARCHAR2(100);
    P_ERR_PARAM      VARCHAR2(100);
    --RIA Incoming Payment Ends

  BEGIN


      DBG('IF', 'Inside depks_ret_telr_upld_custom.fn_validate ...');


    --sampath starts
  --RIA Incoming Payment Starts
    --Validate customer limit per day 9999 USD starts
    IF P_TY_RETAILTLR_UPD.PRODUCT_CODE IN ('RIAI') THEN

      DBG('P_TY_RETAILTLR_UPD.OFS_ACC=' ||
          P_TY_RETAILTLR_UPD.OFS_ACC);

      --Get Customer no for this offset account
      BEGIN
        SELECT CUST_NO
          INTO L_CUST_NO
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.OFS_ACC;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NO := NULL;
      END;

      IF P_TY_RETAILTLR_UPD.OFS_CCY <> P_TY_RETAILTLR_UPD.TXN_CCY AND
         P_TY_RETAILTLR_UPD.OFS_CCY = 'KHR' THEN
        --KHR AMOUNT COMING IN SWITCH

        dbg('inside else condition100');
        dbg('amount coming in switch is KHR nothing but ofs_ccy');
        dbg('amount currency in switch is KHR nothing but txn_amount_Derived');
        dbg('account currency is USD');

        BEGIN

          SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
            INTO L_RATE_CODE, L_RATE_TYPE
            FROM CSTMS_PRODUCT
           WHERE PRODUCT_CODE = P_TY_RETAILTLR_UPD.PRODUCT_CODE
             AND MODULE = 'RT'
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CODE := 'SW-PRD-01';
            DBG('NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                P_ERR_PARAM);
            RETURN FALSE;
        END;

        --Get Rate
        IF NOT CYPKSS.FN_GETRATE(P_TY_RETAILTLR_UPD.TXN_BRANCH,
                                 P_TY_RETAILTLR_UPD.OFS_CCY, --KHR currency coming in switch
                                 P_TY_RETAILTLR_UPD.TXN_CCY, --USD account ccy
                                 L_RATE_TYPE,
                                 L_RATE_CODE,
                                 P_TY_RETAILTLR_UPD.TRN_DT,
                                 P_TY_RETAILTLR_UPD.TRN_DT,
                                 L_X_RATE_DERIVED,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;

        DBG('L_X_RATE_DERIVED=' || L_X_RATE_DERIVED);
        DBG('P_TY_RETAILTLR_UPD.OFS_CCY=' ||
            P_TY_RETAILTLR_UPD.OFS_CCY);
        DBG('P_TY_RETAILTLR_UPD.TXN_CCY=' ||
            P_TY_RETAILTLR_UPD.TXN_CCY);
        DBG('P_TY_RETAILTLR_UPD.OFS_AMOUNT=' ||
            P_TY_RETAILTLR_UPD.OFS_AMOUNT);

        --Get USD Amount
        IF P_TY_RETAILTLR_UPD.OFS_CCY = 'USD' AND
           P_TY_RETAILTLR_UPD.TXN_CCY = 'KHR' THEN
          IF NOT cypkss.fn_amt1_to_amt2(P_TY_RETAILTLR_UPD.BRANCH_CODE,
                                        P_TY_RETAILTLR_UPD.OFS_CCY, --KHR currency coming in switch
                                        P_TY_RETAILTLR_UPD.TXN_CCY, --USD account ccy
                                        L_RATE_TYPE,
                                        'S',
                                        P_TY_RETAILTLR_UPD.OFS_AMOUNT, --khr amount comnig ni api
                                        --P_TY_RETAILTLR_UPD.TXN_AMOUNT, --khr amount coming in switch
                                        'Y',
                                        l_txn_amt,
                                        L_X_RATE_DERIVED, -- l_rate,
                                        P_ERR_PARAM) THEN
            debug.pr_debug('**', '');
            debug.pr_debug('**', SQLERRM);
            p_err_code  := 'ST-OTHR-001';
            P_ERR_PARAM := NULL;
            RETURN FALSE;
          END IF;

          --P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := L_TXN_AMT;

          DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED FINAL=' || L_TXN_AMT); --THIS IS USD AMOUNT

        ELSE

          L_TXN_AMT := P_TY_RETAILTLR_UPD.txn_amount;

        END IF;

        --sampath ends for cash deposit exchange rate column in acc entry ends

        DBG('L_CUST_NO=' || L_CUST_NO);

        BEGIN

          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE --AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC --P_TY_ATM_TXN_REC.txn_acc_no_fcc
          /*RELATED_CUSTOMER IN
          (SELECT CUST_NO
             FROM STTM_CUST_ACCOUNT
            WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC)*/

           AC_NO IN (SELECT CUST_AC_NO
                       FROM STTM_CUST_ACCOUNT
                      WHERE CUST_NO = L_CUST_NO)

           AND CUST_GL = 'A'
           AND AUTH_STAT = 'A'
           AND USER_ID = 'API1USER'
           AND MODULE = 'RT'
           AND DRCR_IND = 'C'
          --AND B.PAN = '7777777XXXXXXXXXX'
           AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAI'
           AND A.EVENT NOT IN ('CYPO')
           AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;

        DBG('L_AMOUNT==' || L_AMOUNT);

        --L_AMOUNT1 := (L_AMOUNT / P_TY_ATM_TXN_REC.X_RATE_DERIVED) + L_TXN_AMT;

        L_AMOUNT1 := L_AMOUNT + L_TXN_AMT;

        DBG('SUM=' || L_AMOUNT1);

        IF 9999 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'API1', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;

      ELSIF P_TY_RETAILTLR_UPD.OFS_CCY <> --this elseif case never come as txn ccy is always USD
            P_TY_RETAILTLR_UPD.TXN_CCY AND
            P_TY_RETAILTLR_UPD.OFS_CCY = 'USD' --USD AMOUNT COMING IN SWITCH
       THEN

        dbg('inside else condition101');
        dbg('amount coming in switch is usd nothing but ofs_ccy');
        dbg('amount currency in switch is usd nothing but txn_amount_Derived');
        dbg('account currency is khr');

        BEGIN

          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE --AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC
          /*RELATED_CUSTOMER IN
          (SELECT CUST_NO
             FROM STTM_CUST_ACCOUNT
            WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC)*/
           AC_NO IN (SELECT CUST_AC_NO
                       FROM STTM_CUST_ACCOUNT
                      WHERE CUST_NO = L_CUST_NO)
           AND CUST_GL = 'A'
           AND AUTH_STAT = 'A'
           AND USER_ID = 'API1USER'
           AND MODULE = 'RT'
           AND DRCR_IND = 'C'
          --AND B.PAN = '7777777XXXXXXXXXX'
           AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAI'
           AND A.EVENT NOT IN ('CYPO')
           AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;

        DBG('L_AMOUNT==' || L_AMOUNT);

        DBG('P_TY_RETAILTLR_UPD.TXN_AMOUNT==' ||
            P_TY_RETAILTLR_UPD.TXN_AMOUNT);

        L_AMOUNT1 := (L_AMOUNT /* / P_TY_ATM_TXN_REC.X_RATE_DERIVED*/
                     ) + P_TY_RETAILTLR_UPD.TXN_AMOUNT;

        DBG('SUM=' || L_AMOUNT1);

        IF 9999 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'API1', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;

      ELSE

        dbg('inside final else condition');

        dbg('L_AMOUNT==' || L_AMOUNT);

        BEGIN

          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE AC_NO IN (SELECT CUST_AC_NO
                             FROM STTM_CUST_ACCOUNT
                            WHERE CUST_NO = L_CUST_NO)
             AND CUST_GL = 'A'
             AND AUTH_STAT = 'A'
             AND USER_ID = 'API1USER'
             AND MODULE = 'RT'
             AND DRCR_IND = 'C'
             AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAI'
             AND A.EVENT NOT IN ('CYPO')
             AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;

        DBG('L_AMOUNT==' || L_AMOUNT);

        DBG('P_TY_RETAILTLR_UPD.TXN_AMOUNT==' ||
            P_TY_RETAILTLR_UPD.TXN_AMOUNT);

        --Get Rate
        IF NOT CYPKSS.FN_GETRATE(P_TY_RETAILTLR_UPD.TXN_BRANCH,
                                 P_TY_RETAILTLR_UPD.OFS_CCY, --KHR currency coming in switch
                                 'USD', --USD account ccy
                                 L_RATE_TYPE,
                                 L_RATE_CODE,
                                 P_TY_RETAILTLR_UPD.TRN_DT,
                                 P_TY_RETAILTLR_UPD.TRN_DT,
                                 L_X_RATE_DERIVED,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;

        DBG('L_X_RATE_DERIVED=' || L_X_RATE_DERIVED);

        IF P_TY_RETAILTLR_UPD.TXN_CCY = P_TY_RETAILTLR_UPD.OFS_CCY AND
           P_TY_RETAILTLR_UPD.OFS_CCY = 'KHR' THEN

          DBG('Inside If condition of apple');

          L_AMOUNT1 := (L_AMOUNT) +
                       (P_TY_RETAILTLR_UPD.TXN_AMOUNT / L_X_RATE_DERIVED);

        ELSE

          L_AMOUNT1 := (L_AMOUNT) + P_TY_RETAILTLR_UPD.TXN_AMOUNT;

        END IF;

        DBG('SUM=' || L_AMOUNT1);

        IF 9999 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'API1', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;

      END IF;
    END IF;

    IF P_TY_RETAILTLR_UPD.PRODUCT_CODE IN ('RIAB') THEN
      IF P_TY_RETAILTLR_UPD.OFS_CCY <> P_TY_RETAILTLR_UPD.TXN_CCY AND
         P_TY_RETAILTLR_UPD.OFS_CCY = 'KHR' THEN
        --KHR AMOUNT COMING IN SWITCH

        dbg('inside else condition100');
        dbg('amount coming in switch is KHR nothing but ofs_ccy');
        dbg('amount currency in switch is KHR nothing but txn_amount_Derived');
        dbg('account currency is USD');

        BEGIN

          SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
            INTO L_RATE_CODE, L_RATE_TYPE
            FROM CSTMS_PRODUCT
           WHERE PRODUCT_CODE = P_TY_RETAILTLR_UPD.PRODUCT_CODE
             AND MODULE = 'RT'
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CODE := 'SW-PRD-01';
            DBG(
                'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                P_ERR_PARAM);
            RETURN FALSE;
        END;

        --Get Rate
        IF NOT CYPKSS.FN_GETRATE(P_TY_RETAILTLR_UPD.TXN_BRANCH,
                                 P_TY_RETAILTLR_UPD.OFS_CCY, --KHR currency coming in switch
                                 P_TY_RETAILTLR_UPD.TXN_CCY, --USD account ccy
                                 L_RATE_TYPE,
                                 L_RATE_CODE,
                                 P_TY_RETAILTLR_UPD.TRN_DT,
                                 P_TY_RETAILTLR_UPD.TRN_DT,
                                 L_X_RATE_DERIVED,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;

        DBG('L_X_RATE_DERIVED=' || L_X_RATE_DERIVED);

        --Get USD Amount
        IF NOT cypkss.fn_amt1_to_amt2(P_TY_RETAILTLR_UPD.BRANCH_CODE,
                                      P_TY_RETAILTLR_UPD.OFS_CCY, --KHR currency coming in switch
                                      P_TY_RETAILTLR_UPD.TXN_CCY, --USD account ccy
                                      L_RATE_TYPE,
                                      'S',
                                      --P_TY_RETAILTLR_UPD.OFS_AMOUNT,
                                      P_TY_RETAILTLR_UPD.TXN_AMOUNT, --khr amount coming in switch
                                      'Y',
                                      l_txn_amt,
                                      L_X_RATE_DERIVED, -- l_rate,
                                      P_ERR_PARAM) THEN
          debug.pr_debug('**', '');
          debug.pr_debug('**', SQLERRM);
          p_err_code  := 'ST-OTHR-001';
          P_ERR_PARAM := NULL;
          RETURN FALSE;
        END IF;

        --P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := L_TXN_AMT;

        DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED FINAL=' || L_TXN_AMT); --THIS IS USD AMOUNT

        --sampath ends for cash deposit exchange rate column in acc entry ends

        BEGIN

          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE --AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC --P_TY_ATM_TXN_REC.txn_acc_no_fcc
          /*RELATED_CUSTOMER IN
          (SELECT CUST_NO
             FROM STTM_CUST_ACCOUNT
            WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC)*/
           AC_NO IN (SELECT CUST_AC_NO
                       FROM STTM_CUST_ACCOUNT
                      WHERE CUST_NO = L_CUST_NO)
           AND CUST_GL = 'A'
           AND AUTH_STAT = 'A'
           AND USER_ID = 'API1USER'
           AND MODULE = 'RT'
           AND DRCR_IND = 'C'
          --AND B.PAN = '7777777XXXXXXXXXX'
           AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAB'
           AND A.EVENT NOT IN ('CYPO')
           AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;

        DBG('L_AMOUNT==' || L_AMOUNT);

        --L_AMOUNT1 := (L_AMOUNT / P_TY_ATM_TXN_REC.X_RATE_DERIVED) + L_TXN_AMT;

        L_AMOUNT1 := L_AMOUNT + L_TXN_AMT;

        DBG('SUM=' || L_AMOUNT1);

        IF 9999 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'API1', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;

      ELSIF P_TY_RETAILTLR_UPD.OFS_CCY <> P_TY_RETAILTLR_UPD.TXN_CCY AND
            P_TY_RETAILTLR_UPD.OFS_CCY = 'USD' --USD AMOUNT COMING IN SWITCH
       THEN

        dbg('inside else condition101');
        dbg('amount coming in switch is usd nothing but ofs_ccy');
        dbg('amount currency in switch is usd nothing but txn_amount_Derived');
        dbg('account currency is khr');

        BEGIN

          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE --AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC
          /*RELATED_CUSTOMER IN
          (SELECT CUST_NO
             FROM STTM_CUST_ACCOUNT
            WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC)*/
           AC_NO IN (SELECT CUST_AC_NO
                       FROM STTM_CUST_ACCOUNT
                      WHERE CUST_NO = L_CUST_NO)
           AND CUST_GL = 'A'
           AND AUTH_STAT = 'A'
           AND USER_ID = 'API1USER'
           AND MODULE = 'RT'
           AND DRCR_IND = 'C'
          --AND B.PAN = '7777777XXXXXXXXXX'
           AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAB'
           AND A.EVENT NOT IN ('CYPO')
           AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;

        DBG('L_AMOUNT==' || L_AMOUNT);

        DBG('P_TY_RETAILTLR_UPD.TXN_AMOUNT==' ||
            P_TY_RETAILTLR_UPD.TXN_AMOUNT);

        L_AMOUNT1 := (L_AMOUNT /* / P_TY_ATM_TXN_REC.X_RATE_DERIVED*/
                     ) + P_TY_RETAILTLR_UPD.TXN_AMOUNT;

        DBG('SUM=' || L_AMOUNT1);

        IF 9999 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'API1', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;

      ELSE

        dbg('inside final else condition');

        BEGIN

          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE --AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC
          /*RELATED_CUSTOMER IN
          (SELECT CUST_NO
             FROM STTM_CUST_ACCOUNT
            WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC)*/
           AC_NO IN (SELECT CUST_AC_NO
                       FROM STTM_CUST_ACCOUNT
                      WHERE CUST_NO = L_CUST_NO)
           AND CUST_GL = 'A'
           AND AUTH_STAT = 'A'
           AND USER_ID = 'API1USER'
           AND MODULE = 'RT'
           AND DRCR_IND = 'C'
          --AND B.PAN = '7777777XXXXXXXXXX'
           AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAB'
           AND A.EVENT NOT IN ('CYPO')
           AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;

        DBG('L_AMOUNT==' || L_AMOUNT);

        DBG('P_TY_RETAILTLR_UPD.TXN_AMOUNT==' ||
            P_TY_RETAILTLR_UPD.TXN_AMOUNT);

        --Get Rate
        IF NOT CYPKSS.FN_GETRATE(P_TY_RETAILTLR_UPD.TXN_BRANCH,
                                 P_TY_RETAILTLR_UPD.OFS_CCY, --KHR currency coming in switch
                                 'USD', --USD account ccy
                                 L_RATE_TYPE,
                                 L_RATE_CODE,
                                 P_TY_RETAILTLR_UPD.TRN_DT,
                                 P_TY_RETAILTLR_UPD.TRN_DT,
                                 L_X_RATE_DERIVED,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;

        DBG('L_X_RATE_DERIVED=' || L_X_RATE_DERIVED);

        IF P_TY_RETAILTLR_UPD.TXN_CCY = P_TY_RETAILTLR_UPD.OFS_CCY AND
           P_TY_RETAILTLR_UPD.OFS_CCY = 'KHR' THEN

          DBG('Inside If condition of apple');

          L_AMOUNT1 := (L_AMOUNT) +
                       (P_TY_RETAILTLR_UPD.TXN_AMOUNT / L_X_RATE_DERIVED);

        ELSE

          L_AMOUNT1 := (L_AMOUNT) + P_TY_RETAILTLR_UPD.TXN_AMOUNT;

        END IF;

        DBG('SUM=' || L_AMOUNT1);

        IF 9999 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'API1', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;

      END IF;
    END IF;
    --Validate customer limit per day 9999 USD ends
    --RIA Incoming Payment Ends
    --sampath ends


    DBG('IF', 'Returning Successfully from depks_ret_telr_upld_custom.fn_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
                     'In When Others of depks_ret_telr_upld_custom.fn_validate ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE;




  FUNCTION FN_RESOLVE_REF(P_EXT_REF    IN OUT DETBS_RTL_TELLER.XREF%TYPE
                          ,P_FCC_REF    IN OUT DETBS_RTL_TELLER.TRN_REF_NO%TYPE
              ,P_FN_CALL_ID    IN OUT NUMBER
                          ,P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA
                          ,P_ERR_CODE   IN OUT VARCHAR2
                          ,P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
    BEGIN
     DBG('Inside Depks_Retailtellerupd_CUSTOM.Fn_Resolve_Ref ...');
      IF P_FN_CALL_ID = 1 THEN
        DBG('Inside Fn_Resolve_Ref ...');


      END IF;
      DBG('Returning Successfully from Fn_Resolve_Ref..');
      RETURN TRUE;
      EXCEPTION
      WHEN OTHERS THEN
        DBG('In When Others of Depks_Retailtellerupd_CUSTOM.Fn_Resolve_Ref ..');
        DBG(SQLERRM);
        P_ERR_CODE := SQLERRM;
        RETURN FALSE;
      END FN_RESOLVE_REF;


FUNCTION FN_REVERSE(P_XREF                 IN OUT NOCOPY VARCHAR2
            ,P_FCCREF            IN OUT NOCOPY VARCHAR2
            ,P_SOURCE            IN VARCHAR2
            ,P_OVERRIDE_FLAG     IN OUT NOCOPY VARCHAR2
            ,P_AUTO_AUTH_FLAG    IN OUT NOCOPY VARCHAR2
            ,P_TYP_ERR           IN OUT NOCOPY OVPKSS.TBL_ERROR
            ,P_FN_CALL_ID       IN OUT NOCOPY NUMBER
                        ,P_TB_CUSTOM_DATA    IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) RETURN BOOLEAN IS

  BEGIN

  DBG('Inside fn_reverse in custom');
  DBG('Returning Successfully from Depks_Retailtellerupd_Custom.fn_reverse..');
  RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Depks_Retailtellerupd_Custom.fn_reverse..');
    P_TYP_ERR := OVPKSS.GL_TBLERROR;
      RETURN FALSE;
  END FN_REVERSE;


FUNCTION FN_VALIDATE_RTL_TELLER_REC(P_TY_RETAILTLR_UPD IN OUT NOCOPY DETB_UPLOAD_RTL_TELLER%ROWTYPE,
                                    P_RET              IN OUT NUMBER,
                                    P_FN_CALL_ID       IN OUT NUMBER,
                                    P_TB_CUSTOM_DATA   IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
  RETURN BOOLEAN IS
BEGIN
  DBG('In Fn_Validate_Rtl_Teller_Rec..');

  DBG('Returning Fn_Validate_Rtl_Teller_Rec');
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    DEBUG.PR_DEBUG('**',
                   'In when others of depks_retailtellerupd_custom.Fn_Validate_Rtl_Teller_Rec ..');
    DEBUG.PR_DEBUG('**', SQLERRM);
    RETURN FALSE;
END FN_VALIDATE_RTL_TELLER_REC;


  FUNCTION FN_DEFAULT_CHGDETS(P_TBL_CHGDETS  IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_TBLCHGDETS,
                              P_DETB_RTL_TLR IN DETBS_RTL_TELLER%ROWTYPE,
                              P_RET          IN OUT NUMBER,
                P_FN_CALL_ID       IN OUT NOCOPY NUMBER,
                    P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA) RETURN BOOLEAN  IS
  BEGIN
  DBG('Inside fn_default_chgdets');

  DBG('Returning success from fn_default_chgdets');
  RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_ret_telr_upld_custom.fn_default_chgdets ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
     P_RET := -1;
      RETURN FALSE;
  END FN_DEFAULT_CHGDETS;


FUNCTION FN_VALIDATE_CHG_GL(P_CHG_GL             IN STTBS_ACCOUNT.AC_GL_NO%TYPE
                              ,P_RET               IN OUT NUMBER
                ,P_FN_CALL_ID        IN OUT NUMBER
                              ,P_TB_CUSTOM_DATA    IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
  RETURN BOOLEAN IS
  BEGIN
  DBG('Inside fn_validate_chg_gl');

  DBG('Returning success from fn_validate_chg_gl');
  RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_ret_telr_upld_custom.fn_validate_chg_gl ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
    P_RET := -1;
  END FN_VALIDATE_CHG_GL;


 FUNCTION FN_PRE_GET_AC_ROW(P_BRN          IN VARCHAR2,
                         P_PROD         IN VARCHAR2,
                         P_REL_CUSTOMER IN VARCHAR2,
                         P_COD_CCY      IN VARCHAR2,
                         P_IB_FLAG      IN VARCHAR2 DEFAULT 'N',
                         P_ARC_MAINT    IN OUT NOCOPY IFTMS_ARC_MAINT%ROWTYPE,
                         P_ERR_CODE     IN OUT VARCHAR2,
                         P_ERR_PARAM    IN OUT VARCHAR2,
                         P_TXN_AC_NO    IN VARCHAR2,
                         P_AC_BRN       IN VARCHAR2)

   RETURN BOOLEAN IS
  BEGIN
  DBG('Inside depks_ret_telr_upld_custom.fn_pre_get_ac_row');

  DBG('Returning success from depks_ret_telr_upld_custom.fn_pre_get_ac_row');
  RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of depks_ret_telr_upld_custom.fn_pre_get_ac_row ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_GET_AC_ROW;


FUNCTION FN_ARC_SETTLE_PICKUP(P_ROUTE_CODE IN VARCHAR2,
                                P_CR_ACCOUNT IN OUT VARCHAR2,
                                P_CR_BRANCH  IN OUT VARCHAR2,
                                P_ARC_SETTLE IN OUT NOCOPY CSTBS_ARC_SETTLE%ROWTYPE,
                                P_RET        IN OUT NUMBER,
                P_FN_CALL_ID        IN OUT NUMBER,
                                P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
  RETURN BOOLEAN IS
  BEGIN
  DBG('Inside fn_arc_settle_pickup in cluster');

  DBG('Returning Successfully from Depks_Retailtellerupld_Cluster.fn_arc_settle_pickup..');
  RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Depks_Retailtellerupld_Cluster.fn_arc_settle_pickup..' || SQLERRM);
      RETURN FALSE;
  END FN_ARC_SETTLE_PICKUP;


END DEPKS_RET_TELR_UPLD_CUSTOM;
