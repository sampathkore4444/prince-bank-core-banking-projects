*************************Final Starts*********************
BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM (
program_name      => 'PROG_PROCESS_NCS_PAYMENTS_MORNING',
program_action    => 'PR_PROCESS_NCS_PAYMENTS_MORNING',
program_type      => 'STORED_PROCEDURE');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM (
program_name      => 'PROG_PROCESS_NCS_PAYMENTS_LUNCH',
program_action    => 'PR_PROCESS_NCS_PAYMENTS_LUNCH',
program_type      => 'STORED_PROCEDURE');
END;
/

--this is for daily at 10:30AM
BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_DAILY_NCS_SCHEDULE_MORNING',
 start_date    => TRUNC(SYSDATE, 'HH'),
 repeat_interval  => 'FREQ=DAILY;BYHOUR=09;BYMINUTE=35',
 comments     => 'Daily at 09:35 AM');
END;
/

--this is for daily at 01:35PM
BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_DAILY_NCS_SCHEDULE_LUNCH',
 start_date    => TRUNC(SYSDATE, 'HH'),
 repeat_interval  => 'FREQ=DAILY;BYHOUR=13;BYMINUTE=35',
 comments     => 'Daily at 01:35 PM');
END;
/


BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_PROCESS_NCS_PAYMENTS_MORNING',
  program_name   => 'PROG_PROCESS_NCS_PAYMENTS_MORNING',
  schedule_name   => 'SCH_DAILY_NCS_SCHEDULE_MORNING',
  enabled            =>  true);
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_PROCESS_NCS_PAYMENTS_LUNCH',
  program_name   => 'PROG_PROCESS_NCS_PAYMENTS_LUNCH',
  schedule_name   => 'SCH_DAILY_NCS_SCHEDULE_LUNCH',
  enabled            =>  true);
END;
/
--enable job
begin
dbms_scheduler.enable('JOB_PROCESS_NCS_PAYMENTS_MORNING');
end;
--enable program
begin
DBMS_SCHEDULER.ENABLE('PROG_PROCESS_NCS_PAYMENTS_MORNING');
end;

--enable job
begin
dbms_scheduler.enable('JOB_PROCESS_NCS_PAYMENTS_LUNCH');
end;
--enable program
begin
DBMS_SCHEDULER.ENABLE('PROG_PROCESS_NCS_PAYMENTS_LUNCH');
end;


--drop1:
begin
  dbms_scheduler.drop_job('JOB_PROCESS_NCS_PAYMENTS_MORNING');
end;

--drop2:
begin
 dbms_scheduler.drop_schedule('SCH_DAILY_NCS_SCHEDULE_MORNING');
end;

--drop3:
begin
  dbms_scheduler.drop_program('PROG_PROCESS_NCS_PAYMENTS_MORNING');
end;

--drop1:
begin
  dbms_scheduler.drop_job('JOB_PROCESS_NCS_PAYMENTS_LUNCH');
end;

--drop2:
begin
 dbms_scheduler.drop_schedule('SCH_DAILY_NCS_SCHEDULE_LUNCH');
end;

--drop3:
begin
  dbms_scheduler.drop_program('PROG_PROCESS_NCS_PAYMENTS_LUNCH');
end;

--queries
SELECT * FROM dba_scheduler_jobs WHERE owner = 'P1OBPRFM' AND JOB_NAME IN ('JOB_PROCESS_NCS_PAYMENTS_MORNING', 'JOB_PROCESS_NCS_PAYMENTS_LUNCH');
SELECT * FROM DBA_SCHEDULER_PROGRAMS WHERE  owner = 'P1OBPRFM';

select * from User_Scheduler_Job_Run_Details WHERE JOB_NAME IN ('JOB_PROCESS_NCS_PAYMENTS_MORNING', 'JOB_PROCESS_NCS_PAYMENTS_LUNCH') order by log_id desc 
select * from user_scheduler_job_log WHERE JOB_NAME IN ('JOB_PROCESS_NCS_PAYMENTS_MORNING', 'JOB_PROCESS_NCS_PAYMENTS_LUNCH') order by log_id desc 
select * from user_scheduler_jobs WHERE JOB_NAME IN ('JOB_PROCESS_NCS_PAYMENTS_MORNING', 'JOB_PROCESS_NCS_PAYMENTS_LUNCH');

SELECT * FROM IFTB_NCS_INCOMING_TRACK WHERE SERIAL_NO IN ('FTW777779','100LT22180996715','100LT72191096787');
SELECT * FROM IFTB_NCS_INC_TRACK;
SELECT * FROM IFTB_NCS_SERIAL_NO_LOG  WHERE SERIAL_NO IN ('FTW777779','100LT22180996715','100LT72191096787');

SELECT * FROM IFTB_NCS_SERIAL_NO_LOG  WHERE SERIAL_NO IN ('FTW777789','100LT22180996725','100LT72191096797');

SELECT * FROM IFTB_NCS_MASTER WHERE RELATED_REF_NO = '000OBPM210061002';

SELECT * FROM IFTB_NCS_INCOMING_TRACK WHERE STATUS IN ('U');

SELECT * FROM IFTB_NCS_INCOMING_TRACK WHERE SERIAL_NO IN ('FTW177719','100LT12180996735','100LT12191096187');
SELECT * FROM IFTB_NCS_SERIAL_NO_LOG  WHERE SERIAL_NO IN ('FTW477719','100LT42180996735','100LT42191096187');
SELECT * FROM IFTB_NCS_MASTER a WHERE trn_ref_no in ('013NCSI200140522','013NCSI200140523') or a.batch_no = 'O9931245/102' for update
