CREATE OR REPLACE PACKAGE depks_ret_telr_upld_custom AS
/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2012 - 2015  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
-----------------------------------------------------------------------------------------*/
  /*
    -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  Change Description : New Cluster Package (FCUBS_12.0_FUJITSU(EXT HOOKS)_15842655)
  Created By         : Ankit Srivastava
  Created On         : 08/11/2012

  Created By				      : Ankit Tiwari
  Change Description			: Hook Has been provided for the function FN_VALIDATE
  Chnaged On    				  : 06-Sep-2013
  Search string			      : FCUBS_12.0.2_IDTKEKE_17420685

 Modified By         : Sriraam S
 Modified On         : 12-Dec-2013
 Modified Reason     : Hook to determine xref from transaction ref, Base bug#17940518
 Search String       : 9NT1525_1202_IUPKRASK_17940525

   Changed By                 : Mantinder Kaur
   Changed On                 : 24-July-2014
   Change Description         : Hook given to handle transaction between two branches out of whichone branch resides in flexcube
				                and other branch resides in non flexcube systems.
   Search string              : 9NT1587_1203_INTERNAL_19281031

Modified By        : Saisudha Rathinavelu
Modified On        : 28-Sep-2016
Modified Reason    : Retro for hook change bug id 21384115.
Search String      : 12.2_RETRO_Bug#23656095

  ** Modified By         : Karthikeyan k
  ** Modified On         : 07-OCT-2016
  ** Modified Reason     : Manual Merger from 12.2 to 12.3
  ** Search String       : [FCUBS12.3->Retro->24702528]

**    Modified By       :Nidhi Verma
**    Modified On       : 09-Jan-2017
**    Modified Reason   : Manual Merger from 12.2 to 12.3[FCUBS12.3->Retro->25088446]
**    Search String     : Bug#25357568

    **Modified By         : Nidhi Verma
    **Modified On         : 05-May-2017
    **Modified Reason     : Hook request. EHD ref: KHRSPN_12.0.3_24_APR_2017_02_0000
    **search String       : Bug#25989671

Modified By        : Saisudha Rathinavelu
Modified On        : 02-Aug-2017
Modified Reason    : Retro for hook change bug id 26391828.
Search String      : 12.4_RETRO_Bug#26441050

**   Modified By    : Saurabh Sarawagi
**   Changed On     : 28-Aug-2017
**   Description    : provided hook changes(Retro for Bug#26449958)
**   Search string  : Bug#26474242

Modified By         : Saisudha Rathinavelu
Modified On         : 27-Jun-2018
Modified Reason     : Provided Extensible hooks.
Search String       : Bug#28251023

    -------------------------------------------------------------------------------------------------------
  */

 --NCS outgoing payment Sampath Starts
  G_REQUESTORS_BRANCH STTM_BRANCH.BRANCH_CODE%TYPE;
  G_EXCHANGE_RATE     ACTB_DAILY_LOG.EXCH_RATE%TYPE;
  G_EXCHANGE_RATE1    ACTB_DAILY_LOG.EXCH_RATE%TYPE;
  L_EXCH_RATE_FLAG    BOOLEAN := FALSE;
  --NCS outgoing payment Sampath Ends 
  
 --[FCUBS12.3->Retro->24702528] starts
 --FCUBS_122_23658351_RETRO_FROM_22922272 starts
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2);
FUNCTION fn_default_chgdets_Pre(p_tbl_chgdets  IN OUT NOCOPY Depks_RetailTellerUpload.typ_tblchgdets,
                              p_detb_rtl_tlr IN detbs_rtl_teller%ROWTYPE,
                              p_ret          IN OUT NUMBER)
RETURN BOOLEAN;

FUNCTION fn_default_chgdets_Post(p_tbl_chgdets  IN OUT NOCOPY Depks_RetailTellerUpload.typ_tblchgdets,
                              p_detb_rtl_tlr IN detbs_rtl_teller%ROWTYPE,
                              p_ret          IN OUT NUMBER)
RETURN BOOLEAN;

 --FCUBS_122_23658351_RETRO_FROM_22922272 ends
--[FCUBS12.3->Retro->24702528] ends
  FUNCTION fn_upload(p_ty_retailtlr_upd IN OUT NOCOPY detb_upload_rtl_teller%ROWTYPE,
                     p_tbl_chgdets      IN OUT NOCOPY depks_retailtellerupload.typ_tblchgdets,
                     p_upl_mis_det      IN OUT NOCOPY mitbs_upload_class_mapping%ROWTYPE,
                     p_upl_udf_det      IN OUT NOCOPY uvpkss_udf_upload.ty_upl_cont_udf,
                     p_upl_pcdetails    IN OUT NOCOPY DETB_PCTRN%ROWTYPE,
                     p_ty_mckdetails    IN OUT NOCOPY istb_upload_contractis%ROWTYPE,
                     p_ty_msgdets       IN OUT NOCOPY cstb_upload_arc_settle%ROWTYPE,
                     p_tbl_node_rec     IN depks_retailtellerupload.typ_node_tbl,
                     p_source           IN VARCHAR2,
                     p_override_flag    IN OUT CHAR, --OUT CHAR, --9NT1587_1203_INTERNAL_19281031(Making the variable IN OUT)
                     p_auth_stat        IN OUT CHAR, --OUT CHAR, --9NT1587_1203_INTERNAL_19281031(Making the variable IN OUT)
                     p_ret              IN OUT NUMBER,
                     p_typ_err          IN OUT NOCOPY ovpkss.tbl_error,
                     p_Fn_Call_Id       IN NUMBER,
                     p_tb_cluster_data  IN OUT NOCOPY Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN;

--FCUBS_12.0.2_IDTKEKE_17420685 starts
  FUNCTION fn_validate(p_ty_retailtlr_upd IN OUT NOCOPY detb_upload_rtl_teller%ROWTYPE
                      ,p_tbl_chgdets      IN OUT NOCOPY depks_retailtellerupload.typ_tblchgdets
                      ,p_upl_mis_det      IN OUT NOCOPY mitbs_upload_class_mapping%ROWTYPE
                      ,p_upl_udf_det      IN OUT NOCOPY uvpkss_udf_upload.ty_upl_cont_udf
                      ,p_ty_mckdetails    IN OUT NOCOPY istb_upload_contractis%ROWTYPE
                      ,p_ty_msgdets       IN OUT NOCOPY cstb_upload_arc_settle%ROWTYPE
                      ,p_tbl_node_rec     IN depks_retailtellerupload.typ_node_tbl
                      ,p_ret              IN OUT NUMBER
		                  ,p_Fn_Call_Id       IN OUT NUMBER
		                  ,p_Tb_Custom_Data   IN OUT NOCOPY Global.Ty_Tb_Custom_Data)
  RETURN BOOLEAN;
--FCUBS_12.0.2_IDTKEKE_17420685 ends

--9NT1525_1202_IUPKRASK_17940525 Starts
	   FUNCTION Fn_Resolve_Ref(p_Ext_Ref    IN OUT Detbs_Rtl_Teller.Xref%TYPE
                          ,p_Fcc_Ref    IN OUT Detbs_Rtl_Teller.Trn_Ref_No%TYPE
						  ,p_Fn_Call_Id    IN OUT NUMBER
                          ,p_tb_custom_data IN OUT NOCOPY global.ty_tb_custom_data
                          ,p_Err_Code   IN OUT VARCHAR2
                          ,p_Err_Params IN OUT VARCHAR2) RETURN BOOLEAN ;
	--9NT1525_1202_IUPKRASK_17940525 Ends
--12.2_RETRO_Bug#23656095 Changes starts here
FUNCTION fn_reverse(p_xref           IN OUT NOCOPY VARCHAR2
                     ,p_fccref         	 IN OUT NOCOPY VARCHAR2
                     ,p_source         	 IN VARCHAR2
                     ,p_override_flag  	 IN OUT NOCOPY VARCHAR2
                     ,p_auto_auth_flag 	 IN OUT NOCOPY VARCHAR2
                     ,p_typ_err        	 IN OUT NOCOPY ovpkss.tbl_error
					 ,p_Fn_Call_Id    	 IN OUT NOCOPY NUMBER
					 ,p_Tb_Custom_Data   IN OUT NOCOPY Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN;
--12.2_RETRO_Bug#23656095 Changes ends here
--Bug#25357568 Changes starts here
FUNCTION Fn_Validate_Rtl_Teller_Rec(p_ty_retailtlr_upd IN OUT NOCOPY detb_upload_rtl_teller%ROWTYPE
                                      ,p_Ret              IN OUT NUMBER
                                      ,p_Fn_Call_Id       IN OUT NUMBER
                                      ,p_tb_custom_data  IN OUT Global.Ty_Tb_Custom_Data) RETURN BOOLEAN;
--Bug#25357568 Changes ends here
	--Bug#25989671  starts
  FUNCTION fn_default_chgdets(p_tbl_chgdets  IN OUT NOCOPY depks_retailtellerupload.typ_tblchgdets,
                              p_detb_rtl_tlr IN detbs_rtl_teller%ROWTYPE,
                              p_ret          IN OUT NUMBER,
							  p_Fn_Call_Id    	 IN OUT NOCOPY NUMBER,
					          p_Tb_Custom_Data   IN OUT NOCOPY Global.Ty_Tb_Custom_Data) RETURN BOOLEAN;
--Bug#25989671  ends
--12.4_RETRO_Bug#26441050 Changes starts here
FUNCTION fn_validate_chg_gl(p_chg_gl             IN sttbs_account.ac_gl_no%TYPE
                              ,p_ret               IN OUT NUMBER
							  ,p_Fn_Call_Id        IN OUT NUMBER
                              ,p_Tb_Custom_Data    IN OUT NOCOPY Global.Ty_Tb_Custom_Data)
  RETURN BOOLEAN;
--12.4_RETRO_Bug#26441050 Changes ends here
--Bug#26474242 starts
 FUNCTION fn_pre_get_ac_row(p_brn          IN VARCHAR2,
                         p_prod         IN VARCHAR2,
                         p_rel_customer IN VARCHAR2,
                         p_cod_ccy      IN VARCHAR2,
                         p_ib_flag      IN VARCHAR2 DEFAULT 'N',
                         p_arc_maint    IN OUT NOCOPY iftms_arc_maint%ROWTYPE,
                         p_err_code     IN OUT VARCHAR2,
                         p_err_param    IN OUT VARCHAR2,
                         p_txn_ac_no    IN VARCHAR2,
                         p_ac_brn       IN VARCHAR2)

   RETURN BOOLEAN;
--Bug#26474242 ends
--12.4_EXTN_Bug#28251023 Changes starts here
FUNCTION fn_arc_settle_pickup(p_route_code IN VARCHAR2,
                                p_cr_account IN OUT VARCHAR2,
                                p_cr_branch  IN OUT VARCHAR2,
                                p_arc_settle IN OUT NOCOPY cstbs_arc_settle%ROWTYPE,
                                p_ret        IN OUT NUMBER,
								p_Fn_Call_Id        IN OUT NUMBER,
                                p_Tb_Custom_Data   IN OUT NOCOPY GLOBAL.Ty_Tb_Custom_Data)
	RETURN BOOLEAN;
--12.4_EXTN_Bug#28251023 Changes ends here

END depks_ret_telr_upld_custom;
