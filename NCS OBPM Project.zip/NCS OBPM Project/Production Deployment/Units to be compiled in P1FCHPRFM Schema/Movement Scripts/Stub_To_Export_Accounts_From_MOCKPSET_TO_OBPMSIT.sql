DECLARE 
L_FAILED_COUNT NUMBER:=0;
BEGIN

  FOR G IN (SELECT * 
              FROM STTM_CUST_ACCOUNT A
             WHERE  A.ACCOUNT_TYPE IN ('U','S') AND A.RECORD_STAT = 'O'
               AND A.ONCE_AUTH = 'Y') LOOP
  BEGIN
    INSERT INTO STTM_CORE_ACCOUNT@OBPM_REMOTE
    VALUES
      (G.CUST_ACCOUNT_NO,
       G.HOST_CODE,
       NULL,
       G.SOURCE_SYSTEM,
       G.SOURCE_SYSTEM_ACC_NO,
       G.SOURCE_SYSTEM_ACC_BRN,
       G.CUSTOMER_NO,
       G.CUST_AC_CCY,
       G.CUST_AC_NAME,
       G.AC_OPEN_DATE,
       G.AC_STAT_NO_CR,
       G.AC_STAT_NO_DR,
       G.GL_STAT_BLOCKED,
       G.AC_STAT_FROZEN,
       G.AC_STAT_DORMANT,
       G.ACCOUNT_CLASS,
       'N',
       G.MAKER_ID,
       G.MAKER_DT_STAMP,
       G.CHECKER_ID,
       G.CHECKER_DT_STAMP,
       G.MOD_NO,
       G.ONCE_AUTH,
       G.RECORD_STAT,
       G.AUTH_STAT,
       G.ADDRESS1,
       G.ADDRESS2,
       G.ADDRESS3,
       G.ADDRESS4,
       'KH',
       G.IS_FORGOTTEN,
       '*.*',
       '*.*');
  
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
	  L_FAILED_COUNT := L_FAILED_COUNT + 1;
      
    END;
  END LOOP;
  
  DBMS_OUTPUT.PUT_LINE('L_FAILED_COUNT ROWS THAT DID NOT GET INSERTED='||L_FAILED_COUNT);

END;