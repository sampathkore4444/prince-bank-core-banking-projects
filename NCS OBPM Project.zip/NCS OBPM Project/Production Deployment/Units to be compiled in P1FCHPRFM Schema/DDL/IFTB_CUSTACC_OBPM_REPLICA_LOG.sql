-- Create table
create table IFTB_CUSTACC_OBPM_REPLICA_LOG
(
  unique_id   VARCHAR2(16),
  cust_ac_no  VARCHAR2(20),
  branch_code VARCHAR2(3),
  operation   VARCHAR2(25),
  record_stat CHAR(1),
  log_time    TIMESTAMP(6),
  status      CHAR(1),
  err_code    VARCHAR2(15),
  error_param VARCHAR2(105)
)
/
alter table IFTB_CUSTACC_OBPM_REPLICA_LOG add primary key (UNIQUE_ID, CUST_AC_NO, BRANCH_CODE)
/