insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-031', 'ENG', 'First Installment Date Can Not Be Null for a loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-020', 'ENG', 'Loan Tenor Must be 6 Months for loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-021', 'ENG', 'Loan Tenor Must be 4 Months for loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-022', 'ENG', 'Loan Disbursment Date Must be same as Loan Booking Date', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-023', 'ENG', 'Collateral Code for AFS Can Not Be Empty for a loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-024', 'ENG', 'No: of schedules Must be 6 Months for a loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-025', 'ENG', 'No: of schedules Must be 4 Months for a loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-026', 'ENG', 'PRINCIPAL Component must have only 1 Bullet Schedule for a loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-027', 'ENG', 'Loan Tenor can not be Amended either more or less than 6 Months for a loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-028', 'ENG', 'Loan Tenor can not be Amended either more or less than 4 Months for a loan product: $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-029', 'ENG', 'Existing Loans of this customer has a different segment $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-030', 'ENG', 'Collateral Code Must be the latest one $1', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

COMMIT;
