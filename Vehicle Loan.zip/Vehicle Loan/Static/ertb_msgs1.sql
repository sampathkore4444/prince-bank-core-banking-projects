update ertb_msgs a set a.type = 'O' where a.err_code = 'GEDCOLLT114' and a.language = 'ENG'
/
commit
/