DELETE FROM swtm_issuer_details_ata A WHERE A.ISS_BIN = '462823';

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282331', 'Debit Card Visa Platinum', null, null, null, null, null, null, null, null, 'PRINCE');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282341', 'Debit Card Visa Platinum', null, null, null, null, null, null, null, null, 'PRINCE');

COMMIT;
