CREATE OR REPLACE PACKAGE BODY gwpks_createswtransaction AS

  G_SOURCE       VARCHAR2(15);
  G_CL_OLL_ACC   CLTBS_ACCOUNT_MASTER.OPEN_LINE_LOAN%TYPE := 'N';
  G_FN_CALL_ID   NUMBER;
  G_DB_IN_TIME   VARCHAR2(30) := '';
  G_VIR_ACC_FLAG VARCHAR2(1) := 'N';

  G_ACC_AMT            NUMBER;
  PKG_CARD_DETAILS_REC SWTMS_CARD_DETAILS%ROWTYPE;
  PKG_CARD_LIMITS_REC  SWTMS_CARD_LIMITS%ROWTYPE;

  --sampath changes for master card starts
  FUNCTION FN_GET_TERMINAL_GL(P_TERM_ID IN SWTM_TERMINAL_DETAILS.TERM_ID%TYPE)
    RETURN SWTM_TERMINAL_DETAILS.ORG_BRN%TYPE AS
    L_CASH_GL SWTM_TERMINAL_DETAILS.CASH_GL%TYPE;
  BEGIN
    BEGIN
      SELECT CASH_GL
        INTO L_CASH_GL
        FROM SWTM_TERMINAL_DETAILS
       WHERE TERM_ID = P_TERM_ID
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      RETURN L_CASH_GL;
    EXCEPTION
      WHEN OTHERS THEN
        --L_BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
        RETURN L_CASH_GL;
    END;
    RETURN L_CASH_GL;
  END FN_GET_TERMINAL_GL;

  --sampath starts for css
  FUNCTION FN_GET_IBFT_DR_CR_GL(P_PARAM_NAME IN CSTB_PARAM_CUSTOM.PARAM_NAME%TYPE)
    RETURN CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE AS
    L_PARAM_VAL CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE;
  BEGIN
    SELECT PARAM_VAL
      INTO L_PARAM_VAL
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = P_PARAM_NAME;
    RETURN L_PARAM_VAL;
  EXCEPTION
    WHEN OTHERS THEN
      L_PARAM_VAL := NULL;
      RETURN L_PARAM_VAL;
  END FN_GET_IBFT_DR_CR_GL;
  --sampath ends for css

  FUNCTION FN_GET_ISO_CURRENCY_CODE(P_ISO_CCY IN VARCHAR2)
    RETURN CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE AS
    L_CCY_CODE CYTMS_CCY_DEFN_MASTER.CCY_CODE%TYPE;
  BEGIN
    BEGIN
      SELECT CCY_CODE
        INTO L_CCY_CODE
        FROM CYTMS_CCY_DEFN_MASTER
       WHERE ISO_NUM_CCY_CODE = P_ISO_CCY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      RETURN L_CCY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN L_CCY_CODE;
    END;
    RETURN L_CCY_CODE;
  END FN_GET_ISO_CURRENCY_CODE;

  FUNCTION FN_GET_CREDIT_CARD_GL(P_PARAM_NAME IN CSTB_PARAM_CUSTOM.PARAM_NAME%TYPE)
    RETURN CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE AS
    L_PARAM_VAL CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE;
  BEGIN
    SELECT PARAM_VAL
      INTO L_PARAM_VAL
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = P_PARAM_NAME;
    RETURN L_PARAM_VAL;
  EXCEPTION
    WHEN OTHERS THEN
      L_PARAM_VAL := NULL;
      RETURN L_PARAM_VAL;
  END FN_GET_CREDIT_CARD_GL;

  FUNCTION FN_GET_CREDIT_CARD_GL_BRANCH(P_PARAM_NAME IN CSTB_PARAM_CUSTOM.PARAM_NAME%TYPE)
    RETURN CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE AS
    L_PARAM_VAL CSTB_PARAM_CUSTOM.PARAM_VAL%TYPE;
  BEGIN
    SELECT PARAM_VAL
      INTO L_PARAM_VAL
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = P_PARAM_NAME;
    RETURN L_PARAM_VAL;
  EXCEPTION
    WHEN OTHERS THEN
      L_PARAM_VAL := NULL;
      RETURN L_PARAM_VAL;
  END FN_GET_CREDIT_CARD_GL_BRANCH;
  --sampath changes for master card ends
  FUNCTION FN_BUILD_ATM_NOTIF_XML(P_TY_ATM_NOTIF_REC IN OUT NOCOPY TY_ATM_NOTIF_REC,
                                  P_PARENTS_LIST     IN OUT VARCHAR2,
                                  P_PARENTS_FORMAT   IN OUT VARCHAR2,
                                  P_TS_TAG_NAMES     IN OUT VARCHAR2,
                                  P_TS_TAG_VALUES    IN OUT VARCHAR2,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_GET_ATM_NOTIF_DATA(P_XREF             IN OUT VARCHAR2,
                                 P_TY_ATM_NOTIF_REC IN OUT NOCOPY TY_ATM_NOTIF_REC,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHECK_CHANNEL_LIMITS(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                                   P_ERR_CODE       IN OUT VARCHAR2,
                                   P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_UPDATE_LIMITS(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN;

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN

    DEBUG.PR_DEBUG('SW',
                   '[DEBUG]' || 'gwpks_createswtransaction :' || P_DBG);

  END DBG;

  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN

    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('SW',
                     '[ERROR] ' || 'gwpks_createswtransaction :' || P_DBG);
    ELSE
      DEBUG.PR_DEBUG('SW',
                     '[DEBUG] ' || 'gwpks_createswtransaction :' || P_DBG);
    END IF;

  END DBG;

  PROCEDURE PR_LOG_ERROR(P_SOURCE      COTMS_SOURCE.SOURCE_CODE%TYPE,
                         P_FUNCTION_ID IN SMTBS_MENU.FUNCTION_ID%TYPE,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS

  BEGIN
    STPKS_FCMAINT_UTILS.PR_LOG_ERROR(P_SOURCE,
                                     P_FUNCTION_ID,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS);
  END PR_LOG_ERROR;

  FUNCTION FN_TXN_CONTOL_LOG(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                             P_ERR_CODE       IN OUT VARCHAR2,
                             P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS

    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('fn_txn_contol_log : Coming inside fn_txn_contol_logd_derive ');

    DBG('fn_txn_contol_log : Deriving PKEY ');
    IF NOT
        SWPKSS_UTILS.FN_GET_PKEY(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
      DBG('E', ' swpks_utils.fn_get_pkey returned false ');
      P_ERR_CODE  := 'SW-KEY-01';
      P_ERR_PARAM := NULL;
      RETURN FALSE;
    END IF;

    DBG('p_ty_atm_txn_rec.resp_code...before .' ||
        P_TY_ATM_TXN_REC.RESP_CODE);
    IF NOT (NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_REQ, 'N') = 'Y' AND
        SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '8') THEN

      INSERT INTO SWTBS_TXN_LOG
        (P_KEY,
         MSG_TYPE,
         PAN,
         PROC_CODE,
         TXN_AMT,
         SETL_AMT,
         BILL_AMT,
         TRANS_DT_TIME,
         STAN,
         ACQ_INS_ID,
         FWD_INS_ID,
         RRN,
         RESP_CODE,
         TERM_ID,
         TXN_CCY_CODE,
         SETL_CCY_CODE,
         BILL_CCY_CODE,
         FROM_ACC,
         TO_ACC,
         TXN_DESC,
         EXP_DATE,
         SETL_DATE,
         CONV_DATE,
         CAPT_DATE,
         PRE_AUTH_SEQ_NO,
         WORK_PROGRESS,
         XREF

        ,
         ADD_AMT,
         MINI_STMT_DATA

        ,
         OFFUS_ONUS,
         FILE_PROCESS,
         DB_IN_TIME,
         TERM_ADDR)
      VALUES
        (P_TY_ATM_TXN_REC.P_KEY,
         P_TY_ATM_TXN_REC.MSG_TYPE,
         P_TY_ATM_TXN_REC.PAN,
         P_TY_ATM_TXN_REC.PROC_CODE,
         P_TY_ATM_TXN_REC.TXN_AMT,
         P_TY_ATM_TXN_REC.SETL_AMT,
         P_TY_ATM_TXN_REC.BILL_AMT,
         P_TY_ATM_TXN_REC.TRANS_DT_TIME,
         P_TY_ATM_TXN_REC.STAN,
         P_TY_ATM_TXN_REC.ACQ_INS_ID,
         P_TY_ATM_TXN_REC.FWD_INS_ID,
         P_TY_ATM_TXN_REC.RRN,
         P_TY_ATM_TXN_REC.RESP_CODE,
         P_TY_ATM_TXN_REC.TERM_ID,
         P_TY_ATM_TXN_REC.TXN_CCY_CODE,
         P_TY_ATM_TXN_REC.SETL_CCY_CODE,
         P_TY_ATM_TXN_REC.BILL_CCY_CODE,
         P_TY_ATM_TXN_REC.FROM_ACC,
         P_TY_ATM_TXN_REC.TO_ACC,
         P_TY_ATM_TXN_REC.TXN_DESC,
         P_TY_ATM_TXN_REC.EXP_DATE,
         P_TY_ATM_TXN_REC.SETL_DATE,
         P_TY_ATM_TXN_REC.CONV_DATE,
         P_TY_ATM_TXN_REC.CAPT_DATE,
         P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO,
         'W',
         P_TY_ATM_TXN_REC.XREF

        ,
         P_TY_ATM_TXN_REC.ADD_AMT,
         P_TY_ATM_TXN_REC.MINI_STMT_DATA

        ,
         P_TY_ATM_TXN_REC.OFFUS_ONUS,
         P_TY_ATM_TXN_REC.FILE_PROCESS,
         G_DB_IN_TIME,
         P_TY_ATM_TXN_REC.ACCEPT_ADDR);
      COMMIT;
    END IF;
    DBG('p_ty_atm_txn_rec.resp_code...after .' ||
        P_TY_ATM_TXN_REC.RESP_CODE);
    DBG('Returning true from fn_txn_contol_log');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('E', 'In fn_txn_contol_log ' || SQLERRM);
      P_ERR_CODE  := 'SW-LOG-01';
      P_ERR_PARAM := P_TY_ATM_TXN_REC.P_KEY;
      RETURN FALSE;

  END FN_TXN_CONTOL_LOG;

  FUNCTION FN_MANDATORY_VALIDATE(P_TY_ATM_TXN_REC IN TY_ATM_TXN_REC,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
    L_ACQ_CTRY_DERIVED VARCHAR2(3);
  BEGIN

    DBG('fn_mandatory_validate : Coming inside fn_mandatory_validate ');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_MANDATORY_VALIDATE(P_TY_ATM_TXN_REC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.fn_mandatory_validate returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF P_TY_ATM_TXN_REC.MSG_TYPE IS NULL THEN

        DBG('E', 'Mandatory field is NULL : FIELD1 - msg_type ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD1 - Msg_Type';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.PAN IS NULL THEN

        IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) <> '8' THEN
          IF NOT NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_ACC_FROM_SWITCH,
                     'N') = 'Y' THEN
            DBG('E', 'Mandatory field is NULL : FIELD2 - pan ');
            P_ERR_CODE  := 'SW-MND-01';
            P_ERR_PARAM := 'FIELD2 - PAN';
            RETURN FALSE;
          END IF;
        END IF;

      ELSIF P_TY_ATM_TXN_REC.PROC_CODE IS NULL THEN

        DBG('E', 'Mandatory field is NULL : FIELD3 - Proc_Code');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD3 - Proc_Code';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL AND
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION NOT IN ('1', '2')

       THEN

        DBG('E', 'Mandatory field is NULL : FIELD7 - Trans_Dt_Time ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD7 - Trans_Dt_Time';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION IN ('1', '2') AND
            P_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL AND
            P_TY_ATM_TXN_REC.LOCAL_TXN_TIME IS NULL THEN

        DBG('E', 'Mandatory field is NULL : FIELD12 - LOCAL_TXN_TIME ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD12 - LOCAL_TXN_TIME';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.STAN IS NULL THEN

        DBG('E', 'Mandatory field is NULL : FIELD11 - stan ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD11 - stan';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.ACQ_INS_ID IS NULL THEN

        DBG('E', 'Mandatory field is NULL : FIELD32 - Acq_Ins_Id ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD32 - Acq_Ins_Id ';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.RRN IS NULL THEN

        DBG('E', 'Mandatory field is NULL : FIELD37 - rrn ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD37 - rrn ';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.TERM_ID IS NULL AND --sampath added 2 AND conditions as we should not validate Terminal ID for off us transaction for master and Visa
            (P_TY_ATM_TXN_REC.RSV_60 NOT IN ('MAS', 'VIS') AND
            P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'R') THEN

        DBG('E', 'Mandatory field is NULL : FIELD41 - term_id ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD41 - term_id ';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.FROM_ACC IS NULL AND
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH = 'N' AND

            SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN
            ('21', '20', '22') AND P_TY_ATM_TXN_REC.offus_onus <> 'F' THEN
        --sampath added P_TY_ATM_TXN_REC.offus_onus <> 'F' condition

        DBG('E', 'Mandatory field is NULL : FIELD102 - from_acc ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD102 - from_acc ';
        RETURN FALSE;

      ELSIF P_TY_ATM_TXN_REC.TO_ACC IS NULL AND
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH = 'N' THEN

        IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('21', '22') OR
           (NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.POS_VOID, 'N') = 'N' AND
            SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '20') THEN

          DBG('E', 'Mandatory field is NULL : FIELD103 - to_acc ');
          P_ERR_CODE  := 'SW-MND-01';
          P_ERR_PARAM := 'FIELD102 - to_acc ';
          RETURN FALSE;
        END IF;

      END IF;

      IF P_TY_ATM_TXN_REC.ACQ_INST_CTRY IS NOT NULL AND
         NOT FN_CNTY_TRANS(P_TY_ATM_TXN_REC.ACQ_INST_CTRY,
                           L_ACQ_CTRY_DERIVED,
                           P_ERR_CODE,
                           P_ERR_PARAM) THEN
        DBG('E',
            'fn_mandatory_validate : No proper translation avl for country ' ||
            P_TY_ATM_TXN_REC.ACQ_INST_CTRY || '~' || L_ACQ_CTRY_DERIVED);
        P_ERR_PARAM := 'fn_mandatory_validate' || '~' || P_ERR_CODE;
        RETURN FALSE;
      END IF;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    DBG('Returning true from fn_mandatory_validate');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('E', 'In fn_mandatory_validate ' || SQLERRM);
      P_ERR_CODE  := 'SW-MAN-01';
      P_ERR_PARAM := P_TY_ATM_TXN_REC.P_KEY;
      RETURN FALSE;

  END FN_MANDATORY_VALIDATE;

  FUNCTION FN_TXN_CONTOL(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                         P_ERR_CODE       IN OUT VARCHAR2,
                         P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS

    L_MSG_TYPE_TEMP VARCHAR2(16) DEFAULT NULL;
    L_KEY_TEMP      VARCHAR2(255) DEFAULT NULL;

    ROW_COUNT  NUMBER DEFAULT 0;
    L_TXN_TYPE VARCHAR2(1) DEFAULT NULL;
    L_STATUS   VARCHAR2(1) DEFAULT NULL;

    L_ORG_MSG  VARCHAR2(4) DEFAULT NULL;
    L_ORG_STAN VARCHAR2(6) DEFAULT NULL;
    L_ORG_TRNS VARCHAR2(10) DEFAULT NULL;
    L_MSG_LEN  NUMBER DEFAULT 0;
    L_STAN_LEN NUMBER DEFAULT 0;
    L_TRNS_LEN NUMBER DEFAULT 0;
    L_RRN      VARCHAR2(12 CHAR);

    CURSOR CUR_ORG_DATA IS
      SELECT NVL(TRN_REF_NO, 0) TRN_REF_NO,
             NVL(AMOUNT_BLOCK_NO, 0) AMOUNT_BLOCK_NO,
             RESP_CODE,
             TXN_AMT,
             XREF,
             DCN,
             RRN,
             ERROR_CODE
        FROM SWTBS_TXN_LOG

       WHERE MSG_TYPE = L_ORG_MSG
         AND STAN = L_ORG_STAN;
         --AND TRANS_DT_TIME = L_ORG_TRNS;--uncomment sampath added +2 for timestamp issue for reversal issue in US ON THEM case

    L_FN_CALL_ID NUMBER;

    TYPE TYP_TBL_SWTBSTXNLOG IS TABLE OF CUR_ORG_DATA%ROWTYPE INDEX BY PLS_INTEGER;
    TB_SWTBS_TXN_LOG TYP_TBL_SWTBSTXNLOG;

    --sampath starts
    L_TRAN_TYPE SWTM_FCLITERAL_CODE.FC_LITERAL%TYPE;
    --sampath ends
  BEGIN

    DBG('fn_txn_contol : Coming inside fn_txn_contol ');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_TXN_CONTROL(P_TY_ATM_TXN_REC,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM) THEN
        DBG('E', 'gwpks_ext_switchservice.fn_txn_control returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      BEGIN
        SELECT COUNT(1)
          INTO ROW_COUNT
          FROM SWTBS_TXN_LOG
         WHERE P_KEY = P_TY_ATM_TXN_REC.P_KEY;

        DBG('fn_txn_contol : Check for duplicate msg ... ROW COUNT = ' ||
            ROW_COUNT);
        DBG('fn_txn_contol : p_ty_atm_txn_rec.msg_type.... ' ||
            P_TY_ATM_TXN_REC.MSG_TYPE);

        IF ROW_COUNT > 1 AND
           (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) <> '8') THEN

          --sampath added to get the cash back literal to skip the RRN dup validation starts
          BEGIN
            SELECT FC_LITERAL
              INTO L_TRAN_TYPE
              FROM SWTM_FCLITERAL_CODE
             WHERE PROC_CODE_TYPE =
                   SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2);

          EXCEPTION
            WHEN NO_DATA_FOUND THEN

              L_TRAN_TYPE := NULL;
          END;
          --sampath added to get the cash back literal to skip the RRN dup validation ends

          IF L_TRAN_TYPE NOT IN ('CAB') THEN
            --sampath added if condition to skip for refund/cashback
          IF (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 4, 1) <> '1') THEN
            P_ERR_CODE := 'SW-DUP-02';
            PR_LOG_ERROR('', '', 'SW-DUP-02', P_TY_ATM_TXN_REC.P_KEY);

            RETURN FALSE;
          END IF;
         END IF; --sampath added end if condition to skip for refund/cashback

        END IF;

      END;

      IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 3) IN
         ('804', '814', '824', '825', '844') THEN

        DBG('fn_txn_contol :Sign On Message ');
        P_ERR_CODE := 'SW-ADM-02';
        RETURN FALSE;

      ELSIF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '8' THEN

        DBG('fn_txn_contol :This is Admin Echo Message ');
        P_ERR_CODE := 'SW-ADM-01';
        RETURN FALSE;

      ELSIF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '4' THEN

        DBG('fn_txn_contol :Checking For Repeat  ');
        IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 4, 1) = '1' THEN
          L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 3) || '0');

          DBG('fn_txn_contol : Deriving PKEY ');

          IF NOT SWPKS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                               P_TY_ATM_TXN_REC.P_KEY,
                                               L_MSG_TYPE_TEMP,
                                               P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                               L_KEY_TEMP) THEN
            DBG('E',
                'fn_txn_contol: swpks_utils.fn_get_parent_key returned false ');
            P_ERR_CODE  := 'SW-KEY-02';
            P_ERR_PARAM := NULL;
            RETURN FALSE;
          END IF;
          BEGIN
            SELECT RESP_CODE, XREF, DCN, ERROR_CODE
              INTO P_TY_ATM_TXN_REC.RESP_CODE,
                   P_TY_ATM_TXN_REC.OLD_XREF,
                   P_TY_ATM_TXN_REC.DCN,
                   P_ERR_CODE
              FROM SWTBS_TXN_LOG
             WHERE P_KEY = L_KEY_TEMP
               AND ROWNUM = 1
             ORDER BY XREF ASC;

            IF TO_NUMBER(P_TY_ATM_TXN_REC.RESP_CODE) = 0 THEN
              P_ERR_CODE := 'SW-DUP-03';
              RETURN FALSE;
            END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN

              P_TY_ATM_TXN_REC.MSG_TYPE := L_MSG_TYPE_TEMP;
              P_TY_ATM_TXN_REC.P_KEY    := L_KEY_TEMP;

          END;
        END IF;

        IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 4, 1) = '0' THEN

          DBG('fn_txn_contol :It is not a repeat reversal ');
          DBG('fn_txn_contol :org_data~' || P_TY_ATM_TXN_REC.ORG_DATA);
          IF P_TY_ATM_TXN_REC.ORG_DATA IS NULL THEN
            L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 1) || '2' ||
                               SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 3, 2));
            DBG('fn_txn_contol : Deriving PKEY ');

            IF NOT SWPKS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                                 P_TY_ATM_TXN_REC.P_KEY,
                                                 L_MSG_TYPE_TEMP,
                                                 P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                                 L_KEY_TEMP) THEN
              DBG('E',
                  'fn_txn_contol : swpks_utils.fn_get_parent_key returned false ');
              P_ERR_CODE  := 'SW-KEY-03';
              P_ERR_PARAM := NULL;
              RETURN FALSE;
            END IF;
            BEGIN

              SELECT NVL(TRN_REF_NO, 0),
                     NVL(AMOUNT_BLOCK_NO, 0),
                     RESP_CODE,
                     TXN_AMT,
                     XREF,
                     DCN,
                     ERROR_CODE
                INTO P_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
                     P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO,
                     P_TY_ATM_TXN_REC.RESP_CODE,
                     P_TY_ATM_TXN_REC.ORIG_TXN_AMT,
                     P_TY_ATM_TXN_REC.OLD_XREF,
                     P_TY_ATM_TXN_REC.DCN,
                     P_ERR_CODE
                FROM SWTBS_TXN_LOG
               WHERE P_KEY = L_KEY_TEMP
                 AND ROWNUM = 1
               ORDER BY XREF ASC;

              DBG('fn_txn_control p_ty_atm_txn_rec.old_xref ::' ||
                  P_TY_ATM_TXN_REC.OLD_XREF);

              IF TO_NUMBER(P_TY_ATM_TXN_REC.RESP_CODE) <> 0 THEN
                IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 2) = '42' THEN
                  P_ERR_CODE := 'SW-PRT-01';

                ELSE
                  P_ERR_CODE := 'SW-PRT-06';
                END IF;

                P_ERR_PARAM := L_KEY_TEMP;
                RETURN FALSE;
              END IF;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN

                BEGIN

                  L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE,
                                             1,
                                             1) || '20' ||
                                     SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE,
                                             4,
                                             1));
                  DBG('fn_txn_contol_log 2: Deriving PKEY ');

                  IF NOT SWPKSS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                                        P_TY_ATM_TXN_REC.P_KEY,
                                                        L_MSG_TYPE_TEMP,
                                                        P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                                        L_KEY_TEMP) THEN
                    DBG('e',
                        ' swpks_utils.fn_get_parent_key returned false ');
                    P_ERR_CODE  := 'sw-key-02';
                    P_ERR_PARAM := 'fn_txn_contol' || '~' || P_ERR_CODE;
                    RETURN FALSE;
                  END IF;

                  SELECT NVL(TRN_REF_NO, 0),
                         NVL(AMOUNT_BLOCK_NO, 0),
                         RESP_CODE,
                         TXN_AMT,
                         XREF,
                         DCN,
                         ERROR_CODE
                    INTO P_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
                         P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO,
                         P_TY_ATM_TXN_REC.RESP_CODE,
                         P_TY_ATM_TXN_REC.ORIG_TXN_AMT,
                         P_TY_ATM_TXN_REC.OLD_XREF,
                         P_TY_ATM_TXN_REC.DCN,
                         P_ERR_CODE
                    FROM SWTBS_TXN_LOG
                   WHERE P_KEY = L_KEY_TEMP
                     AND ROWNUM = 1
                   ORDER BY XREF ASC;

                  DBG('fn_txn_control p_ty_atm_txn_rec.old_xref ::' ||
                      P_TY_ATM_TXN_REC.OLD_XREF);

                  IF TO_NUMBER(P_TY_ATM_TXN_REC.RESP_CODE) <> 0 THEN
                    P_ERR_CODE  := 'SW-PRT-01';
                    P_ERR_PARAM := L_KEY_TEMP;
                    RETURN FALSE;
                  END IF;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN

                    L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE,
                                               1,
                                               1) || '1' ||
                                       SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE,
                                               3,
                                               2));
                    DBG('fn_txn_contol_log : Deriving PKEY ');

                    IF NOT SWPKSS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                                          P_TY_ATM_TXN_REC.P_KEY,
                                                          L_MSG_TYPE_TEMP,
                                                          P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                                          L_KEY_TEMP) THEN
                      DBG('E',
                          ' swpks_utils.fn_get_parent_key returned false ');
                      P_ERR_CODE  := 'SW-KEY-02';
                      P_ERR_PARAM := 'fn_txn_contol' || '~' || P_ERR_CODE;
                      RETURN FALSE;
                    END IF;
                    BEGIN

                      SELECT NVL(TRN_REF_NO, 0),
                             NVL(AMOUNT_BLOCK_NO, 0),
                             RESP_CODE,
                             TXN_AMT,
                             XREF,
                             DCN,
                             ERROR_CODE
                        INTO P_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
                             P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO,
                             P_TY_ATM_TXN_REC.RESP_CODE,
                             P_TY_ATM_TXN_REC.ORIG_TXN_AMT,
                             P_TY_ATM_TXN_REC.OLD_XREF,
                             P_TY_ATM_TXN_REC.DCN,
                             P_ERR_CODE
                        FROM SWTBS_TXN_LOG
                       WHERE P_KEY = L_KEY_TEMP
                         AND ROWNUM = 1
                       ORDER BY XREF ASC;

                      IF TO_NUMBER(P_TY_ATM_TXN_REC.RESP_CODE) <> 0 THEN
                        P_ERR_CODE  := 'SW-PRT-02';
                        P_ERR_PARAM := L_KEY_TEMP;
                        RETURN FALSE;
                      END IF;

                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN

                        DBG('p_ty_atm_txn_rec.msg_type =>' ||
                            P_TY_ATM_TXN_REC.MSG_TYPE);
                        L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE,
                                                   1,
                                                   1) || '10' ||
                                           SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE,
                                                   4,
                                                   1));
                        DBG('fn_txn_contol_log : deriving pkey3 ');
                        DBG('p_ty_atm_txn_rec.p_key => ' ||
                            P_TY_ATM_TXN_REC.P_KEY);
                        DBG('l_msg_type_temp =>' || L_MSG_TYPE_TEMP);
                        IF NOT SWPKSS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                                              P_TY_ATM_TXN_REC.P_KEY,
                                                              L_MSG_TYPE_TEMP,
                                                              P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                                              L_KEY_TEMP) THEN
                          DBG('e',
                              ' swpks_utils.fn_get_parent_key returned false ');
                          P_ERR_CODE  := 'sw-key-02';
                          P_ERR_PARAM := 'fn_txn_contol' || '~' ||
                                         P_ERR_CODE;
                          RETURN FALSE;
                        END IF;
                        DBG('swpks_utils.fn_get_parent_key returned true');
                        DBG('l_key_temp =>' || L_KEY_TEMP);
                        BEGIN
                          SELECT NVL(TRN_REF_NO, 0),
                                 NVL(AMOUNT_BLOCK_NO, 0),
                                 RESP_CODE,
                                 TXN_AMT,
                                 XREF,
                                 DCN,
                                 ERROR_CODE
                            INTO P_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
                                 P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO,
                                 P_TY_ATM_TXN_REC.RESP_CODE,
                                 P_TY_ATM_TXN_REC.ORIG_TXN_AMT,
                                 P_TY_ATM_TXN_REC.OLD_XREF,
                                 P_TY_ATM_TXN_REC.DCN,
                                 P_ERR_CODE
                            FROM SWTBS_TXN_LOG
                           WHERE P_KEY = L_KEY_TEMP
                             AND ROWNUM = 1
                           ORDER BY XREF ASC;
                          DBG('p_ty_atm_txn_rec.trn_ref_no_fcc =>' ||
                              P_TY_ATM_TXN_REC.TRN_REF_NO_FCC);
                          DBG('p_ty_atm_txn_rec.amount_block_no =>' ||
                              P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO);
                          DBG('p_ty_atm_txn_rec.resp_code =>' ||
                              P_TY_ATM_TXN_REC.RESP_CODE);
                          DBG('p_ty_atm_txn_rec.orig_txn_amt =>' ||
                              P_TY_ATM_TXN_REC.ORIG_TXN_AMT);
                          DBG('p_ty_atm_txn_rec.old_xref  =>' ||
                              P_TY_ATM_TXN_REC.OLD_XREF);
                          DBG('p_ty_atm_txn_rec.dcn  =>' ||
                              P_TY_ATM_TXN_REC.DCN);
                          DBG('p_err_code  =>' || P_ERR_CODE);

                          IF TO_NUMBER(P_TY_ATM_TXN_REC.RESP_CODE) <> 0 THEN
                            DBG('to_number(p_ty_atm_txn_rec.resp_code) <> 0');
                            P_ERR_CODE  := 'SW-PRT-02';
                            P_ERR_PARAM := L_KEY_TEMP;
                            RETURN FALSE;
                          END IF;

                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN

                            IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 3, 1) = '2' THEN
                              P_ERR_CODE  := 'SW-PRT-03';
                              P_ERR_PARAM := L_KEY_TEMP;
                              RETURN FALSE;

                            ELSE
                              P_ERR_CODE  := 'SW-PRT-05';
                              P_ERR_PARAM := L_KEY_TEMP;
                              RETURN FALSE;
                            END IF;

                        END;
                    END;
                END;

            END;

          ELSE
            IF CUR_ORG_DATA%ISOPEN THEN
              CLOSE CUR_ORG_DATA;
            END IF;

            DBG('LENGTH(P_TY_ATM_TXN_REC.MSG_TYPE)=' ||
                LENGTH(P_TY_ATM_TXN_REC.MSG_TYPE));
            L_MSG_LEN := LENGTH(P_TY_ATM_TXN_REC.MSG_TYPE);
            DBG('L_MSG_LEN=' || L_MSG_LEN);
            L_ORG_MSG := SUBSTR(P_TY_ATM_TXN_REC.ORG_DATA, 1, L_MSG_LEN);

            DBG('L_ORG_MSG=' || L_ORG_MSG);
            L_STAN_LEN := LENGTH(P_TY_ATM_TXN_REC.STAN);
            DBG('L_STAN_LEN=' || L_STAN_LEN);
            L_ORG_STAN := SUBSTR(P_TY_ATM_TXN_REC.ORG_DATA,
                                 L_MSG_LEN + 1,
                                 L_STAN_LEN);
            DBG('L_ORG_STAN=' || L_ORG_STAN);
            L_TRNS_LEN := LENGTH(P_TY_ATM_TXN_REC.TRANS_DT_TIME);

            DBG('L_TRNS_LEN=' || L_TRNS_LEN);
            IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '0' THEN
              L_TRNS_LEN := LENGTH(P_TY_ATM_TXN_REC.TRANS_DT_TIME);
            ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
              L_TRNS_LEN := NVL(LENGTH(P_TY_ATM_TXN_REC.TRANS_DT_TIME),
                                LENGTH(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME) - 2);
            ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
              L_TRNS_LEN := NVL(LENGTH(P_TY_ATM_TXN_REC.TRANS_DT_TIME),
                                LENGTH(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME) - 4);
            END IF;

            DBG('L_TRNS_LEN=' || L_TRNS_LEN);

            DBG('P_TY_ATM_TXN_REC.ORG_DATA=' || P_TY_ATM_TXN_REC.ORG_DATA);
            L_ORG_TRNS := SUBSTR(P_TY_ATM_TXN_REC.ORG_DATA,
                                 L_STAN_LEN + L_MSG_LEN + 1 + 2, -- L_STAN_LEN + L_MSG_LEN + 1 + 2, --sampath added +2 for timestamp issue for reversal issue in US ON THEM case
                                 L_TRNS_LEN);

            DBG('L_ORG_TRNS=' || L_ORG_TRNS);
            OPEN CUR_ORG_DATA;

            FETCH CUR_ORG_DATA BULK COLLECT
              INTO TB_SWTBS_TXN_LOG;
            IF CUR_ORG_DATA%ROWCOUNT > 1 THEN
              DBG('cur_org_data rowcount is > 1 ');
              FOR L_INDX IN TB_SWTBS_TXN_LOG.FIRST .. TB_SWTBS_TXN_LOG.LAST LOOP
                L_RRN := TB_SWTBS_TXN_LOG(L_INDX).RRN;
                IF L_RRN = P_TY_ATM_TXN_REC.RRN THEN
                  P_TY_ATM_TXN_REC.TRN_REF_NO_FCC  := TB_SWTBS_TXN_LOG(L_INDX)
                                                      .TRN_REF_NO;
                  P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO := TB_SWTBS_TXN_LOG(L_INDX)
                                                      .AMOUNT_BLOCK_NO;
                  P_TY_ATM_TXN_REC.RESP_CODE       := TB_SWTBS_TXN_LOG(L_INDX)
                                                      .RESP_CODE;
                  P_TY_ATM_TXN_REC.ORIG_TXN_AMT    := TB_SWTBS_TXN_LOG(L_INDX)
                                                      .TXN_AMT;
                  P_TY_ATM_TXN_REC.OLD_XREF        := TB_SWTBS_TXN_LOG(L_INDX).XREF;
                  P_TY_ATM_TXN_REC.DCN             := TB_SWTBS_TXN_LOG(L_INDX) . DCN;
                  P_ERR_CODE                       := TB_SWTBS_TXN_LOG(L_INDX)
                                                      .ERROR_CODE;
                  P_TY_ATM_TXN_REC.RRN             := TB_SWTBS_TXN_LOG(L_INDX).RRN;
                END IF;
              END LOOP;
            ELSIF CUR_ORG_DATA%ROWCOUNT = 1 THEN
              DBG('cur_org_data rowcount is 1');

              P_TY_ATM_TXN_REC.TRN_REF_NO_FCC  := TB_SWTBS_TXN_LOG(TB_SWTBS_TXN_LOG.FIRST)
                                                  .TRN_REF_NO;
              P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO := TB_SWTBS_TXN_LOG(TB_SWTBS_TXN_LOG.FIRST)
                                                  .AMOUNT_BLOCK_NO;
              P_TY_ATM_TXN_REC.RESP_CODE       := TB_SWTBS_TXN_LOG(TB_SWTBS_TXN_LOG.FIRST)
                                                  .RESP_CODE;
              P_TY_ATM_TXN_REC.ORIG_TXN_AMT    := TB_SWTBS_TXN_LOG(TB_SWTBS_TXN_LOG.FIRST)
                                                  .TXN_AMT;
              P_TY_ATM_TXN_REC.OLD_XREF        := TB_SWTBS_TXN_LOG(TB_SWTBS_TXN_LOG.FIRST).XREF;
              P_TY_ATM_TXN_REC.DCN             := TB_SWTBS_TXN_LOG(TB_SWTBS_TXN_LOG.FIRST).DCN;
              P_TY_ATM_TXN_REC.RRN             := TB_SWTBS_TXN_LOG(TB_SWTBS_TXN_LOG.FIRST).RRN;
              P_ERR_CODE                       := TB_SWTBS_TXN_LOG(TB_SWTBS_TXN_LOG.FIRST)
                                                  .ERROR_CODE;
              DBG('fn_txn_control : p_ty_atm_txn_rec.trn_ref_no_fcc~' ||
                  P_TY_ATM_TXN_REC.TRN_REF_NO_FCC);
              DBG('fn_txn_control : p_ty_atm_txn_rec.amount_block_no~' ||
                  P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO);
              DBG('fn_txn_control : p_ty_atm_txn_rec.resp_code~' ||
                  P_TY_ATM_TXN_REC.RESP_CODE);
              DBG('fn_txn_control : p_ty_atm_txn_rec.orig_txn_amt~' ||
                  P_TY_ATM_TXN_REC.ORIG_TXN_AMT);
              DBG('fn_txn_control : p_ty_atm_txn_rec.old_xref~' ||
                  P_TY_ATM_TXN_REC.OLD_XREF);
              DBG('fn_txn_control : p_ty_atm_txn_rec.dcn~' ||
                  P_TY_ATM_TXN_REC.DCN);
              DBG('fn_txn_control : p_ty_atm_txn_rec.rrn~' ||
                  P_TY_ATM_TXN_REC.RRN);
              DBG('fn_txn_control : p_err_code~' || P_ERR_CODE);

            ELSIF CUR_ORG_DATA%ROWCOUNT = 0

             THEN
              DBG('fn_txn_control : org data rowcount is 0');
              P_ERR_CODE  := 'SW-PRT-03';
              P_ERR_PARAM := L_KEY_TEMP;
              CLOSE CUR_ORG_DATA;
              RETURN FALSE;

            END IF;
            CLOSE CUR_ORG_DATA;
          END IF;

        END IF;

      ELSIF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) IN ('1', '2') THEN
        IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 4, 1) = '1' THEN
          L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 3) || '0');
          DBG('fn_txn_contol : Deriving PKEY ');

          IF NOT SWPKSS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                                P_TY_ATM_TXN_REC.P_KEY,
                                                L_MSG_TYPE_TEMP,
                                                P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                                L_KEY_TEMP) THEN
            DBG('E',
                'fn_txn_contoleswitch : swpks_utils.fn_get_parent_key returned false ');
            P_ERR_CODE  := 'SW-KEY-03';
            P_ERR_PARAM := NULL;
            RETURN FALSE;
          END IF;

          BEGIN
            SELECT RESP_CODE

                  ,
                   ADD_AMT,
                   MINI_STMT_DATA

                  ,
                   ERROR_CODE
              INTO P_TY_ATM_TXN_REC.RESP_CODE

                  ,
                   P_TY_ATM_TXN_REC.ADD_AMT,
                   P_TY_ATM_TXN_REC.MINI_STMT_DATA

                  ,
                   P_ERR_CODE
              FROM SWTBS_TXN_LOG
             WHERE P_KEY = L_KEY_TEMP
               AND ROWNUM = 1
             ORDER BY XREF ASC;

            DBG('p_ty_atm_txn_rec.add_amt ' || P_TY_ATM_TXN_REC.ADD_AMT);
            DBG('fn_txn_contol : Repeat msg returning Successfully ');
            RETURN FALSE;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN

              UPDATE SWTBS_TXN_LOG
                 SET MSG_TYPE = L_MSG_TYPE_TEMP, P_KEY = L_KEY_TEMP
               WHERE

               XREF = P_TY_ATM_TXN_REC.XREF;

              COMMIT;
              P_TY_ATM_TXN_REC.MSG_TYPE := L_MSG_TYPE_TEMP;
              P_TY_ATM_TXN_REC.P_KEY    := L_KEY_TEMP;

          END;

        END IF;

      ELSE

        P_ERR_CODE  := 'SW-MSG-01';
        P_ERR_PARAM := P_TY_ATM_TXN_REC.MSG_TYPE;
        RETURN FALSE;

      END IF;

      DBG('Returning true from fn_txn_contol_and_derive');

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      L_FN_CALL_ID := 2;
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_TXN_CONTROL(P_TY_ATM_TXN_REC,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM,
                                                    L_FN_CALL_ID) THEN
        DBG('E', 'gwpks_ext_switchservice.fn_txn_control returned false ');
        RETURN FALSE;
      END IF;
    END IF;
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('E', 'In fn_txn_contol ' || SQLERRM);
      P_ERR_CODE  := 'SW-CTL-01';
      P_ERR_PARAM := NULL;
      RETURN FALSE;

  END FN_TXN_CONTOL;

  FUNCTION FN_DERIVE_NORMAL(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS

    L_ACQ_MATCH NUMBER(1) := 0;
    L_ISS_MATCH NUMBER(1) := 0;
    L_USER_ID   VARCHAR2(32);
    L_DR_CR     VARCHAR2(1);

    L_CUST_AC_NO   STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_VIR_ACC_NAME STTM_VIRTUAL_ACCOUNTS.VIR_ACC_NAME%TYPE;
    L_IS_VIR_ACC   VARCHAR2(1);
    L_BRANCH_CODE  STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;

  BEGIN

    DBG('fn_derive_normal : Coming inside fn_derive_normal ');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_DERIVE_NORMAL(P_TY_ATM_TXN_REC,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.fn_derive_normal returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('proc_code_type --> ' ||
          SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2));

      IF NOT SWPKSS_UTILS.FN_GET_FC_CODE_REC_WRP(SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,
                                                        1,
                                                        2),
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM) THEN
        P_ERR_CODE  := 'SW-LIT-01';
        P_ERR_PARAM := SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2);
        DBG('E', 'In fn_derive_normal ' || SQLERRM);
        RETURN FALSE;
      ELSE
        DBG('Inside Fn_Get_fc_code_Rec_Wrp...');
        P_TY_ATM_TXN_REC.FC_LITERAL := SWPKSS_UTILS.G_TBL_SWTM_FC_CODE.FC_LITERAL;
      END IF;

      IF P_TY_ATM_TXN_REC.PAN IS NOT NULL THEN

        --sampath added to resolve 7 digit issuer bin starts
        FOR G IN REVERSE 6 .. 8 LOOP
          IF NOT SWPKSS_UTILS.FN_GET_ISSUER_DTLS_REC_WRP(SUBSTR(P_TY_ATM_TXN_REC.PAN,
                                                                1,
                                                                G),
                                                         P_ERR_CODE,
                                                         P_ERR_PARAM)

           THEN

            IF G = 6 THEN
              IF P_ERR_CODE = 'CS-FRC-001' THEN
                P_TY_ATM_TXN_REC.NETWORK_ID := 'ALL';
                L_ISS_MATCH                 := 0;
                P_ERR_CODE                  := NULL;
              ELSE
                P_TY_ATM_TXN_REC.NETWORK_ID := 'ALL';
                P_ERR_CODE                  := 'SW-ISS-01';
                P_ERR_PARAM                 := SUBSTR(P_TY_ATM_TXN_REC.PAN,
                                                      1,
                                                      6);
                DBG('Error occured while retreiving the issuer details...');
                RETURN FALSE;
              END IF;
            END IF;
          ELSE
            DBG('Inside Fn_Get_issuer_dtls_Rec_Wrp...');
            P_TY_ATM_TXN_REC.NETWORK_ID := SWPKSS_UTILS.G_TBL_SWTM_ISS_DTLS.NETWORK_ID;
            L_ISS_MATCH                 := 1;
            P_ERR_CODE                  := NULL; --Making null as this varibale is getting checked during reversal atm remote on us from cup network
            EXIT;
          END IF;
        END LOOP;
        --sampath added to resolve 7 digit issuer bin ends

        --sampath commented to resolve 7 digit issuer bin starts
        /*
        IF NOT SWPKSS_UTILS.FN_GET_ISSUER_DTLS_REC_WRP(SUBSTR(P_TY_ATM_TXN_REC.PAN,
                                                              1,
                                                              6),
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM)

         THEN

          IF P_ERR_CODE = 'CS-FRC-001' THEN
            P_TY_ATM_TXN_REC.NETWORK_ID := 'ALL';
            L_ISS_MATCH                 := 0;
            P_ERR_CODE                  := NULL;
          ELSE
            P_TY_ATM_TXN_REC.NETWORK_ID := 'ALL';
            P_ERR_CODE                  := 'SW-ISS-01';
            P_ERR_PARAM                 := SUBSTR(P_TY_ATM_TXN_REC.PAN,
                                                  1,
                                                  6);
            DBG('Error occured while retreiving the issuer details...');
            RETURN FALSE;
          END IF;

          ELSE
            DBG('Inside Fn_Get_issuer_dtls_Rec_Wrp...6 digit match');
            P_TY_ATM_TXN_REC.NETWORK_ID := SWPKSS_UTILS.G_TBL_SWTM_ISS_DTLS.NETWORK_ID;
            L_ISS_MATCH                 := 1;
          END IF;

        ELSE
          DBG('Inside Fn_Get_issuer_dtls_Rec_Wrp...');
          P_TY_ATM_TXN_REC.NETWORK_ID := SWPKSS_UTILS.G_TBL_SWTM_ISS_DTLS.NETWORK_ID;
          L_ISS_MATCH                 := 1;
        END IF;*/
        --sampath commented to resolve 7 digit issuer bin ends
      END IF;

      IF NOT SWPKSS_UTILS.FN_GET_ACQ_DTLS_REC_WRP(P_TY_ATM_TXN_REC.ACQ_INS_ID,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM) THEN

        L_ACQ_MATCH := 0;

      ELSE
        DBG('Inside Fn_Get_acq_dtls_Rec_Wrp...');
        L_ACQ_MATCH := 1;
      END IF;

      IF L_ISS_MATCH = 1 AND L_ACQ_MATCH = 1 THEN
        P_TY_ATM_TXN_REC.OFFUS_ONUS := 'O';
      ELSIF L_ISS_MATCH = 1 THEN
        P_TY_ATM_TXN_REC.OFFUS_ONUS := 'R';
      ELSE
        P_TY_ATM_TXN_REC.NETWORK_ID := SWPKSS_UTILS.G_TBL_SWTM_ACQ_DTLS.NETWORK_ID;
        P_TY_ATM_TXN_REC.OFFUS_ONUS := 'F';
      END IF;

      --sampath starts
      IF P_TY_ATM_TXN_REC.RSV_60 = 'MAS' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'MASTER';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'VIS' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'VISA';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) NOT IN ('29') THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'UPI';

      --sampath UPI for PCT starts
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) = '29' AND P_TY_ATM_TXN_REC.txn_desc = '00' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'UPIGPAY';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) = '29' AND P_TY_ATM_TXN_REC.txn_desc = '01' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'UPIDFT';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) = '29' AND P_TY_ATM_TXN_REC.txn_desc = '02' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'UPICPY';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) = '29' AND P_TY_ATM_TXN_REC.txn_desc = '03' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'UPICR';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) = '29' AND P_TY_ATM_TXN_REC.txn_desc = '04' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'UPIMS';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) = '29' AND P_TY_ATM_TXN_REC.txn_desc = '05' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'UPIDSB';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'UPI' AND SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) = '29' AND P_TY_ATM_TXN_REC.txn_desc = '06' THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'UPIOTR';
      --sampath UPI for PCT ends

    ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'CSS' OR
            SUBSTR(P_TY_ATM_TXN_REC.proc_code, 1, 2) IN ('42') THEN
        P_TY_ATM_TXN_REC.NETWORK_ID := 'NBC';
      ELSIF P_TY_ATM_TXN_REC.RSV_60 = 'CCONUS' THEN
        --P_TY_ATM_TXN_REC.NETWORK_ID := 'CREDITCARD';
        P_TY_ATM_TXN_REC.NETWORK_ID := SWPKS_UTILS.G_TBL_SWTM_ISS_DTLS.NETWORK_ID;

    --sampath starts for credit card payment via ATM
      ELSIF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) = '49' THEN

        IF P_TY_ATM_TXN_REC.TO_ACC = '389220012' THEN

         P_TY_ATM_TXN_REC.NETWORK_ID := 'CCPAYMAS';

        END IF;

        IF P_TY_ATM_TXN_REC.TO_ACC = '389220011' THEN

         P_TY_ATM_TXN_REC.NETWORK_ID := 'CCPAYVIS';

        END IF;

    IF P_TY_ATM_TXN_REC.TO_ACC = '389220013' THEN

         P_TY_ATM_TXN_REC.NETWORK_ID := 'CCPAYUPI';

        END IF;
    --sampath ends for credit card payment via ATM
      ELSE
        P_TY_ATM_TXN_REC.NETWORK_ID := 'PRINCE';
      END IF;
      --sampath ends
      DBG('IDENTIFIER:: ' || P_TY_ATM_TXN_REC.OFFUS_ONUS);
      DBG('p_Ty_Atm_Txn_Rec.Network_Id --> ' ||
          P_TY_ATM_TXN_REC.NETWORK_ID);

      IF P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' THEN

        IF NOT FN_CARDACC_TO_FCCACC(P_TY_ATM_TXN_REC,
                                    'N',
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
          DBG('E',
              'fn_derive_normal : fn_cardacc_to_fccacc returned false ');
          IF P_ERR_CODE IS NULL THEN
            P_ERR_CODE  := 'SW-CRD-01';
            P_ERR_PARAM := P_TY_ATM_TXN_REC.PAN || '~' ||
                           P_TY_ATM_TXN_REC.FROM_ACC;
          END IF;
          RETURN FALSE;
        END IF;
        IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('FTR', 'DFT', 'CFT') THEN
          --sampath added for Dr IBFT and Cr IBFT for css
          IF NOT FN_CARDACC_TO_FCCACC(P_TY_ATM_TXN_REC,
                                      'Y',
                                      P_ERR_CODE,
                                      P_ERR_PARAM) THEN
            DBG('E',
                'fn_derive_normal : fn_cardacc_to_fccacc returned false ');
            P_ERR_CODE  := 'SW-CRD-02';
            P_ERR_PARAM := P_TY_ATM_TXN_REC.FROM_ACC;
            RETURN FALSE;
          END IF;

          DBG('Calling swpkss_utils.fn_validate_ac .........p_ty_atm_txn_rec.txn_acc_no_fcc ' ||
              P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
          IF NOT SWPKSS_UTILS.FN_VALIDATE_AC(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                             P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                             'D',
                                             P_TY_ATM_TXN_REC.TXN_DT,
                                             P_TY_ATM_TXN_REC.TXN_CCY_CODE,
                                             P_ERR_CODE,
                                             P_ERR_PARAM) THEN
            DBG('E',
                'Failed while calling swpkss_utils.fn_validate_ac' ||
                SQLCODE);
            IF P_ERR_CODE IS NULL THEN
              P_ERR_CODE := 'AC-VAC28';
            END IF;
            RETURN FALSE;
          END IF;
          DBG('Calling swpkss_utils.fn_validate_ac .........p_ty_atm_txn_rec.to_acc ' ||
              P_TY_ATM_TXN_REC.TO_ACC);

          DBG('Calling swpkss_utils.fn_validate_ac ......... ');

          DBG('virtual acc no~' ||
              NVL(DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO, 'NULL'));

          IF G_VIR_ACC_FLAG = 'Y' THEN
            DBG('It is a virtual account,resolving the actual account for account validation');
            IF NOT STPKS_VIRTUALACC_UTILS.FN_RESOLVE_VIR_ACC(P_TY_ATM_TXN_REC.TO_ACC,
                                                             P_TY_ATM_TXN_REC.TXN_CCY_FCC,
                                                             L_BRANCH_CODE,
                                                             L_CUST_AC_NO,
                                                             L_VIR_ACC_NAME,
                                                             L_IS_VIR_ACC,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
              DBG('p_err_code :::::: ' || P_ERR_CODE ||
                  '::::: p_err_param ::::: ' || P_ERR_PARAM);
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
              ROLLBACK TO BEFORE_UPLOAD;
              RETURN FALSE;
            ELSE
              DBG('Returned successfully from fn_resolve_vir_acc' ||
                  P_ERR_PARAM);
              DBG('Returned successfully with l_cust_ac_no' ||
                  L_CUST_AC_NO);
              IF P_ERR_CODE IS NOT NULL THEN
                DBG('error code is not null');
                OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
              END IF;
            END IF;
          END IF;

          IF NOT SWPKSS_UTILS.FN_VALIDATE_AC(

                                             P_TY_ATM_TXN_REC.OFF_BRANCH_CODE

                                            ,
                                             NVL(L_CUST_AC_NO,
                                                 P_TY_ATM_TXN_REC.TO_ACC)

                                            ,
                                             'C',
                                             P_TY_ATM_TXN_REC.TXN_DT,
                                             P_TY_ATM_TXN_REC.TXN_CCY_CODE,
                                             P_ERR_CODE,
                                             P_ERR_PARAM) THEN
            DBG('E',
                'Failed while calling swpkss_utils.fn_validate_ac' ||
                SQLCODE);
            IF P_ERR_CODE IS NULL THEN
              P_ERR_CODE := 'AC-VAC28';
            END IF;
            RETURN FALSE;
          END IF;

        END IF;
        IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('PAY') THEN

          IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.UTIL_PROV_ACC_SEND = 'Y' THEN
            IF NOT FN_CARDACC_TO_FCCACC(P_TY_ATM_TXN_REC,
                                        'Y',
                                        P_ERR_CODE,
                                        P_ERR_PARAM) THEN
              DBG('E',
                  'fn_derive_normal : fn_cardacc_to_fccacc returned false ');
              P_ERR_CODE  := 'SW-CRD-02';
              P_ERR_PARAM := P_TY_ATM_TXN_REC.TO_ACC;
              RETURN FALSE;
            END IF;
          ELSE
            BEGIN

              SELECT ACCOUNT_NO, ACCOUNT_BRANCH
                INTO P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC,
                     P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
                FROM SWTMS_UTIL_PROV_DETAILS
               WHERE UTILITY_PROVIDER_ID = P_TY_ATM_TXN_REC.TO_ACC;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('E',
                    'fn_derive_normal : Utility Provider ID not found ');
                P_ERR_CODE  := 'SW-UTP-01';
                P_ERR_PARAM := P_TY_ATM_TXN_REC.TO_ACC;
                RETURN FALSE;
            END;
          END IF;
        END IF;

        IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('CAW', 'NPA', 'CDP', 'CCP', 'PCT', 'QCT') THEN --sampath starts for credit card payment via ATM --sampath added PCT for UPI
          DBG('Calling swpkss_utils.fn_validate_ac for CAW/NPA/CDP.........p_ty_atm_txn_rec.txn_acc_no_fcc ' ||
              P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
          DBG('Calling swpkss_utils.fn_validate_ac for CAW/NPA/CDP.........p_ty_atm_txn_rec.acc_branch_code ' ||
              P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
          L_DR_CR := 'D';
          IF P_TY_ATM_TXN_REC.FC_LITERAL = 'CDP' OR P_TY_ATM_TXN_REC.FC_LITERAL = 'PCT' THEN --sampath added PCT for UPI
            L_DR_CR := 'C';
          END IF;

          IF NOT SWPKSS_UTILS.FN_VALIDATE_AC(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                             P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                                             L_DR_CR,
                                             P_TY_ATM_TXN_REC.TXN_DT,
                                             P_TY_ATM_TXN_REC.TXN_CCY_CODE,
                                             P_ERR_CODE,
                                             P_ERR_PARAM) THEN
            DBG('E',
                'Failed while calling swpkss_utils.fn_validate_ac' ||
                SQLCODE);
            IF P_ERR_CODE IS NULL THEN
              P_ERR_CODE := 'AC-VAC01';
            END IF;
            RETURN FALSE;
          END IF;
        END IF;

        IF NVL(G_CL_OLL_ACC, 'N') = 'N' THEN

          IF P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' THEN

            --sampath added code for credit card cash withdrawal starts
            IF P_TY_ATM_TXN_REC.RSV_60 IN ('CCONUS') THEN
              P_TY_ATM_TXN_REC.CUSTOMER_CATEGORY := 'ALL'; --sampath added else for credit card cash withdrawal

            ELSE
              --sampath added else condition for credit card cash withdrawal

              IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('42') THEN
                --sampath added for CFT for CSS
                P_TY_ATM_TXN_REC.CUSTOMER_CATEGORY := 'ALL'; --sampath added for IBFT CFT for CSS
              ELSE
                --sampath added for IBFT CFT for CSS
            BEGIN
              DBG('cust_ac_no --> ' || P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
              DBG('branch_code --> ' || P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
              SELECT CUSTOMER_CATEGORY
                INTO P_TY_ATM_TXN_REC.CUSTOMER_CATEGORY
                FROM STTMS_CUSTOMER
               WHERE CUSTOMER_NO =
                     (SELECT CUST_NO
                        FROM STTMS_CUST_ACCOUNT
                       WHERE CUST_AC_NO = P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC
                         AND BRANCH_CODE = P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('E', 'fn_derive_normal : Customer category not found ');
                P_ERR_CODE := 'SW-CTG-01';
                RETURN FALSE;
            END;
              END IF; --sampath added for CFT for CSS
            END IF; --sampath added End if code for credit card cash withdrawal
          ELSE
            P_TY_ATM_TXN_REC.CUSTOMER_CATEGORY := 'ALL';
          END IF;

        END IF;

      END IF;

      IF P_TY_ATM_TXN_REC.OFFUS_ONUS IN ('O', 'F') AND
         SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN ('41', '42') THEN
        --sampath added AND condition for CSS

        IF NOT SWPKSS_UTILS.FN_GET_SW_TERMID_REC_WRP(P_TY_ATM_TXN_REC.TERM_ID,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM) THEN

          RETURN FALSE;

        ELSE
          P_TY_ATM_TXN_REC.TXN_GL              := SWPKSS_UTILS.G_TBL_SW_TERMID_REC.CASH_GL;
          P_TY_ATM_TXN_REC.INTELLIGENT_DEPOSIT := SWPKSS_UTILS.G_TBL_SW_TERMID_REC.INTELLIGENT_DEPOSIT;
        END IF;

      END IF;

      IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN
        DBG('Remote ONUS');

        P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                                                 P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
        L_USER_ID                         := CSPKS_REQ_GLOBAL.G_HEADER('SOURCE');
        GLOBAL.PR_INIT(P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE, L_USER_ID);
      END IF;

      DBG('p_ty_atm_txn_rec.txn_gl = ' || P_TY_ATM_TXN_REC.TXN_GL);
      DBG('Returning true from fn_derive_normal');

    END IF;

    GLOBAL.PR_RESET_SKIP_KERNEL;

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_POST_DERIVE_NORMAL(P_TY_ATM_TXN_REC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.fn_post_derive_normal returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In fn_derive_normal ' || SQLERRM);
      P_ERR_CODE  := 'SW-DRV-01';
      P_ERR_PARAM := NULL;
      RETURN FALSE;

  END FN_DERIVE_NORMAL;

  FUNCTION FN_CHECK_FOR_REVERSAL(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS

    L_MSG_TYPE_TEMP VARCHAR2(4) DEFAULT NULL;
    L_KEY_TEMP      VARCHAR2(255) DEFAULT NULL;
    L_KEY_ORIG      VARCHAR2(255) DEFAULT NULL;
    L_MSG_TYPE_ORIG VARCHAR2(4) DEFAULT NULL;
  BEGIN

    DBG('fn_check_for_reversal : Coming inside fn_check_for_reversal ');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_CHECK_FOR_REVERSAL(P_TY_ATM_TXN_REC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.fn_check_for_reversal returned false ');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 1) || '400');

      IF NOT SWPKSS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                            P_TY_ATM_TXN_REC.P_KEY,
                                            L_MSG_TYPE_TEMP,
                                            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                            L_KEY_TEMP) THEN
        DBG('E',
            'fn_txn_contol: swpks_utils.fn_get_parent_key returned false ');
        P_ERR_CODE  := 'SW-KEY-02';
        P_ERR_PARAM := NULL;
        RETURN FALSE;
      END IF;
      BEGIN
        SELECT RESP_CODE
          INTO P_TY_ATM_TXN_REC.RESP_CODE
          FROM SWTBS_TXN_LOG
         WHERE P_KEY = L_KEY_TEMP;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_CODE  := 'SW-REV-04';
          P_ERR_PARAM := L_KEY_TEMP;
          RETURN TRUE;
      END;
      L_KEY_ORIG             := P_TY_ATM_TXN_REC.P_KEY;
      P_TY_ATM_TXN_REC.P_KEY := L_KEY_TEMP;

      L_MSG_TYPE_ORIG           := P_TY_ATM_TXN_REC.MSG_TYPE;
      P_TY_ATM_TXN_REC.MSG_TYPE := L_MSG_TYPE_TEMP;

      IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('CHB', 'BEQ', 'BIQ', 'ADS', 'MST') THEN
        IF NOT SWPKSS_NONFINHANDLER.FN_MAIN(P_TY_ATM_TXN_REC,
                                            P_ERR_CODE,
                                            P_ERR_PARAM) THEN

          DBG('gwpks_switch_nonfin.fn_main');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          RETURN FALSE;
        END IF;
      END IF;
      IF P_TY_ATM_TXN_REC.FC_LITERAL IN
         ('CAW',
      'QCT',
          'CCP', --sampath starts for credit card payment via ATM
          'FTR',
          'DFT', --sampath added for Dr IBFT
          'CFT', --sampath added for Dr IBFT
          'PAY',
          'CDP',
      'PCT', --sampath added PCT for UPI
          'NPA',
          'CAB',
          'PAD',
          'MRE',
          'MRA',
          'MER',
          'CQP') OR P_TY_ATM_TXN_REC.CHARGE_NON_FIN_TXN = 'Y' THEN

        IF NOT SWPKS_FINHANDLER.FN_MAIN(P_TY_ATM_TXN_REC,
                                        P_ERR_CODE,
                                        P_ERR_PARAM) THEN
          DBG('E', 'swpks_finhandler.fn_main returned false ');
          P_ERR_CODE  := 'GW-REV-01';
          P_ERR_PARAM := 'fn_update_resp' || '~' || P_ERR_CODE;
          ROLLBACK TO SP_SWITCH;
        END IF;

      END IF;

      P_TY_ATM_TXN_REC.P_KEY    := L_KEY_ORIG;
      P_TY_ATM_TXN_REC.MSG_TYPE := L_MSG_TYPE_ORIG;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
    RETURN TRUE;

  EXCEPTION

    WHEN OTHERS THEN
      DBG('E', 'In fn_check_for_reversal ' || SQLERRM);
      P_ERR_CODE  := 'SW-CRV-01';
      P_ERR_PARAM := NULL;
      RETURN FALSE;

  END FN_CHECK_FOR_REVERSAL;

  FUNCTION FN_CALC_CHGS(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                        P_ERR_CODE       IN OUT VARCHAR2,
                        P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_MINOR        NUMBER(1) DEFAULT 0;
    L_CCY          VARCHAR2(3) DEFAULT NULL;
    L_TXN_CCY_FCC  VARCHAR2(3) DEFAULT NULL;
    L_SETL_CCY_FCC VARCHAR2(3) DEFAULT NULL;
    L_TXN_CHG      VARCHAR2(10) DEFAULT NULL;
    L_SETL_CHG     VARCHAR2(10) DEFAULT NULL;
    LEN            NUMBER(3) DEFAULT 0;
    L_CCY_MINOR    NUMBER(1) DEFAULT 0;
  BEGIN

    DBG('fn_calc_chgs : Coming inside Gwpks_CreateSWTransaction.fn_calc_chgs ');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKSS_EXT_SWITCHSERVICE.FN_PRE_CALC_CHGS(P_TY_ATM_TXN_REC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM) THEN
        DBG('Function gwpkss_ext_switchservice.fn_pre_calc_chgs returned FALSE');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
        WHILE (LEN <= 216 OR LEN <= LENGTH(P_TY_ATM_TXN_REC.ADD_ISO_46)) LOOP

          IF SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 1, 2) IN
             ('00', '01') THEN

            L_CCY := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 4, 3);
            DBG('fn_calc_chgs : Cal chg for 2003 -- l_ccy' || L_CCY);

            IF NOT
                GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_CCY,
                                                        L_TXN_CCY_FCC,
                                                        L_CCY_MINOR,
                                                        P_TY_ATM_TXN_REC.RESP_CODE) THEN
              DBG('E',
                  'fn_calc_chgs : No proper translation avl for ccy type ' ||
                  L_CCY || '~' || L_TXN_CCY_FCC);
              RETURN FALSE;
            END IF;
            L_MINOR := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46,
                                        LEN + 7,
                                        1));
            DBG('fn_calc_chgs : Cal chg for 2003 -- l_minor' || L_MINOR);
            L_TXN_CHG := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 8, 8);
            DBG('fn_calc_chgs : Cal chg for 2003 -- l_txn_chg' ||
                L_TXN_CHG);

            L_CCY := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 25, 3);
            DBG('fn_calc_chgs : Cal chg for 2003 -- l_ccy' || L_CCY);

            IF NOT
                GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_CCY,
                                                        L_SETL_CCY_FCC,
                                                        L_CCY_MINOR,
                                                        P_TY_ATM_TXN_REC.RESP_CODE) THEN
              DBG('E',
                  'fn_calc_chgs : No proper translation avl for ccy type ' ||
                  L_CCY || '~' || L_SETL_CCY_FCC);
              RETURN FALSE;
            END IF;

            L_MINOR := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46,
                                        LEN + 28,
                                        1));
            DBG('fn_calc_chgs : Cal chg for 2003 -- l_minor' || L_MINOR);
            L_SETL_CHG := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 29, 8);
            DBG('fn_calc_chgs : Cal chg for 2003 -- l_setl_chg' ||
                L_SETL_CHG);

            IF SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 1, 2) = '00' THEN
              P_TY_ATM_TXN_REC.TXN_FEE_CCY_FCC  := L_TXN_CCY_FCC;
              P_TY_ATM_TXN_REC.TXN_FEE_AMT      := L_TXN_CHG;
              P_TY_ATM_TXN_REC.SETL_FEE_CCY_FCC := L_SETL_CCY_FCC;
              P_TY_ATM_TXN_REC.SETL_FEE_AMT     := L_SETL_CHG;
              DBG('fn_calc_chgs : Cal chg for 2003 -- txn_fee_amt' ||
                  P_TY_ATM_TXN_REC.TXN_FEE_AMT);
            ELSE
              P_TY_ATM_TXN_REC.TXN_PROC_FEE_CCY_FCC  := L_TXN_CCY_FCC;
              P_TY_ATM_TXN_REC.TXN_PROC_FEE          := L_TXN_CHG;
              P_TY_ATM_TXN_REC.SETL_PROC_FEE_CCY_FCC := L_SETL_CCY_FCC;
              P_TY_ATM_TXN_REC.SETL_PROC_FEE         := L_SETL_CHG;
              DBG('fn_calc_chgs : Cal chg for 2003 -- txn_proc_fee' ||
                  P_TY_ATM_TXN_REC.TXN_PROC_FEE);
            END IF;

          END IF;
          LEN := LEN + 36;
        END LOOP;

      ELSE
        DBG('fn_calc_chgs : Cal chg for 93 ');

        WHILE (LEN <= 204 OR LEN <= LENGTH(P_TY_ATM_TXN_REC.ADD_ISO_46)) LOOP

          IF P_TY_ATM_TXN_REC.RSV_60 <> 'CSS' AND
             SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN ('41', '42') THEN
            --sampath added AND condition also
            --sampath added
            DBG('INSIDE NOT CSS');
          IF SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 1, 2) IN
             ('00', '01') THEN

            L_CCY := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 3, 3);

            IF NOT
                GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_CCY,
                                                        L_TXN_CCY_FCC,
                                                        L_CCY_MINOR,
                                                        P_TY_ATM_TXN_REC.RESP_CODE) THEN
              DBG('E',
                  'fn_calc_chgs : No proper translation avl for ccy type ' ||
                  L_CCY || '~' || L_TXN_CCY_FCC);
              RETURN FALSE;
            END IF;

            L_TXN_CHG := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 7, 8);

            L_SETL_CHG := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 24, 8);

            L_CCY := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 32, 3);

            IF NOT
                GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_CCY,
                                                        L_SETL_CCY_FCC,
                                                        L_CCY_MINOR,
                                                        P_TY_ATM_TXN_REC.RESP_CODE) THEN
              DBG('E',
                  'fn_calc_chgs : No proper translation avl for ccy type ' ||
                  L_CCY || '~' || L_SETL_CCY_FCC);
              RETURN FALSE;
            END IF;

            IF SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 1, 2) = '00' THEN
              P_TY_ATM_TXN_REC.TXN_FEE_CCY_FCC  := L_TXN_CCY_FCC;
                DBG('FIRST CHARGE=' || L_TXN_CCY_FCC);
              P_TY_ATM_TXN_REC.TXN_FEE_AMT      := L_TXN_CHG;
              P_TY_ATM_TXN_REC.SETL_FEE_CCY_FCC := L_SETL_CCY_FCC;
              P_TY_ATM_TXN_REC.SETL_FEE_AMT     := L_SETL_CHG;
              DBG('fn_calc_chgs : Cal chg for 93 -- txn_fee_amt' ||
                  P_TY_ATM_TXN_REC.TXN_FEE_AMT);
            ELSE
              P_TY_ATM_TXN_REC.TXN_PROC_FEE_CCY_FCC  := L_TXN_CCY_FCC;
                DBG('SECOND CHARGE=' || L_TXN_CCY_FCC);
              P_TY_ATM_TXN_REC.TXN_PROC_FEE          := L_TXN_CHG;
              P_TY_ATM_TXN_REC.SETL_PROC_FEE_CCY_FCC := L_SETL_CCY_FCC;
              P_TY_ATM_TXN_REC.SETL_PROC_FEE         := L_SETL_CHG;
              DBG('fn_calc_chgs : Cal chg for 93 -- txn_proc_fee' ||
                  P_TY_ATM_TXN_REC.TXN_PROC_FEE);
            END IF;

          END IF;
          ELSE
            DBG('INSIDE CSS');
            --Sampath added
            --Sampath added
            IF SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 1, 2) IN
               ('00', '01', '22') THEN
              --sampath added 22 for CSS beneficiary fee

              L_CCY := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 3, 3);

              IF NOT
                  GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_CCY,
                                                          L_TXN_CCY_FCC,
                                                          L_CCY_MINOR,
                                                          P_TY_ATM_TXN_REC.RESP_CODE) THEN
                DBG('E',
                    'fn_calc_chgs : No proper translation avl for ccy type ' ||
                    L_CCY || '~' || L_TXN_CCY_FCC);
                RETURN FALSE;
              END IF;

              L_TXN_CHG := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 7, 8);

              L_SETL_CHG := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 24, 8);

              L_CCY := SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 32, 3);

              IF NOT
                  GWPKSS_CREATESWTRANSACTION.FN_CCY_TRANS(L_CCY,
                                                          L_SETL_CCY_FCC,
                                                          L_CCY_MINOR,
                                                          P_TY_ATM_TXN_REC.RESP_CODE) THEN
                DBG('E',
                    'fn_calc_chgs : No proper translation avl for ccy type ' ||
                    L_CCY || '~' || L_SETL_CCY_FCC);
                RETURN FALSE;
              END IF;

              IF SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 1, 2) = '00' THEN
                P_TY_ATM_TXN_REC.TXN_FEE_CCY_FCC := L_TXN_CCY_FCC;
                DBG('FIRST CHARGE=' || L_TXN_CCY_FCC);
                P_TY_ATM_TXN_REC.TXN_FEE_AMT      := L_TXN_CHG;
                P_TY_ATM_TXN_REC.SETL_FEE_CCY_FCC := L_SETL_CCY_FCC;
                P_TY_ATM_TXN_REC.SETL_FEE_AMT     := L_SETL_CHG;
                DBG('fn_calc_chgs : Cal chg for 93 -- txn_fee_amt' ||
                    P_TY_ATM_TXN_REC.TXN_FEE_AMT);
              ELSIF SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 1, 2) = '01' THEN
                --sampath added else if for CSS beneficiary fee
                P_TY_ATM_TXN_REC.TXN_PROC_FEE_CCY_FCC := L_TXN_CCY_FCC;
                DBG('SECOND CHARGE=' || L_TXN_CCY_FCC);
                P_TY_ATM_TXN_REC.TXN_PROC_FEE          := L_TXN_CHG;
                P_TY_ATM_TXN_REC.SETL_PROC_FEE_CCY_FCC := L_SETL_CCY_FCC;
                P_TY_ATM_TXN_REC.SETL_PROC_FEE         := L_SETL_CHG;
                DBG('fn_calc_chgs : Cal chg for 93 -- txn_proc_fee' ||
                    P_TY_ATM_TXN_REC.TXN_PROC_FEE);

                --sampath added starts for CSS beneficiary fee
              ELSIF SUBSTR(P_TY_ATM_TXN_REC.ADD_ISO_46, LEN + 1, 2) = '22' THEN

                IF P_TY_ATM_TXN_REC.RSV_60 = 'CSS' OR
                   (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN
                   ('41', '42')) THEN
                  --sampath added OR conditon because for 41 dft CSS not coming in field 60
                  P_TY_ATM_TXN_REC.TXN_BEN_FEE_CCY_FCC := L_TXN_CCY_FCC;
                  DBG('THIRD CHARGE=' || L_TXN_CCY_FCC);
                  P_TY_ATM_TXN_REC.TXN_BEN_FEE          := L_TXN_CHG;
                  P_TY_ATM_TXN_REC.SETL_BEN_FEE_CCY_FCC := L_SETL_CCY_FCC;
                  P_TY_ATM_TXN_REC.SETL_BEN_FEE         := L_SETL_CHG;
                  DBG('fn_calc_chgs : Cal chg for 93 -- txn_proc_fee' ||
                      P_TY_ATM_TXN_REC.TXN_BEN_FEE);
                END IF;

                --sampath added ends for CSS beneficiary fee
              END IF;

            END IF;
          END IF; --sampath added for CSS beneficiary fee
          LEN := LEN + 34;
        END LOOP;

      END IF;

      DBG('Returning true from fn_calc_chgs');

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In fn_calc_chgs ' || SQLERRM);
      P_ERR_CODE  := 'SW-CHG-01';
      P_ERR_PARAM := NULL;
      RETURN FALSE;

  END FN_CALC_CHGS;

  FUNCTION FN_BUSINESS_MAPPING(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
    L_APP_DATE VARCHAR2(10);
    CCY_EXCEPTION EXCEPTION;
    L_FN_CALL_ID           NUMBER;
    L_TB_CUSTOM_DATA       GLOBAL.TY_TB_CUSTOM_DATA;
    L_TB_CUSTOM_DATA_EMPTY GLOBAL.TY_TB_CUSTOM_DATA;
    L_VALUE_DATE           DATE;
    L_VL_DT_YEAR           DATE;
    L_GL_APP_DT_YEAR       DATE;

  BEGIN

    DBG('fn_business_mapping : Coming inside fn_business_mapping ');
    IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '8' THEN
      RETURN TRUE;
    ELSE

      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
        L_FN_CALL_ID     := 1;
        L_TB_CUSTOM_DATA := L_TB_CUSTOM_DATA_EMPTY;
        IF NOT GWPKS_CREATESWTXN_CUSTOM.FN_BUSINESS_MAPPING(P_TY_ATM_TXN_REC,
                                                            L_FN_CALL_ID,
                                                            L_TB_CUSTOM_DATA,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
          DBG('error occured in gwpks_createswtxn_custom.fn_business_mapping:' ||
              P_ERR_CODE);
          DBG('pprms:' || P_ERR_PARAM);
          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
        P_TY_ATM_TXN_REC.TXN_DT := GLOBAL.APPLICATION_DATE;
      END IF;
      DBG('p_ty_atm_txn_rec.txn_dt::' || P_TY_ATM_TXN_REC.TXN_DT);

      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '0' THEN
        P_TY_ATM_TXN_REC.VALUE_DT := TO_DATE(TO_CHAR(TO_DATE(P_TY_ATM_TXN_REC.TRANS_DT_TIME,
                                                             'mmddhh24miss')));
      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
        P_TY_ATM_TXN_REC.VALUE_DT := TO_DATE(TO_CHAR(TO_DATE(NVL(P_TY_ATM_TXN_REC.TRANS_DT_TIME,
                                                                 SUBSTR(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                                        3)),
                                                             'mmddhh24miss')));
      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
        P_TY_ATM_TXN_REC.VALUE_DT := TO_DATE(TO_CHAR(TO_DATE(NVL(P_TY_ATM_TXN_REC.TRANS_DT_TIME,
                                                                 SUBSTR(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                                        5)),
                                                             'mmddhh24miss')));
      END IF;

      P_TY_ATM_TXN_REC.VALUE_DT := TO_DATE(TO_CHAR(TO_DATE(P_TY_ATM_TXN_REC.TRANS_DT_TIME,
                                                           'mmddhh24miss')));

      DBG('value date received ' || P_TY_ATM_TXN_REC.VALUE_DT);
      DBG('local txn date and time ' || P_TY_ATM_TXN_REC.LOCAL_TXN_TIME);
      DBG('SYSDATE ' || SYSDATE);
      DBG('Trunc SYSDATE ' || TRUNC(SYSDATE));

      BEGIN
        SELECT TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE, 'YYYY') ||
                       SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4)),
                       'YYYY-MM-DD')
          INTO L_VALUE_DATE
          FROM DUAL;

        DBG('l_value_date: ' || L_VALUE_DATE);

        SELECT TO_CHAR(TO_DATE(P_TY_ATM_TXN_REC.VALUE_DT,
                               GLOBAL.GET_NLS_DT_FORMAT),
                       'YYYY'),
               TO_CHAR(TO_DATE(GLOBAL.APPLICATION_DATE,
                               GLOBAL.GET_NLS_DT_FORMAT),
                       'YYYY')
          INTO L_VL_DT_YEAR, L_GL_APP_DT_YEAR
          FROM DUAL;
        DBG('Values for l_vl_dt_year: ' || L_VL_DT_YEAR ||
            ' l_gl_app_dt_year: ' || L_GL_APP_DT_YEAR || ' glbl app date:' ||
            GLOBAL.APPLICATION_DATE);
        IF L_VALUE_DATE > GLOBAL.APPLICATION_DATE AND
           L_VL_DT_YEAR > L_GL_APP_DT_YEAR THEN
          DBG('value date greater than system date :: so assigning the previous year to the value date');
          SELECT TO_DATE(((TO_CHAR(GLOBAL.APPLICATION_DATE, 'YYYY') - 1) ||
                         SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4)),
                         'YYYY-MM-DD')
            INTO L_VALUE_DATE
            FROM DUAL;
        END IF;
        DBG('value date after re-assignment is -->' || L_VALUE_DATE);
        P_TY_ATM_TXN_REC.VALUE_DT := L_VALUE_DATE;
      EXCEPTION
        WHEN OTHERS THEN

          DBG('Exception while getting value date ' || SQLERRM);

      END;

      DBG('value date re-assigned ' || P_TY_ATM_TXN_REC.VALUE_DT);

      DBG('p_ty_atm_txn_rec.msg_type ' || P_TY_ATM_TXN_REC.MSG_TYPE);
      DBG('p_ty_atm_txn_rec.switch_param_flg.iso_version ' ||
          P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION);
      DBG('p_ty_atm_txn_rec.trans_dt_time ' ||
          P_TY_ATM_TXN_REC.TRANS_DT_TIME ||
          ' p_ty_atm_txn_rec.local_txn_time ' ||
          P_TY_ATM_TXN_REC.LOCAL_TXN_TIME);
      DBG('p_ty_atm_txn_rec.value_dt ' || P_TY_ATM_TXN_REC.VALUE_DT);
      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '0' THEN

        IF SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4) = '0101' AND
           P_TY_ATM_TXN_REC.LOCAL_TXN_TIME >= '000000'

           AND TO_CHAR(SYSDATE, 'DD-MM') = '01-01'

           AND SYSDATE > P_TY_ATM_TXN_REC.VALUE_DT THEN

          IF NOT TRUNC(SYSDATE) = TRUNC(P_TY_ATM_TXN_REC.VALUE_DT) THEN

            P_TY_ATM_TXN_REC.VALUE_DT := P_TY_ATM_TXN_REC.VALUE_DT +
                                         TO_YMINTERVAL('1-0');
          END IF;

          DBG('value date year end support ' || P_TY_ATM_TXN_REC.VALUE_DT);
        END IF;

        IF SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4) = '1231' AND
           P_TY_ATM_TXN_REC.LOCAL_TXN_TIME >= '000000' AND
           SYSDATE < P_TY_ATM_TXN_REC.VALUE_DT THEN
          IF NOT TRUNC(SYSDATE) = TRUNC(P_TY_ATM_TXN_REC.VALUE_DT) THEN
            IF NOT (TRUNC(SYSDATE) + 1 = TRUNC(P_TY_ATM_TXN_REC.VALUE_DT) OR
                TRUNC(SYSDATE) + 2 = TRUNC(P_TY_ATM_TXN_REC.VALUE_DT)) THEN

              P_TY_ATM_TXN_REC.VALUE_DT := P_TY_ATM_TXN_REC.VALUE_DT +
                                           TO_YMINTERVAL('-1-0');
            END IF;
          END IF;
          DBG('value date year end support ' || P_TY_ATM_TXN_REC.VALUE_DT);
        END IF;

      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
        P_TY_ATM_TXN_REC.VALUE_DT := TO_DATE(TO_CHAR(TO_DATE(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                             'yymmddhh24miss')));
        DBG('value date year end support ' || P_TY_ATM_TXN_REC.VALUE_DT);

      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
        P_TY_ATM_TXN_REC.VALUE_DT := TO_DATE(TO_CHAR(TO_DATE(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                             'yyyymmddhh24miss')));
        DBG('value date year end support ' || P_TY_ATM_TXN_REC.VALUE_DT);

      END IF;

      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN

        IF P_TY_ATM_TXN_REC.ISO_FEILD_04 IS NOT NULL THEN
          P_TY_ATM_TXN_REC.TXN_CCY_CODE  := SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_04,
                                                   1,
                                                   3);
          P_TY_ATM_TXN_REC.TXN_AMT       := SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_04,
                                                   5,
                                                   12);
          P_TY_ATM_TXN_REC.TXN_CCY_MINOR := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_04,
                                                             4,
                                                             1));

          DBG('p_ty_atm_txn_rec.txn_ccy_minor==>' ||
              P_TY_ATM_TXN_REC.TXN_CCY_MINOR);
          DBG('p_ty_atm_txn_rec.txn_ccy_code==>' ||
              P_TY_ATM_TXN_REC.TXN_CCY_CODE);
          DBG('p_ty_atm_txn_rec.txn_ccy_fcc=>' ||
              P_TY_ATM_TXN_REC.TXN_CCY_FCC);

          IF NOT FN_CCY_TRANS(P_TY_ATM_TXN_REC.TXN_CCY_CODE,
                              P_TY_ATM_TXN_REC.TXN_CCY_FCC,
                              P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                              P_ERR_CODE) THEN
            DBG('E',
                'fn_business_mapping : No proper translation avl for ccy type ' ||
                P_TY_ATM_TXN_REC.TXN_CCY_CODE || '~' ||
                P_TY_ATM_TXN_REC.TXN_CCY_FCC);
            P_ERR_PARAM := 'fn_business_mapping' || '~' || P_ERR_CODE;

            RAISE CCY_EXCEPTION;
          END IF;
        END IF;
        IF P_TY_ATM_TXN_REC.ISO_FEILD_05 IS NOT NULL THEN
          P_TY_ATM_TXN_REC.SETL_CCY_CODE  := SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_05,
                                                    1,
                                                    3);
          P_TY_ATM_TXN_REC.SETL_AMT       := SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_05,
                                                    5,
                                                    12);
          P_TY_ATM_TXN_REC.SETL_CCY_MINOR := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_05,
                                                              4,
                                                              1));

          IF P_TY_ATM_TXN_REC.SETL_CCY_CODE = P_TY_ATM_TXN_REC.TXN_CCY_CODE THEN
            P_TY_ATM_TXN_REC.SETL_CCY_FCC := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          ELSE

            IF NOT FN_CCY_TRANS(P_TY_ATM_TXN_REC.SETL_CCY_CODE,
                                P_TY_ATM_TXN_REC.SETL_CCY_FCC,
                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                P_ERR_CODE) THEN
              DBG('E',
                  'fn_business_mapping : No proper translation avl for ccy type ' ||
                  P_TY_ATM_TXN_REC.SETL_CCY_CODE || '~' ||
                  P_TY_ATM_TXN_REC.SETL_CCY_FCC);
              P_ERR_PARAM := 'fn_business_mapping' || '~' || P_ERR_CODE;

              RAISE CCY_EXCEPTION;
            END IF;
          END IF;
        END IF;
        IF P_TY_ATM_TXN_REC.ISO_FEILD_06 IS NOT NULL THEN
          P_TY_ATM_TXN_REC.BILL_CCY_CODE  := SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_06,
                                                    1,
                                                    3);
          P_TY_ATM_TXN_REC.BILL_AMT       := SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_06,
                                                    5,
                                                    12);
          P_TY_ATM_TXN_REC.BILL_CCY_MINOR := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.ISO_FEILD_06,
                                                              4,
                                                              1));

          IF P_TY_ATM_TXN_REC.BILL_CCY_CODE = P_TY_ATM_TXN_REC.TXN_CCY_CODE THEN
            P_TY_ATM_TXN_REC.BILL_CCY_FCC := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

          ELSIF P_TY_ATM_TXN_REC.SETL_CCY_CODE IS NOT NULL AND
                P_TY_ATM_TXN_REC.BILL_CCY_CODE =
                P_TY_ATM_TXN_REC.SETL_CCY_CODE

           THEN
            P_TY_ATM_TXN_REC.BILL_CCY_FCC := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
          ELSE

            IF NOT FN_CCY_TRANS(P_TY_ATM_TXN_REC.BILL_CCY_CODE,
                                P_TY_ATM_TXN_REC.BILL_CCY_FCC,
                                P_TY_ATM_TXN_REC.BILL_CCY_MINOR,
                                P_ERR_CODE) THEN
              DBG('E',
                  'fn_business_mapping : No proper translation avl for ccy type ' ||
                  P_TY_ATM_TXN_REC.BILL_CCY_CODE || '~' ||
                  P_TY_ATM_TXN_REC.BILL_CCY_FCC || 'Y');
              P_ERR_PARAM := 'fn_business_mapping' || '~' || P_ERR_CODE;

              RAISE CCY_EXCEPTION;
            END IF;
          END IF;
        END IF;

        P_TY_ATM_TXN_REC.RECON_DATE       := P_TY_ATM_TXN_REC.ISO_FEILD_28;
        P_TY_ATM_TXN_REC.RECON_IND        := P_TY_ATM_TXN_REC.ISO_FEILD_29;
        P_TY_ATM_TXN_REC.ORIG_AMT         := P_TY_ATM_TXN_REC.ISO_FEILD_30;
        P_TY_ATM_TXN_REC.ACQ_REF_NO       := P_TY_ATM_TXN_REC.ISO_FEILD_31;
        P_TY_ATM_TXN_REC.ECOM_DATA        := P_TY_ATM_TXN_REC.ISO_FEILD_34;
        P_TY_ATM_TXN_REC.VERIFY_DATA      := P_TY_ATM_TXN_REC.VERIFY_DATA;
        P_TY_ATM_TXN_REC.RSV_ISO_50       := P_TY_ATM_TXN_REC.RSV_ISO_50;
        P_TY_ATM_TXN_REC.RSV_ISO_51       := P_TY_ATM_TXN_REC.RSV_ISO_51;
        P_TY_ATM_TXN_REC.AMT_ORIG_FEE     := P_TY_ATM_TXN_REC.ISO_FEILD_66;
        P_TY_ATM_TXN_REC.EXT_PAY_DATA     := P_TY_ATM_TXN_REC.ISO_FEILD_67;
        P_TY_ATM_TXN_REC.F_TRFR_MSG_CTL   := P_TY_ATM_TXN_REC.ISO_FEILD_68;
        P_TY_ATM_TXN_REC.F_TRFR_CTL_DATA  := P_TY_ATM_TXN_REC.ISO_FEILD_69;
        P_TY_ATM_TXN_REC.F_TRFR_DESC_DATA := P_TY_ATM_TXN_REC.ISO_FEILD_70;
        P_TY_ATM_TXN_REC.RECON_DATA_PRI   := P_TY_ATM_TXN_REC.ISO_FEILD_74;
        P_TY_ATM_TXN_REC.RECON_DATA_SEC   := P_TY_ATM_TXN_REC.ISO_FEILD_75;

      ELSE

        P_TY_ATM_TXN_REC.TXN_AMT       := P_TY_ATM_TXN_REC.ISO_FEILD_04;
        P_TY_ATM_TXN_REC.SETL_AMT      := P_TY_ATM_TXN_REC.ISO_FEILD_05;
        P_TY_ATM_TXN_REC.BILL_AMT      := P_TY_ATM_TXN_REC.ISO_FEILD_06;
        P_TY_ATM_TXN_REC.TXN_FEE_AMT   := P_TY_ATM_TXN_REC.ISO_FEILD_28;
        P_TY_ATM_TXN_REC.SETL_FEE_AMT  := P_TY_ATM_TXN_REC.ISO_FEILD_29;
        P_TY_ATM_TXN_REC.TXN_PROC_FEE  := P_TY_ATM_TXN_REC.ISO_FEILD_30;
        P_TY_ATM_TXN_REC.SETL_PROC_FEE := P_TY_ATM_TXN_REC.ISO_FEILD_31;
        P_TY_ATM_TXN_REC.PAN_EXTD      := P_TY_ATM_TXN_REC.ISO_FEILD_34;

        P_TY_ATM_TXN_REC.TXN_CCY_CODE := P_TY_ATM_TXN_REC.VERIFY_DATA;

        DBG('p_ty_atm_txn_rec.txn_ccy_code~' ||
            P_TY_ATM_TXN_REC.TXN_CCY_CODE);
        DBG('p_ty_atm_txn_rec.rsv_iso_50~' ||
            NVL(P_TY_ATM_TXN_REC.RSV_ISO_50, 'NULL'));

        IF P_TY_ATM_TXN_REC.TXN_CCY_CODE IS NOT NULL THEN
          IF P_TY_ATM_TXN_REC.RSV_ISO_50 IS NULL OR
             (P_TY_ATM_TXN_REC.RSV_ISO_50 = P_TY_ATM_TXN_REC.TXN_CCY_CODE) THEN
          IF NOT FN_CCY_TRANS(P_TY_ATM_TXN_REC.TXN_CCY_CODE,
                              P_TY_ATM_TXN_REC.TXN_CCY_FCC,
                              P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                              P_ERR_CODE) THEN
            DBG('E',
                'fn_business_mapping : No proper translation avl for ccy type ' ||
                P_TY_ATM_TXN_REC.TXN_CCY_CODE || '~' ||
                P_TY_ATM_TXN_REC.TXN_CCY_FCC);
            P_ERR_PARAM := 'fn_business_mapping' || '~' || P_ERR_CODE;

            RAISE CCY_EXCEPTION;
          END IF;
        END IF;
        END IF;

        DBG('[Txn_Ccy_Code]=>' || P_TY_ATM_TXN_REC.TXN_CCY_CODE);
        DBG('[txn_ccy_fcc]=>' || P_TY_ATM_TXN_REC.TXN_CCY_FCC);

        P_TY_ATM_TXN_REC.SETL_CCY_CODE := P_TY_ATM_TXN_REC.RSV_ISO_50;

        IF P_TY_ATM_TXN_REC.SETL_CCY_CODE IS NOT NULL THEN
          IF P_TY_ATM_TXN_REC.SETL_CCY_CODE = P_TY_ATM_TXN_REC.TXN_CCY_CODE THEN
            P_TY_ATM_TXN_REC.SETL_CCY_FCC   := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
            P_TY_ATM_TXN_REC.SETL_CCY_MINOR := P_TY_ATM_TXN_REC.TXN_CCY_MINOR;
          ELSE

            IF NOT FN_CCY_TRANS(P_TY_ATM_TXN_REC.SETL_CCY_CODE,
                                P_TY_ATM_TXN_REC.SETL_CCY_FCC,
                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                P_ERR_CODE) THEN
              DBG('E',
                  'fn_business_mapping : No proper translation avl for ccy type ' ||
                  P_TY_ATM_TXN_REC.SETL_CCY_CODE || '~' ||
                  P_TY_ATM_TXN_REC.SETL_CCY_FCC);
              P_ERR_PARAM := 'fn_business_mapping' || '~' || P_ERR_CODE;

              RAISE CCY_EXCEPTION;
            END IF;
          END IF;
          DBG('p_ty_atm_txn_rec.setl_ccy_minor ~p_ty_atm_txn_rec.txn_ccy_minor' ||
              P_TY_ATM_TXN_REC.SETL_CCY_MINOR ||
              P_TY_ATM_TXN_REC.TXN_CCY_MINOR);
        END IF;

        DBG('[Setl_Ccy_Code]=>' || P_TY_ATM_TXN_REC.SETL_CCY_CODE);
        DBG('[setl_ccy_fcc]=>' || P_TY_ATM_TXN_REC.SETL_CCY_FCC);

        P_TY_ATM_TXN_REC.BILL_CCY_CODE := P_TY_ATM_TXN_REC.RSV_ISO_51;

        IF P_TY_ATM_TXN_REC.BILL_CCY_CODE IS NOT NULL THEN
          IF P_TY_ATM_TXN_REC.BILL_CCY_CODE = P_TY_ATM_TXN_REC.TXN_CCY_CODE THEN
            P_TY_ATM_TXN_REC.BILL_CCY_FCC := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

            P_TY_ATM_TXN_REC.BILL_CCY_MINOR := P_TY_ATM_TXN_REC.TXN_CCY_MINOR;

          ELSIF P_TY_ATM_TXN_REC.SETL_CCY_CODE IS NOT NULL AND
                P_TY_ATM_TXN_REC.BILL_CCY_CODE =
                P_TY_ATM_TXN_REC.SETL_CCY_CODE

           THEN
            P_TY_ATM_TXN_REC.BILL_CCY_FCC := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

            P_TY_ATM_TXN_REC.BILL_CCY_MINOR := P_TY_ATM_TXN_REC.SETL_CCY_MINOR;

          ELSE

            IF NOT FN_CCY_TRANS(P_TY_ATM_TXN_REC.BILL_CCY_CODE,
                                P_TY_ATM_TXN_REC.BILL_CCY_FCC,
                                P_TY_ATM_TXN_REC.BILL_CCY_MINOR,
                                P_ERR_CODE) THEN
              DBG('E',
                  'fn_business_mapping : No proper translation avl for ccy type ' ||
                  P_TY_ATM_TXN_REC.BILL_CCY_CODE || '~' ||
                  P_TY_ATM_TXN_REC.BILL_CCY_FCC || 'Y');
              P_ERR_PARAM := 'fn_business_mapping' || '~' || P_ERR_CODE;

              RAISE CCY_EXCEPTION;
            END IF;
          END IF;
        END IF;

        DBG('[Bill_Ccy_Code]=>' || P_TY_ATM_TXN_REC.BILL_CCY_CODE);
        DBG('[bill_ccy_fcc]=>' || P_TY_ATM_TXN_REC.BILL_CCY_FCC);

        P_TY_ATM_TXN_REC.SETL_CODE          := P_TY_ATM_TXN_REC.ISO_FEILD_66;
        P_TY_ATM_TXN_REC.EXT_PAY_CODE       := P_TY_ATM_TXN_REC.ISO_FEILD_67;
        P_TY_ATM_TXN_REC.RCV_INST_CTY_CODE  := P_TY_ATM_TXN_REC.ISO_FEILD_68;
        P_TY_ATM_TXN_REC.SETL_INST_CTY_CODE := P_TY_ATM_TXN_REC.ISO_FEILD_69;
        P_TY_ATM_TXN_REC.NET_INFO_CODE      := P_TY_ATM_TXN_REC.ISO_FEILD_70;
        P_TY_ATM_TXN_REC.CREDIT_NO          := P_TY_ATM_TXN_REC.ISO_FEILD_74;
        P_TY_ATM_TXN_REC.CREDIT_REV_NO      := P_TY_ATM_TXN_REC.ISO_FEILD_75;

      END IF;

      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION <> '0' AND
         P_TY_ATM_TXN_REC.ADD_ISO_46 IS NOT NULL THEN

        IF NOT FN_CALC_CHGS(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
          DBG('E',
              'fn_calc_chg : Error in  Charge Calculation ' ||
              P_TY_ATM_TXN_REC.ADD_ISO_46);
          P_ERR_PARAM := 'fn_pop_plsql_tbl' || '~' || P_ERR_CODE;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
    RETURN TRUE;

  EXCEPTION

    WHEN CCY_EXCEPTION THEN
      DBG('E', 'inside Ccy_Exception ');
      IF NOT SWPKSS_UTILS.FN_SW_XREF_GEN(P_TY_ATM_TXN_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAM) THEN
        DBG('E', 'swpks_utils.fn_sw_xref_gen returned FALSE....... ');
        RETURN FALSE;
      END IF;
      IF NOT FN_TXN_CONTOL_LOG(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E', 'fn_txn_contol_log returned false ');
        RETURN FALSE;
      END IF;
      RETURN FALSE;

    WHEN OTHERS THEN
      DBG('E', 'In fn_business_mapping ' || SQLERRM);
      P_ERR_CODE  := 'SW-MAN-01';
      P_ERR_PARAM := P_TY_ATM_TXN_REC.P_KEY;
      RETURN FALSE;

  END FN_BUSINESS_MAPPING;

  FUNCTION FN_POP_PLSQL_TBL(P_TBL_NAME_VAL_PAIR IN OUT NOCOPY TY_RECS_TBL,
                            P_TY_ATM_TXN_REC    IN OUT NOCOPY TY_ATM_TXN_REC,
                            P_ERR_CODE          IN OUT VARCHAR2,
                            P_ERR_PARAM         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    P_TY_ATM_TXN_REC.RESP_CODE := '00';

    DBG('Inside fn_pop_plsql_tbl');

    IF P_TBL_NAME_VAL_PAIR('FIELD0').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.HEDDER := P_TBL_NAME_VAL_PAIR('FIELD0').TYP_VAR_VALUE;
      DBG('[hedder]=>' || P_TY_ATM_TXN_REC.HEDDER);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD1').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.MSG_TYPE := P_TBL_NAME_VAL_PAIR('FIELD1')
                                   .TYP_VAR_VALUE;
      DBG('[Msg_Type]=>' || P_TY_ATM_TXN_REC.MSG_TYPE);
    END IF;

    IF P_TBL_NAME_VAL_PAIR('FIELD2').TYP_VAR_VALUE IS NOT NULL THEN
      DBG('Inside FIELD2');
      P_TY_ATM_TXN_REC.PAN := P_TBL_NAME_VAL_PAIR('FIELD2').TYP_VAR_VALUE;
      DBG('[PAN]=>' || P_TY_ATM_TXN_REC.PAN);
    END IF;

    IF P_TBL_NAME_VAL_PAIR('FIELD3').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.PROC_CODE := P_TBL_NAME_VAL_PAIR('FIELD3')
                                    .TYP_VAR_VALUE;
      DBG('[Proc_Code]=>' || P_TY_ATM_TXN_REC.PROC_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD4').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_04 := P_TBL_NAME_VAL_PAIR('FIELD4')
                                       .TYP_VAR_VALUE;
      DBG('[ISO version]=>' ||
          P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION);

      DBG('[Txn_Amt]=>' || P_TY_ATM_TXN_REC.TXN_AMT);

    END IF;

    IF P_TBL_NAME_VAL_PAIR('FIELD5').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_05 := P_TBL_NAME_VAL_PAIR('FIELD5')
                                       .TYP_VAR_VALUE;

      DBG('[Setl_Amt]=>' || P_TY_ATM_TXN_REC.SETL_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD6').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_06 := P_TBL_NAME_VAL_PAIR('FIELD6')
                                       .TYP_VAR_VALUE;

      DBG('[Bill_Amt]=>' || P_TY_ATM_TXN_REC.BILL_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD7').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TRANS_DT_TIME := P_TBL_NAME_VAL_PAIR('FIELD7')
                                        .TYP_VAR_VALUE;

      DBG('[Trans_Dt_Time]=>' || P_TY_ATM_TXN_REC.TRANS_DT_TIME);

    ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION NOT IN ('1', '2') THEN

      DBG('E', 'Mandatory feild is NULL : FIELD7 - Trans_Dt_Time ');
      P_ERR_CODE  := 'SW-MND-01';
      P_ERR_PARAM := 'FIELD7 - Trans_Dt_Time';
      RETURN FALSE;
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD8').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.BILL_FEE_AMT := P_TBL_NAME_VAL_PAIR('FIELD8')
                                       .TYP_VAR_VALUE;
      DBG('[Bill_Fee_Amt]=>' || P_TY_ATM_TXN_REC.BILL_FEE_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD9').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.SETL_X_RATE := P_TBL_NAME_VAL_PAIR('FIELD9')
                                      .TYP_VAR_VALUE;
      DBG('[Setl_X_Rate]=>' || P_TY_ATM_TXN_REC.SETL_X_RATE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD10').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.BILL_X_RATE := P_TBL_NAME_VAL_PAIR('FIELD10')
                                      .TYP_VAR_VALUE;
      DBG('[Bill_X_Rate]=>' || P_TY_ATM_TXN_REC.BILL_X_RATE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD11').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.STAN := P_TBL_NAME_VAL_PAIR('FIELD11').TYP_VAR_VALUE;
      DBG('[FIELD11]=>' || P_TY_ATM_TXN_REC.STAN);
    ELSE
      DBG('E', 'Mandatory feild is NULL : FIELD11 - stan ');
      P_ERR_CODE  := 'SW-MND-01';
      P_ERR_PARAM := 'FIELD11 - stan';
      RETURN FALSE;
    END IF;

    IF P_TBL_NAME_VAL_PAIR('FIELD12').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.LOCAL_TXN_TIME := P_TBL_NAME_VAL_PAIR('FIELD12')
                                         .TYP_VAR_VALUE;
      DBG('[Local_Txn_Time]=>' || P_TY_ATM_TXN_REC.LOCAL_TXN_TIME);

    ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION IN ('1', '2') AND
          P_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL THEN
      DBG('E', 'Mandatory feild is NULL : FIELD12 - LOCAL_TXN_TIME ');
      P_ERR_CODE  := 'SW-MND-01';
      P_ERR_PARAM := 'FIELD12 - LOCAL_TXN_TIME';
      RETURN FALSE;

    END IF;

    IF P_TBL_NAME_VAL_PAIR('FIELD13').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.LOCAL_TXN_DT := P_TBL_NAME_VAL_PAIR('FIELD13')
                                       .TYP_VAR_VALUE;
      DBG('[Local_Txn_Dt]=>' || P_TY_ATM_TXN_REC.LOCAL_TXN_DT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD14').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.EXP_DATE := P_TBL_NAME_VAL_PAIR('FIELD14')
                                   .TYP_VAR_VALUE;
      DBG('[Exp_Date]=>' || P_TY_ATM_TXN_REC.EXP_DATE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD15').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.SETL_DATE := P_TBL_NAME_VAL_PAIR('FIELD15')
                                    .TYP_VAR_VALUE;
      DBG('[Setl_Date]=>' || P_TY_ATM_TXN_REC.SETL_DATE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD16').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.CONV_DATE := P_TBL_NAME_VAL_PAIR('FIELD16')
                                    .TYP_VAR_VALUE;
      DBG('[Conv_Date]=>' || P_TY_ATM_TXN_REC.CONV_DATE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD17').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.CAPT_DATE := P_TBL_NAME_VAL_PAIR('FIELD17')
                                    .TYP_VAR_VALUE;
      DBG('[Capt_Date]=>' || P_TY_ATM_TXN_REC.CAPT_DATE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD18').TYP_VAR_VALUE IS NOT NULL THEN

      P_TY_ATM_TXN_REC.ISO_FEILD_18 := P_TBL_NAME_VAL_PAIR('FIELD18')
                                       .TYP_VAR_VALUE;
      DBG('[iso_feild_18]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_18);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD19').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ACQ_INST_CTRY := P_TBL_NAME_VAL_PAIR('FIELD19')
                                        .TYP_VAR_VALUE;
      IF NOT FN_CNTY_TRANS(P_TY_ATM_TXN_REC.ACQ_INST_CTRY,
                           P_TY_ATM_TXN_REC.ACQ_CTRY_DERIVED,
                           P_ERR_CODE,
                           P_ERR_PARAM) THEN
        DBG('E',
            'fn_pop_plsql_tbl : No proper translation avl for ccy type ' ||
            P_TY_ATM_TXN_REC.TXN_CCY_CODE || '~' ||
            P_TY_ATM_TXN_REC.TXN_CCY_FCC);
        P_ERR_PARAM := 'fn_pop_plsql_tbl' || '~' || P_ERR_CODE;
        RETURN FALSE;
      END IF;
      DBG('[Acq_Inst_Ctry]=>' || P_TY_ATM_TXN_REC.ACQ_INST_CTRY);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD20').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.PAN_EXT_CTRY := P_TBL_NAME_VAL_PAIR('FIELD20')
                                       .TYP_VAR_VALUE;
      DBG('[PAN_Ext_Ctry]=>' || P_TY_ATM_TXN_REC.PAN_EXT_CTRY);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD21').TYP_VAR_VALUE IS NOT NULL THEN

      P_TY_ATM_TXN_REC.ISO_FEILD_21 := P_TBL_NAME_VAL_PAIR('FIELD21')
                                       .TYP_VAR_VALUE;
      DBG('[iso_feild_21]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_21);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD22').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.POS_ENT_MOD := P_TBL_NAME_VAL_PAIR('FIELD22')
                                      .TYP_VAR_VALUE;
      DBG('[POS_Ent_Mod]=>' || P_TY_ATM_TXN_REC.POS_ENT_MOD);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD23').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.APPL_PAN := P_TBL_NAME_VAL_PAIR('FIELD23')
                                   .TYP_VAR_VALUE;
      DBG('[Appl_PAN]=>' || P_TY_ATM_TXN_REC.APPL_PAN);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD24').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.NET_INT_ID := P_TBL_NAME_VAL_PAIR('FIELD24')
                                     .TYP_VAR_VALUE;
      DBG('[Net_Int_Id]=>' || P_TY_ATM_TXN_REC.NET_INT_ID);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD25').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.POS_COND_CODE := P_TBL_NAME_VAL_PAIR('FIELD25')
                                        .TYP_VAR_VALUE;
      DBG('[POS_Ctry_Code]=>' || P_TY_ATM_TXN_REC.POS_COND_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD26').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.POS_CAPT_CODE := P_TBL_NAME_VAL_PAIR('FIELD26')
                                        .TYP_VAR_VALUE;
      DBG('[POS_Capt_Code]=>' || P_TY_ATM_TXN_REC.POS_CAPT_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD27').TYP_VAR_VALUE IS NOT NULL THEN

      P_TY_ATM_TXN_REC.ISO_FEILD_27 := P_TBL_NAME_VAL_PAIR('FIELD27')
                                       .TYP_VAR_VALUE;
      DBG('[iso_feild_27]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_27);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD28').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_28 := P_TBL_NAME_VAL_PAIR('FIELD28')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_28]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_28);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD29').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_29 := P_TBL_NAME_VAL_PAIR('FIELD29')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_29]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_29);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD30').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_30 := P_TBL_NAME_VAL_PAIR('FIELD30')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_30]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_30);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD31').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_31 := P_TBL_NAME_VAL_PAIR('FIELD31')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_31]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_31);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD32').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ACQ_INS_ID := P_TBL_NAME_VAL_PAIR('FIELD32')
                                     .TYP_VAR_VALUE;
      DBG('[Acq_Ins_Id]=>' || P_TY_ATM_TXN_REC.ACQ_INS_ID);

    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD33').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.FWD_INS_ID := P_TBL_NAME_VAL_PAIR('FIELD33')
                                     .TYP_VAR_VALUE;
      DBG('[Fwd_Ins_Id]=>' || P_TY_ATM_TXN_REC.FWD_INS_ID);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD34').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_34 := P_TBL_NAME_VAL_PAIR('FIELD34')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_34]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_34);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD35').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TRK_2_DATA := P_TBL_NAME_VAL_PAIR('FIELD35')
                                     .TYP_VAR_VALUE;
      DBG('[Trk_2_data]=>' || P_TY_ATM_TXN_REC.TRK_2_DATA);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD36').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TRK_3_DATA := P_TBL_NAME_VAL_PAIR('FIELD36')
                                     .TYP_VAR_VALUE;
      DBG('[Trk_3_data]=>' || P_TY_ATM_TXN_REC.TRK_3_DATA);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD37').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RRN := P_TBL_NAME_VAL_PAIR('FIELD37').TYP_VAR_VALUE;
      DBG('[FIELD37]=>' || P_TY_ATM_TXN_REC.RRN);

    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD38').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.AUTH_CODE := P_TBL_NAME_VAL_PAIR('FIELD38')
                                    .TYP_VAR_VALUE;
      DBG('[Auth_Code]=>' || P_TY_ATM_TXN_REC.AUTH_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD39').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RESP_CODE := P_TBL_NAME_VAL_PAIR('FIELD39')
                                    .TYP_VAR_VALUE;
      DBG('[Resp_Code]=>' || P_TY_ATM_TXN_REC.RESP_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD40').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.SERV_REST_CODE := P_TBL_NAME_VAL_PAIR('FIELD40')
                                         .TYP_VAR_VALUE;
      DBG('[Serv_rest_code]=>' || P_TY_ATM_TXN_REC.SERV_REST_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD41').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TERM_ID := TRIM(P_TBL_NAME_VAL_PAIR('FIELD41')
                                       .TYP_VAR_VALUE);
      DBG('[Term_Id]=>' || P_TY_ATM_TXN_REC.TERM_ID);

    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD42').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ACCEPT_ID_CODE := P_TBL_NAME_VAL_PAIR('FIELD42')
                                         .TYP_VAR_VALUE;
      DBG('[Accept_Id_Code]=>' || P_TY_ATM_TXN_REC.ACCEPT_ID_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD43').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ACCEPT_ADDR := P_TBL_NAME_VAL_PAIR('FIELD43')
                                      .TYP_VAR_VALUE;
      DBG('[Accept_Addr]=>' || P_TY_ATM_TXN_REC.ACCEPT_ADDR);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD44').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ADD_RESP_DATA := P_TBL_NAME_VAL_PAIR('FIELD44')
                                        .TYP_VAR_VALUE;
      DBG('[Add_resp_data]=>' || P_TY_ATM_TXN_REC.ADD_RESP_DATA);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD45').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TRK_1_DATA := P_TBL_NAME_VAL_PAIR('FIELD45')
                                     .TYP_VAR_VALUE;
      DBG('[Trk_1_data]=>' || P_TY_ATM_TXN_REC.TRK_1_DATA);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD46').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ADD_ISO_46 := P_TBL_NAME_VAL_PAIR('FIELD46')
                                     .TYP_VAR_VALUE;

      DBG('[add_iso_46]=>' || P_TY_ATM_TXN_REC.ADD_ISO_46);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD47').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ADD_NTL_47 := P_TBL_NAME_VAL_PAIR('FIELD47')
                                     .TYP_VAR_VALUE;
      DBG('[Add_Ntl_47]=>' || P_TY_ATM_TXN_REC.ADD_NTL_47);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD48').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_48 := P_TBL_NAME_VAL_PAIR('FIELD48')
                                 .TYP_VAR_VALUE;
      DBG('[Rsv_48]=>' || P_TY_ATM_TXN_REC.RSV_48);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD49').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.VERIFY_DATA := P_TBL_NAME_VAL_PAIR('FIELD49')
                                      .TYP_VAR_VALUE;

      DBG('[verify_data]=>' || P_TY_ATM_TXN_REC.VERIFY_DATA);
    ELSE

      NULL;
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD50').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_50 := P_TBL_NAME_VAL_PAIR('FIELD50')
                                     .TYP_VAR_VALUE;

      DBG('[rsv_iso_50]=>' || P_TY_ATM_TXN_REC.RSV_ISO_50);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD51').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_51 := P_TBL_NAME_VAL_PAIR('FIELD51')
                                     .TYP_VAR_VALUE;

      DBG('[rsv_iso_51]=>' || P_TY_ATM_TXN_REC.RSV_ISO_51);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD52').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.PIN_NO := P_TBL_NAME_VAL_PAIR('FIELD52')
                                 .TYP_VAR_VALUE;
      DBG('[PIN_No]=>' || P_TY_ATM_TXN_REC.PIN_NO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD53').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.SEC_INFO := P_TBL_NAME_VAL_PAIR('FIELD53')
                                   .TYP_VAR_VALUE;
      DBG('[Sec_Info]=>' || P_TY_ATM_TXN_REC.SEC_INFO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD54').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ADD_AMT := P_TBL_NAME_VAL_PAIR('FIELD54')
                                  .TYP_VAR_VALUE;
      DBG('[Add_Amt]=>' || P_TY_ATM_TXN_REC.ADD_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD55').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_55 := P_TBL_NAME_VAL_PAIR('FIELD55')
                                     .TYP_VAR_VALUE;

      DBG('[Rsv_ISO_55]=>' || P_TY_ATM_TXN_REC.RSV_ISO_55);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD56').TYP_VAR_VALUE IS NOT NULL THEN
      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = 0 THEN
        P_TY_ATM_TXN_REC.RSV_ISO_56 := P_TBL_NAME_VAL_PAIR('FIELD56')
                                       .TYP_VAR_VALUE;

      ELSE
        P_TY_ATM_TXN_REC.ORG_DATA := P_TBL_NAME_VAL_PAIR('FIELD56')
                                     .TYP_VAR_VALUE;
      END IF;

      DBG('[Rsv_ISO_56]=>' || P_TY_ATM_TXN_REC.RSV_ISO_56);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD57').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_57 := P_TBL_NAME_VAL_PAIR('FIELD57')
                                     .TYP_VAR_VALUE;

      DBG('[Rsv_Ntl_57]=>' || P_TY_ATM_TXN_REC.RSV_NTL_57);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD58').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_58 := P_TBL_NAME_VAL_PAIR('FIELD58')
                                     .TYP_VAR_VALUE;

      DBG('[Rsv_Ntl_58]=>' || P_TY_ATM_TXN_REC.RSV_NTL_58);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD59').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_59 := P_TBL_NAME_VAL_PAIR('FIELD59')
                                     .TYP_VAR_VALUE;
      DBG('[Rsv_Ntl_59]=>' || P_TY_ATM_TXN_REC.RSV_NTL_59);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD60').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_60 := P_TBL_NAME_VAL_PAIR('FIELD60')
                                 .TYP_VAR_VALUE;
      DBG('[Rsv_60]=>' || P_TY_ATM_TXN_REC.RSV_60);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD61').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_PVT_61 := P_TBL_NAME_VAL_PAIR('FIELD61')
                                     .TYP_VAR_VALUE;
      DBG('[Rsv_Pvt_61]=>' || P_TY_ATM_TXN_REC.RSV_PVT_61);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD62').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_PVT_62 := P_TBL_NAME_VAL_PAIR('FIELD62')
                                     .TYP_VAR_VALUE;
      DBG('[Rsv_Pvt_62]=>' || P_TY_ATM_TXN_REC.RSV_PVT_62);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD63').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_PVT_63 := P_TBL_NAME_VAL_PAIR('FIELD63')
                                     .TYP_VAR_VALUE;
      DBG('[Rsv_Pvt_63]=>' || P_TY_ATM_TXN_REC.RSV_PVT_63);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD64').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.MAC_CHK_CODE := P_TBL_NAME_VAL_PAIR('FIELD64')
                                       .TYP_VAR_VALUE;
      DBG('[MAC_chk_code]=>' || P_TY_ATM_TXN_REC.MAC_CHK_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD65').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.BITMAP_TER := P_TBL_NAME_VAL_PAIR('FIELD65')
                                     .TYP_VAR_VALUE;
      DBG('[Bitmap_Ter]=>' || P_TY_ATM_TXN_REC.BITMAP_TER);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD66').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_66 := P_TBL_NAME_VAL_PAIR('FIELD66')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_66]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_66);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD67').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_67 := P_TBL_NAME_VAL_PAIR('FIELD67')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_67]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_67);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD68').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_68 := P_TBL_NAME_VAL_PAIR('FIELD68')
                                       .TYP_VAR_VALUE;

    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD69').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_69 := P_TBL_NAME_VAL_PAIR('FIELD69')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_69]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_69);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD70').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_70 := P_TBL_NAME_VAL_PAIR('FIELD70')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_70]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_70);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD71').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.MSG_NO := P_TBL_NAME_VAL_PAIR('FIELD71')
                                 .TYP_VAR_VALUE;
      DBG('[Msg_No]=>' || P_TY_ATM_TXN_REC.MSG_NO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD72').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.MSG_DATA := P_TBL_NAME_VAL_PAIR('FIELD72')
                                   .TYP_VAR_VALUE;
      DBG('[Msg_No_Last]=>' || P_TY_ATM_TXN_REC.MSG_DATA);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD73').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ACTION_DATE := P_TBL_NAME_VAL_PAIR('FIELD73')
                                      .TYP_VAR_VALUE;
      DBG('[Action_Date]=>' || P_TY_ATM_TXN_REC.ACTION_DATE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD74').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_74 := P_TBL_NAME_VAL_PAIR('FIELD74')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_74]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_74);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD75').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ISO_FEILD_75 := P_TBL_NAME_VAL_PAIR('FIELD75')
                                       .TYP_VAR_VALUE;

      DBG('[iso_feild_75]=>' || P_TY_ATM_TXN_REC.ISO_FEILD_75);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD76').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.DEBIT_NO := P_TBL_NAME_VAL_PAIR('FIELD76')
                                   .TYP_VAR_VALUE;
      DBG('[Debit_No]=>' || P_TY_ATM_TXN_REC.DEBIT_NO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD77').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.DEBIT_REV_NO := P_TBL_NAME_VAL_PAIR('FIELD77')
                                       .TYP_VAR_VALUE;
      DBG('[Debit_Rev_No]=>' || P_TY_ATM_TXN_REC.DEBIT_REV_NO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD78').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TRFR_NO := P_TBL_NAME_VAL_PAIR('FIELD78')
                                  .TYP_VAR_VALUE;
      DBG('[Trfr_No]=>' || P_TY_ATM_TXN_REC.TRFR_NO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD79').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TRFR_REV_NO := P_TBL_NAME_VAL_PAIR('FIELD79')
                                      .TYP_VAR_VALUE;
      DBG('[Trfr_Rev_No]=>' || P_TY_ATM_TXN_REC.TRFR_REV_NO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD80').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.INQ_NO := P_TBL_NAME_VAL_PAIR('FIELD80')
                                 .TYP_VAR_VALUE;
      DBG('[Inq_No]=>' || P_TY_ATM_TXN_REC.INQ_NO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD81').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.AUTH_NO := P_TBL_NAME_VAL_PAIR('FIELD81')
                                  .TYP_VAR_VALUE;
      DBG('[Auth_No]=>' || P_TY_ATM_TXN_REC.AUTH_NO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD82').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.CREDIT_PROC_FEE := P_TBL_NAME_VAL_PAIR('FIELD82')
                                          .TYP_VAR_VALUE;
      DBG('[Credit_Proc_Fee]=>' || P_TY_ATM_TXN_REC.CREDIT_PROC_FEE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD83').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.CREDIT_TXN_FEE := P_TBL_NAME_VAL_PAIR('FIELD83')
                                         .TYP_VAR_VALUE;
      DBG('[Credit_Txn_Fee]=>' || P_TY_ATM_TXN_REC.CREDIT_TXN_FEE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD84').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.DEBIT_PROC_FEE := P_TBL_NAME_VAL_PAIR('FIELD84')
                                         .TYP_VAR_VALUE;
      DBG('[Debit_Proc_Fee]=>' || P_TY_ATM_TXN_REC.DEBIT_PROC_FEE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD85').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.DEBIT_TXN_FEE := P_TBL_NAME_VAL_PAIR('FIELD85')
                                        .TYP_VAR_VALUE;
      DBG('[Debit_Txn_Fee]=>' || P_TY_ATM_TXN_REC.DEBIT_TXN_FEE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD86').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.CREDIT_AMT := P_TBL_NAME_VAL_PAIR('FIELD86')
                                     .TYP_VAR_VALUE;
      DBG('[Credit_Amt]=>' || P_TY_ATM_TXN_REC.CREDIT_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD87').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.CREDIT_REV_AMT := P_TBL_NAME_VAL_PAIR('FIELD87')
                                         .TYP_VAR_VALUE;
      DBG('[Credit_Rev_Amt]=>' || P_TY_ATM_TXN_REC.CREDIT_REV_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD88').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.DEBIT_AMT := P_TBL_NAME_VAL_PAIR('FIELD88')
                                    .TYP_VAR_VALUE;
      DBG('[Debit_Amt]=>' || P_TY_ATM_TXN_REC.DEBIT_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD89').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.DEBIT_REV_AMT := P_TBL_NAME_VAL_PAIR('FIELD89')
                                        .TYP_VAR_VALUE;
      DBG('[Debit_Rev_Amt]=>' || P_TY_ATM_TXN_REC.DEBIT_REV_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD90').TYP_VAR_VALUE IS NOT NULL THEN
      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = 0 THEN
        P_TY_ATM_TXN_REC.ORG_DATA := P_TBL_NAME_VAL_PAIR('FIELD90')
                                     .TYP_VAR_VALUE;
        DBG('[Org_Data]=>' || P_TY_ATM_TXN_REC.ORG_DATA);
      END IF;
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD91').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.FILE_UPLD_CODE := P_TBL_NAME_VAL_PAIR('FIELD91')
                                         .TYP_VAR_VALUE;
      DBG('[File_Upld_Code]=>' || P_TY_ATM_TXN_REC.FILE_UPLD_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD92').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.FILE_SEC_CODE := P_TBL_NAME_VAL_PAIR('FIELD92')
                                        .TYP_VAR_VALUE;
      DBG('[File_Sec_Code]=>' || P_TY_ATM_TXN_REC.FILE_SEC_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD93').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RESP_IND := P_TBL_NAME_VAL_PAIR('FIELD93')
                                   .TYP_VAR_VALUE;
      DBG('[Resp_Ind]=>' || P_TY_ATM_TXN_REC.RESP_IND);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD94').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.SERVICE_IND := P_TBL_NAME_VAL_PAIR('FIELD94')
                                      .TYP_VAR_VALUE;
      DBG('[Service_Ind]=>' || P_TY_ATM_TXN_REC.SERVICE_IND);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD95').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RPLACE_AMT := P_TBL_NAME_VAL_PAIR('FIELD95')
                                     .TYP_VAR_VALUE;
      DBG('[Rplace_Amt]=>' || P_TY_ATM_TXN_REC.RPLACE_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD96').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.MSG_SEC_CODE := P_TBL_NAME_VAL_PAIR('FIELD96')
                                       .TYP_VAR_VALUE;
      DBG('[Msg_Sec_Code]=>' || P_TY_ATM_TXN_REC.MSG_SEC_CODE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD97').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.NET_SETL_AMT := P_TBL_NAME_VAL_PAIR('FIELD97')
                                       .TYP_VAR_VALUE;
      DBG('[Net_Setl_Amt]=>' || P_TY_ATM_TXN_REC.NET_SETL_AMT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD98').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.PAYEE := P_TBL_NAME_VAL_PAIR('FIELD98').TYP_VAR_VALUE;
      DBG('[Payee]=>' || P_TY_ATM_TXN_REC.PAYEE);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD99').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.SETL_INST_ID := P_TBL_NAME_VAL_PAIR('FIELD99')
                                       .TYP_VAR_VALUE;
      DBG('[Setl_Inst_Id]=>' || P_TY_ATM_TXN_REC.SETL_INST_ID);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD100').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RCV_INST_ID := P_TBL_NAME_VAL_PAIR('FIELD100')
                                      .TYP_VAR_VALUE;
      DBG('[Rcv_Inst_Id]=>' || P_TY_ATM_TXN_REC.RCV_INST_ID);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD101').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.FILE_NAME := P_TBL_NAME_VAL_PAIR('FIELD101')
                                    .TYP_VAR_VALUE;
      DBG('[File_Name]=>' || P_TY_ATM_TXN_REC.FILE_NAME);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD102').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.FROM_ACC := P_TBL_NAME_VAL_PAIR('FIELD102')
                                   .TYP_VAR_VALUE;
      DBG('[From_Acc]=>' || P_TY_ATM_TXN_REC.FROM_ACC ||
          '   txn_acc_no_fcc  ' || P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);

    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD103').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TO_ACC := P_TBL_NAME_VAL_PAIR('FIELD103')
                                 .TYP_VAR_VALUE;
      DBG('[To_Acc]=>' || P_TY_ATM_TXN_REC.TO_ACC);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD104').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.TXN_DESC := P_TBL_NAME_VAL_PAIR('FIELD104')
                                   .TYP_VAR_VALUE;
      DBG('[Txn_Desc]=>' || P_TY_ATM_TXN_REC.TXN_DESC);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD105').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_105 := P_TBL_NAME_VAL_PAIR('FIELD105')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_ISO_105]=>' || P_TY_ATM_TXN_REC.RSV_ISO_105);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD106').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_106 := P_TBL_NAME_VAL_PAIR('FIELD106')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_ISO_106]=>' || P_TY_ATM_TXN_REC.RSV_ISO_106);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD107').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_107 := P_TBL_NAME_VAL_PAIR('FIELD107')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_ISO_107]=>' || P_TY_ATM_TXN_REC.RSV_ISO_107);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD108').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_108 := P_TBL_NAME_VAL_PAIR('FIELD108')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_ISO_108]=>' || P_TY_ATM_TXN_REC.RSV_ISO_108);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD109').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_109 := P_TBL_NAME_VAL_PAIR('FIELD109')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_ISO_109]=>' || P_TY_ATM_TXN_REC.RSV_ISO_109);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD110').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_110 := P_TBL_NAME_VAL_PAIR('FIELD110')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_ISO_110]=>' || P_TY_ATM_TXN_REC.RSV_ISO_110);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD111').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_ISO_111 := P_TBL_NAME_VAL_PAIR('FIELD111')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_ISO_111]=>' || P_TY_ATM_TXN_REC.RSV_ISO_111);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD112').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_112 := P_TBL_NAME_VAL_PAIR('FIELD112')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Ntl_112]=>' || P_TY_ATM_TXN_REC.RSV_NTL_112);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD113').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.AUTH_AGENT_INST_ID := P_TBL_NAME_VAL_PAIR('FIELD113')
                                             .TYP_VAR_VALUE;
      DBG('[Auth_Agent_Inst_Id]=>' || P_TY_ATM_TXN_REC.AUTH_AGENT_INST_ID);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD114').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_114 := P_TBL_NAME_VAL_PAIR('FIELD114')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Ntl_114]=>' || P_TY_ATM_TXN_REC.RSV_NTL_114);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD115').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_115 := P_TBL_NAME_VAL_PAIR('FIELD115')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Ntl_115]=>' || P_TY_ATM_TXN_REC.RSV_NTL_115);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD116').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_116 := P_TBL_NAME_VAL_PAIR('FIELD116')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Ntl_116]=>' || P_TY_ATM_TXN_REC.RSV_NTL_116);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD117').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_117 := P_TBL_NAME_VAL_PAIR('FIELD117')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Ntl_117]=>' || P_TY_ATM_TXN_REC.RSV_NTL_117);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD118').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_118 := P_TBL_NAME_VAL_PAIR('FIELD118')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Ntl_118]=>' || P_TY_ATM_TXN_REC.RSV_NTL_118);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD119').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_NTL_119 := P_TBL_NAME_VAL_PAIR('FIELD119')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Ntl_119]=>' || P_TY_ATM_TXN_REC.RSV_NTL_119);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD120').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_PVT_120 := P_TBL_NAME_VAL_PAIR('FIELD120')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Pvt_120]=>' || P_TY_ATM_TXN_REC.RSV_PVT_120);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD121').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_PVT_121 := P_TBL_NAME_VAL_PAIR('FIELD121')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Pvt_121]=>' || P_TY_ATM_TXN_REC.RSV_PVT_121);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD122').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_PVT_122 := P_TBL_NAME_VAL_PAIR('FIELD122')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Pvt_122]=>' || P_TY_ATM_TXN_REC.RSV_PVT_122);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD123').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.RSV_PVT_123 := P_TBL_NAME_VAL_PAIR('FIELD123')
                                      .TYP_VAR_VALUE;
      DBG('[Rsv_Pvt_123]=>' || P_TY_ATM_TXN_REC.RSV_PVT_123);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD124').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.INFO_TXT := P_TBL_NAME_VAL_PAIR('FIELD124')
                                   .TYP_VAR_VALUE;
      DBG('[Info_Txt]=>' || P_TY_ATM_TXN_REC.INFO_TXT);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD125').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.ADD_NET_INFO := P_TBL_NAME_VAL_PAIR('FIELD125')
                                       .TYP_VAR_VALUE;
      DBG('[Add_Net_Info]=>' || P_TY_ATM_TXN_REC.ADD_NET_INFO);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD126').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK := P_TBL_NAME_VAL_PAIR('FIELD126')
                                             .TYP_VAR_VALUE;
      P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO    := SUBSTR(P_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK,
                                                    7,
                                                    12);
      DBG('[Pre_Auth_N_Chg_Bck]=>' || P_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD127').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.MINI_STMT_DATA := P_TBL_NAME_VAL_PAIR('FIELD127')
                                         .TYP_VAR_VALUE;
      DBG('[Mini_Stmt_Data]=>' || P_TY_ATM_TXN_REC.MINI_STMT_DATA);
    END IF;
    IF P_TBL_NAME_VAL_PAIR('FIELD128').TYP_VAR_VALUE IS NOT NULL THEN
      P_TY_ATM_TXN_REC.MSG_AUTH_CODE := P_TBL_NAME_VAL_PAIR('FIELD128')
                                        .TYP_VAR_VALUE;
      DBG('[Msg_Auth_Code1]=>' || P_TY_ATM_TXN_REC.MSG_AUTH_CODE);
    END IF;

    CSPKS_REQ_GLOBAL.G_RELEASE_TYPE := CSPKS_REQ_GLOBAL.P_CUSTOM;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      IF NOT GWPKS_CREATESWTXN_CLUSTER.FN_POP_PLSQL_TBL(P_TBL_NAME_VAL_PAIR,
                                                        P_TY_ATM_TXN_REC,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT FN_BUSINESS_MAPPING(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
      DBG('E', 'fn_pop_plsql_tbl : fn_process_req returned false ');
      RETURN FALSE;
    END IF;

    DBG('Returning true from fn_pop_plsql_tbl');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('E', 'In WOT of fn_pop_plsql_tbl ' || SQLERRM);
      P_ERR_CODE  := 'SW-POP-01';
      P_ERR_PARAM := NULL;
      RETURN FALSE;

  END FN_POP_PLSQL_TBL;

  PROCEDURE PR_PROCESS_MSG(P_IS_IN_MSG_CLOB IN VARCHAR2

                          ,
                           P_REC_MSG_HEADER  IN GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                           P_IS_OUT_MSG_CLOB OUT VARCHAR2

                          ,
                           P_INSTR_REC IN OUT NOCOPY GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                           P_FLAG      IN OUT NOCOPY NUMBER,
                           P_ERR_CODE  IN OUT NOCOPY VARCHAR2,
                           P_ERR_PARAM IN OUT NOCOPY VARCHAR2) AS

    L_IS_IN_MSG_CLOB     VARCHAR2(1) := P_IS_IN_MSG_CLOB;
    L_PARENTS_LIST       VARCHAR2(32767);
    L_PARENTS_FORMAT     VARCHAR2(32767);
    L_TS_TAG_NAMES       VARCHAR2(32767);
    L_TS_TAG_VALUES      VARCHAR2(32767);
    L_TS_TAG_FORMAT      VARCHAR2(32767);
    L_TAG_NAME           VARCHAR2(32767);
    L_TAG_VALUE          VARCHAR2(32767);
    L_TS_CLOB_TAG_NAMES  CLOB;
    L_TS_CLOB_TAG_VALUES CLOB;
    L_TS_CLOB_TAG_FORMAT CLOB;
    L_IS_CLOB            VARCHAR2(1) := 'N';
    L_TY_ATM_TXN_REC     TY_ATM_TXN_REC;
    L_REC_TXN_CTRL       GWPKS_BRNTXN_CONTROL.TYP_TXN_CTRL;
    I                    INTEGER := 1;
    L_TB_NAME_VAL_PAIR   TY_RECS_TBL;
    L_CURR_TAG           VARCHAR2(255);
    L_CHANNEL            VARCHAR2(3);
    L_XREF               VARCHAR2(100);
    L_TY_ATM_NOTIF_REC   TY_ATM_NOTIF_REC;
    L_HOST_NAME          SWTBS_TERMID_BRANCH_MAPPING.ORIG_BRANCH%TYPE;
    ERROR_EXCEPTION EXCEPTION;
    NOTIF_EXCEPTION EXCEPTION;

  BEGIN

    P_FLAG := 1;
    DBG('*********************************************************************');
    DBG('                   ' || P_REC_MSG_HEADER.FUNCTIONID || ' ' ||
        P_REC_MSG_HEADER.ACTION);
    DBG('*********************************************************************');

    SELECT TO_CHAR(SYSTIMESTAMP, 'YYYY:DD:MM HH:MI:SS.FF')
      INTO G_DB_IN_TIME
      FROM DUAL;

    IF NOT GWPKSS_XML_PARSER.FN_XML_PARSER(P_REC_MSG_HEADER.SOURCE

                                          ,
                                           L_PARENTS_LIST,
                                           L_PARENTS_FORMAT,
                                           L_TS_TAG_NAMES,
                                           L_TS_TAG_VALUES,
                                           L_TS_TAG_FORMAT,
                                           L_TS_CLOB_TAG_NAMES,
                                           L_TS_CLOB_TAG_VALUES,
                                           L_TS_CLOB_TAG_FORMAT,
                                           L_IS_IN_MSG_CLOB,
                                           L_IS_CLOB,
                                           P_ERR_CODE,
                                           P_ERR_PARAM) THEN

      DBG('FAILED IN gwpks_xml_parser.fn_parse_xml');
      P_ERR_CODE  := 'SW-PRS-01';
      P_ERR_PARAM := NULL;
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      RAISE ERROR_EXCEPTION;
    END IF;
    DBG('************DONE***************************************');

    L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := P_REC_MSG_HEADER.BRANCH_CODE;
    L_TY_ATM_TXN_REC.USER_ID          := P_REC_MSG_HEADER.USER_ID;
    L_TY_ATM_TXN_REC.SOURCE           := P_REC_MSG_HEADER.SOURCE;
    G_SOURCE                          := P_REC_MSG_HEADER.SOURCE;

    IF L_TY_ATM_TXN_REC.SOURCE NOT IN ('FLEXNOTIF') THEN
      L_TS_TAG_VALUES := L_TS_TAG_VALUES || '@';

    ELSE
      L_TS_TAG_VALUES := L_TS_TAG_VALUES;
    END IF;

    DBG('l_parents_list  ' || L_PARENTS_LIST);
    DBG('l_parents_format  ' || L_PARENTS_FORMAT);
    DBG('l_ts_tag_names  ' || L_TS_TAG_NAMES);
    DBG('l_ts_tag_values  ' || L_TS_TAG_VALUES);
    DBG('l_ts_tag_format  ' || L_TS_TAG_FORMAT);
    DBG('l_is_in_msg_clob  ' || L_IS_IN_MSG_CLOB);

    DBG('l_ts_tag_names-------> ' || L_TS_TAG_NAMES);
    WHILE CSPKES_MISC.FN_GETPARAM(L_TS_TAG_NAMES, I, '>') <> 'EOPL' LOOP
      L_TAG_NAME := CSPKES_MISC.FN_GETPARAM(L_TS_TAG_NAMES, I, '>');

      IF L_TY_ATM_TXN_REC.SOURCE NOT IN ('FLEXNOTIF') THEN
        L_TAG_VALUE := CSPKES_MISC.FN_GETPARAM(L_TS_TAG_VALUES, I, '>@');

      ELSE
        L_TAG_VALUE := CSPKES_MISC.FN_GETPARAM(L_TS_TAG_VALUES, I, '>');
      END IF;

      DBG('l_tag_name [' || I || ']== > ' || L_TAG_NAME);

      DBG('l_tag_value [' || I || ']== > ' || L_TAG_VALUE);

      I := I + 1;

    END LOOP;
    I := 1;
    DBG('l_tag_name-------> ' || L_TAG_NAME);
    WHILE CSPKES_MISC.FN_GETPARAM(L_TAG_NAME, I, '~') <> 'EOPL' LOOP
      L_CURR_TAG := CSPKES_MISC.FN_GETPARAM(L_TAG_NAME, I, '~');

      L_TB_NAME_VAL_PAIR(L_CURR_TAG).TYP_VAR_VALUE := CSPKES_MISC.FN_GETPARAM(L_TAG_VALUE,
                                                                              I,
                                                                              '~');
      DBG(L_CURR_TAG || ' :) ' || L_TB_NAME_VAL_PAIR(L_CURR_TAG)
          .TYP_VAR_VALUE);
      I := I + 1;

    END LOOP;
    IF L_TY_ATM_TXN_REC.SOURCE NOT IN ('FLEXNOTIF') THEN

      L_CHANNEL := P_REC_MSG_HEADER.ADDL('CHANNEL').VALUE;

      BEGIN
        SELECT *
          INTO L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG
          FROM SWTBS_PARAM
         WHERE CHANNEL = L_CHANNEL;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Exception while selecting data from swtbs_param');
          P_ERR_CODE := 'SW-PRM-01';
          RAISE ERROR_EXCEPTION;
      END;

      IF NOT FN_POP_PLSQL_TBL(L_TB_NAME_VAL_PAIR,
                              L_TY_ATM_TXN_REC,
                              P_ERR_CODE,
                              P_ERR_PARAM) THEN
        RAISE ERROR_EXCEPTION;
      END IF;

      DBG('l_Ty_Atm_Txn_Rec.Term_Id >>' || L_TY_ATM_TXN_REC.TERM_ID);
      BEGIN
        SELECT ORIG_BRANCH
          INTO L_HOST_NAME
          FROM SWTBS_TERMID_BRANCH_MAPPING
         WHERE TERMID = L_TY_ATM_TXN_REC.TERM_ID;

        L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := L_HOST_NAME;
        GLOBAL.PR_INIT(L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE,
                       L_TY_ATM_TXN_REC.USER_ID);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
      END;
      DBG('Incoming orig branch code:' ||
          L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE);

      IF NOT
          GWPKSS_EXT_SWITCHSERVICE.FN_PRE_SWITCHTRANSACTION(P_REC_MSG_HEADER,
                                                            P_INSTR_REC,
                                                            L_TY_ATM_TXN_REC,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
        DBG('Function gwpkss_ext_switchservice.fn_pre_switchTransaction returned FALSE');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        RAISE ERROR_EXCEPTION;
      END IF;

      DBG('Calling the function fn_ts_to_type  ');

      L_TY_ATM_TXN_REC.TY_PROCESSING_INSTRUCTIONS := P_INSTR_REC;
      L_TY_ATM_TXN_REC.TY_BIZ_PROCESS_HEADER      := P_REC_MSG_HEADER;

      SAVEPOINT SP_SWITCH;

      IF NOT FN_PROCESS_REQ(L_TY_ATM_TXN_REC, 'N', P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E',
            'Gwpks_CreateSWTransaction : fn_process_req returned false ');
        ROLLBACK TO SP_SWITCH;
        RAISE ERROR_EXCEPTION;
      END IF;

      OVPKS.PR_APPENDTBL('GW-SAV-01', NULL);
      L_REC_TXN_CTRL.PROCESS_STATUS := 'S';
      P_ERR_CODE                    := 'SW-SUC-01';
      P_ERR_PARAM                   := NULL;

      IF NOT
          GWPKSS_EXT_SWITCHSERVICE.FN_POST_SWITCHTRANSACTION(P_REC_MSG_HEADER,
                                                             P_INSTR_REC,
                                                             L_TY_ATM_TXN_REC,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
        DBG('Function gwpkss_ext_switchservice.fn_post_switchTransaction returned FALSE');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        RAISE ERROR_EXCEPTION;
      END IF;

      DBG('Calling gwpkss_xml_crtr.fn_xml_creator');

      IF NOT FN_BUILD_ATM_REPLY_XML(L_TY_ATM_TXN_REC,
                                    L_TS_TAG_VALUES,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
        DBG('E', 'FAILED IN fn_build_atm_reply_xml');
        P_ERR_CODE := 'SW-REP-01';
        RAISE ERROR_EXCEPTION;
      END IF;

    ELSE

      DBG('Code for Notification');

      L_XREF := L_TAG_VALUE;
      L_XREF := SUBSTR(L_XREF, 1, LENGTH(L_XREF) - 1);

      L_TY_ATM_TXN_REC.TY_PROCESSING_INSTRUCTIONS := P_INSTR_REC;
      L_TY_ATM_TXN_REC.TY_BIZ_PROCESS_HEADER      := P_REC_MSG_HEADER;

      IF NOT FN_GET_ATM_NOTIF_DATA(L_XREF,
                                   L_TY_ATM_NOTIF_REC,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
        DBG('E', 'FAILED IN Fn_Build_Atm_Notif_Xml');
        P_ERR_CODE := 'SW-NOT-03';
        RAISE NOTIF_EXCEPTION;
      END IF;

      IF NOT FN_BUILD_ATM_NOTIF_XML(L_TY_ATM_NOTIF_REC,
                                    L_PARENTS_LIST,
                                    L_PARENTS_FORMAT,
                                    L_TS_TAG_NAMES,
                                    L_TS_TAG_VALUES,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
        DBG('E', 'FAILED IN Fn_Build_Atm_Notif_Xml');
        P_ERR_CODE := 'SW-NOT-02';
        RAISE NOTIF_EXCEPTION;
      END IF;
      L_REC_TXN_CTRL.PROCESS_STATUS := 'S';

    END IF;

    IF NOT GWPKSS_XML_CRTR.FN_XML_CREATOR(L_TY_ATM_TXN_REC.TY_BIZ_PROCESS_HEADER,
                                          L_TY_ATM_TXN_REC.TY_PROCESSING_INSTRUCTIONS

                                         ,
                                          L_IS_IN_MSG_CLOB,
                                          L_PARENTS_LIST,
                                          L_PARENTS_FORMAT,
                                          L_TS_TAG_NAMES,
                                          L_TS_TAG_VALUES,
                                          L_TS_TAG_FORMAT,
                                          L_TS_CLOB_TAG_NAMES,
                                          L_TS_CLOB_TAG_VALUES,
                                          L_TS_CLOB_TAG_FORMAT,
                                          L_REC_TXN_CTRL.PROCESS_STATUS

                                         ,
                                          P_IS_OUT_MSG_CLOB) THEN
      DBG('E', 'FAILED IN gwpkss_xml_crtr.fn_create_xml');
      RAISE ERROR_EXCEPTION;
    END IF;

    IF SUBSTR(L_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) <> '4' AND
       SUBSTR(L_TY_ATM_TXN_REC.MSG_TYPE, 3, 1) <> '2' THEN
      IF NOT
          FN_CHECK_FOR_REVERSAL(L_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('FAILED IN fn_check_for_reversal');
        RAISE ERROR_EXCEPTION;
      END IF;
    END IF;
    P_FLAG := 0;

    DBG('Succcessfully Returned from Function Handler  ');

    P_ERR_CODE := NULL;

    RETURN;

  EXCEPTION
    WHEN ERROR_EXCEPTION THEN
      DBG('Inside error exception 1 ' || SQLERRM);

      IF NOT FN_BUILD_ATM_REPLY_XML(L_TY_ATM_TXN_REC,
                                    L_TS_TAG_VALUES,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
        DBG('FAILED IN fn_build_atm_reply_xml');
        P_ERR_CODE := 'SW-REP-01';
        RAISE ERROR_EXCEPTION;
      END IF;

    WHEN NOTIF_EXCEPTION THEN

      DBG('Inside Notif exception 1 ' || SQLERRM);

      IF NOT FN_BUILD_ATM_NOTIF_XML(L_TY_ATM_NOTIF_REC,
                                    L_PARENTS_LIST,
                                    L_PARENTS_FORMAT,
                                    L_TS_TAG_NAMES,
                                    L_TS_TAG_VALUES,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
        DBG('E', 'FAILED IN Fn_Build_Atm_Notif_Xml');
        P_ERR_CODE := 'SW-NOT-02';
      END IF;

      IF NOT GWPKSS_XML_CRTR.FN_XML_CREATOR(P_REC_MSG_HEADER,
                                            P_INSTR_REC

                                           ,
                                            P_IS_IN_MSG_CLOB,
                                            L_PARENTS_LIST,
                                            L_PARENTS_FORMAT,
                                            L_TS_TAG_NAMES,
                                            L_TS_TAG_VALUES,
                                            L_TS_TAG_FORMAT,
                                            L_TS_CLOB_TAG_NAMES,
                                            L_TS_CLOB_TAG_VALUES,
                                            L_TS_CLOB_TAG_FORMAT,
                                            'F'

                                           ,
                                            P_IS_OUT_MSG_CLOB) THEN
        DBG('E', 'Failed in gwpkss_xml_crtr.fn_xml_creator ');
      END IF;
      P_FLAG     := -1;
      P_ERR_CODE := NULL;
      RETURN;
    WHEN OTHERS THEN
      DBG('E', 'Inside error exception 2 ' || SQLERRM);
      OVPKSS.PR_APPENDTBL('SW-OTH-01', SQLERRM || '~');
      L_REC_TXN_CTRL.TY_GWTB_TXN_LOG.RESPSTAT := 'F';
      L_REC_TXN_CTRL.TY_GWTB_TXN_LOG.CURRSTAT := 'X';

      IF L_TY_ATM_TXN_REC.SOURCE NOT IN ('FLEXNOTIF') THEN
        IF NOT FN_BUILD_ATM_REPLY_XML(L_TY_ATM_TXN_REC,
                                      L_TS_TAG_VALUES,
                                      P_ERR_CODE,
                                      P_ERR_PARAM) THEN
          DBG('E', 'FAILED IN fn_build_atm_reply_xml');
          P_ERR_CODE := 'SW-REP-01';
        END IF;

      ELSE

        IF NOT FN_BUILD_ATM_NOTIF_XML(L_TY_ATM_NOTIF_REC,
                                      L_PARENTS_LIST,
                                      L_PARENTS_FORMAT,
                                      L_TS_TAG_NAMES,
                                      L_TS_TAG_VALUES,
                                      P_ERR_CODE,
                                      P_ERR_PARAM) THEN
          DBG('E', 'FAILED IN Fn_Build_Atm_Notif_Xml');
          P_ERR_CODE := 'SW-NOT-02';
        END IF;
      END IF;

      IF NOT GWPKSS_XML_CRTR.FN_XML_CREATOR(P_REC_MSG_HEADER,
                                            P_INSTR_REC

                                           ,
                                            P_IS_IN_MSG_CLOB,
                                            L_PARENTS_LIST,
                                            L_PARENTS_FORMAT,
                                            L_TS_TAG_NAMES,
                                            L_TS_TAG_VALUES,
                                            L_TS_TAG_FORMAT,
                                            L_TS_CLOB_TAG_NAMES,
                                            L_TS_CLOB_TAG_VALUES,
                                            L_TS_CLOB_TAG_FORMAT,
                                            'F'

                                           ,
                                            P_IS_OUT_MSG_CLOB) THEN
        DBG('E', 'Failed in gwpkss_xml_crtr.fn_create_fcjxml ');
      END IF;

      P_FLAG := -1;
      RETURN;
  END PR_PROCESS_MSG;

  FUNCTION FN_CCY_TRANS(P_ISO_TXN_CCY IN OUT NOCOPY VARCHAR2,
                        P_TXN_CCY     OUT VARCHAR2,
                        P_CCY_MINOR   OUT NUMBER,
                        P_ERRCODE     IN OUT NOCOPY VARCHAR2) RETURN BOOLEAN IS
    L_ERRORPARAMS VARCHAR2(1000);

  BEGIN

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling gwpks_ext_switchservice.FN_PRE_CCY_TRANS ');
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_PRE_CCY_TRANS(P_ISO_TXN_CCY,
                                                      P_TXN_CCY,
                                                      P_CCY_MINOR,
                                                      P_ERRCODE) THEN
        DBG('gwpks_ext_switchservice.FN_PRE_CCY_TRANS has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('fn_ccy_trans : gwpk_createATM.fn_ccy_trans ' || '~' ||
          P_ISO_TXN_CCY || '~' || P_TXN_CCY);

      IF NOT SWPKSS_UTILS.FN_GET_ISO_CCY_DEFN_WRP_REC(P_ISO_TXN_CCY,
                                                      P_ERRCODE,
                                                      L_ERRORPARAMS) THEN
        DBG('E',
            'After calling frc fn_ccy_trans : No Data Found in cytms_ccy_defn ' ||
            P_ERRCODE);
        P_ERRCODE := 'SW-CCY-01';
        RETURN FALSE;
      ELSE
        P_TXN_CCY   := SWPKSS_UTILS.G_TBL_ISO_CYTM_CCY_DEFN_REC.CCY_CODE;
        P_CCY_MINOR := SWPKSS_UTILS.G_TBL_ISO_CYTM_CCY_DEFN_REC.CCY_DECIMALS;
      END IF;

      DBG('fn_ccy_trans : Exit out of Gwpks_CreateSWTransaction.fn_ccy_trans ' || '~' ||
          P_ISO_TXN_CCY || '~' || P_TXN_CCY);

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('E',
          'fn_ccy_trans : No Data Found in cytms_ccy_defn ' || P_ERRCODE);
      P_ERRCODE := 'SW-CCY-01';
      RETURN FALSE;
  END FN_CCY_TRANS;

  FUNCTION FN_CNTY_TRANS(P_ISO_TXN_CNTY IN VARCHAR2,
                         P_TXN_CNTY     IN OUT NOCOPY VARCHAR2,
                         P_ERRCODE      IN OUT NOCOPY VARCHAR2,
                         P_ERR_PARAM    IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('fn_cnty_trans :  ' || '~' || P_ISO_TXN_CNTY || '~' || P_TXN_CNTY);

    SELECT COUNTRY_CODE
      INTO P_TXN_CNTY
      FROM STTMS_COUNTRY
     WHERE ISO_NUM_COUNTRY_CODE = P_ISO_TXN_CNTY
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';

    DBG('fn_cnty_trans : Exit  ' || '~' || P_ISO_TXN_CNTY || '~' ||
        P_TXN_CNTY);
    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERRCODE   := 'SW-CTY-01';
      P_ERR_PARAM := P_ISO_TXN_CNTY;
      DBG('E',
          'fn_ccy_trans : No Data Found in STTM_COUNTRY ' || P_ERRCODE);
      RETURN FALSE;
  END FN_CNTY_TRANS;

  FUNCTION FN_BUILD_ATM_REPLY_XML(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                                  P_TS_TAG_VALUES  IN OUT VARCHAR2,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_LAST_MSG_TYPE_DIGIT INTEGER := 0;
  BEGIN

    DBG('inside fn_build_atm_reply_xml');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      G_FN_CALL_ID := 2;
      IF NOT GWPKSS_EXT_SWITCHSERVICE.FN_POST_UPDATE_RESP(P_TY_ATM_TXN_REC,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM,
                                                          G_FN_CALL_ID) THEN
        DBG('Function gwpkss_ext_switchservice.Fn_Post_Update_Resp returned FALSE');
        P_ERR_PARAM := P_ERR_CODE;
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF NOT FN_MAP_ERR_RESPCODE(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('FAILED IN fn_map_err_respcode');
        P_ERR_CODE  := 'SW-ERR-01';
        P_ERR_PARAM := 'fn_build_atm_reply_xml' || '~' || P_ERR_CODE;
        RETURN FALSE;
      END IF;

      IF NOT FN_UPDATE_RESP(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling Gwpks_CreateSWTransaction.fn_update_resp' ||
            P_ERR_CODE);
        P_ERR_PARAM := P_ERR_CODE;
        RETURN FALSE;
      END IF;

      DBG('ip_ty_atm_txn_rec.offus_onus>>' || P_TY_ATM_TXN_REC.OFFUS_ONUS ||
          ' Txn type is non financial>>' ||
          P_TY_ATM_TXN_REC.CHARGE_NON_FIN_TXN || ' with response code>>' ||
          P_TY_ATM_TXN_REC.RESP_CODE);
      IF P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' AND
         P_TY_ATM_TXN_REC.CHARGE_NON_FIN_TXN = 'N' AND
         P_TY_ATM_TXN_REC.RESP_CODE NOT IN ('00', '000', '0000')

       THEN
        IF NOT SWPKSS_QUERYBALANCE.FN_MAIN(P_TY_ATM_TXN_REC,
                                           P_ERR_CODE,
                                           P_ERR_PARAM) THEN
          DBG('E',
              'Failed while calling swpkss_querybalance.fn_main' ||
              P_ERR_CODE);
        END IF;

      END IF;

      DBG('Calling gwpkss_xml_crtr.fn_xml_creator');

      P_TY_ATM_TXN_REC.ACCEPT_ADDR := REPLACE(P_TY_ATM_TXN_REC.ACCEPT_ADDR,
                                              '>',
                                              CHR(38) || 'gt' || CHR(38));

      IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
        IF NOT GWPKS_EXT_SWITCHSERVICE.FN_REASSIGN_FIELD(P_TY_ATM_TXN_REC,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAM) THEN
          DBG('E', 'gwpks_ext_switchservice.Fn_MiniStat returned false ');
          RETURN FALSE;
        END IF;
      END IF;

      IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = 8 THEN
        L_LAST_MSG_TYPE_DIGIT := SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 4, 1);
      END IF;

      P_TS_TAG_VALUES := P_TY_ATM_TXN_REC.HEDDER || '~' ||
                         (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 2) ||
                         TO_CHAR(TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE,
                                                   3,
                                                   1)) + 1) ||

                         L_LAST_MSG_TYPE_DIGIT) || '~' ||

                         P_TY_ATM_TXN_REC.PAN || '~' ||
                         P_TY_ATM_TXN_REC.PROC_CODE || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_04 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_05 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_06 || '~' ||
                         P_TY_ATM_TXN_REC.TRANS_DT_TIME || '~' ||
                         P_TY_ATM_TXN_REC.BILL_FEE_AMT || '~' ||
                         P_TY_ATM_TXN_REC.SETL_X_RATE || '~' ||
                         P_TY_ATM_TXN_REC.BILL_X_RATE || '~' ||
                         P_TY_ATM_TXN_REC.STAN || '~' ||
                         P_TY_ATM_TXN_REC.LOCAL_TXN_TIME || '~' ||
                         P_TY_ATM_TXN_REC.LOCAL_TXN_DT || '~' ||
                         P_TY_ATM_TXN_REC.EXP_DATE || '~' ||
                         P_TY_ATM_TXN_REC.SETL_DATE || '~' ||
                         P_TY_ATM_TXN_REC.CONV_DATE || '~' ||
                         P_TY_ATM_TXN_REC.CAPT_DATE || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_18 || '~' ||
                         P_TY_ATM_TXN_REC.ACQ_INST_CTRY || '~' ||
                         P_TY_ATM_TXN_REC.PAN_EXT_CTRY || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_21 || '~' ||
                         P_TY_ATM_TXN_REC.POS_ENT_MOD || '~' ||
                         P_TY_ATM_TXN_REC.APPL_PAN || '~' ||
                         P_TY_ATM_TXN_REC.NET_INT_ID || '~' ||
                         P_TY_ATM_TXN_REC.POS_COND_CODE || '~' ||
                         P_TY_ATM_TXN_REC.POS_CAPT_CODE || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_27 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_28 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_29 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_30 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_31 || '~' ||
                         P_TY_ATM_TXN_REC.ACQ_INS_ID || '~' ||
                         P_TY_ATM_TXN_REC.FWD_INS_ID || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_34 || '~' ||
                         P_TY_ATM_TXN_REC.TRK_2_DATA || '~' ||
                         P_TY_ATM_TXN_REC.TRK_3_DATA || '~' ||
                         P_TY_ATM_TXN_REC.RRN || '~' ||
                         P_TY_ATM_TXN_REC.AUTH_CODE || '~' ||
                         P_TY_ATM_TXN_REC.RESP_CODE || '~' ||
                         P_TY_ATM_TXN_REC.SERV_REST_CODE || '~' ||
                         P_TY_ATM_TXN_REC.TERM_ID || '~' ||
                         P_TY_ATM_TXN_REC.ACCEPT_ID_CODE || '~' ||
                         P_TY_ATM_TXN_REC.ACCEPT_ADDR || '~' ||
                         P_TY_ATM_TXN_REC.ADD_RESP_DATA || '~' ||
                         P_TY_ATM_TXN_REC.TRK_1_DATA || '~' ||
                         P_TY_ATM_TXN_REC.ADD_ISO_46 || '~' ||
                         P_TY_ATM_TXN_REC.ADD_NTL_47 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_48 || '~' ||
                         P_TY_ATM_TXN_REC.VERIFY_DATA || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_50 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_51 || '~' ||
                         P_TY_ATM_TXN_REC.PIN_NO || '~' ||
                         P_TY_ATM_TXN_REC.SEC_INFO || '~' ||
                         P_TY_ATM_TXN_REC.ADD_AMT || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_55 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_56 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_57 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_58 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_59 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_60 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_PVT_61 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_PVT_62 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_PVT_63 || '~' ||
                         P_TY_ATM_TXN_REC.MAC_CHK_CODE || '~' ||
                         P_TY_ATM_TXN_REC.BITMAP_TER || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_66 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_67 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_68 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_69 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_70 || '~' ||
                         P_TY_ATM_TXN_REC.MSG_NO || '~' ||
                         P_TY_ATM_TXN_REC.MSG_DATA || '~' ||
                         P_TY_ATM_TXN_REC.ACTION_DATE || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_74 || '~' ||
                         P_TY_ATM_TXN_REC.ISO_FEILD_75 || '~' ||
                         P_TY_ATM_TXN_REC.DEBIT_NO || '~' ||
                         P_TY_ATM_TXN_REC.DEBIT_REV_NO || '~' ||
                         P_TY_ATM_TXN_REC.TRFR_NO || '~' ||
                         P_TY_ATM_TXN_REC.TRFR_REV_NO || '~' ||
                         P_TY_ATM_TXN_REC.INQ_NO || '~' ||
                         P_TY_ATM_TXN_REC.AUTH_NO || '~' ||
                         P_TY_ATM_TXN_REC.CREDIT_PROC_FEE || '~' ||
                         P_TY_ATM_TXN_REC.CREDIT_TXN_FEE || '~' ||
                         P_TY_ATM_TXN_REC.DEBIT_PROC_FEE || '~' ||
                         P_TY_ATM_TXN_REC.DEBIT_TXN_FEE || '~' ||
                         P_TY_ATM_TXN_REC.CREDIT_AMT || '~' ||
                         P_TY_ATM_TXN_REC.CREDIT_REV_AMT || '~' ||
                         P_TY_ATM_TXN_REC.DEBIT_AMT || '~' ||
                         P_TY_ATM_TXN_REC.DEBIT_REV_AMT || '~' ||
                         P_TY_ATM_TXN_REC.ORG_DATA || '~' ||
                         P_TY_ATM_TXN_REC.FILE_UPLD_CODE || '~' ||
                         P_TY_ATM_TXN_REC.FILE_SEC_CODE || '~' ||
                         P_TY_ATM_TXN_REC.RESP_IND || '~' ||
                         P_TY_ATM_TXN_REC.SERVICE_IND || '~' ||
                         P_TY_ATM_TXN_REC.RPLACE_AMT || '~' ||
                         P_TY_ATM_TXN_REC.MSG_SEC_CODE || '~' ||
                         P_TY_ATM_TXN_REC.NET_SETL_AMT || '~' ||
                         P_TY_ATM_TXN_REC.PAYEE || '~' ||
                         P_TY_ATM_TXN_REC.SETL_INST_ID || '~' ||
                         P_TY_ATM_TXN_REC.RCV_INST_ID || '~' ||
                         P_TY_ATM_TXN_REC.FILE_NAME || '~' ||
                         P_TY_ATM_TXN_REC.FROM_ACC || '~' ||
                         P_TY_ATM_TXN_REC.TO_ACC || '~' ||
                         P_TY_ATM_TXN_REC.TXN_DESC || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_105 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_106 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_107 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_108 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_109 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_110 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_ISO_111 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_112 || '~' ||
                         P_TY_ATM_TXN_REC.AUTH_AGENT_INST_ID || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_114 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_115 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_116 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_117 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_118 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_NTL_119 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_PVT_120 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_PVT_121 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_PVT_122 || '~' ||
                         P_TY_ATM_TXN_REC.RSV_PVT_123 || '~' ||
                         P_TY_ATM_TXN_REC.INFO_TXT || '~' ||
                         P_TY_ATM_TXN_REC.ADD_NET_INFO || '~' ||
                         P_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK || '~' ||
                         P_TY_ATM_TXN_REC.MINI_STMT_DATA || '~' ||
                         P_TY_ATM_TXN_REC.MSG_AUTH_CODE || '~>';

      SWPKS_DEGSWTXN_KERNEL.G_FLD_TAG_VALUE := P_TS_TAG_VALUES;
      SWPKS_DEGSWTXN_KERNEL.G_KEY           := P_TY_ATM_TXN_REC.P_KEY;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    RETURN TRUE;

  EXCEPTION

    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-CON-01';
      P_ERR_PARAM := 'fn_build_atm_reply_xml' || P_ERR_CODE;
      DBG('E',
          'fn_build_atm_reply_xml : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;

  END FN_BUILD_ATM_REPLY_XML;

  FUNCTION FN_AMT_CHG_DERIVE_NEW(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                                 P_ERR_CODE       IN OUT NOCOPY VARCHAR2,
                                 P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN AS

  BEGIN
    DBG('Inside fn_amt_chg_derive_new');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT
          GWPKSS_EXT_SWITCHSERVICE.FN_PRE_AMT_CHG_DERIVE_NEW(P_TY_ATM_TXN_REC,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
        DBG('Function gwpkss_ext_switchservice.fn_pre_amt_chg_derive_new returned FALSE');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF P_TY_ATM_TXN_REC.TXN_AMT IS NULL THEN
        P_TY_ATM_TXN_REC.TXN_AMT := '0';
      END IF;
      DBG('p_ty_atm_txn_rec.setl_amt -> ' || P_TY_ATM_TXN_REC.SETL_AMT);
      DBG('p_ty_atm_txn_rec.bill_amt -> ' || P_TY_ATM_TXN_REC.BILL_AMT);
      IF P_TY_ATM_TXN_REC.SETL_AMT IS NULL AND
         P_TY_ATM_TXN_REC.BILL_AMT IS NULL THEN

        DBG('p_Ty_Atm_Txn_Rec.Txn_Amt--< ' || P_TY_ATM_TXN_REC.TXN_AMT);
        DBG('p_Ty_Atm_Txn_Rec.Txn_Ccy_Minor--< ' ||
            P_TY_ATM_TXN_REC.TXN_CCY_MINOR);

        DBG('P_TY_ATM_TXN_REC.TXN_AMT=' || P_TY_ATM_TXN_REC.TXN_AMT);
        DBG('LENGTH(P_TY_ATM_TXN_REC.TXN_AMT)=' ||
            LENGTH(P_TY_ATM_TXN_REC.TXN_AMT));
        DBG('P_TY_ATM_TXN_REC.TXN_CCY_MINOR=' ||
            P_TY_ATM_TXN_REC.TXN_CCY_MINOR);
        P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                             1,
                                                             LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) -
                                                             P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                      SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                             LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) + 1 -
                                                             P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                             P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

        DBG('p_ty_atm_txn_rec.txn_amt_derived==>' ||
            P_TY_ATM_TXN_REC.TXN_AMT_DERIVED);

        IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('42') AND
           P_TY_ATM_TXN_REC.OFFUS_ONUS IN ('F') THEN
          NULL;
        ELSE
          --IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN ('42') AND
          -- P_TY_ATM_TXN_REC.OFFUS_ONUS NOT IN ('F')  THEN --sampath added to skip acquirer fee for credit payment and them on us for css txns
        IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN

          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                      1,
                                                                      LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) -
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                               SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                      LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) + 1 -
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

          DBG('p_ty_atm_txn_rec.tbl_chgdets(1) .chg_amt==>' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
              .CHG_AMT);
        END IF;
        END IF; --sampath added to skip acquirer fee for credit payment and them on us for css txns

        IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN ('42') AND
           P_TY_ATM_TXN_REC.OFFUS_ONUS NOT IN ('F') THEN
          --sampath added to skip issuer fee for credit payment and them on us for css txns
        IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN

          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                      1,
                                                                      LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) -
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                               SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                      LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 -
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                      P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

          DBG('p_ty_atm_txn_rec.tbl_chgdets(2) .chg_amt==>' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
              .CHG_AMT);
        END IF;
        END IF; --sampath added for CSS

        --sampath starts added for CSS beneficiary fee
        DBG('P_TY_ATM_TXN_REC.RSV_60 =' || P_TY_ATM_TXN_REC.RSV_60);
        DBG('SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2)=' ||
            SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2));
        DBG('P_TY_ATM_TXN_REC.TXN_BEN_FEE=' ||
            P_TY_ATM_TXN_REC.TXN_BEN_FEE);

        IF P_TY_ATM_TXN_REC.RSV_60 = 'CSS' OR
           SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('41', '42') THEN
          --sampath added OR as CSS value not coming in field 60 for us on us fund transfer for css txns
          IF P_TY_ATM_TXN_REC.TXN_BEN_FEE IS NOT NULL THEN

            DBG('INSIDE CHARGE3');

            P_TY_ATM_TXN_REC.TBL_CHGDETS(3).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_BEN_FEE,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_BEN_FEE) -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.TXN_BEN_FEE,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_BEN_FEE) + 1 -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

            DBG('p_ty_atm_txn_rec.tbl_chgdets(3) .chg_amt==>' || P_TY_ATM_TXN_REC.TBL_CHGDETS(3)
                .CHG_AMT);
          END IF;
        END IF;
        --sampath ends added for CSS beneficiary fee

        P_TY_ATM_TXN_REC.TXN_CCY_DERIVED := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

        --sampath starts for css
        IF P_TY_ATM_TXN_REC.RSV_60 = 'CSS' OR
           SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('41', '42') THEN
          --sampath added OR as CSS value not coming in field 60 for us on us fund transfer for css txns
          P_TY_ATM_TXN_REC.TBL_CHGDETS(3).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(3).COD_CHG_DESC := 'TXN_BEN_FEE';
        END IF;
        --sampath ends for css

        --sampath starts for credit card withdrawal us on us in case of KHR txn ccy
        DBG('THIRD CURRENCY=' || P_TY_ATM_TXN_REC.SETL_FEE_CCY_FCC);
        IF P_TY_ATM_TXN_REC.RSV_60 = 'CCONUS' THEN
          IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) - 2) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) + 1 - 2,
                                                                        2));

            DBG('p_ty_atm_txn_rec.tbl_chgdets(1) .chg_amt==>' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
                .CHG_AMT);
          END IF;
          IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) - 2) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 - 2,
                                                                        2));

            DBG('p_ty_atm_txn_rec.tbl_chgdets(2) .chg_amt==>' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
                .CHG_AMT);
          END IF;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_FEE_CCY_FCC; --Not Required
          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_PROC_FEE_CCY_FCC;
        END IF;
        --sampath ends for credit card withdrawal us on us in case of KHR txn ccy
      ELSIF P_TY_ATM_TXN_REC.BILL_AMT IS NULL THEN
        DBG('p_ty_atm_txn_rec.offus_onus -> ' ||
            P_TY_ATM_TXN_REC.OFFUS_ONUS);

        IF P_TY_ATM_TXN_REC.OFFUS_ONUS IN ('O', 'R')

         THEN

          P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                               1,
                                                               LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) -
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                        SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                               LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) + 1 -
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

          P_TY_ATM_TXN_REC.SETL_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_AMT,
                                                                1,
                                                                LENGTH(P_TY_ATM_TXN_REC.SETL_AMT) -
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                         SUBSTR(P_TY_ATM_TXN_REC.SETL_AMT,
                                                                LENGTH(P_TY_ATM_TXN_REC.SETL_AMT) + 1 -
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR));

          IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN

            IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN

              P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                          1,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) -
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                   SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) + 1 -
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

            END IF;
            IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN

              P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                          1,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) -
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                   SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 -
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

            END IF;

            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          ELSE
            DBG('Calculating Settlement Fees');
            IF P_TY_ATM_TXN_REC.SETL_FEE_AMT IS NOT NULL THEN
              P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_FEE_AMT,
                                                                          1,
                                                                          LENGTH(P_TY_ATM_TXN_REC.SETL_FEE_AMT) -
                                                                          P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                                   SUBSTR(P_TY_ATM_TXN_REC.SETL_FEE_AMT,
                                                                          LENGTH(P_TY_ATM_TXN_REC.SETL_FEE_AMT) + 1 -
                                                                          P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                          P_TY_ATM_TXN_REC.SETL_CCY_MINOR));
              DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(1).Chg_Amt -> ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
                  .CHG_AMT);
            END IF;
            IF P_TY_ATM_TXN_REC.SETL_PROC_FEE IS NOT NULL THEN
              P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_PROC_FEE,
                                                                          1,
                                                                          LENGTH(P_TY_ATM_TXN_REC.SETL_PROC_FEE) -
                                                                          P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                                   SUBSTR(P_TY_ATM_TXN_REC.SETL_PROC_FEE,
                                                                          LENGTH(P_TY_ATM_TXN_REC.SETL_PROC_FEE) + 1 -
                                                                          P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                          P_TY_ATM_TXN_REC.SETL_CCY_MINOR));
              DBG('p_Ty_Atm_Txn_Rec.Tbl_Chgdets(2).Chg_Amt -> ' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
                  .CHG_AMT);
            END IF;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
          END IF;

          P_TY_ATM_TXN_REC.TXN_CCY_DERIVED  := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.SETL_CCY_DERIVED := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

        ELSE
          DBG('------------1');
          DBG('p_ty_atm_txn_rec.txn_amt -> ' || P_TY_ATM_TXN_REC.TXN_AMT);
          DBG('p_ty_atm_txn_rec.txn_ccy_minor -> ' ||
              P_TY_ATM_TXN_REC.TXN_CCY_MINOR);

          P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                               1,
                                                               LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) -
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                        SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                               LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) + 1 -
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

          DBG('------------2');
          DBG('p_ty_atm_txn_rec.setl_amt -> ' || P_TY_ATM_TXN_REC.SETL_AMT);
          DBG('p_ty_atm_txn_rec.setl_ccy_minor -> ' ||
              P_TY_ATM_TXN_REC.SETL_CCY_MINOR);

          P_TY_ATM_TXN_REC.SETL_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_AMT,
                                                                1,
                                                                LENGTH(P_TY_ATM_TXN_REC.SETL_AMT) -
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                         SUBSTR(P_TY_ATM_TXN_REC.SETL_AMT,
                                                                LENGTH(P_TY_ATM_TXN_REC.SETL_AMT) + 1 -
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR));

          IF P_TY_ATM_TXN_REC.SETL_FEE_AMT IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_FEE_AMT,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.SETL_FEE_AMT) -
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.SETL_FEE_AMT,
                                                                        LENGTH(P_TY_ATM_TXN_REC.SETL_FEE_AMT) + 1 -
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR));

          END IF;
          DBG('------------4');
          DBG('p_ty_atm_txn_rec.setl_proc_fee -> ' ||
              P_TY_ATM_TXN_REC.SETL_PROC_FEE);
          DBG('p_ty_atm_txn_rec.setl_ccy_minor -> ' ||
              P_TY_ATM_TXN_REC.SETL_CCY_MINOR);
          IF P_TY_ATM_TXN_REC.SETL_PROC_FEE IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_PROC_FEE,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.SETL_PROC_FEE) -
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.SETL_PROC_FEE,
                                                                        LENGTH(P_TY_ATM_TXN_REC.SETL_PROC_FEE) + 1 -
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR));

          END IF;

          P_TY_ATM_TXN_REC.TXN_CCY_DERIVED  := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.SETL_CCY_DERIVED := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

        END IF;

      ELSE

        IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN

          P_TY_ATM_TXN_REC.SETL_AMT_DERIVED := NULL;
          P_TY_ATM_TXN_REC.SETL_CCY_DERIVED := NULL;

          P_TY_ATM_TXN_REC.TXN_AMT := NVL(P_TY_ATM_TXN_REC.TXN_AMT, 0);
          DBG('p_ty_atm_txn_rec.txn_amt -> ' || P_TY_ATM_TXN_REC.TXN_AMT);

          P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                               1,
                                                               LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) -
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                        SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                               LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) + 1 -
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

          P_TY_ATM_TXN_REC.BILL_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.BILL_AMT,
                                                                1,
                                                                LENGTH(P_TY_ATM_TXN_REC.BILL_AMT) -
                                                                P_TY_ATM_TXN_REC.BILL_CCY_MINOR) || '.' ||
                                                         SUBSTR(P_TY_ATM_TXN_REC.BILL_AMT,
                                                                LENGTH(P_TY_ATM_TXN_REC.BILL_AMT) + 1 -
                                                                P_TY_ATM_TXN_REC.BILL_CCY_MINOR,
                                                                P_TY_ATM_TXN_REC.BILL_CCY_MINOR));

          IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) + 1 -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

          END IF;
          IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

          END IF;
          P_TY_ATM_TXN_REC.TXN_CCY_DERIVED  := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.BILL_CCY_DERIVED := P_TY_ATM_TXN_REC.BILL_CCY_FCC;

          --sampath starts added for CSS beneficiary fee
          IF P_TY_ATM_TXN_REC.RSV_60 = 'CSS' OR
             SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('41') THEN
            --sampath added OR as CSS value not coming in field 60 for us on us fund transfer for css txns
            IF P_TY_ATM_TXN_REC.TXN_BEN_FEE IS NOT NULL THEN

              P_TY_ATM_TXN_REC.TBL_CHGDETS(3).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_BEN_FEE,
                                                                          1,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_BEN_FEE) -
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                   SUBSTR(P_TY_ATM_TXN_REC.TXN_BEN_FEE,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_BEN_FEE) + 1 -
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

              DBG('p_ty_atm_txn_rec.tbl_chgdets(3) .chg_amt==>' || P_TY_ATM_TXN_REC.TBL_CHGDETS(3)
                  .CHG_AMT);
            END IF;
          END IF;
          --sampath ends added for CSS beneficiary fee
          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

          --sampath starts for css
          IF P_TY_ATM_TXN_REC.RSV_60 = 'CSS' OR
             SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('41') THEN
            --sampath added OR as CSS value not coming in field 60 for us on us fund transfer for css txns
            P_TY_ATM_TXN_REC.TBL_CHGDETS(3).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(3).COD_CHG_DESC := 'TXN_BEN_FEE';
          END IF;
          --sampath ends for css
        ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN

          P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := NULL;
          P_TY_ATM_TXN_REC.TXN_CCY_DERIVED := NULL;

          P_TY_ATM_TXN_REC.BILL_AMT_DERIVED := NULL;
          P_TY_ATM_TXN_REC.BILL_CCY_DERIVED := NULL;

          --sampath commented starts
          /*P_TY_ATM_TXN_REC.SETL_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_AMT,
                                                                1,
                                                                LENGTH(P_TY_ATM_TXN_REC.SETL_AMT) -
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                         SUBSTR(P_TY_ATM_TXN_REC.SETL_AMT,
                                                                LENGTH(P_TY_ATM_TXN_REC.SETL_AMT) + 1 -
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR));

          */
          --sampath commented ends
          DBG('p_Ty_Atm_Txn_Rec.Txn_Ccy_Fcc' ||
              P_TY_ATM_TXN_REC.TXN_CCY_FCC);
          DBG('p_Ty_Atm_Txn_Rec.Txn_Acc_Ccy_Fcc' ||
              P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC);

          DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED=' ||
              P_TY_ATM_TXN_REC.TXN_AMT_DERIVED);
          IF P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC <>
             P_TY_ATM_TXN_REC.TXN_CCY_FCC THEN
            P_TY_ATM_TXN_REC.BILL_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.BILL_AMT,
                                                                  1,
                                                                  LENGTH(P_TY_ATM_TXN_REC.BILL_AMT) -
                                                                  P_TY_ATM_TXN_REC.BILL_CCY_MINOR) || '.' ||
                                                           SUBSTR(P_TY_ATM_TXN_REC.BILL_AMT,
                                                                  LENGTH(P_TY_ATM_TXN_REC.BILL_AMT) + 1 -
                                                                  P_TY_ATM_TXN_REC.BILL_CCY_MINOR,
                                                                  P_TY_ATM_TXN_REC.BILL_CCY_MINOR));


            --sampath added starts for css

            IF P_TY_ATM_TXN_REC.rsv_60 = 'CSS' AND
               P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC <>
               P_TY_ATM_TXN_REC.TXN_CCY_FCC AND
               P_TY_ATM_TXN_REC.offus_onus IN ('R') AND
               SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN ('00') THEN

              P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                                   1,
                                                                   LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) -
                                                                   P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                            SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                                   LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) + 1 -
                                                                   P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                   P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

            ELSE
              --sampath added for css
              --sampath added starts
              P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := P_TY_ATM_TXN_REC.BILL_AMT_DERIVED;
              --sampath added ends
            END IF; --sampath added ends for css
          ELSE
            P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                                 1,
                                                                 12 -
                                                                 P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                          SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                                 13 -
                                                                 P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                 P_TY_ATM_TXN_REC.TXN_CCY_MINOR));
            P_TY_ATM_TXN_REC.TXN_CCY_DERIVED := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          END IF;

          IF P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC <>
             P_TY_ATM_TXN_REC.TXN_CCY_FCC THEN
            --sampath added to handle Txn Fee not to pass 500 USD but 5 USD

            IF P_TY_ATM_TXN_REC.rsv_60 = 'CSS' AND
               P_TY_ATM_TXN_REC.offus_onus IN ('R') THEN
              --sampath added for charge amount to be derived based on charge currency in field 46 for css

              IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN

                P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                            1,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) -
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) + 1 -
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

                DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
                    .CHG_AMT);
              END IF;

            ELSE
              --sampath added else for CSS
          IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) -
                                                                            P_TY_ATM_TXN_REC.BILL_CCY_MINOR) || '.' ||
                                                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) + 1 -
                                                                            P_TY_ATM_TXN_REC.BILL_CCY_MINOR,
                                                                            P_TY_ATM_TXN_REC.BILL_CCY_MINOR));

                DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
                    .CHG_AMT);
              END IF;
            END IF; --sampath added end if for CSS
          ELSE
            --sampath added else
            IF P_TY_ATM_TXN_REC.TXN_FEE_AMT IS NOT NULL THEN
              P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                          1,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.TXN_FEE_AMT,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_FEE_AMT) + 1 -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

              DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1)
                  .CHG_AMT);

            END IF;
          END IF; --sampath added endif

          IF P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC <>
             P_TY_ATM_TXN_REC.TXN_CCY_FCC THEN
            --sampath added to handle Txn Fee not to pass 500 USD but 5 USD

            IF P_TY_ATM_TXN_REC.rsv_60 = 'CSS' AND
               P_TY_ATM_TXN_REC.offus_onus IN ('R') THEN
              --sampath added for charge amount to be derived based on charge currency in field 46 for css

              IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN

                P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                            1,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) -
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 -
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

                DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
                    .CHG_AMT);
          END IF;

            ELSE
              --sampath added else for css

              IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN

                P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                            1,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) -
                                                                            P_TY_ATM_TXN_REC.BILL_CCY_MINOR) || '.' ||
                                                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 -
                                                                            P_TY_ATM_TXN_REC.BILL_CCY_MINOR,
                                                                            P_TY_ATM_TXN_REC.BILL_CCY_MINOR));

                DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
                    .CHG_AMT);
              END IF;
            END IF; --sampath added end if for css

          ELSE
            --sampath added else
          IF P_TY_ATM_TXN_REC.TXN_PROC_FEE IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.TXN_PROC_FEE,
                                                                        LENGTH(P_TY_ATM_TXN_REC.TXN_PROC_FEE) + 1 -
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

              DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(2)
                  .CHG_AMT);

            END IF;
          END IF; --sampath added endif

          --sampath starts
          IF P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC <>
             P_TY_ATM_TXN_REC.TXN_CCY_FCC THEN

            IF P_TY_ATM_TXN_REC.rsv_60 = 'CSS' AND
               P_TY_ATM_TXN_REC.offus_onus IN ('R') THEN
              --sampath added for charge amount to be derived based on charge currency in field 46 for css

              IF P_TY_ATM_TXN_REC.TXN_BEN_FEE IS NOT NULL THEN

                P_TY_ATM_TXN_REC.TBL_CHGDETS(3).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_BEN_FEE,
                                                                            1,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_BEN_FEE) -
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_BEN_FEE,
                                                                            LENGTH(P_TY_ATM_TXN_REC.TXN_BEN_FEE) + 1 -
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

                DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(3).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(3)
                    .CHG_AMT);
              END IF;

            END IF;

          ELSE

            IF P_TY_ATM_TXN_REC.TXN_BEN_FEE IS NOT NULL THEN

              P_TY_ATM_TXN_REC.TBL_CHGDETS(3).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_BEN_FEE,
                                                                          1,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_BEN_FEE) -
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                                   SUBSTR(P_TY_ATM_TXN_REC.TXN_BEN_FEE,
                                                                          LENGTH(P_TY_ATM_TXN_REC.TXN_BEN_FEE) + 1 -
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                                          P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

              DBG('P_TY_ATM_TXN_REC.TBL_CHGDETS(3).CHG_AMT=' || P_TY_ATM_TXN_REC.TBL_CHGDETS(3)
                  .CHG_AMT);
          END IF;
          END IF;
          --sampath ends
          P_TY_ATM_TXN_REC.SETL_CCY_DERIVED := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
          P_TY_ATM_TXN_REC.BILL_CCY_DERIVED := P_TY_ATM_TXN_REC.BILL_CCY_FCC;

          DBG('P_TY_ATM_TXN_REC.SETL_CCY_DERIVED=' ||
              P_TY_ATM_TXN_REC.SETL_CCY_DERIVED);
          DBG('P_TY_ATM_TXN_REC.BILL_CCY_DERIVED=' ||
              P_TY_ATM_TXN_REC.BILL_CCY_DERIVED);

          IF P_TY_ATM_TXN_REC.rsv_60 = 'CSS' AND
             P_TY_ATM_TXN_REC.offus_onus IN ('R') THEN
            --sampath added for charge amount to be derived based on charge currency in field 46 for css

            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_FEE_CCY_FCC;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_PROC_FEE_CCY_FCC;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

            P_TY_ATM_TXN_REC.TBL_CHGDETS(3).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_BEN_FEE_CCY_FCC;
            P_TY_ATM_TXN_REC.TBL_CHGDETS(3).COD_CHG_DESC := 'TXN_BEN_FEE';

          ELSE
            --sampath added else for css

            IF P_TY_ATM_TXN_REC.BILL_CCY_DERIVED IS NOT NULL THEN
              --sampath added to prevent CYPO related above case
              P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
              P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

              P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.BILL_CCY_DERIVED;
              P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';
            ELSE
              --sampath added else
          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';
            END IF; --sampath added endif

          END IF; --sampath added end if for css

        ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN

          P_TY_ATM_TXN_REC.BILL_AMT_DERIVED := NULL;
          P_TY_ATM_TXN_REC.BILL_CCY_DERIVED := NULL;

          P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                               1,
                                                               LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) -
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                                        SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                                               LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) + 1 -
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                                               P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

          P_TY_ATM_TXN_REC.SETL_AMT_DERIVED := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_AMT,
                                                                1,
                                                                LENGTH(P_TY_ATM_TXN_REC.SETL_AMT) -
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                         SUBSTR(P_TY_ATM_TXN_REC.SETL_AMT,
                                                                LENGTH(P_TY_ATM_TXN_REC.SETL_AMT) + 1 -
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                P_TY_ATM_TXN_REC.SETL_CCY_MINOR));

          IF P_TY_ATM_TXN_REC.SETL_FEE_AMT IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_FEE_AMT,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.SETL_FEE_AMT) -
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.SETL_FEE_AMT,
                                                                        LENGTH(P_TY_ATM_TXN_REC.SETL_FEE_AMT) + 1 -
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR));

          END IF;
          IF P_TY_ATM_TXN_REC.SETL_PROC_FEE IS NOT NULL THEN

            P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.SETL_PROC_FEE,
                                                                        1,
                                                                        LENGTH(P_TY_ATM_TXN_REC.SETL_PROC_FEE) -
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR) || '.' ||
                                                                 SUBSTR(P_TY_ATM_TXN_REC.SETL_PROC_FEE,
                                                                        LENGTH(P_TY_ATM_TXN_REC.SETL_PROC_FEE) + 1 -
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR,
                                                                        P_TY_ATM_TXN_REC.SETL_CCY_MINOR));

          END IF;

          P_TY_ATM_TXN_REC.TXN_CCY_DERIVED  := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
          P_TY_ATM_TXN_REC.SETL_CCY_DERIVED := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
          P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

        END IF;

      END IF;
      DBG('p_ty_atm_txn_rec.txn_amt_derived==>' ||
          P_TY_ATM_TXN_REC.TXN_AMT_DERIVED);
      DBG('p_ty_atm_txn_rec.setl_amt_derived==>' ||
          P_TY_ATM_TXN_REC.SETL_AMT_DERIVED);
      DBG('p_ty_atm_txn_rec.bill_amt_derived==>' ||
          P_TY_ATM_TXN_REC.BILL_AMT_DERIVED);

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    RETURN TRUE;

  EXCEPTION

    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-AMT-03';
      DBG('E', 'fn_amt_chg_derive : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;

  END FN_AMT_CHG_DERIVE_NEW;

  FUNCTION FN_AMT_CHG_DERIVE(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                             P_ERR_CODE       IN OUT NOCOPY VARCHAR2,
                             P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN AS

    L_TXN_AMT_DERIVED   VARCHAR2(12) DEFAULT NULL;
    L_OFSET_AMT_DERIVED VARCHAR2(12) DEFAULT NULL;
    L_TXN_CCY_DERIVED   VARCHAR2(3) DEFAULT NULL;
    L_OFSET_CCY_DERIVED VARCHAR2(3) DEFAULT NULL;

  BEGIN

    IF P_TY_ATM_TXN_REC.SETL_AMT IS NULL AND
       P_TY_ATM_TXN_REC.BILL_AMT IS NULL THEN

      L_TXN_AMT_DERIVED   := P_TY_ATM_TXN_REC.TXN_AMT;
      L_OFSET_AMT_DERIVED := P_TY_ATM_TXN_REC.TXN_AMT;
      L_TXN_CCY_DERIVED   := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
      L_OFSET_CCY_DERIVED := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

      P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.TXN_FEE_AMT);

      P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

      P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

      P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.TXN_PROC_FEE);

      P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

      P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

    ELSIF P_TY_ATM_TXN_REC.BILL_AMT IS NULL THEN

      IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN

        L_TXN_AMT_DERIVED   := P_TY_ATM_TXN_REC.TXN_AMT;
        L_OFSET_AMT_DERIVED := P_TY_ATM_TXN_REC.SETL_AMT;
        L_TXN_CCY_DERIVED   := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
        L_OFSET_CCY_DERIVED := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.TXN_FEE_AMT);
        DBG('Slumper        :' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT ||
            ' Joe:' || P_TY_ATM_TXN_REC.TXN_FEE_AMT);

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.TXN_PROC_FEE);

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

      ELSE
        L_TXN_AMT_DERIVED   := P_TY_ATM_TXN_REC.SETL_AMT;
        L_OFSET_AMT_DERIVED := P_TY_ATM_TXN_REC.TXN_AMT;
        L_TXN_CCY_DERIVED   := P_TY_ATM_TXN_REC.SETL_CCY_FCC;
        L_OFSET_CCY_DERIVED := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.SETL_FEE_AMT);
        DBG('Slumper        :' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT ||
            ' Joe:' || P_TY_ATM_TXN_REC.SETL_FEE_AMT);

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.SETL_PROC_FEE);

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';
      END IF;

    ELSE

      IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN

        L_TXN_AMT_DERIVED   := P_TY_ATM_TXN_REC.BILL_AMT;
        L_OFSET_AMT_DERIVED := P_TY_ATM_TXN_REC.TXN_AMT;
        L_TXN_CCY_DERIVED   := P_TY_ATM_TXN_REC.BILL_CCY_FCC;
        L_OFSET_CCY_DERIVED := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.TXN_FEE_AMT);
        DBG('Slumper        :' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT ||
            ' Joe:' || P_TY_ATM_TXN_REC.TXN_FEE_AMT);
        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.TXN_PROC_FEE);

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

      ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN

        L_TXN_AMT_DERIVED   := P_TY_ATM_TXN_REC.BILL_AMT;
        L_OFSET_AMT_DERIVED := P_TY_ATM_TXN_REC.SETL_AMT;
        L_TXN_CCY_DERIVED   := P_TY_ATM_TXN_REC.BILL_CCY_FCC;
        L_OFSET_CCY_DERIVED := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.TXN_FEE_AMT);
        DBG('Slumper        :' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT ||
            ' Joe:' || P_TY_ATM_TXN_REC.TXN_FEE_AMT);
        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.TXN_PROC_FEE);

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

      ELSIF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN

        L_TXN_AMT_DERIVED   := P_TY_ATM_TXN_REC.TXN_AMT;
        L_OFSET_AMT_DERIVED := P_TY_ATM_TXN_REC.SETL_AMT;
        L_TXN_CCY_DERIVED   := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
        L_OFSET_CCY_DERIVED := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.SETL_FEE_AMT);
        DBG('Slumper        :' || P_TY_ATM_TXN_REC.TBL_CHGDETS(1).CHG_AMT ||
            ' Joe:' || P_TY_ATM_TXN_REC.SETL_FEE_AMT);

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(1).COD_CHG_DESC := 'TXN_FEE';

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).CHG_AMT := TO_NUMBER(P_TY_ATM_TXN_REC.SETL_PROC_FEE);

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_CCY := P_TY_ATM_TXN_REC.SETL_CCY_FCC;

        P_TY_ATM_TXN_REC.TBL_CHGDETS(2).COD_CHG_DESC := 'TXN_PROCESS_FEE';

      END IF;

    END IF;

    IF L_TXN_AMT_DERIVED IS NOT NULL THEN

      IF L_TXN_CCY_DERIVED <> P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC THEN

        IF NOT SWPKSS_UTILS.FN_GET_PRODUCT_REC_WRP(P_TY_ATM_TXN_REC.PRODUCT_CODE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM) THEN
          P_ERR_CODE  := 'SW-PRD-01';
          P_ERR_PARAM := 'fn_amt_chg_derive' || '~' || P_ERR_CODE;
          DBG('E',
              'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
              P_ERR_PARAM);
          RETURN FALSE;
        ELSE
          DBG('Inside Fn_Get_Product_Rec_Wrp for product :' ||
              SWPKSS_UTILS.G_TBL_CSTM_PROD_REC.PRODUCT_CODE);
          IF SWPKSS_UTILS.G_TBL_CSTM_PROD_REC.MODULE <> 'RT' THEN
            P_ERR_CODE  := 'SW-PRD-01';
            P_ERR_PARAM := 'fn_amt_chg_derive' || '~' || P_ERR_CODE;
            DBG('E',
                'Product is avaliable but it is not RT module ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          ELSE
            P_TY_ATM_TXN_REC.RATE_CODE := SWPKSS_UTILS.G_TBL_CSTM_PROD_REC.RATE_CODE_PREFERRED;
            P_TY_ATM_TXN_REC.RATE_TYPE := SWPKSS_UTILS.G_TBL_CSTM_PROD_REC.RATE_TYPE_PREFERRED;
            DBG('Rate Code :' || P_TY_ATM_TXN_REC.RATE_CODE ||
                ' Rate Type :' || P_TY_ATM_TXN_REC.RATE_TYPE);
          END IF;
        END IF;

        DBG('cypks.fn_amt1_to_amt2 : Calling cypks.fn_amt1_to_amt2  ' || '~' ||
            P_TY_ATM_TXN_REC.ACC_BRANCH_CODE || '~' || L_TXN_CCY_DERIVED || ' ~' ||
            P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC || '~' ||
            P_TY_ATM_TXN_REC.RATE_CODE || '~' ||
            P_TY_ATM_TXN_REC.RATE_TYPE || '~' || L_TXN_AMT_DERIVED || ' ~' ||
            P_TY_ATM_TXN_REC.TXN_AMT_DERIVED || ' ~' ||
            P_TY_ATM_TXN_REC.X_RATE_DERIVED || ' ~' || P_ERR_CODE);

        IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                      L_TXN_CCY_DERIVED,
                                      P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC,
                                      P_TY_ATM_TXN_REC.RATE_CODE,
                                      P_TY_ATM_TXN_REC.RATE_TYPE,
                                      L_TXN_AMT_DERIVED,
                                      'N',
                                      P_TY_ATM_TXN_REC.TXN_AMT_DERIVED,
                                      P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                      P_ERR_CODE) THEN
          P_ERR_CODE  := 'SW-AMT-01';
          P_ERR_PARAM := '~' || L_TXN_CCY_DERIVED || '~' ||
                         L_TXN_CCY_DERIVED;
          DBG('fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
              P_ERR_CODE || '~' || P_ERR_PARAM);
          RETURN FALSE;
        END IF;

        P_TY_ATM_TXN_REC.TXN_CCY_DERIVED := P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC;

      ELSE

        P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := TO_NUMBER(L_TXN_AMT_DERIVED);
        P_TY_ATM_TXN_REC.TXN_CCY_DERIVED := L_TXN_CCY_DERIVED;
      END IF;
    END IF;
    P_TY_ATM_TXN_REC.OFSET_AMT_DERIVED := TO_NUMBER(L_OFSET_AMT_DERIVED);
    P_TY_ATM_TXN_REC.OFSET_CCY_DERIVED := L_OFSET_CCY_DERIVED;

    DBG('ofset_amt_derived :' || P_TY_ATM_TXN_REC.OFSET_AMT_DERIVED);
    DBG('txn_amt_derived   :' || P_TY_ATM_TXN_REC.TXN_AMT_DERIVED);

    RETURN TRUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERR_CODE  := 'SW-AMT-02';
      P_ERR_PARAM := '~' || P_TY_ATM_TXN_REC.PRODUCT_CODE;
      DBG('E',
          'fn_amt_chg_derive : No data found in cstm_product ' ||
          P_ERR_CODE || '~' || P_ERR_PARAM);
      RETURN FALSE;
    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-AMT-03';
      DBG('E', 'fn_amt_chg_derive : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;

  END FN_AMT_CHG_DERIVE;

  FUNCTION FN_GET_BALANCES(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                           P_ERRCODE        IN OUT VARCHAR2,
                           P_ERRPARAM       IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
    L_AC_NO       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRANCH_CODE VARCHAR2(3);

    L_ACCOUNT_CCY VARCHAR2(3);
    L_CCY_DECIMAL NUMBER(2);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('fn_get_balances : Coming inside Gwpks_CreateSWTransaction.fn_get_balances ');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling Gwpks_Ext_Switchservice.Fn_Pre_Get_Balances ');
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_PRE_GET_BALANCES(P_TY_ATM_TXN_REC,
                                                         P_ERRCODE,
                                                         P_ERRPARAM) THEN

        DBG('Gwpks_Ext_Switchservice.Fn_Pre_Get_Balances has returned false');
        RETURN FALSE;
      END IF;

    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      L_AC_NO       := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
      L_BRANCH_CODE := P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;

      DBG('fn_get_balances : p_ty_atm_txn_rec.acc_branch_code ' ||
          L_BRANCH_CODE || 'Account No...' || L_AC_NO);
      BEGIN
        SELECT B.ACY_CURR_ACC_BAL, B.ACY_UNCOLLECTED, A.ACCOUNT_TYPE, A.CCY
          INTO P_TY_ATM_TXN_REC.CURR_BAL_DERIVED,
               P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED,
               P_TY_ATM_TXN_REC.TXN_ACC_TYPE_FCC,
               L_ACCOUNT_CCY
          FROM STTMS_CUST_ACCOUNT A, STTM_ACCOUNT_BALANCE B

         WHERE A.CUST_AC_NO = L_AC_NO
           AND A.BRANCH_CODE = L_BRANCH_CODE
           AND A.CUST_AC_NO = B.CUST_AC_NO
           AND A.BRANCH_CODE = B.CUST_AC_BRN;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERRCODE  := 'SW-BAL-02';
          P_ERRPARAM := L_BRANCH_CODE || '~' || L_AC_NO;
          DBG('E',
              'fn_get_balances : No data found in sttms_cust_account ' ||
              P_ERRCODE || '~' || P_ERRPARAM);
          RETURN FALSE;
      END;
      DBG('fn_get_balances : After ');

      IF NOT ACPKSS_MISC.FN_GETAVLBAL(L_BRANCH_CODE,
                                      L_AC_NO,
                                      P_TY_ATM_TXN_REC.AVL_BAL_DERIVED,
                                      'Y')

       THEN
        DBG('E',
            'fn_get_balances : acpks_misc.fn_getavlbal returned false ');
        P_ERRCODE  := 'SW-BAL-01';
        P_ERRPARAM := '~' || L_BRANCH_CODE || '~' || L_AC_NO;
        RETURN FALSE;
      END IF;

      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;
        DBG('Calling gwpks_createswtxn_cluster.fn_get_balances');
        IF NOT
            GWPKS_CREATESWTXN_CLUSTER.FN_GET_BALANCES(P_TY_ATM_TXN_REC,
                                                      P_ERRCODE,
                                                      P_ERRPARAM,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
          DBG('Failure has happened in gwpks_createswtxn_cluster.fn_get_balances');
          RETURN FALSE;
        END IF;
      END IF;

      BEGIN
        SELECT CCY_DECIMALS
          INTO L_CCY_DECIMAL
          FROM CYTMS_CCY_DEFN
         WHERE CCY_CODE = L_ACCOUNT_CCY;
        DBG('fn_get_balances : decimal: ' || L_CCY_DECIMAL);

        P_TY_ATM_TXN_REC.AVL_BAL_DERIVED   := P_TY_ATM_TXN_REC.AVL_BAL_DERIVED *
                                              POWER(10, L_CCY_DECIMAL);
        P_TY_ATM_TXN_REC.CURR_BAL_DERIVED  := P_TY_ATM_TXN_REC.CURR_BAL_DERIVED *
                                              POWER(10, L_CCY_DECIMAL);
        P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED := P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED *
                                              POWER(10, L_CCY_DECIMAL);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('E',
              'fn_get_balances : unable to get ccy decimals ' ||
              L_ACCOUNT_CCY);
          P_ERRCODE  := 'SW-BAL-01';
          P_ERRPARAM := '~' || L_BRANCH_CODE || '~' || L_AC_NO;
          RETURN FALSE;
      END;

      P_ERRCODE  := NULL;
      P_ERRPARAM := NULL;
      DBG('fn_get_balances : Available balance ' ||
          P_TY_ATM_TXN_REC.AVL_BAL_DERIVED);
      DBG('fn_get_balances : Current balance ' ||
          P_TY_ATM_TXN_REC.CURR_BAL_DERIVED);
      DBG('fn_get_balances : Uncollected balance ' ||
          P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED);

    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling Gwpks_Ext_Switchservice.Fn_Post_Get_Balances ');
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_POST_GET_BALANCES(P_TY_ATM_TXN_REC,
                                                          P_ERRCODE,
                                                          P_ERRPARAM) THEN

        DBG('Gwpks_Ext_Switchservice.Fn_Post_Get_Balances has returned false');
        RETURN FALSE;
      END IF;

    END IF;

    DBG('fn_get_balances : Exit out of Gwpks_CreateSWTransaction.fn_get_balances ');
    RETURN TRUE;
  EXCEPTION

    WHEN OTHERS THEN
      P_ERRCODE := 'SW-BAL-03';
      DBG('E', 'fn_get_balances : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;
  END FN_GET_BALANCES;

  FUNCTION FN_GET_ADDAMT(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                         P_ERRCODE        IN OUT VARCHAR2,
                         P_ERRPARAM       IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS

    L_AVAIL_BAL_FLG  CHAR(1);
    L_UNCL_BAL_FLG   CHAR(1);
    L_LEDGER_BAL_FLG CHAR(1);
    L_SW_ACC_TYPE    VARCHAR(2);
    L_ACC_CCY_ISO    CYTM_CCY_DEFN.ISO_NUM_CCY_CODE%TYPE;
  BEGIN

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_GET_ADDAMT(P_TY_ATM_TXN_REC,
                                                   P_ERRCODE,
                                                   P_ERRPARAM) THEN
        DBG('E', 'gwpks_ext_switchservice.fn_get_addamt returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('fn_get_addamt : Coming inside Gwpks_CreateSWTransaction.fn_get_addamt ');
      L_SW_ACC_TYPE := SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 3, 2);

      IF NVL(G_CL_OLL_ACC, 'N') = 'N' AND
         P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' THEN
        IF NOT FN_GET_BALANCES(P_TY_ATM_TXN_REC, P_ERRCODE, P_ERRCODE) THEN
          DBG('failed in gwpkss_createatm.fn_get_balances');
          RETURN FALSE;
        END IF;

        IF SIGN(P_TY_ATM_TXN_REC.CURR_BAL_DERIVED) = -1 THEN
          L_LEDGER_BAL_FLG := 'D';
        ELSE
          L_LEDGER_BAL_FLG := 'C';
        END IF;
        IF SIGN(P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED) = -1 THEN
          L_UNCL_BAL_FLG := 'D';
        ELSE
          L_UNCL_BAL_FLG := 'C';
        END IF;
        IF SIGN(P_TY_ATM_TXN_REC.AVL_BAL_DERIVED) = -1 THEN
          L_AVAIL_BAL_FLG := 'D';
        ELSE
          L_AVAIL_BAL_FLG := 'C';
        END IF;

        P_TY_ATM_TXN_REC.AVL_BAL_DERIVED   := ABS(P_TY_ATM_TXN_REC.AVL_BAL_DERIVED);
        P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED := ABS(P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED);
        P_TY_ATM_TXN_REC.CURR_BAL_DERIVED  := ABS(P_TY_ATM_TXN_REC.CURR_BAL_DERIVED);

        DBG('Account currency: ' || P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC);
        SELECT ISO_NUM_CCY_CODE
          INTO L_ACC_CCY_ISO
          FROM CYTM_CCY_DEFN
         WHERE CCY_CODE = P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC;
        P_TY_ATM_TXN_REC.ADD_AMT := L_SW_ACC_TYPE || '02' ||
                                    LPAD(L_ACC_CCY_ISO, 3, '0') ||
                                    L_AVAIL_BAL_FLG ||
                                    LPAD(P_TY_ATM_TXN_REC.AVL_BAL_DERIVED,
                                         12,
                                         '0') || L_SW_ACC_TYPE || '04' ||
                                    LPAD(L_ACC_CCY_ISO, 3, '0') ||
                                    L_UNCL_BAL_FLG ||
                                    LPAD(P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED,
                                         12,
                                         '0') || L_SW_ACC_TYPE || '01' ||
                                    LPAD(L_ACC_CCY_ISO, 3, '0') ||
                                    L_LEDGER_BAL_FLG ||
                                    LPAD(P_TY_ATM_TXN_REC.CURR_BAL_DERIVED,
                                         12,
                                         '0');

        P_ERRCODE  := NULL;
        P_ERRPARAM := NULL;
      END IF;
      DBG('fn_get_addamt : Available balance ' ||
          P_TY_ATM_TXN_REC.AVL_BAL_DERIVED);
      DBG('fn_get_addamt : Current balance ' ||
          P_TY_ATM_TXN_REC.CURR_BAL_DERIVED);
      DBG('fn_get_addamt : Uncollected balance ' ||
          P_TY_ATM_TXN_REC.UNCOL_BAL_DERIVED);
      DBG('fn_get_addamt : additional amts ' || P_TY_ATM_TXN_REC.ADD_AMT);
      DBG('fn_get_addamt : Exit out of Gwpks_CreateSWTransaction.fn_get_addamt ');

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERRCODE := 'SW-ADD-01';
      DBG('E',
          'fn_get_addamt : No data found in sttms_cust_account ' ||
          P_ERRCODE || '~' || P_ERRPARAM);
      RETURN FALSE;
    WHEN OTHERS THEN
      P_ERRCODE := 'SW-ADD-02';
      DBG('E', 'fn_get_addamt : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;
  END FN_GET_ADDAMT;

  FUNCTION FN_CARDACC_TO_FCCACC(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                                AC_ONLY_FLG      IN VARCHAR2,
                                P_ERRCODE        IN OUT NOCOPY VARCHAR2,
                                P_ERRPARAM       IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
    L_COUNT           NUMBER;
    L_AC_STAT_DE_POST STTM_CUST_ACCOUNT.AC_STAT_DE_POST%TYPE;

    L_TB_CLUSTER_DATA       GLOBAL. TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL. TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('Inside fn_cardacc_to_fccacc');
    DBG('p_ty_atm_txn_rec.from_acc --> ' || P_TY_ATM_TXN_REC.FROM_ACC || '~' ||
        P_TY_ATM_TXN_REC.TO_ACC);
    DBG('atm_card_num --> ' || P_TY_ATM_TXN_REC.PAN);

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_CARDACC_TO_FCCACC(P_TY_ATM_TXN_REC,
                                                          AC_ONLY_FLG,
                                                          P_ERRCODE,
                                                          P_ERRPARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.fn_cardacc_to_fccacc returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF AC_ONLY_FLG = 'N' THEN

        DBG('p_ty_atm_txn_rec.switch_param_flg.fcc_acc_on_switch --> ' ||
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.FCC_ACC_FROM_SWITCH);

        DBG('p_ty_atm_txn_rec.Switch_Param_Flg.ONLY_ACC_FROM_SWITCH --> ' ||
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_ACC_FROM_SWITCH);
        DBG(' p_ty_atm_txn_rec.switch_param_flg.only_pan_from_switch --> ' ||
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH);

        IF NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_ACC_FROM_SWITCH, 'N') = 'Y' AND
           P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.FCC_ACC_FROM_SWITCH = 'Y' AND
           P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH = 'N' THEN
          DBG('Card Number Not Available in Request');
          DBG('Inside fn_cardacc_to_fccacc --proc_code_type --> ' ||
              SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2));
          BEGIN

            IF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN
               ('21', '20', '22')) THEN
              DBG('fn_cardacc_to_fccacc : proc code is not 21 20 22');
              DBG('FIRST IF CONDITION');

              IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.POS_VOID = 'Y' THEN
                DBG('fn_cardacc_to_fccacc : If pos_void is Y');
                DBG('FIRST IF FIRST IF CONDITION');

                IF P_TY_ATM_TXN_REC.RSV_60 IN ('CCONUS') THEN
                  P_TY_ATM_TXN_REC.FROM_ACC        := FN_GET_CREDIT_CARD_GL('CREDIT_CARD_LOAN_GL'); --'133210011';
                  P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC  := P_TY_ATM_TXN_REC.FROM_ACC;
                  P_TY_ATM_TXN_REC.ACC_BRANCH_CODE := FN_GET_CREDIT_CARD_GL_BRANCH('CREDIT_CARD_LOAN_GL_BRANCH'); --'001'; --sampath added  for credit card cash withdrawal
                  P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC  := P_TY_ATM_TXN_REC.FROM_ACC;
                  P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC  := FN_GET_TERMINAL_GL(P_TY_ATM_TXN_REC.TERM_ID);
                  DBG('P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC=' ||
                      P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
                  DBG('P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC=' ||
                      P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC);

                ELSE
                  --sampath added else for credit card cash withdrawal ends

                  --sampath changes for IBFT to derive the ISO Field 103 account covered 2 cases ON US other bank account and remote on us for CSS
                  IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('42') THEN
                    --SAMPATH
                    P_TY_ATM_TXN_REC.FROM_ACC        := '000021069'; --'296920019'; --SAMPATH
                    P_TY_ATM_TXN_REC.ACC_BRANCH_CODE := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                                                            P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
                    P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC  := P_TY_ATM_TXN_REC.FROM_ACC;

                  ELSE
                    --sampath added else for CSS
                P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.FROM_ACC;
                  END IF; --sampath added for CSS

                  IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('42') THEN
                    --sampath added IF for CSS

                    BEGIN
                      DBG('BEGIN');
                      SELECT AC_GL_NO, NVL(BRANCH_CODE, GLOBAL.HEAD_OFFICE)
                        INTO P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                             P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                        FROM STTB_ACCOUNT
                       WHERE AC_GL_NO = P_TY_ATM_TXN_REC.FROM_ACC
                         AND AUTH_STAT = 'A'
                         AND AC_GL_REC_STATUS = 'O'
                         AND AC_OR_GL = 'G'
                         AND GL_STAT_DE_POST = 'Y';
                      DBG('QUERY Exwecuted');
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        P_ERRCODE  := 'SW-CRD-01';
                        P_ERRPARAM := P_TY_ATM_TXN_REC.TO_ACC;
                        DBG('E',
                            'fn_cardacc_to_fccacc : No data found in sttb_account ' ||
                            P_ERRCODE || '~' || P_ERRPARAM);
                        RETURN FALSE;
                    END;

                  ELSE
                    --sampath added ELSE for CSS

                SELECT BRANCH_CODE
                  INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_TY_ATM_TXN_REC.FROM_ACC
                   AND AUTH_STAT = 'A'
                   AND AC_GL_REC_STATUS = 'O';

                  END IF; --sampath added END IF for CSS

                END IF; --sampath added end if for credit card cash withdrawal
              ELSIF NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.POS_VOID, 'N') = 'N' THEN
                DBG('fn_cardacc_to_fccacc : If pos_void is N');

                P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.TO_ACC;

                SELECT BRANCH_CODE
                  INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
                   AND AUTH_STAT = 'A'
                   AND AC_GL_REC_STATUS = 'O';
              END IF;

            ELSIF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN
                  ('21', '22')) THEN
              DBG('INSIDE ELSEIF CONDITION');
              DBG('fn_cardacc_to_fccacc : proc code is not 21 22');

              P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.FROM_ACC;
              SELECT BRANCH_CODE
                INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                FROM STTB_ACCOUNT
               WHERE AC_GL_NO = P_TY_ATM_TXN_REC.FROM_ACC
                 AND AUTH_STAT = 'A'
                 AND AC_GL_REC_STATUS = 'O';
            ELSE
              DBG('fn_cardacc_to_fccacc : else of not 20 21 22');

              P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.TO_ACC;
              SELECT BRANCH_CODE
                INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                FROM STTB_ACCOUNT
               WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
                 AND AUTH_STAT = 'A'
                 AND AC_GL_REC_STATUS = 'O';
            END IF;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERRCODE  := 'SW-CRD-09';
              P_ERRPARAM := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
              DBG('E',
                  'fn_cardacc_to_fccacc : No data found in sttb_account ' ||
                  P_ERRCODE || '~' || P_ERRPARAM);
              RETURN FALSE;
          END;

        ELSE

          DBG('fn_cardacc_to_fccacc : else 2');

          IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.FCC_ACC_FROM_SWITCH = 'Y' THEN

            DBG('Inside fn_cardacc_to_fccacc --proc_code_type --> ' ||
                SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2));
            IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '20' THEN
              DBG('fn_cardacc_to_fccacc : proc code is 20');

              IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.POS_VOID = 'Y' THEN
                DBG('fn_cardacc_to_fccacc : pos void is Y');

                P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.FROM_ACC;

                SELECT FCC_ACC_BRN
                  INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                  FROM SWTMS_CARD_DETAILS
                 WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                   AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
                   AND AUTH_STAT = 'A'
                   AND RECORD_STAT = 'O';

              ELSIF NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.POS_VOID, 'N') = 'N' THEN
                DBG('fn_cardacc_to_fccacc : pos void is N');

                P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.TO_ACC;

                SELECT FCC_ACC_BRN
                  INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                  FROM SWTMS_CARD_DETAILS
                 WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                   AND ATM_ACC_NO = P_TY_ATM_TXN_REC.TO_ACC
                   AND AUTH_STAT = 'A'
                   AND RECORD_STAT = 'O';
              END IF;
            ELSIF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) NOT IN
                  ('21', '22')) THEN

              DBG('fn_cardacc_to_fccacc : proc code is not 21 22');

              P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.FROM_ACC;

              SELECT FCC_ACC_BRN
                INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                FROM SWTMS_CARD_DETAILS
               WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                 AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
                 AND AUTH_STAT = 'A'
                 AND RECORD_STAT = 'O';
            ELSE
              DBG('fn_cardacc_to_fccacc : proc code else part');

              P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.TO_ACC;

              SELECT FCC_ACC_BRN
                INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                FROM SWTMS_CARD_DETAILS
               WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                 AND ATM_ACC_NO = P_TY_ATM_TXN_REC.TO_ACC
                 AND AUTH_STAT = 'A'
                 AND RECORD_STAT = 'O';

            END IF;

          ELSE
            DBG('fn_cardacc_to_fccacc : else of fcc_acc_from_switch Y');

            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_FN_CALL_ID      := 1;
              IF NOT
                  GWPKS_CREATESWTXN_CLUSTER.FN_CARDACC_TO_FCCACC(P_TY_ATM_TXN_REC,
                                                                 AC_ONLY_FLG,
                                                                 P_ERRCODE,
                                                                 P_ERRPARAM,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA) THEN
                DEBUG.PR_DEBUG('GW',
                               'gwpks_createswtxn_cluster.fn_cardacc_to_fccacc failed' ||
                               P_ERRCODE);
                RETURN FALSE;
              END IF;
            END IF;
            IF NOT GLOBAL.G_SKIP_KERNEL THEN

              DBG('in else..');
              DBG('p_ty_atm_txn_rec.from_acc:' ||
                  P_TY_ATM_TXN_REC.FROM_ACC);

              IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH = 'N' THEN
                DBG('fn_cardacc_to_fccacc : only_pan_from_switch is N');

                IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '20' THEN
                  DBG('fn_cardacc_to_fccacc : proc_code is 20');
                  IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.POS_VOID = 'Y' THEN
                    DBG('fn_cardacc_to_fccacc : pos_void is Y');

                    SELECT FCC_ACC_NO, FCC_ACC_BRN
                      INTO P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                           P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                      FROM SWTMS_CARD_DETAILS
                     WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                       AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
                       AND AUTH_STAT = 'A'
                       AND RECORD_STAT = 'O';

                  ELSIF NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.POS_VOID, 'N') = 'N' THEN
                    DBG('fn_cardacc_to_fccacc : pos_void is N');

                    SELECT FCC_ACC_NO, FCC_ACC_BRN
                      INTO P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                           P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                      FROM SWTMS_CARD_DETAILS
                     WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                       AND ATM_ACC_NO = P_TY_ATM_TXN_REC.TO_ACC
                       AND AUTH_STAT = 'A'
                       AND RECORD_STAT = 'O';

                  END IF;
                ELSIF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN
                      ('21', '22')) THEN
                  DBG('fn_cardacc_to_fccacc : proc_code is 21 22');

                  SELECT FCC_ACC_NO, FCC_ACC_BRN
                    INTO P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                         P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                    FROM SWTMS_CARD_DETAILS
                   WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                     AND ATM_ACC_NO = P_TY_ATM_TXN_REC.TO_ACC
                     AND AUTH_STAT = 'A'
                     AND RECORD_STAT = 'O';
                ELSE
                  DBG('fn_cardacc_to_fccacc : else of proc code');
                  SELECT FCC_ACC_NO, FCC_ACC_BRN
                    INTO P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                         P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                    FROM SWTMS_CARD_DETAILS
                   WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                     AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
                     AND AUTH_STAT = 'A'
                     AND RECORD_STAT = 'O';
                END IF;

              ELSE
                DBG('fn_cardacc_to_fccacc : else of only_pan_from_switch is N');

                SELECT FCC_ACC_NO, FCC_ACC_BRN
                  INTO P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC,
                       P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                  FROM SWTMS_CARD_DETAILS
                 WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                   AND AUTH_STAT = 'A'
                   AND RECORD_STAT = 'O';
              END IF;

            END IF;
          END IF;
          DBG('fn_cardacc_to_fccacc : after if for fcc_acc_from_switch is Y');

          SELECT AC_STAT_DE_POST
            INTO L_AC_STAT_DE_POST
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC
             AND BRANCH_CODE = P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
          DBG('l_ac_stat_de_post' || L_AC_STAT_DE_POST);
          IF L_AC_STAT_DE_POST != 'Y' THEN
            P_ERRCODE  := 'AC-VAC08';
            P_ERRPARAM := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
            RETURN FALSE;
          END IF;

        END IF;

      ELSE

    DBG('INSIDE MAIN ELSE CONDITION');
        DBG('p_ty_atm_txn_rec.switch_param_flg.fcc_acc_on_switch --> ' ||
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.FCC_ACC_FROM_SWITCH);

        DBG('p_ty_atm_txn_rec.Switch_Param_Flg.ONLY_ACC_FROM_SWITCH --> ' ||
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_ACC_FROM_SWITCH);
        DBG(' p_ty_atm_txn_rec.switch_param_flg.only_pan_from_switch --> ' ||
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH);

        IF NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_ACC_FROM_SWITCH, 'N') = 'Y' AND
           P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.FCC_ACC_FROM_SWITCH = 'Y' AND
           P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH = 'N' THEN
          DBG('fn_cardacc_to_fccacc : inside if for switch Y~Y~N');
          DBG('Card Number Not Available in Request');

          DBG('P_TY_ATM_TXN_REC.FROM_ACC=' || P_TY_ATM_TXN_REC.FROM_ACC);
          DBG('P_TY_ATM_TXN_REC.TO_ACC=' || P_TY_ATM_TXN_REC.TO_ACC);

          DBG('P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC=' ||
              P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC);
          DBG('P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC=' ||
              P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);

          --sampath changes for IBFT to derive the ISO Field 103 account covered 2 cases ON US other bank account and remote on us for CSS
          IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('41') THEN
            --SAMPATH added for css

            P_TY_ATM_TXN_REC.TO_ACC          := FN_GET_IBFT_DR_CR_GL('CSS_IBFT_DEBIT_PAYMENT'); --SAMPATH
            P_TY_ATM_TXN_REC.OFF_BRANCH_CODE := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                                                    P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
            P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC  := P_TY_ATM_TXN_REC.TO_ACC;

            DBG('P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC=' ||
                P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC);
            DBG('P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC=' ||
                P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);

            BEGIN
              SELECT AC_GL_NO, BRANCH_CODE
                INTO P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC,
                     P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
                FROM STTB_ACCOUNT
               WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
                 AND AUTH_STAT = 'A'
                 AND AC_GL_REC_STATUS = 'O'
                 AND AC_OR_GL = 'A';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Card Number Not Available in Request -- No Data Found Cheking in GL' ||
                    P_TY_ATM_TXN_REC.TO_ACC);
                BEGIN
                  DBG('BEGIN');
                  SELECT AC_GL_NO, NVL(BRANCH_CODE, GLOBAL.HEAD_OFFICE)
                    INTO P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC,
                         P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
                    FROM STTB_ACCOUNT
                   WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
                     AND AUTH_STAT = 'A'
                     AND AC_GL_REC_STATUS = 'O'
                     AND AC_OR_GL = 'G'
                     AND GL_STAT_DE_POST = 'Y';
                  DBG('QUERY Exwecuted');
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    P_ERRCODE  := 'SW-CRD-01';
                    P_ERRPARAM := P_TY_ATM_TXN_REC.TO_ACC;
                    DBG('E',
                        'fn_cardacc_to_fccacc : No data found in sttb_account ' ||
                        P_ERRCODE || '~' || P_ERRPARAM);
                    RETURN FALSE;
                END;
            END;

          ELSIF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('42') THEN
            --SAMPATH added for css

            DBG('P_TY_ATM_TXN_REC.ACC_BRANCH_CODE=' ||
                P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
            DBG('P_TY_ATM_TXN_REC.ACC_BRANCH_CODE=' ||
                P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
            --P_TY_ATM_TXN_REC.FROM_ACC          := '111100309'; --SAMPATH
            P_TY_ATM_TXN_REC.OFF_BRANCH_CODE := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                                                    P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
            P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC  := P_TY_ATM_TXN_REC.TO_ACC; --P_TY_ATM_TXN_REC.FROM_ACC;

            P_TY_ATM_TXN_REC.ACC_BRANCH_CODE := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                                                    P_TY_ATM_TXN_REC.ACC_BRANCH_CODE);
            P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC  := FN_GET_IBFT_DR_CR_GL('CSS_IBFT_CREDIT_PAYMENT');

            BEGIN
              SELECT AC_GL_NO, BRANCH_CODE
                INTO P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC,
                     P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
                FROM STTB_ACCOUNT
               WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
                 AND AUTH_STAT = 'A'
                 AND AC_GL_REC_STATUS = 'O'
                 AND AC_OR_GL = 'A';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Card Number Not Available in Request -- No Data Found Cheking in GL' ||
                    P_TY_ATM_TXN_REC.TO_ACC);
                BEGIN
                  DBG('BEGIN');
                  SELECT AC_GL_NO, NVL(BRANCH_CODE, GLOBAL.HEAD_OFFICE)
                    INTO P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC,
                         P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
                    FROM STTB_ACCOUNT
                   WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
                     AND AUTH_STAT = 'A'
                     AND AC_GL_REC_STATUS = 'O'
                     AND AC_OR_GL = 'G'
                     AND GL_STAT_DE_POST = 'Y';
                  DBG('QUERY Exwecuted');
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    P_ERRCODE  := 'SW-CRD-01';
                    P_ERRPARAM := P_TY_ATM_TXN_REC.TO_ACC;
                    DBG('E',
                        'fn_cardacc_to_fccacc : No data found in sttb_account ' ||
                        P_ERRCODE || '~' || P_ERRPARAM);
                    RETURN FALSE;
                END;
            END;

          ELSE
            --SAMPATH added for css
          P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC := P_TY_ATM_TXN_REC.TO_ACC;
          BEGIN
            SELECT AC_GL_NO, BRANCH_CODE
              INTO P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC,
                   P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
              FROM STTB_ACCOUNT
             WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
               AND AUTH_STAT = 'A'
               AND AC_GL_REC_STATUS = 'O'
               AND AC_OR_GL = 'A';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Card Number Not Available in Request -- No Data Found Cheking in GL' ||
                  P_TY_ATM_TXN_REC.TO_ACC);
              BEGIN
                DBG('BEGIN');
                SELECT AC_GL_NO, NVL(BRANCH_CODE, GLOBAL.HEAD_OFFICE)
                  INTO P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC,
                       P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
                   AND AUTH_STAT = 'A'
                   AND AC_GL_REC_STATUS = 'O'
                   AND AC_OR_GL = 'G'
                   AND GL_STAT_DE_POST = 'Y';
                DBG('QUERY Exwecuted');
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  P_ERRCODE  := 'SW-CRD-01';
                  P_ERRPARAM := P_TY_ATM_TXN_REC.TO_ACC;
                  DBG('E',
                      'fn_cardacc_to_fccacc : No data found in sttb_account ' ||
                      P_ERRCODE || '~' || P_ERRPARAM);
                  RETURN FALSE;
              END;
          END;
          END IF; --SAMPATH added for css
        ELSE
          DBG('fn_cardacc_to_fccacc : else for switch Y~Y~N');

          DBG('p_ty_atm_txn_rec.to_acc:' || P_TY_ATM_TXN_REC.TO_ACC);

          BEGIN
            SELECT AC_GL_NO, NVL(BRANCH_CODE, GLOBAL.HEAD_OFFICE)
              INTO P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC,
                   P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
              FROM STTB_ACCOUNT
             WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
               AND AUTH_STAT = 'A'
               AND AC_GL_REC_STATUS = 'O';

          EXCEPTION
            WHEN NO_DATA_FOUND THEN

              IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('FTR', 'DFT', 'CFT') THEN
                --sampath added for Dr IBFT and Cr IBFT for CSS
                DBG('Virtual Account Case p_ty_atm_txn_rec.to_acc:' ||
                    P_TY_ATM_TXN_REC.TO_ACC);
                DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO := NULL;
                G_VIR_ACC_FLAG                      := 'Y';
                IF NOT
                    STPKS_VIRTUALACC_UTILS.FN_VALIDATE_VIRTUALACC(P_TY_ATM_TXN_REC.TO_ACC,
                                                                  P_TY_ATM_TXN_REC.TXN_CCY_FCC,
                                                                  'C',
                                                                  P_ERRCODE,
                                                                  P_ERRPARAM) THEN
                  P_ERRCODE  := 'SW-CRD-01';
                  P_ERRPARAM := P_TY_ATM_TXN_REC.TO_ACC;
                  DBG('E',
                      'fn_cardacc_to_fccacc : No data found in sttm_virtual_accounts ' ||
                      P_ERRCODE || '~' || P_ERRPARAM);
                  RETURN FALSE;
                ELSE

                  SELECT COUNT(1)
                    INTO L_COUNT
                    FROM STTMS_VIRTUAL_ACCOUNTS
                   WHERE VIR_ACC_NO = P_TY_ATM_TXN_REC.TO_ACC
                     AND CCY = P_TY_ATM_TXN_REC.TXN_CCY_FCC
                     AND RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y';

                  IF L_COUNT = 0 THEN
                    SELECT COUNT(1)
                      INTO L_COUNT
                      FROM STTMS_VIRTUAL_ACCOUNTS
                     WHERE VIR_ACC_NO = P_TY_ATM_TXN_REC.TO_ACC
                       AND RECORD_STAT = 'O'
                       AND ONCE_AUTH = 'Y';

                    IF L_COUNT = 0 THEN
                      P_ERRCODE  := 'SW-CRD-01';
                      P_ERRPARAM := P_TY_ATM_TXN_REC.TO_ACC;
                      DBG('E',
                          'Virtual account is closed or doesnt exist' ||
                          P_ERRCODE || '~' || P_ERRPARAM);
                      RETURN FALSE;
                    END IF;
                  END IF;
                  DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO     := P_TY_ATM_TXN_REC.TO_ACC;
                  DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
                END IF;

              ELSE

                P_ERRCODE  := 'SW-CRD-01';
                P_ERRPARAM := P_TY_ATM_TXN_REC.TO_ACC;
                DBG('E',
                    'fn_cardacc_to_fccacc : No data found in sttb_account ' ||
                    P_ERRCODE || '~' || P_ERRPARAM);
                RETURN FALSE;
              END IF;
          END;

          IF P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC <> NULL THEN
            SELECT AC_STAT_DE_POST
              INTO L_AC_STAT_DE_POST
              FROM STTM_CUST_ACCOUNT
             WHERE CUST_AC_NO = P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC
               AND BRANCH_CODE = P_TY_ATM_TXN_REC.OFF_BRANCH_CODE
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
            DBG('l_ac_stat_de_post' || L_AC_STAT_DE_POST);
            IF L_AC_STAT_DE_POST != 'Y' THEN
              P_ERRCODE  := 'AC-VAC08';
              P_ERRPARAM := P_TY_ATM_TXN_REC.OFF_ACC_NO_FCC;
              RETURN FALSE;
            END IF;
          END IF;

        END IF;
      END IF;

      IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('CFT') THEN
        --sampath for css added to derive the currency for debit leg for CSS
        P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC := FN_GET_ISO_CURRENCY_CODE(P_TY_ATM_TXN_REC.VERIFY_DATA);

      ELSE
        --sampath for css added to derive the currency for debit leg for CSS

        IF P_TY_ATM_TXN_REC.RSV_60 IN ('CCONUS') THEN
          --sampath added else for credit card cash withdrawal
          P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC := FN_GET_ISO_CURRENCY_CODE(P_TY_ATM_TXN_REC.VERIFY_DATA); --sampath added else for credit card cash withdrawal
        ELSE
          --sampath added else for credit card cash withdrawal
      BEGIN
        SELECT CCY
          INTO P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC
           AND BRANCH_CODE = P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;

        DBG('p_ty_atm_txn_rec.txn_acc_no_fcc --> ' ||
            P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN

          BEGIN
            SELECT CURRENCY, OPEN_LINE_LOAN

              INTO P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC, G_CL_OLL_ACC

              FROM CLTBS_ACCOUNT_MASTER
             WHERE ACCOUNT_NUMBER = P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC
               AND BRANCH_CODE = P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN

              P_ERRCODE  := 'SW-CCY-02';
              P_ERRPARAM := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
              RETURN FALSE;
          END;
      END;
        END IF; --sampath for css added to derive the currency for debit leg for CSS
      END IF; --sampath added else for credit card cash withdrawal

      IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'R' THEN
        GLOBAL.PR_INIT(NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                           P_TY_ATM_TXN_REC.ACC_BRANCH_CODE),
                       P_TY_ATM_TXN_REC.USER_ID);
        P_TY_ATM_TXN_REC.TXN_DT := GLOBAL.APPLICATION_DATE;
      END IF;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    RETURN TRUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERRCODE  := 'SW-CRD-01';
      P_ERRPARAM := P_TY_ATM_TXN_REC.PAN || '~' ||
                    P_TY_ATM_TXN_REC.FROM_ACC || '~' ||
                    P_TY_ATM_TXN_REC.TO_ACC;
      DBG('E',
          'fn_cardacc_to_fccacc : No data found in swtm_card_detail ' ||
          P_ERRCODE || '~' || P_ERRPARAM);
      RETURN FALSE;
    WHEN OTHERS THEN
      P_ERRCODE := 'SW-CRD-02';
      DBG('E', 'fn_cardacc_to_fccacc : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;
  END FN_CARDACC_TO_FCCACC;

  FUNCTION FN_GET_PRODUCT(P_FC_LIT     IN SWTMS_FCLITERAL_CODE.FC_LITERAL%TYPE,
                          P_CATEGORY   IN VARCHAR2,
                          P_NETWORK    IN VARCHAR2,
                          P_ACQ_CTRY   IN VARCHAR2,
                          P_CUST_CTGRY IN VARCHAR2,
                          P_CHANNEL    IN VARCHAR2,
                          P_PRODUCT    OUT NOCOPY SWTM_PRODUCT_MAPPING.PRODUCT_CODE%TYPE,
                          P_ERROR      IN OUT VARCHAR2,
                          P_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN
    DBG('fn_get_product : Coming inside Gwpks_CreateSWTransaction.fn_get_product ');
    DBG('l_fc_lit -->' || P_FC_LIT || '<--');
    DBG('p_category -->' || P_CATEGORY || '<--');
    DBG('p_network -->' || P_NETWORK || '<--');
    DBG('p_acq_ctry -->' || P_ACQ_CTRY || '<--');
    DBG('p_cust_ctgry -->' || P_CUST_CTGRY || '<--');
    DBG('p_channel -->' || P_CHANNEL || '<--');

    IF NOT SWPKSS_UTILS.FN_GET_SW_PROD_MAP_REC_WRP(P_FC_LIT,
                                                   P_CATEGORY,
                                                   P_NETWORK,
                                                   P_ACQ_CTRY,
                                                   P_CUST_CTGRY,
                                                   P_CHANNEL,
                                                   P_ERROR,
                                                   P_PARAM)

     THEN
      DBG('error assignment removed');

      RETURN FALSE;
    ELSE
      DBG('product found');
      P_PRODUCT := SWPKSS_UTILS.G_TBL_SW_PROD_MAP.PRODUCT_CODE;
      RETURN TRUE;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('E', 'Inside when others :' || SQLERRM);
      P_ERROR := 'SW-PRD-01';
      RETURN FALSE;
  END FN_GET_PRODUCT;

  FUNCTION FN_PRODUCT_DERIVE(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                             P_ERRCODE        IN OUT VARCHAR2,
                             P_ERRPARAM       IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS

    L_FC_LIT   SWTMS_FCLITERAL_CODE.FC_LITERAL%TYPE;
    L_CATEGORY VARCHAR2(1);
    L_ACQ_CTRY VARCHAR2(3);

    L_NETWORK    VARCHAR2(11);
    L_CUST_CTGRY VARCHAR2(10);
    L_PRODUCT    SWTMS_PRODUCT_MAPPING.PRODUCT_CODE%TYPE;
    L_CHANNEL    SWTB_PARAM.CHANNEL%TYPE;

    L_TB_CUSTOM_DATA       GLOBAL.TY_TB_CUSTOM_DATA;
    L_TB_CUSTOM_DATA_EMPTY GLOBAL.TY_TB_CUSTOM_DATA;
    L_FN_CALL_ID           NUMBER;

  BEGIN

    DBG('fn_product_derive : Coming inside Gwpks_CreateSWTransaction.fn_product_derive ');

    DBG('Inside fn_get_product');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      G_FN_CALL_ID := 1;
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_PRODUCT_DERIVE(P_TY_ATM_TXN_REC,
                                                       G_FN_CALL_ID,
                                                       P_ERRCODE,
                                                       P_ERRPARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.Fn_Product_Derive returned false ');
        RETURN FALSE;
      END IF;
    END IF;

    L_FC_LIT     := P_TY_ATM_TXN_REC.FC_LITERAL;
    L_CATEGORY   := P_TY_ATM_TXN_REC.OFFUS_ONUS;
    L_ACQ_CTRY   := P_TY_ATM_TXN_REC.ACQ_CTRY_DERIVED;
    L_NETWORK    := P_TY_ATM_TXN_REC.NETWORK_ID;
    L_CHANNEL    := P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL;
    L_CUST_CTGRY := P_TY_ATM_TXN_REC.CUSTOMER_CATEGORY;

    DBG('p_ty_atm_txn_rec.customer_category :: ' ||
        P_TY_ATM_TXN_REC.CUSTOMER_CATEGORY);

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('seling1 -' || P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
          P_TY_ATM_TXN_REC.OFFUS_ONUS || ',' || L_NETWORK || ',' ||
          P_TY_ATM_TXN_REC.ACQ_INST_CTRY || ',' || L_CUST_CTGRY || ',' ||
          L_CHANNEL);

      --sampath starts to derive the acquiring country
      IF P_TY_ATM_TXN_REC.NETWORK_ID = 'VISA' AND
         P_TY_ATM_TXN_REC.OFFUS_ONUS IN ('R', 'F') /* AND
                     P_TY_ATM_TXN_REC.fc_literal IN ('CAW', 'CAB')*/
       THEN
        P_TY_ATM_TXN_REC.ACQ_INST_CTRY := SUBSTR(P_TY_ATM_TXN_REC.ACCEPT_ADDR,
                                                 39,
                                                 2);
        IF P_TY_ATM_TXN_REC.ACQ_INST_CTRY = 'KH' THEN
          L_ACQ_CTRY := P_TY_ATM_TXN_REC.ACQ_INST_CTRY;
        ELSE
          L_ACQ_CTRY := 'ALL';
        END IF;
      END IF;
      DBG('P_TY_ATM_TXN_REC.ACQ_INST_CTRY=' ||
          P_TY_ATM_TXN_REC.ACQ_INST_CTRY);
      --sampath ends to derive the acquiring country
      IF NOT FN_GET_PRODUCT(L_FC_LIT,
                            L_CATEGORY,
                            L_NETWORK,
                            L_ACQ_CTRY,
                            L_CUST_CTGRY,
                            L_CHANNEL,
                            L_PRODUCT,
                            P_ERRCODE,
                            P_ERRPARAM) THEN

        DBG('seling2 -' || P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
            P_TY_ATM_TXN_REC.OFFUS_ONUS || ',' || L_NETWORK || ',ALL,' ||
            L_CUST_CTGRY || ',' || L_CHANNEL);
        IF NOT FN_GET_PRODUCT(L_FC_LIT,
                              L_CATEGORY,
                              L_NETWORK,
                              'ALL',
                              L_CUST_CTGRY,
                              L_CHANNEL,
                              L_PRODUCT,
                              P_ERRCODE,
                              P_ERRPARAM) THEN

          DBG('seling3 -' || P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
              P_TY_ATM_TXN_REC.OFFUS_ONUS || ',' || L_NETWORK || ',' ||
              L_ACQ_CTRY || ',ALL,' || L_CHANNEL);
          IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                L_CATEGORY,
                                L_NETWORK,
                                L_ACQ_CTRY,
                                'ALL',
                                L_CHANNEL,
                                L_PRODUCT,
                                P_ERRCODE,
                                P_ERRPARAM) THEN
            DBG('seling4 -' || P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                P_TY_ATM_TXN_REC.OFFUS_ONUS || ',ALL,' || L_ACQ_CTRY || ',' ||
                L_CUST_CTGRY || ',' || L_CHANNEL);

            IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                  L_CATEGORY,
                                  'ALL',
                                  L_ACQ_CTRY,
                                  L_CUST_CTGRY,
                                  L_CHANNEL,
                                  L_PRODUCT,
                                  P_ERRCODE,
                                  P_ERRPARAM) THEN

              DBG('seling5 -' || P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                  P_TY_ATM_TXN_REC.OFFUS_ONUS || ',' || L_NETWORK ||
                  ',ALL,ALL,' || L_CHANNEL);
              IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                    L_CATEGORY,
                                    L_NETWORK,
                                    'ALL',
                                    'ALL',
                                    L_CHANNEL,
                                    L_PRODUCT,
                                    P_ERRCODE,
                                    P_ERRPARAM) THEN

                DBG('seling6 -' || P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                    P_TY_ATM_TXN_REC.OFFUS_ONUS || ',ALL,ALL,' ||
                    L_CUST_CTGRY || ',' || L_CHANNEL);
                IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                      L_CATEGORY,
                                      'ALL',
                                      'ALL',
                                      L_CUST_CTGRY,
                                      L_CHANNEL,
                                      L_PRODUCT,
                                      P_ERRCODE,
                                      P_ERRPARAM) THEN

                  DBG('seling7 -' || P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                      P_TY_ATM_TXN_REC.OFFUS_ONUS || ',ALL,' || L_ACQ_CTRY ||
                      ',ALL,' || L_CHANNEL);
                  IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                        L_CATEGORY,
                                        'ALL',
                                        L_ACQ_CTRY,
                                        'ALL',
                                        L_CHANNEL,
                                        L_PRODUCT,
                                        P_ERRCODE,
                                        P_ERRPARAM) THEN
                    DBG('seling8 -' || P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                        P_TY_ATM_TXN_REC.OFFUS_ONUS || L_CATEGORY ||
                        ',ALL,ALL,ALL,' || L_CHANNEL);
                    IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                          L_CATEGORY,
                                          'ALL',
                                          'ALL',
                                          'ALL',
                                          L_CHANNEL,
                                          L_PRODUCT,
                                          P_ERRCODE,
                                          P_ERRPARAM) THEN

                      DBG('ALL seling9 -' || L_FC_LIT || ',' || L_CATEGORY || ',' ||
                          L_NETWORK || ',' || L_ACQ_CTRY || ',' ||
                          L_CUST_CTGRY || ',ALL');
                      IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                            L_CATEGORY,
                                            L_NETWORK,
                                            L_ACQ_CTRY,
                                            L_CUST_CTGRY,
                                            'ALL',
                                            L_PRODUCT,
                                            P_ERRCODE,
                                            P_ERRPARAM) THEN

                        DBG('ALL seling10 -' ||
                            P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                            P_TY_ATM_TXN_REC.OFFUS_ONUS || ',' ||
                            L_NETWORK || ',ALL,' || L_CUST_CTGRY || ',ALL');
                        IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                              L_CATEGORY,
                                              L_NETWORK,
                                              'ALL',
                                              L_CUST_CTGRY,
                                              'ALL',
                                              L_PRODUCT,
                                              P_ERRCODE,
                                              P_ERRPARAM) THEN

                          DBG('ALL seling11 -' ||
                              P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                              P_TY_ATM_TXN_REC.OFFUS_ONUS || ',' ||
                              L_NETWORK || ',' || L_ACQ_CTRY || ',ALL,ALL');
                          IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                                L_CATEGORY,
                                                L_NETWORK,
                                                L_ACQ_CTRY,
                                                'ALL',
                                                'ALL',
                                                L_PRODUCT,
                                                P_ERRCODE,
                                                P_ERRPARAM) THEN

                            DBG('ALL seling12 -' || L_FC_LIT || ',' ||
                                L_CATEGORY || ',ALL,' || L_ACQ_CTRY || ',' ||
                                L_CUST_CTGRY || ',ALL');
                            IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                                  L_CATEGORY,
                                                  'ALL',
                                                  L_ACQ_CTRY,
                                                  L_CUST_CTGRY,
                                                  'ALL',
                                                  L_PRODUCT,
                                                  P_ERRCODE,
                                                  P_ERRPARAM) THEN

                              DBG('ALL seling13 -' ||
                                  P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                                  P_TY_ATM_TXN_REC.OFFUS_ONUS ||
                                  ',ALL,ALL,' || L_CUST_CTGRY || ',ALL');
                              IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                                    L_CATEGORY,
                                                    L_NETWORK,
                                                    'ALL',
                                                    'ALL',
                                                    'ALL',
                                                    L_PRODUCT,
                                                    P_ERRCODE,
                                                    P_ERRPARAM) THEN

                                DBG('ALL seling14 -' ||
                                    P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                                    P_TY_ATM_TXN_REC.OFFUS_ONUS ||
                                    ',ALL,ALL,' || L_CUST_CTGRY || ',ALL');
                                IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                                      L_CATEGORY,
                                                      'ALL',
                                                      'ALL',
                                                      L_CUST_CTGRY,
                                                      'ALL',
                                                      L_PRODUCT,
                                                      P_ERRCODE,
                                                      P_ERRPARAM) THEN

                                  DBG('ALL seling15 -' ||
                                      P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                                      P_TY_ATM_TXN_REC.OFFUS_ONUS ||
                                      ',ALL,ALL,' || L_CUST_CTGRY ||
                                      ',ALL');
                                  IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                                        L_CATEGORY,
                                                        'ALL',
                                                        L_ACQ_CTRY,
                                                        'ALL',
                                                        'ALL',
                                                        L_PRODUCT,
                                                        P_ERRCODE,
                                                        P_ERRPARAM) THEN
                                    DBG('ALL seling16 -' ||
                                        P_TY_ATM_TXN_REC.FC_LITERAL || ',' ||
                                        P_TY_ATM_TXN_REC.OFFUS_ONUS ||
                                        ',ALL,ALL,ALL,ALL');
                                    IF NOT FN_GET_PRODUCT(L_FC_LIT,
                                                          L_CATEGORY,
                                                          'ALL',
                                                          'ALL',
                                                          'ALL',
                                                          'ALL',
                                                          L_PRODUCT,
                                                          P_ERRCODE,
                                                          P_ERRPARAM) THEN

                                      DBG('E',
                                          'error while getting product details :' ||
                                          SQLERRM);
                                      P_ERRCODE := 'SW-PRD-01';
                                      RETURN FALSE;
                                    END IF;
                                  END IF;
                                END IF;
                              END IF;
                            END IF;
                          END IF;
                        END IF;
                      END IF;
                    END IF;
                  END IF;
                END IF;
              END IF;
            END IF;
          END IF;
        END IF;
      END IF;

      P_TY_ATM_TXN_REC.PRODUCT_CODE := L_PRODUCT;
      DBG('success product is: ' || P_TY_ATM_TXN_REC.PRODUCT_CODE);

      --sampath starts
      IF P_TY_ATM_TXN_REC.network_id = 'VISA' THEN
        P_TY_ATM_TXN_REC.ACQ_INST_CTRY := NULL;
      END IF;
      --sampath ends
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    RETURN TRUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERRCODE  := 'SW-PRD-02';
      P_ERRPARAM := P_TY_ATM_TXN_REC.FC_LITERAL || '~' ||
                    P_TY_ATM_TXN_REC.OFFUS_ONUS;
      DBG('fn_product_derive : No data found in iftm_atm_product_map ' ||
          P_ERRCODE || '~' || P_ERRPARAM);
      RETURN FALSE;
    WHEN OTHERS THEN
      P_ERRCODE := 'SW-PRD-03';
      DBG('fn_product_derive : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;
  END FN_PRODUCT_DERIVE;

  FUNCTION FN_UPDATE_RESP(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                          P_ERR_CODE       IN OUT VARCHAR2,
                          P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
    L_MSG_TYPE_TEMP VARCHAR2(16) DEFAULT NULL;
    L_KEY_TEMP      VARCHAR2(255) DEFAULT NULL;
    L_PURGE_DT      DATE;
    L_WORK_PROGRESS VARCHAR2(1);

    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    DBG('fn_update_resp : Coming inside fn_update_resp ');
    BEGIN

      L_PURGE_DT := P_TY_ATM_TXN_REC.TXN_DT +
                    P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.BLOCK_EXP_DAYS;

      DBG('l_purge_dt........ :' || L_PURGE_DT);
      DBG('p_ty_atm_txn_rec.trn_ref_no_fcc......... :' ||
          P_TY_ATM_TXN_REC.TRN_REF_NO_FCC);
      DBG('p_ty_atm_txn_rec.add_amt ........ :' ||
          P_TY_ATM_TXN_REC.ADD_AMT);
      DBG('p_ty_atm_txn_rec.resp_code ........ :' ||
          P_TY_ATM_TXN_REC.RESP_CODE);
      DBG('p_ty_atm_txn_rec.xref ........ :' || P_TY_ATM_TXN_REC.XREF);

      G_RESP_CODE := P_TY_ATM_TXN_REC.RESP_CODE;

      IF P_TY_ATM_TXN_REC.RESP_CODE IN ('00', '000', '0000') THEN
        L_WORK_PROGRESS := 'S';

        IF NOT P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL_LIMIT = 'N' THEN
          IF P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' THEN
            IF NOT
                FN_UPDATE_LIMITS(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
              DBG('E', 'Fn_Update_Limits returned false ');
              RETURN FALSE;
            END IF;
          END IF;
        END IF;

      ELSE
        L_WORK_PROGRESS := 'F';
      END IF;

      DBG('l_work_progress :' || L_WORK_PROGRESS);
      DBG('p_ty_atm_txn_rec.resp_code ........ :' ||
          P_TY_ATM_TXN_REC.RESP_CODE);

      IF P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO = '0' THEN
        P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO := NULL;
      END IF;

      P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO := LPAD(P_TY_ATM_TXN_REC.AUTH_CODE,
                                               12,
                                               '0');

      IF L_WORK_PROGRESS = 'S' THEN
        IF P_TY_ATM_TXN_REC.FIN_TXN_COUNT > 0 THEN
          P_TY_ATM_TXN_REC.FIN_IMPACT := 'Y';
        ELSE
          P_TY_ATM_TXN_REC.FIN_IMPACT := 'N';
        END IF;
      END IF;

      UPDATE SWTBS_TXN_LOG
         SET RESP_CODE       = P_TY_ATM_TXN_REC.RESP_CODE,
             WORK_PROGRESS   = L_WORK_PROGRESS,
             ERR_PARAM       = P_ERR_PARAM,
             ERROR_CODE      = P_ERR_CODE,
             TRN_REF_NO      = P_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
             AMOUNT_BLOCK_NO = P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO,
             PURGE_DATE      = L_PURGE_DT,
             OFFUS_ONUS      = P_TY_ATM_TXN_REC.OFFUS_ONUS,
             DCN             = P_TY_ATM_TXN_REC.DCN

            ,
             ADD_AMT         = P_TY_ATM_TXN_REC.ADD_AMT,
             MINI_STMT_DATA  = P_TY_ATM_TXN_REC.MINI_STMT_DATA,
             PRE_AUTH_SEQ_NO = P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO

            ,
             FIN_IMP = P_TY_ATM_TXN_REC.FIN_IMPACT

            ,
             DB_OUT_TIME = TO_CHAR(SYSTIMESTAMP, 'YYYY:DD:MM HH:MI:SS.FF')
       WHERE

       XREF = P_TY_ATM_TXN_REC.XREF;
      DBG('Test 1::' || SQLERRM);
      DBG('Test 2::' || SQLCODE);
      DBG('p_ty_atm_txn_rec.orig_txn_amt :' ||
          P_TY_ATM_TXN_REC.ORIG_TXN_AMT);
      DBG('p_ty_atm_txn_rec.txn_amt :' || P_TY_ATM_TXN_REC.TXN_AMT);
      IF P_TY_ATM_TXN_REC.ORIG_TXN_AMT IS NOT NULL AND
         P_TY_ATM_TXN_REC.ORIG_TXN_AMT <> P_TY_ATM_TXN_REC.TXN_AMT THEN

        L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 1) ||
                           '200');
        DBG('fn_txn_contol : Deriving PKEY ');

        IF NOT SWPKS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                             P_TY_ATM_TXN_REC.P_KEY,
                                             L_MSG_TYPE_TEMP,
                                             P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                             L_KEY_TEMP) THEN
          DBG('E',
              'fn_txn_contol : swpks_utils.fn_get_parent_key returned false ');
          P_ERR_CODE  := 'SW-KEY-03';
          P_ERR_PARAM := NULL;
          RETURN FALSE;
        END IF;

        UPDATE SWTBS_TXN_LOG
           SET TRN_REF_NO      = P_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
               AMOUNT_BLOCK_NO = P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO
         WHERE

         XREF = P_TY_ATM_TXN_REC.XREF;
        L_MSG_TYPE_TEMP := (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 1) ||
                           '100');
        DBG('fn_txn_contol : Deriving PKEY ');

        IF NOT SWPKS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                             P_TY_ATM_TXN_REC.P_KEY,
                                             L_MSG_TYPE_TEMP,
                                             P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                             L_KEY_TEMP) THEN
          DBG('E',
              'fn_txn_contol : swpks_utils.fn_get_parent_key returned false ');
          P_ERR_CODE  := 'SW-KEY-03';
          P_ERR_PARAM := NULL;
          RETURN FALSE;
        END IF;

        UPDATE SWTBS_TXN_LOG
           SET TRN_REF_NO      = P_TY_ATM_TXN_REC.TRN_REF_NO_FCC,
               AMOUNT_BLOCK_NO = P_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO
         WHERE

         XREF = P_TY_ATM_TXN_REC.XREF;

      END IF;

      COMMIT;

      RETURN TRUE;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('E', 'In fn_update_resp ' || SQLERRM);
        P_ERR_CODE  := 'SW-UPD-01';
        P_ERR_PARAM := P_TY_ATM_TXN_REC.P_KEY;
        RETURN FALSE;
    END;
  END FN_UPDATE_RESP;

  FUNCTION FN_MAP_ERR_RESPCODE(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS

    L_RESP_CODE_2003 VARCHAR2(4) DEFAULT NULL;
    L_RESP_CODE_1993 VARCHAR2(3) DEFAULT NULL;
    L_RESP_CODE_1987 VARCHAR2(2) DEFAULT NULL;

    L_COUNT    NUMBER;
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
    L_TYPE     ERTB_MSGS.TYPE%TYPE;

  BEGIN

    DBG('fn_map_err_respcode : Coming inside fn_map_err_respcode ');

    IF P_ERR_CODE IS NOT NULL THEN
      DBG('coming inside with errors:' || P_ERR_CODE);
      L_COUNT := REGEXP_COUNT(P_ERR_CODE, ';');
      IF L_COUNT > 0 THEN
        FOR I IN REVERSE 1 .. L_COUNT LOOP
          L_ERR_CODE := CSPKES_MISC.FN_GETPARAM(P_ERR_CODE, I, ';');
          DBG('l_err_code is ' || L_ERR_CODE);
          L_TYPE := OVPKS.FN_GETTYPE(L_ERR_CODE);
          DBG('l_type is ' || L_TYPE);
          IF L_TYPE = 'E' THEN
            P_ERR_CODE := L_ERR_CODE;
            DBG('Final error code is @@ ' || P_ERR_CODE);
            EXIT;
          END IF;
        END LOOP;
      END IF;
    END IF;

    DBG('The error code to get the response map is ' || P_ERR_CODE);

    IF NOT SWPKSS_UTILS.FN_GET_SW_RESP_MAP_WRP_REC(P_ERR_CODE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM) THEN
      DBG('No response map found');
      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
        P_TY_ATM_TXN_REC.RESP_CODE := '1000';
      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
        P_TY_ATM_TXN_REC.RESP_CODE := '100';
      ELSE
        P_TY_ATM_TXN_REC.RESP_CODE := '05';
      END IF;
    ELSE
      DBG('assign iso response code');
      L_RESP_CODE_2003 := SWPKSS_UTILS.G_TBL_SW_RESP_MAP_REC.ISO_2003_RESP_CODE;
      L_RESP_CODE_1993 := SWPKSS_UTILS.G_TBL_SW_RESP_MAP_REC.ISO_1993_RESP_CODE;
      L_RESP_CODE_1987 := SWPKSS_UTILS.G_TBL_SW_RESP_MAP_REC.ISO_1987_RESP_CODE;

      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
        P_TY_ATM_TXN_REC.RESP_CODE := L_RESP_CODE_2003;
      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
        P_TY_ATM_TXN_REC.RESP_CODE := L_RESP_CODE_1993;
      ELSE
        P_TY_ATM_TXN_REC.RESP_CODE := L_RESP_CODE_1987;
      END IF;
    END IF;

    RETURN TRUE;

  EXCEPTION

    WHEN NO_DATA_FOUND THEN

      IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
        P_TY_ATM_TXN_REC.RESP_CODE := '1000';
      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
        P_TY_ATM_TXN_REC.RESP_CODE := '100';
      ELSE
        P_TY_ATM_TXN_REC.RESP_CODE := '05';
      END IF;

      RETURN TRUE;

    WHEN OTHERS THEN

      DBG('E', 'In fn_update_resp ' || SQLERRM);
      P_ERR_PARAM                := P_ERR_CODE;
      P_ERR_CODE                 := 'SW-UPD-01';
      P_TY_ATM_TXN_REC.RESP_CODE := '05';
      RETURN FALSE;

  END FN_MAP_ERR_RESPCODE;

  FUNCTION FN_PROCESS_REQ(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                          SETL_TXN_FLG     IN VARCHAR2,
                          P_ERR_CODE       IN OUT VARCHAR2,
                          P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
    L_TXN_TYPE VARCHAR2(1);

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_ACCREC STTBS_ACCOUNT%ROWTYPE;
  BEGIN

    DBG('fn_process_req : Coming inside fn_process_req ');
    BEGIN

      IF NOT SWPKSS_UTILS.FN_SW_XREF_GEN(P_TY_ATM_TXN_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAM) THEN
        DBG('E', 'swpks_utils.fn_sw_xref_gen returned FALSE....... ');
        RETURN FALSE;
      END IF;

      IF NOT FN_TXN_CONTOL_LOG(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E', 'fn_txn_contol_log returned false ');
        RETURN FALSE;
      END IF;

      IF NOT
          FN_MANDATORY_VALIDATE(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E', 'fn_mandatory_validate returned false ');
        RETURN FALSE;
      END IF;

      IF NOT FN_TXN_CONTOL(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E', 'fn_txn_contol returned false ');
        RETURN FALSE;
      END IF;

      IF NOT FN_DERIVE_NORMAL(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E', 'fn_derive_normal returned false ');
        RETURN FALSE;
      END IF;

      DBG('Check For Limits--');
      DBG('Proc_code_type --> ' ||
          SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2));
      DBG('Msg Type --> ' || SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1));
      IF NOT P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL_LIMIT = 'N' THEN
        IF NOT (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('00', '01'))

           OR P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN
          DBG('Skip, Channel Limits Check Not Required--');
          NULL;
        ELSE
          IF NOT FN_CHECK_CHANNEL_LIMITS(P_TY_ATM_TXN_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAM) THEN
            DBG('E', 'Fn_Check_Channel_Limits returned false ');

            DBG('p_Err_Code-->' || P_ERR_CODE);
            IF (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 3)) = '220' AND
               P_ERR_CODE IS NOT NULL THEN
              IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.AMOUNT_BLOCK = 'Y' THEN
                DBG('inside amount block check' || GLOBAL.BRANCH_STATUS);
                IF GLOBAL.BRANCH_STATUS = 'N' THEN
                  L_TXN_TYPE := 'B';
                ELSE
                  IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN
                    L_TXN_TYPE := 'P';
                  ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.SETL_BEFORE_FILE = 'Y' THEN
                    L_TXN_TYPE := 'P';
                  ELSE
                    L_TXN_TYPE := 'B';
                  END IF;
                END IF;

              ELSE
                IF P_TY_ATM_TXN_REC.OFFUS_ONUS = 'O' THEN
                  L_TXN_TYPE := 'P';
                ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.SETL_BEFORE_FILE = 'Y' OR
                      P_TY_ATM_TXN_REC.OFFUS_ONUS = 'F' THEN
                  L_TXN_TYPE := 'P';
                ELSE
                  L_TXN_TYPE := 'B';
                END IF;
              END IF;
              IF NOT SWPKS_FINHANDLER.FN_INSERT_JOB(P_TY_ATM_TXN_REC,
                                                    L_TXN_TYPE,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM) THEN
                DBG('E',
                    'Failed while calling fn_process_control' || SQLCODE);
                RETURN FALSE;
              END IF;
            END IF;

            RETURN FALSE;
          END IF;
        END IF;
      END IF;

      IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('CHB', 'BEQ', 'BIQ', 'ADS', 'MST') AND
         SETL_TXN_FLG = 'N' THEN
        IF NOT SWPKSS_NONFINHANDLER.FN_MAIN(P_TY_ATM_TXN_REC,
                                            P_ERR_CODE,
                                            P_ERR_PARAM) THEN

          DBG('gwpks_switch_nonfin.fn_main');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          RETURN FALSE;
        END IF;
      END IF;

      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_PROCESS_REQ(P_TY_ATM_TXN_REC,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM) THEN
        DBG('E', 'gwpks_ext_switchservice.Fn_Process_Req returned false ');
        RETURN FALSE;
      END IF;

      IF P_TY_ATM_TXN_REC.FC_LITERAL IN
         ('CAW',
      'QCT',
          'CCP', --sampath starts for credit card payment via ATM
          'FTR',
          'DFT', --sampath added for Dr IBFT for CSS
          'CFT', --sampath added for Cr IBFT for CSS
          'PAY',
          'CDP',
      'PCT', --sampath added PCT for UPI
          'NPA',
          'CAB',
          'PAD',
          'MRE',
          'MRA',
          'MER',
          'CQP') OR P_TY_ATM_TXN_REC.CHARGE_NON_FIN_TXN = 'Y' THEN
        DBG('Calling swpkss_finhandler.fn_main');

        IF NOT SWPKSS_FINHANDLER.FN_MAIN(P_TY_ATM_TXN_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAM) THEN
          DBG('swpkss_finhandler.fn_main');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          RETURN FALSE;
        END IF;

      END IF;

      DBG('Calling cluster process req...');
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT GWPKS_CREATESWTXN_CLUSTER.FN_PROCESS_REQ(P_TY_ATM_TXN_REC,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
          DBG('Error while calling CLUSTER gwpks_createswtxn_cluster.fn_process_req...' ||
              P_ERR_CODE);
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          RETURN FALSE;
        END IF;

      END IF;

      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In fn_process_req ' || SQLERRM);
        P_ERR_CODE := 'SW-REQ-01';
        RETURN FALSE;
    END;
  END FN_PROCESS_REQ;

  FUNCTION SOURCE RETURN VARCHAR2 AS
  BEGIN
    RETURN G_SOURCE;
  END;

  FUNCTION FN_GET_TSVAL(P_TS_VALUES IN OUT NOCOPY VARCHAR2,
                        P_CUR_NO    IN OUT NOCOPY SIMPLE_INTEGER,
                        P_LEN       IN OUT NOCOPY SIMPLE_INTEGER)
    RETURN VARCHAR2 IS
    L_OUTVAL VARCHAR2(32767);
  BEGIN
    P_LEN    := INSTR(P_TS_VALUES, '~', P_CUR_NO) - P_CUR_NO;
    L_OUTVAL := SUBSTR(P_TS_VALUES, P_CUR_NO, P_LEN);
    P_CUR_NO := P_CUR_NO + P_LEN + 1;
    RETURN L_OUTVAL;
  END FN_GET_TSVAL;

  PROCEDURE PR_MSG_HANDLER(P_BRANCH      IN OUT NOCOPY VARCHAR2,
                           P_USER_ID     IN OUT NOCOPY VARCHAR2,
                           P_SOURCE      IN OUT NOCOPY VARCHAR2,
                           P_CHANNEL     IN OUT NOCOPY VARCHAR2,
                           P_ISO_MESSAGE IN OUT NOCOPY VARCHAR2,
                           P_ERR_CODE    IN OUT NOCOPY VARCHAR2,
                           P_ERR_PARAM   IN OUT NOCOPY VARCHAR2) AS
    L_TY_ATM_TXN_REC TY_ATM_TXN_REC;
    ERROR_EXCEPTION EXCEPTION;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      GWPKSS_EXT_SWITCHSERVICE.PR_PRE_MSG_HANDLER(P_BRANCH,
                                                  P_USER_ID,
                                                  P_SOURCE,
                                                  P_CHANNEL,
                                                  P_ISO_MESSAGE,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM,
                                                  L_TB_CLUSTER_DATA,
                                                  L_FN_CALL_ID);
    END IF;

    GWPKSS_RESET_PKG.PR_RESET_PKG();
    GLOBAL.PR_INIT(P_BRANCH, NVL(P_USER_ID, 'FLEXSWITCH'));

    L_TY_ATM_TXN_REC                    := NULL;
    L_TY_ATM_TXN_REC.TXN_CCY_MINOR      := 0;
    L_TY_ATM_TXN_REC.SETL_CCY_MINOR     := 0;
    L_TY_ATM_TXN_REC.BILL_CCY_MINOR     := 0;
    L_TY_ATM_TXN_REC.CHARGE_NON_FIN_TXN := 'N';
    L_TY_ATM_TXN_REC.FILE_PROCESS       := 'N';

    SELECT TO_CHAR(SYSTIMESTAMP, 'YYYY:DD:MM HH:MI:SS.FF')
      INTO G_DB_IN_TIME
      FROM DUAL;
    L_TY_ATM_TXN_REC.RESP_CODE := '111';
    P_ERR_CODE                 := NULL;
    DBG('[p_Source]=>' || P_SOURCE);
    CSPKSS_REQ_GLOBAL.G_HEADER('SOURCE') := NVL(P_SOURCE, 'FLEXSWITCH');
    DBG('Cspks_Req_Global.g_Header source ' ||
        CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));

    IF NOT SWPKSS_UTILS.FN_GET_SWTB_PARAM_REC_WRP(P_CHANNEL,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM) THEN
      DBG('Exception while selecting data from swtbs_param');
      P_ERR_CODE := 'SW-PRM-01';
      RAISE ERROR_EXCEPTION;
    ELSE
      DBG('Inside Fn_Get_swtb_param_Rec_Wrp...');
      L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG := SWPKSS_UTILS.G_TBL_SWTB_PARAM;
    END IF;

    DECLARE
      CUR SIMPLE_INTEGER := 1;
      LEN SIMPLE_INTEGER := 1;
    BEGIN
      DBG('-.[p_Iso_Message]=>' || P_ISO_MESSAGE);
      DBG('-.[ISO version]=>' ||
          L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION);
      L_TY_ATM_TXN_REC.HEDDER   := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);
      L_TY_ATM_TXN_REC.MSG_TYPE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);
      L_TY_ATM_TXN_REC.PAN      := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.PROC_CODE    := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);
      L_TY_ATM_TXN_REC.ISO_FEILD_04 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);
      L_TY_ATM_TXN_REC.ISO_FEILD_05 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_06 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.TRANS_DT_TIME := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                     CUR,
                                                     LEN);

      IF L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION NOT IN ('1', '2') THEN
        IF L_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL THEN
          DBG('E', 'Mandatory feild is NULL : 7 - Trans_Dt_Time ');
          P_ERR_CODE  := 'SW-MND-01';
          P_ERR_PARAM := '7 - Trans_Dt_Time';
          RETURN;
        END IF;
      END IF;

      L_TY_ATM_TXN_REC.BILL_FEE_AMT := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.SETL_X_RATE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.BILL_X_RATE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.STAN := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      IF L_TY_ATM_TXN_REC.STAN IS NULL THEN
        DBG('E', 'Mandatory feild is NULL : 11 - stan ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := '11 - stan';
        RETURN;
      END IF;
      L_TY_ATM_TXN_REC.LOCAL_TXN_TIME := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                      CUR,
                                                      LEN);

      IF L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION IN ('1', '2') AND
         L_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL THEN
        IF L_TY_ATM_TXN_REC.LOCAL_TXN_TIME IS NULL THEN
          DBG('E', 'Mandatory feild is NULL : 12 - Local_Txn_Time ');
          P_ERR_CODE  := 'SW-MND-01';
          P_ERR_PARAM := '12 - Local_Txn_Time';
          RETURN;
        END IF;
      END IF;

      L_TY_ATM_TXN_REC.LOCAL_TXN_DT := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.EXP_DATE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.SETL_DATE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.CONV_DATE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.CAPT_DATE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_18 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ACQ_INST_CTRY := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                     CUR,
                                                     LEN);

      IF L_TY_ATM_TXN_REC.ACQ_INST_CTRY IS NOT NULL AND
         NOT FN_CNTY_TRANS(L_TY_ATM_TXN_REC.ACQ_INST_CTRY,
                           L_TY_ATM_TXN_REC.ACQ_CTRY_DERIVED,
                           P_ERR_CODE,
                           P_ERR_PARAM) THEN
        DBG('E',
            'fn_pop_plsql_tbl : No proper translation avl for ccy type ' ||
            L_TY_ATM_TXN_REC.TXN_CCY_CODE || '~' ||
            L_TY_ATM_TXN_REC.TXN_CCY_FCC);
        P_ERR_PARAM := 'fn_pop_plsql_tbl' || '~' || P_ERR_CODE;

      END IF;
      L_TY_ATM_TXN_REC.PAN_EXT_CTRY := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_21 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.POS_ENT_MOD := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.APPL_PAN := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.NET_INT_ID := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.POS_COND_CODE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                     CUR,
                                                     LEN);

      L_TY_ATM_TXN_REC.POS_CAPT_CODE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                     CUR,
                                                     LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_27 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_28 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_29 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_30 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_31 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ACQ_INS_ID := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.FWD_INS_ID := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_34 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.TRK_2_DATA := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.TRK_3_DATA := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RRN := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.AUTH_CODE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RESP_CODE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.SERV_REST_CODE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                      CUR,
                                                      LEN);

      L_TY_ATM_TXN_REC.TERM_ID := TRIM(FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN));

      L_TY_ATM_TXN_REC.ACCEPT_ID_CODE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                      CUR,
                                                      LEN);

      L_TY_ATM_TXN_REC.ACCEPT_ADDR := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ADD_RESP_DATA := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                     CUR,
                                                     LEN);

      L_TY_ATM_TXN_REC.TRK_1_DATA := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ADD_ISO_46 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ADD_NTL_47 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_48 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.VERIFY_DATA := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_50 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_51 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.PIN_NO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.SEC_INFO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ADD_AMT := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_55 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_56 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_57 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_58 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_59 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_60 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_PVT_61 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_PVT_62 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_PVT_63 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.MAC_CHK_CODE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.BITMAP_TER := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_66 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_67 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_68 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_69 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_70 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.MSG_NO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.MSG_DATA := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ACTION_DATE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_74 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ISO_FEILD_75 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.DEBIT_NO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.DEBIT_REV_NO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.TRFR_NO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.TRFR_REV_NO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.INQ_NO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.AUTH_NO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.CREDIT_PROC_FEE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                       CUR,
                                                       LEN);

      L_TY_ATM_TXN_REC.CREDIT_TXN_FEE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                      CUR,
                                                      LEN);

      L_TY_ATM_TXN_REC.DEBIT_PROC_FEE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                      CUR,
                                                      LEN);

      L_TY_ATM_TXN_REC.DEBIT_TXN_FEE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                     CUR,
                                                     LEN);

      L_TY_ATM_TXN_REC.CREDIT_AMT := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.CREDIT_REV_AMT := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                      CUR,
                                                      LEN);

      L_TY_ATM_TXN_REC.DEBIT_AMT := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.DEBIT_REV_AMT := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                     CUR,
                                                     LEN);

      L_TY_ATM_TXN_REC.ORG_DATA := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.FILE_UPLD_CODE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                      CUR,
                                                      LEN);

      L_TY_ATM_TXN_REC.FILE_SEC_CODE := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                     CUR,
                                                     LEN);

      L_TY_ATM_TXN_REC.RESP_IND := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.SERVICE_IND := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RPLACE_AMT := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.MSG_SEC_CODE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.NET_SETL_AMT := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.PAYEE := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.SETL_INST_ID := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RCV_INST_ID := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.FILE_NAME := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.FROM_ACC := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.TO_ACC := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.TXN_DESC := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_105 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_106 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_107 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_108 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_109 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_110 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_ISO_111 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_112 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.AUTH_AGENT_INST_ID := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                          CUR,
                                                          LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_114 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_115 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_116 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_117 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_118 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_NTL_119 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_PVT_120 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_PVT_121 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_PVT_122 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.RSV_PVT_123 := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.INFO_TXT := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.ADD_NET_INFO := FN_GET_TSVAL(P_ISO_MESSAGE, CUR, LEN);

      L_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                          CUR,
                                                          LEN);
      L_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO    := SUBSTR(L_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK,
                                                    7,
                                                    12);

      L_TY_ATM_TXN_REC.MINI_STMT_DATA := FN_GET_TSVAL(P_ISO_MESSAGE,
                                                      CUR,
                                                      LEN);

      L_TY_ATM_TXN_REC.MSG_AUTH_CODE := SUBSTR(P_ISO_MESSAGE, CUR);

      IF L_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION <> 0 THEN
        L_TY_ATM_TXN_REC.ORG_DATA := L_TY_ATM_TXN_REC.RSV_ISO_56;
      END IF;

      DBG('0.[Header]=>' || L_TY_ATM_TXN_REC.HEDDER);
      DBG('1.[Msg_Type]=>' || L_TY_ATM_TXN_REC.MSG_TYPE);
      DBG('2.[PAN]=>' || L_TY_ATM_TXN_REC.PAN);
      DBG('3.[Proc_Code]=>' || L_TY_ATM_TXN_REC.PROC_CODE);
      DBG('4.[Amount transaction]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_04);
      DBG('5.[Setl_Amt]=>' || L_TY_ATM_TXN_REC.SETL_AMT);
      DBG('6.[Bill_Amt]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_06);
      DBG('7.[Trans_Dt_Time MMDDhhmmss]=>' ||
          L_TY_ATM_TXN_REC.TRANS_DT_TIME);
      DBG('8.[Bill_Fee_Amt]=>' || L_TY_ATM_TXN_REC.BILL_FEE_AMT);
      DBG('9.[Setl_X_Rate]=>' || L_TY_ATM_TXN_REC.SETL_X_RATE);
      DBG('10.[Bill_X_Rate]=>' || L_TY_ATM_TXN_REC.BILL_X_RATE);
      DBG('11.[Systems trace audit number]=>' || L_TY_ATM_TXN_REC.STAN);
      DBG('12.[Local_Txn_Time]=>' || L_TY_ATM_TXN_REC.LOCAL_TXN_TIME);
      DBG('13.[Local_Txn_Dt]=>' || L_TY_ATM_TXN_REC.LOCAL_TXN_DT);
      DBG('14.[Exp_Date]=>' || L_TY_ATM_TXN_REC.EXP_DATE);
      DBG('15.[Setl_Date]=>' || L_TY_ATM_TXN_REC.SETL_DATE);
      DBG('16.[Conv_Date]=>' || L_TY_ATM_TXN_REC.CONV_DATE);
      DBG('17.[Capt_Date]=>' || L_TY_ATM_TXN_REC.CAPT_DATE);
      DBG('18.[Message error indicator]=>' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_18);
      DBG('19.[Acq_Inst_Ctry]=>' || L_TY_ATM_TXN_REC.ACQ_INST_CTRY);
      DBG('20.[PAN_Ext_Ctry]=>' || L_TY_ATM_TXN_REC.PAN_EXT_CTRY);
      DBG('21.[Transaction life cycle id]=>' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_21);
      DBG('22.[POS_Ent_Mod]=>' || L_TY_ATM_TXN_REC.POS_ENT_MOD);
      DBG('23.[Appl_PAN]=>' || L_TY_ATM_TXN_REC.APPL_PAN);
      DBG('24.[Net_Int_Id]=>' || L_TY_ATM_TXN_REC.NET_INT_ID);
      DBG('25.[POS_Ctry_Code]=>' || L_TY_ATM_TXN_REC.POS_COND_CODE);
      DBG('26.[POS_Capt_Code]=>' || L_TY_ATM_TXN_REC.POS_CAPT_CODE);
      DBG('27.[Point of service capability]=>' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_27);
      DBG('28.[Date reconciliation CCYYMMDD]=>' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_28);
      DBG('29.[Reconciliation indicator]=>' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_29);
      DBG('30.[Amounts original]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_30);
      DBG('31.[Acquirer reference number]=>' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_31);
      DBG('32.[Acq_Ins_Id]=>' || L_TY_ATM_TXN_REC.ACQ_INS_ID);
      DBG('33.[Fwd_Ins_Id]=>' || L_TY_ATM_TXN_REC.FWD_INS_ID);
      DBG('34.[E-commerce data]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_34);
      DBG('35.[Trk_2_data]=>' || L_TY_ATM_TXN_REC.TRK_2_DATA);
      DBG('36.[Trk_3_data]=>' || L_TY_ATM_TXN_REC.TRK_3_DATA);
      DBG('37.[Retrieval reference no.]=>' || L_TY_ATM_TXN_REC.RRN);
      DBG('38.[Auth_Code]=>' || L_TY_ATM_TXN_REC.AUTH_CODE);
      DBG('39.[Resp_Code]=>' || L_TY_ATM_TXN_REC.RESP_CODE);
      DBG('40.[Serv_rest_code]=>' || L_TY_ATM_TXN_REC.SERV_REST_CODE);
      DBG('41.[Card acceptor terminal id]=>' || L_TY_ATM_TXN_REC.TERM_ID);
      DBG('42.[Card acceptor id code]=>' ||
          L_TY_ATM_TXN_REC.ACCEPT_ID_CODE);
      DBG('43.[Card acceptor name/loc]=>' || L_TY_ATM_TXN_REC.ACCEPT_ADDR);
      DBG('44.[Add_resp_data]=>' || L_TY_ATM_TXN_REC.ADD_RESP_DATA);
      DBG('45.[Trk_1_data]=>' || L_TY_ATM_TXN_REC.TRK_1_DATA);
      DBG('46.[Amounts fees]=>' || L_TY_ATM_TXN_REC.ADD_ISO_46);
      DBG('47.[Additional data national]=>' || L_TY_ATM_TXN_REC.ADD_NTL_47);
      DBG('48.[Additional data private]=>' || L_TY_ATM_TXN_REC.RSV_48);
      DBG('49.[verify_data]=>' || L_TY_ATM_TXN_REC.VERIFY_DATA);
      DBG('50.[Ccy Code, Reconciliation]=>' || L_TY_ATM_TXN_REC.RSV_ISO_50);
      DBG('51.[Ccy Code, Cardholder Billing]=>' ||
          L_TY_ATM_TXN_REC.RSV_ISO_51);
      DBG('52.[PIN_No]=>' || L_TY_ATM_TXN_REC.PIN_NO);
      DBG('53.[Sec control Info]=>' || L_TY_ATM_TXN_REC.SEC_INFO);
      DBG('54.[Add_Amt]=>' || L_TY_ATM_TXN_REC.ADD_AMT);
      DBG('55.[ICC sys data]=>' || L_TY_ATM_TXN_REC.RSV_ISO_55);
      DBG('56.[Original data elem]=>' || L_TY_ATM_TXN_REC.RSV_ISO_56);
      DBG('57.[Auth life cycle code]=>' || L_TY_ATM_TXN_REC.RSV_NTL_57);
      DBG('58.[Auth agent institution id]=>' ||
          L_TY_ATM_TXN_REC.RSV_NTL_58);
      DBG('59.[Transport data]=>' || L_TY_ATM_TXN_REC.RSV_NTL_59);
      DBG('60.[Rsv for natl use]=>' || L_TY_ATM_TXN_REC.RSV_60);
      DBG('61.[Rsv for natl use]=>' || L_TY_ATM_TXN_REC.RSV_PVT_61);
      DBG('62.[Rsv for pvt use]=>' || L_TY_ATM_TXN_REC.RSV_PVT_62);
      DBG('63.[Rsv for pvt use]=>' || L_TY_ATM_TXN_REC.RSV_PVT_63);
      DBG('64.[MAC_chk_code]=>' || L_TY_ATM_TXN_REC.MAC_CHK_CODE);
      DBG('65.[Bitmap, Extended]=>' || L_TY_ATM_TXN_REC.BITMAP_TER);
      DBG('66.[Amounts original fees]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_66);
      DBG('67.[Extended payment data]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_67);
      DBG('68.[Batch/file transfer message control]=>' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_68);
      DBG('69.[Batch/file transfer control data]=>' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_69);
      DBG('70.[File transfer desc]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_70);
      DBG('71.[Msg_No]=>' || L_TY_ATM_TXN_REC.MSG_NO);
      DBG('72.[Data record]=>' || L_TY_ATM_TXN_REC.MSG_DATA);
      DBG('73.[Action Date CCYYMMDD]=>' || L_TY_ATM_TXN_REC.ACTION_DATE);
      DBG('74.[Recon data primary]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_74);
      DBG('75.[Recon data secondary]=>' || L_TY_ATM_TXN_REC.ISO_FEILD_75);
      DBG('76.[Debit_No]=>' || L_TY_ATM_TXN_REC.DEBIT_NO);
      DBG('77.[Debit_Rev_No]=>' || L_TY_ATM_TXN_REC.DEBIT_REV_NO);
      DBG('78.[Trfr_No]=>' || L_TY_ATM_TXN_REC.TRFR_NO);
      DBG('79.[Trfr_Rev_No]=>' || L_TY_ATM_TXN_REC.TRFR_REV_NO);
      DBG('80.[Inq_No]=>' || L_TY_ATM_TXN_REC.INQ_NO);
      DBG('81.[Auth_No]=>' || L_TY_ATM_TXN_REC.AUTH_NO);
      DBG('82.[Credit_Proc_Fee]=>' || L_TY_ATM_TXN_REC.CREDIT_PROC_FEE);
      DBG('83.[Credit_Txn_Fee]=>' || L_TY_ATM_TXN_REC.CREDIT_TXN_FEE);
      DBG('84.[Debit_Proc_Fee]=>' || L_TY_ATM_TXN_REC.DEBIT_PROC_FEE);
      DBG('85.[Debit_Txn_Fee]=>' || L_TY_ATM_TXN_REC.DEBIT_TXN_FEE);
      DBG('86.[Credit_Amt]=>' || L_TY_ATM_TXN_REC.CREDIT_AMT);
      DBG('87.[Credit_Rev_Amt]=>' || L_TY_ATM_TXN_REC.CREDIT_REV_AMT);
      DBG('88.[Debit_Amt]=>' || L_TY_ATM_TXN_REC.DEBIT_AMT);
      DBG('89.[Debit_Rev_Amt]=>' || L_TY_ATM_TXN_REC.DEBIT_REV_AMT);
      DBG('90.[Org_Data]=>' || L_TY_ATM_TXN_REC.ORG_DATA);
      DBG('91.[File_Upld_Code]=>' || L_TY_ATM_TXN_REC.FILE_UPLD_CODE);
      DBG('92.[File_Sec_Code]=>' || L_TY_ATM_TXN_REC.FILE_SEC_CODE);
      DBG('93.[Resp_Ind]=>' || L_TY_ATM_TXN_REC.RESP_IND);
      DBG('94.[Service_Ind]=>' || L_TY_ATM_TXN_REC.SERVICE_IND);
      DBG('95.[Rplace_Amt]=>' || L_TY_ATM_TXN_REC.RPLACE_AMT);
      DBG('96.[Msg_Sec_Code]=>' || L_TY_ATM_TXN_REC.MSG_SEC_CODE);
      DBG('97.[Net_Setl_Amt]=>' || L_TY_ATM_TXN_REC.NET_SETL_AMT);
      DBG('98.[Payee]=>' || L_TY_ATM_TXN_REC.PAYEE);
      DBG('99.[Setl_Inst_Id]=>' || L_TY_ATM_TXN_REC.SETL_INST_ID);
      DBG('100.[Rcv_Inst_Id]=>' || L_TY_ATM_TXN_REC.RCV_INST_ID);
      DBG('101.[File_Name]=>' || L_TY_ATM_TXN_REC.FILE_NAME);
      DBG('102.[From_Acc]=>' || L_TY_ATM_TXN_REC.FROM_ACC ||
          ' txn_acc_no_fcc ' || L_TY_ATM_TXN_REC.TXN_ACC_NO_FCC);
      DBG('103.[To_Acc]=>' || L_TY_ATM_TXN_REC.TO_ACC);
      DBG('104.[Txn_Desc]=>' || L_TY_ATM_TXN_REC.TXN_DESC);
      DBG('105.[Rsv_ISO_105]=>' || L_TY_ATM_TXN_REC.RSV_ISO_105);
      DBG('106.[Rsv_ISO_106]=>' || L_TY_ATM_TXN_REC.RSV_ISO_106);
      DBG('107.[Rsv_ISO_107]=>' || L_TY_ATM_TXN_REC.RSV_ISO_107);
      DBG('108.[Rsv_ISO_108]=>' || L_TY_ATM_TXN_REC.RSV_ISO_108);
      DBG('109.[Rsv_ISO_109]=>' || L_TY_ATM_TXN_REC.RSV_ISO_109);
      DBG('110.[Rsv_ISO_110]=>' || L_TY_ATM_TXN_REC.RSV_ISO_110);
      DBG('111.[Rsv_ISO_111]=>' || L_TY_ATM_TXN_REC.RSV_ISO_111);
      DBG('112.[Rsv_Ntl_112]=>' || L_TY_ATM_TXN_REC.RSV_NTL_112);
      DBG('113.[Auth_Agent_Inst_Id]=>' ||
          L_TY_ATM_TXN_REC.AUTH_AGENT_INST_ID);
      DBG('114.[Rsv_Ntl_114]=>' || L_TY_ATM_TXN_REC.RSV_NTL_114);
      DBG('115.[Rsv_Ntl_115]=>' || L_TY_ATM_TXN_REC.RSV_NTL_115);
      DBG('116.[Rsv_Ntl_116]=>' || L_TY_ATM_TXN_REC.RSV_NTL_116);
      DBG('117.[Rsv_Ntl_117]=>' || L_TY_ATM_TXN_REC.RSV_NTL_117);
      DBG('118.[Rsv_Ntl_118]=>' || L_TY_ATM_TXN_REC.RSV_NTL_118);
      DBG('119.[Rsv_Ntl_119]=>' || L_TY_ATM_TXN_REC.RSV_NTL_119);
      DBG('120.[Rsv_Pvt_120]=>' || L_TY_ATM_TXN_REC.RSV_PVT_120);
      DBG('121.[Rsv_Pvt_121]=>' || L_TY_ATM_TXN_REC.RSV_PVT_121);
      DBG('122.[Rsv_Pvt_122]=>' || L_TY_ATM_TXN_REC.RSV_PVT_122);
      DBG('123.[Rsv_Pvt_123]=>' || L_TY_ATM_TXN_REC.RSV_PVT_123);
      DBG('124.[Info_Txt]=>' || L_TY_ATM_TXN_REC.INFO_TXT);
      DBG('125.[Add_Net_Info]=>' || L_TY_ATM_TXN_REC.ADD_NET_INFO);
      DBG('126.[Pre_Auth_N_Chg_Bck]=>' ||
          L_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK);
      DBG('127.[Mini_Stmt_Data]=>' || L_TY_ATM_TXN_REC.MINI_STMT_DATA);
      DBG('128.[Msg_Auth_Code1]=>' || L_TY_ATM_TXN_REC.MSG_AUTH_CODE);
      DBG('Org_Data=>' || L_TY_ATM_TXN_REC.ORG_DATA);

    EXCEPTION
      WHEN OTHERS THEN
        DBG('E', 'In WOT of fn_pop_plsql_tbl ' || SQLERRM);
        P_ERR_CODE  := 'SW-POP-01';
        P_ERR_PARAM := NULL;
        RETURN;
    END;
    DBG('*********************************************************************' ||
        P_USER_ID);

    L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := P_BRANCH;
    L_TY_ATM_TXN_REC.USER_ID          := P_USER_ID;
    L_TY_ATM_TXN_REC.SOURCE           := P_SOURCE;
    G_SOURCE                          := P_SOURCE;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DBG('The l_Ty_Atm_Txn_Rec.Term_Id sent to the gwpks_retailtlrservice_cluster.pr_service_handler is:' ||
          L_TY_ATM_TXN_REC.TERM_ID);
      L_FN_CALL_ID := 3;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('l_Ty_Atm_Txn_Rec.Term_Id') := L_TY_ATM_TXN_REC.TERM_ID;

      DBG('The l_Ty_Atm_Txn_Rec.Iso_Feild_18 sent to the gwpks_retailtlrservice_cluster.pr_service_handler is:' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_18);
      L_TB_CLUSTER_DATA('l_Ty_Atm_Txn_Rec.Iso_Feild_18') := L_TY_ATM_TXN_REC.ISO_FEILD_18;
      L_TB_CLUSTER_DATA('l_Ty_Atm_Txn_Rec.ORIG_BRANCH_CODE') := L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE;
      L_TB_CLUSTER_DATA('l_Ty_Atm_Txn_Rec.PAN') := L_TY_ATM_TXN_REC.PAN;
      L_TB_CLUSTER_DATA('l_Ty_Atm_Txn_Rec.acq_ins_id') := L_TY_ATM_TXN_REC.ACQ_INS_ID;

      GWPKS_CREATESWTXN_CLUSTER.PR_MSG_HANDLER(P_BRANCH,
                                               P_USER_ID,
                                               P_SOURCE,
                                               P_CHANNEL,
                                               P_ISO_MESSAGE,
                                               P_ERR_CODE,
                                               P_ERR_PARAM,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);

    END IF;

    IF NOT SWPKSS_UTILS.FN_GET_SW_TERMID_MAP_REC_WRP(L_TY_ATM_TXN_REC.TERM_ID,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM) THEN

      IF P_ERR_CODE = 'CS-FRC-001' THEN
        P_ERR_CODE := NULL;
      END IF;

      L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
    ELSE
      DBG('Inside Fn_Get_fc_code_Rec_Wrp...');
      L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE := SWPKSS_UTILS.G_TBL_SW_TERMID_MAP.ORIG_BRANCH;
      GLOBAL.PR_INIT(L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE, P_USER_ID);
    END IF;
    DBG('Incoming orig branch code:' || L_TY_ATM_TXN_REC.ORIG_BRANCH_CODE);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DBG('The l_Ty_Atm_Txn_Rec.Term_Id sent to the gwpks_retailtlrservice_cluster.pr_service_handler is:' ||
          L_TY_ATM_TXN_REC.TERM_ID);
      L_FN_CALL_ID := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('l_Ty_Atm_Txn_Rec.Term_Id') := L_TY_ATM_TXN_REC.TERM_ID;

      DBG('The l_Ty_Atm_Txn_Rec.Iso_Feild_18 sent to the gwpks_retailtlrservice_cluster.pr_service_handler is:' ||
          L_TY_ATM_TXN_REC.ISO_FEILD_18);
      L_TB_CLUSTER_DATA('l_Ty_Atm_Txn_Rec.Iso_Feild_18') := L_TY_ATM_TXN_REC.ISO_FEILD_18;

      GWPKS_CREATESWTXN_CLUSTER.PR_MSG_HANDLER(P_BRANCH,
                                               P_USER_ID,
                                               P_SOURCE,
                                               P_CHANNEL,
                                               P_ISO_MESSAGE,
                                               P_ERR_CODE,
                                               P_ERR_PARAM,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);

    END IF;

    L_TY_ATM_TXN_REC.TY_PROCESSING_INSTRUCTIONS := NULL;
    L_TY_ATM_TXN_REC.TY_BIZ_PROCESS_HEADER      := NULL;

    SAVEPOINT SP_SWITCH;

    IF NOT FN_BUSINESS_MAPPING(L_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
      DBG('E', 'fn_pop_plsql_tbl : fn_process_req returned false ');
      ROLLBACK TO SP_SWITCH;
      RAISE ERROR_EXCEPTION;
    END IF;

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT
          GWPKSS_EXT_SWITCHSERVICE.FN_ISO_PRE_SWITCHTRANSACTION(L_TY_ATM_TXN_REC,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAM) THEN
        DBG('Function gwpkss_ext_switchservice.fn_iso_pre_switchTransaction returned FALSE');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        RAISE ERROR_EXCEPTION;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF NOT FN_PROCESS_REQ(L_TY_ATM_TXN_REC, 'N', P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E',
            'Gwpks_CreateSWTransaction : fn_process_req returned false ');
        ROLLBACK TO SP_SWITCH;
        RAISE ERROR_EXCEPTION;
      END IF;

      DBG('E', 'p_err_code is:' || P_ERR_CODE);
      IF P_ERR_CODE IS NULL THEN
        OVPKS.PR_APPENDTBL('GW-SAV-01', NULL);
        P_ERR_CODE  := 'SW-SUC-01';
        P_ERR_PARAM := NULL;
      END IF;

      IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
        IF NOT
            GWPKSS_EXT_SWITCHSERVICE.FN_ISO_POST_SWITCHTRANSACTION(L_TY_ATM_TXN_REC,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAM) THEN
          DBG('Function gwpkss_ext_switchservice.fn_iso_post_switchTransaction returned FALSE');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          RAISE ERROR_EXCEPTION;
        END IF;
      END IF;

      IF L_TY_ATM_TXN_REC.TRN_REF_NO_FCC IS NOT NULL THEN
        DBG('Trn_Ref_No_Fcc ' || L_TY_ATM_TXN_REC.TRN_REF_NO_FCC);

        SELECT COUNT(*)
          INTO L_TY_ATM_TXN_REC.FIN_TXN_COUNT
          FROM ACTB_DAILY_LOG
         WHERE TRN_REF_NO = L_TY_ATM_TXN_REC.TRN_REF_NO_FCC;
        DBG('count in actb ' || L_TY_ATM_TXN_REC.FIN_TXN_COUNT);
      END IF;

      IF L_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO = '0' THEN
        L_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO := NULL;
      END IF;

      IF L_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO IS NOT NULL THEN
        SELECT COUNT(*)
          INTO L_TY_ATM_TXN_REC.FIN_TXN_COUNT
          FROM CATMS_AMOUNT_BLOCKS
         WHERE AMOUNT_BLOCK_NO = L_TY_ATM_TXN_REC.AMOUNT_BLOCK_NO;
        DBG('count in catms' || L_TY_ATM_TXN_REC.FIN_TXN_COUNT);
      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    IF NOT FN_BUILD_ATM_REPLY_ISO(L_TY_ATM_TXN_REC,
                                  P_ISO_MESSAGE,
                                  P_ERR_CODE,
                                  P_ERR_PARAM) THEN
      DBG('E', 'FAILED IN fn_build_atm_reply_iso');
      P_ERR_CODE := 'SW-REP-01';
      RAISE ERROR_EXCEPTION;
    END IF;

    IF SUBSTR(L_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) <> '4' AND
       SUBSTR(L_TY_ATM_TXN_REC.MSG_TYPE, 3, 1) <> '2' THEN
      IF NOT
          FN_CHECK_FOR_REVERSAL(L_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('FAILED IN fn_check_for_reversal');
        RAISE ERROR_EXCEPTION;
      END IF;
    END IF;

    P_ERR_CODE := NULL;

    DBG('Outgoing ISO message:[[' || P_ISO_MESSAGE || ']]');
    RETURN;

  EXCEPTION
    WHEN ERROR_EXCEPTION THEN
      ROLLBACK TO SP_SWITCH;
      DBG('Inside error exception 1 ' || SQLERRM);
      IF NOT FN_BUILD_ATM_REPLY_ISO(L_TY_ATM_TXN_REC,
                                    P_ISO_MESSAGE,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
        DBG('FAILED IN fn_build_atm_reply_iso');
        P_ERR_CODE := 'SW-REP-01';

      END IF;
      RETURN;
    WHEN OTHERS THEN
      ROLLBACK TO SP_SWITCH;
      DBG('E', 'Inside error exception 2 ' || SQLERRM);
      P_ERR_CODE := 'SW-OTH-01';
      IF NOT FN_BUILD_ATM_REPLY_ISO(L_TY_ATM_TXN_REC,
                                    P_ISO_MESSAGE,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
        DBG('FAILED IN fn_build_atm_reply_iso');
        P_ERR_CODE := 'SW-REP-01';
      END IF;
      RETURN;
  END PR_MSG_HANDLER;

  FUNCTION FN_BUILD_ATM_REPLY_ISO(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                                  P_ISO_OUT_MSG    IN OUT VARCHAR2,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_LAST_MSG_TYPE_DIGIT INTEGER := 0;
  BEGIN

    DBG('inside fn_build_atm_reply_iso');

    IF NOT FN_MAP_ERR_RESPCODE(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
      DBG('FAILED IN fn_map_err_respcode');
      P_ERR_CODE  := 'SW-ERR-01';
      P_ERR_PARAM := 'fn_build_atm_reply_iso' || '~' || P_ERR_CODE;
      RETURN FALSE;
    END IF;
    DBG('inside fn_build_atm_reply_iso Error Code ' || P_ERR_CODE);

    IF P_ERR_CODE NOT IN ('SW-LOG-01') THEN
      IF NOT FN_UPDATE_RESP(P_TY_ATM_TXN_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling Gwpks_CreateSWTransaction.fn_update_resp' ||
            P_ERR_CODE);
        P_ERR_PARAM := P_ERR_CODE;
        RETURN FALSE;
      END IF;
    END IF;

    DBG('ip_ty_atm_txn_rec.offus_onus>>' || P_TY_ATM_TXN_REC.OFFUS_ONUS ||
        ' Txn type is non financial>>' ||
        P_TY_ATM_TXN_REC.CHARGE_NON_FIN_TXN || ' with response code>>' ||
        P_TY_ATM_TXN_REC.RESP_CODE);
    IF P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'F' AND
       P_TY_ATM_TXN_REC.CHARGE_NON_FIN_TXN = 'N' AND
       P_TY_ATM_TXN_REC.RESP_CODE NOT IN ('00', '000', '0000')

     THEN
      IF NOT SWPKSS_QUERYBALANCE.FN_MAIN(P_TY_ATM_TXN_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling swpkss_querybalance.fn_main' ||
            P_ERR_CODE);
      END IF;
    END IF;

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKSS_EXT_SWITCHSERVICE.FN_POST_UPDATE_RESP(P_TY_ATM_TXN_REC,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM) THEN
        DBG('Function gwpkss_ext_switchservice.Fn_Post_Update_Resp returned FALSE');
        P_ERR_PARAM := P_ERR_CODE;
        RETURN FALSE;
      END IF;

      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_BUILD_ATM_REPLY_ISO(P_TY_ATM_TXN_REC,
                                                            P_ISO_OUT_MSG,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.fn_build_atm_reply_iso returned false ');
        RETURN FALSE;
      END IF;

    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = 8 THEN
        L_LAST_MSG_TYPE_DIGIT := SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 4, 1);
      END IF;

      P_ISO_OUT_MSG := P_TY_ATM_TXN_REC.HEDDER || '~' ||
                       (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 2) ||
                       TO_CHAR(TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE,
                                                 3,
                                                 1)) + 1) ||

                       L_LAST_MSG_TYPE_DIGIT) || '~' ||
                       P_TY_ATM_TXN_REC.PAN || '~' ||
                       P_TY_ATM_TXN_REC.PROC_CODE || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_04 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_05 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_06 || '~' ||
                       P_TY_ATM_TXN_REC.TRANS_DT_TIME || '~' ||
                       P_TY_ATM_TXN_REC.BILL_FEE_AMT || '~' ||
                       P_TY_ATM_TXN_REC.SETL_X_RATE || '~' ||
                       P_TY_ATM_TXN_REC.BILL_X_RATE || '~' ||
                       P_TY_ATM_TXN_REC.STAN || '~' ||
                       P_TY_ATM_TXN_REC.LOCAL_TXN_TIME || '~' ||
                       P_TY_ATM_TXN_REC.LOCAL_TXN_DT || '~' ||
                       P_TY_ATM_TXN_REC.EXP_DATE || '~' ||
                       P_TY_ATM_TXN_REC.SETL_DATE || '~' ||
                       P_TY_ATM_TXN_REC.CONV_DATE || '~' ||
                       P_TY_ATM_TXN_REC.CAPT_DATE || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_18 || '~' ||
                       P_TY_ATM_TXN_REC.ACQ_INST_CTRY || '~' ||
                       P_TY_ATM_TXN_REC.PAN_EXT_CTRY || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_21 || '~' ||
                       P_TY_ATM_TXN_REC.POS_ENT_MOD || '~' ||
                       P_TY_ATM_TXN_REC.APPL_PAN || '~' ||
                       P_TY_ATM_TXN_REC.NET_INT_ID || '~' ||
                       P_TY_ATM_TXN_REC.POS_COND_CODE || '~' ||
                       P_TY_ATM_TXN_REC.POS_CAPT_CODE || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_27 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_28 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_29 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_30 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_31 || '~' ||
                       P_TY_ATM_TXN_REC.ACQ_INS_ID || '~' ||
                       P_TY_ATM_TXN_REC.FWD_INS_ID || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_34 || '~' ||
                       P_TY_ATM_TXN_REC.TRK_2_DATA || '~' ||
                       P_TY_ATM_TXN_REC.TRK_3_DATA || '~' ||
                       P_TY_ATM_TXN_REC.RRN || '~' ||
                       P_TY_ATM_TXN_REC.AUTH_CODE || '~' ||
                       P_TY_ATM_TXN_REC.RESP_CODE || '~' ||
                       P_TY_ATM_TXN_REC.SERV_REST_CODE || '~' ||
                       P_TY_ATM_TXN_REC.TERM_ID || '~' ||
                       P_TY_ATM_TXN_REC.ACCEPT_ID_CODE || '~' ||
                       P_TY_ATM_TXN_REC.ACCEPT_ADDR || '~' ||
                       P_TY_ATM_TXN_REC.ADD_RESP_DATA || '~' ||
                       P_TY_ATM_TXN_REC.TRK_1_DATA || '~' ||
                       P_TY_ATM_TXN_REC.ADD_ISO_46 || '~' ||
                       P_TY_ATM_TXN_REC.ADD_NTL_47 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_48 || '~' ||
                       P_TY_ATM_TXN_REC.VERIFY_DATA || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_50 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_51 || '~' ||
                       P_TY_ATM_TXN_REC.PIN_NO || '~' ||
                       P_TY_ATM_TXN_REC.SEC_INFO || '~' ||
                       P_TY_ATM_TXN_REC.ADD_AMT || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_55 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_56 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_57 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_58 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_59 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_60 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_PVT_61 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_PVT_62 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_PVT_63 || '~' ||
                       P_TY_ATM_TXN_REC.MAC_CHK_CODE || '~' ||
                       P_TY_ATM_TXN_REC.BITMAP_TER || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_66 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_67 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_68 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_69 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_70 || '~' ||
                       P_TY_ATM_TXN_REC.MSG_NO || '~' ||
                       P_TY_ATM_TXN_REC.MSG_DATA || '~' ||
                       P_TY_ATM_TXN_REC.ACTION_DATE || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_74 || '~' ||
                       P_TY_ATM_TXN_REC.ISO_FEILD_75 || '~' ||
                       P_TY_ATM_TXN_REC.DEBIT_NO || '~' ||
                       P_TY_ATM_TXN_REC.DEBIT_REV_NO || '~' ||
                       P_TY_ATM_TXN_REC.TRFR_NO || '~' ||
                       P_TY_ATM_TXN_REC.TRFR_REV_NO || '~' ||
                       P_TY_ATM_TXN_REC.INQ_NO || '~' ||
                       P_TY_ATM_TXN_REC.AUTH_NO || '~' ||
                       P_TY_ATM_TXN_REC.CREDIT_PROC_FEE || '~' ||
                       P_TY_ATM_TXN_REC.CREDIT_TXN_FEE || '~' ||
                       P_TY_ATM_TXN_REC.DEBIT_PROC_FEE || '~' ||
                       P_TY_ATM_TXN_REC.DEBIT_TXN_FEE || '~' ||
                       P_TY_ATM_TXN_REC.CREDIT_AMT || '~' ||
                       P_TY_ATM_TXN_REC.CREDIT_REV_AMT || '~' ||
                       P_TY_ATM_TXN_REC.DEBIT_AMT || '~' ||
                       P_TY_ATM_TXN_REC.DEBIT_REV_AMT || '~' ||
                       P_TY_ATM_TXN_REC.ORG_DATA || '~' ||
                       P_TY_ATM_TXN_REC.FILE_UPLD_CODE || '~' ||
                       P_TY_ATM_TXN_REC.FILE_SEC_CODE || '~' ||
                       P_TY_ATM_TXN_REC.RESP_IND || '~' ||
                       P_TY_ATM_TXN_REC.SERVICE_IND || '~' ||
                       P_TY_ATM_TXN_REC.RPLACE_AMT || '~' ||
                       P_TY_ATM_TXN_REC.MSG_SEC_CODE || '~' ||
                       P_TY_ATM_TXN_REC.NET_SETL_AMT || '~' ||
                       P_TY_ATM_TXN_REC.PAYEE || '~' ||
                       P_TY_ATM_TXN_REC.SETL_INST_ID || '~' ||
                       P_TY_ATM_TXN_REC.RCV_INST_ID || '~' ||
                       P_TY_ATM_TXN_REC.FILE_NAME || '~' ||
                       P_TY_ATM_TXN_REC.FROM_ACC || '~' ||
                       P_TY_ATM_TXN_REC.TO_ACC || '~' ||
                       P_TY_ATM_TXN_REC.TXN_DESC || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_105 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_106 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_107 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_108 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_109 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_110 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_ISO_111 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_112 || '~' ||
                       P_TY_ATM_TXN_REC.AUTH_AGENT_INST_ID || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_114 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_115 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_116 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_117 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_118 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_NTL_119 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_PVT_120 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_PVT_121 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_PVT_122 || '~' ||
                       P_TY_ATM_TXN_REC.RSV_PVT_123 || '~' ||
                       P_TY_ATM_TXN_REC.INFO_TXT || '~' ||
                       P_TY_ATM_TXN_REC.ADD_NET_INFO || '~' ||
                       P_TY_ATM_TXN_REC.PRE_AUTH_N_CHG_BCK || '~' ||
                       P_TY_ATM_TXN_REC.MINI_STMT_DATA || '~' ||
                       P_TY_ATM_TXN_REC.MSG_AUTH_CODE;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    RETURN TRUE;

  EXCEPTION

    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-CON-01';
      P_ERR_PARAM := 'fn_build_atm_reply_iso' || P_ERR_CODE;
      DBG('E',
          'fn_build_atm_reply_iso : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;

  END FN_BUILD_ATM_REPLY_ISO;

  FUNCTION FN_UPDATE_LIMITS(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_MSG_TYPE_TEMP  VARCHAR2(16) DEFAULT NULL;
    L_KEY_TEMP       VARCHAR2(255) DEFAULT NULL;
    L_AMONT_BLOCK_NO VARCHAR2(35) DEFAULT NULL;
    L_TRANS_DT_TIME  VARCHAR2(12);
    L_TXN_AMT        NUMBER;
    L_ORIG_TXN_AMT   NUMBER;
  BEGIN

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT GWPKS_EXT_SWITCHSERVICE.FN_UPDATE_LIMITS(P_TY_ATM_TXN_REC,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAM) THEN
        DBG('E',
            'gwpks_ext_switchservice.Fn_Update_Limits returned false ');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 3) = '220') THEN

        IF (P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.FOLLOW_ON = 'Y' OR
           P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.AMOUNT_BLOCK = 'Y') THEN
          L_MSG_TYPE_TEMP := SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 1) ||
                             '200';
          DBG('l_Msg_Type_Temp : Deriving PKEY ' || L_MSG_TYPE_TEMP);
          DBG('fn_txn_contol : Deriving PKEY ');
        ELSE
          L_MSG_TYPE_TEMP := SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 1) ||
                             '100';
          DBG('l_Msg_Type_Temp : Deriving PKEY ' || L_MSG_TYPE_TEMP);
          DBG('fn_txn_contol : Deriving PKEY ');
        END IF;
        IF NOT SWPKS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                             P_TY_ATM_TXN_REC.P_KEY,
                                             L_MSG_TYPE_TEMP,
                                             P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                             L_KEY_TEMP) THEN
          DBG('E',
              'fn_txn_contol: swpks_utils.fn_get_parent_key returned false ');
          P_ERR_CODE  := 'SW-KEY-02';
          P_ERR_PARAM := NULL;
          RETURN FALSE;
        END IF;
        DBG('Parent Found for 200 ' || L_KEY_TEMP);
        BEGIN
          SELECT AMOUNT_BLOCK_NO, TRANS_DT_TIME, TXN_AMT
            INTO L_AMONT_BLOCK_NO, L_TRANS_DT_TIME, L_ORIG_TXN_AMT
            FROM SWTB_TXN_LOG
           WHERE P_KEY = L_KEY_TEMP;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('parent not found');
            IF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '00') THEN
              PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT +
                                                         G_ACC_AMT;
              PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT := PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT + 1;

            ELSIF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '01') THEN
              PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT +
                                                         G_ACC_AMT;
              PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT + 1;

            END IF;

            IF SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('00', '01') THEN
              UPDATE SWTMS_CARD_DETAILS
                 SET POS_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT,
                     POS_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT,
                     LAST_TXN_DATE      = PKG_CARD_DETAILS_REC.LAST_TXN_DATE,
                     ATM_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT,
                     ATM_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT
               WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                 AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
                 AND AUTH_STAT = 'A'
                 AND RECORD_STAT = 'O';
            END IF;
            RETURN TRUE;
        END;

        L_TRANS_DT_TIME := SUBSTR(L_TRANS_DT_TIME, 1, 4);
        L_TXN_AMT       := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                            1,
                                            LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) -
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                            LENGTH(P_TY_ATM_TXN_REC.TXN_AMT) + 1 -
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

        L_ORIG_TXN_AMT := TO_NUMBER(SUBSTR(L_ORIG_TXN_AMT,
                                           1,
                                           LENGTH(L_ORIG_TXN_AMT) -
                                           P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                    SUBSTR(L_ORIG_TXN_AMT,
                                           LENGTH(L_ORIG_TXN_AMT) + 1 -
                                           P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                           P_TY_ATM_TXN_REC.TXN_CCY_MINOR));
        DBG('l_trans_dt_time' || L_TRANS_DT_TIME);
        DBG('p_Ty_Atm_Txn_Rec.Local_Txn_Dt' ||
            P_TY_ATM_TXN_REC.LOCAL_TXN_DT);

        DBG('l_txn_Amt' || L_TXN_AMT);
        DBG('l_orig_txn_Amt' || L_ORIG_TXN_AMT);

        IF P_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL THEN
          IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
            P_TY_ATM_TXN_REC.TRANS_DT_TIME := SUBSTR(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                     3);
          ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
            P_TY_ATM_TXN_REC.TRANS_DT_TIME := SUBSTR(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                     5);
          END IF;
        END IF;

        IF L_TRANS_DT_TIME = (SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4)) THEN
          DBG('Dates are Same No Need to do any thing');
          IF (L_TXN_AMT > L_ORIG_TXN_AMT) THEN
            IF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '00') THEN
              PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT +
                                                         L_TXN_AMT -
                                                         L_ORIG_TXN_AMT;
            ELSE
              PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT +
                                                         L_TXN_AMT -
                                                         L_ORIG_TXN_AMT;
              DBG('Pkg_Card_Details_Rec.ATM_Utilized_Limit' ||
                  PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT);
            END IF;
          ELSE
            DBG('ELSE OF LIMIT AMOUNT');
            IF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '00') THEN
              PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT -
                                                         L_TXN_AMT;
            ELSE
              PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT -
                                                         L_TXN_AMT;
            END IF;
          END IF;

        END IF;
      END IF;

      DBG('Inside Fn_Update_Limits');
      DBG('Printing Derived Transaction Amount---' || G_ACC_AMT);

      DBG('For Reversal - p_Ty_Atm_Txn_Rec.Local_Txn_Dt' ||
          P_TY_ATM_TXN_REC.LOCAL_TXN_DT);
      IF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '00') THEN

        DBG('Updating POS Limits -');

        IF NOT (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '4') THEN
          BEGIN
            IF NOT (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 3) = '220') THEN
              IF NOT NVL(PKG_CARD_DETAILS_REC.POS_DLY_TXN_LIMIT, 0) = 0 THEN
                PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT +
                                                           G_ACC_AMT;

              ELSE
                PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT := 0;
              END IF;

            END IF;

            UPDATE SWTMS_CARD_DETAILS
               SET POS_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT,
                   POS_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT,
                   LAST_TXN_DATE      = PKG_CARD_DETAILS_REC.LAST_TXN_DATE,
                   ATM_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT,
                   ATM_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT
             WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
               AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CODE  := 'SW-CHL-03';
              P_ERR_PARAM := 'Record Not Found';
              RETURN FALSE;
          END;
        ELSE
          BEGIN
            DBG('For Reversal -');
            DBG('Pkg_Card_Details_Rec.last_txn_date' ||
                PKG_CARD_DETAILS_REC.LAST_TXN_DATE);

            IF P_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL THEN
              IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
                P_TY_ATM_TXN_REC.TRANS_DT_TIME := SUBSTR(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                         3);
              ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
                P_TY_ATM_TXN_REC.TRANS_DT_TIME := SUBSTR(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                         5);
              END IF;
            END IF;

            IF PKG_CARD_DETAILS_REC.LAST_TXN_DATE =
               (SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4)) THEN
              G_ACC_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                            1,
                                            12 -
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                            13 -
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

              IF NOT (P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC =
                  P_TY_ATM_TXN_REC.TXN_CCY_DERIVED) THEN

                L_TXN_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                              1,
                                              12 -
                                              P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                       SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                              13 -
                                              P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                              P_TY_ATM_TXN_REC.TXN_CCY_MINOR));
                IF NOT
                    GWPKSS_CREATESWTRANSACTION.FN_PRODUCT_DERIVE(P_TY_ATM_TXN_REC,
                                                                 P_ERR_CODE,
                                                                 P_ERR_PARAM) THEN
                  DBG('E',
                      'Failed while calling Gwpks_CreateSWTransaction.fn_product_derive' ||
                      P_ERR_CODE);
                  RETURN FALSE;
                END IF;

                BEGIN
                  SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
                    INTO P_TY_ATM_TXN_REC.RATE_CODE,
                         P_TY_ATM_TXN_REC.RATE_TYPE
                    FROM CSTMS_PRODUCT
                   WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
                     AND MODULE = 'RT'
                     AND AUTH_STAT = 'A'
                     AND RECORD_STAT = 'O';
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    P_ERR_CODE                 := 'SW-PRD-01';
                    P_TY_ATM_TXN_REC.RESP_CODE := '05';
                    DBG('E',
                        'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                        P_ERR_PARAM);
                    RETURN FALSE;
                END;

                IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                              P_TY_ATM_TXN_REC.TXN_CCY_DERIVED,
                                              P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC,
                                              P_TY_ATM_TXN_REC.RATE_TYPE,
                                              P_TY_ATM_TXN_REC.RATE_CODE,
                                              L_TXN_AMT,
                                              'Y',
                                              G_ACC_AMT,
                                              P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                              P_ERR_CODE) THEN
                  P_ERR_CODE  := 'SW-AMT-01';
                  P_ERR_PARAM := '~' || P_TY_ATM_TXN_REC.TXN_CCY_DERIVED || '~' ||
                                 P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC;
                  DBG('E',
                      'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
                      P_ERR_CODE || '~' || P_ERR_PARAM);
                  RETURN FALSE;
                END IF;

                DBG('ATM Transaction - Amount After Currency Conversion' ||
                    G_ACC_AMT);
                DBG('ATM Transaction - Starting Limits Check');
              END IF;
              IF NOT NVL(PKG_CARD_DETAILS_REC.POS_DLY_TXN_LIMIT, 0) = 0 THEN
                PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT -
                                                           G_ACC_AMT;

              ELSE
                PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT := 0;
              END IF;

              DBG('ATM Transaction - Amount After Currency Conversion' ||
                  PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT);
              IF NOT NVL(PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT, 0) = 0 THEN
                UPDATE SWTMS_CARD_DETAILS
                   SET POS_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT,
                       POS_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT - 2,
                       LAST_TXN_DATE      = PKG_CARD_DETAILS_REC.LAST_TXN_DATE,
                       ATM_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT,
                       ATM_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT
                 WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                   AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
                   AND AUTH_STAT = 'A'
                   AND RECORD_STAT = 'O';
              END IF;
              DBG('For Reversal -Pkg_Card_Details_Rec.Pos_Utilized_Count after updation' ||
                  PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT);
            END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CODE  := 'SW-CHL-03';
              P_ERR_PARAM := 'Record Not Found';
              RETURN FALSE;
          END;

        END IF;

      END IF;

      IF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '01') THEN

        DBG('ATM Transaction -');
        IF NOT (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '4') THEN
          BEGIN
            DBG('For NON Reversal -Pkg_Card_Details_Rec.Atm_Utilized_Count' ||
                PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT);

            DBG('Pkg_Card_Details_Rec.Atm_Utilized_Limit' ||
                PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT);
            IF NOT (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 3) = '220') THEN
              IF NOT NVL(PKG_CARD_DETAILS_REC.ATM_DLY_TXN_LIMIT, 0) = 0 THEN
                PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT +
                                                           G_ACC_AMT;

              ELSE
                PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT := 0;
              END IF;

            END IF;

            UPDATE SWTMS_CARD_DETAILS
               SET ATM_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT,
                   ATM_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT,
                   LAST_TXN_DATE      = PKG_CARD_DETAILS_REC.LAST_TXN_DATE,
                   POS_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT,
                   POS_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT
             WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
               AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CODE  := 'SW-CHL-03';
              P_ERR_PARAM := 'Record Not Found';
              RETURN FALSE;
          END;
        ELSE
          BEGIN
            DBG('For Reversal -');
            DBG('For Reversal -Pkg_Card_Details_Rec.Atm_Utilized_Limit' ||
                PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT);
            DBG('For Reversal -p_Ty_Atm_Txn_Rec.Txn_Amt_Derived' ||
                P_TY_ATM_TXN_REC.TXN_AMT);
            DBG('p_ty_atm_txn_rec.orig_txn_amt' ||
                P_TY_ATM_TXN_REC.ORIG_TXN_AMT);
            DBG('For Reversal -Pkg_Card_Details_Rec.Atm_Utilized_Count' ||
                PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT);

            DBG('For Reversal - p_Ty_Atm_Txn_Rec.Local_Txn_Dt' ||
                P_TY_ATM_TXN_REC.LOCAL_TXN_DT);
            DBG('For Reversal - Pkg_Card_Details_Rec.last_txn_date' ||
                PKG_CARD_DETAILS_REC.LAST_TXN_DATE);

            IF P_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL THEN
              IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '1' THEN
                P_TY_ATM_TXN_REC.TRANS_DT_TIME := SUBSTR(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                         3);
              ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION = '2' THEN
                P_TY_ATM_TXN_REC.TRANS_DT_TIME := SUBSTR(P_TY_ATM_TXN_REC.LOCAL_TXN_TIME,
                                                         5);
              END IF;
            END IF;

            IF PKG_CARD_DETAILS_REC.LAST_TXN_DATE =
               (SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4)) THEN
              G_ACC_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                            1,
                                            12 -
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                     SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                            13 -
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                            P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

              IF NOT (P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC =
                  P_TY_ATM_TXN_REC.TXN_CCY_DERIVED) THEN

                L_TXN_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                              1,
                                              12 -
                                              P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                       SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                              13 -
                                              P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                              P_TY_ATM_TXN_REC.TXN_CCY_MINOR));
                IF NOT
                    GWPKSS_CREATESWTRANSACTION.FN_PRODUCT_DERIVE(P_TY_ATM_TXN_REC,
                                                                 P_ERR_CODE,
                                                                 P_ERR_PARAM) THEN
                  DBG('E',
                      'Failed while calling Gwpks_CreateSWTransaction.fn_product_derive' ||
                      P_ERR_CODE);
                  RETURN FALSE;
                END IF;

                BEGIN
                  SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
                    INTO P_TY_ATM_TXN_REC.RATE_CODE,
                         P_TY_ATM_TXN_REC.RATE_TYPE
                    FROM CSTMS_PRODUCT
                   WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
                     AND MODULE = 'RT'
                     AND AUTH_STAT = 'A'
                     AND RECORD_STAT = 'O';
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    P_ERR_CODE                 := 'SW-PRD-01';
                    P_TY_ATM_TXN_REC.RESP_CODE := '05';
                    DBG('E',
                        'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                        P_ERR_PARAM);
                    RETURN FALSE;
                END;

                IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                              P_TY_ATM_TXN_REC.TXN_CCY_DERIVED,
                                              P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC,
                                              P_TY_ATM_TXN_REC.RATE_TYPE,
                                              P_TY_ATM_TXN_REC.RATE_CODE

                                             ,
                                              L_TXN_AMT,

                                              'Y',
                                              G_ACC_AMT,
                                              P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                              P_ERR_CODE) THEN
                  P_ERR_CODE  := 'SW-AMT-01';
                  P_ERR_PARAM := '~' || P_TY_ATM_TXN_REC.TXN_CCY_DERIVED || '~' ||
                                 P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC;
                  DBG('E',
                      'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
                      P_ERR_CODE || '~' || P_ERR_PARAM);
                  RETURN FALSE;
                END IF;

                DBG('ATM Transaction - Amount After Currency Conversion' ||
                    G_ACC_AMT);
                DBG('ATM Transaction - Starting Limits Check');
              END IF;
              IF NOT NVL(PKG_CARD_DETAILS_REC.ATM_DLY_TXN_LIMIT, 0) = 0 THEN
                PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT -
                                                           G_ACC_AMT;

              ELSE
                PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT := 0;
              END IF;

              DBG('For Reversal -Pkg_Card_Details_Rec.Atm_Utilized_Limit After Deduction' ||
                  PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT);
              IF NOT NVL(PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT, 0) = 0 THEN
                UPDATE SWTMS_CARD_DETAILS
                   SET ATM_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT,
                       ATM_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT - 2,
                       LAST_TXN_DATE      = PKG_CARD_DETAILS_REC.LAST_TXN_DATE,
                       POS_UTILIZED_LIMIT = PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT,
                       POS_UTILIZED_COUNT = PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT
                 WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
                   AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
                   AND AUTH_STAT = 'A'
                   AND RECORD_STAT = 'O';
              END IF;
              DBG('For Reversal -Pkg_Card_Details_Rec.Atm_Utilized_Count after updation' ||
                  PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT);
            END IF;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CODE  := 'SW-CHL-03';
              P_ERR_PARAM := 'Record Not Found';
              RETURN FALSE;
          END;

        END IF;

      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
    DBG('Returning Success from Fn_Update_Limits');
    RETURN TRUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERR_CODE  := 'SW-CHL-03';
      P_ERR_PARAM := P_TY_ATM_TXN_REC.PAN || '~' ||
                     P_TY_ATM_TXN_REC.FROM_ACC;
      DBG('E',
          'fn_update_limits : No data found in swtm_card_detail ' ||
          P_ERR_CODE || '~' || P_ERR_PARAM);
      RETURN FALSE;
    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-CHL-03';
      P_ERR_PARAM := 'Fn_Update_Limits' || P_ERR_CODE;
      DBG('E', 'Fn_Update_Limits : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;

  END FN_UPDATE_LIMITS;

  FUNCTION FN_CHECK_CHANNEL_LIMITS(P_TY_ATM_TXN_REC IN OUT NOCOPY TY_ATM_TXN_REC,
                                   P_ERR_CODE       IN OUT VARCHAR2,
                                   P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_TXN_DATE      VARCHAR2(4);
    L_TXN_LIMIT_AMT NUMBER;

    L_CARD_TYPE           SWTMS_CARD_DETAILS.CARD_TYPE%TYPE;
    L_CATEGORY            SWTMS_CARD_DETAILS.CATEGORY%TYPE;
    L_ATM_DLY_TXN_LIMIT   NUMBER;
    L_ATM_DLY_COUNT_LIMIT NUMBER;
    L_POS_DLY_TXN_LIMIT   NUMBER;
    L_POS_DLY_COUNT_LIMIT NUMBER;
    L_ATM_MAX_TXN_LIMIT   NUMBER;
    L_POS_MAX_TXN_LIMIT   NUMBER;
    L_ATM_LAST_TXN_DATE   DATE;
    L_POS_LAST_TXN_DATE   DATE;
    L_TRANSACTION_AMT     NUMBER;
    L_ATM_UTILIZED_LIMIT  NUMBER;
    L_POS_UTILIZED_LIMIT  NUMBER;
    L_ATM_UTILIZED_COUNT  NUMBER(3);
    L_POS_UTILIZED_COUNT  NUMBER(3);

    L_PARENT_FOUND   VARCHAR2(1);
    L_MSG_TYPE_TEMP  VARCHAR2(16) DEFAULT NULL;
    L_KEY_TEMP       VARCHAR2(255) DEFAULT NULL;
    L_AMONT_BLOCK_NO VARCHAR2(35) DEFAULT NULL;
    L_TRANS_DT_TIME  VARCHAR2(12);
    L_TXN_AMT        NUMBER;
    L_ORIG_TXN_AMT   NUMBER;

  BEGIN

    DBG('Inside Fn_Check_Channel_Limits');
    G_ACC_AMT := 0;

    DBG('p_Ty_Atm_Txn_Rec.Switch_Param_Flg.Only_Pan_From_Switch~' ||
        P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH);
    IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH = 'Y' THEN
      RETURN TRUE;
    END IF;

    SELECT *
      INTO PKG_CARD_DETAILS_REC
      FROM SWTMS_CARD_DETAILS
     WHERE ATM_CARD_NO = P_TY_ATM_TXN_REC.PAN
       AND ATM_ACC_NO = P_TY_ATM_TXN_REC.FROM_ACC
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';

    DBG('Inside block Fn_Check_Channel_Limits Category ' ||
        PKG_CARD_DETAILS_REC.CATEGORY);
    IF PKG_CARD_DETAILS_REC.CATEGORY = 'D' THEN
      DBG('before taking defaults...');
      SELECT *
        INTO PKG_CARD_LIMITS_REC
        FROM SWTMS_CARD_LIMITS
       WHERE CARD_TYPE = PKG_CARD_DETAILS_REC.CARD_TYPE
         AND CCY_CODE = P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC;

      PKG_CARD_DETAILS_REC.ATM_DLY_TXN_LIMIT   := PKG_CARD_LIMITS_REC.ATM_DLY_TXN_LIMIT;
      PKG_CARD_DETAILS_REC.ATM_DLY_COUNT_LIMIT := PKG_CARD_LIMITS_REC.ATM_DLY_COUNT_LIMIT;
      PKG_CARD_DETAILS_REC.ATM_MAX_TXN_LIMIT   := PKG_CARD_LIMITS_REC.ATM_MAX_TXN_LIMIT;
      PKG_CARD_DETAILS_REC.POS_DLY_TXN_LIMIT   := PKG_CARD_LIMITS_REC.POS_DLY_TXN_LIMIT;
      PKG_CARD_DETAILS_REC.POS_DLY_COUNT_LIMIT := PKG_CARD_LIMITS_REC.POS_DLY_COUNT_LIMIT;
      PKG_CARD_DETAILS_REC.POS_MAX_TXN_LIMIT   := PKG_CARD_LIMITS_REC.POS_MAX_TXN_LIMIT;

    ELSIF PKG_CARD_DETAILS_REC.CATEGORY = 'S' THEN
      DBG('fetching per transaction limits for special');
      SELECT ATM_MAX_TXN_LIMIT, POS_MAX_TXN_LIMIT
        INTO PKG_CARD_DETAILS_REC.ATM_MAX_TXN_LIMIT,
             PKG_CARD_DETAILS_REC.POS_MAX_TXN_LIMIT
        FROM SWTMS_CARD_LIMITS
       WHERE CARD_TYPE = PKG_CARD_DETAILS_REC.CARD_TYPE
         AND CCY_CODE = P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC;

    END IF;

    DBG('Pkg_Card_Details_Rec.Atm_Dly_Txn_Limit~' ||
        PKG_CARD_DETAILS_REC.ATM_DLY_TXN_LIMIT);
    DBG('Pkg_Card_Details_Rec.Atm_Dly_Count_Limit~' ||
        PKG_CARD_DETAILS_REC.ATM_DLY_COUNT_LIMIT);
    DBG('Pkg_Card_Details_Rec.Atm_Max_Txn_Limit~' ||
        PKG_CARD_DETAILS_REC.ATM_MAX_TXN_LIMIT);
    DBG('Pkg_Card_Details_Rec.Pos_Dly_Txn_Limit~' ||
        PKG_CARD_DETAILS_REC.POS_DLY_TXN_LIMIT);
    DBG('Pkg_Card_Details_Rec.Pos_Dly_Count_Limit~' ||
        PKG_CARD_DETAILS_REC.POS_DLY_COUNT_LIMIT);
    DBG('Pkg_Card_Details_Rec.Pos_Max_Txn_Limit~' ||
        PKG_CARD_DETAILS_REC.POS_MAX_TXN_LIMIT);
    DBG('Pkg_Card_Details_Rec.last_txn_date~' ||
        PKG_CARD_DETAILS_REC.LAST_TXN_DATE);
    DBG('Pkg_Card_Details_Rec.Atm_Utilized_Limit~' ||
        PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT);
    DBG('Pkg_Card_Details_Rec.Pos_Utilized_Limit~' ||
        PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT);
    DBG('Pkg_Card_Details_Rec.Pos_Utilized_Count~' ||
        PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT);
    DBG('Pkg_Card_Details_Rec.Atm_Utilized_Count~' ||
        PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT);

    DBG('p_Ty_Atm_Txn_Rec.Local_Txn_Dt~' || P_TY_ATM_TXN_REC.LOCAL_TXN_DT);
    DBG('p_Ty_Atm_Txn_Rec.Trans_Dt_Time ~' ||
        SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4));
    IF NOT SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '4' THEN
      IF (PKG_CARD_DETAILS_REC.LAST_TXN_DATE <>
         (SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME, 1, 4)) OR
         PKG_CARD_DETAILS_REC.LAST_TXN_DATE IS NULL) THEN
        DBG('dates are different, reseting old utilizations to zero...');

        PKG_CARD_DETAILS_REC.LAST_TXN_DATE      := SUBSTR(P_TY_ATM_TXN_REC.TRANS_DT_TIME,
                                                          1,
                                                          4);
        PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT := 0;
        PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT := 0;
        PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT := 0;
        PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT := 0;
      END IF;
    END IF;

    L_TXN_LIMIT_AMT := TO_NUMBER(SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                        1,
                                        12 - P_TY_ATM_TXN_REC.TXN_CCY_MINOR) || '.' ||
                                 SUBSTR(P_TY_ATM_TXN_REC.TXN_AMT,
                                        13 - P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR));

    IF NOT FN_CCY_TRANS(P_TY_ATM_TXN_REC.TXN_CCY_CODE,
                        P_TY_ATM_TXN_REC.TXN_CCY_DERIVED,
                        P_TY_ATM_TXN_REC.TXN_CCY_MINOR,
                        P_ERR_CODE) THEN
      DBG('E',
          'fn_Check_Channel_Limits : No proper translation avl for ccy type ' ||
          P_TY_ATM_TXN_REC.TXN_CCY_CODE || '~' ||
          P_TY_ATM_TXN_REC.TXN_CCY_FCC);
      P_ERR_PARAM := 'fn_Check_Channel_Limits' || '~' || P_ERR_CODE;
      RETURN FALSE;
    END IF;
    DBG('p_Ty_Atm_Txn_Rec.Txn_Ccy_Derived' ||
        P_TY_ATM_TXN_REC.TXN_CCY_DERIVED);

    IF NOT
        (P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC = P_TY_ATM_TXN_REC.TXN_CCY_DERIVED) THEN

      IF NOT GWPKSS_CREATESWTRANSACTION.FN_PRODUCT_DERIVE(P_TY_ATM_TXN_REC,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM) THEN
        DBG('E',
            'Failed while calling Gwpks_CreateSWTransaction.fn_product_derive' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;

      BEGIN
        SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
          INTO P_TY_ATM_TXN_REC.RATE_CODE, P_TY_ATM_TXN_REC.RATE_TYPE
          FROM CSTMS_PRODUCT
         WHERE PRODUCT_CODE = P_TY_ATM_TXN_REC.PRODUCT_CODE
           AND MODULE = 'RT'
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_CODE                 := 'SW-PRD-01';
          P_TY_ATM_TXN_REC.RESP_CODE := '05';
          DBG('E',
              'NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
              P_ERR_PARAM);
          RETURN FALSE;
      END;

      IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_TY_ATM_TXN_REC.ACC_BRANCH_CODE,
                                    P_TY_ATM_TXN_REC.TXN_CCY_DERIVED,
                                    P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC,
                                    P_TY_ATM_TXN_REC.RATE_TYPE,
                                    P_TY_ATM_TXN_REC.RATE_CODE

                                   ,
                                    L_TXN_LIMIT_AMT,

                                    'Y',
                                    G_ACC_AMT,
                                    P_TY_ATM_TXN_REC.X_RATE_DERIVED,
                                    P_ERR_CODE) THEN
        P_ERR_CODE  := 'SW-AMT-01';
        P_ERR_PARAM := '~' || P_TY_ATM_TXN_REC.TXN_CCY_DERIVED || '~' ||
                       P_TY_ATM_TXN_REC.TXN_ACC_CCY_FCC;
        DBG('E',
            'fn_amount_derive : Calling cypks.fn_amt1_to_amt2 failed ' ||
            P_ERR_CODE || '~' || P_ERR_PARAM);
        RETURN FALSE;
      END IF;
      L_TXN_LIMIT_AMT := G_ACC_AMT;
    ELSE

      G_ACC_AMT := L_TXN_LIMIT_AMT;

    END IF;

    DBG('Fn_Check_Channel_Limits - Transaction Amount ' || G_ACC_AMT);
    DBG('Fn_Check_Channel_Limits - Transaction Currency ' ||
        P_TY_ATM_TXN_REC.TXN_CCY_DERIVED);

    IF (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 3) = '220') THEN

      IF (P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.FOLLOW_ON = 'Y' OR
         P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.AMOUNT_BLOCK = 'Y') THEN
        L_MSG_TYPE_TEMP := SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 1) || '200';
        DBG('l_Msg_Type_Temp : Deriving PKEY ' || L_MSG_TYPE_TEMP);
        DBG('fn_txn_contol : Deriving PKEY ');
      ELSE
        L_MSG_TYPE_TEMP := SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 1, 1) || '100';
        DBG('l_Msg_Type_Temp : Deriving PKEY ' || L_MSG_TYPE_TEMP);
        DBG('fn_txn_contol : Deriving PKEY ');
      END IF;
      IF NOT SWPKS_UTILS.FN_GET_PARENT_KEY(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.LOG_TABLE_KEY,
                                           P_TY_ATM_TXN_REC.P_KEY,
                                           L_MSG_TYPE_TEMP,
                                           P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.CHANNEL,
                                           L_KEY_TEMP) THEN
        DBG('E',
            'fn_txn_contol: swpks_utils.fn_get_parent_key returned false ');
        P_ERR_CODE  := 'SW-KEY-02';
        P_ERR_PARAM := NULL;
        RETURN FALSE;
      END IF;
      DBG('Parent Found for 200 ' || L_KEY_TEMP);

      BEGIN
        SELECT AMOUNT_BLOCK_NO, TRANS_DT_TIME, TXN_AMT
          INTO L_AMONT_BLOCK_NO, L_TRANS_DT_TIME, L_ORIG_TXN_AMT
          FROM SWTB_TXN_LOG
         WHERE P_KEY = L_KEY_TEMP;
        L_PARENT_FOUND := 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('parent not found');
          L_PARENT_FOUND := 'N';
      END;
    END IF;

    IF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '00') THEN

      DBG('POS Transaction - POS Limits to be Considered');
      PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT := PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT + 1;
      DBG('p_Ty_Atm_Txn_Rec.Msg_Type' || P_TY_ATM_TXN_REC.MSG_TYPE);
      DBG('POS Transaction - POS Limits to be Considered' ||
          SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 2));

      IF NOT (((SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 3, 1) = '2') AND
          L_PARENT_FOUND = 'Y') OR
          (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '4')) THEN
        DBG('Checking POS Transactions Limits');
        DBG('Pos_Dly_Count_Limit' ||
            PKG_CARD_DETAILS_REC.POS_DLY_COUNT_LIMIT);

        IF NOT NVL(PKG_CARD_DETAILS_REC.POS_DLY_COUNT_LIMIT, 0) = 0 THEN
          IF (PKG_CARD_DETAILS_REC.POS_UTILIZED_COUNT >
             PKG_CARD_DETAILS_REC.POS_DLY_COUNT_LIMIT) THEN
            DBG('POS Transaction - Transaction Count Limts Failed');
            P_ERR_CODE  := 'SW-CHL-01';
            P_ERR_PARAM := L_TRANSACTION_AMT;
            DBG('E',
                'Fn_Check_Channel_Limits : Transaction Not Allowed ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          END IF;
        END IF;

        PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT +
                                                   L_TXN_LIMIT_AMT;

        IF NOT NVL(PKG_CARD_DETAILS_REC.POS_DLY_TXN_LIMIT, 0) = 0 THEN
          IF (PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT >
             PKG_CARD_DETAILS_REC.POS_DLY_TXN_LIMIT) THEN
            DBG('POS Transaction - Transaction Amount Limts Failed');
            P_ERR_CODE  := 'SW-CHL-02';
            P_ERR_PARAM := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT;
            DBG('E',
                'Fn_Amount_Channel_Limits : Transaction Not Allowed ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          END IF;
        END IF;

        IF NOT NVL(PKG_CARD_DETAILS_REC.POS_MAX_TXN_LIMIT, 0) = 0 THEN
          IF (L_TXN_LIMIT_AMT > PKG_CARD_DETAILS_REC.POS_MAX_TXN_LIMIT) THEN
            DBG('POS Transaction - MAX Transaction Amount Limts Failed');
            P_ERR_CODE  := 'SW-CHL-02';
            P_ERR_PARAM := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT;
            DBG('E',
                'Fn_Amount_Channel_Limits : Transaction Not Allowed ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          END IF;
        END IF;

        PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.POS_UTILIZED_LIMIT -
                                                   L_TXN_LIMIT_AMT;
      END IF;

    ELSIF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) = '01') THEN

      PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT + 1;

      IF NOT (((SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 3, 1) = '2') AND
          L_PARENT_FOUND = 'Y') OR
          (SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '4')) THEN
        DBG('entered');
        IF NOT NVL(PKG_CARD_DETAILS_REC.ATM_DLY_COUNT_LIMIT, 0) = 0 THEN
          IF (PKG_CARD_DETAILS_REC.ATM_UTILIZED_COUNT >
             PKG_CARD_DETAILS_REC.ATM_DLY_COUNT_LIMIT) THEN
            DBG('ATM Transaction - Transaction Count Limts Failed');
            P_ERR_CODE  := 'SW-CHL-01';
            P_ERR_PARAM := L_TRANSACTION_AMT;
            DBG('E',
                'Fn_Check_Channel_Limits : Transaction Not Allowed ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          END IF;
        END IF;

        PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT +
                                                   L_TXN_LIMIT_AMT;

        IF NOT NVL(PKG_CARD_DETAILS_REC.ATM_DLY_TXN_LIMIT, 0) = 0 THEN
          IF (PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT >
             PKG_CARD_DETAILS_REC.ATM_DLY_TXN_LIMIT) THEN
            DBG('ATM Transaction - Transaction Amount Limts Failed');
            P_ERR_CODE  := 'SW-CHL-02';
            P_ERR_PARAM := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT;
            DBG('E',
                'Fn_Amount_Channel_Limits : Transaction Not Allowed ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          END IF;
        END IF;

        IF NOT NVL(PKG_CARD_DETAILS_REC.ATM_MAX_TXN_LIMIT, 0) = 0 THEN

          IF (L_TXN_LIMIT_AMT > PKG_CARD_DETAILS_REC.ATM_MAX_TXN_LIMIT) THEN
            DBG('ATM Transaction - MAX Transaction Amount Limts Failed');
            P_ERR_CODE  := 'SW-CHL-02';
            P_ERR_PARAM := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT;
            DBG('E',
                'Fn_Amount_Channel_Limits : Transaction Not Allowed ' ||
                P_ERR_CODE || '~' || P_ERR_PARAM);
            RETURN FALSE;
          END IF;
        END IF;
        PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT := PKG_CARD_DETAILS_REC.ATM_UTILIZED_LIMIT -
                                                   L_TXN_LIMIT_AMT;
      END IF;
    END IF;

    DBG('Returning Success from Fn_Check_Channel_Limits');
    RETURN TRUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERR_CODE  := 'SW-CHL-01';
      P_ERR_PARAM := P_TY_ATM_TXN_REC.PAN || '~' ||
                     P_TY_ATM_TXN_REC.FROM_ACC;
      DBG('E',
          'Fn_Check_Channel_Limits : No data found in swtm_card_detail ' ||
          P_ERR_CODE || '~' || P_ERR_PARAM);
      RETURN FALSE;
    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-CHL-01';
      P_ERR_PARAM := 'Fn_Check_Channel_Limits' || P_ERR_CODE;
      DBG('E',
          'Fn_Check_Channel_Limits : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;

  END FN_CHECK_CHANNEL_LIMITS;

  FUNCTION FN_BUILD_ATM_NOTIF_XML(P_TY_ATM_NOTIF_REC IN OUT NOCOPY TY_ATM_NOTIF_REC,
                                  P_PARENTS_LIST     IN OUT VARCHAR2,
                                  P_PARENTS_FORMAT   IN OUT VARCHAR2,
                                  P_TS_TAG_NAMES     IN OUT VARCHAR2,
                                  P_TS_TAG_VALUES    IN OUT VARCHAR2,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_CCY_MINOR       CYTMS_CCY_DEFN.CCY_DECIMALS%TYPE;
    L_CURR_BAL_DEBIT  VARCHAR2(50);
    L_AVL_BAL_DEBIT   VARCHAR2(50);
    L_CURR_BAL_CREDIT VARCHAR2(50);
    L_AVL_BAL_CREDIT  VARCHAR2(50);
    L_TRAN_TYPE       VARCHAR2(5);
    L_AC_NO           STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRANCH_CODE     STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
  BEGIN

    DBG('inside Fn_Build_Atm_Notif_Xml');

    IF GWPKS_EXT_SWITCHSERVICE.G_CALL_EXTENSIBILITY THEN
      IF NOT
          GWPKSS_EXT_SWITCHSERVICE.FN_PRE_BUILD_ATM_NOTIF_XML(P_TY_ATM_NOTIF_REC,
                                                              P_PARENTS_LIST,
                                                              P_PARENTS_FORMAT,
                                                              P_TS_TAG_NAMES,
                                                              P_TS_TAG_VALUES,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAM) THEN
        DBG('Function gwpkss_ext_switchservice.fn_pre_build_atm_notif_xml returned FALSE');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('p_Parents_List ::::: ' || P_PARENTS_LIST);
      DBG('p_Parents_Format :::: ' || P_PARENTS_FORMAT);
      P_PARENTS_FORMAT := '1>';
      IF P_PARENTS_LIST = 'Switch-Notif-IO' THEN
        P_TS_TAG_NAMES := 'TRN_REF_NO' || '~' || 'AMT_BLK_NO' || '~' ||
                          'TXN_CODE' || '~' || 'TRN_CODE_DESC' || '~' ||
                          'TRN_PROD_CODE' || '~' || 'TRN_PROD_DESC' || '~' ||
                          'DEBIT_ACC' || '~' || 'DEBIT_ACC_CCY' || '~' ||
                          'DEBIT_AMT' || '~' || 'CREDIT_ACC' || '~' ||
                          'CREDIT_ACC_CCY' || '~' || 'CREDIT_AMT' || '~' ||
                          'TRANS_DT_TIME' || '~' || 'VALUE_DT' || '~' ||
                          'TRANS_DESC' || '~' || 'ATM_LOC' || '~' ||
                          'TERM_ID' || '~' || 'RRN' || '~' || 'MERCHANT_ID' || '~' ||
                          'MERCHANT_NAME' || '~' || 'ATM_CARD_NO' || '~' ||
                          'CURR_BAL_DEBIT' || '~' || 'AVAIL_BAL_DEBIT' || '~' ||
                          'CURR_BAL_CREDIT' || '~' || 'AVAIL_BAL_CREDIT' || '~' ||
                          'ACQ_INS_ID' || '~' || 'ACQ_INS_DESC' || '~' ||
                          'FWD_INS_ID' || '~' || 'RESP_CODE' || '~' ||
                          'MSG_TYPE' || '~' || 'PROC_CODE' || '~' ||
                          'FILE_PROCESS' || '~' || '~>';

        IF P_TY_ATM_NOTIF_REC.DEBIT_ACC_CURR IS NOT NULL AND
           P_TY_ATM_NOTIF_REC.BALANCES IS NOT NULL THEN
          BEGIN
            SELECT CCY_DECIMALS, CCY_CODE
              INTO L_CCY_MINOR, P_TY_ATM_NOTIF_REC.DEBIT_ACC_CURR
              FROM CYTMS_CCY_DEFN
             WHERE ISO_NUM_CCY_CODE = P_TY_ATM_NOTIF_REC.DEBIT_ACC_CURR
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Debit Currency Not Found');
          END;
          L_CURR_BAL_DEBIT := P_TY_ATM_NOTIF_REC.DEBIT_ACC_CURR || ' ' ||
                              TO_NUMBER(SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                               9,
                                               12 - L_CCY_MINOR)

                                        || '.' ||
                                        SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                               21 - L_CCY_MINOR,
                                               L_CCY_MINOR));
          DBG('Curr Bal' || L_CURR_BAL_DEBIT);
          L_AVL_BAL_DEBIT := P_TY_ATM_NOTIF_REC.DEBIT_ACC_CURR || ' ' ||
                             TO_NUMBER(SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                              49,
                                              12 - L_CCY_MINOR)

                                       || '.' ||
                                       SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                              61 - L_CCY_MINOR,
                                              L_CCY_MINOR));
          DBG('Avail Bal' || L_AVL_BAL_DEBIT);
        END IF;

        IF P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR IS NOT NULL AND
           P_TY_ATM_NOTIF_REC.BALANCES IS NOT NULL THEN
          BEGIN
            SELECT CCY_DECIMALS, CCY_CODE
              INTO L_CCY_MINOR, P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR
              FROM CYTMS_CCY_DEFN
             WHERE ISO_NUM_CCY_CODE = P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Credit Currency Not Found');
          END;
          L_CURR_BAL_CREDIT := P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR || ' ' ||
                               TO_NUMBER(SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                                9,
                                                12 - L_CCY_MINOR)

                                         || '.' ||
                                         SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                                21 - L_CCY_MINOR,
                                                L_CCY_MINOR));
          L_AVL_BAL_CREDIT  := P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR || ' ' ||
                               TO_NUMBER(SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                                49,
                                                12 - L_CCY_MINOR)

                                         || '.' ||
                                         SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                                61 - L_CCY_MINOR,
                                                L_CCY_MINOR));
        END IF;

        IF P_TY_ATM_NOTIF_REC.PROC_CODE IS NOT NULL THEN
          BEGIN
            SELECT FC_LITERAL
              INTO L_TRAN_TYPE
              FROM SWTM_FCLITERAL_CODE
             WHERE PROC_CODE_TYPE =
                   SUBSTR(P_TY_ATM_NOTIF_REC.PROC_CODE, 1, 2);

          EXCEPTION
            WHEN NO_DATA_FOUND THEN

              L_TRAN_TYPE := NULL;
          END;
          DBG('l_Tran_Type' || L_TRAN_TYPE);
          IF L_TRAN_TYPE IN ('CDP', 'PCT') THEN --sampath added PCT for UPI
            P_TY_ATM_NOTIF_REC.CREDIT_AMT := P_TY_ATM_NOTIF_REC.DEBIT_AMT;
            P_TY_ATM_NOTIF_REC.DEBIT_AMT  := NULL;
          END IF;

          IF L_TRAN_TYPE IN ('FTR', 'PAY', 'DFT', 'CFT') THEN
            --sampath added for Dr IBFT and Cr IBFT for CSS
            BEGIN
              SELECT LCY_AMOUNT, AC_NO, AC_BRANCH
                INTO P_TY_ATM_NOTIF_REC.CREDIT_AMT, L_AC_NO, L_BRANCH_CODE
                FROM ACTB_DAILY_LOG
               WHERE TRN_REF_NO = P_TY_ATM_NOTIF_REC.TRN_REF_NO
                 AND ENTRY_SEQ_NO = 4;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                P_TY_ATM_NOTIF_REC.CREDIT_AMT := NULL;
            END;
            BEGIN

              SELECT B.ACY_CURR_ACC_BAL, A.CCY

                INTO L_CURR_BAL_CREDIT, P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR
                FROM STTMS_CUST_ACCOUNT A, STTM_ACCOUNT_BALANCE B
               WHERE A.BRANCH_CODE = L_BRANCH_CODE
                 AND A.CUST_AC_NO = L_AC_NO
                 AND A.AUTH_STAT = 'A'
                 AND A.RECORD_STAT = 'O'

                 AND A.CUST_AC_NO = B.CUST_AC_NO
                 AND A.BRANCH_CODE = B.CUST_AC_BRN;

              L_CURR_BAL_CREDIT := P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR || ' ' ||
                                   L_CURR_BAL_CREDIT;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                L_CURR_BAL_CREDIT := NULL;
            END;
            DBG('fn_get_balances : After ');
            IF NOT ACPKSS_MISC.FN_GETAVLBAL(L_BRANCH_CODE,
                                            L_AC_NO,
                                            L_AVL_BAL_CREDIT,
                                            'Y') THEN
              L_AVL_BAL_CREDIT := NULL;
            END IF;
            L_AVL_BAL_CREDIT := P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR || ' ' ||
                                L_AVL_BAL_CREDIT;
          END IF;
        END IF;
        P_TS_TAG_VALUES := P_TY_ATM_NOTIF_REC.TRN_REF_NO || '~' ||
                           P_TY_ATM_NOTIF_REC.AMOUNT_BLOCK_NO || '~' ||
                           P_TY_ATM_NOTIF_REC.TXN_CODE || '~' ||
                           P_TY_ATM_NOTIF_REC.TXN_CODE_DESC || '~' ||
                           P_TY_ATM_NOTIF_REC.TXN_PROD_CODE || '~' ||
                           P_TY_ATM_NOTIF_REC.TXN_PROD_DESC || '~' ||
                           P_TY_ATM_NOTIF_REC.DEBIT_ACC || '~' ||
                           P_TY_ATM_NOTIF_REC.DEBIT_ACC_CURR || '~' ||
                           P_TY_ATM_NOTIF_REC.DEBIT_AMT || '~' ||
                           P_TY_ATM_NOTIF_REC.CREDIT_ACC || '~' ||
                           P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR || '~' ||
                           P_TY_ATM_NOTIF_REC.CREDIT_AMT || '~' ||
                           SUBSTR(P_TY_ATM_NOTIF_REC.DATE_TRN, 1, 18) || ' ' ||
                           SUBSTR(P_TY_ATM_NOTIF_REC.DATE_TRN, 27, 2) || '~' ||
                           P_TY_ATM_NOTIF_REC.VAL_DATE || '~' ||
                           P_TY_ATM_NOTIF_REC.TXN_DESC || '~' ||
                           P_TY_ATM_NOTIF_REC.ATM_LOC || '~' ||
                           P_TY_ATM_NOTIF_REC.TERM_ID || '~' ||
                           P_TY_ATM_NOTIF_REC.RRN || '~' ||
                           P_TY_ATM_NOTIF_REC.MERCH_ID || '~' ||
                           P_TY_ATM_NOTIF_REC.MERCH_ID || '~' ||
                           P_TY_ATM_NOTIF_REC.ATM_CARD_NO || '~' ||
                           L_AVL_BAL_DEBIT || '~' || L_CURR_BAL_DEBIT || '~' ||
                           L_AVL_BAL_CREDIT || '~' || L_CURR_BAL_CREDIT || '~' ||
                           P_TY_ATM_NOTIF_REC.ACQ_INS_ID || '~' ||
                           P_TY_ATM_NOTIF_REC.ACQ_ID || '~' ||
                           P_TY_ATM_NOTIF_REC.FWD_INS_ID || '~' ||
                           P_TY_ATM_NOTIF_REC.RESP_CODE || '~' ||
                           P_TY_ATM_NOTIF_REC.MSG_TYPE || '~' ||
                           P_TY_ATM_NOTIF_REC.PROC_CODE || '~' ||
                           P_TY_ATM_NOTIF_REC.FILE_PROCESS || '~' || '~>';
        DBG('Tag Created Successfully');
      END IF;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    RETURN TRUE;

  EXCEPTION

    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-CON-01';
      P_ERR_PARAM := 'Fn_Build_Atm_Notif_Xml' || P_ERR_CODE;
      DBG('E',
          'Fn_Build_Atm_Notif_Xml : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;

  END FN_BUILD_ATM_NOTIF_XML;

  FUNCTION FN_GET_ATM_NOTIF_DATA(P_XREF             IN OUT VARCHAR2,
                                 P_TY_ATM_NOTIF_REC IN OUT NOCOPY TY_ATM_NOTIF_REC,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_TRAN_DT   VARCHAR2(50);
    L_TRAN_TIME VARCHAR2(50);

  BEGIN

    DBG('inside Fn_Get_Atm_Notif_Data');

    BEGIN
      SELECT TRN_REF_NO,
             AMOUNT_BLOCK_NO,
             FROM_ACC,
             TO_ACC,
             TERM_ID,
             RRN,
             PAN,
             ADD_AMT,
             ACQ_INS_ID,
             FWD_INS_ID,
             RESP_CODE,
             MSG_TYPE,
             PROC_CODE,
             FILE_PROCESS
        INTO P_TY_ATM_NOTIF_REC.TRN_REF_NO,
             P_TY_ATM_NOTIF_REC.AMOUNT_BLOCK_NO,
             P_TY_ATM_NOTIF_REC.DEBIT_ACC,
             P_TY_ATM_NOTIF_REC.CREDIT_ACC,
             P_TY_ATM_NOTIF_REC.TERM_ID,
             P_TY_ATM_NOTIF_REC.RRN,
             P_TY_ATM_NOTIF_REC.ATM_CARD_NO,
             P_TY_ATM_NOTIF_REC.BALANCES,
             P_TY_ATM_NOTIF_REC.ACQ_INS_ID,
             P_TY_ATM_NOTIF_REC.FWD_INS_ID,
             P_TY_ATM_NOTIF_REC.RESP_CODE,
             P_TY_ATM_NOTIF_REC.MSG_TYPE,
             P_TY_ATM_NOTIF_REC.PROC_CODE,
             P_TY_ATM_NOTIF_REC.FILE_PROCESS
        FROM SWTBS_TXN_LOG
       WHERE XREF = P_XREF;
      IF P_TY_ATM_NOTIF_REC.DEBIT_ACC IS NOT NULL THEN
        DBG('P_Ty_Atm_Notif_Rec.Balances' || P_TY_ATM_NOTIF_REC.BALANCES);
        P_TY_ATM_NOTIF_REC.DEBIT_ACC_CURR := SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                                    5,
                                                    3);
      END IF;
      IF P_TY_ATM_NOTIF_REC.CREDIT_ACC IS NOT NULL THEN
        DBG('P_Ty_Atm_Notif_Rec.Balances' || P_TY_ATM_NOTIF_REC.BALANCES);
        P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR := SUBSTR(P_TY_ATM_NOTIF_REC.BALANCES,
                                                     5,
                                                     3);

      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_TY_ATM_NOTIF_REC.TRN_REF_NO      := NULL;
        P_TY_ATM_NOTIF_REC.AMOUNT_BLOCK_NO := NULL;
        P_TY_ATM_NOTIF_REC.DEBIT_ACC       := NULL;
        P_TY_ATM_NOTIF_REC.CREDIT_ACC      := NULL;
        P_TY_ATM_NOTIF_REC.DATE_TRN        := NULL;
        P_TY_ATM_NOTIF_REC.TERM_ID         := NULL;
        P_TY_ATM_NOTIF_REC.RRN             := NULL;
        P_TY_ATM_NOTIF_REC.ATM_CARD_NO     := NULL;
        P_TY_ATM_NOTIF_REC.BALANCES        := NULL;
        P_TY_ATM_NOTIF_REC.ACQ_INS_ID      := NULL;
        P_TY_ATM_NOTIF_REC.FWD_INS_ID      := NULL;
        P_TY_ATM_NOTIF_REC.RESP_CODE       := NULL;
        P_TY_ATM_NOTIF_REC.MSG_TYPE        := NULL;
        P_TY_ATM_NOTIF_REC.PROC_CODE       := NULL;
    END;

    IF P_TY_ATM_NOTIF_REC.AMOUNT_BLOCK_NO IS NOT NULL THEN

      BEGIN
        SELECT MAKER_DT_STAMP
          INTO P_TY_ATM_NOTIF_REC.DATE_TRN
          FROM CATMS_AMOUNT_BLOCKS
         WHERE AMOUNT_BLOCK_NO = P_TY_ATM_NOTIF_REC.AMOUNT_BLOCK_NO;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_TY_ATM_NOTIF_REC.DATE_TRN := NULL;

      END;

    ELSE

      BEGIN
        SELECT MAKER_DT_STAMP
          INTO P_TY_ATM_NOTIF_REC.DATE_TRN
          FROM DETBS_RTL_TELLER
         WHERE TRN_REF_NO = P_TY_ATM_NOTIF_REC.TRN_REF_NO;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_TY_ATM_NOTIF_REC.DATE_TRN := NULL;

      END;

    END IF;
    DBG('P_Ty_Atm_Notif_Rec.Date_Trn ' || P_TY_ATM_NOTIF_REC.DATE_TRN);

    BEGIN

      IF SUBSTR(P_TY_ATM_NOTIF_REC.MSG_TYPE, 2, 1) = '4' THEN
        SELECT TRN_CODE, PRODUCT, ABS(LCY_AMOUNT), VALUE_DT, AC_CCY
          INTO P_TY_ATM_NOTIF_REC.TXN_CODE,
               P_TY_ATM_NOTIF_REC.TXN_PROD_CODE,
               P_TY_ATM_NOTIF_REC.CREDIT_AMT,
               P_TY_ATM_NOTIF_REC.VAL_DATE,
               P_TY_ATM_NOTIF_REC.CREDIT_ACC_CURR
          FROM ACTB_DAILY_LOG
         WHERE TRN_REF_NO = P_TY_ATM_NOTIF_REC.TRN_REF_NO
           AND ENTRY_SEQ_NO = 1
           AND EVENT = 'REVR';
        P_TY_ATM_NOTIF_REC.CREDIT_ACC := P_TY_ATM_NOTIF_REC.DEBIT_ACC;
        P_TY_ATM_NOTIF_REC.DEBIT_ACC  := NULL;
      ELSE

        SELECT TRN_CODE, PRODUCT, LCY_AMOUNT, VALUE_DT
          INTO P_TY_ATM_NOTIF_REC.TXN_CODE,
               P_TY_ATM_NOTIF_REC.TXN_PROD_CODE,
               P_TY_ATM_NOTIF_REC.DEBIT_AMT,
               P_TY_ATM_NOTIF_REC.VAL_DATE
          FROM ACTB_DAILY_LOG
         WHERE TRN_REF_NO = P_TY_ATM_NOTIF_REC.TRN_REF_NO
           AND ENTRY_SEQ_NO = 1;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_TY_ATM_NOTIF_REC.TXN_CODE      := NULL;
        P_TY_ATM_NOTIF_REC.TXN_PROD_CODE := NULL;
        P_TY_ATM_NOTIF_REC.DEBIT_AMT     := NULL;
        P_TY_ATM_NOTIF_REC.VAL_DATE      := NULL;

    END;

    BEGIN

      SELECT TRIM(PRODUCT_DESCRIPTION)
        INTO P_TY_ATM_NOTIF_REC.TXN_PROD_DESC
        FROM CSTM_PRODUCT
       WHERE PRODUCT_CODE = P_TY_ATM_NOTIF_REC.TXN_PROD_CODE;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_TY_ATM_NOTIF_REC.TXN_PROD_DESC := NULL;
    END;

    BEGIN

      SELECT TRIM(TRN_DESC)
        INTO P_TY_ATM_NOTIF_REC.TXN_CODE_DESC
        FROM STTM_TRN_CODE
       WHERE TRN_CODE = P_TY_ATM_NOTIF_REC.TXN_CODE;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_TY_ATM_NOTIF_REC.TXN_CODE_DESC := NULL;
    END;
    BEGIN

      SELECT TRIM(ADDL_TEXT)
        INTO P_TY_ATM_NOTIF_REC.TXN_DESC
        FROM CSTB_ADDL_TEXT
       WHERE REFERENCE_NO = P_TY_ATM_NOTIF_REC.TRN_REF_NO;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_TY_ATM_NOTIF_REC.TXN_DESC := NULL;
    END;
    BEGIN

      SELECT TRIM(TERM_ADDR), MERCH_ID
        INTO P_TY_ATM_NOTIF_REC.ATM_LOC, P_TY_ATM_NOTIF_REC.MERCH_ID
        FROM SWTM_TERMINAL_DETAILS
       WHERE TERM_ID = P_TY_ATM_NOTIF_REC.TERM_ID;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_TY_ATM_NOTIF_REC.ATM_LOC  := NULL;
        P_TY_ATM_NOTIF_REC.MERCH_ID := '';
    END;
    BEGIN

      SELECT TRIM(ACQ_DESC)
        INTO P_TY_ATM_NOTIF_REC.ACQ_ID
        FROM SWTM_ACQUIRER_DETAILS
       WHERE ACQ_BIN = P_TY_ATM_NOTIF_REC.ACQ_INS_ID;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_TY_ATM_NOTIF_REC.ACQ_ID := NULL;
    END;

    BEGIN
      SELECT FCC_ACC_NO
        INTO P_TY_ATM_NOTIF_REC.DEBIT_ACC
        FROM SWTMS_CARD_DETAILS
       WHERE ATM_CARD_NO = P_TY_ATM_NOTIF_REC.ATM_CARD_NO
         AND ATM_ACC_NO = P_TY_ATM_NOTIF_REC.DEBIT_ACC
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('no mapping is present');
    END;

    IF P_TY_ATM_NOTIF_REC.CREDIT_ACC IS NOT NULL THEN
      BEGIN
        SELECT FCC_ACC_NO
          INTO P_TY_ATM_NOTIF_REC.CREDIT_ACC
          FROM SWTMS_CARD_DETAILS
         WHERE ATM_CARD_NO = P_TY_ATM_NOTIF_REC.ATM_CARD_NO
           AND ATM_ACC_NO = P_TY_ATM_NOTIF_REC.CREDIT_ACC
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('no mapping is present');
      END;
    END IF;

    RETURN TRUE;

  EXCEPTION

    WHEN OTHERS THEN
      P_ERR_CODE  := 'SW-NOT-01';
      P_ERR_PARAM := 'Fn_Build_Atm_Notif_Xml' || P_ERR_CODE;
      DBG('E',
          'Fn_Build_Atm_Notif_Xml : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;

  END FN_GET_ATM_NOTIF_DATA;

  FUNCTION FN_GET_GRESPCODE RETURN VARCHAR2 IS
  BEGIN
    RETURN G_RESP_CODE;
  END;

END GWPKS_CREATESWTRANSACTION;
