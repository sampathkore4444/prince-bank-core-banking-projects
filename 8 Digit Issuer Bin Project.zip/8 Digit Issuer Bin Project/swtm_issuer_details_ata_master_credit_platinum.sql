DELETE FROM swtm_issuer_details_ata A WHERE A.ISS_BIN = '530759';

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('53075982', 'Master Credit Card - Platinum', null, null, null, null, null, null, null, null, 'CREDITCARD');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('53075997', 'Master Credit Card - Platinum', null, null, null, null, null, null, null, null, 'CREDITCARD');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('53075998', 'Master Credit Card - Platinum', null, null, null, null, null, null, null, null, 'CREDITCARD');

COMMIT;
