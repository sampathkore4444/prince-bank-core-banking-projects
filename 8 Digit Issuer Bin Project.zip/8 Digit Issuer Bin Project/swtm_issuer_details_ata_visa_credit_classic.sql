DELETE FROM swtm_issuer_details_ata A WHERE A.ISS_BIN = '462825';

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282503', 'Credit Card Visa Classic', null, null, null, null, null, null, null, null, 'CREDITCARDV');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282522', 'Credit Card Visa Classic', null, null, null, null, null, null, null, null, 'CREDITCARDV');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282586', 'Credit Card Visa Classic', null, null, null, null, null, null, null, null, 'CREDITCARDV');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282591', 'Credit Card Visa Classic', null, null, null, null, null, null, null, null, 'CREDITCARDV');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282592', 'Credit Card Visa Classic', null, null, null, null, null, null, null, null, 'CREDITCARDV');

COMMIT;