DELETE FROM swtm_issuer_details_ata A WHERE A.ISS_BIN = '462827';

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282742', 'Credit Card Visa Platinum', null, null, null, null, null, null, null, null, 'CREDITCARDV');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282793', 'Credit Card Visa Platinum', null, null, null, null, null, null, null, null, 'CREDITCARDV');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46282794', 'Credit Card Visa Platinum', null, null, null, null, null, null, null, null, 'CREDITCARDV');

COMMIT;
