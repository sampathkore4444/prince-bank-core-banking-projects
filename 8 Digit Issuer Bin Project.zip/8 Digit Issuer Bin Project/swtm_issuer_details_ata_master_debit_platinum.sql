DELETE FROM swtm_issuer_details_ata A WHERE A.ISS_BIN = '534443';

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('53444371', 'Master Debit Card - Platinum', null, null, null, null, null, null, null, null, 'PRINCE');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('53444381', 'Master Debit Card - Platinum', null, null, null, null, null, null, null, null, 'PRINCE');

prompt Done.
