DELETE FROM swtm_issuer_details_ata A WHERE A.ISS_BIN = '462885';

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46288502', 'Debit Card Visa Classic', null, null, null, null, null, null, null, null, 'PRINCE');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46288511', 'Debit Card Visa Classic', null, null, null, null, null, null, null, null, 'PRINCE');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46288521', 'Debit Card Visa Classic', null, null, null, null, null, null, null, null, 'PRINCE');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46288523', 'Debit Card Visa Classic', null, null, null, null, null, null, null, null, 'PRINCE');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('46288524', 'Debit Card Visa Classic', null, null, null, null, null, null, null, null, 'PRINCE');

COMMIT;