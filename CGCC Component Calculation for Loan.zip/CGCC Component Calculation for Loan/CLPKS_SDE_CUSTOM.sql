CREATE OR REPLACE PACKAGE BODY clpks_sde_custom IS

  PROCEDURE DBG(X VARCHAR2) IS
    MSG VARCHAR2(32767);
  BEGIN
    MSG := 'clpks_sde_custom===>' || X;
    DEBUG.PR_DEBUG('LD', MSG);
  END DBG;

  --sampath starts

  --sampath ends
  FUNCTION FN_GET_SCHODUE(P_REC_ACC        IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                          P_SDE_ID         IN CLTMS_SDE.SDE_ID%TYPE,
                          P_COMP_NAME      IN OUT CLTM_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE,
                          P_FROM_DT        DATE,
                          P_TO_DT          DATE,
                          P_TB_SDE_VALS    IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_SDE_VALS,
                          P_FN_CALL_ID     IN OUT NUMBER,
                          P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                          P_PROCESS        IN OUT BOOLEAN,
                          P_ERR_CODE       IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                          P_ERR_PARAM      IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
  
    RETURN TRUE;
  END FN_GET_SCHODUE;

  FUNCTION FN_PRE_GET_OVERDUE_DAYS(P_BRANCH_CD STTMS_BRANCH.BRANCH_CODE%TYPE,
                                   
                                   P_ACC_NO         IN OUT NOCOPY CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                                   P_SDE_ID         CLTMS_SDE.SDE_ID%TYPE,
                                   P_DATE           DATE,
                                   P_OVERDUE_DAYS   OUT NUMBER,
                                   P_FN_CALL_ID     IN OUT NUMBER,
                                   P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                   P_ERR_CD         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                   P_ERR_PARAM      IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside clpks_sde_custom.fn_pre_get_overdue_days..');
  
    DBG('Returning success from clpks_sde_custom.fn_pre_get_overdue_days..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in clpks_sde_custom.fn_pre_get_overdue_days..');
      CLPKSS_LOGGER.PR_LOG_EXCEPTION;
      RETURN FALSE;
  END FN_PRE_GET_OVERDUE_DAYS;
  FUNCTION FN_POST_GET_OVERDUE_DAYS(P_BRANCH_CD STTMS_BRANCH.BRANCH_CODE%TYPE,
                                    
                                    P_ACC_NO         IN OUT NOCOPY CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                                    P_SDE_ID         CLTMS_SDE.SDE_ID%TYPE,
                                    P_DATE           DATE,
                                    P_OVERDUE_DAYS   OUT NUMBER,
                                    P_FN_CALL_ID     IN OUT NUMBER,
                                    P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                    P_ERR_CD         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                    P_ERR_PARAM      IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside clpks_sde_custom.fn_get_overdue_days..');
  
    DBG('Returning success from clpks_sde_custom.fn_post_get_overdue_days..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in clpks_sde_custom.fn_post_get_overdue_days..');
      CLPKSS_LOGGER.PR_LOG_EXCEPTION;
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_POST_GET_OVERDUE_DAYS;

  --sampath starts

  FUNCTION FN_GET_CUR_PRIN_OUTSTND_SAM(P_REC_ACC IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                       P_FROM_DT DATE,
                                       P_TO_DT   DATE,
                                       P_ERR_CD  IN OUT ERTBS_MSGS.ERR_CODE%TYPE)
    RETURN BOOLEAN IS
    L_PRIN_OUTSTANDING clvw_get_summ_loan_accs_custom.outstanding_balance%TYPE;
    PKG_TMP_HSH_VAL    PLS_INTEGER;
    L_TB_SDE_VALUES    CLPKSS_ELEMENT_TYPES.TY_TB_SDE_VALS;
    L_SDE_ID           CLTMS_SDE.SDE_ID%TYPE := 'CUR_PRIN_OUTSTND_SAM';
  
  BEGIN
    DBG('START OF FN_GET_CUR_PRIN_OUTSTND_SAM');
    DBG('P_REC_ACC.Account_Det.ACCOUNT_NUMBER=' ||
        P_REC_ACC.Account_Det.ACCOUNT_NUMBER);
    DBG('P_REC_ACC.Account_Det.AMOUNT_FINANCED=' ||
        P_REC_ACC.Account_Det.AMOUNT_FINANCED);
  
    DBG('P_FROM_DT=' || P_FROM_DT);
    DBG('P_TO_DT=' || P_TO_DT);
  
    BEGIN
      /*SELECT OUTSTANDING_BALANCE
       INTO L_PRIN_OUTSTANDING
       FROM CLVW_GET_SUMM_LOAN_ACCS_CUSTOM
      WHERE ACCOUNT_NUMBER = P_REC_ACC.ACCOUNT_DET.ACCOUNT_NUMBER
        AND COMPONENT_NAME = 'PRINCIPAL';*/
    
      L_PRIN_OUTSTANDING := CLPKS_CALC_CUSTOM.L_OUTSTAN_PRIN_SAM;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('SQLERRM in NO_DATA_FOUND ' || SQLERRM);
        DBG('SQLCODE in NO_DATA_FOUND ' || SQLCODE);
        L_PRIN_OUTSTANDING := P_REC_ACC.Account_Det.AMOUNT_FINANCED;
      WHEN OTHERS THEN
        DBG('SQLERRM in OTHERS ' || SQLERRM);
        DBG('SQLCODE in OTHERS ' || SQLCODE);
        L_PRIN_OUTSTANDING := 0;
    END;
  
    DBG('L_PRIN_OUTSTANDING=' || L_PRIN_OUTSTANDING);
  
    IF L_PRIN_OUTSTANDING = 0 THEN
      L_PRIN_OUTSTANDING := P_REC_ACC.Account_Det.AMOUNT_FINANCED;
    
    END IF;
  
    PKG_TMP_HSH_VAL := CLPKS_UTIL.FN_HASH_DATE(P_REC_ACC.ACCOUNT_DET.VALUE_DATE);
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).FROM_DT := P_REC_ACC.ACCOUNT_DET.VALUE_DATE;
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).TO_DT := P_TO_DT;
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).SDE_NUM_VAL := L_PRIN_OUTSTANDING;
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).SDE_CHAR_VAL := NULL;
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).SDE_DATE_VAL := NULL;
    P_REC_ACC.G_TB_SDE(L_SDE_ID).SDE_ID := L_SDE_ID;
    P_REC_ACC.G_TB_SDE(L_SDE_ID).SDE_DTYPE := 'N';
    P_REC_ACC.G_TB_SDE(L_SDE_ID).TBL_VALS := L_TB_SDE_VALUES;
    L_TB_SDE_VALUES.DELETE;
  
    DBG('L_PRIN_OUTSTANDING=' || L_PRIN_OUTSTANDING);
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When Others Bombed in fn_get_CUR_PRIN_OUTSTND');
      DBG('SQLERRM: ' || SQLERRM);
      DBG('SQLCODE: ' || SQLCODE);
    
      RETURN FALSE;
    
  END FN_GET_CUR_PRIN_OUTSTND_SAM;

  FUNCTION FN_GET_CGCC_LIMIT_AMOUNT(P_REC_ACC IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                    P_FROM_DT DATE,
                                    P_TO_DT   DATE,
                                    P_ERR_CD  IN OUT ERTBS_MSGS.ERR_CODE%TYPE)
    RETURN BOOLEAN IS
    L_TB_SDE_VALUES CLPKSS_ELEMENT_TYPES.TY_TB_SDE_VALS;
    L_CGCC_LIMIT    NUMBER := 0;
    L_SDE_ID        CLTMS_SDE.SDE_ID%TYPE := 'CGCC_LIMIT';
    PKG_TMP_HSH_VAL PLS_INTEGER;
  BEGIN
    L_TB_SDE_VALUES.DELETE;
  
    --Get CGCC Limit
    BEGIN
      SELECT FIELD_NUMBER_1
        INTO L_CGCC_LIMIT
        FROM CLVW_ACCOUNT_UDF
       where ACCNO = P_REC_ACC.ACCOUNT_DET.ACCOUNT_NUMBER; --  '9000192148';
    EXCEPTION
      WHEN OTHERS THEN
        L_CGCC_LIMIT := 0;
    END;
  
    --L_CGCC_LIMIT := P_REC_ACC.ACCOUNT_DET.AMOUNT_FINANCED; --CGCC_LIMIT
    
    dbg('L_CGCC_LIMIT='||L_CGCC_LIMIT);
    dbg('FROM_DT=' || P_REC_ACC.ACCOUNT_DET.VALUE_DATE);
    dbg('P_TO_DT=' || P_TO_DT);
  
    PKG_TMP_HSH_VAL := CLPKS_UTIL.FN_HASH_DATE(P_REC_ACC.ACCOUNT_DET.VALUE_DATE);
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).FROM_DT := P_REC_ACC.ACCOUNT_DET.VALUE_DATE;
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).TO_DT := P_TO_DT;
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).SDE_NUM_VAL := L_CGCC_LIMIT;
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).SDE_CHAR_VAL := NULL;
    L_TB_SDE_VALUES(PKG_TMP_HSH_VAL).SDE_DATE_VAL := NULL;
    P_REC_ACC.G_TB_SDE(L_SDE_ID).SDE_ID := L_SDE_ID;
    P_REC_ACC.G_TB_SDE(L_SDE_ID).SDE_DTYPE := 'N';
    P_REC_ACC.G_TB_SDE(L_SDE_ID).TBL_VALS := L_TB_SDE_VALUES;
    L_TB_SDE_VALUES.DELETE;
  
    DBG('L_CGCC_LIMIT=' || L_CGCC_LIMIT);
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CD := 'CL-SDE01;';
      OVPKSS.PR_APPENDTBL(P_ERR_CD, '');
      DBG('WHEN OTHERS BOMBED IN FN_GET_CGCC_LIMIT_AMOUNT');
      DBG('SQLERRM: ' || SQLERRM);
      DBG('SQLCODE: ' || SQLCODE);
      L_TB_SDE_VALUES.DELETE;
      RETURN FALSE;
  END FN_GET_CGCC_LIMIT_AMOUNT;
  --sampath ends

  FUNCTION FN_PRE_GET_SDE_VALS(P_REC_ACC        IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                               P_SDE_ID         CLTMS_SDE.SDE_ID%TYPE,
                               P_COMP_NAME      IN OUT CLTM_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE,
                               P_FROM_DT        DATE,
                               P_TO_DT          DATE,
                               P_TB_SDE_VALS    IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_SDE_VALS,
                               P_DAY_BASIS      CLTMS_PRODUCT_COMPONENTS.DAYS_MTH%TYPE,
                               P_PERIODICITY    CLTMS_PRODUCT_COMPONENTS.PERIODICITY%TYPE,
                               P_ERR_CD         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERR_PARAM      IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                               P_FN_CALL_ID     IN OUT NUMBER,
                               P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function Fn_Pre_Get_Sde_Vals for Custom...');
  
    --sampath starts
    IF P_FN_CALL_ID = 1 AND P_SDE_ID = 'CGCC_LIMIT' THEN
    
      DBG('In Fn_Pre_Get_Sde_Vals , Calling FN_GET_CGCC_LIMIT_AMOUNT...');
      IF NOT
          FN_GET_CGCC_LIMIT_AMOUNT(P_REC_ACC, P_FROM_DT, P_TO_DT, P_ERR_CD) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_FN_CALL_ID = 1 AND P_SDE_ID = 'CUR_PRIN_OUTSTND_SAM' THEN
    
      DBG('In Fn_Pre_Get_Sde_Vals , Calling FN_GET_CUR_PRIN_OUTSTND_SAM...');
      IF NOT FN_GET_CUR_PRIN_OUTSTND_SAM(P_REC_ACC,
                                         P_FROM_DT,
                                         P_TO_DT,
                                         P_ERR_CD) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
    --sampath ends
  
    DBG('Returning success from Fn_Pre_Get_Sde_Vals for Custom...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Clpks_Sde_Custom.Fn_Pre_Get_Sde_Vals ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PRE_GET_SDE_VALS;

  FUNCTION FN_POST_GET_SDE_VALS(P_REC_ACC        IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                P_SDE_ID         CLTMS_SDE.SDE_ID%TYPE,
                                P_COMP_NAME      IN OUT CLTM_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE,
                                P_FROM_DT        DATE,
                                P_TO_DT          DATE,
                                P_TB_SDE_VALS    IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_SDE_VALS,
                                P_DAY_BASIS      CLTMS_PRODUCT_COMPONENTS.DAYS_MTH%TYPE,
                                P_PERIODICITY    CLTMS_PRODUCT_COMPONENTS.PERIODICITY%TYPE,
                                P_ERR_CD         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                P_ERR_PARAM      IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                                P_FN_CALL_ID     IN OUT NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function Fn_Post_Get_Sde_Vals for Custom...');
  
    DBG('Returning success from Fn_Post_Get_Sde_Vals for Custom...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Clpks_Sde_Custom.Fn_Post_Get_Sde_Vals ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_POST_GET_SDE_VALS;

  FUNCTION FN_GET_DYNAMIC_COMP(P_SDE_ID         CLTMS_SDE.SDE_ID%TYPE,
                               P_TB_SDE_VALS    OUT CLPKSS_ELEMENT_TYPES.TY_TB_SDE_VALS,
                               P_ERROR_CODE     IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERROR_PARAM    IN OUT VARCHAR2,
                               P_FN_CALL_ID     IN OUT NUMBER,
                               P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function FN_GET_DYNAMIC_COMP for Custom...');
  
    DBG('Returning success from FN_GET_DYNAMIC_COMP for Custom...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Acpks_Custom.FN_GET_DYNAMIC_COMP ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_GET_DYNAMIC_COMP;

  FUNCTION FN_GET_COMMITMENT_UNUTILIZED(P_REC_ACCOUNT    IN OUT NOCOPY CLPKS_OBJECT.TY_REC_ACCOUNT,
                                        P_FROM_DATE      IN DATE,
                                        P_TO_DATE        IN DATE,
                                        P_TB_SDE_VALS    IN OUT CLPKSS_ELEMENT_TYPES.TY_TB_SDE_VALS,
                                        P_ERR_CODE       IN OUT VARCHAR2,
                                        P_FN_CALL_ID     IN OUT NUMBER,
                                        P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function FN_GET_COMMITMENT_UNUTILIZED for Custom...');
  
    DBG('Returning success from FN_GET_COMMITMENT_UNUTILIZED for Custom...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of clpks_sde_custom.FN_GET_COMMITMENT_UNUTILIZED ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_GET_COMMITMENT_UNUTILIZED;

END CLPKS_SDE_CUSTOM;
/