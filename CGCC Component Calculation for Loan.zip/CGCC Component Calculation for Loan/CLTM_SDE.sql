insert into CLTM_SDE (SDE_ID, SDE_DESC, SDE_DATATYPE, EDITABLE, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, UD_FUNC_NAME, SDE_USAGE, SDE_TYPE)
values ('CUR_PRIN_OUTSTND_SAM', null, 'N', null, 'O', 'A', 'Y', 1, 'SAMPATH2', to_date('22-03-2021 12:48:45', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH1', to_date('22-03-2021 14:44:32', 'dd-mm-yyyy hh24:mi:ss'), null, null, null);

COMMIT;
