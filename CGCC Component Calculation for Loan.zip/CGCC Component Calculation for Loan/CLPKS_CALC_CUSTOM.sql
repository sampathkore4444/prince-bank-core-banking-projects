CREATE OR REPLACE PACKAGE BODY Clpks_Calc_Custom

 IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      DEBUG.PR_DEBUG('CL', 'Clpks_Calc_Custom->' || P_MSG);
    END IF;
  END;

  FUNCTION FN_PRE_COMP_CALC(P_REC_ACC   IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                            P_COMP_NAME CLTMS_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE,
                            P_FROM_DT   DATE,
                            P_TO_DT     DATE,
                            P_ERR_CD    IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                            P_ERR_PARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
  
   RETURN BOOLEAN IS
  BEGIN
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of function Fn_pre_Comp_Calc');
      DBG('Oracle Error code is' || SQLCODE || '--' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_COMP_CALC;

  FUNCTION FN_POST_COMP_CALC(P_REC_ACC   IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                             P_COMP_NAME CLTMS_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE,
                             P_FROM_DT   DATE,
                             P_TO_DT     DATE,
                             P_ERR_CD    IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                             P_ERR_PARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
  
   RETURN BOOLEAN IS
  BEGIN
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of function Fn_post_Comp_Calc');
      DBG('Oracle Error code is' || SQLCODE || '--' || SQLERRM);
      RETURN FALSE;
  END FN_POST_COMP_CALC;

  FUNCTION FN_PRE_INCREASE_PRINCIPAL(P_REC_ACC       IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                     P_PRIN_COMP     IN CLTBS_ACCOUNT_COMPONENTS.COMPONENT_NAME%TYPE,
                                     P_AMOUNT        NUMBER,
                                     P_DATE          DATE,
                                     P_OUTSTAND_FLAG BOOLEAN,
                                     P_ERR_CD        IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                     P_ERR_PARAM     IN OUT ERTBS_MSGS.MESSAGE%TYPE)
  
   RETURN BOOLEAN IS
  BEGIN
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of function Fn_pre_Increase_Principal');
      DBG('Oracle Error code is' || SQLCODE || '--' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_INCREASE_PRINCIPAL;
  FUNCTION FN_POST_INCREASE_PRINCIPAL(P_REC_ACC       IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                      P_PRIN_COMP     IN CLTBS_ACCOUNT_COMPONENTS.COMPONENT_NAME%TYPE,
                                      P_AMOUNT        NUMBER,
                                      P_DATE          DATE,
                                      P_OUTSTAND_FLAG BOOLEAN,
                                      P_ERR_CD        IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                      P_ERR_PARAM     IN OUT ERTBS_MSGS.MESSAGE%TYPE)
  
   RETURN BOOLEAN IS
  BEGIN
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of function Fn_post_Increase_Principal');
      DBG('Oracle Error code is' || SQLCODE || '--' || SQLERRM);
      RETURN FALSE;
  END FN_POST_INCREASE_PRINCIPAL;

  FUNCTION FN_FILL_SIMPLE(P_REC_ACC          IN OUT CLPKSS_OBJECT.TY_REC_ACCOUNT,
                          P_START_DATE_IDX   IN OUT PLS_INTEGER,
                          P_TB_OLD_AMORT_BAL OUT CLPKS_CALC.TY_TB_AMORT_BAL,
                          P_FN_CALL_ID       IN OUT NUMBER,
                          P_TB_CUSTOM_DATA   IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                          P_ERR_CD           IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                          P_ERR_PARAM        IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('start of Fn_Pre_Fill_Simple');
  
    DBG('End of Fn_Pre_Fill_Simple, Return True');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Fn_Pre_Fill_Simple failed in WO :' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CD    := 'CL-DML01;';
      P_ERR_PARAM := 'CLTB_ACC_SCH_EFFRT_EXTGBL' || '~' ||
                     SUBSTR(SQLERRM, 1, 50);
      OVPKSS.PR_APPENDTBL(P_ERR_CD, P_ERR_PARAM);
      RETURN FALSE;
  END FN_FILL_SIMPLE;

  FUNCTION FN_PRE_CALC_PRINCIPAL(P_REC_ACC          IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                 P_FROM_DT          DATE,
                                 P_TO_DT            DATE,
                                 P_TB_COMP          IN OUT NOCOPY CLPKS_CALC.TY_TB_COMP,
                                 P_TB_SEQ_COMP      IN OUT NOCOPY CLPKS_CALC.TY_TB_SEQ_COMP,
                                 P_TB_ALL_DUE_DATES IN OUT NOCOPY CLPKS_CALC.TY_TB_DATES,
                                 P_IS_RECALC        BOOLEAN,
                                 P_EMI_CALC_REQD    BOOLEAN,
                                 P_TB_OLD_AMORT_BAL IN OUT NOCOPY CLPKS_CALC.TY_TB_AMORT_BAL,
                                 P_DIFFAMT          IN CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED%TYPE,
                                 P_TB_COMP_CALC     IN OUT NOCOPY CLPKS_CALC.TY_TB_COMP_CALC,
                                 P_FN_CALL_ID       IN OUT NUMBER,
                                 P_TB_CUSTOM_DATA   IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                 P_ERR_CD           IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                 P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('start of Fn_Pre_Calc_Principal');
  
    DBG('End of Fn_Pre_Calc_Principal, Return True');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Fn_Pre_Calc_Principal failed in WO :' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CD    := 'CL-DML01;';
      P_ERR_PARAM := 'CLTB_ACC_SCH_EFFRT_EXTGBL' || '~' ||
                     SUBSTR(SQLERRM, 1, 50);
      OVPKSS.PR_APPENDTBL(P_ERR_CD, P_ERR_PARAM);
      RETURN FALSE;
  END FN_PRE_CALC_PRINCIPAL;

  FUNCTION FN_POST_CALC_PRINCIPAL(P_REC_ACC          IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                  P_FROM_DT          DATE,
                                  P_TO_DT            DATE,
                                  P_TB_COMP          IN OUT NOCOPY CLPKS_CALC.TY_TB_COMP,
                                  P_TB_SEQ_COMP      IN OUT NOCOPY CLPKS_CALC.TY_TB_SEQ_COMP,
                                  P_TB_ALL_DUE_DATES IN OUT NOCOPY CLPKS_CALC.TY_TB_DATES,
                                  P_IS_RECALC        BOOLEAN,
                                  P_EMI_CALC_REQD    BOOLEAN,
                                  P_TB_OLD_AMORT_BAL IN OUT NOCOPY CLPKS_CALC.TY_TB_AMORT_BAL,
                                  P_DIFFAMT          IN CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED%TYPE,
                                  P_TB_COMP_CALC     IN OUT NOCOPY CLPKS_CALC.TY_TB_COMP_CALC,
                                  P_FN_CALL_ID       IN OUT NUMBER,
                                  P_TB_CUSTOM_DATA   IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                  P_ERR_CD           IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                  P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('start of Fn_Post_Calc_Principal');
  
    DBG('End of Fn_Post_Calc_Principal, Return True');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Fn_Post_Calc_Principal failed in WO :' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CD    := 'CL-DML01;';
      P_ERR_PARAM := 'CLTB_ACC_SCH_EFFRT_EXTGBL' || '~' ||
                     SUBSTR(SQLERRM, 1, 50);
      OVPKSS.PR_APPENDTBL(P_ERR_CD, P_ERR_PARAM);
      RETURN FALSE;
  END FN_POST_CALC_PRINCIPAL;

  FUNCTION FN_INCREASE_COMP_BALANCE(P_REC_ACC        IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                    P_AMOUNT         NUMBER,
                                    P_DATE           DATE,
                                    P_CASCADE_TILL   DATE,
                                    P_COMP_NAME      VARCHAR2,
                                    P_ERR_CD         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                    P_ERR_PARAM      IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                                    P_FN_CALL_ID     IN OUT NUMBER,
                                    P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('In clpks_calc_custom.Fn_Increase_Comp_Balance....');
  
    DBG('P_COMP_NAME=' || P_COMP_NAME);
    DBG('P_DATE=' || P_DATE);
  
    --sampath starts for CGCC Loan Component
    IF P_FN_CALL_ID = 1 AND P_REC_ACC.ACCOUNT_DET.PRODUCT_CODE = 'CGC1' THEN
      L_OUTSTAN_PRIN_SAM := P_TB_CUSTOM_DATA('l_Balance');
      dbg('L_OUTSTAN_PRIN_SAM=' || L_OUTSTAN_PRIN_SAM);
    END IF;
    --sampath ends for CGCC Loan Component
    
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in Fn_Increase_Comp_Balance ' || SQLERRM);
      P_ERR_CD    := 'ST-OTHR-001';
      P_ERR_PARAM := NULL;
      RETURN FALSE;
  END FN_INCREASE_COMP_BALANCE;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_PRE_RECALC_COMPONENTS(P_REC_ACC          IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                    P_FROM_DT          DATE,
                                    P_TO_DT            DATE,
                                    P_DIFF_AMT         NUMBER,
                                    P_EMI_CALC_REQD    BOOLEAN,
                                    P_TB_OLD_AMORT_BAL IN OUT NOCOPY CLPKSS_CALC.TY_TB_AMORT_BAL,
                                    P_ERR_CD           IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                    P_ERR_PARAM        IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In clpks_calc_custom.Fn_Pre_Recalc_Components....');
    DBG('End of Fn_Pre_Recalc_Components, Return True');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in Fn_Pre_Recalc_Components ' || SQLERRM);
      P_ERR_CD    := 'ST-OTHR-001';
      P_ERR_PARAM := NULL;
      RETURN FALSE;
  END FN_PRE_RECALC_COMPONENTS;

  FUNCTION FN_POST_RECALC_COMPONENTS(P_REC_ACC          IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                     P_FROM_DT          DATE,
                                     P_TO_DT            DATE,
                                     P_DIFF_AMT         NUMBER,
                                     P_EMI_CALC_REQD    BOOLEAN,
                                     P_TB_OLD_AMORT_BAL IN OUT NOCOPY CLPKSS_CALC.TY_TB_AMORT_BAL,
                                     P_ERR_CD           IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                     P_ERR_PARAM        IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In clpks_calc_custom.Fn_Post_Recalc_Components....');
    DBG('End of Fn_Post_Recalc_Components, Return True');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in Fn_Post_Recalc_Components ' || SQLERRM);
      P_ERR_CD    := 'ST-OTHR-001';
      P_ERR_PARAM := NULL;
      RETURN FALSE;
  END FN_POST_RECALC_COMPONENTS;

  FUNCTION FN_DUMP_COMP_CALC(P_TB_COMP_CALC   IN OUT NOCOPY CLPKSS_CALC.TY_TB_COMP_CALC,
                             P_REC_ACC        IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                             P_FN_CALL_ID     IN OUT NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                             P_ERR_CD         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                             P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
    DBG('start of Fn_Dump_Comp_Calc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Fn_Store_sch_effrt_extgbl :' || SQLERRM);
      P_ERR_CD    := 'CL-DML01;';
      P_ERR_PARAM := 'CLTB_ACC_SCH_EFFRT_EXTGBL' || '~' ||
                     SUBSTR(SQLERRM, 1, 50);
      OVPKSS.PR_APPENDTBL(P_ERR_CD, P_ERR_PARAM);
      RETURN FALSE;
  END FN_DUMP_COMP_CALC;

  FUNCTION FN_PRE_DUMP_COMP_CALC(P_TB_COMP_CALC IN OUT NOCOPY CLPKS_CALC.TY_TB_COMP_CALC,
                                 P_REC_ACC      IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                 P_ERR_CD       IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                 P_ERR_PARAM    IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In Clpks_Calc_Custom.Fn_Pre_Dump_Comp_Calc..');
  
    DBG('Returning True from In Clpks_Calc_Custom.Fn_Pre_Dump_Comp_Calc...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of Fn_Dump_Comp_Calc: SQLERR: ' || SQLERRM);
  END FN_PRE_DUMP_COMP_CALC;

  FUNCTION FN_PRE_DEFAULT_CALC(P_REC_ACC   IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                               P_FROM_DT   DATE,
                               P_TO_DT     DATE,
                               P_ERR_CD    IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERR_PARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In Clpks_Calc_Custom.Fn_Pre_Default_Calc..');
  
    DBG('Returning True from In Clpks_Calc_Custom.Fn_Pre_Default_Calc...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of Fn_Default_Calc: SQLERR: ' || SQLERRM);
  END FN_PRE_DEFAULT_CALC;

  FUNCTION FN_POST_DEFAULT_CALC(P_REC_ACC   IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                P_FROM_DT   DATE,
                                P_TO_DT     DATE,
                                P_ERR_CD    IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                P_ERR_PARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In Clpks_Calc_Custom.Fn_Post_Default_Calc..');
  
    DBG('Returning True from In Clpks_Calc_Custom.Fn_Post_Default_Calc..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of Fn_Default_Calc: SQLERR: ' || SQLERRM);
  END FN_POST_DEFAULT_CALC;

  FUNCTION FN_DELETE_COMP_CALC(P_TB_COMP_CALC   IN OUT NOCOPY CLPKSS_CALC.TY_TB_COMP_CALC,
                               P_ACC_NO         IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                               P_BRANCH_CODE    IN CLTBS_ACCOUNT_MASTER.BRANCH_CODE%TYPE,
                               P_TB_COMP_NAMES  IN CLPKSS_CALC.TY_TB_COMPONENT_NAME,
                               P_TB_MIN_DATES   IN DBMS_SQL.DATE_TABLE,
                               P_TB_MAX_DATES   IN DBMS_SQL.DATE_TABLE,
                               P_FN_CALL_ID     IN OUT NUMBER,
                               P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                               P_ERR_CD         IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start of Fn_Delete_Comp_Calc');
  
    DBG('End of Fn_Delete_Comp_Calc, Return True');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Fn_Delete_Comp_Calc failed in WO :' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CD    := 'CL-DML01;';
      P_ERR_PARAM := 'CLTB_ACC_SCH_EFFRT_EXTGBL' || '~' ||
                     SUBSTR(SQLERRM, 1, 50);
      OVPKSS.PR_APPENDTBL(P_ERR_CD, P_ERR_PARAM);
      RETURN FALSE;
  END FN_DELETE_COMP_CALC;

  FUNCTION FN_DELETE_COMP_CALC_PENL(P_TB_COMP_CALC     IN OUT NOCOPY CLPKSS_CALC.TY_TB_COMP_CALC,
                                    P_ACC_NO           IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                                    P_BRANCH_CODE      IN CLTBS_ACCOUNT_MASTER.BRANCH_CODE%TYPE,
                                    P_TB_COMP_NAMES    IN CLPKSS_CALC.TY_TB_COMPONENT_NAME,
                                    P_TB_MIN_DATES     IN DBMS_SQL.DATE_TABLE,
                                    P_TB_MIN_SCH_DATES IN DBMS_SQL.DATE_TABLE,
                                    P_TB_MAX_DATES     IN DBMS_SQL.DATE_TABLE,
                                    P_FN_CALL_ID       IN OUT NUMBER,
                                    P_TB_CUSTOM_DATA   IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                    P_ERR_CD           IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                    P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('start of Fn_Delete_Comp_Calc_Penl');
  
    DBG('End of Fn_Delete_Comp_Calc_Penl, Return True');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Fn_Delete_Comp_Calc_Penl failed in WO :' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CD    := 'CL-DML01;';
      P_ERR_PARAM := 'CLTB_ACC_SCH_EFFRT_EXTGBL' || '~' ||
                     SUBSTR(SQLERRM, 1, 50);
      OVPKSS.PR_APPENDTBL(P_ERR_CD, P_ERR_PARAM);
      RETURN FALSE;
  END FN_DELETE_COMP_CALC_PENL;

  FUNCTION FN_PRE_GET_COMP_VALS(P_REC_ACC          IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                P_FROM_DT          DATE,
                                P_TO_DT            IN OUT DATE,
                                P_PROCESS_DT       DATE,
                                P_TB_COMP          IN OUT NOCOPY CLPKSS_CALC.TY_TB_COMP,
                                P_TB_SEQ_COMP      IN OUT NOCOPY CLPKSS_CALC.TY_TB_SEQ_COMP,
                                P_TB_ALL_DUE_DATES IN OUT NOCOPY CLPKSS_CALC.TY_TB_DATES,
                                P_PRIN_COMP        IN CLTBS_ACCOUNT_COMPONENTS.COMPONENT_NAME%TYPE,
                                P_IS_RECALC        IN OUT BOOLEAN,
                                P_EMI_CALC_REQD    IN OUT BOOLEAN,
                                P_TB_OLD_AMORT_BAL IN OUT NOCOPY CLPKSS_CALC.TY_TB_AMORT_BAL,
                                P_TB_EMI_VALS      IN OUT NOCOPY CLPKSS_CALC.TY_TB_EMI_VALS,
                                P_TB_COMP_CALC     IN OUT NOCOPY CLPKSS_CALC.TY_TB_COMP_CALC,
                                P_FN_CALL_ID       IN OUT NUMBER,
                                P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                P_ERR_CD           IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                P_ERR_PARAM        IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In clpks_calc_cluster.Fn_Pre_Get_Comp_Vals....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in Fn_Pre_Get_Comp_Vals ' || SQLERRM);
      P_ERR_CD    := 'ST-OTHR-001';
      P_ERR_PARAM := NULL;
      RETURN FALSE;
  END FN_PRE_GET_COMP_VALS;

  FUNCTION FN_POST_GET_COMP_VALS(P_REC_ACC          IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                 P_FROM_DT          DATE,
                                 P_TO_DT            IN OUT DATE,
                                 P_PROCESS_DT       DATE,
                                 P_TB_COMP          IN OUT NOCOPY CLPKSS_CALC.TY_TB_COMP,
                                 P_TB_SEQ_COMP      IN OUT NOCOPY CLPKSS_CALC.TY_TB_SEQ_COMP,
                                 P_TB_ALL_DUE_DATES IN OUT NOCOPY CLPKSS_CALC.TY_TB_DATES,
                                 P_PRIN_COMP        IN CLTBS_ACCOUNT_COMPONENTS.COMPONENT_NAME%TYPE,
                                 P_IS_RECALC        IN OUT BOOLEAN,
                                 P_EMI_CALC_REQD    IN OUT BOOLEAN,
                                 P_TB_OLD_AMORT_BAL IN OUT NOCOPY CLPKSS_CALC.TY_TB_AMORT_BAL,
                                 P_TB_EMI_VALS      IN OUT NOCOPY CLPKSS_CALC.TY_TB_EMI_VALS,
                                 P_TB_COMP_CALC     IN OUT NOCOPY CLPKSS_CALC.TY_TB_COMP_CALC,
                                 P_FN_CALL_ID       IN OUT NUMBER,
                                 P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                 P_ERR_CD           IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                 P_ERR_PARAM        IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In clpks_calc_cluster.Fn_Post_Get_Comp_Vals....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in Fn_Post_Get_Comp_Vals ' || SQLERRM);
      P_ERR_CD    := 'ST-OTHR-001';
      P_ERR_PARAM := NULL;
      RETURN FALSE;
  END FN_POST_GET_COMP_VALS;

  FUNCTION FN_HANDLE_PRINCIPAL_BULLET(P_REC_ACC         IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                      P_HSH_MATURITY_DT PLS_INTEGER,
                                      P_FN_CALL_ID      IN OUT NUMBER,
                                      P_TB_CUSTOM_DATA  IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                      P_ERR_CD          IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                      P_ERR_PARAM       IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In clpks_calc_custom.Fn_Handle_Principal_Bullet');
  
    DBG('Successfully comes out of clpks_calc_custom');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of Fn_Handle_Principal_Bullet ***' || SQLERRM);
      RETURN FALSE;
  END FN_HANDLE_PRINCIPAL_BULLET;

END CLPKS_CALC_CUSTOM;
/