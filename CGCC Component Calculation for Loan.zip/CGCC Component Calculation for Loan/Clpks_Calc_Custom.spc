CREATE OR REPLACE PACKAGE Clpks_Calc_Custom IS
  /*------------------------------------------------------------------------------------------
  ** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
  ** Copyright © 2005 - 2009  Oracle and/or its affiliates.  All rights reserved.
  **
  ** No part of this work may be reproduced, stored in a retrieval system,
  ** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
  ** translated in any language or computer language,
  ** without the prior written permission of Oracle and/or its affiliates.
  **
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India.
  ------------------------------------------------------------------------------------------
  */
  /*
  **************************************************************************************************
  **  PACKAGE Name      : Clpks_Amort_Custom
  **  File Name         : Clpks_Amort_Custom.SPC
  **  Module            : CONSUMER LENDING
  **  Description       :
  **
  **  Subroutines called  :
  
  **  Written by          : Abhishek Jain
  **  Date of creation    :16-MAY-2013
  **  Description         :Custom changes for Clpks_Calc.
  **
  **   Modified By          : Nameirakpam Ibochouba Singh
  **   Modified On          : 13-Sep-2013
  **   Modified Reason      : Extensible Hook provide for MYRSME_12.0_23_JUL_2013_01_0000 to call clpks_calc_custom.Fn_Increase_Principal.
  **   Search String        : FCUBS12.0.2->17405280 Propagated from ->FCUBS12.0.1->CNSL->SMEMYR;SFR#17240898
  
  **    Modified By            : Dekyi
  **    Modified On            : 03-Oct-2016
  **    Modified Reason        : NED_12.0.1_22_SEP_2015_02 Extensibility Code changes for EHD Prepayment with Change in Installment Amount option,for a Simple Interest Loan and Allow Pre-payment for Linear Loans.
  **    Search String          : Bug#23657112
  
  Modified By        : Saisudha Rathinavelu
  Modified On        : 17-Jan-2017
  Modified Reason    : Retro for hook change bug id 25110963.
  Search String      : 12.3_RETRO_Bug#25401296
  
  **    Modified By           : Dekyi
  **    Modified On           : 26-Apr-2017
  **    Modified Reason       : Hook Request. EHD Ref: ITLCAB_12.3_19_APR_2017_01_0000
  **    Search String         : 12.3_EXTN_25952292
      **
  **    Modified By            : Nidhi Verma
  **    Modified On            : 08-May-2017
  **    Modified Reason        : Extensibility Code changes for EHD CITIBR_12.0.1.7_25_FEB_2014_02_0000. "Effective Rate Computation Changes".
  **    Search String          : Bug#25888927
  
  **    Modified By           : Suresh Babu B
  **    Modified On           : 24-Nov-2017
  **    Modified Reason       : Extensible changes are required to handle the below requirement
                  Bank requires an option to postpone the past installment due to a new date
                  without the need of capitalizing it and resetting the schedule. It also requires an
                    option to decide on the Penalty and Penal interest accrued to be liquidated or will be
                    waived or will be reversed.
  **    Search String         : [FCUBS12.4->RETRO->26234096;Base#22831333]
  
    Modified By     : Akshay Kumar
    Modified On     : 02-Apr-2018
    Modified Reason   : Error 'CL-CMPEMI' needs to be skipped
    Search String     : Bug#27792637
  
    Modified By     : Akshada Muneshwar
    Modified On     : 12-Apr-2018
    Modified Reason   : Pre-Hook provided for function Fn_Dump_Comp_Calc and Pre and Post Hook provided for function Fn_Default_Calc
    Search String     : Bug#27845133
  **************************************************************************************************/

  --SAMPATH STARTS  for CGCC Loan Component
  L_OUTSTAN_PRIN_SAM clvw_get_summ_loan_accs_custom.outstanding_balance%TYPE;
  --SAMPATH ENDS  for CGCC Loan Component

  FUNCTION Fn_pre_Comp_Calc(p_Rec_Acc   IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                            p_Comp_Name Cltms_Product_Components.Component_Name%TYPE,
                            p_From_Dt   DATE,
                            p_To_Dt     DATE,
                            p_Err_Cd    IN OUT Ertbs_Msgs.Err_Code%TYPE,
                            p_Err_Param IN OUT Ertbs_Msgs.Message%TYPE)
  
   RETURN BOOLEAN;

  FUNCTION Fn_post_Comp_Calc(p_Rec_Acc   IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                             p_Comp_Name Cltms_Product_Components.Component_Name%TYPE,
                             p_From_Dt   DATE,
                             p_To_Dt     DATE,
                             p_Err_Cd    IN OUT Ertbs_Msgs.Err_Code%TYPE,
                             p_Err_Param IN OUT Ertbs_Msgs.Message%TYPE)
  
   RETURN BOOLEAN;
  --FCUBS12.0.2->17405280 Propagated from ->FCUBS12.0.1->CNSL->SMEMYR;SFR#17240898 Start
  FUNCTION Fn_pre_Increase_Principal(p_Rec_Acc       IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                     p_Prin_Comp     IN Cltbs_Account_Components.Component_Name%TYPE,
                                     p_Amount        NUMBER,
                                     p_Date          DATE,
                                     p_Outstand_Flag BOOLEAN,
                                     p_Err_Cd        IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                     p_Err_Param     IN OUT Ertbs_Msgs.Message%TYPE)
    RETURN BOOLEAN;
  FUNCTION Fn_post_Increase_Principal(p_Rec_Acc       IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                      p_Prin_Comp     IN Cltbs_Account_Components.Component_Name%TYPE,
                                      p_Amount        NUMBER,
                                      p_Date          DATE,
                                      p_Outstand_Flag BOOLEAN,
                                      p_Err_Cd        IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                      p_Err_Param     IN OUT Ertbs_Msgs.Message%TYPE)
    RETURN BOOLEAN;
  --FCUBS12.0.2->17405280 Propagated from ->FCUBS12.0.1->CNSL->SMEMYR;SFR#17240898 End
  --Bug#23657112 starts
  FUNCTION Fn_Fill_Simple(p_Rec_Acc        IN OUT Clpkss_Object.Ty_Rec_Account,
                          p_Start_Date_Idx IN OUT PLS_INTEGER,
                          
                          p_Tb_Old_Amort_Bal OUT clpks_calc.Ty_Tb_Amort_Bal,
                          p_fn_call_id       IN OUT NUMBER,
                          P_tb_custom_data   IN OUT global.ty_tb_custom_data,
                          p_Err_Cd           IN OUT Ertbs_Msgs.Err_Code%TYPE,
                          p_Err_Param        IN OUT Ertbs_Msgs.Message%TYPE)
    RETURN BOOLEAN;
  FUNCTION Fn_Pre_Calc_Principal(p_Rec_Acc          IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                 p_From_Dt          DATE,
                                 p_To_Dt            DATE,
                                 p_Tb_Comp          IN OUT NOCOPY clpks_calc.Ty_Tb_Comp,
                                 p_Tb_Seq_Comp      IN OUT NOCOPY clpks_calc.Ty_Tb_Seq_Comp,
                                 p_Tb_All_Due_Dates IN OUT NOCOPY clpks_calc.Ty_Tb_Dates,
                                 p_Is_Recalc        BOOLEAN,
                                 p_Emi_Calc_Reqd    BOOLEAN,
                                 p_Tb_Old_Amort_Bal IN OUT NOCOPY clpks_calc.Ty_Tb_Amort_Bal,
                                 p_Diffamt          IN Cltbs_Account_Master.Amount_Financed%TYPE,
                                 p_Tb_Comp_Calc     IN OUT NOCOPY clpks_calc.Ty_Tb_Comp_Calc,
                                 p_Fn_Call_Id       IN OUT NUMBER,
                                 p_Tb_Custom_Data   IN OUT global.ty_tb_custom_data,
                                 p_Err_Cd           IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                 p_Err_Param        IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Calc_Principal(p_Rec_Acc          IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                  p_From_Dt          DATE,
                                  p_To_Dt            DATE,
                                  p_Tb_Comp          IN OUT NOCOPY clpks_calc.Ty_Tb_Comp,
                                  p_Tb_Seq_Comp      IN OUT NOCOPY clpks_calc.Ty_Tb_Seq_Comp,
                                  p_Tb_All_Due_Dates IN OUT NOCOPY clpks_calc.Ty_Tb_Dates,
                                  p_Is_Recalc        BOOLEAN,
                                  p_Emi_Calc_Reqd    BOOLEAN,
                                  p_Tb_Old_Amort_Bal IN OUT NOCOPY clpks_calc.Ty_Tb_Amort_Bal,
                                  p_Diffamt          IN Cltbs_Account_Master.Amount_Financed%TYPE,
                                  p_Tb_Comp_Calc     IN OUT NOCOPY clpks_calc.Ty_Tb_Comp_Calc,
                                  p_Fn_Call_Id       IN OUT NUMBER,
                                  p_Tb_Custom_Data   IN OUT global.ty_tb_custom_data,
                                  p_Err_Cd           IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                  p_Err_Param        IN OUT VARCHAR2)
    RETURN BOOLEAN;
  --Bug#23657112 ends
  --12.3_RETRO_Bug#25401296 Changes starts here
  FUNCTION Fn_Increase_Comp_Balance(p_Rec_Acc        IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                    p_Amount         NUMBER,
                                    p_Date           DATE,
                                    p_Cascade_Till   DATE,
                                    p_Comp_Name      VARCHAR2,
                                    p_Err_Cd         IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                    p_Err_Param      IN OUT Ertbs_Msgs.Message%TYPE,
                                    p_Fn_Call_Id     IN OUT NUMBER,
                                    p_tb_custom_data IN OUT NOCOPY Global.ty_tb_custom_data)
    RETURN BOOLEAN;
  --12.3_RETRO_Bug#25401296 Changes ends here
  --12.3_EXTN_25952292 starts
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2);
  FUNCTION Fn_Pre_Recalc_Components(p_Rec_Acc          IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                    p_From_Dt          DATE,
                                    p_To_Dt            DATE,
                                    p_Diff_Amt         NUMBER,
                                    p_Emi_Calc_Reqd    BOOLEAN,
                                    p_Tb_Old_Amort_Bal IN OUT NOCOPY clpkss_calc.Ty_Tb_Amort_Bal,
                                    p_Err_Cd           IN OUT Ertb_Msgs.Err_Code%TYPE,
                                    p_Err_Param        IN OUT Ertb_Msgs.Message%TYPE)
    RETURN BOOLEAN;
  FUNCTION Fn_Post_Recalc_Components(p_Rec_Acc          IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                     p_From_Dt          DATE,
                                     p_To_Dt            DATE,
                                     p_Diff_Amt         NUMBER,
                                     p_Emi_Calc_Reqd    BOOLEAN,
                                     p_Tb_Old_Amort_Bal IN OUT NOCOPY clpkss_calc.Ty_Tb_Amort_Bal,
                                     p_Err_Cd           IN OUT Ertb_Msgs.Err_Code%TYPE,
                                     p_Err_Param        IN OUT Ertb_Msgs.Message%TYPE)
    RETURN BOOLEAN;
  --12.3_EXTN_25952292 ends

  --Bug#25888927 Start
  FUNCTION Fn_Dump_Comp_Calc(p_Tb_Comp_Calc   IN OUT NOCOPY Clpkss_Calc.Ty_Tb_Comp_Calc,
                             p_Rec_Acc        IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                             p_Fn_Call_Id     IN OUT NUMBER,
                             p_Tb_Custom_Data IN OUT global.ty_tb_custom_data,
                             p_Err_Cd         IN OUT Ertbs_Msgs.Err_Code%TYPE,
                             p_Err_Param      IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION Fn_Delete_Comp_Calc(p_Tb_Comp_Calc   IN OUT NOCOPY clpkss_calc.Ty_Tb_Comp_Calc,
                               p_Acc_No         IN Cltbs_Account_Master.Account_Number%TYPE,
                               p_Branch_Code    IN Cltbs_Account_Master.branch_code%TYPE,
                               p_Tb_Comp_Names  IN clpkss_calc.Ty_Tb_Component_Name,
                               p_Tb_Min_Dates   IN Dbms_Sql.Date_Table,
                               p_Tb_Max_Dates   IN Dbms_Sql.Date_Table,
                               p_Fn_Call_Id     IN OUT NUMBER,
                               p_Tb_Custom_Data IN OUT global.ty_tb_custom_data,
                               p_Err_Cd         IN OUT Ertbs_Msgs.Err_Code%TYPE,
                               p_Err_Param      IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Delete_Comp_Calc_Penl(p_Tb_Comp_Calc     IN OUT NOCOPY clpkss_calc.Ty_Tb_Comp_Calc,
                                    p_Acc_No           IN Cltbs_Account_Master.Account_Number%TYPE,
                                    p_Branch_Code      IN Cltbs_Account_Master.branch_code%TYPE,
                                    p_Tb_Comp_Names    IN clpkss_calc.Ty_Tb_Component_Name,
                                    p_Tb_Min_Dates     IN Dbms_Sql.Date_Table,
                                    p_Tb_Min_Sch_Dates IN Dbms_Sql.Date_Table,
                                    p_Tb_Max_Dates     IN Dbms_Sql.Date_Table,
                                    p_Fn_Call_Id       IN OUT NUMBER,
                                    p_Tb_Custom_Data   IN OUT global.ty_tb_custom_data,
                                    p_Err_Cd           IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                    p_Err_Param        IN OUT VARCHAR2)
    RETURN BOOLEAN;
  --Bug#25888927 End
  --[FCUBS12.4->RETRO->26234096;Base#22831333] Start
  FUNCTION Fn_Pre_Get_Comp_Vals(p_Rec_Acc          IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                p_From_Dt          DATE,
                                p_To_Dt            IN OUT DATE,
                                p_Process_Dt       DATE,
                                p_Tb_Comp          IN OUT NOCOPY clpkss_calc.Ty_Tb_Comp,
                                p_Tb_Seq_Comp      IN OUT NOCOPY clpkss_calc.Ty_Tb_Seq_Comp,
                                p_Tb_All_Due_Dates IN OUT NOCOPY clpkss_calc.Ty_Tb_Dates,
                                p_Prin_Comp        IN Cltbs_Account_Components.Component_Name%TYPE,
                                p_Is_Recalc        IN OUT BOOLEAN,
                                p_Emi_Calc_Reqd    IN OUT BOOLEAN,
                                p_Tb_Old_Amort_Bal IN OUT NOCOPY clpkss_calc.Ty_Tb_Amort_Bal,
                                p_Tb_Emi_Vals      IN OUT NOCOPY clpkss_calc.Ty_Tb_Emi_Vals,
                                p_Tb_Comp_Calc     IN OUT NOCOPY clpkss_calc.Ty_Tb_Comp_Calc,
                                p_fn_call_id       IN OUT NUMBER,
                                p_tb_custom_data   IN OUT NOCOPY global.ty_tb_custom_data,
                                p_Err_Cd           IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                p_Err_Param        IN OUT Ertbs_Msgs.Message%TYPE)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Get_Comp_Vals(p_Rec_Acc          IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                 p_From_Dt          DATE,
                                 p_To_Dt            IN OUT DATE,
                                 p_Process_Dt       DATE,
                                 p_Tb_Comp          IN OUT NOCOPY clpkss_calc.Ty_Tb_Comp,
                                 p_Tb_Seq_Comp      IN OUT NOCOPY clpkss_calc.Ty_Tb_Seq_Comp,
                                 p_Tb_All_Due_Dates IN OUT NOCOPY clpkss_calc.Ty_Tb_Dates,
                                 p_Prin_Comp        IN Cltbs_Account_Components.Component_Name%TYPE,
                                 p_Is_Recalc        IN OUT BOOLEAN,
                                 p_Emi_Calc_Reqd    IN OUT BOOLEAN,
                                 p_Tb_Old_Amort_Bal IN OUT NOCOPY clpkss_calc.Ty_Tb_Amort_Bal,
                                 p_Tb_Emi_Vals      IN OUT NOCOPY clpkss_calc.Ty_Tb_Emi_Vals,
                                 p_Tb_Comp_Calc     IN OUT NOCOPY clpkss_calc.Ty_Tb_Comp_Calc,
                                 p_fn_call_id       IN OUT NUMBER,
                                 p_tb_custom_data   IN OUT NOCOPY global.ty_tb_custom_data,
                                 p_Err_Cd           IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                 p_Err_Param        IN OUT Ertbs_Msgs.Message%TYPE)
    RETURN BOOLEAN;
  --[FCUBS12.4->RETRO->26234096;Base#22831333] End
  --Bug#27792637 Starts
  FUNCTION Fn_Handle_Principal_Bullet(p_Rec_Acc         IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                      p_Hsh_Maturity_Dt PLS_INTEGER,
                                      p_fn_call_id      IN OUT NUMBER,
                                      p_tb_custom_data  IN OUT global.ty_tb_custom_data,
                                      p_Err_Cd          IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                      p_Err_Param       IN OUT Ertbs_Msgs.Message%TYPE)
    RETURN BOOLEAN;
  --Bug#27792637 Ends
  -------------------Bug#27845133 starts-------------------------------------
  FUNCTION Fn_Pre_Dump_Comp_Calc(p_Tb_Comp_Calc IN OUT NOCOPY CLPKS_CALC.Ty_Tb_Comp_Calc,
                                 p_Rec_Acc      IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                 p_Err_Cd       IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                 p_Err_Param    IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION Fn_Pre_Default_Calc(p_Rec_Acc   IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                               p_From_Dt   DATE,
                               p_To_Dt     DATE,
                               p_Err_Cd    IN OUT Ertbs_Msgs.Err_Code%TYPE,
                               p_Err_Param IN OUT Ertbs_Msgs.Message%TYPE)
    RETURN BOOLEAN;

  FUNCTION Fn_Post_Default_Calc(p_Rec_Acc   IN OUT NOCOPY Clpkss_Object.Ty_Rec_Account,
                                p_From_Dt   DATE,
                                p_To_Dt     DATE,
                                p_Err_Cd    IN OUT Ertbs_Msgs.Err_Code%TYPE,
                                p_Err_Param IN OUT Ertbs_Msgs.Message%TYPE)
    RETURN BOOLEAN;
  -------------------Bug#27845133 ends-------------------------------------
END Clpks_Calc_Custom;
