insert into SWTM_NETWORK_DETAILS (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('CCPAYMAS', '114100001', 'Credit Card Payment Network For Master', 'SAMPATH1', to_date('06-01-2020 16:14:12', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH1', to_date('06-01-2020 16:14:12', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

insert into SWTM_NETWORK_DETAILS (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('CCPAYVIS', '114100001', 'Credit Card Payment Network for Visa', 'SAMPATH1', to_date('06-01-2020 16:14:12', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH1', to_date('06-01-2020 16:14:12', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

COMMIT;
