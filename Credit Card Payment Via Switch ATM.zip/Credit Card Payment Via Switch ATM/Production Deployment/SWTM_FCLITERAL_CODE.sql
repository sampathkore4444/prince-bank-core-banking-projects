insert into SWTM_FCLITERAL_CODE (PROC_CODE_TYPE, FC_LITERAL, EXT_TXN_CODE, DESCRIPTION, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CHANNEL, ATM_SUPPORT, POS_SUPPORT, IVR_SUPPORT)
values ('49', 'CCP', '05', 'Credit Card Payment', 'O', 'A', 1, 'SAMPATH1', to_date('06-10-2018 08:59:04', 'dd-mm-yyyy hh24:mi:ss'), 'SMAPATH1', to_date('06-10-2018 09:05:22', 'dd-mm-yyyy hh24:mi:ss'), 'Y', null, null, null, null);

COMMIT;
