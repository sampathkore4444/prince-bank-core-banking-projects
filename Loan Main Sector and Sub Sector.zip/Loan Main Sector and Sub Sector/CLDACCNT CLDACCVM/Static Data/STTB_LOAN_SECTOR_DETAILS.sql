prompt Importing table STTB_LOAN_SECTOR_DETAILS...
set feedback off
set define off
insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('1', 'Agriculture, Forestry and Fishing', '1.1', 'Agriculture', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('1', 'Agriculture, Forestry and Fishing', '1.2', 'Livestock and Poultry', null, 'N/A', 2);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('1', 'Agriculture, Forestry and Fishing', '1.3', 'Forestry', null, 'N/A', 3);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('1', 'Agriculture, Forestry and Fishing', '1.4', 'Fishing', null, 'N/A', 4);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('2', 'Mining and Quarrying', '2.1', 'Mining and Quarrying', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.1', 'Food Products Manufacturing', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.2', 'Beverage and Tobacco Manufacturing', null, 'N/A', 2);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.3', 'Textile, Wearing Apparel and Leather Products Manufacturing', null, 'N/A', 3);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.4', 'Wood Products and Paper Manufacturing', null, 'N/A', 4);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.5', 'Printing', null, 'N/A', 5);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.6', 'Petroleum, Coal, Chemical, Polymer and Rubber Manufacturing', null, 'N/A', 6);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.7', 'Non-Metallic Minerals Manufacturing', null, 'N/A', 7);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.8', 'Metal and Metal Products Manufacturing', null, 'N/A', 8);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.9', 'Transport Equipment Manufacturing', null, 'N/A', 9);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.10', 'Machinery and Equipment Manufacturing', null, 'N/A', 10);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('3', 'Manufacturing', '3.11', 'Furniture and Other Manufacturing', null, 'N/A', 11);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('4', 'Utilities', '4.1', 'Electricity', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('4', 'Utilities', '4.2', 'Gas', null, 'N/A', 2);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('4', 'Utilities', '4.3', 'Water, Sewerage and Drainage', null, 'N/A', 3);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('4', 'Utilities', '4.4', 'Waste Collection, Treatment and Disposal', null, 'N/A', 4);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('5', 'Construction', '5.1', 'Property Development: Industrial', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('5', 'Construction', '5.2', 'Property Development: Commercial', null, 'N/A', 2);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('5', 'Construction', '5.3', 'Property Development: Tourism related', null, 'N/A', 3);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('5', 'Construction', '5.4', 'Property Development: Residential', null, 'N/A', 4);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('5', 'Construction', '5.5', 'Property Development: Others', null, 'N/A', 5);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('5', 'Construction', '5.6', 'Heavy Construction', null, 'N/A', 6);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('5', 'Construction', '5.7', 'Land Management', null, 'N/A', 7);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('5', 'Construction', '5.8', 'Other Construction', null, 'N/A', 8);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('6', 'Wholesale Trade', '6.1', 'Import', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('6', 'Wholesale Trade', '6.2', 'Export', null, 'N/A', 2);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('6', 'Wholesale Trade', '6.3', 'Other', null, 'N/A', 3);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('7', 'Retail Trade', '7.1', 'Retail Trade', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('8', 'Accommodation and Food Service Activities', '8.1', 'Accommodation and Food Service Activities', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('9', 'Arts, Entertainment and Recreation', '9.1', 'Arts, Entertainment and Recreation', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.1', 'National Bank of Cambodia (Central Bank)', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.2', 'Commercial Banks', null, 'N/A', 2);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.4', 'Other Depository Institutions', null, 'N/A', 4);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.3', 'Depository Microfinance Institutions', null, 'N/A', 3);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.5', 'Specialized Banks', null, 'N/A', 5);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.6', 'Licensed Microfinance Institutions', null, 'N/A', 6);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.7', 'Life Insurance', null, 'N/A', 7);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.8', 'General Insurance', null, 'N/A', 8);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.9', 'Pension Funds', null, 'N/A', 9);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.10', 'Stock Exchange and Stockbrokers', null, 'N/A', 10);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('10', 'Financial and Insurance Activities', '10.11', 'Other Financial Institutions, not listed above', null, 'N/A', 11);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('11', 'Transport and Storage', '11.1', 'Transport and Storage', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('12', 'Information and Communications', '12.1', 'Information and Communication', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('13', 'Rental and Operational Leasing Activities, excluded Real Estate Leasing and Rentals', '13.1', 'Rental and Operational Leasing Activities, excluded Real Estate Leasing and Rentals', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('14', 'Real Estate Activities', '14.1', 'Real Estate Operation: Industrial', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('14', 'Real Estate Activities', '14.2', 'Real Estate Operation: Commercial', null, 'N/A', 2);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('14', 'Real Estate Activities', '14.3', 'Real Estate Operation: Tourism Related', null, 'N/A', 3);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('14', 'Real Estate Activities', '14.4', 'Real Estate Operation: Residential', null, 'N/A', 4);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('14', 'Real Estate Activities', '14.5', 'Real Estate Operation: Others', null, 'N/A', 5);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('14', 'Real Estate Activities', '14.6', 'Real Estate Service Providers for a fee (i.e. Real Estate Agents and Similar Activities)', null, 'N/A', 6);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('14', 'Real Estate Activities', '14.7', 'Mortgages, Owner-Occupied Housing only', '14.7.1', 'Of which first-time homebuyer', 7);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('14', 'Real Estate Activities', '14.7', 'Mortgages, Owner-Occupied Housing only', '14.7.2', 'Of which but not first time', 7);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('15', 'Education', '15.1', 'Education', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('16', 'Human health and social work activities', '16.1', 'Human health and social work activities', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('17', 'Activities of households as employers; undifferentiated goods- and services-producing activities of households for own use', '17.1', 'Secured, excluding Mortgages to purchase owner-occupied housing', null, 'N/A', 1);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('17', 'Activities of households as employers; undifferentiated goods- and services-producing activities of households for own use', '17.2', 'Unsecured', null, 'N/A', 2);

insert into STTB_LOAN_SECTOR_DETAILS (MAIN_SECTOR_CODE, MAIN_SECTOR_DESC, SUB_SECTOR_CODE, SUB_SECTOR_DESC, OF_WHICH_SECTOR_CODE, OF_WHICH_SECTOR_DESC, SUB_SECTOR_SEQ)
values ('18', 'Other Lending', '18.1', 'Other Lending', null, 'N/A', 1);

prompt Done.
