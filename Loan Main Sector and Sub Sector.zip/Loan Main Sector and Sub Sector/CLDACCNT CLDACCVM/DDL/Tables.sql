-- Create table
create table STTB_LOAN_SECTOR_DETAILS
(
  main_sector_code     VARCHAR2(35),
  main_sector_desc     VARCHAR2(255),
  sub_sector_code      VARCHAR2(35),
  sub_sector_desc      VARCHAR2(255),
  of_which_sector_code VARCHAR2(35),
  of_which_sector_desc VARCHAR2(255),
  sub_sector_seq       NUMBER
)
/
-- Create table
create table CLTB_LOAN_SECTOR_DTLS_CUSTOM
(
  loan_account_number VARCHAR2(35),
  branch_code         VARCHAR2(3),
  main_sector         VARCHAR2(255),
  sub_sector          VARCHAR2(255),
  of_which_sector     VARCHAR2(255)
)
/
alter table CLTB_LOAN_SECTOR_DTLS_CUSTOM add primary key (LOAN_ACCOUNT_NUMBER, BRANCH_CODE)
/
-- Create table
create table CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
(
  loan_account_number VARCHAR2(35),
  branch_code         VARCHAR2(3),
  main_sector         VARCHAR2(255),
  sub_sector          VARCHAR2(255),
  of_which_sector     VARCHAR2(255),
  unique_seq_no       VARCHAR2(25)
)
/
