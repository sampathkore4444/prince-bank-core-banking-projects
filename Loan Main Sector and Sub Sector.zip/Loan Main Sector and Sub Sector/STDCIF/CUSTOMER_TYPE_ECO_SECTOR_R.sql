insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('R', 'S0050', 'Ministries');
