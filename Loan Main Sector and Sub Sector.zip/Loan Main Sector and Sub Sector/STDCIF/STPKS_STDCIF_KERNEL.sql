CREATE OR REPLACE PACKAGE BODY stpks_stdcif_kernel AS

  G_STDCIF STPKS_STDCIF_MAIN.TY_STDCIF;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'stpks_stdcif_Kernel ==>' || P_MSG;
    DEBUG.PR_DEBUG('ST', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');
  
  END PR_SKIP_HANDLER;

  FUNCTION FN_CHECK_SNCK_REQ(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                             P_PREV_STDCIF      IN STPKS_STDCIF_MAIN.TY_STDCIF,
                             P_WRK_STDCIF       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_RECORD_LOG    STTBS_RECORD_LOG%ROWTYPE;
    L_SNCK_REQUIRED CSTM_SNCK_BRN_PARAM.SANCTIONS_CHECKS_REQUIRED%TYPE;
  BEGIN
    DBG('In Fn_check_Snck_req..');
  
    DBG('Returning true from Fn_check_Snck_req');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of Fn_check_Snck_req with SQLERRM ' || SQLERRM);
      DBG('Trace :' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_CHECK_SNCK_REQ;

  PROCEDURE PR_POPULAT_AUX_UDF(P_STDCIF      IN STPKS_STDCIF_MAIN.TY_STDCIF,
                               P_WRK_STDCIF  IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                               P_ACTION_CODE IN VARCHAR2) IS
  
    CURSOR C_UDF_AUX IS
      SELECT A.FUNCTION_ID,
             A.FIELD_NAME,
             A.SEQ_NO,
             B.VAL_TYPE,
             B.FIELD_TYPE,
             B.MANDATORY,
             B.DEFAULT_VALUE,
             B.AMENDABLE
             
            ,
             B.FIXED_LENGTH,
             B.FIELD_LENGTH,
             B.MIN_LENGTH,
             B.MAX_LENGTH
      
        FROM STTM_BASE_TABLE_UDF_DETAIL A, UDTM_FIELDS B
       WHERE A.FIELD_NAME = B.FIELD_NAME
         AND A.FUNCTION_ID = 'STDCIF';
    L_COUNT NUMBER := 0;
  
    L_STAT     NUMBER := 0;
    L_LEN      NUMBER;
    L_CHAR_STR VARCHAR2(255);
    L_STRING   VARCHAR2(1);
  
  BEGIN
    FOR REC IN C_UDF_AUX LOOP
      DBG('AM HERE');
      IF REC.SEQ_NO = 1 THEN
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD1  := REC.FIELD_NAME;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD20 := REC.VAL_TYPE;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD25 := REC.FIELD_TYPE;
      
        DBG('#28197543 rec.MIN_LENGTH :: ' || REC.MIN_LENGTH);
        DBG('#28197543 rec.MAX_LENGTH :: ' || REC.MAX_LENGTH);
        DBG('#28197543 rec.FIELD_LENGTH :: ' || REC.FIELD_LENGTH);
        DBG('#28197543 rec.FIXED_LENGTH :: ' || REC.FIXED_LENGTH);
        DBG('#28197543 Length(p_stdcif.v_sttms_customer.udf_1):: ' ||
            LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_1));
        DBG('#28197543 Length(p_stdcif.v_sttms_customer.udf_2):: ' ||
            LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_2));
        DBG('#28197543 Length(p_stdcif.v_sttms_customer.udf_3):: ' ||
            LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_3));
        DBG('#28197543 Length(p_stdcif.v_sttms_customer.udf_4):: ' ||
            LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_4));
        DBG('#28197543 Length(p_stdcif.v_sttms_customer.udf_5):: ' ||
            LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_5));
      
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_1 IS NULL THEN
          IF REC.DEFAULT_VALUE IS NOT NULL THEN
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_1 := REC.DEFAULT_VALUE;
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_1 IS NULL THEN
            SELECT MIN(LOV)
              INTO P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_1
              FROM UDTM_LOV
             WHERE FIELD_NAME = REC.FIELD_NAME
               AND IS_DEFAULT_VALUE = 'Y';
          END IF;
        END IF;
      
        DBG('p_stdcif.v_sttms_customer.udf_1 :: ' ||
            P_STDCIF.V_STTMS_CUSTOMER.UDF_1);
        DBG('p_wrk_stdcif.v_sttms_customer.udf_1 :: ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_1);
        DBG('rec.amendable :: ' || REC.AMENDABLE);
        DBG('rec.field_name :: ' || REC.FIELD_NAME);
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
           REC.AMENDABLE = 'N' THEN
          IF NVL(P_STDCIF.V_STTMS_CUSTOMER.UDF_1, '$$$') <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_1, '$$$') THEN
            DBG('Not amendable');
          
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'UD-UDF-201',
                         REC.FIELD_NAME);
          
          END IF;
        
        ELSIF REC.AMENDABLE = 'Y' AND REC.FIXED_LENGTH = 'Y' AND
              (LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_1) <> REC.FIELD_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_1) < REC.MIN_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_1) > REC.MAX_LENGTH) THEN
          DBG('#28197543 failed 1st ');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'UD-UDF-202', REC.FIELD_NAME);
        
        END IF;
      
        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        
          DBG('#28333249 rec.field_type   :' || REC.FIELD_TYPE);
          IF REC.FIELD_TYPE = 'N' THEN
            SELECT '0123456789' INTO L_CHAR_STR FROM DUAL;
            DBG('#28333249 The valid characters string is :' || L_CHAR_STR);
          
            L_LEN := NVL(LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_1), 0);
            DBG('#28333249 l_Len  :' || L_LEN);
          
            FOR I IN 1 .. L_LEN LOOP
              L_STRING := SUBSTR(P_STDCIF.V_STTMS_CUSTOMER.UDF_1, I, 1);
            
              DBG('#28333249 The l_string is :' || L_STRING);
            
              IF (INSTR(L_CHAR_STR, L_STRING, 1) = 0) THEN
                PR_LOG_ERROR('STDCIF',
                             'FLEXCUBE',
                             'UD-UDF-203',
                             REC.FIELD_NAME);
                DBG('character is ' || L_STRING);
              END IF;
            END LOOP;
          END IF;
        
          IF REC.MANDATORY = 'Y' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_1 IS NULL THEN
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'ST-MAND-004',
                         REC.FIELD_NAME);
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_1 IS NOT NULL THEN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM UDTM_LOV
             WHERE LOV = P_STDCIF.V_STTMS_CUSTOMER.UDF_1
               AND FIELD_NAME = REC.FIELD_NAME;
          
            IF L_COUNT = 0 THEN
              PR_LOG_ERROR('STDCIF',
                           'FLEXCUBE',
                           'FX-NEWUP024',
                           REC.FIELD_NAME);
            END IF;
          END IF;
        END IF;
        DBG('UDF new:' || REC.SEQ_NO || '~' || REC.FIELD_NAME || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD40 || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45);
      ELSIF REC.SEQ_NO = 2 THEN
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD2  := REC.FIELD_NAME;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD21 := REC.VAL_TYPE;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD26 := REC.FIELD_TYPE;
      
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_2 IS NULL THEN
          IF REC.DEFAULT_VALUE IS NOT NULL THEN
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_2 := REC.DEFAULT_VALUE;
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_2 IS NULL THEN
            SELECT MIN(LOV)
              INTO P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_2
              FROM UDTM_LOV
             WHERE FIELD_NAME = REC.FIELD_NAME
               AND IS_DEFAULT_VALUE = 'Y';
          END IF;
        END IF;
      
        DBG('p_stdcif.v_sttms_customer.udf_2 :: ' ||
            P_STDCIF.V_STTMS_CUSTOMER.UDF_2);
        DBG('p_wrk_stdcif.v_sttms_customer.udf_2 :: ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_2);
        DBG('rec.amendable :: ' || REC.AMENDABLE);
        DBG('rec.field_name :: ' || REC.FIELD_NAME);
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
           REC.AMENDABLE = 'N' THEN
          IF NVL(P_STDCIF.V_STTMS_CUSTOMER.UDF_2, '$$$') <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_2, '$$$') THEN
            DBG('Not amendable');
          
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'UD-UDF-201',
                         REC.FIELD_NAME);
          
          END IF;
        
        ELSIF REC.AMENDABLE = 'Y' AND REC.FIXED_LENGTH = 'Y' AND
              (LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_2) <> REC.FIELD_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_2) < REC.MIN_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_2) > REC.MAX_LENGTH) THEN
          DBG('#28197543 failed 2nd ');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'UD-UDF-202', REC.FIELD_NAME);
        
        END IF;
      
        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        
          DBG('#28333249 2nd rec.field_type   :' || REC.FIELD_TYPE);
          IF REC.FIELD_TYPE = 'N' THEN
            SELECT '0123456789' INTO L_CHAR_STR FROM DUAL;
            DBG('#28333249 The valid characters string is :' || L_CHAR_STR);
          
            L_LEN := NVL(LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_2), 0);
            DBG('#28333249 l_Len  :' || L_LEN);
          
            FOR I IN 1 .. L_LEN LOOP
              L_STRING := SUBSTR(P_STDCIF.V_STTMS_CUSTOMER.UDF_2, I, 1);
            
              DBG('#28333249 The l_string is :' || L_STRING);
            
              IF (INSTR(L_CHAR_STR, L_STRING, 1) = 0) THEN
                PR_LOG_ERROR('STDCIF',
                             'FLEXCUBE',
                             'UD-UDF-203',
                             REC.FIELD_NAME);
                DBG('character is ' || L_STRING);
              END IF;
            END LOOP;
          END IF;
        
          IF REC.MANDATORY = 'Y' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_2 IS NULL THEN
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'ST-MAND-004',
                         REC.FIELD_NAME);
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_2 IS NOT NULL THEN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM UDTM_LOV
             WHERE LOV = P_STDCIF.V_STTMS_CUSTOMER.UDF_2
               AND FIELD_NAME = REC.FIELD_NAME;
          
            IF L_COUNT = 0 THEN
              PR_LOG_ERROR('STDCIF',
                           'FLEXCUBE',
                           'FX-NEWUP024',
                           REC.FIELD_NAME);
            END IF;
          END IF;
        END IF;
        DBG('UDF new:' || REC.SEQ_NO || '~' || REC.FIELD_NAME || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD41 || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD46);
      ELSIF REC.SEQ_NO = 3 THEN
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD3  := REC.FIELD_NAME;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD22 := REC.VAL_TYPE;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD27 := REC.FIELD_TYPE;
      
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_3 IS NULL THEN
          IF REC.DEFAULT_VALUE IS NOT NULL THEN
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_3 := REC.DEFAULT_VALUE;
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_3 IS NULL THEN
            SELECT MIN(LOV)
              INTO P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_3
              FROM UDTM_LOV
             WHERE FIELD_NAME = REC.FIELD_NAME
               AND IS_DEFAULT_VALUE = 'Y';
          END IF;
        END IF;
      
        DBG('p_stdcif.v_sttms_customer.udf_3 :: ' ||
            P_STDCIF.V_STTMS_CUSTOMER.UDF_3);
        DBG('p_wrk_stdcif.v_sttms_customer.udf_3 :: ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_3);
        DBG('rec.amendable :: ' || REC.AMENDABLE);
        DBG('rec.field_name :: ' || REC.FIELD_NAME);
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
           REC.AMENDABLE = 'N' THEN
          IF NVL(P_STDCIF.V_STTMS_CUSTOMER.UDF_3, '$$$') <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_3, '$$$') THEN
            DBG('Not amendable');
          
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'UD-UDF-201',
                         REC.FIELD_NAME);
          
          END IF;
        
        ELSIF REC.AMENDABLE = 'Y' AND REC.FIXED_LENGTH = 'Y' AND
              (LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_3) <> REC.FIELD_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_3) < REC.MIN_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_3) > REC.MAX_LENGTH) THEN
          DBG('#28197543 failed 2nd ');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'UD-UDF-202', REC.FIELD_NAME);
        
        END IF;
      
        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        
          DBG('#28333249 3rd rec.field_type   :' || REC.FIELD_TYPE);
          IF REC.FIELD_TYPE = 'N' THEN
            SELECT '0123456789' INTO L_CHAR_STR FROM DUAL;
            DBG('#28333249 The valid characters string is :' || L_CHAR_STR);
          
            L_LEN := NVL(LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_3), 0);
            DBG('#28333249 l_Len  :' || L_LEN);
          
            FOR I IN 1 .. L_LEN LOOP
              L_STRING := SUBSTR(P_STDCIF.V_STTMS_CUSTOMER.UDF_3, I, 1);
            
              DBG('#28333249 The l_string is :' || L_STRING);
            
              IF (INSTR(L_CHAR_STR, L_STRING, 1) = 0) THEN
                PR_LOG_ERROR('STDCIF',
                             'FLEXCUBE',
                             'UD-UDF-203',
                             REC.FIELD_NAME);
                DBG('character is ' || L_STRING);
              END IF;
            END LOOP;
          END IF;
        
          IF REC.MANDATORY = 'Y' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_3 IS NULL THEN
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'ST-MAND-004',
                         REC.FIELD_NAME);
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_3 IS NOT NULL THEN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM UDTM_LOV
             WHERE LOV = P_STDCIF.V_STTMS_CUSTOMER.UDF_3
               AND FIELD_NAME = REC.FIELD_NAME;
          
            IF L_COUNT = 0 THEN
              PR_LOG_ERROR('STDCIF',
                           'FLEXCUBE',
                           'FX-NEWUP024',
                           REC.FIELD_NAME);
            END IF;
          END IF;
        END IF;
        DBG('UDF new:' || REC.SEQ_NO || '~' || REC.FIELD_NAME || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD42 || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD47);
      ELSIF REC.SEQ_NO = 4 THEN
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD4  := REC.FIELD_NAME;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD23 := REC.VAL_TYPE;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD28 := REC.FIELD_TYPE;
      
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_4 IS NULL THEN
          IF REC.DEFAULT_VALUE IS NOT NULL THEN
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_4 := REC.DEFAULT_VALUE;
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_4 IS NULL THEN
            SELECT MIN(LOV)
              INTO P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_4
              FROM UDTM_LOV
             WHERE FIELD_NAME = REC.FIELD_NAME
               AND IS_DEFAULT_VALUE = 'Y';
          END IF;
        END IF;
      
        DBG('p_stdcif.v_sttms_customer.udf_4 :: ' ||
            P_STDCIF.V_STTMS_CUSTOMER.UDF_4);
        DBG('p_wrk_stdcif.v_sttms_customer.udf_4 :: ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_4);
        DBG('rec.amendable :: ' || REC.AMENDABLE);
        DBG('rec.field_name :: ' || REC.FIELD_NAME);
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
           REC.AMENDABLE = 'N' THEN
          IF NVL(P_STDCIF.V_STTMS_CUSTOMER.UDF_4, '$$$') <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_4, '$$$') THEN
            DBG('Not amendable');
          
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'UD-UDF-201',
                         REC.FIELD_NAME);
          
          END IF;
        
        ELSIF REC.AMENDABLE = 'Y' AND REC.FIXED_LENGTH = 'Y' AND
              (LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_4) <> REC.FIELD_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_4) < REC.MIN_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_4) > REC.MAX_LENGTH) THEN
          DBG('#28197543 failed 2nd ');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'UD-UDF-202', REC.FIELD_NAME);
        
        END IF;
      
        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        
          DBG('#28333249 4th rec.field_type   :' || REC.FIELD_TYPE);
          IF REC.FIELD_TYPE = 'N' THEN
            SELECT '0123456789' INTO L_CHAR_STR FROM DUAL;
            DBG('#28333249 The valid characters string is :' || L_CHAR_STR);
          
            L_LEN := NVL(LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_4), 0);
            DBG('#28333249 l_Len  :' || L_LEN);
          
            FOR I IN 1 .. L_LEN LOOP
              L_STRING := SUBSTR(P_STDCIF.V_STTMS_CUSTOMER.UDF_4, I, 1);
            
              DBG('#28333249 The l_string is :' || L_STRING);
            
              IF (INSTR(L_CHAR_STR, L_STRING, 1) = 0) THEN
                PR_LOG_ERROR('STDCIF',
                             'FLEXCUBE',
                             'UD-UDF-203',
                             REC.FIELD_NAME);
                DBG('character is ' || L_STRING);
              END IF;
            END LOOP;
          END IF;
        
          IF REC.MANDATORY = 'Y' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_4 IS NULL THEN
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'ST-MAND-004',
                         REC.FIELD_NAME);
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_4 IS NOT NULL THEN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM UDTM_LOV
             WHERE LOV = P_STDCIF.V_STTMS_CUSTOMER.UDF_4
               AND FIELD_NAME = REC.FIELD_NAME;
          
            IF L_COUNT = 0 THEN
              PR_LOG_ERROR('STDCIF',
                           'FLEXCUBE',
                           'FX-NEWUP024',
                           REC.FIELD_NAME);
            END IF;
          END IF;
        END IF;
        DBG('UDF new:' || REC.SEQ_NO || '~' || REC.FIELD_NAME || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD43 || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD48);
      ELSIF REC.SEQ_NO = 5 THEN
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD5  := REC.FIELD_NAME;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD24 := REC.VAL_TYPE;
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD29 := REC.FIELD_TYPE;
      
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_5 IS NULL THEN
          IF REC.DEFAULT_VALUE IS NOT NULL THEN
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_5 := REC.DEFAULT_VALUE;
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_5 IS NULL THEN
            SELECT MIN(LOV)
              INTO P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_5
              FROM UDTM_LOV
             WHERE FIELD_NAME = REC.FIELD_NAME
               AND IS_DEFAULT_VALUE = 'Y';
          END IF;
        END IF;
      
        DBG('p_stdcif.v_sttms_customer.udf_5 :: ' ||
            P_STDCIF.V_STTMS_CUSTOMER.UDF_5);
        DBG('p_wrk_stdcif.v_sttms_customer.udf_5 :: ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_5);
        DBG('rec.amendable :: ' || REC.AMENDABLE);
        DBG('rec.field_name :: ' || REC.FIELD_NAME);
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
           REC.AMENDABLE = 'N' THEN
          IF NVL(P_STDCIF.V_STTMS_CUSTOMER.UDF_5, '$$$') <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.UDF_5, '$$$') THEN
            DBG('Not amendable');
          
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'UD-UDF-201',
                         REC.FIELD_NAME);
          
          END IF;
        
        ELSIF REC.AMENDABLE = 'Y' AND REC.FIXED_LENGTH = 'Y' AND
              (LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_5) <> REC.FIELD_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_5) < REC.MIN_LENGTH OR
              LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_5) > REC.MAX_LENGTH) THEN
          DBG('#28197543 failed 2nd ');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'UD-UDF-202', REC.FIELD_NAME);
        
        END IF;
      
        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        
          DBG('#28333249 5th rec.field_type   :' || REC.FIELD_TYPE);
          IF REC.FIELD_TYPE = 'N' THEN
            SELECT '0123456789' INTO L_CHAR_STR FROM DUAL;
            DBG('#28333249 The valid characters string is :' || L_CHAR_STR);
          
            L_LEN := NVL(LENGTH(P_STDCIF.V_STTMS_CUSTOMER.UDF_5), 0);
            DBG('#28333249 l_Len  :' || L_LEN);
          
            FOR I IN 1 .. L_LEN LOOP
              L_STRING := SUBSTR(P_STDCIF.V_STTMS_CUSTOMER.UDF_5, I, 1);
            
              DBG('#28333249 The l_string is :' || L_STRING);
            
              IF (INSTR(L_CHAR_STR, L_STRING, 1) = 0) THEN
                PR_LOG_ERROR('STDCIF',
                             'FLEXCUBE',
                             'UD-UDF-203',
                             REC.FIELD_NAME);
                DBG('character is ' || L_STRING);
              END IF;
            END LOOP;
          END IF;
        
          IF REC.MANDATORY = 'Y' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_5 IS NULL THEN
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'ST-MAND-004',
                         REC.FIELD_NAME);
          END IF;
          IF REC.VAL_TYPE = 'V' AND
             P_STDCIF.V_STTMS_CUSTOMER.UDF_5 IS NOT NULL THEN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM UDTM_LOV
             WHERE LOV = P_STDCIF.V_STTMS_CUSTOMER.UDF_5
               AND FIELD_NAME = REC.FIELD_NAME;
            IF L_COUNT = 0 THEN
              PR_LOG_ERROR('STDCIF',
                           'FLEXCUBE',
                           'FX-NEWUP024',
                           REC.FIELD_NAME);
            END IF;
          END IF;
        END IF;
        DBG('UDF new:' || REC.SEQ_NO || '~' || REC.FIELD_NAME || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD44 || '~' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD49);
      END IF;
    END LOOP;
    DBG('end of procedure pr_populat_aux_udf');
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('No data found for assigning values to the embeded fields');
    
  END PR_POPULAT_AUX_UDF;

  FUNCTION FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                        P_STDCIF           IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In Fn_Post_Build_type_structure..');
    DBG('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of stpks_stdcif_Kernel.Fn_Post_Build_type_structure ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_BUILD_TYPE_STRUCTURE;

  FUNCTION FN_PRE_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CHILD_FUNCTION   IN VARCHAR2,
                                  P_STDCIF           IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    P_CUST_REC         STPKS_STDCIF_MAIN.TY_STDCIF;
    P_CUST_NO          STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    P_BRANCH           STTMS_BRANCH.BRANCH_CODE%TYPE;
    P_KEY              VARCHAR2(32767);
    P_PARENT           VARCHAR2(32767);
    P_FORMAT           VARCHAR2(32767);
    L_TMP_FMT          VARCHAR2(32767);
    L_CNT_LVL          VARCHAR2(32767);
    I                  NUMBER;
    L_CHECKER_ID       VARCHAR2(32767);
    L_CHECKER_DT_STAMP VARCHAR2(32767);
    L_AUTH_STAT        VARCHAR2(32767);
    CNT                NUMBER;
    L_CNT              NUMBER;
    LONCE_AUTH         VARCHAR2(32767);
    L_AUTO_AUTH_MENU   VARCHAR2(32767);
    L_AUTO_AUTH_USER   VARCHAR2(32767);
    L_COUNT_REC        NUMBER;
    L_AUTO_GEN_CIF     STTMS_BANK.AUTO_GEN_CIF%TYPE;
    B                  BOOLEAN;
    L_PARAM_VAL        VARCHAR2(32767);
    PSERIAL            VARCHAR2(20);
    L_PREF             MSTBS_DLY_MSG_OUT.REFERENCE_NO%TYPE;
    L_TPINREF          MSTBS_DLY_MSG_OUT.REFERENCE_NO%TYPE;
    L_FUNCTION_ID      VARCHAR2(8);
    L_FLD              VARCHAR2(32767);
    L_SPCL_CUST        STTMS_CUSTOMER.SPECIAL_CUST%TYPE;
  
    L_MITMS_DEFAULT_CODES    MIPKS_MICCUSTM_MAIN.TY_TB_V_MITMS_DEFAULT_CODES;
    L_MITMS_DEFAULT_CODES__C MIPKS_MICCUSTM_MAIN.TY_TB_V_MITM_DEFAULT_CODES__C;
    L_M_CODE                 NUMBER := 0;
    L_MIS_COMP               NUMBER := 0;
    L_CORP                   VARCHAR2(1);
    L_BANK                   VARCHAR2(1);
    L_INDV                   VARCHAR2(1);
    CURSOR C_CUST_MIS IS
      SELECT *
        FROM GLTMS_MIS_CLASS
       WHERE MIS_TYPE = 'C'
         AND ONCE_AUTH = 'Y'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
       ORDER BY CLASS_NUM;
  
    CURSOR C_COMP_MIS IS
      SELECT *
        FROM GLTMS_MIS_CLASS
       WHERE MIS_TYPE = 'O'
         AND ONCE_AUTH = 'Y'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
       ORDER BY CLASS_NUM;
  
    L_COUNT  NUMBER;
    IDX      VARCHAR2(255);
    L_COUNT1 NUMBER := 0;
  BEGIN
    DBG('In Fn_Pre_Check_Mandatory');
  
    DBG('pre1 p_STDCIF.v_sttms_cust_doc_checklist Count check-->' ||
        P_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.COUNT);
    DBG('Action Code-->' || P_ACTION_CODE);
    IF P_ACTION_CODE = 'COPY' THEN
      P_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.DELETE;
    END IF;
  
    IF P_ACTION_CODE = 'CUSSNCKSTATUS' THEN
      DBG('This Action code is to display sanction check.. So returning true..');
      RETURN TRUE;
    END IF;
  
    P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO := TRIM(P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
  
    IF P_SOURCE <> 'FLEXCUBE' AND
       P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY, 'MODIFY') AND
       P_STDCIF.V_STTMS_CUST_PERSONAL.CUSTOMER_NO IS NULL THEN
      DBG('coming here for action' || P_ACTION_CODE);
      DBG('before the value of p_stdcif.v_sttms_cust_personal.CUSTOMER_NO is ' ||
          P_STDCIF.V_STTMS_CUST_PERSONAL.CUSTOMER_NO);
      P_STDCIF.V_STTMS_CUST_PERSONAL.CUSTOMER_NO := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('now the value of p_stdcif.v_sttms_cust_personal.CUSTOMER_NO is ' ||
          P_STDCIF.V_STTMS_CUST_PERSONAL.CUSTOMER_NO);
    END IF;
  
    P_STDCIF.V_STTMS_CUSTOMER.SHORT_NAME      := TRIM(P_STDCIF.V_STTMS_CUSTOMER.SHORT_NAME);
    P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1   := TRIM(P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
    P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE := TRIM(P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE);
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY, CSPKS_REQ_GLOBAL.P_NEW) AND
       P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1 IS NULL AND
       P_FUNCTION_ID = ' STDCIF' THEN
      P_ERR_CODE   := 'IF-UPL-29';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
  
    P_STDCIF.V_STTMS_CUST_PERSONAL.FIRST_NAME := TRIM(P_STDCIF.V_STTMS_CUST_PERSONAL.FIRST_NAME);
    P_STDCIF.V_STTMS_CUST_PERSONAL.LAST_NAME  := TRIM(P_STDCIF.V_STTMS_CUST_PERSONAL.LAST_NAME);
  
    P_CUST_REC := P_STDCIF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY AND P_SOURCE = 'FLEXCUBE' THEN
    
      BEGIN
        SELECT FUNCTION_ID
          INTO L_FUNCTION_ID
          FROM STTB_RECORD_MASTER
         WHERE KEY_ID =
               '~STTM_CUSTOMER~' || P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO || '~'
           AND AUTH_STAT = 'U'
           AND LATEST_AUTH_MOD_NO < 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_FUNCTION_ID := NULL;
        WHEN OTHERS THEN
          RETURN NULL;
      END;
      DBG('p_function_id ==> ' || P_FUNCTION_ID);
      DBG('l_function_id ==> ' || L_FUNCTION_ID);
      IF P_FUNCTION_ID <> L_FUNCTION_ID THEN
        DBG('Record Does not Exist..');
        P_ERR_CODE   := 'ST-VALS-002';
        P_ERR_PARAMS := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        RETURN FALSE;
      END IF;
    
    ELSE
      DBG('Local_Branch~Global.CurrentBranch~HeaderBranch~ :' ||
          P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH || '~' ||
          GLOBAL.CURRENT_BRANCH || '~' ||
          CSPKS_REQ_GLOBAL.G_HEADER('BRANCH'));
      IF NOT CSPKS_REQ_UTILS.FN_CHECK_BRANCH_RIGHTS(P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH,
                                                    GLOBAL.USER_ID,
                                                    P_FUNCTION_ID,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DBG('fAiled for multibrn');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = 'COPY' THEN
      P_STDCIF.TY_STCCUACC                          := NULL;
      P_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT := NULL;
      P_STDCIF.V_STTMS_CUSTOMER.AUTO_CUST_AC_NO     := NULL;
    END IF;
  
    IF P_ACTION_CODE = 'MODIFY' THEN
      G_CUST_MODIFY                         := 'Y';
      P_STDCIF.V_STTMS_CUSTOMER.SHORT_NAME2 := P_STDCIF.V_STTMS_CUSTOMER.SHORT_NAME ||
                                               P_STDCIF.V_STTMS_CUSTOMER.LOC_CODE;
    END IF;
  
    BEGIN
      SELECT AUTO_GEN_CIF
        INTO L_AUTO_GEN_CIF
        FROM STTMS_BANK
       WHERE AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_CODE   := 'CS-10000';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
    END;
  
    IF P_ACTION_CODE IN ('DEFAULT', 'COPY') THEN
    
      DBG('Assignment of Branch');
      P_STDCIF. V_STTMS_CUSTOMER.LOCAL_BRANCH := GLOBAL.CURRENT_BRANCH;
    END IF;
    IF P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = 'NEW' THEN
    
      IF P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH IS NULL THEN
        P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH := GLOBAL.CURRENT_BRANCH;
      END IF;
    
      IF NOT STPKS_STDCIF_UTILS_0.FN_GATEWAY_VALIDATE(P_FUNCTION_ID,
                                                      P_STDCIF,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
        DBG('failed inside gateway validation');
      END IF;
      DBG('success inside gateway validation');
    END IF;
    IF P_ACTION_CODE IN ('DEFAULT', 'COPY') OR
       (P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = 'NEW') THEN
      DBG('Inside Default');
    
      L_SPCL_CUST := NVL(P_STDCIF. V_STTMS_CUSTOMER.SPECIAL_CUST, 'N');
      DBG('l_spcl_cust > ' || L_SPCL_CUST);
      IF L_SPCL_CUST = 'Y' THEN
        DBG('Case For Special,l_auto_gen_cif > ' || L_AUTO_GEN_CIF ||
            ' p_action_code > ' || P_ACTION_CODE);
        IF L_AUTO_GEN_CIF = 'Y' AND P_ACTION_CODE IN ('COPY') THEN
          DBG('Case For Special Copy,SKIP Validate Now and Do it during Default/Save');
          L_AUTO_GEN_CIF := 'N';
        ELSE
        
          IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO IS NULL AND
             P_ACTION_CODE NOT IN ('COPY') THEN
            DBG('Mandatory customer number cannot be null');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-MAIL03', NULL);
            RETURN FALSE;
          ELSIF P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO IS NOT NULL THEN
            DBG('Case for Special and not COPY Operation, Do Special Validation.');
            DBG('customer_no > ' || P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
          
            IF NOT STPKS_STDCIF_UTILS_0.FN_CHK_VIP_CUST(P_FUNCTION_ID,
                                                        P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                        L_SPCL_CUST,
                                                        P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
              DBG('Append Error: ST-CIF-40 - Failed in validating VIP customer, may be not in VIP range or Already Used VIP number');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-CIF-40',
                           P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO);
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      ELSE
        DBG('Case for Non Special');
        DBG('l_auto_gen_cif > ' || L_AUTO_GEN_CIF);
      
        IF NVL(L_AUTO_GEN_CIF, 'N') = 'Y' THEN
        
          DBG('Case for AUTO GEN');
          IF NOT STPKS_STDCIF_UTILS_0.FN_GENERATECIF(P_FUNCTION_ID,
                                                     P_CUST_NO,
                                                     P_STDCIF.
                                                     V_STTMS_CUSTOMER.LOCAL_BRANCH,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
            DBG('Failed in fn_Generate');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-CIF-40',
                         P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO);
            RETURN FALSE;
          END IF;
        
          IF NOT STPKS_ACCGEN.FN_UPDATE_UNUSEDCUSTNO(P_SOURCE,
                                                     P_CUST_NO,
                                                     P_ACTION_CODE,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
            DBG('ERROR~' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || SQLERRM);
            RETURN FALSE;
          END IF;
        
        ELSE
          IF P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO IS NULL AND
             P_ACTION_CODE NOT IN ('COPY') THEN
            DBG('Mandatory customer number cannot be null');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-MAIL03', NULL);
            RETURN FALSE;
          END IF;
        
          DBG('Customer number > ' || P_STDCIF.
              V_STTMS_CUSTOMER.CUSTOMER_NO || ' p_cust_no > ' || P_CUST_NO ||
              ' Local_branch > ' || P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH);
          DBG('Not a Special Customer Copy Need to Validate that the User Input Non Special Cusomter is not in Special Range');
          IF P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO IS NOT NULL THEN
            IF NOT STPKS_STDCIF_UTILS_0.FN_CHK_VIP_CUST(P_FUNCTION_ID,
                                                        P_STDCIF.
                                                        V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                        L_SPCL_CUST,
                                                        P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
              DBG('Append Error: ST-CIF-40 - Failed in validating VIP customer');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-CIF-40',
                           P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO);
              RETURN FALSE;
            END IF;
          END IF;
        
        END IF;
        BEGIN
          DBG('customer number' || P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO);
          DBG('short name' || P_STDCIF. V_STTMS_CUSTOMER.ADDRESS_LINE1);
          DBG('p_cust_no' || P_CUST_NO);
          IF P_CUST_NO IS NOT NULL THEN
            P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO := P_CUST_NO;
            DBG('customer number' || P_STDCIF.
                V_STTMS_CUSTOMER.CUSTOMER_NO);
          END IF;
        END;
      END IF;
    
      IF P_ACTION_CODE = 'DEFAULT' OR
         (P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = 'NEW') THEN
        DBG('P_ACTION_CODE' || P_ACTION_CODE);
      
        IF NOT STPKS_STDCIF_UTILS_0.FN_CUSTNO_VALID(P_FUNCTION_ID,
                                                    P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                    L_AUTO_GEN_CIF,
                                                    L_SPCL_CUST,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        
          DBG('Failed in fn_custno_valid: ' || P_ERR_CODE);
        END IF;
      
      END IF;
    
      IF P_STDCIF.V_CUSTOMER_CHANNEL_INFO.COUNT > 0 THEN
        IDX := P_STDCIF.V_CUSTOMER_CHANNEL_INFO.FIRST;
        DBG('idx ' || IDX);
        WHILE IDX IS NOT NULL LOOP
          DBG('p_stdcif.v_customer_channel_info.channel_id : ' || P_STDCIF.V_CUSTOMER_CHANNEL_INFO(IDX)
              .CHANNEL_ID);
          IF P_STDCIF.V_CUSTOMER_CHANNEL_INFO(IDX).CUSTOMER_NO IS NULL THEN
            P_STDCIF.V_CUSTOMER_CHANNEL_INFO(IDX).CUSTOMER_NO := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
            DBG('custno--->' || P_STDCIF.V_CUSTOMER_CHANNEL_INFO(IDX)
                .CUSTOMER_NO);
          END IF;
          IDX := P_STDCIF.V_CUSTOMER_CHANNEL_INFO.NEXT(IDX);
        END LOOP;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
    
      BEGIN
        SELECT NVL(ONCE_AUTH, 'N')
          INTO LONCE_AUTH
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      EXCEPTION
        WHEN OTHERS THEN
          LONCE_AUTH := 'N';
      END;
    
      IF LONCE_AUTH = 'Y' THEN
      
        DBG('##selecting customer count..');
        DBG('p_stdcif.v_sttms_customer.customer_no--> ' ||
            P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
        SELECT COUNT(1)
          INTO L_COUNT1
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND RECORD_STAT = 'O'
           AND ONCE_AUTH = 'Y';
      
        DBG('##l_count1--> ' || L_COUNT1);
        IF L_COUNT1 > 0 THEN
          DBG('calling cspks_cross_rm_restr.fn_check_access..');
        
          IF NOT CSPKS_CROSS_RM_RESTR.FN_CHECK_ACCESS(P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                      P_ERR_PARAMS,
                                                      P_ERR_CODE) THEN
            DBG('failed in cspks_staff_restr.fn_check_cust');
            DBG('user dosent have access on this customer:' ||
                P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
            RETURN FALSE;
          END IF;
        
        END IF;
      END IF;
    
    ELSIF P_ACTION_CODE NOT IN
          (CSPKS_REQ_GLOBAL.P_NEW,
           CSPKS_REQ_GLOBAL.P_DEFAULT,
           'PICKLIABUDF',
           CSPKS_REQ_GLOBAL.P_COPY) THEN
    
      IF P_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH = 'Y' THEN
        IF NOT CSPKS_STAFF_RESTR.FN_CHECK_CUST(P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                               NULL,
                                               GLOBAL.CURRENT_BRANCH,
                                               'N',
                                               P_ERR_PARAMS,
                                               P_ERR_CODE) THEN
          DBG('failed in cspks_staff_restr.fn_check_cust');
          DBG('user dosent have access on this customer:' ||
              P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
          RETURN FALSE;
        END IF;
      
        IF NOT CSPKS_CROSS_RM_RESTR.FN_CHECK_ACCESS(P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                    P_ERR_PARAMS,
                                                    P_ERR_CODE) THEN
          DBG('failed in cspks_cross_rm_restr.fn_check_access');
          DBG('user dosent have access on this customer:' ||
              P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
          RETURN FALSE;
        END IF;
      
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN
       ('DEFAULT', 'COPY', 'NEW', 'MODIFY', 'QUERY', 'EXECUTEQUERY') THEN
    
      IF P_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.COUNT > 0 THEN
        FOR I IN P_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.FIRST .. P_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.LAST LOOP
          P_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(I).RECORD_NO := I;
          DBG('Record no STCCIFJ' || P_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(I)
              .RECORD_NO);
          IF P_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(I)
           .CUSTOMER_NO IS NULL THEN
            P_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(I).CUSTOMER_NO := P_STDCIF.
                                                                              V_STTMS_CUSTOMER.CUSTOMER_NO;
            DBG('p_stdcif.ty_stccifj.v_sttms_cust_personal_joint(i).customer_no          ' || P_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(I)
                .CUSTOMER_NO);
          END IF;
        END LOOP;
      END IF;
      DBG('Joint Callform Customer Number ::' ||
          P_STDCIF.TY_STCCIFJ.V_STTMS_CUSTOMER.CUSTOMER_NO);
    
      P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUSTOMER := P_STDCIF.
                                                                V_STTMS_CUSTOMER.CUSTOMER_NO;
      P_STDCIF.TY_MICCUSTM.V_STTMS_CUSTOMER.CUSTOMER_NO      := P_STDCIF.
                                                                V_STTMS_CUSTOMER.CUSTOMER_NO;
      P_STDCIF.TY_MICCUSTM.V_STTMS_CUSTOMER.LOCAL_BRANCH     := P_STDCIF.
                                                                V_STTMS_CUSTOMER.LOCAL_BRANCH;
      DBG('Branch in master of MIS' ||
          P_STDCIF.TY_MICCUSTM.V_STTMS_CUSTOMER.LOCAL_BRANCH);
      DBG('Customer no in master of MIS' ||
          P_STDCIF.TY_MICCUSTM.V_STTMS_CUSTOMER.CUSTOMER_NO);
      DBG('MIS Customer number::' ||
          P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUSTOMER);
      DBG('STDCIF Cust MIS 1 ::' ||
          P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_1);
    
      P_STDCIF.TY_SICDIARC.V_STTMS_CUSTOMER.CUSTOMER_NO := P_STDCIF.
                                                           V_STTMS_CUSTOMER.CUSTOMER_NO;
    
      IF P_ACTION_CODE = 'DEFAULT' AND NVL(L_AUTO_GEN_CIF, 'N') = 'N' THEN
        P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.DELETE;
      END IF;
    
      P_STDCIF.TY_CSCCURLN.V_STTMS_CUSTOMER.CUSTOMER_NO := P_STDCIF.
                                                           V_STTMS_CUSTOMER.CUSTOMER_NO;
    
      IF NVL(P_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER, 'N') = 'Y' AND
         P_STDCIF.V_STTMS_MFI_DETAILS.INSURANCE_NUMBER IS NOT NULL THEN
        IF P_ACTION_CODE IN ('NEW') THEN
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM STTM_MFI_DETAILS
             WHERE INSURANCE_NUMBER =
                   P_STDCIF.V_STTMS_MFI_DETAILS.INSURANCE_NUMBER;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_COUNT := 0;
            WHEN OTHERS THEN
              RETURN FALSE;
          END;
          IF L_COUNT > 0 THEN
            DBG('DUPLICATE CUSTOMER');
            P_ERR_CODE   := 'MF-CIF-011';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        END IF;
        IF P_ACTION_CODE IN ('MODIFY') AND
           P_STDCIF.V_STTMS_MFI_DETAILS.INSURANCE_NUMBER IS NOT NULL THEN
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM STTM_MFI_DETAILS
             WHERE INSURANCE_NUMBER =
                   P_STDCIF.V_STTMS_MFI_DETAILS.INSURANCE_NUMBER;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_COUNT := 0;
            WHEN OTHERS THEN
              RETURN FALSE;
          END;
          IF L_COUNT > 1 THEN
            DBG('DUPLICATE CUSTOMER');
            P_ERR_CODE   := 'MF-CIF-011';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        END IF;
        DBG('DOCUMENT TYPE IS-->' ||
            P_STDCIF.V_MFTBS_CUST_ID_DETAIL.DOCUMENT_TYPE);
        DBG('SERIES-->' || P_STDCIF.V_MFTBS_CUST_ID_DETAIL.SERIES);
        DBG('DOC_ID-->' || P_STDCIF.V_MFTBS_CUST_ID_DETAIL.DOC_ID);
        DBG('DT OF ISSUER-->' ||
            P_STDCIF.V_MFTBS_CUST_ID_DETAIL.DATE_OF_ISSUE);
        DBG('DT OF EXPIRE-->' ||
            P_STDCIF.V_MFTBS_CUST_ID_DETAIL.DATE_OF_EXPIRY);
        DBG('ISSUING AUTH-->' ||
            P_STDCIF.V_MFTBS_CUST_ID_DETAIL.ISSUING_AUTHORITY);
        DBG('PLACE OF ISSUE-->' ||
            P_STDCIF.V_MFTBS_CUST_ID_DETAIL.PLACE_OF_ISSUE);
        DBG('NAME-->' || P_STDCIF.V_MFTBS_CUST_ID_DETAIL.NAME);
        IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
          DBG('I AM HERE with the value ');
          IF P_STDCIF.V_MFTBS_CUST_ID_DETAIL.DOCUMENT_TYPE IS NOT NULL AND
             P_STDCIF.V_MFTBS_CUST_ID_DETAIL.SERIES IS NULL AND
             P_STDCIF.V_MFTBS_CUST_ID_DETAIL.DOC_ID IS NULL AND
             P_STDCIF.V_MFTBS_CUST_ID_DETAIL.DATE_OF_ISSUE IS NULL AND
             P_STDCIF.V_MFTBS_CUST_ID_DETAIL.DATE_OF_EXPIRY IS NULL AND
             P_STDCIF.V_MFTBS_CUST_ID_DETAIL.ISSUING_AUTHORITY IS NULL AND
             P_STDCIF.V_MFTBS_CUST_ID_DETAIL.PLACE_OF_ISSUE IS NULL AND
             P_STDCIF.V_MFTBS_CUST_ID_DETAIL.NAME IS NULL THEN
            DBG('DETAILS NOT ENTERED FOR IDENTIFICATION DETAILS');
            P_ERR_CODE   := 'MF-CIF-012';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          END IF;
        END IF;
      END IF;
    
      IF P_ACTION_CODE NOT IN ('COPY') THEN
      
        DBG('count of linked entity ' ||
            P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT);
        IF P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT > 0 THEN
          FOR L_CUST_LINKED_ENTITY IN P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.FIRST .. P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.LAST LOOP
            DBG('Inside Linked Entity assignment');
            IF P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY)
             .CUSTOMER IS NOT NULL THEN
              P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY).BRANCH := P_STDCIF.
                                                                                          V_STTMS_CUSTOMER.LOCAL_BRANCH;
              P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY).CATEGORY := 'C';
              DBG('Category assigned ');
              IF P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY)
               .RELATIONSHIP = 'PRIMARY' AND P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY)
                 .CUSTOMER != P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO THEN
              
                IF P_ACTION_CODE IN ('NEW') THEN
                  P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY).CUSTOMER := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
                
                  DBG('Customer:' || P_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(L_CUST_LINKED_ENTITY)
                      .CUSTOMER);
                ELSIF P_ACTION_CODE NOT IN ('NEW') THEN
                
                  DBG('INside condition of PRIMARY Relationship');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'ST-CIF141',
                               P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO);
                  RETURN FALSE;
                END IF;
              END IF;
            END IF;
          END LOOP;
          DBG(' Category assignment done ');
        END IF;
      
      END IF;
    
      P_STDCIF.TY_STCCIFTX.V_STTMS_CUSTOMER.CUSTOMER_NO := P_STDCIF.
                                                           V_STTMS_CUSTOMER.CUSTOMER_NO;
      P_STDCIF.TY_STCCIFTX.V_STTMS_CUSTOMER.CUSTOMER_NO := P_STDCIF.
                                                           V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('count of linked entity ' ||
          P_STDCIF.TY_STCCIFTX.V_STTMS_CUST_TEXT.COUNT);
      IF P_STDCIF.TY_STCCIFTX.V_STTMS_CUST_TEXT.COUNT > 0 THEN
        DBG('assign value of seq' || I);
        I := 1;
        FOR L_CUST_TEXT IN P_STDCIF.TY_STCCIFTX.V_STTMS_CUST_TEXT.FIRST .. P_STDCIF.TY_STCCIFTX.V_STTMS_CUST_TEXT.LAST LOOP
          DBG('Inside Linked Entity assignment');
          P_STDCIF.TY_STCCIFTX.V_STTMS_CUST_TEXT(L_CUST_TEXT).CUSTOMER_NO := P_STDCIF.
                                                                             V_STTMS_CUSTOMER.CUSTOMER_NO;
          P_STDCIF.TY_STCCIFTX.V_STTMS_CUST_TEXT(L_CUST_TEXT).SEQ_NO := I;
          I := I + 1;
          DBG('Category assigned ');
        END LOOP;
        DBG(' Category assignment done ');
      END IF;
    END IF;
    IF P_ACTION_CODE IN ('DEFAULT', 'COPY') OR
      
       (P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE IN ('NEW', 'MODIFY')) THEN
    
      IF P_SOURCE <> 'FLEXCUBE' THEN
        IF P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES.COUNT > 0 THEN
          FOR REC IN C_CUST_MIS LOOP
            L_M_CODE := L_M_CODE + 1;
            L_MITMS_DEFAULT_CODES(L_M_CODE).KEY_ID := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
            L_MITMS_DEFAULT_CODES(L_M_CODE).MIS_TYPE := 'C';
            L_MITMS_DEFAULT_CODES(L_M_CODE).MIS_CLASS := REC.MIS_CLASS;
            FOR X IN 1 .. P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES.COUNT LOOP
              IF P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(X)
               .MIS_CLASS = REC.MIS_CLASS THEN
                L_MITMS_DEFAULT_CODES(L_M_CODE).MIS_CODE := P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(X)
                                                            .MIS_CODE;
              END IF;
            END LOOP;
          
          END LOOP;
          P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES.DELETE;
          P_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES := L_MITMS_DEFAULT_CODES;
        END IF;
      
        IF P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C.COUNT > 0 THEN
        
          FOR REC IN C_COMP_MIS LOOP
            L_MIS_COMP := L_MIS_COMP + 1;
            L_MITMS_DEFAULT_CODES__C(L_MIS_COMP).KEY_ID := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
            L_MITMS_DEFAULT_CODES__C(L_MIS_COMP).MIS_TYPE := 'C';
            L_MITMS_DEFAULT_CODES__C(L_MIS_COMP).MIS_CLASS := REC.MIS_CLASS;
            FOR X IN 1 .. P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C.COUNT LOOP
              IF P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(X)
               .MIS_CLASS = REC.MIS_CLASS THEN
                L_MITMS_DEFAULT_CODES__C(L_MIS_COMP).MIS_CODE := P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(X)
                                                                 .MIS_CODE;
              END IF;
            END LOOP;
          
          END LOOP;
          P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C.DELETE;
          P_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C := L_MITMS_DEFAULT_CODES__C;
        END IF;
      
      END IF;
    
      DBG('In pickup');
      IF NOT STPKS_STDCIF_UTILS_0.FN_PICKUP(P_FUNCTION_ID,
                                            P_STDCIF.
                                            V_STTMS_CUSTOMER.CUSTOMER_NO,
                                            P_STDCIF,
                                            P_KEY,
                                            P_PARENT,
                                            P_FORMAT,
                                            L_TMP_FMT,
                                            L_CNT_LVL,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
        DBG('Error Inside Function fn_CustMis' || SQLERRM);
      END IF;
    END IF;
    DBG('MIS Customer number >>>::' ||
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUSTOMER);
    DBG('STDCIF Cust MIS 1 >::' ||
        P_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUST_MIS_1);
    DBG('Returning Success from fn_pre_check_mandatory');
    DBG('short name@@@' || P_STDCIF. V_STTMS_CUSTOMER.ADDRESS_LINE1);
  
    IF P_ACTION_CODE IN ('DEFAULT', 'COPY') AND
       (NVL(L_AUTO_GEN_CIF, 'N') = 'N') THEN
      DBG('in skip');
      STPKS_STDCIF_MAIN.PR_SET_SKIP_SYS;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
    
      IF NVL(P_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE, 'N') = 'Y' AND
         P_STDCIF.V_STTMS_CUST_JV.COUNT > 0 THEN
      
        FOR I IN P_STDCIF.V_STTMS_CUST_JV.FIRST .. P_STDCIF.V_STTMS_CUST_JV.LAST LOOP
        
          IF P_STDCIF.V_STTMS_CUST_JV(I).PARTY_RATIO IS NULL THEN
          
            P_ERR_CODE   := 'ST-MAND-006';
            P_ERR_PARAMS := '@STTMS_CUST_JV.PARTY_RATIO~@BLK_STTMS_CUSTOMER.JOINT_VENTURE~' || I;
          
            RETURN FALSE;
          END IF;
        END LOOP;
      
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
    
      IF (P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD8 = 'Y' AND
         P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.COUNT = 0) THEN
        DBG('Joint customer is checked but details are not given');
        P_ERR_CODE := 'ST-CIF162';
        RETURN FALSE;
      END IF;
    
    END IF;
  
    DBG('BEFORE KEY ID PRECHECK' ||
        P_STDCIF.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);
    IF P_STDCIF.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID IS NULL THEN
      P_STDCIF.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID := P_STDCIF.
                                                              V_STTMS_CUSTOMER.CUSTOMER_NO;
    END IF;
    DBG('AFTER KEY ID PRECHECK IS' ||
        P_STDCIF.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);
  
    IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN
       --('C', 'B') AND --loan sector sampath commented
      ('C', 'B', 'U', 'R', 'S', 'N') AND --loan sector sampath changes
       P_ACTION_CODE <> 'AUTH' THEN
    
      DBG('p_stdcif.v_sttms_customer__a.ADDRESS_LINE1 ==>' ||
          P_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1);
      DBG('p_stdcif.v_sttms_customer.ADDRESS_LINE1 ==>' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
      BEGIN
      
        P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1 := NVL(P_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1,
                                                       P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
      
        P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2       := P_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE2;
        P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3       := P_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE3;
        P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4       := P_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE4;
        P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1      := P_STDCIF.V_STTMS_CUSTOMER__A.CUSTOMER_NAME1;
        P_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE       := P_STDCIF.V_STTMS_CUSTOMER__A.JOINT_VENTURE;
        P_STDCIF.V_STTMS_CUST_PERSONAL.TELEPHONE      := P_STDCIF.V_STTMS_CUST_PERSONAL__A.TELEPHONE;
        P_STDCIF.V_STTMS_CUST_PERSONAL.FAX            := P_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX;
        P_STDCIF.V_STTMS_CUST_PERSONAL.E_MAIL         := P_STDCIF.V_STTMS_CUST_PERSONAL__A.E_MAIL;
        P_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER  := P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOBILE_NUMBER;
        P_STDCIF.V_STTMS_CUST_PERSONAL.CUST_COMM_MODE := P_STDCIF.V_STTMS_CUST_PERSONAL__A.CUST_COMM_MODE;
      
        P_STDCIF.V_STTMS_CUSTOMER.PINCODE := P_STDCIF.V_STTMS_CUSTOMER__A.PINCODE;
      
        P_STDCIF.V_STTMS_CUST_PERSONAL.TEL_ISD_NO := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.TEL_ISD_NO,
                                                         P_STDCIF.V_STTMS_CUST_PERSONAL.TEL_ISD_NO);
        P_STDCIF.V_STTMS_CUST_PERSONAL.MOB_ISD_NO := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO,
                                                         P_STDCIF.V_STTMS_CUST_PERSONAL.MOB_ISD_NO);
        P_STDCIF.V_STTMS_CUST_PERSONAL.FAX_ISD_NO := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX_ISD_NO,
                                                         P_STDCIF.V_STTMS_CUST_PERSONAL.FAX_ISD_NO);
      
        IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.TELEPHONE IS NULL THEN
          P_STDCIF.V_STTMS_CUST_PERSONAL.TELEPHONE := NULL;
        END IF;
        IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX IS NULL THEN
          P_STDCIF.V_STTMS_CUST_PERSONAL.FAX := NULL;
        END IF;
        IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.E_MAIL IS NULL THEN
          P_STDCIF.V_STTMS_CUST_PERSONAL.E_MAIL := NULL;
        END IF;
        IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOBILE_NUMBER IS NULL THEN
          P_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER := NULL;
        END IF;
        IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.CUST_COMM_MODE IS NULL THEN
          P_STDCIF.V_STTMS_CUST_PERSONAL.CUST_COMM_MODE := NULL;
        END IF;
        IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.TEL_ISD_NO IS NULL THEN
          P_STDCIF.V_STTMS_CUST_PERSONAL.TEL_ISD_NO := NULL;
        END IF;
        IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO IS NULL THEN
          P_STDCIF.V_STTMS_CUST_PERSONAL.MOB_ISD_NO := NULL;
        END IF;
        IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX_ISD_NO IS NULL THEN
          P_STDCIF.V_STTMS_CUST_PERSONAL.FAX_ISD_NO := NULL;
        END IF;
      
        DBG('country 1 ' || P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
        DBG('nationality 1 ' || P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
        DBG('LANGUAGE 1 ' || P_STDCIF.V_STTMS_CUSTOMER.LANGUAGE);
      
        P_STDCIF.V_STTMS_CUSTOMER.COUNTRY     := NVL(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY,
                                                     P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
        P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY := NVL(P_STDCIF.V_STTMS_CUSTOMER__A.NATIONALITY,
                                                     P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
        P_STDCIF.V_STTMS_CUSTOMER.LANGUAGE    := NVL(P_STDCIF.V_STTMS_CUSTOMER__A.LANGUAGE,
                                                     P_STDCIF.V_STTMS_CUSTOMER.LANGUAGE);
      
        DBG('country 2 ' || P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
        DBG('nationality 2 ' || P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
        DBG('LANGUAGE 2 ' || P_STDCIF.V_STTMS_CUSTOMER.LANGUAGE);
      
        IF P_FUNCTION_ID = 'STDCIFAD' THEN
        
          P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME  := P_STDCIF.V_STTMS_CUSTOMER__A.UNIQUE_ID_NAME;
          P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE := P_STDCIF.V_STTMS_CUSTOMER__A.UNIQUE_ID_VALUE;
        END IF;
        P_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO  := P_STDCIF.V_STTMS_CUSTOMER__A.KYC_REF_NO;
        P_STDCIF.V_STTMS_CUSTOMER.KYC_DETAILS := P_STDCIF.V_STTMS_CUSTOMER__A.KYC_DETAILS;
      END;
      --IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN --loan sector sampath commented
      IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN
         ('C', 'U', 'R', 'S', 'N') THEN
        --loan sector sampath changes
        IF P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY IS NULL THEN
          DBG('incorp country is null');
          P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY := NVL(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY,
                                                                P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
        END IF;
        IF P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY IS NULL THEN
          DBG('reg country is null');
          P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY := NVL(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY,
                                                           P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
        END IF;
      END IF;
      DBG('incorp country ->' ||
          P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);
      DBG('reg country ->' || P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);
      IF P_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT > 0 THEN
        FOR REC_DIR IN 1 .. P_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT LOOP
          IF P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).P_COUNTRY IS NULL THEN
            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).P_COUNTRY := NVL(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY,
                                                                      P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          END IF;
          IF P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).P_ADDRESS1 IS NULL THEN
            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).P_ADDRESS1 := COALESCE(P_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1,
                                                                            P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                                                                            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR)
                                                                            .ADDRESS_LINE1);
          END IF;
        
          IF P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).TELEPHONE IS NULL THEN
            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).TELEPHONE := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.TELEPHONE,
                                                                      P_STDCIF.V_STTMS_CUST_PERSONAL.TELEPHONE);
          END IF;
        
          IF P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).MOBILE_NUMBER IS NULL THEN
            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).MOBILE_NUMBER := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOBILE_NUMBER,
                                                                          P_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER);
          END IF;
        
          IF P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).TEL_ISD_NO IS NULL THEN
            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).TEL_ISD_NO := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.TEL_ISD_NO,
                                                                       P_STDCIF.V_STTMS_CUST_PERSONAL.TEL_ISD_NO);
          END IF;
          IF P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).MOB_ISD_NO IS NULL THEN
            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).MOB_ISD_NO := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO,
                                                                       P_STDCIF.V_STTMS_CUST_PERSONAL.MOB_ISD_NO);
          END IF;
        
          IF P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).HOME_TEL_NO IS NULL THEN
            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).HOME_TEL_NO := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.HOME_TEL_NO,
                                                                        P_STDCIF.V_STTMS_CUST_PERSONAL.HOME_TEL_NO);
          END IF;
          IF P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).HOME_TEL_ISD IS NULL THEN
            P_STDCIF.V_STTMS_CORP_DIRECTORS(REC_DIR).HOME_TEL_ISD := NVL(P_STDCIF.V_STTMS_CUST_PERSONAL__A.HOME_TEL_ISD,
                                                                         P_STDCIF.V_STTMS_CUST_PERSONAL.HOME_TEL_ISD);
          END IF;
        
        END LOOP;
      END IF;
    END IF;
  
    DBG('Before assingning directors');
    FOR K IN 1 .. P_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT LOOP
      DBG('Dir Name:' || P_STDCIF.V_STTMS_CORP_DIRECTORS(K).DIRECTOR_NAME);
      DBG('SlNo:' || P_STDCIF.V_STTMS_CORP_DIRECTORS(K).SLNO);
      P_STDCIF.V_STTMS_CORP_DIRECTORS(K).SLNO := K;
    END LOOP;
  
    IF P_STDCIF.V_STTMS_CUST_PERSONAL.PREF_CONTACT_DT IS NOT NULL THEN
      L_FLD := 'STTMS_CUST_PERSONAL.PREF_CONTACT_DT';
      IF P_STDCIF.V_STTMS_CUST_PERSONAL.PREF_CONTACT_DT <
         GLOBAL.APPLICATION_DATE THEN
        DBG('Preferred Contact Date Cannot be less than present date');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-DATE-001', '@' || L_FLD);
      END IF;
    END IF;
    IF P_STDCIF.V_STTMS_CUST_CORPORATE.PREF_CONTACT_DT IS NOT NULL THEN
      L_FLD := 'STTMS_CUST_CORPORATE.PREF_CONTACT_DT';
      IF P_STDCIF.V_STTMS_CUST_CORPORATE.PREF_CONTACT_DT <
         GLOBAL.APPLICATION_DATE THEN
        DBG('Preferred Contact Date Cannot be less than present date for Corporate Customer');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-DATE-001', '@' || L_FLD);
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN ('DEFAULT', 'COPY') THEN
      BEGIN
      
        SELECT LIMIT_TRACK_CIF_CORP,
               LIMIT_TRACK_CIF_BANK,
               LIMIT_TRACK_CIF_INDL
          INTO L_CORP, L_BANK, L_INDV
          FROM STTM_BANK;
      EXCEPTION
        WHEN OTHERS THEN
          L_CORP := 'N';
          L_BANK := 'N';
          L_INDV := 'N';
      END;
      IF ((L_CORP = 'Y' AND P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C') OR
         --loan sector sampath changes starts
         (L_CORP = 'Y' AND P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'U') OR
         (L_CORP = 'Y' AND P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'R') OR
         (L_CORP = 'Y' AND P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'S') OR
         (L_CORP = 'Y' AND P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'N') OR
         --loan sector sampath changes ends
         (L_BANK = 'Y' AND P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'B') OR
         (L_INDV = 'Y' AND P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I')) THEN
      
        IF P_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS = 'Y' THEN
        
          P_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        END IF;
      END IF;
    END IF;
  
    DBG('pre2 p_STDCIF.v_sttms_cust_doc_checklist Count check-->' ||
        P_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.COUNT);
    DBG('Action Code-->' || P_ACTION_CODE);
    IF P_ACTION_CODE = 'COPY' THEN
      P_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.DELETE;
    END IF;
  
    DBG('p_stdcif.v_cstb_ui_columns.char_field45' ||
        P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45);
  
    DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1=' ||
        P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
    DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2=' ||
        P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2);
    DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3=' ||
        P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3);
    DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4=' ||
        P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4);
  
    IF (P_SOURCE <> 'FLEXCUBE') THEN
      IF P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45 IS NOT NULL THEN
        BEGIN
          SELECT ADDRESS_LINE1,
                 ADDRESS_LINE2,
                 ADDRESS_LINE3,
                 ADDRESS_LINE4,
                 COUNTRY
            INTO P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4,
                 P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
            FROM STTM_ADDRESS
           WHERE ADDRESS_CODE = P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No records present ');
        END;
      END IF;
    
      DBG('p_stdcif.v_cstb_ui_columns.char_field94 Permanent address personal tab' ||
          P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD94);
    
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4);
    
      IF P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD94 IS NOT NULL THEN
        BEGIN
          SELECT ADDRESS_LINE1,
                 ADDRESS_LINE2,
                 ADDRESS_LINE3,
                 ADDRESS_LINE4,
                 COUNTRY
            INTO P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4,
                 P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
            FROM STTM_ADDRESS
           WHERE ADDRESS_CODE = P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD94;
          DBG('**');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No records present ');
        END;
      END IF;
    
      DBG('p_stdcif.v_cstb_ui_columns.char_field87 correspondence address corporate tab' ||
          P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87);
    
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4);
    
      IF P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87 IS NOT NULL THEN
        BEGIN
          SELECT ADDRESS_LINE1,
                 ADDRESS_LINE2,
                 ADDRESS_LINE3,
                 ADDRESS_LINE4,
                 COUNTRY
            INTO P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4,
                 P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
            FROM STTM_ADDRESS
           WHERE ADDRESS_CODE = P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87;
          DBG('**');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No records present ');
        END;
      END IF;
    
      DBG('p_stdcif.v_cstb_ui_columns.char_field86 registration corporate tab' ||
          P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD86);
    
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4);
    
      IF P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD86 IS NOT NULL THEN
        BEGIN
          SELECT ADDRESS_LINE1,
                 ADDRESS_LINE2,
                 ADDRESS_LINE3,
                 ADDRESS_LINE4,
                 COUNTRY
            INTO P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4,
                 P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
            FROM STTM_ADDRESS
           WHERE ADDRESS_CODE = P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD86;
          DBG('**');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No records present ');
        END;
      END IF;
    
      DBG('p_stdcif.v_cstb_ui_columns.char_field90 additional tab' ||
          P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD90);
    
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4);
    
      IF P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD90 IS NOT NULL THEN
        BEGIN
          SELECT ADDRESS_LINE1,
                 ADDRESS_LINE2,
                 ADDRESS_LINE3,
                 ADDRESS_LINE4,
                 COUNTRY
            INTO P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4,
                 P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
            FROM STTM_ADDRESS
           WHERE ADDRESS_CODE = P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD90;
          DBG('**');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No records present ');
        END;
      END IF;
    
      DBG('p_stdcif.v_cstb_ui_columns.char_field54 professional tab' ||
          P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD54);
    
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3);
      DBG('P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4=' ||
          P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4);
    
      IF P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD54 IS NOT NULL THEN
        BEGIN
          SELECT ADDRESS_LINE1,
                 ADDRESS_LINE2,
                 ADDRESS_LINE3,
                 ADDRESS_LINE4,
                 COUNTRY
            INTO P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3,
                 P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4,
                 P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
            FROM STTM_ADDRESS
           WHERE ADDRESS_CODE = P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD54;
          DBG('**');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No records present ');
        END;
      END IF;
    END IF;
  
    DBG('P_ACTION_CODE:' || P_ACTION_CODE);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('p_stdcif.v_sttms_customer.elcm_customer:' ||
          P_STDCIF.V_STTMS_CUSTOMER.ELCM_CUSTOMER);
      DBG('p_stdcif.v_sttms_customer.track_limits:' ||
          P_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS);
    
      IF NVL(P_STDCIF.V_STTMS_CUSTOMER.ELCM_CUSTOMER, 'N') = 'N' AND
         NVL(P_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS, 'N') = 'Y' THEN
        P_ERR_CODE   := 'ST-CIF-L010';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcif_Kernel.Fn_Pre_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_BLK        VARCHAR2(100);
    L_FLD        VARCHAR2(100);
    L_FATCA_APPL CHAR(1) := NULL;
  BEGIN
    DBG('In Fn_Post_Check_Mandatory..');
  
    IF P_ACTION_CODE = 'CUSSNCKSTATUS' THEN
      DBG('This Action code is to display sanction check.. So returning true..');
      RETURN TRUE;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_SERVICE.P_MODIFY THEN
    
      IF P_STDCIF.V_STTMS_CUSTOMER.SHORT_NAME IS NULL THEN
      
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIF-310', '');
      
      END IF;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_SERVICE.P_NEW THEN
    
      IF P_STDCIF.V_STTMS_CUSTOMER.SHORT_NAME IS NULL THEN
      
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIF-312', '');
      
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN ('DEFAULT', 'COPY') THEN
      STPKS_STDCIF_MAIN.PR_SET_ACTIVATE_SYS;
    END IF;
  
    SELECT FATCA_APPLICABLE
      INTO L_FATCA_APPL
      FROM STTMS_BANK
     WHERE ROWNUM = 1;
    IF L_FATCA_APPL = 'Y' AND P_FUNCTION_ID IN ('STDCIF', 'STDCIFAD') THEN
      IF P_ACTION_CODE IN (CSPKS_SERVICE.P_NEW, CSPKS_SERVICE.P_MODIFY) THEN
        IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
          DBG('Customer is of type Individual');
        
          L_BLK := 'STTMS_CUST_PERSONAL';
        
          L_FLD := 'STTMS_CUST_PERSONAL.TEL_ISD_NO';
          IF P_STDCIF.V_STTMS_CUST_PERSONAL.TELEPHONE IS NOT NULL AND
             P_STDCIF.V_STTMS_CUST_PERSONAL.TEL_ISD_NO IS NULL THEN
            DBG('Mandatory Key Column TEL_ISD_NO Cannot Be Null');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         
                         'ST-MAND-012',
                         
                         '@' || L_FLD || '~@' || L_BLK);
          
          END IF;
        
          L_FLD := 'STTMS_CUST_PERSONAL.HOME_TEL_ISD';
          IF P_STDCIF.V_STTMS_CUST_PERSONAL.HOME_TEL_NO IS NOT NULL AND
             P_STDCIF.V_STTMS_CUST_PERSONAL.HOME_TEL_ISD IS NULL THEN
            DBG('Mandatory Key Column HOME_TEL_ISD Cannot Be Null');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         
                         'ST-MAND-012',
                         
                         '@' || L_FLD || '~@' || L_BLK);
          
          END IF;
        
          L_FLD := 'STTMS_CUST_PERSONAL.FAX_ISD_NO';
          IF P_STDCIF.V_STTMS_CUST_PERSONAL.FAX IS NOT NULL AND
             P_STDCIF.V_STTMS_CUST_PERSONAL.FAX_ISD_NO IS NULL THEN
            DBG('Mandatory Key Column FAX_ISD_NO Cannot Be Null');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         
                         'ST-MAND-012',
                         
                         '@' || L_FLD || '~@' || L_BLK);
          
          END IF;
          L_FLD := 'STTMS_CUST_PERSONAL.MOB_ISD_NO';
          IF P_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER IS NOT NULL AND
             P_STDCIF.V_STTMS_CUST_PERSONAL.MOB_ISD_NO IS NULL THEN
            DBG('Mandatory Key Column MOB_ISD_NO Cannot Be Null');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         
                         'ST-MAND-012',
                         
                         '@' || L_FLD || '~@' || L_BLK);
          
          END IF;
          IF P_FUNCTION_ID = 'STDCIF' THEN
            IF P_STDCIF.V_STTMS_CUST_PERSONAL.PA_ISSUED = 'Y' THEN
              IF P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_NAME IS NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_NATIONALTY IS NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_ADDR IS NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_TEL_ISD IS NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_TEL_NO IS NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_ADDR_COUNTRY IS NULL THEN
                DBG('Power of attorney Details Not Given');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-KYC-06', '');
              END IF;
            END IF;
            IF P_STDCIF.V_STTMS_CUST_PERSONAL.PA_ISSUED = 'N' THEN
              IF P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_NAME IS NOT NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_NATIONALTY IS NOT NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_ADDR IS NOT NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_TEL_ISD IS NOT NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_TEL_NO IS NOT NULL OR
                 P_STDCIF.V_STTMS_CUST_PERSONAL.PA_HOLDER_ADDR_COUNTRY IS NOT NULL THEN
                DBG('Power of attorney  Not Checked');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-KYC-07', '');
              END IF;
            END IF;
            IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
              DBG('Checking Mandatory fields for Individual Customer..');
            
              L_BLK := 'STTMS_CUST_PERSONAL';
            
              L_FLD := 'STTMS_CUST_PERSONAL.BIRTH_COUNTRY';
            
              IF P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY IS NULL THEN
              
                DBG('Mandatory Key Column BIRTH_COUNTRY Cannot Be Null');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             
                             'ST-MAND-012',
                             
                             '@' || L_FLD || '~@' || L_BLK);
              
              END IF;
            END IF;
          END IF;
        END IF;
       --IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN --loan sector sampath commented
           IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN
           ('C', 'U', 'R', 'S', 'N') THEN
          --loan sector sampath changes
          DBG('Customer is of type Corporate ');
        
          L_BLK := 'STTMS_CUST_CORPORATE';
        
          L_FLD := 'STTMS_CUST_PERSONAL__A.TEL_ISD_NO';
        
          IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.TELEPHONE IS NOT NULL AND
             P_STDCIF.V_STTMS_CUST_PERSONAL__A.TEL_ISD_NO IS NULL THEN
            DBG('STTMS_CUST_PERSONAL__A Mandatory Key Column TEL_ISD_NO Cannot Be Null');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         
                         'ST-MAND-012',
                         
                         '@' || L_FLD || '~@' || L_BLK);
          
          END IF;
        
          L_FLD := 'STTMS_CUST_PERSONAL__A.FAX_ISD_NO';
        
          IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX IS NOT NULL AND
             P_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX_ISD_NO IS NULL THEN
            DBG('STTMS_CUST_PERSONAL__A Mandatory Key Column FAX_ISD_NO Cannot Be Null');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         
                         'ST-MAND-012',
                         
                         '@' || L_FLD || '~@' || L_BLK);
          
          END IF;
        
          L_FLD := 'STTMS_CUST_PERSONAL__A.MOB_ISD_NO';
        
          IF P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOBILE_NUMBER IS NOT NULL AND
             P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO IS NULL THEN
            DBG('STTMS_CUST_PERSONAL__A Mandatory Key Column MOB_ISD_NO Cannot Be Null' ||
                P_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO);
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         
                         'ST-MAND-012',
                         
                         '@' || L_FLD || '~@' || L_BLK);
          
          END IF;
        
          IF P_FUNCTION_ID = 'STDCIF' THEN
          
            L_BLK := 'STTMS_CORP_DIRECTORS';
          
            DBG('p_stdcif.v_sttms_corp_directors.count->' ||
                P_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT);
            IF P_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT > 0 THEN
            
              FOR I IN P_STDCIF.V_STTMS_CORP_DIRECTORS.FIRST .. P_STDCIF.V_STTMS_CORP_DIRECTORS.LAST LOOP
              
                L_FLD := 'STTMS_CORP_DIRECTORS.TEL_ISD_NO';
              
                IF P_STDCIF.V_STTMS_CORP_DIRECTORS(I).TELEPHONE IS NOT NULL AND P_STDCIF.V_STTMS_CORP_DIRECTORS(I)
                   .TEL_ISD_NO IS NULL THEN
                  DBG('STTMS_CORP_DIRECTORS Mandatory Key Column TEL_ISD_NO Cannot Be Null');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               
                               'ST-MAND-012',
                               
                               '@' || L_FLD || '~@' || L_BLK);
                
                END IF;
              
                L_FLD := 'STTMS_CORP_DIRECTORS.HOME_TEL_ISD';
              
                IF P_STDCIF.V_STTMS_CORP_DIRECTORS(I).HOME_TEL_NO IS NOT NULL AND P_STDCIF.V_STTMS_CORP_DIRECTORS(I)
                   .HOME_TEL_ISD IS NULL THEN
                  DBG('STTMS_CORP_DIRECTORS Mandatory Key Column HOME_TEL_ISD Cannot Be Null');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               
                               'ST-MAND-012',
                               
                               '@' || L_FLD || '~@' || L_BLK);
                
                END IF;
              
                L_FLD := 'STTMS_CORP_DIRECTORS.MOB_ISD_NO';
              
                IF P_STDCIF.V_STTMS_CORP_DIRECTORS(I).MOBILE_NUMBER IS NOT NULL AND P_STDCIF.V_STTMS_CORP_DIRECTORS(I)
                   .MOB_ISD_NO IS NULL THEN
                  DBG('STTMS_CORP_DIRECTORS Mandatory Key Column MOB_ISD_NO Cannot Be Null' || P_STDCIF.V_STTMS_CORP_DIRECTORS(I)
                      .MOBILE_NUMBER);
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               
                               'ST-MAND-012',
                               
                               '@' || L_FLD || '~@' || L_BLK);
                
                END IF;
              
                L_FLD := 'STTMS_CORP_DIRECTORS.NATIONALITY';
              
                IF P_STDCIF.V_STTMS_CORP_DIRECTORS(I).NATIONALITY IS NULL THEN
                  DBG('STTMS_CORP_DIRECTORS Mandatory Key Column NATIONALITY Cannot Be Null');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               
                               'ST-MAND-012',
                               
                               '@' || L_FLD || '~@' || L_BLK);
                
                END IF;
              END LOOP;
            END IF;
          END IF;
          DBG('out of loop');
        END IF;
      
      END IF;
    END IF;
  
    DBG('validation for combined statement');
    IF P_STDCIF.V_STTMS_CUSTOMER.AUTOGEN_STMTPLAN != 'Y' AND
       P_STDCIF.V_STTMS_CUSTOMER.FREQUENCY IS NOT NULL THEN
    
      DBG('Please remove values for combined statement related parameters from the additional tab,since the flag Auto Generated Statement PLAN is unchecked');
      P_ERR_CODE   := 'ST-CMB-21';
      P_ERR_PARAMS := 'Please remove values for combined statement related parameters from the additional tab,since the flag Auto Generated Statement PLAN is unchecked';
    
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
    IF P_STDCIF.V_STTMS_CUSTOMER.AUTOGEN_STMTPLAN = 'Y' AND
       P_STDCIF.V_STTMS_CUSTOMER.FREQUENCY IS NULL AND
       P_STDCIF.V_STTMS_CUSTOMER.STMT_DAY IS NULL THEN
    
      DBG('Please input Frequency and Statement Day for combined statement plan in the Additional tab');
      P_ERR_CODE   := 'ST-CMB-22';
      P_ERR_PARAMS := 'Please input Frequency and Statement Day for combined statement plan in the Additional tab';
    
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
  
    DBG('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcif_Kernel.Fn_Post_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CHILD_FUNCTION   IN VARCHAR2,
                                       P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                       P_PREV_STDCIF      IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                       P_WRK_STDCIF       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_WRK_STDCIF VARCHAR2(1) := NULL;
    L_TEMP       VARCHAR2(1) := NULL;
    L_REFCOUNT   NUMBER := 0;
    L_LOV_COUNT  PLS_INTEGER;
    L_LOV_COUNT1 PLS_INTEGER;
    L_LOV_COUNT2 PLS_INTEGER;
  BEGIN
    DBG('In Fn_Pre_Default_And_Validate..');
  
    IF P_ACTION_CODE = 'CUSSNCKSTATUS' THEN
      DBG('This Action code is to display sanction check.. So returning true..');
      RETURN TRUE;
    END IF;
  
    IF P_ACTION_CODE = 'MODIFY' THEN
      IF P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS.COUNT > 0 THEN
        DBG('P_PREV_STDCIF.v_sttms_linkedacc_details.COUNT' ||
            P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS.COUNT);
        FOR I IN 1 .. P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS.COUNT LOOP
          FOR J IN 1 .. P_STDCIF.V_STTMS_LINKEDACC_DETAILS.COUNT LOOP
            DBG('P_PREV_STDCIF.v_sttms_linkedacc_details.LINKED_ACC_VER' || P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS(I)
                .LINKED_ACC_VER);
            DBG('P_STDCIF.v_sttms_linkedacc_details.LINKED_ACC_VER' || P_STDCIF.V_STTMS_LINKEDACC_DETAILS(J)
                .LINKED_ACC_VER);
            IF (P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS(I)
               .LINKED_ACC_VER = 'Y' AND P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS(I)
               .LINKED_ACC_NO = P_STDCIF.V_STTMS_LINKEDACC_DETAILS(J)
               .LINKED_ACC_NO AND
                NVL(P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS(I)
                    .LINKED_ACC_IBAN,
                    '123') =
                NVL(P_STDCIF.V_STTMS_LINKEDACC_DETAILS(J).LINKED_ACC_IBAN,
                    '123') AND
                NVL(P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS(I).LINKED_ACC_BIC,
                    '111') =
                NVL(P_STDCIF.V_STTMS_LINKEDACC_DETAILS(J).LINKED_ACC_BIC,
                    '111') AND
                NVL(P_PREV_STDCIF.V_STTMS_LINKEDACC_DETAILS(I).LINKED_ACC_BLZ,
                    '222') =
                NVL(P_STDCIF.V_STTMS_LINKEDACC_DETAILS(J).LINKED_ACC_BLZ,
                    '222')) THEN
              IF P_STDCIF.V_STTMS_LINKEDACC_DETAILS(J).LINKED_ACC_VER = 'N' THEN
                L_WRK_STDCIF := 'Y';
              END IF;
            END IF;
          END LOOP;
        END LOOP;
        DBG('FINAL l_temp' || L_TEMP);
      END IF;
    END IF;
    IF NVL(L_WRK_STDCIF, 'N') = 'Y' THEN
      P_ERR_CODE   := 'ST-LAC-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       P_SOURCE <> 'FLEXCUBE' THEN
    
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO IS NOT NULL THEN
        DBG('validation for kyc ref no' || L_LOV_COUNT1 || ':' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE || ':' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO);
        SELECT COUNT(*)
          INTO L_LOV_COUNT1
          FROM (SELECT KYC_REF_NO, KYC_DESC
                  FROM STTM_KYC_MASTER
                 WHERE RECORD_STAT = 'O'
                   AND ONCE_AUTH = 'Y'
                   AND KYC_CUST_TYPE = DECODE(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE,
                                              'I',
                                              'R',
                                              'C',
                                              'C',
                                              --loan sector sampath changes starts
                                              'U',
                                              'C',
                                              'R',
                                              'C',
                                              'S',
                                              'C',
                                              'N',
                                              'C',
                                              --loan sector sampath changes ends
                                              'B',
                                              'F')
                   AND KYC_REF_NO NOT IN
                       (SELECT KYC_REF_NO
                          FROM STTM_CUSTOMER
                        
                         WHERE KYC_REF_NO IS NOT NULL
                           AND CUSTOMER_NO <>
                               P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO));
        IF L_LOV_COUNT1 = 0 THEN
          DBG('Invalid Value For The Field  :KYC_REF_NO:' ||
              P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO);
          P_ERR_CODE   := 'ST-UPLD99';
          P_ERR_PARAMS := P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO ||
                          '~@STTMS_CUSTOMER.KYC_REF_NO~@STTMS_CUSTOMER';
          RETURN FALSE;
        
        ELSE
        
          SELECT COUNT(*)
            INTO L_LOV_COUNT2
            FROM STTM_KYC_MASTER
           WHERE RECORD_STAT = 'O'
             AND ONCE_AUTH = 'Y'
             AND KYC_CUST_TYPE = DECODE(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE,
                                        'I',
                                        'R',
                                        'C',
                                        'C',
                                        --loan sector sampath changes starts
                                        'U',
                                        'C',
                                        'R',
                                        'C',
                                        'S',
                                        'C',
                                        'N',
                                        'C',
                                        --loan sector sampath changes ends
                                        'B',
                                        'F')
             AND KYC_REF_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO;
          IF L_LOV_COUNT2 = 0 THEN
            DBG('Invalid Value For The Field 2 :KYC_REF_NO:' ||
                P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO);
            P_ERR_CODE   := 'ST-VALS-011';
            P_ERR_PARAMS := P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO ||
                            '~@STTMS_CUSTOMER.KYC_REF_NO~@STTMS_CUSTOMER';
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;
    DBG('After validation for kyc ref no');
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
    
      IF NVL(P_STDCIF.V_STTMS_CUSTOMER.KYC_DETAILS, '#') = 'N' AND
         P_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO IS NOT NULL THEN
      
        P_ERR_CODE   := 'ST-KYC-05';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) AND
       P_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO IS NOT NULL THEN
    
      BEGIN
        SELECT COUNT(*)
          INTO L_REFCOUNT
          FROM STTM_CUSTOMER
         WHERE KYC_REF_NO = P_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in Selecting Source ' || P_SOURCE);
          RETURN FALSE;
      END;
      DBG('g_modify: ' || G_CUST_MODIFY);
    
      IF (L_REFCOUNT > 0 AND NVL(G_CUST_MODIFY, 'N') = 'N') THEN
      
        DBG('KYC Reference Number is not Unique');
        P_ERR_CODE   := 'ST-KYC-03';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_DEFAULT) THEN
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT, 'N') = 'N' THEN
        STPKS_STCCUACC_KERNEL.G_STCCUACC.V_STVWS_AUTO_ACCOUNT.FIELD_NAME := 'SKIP';
      ELSE
        STPKS_STCCUACC_KERNEL.G_STCCUACC.V_STVWS_AUTO_ACCOUNT.FIELD_NAME := NULL;
      END IF;
    END IF;
  
    DBG('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcif_Kernel.Fn_Pre_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

  FUNCTION FN_POST_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                        P_PREV_STDCIF      IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                        P_WRK_STDCIF       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    P_CUST_REC            STPKS_STDCIF_MAIN.TY_STDCIF;
    L_TY_CUST_BASE        STPKS_STDCIF_MAIN.TY_STDCIF;
    P_OVERRIDE_FLAG       VARCHAR2(1);
    P_AUTO_AUTH_FLAG      VARCHAR2(1);
    V_CUSTNO              VARCHAR2(30);
    L_FLAG                NUMBER;
    L_REC_MSG_HEADER      GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER;
    L_BRANCH_AVAIL_STATUS STTM_BRANCH.BRN_AVAIL_STAT%TYPE;
    P_KEY                 VARCHAR2(32767);
  
    P_PARENT            VARCHAR2(32767);
    P_FORMAT            VARCHAR2(32767);
    L_TMP_FMT           VARCHAR2(32767);
    L_UNAUTH_ACC        NUMBER;
    L_CNT_LVL           VARCHAR2(32767);
    L_CNT_CUST          NUMBER;
    L_CNT_JCUST         NUMBER;
    L_CNT_LCUST         NUMBER;
    L_BASE_DATA_FROM_FC VARCHAR2(1) := 'Y';
    L_CNT_LIAB          NUMBER;
  
    L_TOTAL_JV NUMBER := 0;
  
    L_SEG_COUNT NUMBER := 0;
    L_COUNT     NUMBER;
    CURSOR C_UDF_AUX IS
      SELECT *
        FROM STTM_BASE_TABLE_UDF_DETAIL
       WHERE FUNCTION_ID = P_FUNCTION_ID;
    L_COUNT_MIS NUMBER;
    L_MINOR     STTMS_BRANCH.MINOR_AGE%TYPE;
  
    CURSOR CR_CB_CUST_DET IS
      SELECT *
        FROM STTB_CB_BLK_DET
       WHERE BK_EXPDT >= GLOBAL.APPLICATION_DATE;
  
    L_CNT_BLK_CUST NUMBER;
    L_CNT_CB_CUST  NUMBER;
  
    P_MULTI_TRIP_ID VARCHAR2(20);
    P_REQUEST_NO    VARCHAR2(20);
    P_STATUS        VARCHAR2(20);
  
    L_LIMIT_CHECK STTMS_ACCOUNT_CLASS.LIMIT_CHECK_REQUIRED%TYPE;
  
    L_VER_TIME_LMT NUMBER := 0;
    L_CHK_DOCTYPE  NUMBER := 0;
    L_CHK_DOCNAME  NUMBER := 0;
    L_FLD          VARCHAR2(100);
    L_FATCA_APPL   CHAR(1) := NULL;
    E_FAILURE_EXCEPTION EXCEPTION;
  
    L_FREQUENCY NUMBER;
  
    L_STMT_DAY STTM_CUSTOMER.STMT_DAY%TYPE;
  
    L_SET_CNT NUMBER;
  
    CURSOR C_CHKLIST(P_ACT_CODE MFTM_ACTION_CHK_DETAIL.ACTION_CODE%TYPE) IS
      SELECT ITEM_NAME
        FROM MFTM_ACTION_CHK_DETAIL
       WHERE FUNCTION_ID = 'STDCIF'
         AND ACTION_CODE = P_ACT_CODE;
    TYPE TY_CHKLIST IS TABLE OF C_CHKLIST%ROWTYPE;
    L_MFIUSER         VARCHAR2(1);
    L_ACTION_CODE     VARCHAR2(10);
    L_CHKLIST         TY_CHKLIST;
    L_LIMIT_SIZE      NUMBER := 4000;
    L_OFF_TYPE        CLTM_BRANCH_PARAMETERS.OFFICE_TYPE%TYPE;
    L_LEVEL           MFTM_OFFICE_TYPE.LEVEL_NO%TYPE;
    L_GROUP_CODE      MFTM_GROUP_DEFINITION.GROUP_CODE%TYPE;
    L_ACCOUNT_OFFICER STTM_MFI_DETAILS.ACCOUNT_OFFICER%TYPE;
    L_MFI_CUST_TYPE   STTM_MFI_DETAILS.MFI_CUST_TYPE%TYPE;
    CNT1              NUMBER;
    L_COUNT2          NUMBER;
    L_VIRTUAL_COUNT   NUMBER;
    L_COUNT_CLOSURE   NUMBER;
    L_CLOSURE_ALLOWED VARCHAR2(1);
    L_PARAM_VAL       VARCHAR2(1);
    L_VRTL_CUST_COUNT NUMBER;
  
    L_CNT_CUST_ADDRES NUMBER;
    L_KEYID           VARCHAR2(2000);
    L_INTM_CNT        NUMBER := 0;
  
    L_SNCK_STATUS CSTB_SNCK_STATUS.SNCK_STATUS%TYPE;
    L_KEY_ID      STTB_RECORD_MASTER.KEY_ID%TYPE;
  
    L_RES VARCHAR2(2000) := NULL;
  
    CURSOR CR_CUST_CHNNL IS
      SELECT DISTINCT SAC.CHANNEL_ID
        FROM STTMS_ACCOUNT_CHANNEL SAC, STTMS_CUST_ACCOUNT SCA
       WHERE SAC.ACCOUNT_NO = SCA.CUST_AC_NO
         AND SAC.BRANCH_CODE = SCA.BRANCH_CODE
         AND SCA.RECORD_STAT <> 'C'
         AND SCA.ONCE_AUTH = 'Y'
         AND SCA.CUST_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
    L_REC_CHNNL   CR_CUST_CHNNL%ROWTYPE;
    IDX           VARCHAR2(255);
    L_CHNNEL_FLAG BOOLEAN := FALSE;
  
    L_TMP_CNT_1 NUMBER := 0;
    L_TMP_CNT_2 NUMBER := 0;
  
  BEGIN
    DBG('In Fn_Post_Default_And_Validate..');
  
    IF P_ACTION_CODE = 'CUSSNCKSTATUS' THEN
      DBG('This Action code is to display sanction check.. So returning true..');
      RETURN TRUE;
    END IF;
  
    IF P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = 'NEW' THEN
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH IS NULL THEN
        P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH := GLOBAL.CURRENT_BRANCH;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      SELECT COUNT(1)
        INTO L_INTM_CNT
        FROM INTM_INTERMEDIARY
       WHERE INTERMEDIARY_CUSTOMER_NO =
             P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND RECORD_STAT = 'O';
      IF L_INTM_CNT <> 0 THEN
        DBG('Cannot Close a Customer who is linked to an active Intermediary ');
        P_ERR_CODE := 'ST-CUS-102';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    END IF;
  
    P_CUST_REC := P_WRK_STDCIF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      --IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B') THEN --loan sector sampath commented
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN
         ('C', 'B', 'U', 'R', 'S', 'N') THEN
        --loan sector sampath changes
        BEGIN
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.TELEPHONE := NULL;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.FAX       := NULL;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.E_MAIL    := NULL;
        END;
      END IF;
    END IF;
  
    DBG('Inside p_wrk_stdcif.v_sttms_cust_doc_checklist Count check-->' ||
        P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.COUNT);
    DBG('Action Code-->' || P_ACTION_CODE);
    IF P_ACTION_CODE = 'COPY' THEN
      P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.DELETE;
    END IF;
  
    IF P_SOURCE <> 'FLEXCUBE' THEN
      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        --IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B') AND --loan sector sampath commented
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN
           ('C', 'B', 'U', 'R', 'S', 'N') AND --loan sector sampath changes
           NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.STAFF, 'N') = 'Y' THEN
          P_ERR_CODE := 'ST-CIF60';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;
    END IF;
  
    SELECT FATCA_APPLICABLE
      INTO L_FATCA_APPL
      FROM STTMS_BANK
     WHERE ROWNUM = 1;
    IF L_FATCA_APPL = 'Y' AND P_FUNCTION_ID = 'STDCIF' THEN
      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      
        BEGIN
          IF P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.COUNT > 0 THEN
            FOR I IN P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.FIRST .. P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.LAST LOOP
            
              SELECT COUNT(*)
                INTO L_CHK_DOCTYPE
                FROM CSTM_DOCUMENT_TYPE DT, CSTM_DOCUMENTS DS
               WHERE DT.DOC_CATEGORY IN
                     NVL(P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I)
                         .DOC_CATEGORY,
                         DS.DOC_CATEGORY)
                 AND DT.DOCTYPE = P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I)
                    .DOCUMENT_TYPE
                 AND DS.ONCE_AUTH = 'Y'
                 AND DS.RECORD_STAT = 'O';
              L_FLD := 'STTMS_CUST_DOC_CHECKLIST.DOCUMENT_TYPE';
              IF L_CHK_DOCTYPE = 0 THEN
                DBG('Mandatory Key Column Document Type Is not valid');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'ST-MNT-LOV1',
                             '@' || L_FLD);
              END IF;
            
              IF P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I) .
                EXP_SUB_DATE IS NULL THEN
                BEGIN
                  L_FLD := 'STTMS_CUST_DOC_CHECKLIST.EXP_SUB_DATE';
                  SELECT VRFCN_TL_DAYS
                    INTO L_VER_TIME_LMT
                    FROM STTM_CUST_FATCA_DOCS
                   WHERE CUST_TYPE =
                         P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                     AND DOC_CATEGORY = P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I)
                        .DOC_CATEGORY
                     AND DOCTYPE = P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I)
                        .DOCUMENT_TYPE;
                
                  IF SQL%FOUND THEN
                    P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I).EXP_SUB_DATE := P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I)
                                                                               .REQUEST_DATE +
                                                                                L_VER_TIME_LMT;
                  END IF;
                EXCEPTION
                
                  WHEN NO_DATA_FOUND THEN
                  
                    DBG('No data in verification time limit Found ');
                  
                END;
              END IF;
            
            END LOOP;
          END IF;
        
        END;
      END IF;
    END IF;
  
    IF P_SOURCE <> 'FLEXCUBE' THEN
      BEGIN
        SELECT BASE_DATA_FROM_FC
          INTO L_BASE_DATA_FROM_FC
          FROM COTMS_SOURCE
         WHERE SOURCE_CODE = P_SOURCE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in Selecting Source ' || P_SOURCE);
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-VALS-002';
          P_ERR_PARAMS := P_SOURCE;
          RETURN FALSE;
      END;
    END IF;
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      IF P_WRK_STDCIF. V_STTMS_CUSTOMER.MOD_NO IS NULL THEN
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.MOD_NO := P_PREV_STDCIF.
                                                     V_STTMS_CUSTOMER.MOD_NO;
      END IF;
      IF NVL(L_BASE_DATA_FROM_FC, 'N') = 'Y' THEN
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.CHECKER_DT_STAMP := NVL(P_STDCIF.
                                                                   V_STTMS_CUSTOMER.CHECKER_DT_STAMP,
                                                                   FN_MNTSTAMP);
      ELSE
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.CHECKER_DT_STAMP := FN_MNTSTAMP;
      END IF;
    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                            CSPKS_REQ_GLOBAL.P_MODIFY,
                            CSPKS_REQ_GLOBAL.P_CLOSE,
                            CSPKS_REQ_GLOBAL.P_REOPEN) THEN
      P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.AUTH_STAT := 'U';
      P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.MAKER_ID  := GLOBAL.USER_ID;
      IF NVL(L_BASE_DATA_FROM_FC, 'N') = 'Y' THEN
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.MAKER_DT_STAMP := FN_MNTSTAMP;
      ELSE
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.MAKER_DT_STAMP := FN_MNTSTAMP;
      END IF;
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.MOD_NO      := 1;
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.RECORD_STAT := 'O';
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ONCE_AUTH   := 'N';
      ELSE
        DBG('MOD NO-->' || P_PREV_STDCIF.V_LMTMS_ISSUER_MASTER.MOD_NO);
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.MOD_NO      := NVL(P_PREV_STDCIF.V_LMTMS_ISSUER_MASTER.MOD_NO,
                                                              0) + 1;
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ONCE_AUTH   := NVL(P_PREV_STDCIF.V_LMTMS_ISSUER_MASTER.ONCE_AUTH,
                                                              'N');
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.RECORD_STAT := NVL(P_PREV_STDCIF.V_LMTMS_ISSUER_MASTER.RECORD_STAT,
                                                              'O');
        DBG('MOD NO11-->' || P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.MOD_NO);
      END IF;
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
        P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.RECORD_STAT := 'C';
      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
        P_WRK_STDCIF. V_STTMS_CUSTOMER.RECORD_STAT := 'O';
      END IF;
      P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.CHECKER_ID       := NULL;
      P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.CHECKER_DT_STAMP := NULL;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) THEN
    
      FOR ECH_CB_CUST IN CR_CB_CUST_DET LOOP
      
        DBG('inside loop for checking the match of cb details');
        --IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN --loan sector sampath commented
          IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN
           ('C', 'U', 'R', 'S', 'N') THEN
          --loan sector sampath changes
          IF ECH_CB_CUST.CUST_TAX_ID =
             P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE THEN
            DBG('cust taxid matches with the cb det');
            P_ERR_CODE := P_ERR_CODE || 'ST-NSFAC2';
            RETURN FALSE;
          ELSIF ECH_CB_CUST.CUST_NAME =
                P_WRK_STDCIF.V_STTMS_CUSTOMER.FULL_NAME AND
                ECH_CB_CUST.CUST_DOB =
                P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE THEN
            DBG('cust corp dob matches with the cb det');
            P_ERR_CODE := P_ERR_CODE || 'ST-NSFAC2';
            RETURN FALSE;
          END IF;
        
        ELSE
          IF ECH_CB_CUST.CUST_TAX_ID =
             P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE THEN
            DBG('cust taxid matches with the cb det');
            P_ERR_CODE := P_ERR_CODE || 'ST-NSFAC2';
            RETURN FALSE;
          ELSIF ECH_CB_CUST.CUST_NAME =
                P_WRK_STDCIF.V_STTMS_CUSTOMER.FULL_NAME AND
                ECH_CB_CUST.CUST_DOB =
                P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH THEN
            DBG('cust personal dob matches with the cb det');
            P_ERR_CODE := P_ERR_CODE || 'ST-NSFAC2';
            RETURN FALSE;
          END IF;
        END IF;
      END LOOP;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('inside the condition for checking blacklisted customer');
      BEGIN
        SELECT COUNT(1)
          INTO L_CNT_BLK_CUST
          FROM STTB_CUST_NSF_CON_DET
         WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND (NSFIB_IB_BLK_STAT = 'Y' AND
               NSFIB_IB_BLK_EXPDT > GLOBAL.APPLICATION_DATE OR
               NSFIB_CS_WBRCK_STAT = 'Y');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in sttb_cust_nsf_con_det for blacklist');
          L_CNT_BLK_CUST := 0;
      END;
    
      DBG('count->' || L_CNT_BLK_CUST);
    
      BEGIN
        SELECT COUNT(1)
          INTO L_CNT_CB_CUST
          FROM STTB_CB_BLK_DET
         WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND BK_EXPDT > GLOBAL.APPLICATION_DATE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in sttb_cb_blk_det for blacklist');
          L_CNT_CB_CUST := 0;
      END;
    
      IF (L_CNT_BLK_CUST > 0 AND L_CNT_CB_CUST > 0) THEN
        DBG('The customer is both internally and central bank blacklisted customer');
      
        P_ERR_CODE := 'ST-NSFAC13';
      
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'p_err_code', P_ERR_PARAMS);
      
      END IF;
    
      IF L_CNT_BLK_CUST > 0 THEN
        DBG('The customer is internally blacklisted customer');
      
        P_ERR_CODE := 'ST-NSFAC11';
      
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'p_err_code', P_ERR_PARAMS);
      
      END IF;
    
      IF L_CNT_CB_CUST > 0 THEN
        DBG('The customer is Central bank blacklisted customer');
      
        P_ERR_CODE := 'ST-NSFAC12';
      
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'p_err_code', P_ERR_PARAMS);
      
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DEBUG.PR_DEBUG('ST',
                     ' Joint Venture Flag' ||
                     P_WRK_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE);
      DEBUG.PR_DEBUG('ST',
                     'Validation Checking If Joint Venture is  Applicable');
      DEBUG.PR_DEBUG('ST',
                     ' p_wrk_stdcif.v_sttms_cust_jv.count-->' ||
                     P_WRK_STDCIF.V_STTMS_CUST_JV.COUNT);
      IF P_WRK_STDCIF.V_STTMS_CUST_JV.COUNT = 0 AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE = 'Y' THEN
        DBG('When JOINT VENTURE is ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE ||
            'Details should be provided');
        P_ERR_CODE   := 'ST-CIF-001';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
      IF P_WRK_STDCIF.V_STTMS_CUST_JV.COUNT > 0 AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE = 'N' THEN
        DBG('When JOINT VENTURE is' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE ||
            'Details should not be provided');
        P_ERR_CODE   := 'ST-CIF-002';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE = 'Y' AND
         P_WRK_STDCIF.V_STTMS_CUST_JV.COUNT > 0 THEN
        FOR I IN P_WRK_STDCIF.V_STTMS_CUST_JV.FIRST .. P_WRK_STDCIF.V_STTMS_CUST_JV.LAST LOOP
          L_TOTAL_JV := L_TOTAL_JV + P_WRK_STDCIF.V_STTMS_CUST_JV(I)
                       .PARTY_RATIO;
        END LOOP;
        IF L_TOTAL_JV <> 100 THEN
          P_ERR_CODE   := 'ST-CIF-003';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.LC_COLLATERAL_PCT < 0 OR
         P_WRK_STDCIF.V_STTMS_CUSTOMER.LC_COLLATERAL_PCT > 100 THEN
        DBG('collateral percent cannot be negative OR Cannot exceed 100');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF-000', '');
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
    
      IF P_WRK_STDCIF.V_STTMS_MFI_DETAILS.MFI_CUST_TYPE NOT IN ('G', 'C') THEN
      
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
           P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.SEX IS NULL THEN
          DBG('Gender is not input for the customer');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIF98', '');
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      IF NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.ELCM_CUSTOMER, 'N') = 'Y' AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.ELCM_CUSTOMER = 'N' THEN
        DBG('Cannot Change ELCM Customer Flag from Y to N');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF109', '');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = STPKS_FCMAINT_SERVICE.P_CLOSE THEN
      SELECT COUNT(*)
        INTO L_CNT_CUST
        FROM STTB_ACCOUNT
      
       WHERE AC_GL_REC_STATUS IN ('O', 'A')
         AND AC_OR_GL != 'L'
         AND CUST_NO = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
    
      DBG('after closing chekcing count-->' || L_CNT_CUST);
      DEBUG.PR_DEBUG('CU',
                     'Count from active/open sttb_account ' || L_CNT_CUST);
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(1)
          INTO L_CNT_CUST
          FROM CSTBS_CONTRACT
         WHERE CONTRACT_STATUS IN ('A', 'Y')
           AND COUNTERPARTY = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND MODULE_CODE <> 'DE';
        DEBUG.PR_DEBUG('CU',
                       'Count from active cstbs_Contract ' || L_CNT_CUST);
      END IF;
      DBG('after closing chekcing count 2-->' || L_CNT_CUST);
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(1)
          INTO L_CNT_CUST
          FROM STTM_CUST_ACCOUNT
         WHERE RECORD_STAT = 'O'
           AND CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        DEBUG.PR_DEBUG('CU',
                       'Count from active sttm_cust_account ' || L_CNT_CUST);
      END IF;
      DBG('after closing chekcing count3-->' || L_CNT_CUST);
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(1)
          INTO L_CNT_CUST
          FROM LCTBS_PARTIES A, LCTBS_CONTRACT_MASTER B, CSTBS_CONTRACT C
         WHERE A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
           AND B.CONTRACT_REF_NO = C.CONTRACT_REF_NO
           AND A.EVENT_SEQ_NO =
               (SELECT MAX(D.EVENT_SEQ_NO)
                  FROM LCTBS_CONTRACT_MASTER D
                 WHERE D.CONTRACT_REF_NO = B.CONTRACT_REF_NO)
           AND C.CONTRACT_STATUS IN ('A', 'Y')
           AND A.CIF_ID = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        DEBUG.PR_DEBUG('CU', 'Count from active LC Parties ' || L_CNT_CUST);
      END IF;
      DBG('after closing chekcing count4-->' || L_CNT_CUST);
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(1)
          INTO L_CNT_CUST
          FROM BCTBS_CONTRACT_PARTIES A,
               BCTBS_CONTRACT_MASTER  B,
               CSTBS_CONTRACT         C
         WHERE A.BCREFNO = B.BCREFNO
           AND B.BCREFNO = C.CONTRACT_REF_NO
           AND A.EVENT_SEQ_NO =
               (SELECT MAX(D.EVENT_SEQ_NO)
                  FROM BCTBS_CONTRACT_MASTER D
                 WHERE D.BCREFNO = B.BCREFNO)
           AND C.CONTRACT_STATUS IN ('A', 'Y')
           AND A.PARTY_ID = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        DEBUG.PR_DEBUG('CU',
                       'Count from active Bills Parties ' || L_CNT_CUST);
      END IF;
      DBG('after closing chekcing count5-->' || L_CNT_CUST);
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(1)
          INTO L_CNT_CUST
          FROM GETM_FACILITY A, GETM_LIAB_CUST B
         WHERE A.LIAB_ID = B.LIAB_ID
           AND A.RECORD_STAT = 'O'
           AND B.RECORD_STAT = 'O'
           AND B.CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        DEBUG.PR_DEBUG('CU', 'Count from active Limits ' || L_CNT_CUST);
      END IF;
      DBG('after closing chekcing count 6-->' || L_CNT_CUST);
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(1)
          INTO L_CNT_CUST
          FROM GETM_COLLAT A, GETM_LIAB_CUST B
         WHERE A.LIAB_ID = B.LIAB_ID
           AND A.RECORD_STAT = 'O'
           AND B.RECORD_STAT = 'O'
           AND B.CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        DEBUG.PR_DEBUG('CU',
                       'Count from active Collaterals ' || L_CNT_CUST);
      END IF;
      DBG('after closing chekcing count 7-->' || L_CNT_CUST);
    
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(1)
          INTO L_CNT_CUST
          FROM GETM_COLLAT_GUARANTEE
         WHERE GUARANTOR_CIF_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      
        DBG('Count from  Guarantor CIF which is attached at Collateral level. ' ||
            L_CNT_CUST);
      END IF;
      DBG('after closing chekcing count 8-->' || L_CNT_CUST);
    
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(1)
          INTO L_CNT_CUST
          FROM PCTBS_CONTRACT_MASTER A
         WHERE A.CONTRACT_STATUS IN ('A')
           AND A.CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        DEBUG.PR_DEBUG('CO', 'Count from PC Contracts.. ' || L_CNT_CUST);
      END IF;
    
      IF L_CNT_CUST = 0 THEN
      
        SELECT COUNT(*)
          INTO L_CNT_CUST
          FROM SITBS_INSTRUCTION A
         WHERE COUNTERPARTY = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND INST_VERSION_NO = LATEST_VERSION_NO
           AND (INST_STATUS IN ('A') OR
               (AUTH_STATUS = 'U' AND INST_STATUS IN ('S')));
      
        DEBUG.PR_DEBUG('CO', 'Count from SI Contracts.. ' || L_CNT_CUST);
      END IF;
    
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(*)
          INTO L_CNT_CUST
          FROM CLTB_ACCOUNT_MASTER
        
         WHERE ACCOUNT_STATUS NOT IN ('L', 'V', 'C')
              
           AND CUSTOMER_ID = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END IF;
      DBG('after closing chekcing count final->' || L_CNT_CUST);
    
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(*)
          INTO L_CNT_CUST
          FROM CLTB_ACCOUNT_PARTIES A
         WHERE CUSTOMER_ID = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND EFFECTIVE_DATE =
               (SELECT MAX(EFFECTIVE_DATE)
                  FROM CLTB_ACCOUNT_PARTIES C
                 WHERE C.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
                   AND C.BRANCH_CODE = A.BRANCH_CODE)
           AND ((LIABILITY IS NOT NULL AND LIABILITY > 0) OR
               (LIABILITY_AMT IS NOT NULL AND LIABILITY_AMT > 0))
           AND EXISTS (SELECT 1
                  FROM CLTB_ACCOUNT_MASTER B
                 WHERE B.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
                   AND B.BRANCH_CODE = A.BRANCH_CODE
                   AND ACCOUNT_STATUS IN ('A', 'Y'));
      END IF;
    
      IF L_CNT_CUST = 0 THEN
        SELECT COUNT(*)
          INTO L_CNT_CUST
          FROM CSTBS_RELATIONSHIP_LINKAGE A
         WHERE CUSTOMER = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND CATEGORY = 'A'
           AND EXISTS (SELECT 1
                  FROM STTMS_CUST_ACCOUNT B
                 WHERE B.BRANCH_CODE = A.BRANCH
                   AND B.CUST_AC_NO = A.REF_NO
                   AND B.RECORD_STAT = 'O');
      END IF;
    
      SELECT COUNT(*)
        INTO L_UNAUTH_ACC
        FROM STTB_RECORD_MASTER
       WHERE FUNCTION_ID = 'STDCUSAC'
         AND CHAR_FLD_4 = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO
         AND AUTH_STAT = 'U'
         AND RECORD_STAT = 'O';
      IF L_CNT_CUST > 0 OR L_UNAUTH_ACC > 0 THEN
        DBG('Cannot Close the customer as Active Contracts Exists SVB shash');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS54', '');
        RETURN FALSE;
      END IF;
      SELECT COUNT(*)
        INTO L_CNT_JCUST
        FROM STTMS_AC_LINKED_ENTITIES
       WHERE JOINT_HOLDER_CODE = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND CUST_AC_NO IN (SELECT CUST_AC_NO
                              FROM STTM_CUST_ACCOUNT
                             WHERE RECORD_STAT = 'O'
                               AND ONCE_AUTH = 'Y');
      IF L_CNT_JCUST > 0 THEN
        DBG('Cannot Close the customer as it is linked to active account as joint holder');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS84', '');
        RETURN FALSE;
      END IF;
    
      DBG('p_action_code for checking address' || P_ACTION_CODE);
      L_KEYID := '~MSTM_CUST_ADDRESS~' ||
                 P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO || '~CIF~' ||
                 P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA || '~';
      SELECT COUNT(1)
        INTO L_CNT_CUST_ADDRES
        FROM STTB_RECORD_MASTER
       WHERE FUNCTION_ID = 'MSDCUSAD'
         AND AUTH_STAT = 'U'
         AND KEY_ID = L_KEYID;
      IF L_CNT_CUST_ADDRES > 0 THEN
        DBG('Cannot close,Either Address is Unauthorised and Open');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS-101', '');
        RETURN FALSE;
      END IF;
    
      SELECT COUNT(*)
        INTO L_CNT_LCUST
        FROM CSTB_RELATIONSHIP_LINKAGE
       WHERE CATEGORY = 'A'
         AND CUSTOMER = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND REF_NO IN (SELECT CUST_AC_NO
                          FROM STTM_CUST_ACCOUNT
                         WHERE RECORD_STAT = 'O'
                           AND ONCE_AUTH = 'Y');
      IF L_CNT_LCUST > 0 THEN
        DBG('Cannot Close the customer as it is linked to active account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS85', '');
        RETURN FALSE;
      END IF;
    
      SELECT COUNT(*)
        INTO L_SET_CNT
        FROM ISTMS_INSTR
       WHERE COUNTERPARTY = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      DBG('FCUBS_12.2.0.0.0_SUPPORT_24707144:l_set_cnt' || L_SET_CNT);
      IF L_SET_CNT > 0 THEN
        DBG('FCUBS_12.2.0.0.0_SUPPORT_24707144:Cannot Close the customer as settlement instruction is active for customer');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IS-CLS891', '');
      END IF;
    
      SELECT COUNT(*)
        INTO L_CNT_LIAB
        FROM GETM_LIAB_CUST
       WHERE RECORD_STAT = 'O'
         AND CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('## l_cnt_liab ' || L_CNT_LIAB);
      IF L_CNT_LIAB > 0 THEN
        DBG('## Cannot Close the customer as it is linked to active liab');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS86', '');
        RETURN FALSE;
      END IF;
    
      SELECT COUNT(*)
        INTO L_CNT_CUST
        FROM STTM_CARD_CUSTOMER
       WHERE RECORD_STAT = 'O'
         AND CUSTOMER_ID = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      IF L_CNT_CUST > 0 THEN
        DBG('## Cannot Close the customer as it is linked to active card');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS-086', '');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
    
      DBG('In pickup');
      IF NOT STPKS_STDCIF_UTILS_0.FN_PICKUP(P_FUNCTION_ID,
                                            P_WRK_STDCIF.
                                            V_STTMS_CUSTOMER.CUSTOMER_NO,
                                            P_WRK_STDCIF,
                                            P_KEY,
                                            P_PARENT,
                                            P_FORMAT,
                                            L_TMP_FMT,
                                            L_CNT_LVL,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
        DBG('Error Inside Function fn_CustMis' || SQLERRM);
      END IF;
    END IF;
  
    DBG('Function id :- ' || CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'));
    IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('FUNCTIONID') AND
       CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') <> 'STDCIFAD' THEN
      DBG('Function id :- ' || CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'));
      PR_POPULAT_AUX_UDF(P_STDCIF, P_WRK_STDCIF, P_ACTION_CODE);
    
    ELSE
      IF P_FUNCTION_ID = 'STDCIF' THEN
        PR_POPULAT_AUX_UDF(P_STDCIF, P_WRK_STDCIF, P_ACTION_CODE);
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = 'MODIFY' THEN
      IF P_WRK_STDCIF. V_STTMS_CUSTOMER.DECEASED = 'Y' THEN
      
        IF P_WRK_STDCIF. V_STTMS_CUSTOMER.FROZEN = 'Y' OR P_WRK_STDCIF.
         V_STTMS_CUSTOMER.WHEREABOUTS_UNKNOWN = 'Y' THEN
          P_ERR_CODE   := 'ST-CIF156';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = 'NEW' THEN
    
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER, 'N') = 'Y' THEN
        BEGIN
          SELECT OFFICE_TYPE
            INTO L_OFF_TYPE
            FROM CLTM_BRANCH_PARAMETERS
           WHERE BRANCH_CODE = P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH
             AND MODULE_ID = 'MF';
          DBG('OFFICE TYPE IS ' || L_OFF_TYPE);
          SELECT LEVEL_NO
            INTO L_LEVEL
            FROM MFTM_OFFICE_TYPE
           WHERE OFFICE_TYPE = L_OFF_TYPE;
          DBG('LEVEL  IS ' || L_LEVEL);
          IF L_LEVEL <> 6 THEN
            DBG('Customer can be created only at branch level 6');
            P_ERR_CODE := 'MF-CIF-015';
            RETURN FALSE;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('IN NO DATA FOUND');
          WHEN OTHERS THEN
            DBG('NO DATA FOUND--->');
        END;
      END IF;
    
      IF (P_WRK_STDCIF. V_STTMS_CUSTOMER.FROZEN = 'Y' OR P_WRK_STDCIF.
          V_STTMS_CUSTOMER.DECEASED = 'Y' OR P_WRK_STDCIF.
          V_STTMS_CUSTOMER.WHEREABOUTS_UNKNOWN = 'Y') THEN
        P_ERR_CODE   := 'ST-CIF146';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    
      BEGIN
        SELECT CUSTOMER_NO
          INTO V_CUSTNO
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('new customer ,going to insert record');
      END;
      DBG('ssn - ' || P_WRK_STDCIF. V_STTMS_CUSTOMER.SSN);
      IF V_CUSTNO IS NOT NULL AND P_ACTION_CODE = 'BPELDEFAULT' THEN
        L_FLAG := 0;
        DBG('Succcessfully Returned from Function Handler -FlgStatus: ' ||
            L_FLAG);
        DBG('Skipping sys for BPEL op');
        STPKS_STDCIF_MAIN.PR_SET_SKIP_SYS;
      ELSIF V_CUSTNO IS NULL AND P_ACTION_CODE = 'BPELDEFAULT' THEN
        DBG('going to insert record for action bpelvalidate');
      END IF;
    
      IF P_WRK_STDCIF. V_STTMS_CUSTOMER.TRACK_LIMITS IS NULL THEN
        P_WRK_STDCIF. V_STTMS_CUSTOMER.TRACK_LIMITS := 'N';
      END IF;
    
      DBG(' Customer Number in Post Default' || P_WRK_STDCIF.
          V_STTMS_CUSTOMER.CUSTOMER_NO);
    
      IF P_WRK_STDCIF. V_STTMS_CUSTOMER.FX_NETTING_CUSTOMER IS NULL THEN
        P_WRK_STDCIF. V_STTMS_CUSTOMER.FX_NETTING_CUSTOMER := P_WRK_STDCIF.
                                                              V_STTMS_CUSTOMER.CUSTOMER_NO;
      END IF;
    
      BEGIN
        DBG('cspks_req_global.g_headerBRANCH==>' ||
            CSPKS_REQ_GLOBAL.G_HEADER('BRANCH'));
      EXCEPTION
        WHEN OTHERS THEN
          CSPKS_REQ_GLOBAL.G_HEADER('BRANCH') := GLOBAL.CURRENT_BRANCH;
          CSPKS_REQ_GLOBAL.PR_INIT;
      END;
      DBG('cspks_req_global.g_headerBRANCH==>' ||
          CSPKS_REQ_GLOBAL.G_HEADER('BRANCH'));
    
      IF CSPKS_REQ_GLOBAL.G_HEADER('BRANCH') <> P_WRK_STDCIF.
       V_STTMS_CUSTOMER.LOCAL_BRANCH THEN
        DBG('Branch code passed in the FCUBS_HEADER and FCUBS_BODY are different. Cannot proceed');
        P_ERR_CODE   := 'GW-ROUT0018';
        P_ERR_PARAMS := CSPKS_REQ_GLOBAL.G_HEADER('BRANCH') || '~' ||
                        P_WRK_STDCIF. V_STTMS_CUSTOMER.LOCAL_BRANCH || '~';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      BEGIN
        SELECT NVL(BRN_AVAIL_STAT, 'Y')
          INTO L_BRANCH_AVAIL_STATUS
          FROM STTM_BRANCH
         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
      EXCEPTION
        WHEN OTHERS THEN
          RETURN FALSE;
      END;
    
      P_WRK_STDCIF. V_STTMS_CUSTOMER.CIF_CREATION_DATE := GLOBAL.APPLICATION_DATE;
      IF L_BRANCH_AVAIL_STATUS = 'N' THEN
        P_WRK_STDCIF. V_STTMS_CUSTOMER.CIF_CREATION_DATE := CEPKSS_DATE.FN_GETNEXTWDAY(GLOBAL.CURRENT_BRANCH);
      END IF;
    
      BEGIN
        DBG('cspks_req_global.g_headerSOURCE==>' ||
            CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));
      EXCEPTION
        WHEN OTHERS THEN
          CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') := P_SOURCE;
      END;
      DBG('cspks_req_global.g_headerSOURCE==>' ||
          CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));
      DBG('p_wrk_stdcif.v_sttms_customer.Liability_No==>' ||
          P_WRK_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO);
    
      IF NOT STPKS_STDCIF_UTILS_0.FN_UPLOAD_NEW_CUSTOMER(P_FUNCTION_ID,
                                                         P_WRK_STDCIF,
                                                         CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'),
                                                         P_OVERRIDE_FLAG,
                                                         P_AUTO_AUTH_FLAG,
                                                         L_REC_MSG_HEADER,
                                                         L_TY_CUST_BASE,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
        DBG('Save Error Code #### ' || P_ERR_CODE);
        DBG('Error Message ##### ' || P_ERR_PARAMS);
      
        RETURN FALSE;
      ELSE
        DBG('p_wrk_stdcif.v_sttms_customer.Liability_No==>' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO);
        DBG('Upload is Success');
      END IF;
    END IF;
    IF P_ACTION_CODE = 'MODIFY' THEN
      IF NOT STPKS_STDCIF_UTILS_0.FN_UPLOAD_MODIFY_CUSTOMER(P_FUNCTION_ID,
                                                            P_WRK_STDCIF
                                                            
                                                           ,
                                                            CSPKS_REQ_GLOBAL.G_HEADER('SOURCE')
                                                            
                                                           ,
                                                            CSPKS_REQ_GLOBAL.G_HEADER('SOURCE_OPERATION')
                                                            
                                                           ,
                                                            L_REC_MSG_HEADER,
                                                            P_AUTO_AUTH_FLAG,
                                                            P_WRK_STDCIF,
                                                            P_ERR_CODE,
                                                            P_OVERRIDE_FLAG,
                                                            P_ERR_PARAMS) THEN
        DBG('Error Code #### ' || P_ERR_CODE);
        DBG('Error Message ##### ' || P_ERR_PARAMS);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      ELSE
        DBG('Upload is Success');
      END IF;
    END IF;
  
    DBG('p_Cust_Rec.ty_cust_mt920_upld.Count is ' ||
        P_WRK_STDCIF.V_STTMS_CUST_MT920_MAINT.COUNT);
    IF P_WRK_STDCIF.V_STTMS_CUST_MT920_MAINT.COUNT > 0 AND P_WRK_STDCIF.
     V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      P_ERR_CODE   := 'ST-CIF81';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
    IF P_WRK_STDCIF.V_STTMS_CUST_MT920_MAINT.COUNT > 0 AND P_WRK_STDCIF.
     V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B', 'U', 'R', 'S', 'N') AND
       P_WRK_STDCIF. --loan sector sampath changes
     V_STTMS_CUSTOMER.GENERATE_MT920 = 'N' THEN
      P_ERR_CODE   := 'ST-CIF82';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.CIF_STATUS IS NOT NULL THEN
      IF P_CUST_REC.V_STTMS_CUSTOMER.CIF_STATUS_SINCE IS NULL THEN
        IF P_ACTION_CODE = 'NEW' THEN
          P_WRK_STDCIF. V_STTMS_CUSTOMER.CIF_STATUS_SINCE := GLOBAL.APPLICATION_DATE;
        
        ELSIF P_ACTION_CODE = 'MODIFY' THEN
          IF NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.CIF_STATUS, '@#') <>
             NVL(P_CUST_REC.V_STTMS_CUSTOMER.CIF_STATUS, '@#') THEN
            P_WRK_STDCIF. V_STTMS_CUSTOMER.CIF_STATUS_SINCE := GLOBAL.APPLICATION_DATE;
          ELSE
            P_WRK_STDCIF. V_STTMS_CUSTOMER.CIF_STATUS_SINCE := P_PREV_STDCIF.V_STTMS_CUSTOMER.CIF_STATUS_SINCE;
          END IF;
        END IF;
      ELSE
        IF P_CUST_REC.V_STTMS_CUSTOMER.CIF_STATUS_SINCE <
           GLOBAL.APPLICATION_DATE AND P_ACTION_CODE = 'NEW' THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'LS-DD-012',
                       'CIF Status Since~Application Date');
        END IF;
      
        IF P_ACTION_CODE = 'MODIFY' AND
           NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.CIF_STATUS, '@#') <>
           NVL(P_CUST_REC.V_STTMS_CUSTOMER.CIF_STATUS, '@#') AND
           P_CUST_REC.V_STTMS_CUSTOMER.CIF_STATUS_SINCE <
           GLOBAL.APPLICATION_DATE THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'LS-DD-012',
                       'CIF Status Since~Application Date');
        END IF;
      
      END IF;
    ELSE
      IF P_CUST_REC.V_STTMS_CUSTOMER.CIF_STATUS_SINCE IS NOT NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'SE-MA0518',
                     'CIF Status Since~CIF Status');
      END IF;
    END IF;
  
    DBG('p_action_code ---- >' || P_ACTION_CODE);
    IF P_ACTION_CODE <> CSPKS_REQ_GLOBAL.P_AUTH THEN
      DBG('ISSUER_CUSTOMER ---- >' || P_STDCIF.
          V_STTMS_CUSTOMER.ISSUER_CUSTOMER);
      IF P_WRK_STDCIF. V_STTMS_CUSTOMER.ISSUER_CUSTOMER IN ('Y') THEN
        IF (P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT IS NULL OR
           P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY IS NULL) THEN
          DBG('inside validation ISSUER_CUSTOMER 1');
          P_ERR_CODE   := 'ST-CIF150';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
        DBG('ISSUER_CUSTOMER DETAILS ---- >' ||
            P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT.COUNT);
        IF P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT.COUNT = 0 THEN
          DBG('inside validation ISSUER_CUSTOMER 2');
          P_ERR_CODE   := 'ST-CIF151';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        ELSE
          DBG('inside validation ISSUER_CUSTOMER 3');
          FOR I IN P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT.FIRST .. P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT.LAST LOOP
            DBG('COLLATERAL_TYPE-->' || P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT(I)
                .COLLATERAL_TYPE);
            DBG('LIMIT_AMOUNT' || P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT(I)
                .LIMIT_AMOUNT);
            DBG('LIMIT_CURRENCY--->' || P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT(I)
                .LIMIT_CURRENCY);
            IF (P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT(I).COLLATERAL_TYPE IS NULL OR P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT(I)
               .LIMIT_AMOUNT = 0 OR P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT(I)
               .LIMIT_CURRENCY IS NULL) THEN
              P_ERR_CODE   := 'SD-LM-00001';
              P_ERR_PARAMS := NULL;
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);
              RETURN FALSE;
            END IF;
          END LOOP;
        END IF;
      ELSE
        BEGIN
          DBG('customer no--->' || P_WRK_STDCIF.
              V_STTMS_CUSTOMER.CUSTOMER_NO);
          DELETE FROM LMTMS_ISSUER_MASTER
           WHERE ISSUER_ID = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
          P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT     := '';
          P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY := '';
        
          P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_CIF_ID := '';
          P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_ID     := '';
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('inside no data found');
            P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT     := '';
            P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY := '';
          
            P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_CIF_ID := '';
            P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_ID     := '';
          
          WHEN OTHERS THEN
            DBG('inside others');
        END;
        P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT.DELETE;
        DBG('ISSUER_CUSTOMER DETAILS here ---- >' ||
            P_WRK_STDCIF.V_LMTMS_ISSUER_LIMIT.COUNT);
      END IF;
    END IF;
  
    DBG('BEFROE  HEREEE');
    IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER, 'N') = 'Y' THEN
      DBG('FAILED HEREEE');
      IF P_ACTION_CODE IN ('NEWW', 'CLOS', 'MODFY') THEN
        IF P_ACTION_CODE = 'MODFY' THEN
          L_ACTION_CODE := 'UNLOCK';
        ELSIF P_ACTION_CODE = 'NEWW' THEN
          L_ACTION_CODE := 'NEW';
        END IF;
        DBG('action_code : ' || L_ACTION_CODE);
        OPEN C_CHKLIST(L_ACTION_CODE);
        LOOP
          FETCH C_CHKLIST BULK COLLECT
            INTO L_CHKLIST LIMIT L_LIMIT_SIZE;
          EXIT WHEN C_CHKLIST%NOTFOUND;
        END LOOP;
        IF L_CHKLIST.COUNT > 0 THEN
          FOR I IN L_CHKLIST.FIRST .. L_CHKLIST.LAST LOOP
            DBG('BEFORE INSERT INTO mftb_mfi_checklist');
            P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST(I).KEY_ID := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
            P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST(I).CHKLIST_ITEM := L_CHKLIST(I)
                                                                  .ITEM_NAME;
            P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST(I).VERIFIED := 'N';
            P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST(I).ACTION_CODE := L_ACTION_CODE;
            P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST(I).FUNCTION_ID := 'STDCIF';
            DBG('AFTER INSERT INTO mftb_mfi_checklist');
          END LOOP;
        END IF;
        DBG(P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST.COUNT || 'ROWS FETCHED');
        CLOSE C_CHKLIST;
      END IF;
    END IF;
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER, 'N') = 'N' THEN
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.CUSTOMER_NO           := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.INSURANCE_NUMBER      := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.ACCOUNT_OFFICER       := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.MFI_CUST_TYPE         := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.POVERTY_STATUS        := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.LITERACY_OF_CLIENT    := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.BUSINESS_ACTIVITY     := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.BLACKLISTED           := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.BLACKLIST_COUNT       := '';
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.PHYSICALLY_CHALLENGED := '';
        P_WRK_STDCIF.V_MFTBS_CUST_ID_MASTER.DELETE;
        P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST.DELETE;
      ELSE
        IF P_WRK_STDCIF.V_STTMS_MFI_DETAILS.INSURANCE_NUMBER IS NULL THEN
          DBG('MFI_CUSTOMER-->' ||
              P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER);
          P_ERR_CODE   := 'MF-CIF-007';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        
        END IF;
      END IF;
    END IF;
    IF P_ACTION_CODE IN ('NEW', 'AUTH', 'CLOSE', 'MODIFY') THEN
      DBG('INSIDE 1111');
      IF P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST.COUNT > 0 THEN
        FOR I IN P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST.FIRST .. P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST.LAST LOOP
          DBG('Verified: ' || I || '-' || P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST(I)
              .VERIFIED);
          IF P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST(I).VERIFIED = 'N' THEN
            DEBUG.PR_DEBUG('**', 'Please check/verify all the checklist');
            P_ERR_CODE   := 'MF-CIF-005';
            P_ERR_PARAMS := P_WRK_STDCIF.V_MFTBS_MFI_CHECKLIST(I).VERIFIED;
            RETURN FALSE;
          END IF;
        END LOOP;
      END IF;
    END IF;
    IF P_ACTION_CODE IN ('NEW', 'MODIFY', 'AUTH') THEN
      DBG('first name is-->' ||
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.FIRST_NAME);
      DBG('second name is-->' ||
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.LAST_NAME);
      DBG('last name is-->' ||
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH);
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER, 'N') = 'Y' THEN
        IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.FIRST_NAME IS NOT NULL AND
           P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.LAST_NAME IS NOT NULL AND
           P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH IS NOT NULL THEN
          BEGIN
          
            SELECT COUNT(1)
              INTO L_COUNT
              FROM STTMS_CUST_PERSONAL
             WHERE FIRST_NAME =
                   P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.FIRST_NAME
               AND LAST_NAME = P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.LAST_NAME
               AND DATE_OF_BIRTH =
                   P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH
               AND CUSTOMER_NO <> P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_COUNT2 := 0;
            WHEN OTHERS THEN
              RETURN FALSE;
          END;
        
          IF L_COUNT2 > 0
          
           THEN
            DBG('DUPLICATE CUSTOMER');
            P_ERR_CODE   := 'MF-CIF-009';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          END IF;
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('p_Prev_stdcif.ty_miccustm.v_mitmS_default_codes.COUNT' ||
          P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES.COUNT);
      IF P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES.COUNT > 0 THEN
        FOR REC IN P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES.FIRST .. P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES.LAST LOOP
          DBG('p_Prev_stdcif.ty_miccustm.v_mitms_default_codes(REC)
            .MIS_CLASS--->' || P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(REC)
              .MIS_CLASS || '~');
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT_MIS
              FROM MITMS_DEFAULT_CODES B
             WHERE B.KEY_ID = P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO
               AND B.MIS_CLASS = P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(REC)
                  .MIS_CLASS;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('error occured' || SQLERRM);
              RETURN FALSE;
          END;
          DBG('l_count_mis--->' || L_COUNT_MIS);
          IF L_COUNT_MIS = 0 THEN
            DBG('BEFORE DELETE');
            P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(REC).KEY_ID := NULL;
            P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(REC).MIS_CLASS := NULL;
            P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(REC).MIS_TYPE := NULL;
            P_PREV_STDCIF.TY_MICCUSTM.V_MITMS_DEFAULT_CODES(REC).MIS_CODE := NULL;
            DBG('AFTER DELETE');
          END IF;
        END LOOP;
      END IF;
    END IF;
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('p_Prev_stdcif.ty_miccustm.v_mitm_default_codes__c.COUNT' ||
          P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C.COUNT);
      IF P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C.COUNT > 0 THEN
        FOR REC IN P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C.FIRST .. P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C.LAST LOOP
          DBG('p_Prev_stdcif.ty_miccustm.v_mitm_default_codes__c(REC)
            .MIS_CLASS--->' || P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(REC)
              .MIS_CLASS || '~');
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT_MIS
              FROM MITMS_DEFAULT_CODES B
             WHERE B.KEY_ID = P_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO
               AND B.MIS_CLASS = P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(REC)
                  .MIS_CLASS;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('error occured' || SQLERRM);
              RETURN FALSE;
          END;
          DBG('l_count_mis--->' || L_COUNT_MIS);
          IF L_COUNT_MIS = 0 THEN
            DBG('BEFORE DELETE');
            P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(REC).KEY_ID := NULL;
            P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(REC).MIS_CLASS := NULL;
            P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(REC).MIS_TYPE := NULL;
            P_PREV_STDCIF.TY_MICCUSTM.V_MITM_DEFAULT_CODES__C(REC).MIS_CODE := NULL;
            DBG('AFTER DELETE');
          END IF;
        END LOOP;
      END IF;
    END IF;
  
    DBG('action code Here Is ----->' || P_ACTION_CODE);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      IF NOT STPKSS_SDN.FN_CHECK_CUSTOMER(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                          P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NAME1,
                                          'N',
                                          'Y',
                                          'Y',
                                          P_ERR_CODE,
                                          P_ERR_PARAMS) THEN
        DBG('Fn_check_customer returns false');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_DEFAULT) AND
       NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT, 'N') = 'Y' AND
       NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH, 'N') = 'N' THEN
      DBG('action code  ----->' || P_ACTION_CODE);
      DBG('p_wrk_stdcif.ty_stccuacc.v_stvws_auto_account.Ac_Open_Date ' ||
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AC_OPEN_DATE);
    
      --sampath starts for Auto Account CIF Creation for Digital Banking
      IF P_SOURCE <> 'FLEXCUBE' AND
         P_WRK_STDCIF.v_sttms_customer.AUTO_CREATE_ACCOUNT = 'Y' THEN
        P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AC_OPEN_DATE := GLOBAL.application_date; --sampath starts
      END IF;
      --sampath ends for Auto Account CIF Creation for Digital Banking
    
      IF NOT CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
                                      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.AC_OPEN_DATE,
                                      L_RES) THEN
        DBG('cepkss_date.fn_isholiday has returned false... but continuing');
        NULL;
      END IF;
      DBG('IS Holiday BUG#24431765  : ' || L_RES);
      IF NVL(L_RES, 'N') = 'H' THEN
        OVPKS.PR_APPENDTBL('ST-CUS105', NULL);
      END IF;
    END IF;
  
    DBG('action code  ----->' || P_ACTION_CODE);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_DEFAULT) AND
       NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT, 'N') = 'Y' AND
       NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH, 'N') = 'N' THEN
    
      IF P_SOURCE NOT IN ('FLEXCUBE') THEN
        DBG('Calling stpks_stccuacc_kernel.fn_main');
        BEGIN
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE := P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH;
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO     := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
          DBG('p_stdcif.ty_stccuacc.v_stvws_Auto_account.account_class ' ||
              P_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS);
          DBG('p_stdcif.ty_stccuacc.v_stvws_Auto_account.ccy ' ||
              P_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CCY);
          DBG('p_prev_stdcif.ty_stccuacc.v_stvws_Auto_account.account_class ' ||
              P_PREV_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS);
          DBG('p_prev_stdcif.ty_stccuacc.v_stvws_Auto_account.ccy ' ||
              P_PREV_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CCY);
          DBG('p_wrk_stdcif.ty_stccuacc.v_stvws_Auto_account.account_class ' ||
              P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS);
          DBG('p_wrk_stdcif.ty_stccuacc.v_stvws_Auto_account.ccy ' ||
              P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CCY);
        
        END;
        IF NOT STPKS_STCCUACC_KERNEL.FN_MAIN(P_SOURCE,
                                             P_SOURCE_OPERATION,
                                             P_FUNCTION_ID,
                                             P_ACTION_CODE,
                                             P_CHILD_FUNCTION,
                                             P_MULTI_TRIP_ID,
                                             P_REQUEST_NO,
                                             P_WRK_STDCIF.TY_STCCUACC,
                                             P_STATUS,
                                             P_ERR_CODE,
                                             P_ERR_PARAMS) THEN
          DBG('Failed in stpks_stccuacc_kernel.fn_main' || SQLERRM);
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('p_Wrk_stdcif.ty_stccuacc.v_stvws_auto_account.cust_ac_no : ' ||
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO);
      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO IS NULL THEN
        P_ERR_CODE   := 'ST-CIF33';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      IF P_SOURCE = 'FLEXCUBE' THEN
      
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1 IS NOT NULL AND
           P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA IS NOT NULL AND
           P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.LOCATION IS NULL THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-LOC-03', '');
          RETURN FALSE;
        END IF;
      
      END IF;
    
      BEGIN
        SELECT NVL(LIMIT_CHECK_REQUIRED, 'N')
          INTO L_LIMIT_CHECK
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('WHEN OTHERS Sttm_Account_Class' || SQLERRM);
          RETURN FALSE;
      END;
      IF P_FUNCTION_ID = 'STDCIF' THEN
        IF L_LIMIT_CHECK = 'Y' AND
           NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS, 'N') = 'N' THEN
          P_ERR_CODE   := 'ST-LIM33';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        
        END IF;
      END IF;
    
    END IF;
  
    IF P_PREV_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS = 'Y' AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS = 'N' THEN
      DBG('Track limits cannot be unchecked once the liability is maintained.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF80', '');
      RETURN FALSE;
    END IF;
  
    IF P_ACTION_CODE = 'DEFAULT' THEN
      DBG('LIMITS_11.3.1:1:');
      DECLARE
        L_TRACK_LIMITS STTMS_CUSTOMER.TRACK_LIMITS%TYPE;
        CUSTOMER_TYPE  P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE%TYPE := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE;
      BEGIN
        BEGIN
          SELECT CASE
                   WHEN CUSTOMER_TYPE = 'C' THEN
                    LIMIT_TRACK_CIF_CORP
                 --loan sector sampath changes starts
                   WHEN CUSTOMER_TYPE = 'U' THEN
                    LIMIT_TRACK_CIF_CORP
                   WHEN CUSTOMER_TYPE = 'R' THEN
                    LIMIT_TRACK_CIF_CORP
                   WHEN CUSTOMER_TYPE = 'S' THEN
                    LIMIT_TRACK_CIF_CORP
                   WHEN CUSTOMER_TYPE = 'N' THEN
                    LIMIT_TRACK_CIF_CORP
                 --loan sector sampath changes ends 
                   WHEN CUSTOMER_TYPE = 'B' THEN
                    LIMIT_TRACK_CIF_BANK
                   WHEN CUSTOMER_TYPE = 'I' THEN
                    LIMIT_TRACK_CIF_INDL
                 END
            INTO L_TRACK_LIMITS
            FROM STTM_BANK;
        EXCEPTION
          WHEN OTHERS THEN
            L_TRACK_LIMITS := 'N';
            DBG('LIMITS_11.3.1:2:');
        END;
        P_WRK_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS := L_TRACK_LIMITS;
        DBG('LIMITS_11.3.1:3: l_track_limits: ' || L_TRACK_LIMITS);
      END;
    ELSIF P_ACTION_CODE = 'LOADLIAB' THEN
      DBG('LIMITS_11.3.1:4:');
      STPKS_STDCIF_MAIN.PR_SET_SKIP_SYS;
      IF NOT STPKS_STDCIF_UTILS_0.FN_LOAD_LIAB_LINK(P_WRK_STDCIF,
                                                    'LOADLIAB',
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DBG('LIMITS_11.3.1:5:');
      END IF;
    ELSIF P_ACTION_CODE = 'PICKLIABUDF' THEN
      DBG('LIMITS_11.3.1:4:');
    
      IF NOT STPKS_STDCIF_UTILS_0.FN_LOAD_LIAB_UDF(P_ACTION_CODE,
                                                   P_WRK_STDCIF,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DBG('LIMITS_11.3.1:12:');
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PASSPORT_NO IS NOT NULL THEN
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW OR
           (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
           
           (NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE,
                 TO_DATE('01-01-1000', 'dd-mm-yyyy')) <>
           NVL(P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE,
                 TO_DATE('01-01-1000', 'dd-mm-yyyy')))) THEN
        
          IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE <
             GLOBAL.APPLICATION_DATE THEN
            DBG('Expiry date of Passport is less than today');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF130', ' ');
          END IF;
        
        END IF;
      
        IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
           (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE =
           P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE)) THEN
        
          IF (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE <
             GLOBAL.APPLICATION_DATE) THEN
            DBG('Expiry date of Passport is less than today');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF131', ' ');
          END IF;
        
        END IF;
      
        IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE =
           GLOBAL.APPLICATION_DATE THEN
          DBG('Passport Expiry Date is equal to System Date');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF132', ' ');
        END IF;
      
        IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE >
           P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE THEN
          DBG('Passport Issue Date cannot be greater than Passport Expiry Date');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF133', ' ');
        END IF;
      
        IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE =
           P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE THEN
          DBG('Passport Issue Date cannot be equal to Passport Expiry Date');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF134', ' ');
        END IF;
      
        IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE =
           GLOBAL.APPLICATION_DATE THEN
          DBG('Passport issue Date is equal to System Date');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF135', ' ');
        END IF;
      
        IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE >
           GLOBAL.APPLICATION_DATE THEN
          DBG('Passport issue Date is greater than today');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF136', ' ');
        END IF;
      END IF;
    
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      
        SELECT MINOR_AGE
          INTO L_MINOR
          FROM STTMS_BRANCH
         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
        DBG('dob' || P_CUST_REC.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH ||
            ' mon' || ADD_MONTHS(GLOBAL.APPLICATION_DATE(),
                                 - (NVL(L_MINOR, 18) * 12)) || 'MIN' ||
            L_MINOR);
        DBG('I AM global.application_dat' || GLOBAL.APPLICATION_DATE);
        DBG('p_wrk_stdcif.v_Sttms_Cust_Personal.Date_Of_Birth' ||
            P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH);
        IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH IS NOT NULL THEN
          IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH <=
             GLOBAL.APPLICATION_DATE THEN
            DBG('I AM HERE');
            IF (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH >
               (ADD_MONTHS(GLOBAL.APPLICATION_DATE(),
                            - (NVL(L_MINOR, 18) * 12)))) THEN
              DBG('cOMING HERE');
              IF NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.MINOR, 'N') = 'N' THEN
                P_ERR_CODE := 'ST-CUST0050';
              
                DBG('Validation failed::Minor option is not checked');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, NULL);
              END IF;
            END IF;
          ELSE
            DBG('DOB exceeds application date');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUST0053', ' ');
          END IF;
        END IF;
      
        IF NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.MINOR, 'N') = 'Y' THEN
          IF (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH <=
             (ADD_MONTHS(GLOBAL.APPLICATION_DATE(),
                          - (NVL(L_MINOR, 18) * 12)))) THEN
            P_ERR_CODE := 'ST-CUST0052';
            DBG('Validation failed::Customer is not a minor');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, NULL);
          END IF;
        
          IF NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.MINOR, 'N') = 'Y' AND
             P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.LEGAL_GUARDIAN IS NULL THEN
            P_ERR_CODE   := 'ST-CUST0051';
            P_ERR_PARAMS := 'Legal Guardian~';
            DBG('Validation failed::Legal guardian cannot be null for minors');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
          END IF;
        
          IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.STAFF, 'N') = 'Y' THEN
            DBG('A minor customer cannot be a staff customer of the bank.');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CUST0054', '');
          END IF;
        
        END IF;
      END IF;
    
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.AML_REQUIRED = 'Y' AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.AML_CUSTOMER_GRP IS NULL THEN
      
        P_WRK_STDCIF.V_STTMS_CUSTOMER.AML_CUSTOMER_GRP := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      ELSIF P_WRK_STDCIF.V_STTMS_CUSTOMER.AML_REQUIRED = 'N' THEN
        P_WRK_STDCIF.V_STTMS_CUSTOMER.AML_CUSTOMER_GRP := NULL;
      END IF;
    
    END IF;
  
    DBG('P_ACTION_CODE ORANGE=' || P_ACTION_CODE);
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      
        DBG('p_wrk_stdcif.v_cstbs_ui_columns.CHAR_FIELD31 = ' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD31);
        IF NVL(P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD31, 'N') = 'Y' THEN
        
          P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD94   := P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS1 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS2 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS3 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS4 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY  := P_WRK_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_PINCODE  := P_WRK_STDCIF.V_STTMS_CUSTOMER.PINCODE;
        
          IF (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS1 <>
             P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1) OR
             (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS2 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2, '*')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS3 <>
             P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3) OR
             (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS4 <>
             P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4) OR
             (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY <>
             P_WRK_STDCIF.V_STTMS_CUSTOMER.COUNTRY)
            
             OR (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_PINCODE <>
             P_WRK_STDCIF.V_STTMS_CUSTOMER.PINCODE)
          
           THEN
            DBG('Permanent address different from Correspondence Address');
            OVPKS.PR_APPENDTBL('ST-CIF-004', NULL);
          END IF;
        END IF;
        IF NVL(P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD33, 'N') = 'Y' THEN
        
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_ADDRESS1 := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS1;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_ADDRESS2 := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS2;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_ADDRESS3 := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS3;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_ADDRESS4 := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS4;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_COUNTRY  := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_PINCODE  := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_PINCODE;
        
          IF (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_ADDRESS1 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS1, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_ADDRESS2 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS2, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_ADDRESS3 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS3, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_ADDRESS4 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_ADDRESS4, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_COUNTRY <>
             NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY, 'X'))
            
             OR (P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.D_PINCODE <>
             NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_PINCODE, 'X'))
          
           THEN
            DBG('Domicile address different from Permanent Address');
            OVPKS.PR_APPENDTBL('ST-CIF-005', NULL);
          END IF;
        END IF;
      
      END IF;
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN
         ('C', 'B', 'U', 'R', 'S', 'N') THEN
        --loan sector sampath changes
      
        BEGIN
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.TELEPHONE      := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.TELEPHONE;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.FAX            := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.E_MAIL         := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.E_MAIL;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER  := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.MOBILE_NUMBER;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.CUST_COMM_MODE := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.CUST_COMM_MODE;
        
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.TEL_ISD_NO := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.TEL_ISD_NO;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.MOB_ISD_NO := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO;
          P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.FAX_ISD_NO := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX_ISD_NO;
        
        END;
      
        DBG('p_wrk_stdcif.v_cstbs_ui_columns.CHAR_FIELD32 = ' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD32);
        IF NVL(P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD32, 'N') = 'Y' THEN
        
          dbg('P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87===' ||
              P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87);
          dbg('P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY======' ||
              P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);
          dbg('P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE====' ||
              P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE);
        
          P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD86        := P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87;
          P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS1     := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1;
          P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS2     := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE2;
          P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS3     := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE3;
          P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS4     := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE4;
          P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY      := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY;
          P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.CORPORATE_NAME := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.CUSTOMER_NAME1;
          P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_PINCODE      := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE;
        
          IF (P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS1 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS2 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE2, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS3 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE3, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS4 <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE4, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY, 'X')) OR
             (P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.CORPORATE_NAME <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.CUSTOMER_NAME1, 'X'))
            
             OR (P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_PINCODE <>
             NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE, 'X'))
          
           THEN
            DBG('p_wrk_stdcif.v_sttms_cust_corporate.r_address1' ||
                P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS1 || '////' ||
                'p_wrk_stdcif.v_sttms_customer__a.address_line1' ||
                P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1);
            DBG('p_wrk_stdcif.v_sttms_cust_corporate.r_address1' ||
                P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS2 || '////' ||
                'p_wrk_stdcif.v_sttms_customer__a.address_line1' ||
                P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE2);
            DBG('p_wrk_stdcif.v_sttms_cust_corporate.r_address1' ||
                P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS3 || '////' ||
                'p_wrk_stdcif.v_sttms_customer__a.address_line1' ||
                P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE3);
            DBG('p_wrk_stdcif.v_sttms_cust_corporate.r_address1' ||
                P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_ADDRESS4 || '////' ||
                'p_wrk_stdcif.v_sttms_customer__a.address_line1' ||
                P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE4);
            DBG('p_wrk_stdcif.v_sttms_cust_corporate.r_country' ||
                P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY || '////' ||
                P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);
            DBG('p_wrk_stdcif.v_sttms_cust_corporate.corporate_name' ||
                P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.CORPORATE_NAME ||
                '/////' || P_WRK_STDCIF.V_STTMS_CUSTOMER__A.CUSTOMER_NAME1);
            DBG('p_wrk_stdcif.v_sttms_cust_corporate.r_pincode' ||
                P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_PINCODE || '/////' ||
                P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE);
          
            DBG('Permanent address different from Correspondence Address');
            OVPKS.PR_APPENDTBL('ST-CIF-004', NULL);
          END IF;
          IF NVL(P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD33, 'N') = 'Y' THEN
            OVPKS.PR_APPENDTBL('IF-CIF026', NULL);
          END IF;
        END IF;
      END IF;
    
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_DETAILS, 'N') IN ('V', 'F') THEN
        DBG('KYC details are not null ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_DETAILS);
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO IS NULL THEN
          DBG('KYC Reference number is null');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF-282', ' ');
        END IF;
      END IF;
    
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'B' THEN
        IF NVL(P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD31, 'N') = 'Y' OR
           NVL(P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD33, 'N') = 'Y' THEN
          OVPKS.PR_APPENDTBL('IF-CIF026', NULL);
        END IF;
      END IF;
    END IF;
  
    DBG('BEFORE KEY ID POSTDFLT IS' ||
        P_WRK_STDCIF.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);
    P_WRK_STDCIF.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID := P_WRK_STDCIF.
                                                                V_STTMS_CUSTOMER.CUSTOMER_NO;
    DBG('AFTER KEY ID POSTDFLT IS' ||
        P_WRK_STDCIF.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);
  
    IF P_ACTION_CODE = 'CLOSE' THEN
      SELECT COUNT(*)
        INTO L_SEG_COUNT
        FROM STTMS_CUST_SEG_MAPPING
       WHERE CUSTOMER_NO = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO
         AND RECORD_STAT = 'O';
      IF L_SEG_COUNT > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIFSEG12', NULL);
      END IF;
    END IF;
  
    IF P_ACTION_CODE = 'NEW' AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTOGEN_STMTPLAN = 'Y' AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.FREQUENCY IS NOT NULL THEN
    
      IF NOT STPKS_STDCIF_UTILS_0.FN_UPDATE_COMB_STMT(P_FUNCTION_ID,
                                                      P_WRK_STDCIF,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
      
        DBG('Failed in insert to sttm_comb_stmt_maint');
      END IF;
    END IF;
    IF P_ACTION_CODE = 'MODIFY' THEN
      BEGIN
      
        SELECT COUNT(FREQUENCY), COUNT(STMT_DAY)
          INTO L_FREQUENCY, L_STMT_DAY
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        DBG('Here frequency is coming as' || L_FREQUENCY);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_FREQUENCY := 0;
      END;
      IF (L_FREQUENCY > 0 AND P_WRK_STDCIF.V_STTMS_CUSTOMER.FREQUENCY <>
         P_PREV_STDCIF.V_STTMS_CUSTOMER.FREQUENCY) OR
         (L_STMT_DAY > 0 AND P_WRK_STDCIF.V_STTMS_CUSTOMER.STMT_DAY <>
         P_PREV_STDCIF.V_STTMS_CUSTOMER.STMT_DAY) THEN
        P_ERR_CODE   := 'ST-CMB-15';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        DBG('Please modify the frequency and statement day from the combined statement plan screen');
      END IF;
    
      IF NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.AUTOGEN_STMTPLAN, 'N') = 'N' AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTOGEN_STMTPLAN = 'Y' AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.FREQUENCY IS NOT NULL THEN
      
        IF NOT STPKS_STDCIF_UTILS_0.FN_UPDATE_COMB_STMT(P_FUNCTION_ID,
                                                        P_WRK_STDCIF,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
        
          DBG('Failed in insert to sttm_comb_stmt_maint');
        END IF;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('Inside my changes.....');
      SELECT COUNT(*)
        INTO L_COUNT
        FROM STTMS_CUST_ACCOUNT A, CATMS_AMOUNT_BLOCKS B
       WHERE A.CUST_AC_NO = B.ACCOUNT
         AND A.BRANCH_CODE = B.BRANCH
         AND A.CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND B.RECORD_STAT = 'O'
         AND NVL(B.EXPIRY_DATE, GLOBAL.APPLICATION_DATE) >=
             GLOBAL.APPLICATION_DATE;
    
      DBG('Count here -->' || L_COUNT);
    
      DBG('p_wrk_stdcif.v_sttms_customer.whereabouts_unknown -->' ||
          P_WRK_STDCIF.V_STTMS_CUSTOMER.WHEREABOUTS_UNKNOWN);
      DBG('p_wrk_stdcif.v_sttms_customer.deceased -->' ||
          P_WRK_STDCIF.V_STTMS_CUSTOMER.DECEASED);
      DBG('p_wrk_stdcif.v_sttms_customer.frozen -->' ||
          P_WRK_STDCIF.V_STTMS_CUSTOMER.FROZEN);
    
      IF L_COUNT > 0 AND
         (NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.FROZEN, 'N') = 'Y' OR
         NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.DECEASED, 'N') = 'Y' OR
         NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.WHEREABOUTS_UNKNOWN, 'N') = 'Y') THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF-20', NULL);
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT LOOP
          IF P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS(I).PCT_HOLDING > 100 OR P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS(I)
             .PCT_HOLDING < 0 THEN
            DEBUG.PR_DEBUG('ST',
                           'Collateral percentage must be specified ');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF-414', '');
            RETURN FALSE;
          END IF;
        END LOOP;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = 'MODIFY' THEN
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER, 'N') = 'Y' THEN
        IF NOT FN_MFI_CHK_ACCESS(NVL(P_WRK_STDCIF.V_STTMS_MFI_DETAILS.ACCOUNT_OFFICER,
                                     '*'),
                                 P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                 NULL,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
          DBG('returned false from  fn_MFi_chk_access');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      
        IF P_ACTION_CODE = 'CLOSE' THEN
          SELECT COUNT(*)
            INTO CNT1
            FROM MFTM_CENTER_DEFINITION
           WHERE CENTER_CIF_ID = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
             AND RECORD_STAT = 'O';
          IF CNT1 > 0 THEN
            P_ERR_CODE   := 'MF-CNT-004';
            P_ERR_PARAMS := NULL;
            DBG('Customer cannot be closed. Some of the mapped Centers are in open status....');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          END IF;
        END IF;
      END IF;
    END IF;
    IF P_ACTION_CODE = 'COPY' THEN
      P_WRK_STDCIF.V_STTMS_MFI_DETAILS.INSURANCE_NUMBER   := '';
      P_WRK_STDCIF.V_MFTMS_AO_CIF_LINKAGE.ACCOUNT_OFFICER := '';
      P_WRK_STDCIF.V_MFVWS_CIF_DET.MEETING_CODE           := '';
      P_WRK_STDCIF.V_MFVWS_CIF_DET.GROUP_CODE             := '';
      P_WRK_STDCIF.V_STTMS_MFI_DETAILS.BLACKLISTED        := '';
      P_WRK_STDCIF.V_STTMS_MFI_DETAILS.BLACKLIST_COUNT    := '';
      P_WRK_STDCIF.V_MFVWS_TRAINING.DELETE;
      P_WRK_STDCIF.V_MFTBS_CUST_ID_MASTER.DELETE;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF (P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA IN ('MAIL', 'SWIFT')) THEN
        DBG('Curr MEDIA:' || P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA);
        DBG('Prev MEDIA:' || P_PREV_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA);
        IF ((P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA IS NOT NULL) AND
           (P_PREV_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA IS NOT NULL)) THEN
          IF (P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA <>
             P_PREV_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA) THEN
            DBG('Address record already exists with CIF location in address table.');
            P_ERR_CODE   := 'ST-CIF149';
            P_ERR_PARAMS := P_PREV_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA;
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
          END IF;
        END IF;
      END IF;
    END IF;
  
    DBG('Not Allowing the Virtual Customer ID to be entered if  the Virtual Accounts Check box is not checked starts');
  
    IF (P_WRK_STDCIF.V_STTMS_CUSTOMER.ALLOW_VRTL_ACCNTS = 'N' AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID IS NOT NULL) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIFVA-01', P_ERR_PARAMS);
    END IF;
  
    DBG('Not Allowing the Virtual Customer ID to be entered if  the Virtual Accounts Check box is not checked ends');
  
    DBG('Making  Virtual Customer ID  as mandatory when allow virtual accounts check box is checked starts');
  
    DBG('check for ALLOW_VRTL_ACCNTS' ||
        P_STDCIF.V_STTMS_CUSTOMER.ALLOW_VRTL_ACCNTS);
    IF P_WRK_STDCIF.V_STTMS_CUSTOMER.ALLOW_VRTL_ACCNTS = 'Y' THEN
      DBG('Virtual Customer ID is' ||
          P_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID);
    
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID IS NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIFVA-02', P_ERR_PARAMS);
      
      END IF;
    END IF;
    DBG('Making  Virtual Customer ID  as mandatory when allow virtual accounts check box is checked starts');
  
    DBG('code for Checking whether any customer id is matching exactly with Virtual Customer ID starts');
    SELECT COUNT(*)
      INTO L_VIRTUAL_COUNT
      FROM STTMS_CUSTOMER A
     WHERE A.CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID;
  
    IF (L_VIRTUAL_COUNT > 0 OR
       (P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO =
       P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID)) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIFVA-03', P_ERR_PARAMS);
    END IF;
    DBG('code for Checking whether any customer id is matching exactly with Virtual Customer ID ends');
  
    DBG('code for Checking the allow virtual accounts to be not un cheked once it is checked starts');
    IF P_ACTION_CODE IN ('MODIFY') THEN
      IF (((P_PREV_STDCIF.V_STTMS_CUSTOMER.ALLOW_VRTL_ACCNTS = 'Y' AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.ALLOW_VRTL_ACCNTS = 'N') OR
         (P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID <>
         P_PREV_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID)) AND
         (P_WRK_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH = 'Y')) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIFVA-04', P_ERR_PARAMS);
      END IF;
    
      OPEN CR_CUST_CHNNL;
      LOOP
        FETCH CR_CUST_CHNNL
          INTO L_REC_CHNNL;
        EXIT WHEN CR_CUST_CHNNL%NOTFOUND;
      
        IF P_STDCIF.V_CUSTOMER_CHANNEL_INFO.COUNT > 0 THEN
          IDX           := P_STDCIF.V_CUSTOMER_CHANNEL_INFO.FIRST;
          L_CHNNEL_FLAG := FALSE;
          WHILE IDX IS NOT NULL LOOP
            DBG('idx ' || IDX);
            DBG('In loop with Channel Id: ' || L_REC_CHNNL.CHANNEL_ID ||
                'p_stdcif.v_customer_channel_info.channel_id : ' || P_STDCIF.V_CUSTOMER_CHANNEL_INFO(IDX)
                .CHANNEL_ID);
            IF L_REC_CHNNL.CHANNEL_ID = P_STDCIF.V_CUSTOMER_CHANNEL_INFO(IDX)
              .CHANNEL_ID THEN
              L_CHNNEL_FLAG := TRUE;
              EXIT;
            END IF;
            IDX := P_STDCIF.V_CUSTOMER_CHANNEL_INFO.NEXT(IDX);
          END LOOP;
        END IF;
        IF NOT L_CHNNEL_FLAG THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'ST-CHNL-001',
                       L_REC_CHNNL.CHANNEL_ID);
        END IF;
      END LOOP;
    
    END IF;
  
    DBG('code for Checking the allow virtual accounts to be not un cheked once it is checked ends');
  
    DBG('Code for not allowing the invest customer to be unchecked once it is checked starts');
    IF P_ACTION_CODE IN ('COPY', 'MODIFY') THEN
      IF (P_PREV_STDCIF.V_STTMS_CUSTOMER.INVEST_CUST = 'Y' AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.INVEST_CUST = 'N') THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CUSIS-01', P_ERR_PARAMS);
      
      END IF;
    END IF;
  
    DBG('COde for not allowing the invest customer to be unchecked once it is checked ends');
  
    DBG('Code for not allowing the customer to be closed unless the closure allowed flag is set to Y starts');
  
    IF (P_ACTION_CODE = 'CLOSE' AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.INVEST_CUST = 'Y') THEN
      SELECT COUNT(*)
        INTO L_COUNT_CLOSURE
        FROM STTM_CUSTOMER_CLOSURE
       WHERE ENTITY_ID = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      IF L_COUNT_CLOSURE < 1 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CUSIS-02', P_ERR_PARAMS);
      ELSE
        SELECT CLOSURE_ALLOWED
          INTO L_CLOSURE_ALLOWED
          FROM STTM_CUSTOMER_CLOSURE
         WHERE ENTITY_ID = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        IF L_CLOSURE_ALLOWED = 'N' THEN
        
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'ST-CUSIS-03',
                       P_ERR_PARAMS);
        
        END IF;
      END IF;
    END IF;
    DBG('Code for not allowing the customer to be closed unless the closure allowed flag is set to Y ends');
  
    DBG('Code for not allowing the Invest  Customer to be checked when the FCIS allowed flag is N starts');
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.INVEST_CUST = 'Y' THEN
        BEGIN
        
          L_PARAM_VAL := CSPKSS_OS_PARAM.GET_PARAM_VAL('FCIS_INSTALLED');
        
        EXCEPTION
          WHEN OTHERS THEN
            L_PARAM_VAL := 'N';
        END;
        IF L_PARAM_VAL = 'N' THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'ST-CUSIS-04',
                       P_ERR_PARAMS);
        END IF;
        DBG('Code for not allowing the Invest  Customer to be checked when the FCIS allowed flag is N ends');
      
        DBG('Code for validating the first name as mandatory when the Investment Customer Flag is selected starts');
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
          IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.FIRST_NAME IS NULL THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'ST-CUSIS-05',
                         P_ERR_PARAMS);
          END IF;
        END IF;
        DBG('Code for validating the first name as mandatory when the Investment Customer Flag is selected ends');
      
        DBG('Code for validating At least one record needs to be provided  under Document list starts');
        IF P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.COUNT = 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'ST-CUSIS-06',
                       P_ERR_PARAMS);
        END IF;
        DBG('Code for validating At least one record needs to be provided  under Document list ends');
      
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN ('NEW') THEN
      DBG('code for validating Virtual Customer Id as unique starts');
      SELECT COUNT(*)
        INTO L_VRTL_CUST_COUNT
        FROM STTMS_CUSTOMER A
       WHERE A.VRTL_CUSTOMER_ID =
             P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID;
      DBG('deva check for p_wrk_stdcif.v_sttms_customer.vrtl_customer_id' ||
          P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID);
      IF (L_VRTL_CUST_COUNT > 0) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIFVA-05', P_ERR_PARAMS);
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN ('MODIFY') THEN
      DBG('code for validating Virtual Customer Id as unique starts for modify');
      SELECT COUNT(*)
        INTO L_VRTL_CUST_COUNT
        FROM STTMS_CUSTOMER A
       WHERE A.VRTL_CUSTOMER_ID =
             P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID
         AND A.CUSTOMER_NO <> P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('deva check for p_wrk_stdcif.v_sttms_customer.vrtl_customer_id' ||
          P_WRK_STDCIF.V_STTMS_CUSTOMER.VRTL_CUSTOMER_ID);
      IF (L_VRTL_CUST_COUNT > 0) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-CIFVA-05', P_ERR_PARAMS);
      END IF;
    END IF;
  
    DBG('code for validating Virtual Customer Id as unique ends');
  
    IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY) AND
       (P_PREV_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY <>
       P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY) THEN
      DBG('Updating the ictb_maint_key');
      IF NOT
          ICPKS_UTIL.FN_UPD_MAINT_QUEUE_CUST(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO) THEN
        DBG('Failed in icpks_util.fn_upd_maint_queue_cust');
      END IF;
    END IF;
  
    IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY) AND
       (P_PREV_STDCIF.V_STTMS_CUSTOMER.
        TAX_GROUP <> P_WRK_STDCIF.V_STTMS_CUSTOMER.TAX_GROUP) THEN
      SELECT COUNT(1)
        INTO L_TMP_CNT_1
        FROM STTM_CUST_TAX_WAIVE
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND CUSTOMER_GROUP = P_WRK_STDCIF.V_STTMS_CUSTOMER.TAX_GROUP;
    
      SELECT COUNT(1)
        INTO L_TMP_CNT_2
        FROM STTM_CUST_TAX_WAIVE
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND CUSTOMER_GROUP = P_PREV_STDCIF.V_STTMS_CUSTOMER.TAX_GROUP;
    
      IF L_TMP_CNT_1 > 0 OR L_TMP_CNT_2 > 0 THEN
      
        IF NOT ICPKS_INTRADAY_UTILS.FN_POP_MAINTQ_LQ_CUST('STDCIF',
                                                          P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
          DBG('Failed in updating maint queue for LQ type for customer ' ||
              P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
        END IF;
      END IF;
    END IF;
  
    DBG('Changes starts');
    IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS, 'N') = 'Y' AND
       P_ACTION_CODE = 'NEW' THEN
      DBG('Checking if Liability already created');
      SELECT COUNT(1)
        INTO L_COUNT
        FROM GETM_LIAB
       WHERE LIAB_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO;
      IF L_COUNT <> 0 THEN
        DBG('Liability already Exists');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LM-00236', P_ERR_PARAMS);
      END IF;
    END IF;
  
    DBG('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
  
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcif_Kernel.Fn_Post_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    
  END FN_POST_DEFAULT_AND_VALIDATE;

  FUNCTION FN_PRE_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_CHILD_FUNCTION   IN VARCHAR2,
                            P_POST_UPL_STAT    IN VARCHAR2,
                            P_MULTI_TRIP_ID    IN VARCHAR2,
                            P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                            P_PREV_STDCIF      IN STPKS_STDCIF_MAIN.TY_STDCIF,
                            P_WRK_STDCIF       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('In Fn_Pre_Upload_Db..');
  
    DBG('p_wrk_stdcif.v_sttms_mfi_details.customer_no' ||
        P_WRK_STDCIF.V_STTMS_MFI_DETAILS.CUSTOMER_NO ||
        'p_stdcif.v_sttms_customer.CUSTOMER_NO' ||
        P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO ||
        'p_stdcif.v_sttms_customer.mfi_customer' ||
        P_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER);
  
    IF P_WRK_STDCIF.V_STTMS_MFI_DETAILS.CUSTOMER_NO IS NULL AND
       P_SOURCE <> 'FLEXCUBE' AND
       NVL(P_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER, 'N') = 'Y' THEN
      P_WRK_STDCIF.V_STTMS_MFI_DETAILS.CUSTOMER_NO := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
    
      P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.MOTHER_MAIDEN_NAME := P_WRK_STDCIF.V_STTMS_CUST_DOMESTIC.MOTHER_MAIDEN_NAME;
    
    END IF;
  
    IF P_ACTION_CODE = 'CUSSNCKSTATUS' THEN
      DBG('This Action code is to display sanction check.. So returning true..');
      RETURN TRUE;
    END IF;
  
    IF P_WRK_STDCIF.V_STTMS_LINKEDACC_DETAILS.COUNT > 0 THEN
      FOR I IN P_WRK_STDCIF.V_STTMS_LINKEDACC_DETAILS.FIRST .. P_WRK_STDCIF.V_STTMS_LINKEDACC_DETAILS.LAST LOOP
        P_WRK_STDCIF.V_STTMS_LINKEDACC_DETAILS(I).CUSTOMER_NO := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END LOOP;
    END IF;
  
    IF P_WRK_STDCIF.V_STTMS_CUST_JV.COUNT > 0 THEN
      FOR I IN P_WRK_STDCIF.V_STTMS_CUST_JV.FIRST .. P_WRK_STDCIF.V_STTMS_CUST_JV.LAST LOOP
        P_WRK_STDCIF.V_STTMS_CUST_JV(I).CUSTOMER_NO := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      END LOOP;
    END IF;
  
    IF P_ACTION_CODE = 'DEFAULT' THEN
      DBG('Skipping sys for DEFAULT op');
      STPKS_STDCIF_MAIN.PR_SET_SKIP_SYS;
    END IF;
  
    IF P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.COUNT > 0 AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO IS NOT NULL THEN
      FOR I IN P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.FIRST .. P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.LAST LOOP
        IF P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I).CUSTOMER_NO IS NULL THEN
          P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST(I).CUSTOMER_NO := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        END IF;
      END LOOP;
    
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_AUTH,
                         CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('LIMITS_11.3.1:6:');
    
      G_STDCIF := P_STDCIF;
    END IF;
  
    P_WRK_STDCIF.V_STTMS_CUSTOMER.IS_FORGOTTEN := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.IS_FORGOTTEN,
                                                      'N');
    DBG('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcif_Kernel.Fn_Pre_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UPLOAD_DB;

  FUNCTION FN_POST_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_POST_UPL_STAT    IN VARCHAR2,
                             P_MULTI_TRIP_ID    IN VARCHAR2,
                             P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                             P_PREV_STDCIF      IN STPKS_STDCIF_MAIN.TY_STDCIF,
                             P_WRK_STDCIF       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_TRACE VARCHAR2(1000);
  
    L_KEY              VARCHAR2(5000) := NULL;
    L_KEY_ID           VARCHAR2(5000) := NULL;
    L_ROW_ID           ROWID;
    P_CUST_REC         STPKS_STDCIF_MAIN.TY_STDCIF;
    CNT                NUMBER;
    L_CNT              NUMBER;
    LONCE_AUTH         VARCHAR2(32767);
    L_PARAM_VAL        VARCHAR2(32767);
    PSERIAL            VARCHAR2(20);
    L_PREF             MSTBS_DLY_MSG_OUT.REFERENCE_NO%TYPE;
    L_TPINREF          MSTBS_DLY_MSG_OUT.REFERENCE_NO%TYPE;
    L_AUTO_AUTH_MENU   VARCHAR2(32767);
    L_AUTO_AUTH_USER   VARCHAR2(32767);
    P_MSDCUSAD         MSPKS_MSDCUSAD_MAIN.TY_MSDCUSAD;
    P_STATUS           VARCHAR2(20);
    L_ERRTBL_BACKUP    OVPKSS.TBL_ERROR;
    L_COUNT            NUMBER := 0;
    L_SOURCE_OPERATION VARCHAR2(50);
    L_ACTION_CODE      VARCHAR2(20);
    L_STDCIF_ACTION    VARCHAR2(20);
  
    L_WRK_STDCIF  STPKS_STDCIF_MAIN.TY_STDCIF;
    L_RECORD_STAT VARCHAR2(1);
  
    L_STAT_QUERY VARCHAR2(20);
  
    L_AUTO_AUTH VARCHAR2(1) := 'Y';
  
    CURSOR CR_MSTMS_MSG_ADDRESS IS
      SELECT *
        FROM MSTMS_MSG_ADDRESS
       WHERE CUSTOMER_NO = P_WRK_STDCIF.
       V_STTMS_CUSTOMER.CUSTOMER_NO
         AND MEDIA = P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA
         AND LOCATION = NVL(P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE, 'CIF');
  
    L_STDCIF     STPKS_STDCIF_MAIN.TY_STDCIF;
    P_REQUEST_NO VARCHAR2(20);
    L_STATUS     VARCHAR2(20);
    E_FAILURE_EXCEPTION EXCEPTION;
  
    L_UPLOADED_STATUS COTMS_SOURCE_PREF.UPLOADED_STATUS%TYPE;
    L_MODULE_CODE     SMTB_MENU.MODULE%TYPE;
  
    L_CUSTREL_COUNT NUMBER := 0;
  
    L_ACC_OFF     NUMBER;
    L_USER_NAME   SMTB_USER.USER_NAME%TYPE;
    L_USER_ID     SMTB_USER.USER_ID%TYPE;
    L_AO_CIF_LINK NUMBER;
  
    L_CURR_STAGE   VARCHAR2(20);
    L_TANKED_STATE VARCHAR2(1);
    L_MOD_NO       VARCHAR2(3);
    L_SNCK_STATUS  CSTB_SNCK_STATUS.SNCK_STATUS%TYPE;
    L_MULTI_FLAG   VARCHAR2(1);
    L_COUNT_1      NUMBER;
  
    L_COUNT_HIST NUMBER;
    CURSOR C_DEL_SNCK(P_CUST_NO STTM_CUSTOMER.CUSTOMER_NO%TYPE,
                      P_MODNO   STTM_CUSTOMER.MOD_NO%TYPE) IS
      SELECT SNCK_REF_NO
        FROM CSTB_SNCK_STATUS
       WHERE KEY_COLS = P_CUST_NO
         AND MOD_NO >= P_MODNO;
  
  BEGIN
    DBG('In Fn_Post_Upload_Db..');
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF NOT STPKS_STDCIF_UTILS_1.FN_CHECK_UDF(P_FUNCTION_ID,
                                               P_WRK_STDCIF,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN
        DBG('Failed while checking the UDF');
        RETURN FALSE;
      END IF;
    END IF;
  
    P_CUST_REC := P_WRK_STDCIF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH,
                         CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_REOPEN) THEN
      P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_ID := P_WRK_STDCIF.
                                                      V_STTMS_CUSTOMER.CUSTOMER_NO;
      DBG('Start Authorize Issuer ~LMTM_ISSUER_MASTER~ ' ||
          P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_ID);
      L_KEY_ID := '~LMTM_ISSUER_MASTER~' ||
                  P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_ID || '~';
      L_KEY    := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                   'LMDISSUR',
                                                   'LMTM_ISSUER_MASTER.ISSUER_ID') || '-' ||
                  P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_ID;
      BEGIN
        SELECT ROWID
          INTO L_ROW_ID
          FROM LMTM_ISSUER_MASTER
         WHERE ISSUER_ID = P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_ID;
        DBG('l_row_id >>' || L_ROW_ID);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in selecting the Previous master Recotrd for LMTM_ISSUER_MASTER');
          P_ERR_CODE   := 'ST-VALS-002';
          P_ERR_PARAMS := L_KEY;
      END;
      IF NOT CSPKS_REQ_UTILS.FN_MAINT_OPERATIONS(P_SOURCE,
                                                 P_SOURCE_OPERATION,
                                                 P_ACTION_CODE,
                                                 P_FUNCTION_ID,
                                                 'LMTM_ISSUER_MASTER',
                                                 L_ROW_ID,
                                                 P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO,
                                                 P_WRK_STDCIF.V_STTMS_CUSTOMER.MAKER_DT_STAMP,
                                                 P_WRK_STDCIF.V_STTMS_CUSTOMER.CHECKER_DT_STAMP,
                                                 L_KEY_ID,
                                                 L_KEY,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAMS) THEN
        DBG('Failed in Cspks_Req_Utils.Fn_Maint_Operations');
      END IF;
      BEGIN
        UPDATE LMTM_ISSUER_MASTER
           SET AUTH_STAT        = 'A',
               ONCE_AUTH        = 'Y',
               CHECKER_ID       = GLOBAL.USER_ID,
               CHECKER_DT_STAMP = FN_MNTSTAMP
         WHERE ISSUER_ID = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed Authorize Issuer ~LMTM_ISSUER_MASTER~ ' ||
              P_WRK_STDCIF.V_LMTMS_ISSUER_MASTER.ISSUER_ID);
      END;
      DBG('After Authorize Issuer ~LMTM_ISSUER_MASTER~ ');
    
      DBG('Cust MIS update');
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
        DBG('Populating ifpkss_fgl_custmis.fn_populate_cmis');
        IF NOT IFPKSS_FGL_CUSTMIS.FN_POPULATE_CMIS(P_WRK_STDCIF.
                                                   V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
          DBG('ifpkss_fgl_custmis.fn_populate_cmis has returned false');
          NULL;
        END IF;
        DBG('Done with cmis update');
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
    
      BEGIN
      
        DBG('FAILUREx ' || SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('**',
                         'In when others of stpks_stdcif_Kernel.fn_post_upload_db ..');
          DEBUG.PR_DEBUG('**', SQLERRM);
          P_ERR_CODE   := 'ST-OTHR-001';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
      END;
    
    END IF;
  
    IF P_ACTION_CODE = 'MODIFY' THEN
      DBG('In fn_post_upload_db P_ACTION_CODE' || P_ACTION_CODE ||
          'credit rating value ' || P_WRK_STDCIF.
          V_STTMS_CUSTOMER.CREDIT_RATING || 'previous value is' ||
          P_PREV_STDCIF. V_STTMS_CUSTOMER.CREDIT_RATING);
      IF P_WRK_STDCIF. V_STTMS_CUSTOMER.CREDIT_RATING IS NOT NULL THEN
        IF NVL(P_PREV_STDCIF. V_STTMS_CUSTOMER.CREDIT_RATING, '$$$$$') <>
           P_WRK_STDCIF. V_STTMS_CUSTOMER.CREDIT_RATING THEN
          DBG('In fn_post_upload_db P_WRK_STDCIF. v_sttms_customer.credit_rating' ||
              P_WRK_STDCIF. V_STTMS_CUSTOMER.CREDIT_RATING);
          IF NOT CLPKS_PROV.FN_MARK_ACCOUNTS_FOR_PROV(P_WRK_STDCIF.
                                                      V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                      P_WRK_STDCIF,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
            DBG('Error Inside Function CLPKS_PROV.fn_mark_accounts_for_prov' ||
                SQLERRM);
          END IF;
        END IF;
      END IF;
    END IF;
  
    IF NOT GLOBALS_FRC.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
      DBG('Failed in FRC function bec of - ' || P_ERR_CODE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;
    DBG('Record exists in FRC..');
    L_AUTO_AUTH_MENU := GLOBAL_FRC.G_TBL_SMTB_MENU_DEFN_REC.AUTO_AUTH;
    L_MODULE_CODE    := GLOBAL_FRC.G_TBL_SMTB_MENU_DEFN_REC.MODULE;
    DBG('Value of l_auto_auth_menu and l_module_code - ' ||
        L_AUTO_AUTH_MENU || '~' || L_MODULE_CODE);
  
    SELECT AUTO_AUTH
      INTO L_AUTO_AUTH_USER
      FROM SMTB_USER
     WHERE USER_ID = GLOBAL.USER_ID();
    DBG('curr USER' || GLOBAL.USER_ID());
  
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      IF P_WRK_STDCIF.V_STTMS_MFI_DETAILS.ACCOUNT_OFFICER IS NOT NULL THEN
        BEGIN
          DBG('USER_ID IS-->' || GLOBAL.USER_ID);
          SELECT USER_ID, USER_NAME
            INTO L_USER_ID, L_USER_NAME
            FROM SMTB_USER
           WHERE USER_ID = P_WRK_STDCIF.V_STTMS_MFI_DETAILS.ACCOUNT_OFFICER;
          DBG('L_USER_NAME-->' || L_USER_NAME);
          SELECT COUNT(*)
            INTO L_ACC_OFF
            FROM MFTM_ACCOUNT_OFFICER
           WHERE ACCOUNT_OFFICER =
                 P_WRK_STDCIF.V_STTMS_MFI_DETAILS.ACCOUNT_OFFICER;
          DBG('l_acc_off-->' || L_ACC_OFF);
          IF L_ACC_OFF <= 0 THEN
          
            INSERT INTO MFTM_ACCOUNT_OFFICER
              (ACCOUNT_OFFICER,
               ACC_OFFICER_NAME,
               BRANCH_CODE,
               RECORD_STAT,
               AUTH_STAT,
               ONCE_AUTH,
               MOD_NO,
               MAKER_ID,
               MAKER_DT_STAMP,
               CHECKER_ID,
               CHECKER_DT_STAMP)
            VALUES
              (L_USER_ID,
               L_USER_NAME,
               GLOBAL.CURRENT_BRANCH,
               'O',
               'A',
               'Y',
               '',
               L_USER_ID,
               STPKSS_UPLOAD.FN_DATE_TIME(GLOBAL.APPLICATION_DATE()),
               L_USER_ID,
               STPKSS_UPLOAD.FN_DATE_TIME(GLOBAL.APPLICATION_DATE()));
          END IF;
          DBG('INSERTING INTO mftm_ao_cif_linkage');
        
          SELECT COUNT(*)
            INTO L_AO_CIF_LINK
            FROM MFTM_AO_CIF_LINKAGE
           WHERE ACCOUNT_OFFICER =
                 P_WRK_STDCIF.V_STTMS_MFI_DETAILS.ACCOUNT_OFFICER
             AND CUSTOMER_ID = P_WRK_STDCIF.V_STTMS_MFI_DETAILS.CUSTOMER_NO;
          IF L_AO_CIF_LINK <= 0 THEN
            INSERT INTO MFTM_AO_CIF_LINKAGE
              (ACCOUNT_OFFICER, CUSTOMER_ID)
            VALUES
              (P_WRK_STDCIF.V_STTMS_MFI_DETAILS.ACCOUNT_OFFICER,
               P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('**', 'In when others--->>>');
            DEBUG.PR_DEBUG('**', SQLERRM);
            P_ERR_CODE   := 'ST-OTHR-001';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
        END;
      END IF;
    END IF;
  
    DBG('l_module_code-->' || L_MODULE_CODE);
    DBG('p_source-->' || P_SOURCE);
  
    BEGIN
      SELECT UPLOADED_STATUS
        INTO L_UPLOADED_STATUS
        FROM COTMS_SOURCE_PREF
       WHERE SOURCE_CODE = P_SOURCE
         AND MODULE_CODE = L_MODULE_CODE
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_UPLOADED_STATUS := 'U';
    END;
    DBG('l_Uploaded_status-->' || L_UPLOADED_STATUS);
  
    L_KEY_ID := '~STTM_CUSTOMER~' || P_WRK_STDCIF.
                V_STTMS_CUSTOMER.CUSTOMER_NO || '~';
    BEGIN
      SELECT RECORD_STAT
        INTO L_RECORD_STAT
        FROM STTB_RECORD_MASTER
       WHERE KEY_ID = L_KEY_ID
         AND AUTH_STAT = 'U';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('nO DATA FOUND FOR RECORD STAT');
      
        BEGIN
          SELECT RECORD_STAT
            INTO L_RECORD_STAT
            FROM STTM_CUSTOMER
           WHERE CUSTOMER_NO = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_RECORD_STAT := 'O';
        END;
      
    END;
  
    DBG('P_WRK_stdcif.v_sttms_customer.mod_no :: ' ||
        P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO);
    DBG('P_prev_stdcif.v_sttms_customer.mod_no :: ' ||
        P_PREV_STDCIF.V_STTMS_CUSTOMER.MOD_NO);
  
    SELECT COUNT(*)
      INTO L_COUNT_HIST
      FROM STTB_RECORD_LOG_HIST A
     WHERE A.MOD_NO = NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO,
                          P_PREV_STDCIF.V_STTMS_CUSTOMER.MOD_NO)
       AND KEY_ID = L_KEY_ID;
    DBG('#28736696 L_count_hist :: ' || L_COUNT_HIST);
    IF L_COUNT_HIST <> 0 THEN
      L_STDCIF_ACTION := NULL;
    END IF;
    DBG('#28736696 l_stdcif_action :: ' || L_STDCIF_ACTION);
  
    BEGIN
      SELECT ACTION_CODE
        INTO L_STDCIF_ACTION
        FROM STTB_RECORD_LOG A
       WHERE A.MOD_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO
         AND KEY_ID = L_KEY_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT ACTION_CODE
            INTO L_STDCIF_ACTION
            FROM STTB_RECORD_LOG A
           WHERE A.MOD_NO = P_PREV_STDCIF.V_STTMS_CUSTOMER.MOD_NO
             AND KEY_ID = L_KEY_ID;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Failed in selcting the action code from previous  record log' ||
                SQLERRM);
          
            L_STDCIF_ACTION := 'NEW';
        END;
      
      WHEN OTHERS THEN
        DBG('Failed in selcting the action code from record log' ||
            SQLERRM);
      
    END;
  
    DBG('#287366962nd  l_stdcif_action :: ' || L_STDCIF_ACTION);
    IF P_ACTION_CODE = 'AUTH' AND NVL(L_RECORD_STAT, 'O') <> 'C' AND
       L_STDCIF_ACTION IN ('NEW', 'MODIFY') THEN
    
      DBG('inside auth of address');
    
      IF P_SOURCE <> 'FLEXCUBE' AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1 IS NULL THEN
        IF NOT STPKS_STDCIF_MAIN.FN_MAIN(P_SOURCE,
                                         '',
                                         P_FUNCTION_ID,
                                         'EXECUTEQUERY',
                                         '',
                                         '',
                                         P_WRK_STDCIF,
                                         L_STAT_QUERY,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN
          DBG('not able to query the function');
        END IF;
      END IF;
    
      P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.HOLD_MAIL := 'N';
    
      BEGIN
      
        SELECT LANGUAGE
          INTO P_WRK_STDCIF.V_STTMS_CUSTOMER.LANGUAGE
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in Selecting laguage.');
          DBG('Record Does not Exist..');
        
      END;
    
      IF NOT CSPKS_REQ_GLOBAL.FN_UNTANKING THEN
        DBG('CALL OF MSDCUSAD');
        GWPKS_SERVICE_ROUTER.PR_BACKUP;
        CSPKS_REQ_GLOBAL.PR_BACKUP;
        CSPKS_REQ_GLOBAL.PR_INIT;
        CSPKS_REQ_GLOBAL.G_REQ := '';
        CSPKS_REQ_GLOBAL.G_RES := '';
        L_ERRTBL_BACKUP        := OVPKSS.GL_TBLERROR;
        OVPKS.PR_INITERRTBL;
        CSPKS_REQ_GLOBAL.PR_SET_POST_UPL_STAT('A');
      
        IF NOT CSPKS_REQ_GLOBAL.FN_GET_BULK_UPLOAD THEN
        
          CSPKS_REQ_GLOBAL.PR_SET_ON_OVERRIDE_ACTION('M');
          CSPKS_REQ_GLOBAL.PR_SET_BULK_UPLOAD(TRUE);
        END IF;
        P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.CUSTOMER_NO := P_WRK_STDCIF.
                                                       V_STTMS_CUSTOMER.CUSTOMER_NO;
      
        IF P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE IS NULL AND
           P_ACTION_CODE = 'MODIFY' THEN
          P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE := NVL(P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE,
                                                      'CIF');
        END IF;
      
        IF UPPER(P_FUNCTION_ID) = 'STDCIFAD' THEN
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LOCATION := 'CIF';
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.MEDIA    := 'MAIL';
        ELSE
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LOCATION := P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE;
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.MEDIA    := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA,
                                                          'MAIL');
        END IF;
      
        IF P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE IS NULL AND
           P_ACTION_CODE = 'MODIFY' THEN
          P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE := NVL(P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE,
                                                      'CIF');
        END IF;
      
        IF UPPER(P_FUNCTION_ID) = 'STDCIFAD' THEN
          DBG('function id is stdcifad');
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LOCATION := 'CIF';
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.MEDIA    := 'MAIL';
        ELSE
        
          DBG('in else..');
          DBG('p_cust_rec.v_sttms_customer.loc_code-->' ||
              P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE);
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LOCATION := NVL(P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE,
                                                          'CIF');
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.MEDIA    := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA,
                                                          'MAIL');
        
        END IF;
      
        DBG('p_msdcusad.v_mstms_cust_address.location ..' ||
            P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LOCATION);
        P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.ADDRESS1 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1;
        P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.MAKER_ID := P_WRK_STDCIF.V_STTMS_CUSTOMER.MAKER_ID;
      
        P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LOCATION := NVL(P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE,
                                                        'CIF');
        DBG('p_msdcusad.v_MSTMS_CUST_ADDRESS(1).location' ||
            P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LOCATION);
      
        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA IN
           ('SWIFT', 'TELEX', 'FAX', 'POST') THEN
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.ADDRESS2 := NULL;
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.ADDRESS3 := NULL;
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.ADDRESS4 := NULL;
        ELSE
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.ADDRESS2 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2;
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.ADDRESS3 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3;
          P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.ADDRESS4 := P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4;
        END IF;
        P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LANGUAGE  := P_WRK_STDCIF.V_STTMS_CUSTOMER.LANGUAGE;
        P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.COUNTRY   := P_WRK_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
        P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.NAME      := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1;
        P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.HOLD_MAIL := 'N';
      
        SELECT COUNT(*)
          INTO L_CNT
          FROM MSTMS_MSG_ADDRESS
         WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND LOCATION = NVL(P_CUST_REC. V_STTMS_CUSTOMER.LOC_CODE, 'CIF')
           AND MEDIA =
               NVL(P_CUST_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA, 'MAIL');
      
        DBG('Msg Address Count:' || L_CNT);
      
        IF L_CNT = 0 THEN
          DBG('No data in Msg_Address for cust_ac_no ALL...');
          P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1).MSG_TYPE := 'ANY MSG TYPE';
          P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1).MODULE := 'AL';
          P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1).BRANCH := 'ALL';
          DBG('p_cust_rec.v_sttms_customer.loc_code' ||
              P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE);
          P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1).LOCATION := NVL(P_CUST_REC.V_STTMS_CUSTOMER.LOC_CODE,
                                                            'CIF');
          DBG('p_msdcusad.v_mstms_msg_address(1).location' || P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1)
              .LOCATION);
          P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1).MEDIA := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA,
                                                         'MAIL');
          P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1).CUSTOMER_NO := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
          P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1).CUST_AC_NO := 'ALL';
        ELSE
          DBG('Msg_Address table has some data...');
          OPEN CR_MSTMS_MSG_ADDRESS;
          LOOP
            FETCH CR_MSTMS_MSG_ADDRESS BULK COLLECT
              INTO P_MSDCUSAD.V_MSTMS_MSG_ADDRESS;
            EXIT WHEN CR_MSTMS_MSG_ADDRESS%NOTFOUND;
          END LOOP;
          CLOSE CR_MSTMS_MSG_ADDRESS;
        END IF;
      
        CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') := 'MSDCUSAD';
        CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := 'NEW';
      
        IF ((P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE) OR
           (P_SOURCE_OPERATION = 'STDCIF_CLOSE')) THEN
          CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := 'CLOSE';
          L_SOURCE_OPERATION := 'MSDCUSAD_CLOSE';
          L_ACTION_CODE := 'CLOSE';
        
        ELSIF (P_SOURCE_OPERATION = 'STDCIF_REOPEN') THEN
          CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := 'REOPEN';
          L_SOURCE_OPERATION := 'MSDCUSAD_REOPEN';
          L_ACTION_CODE := 'REOPEN';
        
        ELSE
          SELECT COUNT(*)
            INTO L_COUNT
            FROM MSTMS_CUST_ADDRESS
           WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
             AND LOCATION =
                 NVL(P_CUST_REC. V_STTMS_CUSTOMER.LOC_CODE, 'CIF')
             AND MEDIA =
                 NVL(P_CUST_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA, 'MAIL');
          DBG('l_count' || L_COUNT);
          IF L_COUNT > 0 THEN
            CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := 'MODIFY';
            L_SOURCE_OPERATION := 'MSDCUSAD_MODIFY';
            MSPKS_MSDCUSAD_KERNEL.G_MOD_ADD_CIF := 'Y';
            L_ACTION_CODE := 'MODIFY';
          ELSE
            CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := 'NEW';
            L_SOURCE_OPERATION := 'MSDCUSAD_NEW';
            L_ACTION_CODE := 'NEW';
          END IF;
        END IF;
        DBG('p_msdcusad.v_mstms_msg_address.location-->' || P_MSDCUSAD.V_MSTMS_MSG_ADDRESS(1)
            .LOCATION);
        DBG('p_msdcusad.v_mstms_cust_address.location' ||
            P_MSDCUSAD.V_MSTMS_CUST_ADDRESS.LOCATION);
      
        G_FUNCTION_ID := 'STDCIF';
        IF NOT MSPKS_MSDCUSAD_MAIN.FN_MAIN('FLEXCUBE',
                                           L_SOURCE_OPERATION,
                                           'MSDCUSAD',
                                           L_ACTION_CODE,
                                           P_MULTI_TRIP_ID,
                                           1,
                                           P_MSDCUSAD,
                                           P_STATUS,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN
          GWPKS_SERVICE_ROUTER.PR_RESTORE;
          CSPKS_REQ_GLOBAL.PR_RESTORE;
          OVPKSS.GL_TBLERROR     := L_ERRTBL_BACKUP;
          CSPKS_REQ_GLOBAL.G_RES := '';
          DBG('Failed In Mspks_Msdcusad_Main.Fn_Main');
          RETURN FALSE;
        END IF;
        IF P_STATUS = 'F' THEN
          GWPKS_SERVICE_ROUTER.PR_RESTORE;
          CSPKS_REQ_GLOBAL.PR_RESTORE;
          OVPKSS.GL_TBLERROR     := L_ERRTBL_BACKUP;
          CSPKS_REQ_GLOBAL.G_RES := '';
          DBG('Failed In Mspks_Msdcusad_Main.Fn_Main');
          RETURN FALSE;
        END IF;
        GWPKS_SERVICE_ROUTER.PR_RESTORE;
        CSPKS_REQ_GLOBAL.PR_RESTORE;
        OVPKSS.GL_TBLERROR     := L_ERRTBL_BACKUP;
        CSPKS_REQ_GLOBAL.G_RES := '';
      END IF;
    
      SELECT ONCE_AUTH
        INTO LONCE_AUTH
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
      IF LONCE_AUTH = 'N' THEN
        SELECT COUNT(*)
          INTO L_CNT
          FROM MSTMS_MSG_ADDRESS
         WHERE CUSTOMER_NO = P_WRK_STDCIF.
         V_STTMS_CUSTOMER.CUSTOMER_NO
           AND LOCATION = NVL(P_CUST_REC. V_STTMS_CUSTOMER.LOC_CODE, 'CIF')
           AND MEDIA = 'MAIL'
           AND MSG_TYPE = 'ANY MSG TYPE'
           AND MODULE = 'AL'
           AND BRANCH = 'ALL';
      
        L_PARAM_VAL := CSPKSS_OS_PARAM.GET_PARAM_VAL('TPIN_GEN');
      
        IF L_PARAM_VAL = 'Y' THEN
          IF (TRPKSS.FN_GET_PROCESS_REFNO(P_WRK_STDCIF.
                                          V_STTMS_CUSTOMER.LOCAL_BRANCH,
                                          'TPIN',
                                          GLOBAL.APPLICATION_DATE,
                                          PSERIAL,
                                          L_PREF,
                                          P_ERR_CODE)) THEN
            DBG('INTO IF' || L_PREF);
            L_TPINREF := L_PREF;
            BEGIN
              INSERT INTO MSTBS_DLY_MSG_OUT
                (BRANCH,
                 REFERENCE_NO,
                 RECEIVER,
                 MODULE,
                 PRODUCT,
                 MSG_TYPE,
                 FORMAT,
                 MEDIA,
                 ESN,
                 PROCESSED_FLAG)
              VALUES
                (P_WRK_STDCIF. V_STTMS_CUSTOMER.LOCAL_BRANCH,
                 L_TPINREF,
                 P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO,
                 'CS',
                 'ACST',
                 'TPIN_OP_ADV',
                 'TPIN_OPEN',
                 'MAIL',
                 1,
                 'N');
            EXCEPTION
              WHEN OTHERS THEN
              
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'CO-0001',
                             'fn_authorise');
                RETURN FALSE;
            END;
          END IF;
        
          DBG('this is after pr gen insert in to dly msg out');
        END IF;
      END IF;
      SELECT COUNT(*)
        INTO L_CNT
        FROM SVTMS_CIF_SIG_MASTER
       WHERE CIF_ID = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO
         AND RECORD_STAT <> 'A';
      IF (L_CNT > 0) THEN
        DBG('Starting Replication Now');
        BEGIN
          SVPKSS.PR_REPLICATE_CIF_SIG(P_WRK_STDCIF.
                                      V_STTMS_CUSTOMER.CUSTOMER_NO);
          DBG('Signatures Successfully Replicated !!!');
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Signatures Not Successfully Replicated ???');
            DBG('Now Fire a job to Replicate');
            SVPKSS.PR_FIRE_JOB('svpkss.pr_replicate_cIF_sig(' || '''' ||
                               P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO || '''' ||
                               ',job);');
        END;
      END IF;
    
      DBG('about to return true from authorisation');
    END IF;
  
    DBG('P_ACTION_CODE' || P_ACTION_CODE);
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      DBG('global.lang 1 ->' || GLOBAL.LANG);
      SELECT COUNT(*)
        INTO L_CNT
        FROM CSTBS_RELATIONSHIP_LINKAGE
      
       WHERE BRANCH = P_CUST_REC. V_STTMS_CUSTOMER.LOCAL_BRANCH
         AND REF_NO = P_CUST_REC. V_STTMS_CUSTOMER.CUSTOMER_NO
         AND RELATIONSHIP = 'PRIMARY';
      DBG('global.lang 2 ->' || GLOBAL.LANG);
      DBG('L_CNT for CSTBS_RELATIONSHIP_LINKAGE' || L_CNT);
      IF L_CNT = 0 THEN
      
        DBG('global.lang 3 ->' || GLOBAL.LANG);
        DBG('Checking for LOV Validation of Relationship..');
        SELECT COUNT(*)
          INTO L_CUSTREL_COUNT
          FROM (SELECT FIELD_NAME, FIELD_DESC FROM CSTMS_RELATIONSHIP)
         WHERE FIELD_NAME = 'PRIMARY';
        IF L_CUSTREL_COUNT = 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'ST-VALS-013',
                       'PRIMARY' || '~RELATIONSHIP' || '~Linked Entities');
        END IF;
      
        BEGIN
          INSERT INTO CSTBS_RELATIONSHIP_LINKAGE
            (BRANCH, REF_NO, CATEGORY, CUSTOMER, RELATIONSHIP, INHERIT)
          VALUES
            (P_CUST_REC. V_STTMS_CUSTOMER.LOCAL_BRANCH,
             P_CUST_REC. V_STTMS_CUSTOMER.CUSTOMER_NO,
             'C',
             P_CUST_REC. V_STTMS_CUSTOMER.CUSTOMER_NO,
             'PRIMARY',
             'N');
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed to upload relationship details : ' || SQLERRM);
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF120', '');
        END;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_SERVICE.P_AUTH THEN
      DBG('>>> replication dbg::: ');
    
      BEGIN
        DBG('Function id is:' || P_FUNCTION_ID);
      
        IF NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.MAKER_ID, GLOBAL.USER_ID) <>
           NVL(GLOBAL.USER_ID, '**') AND
           NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.MAKER_ID, GLOBAL.USER_ID) =
           NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.MAKER_ID,
               NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.MAKER_ID, '*.*')) THEN
          L_AUTO_AUTH  := 'N';
          L_WRK_STDCIF := P_WRK_STDCIF;
          P_WRK_STDCIF := P_PREV_STDCIF;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Select for AutoAuth failed');
          L_AUTO_AUTH := 'Y';
      END;
    
      IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO IS NOT NULL THEN
      
        STPKS_REPLICATION_CONTROL.G_STDCIF.V_STTMS_CUSTOMER                              := P_WRK_STDCIF.V_STTMS_CUSTOMER;
        STPKS_REPLICATION_CONTROL.G_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUSTOMER := P_WRK_STDCIF.TY_MICCUSTM.V_MITMS_CUSTOMER_DEFAULT.CUSTOMER;
        STPKS_REPLICATION_CONTROL.G_STDCIF.V_STTMS_CUST_PERSONAL.CUSTOMER_NO             := P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.CUSTOMER_NO;
      
        IF NOT STPKSS_REPLICATION_CONTROL.FN_HANDLE_REQUEST('STDCIF',
                                                            P_WRK_STDCIF.V_STTMS_CUSTOMER.RECORD_STAT,
                                                            P_WRK_STDCIF.V_STTMS_CUSTOMER.MOD_NO,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
          DBG('failed in stpkss_replication_control.Fn_Handle_Request: ' ||
              P_ERR_CODE);
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       NVL(P_ERR_CODE, 'ST-REPL-10'),
                       NULL);
          STPKS_REPLICATION_CONTROL.G_STDCIF := NULL;
          RETURN FALSE;
        END IF;
        STPKS_REPLICATION_CONTROL.G_STDCIF := NULL;
        DBG('return from stpkss_replication_control.Fn_Handle_Request');
      END IF;
    
      IF L_AUTO_AUTH = 'N' THEN
        P_WRK_STDCIF := L_WRK_STDCIF;
      END IF;
    
    END IF;
  
    DBG('p_wrk_stdcif. v_sttms_customer.customer_no~p_action' || P_STDCIF.
        V_STTMS_CUSTOMER.CUSTOMER_NO || '#~p_action_code~' ||
        P_ACTION_CODE);
  
    IF P_ACTION_CODE IN
       (CSPKS_SERVICE.P_DELETE, 'DELETE', CSPKS_SERVICE.P_NEW, 'NEW') OR
       (P_ACTION_CODE = 'VERSIONDELETE' AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH = 'N') THEN
    
      IF NOT STPKS_ACCGEN.FN_UPDATE_UNUSEDCUSTNO(P_SOURCE,
                                                 P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                 P_ACTION_CODE,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAMS) THEN
        DBG('ERROR~' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF (NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT, 'N') = 'Y') THEN
      IF (NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH,
              P_WRK_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH) = 'N') THEN
        IF (P_ACTION_CODE IN ('NEW', 'DEFAULT')) THEN
          DBG('Calling stpks_stdcif_utils_0.fn_cust_auto_account');
          IF NOT STPKS_STDCIF_UTILS_0.FN_CUST_AUTO_ACCOUNT(P_FUNCTION_ID,
                                                           P_SOURCE,
                                                           P_ACTION_CODE,
                                                           P_WRK_STDCIF,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
            DBG('Failed in stpks_stdcif_utils_0.fn_cust_auto_account' ||
                SQLERRM);
            RETURN FALSE;
          END IF;
        ELSE
          IF (P_ACTION_CODE = 'MODIFY') THEN
            DBG('Calling stpks_stdcif_utils_0.fn_cust_mod_auto_acc');
            IF NOT
                STPKS_STDCIF_UTILS_0.FN_CUST_MOD_AUTO_ACC(P_FUNCTION_ID,
                                                          P_SOURCE,
                                                          P_ACTION_CODE,
                                                          P_WRK_STDCIF,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
              DBG('Failed in stpks_stdcif_utils_0.fn_cust_mod_auto_acc' ||
                  SQLERRM);
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      L_STATUS := 'A';
    ELSE
      L_STATUS := 'U';
    END IF;
  
    DBG('LIMITS_11.3.1:***: p_action_code=>' || P_ACTION_CODE ||
        '; p_source=>' || P_SOURCE);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH AND P_SOURCE <> 'FLEXCUBE' AND
       L_UPLOADED_STATUS = 'U' THEN
      DBG('LIMITS_11.3.1:***: p_wrk_stdcif := p_prev_stdcif;');
      P_WRK_STDCIF := P_PREV_STDCIF;
    END IF;
  
    DBG('LIMITS_11.3.1:45: p_wrk_stdcif.v_sttms_customer.track_limits:' ||
        P_WRK_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS);
    IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS, 'N') = 'Y' THEN
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_AUTH) THEN
        DBG('LIMITS_11.3.1:7: calling in stpks_stdcif_utils_0.fn_cust_liab_link_process');
      
        IF NOT
            (STPKS_STDCIF_UTILS_0.FN_CUST_LIAB_LINK_PROCESS(P_SOURCE,
                                                            P_SOURCE_OPERATION,
                                                            P_ACTION_CODE,
                                                            P_MULTI_TRIP_ID,
                                                            G_STDCIF,
                                                            P_FUNCTION_ID,
                                                            L_STATUS,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS)) THEN
        
          DBG('LIMITS_11.3.1:7: failed in stpks_stdcif_utils_0.fn_cust_liab_link_process');
          RETURN FALSE;
        
        END IF;
      
      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      
        BEGIN
          DELETE FROM STTM_AUTO_LIAB_DETAILS LD
           WHERE LD.CUST_NO = P_STDCIF.V_STVWS_CUST_LIAB.CUST_NO;
          DELETE FROM STTM_AUTO_LIAB_SCORE LS
           WHERE LS.LIAB_NO = P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
          DELETE FROM STTM_AUTO_LIAB_RATING LC
           WHERE LC.LIAB_NO = P_STDCIF.V_STVWS_CUST_LIAB.LIAB_NO;
          DELETE FROM STTM_AUTO_LIAB_EXPOSURE LE
           WHERE LE.LIAB_CUST_NO = P_STDCIF.V_STVWS_CUST_LIAB.CUST_NO;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('failed in deleting the records' || SQLERRM);
            DBG('failed in deleting the record at line' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;
      
      END IF;
      DBG('LIMITS_11.3.1:7: success in stpks_stdcif_utils_0.fn_cust_liab_link_process');
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW OR
          P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      DECLARE
        L_STDCIF STPKS_STDCIF_MAIN.TY_STDCIF;
      BEGIN
        P_WRK_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO := NULL;
        P_WRK_STDCIF.V_STVWS_CUST_LIAB_SCORE       := L_STDCIF.V_STVWS_CUST_LIAB_SCORE;
        P_WRK_STDCIF.V_STVWS_CUST_LIAB_RATING      := L_STDCIF.V_STVWS_CUST_LIAB_RATING;
        P_WRK_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE    := L_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE;
      END;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      DECLARE
        L_STDCIF STPKS_STDCIF_MAIN.TY_STDCIF;
      BEGIN
        IF STPKS_STDCIF_UTILS_0.FN_STORE_LIAB_LINK(P_SOURCE,
                                                   G_STDCIF,
                                                   'CLEANLIAB',
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
          DBG('I Cleaned');
        END IF;
        P_WRK_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO := NULL;
        P_WRK_STDCIF.V_STVWS_CUST_LIAB_SCORE       := L_STDCIF.V_STVWS_CUST_LIAB_SCORE;
        P_WRK_STDCIF.V_STVWS_CUST_LIAB_RATING      := L_STDCIF.V_STVWS_CUST_LIAB_RATING;
        P_WRK_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE    := L_STDCIF.V_STVWS_CUST_LIAB_EXPOSURE;
      END;
    END IF;
  
    DBG('Calling cspks_req_utils.fn_get_upload_status');
  
    DBG('AUTO CREATE ACCOUNT IS' ||
        P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT);
    IF (NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT, 'N') = 'Y') THEN
      IF (NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH,
              P_WRK_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH) = 'N') THEN
        DBG('p_action_code IS --->' || P_ACTION_CODE);
        DBG('p_prev_stdcif.v_sttms_customer.default_media --> ' ||
            P_PREV_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA);
        DBG('p_wrk_stdcif.v_sttms_customer.default_media --> ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA);
        P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA := NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA,
                                                           P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA);
        DBG('p_wrk_stdcif.v_sttms_customer.default_media ==> ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.DEFAULT_MEDIA);
        DBG('Calling stpks_stdcif_utils_0.fn_auto_create_account');
        IF NOT STPKS_STDCIF_UTILS_0.FN_AUTO_CREATE_ACCOUNT(P_FUNCTION_ID,
                                                           P_ACTION_CODE,
                                                           P_SOURCE,
                                                           P_WRK_STDCIF,
                                                           P_PREV_STDCIF,
                                                           L_STATUS,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
          DBG('Failed in stpks_stdcif_utils_0.fn_auto_create_account' ||
              SQLERRM);
          RETURN FALSE;
        END IF;
        DBG('p_wrk_stdcif.ty_stccuacc.v_stvws_auto_account.CUST_AC_NO : ' ||
            P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO);
        P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CUST_AC_NO := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO;
        DBG('p_wrk_stdcif.v_sttms_customer.AUTO_CUST_AC_NO  : ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CUST_AC_NO);
        IF (NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.JOINT_AC_INDICATOR,
                'N') = 'N') THEN
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT;
        END IF;
        IF (NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CHECK_BOOK_REQUEST,
                'N') = 'N') THEN
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK;
        END IF;
        IF (NVL(P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.DEBIT_CARD_REQUEST,
                'N') = 'N') THEN
          P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD;
        END IF;
      END IF;
    ELSE
    
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT       := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT     := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES  := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_NOMINEES;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_CHECKLIST;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS   := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DOC_REMARKS;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK       := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_CHQBOOK;
      P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD     := L_STDCIF.TY_STCCUACC.V_STVWS_AUTO_DEBITCARD;
      P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL   := L_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL;
      P_WRK_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT       := L_STDCIF.TY_STCCUACC.V_STTMS_CUST_ACCOUNT;
      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING      := L_STDCIF.TY_STCCUACC.V_MITBS_CLASS_MAPPING;
      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_ACCOUNT_CHANGE_LOG := L_STDCIF.TY_STCCUACC.V_MITBS_ACCOUNT_CHANGE_LOG;
      P_WRK_STDCIF.TY_STCCUACC.V_MITBS_BAL_TRANSFER_LOG   := L_STDCIF.TY_STCCUACC.V_MITBS_BAL_TRANSFER_LOG;
    END IF;
  
    DBG('customer account no for upload is ---> ' ||
        P_PREV_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO);
  
    IF (NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT, 'N') = 'Y') AND
       NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH,
           P_PREV_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH) = 'N' AND
       P_ACTION_CODE IN ('AUTH') THEN
      BEGIN
        UPDATE STTMS_CUSTOMER
           SET AUTO_CUST_AC_NO = P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO
         WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in WOT of sttms_customer' || SQLERRM);
          DBG('The error is here' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;
    END IF;
  
    DBG('p_action_code is ' || P_ACTION_CODE);
    DBG('Coming here to check duplicate customer-dedup validation');
  
    IF P_ACTION_CODE IN ('NEW', 'MODIFY', 'REOPEN') THEN
    
      IF NOT STPKS_DEDUP_DYNAMIC.FNGETDEDUP(P_WRK_STDCIF) THEN
        DBG('error in calling STPKS_DEDUP_DYNAMIC.fngetDedup');
      END IF;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY, '*') !=
         NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY, '*') THEN
        DBG('Updating customer_cat into sttbs_account table');
        UPDATE STTBS_ACCOUNT
           SET CUSTOMER_CAT = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY
         WHERE CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND AC_OR_GL IN ('A', 'L');
      END IF;
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1, '*') !=
         NVL(P_PREV_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1, '*') THEN
        DBG('Updating customer_name1 into sttbs_account table');
        UPDATE STTBS_ACCOUNT
           SET CUST_NAME1 = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1
         WHERE CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND AC_OR_GL IN ('A', 'L');
      END IF;
    END IF;
  
    DBG('calling stpkss_FATCA_US_indicia.fn_process_FATCA');
    DBG('action code ->' || P_ACTION_CODE);
  
    IF P_ACTION_CODE = 'AUTH' THEN
      DBG('calling stpkss_FATCA_US_indicia.fn_process_FATCA.the function id is ->' ||
          P_FUNCTION_ID);
      IF NOT STPKSS_FATCA_US_INDICIA.FN_PROCESS_FATCA('BABIDBAT',
                                                      P_FUNCTION_ID,
                                                      NULL,
                                                      P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                      P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                                                      
                                                     ,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
        DBG('failed in stpkss_FATCA_US_indicia.fn_process_FATCA->' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    
      STPKSS_FATCA_OBLIG_ENTRY.PR_OBLIG_FATCACOM(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
    
    END IF;
  
    IF P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.CUSTOMER_NO   := NULL;
      P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.CUSTOMER_NO := NULL;
      P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD6        := NULL;
      P_WRK_STDCIF.V_STTMS_CUSTOMER__A.CUSTOMER_NO      := NULL;
    END IF;
  
    BEGIN
    
      IF P_ACTION_CODE IN ('AUTH') AND
         P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS IS NOT NULL THEN
        DBG(' p_wrk_stdcif.ty_stccuacc.v_stvws_auto_account.account_class' ||
            P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS);
      
        SELECT MULTI_CURRENCY
          INTO L_MULTI_FLAG
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS;
      
        IF L_MULTI_FLAG = 'Y' THEN
        
          SELECT COUNT(*)
            INTO L_COUNT_1
            FROM STTM_MULTI_CCY_ACCNT_MASTER
           WHERE MULTI_CCY_AC_NO =
                 P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MULTI_CCY_AC_NO;
        
          INSERT INTO STTM_MULTI_CCY_ACCNT_MASTER
            (CUSTOMER_NO,
             BRANCH_CODE,
             MULTI_CCY_AC_NO,
             MAIN_AC_NO,
             ACCOUNT_CLASS,
             CCY,
             AUTH_STAT,
             MAKER_ID,
             MAKER_DT_STAMP,
             CHECKER_DT_STAMP,
             CHECKER_ID)
          VALUES
            (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MULTI_CCY_AC_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.ACCOUNT_CLASS,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CCY,
             'A',
             GLOBAL.USER_ID,
             CSFN_TIMESTAMP,
             CSFN_TIMESTAMP,
             GLOBAL.USER_ID);
          INSERT INTO STTM_MULTI_CCY_ACCNT_DTL
            (MULTI_CCY_AC_NO, SUB_AC_NO, CCY)
          VALUES
            (P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.MULTI_CCY_AC_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CCY);
        END IF;
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in inserting !!!');
    END;
  
    DBG('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcif_Kernel.Fn_Post_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UPLOAD_DB;

  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CHILD_FUNCTION   IN VARCHAR2,
                        P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                        P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                        P_QRYDATA_REQD     IN VARCHAR2,
                        P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                        P_WRK_STDCIF       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('In Fn_Pre_Query..');
    DBG('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcif_Kernel.Fn_Pre_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;

  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CHILD_FUNCTION   IN VARCHAR2,
                         P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                         P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                         P_QRYDATA_REQD     IN VARCHAR2,
                         P_STDCIF           IN STPKS_STDCIF_MAIN.TY_STDCIF,
                         P_WRK_STDCIF       IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    CURSOR C_UDF_AUX IS
      SELECT *
        FROM STTM_BASE_TABLE_UDF_DETAIL
       WHERE FUNCTION_ID = 'STDCIF';
  
    L_MASK        VARCHAR2(1);
    CNT           INTEGER := 0;
    L_COUNT_1     NUMBER;
    LCOUNT        NUMBER;
    L_UDF_DETAILS UVPKS_UDF_UPLOAD.TY_UPL_FUNC_UDF;
  
    L_UDF_DTL CSTM_FUNCTION_USERDEF_FIELDS%ROWTYPE;
    L_CONT    NUMBER;
  
    L_REC_KEY VARCHAR2(50);
  
    L_SNCK_STATUS CSTB_SNCK_STATUS.SNCK_STATUS%TYPE;
    L_KEY_ID      STTB_RECORD_MASTER.KEY_ID%TYPE;
    L_CURR_STAGE  VARCHAR2(20);
  
    L_MOD_NO VARCHAR2(3);
  BEGIN
    DBG('In Fn_Post_Query..');
  
    DBG('p_action_code ->' || P_ACTION_CODE);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
      DBG('Customer No.: ' || P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO);
      DBG('Is_forgotten: ' || P_WRK_STDCIF.V_STTMS_CUSTOMER.IS_FORGOTTEN);
      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.IS_FORGOTTEN, 'N') = 'Y' THEN
        DBG('Forgotten Customer Details cannot be Queried');
        P_ERR_CODE   := 'ST-VALS-002';
        P_ERR_PARAMS := P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_QUERY,
                         CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_REOPEN)
    
     THEN
      SELECT COUNT(*)
        INTO LCOUNT
        FROM STTMS_CUSTOMER A
       WHERE A.CUSTOMER_NO = P_WRK_STDCIF.
       V_STTMS_CUSTOMER.CUSTOMER_NO
         AND ((A.GROUP_CODE IS NOT NULL AND EXISTS
              (SELECT 1
                  FROM STVWS_USER_GROUP B
                 WHERE B.USER_ID = GLOBAL.USER_ID
                   AND B.GROUP_CODE = A.GROUP_CODE)) OR
             A.GROUP_CODE IS NULL)
            
         AND ((A.ACCESS_GROUP IS NOT NULL AND EXISTS
              (SELECT 1
                  FROM STVWS_USER_ACCESS B
                 WHERE B.USER_ID = GLOBAL.USER_ID
                   AND B.ACCESS_GROUP = A.ACCESS_GROUP)) OR
             A.ACCESS_GROUP IS NULL);
    
      IF LCOUNT = 0 THEN
        DBG('User is restricted to query the details of this customer');
        P_ERR_CODE   := 'ST-GRP03';
        P_ERR_PARAMS := P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Function id :- ' || CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'));
    IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('FUNCTIONID') AND
       CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') <> 'STDCIFAD' THEN
      DBG('befor calling cursor');
    
      PR_POPULAT_AUX_UDF(P_STDCIF, P_WRK_STDCIF, P_ACTION_CODE);
    
    ELSE
      IF P_FUNCTION_ID = 'STDCIF' THEN
        PR_POPULAT_AUX_UDF(P_STDCIF, P_WRK_STDCIF, P_ACTION_CODE);
      END IF;
    
    END IF;
  
    DBG('befor calling cursor');
  
    SELECT COUNT(*)
      INTO CNT
      FROM STTM_CUST_PERSONAL_JOINT
     WHERE CUSTOMER_NO = P_WRK_STDCIF. V_STTMS_CUSTOMER.CUSTOMER_NO;
    DBG('Count' || CNT);
    IF CNT > 0 THEN
      DBG('inside joint flag');
      P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD8 := 'Y';
    END IF;
  
    BEGIN
      SELECT FIELD_NAME
        INTO P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD1
        FROM STTMS_BASE_TABLE_UDF_DETAIL
       WHERE FUNCTION_ID = P_FUNCTION_ID
         AND SEQ_NO = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data for char_field1');
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD1 := NULL;
    END;
  
    BEGIN
      SELECT FIELD_NAME
        INTO P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD2
        FROM STTMS_BASE_TABLE_UDF_DETAIL
       WHERE FUNCTION_ID = P_FUNCTION_ID
         AND SEQ_NO = 2;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data for char_field2');
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD2 := NULL;
    END;
  
    BEGIN
      SELECT FIELD_NAME
        INTO P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD3
        FROM STTMS_BASE_TABLE_UDF_DETAIL
       WHERE FUNCTION_ID = P_FUNCTION_ID
         AND SEQ_NO = 3;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data for char_field3');
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD3 := NULL;
    END;
  
    BEGIN
      SELECT FIELD_NAME
        INTO P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD4
        FROM STTMS_BASE_TABLE_UDF_DETAIL
       WHERE FUNCTION_ID = P_FUNCTION_ID
         AND SEQ_NO = 4;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data for char_field4');
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD4 := NULL;
    END;
  
    BEGIN
      SELECT FIELD_NAME
        INTO P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD5
        FROM STTMS_BASE_TABLE_UDF_DETAIL
       WHERE FUNCTION_ID = P_FUNCTION_ID
         AND SEQ_NO = 5;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data for char_field5');
        P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD5 := NULL;
    END;
  
    IF (NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT, 'N') = 'Y') AND
       (P_WRK_STDCIF.V_STTMS_CUSTOMER.ONCE_AUTH = 'N') THEN
      DBG('p_action_code is ' || P_ACTION_CODE);
    
      BEGIN
        DBG('count is --->' || L_COUNT_1);
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT_1
            FROM STVWS_AUTO_ACCOUNT
           WHERE CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In WOT of STVWS_AUTO_ACCOUNT ' || SQLERRM);
            RETURN FALSE;
        END;
        DBG('count is ' || L_COUNT_1);
        IF L_COUNT_1 > 0 THEN
          DBG('Calling stpks_stdcif_utils_0.fn_query_sttms_account');
          IF NOT
              STPKS_STDCIF_UTILS_0.FN_QUERY_STTMS_ACCOUNT(P_FUNCTION_ID,
                                                          P_SOURCE,
                                                          P_ACTION_CODE,
                                                          P_WRK_STDCIF,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
            DBG('Failed in stpks_stdcif_utils_0.fn_query_sttms_account ' ||
                SQLERRM);
            RETURN FALSE;
          END IF;
        END IF;
      
        L_REC_KEY := P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.BRANCH_CODE || '~' ||
                     P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACCOUNT.CUST_AC_NO || '~';
      
        DBG('rec key is ' || L_REC_KEY);
      
        BEGIN
          SELECT COUNT(*)
            INTO L_CONT
            FROM CSTM_FUNCTION_USERDEF_FIELDS
           WHERE FUNCTION_ID = 'STDCUSAC'
             AND REC_KEY = L_REC_KEY;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_CONT := 0;
          WHEN OTHERS THEN
            DBG('IN WOT of cstm_function_userdef_fields ' || SQLERRM);
            RETURN FALSE;
        END;
      
        DBG('l_cont' || L_CONT);
      
        IF L_CONT > 0 THEN
        
          IF NOT UVPKS_UDF_UPLOAD.FN_QUERY_FUNC_UDFDETAILS('STDCUSAC',
                                                           L_REC_KEY,
                                                           L_UDF_DETAILS,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
            RETURN FALSE;
          END IF;
          DBG('l_udf_details COUNT : : ' || L_UDF_DETAILS.COUNT);
          IF L_UDF_DETAILS.COUNT > 0 THEN
            DECLARE
              L_CNT1 NUMBER := L_UDF_DETAILS.FIRST;
            BEGIN
              LOOP
                DBG('field_name is ;;;;,,,....' || L_UDF_DETAILS(L_CNT1)
                    .FIELD_NAME);
                DBG('field value is ;;;;' || L_UDF_DETAILS(L_CNT1)
                    .FIELD_VAL);
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1).FIELD_NAME := L_UDF_DETAILS(L_CNT1)
                                                                                        .FIELD_NAME;
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1).FIELD_VAL := L_UDF_DETAILS(L_CNT1)
                                                                                       .FIELD_VAL;
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1).DATA_TYPE := L_UDF_DETAILS(L_CNT1)
                                                                                       .DATA_TYPE;
                P_WRK_STDCIF.TY_STCCUACC.V_FUNC_UDF_UPLOAD_DETAIL(L_CNT1).VAL_TYPE := L_UDF_DETAILS(L_CNT1)
                                                                                      .VAL_TYPE;
                EXIT WHEN L_CNT1 = L_UDF_DETAILS.LAST;
                L_CNT1 := L_UDF_DETAILS.NEXT(L_CNT1);
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('The error is ' || SQLERRM);
                DBG('The error is here ---> ' ||
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                RETURN FALSE;
            END;
          END IF;
        END IF;
      END;
    
    END IF;
  
    DBG('25152096 :: p_wrk_stdcif.v_sttms_customer.track_limits :: ' ||
        P_WRK_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS);
    IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.TRACK_LIMITS, 'N') = 'Y' THEN
      IF NOT STPKS_STDCIF_UTILS_0.FN_LOAD_LIAB_LINK(P_WRK_STDCIF,
                                                    'POSTQUERY',
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DBG('LIMITS_11.3.1:8:');
        RETURN FALSE;
      END IF;
    ELSE
      P_WRK_STDCIF.V_STTMS_CUSTOMER.LIABILITY_NO := NULL;
    END IF;
  
    IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN
       ('C', 'B', 'U', 'R', 'S', 'N') THEN
      --loan sector sampath changes
    
      IF P_ACTION_CODE IN ('EXECUTEQUERY', 'AUTH')
      
       THEN
        DBG('Coming here inside c or b and execute query');
        BEGIN
          SELECT ADDRESS_LINE1,
                 ADDRESS_LINE2,
                 ADDRESS_LINE3,
                 ADDRESS_LINE4,
                 CUSTOMER_NAME1,
                 JOINT_VENTURE,
                 COUNTRY,
                 NATIONALITY,
                 LANGUAGE,
                 KYC_REF_NO,
                 KYC_DETAILS,
                 UNIQUE_ID_NAME,
                 UNIQUE_ID_VALUE,
                 PINCODE
            INTO P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE2,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE3,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE4,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.CUSTOMER_NAME1,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.JOINT_VENTURE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.NATIONALITY,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.LANGUAGE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.KYC_REF_NO,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.KYC_DETAILS,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.UNIQUE_ID_NAME,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.UNIQUE_ID_VALUE,
                 P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('no_data_found in sttms_customer' || SQLERRM);
            RETURN FALSE;
          WHEN OTHERS THEN
            DBG('In WOT of sttms_customer' || SQLERRM);
            RETURN FALSE;
        END;
        BEGIN
          SELECT TELEPHONE,
                 FAX,
                 E_MAIL,
                 MOBILE_NUMBER,
                 CUST_COMM_MODE,
                 TEL_ISD_NO,
                 MOB_ISD_NO,
                 FAX_ISD_NO
            INTO P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.TELEPHONE,
                 P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX,
                 P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.E_MAIL,
                 P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.MOBILE_NUMBER,
                 P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.CUST_COMM_MODE,
                 
                 P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.TEL_ISD_NO,
                 P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO,
                 P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX_ISD_NO
          
            FROM STTMS_CUST_PERSONAL
           WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('no_data_found in sttms_customer' || SQLERRM);
            RETURN FALSE;
          WHEN OTHERS THEN
            DBG('In WOT of sttms_customer' || SQLERRM);
            RETURN FALSE;
        END;
      END IF;
      BEGIN
        DBG('p_wrk_stdcif.v_sttms_customer.address_line1 --' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
        DBG('p_wrk_stdcif.v_sttms_customer.address_line2 0' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2);
        DBG('p_wrk_stdcif.v_sttms_customer__a.address_line1  ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1);
        DBG('p_wrk_stdcif.v_sttms_customer__a.address_line2  ' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE2);
        DBG('p_wrk_stdcif.v_sttms_customer__a.pincode' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE);
        DBG('p_stdcif.v_sttms_customer__a.pincode' ||
            P_STDCIF.V_STTMS_CUSTOMER__A.PINCODE);
      
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1       := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE1,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE1);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE2       := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE2,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE2);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE3       := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE3,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE3);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE4       := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.ADDRESS_LINE4,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.ADDRESS_LINE4);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.CUSTOMER_NAME1      := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.CUSTOMER_NAME1,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NAME1);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.JOINT_VENTURE       := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.JOINT_VENTURE,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.JOINT_VENTURE);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY             := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.NATIONALITY         := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.NATIONALITY,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.LANGUAGE            := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.LANGUAGE,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.LANGUAGE);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.KYC_REF_NO          := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.KYC_REF_NO,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.KYC_REF_NO);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.KYC_DETAILS         := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.KYC_DETAILS,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.KYC_DETAILS);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.UNIQUE_ID_NAME      := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.UNIQUE_ID_NAME,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME);
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.UNIQUE_ID_VALUE     := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.UNIQUE_ID_VALUE,
                                                                    P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE);
        P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.TELEPHONE      := NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.TELEPHONE,
                                                                    P_STDCIF.V_STTMS_CUST_PERSONAL.TELEPHONE);
        P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX            := NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX,
                                                                    P_STDCIF.V_STTMS_CUST_PERSONAL.FAX);
        P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.E_MAIL         := NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.E_MAIL,
                                                                    P_STDCIF.V_STTMS_CUST_PERSONAL.E_MAIL);
        P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.MOBILE_NUMBER  := NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.MOBILE_NUMBER,
                                                                    P_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER);
        P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.CUST_COMM_MODE := NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.CUST_COMM_MODE,
                                                                    P_STDCIF.V_STTMS_CUST_PERSONAL.CUST_COMM_MODE);
      
        P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.TEL_ISD_NO := NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.TEL_ISD_NO,
                                                                P_STDCIF.V_STTMS_CUST_PERSONAL.TEL_ISD_NO);
        P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO := NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.MOB_ISD_NO,
                                                                P_STDCIF.V_STTMS_CUST_PERSONAL.MOB_ISD_NO);
        P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX_ISD_NO := NVL(P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.FAX_ISD_NO,
                                                                P_STDCIF.V_STTMS_CUST_PERSONAL.FAX_ISD_NO);
      
        P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE := NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER__A.PINCODE,
                                                        P_STDCIF.V_STTMS_CUSTOMER__A.PINCODE);
      END;
    
    END IF;
  
    IF P_SOURCE <> 'FLEXCUBE' AND
       P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
       P_ACTION_CODE = 'MODIFY' THEN
      DBG('For Individual Customer,Corptag Parameters to set null');
      P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD6      := NULL;
      P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.CUSTOMER_NO := NULL;
    END IF;
  
    IF P_ACTION_CODE = 'MODIFY' THEN
      DBG('dakr P_stdcif.v_sttms_customer.mfi_customer' ||
          P_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER);
      DBG('dakr 1 p_Wrk_stdcif.v_sttms_customer.mfi_customer' ||
          P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER);
      IF (P_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER = 'N' AND
         P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER IS NULL) THEN
        P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER := 'N';
        DBG('dakr 2 p_Wrk_stdcif.v_sttms_customer.mfi_customer' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.MFI_CUSTOMER);
      END IF;
    END IF;
  
    IF P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY AND
       P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.CUSTOMER_NO   := NULL;
      P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A.CUSTOMER_NO := NULL;
      P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD6        := NULL;
    END IF;
  
    DBG('Post Query p_wrk_stdcif.v_sttms_cust_doc_checklist Count check-->' ||
        P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.COUNT);
    DBG('Action Code-->' || P_ACTION_CODE);
    IF P_ACTION_CODE = 'COPY' THEN
      P_WRK_STDCIF.V_STTMS_CUST_DOC_CHECKLIST.DELETE;
    END IF;
  
    L_MASK := SMPKS_MASK_USER.FN_SETUSRCTX(GLOBAL.USER_ID, P_FUNCTION_ID);
    DBG('Action Code -->' || P_ACTION_CODE || 'Masking -->' || L_MASK);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY AND L_MASK = 'Y' THEN
      DBG('Masking for Customer..');
      IF P_WRK_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT > 0 THEN
        FOR I_2 IN 1 .. P_WRK_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT LOOP
          IF P_WRK_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I_2)
           .CUSTOMER IS NOT NULL THEN
            BEGIN
              SELECT CUSTOMER_NAME1
                INTO P_WRK_STDCIF.TY_CSCCURLN.DESC_FIELDS('CSTBS_RELATIONSHIP_LINKAGE')(I_2)('DESCP')
                FROM STVW_STTM_CUSTOMER
               WHERE AUTH_STAT = 'A'
                 AND RECORD_STAT = 'O'
                 AND CUSTOMER_NO = P_WRK_STDCIF.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I_2)
                    .CUSTOMER
                 AND ROWNUM < 2;
            EXCEPTION
              WHEN OTHERS THEN
                P_WRK_STDCIF.TY_CSCCURLN.DESC_FIELDS('CSTBS_RELATIONSHIP_LINKAGE')(I_2)('DESCP') := NULL;
                DBG(SQLERRM);
                DBG('Failed in selecting the Desc Fields For  :CUSTOMER');
            END;
          END IF;
        END LOOP;
      END IF;
      IF NOT STPKS_STDCIF_UTILS_1.FN_MASK_QUERY(P_WRK_STDCIF,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
        DBG('Error occured in stpks_stdcif_utils_1.Fn_Mask_Query..');
      END IF;
    END IF;
  
    DBG('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of stpks_stdcif_Kernel.Fn_Post_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

  FUNCTION FN_MFI_CHK_ACCESS(P_ACC_OFF    IN VARCHAR2,
                             P_LINK       IN VARCHAR2,
                             P_FUNC       IN VARCHAR2 DEFAULT NULL,
                             P_ERR_CODE   OUT VARCHAR2,
                             P_ERR_PARAMS OUT VARCHAR2) RETURN BOOLEAN IS
    CURSOR CUR_CENTER IS
      SELECT *
        FROM MFTM_CENTER_DEFINITION
       WHERE ACCOUNT_OFFICER = GLOBAL.USER_ID;
    CURSOR CUR_GROUP_CEN(C_CENTER VARCHAR2) IS
      SELECT *
        FROM MFTM_CENTER_CURRENT_MEMBER
       WHERE CENTER_CODE = NVL(C_CENTER, CENTER_CODE);
    CURSOR CUR_GROUP IS
      SELECT *
        FROM MFTM_GROUP_DEFINITION
       WHERE ACCOUNT_OFFICER = GLOBAL.USER_ID;
    RES_CIF         MFTM_GROUP_MEMBER%ROWTYPE;
    L_MFI_USER      VARCHAR2(1);
    L_CEN_HIERARCHY VARCHAR2(1);
    L_CNT           NUMBER := 0;
    P_COUNT         NUMBER := 0;
    P_CIF           VARCHAR2(20);
  
  BEGIN
    DBG('In fn_mfi_chk_access starts');
    BEGIN
      SELECT MFI_USER
        INTO L_MFI_USER
        FROM SMTB_USER
       WHERE USER_ID = NVL(P_ACC_OFF, GLOBAL.USER_ID);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('no account officer for center and group type customer');
        RETURN TRUE;
    END;
    IF L_MFI_USER = 'Y' THEN
      IF P_FUNC = 'C' THEN
        DBG('Mfi level is Center..');
        BEGIN
          SELECT CENTER_CIF_ID
            INTO P_CIF
            FROM MFTM_CENTER_DEFINITION
           WHERE CENTER_CODE = P_LINK;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Center Cif ID not maintained..');
            P_ERR_CODE   := 'FX-PLIQ-001';
            P_ERR_PARAMS := 'this Center Code.';
            RETURN FALSE;
        END;
      
        IF P_CIF IS NOT NULL THEN
          DBG('Checking Account Officer linkage..');
          SELECT COUNT(*)
            INTO P_COUNT
            FROM MFTM_AO_CIF_LINKAGE
           WHERE ACCOUNT_OFFICER = GLOBAL.USER_ID
             AND CUSTOMER_ID = P_CIF;
          IF P_COUNT > 0 THEN
            DBG('User mapped as Acc officer for the Cif..');
            RETURN TRUE;
          END IF;
        END IF;
      ELSIF P_FUNC = 'G' THEN
        DBG('Mfi level is Group..');
        BEGIN
          SELECT GROUP_CIF_ID
            INTO P_CIF
            FROM MFTM_GROUP_DEFINITION
           WHERE GROUP_CODE = P_LINK;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Group Cif ID not maintained..');
            P_ERR_CODE   := 'GW-FXLQ-001';
            P_ERR_PARAMS := 'this Group Code.';
            RETURN FALSE;
        END;
      
        IF P_CIF IS NOT NULL THEN
          DBG('Checking Account Officer linkage..');
          SELECT COUNT(*)
            INTO P_COUNT
            FROM MFTM_AO_CIF_LINKAGE
           WHERE ACCOUNT_OFFICER = GLOBAL.USER_ID
             AND CUSTOMER_ID = P_CIF;
          IF P_COUNT > 0 THEN
            DBG('User mapped as Acc officer for the Cif..');
            RETURN TRUE;
          END IF;
        END IF;
      ELSE
        SELECT COUNT(*)
          INTO L_CNT
          FROM MFTM_AO_CIF_LINKAGE
         WHERE ACCOUNT_OFFICER = GLOBAL.USER_ID
           AND CUSTOMER_ID = P_LINK;
        DBG('count  is' || L_CNT);
        IF L_CNT = 0 THEN
          SELECT CENTER_HIERARCHY
            INTO L_CEN_HIERARCHY
            FROM CLTM_BRANCH_PARAMETERS
           WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
             AND MODULE_ID = 'MF';
          DBG('cen hier is' || L_CEN_HIERARCHY);
        
          FOR REC_CENTER IN CUR_CENTER LOOP
            DBG('inside cur center loop');
            FOR REC_GROUP IN CUR_GROUP_CEN(REC_CENTER.CENTER_CODE) LOOP
              DBG('inside cur_group_cen loop');
              SELECT COUNT(*)
                INTO L_CNT
                FROM MFTM_GROUP_MEMBER
               WHERE GROUP_CODE = REC_GROUP.GROUP_CODE
                 AND CUSTOMER_NO = P_LINK;
              DBG('count  is-->' || L_CNT);
              IF L_CNT > 0 THEN
                RETURN TRUE;
              END IF;
            END LOOP;
          END LOOP;
        
          FOR REC_GROUP IN CUR_GROUP LOOP
            DBG('inside cur_group loop');
            SELECT COUNT(*)
              INTO L_CNT
              FROM MFTM_GROUP_MEMBER
             WHERE GROUP_CODE = REC_GROUP.GROUP_CODE
               AND CUSTOMER_NO = P_LINK;
            DBG('count  is------>' || L_CNT);
            IF L_CNT > 0 THEN
              RETURN TRUE;
            END IF;
          END LOOP;
        
        ELSE
          RETURN TRUE;
        END IF;
      END IF;
    END IF;
    P_ERR_CODE   := 'ST-CIF322';
    P_ERR_PARAMS := NULL;
    RETURN FALSE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of stpks_stdcif_Cluster.fn_post_query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_MFI_CHK_ACCESS;

END STPKS_STDCIF_KERNEL;
