insert into LMTM_TYPE_VALUES (TYPE, CODE, VALUE)
values ('C', 'S0005', 'Jewelry-Gem-Precious Mental Business');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0006', 'Pawn Shop');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0007', 'Stock Exchange');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0008', 'Real Estate Businesses (Including Agents)');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0009', 'Law firm');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0010', 'Accounting firms');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0011', 'Embassy');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0012', 'Casinos Industry');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0015', 'Wholesale and Retail Trades (Physical Store)');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0016', 'Import-Export');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0017', 'Education');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0018', 'Health Care Center');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0019', 'Entertainment/Fine Arts');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0020', 'Hotel/Tourism/Restaurant/Beverage');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0022', 'Agriculture, Forestry and Fisheries');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0023', 'Unemployed');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0025', 'None');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0026', 'Other');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0027', 'Manufacturing Industry');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0029', 'Retail Trade without a Physical Store (Online Business)');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0030', 'Utility/Energy');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0031', 'Post and Telecommunication');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0036', 'Media');


insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0039', 'Money Remittance Companies (Including their agents)');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0040', 'Money changers');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0041', 'Trusted');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0042', 'Airline Industry');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0043', 'Insurance Industry');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0044', 'Construction Industry');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0045', 'Beauty Care');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0046', 'Logistic/Transportation/Delivery');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0047', 'Pharmaceuticals/Medical Equipment');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0048', 'Technology');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0051', 'Athletics/Sports');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('C', 'S0052', 'Rental Service');

COMMIT;