insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('N', 'S0013', 'Local NGO and Association');

insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('N', 'S0049', 'International NGO');

COMMIT;