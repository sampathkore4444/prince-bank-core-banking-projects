insert into LMTM_TYPE_VALUES (TYPE, CODE, VALUE)
values ('S', 'S0034', 'State-owned enterprise');