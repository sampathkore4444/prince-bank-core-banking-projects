CREATE OR REPLACE PACKAGE BODY Stpks_Stdcif_Utils_1 IS

  G_SKIP_KERNEL  BOOLEAN := FALSE;
  G_SKIP_CLUSTER BOOLEAN := FALSE;
  G_SKIP_CUSTOM  BOOLEAN := FALSE;

  PROCEDURE DBG(X VARCHAR2) IS
    L_LEN NUMBER := 0;
    L_IND NUMBER := 1;
    L_MSG VARCHAR2(32767);
  BEGIN
  
    L_MSG := 'stpks_stdcif_utils 1 ==>' || X;
    DEBUG.PR_DEBUG('ST', L_MSG);
  
  END DBG;
  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');
  END PR_SKIP_HANDLER;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
  END FN_SKIP_CUSTOM;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
  END FN_SKIP_CLUSTER;

  FUNCTION FN_UPLOAD_CUSTADDR(P_TYP_ADDR   IN OUT TY_ARRAY_ADDR,
                              P_ERROR_CODE IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                              P_ERROR_PRM  IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
    L_LOOP_VARIABLE  VARCHAR2(17);
    L_AUTO_AUTH_MENU VARCHAR2(32767);
    L_AUTO_AUTH_USER VARCHAR2(32767);
    L_CNT            NUMBER;
    L_PARAM_VAL      VARCHAR2(32767);
    PSERIAL          VARCHAR2(20);
    L_PREF           MSTBS_DLY_MSG_OUT.REFERENCE_NO%TYPE;
    L_TPINREF        MSTBS_DLY_MSG_OUT.REFERENCE_NO%TYPE;
  BEGIN
  
    DBG('Inside Function fn_upload_custaddr');
  
    SELECT AUTO_AUTH
      INTO L_AUTO_AUTH_MENU
      FROM SMTB_MENU
     WHERE FUNCTION_ID = 'STDCIF';
  
    SELECT AUTO_AUTH
      INTO L_AUTO_AUTH_USER
      FROM SMTB_USER
     WHERE USER_ID = GLOBAL.USER_ID();
    DBG('curr USER' || GLOBAL.USER_ID());
  
    IF (L_AUTO_AUTH_USER = 'Y' AND L_AUTO_AUTH_MENU = 'Y') THEN
    
      INSERT INTO MSTMS_CUST_ADDRESS
        (CUSTOMER_NO,
         LOCATION,
         MEDIA,
         ADDRESS1,
         ADDRESS2,
         ADDRESS3,
         ADDRESS4,
         LANGUAGE,
         TEST_KEYWORD,
         COUNTRY,
         NAME,
         ANSWERBACK,
         TEST_REQUIRED,
         CHECKER_DT_STAMP,
         MOD_NO,
         RECORD_STAT,
         AUTH_STAT,
         ONCE_AUTH,
         MAKER_DT_STAMP,
         MAKER_ID,
         CHECKER_ID,
         TOBE_EMAILED,
         DELIVERY_BY,
         HOLD_MAIL)
      VALUES
        (P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO,
         P_TYP_ADDR.TYP_ADDR_MASTER.LOCATION,
         P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA,
         P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS1,
         P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS2,
         P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS3,
         P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS4,
         P_TYP_ADDR.TYP_ADDR_MASTER.LANGUAGE,
         P_TYP_ADDR.TYP_ADDR_MASTER.TEST_KEYWORD,
         P_TYP_ADDR.TYP_ADDR_MASTER.COUNTRY,
         P_TYP_ADDR.TYP_ADDR_MASTER.NAME,
         P_TYP_ADDR.TYP_ADDR_MASTER.ANSWERBACK,
         P_TYP_ADDR.TYP_ADDR_MASTER.TEST_REQUIRED,
         STPKSS_UPLOAD.FN_DATE_TIME(GLOBAL.APPLICATION_DATE()),
         1,
         'O',
         'A',
         'Y',
         STPKSS_UPLOAD.FN_DATE_TIME(GLOBAL.APPLICATION_DATE()),
         GLOBAL.USER_ID,
         GLOBAL.USER_ID,
         P_TYP_ADDR.TYP_ADDR_MASTER.TOBE_EMAILED,
         P_TYP_ADDR.TYP_ADDR_MASTER.DELIVERY_BY,
         P_TYP_ADDR.TYP_ADDR_MASTER.HOLD_MAIL);
    
      L_PARAM_VAL := CSPKSS_OS_PARAM.GET_PARAM_VAL('TPIN_GEN');
    
      IF L_PARAM_VAL = 'Y' THEN
        IF (TRPKSS.FN_GET_PROCESS_REFNO(GLOBAL.CURRENT_BRANCH,
                                        'TPIN',
                                        GLOBAL.APPLICATION_DATE,
                                        PSERIAL,
                                        L_PREF,
                                        P_ERROR_CODE)) THEN
          DBG('INTO IF' || L_PREF);
          L_TPINREF := L_PREF;
          BEGIN
            INSERT INTO MSTBS_DLY_MSG_OUT
              (BRANCH,
               REFERENCE_NO,
               RECEIVER,
               MODULE,
               PRODUCT,
               MSG_TYPE,
               FORMAT,
               MEDIA,
               ESN,
               PROCESSED_FLAG)
            VALUES
              (GLOBAL.CURRENT_BRANCH,
               L_TPINREF,
               P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO,
               'CS',
               'ACST',
               'TPIN_OP_ADV',
               'TPIN_OPEN',
               'MAIL',
               1,
               'N');
          EXCEPTION
            WHEN OTHERS THEN
              OVPKSS.PR_APPENDTBL('CO-0001', 'fn_authorise');
              RETURN FALSE;
          END;
        END IF;
      
        DBG('this is after pr gen insert in to dly msg out');
      END IF;
    
      SELECT COUNT(*)
        INTO L_CNT
        FROM SVTMS_CIF_SIG_MASTER
       WHERE CIF_ID = P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO
         AND RECORD_STAT <> 'A';
    
      IF (L_CNT > 0) THEN
        DBG('Starting Replication Now');
        BEGIN
          SVPKSS.PR_REPLICATE_CIF_SIG(P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO);
          DBG('Signatures Successfully Replicated !!!');
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Signatures Not Successfully Replicated ???');
          
            DBG('Now Fire a job to Replicate');
            SVPKSS.PR_FIRE_JOB('svpkss.pr_replicate_cIF_sig(' || '''' ||
                               P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO || '''' ||
                               ',job);');
        END;
      END IF;
    
      IF ELPKSS.LIMITS_MODULE = 'LM' THEN
        UPDATE LMTMS_LIAB
           SET AUTH_STAT = 'A'
         WHERE LIAB_ID = P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO;
      ELSE
        IF NOT
            ELPKS_LIABILITY_SERVICE.FN_UPDATE_LIAB(P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO) THEN
          DBG('FAILED IN ELPKS_LIABILITY_SERVICE.fn_update_liab');
        END IF;
      END IF;
    
    ELSE
      INSERT INTO MSTMS_CUST_ADDRESS
        (CUSTOMER_NO,
         LOCATION,
         MEDIA,
         ADDRESS1,
         ADDRESS2,
         ADDRESS3,
         ADDRESS4,
         LANGUAGE,
         TEST_KEYWORD,
         COUNTRY,
         NAME,
         ANSWERBACK,
         TEST_REQUIRED,
         CHECKER_DT_STAMP,
         MOD_NO,
         RECORD_STAT,
         AUTH_STAT,
         ONCE_AUTH,
         MAKER_DT_STAMP,
         MAKER_ID,
         CHECKER_ID,
         TOBE_EMAILED,
         DELIVERY_BY,
         HOLD_MAIL)
      VALUES
        (P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO,
         P_TYP_ADDR.TYP_ADDR_MASTER.LOCATION,
         P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA,
         P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS1,
         P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS2,
         P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS3,
         P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS4,
         P_TYP_ADDR.TYP_ADDR_MASTER.LANGUAGE,
         P_TYP_ADDR.TYP_ADDR_MASTER.TEST_KEYWORD,
         P_TYP_ADDR.TYP_ADDR_MASTER.COUNTRY,
         P_TYP_ADDR.TYP_ADDR_MASTER.NAME,
         P_TYP_ADDR.TYP_ADDR_MASTER.ANSWERBACK,
         P_TYP_ADDR.TYP_ADDR_MASTER.TEST_REQUIRED,
         '',
         1,
         'O',
         'U',
         'N',
         STPKSS_UPLOAD.FN_DATE_TIME(GLOBAL.APPLICATION_DATE()),
         GLOBAL.USER_ID,
         '',
         P_TYP_ADDR.TYP_ADDR_MASTER.TOBE_EMAILED,
         P_TYP_ADDR.TYP_ADDR_MASTER.DELIVERY_BY,
         P_TYP_ADDR.TYP_ADDR_MASTER.HOLD_MAIL);
    
    END IF;
  
    DBG('After Successful Insertion into master address table -> mstm_cust_address');
    IF P_TYP_ADDR.TBL_ADDR_DETAIL.COUNT > 0 THEN
      DBG('TOTAL Detailed Address block sent ->' ||
          P_TYP_ADDR.TBL_ADDR_DETAIL.COUNT);
      L_LOOP_VARIABLE := P_TYP_ADDR.TBL_ADDR_DETAIL.FIRST;
      WHILE L_LOOP_VARIABLE IS NOT NULL LOOP
        INSERT INTO MSTMS_MSG_ADDRESS
          (MSG_TYPE,
           MODULE,
           BRANCH,
           LOCATION,
           MEDIA,
           CUSTOMER_NO,
           NO_OF_COPIES,
           FORMAT,
           CUST_AC_NO,
           PRIMARY_ADDRESS)
        VALUES
          (P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).MSG_TYPE,
           P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).MODULE,
           'ALL',
           P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).LOCATION,
           P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).MEDIA,
           P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).CUSTOMER_NO,
           P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).NO_OF_COPIES,
           P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).FORMAT,
           'ALL',
           P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).PRIMARY_ADDRESS
           
           );
      
        DBG('After Successful Insertion into detailed address table-> mstm_msg_address');
        L_LOOP_VARIABLE := P_TYP_ADDR.TBL_ADDR_DETAIL.NEXT(L_LOOP_VARIABLE);
      END LOOP;
    ELSE
      IF P_TYP_ADDR.VAR_COMMADDRESS = 'Y' AND
         P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA IN ('MAIL', 'SWIFT') THEN
        DBG('Communication Address is set to Y');
        INSERT INTO MSTMS_MSG_ADDRESS
          (MSG_TYPE,
           MODULE,
           BRANCH,
           LOCATION,
           MEDIA,
           CUSTOMER_NO,
           NO_OF_COPIES,
           FORMAT,
           CUST_AC_NO,
           PRIMARY_ADDRESS)
        VALUES
          ('ANY MSG TYPE',
           'AL',
           'ALL',
           P_TYP_ADDR.TYP_ADDR_MASTER.LOCATION,
           P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA,
           P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO,
           NULL,
           NULL,
           'ALL',
           'N');
        DBG('Detailed Address block inserted with default values');
      END IF;
    END IF;
    DBG('Successfully Returned from function fn_upload_custaddr');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error in Uploading Address blocks-->' || SQLCODE ||
          'Error Msg-->' || SQLERRM);
      P_ERROR_CODE := 'AC-ADUP04';
      P_ERROR_PRM  := 'Insertion~';
      RETURN FALSE;
  END FN_UPLOAD_CUSTADDR;

  FUNCTION FN_VALID_ADDR_DTL(P_TYP_ADDR   IN OUT TY_ARRAY_ADDR,
                             P_ERROR_CODE IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                             P_ERROR_PRM  IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
    L_BRANCH_CODE   STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_MEDIA         MSTMS_MEDIA.MEDIA%TYPE;
    L_CUST_AC_NO    STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_FORMAT        MSTMS_ADV_FORMAT.FORMAT%TYPE;
    L_LOCATION      STTMS_LOCATION.LOC_CODE%TYPE;
    L_COUNT         NUMBER(5);
    L_MSG_TYPE      MSTMS_MSG_TYPE.MSG_TYPE%TYPE;
    L_LOOP_VARIABLE VARCHAR(17);
  BEGIN
    IF P_TYP_ADDR.TBL_ADDR_DETAIL.COUNT > 0 THEN
    
      WHILE L_LOOP_VARIABLE IS NOT NULL LOOP
      
        IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).MSG_TYPE IS NULL THEN
          DBG('Message Type cannot be Null');
          P_ERROR_CODE := 'ST-MAN01';
          P_ERROR_PRM  := 'Message Type';
          RETURN FALSE;
        END IF;
      
        IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).MODULE IS NULL THEN
          DBG('Module cannot be Null');
          P_ERROR_CODE := 'ST-MAN01';
          P_ERROR_PRM  := 'Module';
          RETURN FALSE;
        END IF;
      
        IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).LOCATION IS NULL THEN
          DBG('Location cannot be Null');
          P_ERROR_CODE := 'ST-MAN01';
          P_ERROR_PRM  := 'Location';
          RETURN FALSE;
        END IF;
      
        IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).MEDIA IS NULL THEN
          DBG('Media cannot be Null');
          P_ERROR_CODE := 'ST-MAN01';
          P_ERROR_PRM  := 'Media';
          RETURN FALSE;
        END IF;
      
        IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).CUSTOMER_NO IS NULL THEN
          DBG('Customer Number cannot be Null');
          P_ERROR_CODE := 'ST-MAN01';
          P_ERROR_PRM  := 'Customer Number';
          RETURN FALSE;
        END IF;
      
        IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE)
         .MSG_TYPE = 'FX_CONFIRMN' THEN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM MSTMS_MSG_ADDRESS
           WHERE CUST_AC_NO = P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE)
                .CUST_AC_NO
             AND MEDIA = 'SWIFT'
             AND MSG_TYPE = 'FX_CONFIRMN';
        
          IF L_COUNT <> 0 THEN
            DBG('Primary Address already defaulted.');
            P_ERROR_CODE := 'AC-ADUP05';
            P_ERROR_PRM  := '';
            RETURN FALSE;
          END IF;
        
        ELSE
          P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).PRIMARY_ADDRESS := NULL;
        END IF;
      
        IF NVL(P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).NO_OF_COPIES, 0) < 0 THEN
          DBG('Number of copies cannot be less than zero.');
          P_ERROR_CODE := 'CS-MINMAX1';
          P_ERROR_PRM  := 'No of copies ~ Less Than 0 ~';
          RETURN FALSE;
        END IF;
      
        IF NVL(P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).NO_OF_COPIES, 0) > 99 THEN
          DBG('Number of copies cannot be greater than zero.');
          P_ERROR_CODE := 'CS-MINMAX1';
          P_ERROR_PRM  := 'No of copies ~ greater Than 99 ~';
          RETURN FALSE;
        END IF;
      
        IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).FORMAT IS NOT NULL THEN
          BEGIN
            SELECT FORMAT
              INTO L_FORMAT
              FROM MSTMS_ADV_FORMAT
             WHERE RECORD_STAT = 'O'
               AND AUTH_STAT = 'A'
               AND FORMAT = P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE)
                  .FORMAT;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Invalid Message Format');
              P_ERROR_CODE := 'AC-ADUP02';
              P_ERROR_PRM  := 'Message Format :' || P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE)
                             .FORMAT || '~';
              RETURN FALSE;
          END;
        
        END IF;
      
        BEGIN
          SELECT MEDIA
            INTO L_MEDIA
            FROM MSTMS_MEDIA
           WHERE MEDIA = P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).MEDIA
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Invalid Media Type');
            P_ERROR_CODE := 'AC-ADUP02';
            P_ERROR_PRM  := 'Media Type :' || P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE)
                           .MEDIA || '~';
            RETURN FALSE;
        END;
      
        BEGIN
        
          SELECT MSG_TYPE
            INTO L_MSG_TYPE
            FROM MSTMS_MSG_TYPE
           WHERE MSG_TYPE = P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE)
                .MSG_TYPE;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE)
             .MSG_TYPE <> 'ANY MSG TYPE' THEN
              DBG('Invalid Message Type');
              P_ERROR_CODE := 'AC-ADUP02';
              P_ERROR_PRM  := 'Mesage Type :' || P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE)
                             .MSG_TYPE || '~';
              RETURN FALSE;
            END IF;
        END;
      
        IF P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).CUST_AC_NO IS NULL THEN
          P_TYP_ADDR.TBL_ADDR_DETAIL(L_LOOP_VARIABLE).CUST_AC_NO := 'ALL';
        END IF;
      
        L_LOOP_VARIABLE := P_TYP_ADDR.TBL_ADDR_DETAIL.NEXT(L_LOOP_VARIABLE);
      END LOOP;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error in Validating Address Detail block-->' || SQLCODE ||
          'Error Msg-->' || SQLERRM);
      P_ERROR_CODE := 'AC-ADUP04';
      P_ERROR_PRM  := 'Validation~';
      RETURN FALSE;
  END FN_VALID_ADDR_DTL;

  FUNCTION FN_VALID_ADDR_MSTR(P_TYP_ADDR   IN OUT TY_ARRAY_ADDR,
                              P_CUSTNO     IN VARCHAR2,
                              P_ERROR_CODE IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                              P_ERROR_PRM  IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
    L_DELIVERY_BY STTMS_LOCATION_CLUSTER.CODE%TYPE;
    L_BRANCH_CODE STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_MEDIA       MSTMS_MEDIA.MEDIA%TYPE;
    L_CUSTOMER_NO STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_FORMAT      MSTMS_ADV_FORMAT.FORMAT%TYPE;
    L_LANG        SMTBS_LANGUAGE.LANG_CODE%TYPE;
    L_COUNTRY     STTMS_COUNTRY.COUNTRY_CODE%TYPE;
    L_LOCATION    STTMS_LOCATION.LOC_CODE%TYPE;
    L_COUNT       NUMBER(5);
  
    L_INVALID_CHAR VARCHAR2(50);
  
  BEGIN
  
    PR_SKIP_HANDLER('PRE_VALID_ADDR_MSTR');
    IF NOT STPKS_STDCIF_UTILS_1.FN_SKIP_CUSTOM THEN
      DBG('Calling stpks_stdcif_utils_1_custom.Fn_Pre_Valid_Addr_Mstr..');
      IF NOT
          STPKS_STDCIF_UTILS_1_CUSTOM.FN_PRE_VALID_ADDR_MSTR(P_TYP_ADDR,
                                                             P_CUSTNO,
                                                             P_ERROR_CODE,
                                                             P_ERROR_PRM) THEN
        DBG('Failed in stpks_stdcif_utils_1_custom.Fn_Pre_Valid_Addr_Mstr..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT STPKS_STDCIF_UTILS_1.FN_SKIP_CLUSTER THEN
      DBG('Calling stpks_stdcif_utils_1_cluster.Fn_Pre_Valid_Addr_Mstr..');
      IF NOT
          STPKS_STDCIF_UTILS_1_CLUSTER.FN_PRE_VALID_ADDR_MSTR(P_TYP_ADDR,
                                                              P_CUSTNO,
                                                              P_ERROR_CODE,
                                                              P_ERROR_PRM) THEN
        DBG('Failed in stpks_stdcif_utils_1_cluster.Fn_Pre_Valid_Addr_Mstr..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT STPKS_STDCIF_UTILS_1.FN_SKIP_KERNEL THEN
    
      DBG('Inside function fn_valid_addr_mstr');
    
      IF P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO IS NULL THEN
        DBG('Customer Number cannot be Null');
        P_ERROR_CODE := 'ST-MAN01';
        P_ERROR_PRM  := 'Customer Number';
        RETURN FALSE;
      END IF;
    
      DBG('Mandatory Check Success--> Customer Number');
    
      IF P_TYP_ADDR.TYP_ADDR_MASTER.LOCATION IS NULL THEN
        DBG('Location cannot be Null');
        P_ERROR_CODE := 'ST-MAN01';
        P_ERROR_PRM  := 'Location';
        RETURN FALSE;
      END IF;
    
      DBG('Mandatory Check Success--> Location');
    
      IF P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA IS NULL THEN
        DBG('Media cannot be Null');
        P_ERROR_CODE := 'ST-MAN01';
        P_ERROR_PRM  := 'Media';
        RETURN FALSE;
      END IF;
    
      DBG('Mandatory Check Success--> Media');
    
      IF P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS1 IS NULL THEN
        DBG('Address1 cannot be Null');
        P_ERROR_CODE := 'ST-MAN01';
        P_ERROR_PRM  := 'Address1';
        RETURN FALSE;
      END IF;
    
      DBG('Mandatory Check Success--> Address1');
    
      DBG('Customer Number Validated');
    
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM MSTMS_CUST_ADDRESS
         WHERE (CUSTOMER_NO = P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO)
           AND (MEDIA = P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA)
           AND (LOCATION = P_TYP_ADDR.TYP_ADDR_MASTER.LOCATION);
      
        IF L_COUNT > 0 THEN
          DBG('Record Already Exists in mstm_cust_address for the CUSTOMERNO/MEDIA/LOCATION combination.');
          P_ERROR_CODE := 'CUS-ADUP01';
          P_ERROR_PRM  := P_TYP_ADDR.TYP_ADDR_MASTER.CUSTOMER_NO || '~' ||
                          P_TYP_ADDR.TYP_ADDR_MASTER.LOCATION || '~' ||
                          P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA || '~';
          RETURN FALSE;
        END IF;
      END;
    
      DBG('Duplicate record in mstms_cust_Address Validated');
    
      IF (P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA = 'SWIFT' AND
         (NVL(LENGTH(P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS1), 0) <> 8 AND
         NVL(LENGTH(P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS1), 0) <> 11)) THEN
        DBG('Address1 not compaitable with Swift Format.');
        P_ERROR_CODE := 'MS-00029';
        P_ERROR_PRM  := '';
        RETURN FALSE;
      END IF;
    
      IF P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA = 'SWIFT' THEN
        L_INVALID_CHAR := STPKS_FCMAINT_UTILS.FN_VALIDATE_RESTR_TEXT(P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS1);
        IF L_INVALID_CHAR IS NOT NULL THEN
        
          IF L_INVALID_CHAR = '@' THEN
            L_INVALID_CHAR := '@@';
          END IF;
        
          P_ERROR_CODE := 'ST-VALS-014';
          P_ERROR_PRM  := L_INVALID_CHAR || '~' ||
                          P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS1 || '~' ||
                          '@STTMS_CUSTOMER.ADDRESS_LINE1';
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('SWIFT format Validated');
    
      IF (P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA IN ('SWIFT', 'TELEX')) THEN
        DBG('Address2, Address3 and Address4 defaulted to NULL');
        P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS2     := NULL;
        P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS3     := NULL;
        P_TYP_ADDR.TYP_ADDR_MASTER.ADDRESS4     := NULL;
        P_TYP_ADDR.TYP_ADDR_MASTER.TOBE_EMAILED := 'N';
      END IF;
    
      IF P_TYP_ADDR.TYP_ADDR_MASTER.DELIVERY_BY IS NOT NULL THEN
        BEGIN
          SELECT CODE
            INTO L_DELIVERY_BY
            FROM STTMS_LOCATION_CLUSTER
           WHERE CODE = P_TYP_ADDR.TYP_ADDR_MASTER.DELIVERY_BY
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Invalid Delivery-By Field');
            P_ERROR_CODE := 'AC-ADUP02';
            P_ERROR_PRM  := 'Delivery By :' ||
                            P_TYP_ADDR.TYP_ADDR_MASTER.DELIVERY_BY || '~';
            RETURN FALSE;
        END;
      
      END IF;
    
      DBG('Delivery By Field Validated');
    
      IF P_TYP_ADDR.TYP_ADDR_MASTER.LANGUAGE IS NOT NULL THEN
        BEGIN
          SELECT LANG_CODE
            INTO L_LANG
            FROM SMTB_LANGUAGE
           WHERE LANG_CODE = P_TYP_ADDR.TYP_ADDR_MASTER.LANGUAGE;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Invalid Language Code');
            P_ERROR_CODE := 'AC-ADUP02';
            P_ERROR_PRM  := 'Language Code:' ||
                            P_TYP_ADDR.TYP_ADDR_MASTER.LANGUAGE || '~';
            RETURN FALSE;
        END;
      END IF;
    
      DBG('Language Field Validated');
      IF P_TYP_ADDR.TYP_ADDR_MASTER.COUNTRY IS NOT NULL THEN
        BEGIN
          SELECT COUNTRY_CODE
            INTO L_COUNTRY
            FROM STTMS_COUNTRY
           WHERE COUNTRY_CODE = P_TYP_ADDR.TYP_ADDR_MASTER.COUNTRY
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Invalid Country Code');
            P_ERROR_CODE := 'AC-ADUP02';
            P_ERROR_PRM  := 'Country Code :' ||
                            P_TYP_ADDR.TYP_ADDR_MASTER.COUNTRY || '~';
            RETURN FALSE;
        END;
      END IF;
      DBG('Country Field Validated');
      BEGIN
      
        SELECT MEDIA
          INTO L_MEDIA
          FROM MSTMS_MEDIA
         WHERE MEDIA = P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Invalid Media Type');
          P_ERROR_CODE := 'AC-ADUP02';
          P_ERROR_PRM  := 'Media Type :' ||
                          P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA || '~';
          RETURN FALSE;
      END;
    
      DBG('Media Field Validated');
    
      IF UPPER(P_TYP_ADDR.TYP_ADDR_MASTER.MEDIA) <> 'MAIL' AND
         NVL(P_TYP_ADDR.TYP_ADDR_MASTER.HOLD_MAIL, 'N') = 'Y' THEN
        DBG('Hold Mail Flag Cannot be set for this Media');
        P_ERROR_CODE := 'MS-000150';
      END IF;
    
    END IF;
    PR_SKIP_HANDLER('POST_VALID_ADDR_MSTR');
    IF NOT STPKS_STDCIF_UTILS_1.FN_SKIP_CLUSTER THEN
      DBG('Calling stpks_stdcif_utils_1_cluster.Fn_Post_Valid_Addr_Mstr..');
      IF NOT
          STPKS_STDCIF_UTILS_1_CLUSTER.FN_POST_VALID_ADDR_MSTR(P_TYP_ADDR,
                                                               P_CUSTNO,
                                                               P_ERROR_CODE,
                                                               P_ERROR_PRM) THEN
        DBG('Failed in stpks_stdcif_utils_1_cluster.Fn_Post_Valid_Addr_Mstr..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT STPKS_STDCIF_UTILS_1.FN_SKIP_CUSTOM THEN
      DBG('Calling stpks_stdcif_utils_1_custom.Fn_Post_Valid_Addr_Mstr..');
      IF NOT
          STPKS_STDCIF_UTILS_1_CUSTOM.FN_POST_VALID_ADDR_MSTR(P_TYP_ADDR,
                                                              P_CUSTNO,
                                                              P_ERROR_CODE,
                                                              P_ERROR_PRM) THEN
        DBG('Failed in stpks_stdcif_utils_1_custom.Fn_Post_Valid_Addr_Mstr..');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('End of function fn_valid_addr_mstr');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error in Validating Address Master block-->' || SQLCODE ||
          'Error Msg-->' || SQLERRM);
      P_ERROR_CODE := 'AC-ADUP04';
      P_ERROR_PRM  := 'Validation';
      RETURN FALSE;
  END FN_VALID_ADDR_MSTR;

  FUNCTION FN_DO_VALIDATIONS(P_TYP_ADDR   IN OUT TY_ARRAY_ADDR,
                             P_CUSTNO     IN VARCHAR2,
                             P_ERROR_CODE IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                             P_ERROR_PRM  IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
  
    IF NOT
        FN_VALID_ADDR_MSTR(P_TYP_ADDR, P_CUSTNO, P_ERROR_CODE, P_ERROR_PRM) THEN
      DBG('Error Occurred in function fn_valid_addr_mstr');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_VALID_ADDR_DTL(P_TYP_ADDR, P_ERROR_CODE, P_ERROR_PRM) THEN
      DBG('Error Occurred in function fn_valid_addr_dtl');
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  END FN_DO_VALIDATIONS;

  FUNCTION FN_START_ADDRESS_UPLOAD(P_FUNCTION_ID IN VARCHAR2,
                                   P_TYP_ADDR    IN OUT TBL_ADDR_BLOCK,
                                   P_CUSTNO      IN VARCHAR2,
                                   P_ERROR_CODE  IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                   P_ERROR_PRM   IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
    L_IS_DEFAULTED VARCHAR2(1) := 'N';
  BEGIN
    DBG('Inside the Function fn_start_address_upload. Start of Customer Account Address Upload.');
    IF P_TYP_ADDR.COUNT > 0 THEN
      FOR L_LOOP_VARIABLE IN P_TYP_ADDR.FIRST .. P_TYP_ADDR.LAST LOOP
      
        IF NOT FN_DO_VALIDATIONS(P_TYP_ADDR(L_LOOP_VARIABLE),
                                 P_CUSTNO,
                                 P_ERROR_CODE,
                                 P_ERROR_PRM) THEN
          DBG('Error Occurred in function fn_do_validations');
          RETURN FALSE;
        END IF;
      
        DBG('Successful Completion of Address Block ->' || L_LOOP_VARIABLE);
      END LOOP;
    END IF;
    DBG('Inside the Function fn_start_address_upload. End of Successful Customer Address Upload.');
    RETURN TRUE;
  END FN_START_ADDRESS_UPLOAD;

  FUNCTION FN_CHK_PASSPORT(P_FUNCTION_ID IN VARCHAR2,
                           P_PPT_NO      IN VARCHAR2,
                           
                           P_PPT_ISSDT  IN DATE,
                           P_PPT_EXPDT  IN DATE,
                           P_ERR_CODE   IN OUT VARCHAR2,
                           P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
    DBG('inside fn_chk_passport');
    DBG('p_ppt_issdt: ' || P_PPT_ISSDT);
    DBG('p_ppt_extdt: ' || P_PPT_EXPDT);
  
    IF P_PPT_EXPDT < GLOBAL.APPLICATION_DATE THEN
      DBG('Expiry date of Passport is less than today');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF143', P_PPT_NO);
    END IF;
  
    IF P_PPT_EXPDT = GLOBAL.APPLICATION_DATE THEN
      DBG('Passport Expiry Date is equal to System Date');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF138', P_PPT_NO);
    END IF;
  
    IF P_PPT_ISSDT > P_PPT_EXPDT THEN
      DBG('Passport Issue Date cannot be greater than Passport Expiry Date');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF139', P_PPT_NO);
    END IF;
  
    IF P_PPT_ISSDT = P_PPT_EXPDT THEN
      DBG('Passport Issue Date cannot be equal to Passport Expiry Date');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF160', P_PPT_NO);
    END IF;
  
    IF P_PPT_ISSDT = GLOBAL.APPLICATION_DATE THEN
      DBG('Passport issue Date is equal to System Date');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF161', P_PPT_NO);
    END IF;
  
    IF P_PPT_ISSDT > GLOBAL.APPLICATION_DATE THEN
      DBG('Passport issue Date is greater than today');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF142', P_PPT_NO);
    END IF;
  
    DBG('Returning from fn_chk_passport');
  
    RETURN TRUE;
  END FN_CHK_PASSPORT;

  FUNCTION FN_CHECK_UID(P_FUNCTION_ID IN VARCHAR2,
                        P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                        P_ERR_CODE    IN OUT VARCHAR2,
                        P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION FN_CHECK_XREF(P_FUNCTION_ID IN VARCHAR2,
                         P_EXT_REF_NO  IN VARCHAR2,
                         P_CUSTOMER_NO IN VARCHAR2,
                         P_ERR_CODE    IN OUT VARCHAR2,
                         P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CUST_BASIC_MAX_LENGTH(P_FUNCTION_ID IN VARCHAR2,
                                    P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                    P_ERR_CODE    IN OUT VARCHAR2,
                                    P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CUST_PERSONAL_MAX_LENGTH(P_FUNCTION_ID IN VARCHAR2,
                                       P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                       P_ERR_CODE    IN OUT VARCHAR2,
                                       P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CUST_CORP_MAX_LENGTH(P_FUNCTION_ID IN VARCHAR2,
                                   P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                   P_ERR_CODE    IN OUT VARCHAR2,
                                   P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CUST_JOINT_DETAILS(P_FUNCTION_ID IN VARCHAR2,
                                 P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_AML_REQUIRED(P_FUNCTION_ID        IN VARCHAR2,
                               P_AML_REQUIRED_TOCHK IN VARCHAR2,
                               P_AML_REQUIRED_DESC  IN VARCHAR2,
                               P_ERR_CODE           IN OUT VARCHAR2,
                               P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_SNAME_VALID(P_FUNCTION_ID IN VARCHAR2,
                          P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                          P_ERR_CODE    IN OUT VARCHAR2,
                          P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHKSWIFTFORMAT(FPSTRINGTOCHK IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION FN_SWIFTCODE_VALID(P_CUST_REC IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_ERRS     OUT ERTB_MSGS.ERR_CODE%TYPE,
                              P_PRMS     OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN;

  FUNCTION FN_SSN_VALID(P_CUST_REC IN STPKS_STDCIF_MAIN.TY_STDCIF,
                        P_ERRS     OUT ERTB_MSGS.ERR_CODE%TYPE,
                        P_PRMS     OUT ERTB_MSGS.MESSAGE%TYPE) RETURN BOOLEAN;

  FUNCTION FN_CHK_FX_NETTING_CUSTOMER(P_FUNCTION_ID               IN VARCHAR2,
                                      P_CUSTOMER_NO               IN VARCHAR2,
                                      P_FX_NETTING_CUSTOMER_TOCHK IN VARCHAR2,
                                      P_FX_NETTING_CUSTOMER_DESC  IN VARCHAR2,
                                      P_ERR_CODE                  IN OUT VARCHAR2,
                                      P_ERR_PARAMS                IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_UTIL_PROVIDER_VALID(P_CUST_REC IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_ERR      OUT ERTB_MSGS.ERR_CODE%TYPE,
                                  P_PRMS     OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_EMP_TENURE(P_FUNCTION_ID      IN VARCHAR2,
                             P_EMP_TENURE_TOCHK IN VARCHAR2,
                             P_EMP_TENURE_DESC  IN VARCHAR2,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_RETIREMENT_AGE(P_FUNCTION_ID          IN VARCHAR2,
                                 P_RETIREMENT_AGE_TOCHK IN VARCHAR2,
                                 P_RETIREMENT_AGE_DESC  IN VARCHAR2,
                                 P_ERR_CODE             IN OUT VARCHAR2,
                                 P_ERR_PARAMS           IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_OTHER_INCOME(P_FUNCTION_ID        IN VARCHAR2,
                               P_OTHER_INCOME_TOCHK IN VARCHAR2,
                               P_OTHER_INCOME_DESC  IN VARCHAR2,
                               P_ERR_CODE           IN OUT VARCHAR2,
                               P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_RENT(P_FUNCTION_ID IN VARCHAR2,
                       P_RENT_TOCHK  IN VARCHAR2,
                       P_RENT_DESC   IN VARCHAR2,
                       P_ERR_CODE    IN OUT VARCHAR2,
                       P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_INSURANCE(P_FUNCTION_ID     IN VARCHAR2,
                            P_INSURANCE_TOCHK IN VARCHAR2,
                            P_INSURANCE_DESC  IN VARCHAR2,
                            P_ERR_CODE        IN OUT VARCHAR2,
                            P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_PAYMENT(P_FUNCTION_ID   IN VARCHAR2,
                          P_PAYMENT_TOCHK IN VARCHAR2,
                          P_PAYMENT_DESC  IN VARCHAR2,
                          P_ERR_CODE      IN OUT VARCHAR2,
                          P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_OTHER_EXPENSES(P_FUNCTION_ID    IN VARCHAR2,
                                 P_EXPENSES_TOCHK IN VARCHAR2,
                                 P_EXPENSES_DESC  IN VARCHAR2,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_HOUSE_VALUE(P_FUNCTION_ID       IN VARCHAR2,
                              P_HOUSE_VALUE_TOCHK IN VARCHAR2,
                              P_HOUSE_VALUE_DESC  IN VARCHAR2,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_DEPENDENT_CHILDREN(P_FUNCTION_ID              IN VARCHAR2,
                                     P_DEPENDENT_CHILDREN_TOCHK IN VARCHAR2,
                                     P_DEPENDENT_CHILDREN_DESC  IN VARCHAR2,
                                     P_ERR_CODE                 IN OUT VARCHAR2,
                                     P_ERR_PARAMS               IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_DEPENDENT_OTHERS(P_FUNCTION_ID            IN VARCHAR2,
                                   P_DEPENDENT_OTHERS_TOCHK IN VARCHAR2,
                                   P_DEPENDENT_OTHERS_DESC  IN VARCHAR2,
                                   P_ERR_CODE               IN OUT VARCHAR2,
                                   P_ERR_PARAMS             IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_NODE_CUST_PERSONAL(P_FUNCTION_ID IN VARCHAR2,
                                     P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                     P_ERR_CODE    IN OUT VARCHAR2,
                                     P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_NODE_CUST_CORP(P_FUNCTION_ID IN VARCHAR2,
                                 P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_CCY(P_FUNCTION_ID IN VARCHAR2,
                      P_CCY_TOCHK   IN VARCHAR2,
                      P_CCY_BRANCH  IN VARCHAR2,
                      P_ERR_CODE    IN OUT VARCHAR2,
                      P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_ISSUER_VALIDATE(P_FUNCTION_ID       IN VARCHAR2,
                              P_ISSUER_DETAILS    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_ISSUER_COLL_LIMIT IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_SHARE_PERCENT(P_FUNCTION_ID IN VARCHAR2,
                                P_CUST_SHARE  IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_REL_LINK(P_FUNCTION_ID  IN VARCHAR2,
                                P_REL_LINK_REC IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                P_CUSTNO       IN STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                                P_ERR_CODE     IN OUT VARCHAR2,
                                P_ERR_PARAMS   IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_BRANCH(P_FUNCTION_ID  IN VARCHAR2,
                         P_BRANCH_TOCHK IN VARCHAR2,
                         P_BRANCH_DESC  IN VARCHAR2,
                         P_ERR_CODE     IN OUT VARCHAR2,
                         P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_IS_ERROR(P_ERR IN ERTBS_MSGS.ERR_CODE%TYPE) RETURN BOOLEAN;

  FUNCTION FN_CHK_LOCATION(P_FUNCTION_ID    IN VARCHAR2,
                           P_LOCATION_TOCHK IN VARCHAR2,
                           P_LOCATION_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_COUNTRY(P_FUNCTION_ID   IN VARCHAR2,
                          P_COUNTRY_TOCHK IN VARCHAR2,
                          P_COUNTRY_DESC  IN VARCHAR2,
                          P_ERR_CODE      IN OUT VARCHAR2,
                          P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_CUST_CATEG(P_FUNCTION_ID      IN VARCHAR2,
                             P_CUST_CATEG_TOCHK IN VARCHAR2,
                             P_CUST_CATEG_DESC  IN VARCHAR2,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_LANGUAGE(P_FUNCTION_ID    IN VARCHAR2,
                           P_LANGUAGE_TOCHK IN VARCHAR2,
                           P_LANGUAGE_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_CUST_GRP(P_FUNCTION_ID    IN VARCHAR2,
                           P_CUST_GRP_TOCHK IN VARCHAR2,
                           P_CUST_NO        IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_GROUP_CODE(P_FUNCTION_ID      IN VARCHAR2,
                             P_GROUP_CODE_TOCHK IN VARCHAR2,
                             P_CUST_TYPE        IN VARCHAR2,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_EXP_CATEG(P_FUNCTION_ID     IN VARCHAR2,
                            P_EXP_CATEG_TOCHK IN VARCHAR2,
                            P_EXP_CATEG_DESC  IN VARCHAR2,
                            P_ERR_CODE        IN OUT VARCHAR2,
                            P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_CUST_CLASSIFICATION(P_FUNCTION_ID               IN VARCHAR2,
                                      P_CUST_CLASSIFICATION_TOCHK IN VARCHAR2,
                                      P_CUST_CLASSIFICATION_DESC  IN VARCHAR2,
                                      P_ERR_CODE                  IN OUT VARCHAR2,
                                      P_ERR_PARAMS                IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_AC_OR_PLAN_NO(P_FUNCTION_ID   IN VARCHAR2,
                                P_CUST_NO       IN VARCHAR2,
                                P_AC_OR_PLAN_NO IN VARCHAR2,
                                P_ERR_CODE      IN OUT VARCHAR2,
                                P_ERR_PARAMS    IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_ADDRESS(P_FUNCTION_ID   IN VARCHAR2,
                          P_ADDRESS_TOCHK IN VARCHAR2,
                          P_ADDRESS_DESC  IN VARCHAR2,
                          P_ERR_CODE      IN OUT VARCHAR2,
                          P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_NAME(P_FUNCTION_ID IN VARCHAR2,
                       P_NAME_TOCHK  IN VARCHAR2,
                       P_NAME_DESC   IN VARCHAR2,
                       P_ERR_CODE    IN OUT VARCHAR2,
                       P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_HO_AC_NO(P_FUNCTION_ID    IN VARCHAR2,
                           P_HO_AC_NO_TOCHK IN VARCHAR2,
                           P_HO_AC_NO_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_LIAB_NODE(P_FUNCTION_ID     IN VARCHAR2,
                            P_LIAB_NODE_TOCHK IN VARCHAR2,
                            P_LIAB_NODE_DESC  IN VARCHAR2,
                            P_ERR_CODE        IN OUT VARCHAR2,
                            P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_TELEPHONE_NO(P_FUNCTION_ID        IN VARCHAR2,
                               P_TELEPHONE_NO_TOCHK IN VARCHAR2,
                               P_TELEPHONE_NO_DESC  IN VARCHAR2,
                               P_ERR_CODE           IN OUT VARCHAR2,
                               P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_NATIONAL_ID(P_FUNCTION_ID       IN VARCHAR2,
                              P_NATIONAL_ID_TOCHK IN VARCHAR2,
                              P_NATIONAL_ID_DESC  IN VARCHAR2,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_MAXLENGTH(P_FUNCTION_ID IN VARCHAR2,
                            P_STR_TOCHK   IN VARCHAR2,
                            P_ERRORDESC   IN VARCHAR2,
                            P_ERR_CODE    IN OUT VARCHAR2,
                            P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_FAX(P_FUNCTION_ID IN VARCHAR2,
                      P_FAX_TOCHK   IN VARCHAR2,
                      P_FAX_DESC    IN VARCHAR2,
                      P_ERR_CODE    IN OUT VARCHAR2,
                      P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_DESIGNATION(P_FUNCTION_ID       IN VARCHAR2,
                              P_DESIGNATION_TOCHK IN VARCHAR2,
                              P_DESIGNATION_DESC  IN VARCHAR2,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_EMPLOYER(P_FUNCTION_ID    IN VARCHAR2,
                           P_EMPLOYER_TOCHK IN VARCHAR2,
                           P_EMPLOYER_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_TELEX(P_FUNCTION_ID IN VARCHAR2,
                        P_TELEX_TOCHK IN VARCHAR2,
                        P_TELEX_DESC  IN VARCHAR2,
                        P_ERR_CODE    IN OUT VARCHAR2,
                        P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_PREFIX(P_FUNCTION_ID  IN VARCHAR2,
                         P_PREFIX_TOCHK IN VARCHAR2,
                         P_LOCAL_BRANCH IN VARCHAR2,
                         P_ERR_CODE     IN OUT VARCHAR2,
                         P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_EMPLOYMENT_TENURE(P_FUNCTION_ID             IN VARCHAR2,
                                    P_EMPLOYMENT_TENURE_TOCHK IN VARCHAR2,
                                    P_EMPLOYMENT_TENURE_DESC  IN VARCHAR2,
                                    P_ERR_CODE                IN OUT VARCHAR2,
                                    P_ERR_PARAMS              IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_RESIDENT_STATUS(P_FUNCTION_ID           IN VARCHAR2,
                                  P_RESIDENT_STATUS_TOCHK IN VARCHAR2,
                                  P_RESIDENT_STATUS_DESC  IN VARCHAR2,
                                  P_ERR_CODE              IN OUT VARCHAR2,
                                  P_ERR_PARAMS            IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_RECORD_NO(P_FUNCTION_ID     IN VARCHAR2,
                            P_RECORD_NO_TOCHK IN VARCHAR2,
                            P_RECORD_NO_DESC  IN VARCHAR2,
                            P_ERR_CODE        IN OUT VARCHAR2,
                            P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_SEX(P_FUNCTION_ID IN VARCHAR2,
                      P_SEX_TOCHK   IN VARCHAR2,
                      P_SEX_DESC    IN VARCHAR2,
                      P_ERR_CODE    IN OUT VARCHAR2,
                      P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_DECEASED(P_FUNCTION_ID    IN VARCHAR2,
                           P_DECEASED_TOCHK IN VARCHAR2,
                           P_DECEASED_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHKNUMFORZERO(P_VAR_NUM IN NUMBER,
                            P_ERRS    OUT ERTB_MSGS.ERR_CODE%TYPE,
                            P_PRMS    IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN;

  FUNCTION FN_NUMERIC_VALID(P_VAR_NUM IN NUMBER, P_RESULT OUT NUMBER)
    RETURN BOOLEAN;

  FUNCTION FN_CHK_DEBTOR_CAT(P_DEBTOR_CAT IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_MEDIA(P_MEDIA IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_RISK_PRFL(P_RISK_PROFILE IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_CLG_GRP(P_CLG_GRP IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_TAX_GRP(P_TAX_GRP IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_CHG_GRP(P_CHG_GRP IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_DATE_OF_BIRTH(P_FUNCTION_ID IN VARCHAR2,
                                P_DOB_TOCHK   IN DATE,
                                P_DOB_DESC    IN VARCHAR2,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHK_SHARE_PERCENT(P_FUNCTION_ID IN VARCHAR2,
                                P_CUST_SHARE  IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_COUNT NUMBER;
    L_TOTAL NUMBER := 0;
  BEGIN
    DBG('Inside the fn_chk_share_percent  ');
  
    IF P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER.COUNT > 0 THEN
    
      FOR I IN P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER.FIRST .. P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER.LAST LOOP
      
        DBG('p_cust_share.v_sttms_cust_shareholder(i).shareholder_id ' || P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I)
            .SHAREHOLDER_ID);
        DBG('p_cust_share.v_sttms_cust_shareholder(i).percentage_holding ' || P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I)
            .PERCENTAGE_HOLDING);
      
        IF P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I)
         .SHAREHOLDER_ID IS NOT NULL THEN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I)
                .SHAREHOLDER_ID
             AND RECORD_STAT = 'O'
             AND ONCE_AUTH = 'Y';
        
          IF L_COUNT = 0 THEN
            DBG('fn_chk_share_percent: Invalid share holder id provided');
            P_ERR_CODE   := 'ST-CIF115';
            P_ERR_PARAMS := P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I)
                            .SHAREHOLDER_ID || '~';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
          END IF;
        
          IF P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER.COUNT > 1 THEN
            FOR J IN I + 1 .. P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER.LAST LOOP
              IF P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I).SHAREHOLDER_ID = P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(J)
                 .SHAREHOLDER_ID THEN
                DBG(' shareholder  should be unique ');
                P_ERR_CODE   := 'ST-CIF116';
                P_ERR_PARAMS := ' shareholder  should be unique ';
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
              END IF;
            END LOOP;
          END IF;
        
          IF P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I)
           .PERCENTAGE_HOLDING IS NULL THEN
            P_ERR_CODE   := 'ST-CIF-416';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
          ELSIF
          
           P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I).PERCENTAGE_HOLDING < 0 OR P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I)
           .PERCENTAGE_HOLDING > 100 THEN
            P_ERR_CODE   := 'ST-CIF-414';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
          END IF;
          L_TOTAL := L_TOTAL + NVL(P_CUST_SHARE.V_STTMS_CUST_SHAREHOLDER(I)
                                   .PERCENTAGE_HOLDING,
                                   0);
          DBG('l_total' || L_TOTAL);
        END IF;
      END LOOP;
    
      IF L_TOTAL > 100 THEN
        OVPKS.PR_APPENDTBL('ST-CIF-415', L_TOTAL);
      END IF;
    
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT of the fn_chk_share_percent  ');
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the share percent details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_SHARE_PERCENT;

  FUNCTION FN_VALIDATE_ITEM(P_FUNCTION_ID IN VARCHAR2,
                            P_CUST_REC    IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                            P_ERR_CODE    IN OUT VARCHAR2,
                            P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN
  
   IS
  
    L_CNT                NUMBER(2);
    L_INX                NUMBER;
    L_CHARTOCHK          CHAR(1);
    L_FLAG               VARCHAR2(5) := 'TRUE';
    L_INTL_CCY_MASK      VARCHAR2(50) := '9G999G999G999G999G999G999';
    L_HINDU_CCY_MASK     VARCHAR2(50) := '99G99G99G99G99G99G99G99G999';
    I_THE_CCY_MASK       VARCHAR2(50);
    L_DECIMAL_POINTS     NUMBER;
    I_HINDU              CHAR(1);
    L_SWIFTCHARSET       VARCHAR2(100) := 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,- ()+/=*&%:?!"<>;~`@#$^_[]{}|\';
    L_CUSTOMER_NO        STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_ERR                VARCHAR2(255) := '';
    O_CNT                NUMBER;
    L_CIF_MASK           VARCHAR2(9);
    L_FIELD_NAME         UDTMS_FIELDS.FIELD_NAME%TYPE;
    L_FIELD_VAL          STTMS_UPLOAD_CUSTOMER.UDF_1%TYPE;
    L_VAL_RULE_TYPE      UDTMS_FIELDS.VAL_RULE_TYPE%TYPE;
    L_MASK_MAINT         VARCHAR2(1);
    P_RESULT             NUMBER(1);
    L_GRP_TYPE           STTMS_GROUP_CODE.GROUP_TYPE%TYPE;
    L_EXP_CAT            STTMS_GROUP_CODE.EXPOSURE_CATEGORY%TYPE;
    L_EXPOSURE_CAT_COUNT NUMBER(1) := 0;
    L_LOCATION_COUNT     NUMBER(1) := 0;
  
    L_IDENTIFIER_COUNT NUMBER := 0;
    L_ALGO_COUNT       NUMBER(1) := 0;
    L_COUNT_BIC        NUMBER(1) := 0;
    I                  NUMBER;
  
  BEGIN
  
    DBG('Inside Function fn_validate_item');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling Stpks_Stdcif_Utils_1_cluster.Fn_Pre_Validate_Item');
      IF NOT
          STPKS_STDCIF_UTILS_1_CLUSTER.FN_PRE_VALIDATE_ITEM(P_FUNCTION_ID,
                                                            P_CUST_REC,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
        DBG('Returned False from Stpks_Stdcif_Utils_1_cluster.Fn_Pre_Validate_Item..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT FN_CHECK_UID(P_FUNCTION_ID, P_CUST_REC, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Failed while checking the UID');
    
    END IF;
  
    IF NOT FN_CHECK_XREF(P_FUNCTION_ID,
                         P_CUST_REC.V_STTMS_CUSTOMER.EXT_REF_NO,
                         P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO,
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
      DBG('Failed while checking the UDF');
    
    END IF;
  
    DBG('Before Maximum Check length');
  
    BEGIN
    
      DBG('CHECKING CUST TYPE -->' ||
          P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE);
      DBG('CHECKING dob  WITH CUST TYPE -->' ||
          P_CUST_REC.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH);
      DBG('#26097587 p_Cust_Rec.v_sttms_mfi_details.MFI_CUST_TYPE -->' ||
          P_CUST_REC.V_STTMS_MFI_DETAILS.MFI_CUST_TYPE);
      DBG('#26097587 p_Cust_Rec.v_Sttms_Customer.MFI_Customer -->' ||
          P_CUST_REC.V_STTMS_CUSTOMER.MFI_CUSTOMER);
      IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      
        IF NVL(P_CUST_REC.V_STTMS_MFI_DETAILS.MFI_CUST_TYPE, 'I') NOT IN
           ('G', 'C') THEN
        
          IF P_CUST_REC.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH IS NULL THEN
            DBG('#26097587 inside if');
            DBG('DOB cannot be Null');
          
            P_ERR_CODE := 'ST-CIFDOB';
          
            P_ERR_PARAMS := '@STTMS_CUST_PERSONAL.Date_Of_Birth';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);
          
          END IF;
        END IF;
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('AC', 'Encountered some problem here' || SQLERRM);
    END;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      IF P_CUST_REC.
       V_STTMS_CUSTOMER.UNIQUE_ID_NAME IS NULL AND P_CUST_REC.
       V_STTMS_CUSTOMER.UNIQUE_ID_VALUE IS NOT NULL THEN
        DBG('unique id  is null');
        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := '@STTMS_CUSTOMER.UNIQUE_ID_NAME~';
        RETURN FALSE;
      END IF;
    
      IF P_CUST_REC.
       V_STTMS_CUSTOMER.UNIQUE_ID_NAME IS NOT NULL AND P_CUST_REC.
       V_STTMS_CUSTOMER.UNIQUE_ID_VALUE IS NULL THEN
        DBG('unique id value is null');
        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := '@STTMS_CUSTOMER.UNIQUE_ID_VALUE~';
        RETURN FALSE;
      
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE = GLOBAL.LANG
    
     THEN
    
      DBG('Calling fn_cust_basic_max_length');
    
      IF NOT FN_CUST_BASIC_MAX_LENGTH(P_FUNCTION_ID,
                                      P_CUST_REC,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
      
        DBG('Failed in fn_cust_basic_max_length: ' || P_ERR_CODE);
      
      END IF;
    
      DBG('Calling fn_cust_personal_max_length');
    
      IF NOT FN_CUST_PERSONAL_MAX_LENGTH(P_FUNCTION_ID,
                                         P_CUST_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN
      
        DBG('Failed in fn_cust_personal_max_length ' || P_ERR_CODE);
      
      END IF;
    
      DBG('Calling fn_cust_corp_max_length');
    
      IF NOT FN_CUST_CORP_MAX_LENGTH(P_FUNCTION_ID,
                                     P_CUST_REC,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
      
        DBG('Failed in fn_cust_corp_max_length: ' || P_ERR_CODE);
      
      END IF;
    
    END IF;
  
    DBG('Before Personal Joint Details Check');
  
    IF P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.COUNT > 0 THEN
    
      DBG('Calling fn_cust_joint_details');
      IF NOT FN_CUST_JOINT_DETAILS(P_FUNCTION_ID,
                                   P_CUST_REC,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
        DBG('Failure from fn_cust_joint_details: ' || P_ERR_CODE);
      
      END IF;
    END IF;
  
    IF (P_CUST_REC.V_STTMS_CUSTOMER.ISSUER_CUSTOMER = 'Y' OR
       P_CUST_REC.V_STTMS_CUSTOMER.GENERATE_MT920 = 'Y') AND
       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      DBG('Failed this check');
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '"Issuer Customer" or "MT920" cannot be checked for Customer Type "Individual"~';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    DBG('After Personal Details Check');
  
    IF NOT FN_CHK_AML_REQUIRED(P_FUNCTION_ID,
                               P_CUST_REC.V_STTMS_CUSTOMER.AML_REQUIRED,
                               'Aml Required',
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
  
    DBG('Before calling fn_sname_valid');
    IF NOT
        FN_SNAME_VALID(P_FUNCTION_ID, P_CUST_REC, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Short Name Validation Failed');
      RETURN FALSE;
    END IF;
  
    L_FLAG := 'TRUE';
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NAME1 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NAME1) <>
         'TRUE' THEN
        DBG('CUSTOMER NAME1 check error');
        P_ERR_CODE := 'ST-TRN05';
      
        P_ERR_PARAMS := '@STTMS_CUSTOMER.CUSTOMER_NAME1';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    END IF;
  
    DBG('After Liability Number Validation');
  
    IF NOT FN_SWIFTCODE_VALID(P_CUST_REC, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating Swift Code');
      RETURN FALSE;
    END IF;
  
    DBG('After Swift Code Validation');
  
    IF NOT FN_SSN_VALID(P_CUST_REC, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating SSN');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_CHK_FX_NETTING_CUSTOMER(P_FUNCTION_ID,
                                      P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                      P_CUST_REC.V_STTMS_CUSTOMER.FX_NETTING_CUSTOMER,
                                      'Fx Netting Customer',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
      DBG('Error ocurred while validatin FX NETT Customer');
      RETURN FALSE;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.CHARGE_GROUP IS NOT NULL THEN
      IF NOT FN_CHK_CHG_GRP(P_CUST_REC.V_STTMS_CUSTOMER.CHARGE_GROUP) THEN
        DBG('Error validatiing charge group');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.CUST_CLG_GROUP IS NOT NULL THEN
      IF NOT FN_CHK_CLG_GRP(P_CUST_REC.V_STTMS_CUSTOMER.CUST_CLG_GROUP) THEN
        DBG('Error validatiing clearing group');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.TAX_GROUP IS NOT NULL THEN
      IF NOT FN_CHK_TAX_GRP(P_CUST_REC.V_STTMS_CUSTOMER.TAX_GROUP) THEN
        DBG('Error validatiing tax group');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_CATEGORY IS NOT NULL THEN
    
      SELECT COUNT(*)
        INTO L_EXPOSURE_CAT_COUNT
        FROM STTMS_EXPOSURE_CATEGORY
       WHERE RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND EXPOSURE_CATEGORY =
             P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_CATEGORY;
    
      IF L_EXPOSURE_CAT_COUNT <= 0 THEN
        DBG('Exposure Category Invalid');
        OVPKSS.PR_APPENDTBL('ST-UPLD13', '');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IS NOT NULL THEN
    
      BEGIN
        SELECT COUNT(1)
          INTO L_IDENTIFIER_COUNT
          FROM STTM_STATIC_TYPE
         WHERE TYPE_VALUE = P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_NAME
           AND TYPE = 'CIF_ID_TYPE';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data for ' || P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_NAME ||
              'CIF_ID_TYPE');
          L_IDENTIFIER_COUNT := 0;
        WHEN OTHERS THEN
          DBG('failed in others of elpks_collateral_service.fn_collateral_type');
      END;
    
      IF L_IDENTIFIER_COUNT <= 0 THEN
        DBG('Unique Identifier Invalid');
        OVPKSS.PR_APPENDTBL('ST-UPLD14', '');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.ALG_ID IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_ALGO_COUNT
        FROM CSTMS_ALG_MASTER
       WHERE RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND ALG_NAME = P_CUST_REC.V_STTMS_CUSTOMER.ALG_ID;
    
      IF L_ALGO_COUNT <= 0 THEN
        DBG('Algorithm Id is Invalid');
        OVPKSS.PR_APPENDTBL('ST-UPLD15', '');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.RISK_CATEGORY IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_RISK_CATEGORY
       WHERE RISK_CATEGORY = P_CUST_REC.V_STTMS_CUSTOMER.RISK_CATEGORY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
    
      IF L_CNT <= 0 THEN
        DBG('Risk Category Invalid');
        OVPKSS.PR_APPENDTBL('ST-UPLD11', '');
      END IF;
    END IF;
  
    IF NVL(P_CUST_REC.V_STTMS_CUSTOMER.OVERALL_LIMIT, 0) <> 0 THEN
      IF P_CUST_REC.V_STTMS_CUSTOMER.OVERALL_LIMIT < 0 THEN
        DBG('Overall limit should not be lessthen 0  ');
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Liabilities Overall limit~less than 0';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    END IF;
    IF NVL(P_CUST_REC.V_STTMS_CUSTOMER.FX_CLEAN_RISK_LIMIT, 0) <> 0 OR
       NVL(P_CUST_REC.V_STTMS_CUSTOMER.SEC_CLEAN_RISK_LIMIT, 0) <> 0 OR
       NVL(P_CUST_REC.V_STTMS_CUSTOMER.SEC_PSTL_RISK_LIMIT, 0) <> 0 THEN
      IF P_CUST_REC.V_STTMS_CUSTOMER.FX_CLEAN_RISK_LIMIT >
         NVL(P_CUST_REC.V_STTMS_CUSTOMER.OVERALL_LIMIT, 0) OR
         P_CUST_REC.V_STTMS_CUSTOMER.SEC_CLEAN_RISK_LIMIT >
         NVL(P_CUST_REC.V_STTMS_CUSTOMER.OVERALL_LIMIT, 0) OR
         P_CUST_REC.V_STTMS_CUSTOMER.SEC_PSTL_RISK_LIMIT >
         NVL(P_CUST_REC.V_STTMS_CUSTOMER.OVERALL_LIMIT, 0) THEN
        DBG('Individual limits are greater than the overall limit');
        OVPKSS.PR_APPENDTBL('CS-MINMAX1',
                            'Clean Risk Limits~greater than Overall Limit');
      END IF;
    END IF;
  
    IF NVL(P_CUST_REC.V_STTMS_CUSTOMER.FX_CUST_CLEAN_RISK_LIMIT, 0) <> 0 OR
       NVL(P_CUST_REC.V_STTMS_CUSTOMER.SEC_CUST_CLEAN_RISK_LIMIT, 0) <> 0 OR
       NVL(P_CUST_REC.V_STTMS_CUSTOMER.SEC_CUST_PSTL_RISK_LIMIT, 0) <> 0 THEN
      IF P_CUST_REC.V_STTMS_CUSTOMER.FX_CUST_CLEAN_RISK_LIMIT >
         NVL(P_CUST_REC.V_STTMS_CUSTOMER.FX_CLEAN_RISK_LIMIT, 0) OR
         P_CUST_REC.V_STTMS_CUSTOMER.SEC_CUST_CLEAN_RISK_LIMIT >
         NVL(P_CUST_REC.V_STTMS_CUSTOMER.SEC_CLEAN_RISK_LIMIT, 0) OR
         P_CUST_REC.V_STTMS_CUSTOMER.SEC_CUST_PSTL_RISK_LIMIT >
         NVL(P_CUST_REC.V_STTMS_CUSTOMER.SEC_PSTL_RISK_LIMIT, 0) THEN
        DBG('Individual customer limits are greater than the generic limit');
        OVPKSS.PR_APPENDTBL('CS-MINMAX1',
                            'Customer Risk Limits~greater than Clean Risk Limits');
      END IF;
    END IF;
  
    IF NOT FN_UTIL_PROVIDER_VALID(P_CUST_REC, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating Utility Provider');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_CHK_EMP_TENURE(P_FUNCTION_ID,
                             P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.EMPLOYMENT_TENURE,
                             'Employment Tenure',
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
  
    DBG('After Employment tenure Validation');
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.DEBTOR_CATEGORY IS NOT NULL THEN
      IF NOT FN_CHK_DEBTOR_CAT(P_CUST_REC.V_STTMS_CUSTOMER.DEBTOR_CATEGORY) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.RISK_PROFILE IS NOT NULL THEN
      IF NOT FN_CHK_RISK_PRFL(P_CUST_REC.V_STTMS_CUSTOMER.RISK_PROFILE) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT FN_CHK_RETIREMENT_AGE(P_FUNCTION_ID,
                                 P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.RETIREMENT_AGE,
                                 'Retirement Age',
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
    DBG('After Retirement Age Validation');
  
    P_ERR_PARAMS := 'Other_income';
  
    IF NOT FN_CHK_OTHER_INCOME(P_FUNCTION_ID,
                               P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.OTHER_INCOME,
                               'Other Income',
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
    DBG('After Other Income Validation');
  
    P_ERR_PARAMS := 'Rent';
    IF NOT FN_CHK_RENT(P_FUNCTION_ID,
                       P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.RENT,
                       'Rent',
                       P_ERR_CODE,
                       P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
    DBG('After Rent Validation');
  
    P_ERR_PARAMS := 'Insurance';
    IF NOT FN_CHK_INSURANCE(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.INSURANCE,
                            'Insurance',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
    DBG('After Insurance Validation');
  
    P_ERR_PARAMS := 'Loan Payment';
    IF NOT FN_CHK_PAYMENT(P_FUNCTION_ID,
                          P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.LOAN_PAYMENT,
                          'Loan Payment',
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
    DBG('After Loan Payment Validation');
  
    P_ERR_PARAMS := 'Other Expenses';
    IF NOT FN_CHK_OTHER_EXPENSES(P_FUNCTION_ID,
                                 P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.OTHER_EXPENSES,
                                 'Other Expenses',
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
    DBG('After validating Other Expenses');
  
    P_ERR_PARAMS := 'House Value';
    IF NOT FN_CHK_HOUSE_VALUE(P_FUNCTION_ID,
                              P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.HOUSE_VALUE,
                              'House Value',
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
    DBG('After validating House Value');
  
    P_ERR_PARAMS := '';
    IF NOT FN_CHK_DEPENDENT_CHILDREN(P_FUNCTION_ID,
                                     P_CUST_REC.V_STTMS_CUST_DOMESTIC.DEPENDENT_CHILDREN,
                                     'Dependant Children',
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
  
    IF NOT FN_CHK_DEPENDENT_OTHERS(P_FUNCTION_ID,
                                   P_CUST_REC.V_STTMS_CUST_DOMESTIC.DEPENDENT_OTHERS,
                                   'Dependant Others',
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
  
    IF NOT FN_CHK_NODE_CUST_PERSONAL(P_FUNCTION_ID,
                                     P_CUST_REC,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
  
    IF NOT FN_CHK_NODE_CUST_CORP(P_FUNCTION_ID,
                                 P_CUST_REC,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      RETURN FALSE;
    END IF;
  
    DBG('for CCY Restrictions check');
    IF P_CUST_REC.V_STTMS_CUSTOMER.CLS_PARTICIPANT = 'N' THEN
      IF P_CUST_REC.V_FSTMS_CUSTOMER_CCY.COUNT > 0 THEN
        DBG('cls pariticipant should not be N');
        OVPKSS.PR_APPENDTBL('ST-CIF117', P_ERR_PARAMS);
      END IF;
    ELSE
      IF P_CUST_REC.V_FSTMS_CUSTOMER_CCY.COUNT > 0 THEN
        FOR I IN P_CUST_REC.V_FSTMS_CUSTOMER_CCY.FIRST .. P_CUST_REC.V_FSTMS_CUSTOMER_CCY.LAST LOOP
        
          DBG('p_cust_rec.v_fstms_customer_ccy(i).typ_cls_ccy:' || P_CUST_REC.V_FSTMS_CUSTOMER_CCY(I)
              .CCY_CODE);
        
          IF NOT FN_CHK_CCY(P_FUNCTION_ID,
                            P_CUST_REC.V_FSTMS_CUSTOMER_CCY(I).CCY_CODE,
                            '- CLS Currency ' || P_CUST_REC.V_FSTMS_CUSTOMER_CCY(I)
                            .CCY_CODE,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
            RETURN FALSE;
          END IF;
        
        END LOOP;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_MT920_MAINT.COUNT > 0 THEN
      FOR I IN P_CUST_REC.V_STTMS_CUST_MT920_MAINT.FIRST .. P_CUST_REC.V_STTMS_CUST_MT920_MAINT.LAST LOOP
        DBG('p_cust_rec.v_sttms_cust_mt920_maint(i).bic_code is ' || P_CUST_REC.V_STTMS_CUST_MT920_MAINT(I)
            .BIC_CODE);
      
        SELECT COUNT(*)
          INTO L_COUNT_BIC
          FROM ISTM_BIC_DIRECTORY
         WHERE BIC_CODE = P_CUST_REC.V_STTMS_CUST_MT920_MAINT(I).BIC_CODE
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A'
           AND ONCE_AUTH = 'Y'
           AND SK_ARRANGEMENT = 'Y';
        IF L_COUNT_BIC = 0 THEN
          DBG('invalid bic code ' || P_CUST_REC.V_STTMS_CUST_MT920_MAINT(I)
              .BIC_CODE);
        
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'GW-FX007',
                       P_CUST_REC.V_STTMS_CUST_MT920_MAINT(I).BIC_CODE);
          RETURN FALSE;
        END IF;
      END LOOP;
    END IF;
  
    DBG('About to call fn_issuer_validate');
    IF NOT FN_ISSUER_VALIDATE(P_FUNCTION_ID,
                              P_CUST_REC,
                              P_CUST_REC,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
      DBG('Problems with Validation issuer details and limits ');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_CHK_SHARE_PERCENT(P_FUNCTION_ID,
                                P_CUST_REC,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
      DBG('Problems with Validation shareholder ');
      RETURN FALSE;
    
    END IF;
  
    DBG('percentage_holding is not null');
  
    IF NOT FN_VALIDATE_REL_LINK(P_FUNCTION_ID,
                                P_CUST_REC,
                                P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
      DBG('Problems with Validation shareholder ');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      IF FN_IS_ERROR(P_ERR_CODE) THEN
        RAISE STPKSS_UPLOAD.G_HALT_ON_EXCEPTION;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA IS NOT NULL THEN
    
      IF NOT FN_CHK_MEDIA(P_CUST_REC.V_STTMS_CUSTOMER.DEFAULT_MEDIA) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH IS NOT NULL THEN
      DBG('local branch: ');
      IF NOT FN_CHK_BRANCH(P_FUNCTION_ID,
                           P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH,
                           'Local Branch',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.LIAB_BR IS NOT NULL THEN
    
      IF NOT FN_CHK_BRANCH(P_FUNCTION_ID,
                           P_CUST_REC.V_STTMS_CUSTOMER.LIAB_BR,
                           'Liab Branch',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    DBG('validations for country code,ccy code ,customer category ');
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.COUNTRY IS NOT NULL THEN
    
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUSTOMER.COUNTRY,
                            'Country',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_COUNTRY IS NOT NULL THEN
    
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_COUNTRY,
                            'Exposure Country',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.NATIONALITY IS NOT NULL THEN
    
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUSTOMER.NATIONALITY,
                            'Nationality',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY IS NOT NULL THEN
    
      IF NOT FN_CHK_CUST_CATEG(P_FUNCTION_ID,
                               P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_CATEGORY,
                               'Customer Category',
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    DBG('@@@@@@p_cust_rec.v_sttms_customer.limit_ccy: ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.LIMIT_CCY);
    IF P_CUST_REC.V_STTMS_CUSTOMER.LIMIT_CCY IS NOT NULL THEN
    
      IF NOT FN_CHK_CCY(P_FUNCTION_ID,
                        P_CUST_REC.V_STTMS_CUSTOMER.LIMIT_CCY,
                        '- Liability Limits Currency',
                        P_ERR_CODE,
                        P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE IS NOT NULL THEN
    
      IF NOT FN_CHK_LANGUAGE(P_FUNCTION_ID,
                             P_CUST_REC.V_STTMS_CUSTOMER.LANGUAGE,
                             'Language',
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.D_COUNTRY IS NOT NULL THEN
    
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PERSONAL.D_COUNTRY,
                            'Domestic Country',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.P_COUNTRY IS NOT NULL THEN
    
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PERSONAL.P_COUNTRY,
                            'Permanent Country',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.CCY_PERS_INCEXP IS NOT NULL THEN
    
      IF NOT FN_CHK_CCY(P_FUNCTION_ID,
                        P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.CCY_PERS_INCEXP,
                        '- Professional Currency of Amounts',
                        P_ERR_CODE,
                        P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_COUNTRY IS NOT NULL THEN
    
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_COUNTRY,
                            'Employment Country',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY IS NOT NULL THEN
    
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY,
                            'Incorporation Country',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.R_COUNTRY IS NOT NULL THEN
    
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_CORPORATE.R_COUNTRY,
                            'Country of Registration',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.AMOUNTS_CCY IS NOT NULL THEN
    
      IF NOT FN_CHK_CCY(P_FUNCTION_ID,
                        P_CUST_REC.V_STTMS_CUST_CORPORATE.AMOUNTS_CCY,
                        '- Corporate Currency of Amounts',
                        P_ERR_CODE,
                        P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.GROUP_CODE IS NOT NULL THEN
    
      IF NOT FN_CHK_GROUP_CODE(P_FUNCTION_ID,
                               P_CUST_REC.V_STTMS_CUSTOMER.GROUP_CODE,
                               P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
      BEGIN
        SELECT EXPOSURE_CATEGORY
          INTO L_EXP_CAT
          FROM STTMS_GROUP_CODE
         WHERE GROUP_CODE = P_CUST_REC.V_STTMS_CUSTOMER.GROUP_CODE;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_EXP_CAT := NULL;
      END;
    
      IF P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_CATEGORY IS NOT NULL THEN
      
        IF P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_CATEGORY <> L_EXP_CAT THEN
          P_ERR_CODE   := 'ST-UPLD40';
          P_ERR_PARAMS := 'Exposure_Category';
          DBG('Invalid Exposure Category');
          RETURN FALSE;
        END IF;
      
      END IF;
    ELSE
    
      IF P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_CATEGORY IS NOT NULL THEN
        IF NOT FN_CHK_EXP_CATEG(P_FUNCTION_ID,
                                P_CUST_REC.V_STTMS_CUSTOMER.EXPOSURE_CATEGORY,
                                'Exposure Category',
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.CUST_CLASSIFICATION IS NOT NULL THEN
    
      IF NOT FN_CHK_CUST_CLASSIFICATION(P_FUNCTION_ID,
                                        P_CUST_REC.V_STTMS_CUSTOMER.CUST_CLASSIFICATION,
                                        'Customer Classfication',
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling Stpks_Stdcif_Utils_1_cluster.Fn_Post_Validate_Item');
      IF NOT
          STPKS_STDCIF_UTILS_1_CLUSTER.FN_POST_VALIDATE_ITEM(P_FUNCTION_ID,
                                                             P_CUST_REC,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
        DBG('Returned False from Stpks_Stdcif_Utils_1_cluster.Fn_Post_Validate_Item..');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('fn_validate_item Return true ');
    RETURN TRUE;
  
  EXCEPTION
    WHEN STPKSS_UPLOAD.G_HALT_ON_EXCEPTION THEN
    
      RETURN FALSE;
    
    WHEN OTHERS THEN
    
      DBG('Motherhood EXCEPTION');
      DBG('fn_validate_item FAILED');
      DBG('ERROR IS - ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPLD200';
      P_ERR_PARAMS := SQLERRM;
      L_ERR        := L_ERR || P_ERR_CODE;
    
      RETURN FALSE;
    
  END FN_VALIDATE_ITEM;

  FUNCTION FN_CHECK_UDF(P_FUNCTION_ID IN VARCHAR2,
                        P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                        P_ERR_CODE    IN OUT VARCHAR2,
                        P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_FIELD_NAME    STTMS_BASE_TABLE_UDF_DETAIL.FIELD_NAME%TYPE;
    L_VAL_RULE_TYPE UDTMS_FIELDS.VAL_RULE_TYPE%TYPE;
    L_FIELD_VAL     VARCHAR2(255);
    L_UNIQUE_FIELD  UDTM_FIELDS.UNIQUE_FIELD%TYPE;
  BEGIN
    DBG('Inside the function fn_check_udf');
  
    IF NOT STPKS_STDCIF_UTILS_1.FN_SKIP_CUSTOM THEN
      DBG('Calling Stpks_Stdcif_Utils_1_Custom.FN_CHECK_UDF');
      IF NOT STPKS_STDCIF_UTILS_1_CUSTOM.FN_CHECK_UDF(P_FUNCTION_ID,
                                                      P_CUST_REC,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT STPKS_STDCIF_UTILS_1.FN_SKIP_CLUSTER THEN
      DBG('Calling Stpks_Stdcif_Utils_1_Cluster.FN_CHECK_UDF');
      IF NOT STPKS_STDCIF_UTILS_1_CLUSTER.FN_CHECK_UDF(P_FUNCTION_ID,
                                                       P_CUST_REC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT STPKS_STDCIF_UTILS_1.FN_SKIP_KERNEL THEN
    
      FOR I IN 1 .. 5 LOOP
        L_FIELD_NAME := NULL;
      
        BEGIN
          SELECT FIELD_NAME
            INTO L_FIELD_NAME
            FROM STTMS_BASE_TABLE_UDF_DETAIL
           WHERE FUNCTION_ID = 'STDCIF'
             AND SEQ_NO = I
             AND EXISTS (SELECT 1
                    FROM STTMS_BASE_TABLE_UDF_MASTER
                   WHERE FUNCTION_ID = 'STDCIF'
                     AND ONCE_AUTH = 'Y');
        EXCEPTION
          WHEN OTHERS THEN
            DBG('no UDF associated for seq no - ' || I || ' - ' || SQLERRM);
        END;
      
        IF L_FIELD_NAME IS NOT NULL THEN
        
          SELECT VAL_RULE_TYPE, UNIQUE_FIELD
            INTO L_VAL_RULE_TYPE, L_UNIQUE_FIELD
            FROM UDTMS_FIELDS
           WHERE FIELD_NAME = L_FIELD_NAME;
        
          IF NVL(L_VAL_RULE_TYPE, 'N') = 'Y' OR
             NVL(L_UNIQUE_FIELD, 'N') = 'Y' THEN
            IF I = 1 THEN
              L_FIELD_VAL := P_CUST_REC.V_STTMS_CUSTOMER.UDF_1;
            ELSIF I = 2 THEN
              L_FIELD_VAL := P_CUST_REC.V_STTMS_CUSTOMER.UDF_2;
            ELSIF I = 3 THEN
              L_FIELD_VAL := P_CUST_REC.V_STTMS_CUSTOMER.UDF_3;
            ELSIF I = 4 THEN
              L_FIELD_VAL := P_CUST_REC.V_STTMS_CUSTOMER.UDF_4;
            ELSIF I = 5 THEN
              L_FIELD_VAL := P_CUST_REC.V_STTMS_CUSTOMER.UDF_5;
            END IF;
          
            IF NOT UDPKS_BASE_TABLE_UDF.FN_WRAPPER_UDF_VAL('STDCIF',
                                                           '~' ||
                                                           P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO || '~',
                                                           'STTM_CUSTOMER',
                                                           I,
                                                           L_FIELD_VAL,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
              DBG('validation failed for udf_1');
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      END LOOP;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_check_udf as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := ' - Failed to read UDFs';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHECK_UDF;

  FUNCTION FN_CUST_BASIC_MAX_LENGTH(P_FUNCTION_ID IN VARCHAR2,
                                    P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                    P_ERR_CODE    IN OUT VARCHAR2,
                                    P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Just entered fn_cust_basic_max_length');
  
    IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                          P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE1,
                          'Address 1',
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                          P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE2,
                          'Address 2',
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                          P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE3,
                          'Address 3',
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                          P_CUST_REC.V_STTMS_CUSTOMER.ADDRESS_LINE4,
                          'Address 4',
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NAME1,
                       'Customer Name',
                       P_ERR_CODE,
                       P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    IF NOT FN_CHK_HO_AC_NO(P_FUNCTION_ID,
                           P_CUST_REC.V_STTMS_CUSTOMER.HO_AC_NO,
                           'HO Ac Number',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    IF NOT FN_CHK_LIAB_NODE(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUSTOMER.LIAB_NODE,
                            'Liability Node',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    DBG('Successfully completed fn_cust_basic_max_length');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := ' - Failed in validating the max length';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
    
  END FN_CUST_BASIC_MAX_LENGTH;

  FUNCTION FN_CUST_PERSONAL_MAX_LENGTH(P_FUNCTION_ID IN VARCHAR2,
                                       P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                       P_ERR_CODE    IN OUT VARCHAR2,
                                       P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Just entered fn_cust_personal_max_length');
    IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                          P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS1,
                          'Domicile Address Line1',
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS2 IS NOT NULL THEN
      DBG('Check MaxLength for Address2');
    
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS2,
                            'Domicile Address Line2',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS3 IS NOT NULL THEN
      DBG('Check MaxLength for Address3');
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PERSONAL.D_ADDRESS3,
                            'Domicile Address Line3',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    DBG('Check MaxLength for PAddress1');
  
    IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                          P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS1,
                          'Permanent Address Line1',
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS2 IS NOT NULL THEN
      DBG('Check MaxLength for PAddress2');
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS2,
                            'Permanent Address Line2',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS3 IS NOT NULL THEN
      DBG('Check MaxLength for PAddress3');
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PERSONAL.P_ADDRESS3,
                            'Permanent Address Line3',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    DBG('Check MaxLength for First Name' ||
        LENGTH(P_CUST_REC.V_STTMS_CUST_PERSONAL.FIRST_NAME));
    IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                       P_CUST_REC.V_STTMS_CUST_PERSONAL.FIRST_NAME,
                       'First Name',
                       P_ERR_CODE,
                       P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    DBG('Check MaxLength for Last Name' ||
        LENGTH(P_CUST_REC.V_STTMS_CUST_PERSONAL.LAST_NAME));
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.LAST_NAME IS NOT NULL THEN
      IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                         P_CUST_REC.V_STTMS_CUST_PERSONAL.LAST_NAME,
                         'Last Name',
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    DBG('Check MaxLength for Legal Guardian' ||
        LENGTH(P_CUST_REC.V_STTMS_CUST_PERSONAL.LEGAL_GUARDIAN));
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.LEGAL_GUARDIAN IS NOT NULL THEN
      IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                         P_CUST_REC.V_STTMS_CUST_PERSONAL.LEGAL_GUARDIAN,
                         'Legal Guardian',
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.TELEPHONE IS NOT NULL THEN
      IF NOT FN_CHK_TELEPHONE_NO(P_FUNCTION_ID,
                                 P_CUST_REC.V_STTMS_CUST_PERSONAL.TELEPHONE,
                                 'Telephone',
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.P_NATIONAL_ID IS NOT NULL THEN
      IF NOT FN_CHK_NATIONAL_ID(P_FUNCTION_ID,
                                P_CUST_REC.V_STTMS_CUST_PERSONAL.P_NATIONAL_ID,
                                'National ID',
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.FAX IS NOT NULL THEN
      IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                              P_CUST_REC.V_STTMS_CUST_PERSONAL.FAX,
                              'Fax',
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    DBG('passport validation');
    IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE IS NOT NULL) THEN
      IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PASSPORT_NO IS NULL) THEN
        P_ERR_CODE := 'ST-MAN01';
      
        P_ERR_PARAMS := 'Passport Number~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    END IF;
  
    IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE IS NOT NULL) THEN
      IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PASSPORT_NO IS NULL) THEN
        P_ERR_CODE := 'ST-MAN01';
      
        P_ERR_PARAMS := 'Passport Number~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    END IF;
    IF (P_CUST_REC.V_STTMS_CUST_PERSONAL.PASSPORT_NO IS NOT NULL) THEN
    
      IF P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_ISS_DATE IS NULL THEN
        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := 'Issue Date~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
      IF P_CUST_REC.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE IS NULL THEN
        P_ERR_CODE   := 'ST-MAN01';
        P_ERR_PARAMS := 'Expiry Date~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
    END IF;
  
    DBG('Validating Customer Domestic Info');
  
    IF P_CUST_REC.V_STTMS_CUST_DOMESTIC.SPOUSE_NAME IS NOT NULL THEN
      IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                         P_CUST_REC.V_STTMS_CUST_DOMESTIC.SPOUSE_NAME,
                         'Spouse Name',
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
        DBG('spouse name validation failed');
        DBG('Encountered');
      END IF;
    END IF;
  
    DBG('Validating Customer Professional Info');
  
    IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS1 IS NOT NULL THEN
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS1,
                            'E Address1',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    
      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS2 IS NOT NULL THEN
        IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                              P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS2,
                              'E Address2',
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS3 IS NOT NULL THEN
        IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                              P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS3,
                              'E Address3',
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_FAX IS NOT NULL THEN
        IF NOT FN_CHK_FAX(P_FUNCTION_ID,
                          P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_FAX,
                          'E-Fax',
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.PREV_DESIGNATION IS NOT NULL THEN
        IF NOT FN_CHK_DESIGNATION(P_FUNCTION_ID,
                                  P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.PREV_DESIGNATION,
                                  'Previous Designation',
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.EMPLOYER IS NOT NULL THEN
        IF NOT FN_CHK_EMPLOYER(P_FUNCTION_ID,
                               P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.EMPLOYER,
                               'Employer',
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.PREV_EMPLOYER IS NOT NULL THEN
        IF NOT FN_CHK_EMPLOYER(P_FUNCTION_ID,
                               P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.PREV_EMPLOYER,
                               'Previous Employer',
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_TELEX IS NOT NULL THEN
        IF NOT FN_CHK_TELEX(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_TELEX,
                            'E Telex',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_TELEPHONE IS NOT NULL THEN
        IF NOT FN_CHK_TELEPHONE_NO(P_FUNCTION_ID,
                                   P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_TELEPHONE,
                                   'E Telephone',
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    END IF;
  
    DBG('Successfully completed fn_cust_personal_max_length');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := ' - Failed in validating the max length';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
    
  END FN_CUST_PERSONAL_MAX_LENGTH;

  FUNCTION FN_CUST_CORP_MAX_LENGTH(P_FUNCTION_ID IN VARCHAR2,
                                   P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                   P_ERR_CODE    IN OUT VARCHAR2,
                                   P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Just entered fn_cust_corp_max_length');
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS1 IS NOT NULL THEN
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS1,
                            'Residential Address1',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS2 IS NOT NULL THEN
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS2,
                            'Residential Address2',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS3 IS NOT NULL THEN
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS3,
                            'Residential Address3',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.CORPORATE_NAME IS NOT NULL THEN
      IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                         P_CUST_REC.V_STTMS_CUST_CORPORATE.CORPORATE_NAME,
                         'Corporate Name',
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CORP_DIRECTORS.COUNT > 0 THEN
    
      FOR L_CORP_DIRE IN P_CUST_REC.V_STTMS_CORP_DIRECTORS.FIRST .. P_CUST_REC.V_STTMS_CORP_DIRECTORS.LAST LOOP
        IF P_CUST_REC.V_STTMS_CORP_DIRECTORS(L_CORP_DIRE)
         .DIRECTOR_NAME IS NOT NULL THEN
          IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                             P_CUST_REC.V_STTMS_CORP_DIRECTORS(L_CORP_DIRE)
                             .DIRECTOR_NAME,
                             'Director Name',
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
            DBG('Encountered');
          END IF;
        END IF;
      END LOOP;
    END IF;
  
    DBG('Successfully completed fn_cust_corp_max_length');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := ' - Failed in validating the max length';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
    
  END FN_CUST_CORP_MAX_LENGTH;

  FUNCTION FN_CUST_JOINT_DETAILS(P_FUNCTION_ID IN VARCHAR2,
                                 P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside fn_cust_joint_details');
  
    FOR REC IN P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.FIRST .. P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT.LAST LOOP
    
      IF NOT FN_CHK_DATE_OF_BIRTH(P_FUNCTION_ID,
                                  P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                                  .DATE_OF_BIRTH,
                                  'Date Of Birth',
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
        DBG('Encountered');
      
        P_ERR_CODE := 'ST-CIF202';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, '');
      
      END IF;
    
      IF NOT FN_CHK_RECORD_NO(P_FUNCTION_ID,
                              P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                              .RECORD_NO,
                              'Record No',
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    
      IF NOT FN_CHK_SEX(P_FUNCTION_ID,
                        P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC).SEX,
                        'Sex',
                        P_ERR_CODE,
                        P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    
      IF NOT FN_CHK_DECEASED(P_FUNCTION_ID,
                             P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                             .DECEASED,
                             'Deceased',
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    
      DBG('Check for resident_status');
      IF NOT FN_CHK_RESIDENT_STATUS(P_FUNCTION_ID,
                                    P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                                    .RESIDENT_STATUS,
                                    'Resident Status',
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    
      IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                            P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                            .ADDRESS1,
                            'Joint Address 1',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    
      IF NOT
          FN_SSN_FORMAT_VALIDATION(P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC).SSN) THEN
        DBG('SSN Joint failed');
      
      END IF;
    
      IF P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
       .ADDRESS2 IS NOT NULL THEN
        IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                              P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                              .ADDRESS2,
                              'Joint Address 2',
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
       .ADDRESS3 IS NOT NULL THEN
        IF NOT FN_CHK_ADDRESS(P_FUNCTION_ID,
                              P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                              .ADDRESS3,
                              'Joint Address 3',
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                         P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                         .FIRST_NAME,
                         'Joint First Name',
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    
      IF P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
       .LAST_NAME IS NOT NULL THEN
        IF NOT FN_CHK_NAME(P_FUNCTION_ID,
                           P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                           .LAST_NAME,
                           'Joint Last Name',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
          DBG('Encountered');
        END IF;
      END IF;
    
      IF (P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
         .PPT_ISS_DATE IS NOT NULL) THEN
        IF (P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
           .PASSPORT_NO IS NULL) THEN
          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Passport Details~';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;
    
      IF (P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
         .PPT_EXP_DATE IS NOT NULL) THEN
        IF (P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
           .PASSPORT_NO IS NULL) THEN
        
          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Passport Details~';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;
    
      IF (P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
         .PASSPORT_NO IS NOT NULL) THEN
        IF (P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
           .PPT_ISS_DATE IS NULL OR P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
           .PPT_EXP_DATE IS NULL) THEN
          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Passport Details~';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;
    
      IF (P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
         .PASSPORT_NO IS NOT NULL) THEN
        DBG('Calling fn_chk_passport');
        IF NOT FN_CHK_PASSPORT(P_FUNCTION_ID,
                               P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                               .PASSPORT_NO,
                               P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                               .PPT_ISS_DATE,
                               P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                               .PPT_EXP_DATE,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
          DBG('Failed in fn_chk_passport');
        END IF;
      END IF;
    
      IF P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
       .TELEPHONE IS NOT NULL AND
          LENGTH(P_CUST_REC.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT(REC)
                 .TELEPHONE) > 105 THEN
        P_ERR_CODE   := 'ST-CUST0002';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
    END LOOP;
  
    DBG('Successfully completed fn_cust_joint_details');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := ' - Failed in validating the max length';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
    
  END FN_CUST_JOINT_DETAILS;

  FUNCTION FN_CHK_AML_REQUIRED(P_FUNCTION_ID        IN VARCHAR2,
                               P_AML_REQUIRED_TOCHK IN VARCHAR2,
                               P_AML_REQUIRED_DESC  IN VARCHAR2,
                               P_ERR_CODE           IN OUT VARCHAR2,
                               P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_aml_required');
  
    IF P_AML_REQUIRED_TOCHK IS NOT NULL AND
       P_AML_REQUIRED_TOCHK NOT IN ('Y', 'N') THEN
      DBG('Value for resident_status has to be either Y or N');
      P_ERR_CODE   := 'ST-UPLD43';
      P_ERR_PARAMS := '~' || P_AML_REQUIRED_TOCHK || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_aml_required_status as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the aml required flag~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_AML_REQUIRED;

  FUNCTION FN_SNAME_VALID(P_FUNCTION_ID IN VARCHAR2,
                          P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                          P_ERR_CODE    IN OUT VARCHAR2,
                          P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_CNT_CUSTOMER NUMBER(5);
  
  BEGIN
  
    SELECT NVL(COUNT(CUSTOMER_NO), 0)
      INTO L_CNT_CUSTOMER
      FROM STTMS_CUSTOMER
     WHERE SHORT_NAME = P_CUST_REC.V_STTMS_CUSTOMER.SHORT_NAME
       AND CUSTOMER_NO <> P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    IF L_CNT_CUSTOMER > 0 THEN
      DBG('Short Name already exists');
      P_ERR_CODE   := 'ST-CIF02';
      P_ERR_PARAMS := 'Short Name';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  END FN_SNAME_VALID;

  FUNCTION FN_CHKSWIFTFORMAT(FPSTRINGTOCHK IN VARCHAR2) RETURN VARCHAR2 IS
  
    L_SWIFTCHARSET VARCHAR2(100) := 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789:+?, .''-' ||
                                    CHR(10) || CHR(13) || '/' || '(' || ')';
  
    L_INX       NUMBER;
    L_CHARTOCHK VARCHAR2(1);
  
  BEGIN
  
    FOR L_INX IN 1 .. NVL(LENGTH(FPSTRINGTOCHK), 0) LOOP
      L_CHARTOCHK := SUBSTR(FPSTRINGTOCHK, L_INX, 1);
      IF INSTR(L_SWIFTCHARSET, L_CHARTOCHK) = 0 THEN
        RETURN('FALSE');
      END IF;
    END LOOP;
  
    RETURN('TRUE');
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN(SQLERRM);
  END FN_CHKSWIFTFORMAT;

  FUNCTION FN_SWIFTCODE_VALID(P_CUST_REC IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_ERRS     OUT ERTB_MSGS.ERR_CODE%TYPE,
                              P_PRMS     OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
    IF P_CUST_REC.V_STTMS_CUSTOMER.SWIFT_CODE IS NOT NULL AND
       P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'B' THEN
      IF LENGTH(P_CUST_REC.V_STTMS_CUSTOMER.SWIFT_CODE) NOT IN (8, 11) THEN
        DBG('Length of Swift code should be 8 or 11');
        P_ERRS := 'MS-00029';
        P_PRMS := 'Swift code';
        OVPKSS.PR_APPENDTBL(P_ERRS, P_PRMS);
      END IF;
    END IF;
    RETURN TRUE;
  END FN_SWIFTCODE_VALID;

  FUNCTION FN_SSN_VALID(P_CUST_REC IN STPKS_STDCIF_MAIN.TY_STDCIF,
                        P_ERRS     OUT ERTB_MSGS.ERR_CODE%TYPE,
                        P_PRMS     OUT ERTB_MSGS.MESSAGE%TYPE) RETURN BOOLEAN IS
  
    L_CNT NUMBER(5) := 0;
  BEGIN
  
    DBG('Just entered fn_ssn_valid, customer_type: ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE);
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
      DBG('Entering check for SSN');
    
      IF P_CUST_REC.V_STTMS_CUSTOMER.SSN IS NULL THEN
        IF NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('SSN_FT_CHK_REQD'), 'Y') = 'Y' THEN
        
          P_ERRS := 'FT-SSN000';
          P_PRMS := 'SSN';
          OVPKSS.PR_APPENDTBL(P_ERRS, P_PRMS);
        END IF;
      ELSE
      
        DBG('SSN: ' || P_CUST_REC.V_STTMS_CUSTOMER.SSN);
      
        SELECT COUNT(*)
          INTO L_CNT
          FROM STTMS_CUSTOMER
         WHERE SSN = P_CUST_REC.V_STTMS_CUSTOMER.SSN
           AND CUSTOMER_NO <> P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
      
        IF L_CNT = 0 THEN
          IF NOT FN_SSN_FORMAT_VALIDATION(P_CUST_REC.V_STTMS_CUSTOMER.SSN) THEN
          
            P_ERRS := 'FT-SSN002';
            P_PRMS := '';
            OVPKSS.PR_APPENDTBL(P_ERRS, P_PRMS);
          
          END IF;
        ELSE
          P_ERRS := 'FT-SSN003';
          P_PRMS := 'SSN';
          OVPKSS.PR_APPENDTBL(P_ERRS, P_PRMS);
        END IF;
      
      END IF;
    
    ELSE
      IF P_CUST_REC.V_STTMS_CUSTOMER.SSN IS NOT NULL THEN
        P_ERRS := 'ST-CIF107';
        P_PRMS := 'SSN';
        OVPKSS.PR_APPENDTBL(P_ERRS, P_PRMS);
      END IF;
    END IF;
  
    DBG('Successfully completed fn_ssn_valid');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT - Failed in fn_ssn_valid: ' || SQLERRM);
      P_ERRS := 'ST-UPL-001';
      P_PRMS := '- Failed while validating the SSN value of the customer~';
      OVPKSS.PR_APPENDTBL(P_ERRS, P_PRMS);
      RETURN TRUE;
  END FN_SSN_VALID;

  FUNCTION FN_CHK_FX_NETTING_CUSTOMER(P_FUNCTION_ID               IN VARCHAR2,
                                      P_CUSTOMER_NO               IN VARCHAR2,
                                      P_FX_NETTING_CUSTOMER_TOCHK IN VARCHAR2,
                                      P_FX_NETTING_CUSTOMER_DESC  IN VARCHAR2,
                                      P_ERR_CODE                  IN OUT VARCHAR2,
                                      P_ERR_PARAMS                IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_fx_netting_customer' ||
        P_FX_NETTING_CUSTOMER_TOCHK);
  
    IF P_FX_NETTING_CUSTOMER_TOCHK IS NULL THEN
      P_ERR_CODE   := 'ST-CIF101';
      P_ERR_PARAMS := 'fx netting customer';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    DBG('Checking fx netting customer');
    SELECT COUNT(*)
      INTO L_CNT
      FROM (SELECT CUSTOMER_NO
              FROM STTMS_CUSTOMER
             WHERE CUSTOMER_NO = FX_NETTING_CUSTOMER
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A'
            UNION
            SELECT P_CUSTOMER_NO
              FROM DUAL)
     WHERE CUSTOMER_NO = P_FX_NETTING_CUSTOMER_TOCHK;
  
    IF L_CNT = 0 THEN
      P_ERR_CODE   := 'ST-CIF85';
      P_ERR_PARAMS := '- Failed while checking the fx netting customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_fx_netting_customer as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the fx netting customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_FX_NETTING_CUSTOMER;

  FUNCTION FN_UTIL_PROVIDER_VALID(P_CUST_REC IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                  P_ERR      OUT ERTB_MSGS.ERR_CODE%TYPE,
                                  P_PRMS     OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
    L_CNT NUMBER(5);
  
  BEGIN
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER = 'Y' THEN
    
      IF P_CUST_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER_TYPE IS NULL THEN
        DBG('Utility Provider Type should not be Null, since utility provider is checked');
        P_ERR  := 'ST-CIF15';
        P_PRMS := 'Utility Provider Type ';
        OVPKSS.PR_APPENDTBL(P_ERR, P_PRMS);
      END IF;
    
      SELECT NVL(COUNT(CUSTOMER_NO), 0)
        INTO L_CNT
        FROM STTMS_CUSTOMER
       WHERE UTILITY_PROVIDER_ID =
             P_CUST_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER_ID
         AND CUSTOMER_NO <> P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO;
    
      IF L_CNT > 0 OR
         P_CUST_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER_ID IS NULL THEN
        DBG('Utility Provider ID should be unique and not Null, since utility provider is checked');
        P_ERR  := 'ST-CIF14';
        P_PRMS := 'Utility Provider ID ';
        OVPKSS.PR_APPENDTBL(P_ERR, P_PRMS);
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER = 'Y' THEN
      IF P_CUST_REC.V_STTMS_CUSTOMER.CHK_DIGIT_VALID_REQD = 'Y' THEN
        IF P_CUST_REC.V_STTMS_CUSTOMER.ALG_ID IS NULL THEN
          P_ERR  := 'ST-CIF100';
          P_PRMS := 'alg id';
          OVPKSS.PR_APPENDTBL(P_ERR, P_PRMS);
        END IF;
      ELSE
        IF P_CUST_REC.V_STTMS_CUSTOMER.ALG_ID IS NOT NULL THEN
          P_ERR  := 'ST-CIF103';
          P_PRMS := 'alg id';
          OVPKSS.PR_APPENDTBL(P_ERR, P_PRMS);
        END IF;
      END IF;
    ELSE
      IF P_CUST_REC.V_STTMS_CUSTOMER.CHK_DIGIT_VALID_REQD = 'Y' OR
         P_CUST_REC.V_STTMS_CUSTOMER.ALG_ID IS NOT NULL OR
         P_CUST_REC.V_STTMS_CUSTOMER.UTILITY_PROVIDER_ID IS NOT NULL THEN
        P_ERR  := 'ST-CIF102';
        P_PRMS := 'utility provider id';
        OVPKSS.PR_APPENDTBL(P_ERR, P_PRMS);
      END IF;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_util_provider_valid as ' || SQLERRM);
      P_ERR  := 'ST-UPL-001';
      P_PRMS := '- Failed while validating the util provider value~';
      OVPKSS.PR_APPENDTBL(P_ERR, P_PRMS);
      RETURN TRUE;
  END FN_UTIL_PROVIDER_VALID;

  FUNCTION FN_CHK_EMP_TENURE(P_FUNCTION_ID      IN VARCHAR2,
                             P_EMP_TENURE_TOCHK IN VARCHAR2,
                             P_EMP_TENURE_DESC  IN VARCHAR2,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_RESULT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_emp_tenure');
  
    IF NOT FN_NUMERIC_VALID(P_EMP_TENURE_TOCHK, L_RESULT) THEN
      DBG('Error Occurred while validating Employment Tenure');
      IF L_RESULT = 1 THEN
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Employment_tenure ~ Less Than 0 ~';
      ELSE
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Employment_tenure ~ Greater Than 99 ~';
      END IF;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_emp_tenure as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the employment tenure of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_EMP_TENURE;

  FUNCTION FN_CHK_RETIREMENT_AGE(P_FUNCTION_ID          IN VARCHAR2,
                                 P_RETIREMENT_AGE_TOCHK IN VARCHAR2,
                                 P_RETIREMENT_AGE_DESC  IN VARCHAR2,
                                 P_ERR_CODE             IN OUT VARCHAR2,
                                 P_ERR_PARAMS           IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_RESULT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_retirement_age');
    IF NOT FN_NUMERIC_VALID(P_RETIREMENT_AGE_TOCHK, L_RESULT) THEN
      DBG('Error Occurred while validating Retirement Age');
      IF L_RESULT = 1 THEN
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Retirement_age ~ Less Than 0 ~';
      ELSE
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Retirement_age ~ Greater Than 99 ~';
      END IF;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_retirement_age as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the retirement age~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_RETIREMENT_AGE;

  FUNCTION FN_CHK_OTHER_INCOME(P_FUNCTION_ID        IN VARCHAR2,
                               P_OTHER_INCOME_TOCHK IN VARCHAR2,
                               P_OTHER_INCOME_DESC  IN VARCHAR2,
                               P_ERR_CODE           IN OUT VARCHAR2,
                               P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_other_income');
    IF NOT FN_CHKNUMFORZERO(P_OTHER_INCOME_TOCHK, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating Other Income Field');
    
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_other_income as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the other income of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_OTHER_INCOME;

  FUNCTION FN_CHK_RENT(P_FUNCTION_ID IN VARCHAR2,
                       P_RENT_TOCHK  IN VARCHAR2,
                       P_RENT_DESC   IN VARCHAR2,
                       P_ERR_CODE    IN OUT VARCHAR2,
                       P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_rent');
    IF NOT FN_CHKNUMFORZERO(P_RENT_TOCHK, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating Other Income Field');
    
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_rent as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the rent details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_RENT;

  FUNCTION FN_CHK_INSURANCE(P_FUNCTION_ID     IN VARCHAR2,
                            P_INSURANCE_TOCHK IN VARCHAR2,
                            P_INSURANCE_DESC  IN VARCHAR2,
                            P_ERR_CODE        IN OUT VARCHAR2,
                            P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_insurance');
    IF NOT FN_CHKNUMFORZERO(P_INSURANCE_TOCHK, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating insurance');
    
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_insurance as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the insurance details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_INSURANCE;

  FUNCTION FN_CHK_PAYMENT(P_FUNCTION_ID   IN VARCHAR2,
                          P_PAYMENT_TOCHK IN VARCHAR2,
                          P_PAYMENT_DESC  IN VARCHAR2,
                          P_ERR_CODE      IN OUT VARCHAR2,
                          P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_payment');
    IF NOT FN_CHKNUMFORZERO(P_PAYMENT_TOCHK, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating insurance');
    
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_payment as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the payment details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_PAYMENT;

  FUNCTION FN_CHK_OTHER_EXPENSES(P_FUNCTION_ID    IN VARCHAR2,
                                 P_EXPENSES_TOCHK IN VARCHAR2,
                                 P_EXPENSES_DESC  IN VARCHAR2,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_other_expenses');
    IF NOT FN_CHKNUMFORZERO(P_EXPENSES_TOCHK, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating insurance');
    
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_other_expenses as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the other expense details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_OTHER_EXPENSES;

  FUNCTION FN_CHK_HOUSE_VALUE(P_FUNCTION_ID       IN VARCHAR2,
                              P_HOUSE_VALUE_TOCHK IN VARCHAR2,
                              P_HOUSE_VALUE_DESC  IN VARCHAR2,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_house_value');
    IF NOT FN_CHKNUMFORZERO(P_HOUSE_VALUE_TOCHK, P_ERR_CODE, P_ERR_PARAMS) THEN
      DBG('Error Occurred while validating insurance');
    
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_house_value as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the house value details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_HOUSE_VALUE;

  FUNCTION FN_CHK_DEPENDENT_CHILDREN(P_FUNCTION_ID              IN VARCHAR2,
                                     P_DEPENDENT_CHILDREN_TOCHK IN VARCHAR2,
                                     P_DEPENDENT_CHILDREN_DESC  IN VARCHAR2,
                                     P_ERR_CODE                 IN OUT VARCHAR2,
                                     P_ERR_PARAMS               IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_RESULT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_dependent_children');
  
    IF NOT FN_NUMERIC_VALID(P_DEPENDENT_CHILDREN_TOCHK, L_RESULT) THEN
      DBG('Error Occurred while validating dependent_children');
      IF L_RESULT = 1 THEN
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Dependent Children ~ Less Than 0 ~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      ELSE
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Dependent Children ~ Greater Than 99 ~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_dependent_children as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the dependent children details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_DEPENDENT_CHILDREN;

  FUNCTION FN_CHK_DEPENDENT_OTHERS(P_FUNCTION_ID            IN VARCHAR2,
                                   P_DEPENDENT_OTHERS_TOCHK IN VARCHAR2,
                                   P_DEPENDENT_OTHERS_DESC  IN VARCHAR2,
                                   P_ERR_CODE               IN OUT VARCHAR2,
                                   P_ERR_PARAMS             IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_RESULT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_dependent_children');
  
    IF NOT FN_NUMERIC_VALID(P_DEPENDENT_OTHERS_TOCHK, L_RESULT) THEN
      DBG('Error Occurred while validating dependent_others');
      IF L_RESULT = 1 THEN
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Dependent others ~ Less Than 0 ~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      ELSE
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Dependent others ~ Greater Than 99 ~';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_dependent_others as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the dependent others details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_DEPENDENT_OTHERS;

  FUNCTION FN_CHK_NODE_CUST_PERSONAL(P_FUNCTION_ID IN VARCHAR2,
                                     P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                     P_ERR_CODE    IN OUT VARCHAR2,
                                     P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  BEGIN
    DBG('Inside the function fn_chk_node_cust_personal');
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX IS NOT NULL THEN
      IF NOT FN_CHK_PREFIX(P_FUNCTION_ID,
                           P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX,
                           P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        DBG('error in ck_prefix');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_PERSONAL.CUSTOMER_PREFIX';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('error in swift format');
        END IF;
      
      END IF;
      DBG('starts here bhuv');
      BEGIN
        SELECT COUNT(*)
          INTO L_CNT
          FROM STTMS_CUST_PREFIX_DETAILS A, STTMS_CUST_PREFIX_MASTER B
         WHERE A.BRANCH_CODE = P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH
           AND B.RECORD_STAT = 'O'
           AND B.AUTH_STAT = 'A'
           AND A.PREFIX1 IS NOT NULL
           AND A.BRANCH_CODE = B.BRANCH_CODE
           AND A.PREFIX1 = P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CNT := 0;
      END;
    
      IF L_CNT = 0 THEN
        OVPKSS.PR_APPENDTBL('ST-PREF04', '');
      END IF;
      DBG('bhuv over');
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX1 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX1) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_PERSONAL.CUSTOMER_PREFIX1';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('error in swift format');
        END IF;
      
      END IF;
    
      BEGIN
        SELECT COUNT(*)
          INTO L_CNT
          FROM STTMS_CUST_PREFIX_DETAILS A, STTMS_CUST_PREFIX_MASTER B
         WHERE A.BRANCH_CODE = P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH
           AND B.RECORD_STAT = 'O'
           AND B.AUTH_STAT = 'A'
           AND A.PREFIX2 IS NOT NULL
           AND A.BRANCH_CODE = B.BRANCH_CODE
           AND A.PREFIX2 =
               P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX1;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CNT := 0;
      END;
    
      IF L_CNT = 0 THEN
        OVPKSS.PR_APPENDTBL('ST-PREF05', '');
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX2 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX2) <>
         'TRUE' THEN
        P_ERR_CODE := 'ST-TRN05';
      
        P_ERR_PARAMS := '@STTMS_CUST_PERSONAL.CUSTOMER_PREFIX2';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('error in swift format');
        END IF;
      
      END IF;
    
      BEGIN
        SELECT COUNT(*)
          INTO L_CNT
          FROM STTMS_CUST_PREFIX_DETAILS A, STTMS_CUST_PREFIX_MASTER B
         WHERE A.BRANCH_CODE = P_CUST_REC.V_STTMS_CUSTOMER.LOCAL_BRANCH
           AND B.RECORD_STAT = 'O'
           AND B.AUTH_STAT = 'A'
           AND A.PREFIX3 IS NOT NULL
           AND A.BRANCH_CODE = B.BRANCH_CODE
           AND A.PREFIX3 =
               P_CUST_REC.V_STTMS_CUST_PERSONAL.CUSTOMER_PREFIX2;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CNT := 0;
      END;
    
      IF L_CNT = 0 THEN
        OVPKSS.PR_APPENDTBL('ST-PREF06', '');
      END IF;
    
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PERSONAL.LEGAL_GUARDIAN IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_PERSONAL.LEGAL_GUARDIAN) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_PERSONAL.LEGAL_GUARDIAN';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('error in swift format');
        END IF;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.EMPLOYER IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.EMPLOYER) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_PROFESSIONAL.EMPLOYER';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('check err code typr error');
        END IF;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS1 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS1) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_PROFESIONAL.E_ADDRESS1';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('swift error');
        END IF;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS2 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS2) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_PROFESIONAL.E_ADDRESS2';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('swift error');
        END IF;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS3 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_PROFESSIONAL.E_ADDRESS3) <>
         'TRUE' THEN
        P_ERR_CODE := 'ST-TRN05';
      
        P_ERR_PARAMS := '@STTMS_CUST_PROFESSIONAL.E_ADDRESS3';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('swift error');
        END IF;
      END IF;
    END IF;
  
    DBG('fn_chk_node_cust_personal: About to return true');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the personal details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_NODE_CUST_PERSONAL;

  FUNCTION FN_CHK_NODE_CUST_CORP(P_FUNCTION_ID IN VARCHAR2,
                                 P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside the function fn_chk_node_cust_corp');
  
    DBG('for Corporate name');
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.CORPORATE_NAME IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_CORPORATE.CORPORATE_NAME) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_CORPORATE.CORPORATE_NAME';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('swift error');
        END IF;
      END IF;
    END IF;
  
    DBG('for Corp Address 1.');
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS1 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS1) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_CORPORATE.R_ADDRESS1';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('swift error');
        END IF;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS2 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS2) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_CORPORATE.R_ADDRESS2';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('swift error');
        END IF;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS3 IS NOT NULL THEN
      IF FN_CHKSWIFTFORMAT(P_CUST_REC.V_STTMS_CUST_CORPORATE.R_ADDRESS3) <>
         'TRUE' THEN
      
        P_ERR_CODE := 'FT-SW001';
      
        P_ERR_PARAMS := '@STTMS_CUST_CORPORATE.R_ADDRESS3';
      
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
          DBG('error;');
        END IF;
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY IS NOT NULL THEN
      IF NOT FN_CHK_COUNTRY(P_FUNCTION_ID,
                            P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY,
                            'Incorporation Country',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Encountered');
      END IF;
    END IF;
  
    IF P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_DATE IS NOT NULL THEN
      IF NOT FN_CHK_DATE_OF_BIRTH(P_FUNCTION_ID,
                                  P_CUST_REC.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                  'Incorporation Date',
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
        DBG('Encountered');
      
        P_ERR_CODE := 'ST-CIF201';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, '');
      
      END IF;
    END IF;
  
    DBG('value of Customer No here for override is : ' ||
        P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);
    DBG('Before calling cspkss_tradelicense_eod.pr_cust_tradelicovd');
    CSPKSS_TRADELICENSE_EOD.PR_CUST_TRADELICOVD(P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);
    DBG('After calling cspkss_tradelicense_eod.pr_cust_tradelicovd');
  
    DBG('fn_chk_node_cust_corp About to return true');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the corporate details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_NODE_CUST_CORP;

  FUNCTION FN_CHK_CCY(P_FUNCTION_ID IN VARCHAR2,
                      P_CCY_TOCHK   IN VARCHAR2,
                      P_CCY_BRANCH  IN VARCHAR2,
                      P_ERR_CODE    IN OUT VARCHAR2,
                      P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_ccy');
  
    BEGIN
      SELECT 1
        INTO L_CNT
        FROM CYTM_CCY_DEFN
       WHERE AUTH_STAT = 'A'
         AND RECORD_STAT = 'O'
         AND CCY_CODE = P_CCY_TOCHK;
    EXCEPTION
      WHEN OTHERS THEN
        L_CNT := 0;
    END;
    IF L_CNT <> 1 THEN
      P_ERR_CODE   := 'FT-VALS-027';
      P_ERR_PARAMS := P_CCY_BRANCH || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_ccy as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the currency details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_CCY;

  FUNCTION FN_ISSUER_VALIDATE(P_FUNCTION_ID       IN VARCHAR2,
                              P_ISSUER_DETAILS    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_ISSUER_COLL_LIMIT IN STPKS_STDCIF_MAIN.TY_STDCIF,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_CNT NUMBER(3) := 0;
  
  BEGIN
    DBG('Inside the fn_issuer_validate function ');
  
    DBG('p_issuer_details.v_lmtms_issuer_masterissuer_id  ' ||
        P_ISSUER_DETAILS.V_LMTMS_ISSUER_MASTER.ISSUER_ID);
    DBG('p_issuer_details.v_lmtms_issuer_masterISSUER_DETAILS   ' ||
        P_ISSUER_DETAILS.V_LMTMS_ISSUER_MASTER.ISSUER_DETAILS);
    DBG('p_issuer_details.v_lmtms_issuer_masterISSUER_CIF_ID ' ||
        P_ISSUER_DETAILS.V_LMTMS_ISSUER_MASTER.ISSUER_CIF_ID);
    DBG('p_issuer_details.v_lmtms_issuer_masterOVERALL_LIMIT ' ||
        P_ISSUER_DETAILS.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT);
    DBG('p_issuer_details.v_lmtms_issuer_masterOVERALL_LIMIT_CCY ' ||
        P_ISSUER_DETAILS.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY);
  
    IF P_ISSUER_DETAILS.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT < 0 THEN
      DBG('Overall limit should not be lessthen 0  ');
      P_ERR_CODE   := 'CS-MINMAX1';
      P_ERR_PARAMS := ' Issuer Overall limit~0';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    IF P_ISSUER_DETAILS.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY IS NOT NULL THEN
      IF NOT FN_CHK_CCY(P_FUNCTION_ID,
                        P_ISSUER_DETAILS.V_LMTMS_ISSUER_MASTER.OVERALL_LIMIT_CCY,
                        '- Overall Issuer Limit Currency',
                        P_ERR_CODE,
                        P_ERR_PARAMS) THEN
        DBG('Failed in the overall currency check');
      END IF;
    
    END IF;
    IF P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT.COUNT > 0 THEN
      FOR I IN P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT.FIRST .. P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT.LAST LOOP
        DBG('p_issuer_coll_limit.v_lmtms_issuer_limit(i).COLLATERAL_TYPE ' || P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I)
            .COLLATERAL_TYPE);
        DBG('p_issuer_coll_limit.v_lmtms_issuer_limit(i).LIMIT_AMOUNT ' || P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I)
            .LIMIT_AMOUNT);
        DBG('p_issuer_coll_limit.v_lmtms_issuer_limit(i).LIMIT_CURRENCY ' || P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I)
            .LIMIT_CURRENCY);
      
        SELECT COUNT(*)
          INTO L_CNT
        
          FROM GETMS_COLL_TYPES
         WHERE COLLATERAL_TYPE = P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I)
              .COLLATERAL_TYPE;
      
        IF P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I)
         .COLLATERAL_TYPE IS NULL THEN
          P_ERR_PARAMS := NULL;
        ELSE
          P_ERR_PARAMS := '-' || P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I)
                         .COLLATERAL_TYPE || '~';
        END IF;
      
        IF L_CNT <= 0 THEN
          DBG('Invalid collateral type found in record ' || I);
          OVPKSS.PR_APPENDTBL('ST-CIF111', P_ERR_PARAMS);
        END IF;
      
        IF P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT.COUNT > 1 THEN
          FOR J IN I + 1 .. P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT.LAST LOOP
            IF P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I).COLLATERAL_TYPE = P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(J)
               .COLLATERAL_TYPE THEN
              DBG(' Collateral type should be unique ');
              P_ERR_CODE   := 'ST-CIF108';
              P_ERR_PARAMS := ' Collateral type should be unique ';
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);
            END IF;
          END LOOP;
        END IF;
      
        IF P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I).LIMIT_AMOUNT < 0 THEN
          DBG('Overall limit should not be lessthen 0  ');
          P_ERR_CODE   := 'CS-MINMAX1';
          P_ERR_PARAMS := ' Overall limit~0';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      
        IF P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I)
         .LIMIT_CURRENCY IS NOT NULL THEN
          IF NOT FN_CHK_CCY(P_FUNCTION_ID,
                            P_ISSUER_COLL_LIMIT.V_LMTMS_ISSUER_LIMIT(I)
                            .LIMIT_CURRENCY,
                            '- Issuer Limit Currency',
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
            DBG('failed in validating collateral cuurency');
          END IF;
        END IF;
      
      END LOOP;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT of the fn_issuer_validate  ');
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the issuer details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_ISSUER_VALIDATE;

  FUNCTION FN_VALIDATE_REL_LINK(P_FUNCTION_ID  IN VARCHAR2,
                                P_REL_LINK_REC IN STPKS_STDCIF_MAIN.TY_STDCIF,
                                P_CUSTNO       IN STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                                P_ERR_CODE     IN OUT VARCHAR2,
                                P_ERR_PARAMS   IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_CNT      NUMBER := 0;
    L_INC      NUMBER := 1;
    L_CUST_CNT NUMBER := 0;
    L_CHK      NUMBER := 0;
    REF_NO     VARCHAR2(9);
    L_COUNT    NUMBER;
  
  BEGIN
    DBG('Inside the fn_validate_rel_link  ');
  
    L_CNT := P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.COUNT;
    IF L_CNT > 0 THEN
    
      SELECT COUNT(*)
        INTO L_COUNT
        FROM CSTBS_RELATIONSHIP_LINKAGE
       WHERE REF_NO = P_CUSTNO;
    
      IF L_COUNT > 0 THEN
      
        FOR I IN P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.FIRST .. P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.LAST LOOP
        
          IF (P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
             .RELATIONSHIP = 'PRIMARY' AND P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
             .CUSTOMER = P_CUSTNO) THEN
            L_CHK := 1;
          END IF;
        END LOOP;
      
        IF L_CHK <> 1 THEN
          L_CHK := 0;
          DBG('Primary relation cannot be deleted or changed');
          OVPKSS.PR_APPENDTBL('ST-CIF140', '');
        END IF;
      
      END IF;
    
      FOR I IN P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.FIRST .. P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.LAST LOOP
        DBG('p_rel_link_rec.ty_csccurln.v_relationship_linkage(i).customer_no  ' || P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
            .CUSTOMER);
        DBG('p_rel_link_rec.ty_csccurln.v_relationship_linkage(i).RELATIONSHIP ' || P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
            .RELATIONSHIP);
      
        IF P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
         .CUSTOMER IS NULL THEN
          P_ERR_CODE   := 'CS-MINMAX1';
          P_ERR_PARAMS := 'Percentage Holding ~ Less Than 0 ~';
          OVPKSS.PR_APPENDTBL('ST-CIF121', 'Linked Entities - Customer~');
        END IF;
      
        IF L_INC < L_CNT THEN
          FOR J IN I + 1 .. P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE.LAST LOOP
            IF P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
             .CUSTOMER = P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(J)
               .CUSTOMER THEN
              DBG(' customer  should be unique ');
              P_ERR_CODE   := 'ST-CIF124';
              P_ERR_PARAMS := P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
                              .CUSTOMER;
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);
            END IF;
          END LOOP;
        END IF;
      
        L_CUST_CNT := 0;
      
        IF (P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
           .RELATIONSHIP <> 'PRIMARY') THEN
          REF_NO := P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
                    .CUSTOMER;
        END IF;
      
        IF (P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
           .CUSTOMER <> REF_NO AND P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
           .RELATIONSHIP <> 'PRIMARY') THEN
          SELECT COUNT(*)
            INTO L_CHK
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
                .CUSTOMER
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        
          IF L_CHK <= 0 THEN
            OVPKSS.PR_APPENDTBL('ST-CIF122',
                                P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
                                .CUSTOMER || '~');
          END IF;
        END IF;
        IF P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
         .RELATIONSHIP <> 'PRIMARY' THEN
          SELECT COUNT(*)
            INTO L_CHK
            FROM CSTMS_RELATIONSHIP
           WHERE FIELD_NAME <> 'PRIMARY'
             AND FIELD_NAME = P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
                .RELATIONSHIP;
          IF L_CHK <= 0 THEN
            OVPKSS.PR_APPENDTBL('ST-CIF123',
                                P_REL_LINK_REC.TY_CSCCURLN.V_RELATIONSHIP_LINKAGE(I)
                                .RELATIONSHIP || '~');
          END IF;
        END IF;
      
        L_INC := L_INC + 1;
      END LOOP;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT of the fn_validate_rel_link  ');
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the relationship linkage details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_VALIDATE_REL_LINK;

  FUNCTION FN_CHK_BRANCH(P_FUNCTION_ID  IN VARCHAR2,
                         P_BRANCH_TOCHK IN VARCHAR2,
                         P_BRANCH_DESC  IN VARCHAR2,
                         P_ERR_CODE     IN OUT VARCHAR2,
                         P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_branch');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_BRANCH
     WHERE BRANCH_CODE = P_BRANCH_TOCHK
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';
  
    IF L_CNT <= 0 THEN
      DBG('Invalid branch code');
      P_ERR_CODE   := 'IF-UPL-14';
      P_ERR_PARAMS := 'Invalid Branch' || P_BRANCH_TOCHK;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_branch as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the branch~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_BRANCH;

  FUNCTION FN_IS_ERROR(P_ERR IN ERTBS_MSGS.ERR_CODE%TYPE) RETURN BOOLEAN IS
    L_ERR_TYPE VARCHAR2(1);
  
  BEGIN
    SELECT TYPE
      INTO L_ERR_TYPE
      FROM ERTBS_MSGS
     WHERE ERR_CODE = P_ERR
          
       AND LANGUAGE = GLOBAL.LANG;
    IF L_ERR_TYPE = 'E' THEN
      RETURN TRUE;
    ELSIF L_ERR_TYPE = 'O' THEN
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN TRUE;
  END;

  FUNCTION FN_CHK_LOCATION(P_FUNCTION_ID    IN VARCHAR2,
                           P_LOCATION_TOCHK IN VARCHAR2,
                           P_LOCATION_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_location');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_LOCATION
     WHERE LOC_CODE = P_LOCATION_TOCHK
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';
  
    IF L_CNT <= 0 THEN
      DBG('Invalid location');
      P_ERR_CODE   := 'ST-UPLD10';
      P_ERR_PARAMS := '- Location';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_location as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the location of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_LOCATION;

  FUNCTION FN_CHK_COUNTRY(P_FUNCTION_ID   IN VARCHAR2,
                          P_COUNTRY_TOCHK IN VARCHAR2,
                          P_COUNTRY_DESC  IN VARCHAR2,
                          P_ERR_CODE      IN OUT VARCHAR2,
                          P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_country');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_COUNTRY
     WHERE COUNTRY_CODE = P_COUNTRY_TOCHK
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';
  
    IF L_CNT <= 0 THEN
      DBG('Invalid country_code');
    
      P_ERR_CODE := 'ST-UPLD10';
    
      P_ERR_PARAMS := P_COUNTRY_DESC || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_country as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the country of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_COUNTRY;

  FUNCTION FN_CHK_CUST_CATEG(P_FUNCTION_ID      IN VARCHAR2,
                             P_CUST_CATEG_TOCHK IN VARCHAR2,
                             P_CUST_CATEG_DESC  IN VARCHAR2,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_cust_categ');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_CUSTOMER_CAT
     WHERE CUST_CAT = P_CUST_CATEG_TOCHK
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';
  
    IF L_CNT <= 0 THEN
    
      --loan sector sampath changes starts
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTB_CUSTOMER_CAT
       WHERE CUST_CAT = P_CUST_CATEG_TOCHK;
      IF L_CNT <= 0 THEN
        P_ERR_CODE   := 'ST-UPLD31';
        P_ERR_PARAMS := 'customer_category';
        DBG('Invalid customer category');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      
      ELSE
        RETURN TRUE;
      END IF;
      --loan sector sampath changes ends  
    
      P_ERR_CODE   := 'ST-UPLD31';
      P_ERR_PARAMS := 'customer_category';
      DBG('Invalid customer category');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_cust_categ as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the customer category~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_CUST_CATEG;

  FUNCTION FN_CHK_LANGUAGE(P_FUNCTION_ID    IN VARCHAR2,
                           P_LANGUAGE_TOCHK IN VARCHAR2,
                           P_LANGUAGE_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_language');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM SMTBS_LANGUAGE
     WHERE LANG_CODE = P_LANGUAGE_TOCHK;
  
    IF L_CNT <= 0 THEN
      P_ERR_CODE   := 'ST-UPLD32';
      P_ERR_PARAMS := 'language';
      DBG('Invalid language');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_language as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the rent details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_LANGUAGE;

  FUNCTION FN_CHK_CUST_GRP(P_FUNCTION_ID    IN VARCHAR2,
                           P_CUST_GRP_TOCHK IN VARCHAR2,
                           P_CUST_NO        IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
    DBG('Entered the function fn_chk_cust_grp');
    SELECT COUNT(*)
      INTO L_CNT
      FROM CSTMS_AML_CUSTOMER_GRP_MASTER
     WHERE CUSTOMER_GRP = P_CUST_GRP_TOCHK
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';
  
    IF L_CNT <= 0 AND P_CUST_GRP_TOCHK <> P_CUST_NO THEN
      P_ERR_CODE   := 'ST-UPLD37';
      P_ERR_PARAMS := 'AML_GROUP';
      DBG('Invalid AML GROUP');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    DBG('About to RETURN TRUE');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_cust_grp as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- failed while checking the customer group~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_CUST_GRP;

  FUNCTION FN_CHK_GROUP_CODE(P_FUNCTION_ID      IN VARCHAR2,
                             P_GROUP_CODE_TOCHK IN VARCHAR2,
                             P_CUST_TYPE        IN VARCHAR2
                             
                            ,
                             P_ERR_CODE   IN OUT VARCHAR2,
                             P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_CNT      NUMBER := 0;
    L_GRP_TYPE STTMS_GROUP_CODE.GROUP_TYPE%TYPE;
  
  BEGIN
  
    DBG('Inside function fn_chk_group_code');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_GROUP_CODE
     WHERE GROUP_CODE = P_GROUP_CODE_TOCHK
       AND GROUP_TYPE = DECODE(P_CUST_TYPE, 'B', 'C', P_CUST_TYPE)
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';
  
    SELECT GROUP_TYPE
      INTO L_GRP_TYPE
      FROM STTMS_GROUP_CODE
     WHERE GROUP_CODE = P_GROUP_CODE_TOCHK
       AND GROUP_TYPE = DECODE(P_CUST_TYPE, 'B', 'C', P_CUST_TYPE)
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';
  
    IF L_CNT <= 0 THEN
      P_ERR_CODE   := 'ST-UPLD39';
      P_ERR_PARAMS := 'Group_Code';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      DBG('Invalid Group Code');
    
    END IF;
  
    IF ((L_GRP_TYPE <> 'I' AND P_CUST_TYPE = 'I') OR
       (L_GRP_TYPE = 'I' AND P_CUST_TYPE <> 'I')) THEN
      P_ERR_CODE   := 'ST-UPLD42';
      P_ERR_PARAMS := 'Group_Code';
      DBG('Invalid Group Code');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
  
    WHEN NO_DATA_FOUND THEN
      DBG('Failed in NO_DATA_FOUND of fn_chk_group_code as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPLD39';
      P_ERR_PARAMS := 'Group_Code';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
    
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_group_code as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the group code of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_GROUP_CODE;

  FUNCTION FN_CHK_EXP_CATEG(P_FUNCTION_ID     IN VARCHAR2,
                            P_EXP_CATEG_TOCHK IN VARCHAR2,
                            P_EXP_CATEG_DESC  IN VARCHAR2,
                            P_ERR_CODE        IN OUT VARCHAR2,
                            P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
    DBG('Entered the function fn_chk_exp_categ');
  
    IF P_EXP_CATEG_TOCHK IS NOT NULL THEN
    
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_EXPOSURE_CATEGORY
       WHERE EXPOSURE_CATEGORY = P_EXP_CATEG_TOCHK
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
    
      IF L_CNT <= 0 THEN
        P_ERR_CODE   := 'ST-UPLD40';
        P_ERR_PARAMS := 'Exposure_Category';
        DBG('Invalid Exposure Category');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
    END IF;
  
    DBG('About to return true');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the exp category of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_EXP_CATEG;

  FUNCTION FN_CHK_CUST_CLASSIFICATION(P_FUNCTION_ID               IN VARCHAR2,
                                      P_CUST_CLASSIFICATION_TOCHK IN VARCHAR2,
                                      P_CUST_CLASSIFICATION_DESC  IN VARCHAR2,
                                      P_ERR_CODE                  IN OUT VARCHAR2,
                                      P_ERR_PARAMS                IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_CNT NUMBER;
  
  BEGIN
  
    DBG('Inside function fn_chk_cust_classification');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_CUST_CLASSIFICATION
     WHERE CUST_CLASSIFICATION = P_CUST_CLASSIFICATION_TOCHK
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';
  
    IF L_CNT <= 0 THEN
      P_ERR_CODE   := 'ST-UPLD41';
      P_ERR_PARAMS := 'Cust_Classification';
      DBG('Invalid Cust Classification');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_cust_classification as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the customer classification~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_CUST_CLASSIFICATION;

  FUNCTION FN_CHK_AC_OR_PLAN_NO(P_FUNCTION_ID   IN VARCHAR2,
                                P_CUST_NO       IN VARCHAR2,
                                P_AC_OR_PLAN_NO IN VARCHAR2,
                                P_ERR_CODE      IN OUT VARCHAR2,
                                P_ERR_PARAMS    IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_ac_or_plan_no');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_CUST_ACCOUNT
     WHERE CUST_NO = P_CUST_NO
       AND CUST_AC_NO = P_AC_OR_PLAN_NO
       AND RECORD_STAT = 'O'
       AND ONCE_AUTH = 'Y'
       AND AC_STAT_DE_POST = 'Y';
  
    DBG('the ira a/c no is :' || P_AC_OR_PLAN_NO);
  
    IF L_CNT <= 0 THEN
      P_ERR_CODE   := 'ST-CIF114';
      P_ERR_PARAMS := '';
      DBG('Invalid Account no for IRA maintanence');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_ac_or_plan_no as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the ac or plan no flag ~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_AC_OR_PLAN_NO;

  FUNCTION FN_CHK_ADDRESS(P_FUNCTION_ID   IN VARCHAR2,
                          P_ADDRESS_TOCHK IN VARCHAR2,
                          P_ADDRESS_DESC  IN VARCHAR2,
                          P_ERR_CODE      IN OUT VARCHAR2,
                          P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_address ');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_ADDRESS_TOCHK,
                            P_ADDRESS_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_address as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the address details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_ADDRESS;

  FUNCTION FN_CHK_NAME(P_FUNCTION_ID IN VARCHAR2,
                       P_NAME_TOCHK  IN VARCHAR2,
                       P_NAME_DESC   IN VARCHAR2,
                       P_ERR_CODE    IN OUT VARCHAR2,
                       P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_name');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_NAME_TOCHK,
                            P_NAME_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_name as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the name details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_NAME;

  FUNCTION FN_CHK_HO_AC_NO(P_FUNCTION_ID    IN VARCHAR2,
                           P_HO_AC_NO_TOCHK IN VARCHAR2,
                           P_HO_AC_NO_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_ho_ac_no');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_HO_AC_NO_TOCHK,
                            P_HO_AC_NO_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_ho_ac_no as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the HO AC no details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_HO_AC_NO;

  FUNCTION FN_CHK_LIAB_NODE(P_FUNCTION_ID     IN VARCHAR2,
                            P_LIAB_NODE_TOCHK IN VARCHAR2,
                            P_LIAB_NODE_DESC  IN VARCHAR2,
                            P_ERR_CODE        IN OUT VARCHAR2,
                            P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_liab_node');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_LIAB_NODE_TOCHK,
                            P_LIAB_NODE_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_liab_node as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the liability details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_LIAB_NODE;

  FUNCTION FN_CHK_TELEPHONE_NO(P_FUNCTION_ID        IN VARCHAR2,
                               P_TELEPHONE_NO_TOCHK IN VARCHAR2,
                               P_TELEPHONE_NO_DESC  IN VARCHAR2,
                               P_ERR_CODE           IN OUT VARCHAR2,
                               P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_telephone_no');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_TELEPHONE_NO_TOCHK,
                            P_TELEPHONE_NO_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_telephone_no as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the telephone details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_TELEPHONE_NO;

  FUNCTION FN_CHK_NATIONAL_ID(P_FUNCTION_ID       IN VARCHAR2,
                              P_NATIONAL_ID_TOCHK IN VARCHAR2,
                              P_NATIONAL_ID_DESC  IN VARCHAR2,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_national_id');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_NATIONAL_ID_TOCHK,
                            P_NATIONAL_ID_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_national_id as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the national id of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_NATIONAL_ID;

  FUNCTION FN_CHK_MAXLENGTH(P_FUNCTION_ID IN VARCHAR2,
                            P_STR_TOCHK   IN VARCHAR2,
                            P_ERRORDESC   IN VARCHAR2,
                            P_ERR_CODE    IN OUT VARCHAR2,
                            P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_maxlength for the value --> ' ||
        P_STR_TOCHK);
  
    IF LENGTH(P_STR_TOCHK) > 105 THEN
      DBG('Length Exceeded 35 Characters');
    
      P_ERR_CODE := 'IF-UPL-24';
    
      P_ERR_PARAMS := P_ERRORDESC || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    
    END IF;
    RETURN TRUE;
  END FN_CHK_MAXLENGTH;

  FUNCTION FN_CHK_FAX(P_FUNCTION_ID IN VARCHAR2,
                      P_FAX_TOCHK   IN VARCHAR2,
                      P_FAX_DESC    IN VARCHAR2,
                      P_ERR_CODE    IN OUT VARCHAR2,
                      P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_fax');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_FAX_TOCHK,
                            P_FAX_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_fax as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the fax no of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_FAX;

  FUNCTION FN_CHK_DESIGNATION(P_FUNCTION_ID       IN VARCHAR2,
                              P_DESIGNATION_TOCHK IN VARCHAR2,
                              P_DESIGNATION_DESC  IN VARCHAR2,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_PARAMS        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_designation');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_DESIGNATION_TOCHK,
                            P_DESIGNATION_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_designation as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the designation details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_DESIGNATION;

  FUNCTION FN_CHK_EMPLOYER(P_FUNCTION_ID    IN VARCHAR2,
                           P_EMPLOYER_TOCHK IN VARCHAR2,
                           P_EMPLOYER_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_employer');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_EMPLOYER_TOCHK,
                            P_EMPLOYER_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_employer as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the employer details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_EMPLOYER;

  FUNCTION FN_CHK_TELEX(P_FUNCTION_ID IN VARCHAR2,
                        P_TELEX_TOCHK IN VARCHAR2,
                        P_TELEX_DESC  IN VARCHAR2,
                        P_ERR_CODE    IN OUT VARCHAR2,
                        P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_telex');
  
    IF NOT FN_CHK_MAXLENGTH(P_FUNCTION_ID,
                            P_TELEX_TOCHK,
                            P_TELEX_DESC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Encountered');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_telex as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the telex details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_TELEX;

  FUNCTION FN_CHK_PREFIX(P_FUNCTION_ID  IN VARCHAR2,
                         P_PREFIX_TOCHK IN VARCHAR2,
                         P_LOCAL_BRANCH IN VARCHAR2,
                         P_ERR_CODE     IN OUT VARCHAR2,
                         P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_prefix');
  
    IF FN_CHKSWIFTFORMAT(P_PREFIX_TOCHK) <> 'TRUE' THEN
    
      P_ERR_CODE   := 'FT-SW001';
      P_ERR_PARAMS := '';
      IF FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE) = 'E' THEN
        DBG('error');
      END IF;
    END IF;
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_CUST_PREFIX_DETAILS
     WHERE PREFIX1 = P_PREFIX_TOCHK
       AND BRANCH_CODE = P_LOCAL_BRANCH;
  
    IF L_CNT = 0 THEN
      P_ERR_CODE   := 'ST-PREF04';
      P_ERR_PARAMS := 'customer prefix';
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_prefix as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the prefix of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_PREFIX;

  FUNCTION FN_CHK_EMPLOYMENT_TENURE(P_FUNCTION_ID             IN VARCHAR2,
                                    P_EMPLOYMENT_TENURE_TOCHK IN VARCHAR2,
                                    P_EMPLOYMENT_TENURE_DESC  IN VARCHAR2,
                                    P_ERR_CODE                IN OUT VARCHAR2,
                                    P_ERR_PARAMS              IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_RESULT NUMBER;
  BEGIN
  
    DBG('Inside function fn_chk_employment_tenure');
  
    IF NOT FN_NUMERIC_VALID(P_EMPLOYMENT_TENURE_TOCHK, L_RESULT) THEN
      DBG('Error Occurred while validating Employment Tenure');
      IF L_RESULT = 1 THEN
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Employment_tenure ~ Less Than 0 ~';
      ELSE
        P_ERR_CODE   := 'CS-MINMAX1';
        P_ERR_PARAMS := 'Employment_tenure ~ Greater Than 99 ~';
      END IF;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_employment_tenure as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the employment tenure of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_EMPLOYMENT_TENURE;

  FUNCTION FN_CHK_RESIDENT_STATUS(P_FUNCTION_ID           IN VARCHAR2,
                                  P_RESIDENT_STATUS_TOCHK IN VARCHAR2,
                                  P_RESIDENT_STATUS_DESC  IN VARCHAR2,
                                  P_ERR_CODE              IN OUT VARCHAR2,
                                  P_ERR_PARAMS            IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_resident_status');
  
    IF P_RESIDENT_STATUS_TOCHK IS NOT NULL AND
       P_RESIDENT_STATUS_TOCHK NOT IN ('R', 'N') THEN
      DBG('Value for resident_status has to be either R or N');
      P_ERR_CODE   := 'IF-UPL-37';
      P_ERR_PARAMS := '~' || P_RESIDENT_STATUS_TOCHK || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_resident_status as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the resident status of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_RESIDENT_STATUS;

  FUNCTION FN_CHK_DATE_OF_BIRTH(P_FUNCTION_ID IN VARCHAR2,
                                P_DOB_TOCHK   IN DATE,
                                P_DOB_DESC    IN VARCHAR2,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
    DBG('Checking for the Date of Birth for the Joint Customer');
    DBG('Date of Birth Coming ' || P_DOB_TOCHK);
  
    IF P_DOB_TOCHK >= GLOBAL.APPLICATION_DATE THEN
    
      RETURN FALSE;
    
    END IF;
  
    DBG('Successfully returns from the Function fn_chk_date_of_birth');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the record no~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_DATE_OF_BIRTH;

  FUNCTION FN_CHK_RECORD_NO(P_FUNCTION_ID     IN VARCHAR2,
                            P_RECORD_NO_TOCHK IN VARCHAR2,
                            P_RECORD_NO_DESC  IN VARCHAR2,
                            P_ERR_CODE        IN OUT VARCHAR2,
                            P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_record_no');
  
    IF P_RECORD_NO_TOCHK IS NULL THEN
      DBG('Record_no cannot be NULL');
      P_ERR_CODE   := 'IF-UPL-34';
      P_ERR_PARAMS := '~' || P_RECORD_NO_TOCHK || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_record_no as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the record no~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_RECORD_NO;

  FUNCTION FN_CHK_SEX(P_FUNCTION_ID IN VARCHAR2,
                      P_SEX_TOCHK   IN VARCHAR2,
                      P_SEX_DESC    IN VARCHAR2,
                      P_ERR_CODE    IN OUT VARCHAR2,
                      P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_sex');
    IF P_SEX_TOCHK IS NOT NULL AND P_SEX_TOCHK NOT IN ('M', 'F', 'O', 'P') THEN
    
      DBG('Value for sex has to be either M or F');
      P_ERR_CODE   := 'IF-UPL-35';
      P_ERR_PARAMS := '~' || P_SEX_TOCHK || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_sex as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the sex ~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_SEX;

  FUNCTION FN_CHK_DECEASED(P_FUNCTION_ID    IN VARCHAR2,
                           P_DECEASED_TOCHK IN VARCHAR2,
                           P_DECEASED_DESC  IN VARCHAR2,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('Inside function fn_chk_deceased');
  
    IF P_DECEASED_TOCHK IS NOT NULL AND P_DECEASED_TOCHK NOT IN ('D', 'N') THEN
      DBG('Value for deceased has to be either D or N');
      P_ERR_CODE   := 'IF-UPL-36';
      P_ERR_PARAMS := '~' || P_DECEASED_TOCHK || '~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_chk_deceased as ' || SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the deceased details of the customer~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHK_DECEASED;

  FUNCTION FN_SSN_FORMAT_VALIDATION(P_SSN IN VARCHAR2) RETURN BOOLEAN IS
  
    L_SSN_MASK  STTM_CUSTOMER.SSN%TYPE;
    L_VALID_SSN BOOLEAN := TRUE;
  BEGIN
  
    BEGIN
    
      L_SSN_MASK := CSPKSS_OS_PARAM.GET_PARAM_VAL('SSN_MASK_FORMAT');
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_SSN_MASK := 'nnn-nn-nnnn';
        DBG('Taking default SSN mask ' || L_SSN_MASK);
    END;
    DBG('Got the SSN mask as ' || L_SSN_MASK);
    DBG('SSN value enterd = ' || P_SSN);
    IF LENGTH(P_SSN) <> LENGTH(L_SSN_MASK) THEN
      DBG('length(l_ssn_mask)' || LENGTH(L_SSN_MASK));
      L_VALID_SSN := FALSE;
    END IF;
  
    IF L_VALID_SSN THEN
      FOR C1 IN 1 .. LENGTH(L_SSN_MASK) LOOP
        IF (LOWER(SUBSTR(L_SSN_MASK, C1, 1)) = 'a') THEN
          IF (LENGTH(TRIM(TRANSLATE(SUBSTR(P_SSN, C1, 1),
                                    'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
                                    ' '))) != 0) THEN
            L_VALID_SSN := FALSE;
            EXIT;
          END IF;
        ELSIF (LOWER(SUBSTR(L_SSN_MASK, C1, 1)) = 'n') THEN
          IF (LENGTH(TRIM(TRANSLATE(SUBSTR(P_SSN, C1, 1), '0123456789', ' '))) != 0) THEN
            L_VALID_SSN := FALSE;
            EXIT;
          END IF;
        ELSIF (SUBSTR(L_SSN_MASK, C1, 1) = '-') THEN
          IF (SUBSTR(P_SSN, C1, 1) != '-') THEN
            L_VALID_SSN := FALSE;
            EXIT;
          END IF;
        ELSE
          DBG('Symbols other than hyphen cannot be used');
          L_VALID_SSN := FALSE;
          EXIT;
        END IF;
      END LOOP;
    END IF;
  
    IF NOT L_VALID_SSN THEN
      OVPKS.PR_APPENDTBL('ST-SSN001', L_SSN_MASK);
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  END FN_SSN_FORMAT_VALIDATION;

  FUNCTION FN_CHKNUMFORZERO(P_VAR_NUM IN NUMBER,
                            P_ERRS    OUT ERTB_MSGS.ERR_CODE%TYPE,
                            P_PRMS    IN OUT ERTB_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
  
    IF P_VAR_NUM IS NULL THEN
      RETURN TRUE;
    END IF;
  
    IF P_VAR_NUM < 0 THEN
      P_ERRS := 'CS-MINMAX1';
      P_PRMS := P_PRMS || '~ Less Than 0 ~';
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  
  END FN_CHKNUMFORZERO;

  FUNCTION FN_NUMERIC_VALID(P_VAR_NUM IN NUMBER, P_RESULT OUT NUMBER)
    RETURN BOOLEAN IS
  
  BEGIN
    IF P_VAR_NUM IS NULL THEN
      P_RESULT := 0;
      RETURN TRUE;
    END IF;
    IF P_VAR_NUM < 0 THEN
      P_RESULT := 1;
      RETURN FALSE;
    END IF;
  
    IF P_VAR_NUM > 99 THEN
      P_RESULT := 2;
      RETURN FALSE;
    END IF;
  
    P_RESULT := 0;
    RETURN TRUE;
  
  END FN_NUMERIC_VALID;

  FUNCTION FN_CHECK_XREF(P_FUNCTION_ID IN VARCHAR2,
                         P_EXT_REF_NO  IN VARCHAR2,
                         P_CUSTOMER_NO IN VARCHAR2,
                         P_ERR_CODE    IN OUT VARCHAR2,
                         P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_COUNT NUMBER;
  BEGIN
  
    DBG('Entered the function fn_check_xref');
  
    SELECT COUNT(*)
      INTO L_COUNT
      FROM STTMS_CUSTOMER
     WHERE EXT_REF_NO = P_EXT_REF_NO
       AND CUSTOMER_NO <> P_CUSTOMER_NO;
  
    IF L_COUNT > 0 THEN
      DBG('The EXTERNAL REF NO is NOT unique..............');
      P_ERR_CODE   := 'ST-REF01';
      P_ERR_PARAMS := '';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    DBG('fn_check_xref:  About to RETURN TRUE');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Faled in WOT of fn_check_xref and the oracle error is ' ||
          SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while checking the xref value~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHECK_XREF;

  FUNCTION FN_CHECK_ERR_CODE_TYPE(P_ERR_CODE IN VARCHAR2) RETURN VARCHAR2 IS
    L_TYPE ERTBS_MSGS.TYPE%TYPE;
  BEGIN
  
    DBG('Entered the function fn_check_err_code_type');
  
    BEGIN
      SELECT TYPE
        INTO L_TYPE
        FROM ERTBS_MSGS
       WHERE ERR_CODE = P_ERR_CODE
            
         AND LANGUAGE = GLOBAL.LANG;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Inside NO DATA FOUND for the error code ' || P_ERR_CODE);
        L_TYPE := 'E';
    END;
  
    RETURN(L_TYPE);
  
  END FN_CHECK_ERR_CODE_TYPE;

  FUNCTION FN_CHECK_UID(P_FUNCTION_ID IN VARCHAR2,
                        P_CUST_REC    IN STPKS_STDCIF_MAIN.TY_STDCIF,
                        P_ERR_CODE    IN OUT VARCHAR2,
                        P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT     NUMBER;
    L_CUST_NO STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
  BEGIN
    DBG('Inside the function fn_check_uid');
    DBG('p_cust_rec.v_sttms_customer.unique_id_name:' ||
        P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_NAME);
    DBG('p_cust_rec.v_sttms_customer.unique_id_value:' ||
        P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE);
  
    SELECT NVL(COUNT(CUSTOMER_NO), 0)
      INTO L_CNT
      FROM STTMS_CUSTOMER
     WHERE UNIQUE_ID_NAME = P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_NAME
       AND UNIQUE_ID_VALUE = P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE
       AND (CUSTOMER_NO <> P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO);
    DBG('l_Cnt is  ' || L_CNT);
    IF L_CNT > 0 THEN
    
      DBG('Going to get cust no for unique id and value');
      SELECT CUSTOMER_NO
        INTO L_CUST_NO
        FROM STTMS_CUSTOMER
       WHERE UNIQUE_ID_NAME = P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_NAME
         AND UNIQUE_ID_VALUE = P_CUST_REC.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE
         AND (CUSTOMER_NO <> P_CUST_REC.V_STTMS_CUSTOMER.CUSTOMER_NO)
         AND ROWNUM < 2;
    
      DBG('Customer Unique Identifier Value and Name Combination does not make it unique.This Combination is already being used for the Customer Number' ||
          L_CUST_NO);
      P_ERR_CODE := 'ST-CIF24';
    
      P_ERR_PARAMS := L_CUST_NO;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    DBG('fn_check_uid: About to RETURN TRUE');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_check_uid and the oracle error is ' ||
          SQLERRM);
      P_ERR_CODE   := 'ST-UPL-001';
      P_ERR_PARAMS := '- Failed while chking the UID name and UID value for uniqueness ~';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      RETURN TRUE;
  END FN_CHECK_UID;

  FUNCTION FN_CHK_DEBTOR_CAT(P_DEBTOR_CAT IN VARCHAR2) RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  BEGIN
  
    DBG(' checking debtor cat now');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM (SELECT DEBTOR_CATEGORY
              FROM PCTM_DEBTOR_CATEGORY_DEFN
             WHERE AUTH_STAT = 'A'
               AND RECORD_STAT = 'O')
     WHERE DEBTOR_CATEGORY = P_DEBTOR_CAT;
  
    IF L_CNT = 0 THEN
      OVPKSS.PR_APPENDTBL('ST-CIF86', '');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_check_uid and the oracle error is ' ||
          SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-CIF86', '');
      RETURN TRUE;
  END FN_CHK_DEBTOR_CAT;

  FUNCTION FN_CHK_MEDIA(P_MEDIA IN VARCHAR2) RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  
  BEGIN
  
    DBG('checking the media now');
    SELECT COUNT(*)
      INTO L_CNT
      FROM (SELECT MEDIA
              FROM MSTM_MEDIA
             WHERE AUTH_STAT = 'A'
               AND RECORD_STAT = 'O')
     WHERE MEDIA = P_MEDIA;
  
    IF L_CNT = 0 THEN
      OVPKSS.PR_APPENDTBL('ST-CIF87', '');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
  
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_check_uid and the oracle error is ' ||
          SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-CIF87', '');
      RETURN TRUE;
  END FN_CHK_MEDIA;

  FUNCTION FN_CHK_RISK_PRFL(P_RISK_PROFILE IN VARCHAR2) RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  
  BEGIN
  
    DBG('checking the risk profile now');
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM (SELECT DISTINCT RISK_PROFILE
              FROM SETMS_RISK_PROFILE_MAST
             WHERE AUTH_STAT = 'A'
               AND RECORD_STAT = 'O')
     WHERE RISK_PROFILE = P_RISK_PROFILE;
  
    IF L_CNT = 0 THEN
      OVPKSS.PR_APPENDTBL('ST-CIF88', '');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_check_uid and the oracle error is ' ||
          SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-CIF88', '');
      RETURN TRUE;
  END FN_CHK_RISK_PRFL;

  FUNCTION FN_CHK_CLG_GRP(P_CLG_GRP IN VARCHAR2) RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  
  BEGIN
  
    BEGIN
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_GROUP_CODE
       WHERE GROUP_TYPE = 'L'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND GROUP_CODE = P_CLG_GRP;
    EXCEPTION
      WHEN OTHERS THEN
        L_CNT := 0;
    END;
  
    IF L_CNT <= 0 THEN
      OVPKSS.PR_APPENDTBL('ST-CIF104', '');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_check_uid and the oracle error is ' ||
          SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-CIF104', '');
      RETURN TRUE;
  END FN_CHK_CLG_GRP;

  FUNCTION FN_CHK_TAX_GRP(P_TAX_GRP IN VARCHAR2) RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  
  BEGIN
  
    BEGIN
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_GROUP_CODE
       WHERE GROUP_TYPE = 'T'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND GROUP_CODE = P_TAX_GRP;
    EXCEPTION
      WHEN OTHERS THEN
        L_CNT := 0;
    END;
  
    IF L_CNT <= 0 THEN
      OVPKSS.PR_APPENDTBL('ST-CIF105', '');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_check_uid and the oracle error is ' ||
          SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-CIF105', '');
      RETURN TRUE;
  END FN_CHK_TAX_GRP;

  FUNCTION FN_CHK_CHG_GRP(P_CHG_GRP IN VARCHAR2) RETURN BOOLEAN IS
  
    L_CNT NUMBER;
  
  BEGIN
  
    BEGIN
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_GROUP_CODE
       WHERE GROUP_TYPE = 'F'
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND GROUP_CODE = P_CHG_GRP;
    EXCEPTION
      WHEN OTHERS THEN
        L_CNT := 0;
    END;
  
    IF L_CNT <= 0 THEN
      OVPKSS.PR_APPENDTBL('ST-CIF106', '');
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOT of fn_check_uid and the oracle error is ' ||
          SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-CIF106', '');
      RETURN TRUE;
  END FN_CHK_CHG_GRP;

  FUNCTION FN_MASK_QUERY(P_WRK_STDCIF IN OUT STPKS_STDCIF_MAIN.TY_STDCIF,
                         P_ERR_CODE   IN OUT VARCHAR2,
                         P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    CURSOR C_V_STVW_STTM_CUSTOMER IS
      SELECT *
        FROM STVW_STTM_CUSTOMER
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STVW_STTM_CUSTOMER__A IS
      SELECT *
        FROM STVW_STTM_CUSTOMER
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STVW_STTM_CORP_DIRECTORS IS
      SELECT *
        FROM STVW_STTM_CORP_DIRECTORS
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STVW_STTM_CUST_CORPORATE IS
      SELECT *
        FROM STVW_STTM_CUST_CORPORATE
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STVW_STTM_CUST_DOMESTIC IS
      SELECT *
        FROM STVW_STTM_CUST_DOMESTIC
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STVW_STTM_CUST_PERSONAL IS
      SELECT *
        FROM STVW_STTM_CUST_PERSONAL
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STVW_STTM_CUST_PERSONAL__A IS
      SELECT *
        FROM STVW_STTM_CUST_PERSONAL
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STTM_CUST_PROFESSIONAL IS
      SELECT *
        FROM STVW_STTM_CUST_PROFESSIONAL
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STTM_CUST_PERSONAL_JOINT IS
      SELECT *
        FROM STVW_STTM_CUST_PERSONAL_JOINT
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;
  
    CURSOR C_V_STVW_DEBIT_CARD_MASTER__A IS
      SELECT *
        FROM STVW_STTM_DEBIT_CARD_MASTER
       WHERE BRANCH_CODE = P_WRK_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH
         AND CUST_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
         AND CUST_AC_NO = CUST_AC_NO;
  
  BEGIN
    DBG('Inside stpks_stdcif_utils_1.Fn_Mask_Query..');
  
    DBG('Masking for Customer..');
    OPEN C_V_STVW_STTM_CUSTOMER;
    LOOP
      FETCH C_V_STVW_STTM_CUSTOMER
        INTO P_WRK_STDCIF.V_STTMS_CUSTOMER;
      EXIT WHEN C_V_STVW_STTM_CUSTOMER%NOTFOUND;
    END LOOP;
    CLOSE C_V_STVW_STTM_CUSTOMER;
    DBG('Masking for Customer directors..');
    OPEN C_V_STVW_STTM_CORP_DIRECTORS;
    LOOP
      FETCH C_V_STVW_STTM_CORP_DIRECTORS BULK COLLECT
        INTO P_WRK_STDCIF.V_STTMS_CORP_DIRECTORS;
      EXIT WHEN C_V_STVW_STTM_CORP_DIRECTORS%NOTFOUND;
    END LOOP;
    CLOSE C_V_STVW_STTM_CORP_DIRECTORS;
  
    DBG('Masking for Customer corporate..');
    OPEN C_V_STVW_STTM_CUST_CORPORATE;
    LOOP
      FETCH C_V_STVW_STTM_CUST_CORPORATE
        INTO P_WRK_STDCIF.V_STTMS_CUST_CORPORATE;
      EXIT WHEN C_V_STVW_STTM_CUST_CORPORATE%NOTFOUND;
    END LOOP;
    CLOSE C_V_STVW_STTM_CUST_CORPORATE;
  
    DBG('Masking for Customer domestic..');
    OPEN C_V_STVW_STTM_CUST_DOMESTIC;
    LOOP
      FETCH C_V_STVW_STTM_CUST_DOMESTIC
        INTO P_WRK_STDCIF.V_STTMS_CUST_DOMESTIC;
      EXIT WHEN C_V_STVW_STTM_CUST_DOMESTIC%NOTFOUND;
    END LOOP;
    CLOSE C_V_STVW_STTM_CUST_DOMESTIC;
  
    DBG('Masking for Customer personal..');
    OPEN C_V_STVW_STTM_CUST_PERSONAL;
    LOOP
      FETCH C_V_STVW_STTM_CUST_PERSONAL
        INTO P_WRK_STDCIF.V_STTMS_CUST_PERSONAL;
      EXIT WHEN C_V_STVW_STTM_CUST_PERSONAL%NOTFOUND;
    END LOOP;
    CLOSE C_V_STVW_STTM_CUST_PERSONAL;
  
    DBG('Masking for Customer professional..');
    OPEN C_V_STTM_CUST_PROFESSIONAL;
    LOOP
      FETCH C_V_STTM_CUST_PROFESSIONAL
        INTO P_WRK_STDCIF.V_STTMS_CUST_PROFESSIONAL;
      EXIT WHEN C_V_STTM_CUST_PROFESSIONAL%NOTFOUND;
    END LOOP;
    CLOSE C_V_STTM_CUST_PROFESSIONAL;
  
    DBG('Masking for personal joint information..');
    OPEN C_V_STTM_CUST_PERSONAL_JOINT;
    LOOP
      FETCH C_V_STTM_CUST_PERSONAL_JOINT BULK COLLECT
        INTO P_WRK_STDCIF.TY_STCCIFJ.V_STTMS_CUST_PERSONAL_JOINT;
      EXIT WHEN C_V_STTM_CUST_PERSONAL_JOINT%NOTFOUND;
    END LOOP;
    CLOSE C_V_STTM_CUST_PERSONAL_JOINT;
  
    DBG('Masking for Debit Cards');
    OPEN C_V_STVW_DEBIT_CARD_MASTER__A;
    LOOP
      FETCH C_V_STVW_DEBIT_CARD_MASTER__A BULK COLLECT
        INTO P_WRK_STDCIF.TY_STCCRDSA.V_DEBIT_CARD_MASTER__A;
      EXIT WHEN C_V_STVW_DEBIT_CARD_MASTER__A%NOTFOUND;
    END LOOP;
    CLOSE C_V_STVW_DEBIT_CARD_MASTER__A;
  
    DBG('Masking for Correspondence Address..');
    OPEN C_V_STVW_STTM_CUSTOMER__A;
    LOOP
      FETCH C_V_STVW_STTM_CUSTOMER__A
        INTO P_WRK_STDCIF.V_STTMS_CUSTOMER__A;
      EXIT WHEN C_V_STVW_STTM_CUSTOMER__A%NOTFOUND;
    END LOOP;
    CLOSE C_V_STVW_STTM_CUSTOMER__A;
  
    DBG('Masking for Correspondence telephone details..');
    OPEN C_V_STVW_STTM_CUST_PERSONAL__A;
    LOOP
      FETCH C_V_STVW_STTM_CUST_PERSONAL__A
        INTO P_WRK_STDCIF.V_STTMS_CUST_PERSONAL__A;
      EXIT WHEN C_V_STVW_STTM_CUST_PERSONAL__A%NOTFOUND;
    END LOOP;
    CLOSE C_V_STVW_STTM_CUST_PERSONAL__A;
  
    DBG('Returning successfully from stpks_stdcif_utils_1.Fn_Mask_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of Stpks_Stdcif_Utils_1.Fn_Mask_Query..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_MASK_QUERY;

END STPKS_STDCIF_UTILS_1;
