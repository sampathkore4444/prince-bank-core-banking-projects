insert into LMTM_TYPE_values (TYPE, CODE, VALUE)
values ('B', 'S0038', 'Bank and Financial Institution');

COMMIT;