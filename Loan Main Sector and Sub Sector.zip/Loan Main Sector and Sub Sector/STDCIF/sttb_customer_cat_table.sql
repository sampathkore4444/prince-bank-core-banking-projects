-- Create table
create table STTB_CUSTOMER_CAT
(
  cust_type      CHAR(1) not null,
  cust_type_desc VARCHAR2(105),
  cust_cat       VARCHAR2(25) not null,
  cust_cat_desc  VARCHAR2(255)
)
/
alter table STTB_CUSTOMER_CAT add primary key (CUST_TYPE, CUST_CAT)
/