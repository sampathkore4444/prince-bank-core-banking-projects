insert into LMTM_TYPE_VALUES (TYPE, CODE, VALUE)
values ('U', 'S0043', 'Insurance Industry');