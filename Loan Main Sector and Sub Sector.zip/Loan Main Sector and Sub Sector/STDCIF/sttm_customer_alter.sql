alter table sttm_customer modify customer_category varchar2(25)
/
alter table sttm_core_customer modify customer_category varchar2(25)
/
