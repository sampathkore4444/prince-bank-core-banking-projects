/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2004 - 2015  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/

var defaultFullName = false;

function fnDefaultFullName() {
	//alert("DEfauling name");
	//debugger;
	if (document.querySelector('input[name="CTYPE"]:checked').value == "I" && (document.getElementById("BLK_CUSTOMER__NAME").value == "" || document.getElementById("BLK_CUSTOMER__NAME").value == document.getElementById("BLK_CUSTOMER__FULLNAME").value || defaultFullName)) {
		document.getElementById("BLK_CUSTOMER__NAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.substring(0,35);
		document.getElementById("BLK_CUSTOMER__NAME").value = document.getElementById("BLK_CUSTOMER__NAME").value.toUpperCase();
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/NAME"), document.getElementById("BLK_CUSTOMER__NAME").value);
	} else if (document.querySelector('input[name="CTYPE"]:checked').value == "C" || document.querySelector('input[name="CTYPE"]:checked').value == "U" || document.querySelector('input[name="CTYPE"]:checked').value == "R" || document.querySelector('input[name="CTYPE"]:checked').value == "S" || document.querySelector('input[name="CTYPE"]:checked').value == "N") { //loan sector changes sampath starts
		if (document.getElementById("BLK_CUSTCORP__CNAME").value == "") {
			document.getElementById("BLK_CUSTCORP__CNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.substring(0,35);
			document.getElementById("BLK_CUSTCORP__CNAME").value = document.getElementById("BLK_CUSTCORP__CNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTCORP/CNAME"), document.getElementById("BLK_CUSTCORP__CNAME").value);
		}
		
		if (document.getElementById("BLK_CUSTCORP__CORPNAME").value == "") {
			document.getElementById("BLK_CUSTCORP__CORPNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.substring(0,26);
			document.getElementById("BLK_CUSTCORP__CORPNAME").value = document.getElementById("BLK_CUSTCORP__CORPNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTCORP/CORPNAME"), document.getElementById("BLK_CUSTCORP__CORPNAME").value);
		}
	}
	
	defaultFullName = false;
}

function fnDefaultCorrName() {
	if (document.querySelector('input[name="CTYPE"]:checked').value == "I") {
		if (document.getElementById("BLK_CUSTOMER__FULLNAME").value == "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__NAME").value;
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/FULLNAME"), document.getElementById("BLK_CUSTOMER__FULLNAME").value);
		}		
	} else if (document.querySelector('input[name="CTYPE"]:checked').value == "C" || document.querySelector('input[name="CTYPE"]:checked').value == "U" || document.querySelector('input[name="CTYPE"]:checked').value == "R" || document.querySelector('input[name="CTYPE"]:checked').value == "S" || document.querySelector('input[name="CTYPE"]:checked').value == "N") { //loan sector changes sampath starts
		if (document.getElementById("BLK_CUSTOMER__FULLNAME").value == "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTCORP__CNAME").value;
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/FULLNAME"), document.getElementById("BLK_CUSTOMER__FULLNAME").value);
		}
		if (document.getElementById("BLK_CUSTCORP__CORPNAME").value == "") {
			document.getElementById("BLK_CUSTCORP__CORPNAME").value = document.getElementById("BLK_CUSTCORP__CNAME").value.substring(0,26);
			document.getElementById("BLK_CUSTCORP__CORPNAME").value = document.getElementById("BLK_CUSTCORP__CORPNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTCORP/CORPNAME"), document.getElementById("BLK_CUSTCORP__CORPNAME").value);
		}
	}
}

function fnDefaultName() {
	if (document.querySelector('input[name="CTYPE"]:checked').value == "I") {
		if (document.getElementById("BLK_CUSTPERSONAL__FSTNAME").value != "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTPERSONAL__FSTNAME").value;
		}
		if (document.getElementById("BLK_CUSTPERSONAL__MIDNAME").value != "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value + " " + document.getElementById("BLK_CUSTPERSONAL__MIDNAME").value;
		}
		if (document.getElementById("BLK_CUSTPERSONAL__LSTNAME").value != "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value + " " + document.getElementById("BLK_CUSTPERSONAL__LSTNAME").value;
		}
		document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.toUpperCase();
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/FULLNAME"), document.getElementById("BLK_CUSTOMER__FULLNAME").value);
		defaultFullName = true;
		fnDefaultFullName();
	}
}

function fnDefaultUidVal() {
	if (document.getElementById("BLK_CUSTOMER__UIDNAME").value == "PASSPORT") { //  
		var res = document.getElementById("BLK_CUSTOMER__UIDVAL").value;
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTPERSONAL/PPTNO"),res);
		document.getElementById("BLK_CUSTPERSONAL__PPTNO").value = res;
		
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTPERSONAL/PPTISSDT"), document.getElementById("BLK_CUSTOMER__UNIQUE_ID_ISS_DT").value);
		document.getElementById("BLK_CUSTPERSONAL__PPTISSDTI").value = document.getElementById("BLK_CUSTOMER__UNIQUE_ID_ISS_DT").value;		
		
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTPERSONAL/PPTEXPDT"),document.getElementById("BLK_CUSTOMER__UNIQUE_ID_EXP_DTI").value);
		document.getElementById("BLK_CUSTPERSONAL__PPTEXPDTI").value = document.getElementById("BLK_CUSTOMER__UNIQUE_ID_EXP_DTI").value;
		
	} else if (document.getElementById("BLK_CUSTOMER__UIDNAME").value == "NATIONAL ID") {
		var res = document.getElementById("BLK_CUSTOMER__UIDVAL").value;
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTPERSONAL/NATIONID"),res);
		document.getElementById("BLK_CUSTPERSONAL__NATIONID").value = res;		
	} else if (document.getElementById("BLK_CUSTOMER__UIDNAME").value == "TAX ID") {
		var res = document.getElementById("BLK_CUSTOMER__UIDVAL").value;
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/TAXIDNO"),res);
		document.getElementById("BLK_CUSTOMER__TAXIDNO").value = res;		
	}
	
	return true;
}

function fnValidateLim(ev) {
	if (document.querySelector('input[name="CTYPE"]:checked').value == "I") {
		if (document.getElementById("BLK_CUSTOMER__NAME") == null || document.getElementById("BLK_CUSTOMER__NAME").value == "" || document.getElementById("BLK_CUSTOMER__FULLNAME").value == "") {
			ev.stopImmediatePropagation();
			alert("Name not entered yet! Please enter name and then visit limits!");
			return false;
		}
	} else if (document.querySelector('input[name="CTYPE"]:checked').value == "C" || document.querySelector('input[name="CTYPE"]:checked').value == "U" || document.querySelector('input[name="CTYPE"]:checked').value == "R" || document.querySelector('input[name="CTYPE"]:checked').value == "S" || document.querySelector('input[name="CTYPE"]:checked').value == "N") { //loan sector changes sampath starts
		if (document.getElementById("BLK_CUSTCORP__CNAME") == null || document.getElementById("BLK_CUSTCORP__CNAME").value == "" || document.getElementById("BLK_CUSTOMER__FULLNAME").value == "") {
			ev.stopImmediatePropagation();
			alert("Name not entered yet! Please enter name and then visit limits!");
			return false;
		}
	}
	
	if (document.getElementById("BLK_CUSTOMER__LIABID") == null || document.getElementById("BLK_CUSTOMER__LIABID").value == "") {
		ev.stopImmediatePropagation();
		alert("Liability ID not entered yet! Please visit Additional tab and then visit limits!");
		return false;
	}
}


function fnBtnP() {
    
    //alert("P pressed");
    var x = document.getElementById("CVS_LIM");
    if (x.addEventListener) {
        x.addEventListener("click", fnValidateLim, true);
    } else if (x.attachEvent) {
        x.attachEvent("onclick", fnValidateLim, true);
    }

}

//sampath starts

function fnDisableFields(fieldName){
try{
console.log("fieldName="+fieldName);

document.getElementById(fieldName).disabled = true;

if(fieldName == "BLK_CUSTCORP__REGISTER_ADDRESS_OWNERSHIP"){
document.getElementById("BLK_CUSTCORP__REGISTER_ADDRESS_OWNERSHIP").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTCORP__FLEXI_CAPITAL"){
document.getElementById("BLK_CUSTCORP__FLEXI_CAPITAL").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__PERSONAL_PHONE_ISDI"){
document.getElementById("BLK_CUSTOMER__PERSONAL_PHONE_ISDI").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__PERSONAL_PHONE1_ISDI"){
document.getElementById("BLK_CUSTOMER__PERSONAL_PHONE1_ISDI").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__PERSONAL_PHONE2_ISDI"){
document.getElementById("BLK_CUSTOMER__PERSONAL_PHONE2_ISDI").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__HOW_TO_KNOW_PRINCE_BANK"){
document.getElementById("BLK_CUSTOMER__HOW_TO_KNOW_PRINCE_BANK").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__SOURCE_OF_INCOME"){
document.getElementById("BLK_CUSTOMER__SOURCE_OF_INCOME").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__ACCOUNT_OPEN_PURPOSE"){
document.getElementById("BLK_CUSTOMER__ACCOUNT_OPEN_PURPOSE").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__SPOUSE_OCCUPATION"){
document.getElementById("BLK_CUSTOMER__SPOUSE_OCCUPATION").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__ADDL_ID_TYPE"){
document.getElementById("BLK_CUSTOMER__ADDL_ID_TYPE").nextSibling.style.visibility="hidden";
}


if(fieldName == "BLK_CUSTOMER__REFERRAL"){
document.getElementById("BLK_CUSTOMER__REFERRAL").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__CURRENT_RESIDENCE_OWNERSHIP"){
document.getElementById("BLK_CUSTOMER__CURRENT_RESIDENCE_OWNERSHIP").nextSibling.style.visibility="hidden";
}

if(fieldName == "BLK_CUSTOMER__RESIDENT_TYPE"){
document.getElementById("BLK_CUSTOMER__RESIDENT_TYPE").nextSibling.style.visibility="hidden";
}

if (document.querySelector('input[name="CTYPE"]:checked').value == "I"){
document.getElementById("cmdAddRow_BLK_CUSTCORP_CONTACT").style.visibility="HIDDEN";
document.getElementById("cmdAddRow_BLK_CUSTCORPDIR_TYPE").style.visibility="HIDDEN";
}
} catch(e){
console.log("Error="+e);
}


}
	

function fnInTab_TAB_FLEXI_DTLS_CUSTOM(){

console.log("inside fnInTab_TAB_FLEXI_DTLS_CUSTOM");

console.log("Customer Type="+document.querySelector('input[name="CTYPE"]:checked').value);

const disableCorpFields = ["BLK_CUSTCORP__CORPORATE_KHMER_NAME", "BLK_CUSTCORP__OTHER_TYPE_OF_ORG", "BLK_CUSTCORP__OTHER_FORM_OF_ORG",
    "BLK_CUSTCORP__ESTIMATED_MONTHLY_INCOMEI", "BLK_CUSTCORP__VAT_REG_DATE", "BLK_CUSTCORP__REGISTER_ADDRESS_TYPE", "BLK_CUSTCORP__REGISTER_ADDRESS_OWNERSHIP",
    "BLK_CUSTCORP__REMARKS", "BLK_CUSTCORP__FLEXI_CAPITAL", "BLK_CUSTCORP_CONTACT__SNO", "BLK_CUSTCORP_CONTACT__CONTACT_PERSON_NAME", "BLK_CUSTCORP_CONTACT__OCCUPATION",
    "BLK_CUSTCORP_CONTACT__MOBILE_NUMBER", "BLK_CUSTCORP_CONTACT__E_MAIL", "BLK_CUSTCORP_CONTACT__REMARKS", "BLK_CUSTCORPDIR_TYPE__SNO", "BLK_CUSTCORPDIR_TYPE__DIRECTOR_TYPE",
    "BLK_CUSTCORPDIR_TYPE__REMARKS"
];

const disableIndFields = ["BLK_CUSTOMER__PERSONAL_PHONE_ISD",
"BLK_CUSTOMER__PERSONAL_PHONE",
"BLK_CUSTOMER__PERSONAL_PHONE_ISDI",
"BLK_CUSTOMER__PERSONAL_PHONE1",
"BLK_CUSTOMER__PERSONAL_PHONE1_ISDI",
"BLK_CUSTOMER__PERSONAL_PHONE2_ISDI",
"BLK_CUSTOMER__PERSONAL_PHONE2",
"BLK_CUSTOMER__AGEI",
"BLK_CUSTOMER__HOW_TO_KNOW_PRINCE_BANK",
"BLK_CUSTOMER__SOURCE_OF_INCOME",
"BLK_CUSTOMER__ACCOUNT_OPEN_PURPOSE",
"BLK_CUSTOMER__SPOUSE_OCCUPATION",
"BLK_CUSTOMER__OTHER_INCOME_TYPE",
"BLK_CUSTOMER__OTHER_INCOME_AMOUNT",
"BLK_CUSTOMER__FACEBOOK_ID",
"BLK_CUSTOMER__LINKEDIN_ID",
"BLK_CUSTOMER__INSTAGRAM_ID",
"BLK_CUSTOMER__TELEGRAM_ID",
"BLK_CUSTOMER__ADDL_ID_TYPE",
"BLK_CUSTOMER__ADDL_ID_NO",
"BLK_CUSTOMER__ADDL_ID_ISS_DATEI",
"BLK_CUSTOMER__ADDL_ID_EXP_DATEI",
"BLK_CUSTOMER__CUSTOMER_CLASS",
"BLK_CUSTOMER__CUSTOMER_PRODUCT_ELIGIBLE",
"BLK_CUSTOMER__CUSTOMER_CREDIT_SCORE",
"BLK_CUSTOMER__REFERRAL",
"BLK_CUSTOMER__CURRENT_RESIDENCE_OWNERSHIP",
"BLK_CUSTOMER__STAFF_ID",
"BLK_CUSTOMER__OTHER_EMPLOYMENT_DETAIL",
"BLK_CUSTOMER__OTHER_EMPLOYMENT_SECTOR",
"BLK_CUSTOMER__OTHER_EMPLOYMENT_SUB_SECTOR",
"BLK_CUSTOMER__OTHER_OCCUPATION_NAME",
"BLK_CUSTOMER__EMPLOYMENT_DATEI",
"BLK_CUSTOMER__RESIDENT_TYPE"];

    if (document.querySelector('input[name="CTYPE"]:checked').value == "I") {
	
	disableCorpFields.forEach(fieldName => fnDisableFields(fieldName));
     

    } else if (document.querySelector('input[name="CTYPE"]:checked').value == "C") {

       
	disableIndFields.forEach(fieldName => fnDisableFields(fieldName));
    }

}

function fnPostNew_CUSTOM() {
	fnEnableElement(document.getElementsByName("CTYPE")[3]);
	fnEnableElement(document.getElementsByName("CTYPE")[4]);
	fnEnableElement(document.getElementsByName("CTYPE")[5]);
	fnEnableElement(document.getElementsByName("CTYPE")[6]);

    return true;
}


//sampath ends