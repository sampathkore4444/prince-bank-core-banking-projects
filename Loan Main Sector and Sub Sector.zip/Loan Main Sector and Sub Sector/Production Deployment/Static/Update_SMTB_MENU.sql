UPDATE p1fchprfm.smtb_menu A SET A.CUSTOM_MODIFIED = 'Y' WHERE function_id = 'CLDACCNT'
/
UPDATE p1fchprfm.smtb_menu A SET A.CUSTOM_MODIFIED = 'Y' WHERE function_id = 'CLDACCVM'
/
COMMIT;