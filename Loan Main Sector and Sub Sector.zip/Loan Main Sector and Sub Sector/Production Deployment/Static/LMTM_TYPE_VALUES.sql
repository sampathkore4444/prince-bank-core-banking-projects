insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('B', 'Bank and Financial Institution', 'S0038');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Jewelry-Gem-Precious Mental Business', 'S0005');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Pawn Shop', 'S0006');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Stock Exchange', 'S0007');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Real Estate Businesses (Including Agents)', 'S0008');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Law firm', 'S0009');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Accounting firms', 'S0010');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Embassy', 'S0011');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Casinos Industry', 'S0012');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Wholesale and Retail Trades (Physical Store)', 'S0015');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Import-Export', 'S0016');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Education', 'S0017');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Health Care Center', 'S0018');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Entertainment/Fine Arts', 'S0019');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Hotel/Tourism/Restaurant/Beverage', 'S0020');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Agriculture, Forestry and Fisheries', 'S0022');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Unemployed', 'S0023');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'None', 'S0025');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Other', 'S0026');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Manufacturing Industry', 'S0027');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Retail Trade without a Physical Store (Online Business)', 'S0029');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Utility/Energy', 'S0030');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Post and Telecommunication', 'S0031');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Media', 'S0036');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Money Remittance Companies (Including their agents)', 'S0039');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Money changers', 'S0040');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Trusted', 'S0041');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Airline Industry', 'S0042');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Insurance Industry', 'S0043');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Construction Industry', 'S0044');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Beauty Care', 'S0045');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Logistic/Transportation/Delivery', 'S0046');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Pharmaceuticals/Medical Equipment', 'S0047');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Technology', 'S0048');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Athletics/Sports', 'S0051');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('C', 'Rental Service', 'S0052');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Jewelry-Gem-Precious Mental Business', 'S0005');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Pawn Shop', 'S0006');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Stock Exchange', 'S0007');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Real Estate Businesses (Including Agents)', 'S0008');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Law firm', 'S0009');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Accounting firms', 'S0010');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Embassy', 'S0011');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Casinos Industry', 'S0012');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Local NGO and Association', 'S0013');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Wholesale and Retail Trades (Physical Store)', 'S0015');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Import-Export', 'S0016');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Education', 'S0017');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Health Care Center', 'S0018');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Entertainment/Fine Arts', 'S0019');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Hotel/Tourism/Restaurant/Beverage', 'S0020');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Agriculture, Forestry and Fisheries', 'S0022');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Unemployed', 'S0023');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'None', 'S0025');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Other', 'S0026');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Manufacturing Industry', 'S0027');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Retail Trade without a Physical Store (Online Business)', 'S0029');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Utility/Energy', 'S0030');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Post and Telecommunication', 'S0031');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'State-owned enterprise', 'S0034');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Media', 'S0036');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Bank and Financial Institution', 'S0038');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Money Remittance Companies (Including their agents)', 'S0039');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Money changers', 'S0040');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Trusted', 'S0041');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Airline Industry', 'S0042');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Insurance Industry', 'S0043');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Construction Industry', 'S0044');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Beauty Care', 'S0045');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Logistic/Transportation/Delivery', 'S0046');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Pharmaceuticals/Medical Equipment', 'S0047');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Technology', 'S0048');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'International NGO', 'S0049');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Ministries', 'S0050');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Athletics/Sports', 'S0051');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('I', 'Rental Service', 'S0052');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('N', 'Local NGO and Association', 'S0013');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('N', 'International NGO', 'S0049');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('R', 'Ministries', 'S0050');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('S', 'State-owned enterprise', 'S0034');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('U', 'Insurance Industry', 'S0043');

COMMIT;
