prompt Importing table sttb_customer_cat...
set feedback off
set define off
insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('I', 'INDIVIDUAL', 'IND_ECIF', 'E ACCOUNTS CIF CATEGORY');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('I', 'INDIVIDUAL', 'IND_RES', 'INDIVIDUAL RESIDENT');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('I', 'INDIVIDUAL', 'IND_NR', 'INDIVIDUAL NON-RESIDENT');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('I', 'INDIVIDUAL', 'IND_BIZ', 'INDIVIDUAL BUSINESS');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('I', 'INDIVIDUAL', 'IND_BIZ_NR', 'INDIVIDUAL BUSINESS NON-RESIDENT');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('I', 'INDIVIDUAL', 'STAFF', 'STAFF');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('I', 'INDIVIDUAL', 'STAFF_NR', 'STAFF NON-RESIDENT');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('I', 'INDIVIDUAL', 'WALKIN', 'WALK-IN CUSTOMER');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('C', 'CORPORATE', 'CORPORATE', 'CORPORATE RESIDENT');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('C', 'CORPORATE', 'CORPORATE_NR', 'CORPORATE NON-RESIDENT');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('B', 'FINANCIAL INSTITUTION', 'BANKS', 'COMMERICIAL BANKS');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('B', 'FINANCIAL INSTITUTION', 'FI', 'MICROFINANCE INSTITUTIONS');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('B', 'FINANCIAL INSTITUTION', 'CEB', 'CENTRAL BANKS');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('B', 'FINANCIAL INSTITUTION', 'MDTI', 'MICROFINANCE DEPOSIT TAKING INSTITUTIONS');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('B', 'FINANCIAL INSTITUTION', 'SPZBANK', 'SPECIALIZED BANK');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('B', 'FINANCIAL INSTITUTION', 'LSC', 'LEASING COMPANIES');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('B', 'FINANCIAL INSTITUTION', 'RCI', 'RURAL CREDIT INSTITUTIONS');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('B', 'FINANCIAL INSTITUTION', 'OTH', 'OTHERS');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('U', 'INSURANCE', 'INS', 'INSURANCE COMPANIES');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('R', 'ROYAL GOVERNMENT OF CAMBODIA', 'NAD', 'NATIONAL ADMINISTRATION');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('R', 'ROYAL GOVERNMENT OF CAMBODIA', 'SAD', 'SUB NATIONAL ADMINISTRATION');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('S', 'STATE-OWNED ENTERPRISES', 'FN', 'FINANCIAL ENTERPRISES');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('S', 'STATE-OWNED ENTERPRISES', 'NFN', 'NON-FINANCIAL ENTERPRISES');

insert into sttb_customer_cat (CUST_TYPE, CUST_TYPE_DESC, CUST_CAT, CUST_CAT_DESC)
values ('N', 'NON-PROFIT ORGANIZATION', 'NPO', 'NPO');

prompt Done.
