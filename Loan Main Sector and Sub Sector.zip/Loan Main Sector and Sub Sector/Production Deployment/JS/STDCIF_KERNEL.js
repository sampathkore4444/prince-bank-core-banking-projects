/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2015  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
----------------------------------------------------------------------------------
**  CHANGE LOG
**  Last Modified By   : Edwin Leo
**  Last modified on   : 21-Sep-2010
**  Full Version       :
**  Reason           : Kernel 11.2 Centralization Changes
**  Search String      : Edwin Added for Kernel11.2
**
**  CHANGE LOG
**  Last Modified By   : Thiru
**  Last modified on   : 25-Oct-2010
**  Reason           : Other Brn Txns shud always be queried thru Summary. 
**                   : As per FS and requested by Testing Team, restricted here.
**  Search String      : ITR1#53
**
**  Changed by	:	Aruna
** Changed for	:	SNORAS#3897
**  Change Description : The Minimum telephone number length has been updated from 10 to 8.
**
**  CHANGE LOG #4
**  Last Modified By   : Suhas Rekhu
**  Last modified on   : 04-july-2011
**  Reason             : Disabling the form after the exhaustion of customer number sequence. 
**  Search String      : 9nt1466 fcubs 11.3.1 cif/casa number resuse
**
**  CHANGE LOG #5
**  Last Modified By   : Stalin Gino S
**  Last modified on   : 18-july-2011
**  Reason             : FCUBS_11.3.1 CIF_CASA LIMITS changes
**  Search String      : LIMITS_11.3.1
**
**  CHANGE LOG #6
**  Last Modified By   : Gokulnath M
**  Last modified on   : 19-July-2011
**  Reason             : FCUBS_11.3.1 CIF_CASA changes
**
**  CHANGE LOG #7
**  Last Modified By   : Stalin Gino S
**  Last modified on   : 08-Aug-2011
**  Reason             : FCUBS_11.3.1 CIF_CASA changes

**  CHANGE LOG #8
**   Changed  By           : Gokulnath M
**   Changed  On           : 13-Oct-2011
**  Modified Reason       : 9NT1462 ITR 13064575 disabled Account Details
**  Search String         : 9NT1462 ITR 13064575
	
**  CHANGE LOG #9	
**  Last Modified By   : Gokulnath.M
**  Last modified on   : 27-Oct-2011
**  Full Version       : FCUBS_11.4.0
**  Reason             : 9NT1462 ITR1 13247536 defaulted the screen arguements
**  Search String : 9NT1462 ITR1 13247536	
**  CHANGE LOG #10	
**  Last Modified By   : Gokulnath.M
**  Last modified on   : 8-Nov-2011
**  Full Version       : FCUBS_11.4.0
**  Reason             : 9NT1462 ITR1 13330438 setting the Account Locked as false
**  Search String : 9NT1462 ITR1 13330438
**  CHANGE LOG #11	
**  Last Modified By   : Gokulnath.M
**  Last modified on   : 31-01-2012
**  Full Version       : FCUBS_12.0.0
**  Reason             : Usabiity changes
**  Search String : FCUBS_12.0.0 Usabiity changes
**  CHANGE LOG #12	
**  Last Modified By   : Suhas Rekhu
**  Last modified on   : 2-03-2012
**  Full Version       : FCUBS_12.0.0
**  Reason             : Revert backing of field names. 
**  Search String 		: FCUBS_12.0.0 Usabiity field name change

**  Last Modified By   : AnjaliSi
**  Last modified on   : 25-02-2012
**  Full Version       : FCUBS_12.0.0
**  Reason             : DMS callform changes
**  Search String : FCUBS_12.0.0 DMS changes

**  Last Modified By  : Periyathambi M
**  Last modified on   : 05-04-2012
**  Full Version           : FCUBS_12.0.0
**  Reason             	     : Disabled Tabs getting enabled when using accesibility keys, so used disabeTabs function exists in EXTUIUTIL.js
**  Search String      : 9NT1501 ITR -1 SFR - 13902635
**  Reason             	     : Commented the bracket in fnCTYPEChange
**  Search String      : 9NT1501 ITR -1 SFR - 13929641


    Changed  By           : Gokulnath M
    Changed  On           : 14-Apr-2012
    Modified Reason       : First focus field defaulted to Customer number field
    Search String         : 9NT1501 ITR1 13958683	

  Changed  By   :         Karan Gaba
  Changed  On    :      26april2012
Search String       :   FCUBS 12.0 itr2 sfr#14004922 
  Modified Reason   Event removed from function fnCTYPEChange .
  
    Changed  By   :      Niranjana R
  Changed  On    :      02-05-2012
Search String       :   9NT1501 SFR#14004922
  Modified Reason  : Added Focus on checklist tab to the multiple entry block
  
   Changed  By           : Niranjana R
   Changed  On           : 31-Aug-2012
   Modified Reason       : Getting the customer type value for population of check list details as per customer type and assigned the value in unused field 'LIABNO' instead of introducing a new UI field.
   Search String         : 9NT1525-12.0RETRO-JMDFGL-14570025 
    
    Changed  By           : Shashanka K
    Changed  On           : 10-Sep-2012
    Modified Reason       : Bug 14549770 - PS-NEDBANK- WAS- KYC DETAILS NOT SHOWN 
    Search String         : 9NT1525 IMPSUPP 14549770

	Changed by         : Shashank Subraya
	Changed on         : 18-Feb-2013
	Change tag         : NLS Changes 12.0.1
	Change description : NLS Changes 12.0.1
	
	Changed by         : Jyotiranjan Harichandan
	Changed on         : 11-Feb-2013
	Change tag         : FATCA Changes 12.0.2
	Change description : FATCA Changes 12.0.2

    Changed  By           : dhananjaya T
    Changed  On           : 20-mar-2013
    Modified Reason       : While creating a new customer after clicking on populate System displays an 
	                        error messgae "Mandatory Field Customer No is Not Input" even though it fails 
                            with someother error message. During analysis we found out that 
                            "ST-MAND-001" error code has been hard coded in STDCIF_KERNEL.js in the 
                            function fnOnClickBtnPopulate and hence whatever the error code system 
                            returns from Database is not displayed on screen. 
 
    Search String         : 16522265	

	Changed  By           : Anjali
    Changed  On           : 15-Apr-2013
    Search String         : 120_CITI120_16593670

   Changed  By           : Anjali
   Changed  On           : 22-jan-2012
   Modified Reason       : Modified the arguments to be passed to limits screen so as to populate liab name with customer name instead of customer number.
   Search String         : 114_JMDFGL_16200195 

  Modfied By        : Tapas Pani
  Modified On       : 29-Apr-2013
  Modified Reason   : Code added to populate statement day details based on frequency.
  Search String     : FC12.0.2_Combined_statement
  
  
  Modfied By        : Tapas Pani
  Modified On       : 29-Apr-2013
  Modified Reason   : Code added to populate statement day details based on frequency.
  Search String     : FC12.0.2_Combined_statement
  
**  Changed by         : Shayam Sundar R
**  Changed On         : 15-May-2013
**  Change Description : Removed customer type B check for STDCIFAD screen
**  Search String      : 9NT1587_FCUBS_12.0.2_DEV_Joint Holder Maintanance_CHANGES_UT_ISSUE

**   Modified By         : Vinu Priyesh V.A.
**   Modified On         : 04-Jul-2013
**   Modified Reason     : statement day in combined statement is made to load on clicking the tab additional
**   Search String       : 9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17053088    
**  Changed by         : Jyotiranjan Harichandan
**  Changed On         : 04-July-2013
**  Change Description : Fix for LABEL ISSUE IN STDCIFAD SCREEN 
**  Search String      : 9NT1587_FCUBS_12.0.2_17043430 

**  Changed By            : Ajai Sebastian	
**	Changed On            :19-july-2013
**	Modified Reason       : The Minimum telephone number length has been updated from 8 to 7.
**	Search String         :Bug#17188227
 
**  Changed By            : Ajai Sebastian	
**	Changed On            :19-july-2013
**	Modified Reason       : condition for opening the joint customer subscreen only if the joint flag is checked.
**	Search String         :1201_IDTKEKE_17190226   

Changed By            : Shashank Subraya
	Changed On            : 23-Apr-2013
	Modified Reason       : Enable/Disable of tabs on screen load.
	Search String         : FC12.0_CITI120_16679039	   

  Changed By              : Ajai Sebastian
	Changed On            : 22-Aug-2013
	Modified Reason       : Defaulting of customer name in account description instead of defaulting the short name
	Search String         :    1202_17346846 
	
	
**   Modified By         : Viba R 
**   Modified On         : 19-Aug-2013
**   Modified Reason     : Fix provided for combined statement 
**   Search String       : 9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17311607

     Changed  By           : Anoop R
     Changed  On           : 23-Oct-2013
     Modified Reason       : Set the ELCM_CUSTOMER_NO to null in case ELCM_CUSTOMER is not checked else copy the new customer number created 
     Search String         : 1202_INTERNAL_17646118   
**
**  Modified By          : Athul Nair  
**  Modified On          : 25-Oct-2013
**  Modified Reason      : MF forward port from 12.0.1 to 12.0.2
**  Search String        : FCUBS_MF12.0.1_to_MF12.0.2_Port

**   Modified By         : Ajai
**   Modified On         : 11-Nov-2013
**   Modified Reason     : Disabling the account creation button during query operation if customer is authorized.
**   Search String       : 1202_17772903

**   Modified By         : Deva Ananda Kumar Reddy
**   Modified On         : 10-Dec-2013
**   Modified Reason     :Passing the Customer Name as the screen argument to CSCCURLN  for displaying the Primary Customer Description in the linked entities sub screen as part of the bug 17910544
**   Search String       : 9NT1606# 1202SUPPORT#17910544

**   Modified By         : Deva Ananda Kumar Reddy
**   Modified On         : 26-Dec-2013
**   Modified Reason     :Changes as part of the bug 17999926
**   Search String       : 9NT1606# 1202SUPPORT#17999926

**   Modified By         : Deva Ananda Kumar Reddy
**   Modified On         : 22-Jan-2014
**   Modified Reason     :Changes as part of CASA Virtual Accounts and FCIS Integration
**   Search String       : 9NT1620_1203_DEV

**   Modified By         : Deva Ananda Kumar Reddy
**   Modified On         : 20-Feb-2014
**   Modified Reason     :Added code to disable the multi entry block under director tab
**   Search String       : 9NT1620_1203_MAT_18273112

**   Modified By         : Deva Ananda Kumar Reddy
**   Modified On         : 05-Mar-2014
**   Modified Reason     :Passing the customer Full name as the parameter to image call form instead of the name under Address for Correspondence
**   Search String       : 9NT1620_1203_18295583

**   Modified By         : Deva Ananda Kumar Reddy
**   Modified On         : 06-May-2013
**   Modified Reason     :Disabling the Pin Code field under the tab additional if the customer is of  type corporate or bank  and disabling the fields  under domicile address for copy and unlock action 
**   Search String       : 9NT1620# 1203RETRO#18709202 


**   Modified By         : Deva Ananda Kumar Reddy
**   Modified On         : 27-May-2013
**   Modified Reason     :Renamed the Fields in sync with the RAD fields in fnPostExecuteQuery
**   Search String       : 9NT1620#1203RETRO#18844414

**   Modified By         : Anoop R
**   Modified On         : 25-Jun-2014
**   Modified Reason     : Copy the new customer number created to FX_NETTING_NO
**   Search String       : 9NT1620_1203_19059946

**   Modified By         : Anoop R
**   Modified On         : 07-Jul-2014
**   Modified Reason     : To display UDF fields as text if it is text under auxiliary tab.
**   Search String       : 1203_IUSDBOA_19161766

     Changed  By           : Anmol
     Changed  On           : 08-July-2014
     Modified Reason       :19171099  Changes
                          Added validation to check the condition of cust type and enable and disable
                          Fields on Domestic button.
     Search String         : 19171099
	 
**   Modified By         : Deva Anand
**   Modified On         : 28-Jul-2013
**   Modified Reason     :Added the code in order to nullify the short name during copy operation for the case of generating the customer number manually.
**   Search String       : 9NT1620#1203SUPPORT#19303321 


  **   Modified By         : Deva Anand
**   Modified On         : 30-Jul-2014
**   Modified Reason     :Commented the code as the fields referred is available in other  tabs which is resulting in failure of the function 
**   Search String       : 9NT1620#1203RETRO#19322716  
**
**  Modified By          : Pratibha Nair  
**  Modified On          : 20-Aug-2014
**  Modified Reason      : Values added in Additional Tab disappears if later MFI customer flag is checked.
**  Search String        : FCUBS_12.0.3_ZAO_UNICREDIT_19471120

  Changed  By           : Deva Anand
   Changed  On           : 16-Oct-2014
   Modified Reason       : Modified the arguments to be passed to limits screen so as to populate liab name with customer name instead of short name
   Search String         : 9NT1606#1203SUPPORT#19822002 
   
**   Modified By         : Subhashini Srinivasan
**   Modified On         : 28-Oct-2014
**   Modified Reason     : Retro to view the customer details in LC Origination screen 
**   Search String       : 19901232 	


   
   Changed  By           : Harikrishna
   Changed  On           : 08-may-2015
   Modified Reason       : 12.1 Sanction Check status fetch
   Search String         : 12.1 Sanction Check Changes
   
Base SFR No	  :   20218742
Modified  By           : Deva Anand
   Modified  On           : 02-Jan-2014
   Modified Reason       : Defaulting the flag track limits and liability id if the track limits flag for the corresponding customer type is checked in the bank level 
   Search String         : 121_21064380
	
 ** Modified  By         : Anoop R
 ** Modified  On         : 19-Mar-2015
 ** Modified Reason      : The domestic and professional subsystem buttons must be disabled for corporate and bank customers.
                           Also, the account creation button must be disabled during query operation if customer is authorized. 
 ** Search String        : 12.1_21064673
 
 
 ** Modified  By         : Deva Anand
 ** Modified  On         : 21-May-2015
 ** Modified Reason      : Customer Landing page changes
 ** Search String        : 12.1 customer Landing page changes
 ** 
 ** Modified  By         : Jayaram S
 ** Modified  On         : 29-May-2015
 ** Modified Reason      : Added function ORDRPYTM, ORDRPPTM,ORDRDSTM function to existing code to view customer details.
 ** Search String        : 19901232 
 
 ** Modified  By         : Pankaj
 ** Modified  On         : 13-Jul-2015
 ** Modified Reason      : Function fnInTab_TAB_ADDITIONAL_KERNEL was written defined twice second place definition is commneted and code is moved to first definition.  
 ** Search String        : Bug#21425319
 
 ** Changed By        : Ravi Ranjan
 ** Changed On        : 20-02-2016
 ** Changed Reason    : FCUBS122DEV_CIFCASARANGE Special Customer Changes 
 ** Search String     : FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range
 
   Modified By       	: Jessey Paul
   Modified On       	: 11-Aug-201g
   Modified Reason   	: When the track limits checkbox is unchecked, the field liability id should be disabled along with erasing its data.
   Search String     	: 12.2_SUPPORT_RETRO_23653806
   
 ** Modified  By         :Jessey Paul
 ** Modified  On         : 30-Aug-2016
 ** Modified Reason      : During execute query for MFI Details tab Identification details and check List button not getting enable. Code added to enable during execute query.
 ** Search String        : 12.2_SUPPORT_RETRO_23657168
 
 ** Modified By         : Jessey Paul
 ** Modified On         : 30-Aug-2016
 ** Modified Reason     : Added extra condition old liabilityNo is not equal to new liabilityNo then default the newly entered liabilityNo
 ** Search String       : 12.2_SUPPORT_RETRO_23664149
 
 ** Modified  By         : Jessey Paul
 ** Modified  On         : 30-Aug-2016
 ** Modified Reason      : The limitsMode should be load when a new customer is created and the liability number is different from the customer number.
 ** Search String        : 12.2_SUPPORT_RETRO_23651456
 
  ** Modified  By         : Jessey Paul
 ** Modified  On         : 31-Aug-2016
 ** Modified Reason      : Hiding Authorize button when a user who do not have multi branch access queries a customer in branches he don't have access.
 ** Search String        : 12.2_SUPPORT_RETRO_23658059

** Modified By      : Vijay Masti
** Modified On      : 02-Sep-2016
** Modified Reason  : Disabling the fields subscreen inside the limits subscreen in STDCIF as the 
** 						user is not allowed to add or change the value of UDF fields. He is only 
** 						allowed to view the value of the fields maintained in the laibility 
** 						maintenace screen (GEDMLIAB) 
** Search String    : RETRO SFR#23656280


** Modified  By         : Ranjana Ladia
** Modified  On         : 15-SEP 2016
** Modified Reason      : Some fields inside the limits tab were made amendable so that data can be maintained during modify operation.
 ** Search String        : FCUBS_12.2_RETRO_BUG#23656001

** Modified  By         : Vrishti Ghosh
 ** Modified  On         : 19-Sept-2016
 ** Modified Reason      : Customer number should be defaulted to the liability id field when you click on the additional tab only when it has not been selected already.
 ** Search String        : FCUBS_12.2.0.0.0_SUPPORT_23657266

** Modified  By         : Ranjana Ladia
** Modified  On         : 22-SEP 2016
** Modified Reason      : added code to chech for if (parent.screenArgs && parent.screenArgs["PARENT_FUNC_ID"] == "STDBRREF")  only when if (parent.screenArgs != undefined)
** Search String        : FCUBS_12.2_RETRO_BUG#24294856

** Modified  By         : Vrishti Ghosh
 ** Modified  On         : 23-Sept-2016
 ** Modified Reason      : The limitsMode should be load during query action
 ** Search String        : FCUBS_12.2.0.0.0_SUPPORT_23652655
 
 ** Modified  By         : Vrishti Ghosh
 ** Modified  On         : 26-Sept-2016
 ** Modified Reason      : Code modified to display the customer's local branch instead of currently logged in branch in Image callform
 ** Search String        : FCUBS_12.2.0.0.0_SUPPORT_23657519
 **
**  Modified By			: Monica R
** Modified  On         : 26-Sept-2016
**	Modified Reason   	: Added condition to check whether the provided email id ends with a dot
**	Search String     	: 9NT1606_12.0.2_CNSL_NBE_24555381
**	Search String     	: 9NT1606_12_2_RETRO_12_0_2_24604345 

 ** Modified  By         : Monica R
 ** Modified  On         : 26-Sep-2016
 ** Modified Reason      : Hiding Authorize button when a user who do not have multi branch access queries a customer in branches he don't have access.Reverted the fix given for bug no. 21469008
 ** Search String        : 1203_21572202 
 ** Search String        : 9NT1606_12_2_RETRO_12_0_3_23654974  
 **
 ** Modified  By         : Priyanka vijai
 ** Modified  On         : 26-Sep-2016
 ** Modified Reason      : System failed to open the limits subscreen immediately after creating the customer with limits maintained and querying.
 ** Retro  String        : 1203_22699342 
 ** Search String        : 9NT1606_12_2_RETRO_12_0_3_23652476 
 
    Modified By       	: Vrishti Ghosh
   Modified On       	: 27-Sept-2016
   Modified Reason   	: Modified the code so that when a customer record with liabilty details is queried, it loads the liability data from ELCM tables if already maintained.
    			  Also added validation to ensure that only one row can be selected as primary in the rating subscreen of limits subscreen.
   Search String     	: FCUBS_12.2.0.0.0_SUPPORT_23655284
 
 ** Modified  By         : Priyanka Vijai
 ** Modified  On         : 27-Sep-2016
 ** Modified Reason      : When creating a new customer, the limit screen should be allowed to open only if the track limits flag is checked 
						   or if mandatory limit tracking is enabled for that customer type at bank level.
 ** Search String        : 9NT1606_12_2_RETRO_12_0_3_23652432
 ** Retro String         : 1203_22663740 

 ** Modified  By         : Karthikeyan k
 ** Modified  On         : 11-Nov-2016
 ** Modified Reason      : On copy of customer details , Customer number should be defaulted to liability id field  when
                           track limit is checked
 ** Search String        : [FCUBS_12.3_ITR1_25050083]
 
 ** Modified  By         : Poornachandran R
 ** Modified  On         : 08-Dec-2016
 ** Modified Reason      : Checking Details are cleared during copy action in STDCIF
 ** Search String        : Bug#25209669
**
** Modified by            : Nalandhan G
** Modified On            : 12-Oct-2016
** Modified Reason        : Corrected the elementid for CUSTNO
** Retro String           : Bug_24555671
** Search string          : 9NT1606_12_2_RETRO_12_0_3_24813498

**
** Modified by            : Kumar Vikrant
** Modified On            : 08-Nov-2016
** Modified Reason        : Liability Name was not defaulted 
** Search string          : 24968965_WELLS_FARGO


** Modified by            : Kumar Vikrant
** Modified On            : 17-Nov-2016
** Modified Reason        : NOT ABLE TO MODIFY CIF CREATED IN STDCIFAD IN STDCIF (special_cust field was disabled)
** Search string          : 25086617_ORIENBANK

** Modified by            : Shayam Sundar Ragunathan
** Modified On            : 15-Jun-2017
** Modified Reason        : DATA IS NOT GETTING CLEARED FROM PREVIOUS RECORD ON STDCIF SCREEN 
** Search string          : 9NT1606_12_4_RETRO_12_3_26230186
**
** Modified By           : Nalandhan G
** Modified On           : 26-Jul-2017
** Modified Reason       : Data from communication mode is not getting cleared from previous
                           record on stdcif if new customer if the previous customer is
                           corporate.
** Retro String          : 26319668_CB_ALLIANZ
** Search string         : 9NT1606_12_4_RETRO_12_3_26384621 
**
** Modified By           : Nalandhan G
** Modified On           : 22-Aug-2017
** Modified Reason       : When all searches are cleared in STSCIF, system does not retrieve
                           the LOV values correctly.
						   As in show detail function in STDCIF_Kernel.js g_txnBranch was 
                           getting changed to branch of detailed screen in case of 
                           multiBranch.
** Retro String          : FCUBS_1203_26654880
** Search string         : 9NT1606_12_4_RETRO_12_0_3_26661106

**  Modified By          : Ambika Selvaraj
**  Modified On          : 19-Sep-2017
**  Modified Reason      : Fixed the unhandled exception while visiting the LIMITS sub screen. 
**  Retro Source         : 9NT1606_12_3_ALPHA_ROMANIA
**  Search String        : 9NT1606_12_4_RETRO_12_3_26724251
**
** Modified By         : Nalandhan G
** Modified On         : 25-Sep-2017
** Change Description  : Code was going into exception as it was not getting corporate 
                         details in case of individual cust and vice-versa.
                         Added condition for the same
** Retro String        : 26809839_cabel
** Search string       : 9NT1606_12_4_RETRO_12_3_26861749
**
** Modified By         : Nalandhan G
** Modified On         : 28-Sep-2017
** Modified Reason     : Chnages done so that only current branch liablity we can link to 
                         customer
** Retro String        : ALPHA SUPPORTING SERVICES S.A._26672295
** Search string       : 9NT1606_12_4_RETRO_12_3_26818173
**
** Modified By         : Nalandhan G
** Modified On         : 09-Oct-2017
** Modified Reason     : The validation is needed only for CIF type corporate hence the 
                         condition is added to skip the validation to check the mandatory 
                         field DIRECTOR NAME when the customer type is Individual  
** Retro String        : FCUBS_1203_BANK AUDI_26876427
** Search string       : 9NT1606_12_4_RETRO_12_3_26913146
**
** Modified By         : Nalandhan G
** Modified On         : 15-Nov-2017
** Modified Reason     : On tab out of the field SSN code is written to check if the action 
                         is not NULL then system should not change the TAB 	  
** Retro string        : Fcubs_12.3_ADVANCED BANK OF ASIA LTD_BUG#27075797
** Search String       : 9NT1606_12_4_RETRO_12_3_27107106

**  Modified By          : Neethu Sreedharan
**  Modified On          : 20-Nov-2017
**  Modified Reason      : Changes done to disable liability branch so that customer can be linked to the liability of the current branch only.
**  Retro Source         : 9NT1606_12_3_BANK_OF_VALLETTA_P_L_C
**  Search String        : 9NT1606_12_4_RETRO_12_3_27143112  
**
**
** Modified By           : Akshara Jorigal
** Modified On           : 21-Nov-2017
** Modified Reason       : Fix given to default the Customer Name in account opening screen(STCCUACC) to full_name 
                           if customer_name1 is null and later on click of fetch Account description will be populated to full_name.
** Retro String          : FCUBS_12.3_CNSL_ADVANCED BANK OF ASIA LTD_SFR#26995839
** Search String         : 9NT1606_12_4_RETRO_12_3_27143099


**  Changed by         : Geeta Adhikari
**  Changed On         : 20-Apr-2018
**  Change Description : Issue : If track limits is checked on unlock operation, system is throwing error while saving the record, as Liability branch is NULL, 
                                 which is a mandatory field and is disabled.
						 Fix   : Fix is given to default the Liability branch with the local  branch, so that user can map the limits of the logged in branch for unlock operation
**  Search String      : Fcubs_12.4_SAIGON COMMERCIAL BANK_Bug_27894587

** Modified by            : Shilesh Mathew
** Modified On            : 18-MAY-2018
** Modified Reason        : Limit Details are not appearing when we are visited the Limit screen if we make Track Liability as Default and  not visited the Additional tab.
** Search string          : Bug_28038515

**  Changed by         : Saurav Jaiswal
**  Changed On         : 30-Jul-2018
**  Change Description : Issue : When user visited any tab other than check list tab, and clicked on COPY button, one record was still not being deleted in the check list tab.
						 Fix   : Modified code to delete all the records from check list tab, when user clicked on the copy button.
**  Search String      : FCUBS_12.4_BANK_OF_SOUTH_PACIFIC_CNSL_Bug#28389441

** Modified by            : Shilesh Mathew
** Modified On            : 23-AUG-2018
** Modified Reason        : 28510495: STDCIF : FNPOSTCOPY_CUSTOM IS NOT GETTING CALLED
** Search string          : Bug_28510495

** Modified by            : Saloni Rai
** Modified On            : 30-Nov-2018
** Modified Reason        : -Code added to populate the same customer name present in the main screen correctly in the limits screen (Retro of 27555873)
                            -Changes done to allow viewing customers belonging to different branches when multi-branch access is enabled for STDCIF. (Retro of 28646586)
							-Commented the code so that the navigation should not happen when the user visited the SSN field. (Retro of 27372434 )
** Search string          : Bug_28995677

** Modified by            : Gowthami R
** Modified On            : 02-Apr-2019
** Modified Reason        : Issue : For Modify action, user was able to amend the Revision Date field in limits subscreen and save, but on query, system was retaining the older value.
							Fix   : Changes done to disable all the fields in limits subscreen for the Modify action, as liability linkage is only supported during New action. For modify case,
							        user should visit the LM screens and perform the required amendability.
** Search string          : Bug_29491312

**  Modified By            : Partha Sarmah	
**	Modofied On            :12-March-2020
**	Modified Reason        : The Minimum telephone number length has been updated from 7 to 5.
**	Search String          : FCUBS_12.4->BANK OF SOUTH PACIFIC LTD->SFR#31023482

** Modified by            : Vibilash Arumugam
** Modified On            : 17-Nov-2021
** Modified Reason        : Issue : Limits details are not getting viewed when user tries to query after saved using non-auto auth user.
							Fix   : Changes done by using AND condition instead of OR condition since LOADLIAB is been called twice 
							        while using OR conditon and hence values are not getting retained in limits tab after save.
** Search string          : 9NT1606_12.4_CNSL_33502861

 //------------------------------------------------------------------------------
// VARIABLE DECLARATIONS
//------------------------------------------------------------------------------
/*
FCUBS_12.0.0 Usabiity changes
LBRN Field changed to BRNCD
CTYPE Field changed to CUSTTYPE
CREATEACC Field changed to AUTO_CREATE_ACCOUNT
FXNETTCUST Field changed to FXNETCUST
XREF Field changed to EXREFNO
LIABID Field changed to LIABNO
SPEMPSTATUS Field changed to SPOUSTAT
NAME Field changed to CNAME
BLK_CUSTPERSONAL Block name changed to BLK_PERSONAL
BLK_CUSTCORP Block name changed to BLK_CORPORATE

*/
/*
FCUBS_12.0.0 Usabiity field name change
FCUBS_12.0.0 Usabiity changes changes have been reverted back
BLK_CUSTOMER__CNTY chnaged to BLK_CUSTOMER__COUNTRY
BLK_CUSTOMER__ADDR1 changed to BLK_CUSTOMER__ADDRLN1
*/


var fcjRequestDOM;
var fcjResponseDOM;
var gPrevAction;
var flgSuccess = 1;
var gErrCodes = "";
var l_headerTabPage = 'CVS_MAIN';
var radiolength;
var l_Custno;

ArrFuncOrigin["SVCCIFOL"]="KERNEL";
ArrPrntFunc["SVCCIFOL"]="";
ArrPrntOrigin["SVCCIFOL"]="";
ArrRoutingType["SVCCIFOL"]="X";
queryFields[0] = "BLK_CUSTOMER__CUSTNO";
queryFields[1] = "BLK_CUSTOMER__LBRN"; //ITR1#53
pkFields[0] = "BLK_CUSTOMER__CUSTNO";
pkFields[1] = "BLK_CUSTOMER__LBRN"; //ITR1#53

// LIMITS_11.3.1 initialization starts
var limitArgs = new Object();
limitArgs.isLoaded = false;
limitArgs.isReadOnly = false;
limitArgs.iChanged = false;
limitArgs.isAuthorized = false;
limitArgs.isAccountLocked = false; // FCUBS_11.3.1 CIF_CASA changes
// LIMITS_11.3.1 initialization ends here
limitArgs.CIFGenerated = false; //FCUBS_12.0.0 Usabiity changes
// LIMITS_11.3.1 utility functions starts
function fnResetLimitArgs() {
	limitArgs = new Object();
	limitArgs.isReadOnly = false;
	limitArgs.iChanged = false;
	limitArgs.isLoaded = false;
	limitArgs.isAuthorized = false;
}

function fnProcessAction(action, elemToAppend) {
	if (gAction) {
		var prevAction = gAction;
		gAction = action;
		if (elemToAppend) {
			appendData(elemToAppend);
		} else {
			appendData();
		}
		fcjRequestDOM = buildUBSXml();
		fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
		// hide success response alert // 11.3.1 shows "Response processed suceessfully" message on each request.
		showProcessMsg = false;
		var l_resp_code = fnProcessResponse();
		gAction = prevAction;
		return l_resp_code;
	}
	return false;
}

// Enabling/Disabling sections may have INFRA version specific code.
function fnDisableAllSubSystemButtons() {
	var subSysButtonList = document.getElementById('DIVSubSystem').children[0].children;
	var subSysButtonListLength = subSysButtonList.length;
	for (var i = 0; i < subSysButtonListLength; i++) {
		var elem = subSysButtonList[i].children[0];
		fnDisableSubSystemButton(elem);
	}
}

function fnEnableAllSubSystemButtons() {
	var subSysButtonList = document.getElementById('DIVSubSystem').children[0].children;
	var subSysButtonListLength = subSysButtonList.length;
	for (var i = 0; i < subSysButtonListLength; i++) {
		var elem = subSysButtonList[i].children[0];
		fnEnableSubSystemButton(elem);
	}
}

function fnDisableSubSystemButton(elem) {
	if (elem.onclick) {
		elem.onmouseover0 = elem.onmouseover;
		elem.onfocus0 = elem.onfocus;
		elem.onmouseout0 = elem.onmouseout;
		elem.onblur0 = elem.onblur;
		elem.onkeydown0 = elem.onkeydown;
		elem.onclick0 = elem.onclick;
		elem.onmouseover = elem.onfocus = elem.onmouseout = elem.onblur = elem.onkeydown = elem.onclick = null;
		elem.className = 'AbuttonD';
	}
}

function fnEnableSubSystemButton(elem) {
	if (elem.onclick0 && !elem.onclick) {
		elem.className = 'Abutton';
		elem.onmouseover = elem.onmouseover0;
		elem.onfocus = elem.onfocus0;
		elem.onmouseout = elem.onmouseout0;
		elem.onblur = elem.onblur0;
		elem.onkeydown = elem.onkeydown0;
		elem.onclick = elem.onclick0;
	}
}

function fnDisableAllTabs() {
	var tablist0 = document.getElementById('tablist').children;
	var tablist0length = tablist0.length;
	for (var i = 0; i < tablist0length; i++) {
		var elem = tablist0[i].children[0];
		if (elem.onclick) {
			elem.onmouseover0 = elem.onmouseover;
			elem.onfocus0 = elem.onfocus;
			elem.onmouseout0 = elem.onmouseout;
			elem.onblur0 = elem.onblur;
			elem.onkeydown0 = elem.onkeydown;
			elem.onclick0 = elem.onclick;
			elem.onmouseover = elem.onfocus = elem.onmouseout = elem.onblur = elem.onkeydown = elem.onclick = null;
			if (tablist0[i].id != 'current')
			{
				elem.className = 'Htabdsb';
				}
		}
	}
}

function fnEnableAllTabs() {
	var tablist0 = document.getElementById('tablist').children;
	var tablist0length = tablist0.length;
	for (var i = 0; i < tablist0length; i++) {
		var elem = tablist0[i].children[0];
		if (elem.onclick0 && !elem.onclick) {
			if (tablist0[i].id != 'current')
				elem.className = 'Htaball';
			elem.onmouseover = elem.onmouseover0;
			elem.onfocus = elem.onfocus0;
			elem.onmouseout = elem.onmouseout0;
			elem.onblur = elem.onblur0;
			elem.onkeydown = elem.onkeydown0;
			elem.onclick = elem.onclick0;
		}
	}
}

function prepareCIF() {
	fnResetLimitArgs(); // LIMITS_11.3.1 starts
	disableForm();
	fnDisableAllSubSystemButtons();
	fnDisableAllTabs(); // LIMITS_11.3.1 ends // defaulting cust no. moved to fnOnClickBtnPopulate
	
	fnEnableElement(document.getElementById("BLK_CUSTOMER__CUSTNO"));
	fnEnableElement(document.getElementById("BLK_CUSTOMER__BTN_P"));
	fnEnableElement(document.getElementsByName("CTYPE")[0]);
	fnEnableElement(document.getElementsByName("CTYPE")[1]);
	fnEnableElement(document.getElementsByName("CTYPE")[2]);
	//loan sector changes sampath starts
	fnEnableElement(document.getElementsByName("CTYPE")[3]);
	fnEnableElement(document.getElementsByName("CTYPE")[4]);
	fnEnableElement(document.getElementsByName("CTYPE")[5]);
	fnEnableElement(document.getElementsByName("CTYPE")[6]);
	//loan sector changes sampath ends
	//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range starts
	fnEnableElement(document.getElementsByName("SPECIAL_CUST")[0]);
	//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range ends
	
}

function fnDisableKeyFields() {
	fnDisableElement(document.getElementsByName("LBRN")[0]);
	fnDisableElement(document.getElementById("BLK_CUSTOMER__CUSTNO"));
	fnDisableElement(document.getElementById("BLK_CUSTOMER__BTN_P"));
	fnDisableElement(document.getElementsByName("CTYPE")[0]);
	fnDisableElement(document.getElementsByName("CTYPE")[1]);
	fnDisableElement(document.getElementsByName("CTYPE")[2]);
	//loan sector changes sampath starts
	fnDisableElement(document.getElementsByName("CTYPE")[3]);
	fnDisableElement(document.getElementsByName("CTYPE")[4]);
	fnDisableElement(document.getElementsByName("CTYPE")[5]);
	fnDisableElement(document.getElementsByName("CTYPE")[6]);
	//loan sector changes sampath ends
	//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range starts
	//fnDisableElement(document.getElementsByName("SPECIAL_CUST")[0]); commented 25086617_ORIENBANK
	//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range ends
}

function fnDisableAllUnderBlock(blockId) {
	// FC11.4 ITR1 BUG 13081807 - AUTO LIABILITY CREATION START
	/*var rootElem = document.getElementById(blockId);
	var elems = selectNodes(rootElem, '//input[@type!="HIDDEN" and @type!="Hidden" and @type!="button"]');
	for ( var i = 0; i < elems.length; i++) {
		fnDisableElement(elems[i]);
	}*/
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__LIAB_NO"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__LIAB_NAME"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__MAIN_LIAB_NO"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__LIAB_BRANCH"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__LIAB_CCY"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__OVERALL_LIMIT"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__UTIL_AMOUNT"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__REVISION_DATE"));
	var el = document.getElementById("BLK_CUST_LIAB__REVISION_DATE").parentNode.getElementsByTagName("Button")[0];
	if (el)
		el.className = 'BTNhide';
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__CR_RATING"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__OVERALL_SCORE"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__USER_DEFINE_STATUS"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__CATEGORY"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__FX_CLEAN_RISK_LIMIT"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__SEC_CLEAN_RISK_LIMIT"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__SEC_PSTL_RISK_LIMIT"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__UNADVISED"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__NETTING_REQUIRED"));
	fnDisableElement(document.getElementById("BLK_CUST_LIAB__REMARKS"));
	// FC11.4 ITR1 BUG 13081807 - AUTO LIABILITY CREATION START
}

function eraseDataOf(block) {
	var l_node = selectSingleNode(dbDataDOM, '//' + block);
	var removedNode = l_node.parentNode.removeChild(l_node);
	showData();
	return removedNode;
}

function initCap(text) {
	var ar = text.split('_');
	for (var i = 0; i < ar.length; i++) {
		ar[i] = ar[i].substring(0,1).toUpperCase() + ar[i].substring(1,ar[i].length).toLowerCase();
	}
	return ar.join(' ');
}

// INFRA specific style correction code
function fnSwitchToUDFMode(fieldSet, readOnlyMode) {
	fieldSet.parentNode.parentNode.parentNode.style.marginTop = "0px";
	fieldSet.children[1].style.visibility = 'hidden';
	fieldSet.parentNode.style.overflow = 'auto';
	fieldSet.parentNode.style.border = '0';

	var li = fieldSet.children[2].children;
	for (var i = 0; i < li.length; i++) {
		var st = li[i].children;
		st[0].style.visibility = 'hidden';
		for (var j = 1; j < st.length; j++) {
			if (j == 2) {
				switch(st[3].children[1].value) { // fld_typ - [NTDC] - Number, Text, Date, CubeEntity
					case 'N':
						st[j].children[1].className = "TXTstd numeric";
						break;
				}
				switch(st[4].children[1].value) { // validation_typ - [LMRVN] - Length, Mask, Range, LOV, None
					case 'V':
						break;
					default:
						st[j].children[2].style.visibility = 'hidden';
						st[j].children[1].onblur = null;
				}
				st[j].style.border = '0';
				st[j].children[0].htmlFor = st[j].children[1].id;
				st[j].children[0].innerHTML = initCap(st[1].children[1].value);
				st[j].children[0].className = "LBLstd";
				continue;
			} else if (j == 3 && readOnlyMode) {
				st[j].className = "TDgrid";
			} else {
				st[j].className = "TDnone";
			}
		}
	}
}
// LIMITS_11.3.1 utility functions ends

//12.2_SUPPORT_RETRO_23658059 starts
function fnPostFocus_KERNEL() { 
    if (!(typeof (multiBrnAccessReq) != "undefined" && multiBrnAccessReq == 
     "Y" && mainWin.multiBranchOperation == "Y") ){ 
        if( document.getElementsByName("LBRN")[0].value != mainWin.CurrentBranch){ 
            DisableToolbar_buttons("Authorize"); 
        } 
    } 
    return true; 
}
//12.2_SUPPORT_RETRO_23658059 ends
function fnPostLoad_KERNEL() {
try {
//12.1 customer Landing page changes  starts
if(typeof(mainWin.gCustInfo["CustNo"])!= 'undefined' && mainWin.gCustInfo["CustNo"]!='')
{
gAction = "ENTERQUERY";     
      fnEnterQuery();
 document.getElementById("BLK_CUSTOMER__CUSTNO").value = mainWin.gCustInfo["CustNo"]; 
gAction= "EXECUTEQUERY";
fnExecuteQuery();
}
//12.1 customer Landing page changes  ends
		fnResetLimitArgs(); // LIMITS_11.3.1
		//document.getElementById('BLK_CUSTOMER__CREATEACC').onclick = fnEnableDisableAcc();
                 //FCUBS_12.2_RETRO_BUG#24294856 starts
		//commented
		/*
		if (parent.screenArgs && parent.screenArgs['PARENT_FUNC_ID'] == "STDBRREF") {
			fnPostLoad_CVS_MAIN_VIEWLOG();
		}
                */

                 if (parent.screenArgs != undefined)
		{ 
		if (parent.screenArgs['PARENT_FUNC_ID'] == "STDBRREF") 
	        {
		fnPostLoad_CVS_MAIN_VIEWLOG();
               }
		}  
		//FCUBS_12.2_RETRO_BUG#24294856 ends
		//FCUBS_12.0.0 Usabiity changes by Gokul
		if (functionId == 'STDCIFAD' ){
			//setInnerText(document.getElementById('STCCUACC').firstChild, 'Add Account'); -- 9NT1587_FCUBS_12.0.2_17043430 Changes
			setInnerText(document.getElementById('STCCUACC').getElementsByTagName("A")[0], 'Add Account'); // 9NT1587_FCUBS_12.0.2_17043430 Changes
		}
		//FCUBS_12.0.0 Usabiity changes by Gokul
		  //FC12.0_CITI120_16679039
		if (viewMnt)
		{
			fnCTYPEChange(); 
		}
		//FC12.0_CITI120_16679039
		//19901232 Changes starts
		if (parent.screenArgs != undefined)
		{
			if(parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCREQ" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDAMLAI" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDAMLCV" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDAMLRB" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCAUT" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCCLM" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCELC" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCENR" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCIBK" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCIPD" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCRAD" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCSAA" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCSCL" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCSDN" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDSTDOC" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDLCVER" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDAMLSM" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDAMLBL" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDAMLVD" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDAMLVT" || parent.screenArgs["PARENT_FUNC_ID"] == "ORDRFATM"|| parent.screenArgs["PARENT_FUNC_ID"] == "ORDRNATM"|| parent.screenArgs["PARENT_FUNC_ID"] == "ORDAMSIM"|| parent.screenArgs["PARENT_FUNC_ID"] == "ORDRPYTM"|| parent.screenArgs["PARENT_FUNC_ID"] == "ORDRPPTM"|| parent.screenArgs["PARENT_FUNC_ID"] == "ORDRDSTM")
			{
			fnEnterQuery();
			document.getElementById('BLK_CUSTOMER__CUSTNO').value	= parent.screenArgs['CUSTNO'];
		       gAction= "EXECUTEQUERY";
		       fnExecuteQuery();
			document.getElementById("navTB").getElementsByTagName("li")[0].style.display = 'none';
			document.getElementById("navTB").getElementsByTagName("li")[1].style.display = 'none';
			document.getElementById("navTB").getElementsByTagName("li")[3].style.display = 'none';
			document.getElementById("navTB").getElementsByTagName("li")[4].style.display = 'none';
			document.getElementById("navTB").getElementsByTagName("li")[6].style.display = 'none';
			document.getElementById("navTB").getElementsByTagName("li")[7].style.display = 'none';
			document.getElementById("navTB").getElementsByTagName("li")[17].style.display = 'none';
			document.getElementById("navTB").getElementsByTagName("li")[18].style.display = 'none';
		       }
			parent.screenArgs = null;
		}
		//19901232 Changes ends
		//9NT1606_12_2_RETRO_12_0_3_23654974 starts
		 if (!(typeof (multiBrnAccessReq) != "undefined" && multiBrnAccessReq == 
				"Y" && mainWin.multiBranchOperation == "Y") )
		{ 
			if( document.getElementsByName("LBRN")[0].value != mainWin.CurrentBranch){ 
				DisableToolbar_buttons("Authorize"); 
                //1203_21752864 starts
				DisableToolbar_buttons("Delete");
				DisableToolbar_buttons("Unlock");
				//1203_21752864 ends
				
			} 
		}		
		//9NT1606_12_2_RETRO_12_0_3_23654974 ends
		return true;
	} catch(e) {return false;}

}

function fnPreNew_KERNEL() {
	alertAction='';
	fnShowTxnBrnScreen();
	return true;
}

function fnPostNew_KERNEL() {
	prepareCIF();
	document.getElementById("BLK_CUSTOMER__CUSTNO").focus(); ////9NT1501 ITR1 13958683
	
    return true;
}

function fnPostCopy_KERNEL() {
	fnResetLimitArgs(); // LIMITS_11.3.1
	var resp = fnProcessAction('COPY', document.getElementById('TBLPageTAB_HEADER')); // LIMITS_11.3.1
	var l_cust_no = document.getElementById("BLK_CUSTOMER__CUSTNO").value;
	//Bug#25209669 Starts
    //var count = 1;  //Bug_28510495 Commented
	var count = 0;    //Bug_28510495 Added 
    var table = document.getElementById('BLK_CUSTDOC_CHKLIST');
    var rowCount = table.rows.length;
	//Bug_28510495 rolling back Bug#28389441 changes
    //FCUBS_12.4_BANK_OF_SOUTH_PACIFIC_CNSL_Bug#28389441 starts
	for (var i = count; i < rowCount; i++) {
	//for (var i = count; i <= rowCount; i++) {	
	//FCUBS_12.4_BANK_OF_SOUTH_PACIFIC_CNSL_Bug#28389441 ends
    //Bug_28510495 rollback ends	
         table.deleteRow(count);
    }
    //Bug#25209669 Ends
	if (resp != 'SUCCESS' || !l_cust_no) {
		prepareCIF();
		return true;
	}

	if (l_cust_no) {
		enableForm();		
		disableMESVFields();//9NT1620_1203_MAT_18273112 added
		fnDisableKeyFields(); // LIMITS_11.3.1
		
		document.getElementById("BLK_CUSTOMER__FXNETTCUST").value = l_cust_no;
		document.getElementById("BLK_CUSTOMER__SNAME").value = "";
		document.getElementById("BLK_CUSTOMER__XREF").value = "";
		document.getElementById("BLK_CUSTOMER__SSN").value = "";
		// LIMITS_11.3.1 starts
		if (document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked) {
			document.getElementById("BLK_CUSTOMER__LIABID").value = l_cust_no;
		} else {
			fnDisableElement(document.getElementById("BLK_CUSTOMER__LIABID"));
		}
		// LIMITS_11.3.1 ends
		
		// 1202_INTERNAL_17646118 changes
		if (document.getElementById("BLK_CUSTOMER__ISELCMCUST").checked) {
			document.getElementById("BLK_CUSTOMER__ELCMCUSTNO").value = l_cust_no;
		} else {
			document.getElementById("BLK_CUSTOMER__ELCMCUSTNO").value = "";
		}
		// 1202_INTERNAL_17646118 changes		

		if (functionId == 'STDCIF') {
			if (document.getElementsByName("CTYPE")[2].checked){
				//fnDisableBank();
			}
		}
		fnCTYPEChange(); //FCUBS_12.0.0 Usabiity changes  //FCUBS 12.0 itr2 sfr#14004922 
	} else {
		disableForm();
	}
	 //FCUBS_MF12.0.1_to_MF12.0.2_Port Starts
	if (document.getElementById("BLK_CUSTOMER__MFI_CUSTOMER").checked) {
		enableTabs("TAB_MFI"); 
	}else {
		disableTabs("TAB_MFI");
	}
	//FCUBS_MF12.0.1_to_MF12.0.2_Port Ends	
    limitArgs.CIFGenerated = true; //9NT1620_1203_19059946
	appendAllData();   //[FCUBS_12.3_ITR1_25050083] added
	return true;
}

function fnPostEnterQuery_KERNEL() {
	fnEnableElement(document.getElementsByName("CUSTNO")[0]);
	document.getElementsByName("CUSTNO")[0].readOnly = false;
	document.getElementsByName("LBRN")[0].value = mainWin.CurrentBranch;
	fnDisableElement(document.getElementsByName("LBRN")[0]);//ITR1#53
	fnEnableElement(document.getElementsByName("BTN_EXIT")[0]);
	return true;
}

function fnPreExecuteQuery_KERNEL() {
	appendData(document.getElementById("TBLPageTAB_MAIN"));
	tmp_multiBrnAccessReq = multiBrnAccessReq;//Bug_28995677
	multiBrnAccessReq = "N" ;//Bug_28995677
	return true;
}

function fnPostExecuteQuery_KERNEL() {
	multiBrnAccessReq = tmp_multiBrnAccessReq; //Bug_28995677
	fnResetLimitArgs(); // LIMITS_11.3.1
	//FCUBS_12.0.0 Usabiity changes starts
	fnCTYPEChange();  //FCUBS 12.0 itr2 sfr#14004922 
	
	//12.1_21064673 starts
	//following code commneted since its failing for coperate CIF alone during ITR2 closure for 12.1
	/* if(getNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/ONCEAUTH"))== 'Y') {
		limitArgs.isAuthorized = true;
		//fnDisableSubSystemButton(document.getElementById('STCCUACC').firstChild); //1202_17772903 //12.1_21064673 commented
		fnDisableSubSystemButton(document.getElementById('STCCUACC').children[0]); //12.1_21064673  added		
	}	
	if (document.getElementsByName("CTYPE")[0].checked != true)
	{
		fnDisableSubSystemButton(document.getElementById('CVS_DOM').children[0]);
		fnDisableSubSystemButton(document.getElementById('CVS_PROF').children[0]);
	} */
	//12.1_21064673 ends
	if (document.getElementsByName("CTYPE")[1].checked == true) {
	expandcontent('TAB_CORPORATE');
		document.getElementById("BLK_CUSTPERSONAL__TEL").value = '';
		document.getElementById("BLK_CUSTPERSONAL__FAX").value = '';
		document.getElementById("BLK_CUSTPERSONAL__EMAIL").value = '';
		//document.getElementById("BLK_CUSTPERSONAL__MOBILE_NUMBER").value = '';// 9NT1620#1203RETRO#18844414 commented
		document.getElementById("BLK_CUSTPERSONAL__MOBNUM").value = '';  // 9NT1620#1203RETRO#18844414Added
		document.getElementById("BLK_CUSTOMER__ADDRLN1").value = '';
		// 9NT1620#1203RETRO#18844414commented starts
		//document.getElementById("BLK_CUSTOMER__ADDR2").value = '';
		//document.getElementById("BLK_CUSTOMER__ADDR3").value = '';
		//document.getElementById("BLK_CUSTOMER__ADDR4").value = '';
			// 9NT1620#1203RETRO#18844414commented ends	
		// 9NT1620#1203RETRO#18844414Changes starts
		document.getElementById("BLK_CUSTOMER__ADDRLN2").value = '';
		document.getElementById("BLK_CUSTOMER__ADDRLN3").value = '';
		document.getElementById("BLK_CUSTOMER__ADDRLN4").value = '';
		// 9NT1620#1203RETRO#18844414Changes ends
		document.getElementById("BLK_CUSTOMER__NAME").value = '';
		document.getElementById("BLK_CUSTOMER__COUNTRY").value = '';
		document.getElementById("BLK_CUSTOMER__NLTY").value = '';
		document.getElementById("BLK_CUSTPERSONAL__LANG").value = '';
		// 9NT1620#1203RETRO#18844414commented starts
		//document.getElementById("BLK_CUSTPERSONAL__COMM_MODE").value = '';
		//document.getElementById("BLK_CUSTPERSONAL__KYC_REF_NO").value = '';
		//document.getElementById("BLK_CUSTPERSONAL__KYC_STATUS").value = 'N';
		// 9NT1620#1203RETRO#18844414commented ends	
		// 9NT1620#1203RETRO#18844414Changes starts
		document.getElementById("BLK_CUSTPERSONAL__CUST_COMM_MODE").value = '';
		document.getElementById("BLK_CUSTPERSONAL__KYCREFNO").value = '';
		document.getElementById("BLK_CUSTPERSONAL__KYCSTAT").value = 'N';
		// 9NT1620#1203RETRO#18844414Changes ends
	}
	//FCUBS_12.0.0 Usabiity changes ends
	//9NT1620#1203RETRO#19322716  commented starts
	//Commented the code as the fields referred is available in additional tab which is resulting in failure and the same is handled in the function   fnInTab_TAB_ADDITIONAL_KERNEL
//FC12.0.2_Combined_statement Starts
	/*var freq =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUSTOMER/FREQ"));
	var stmtDay =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUSTOMER/STMTDAY"));
    document.getElementsByName('FREQ')[0].value = freq;
	fnpopulate('FREQ','STMTDAY');
	document.getElementsByName('STMTDAY')[0].value = stmtDay;
//FC12.0.2_Combined_statement Ends	
 //9NT1606# 1202SUPPORT#17999926 changes starts
 // moved the code from the other post execute query to here
document.getElementsByName("BTN_IDENTIDET")[0].disabled = false;
document.getElementsByName("BTN_CHKLIST")[0].disabled = false;
//9NT1606# 1202SUPPORT#17999926 changes ends 
	*/
//9NT1620#1203RETRO#19322716  commented starts
//9NT1606_12_2_RETRO_12_0_3_23654974 starts
	if (!(typeof (multiBrnAccessReq) != "undefined" && multiBrnAccessReq == "Y"
        && mainWin.multiBranchOperation == "Y") ){ 
        if( document.getElementsByName("LBRN")[0].value != mainWin.CurrentBranch){ 
            DisableToolbar_buttons("Authorize"); 
            //1203_21752864 starts
			DisableToolbar_buttons("Delete");
			DisableToolbar_buttons("Unlock");
			//1203_21752864 ends
				
        } 
    } 
//9NT1606_12_2_RETRO_12_0_3_23654974 ends
	return true;
}
function fnPostUnlock_KERNEL() {
	fnResetLimitArgs(); // LIMITS_11.3.1
	fnDisableKeyFields(); // LIMITS_11.3.1
	// LIMITS_11.3.1 starts
	if(getNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/ONCEAUTH"))== 'Y') {
		limitArgs.isAuthorized = true;
		fnDisableSubSystemButton(document.getElementById('STCCUACC').firstChild); //9NT1462 ITR 13064575 changes
	}
	if (document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked) {
		limitArgs.isLoaded = true;
	} else {
		fnDisableElement(document.getElementById("BLK_CUSTOMER__LIABID"));
	}
	// LIMITS_11.3.1 ends
	if (document.getElementById("BLK_CUSTOMER__CREATEACC").checked) {
		limitArgs.isAccountLocked = true;
	}
	//FCUBS_12.0.0 Usabiity changes starts
	if (functionId == 'STDCIF') {
		if (document.getElementsByName("CTYPE")[2].checked){
			//fnDisableBank();
		}
	}
	fnCTYPEChange(); //FCUBS 12.0 itr2 sfr#14004922 
	//FCUBS_12.0.0 Usabiity changes ends
	//FCUBS_MF12.0.1_to_MF12.0.2_Port Starts
	document.getElementById("cmdAddRow_BLK_TRAINING").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_TRAINING").style.visibility="HIDDEN";
	//FCUBS_MF12.0.1_to_MF12.0.2_Port Ends	
	return true;
}

function fnPreSave_KERNEL() {
	// LIMITS_11.3.1
	//121_21064380 commented starts
	/*if (document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked && !limitArgs.isLoaded) {
		showErrorAlerts('ST-CIF-L001');
		return false;
	}*/
	//121_21064380 commented ends
	//121_21064380 changes starts
	if (typeof(document.getElementById("BLK_CUSTOMER__TRACK_LIMITS")) != 'undefined' && document.getElementById("BLK_CUSTOMER__TRACK_LIMITS") != null) 	
	{
	if (document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked && !limitArgs.isLoaded) 
	{
	showErrorAlerts('ST-CIF-L001');
		return false;
	}
	}
	else
	{
	if ((getNodeText( selectSingleNode(dbDataDOM,"BLK_CUSTOMER/TRACK_LIMITS")))=='Y'  && !limitArgs.isLoaded) {
	showErrorAlerts('ST-CIF-L001');
		return false;	
		}
	}
	//121_21064380 changes ends
	return true;
}

function fnPostLoad_CVS_DOM_KERNEL(screenArgs) {
	

//19171099 starts
		 var l_custype = "";
	     l_custype =  dbDataDOM.selectSingleNode("//BLK_CUSTOMER/CTYPE").text;
		 if (l_custype != 'B' && l_custype != 'C')
	     {
	   //19171099 ends
	fnValidateMaritialStatus('');
	return true;
	   //19171099 starts
		 }
		 else
		 {
			document.getElementsByName("BLK_CUSTDOMESTIC__EDUSTAT").value=null;
			document.getElementsByName("BLK_CUSTDOMESTIC__MARITALSTAT").value=null;
			document.getElementsByName("BLK_CUSTDOMESTIC__SPNAME").value=null;
			document.getElementsByName("BLK_CUSTDOMESTIC__SPEMPSTATUS").value=null;
			document.getElementsByName("BLK_CUSTDOMESTIC__DEPCHILD").value=null;
			document.getElementsByName("BLK_CUSTDOMESTIC__DEPOTH").value=null;
			document.getElementsByName("BLK_CUSTDOMESTIC__ACCOMODATE").value=null;
			return true;
				}

	  //19171099 ends


}

function fnPostLoad_CVS_IRA(screenArgs) {
	document.getElementById("STVWS_CUSTIRA__CUSTNO").value = screenArgs['CUSTNO'];
	document.getElementById("BLK_CUSTOMER__NAME").value = screenArgs['NAME'];
}

function fnPreLoad_CVS_CUSTOMER_KERNEL(screenArgs) {
	screenArgs['CUSTNO'] = document.getElementsByName("CUSTNO")[0].value;
	return true;
}

function fnPreLoad_CVS_CUST_TEXT_KERNEL(screenArgs) {
	screenArgs['CUSTNO'] = document.getElementsByName("CUSTNO")[0].value;
	return true;
}

function fnPreLoad_CVS_SUMM_DIARY_KERNEL(screenArgs) {
	screenArgs['CUSTNO'] = document.getElementsByName("CUSTNO")[0].value;
	return true;
}

function fnPreLoad_CVS_JOINTADDRESS_KERNEL(screenArgs) {
	//1201_IDTKEKE_17190226  starts
	   var jointChecked = false;
             if (document.getElementById("BLK_CUSTOMER__FLGJOINT") != null)
                  {  // 1201_IDTKEKE_16722640 ends	  
	var jointChecked = document.getElementById("BLK_CUSTOMER__FLGJOINT").checked;
	  } //1201_IDTKEKE_17190226  added
		if( jointChecked == false && gAction != ""){
		//alert("Please select as Joint Customer.");
		showErrorAlerts('IN-HEAR-403');//NLS change -Removal of hardcoded alerts
		return false;
	}
	screenArgs['CUSTNO'] = document.getElementsByName("CUSTNO")[0].value;
	return true;
}

//FCUBS10.5 STR1 4089
function fnPreLoad_CVS_ISSUER_KERNEL(screenArgs) {
	var IssuerChecked = document.getElementById("BLK_CUSTOMER__ISSUCUST").checked;
	if( IssuerChecked == false && gAction != ""){
		//alert("Please select as Issuer Customer.");
		showErrorAlerts('IN-HEAR-404');//NLS change -Removal of hardcoded alerts
		return false;
	}
	screenArgs['CUSTNO'] = document.getElementsByName("CUSTNO")[0].value;
	return true;
}

//FCUBS10.5 STR1 4089
function fnPreLoad_CVS_RELATIONSHIP_KERNEL(screenArgs) {
	screenArgs['CUSTNO'] = document.getElementsByName("CUSTNO")[0].value;
	screenArgs['DESP']=document.getElementsByName("FULLNAME")[0].value;    //9NT1606# 1202SUPPORT#17910544  Added in order to pass the Primary Customer name to the Linked entities sub screen
	

	return true;
}

/**
  * Function called when Authorize action is performed
  */

function fnPostLoad_Summary() {
	document.getElementsByName("LBRN")[0].value = mainWin.CurrentBranch;
	//document.getElementsByName("LBRN")[0].disabled = true;
	fnDisableElement(document.getElementsByName("LBRN")[0]);//ITR1#53
}

/**
This function will enable and disable employee
details depending upon the the employee stattus
Added By Saidul EMERGE
*/

function fnValidateEmpStatus(elment) {
	var radioObj = document.getElementsByName("EMPNT");
	for(var i = 0; i<radioObj.length;i++) {//for loop
		if(radioObj[i].checked) {
			var radioValue = radioObj[i].value;
			if(radioValue == "U") {
				fnDisableElement(document.getElementById("BLK_PROF__EMPNT"));
				fnDisableElement(document.getElementById("BLK_PROF__RAGE"));
				fnDisableElement(document.getElementById("BLK_PROF__PRDESIG"));
				fnDisableElement(document.getElementById("BLK_PROF__PREMP"));
				fnDisableElement(document.getElementById("BLK_PROF__CURDESIG"));
				fnDisableElement(document.getElementById("BLK_PROF__CUREMP"));
			} else {
				fnEnableElement(document.getElementById("BLK_PROF__EMPNT"));
				fnEnableElement(document.getElementById("BLK_PROF__RAGE"));
				fnEnableElement(document.getElementById("BLK_PROF__PRDESIG"));
				fnEnableElement(document.getElementById("BLK_PROF__PREMP"));
				fnEnableElement(document.getElementById("BLK_PROF__CURDESIG"));
				fnEnableElement(document.getElementById("BLK_PROF__CUREMP"));
			}//end else
		}//end if
	}//end for
}

/*
The following functions are added to validate Emil,Fax,phone number etc
*/

//FCUBS_12.0.0 DMS changes starts
function fnPreLoad_CVS_UPDOC_KERNEL(screenArgs) {
	
	screenArgs['FLAG_STATUS'] = 'true';
	screenArgs['FUNCT_ID'] = functionId;
	return true;
}
// FCUBS_12.0.0 DMS changes ends

function fnValidateFax(elment) {
	fnValidateTelNo(elment);
}

function fnValidateTelex(elment) {
	fnValidateTelNo(elment);
}

////Phone Number Validation Starts added By Saidul

function fnValidateTelNo(elment) {
	var id =elment.id;
	var Phone = document.getElementById(id);
	if(!(Phone.value)) {
		return true;
	} else if(checkInternationalPhone(Phone.value)==false) {
		//alert("Please Enter a Valid Number")
		showErrorAlerts('IN-HEAR-405');//NLS change -Removal of hardcoded alerts
		Phone.value="";
		Phone.focus();
		return false;
	}
}

// Declaring required variables
var digits = "0123456789";
// non-digit characters which are allowed in phone numbers
var phoneNumberDelimiters = "()- ";
// characters which are allowed in international phone numbers
// (a leading + is OK)
var validWorldPhoneChars = phoneNumberDelimiters + "+";
// Minimum no of digits in an international phone no.
//Bug#17188227  
//SNORAS RETRO SFR#3897 04-FEB-2011 ARUNA STARTS
//var minDigitsInIPhoneNumber = 10; 
//var minDigitsInIPhoneNumber = 8; 
//var minDigitsInIPhoneNumber = 7; // FCUBS_12.4->BANK OF SOUTH PACIFIC LTD->SFR#31023482 commented
  var minDigitsInIPhoneNumber = 5; //FCUBS_12.4->BANK OF SOUTH PACIFIC LTD->SFR#31023482 added
//SNORAS RETRO SFR#3897 04-FEB-2011 ARUNA ENDS
//Bug#17188227  
function isInteger(s) {
	var i;
	for (i = 0; i < s.length; i++) {
		// Check that current character is number.
		var c = s.charAt(i);
		if (((c < "0") || (c > "9"))) {
			return false;
		}
	}
	// All characters are numbers.
	return true;
}

function stripCharsInBag(s, bag) {
	var i;
	var returnString = "";
	// Search through string's characters one by one.
	// If character is not in bag, append to returnString.
	for (i = 0; i < s.length; i++) {
		// Check that current character isn't whitespace.
		var c = s.charAt(i);
		if (bag.indexOf(c) == -1) {
			returnString += c;
		}
	}
	return returnString;
}

function checkInternationalPhone(strPhone) {
	var s = stripCharsInBag(strPhone,validWorldPhoneChars);
	return (isInteger(s) && s.length >= minDigitsInIPhoneNumber);
}

//Phone Number Validation Ends added By Saidul

//Email Address validation Starts Here Saidul:

function fnValidateEmail(elment) {
	var id =elment.id;
	var emailID = document.getElementById(id);
	if(!(emailID.value)) {
		return true;
	} else if(echeck(emailID.value)==false) {
		emailID.value="";
		emailID.focus();
		return false;
	}
}

function echeck(str) {
	var at="@"
	var dot="."
	var lat=str.indexOf(at)
	var lstr=str.length
	var ldot=str.indexOf(dot)
	if (str.indexOf(at)==-1) {
		//alert("Invalid E-mail ID")
		showErrorAlerts('IN-HEAR-406');//NLS change -Removal of hardcoded alerts
		return false;
	}
	if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr) {
		//alert("Invalid E-mail ID")
		showErrorAlerts('IN-HEAR-406');//NLS change -Removal of hardcoded alerts
		return false;
	}
	if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr) {
		//alert("Invalid E-mail ID")
		showErrorAlerts('IN-HEAR-406');//NLS change -Removal of hardcoded alerts
		return false;
	}
	if (str.indexOf(at,(lat+1))!=-1) {
		//alert("Invalid E-mail ID")
		showErrorAlerts('IN-HEAR-406');//NLS change -Removal of hardcoded alerts
		return false;
	}
	if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot) {
		//alert("Invalid E-mail ID")
		showErrorAlerts('IN-HEAR-406');//NLS change -Removal of hardcoded alerts
		return false;
	}
	if (str.indexOf(dot,(lat+2))==-1) {
		//alert("Invalid E-mail ID")
		showErrorAlerts('IN-HEAR-406');//NLS change -Removal of hardcoded alerts
		return false;
	}
	//9NT1606_12_2_RETRO_12_0_2_24604345 starts
	if (str.indexOf(dot,lat)==-1 || str.indexOf(dot,lat)==0 || str.indexOf(dot,lat)==lstr) {
		showErrorAlerts('IN-HEAR-406');
		return false;
	}
	if (str.length < (str.indexOf(dot,lat) + 2) || str.length == (str.indexOf(dot,lat)+1)){
		showErrorAlerts('IN-HEAR-406');
		return false;	
	}	
	//9NT1606_12_2_RETRO_12_0_2_24604345 ends
	if (str.indexOf(" ")!=-1) {
		//alert("Invalid E-mail ID")
		showErrorAlerts('IN-HEAR-406');//NLS change -Removal of hardcoded alerts
		return false;
	}
	return true;
}

//Email Address validation ends Here Saidul:

function fnValidateDependents(element) {
	var id =element.id;
	var dependentObj = document.getElementById(id);
	var dependentCount = dependentObj.value;
	if(dependentCount != null || dependentCount != ""){
		if(dependentCount <0 ||dependentCount >99) {
			//alert("Invalid Dependents Number");
			showErrorAlerts('IN-HEAR-407');//NLS change -Removal of hardcoded alerts
			dependentCount="";
			dependentObj.focus();
			return false;
		}
	}
	return true;
}

function fnValidateMaritialStatus(element) {
	var selectObj = document.getElementById("TBLPageALL").getElementsByTagName("SELECT")[0].getElementsByTagName("OPTION");
	for(var i = 0; i<selectObj.length;i++){//for loop
		if(selectObj[i].selected){
			var selectedValue = selectObj[i].value;
			if(selectedValue == "M" ||selectedValue == "P" ||selectedValue == "R"){
				document.getElementById("BLK_CUSTDOMESTIC__SPNAME").disabled = false;
				document.getElementById("BLK_CUSTDOMESTIC__SPEMPSTATUS").disabled = false;
			} else {
				document.getElementById("BLK_CUSTDOMESTIC__SPNAME").disabled = true;
				document.getElementById("BLK_CUSTDOMESTIC__SPEMPSTATUS").disabled = true;
			}//end else
		}//end if
	}//end for
}

function fnValidateCreditCard(element) {
	var CardId = element.id;
	var CardObj = document.getElementById(CardId);
	var cardVal = CardObj.value;
	if(cardVal != null || cardVal != "") {
		if(cardVal < 0 || cardVal >99) {
			//alert("Invalid Number Of Credit Cards.");
			showErrorAlerts('IN-HEAR-408');//NLS change -Removal of hardcoded alerts
			return false;
		}
	}
	return true;
}

function fnPreLoad_CVS_MAIN_KERNEL(screenArgs) {
	//screenArgs['BRN'] = mainWin.CurrentBranch;  //FCUBS_12.2.0.0.0_SUPPORT_23657519 commented
	screenArgs['BRN'] = document.getElementById("BLK_CUSTOMER__LBRN").value; //FCUBS_12.2.0.0.0_SUPPORT_23657519 added	
	//screenArgs['CUSTNAME']=document.getElementById("BLK_CUSTOMER__NAME").value;  //9NT1620_1203_18295583 commented
	screenArgs['CUSTNAME']=document.getElementById("BLK_CUSTOMER__FULLNAME").value;  //9NT1620_1203_18295583 added
	screenArgs['CUSTNO']=document.getElementById("BLK_CUSTOMER__CUSTNO").value;
	return true;
}

function fnPostLoad_CVS_ISSUER_KERNEL(screenArgs) {
	document.getElementById("BLK_ISSUERDET__ISSUER_ID").value = parent.document.getElementById('BLK_CUSTOMER__CUSTNO').value; //parent.document.getElementById('CUSTNO').value; //9NT1606_12_2_RETRO_12_0_3_24813498
	return true;
}

//Kernel 11.0 - Casa - Debit Card Functionality Changes starts
function fnPreLoad_CVS_CARD_SUMMARY_KERNEL(screenArgs) {
//9NT1462 ITR1 13247536 changes starts
	screenArgs['BRN']=document.getElementById("BLK_CUSTOMER__LBRN").value;
	screenArgs['CUSTNO']=document.getElementById("BLK_CUSTOMER__CUSTNO").value;
	return true;
//9NT1462 ITR1 13247536 changes ends	
	//return !(document.getElementsByName("DIVFooter")[0].children[0].all[28].disabled);
}

function fnPostLoad_CVS_MAIN_VIEWLOG() {
	var codes = new Array();
	createDOM(dbStrRootTableName);
	codes = parent.screenArgs['KEY'].split("|");

	if (codes.length > 0) {
		document.getElementsByName("CUSTNO")[0].value = codes[0];
	}
	document.getElementsByName("MODNO")[0].value = parent.screenArgs['MOD_NO'];

	gAction = 'VIEWMNTLOG';
	functionId = 'STDCIF' ;

	var relationArray = new Array();
	relationArray['BLK_CUSTOMER'] = "";
	relationArray['BLK_CUSTPERSONAL'] = "BLK_CUSTOMER~1";
	relationArray['BLK_CUSTCORP'] = "BLK_CUSTOMER~1";
	relationArray['BLK_CUSTCORPDIR'] = "BLK_CUSTCORP~N";
	relationArray['BLK_CUSTGRP'] = "BLK_CUSTOMER~N";
	relationArray['BLK_CUSTSHHOLD'] = "BLK_CUSTOMER~N";
	relationArray['BLK_CUSTDOMESTIC'] = "BLK_CUSTPERSONAL~1";
	relationArray['BLK_CUSTPROF'] = "BLK_CUSTPERSONAL~1";
	relationArray['BLK_ISSUERDET'] = "BLK_CUSTCORP~1";
	relationArray['BLK_ISSUERLMTS'] = "BLK_ISSUERDET~N";
	relationArray['BLK_CLSCCYREST'] = "BLK_CUSTOMER~N";
	relationArray['BLK_BIC'] = "BLK_CUSTOMER~N";

	var dataSrcLocationArray = new Array();
	dataSrcLocationArray[0] = "BLK_CUSTOMER";
	dataSrcLocationArray[1] = "BLK_CUSTPERSONAL";
	dataSrcLocationArray[2] = "BLK_CUSTCORP";
	dataSrcLocationArray[3] = "BLK_CUSTCORPDIR";
	dataSrcLocationArray[4] = "BLK_CUSTGRP";
	dataSrcLocationArray[5] = "BLK_CUSTSHHOLD";
	dataSrcLocationArray[6] = "BLK_CUSTDOMESTIC";
	dataSrcLocationArray[7] = "BLK_CUSTPROF";
	dataSrcLocationArray[8] = "BLK_ISSUERDET";
	dataSrcLocationArray[9] = "BLK_ISSUERLMTS";
	dataSrcLocationArray[10] = "BLK_CLSCCYREST";
	dataSrcLocationArray[11] = "BLK_BIC";

	//appendData(document.getElementById("TBLPageAll"));
	appendTextFieldValue(document.getElementsByName('CUSTNO')[0], 1, 'BLK_CUSTOMER');
	appendTextFieldValue(document.getElementsByName('MODNO')[0], 1, 'BLK_CUSTOMER');

	//  dbFCJDOM.loadXML(dbDataDOM.xml);
	fcjRequestDOM = buildUBSXml();

	// Post the XML to Server
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);

	if(fcjResponseDOM) {
		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));

		if (msgStatus == 'FAILURE') {
			var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
			var returnVal = displayResponse(messageNode);
		}

		if(msgStatus == 'SUCCESS') {
			var authResDom = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1);
			setDataXML(getXMLString(authResDom));
			mainWin.Authdom = null;
			resetIndex();
			//showTabData_Viewchg();
			viewMnt = true;
			showData();
			gAction = "";
		}
		disableForm();
	}
}

//OFAC Black List Check FC 11.1 Starts
function fnPreLoad_CVS_OFACM_KERNEL(screenArgs) {
	var  REQXML ="<OFAC><SERVICE>FCUBSOfacServ</SERVICE><ID>"+document.getElementById("BLK_CUSTOMER__CUSTNO").value+"</ID><DESTINATION>"+document.getElementById("BLK_CUSTOMER__NAME").value+"</DESTINATION><MSGID></MSGID></OFAC>";
	screenArgs['REQXML']=REQXML;//Prepare the request xml in the format of OFAC accepeted Requested xml and pass as
	// screen argument to CSCOFACM
	return true;
}
//OFAC Black List Check FC 11.1 Ends

//Edwin Added for Kernel1.2 Starts
function fnPreCloseTxnBranch() {
	debugs(" In fnPreCloseTxnBranch", "");
	return true;
}

function fnPostCloseTxnBranch() {
	debugs("In fnPostCloseTxnBranch", "");
	document.getElementsByName("LBRN")[0].value = g_txnBranch;
	return true;
}

function fnPreDetailScreen_KERNEL() {
	var iRowIndex=getRowIndex();
	//var txnBranch=document.getElementById("TBL_QryRslts").tBodies[0].rows[iRowIndex-1].cells[10].innerText;
	var txnBranch;
	if (iRowIndex == -1) {
		txnBranch=getInnerText(document.getElementById("TBL_QryRslts").tBodies[0].rows[sumRsltRowNo].cells[10]); //ITR1#53 - getRowIndex not working for non-IE. So added this
	} else {
		txnBranch=getInnerText(document.getElementById("TBL_QryRslts").tBodies[0].rows[iRowIndex-1].cells[10]);
	}
	sumTxnBranch = txnBranch;
	return true;
}

function fnPostLoad_Summary_KERNEL() {
	document.getElementsByName("BRANCH")[0].value= dlgArg.mainWin.frames['Global'].CurrentBranch;
	fnDisableElement(document.getElementsByName("BRANCH"));
}

function fnPreShowDetail_Sum_KERNEL() {
	var iRowIndex=getRowIndex();
	//var txnBranch=document.getElementById("TBL_QryRslts").tBodies[0].rows[iRowIndex-1].cells[10].innerText;
	var txnBranch;
	if (iRowIndex == -1) {
		txnBranch=getInnerText(document.getElementById("TBL_QryRslts").tBodies[0].rows[sumRsltRowNo].cells[10]); //ITR1#53 - getRowIndex not working for non-IE. So added this
	} else {
		txnBranch=getInnerText(document.getElementById("TBL_QryRslts").tBodies[0].rows[iRowIndex-1].cells[10]);
	}
	sumTxnBranch = txnBranch;
	//g_txnBranch = sumTxnBranch; //9NT1606_12_4_RETRO_12_0_3_26661106 Commented
	return true;
}
//Edwin Added for Kernel1.2 Ends

//FCUBS11.2 ITR1 SFR#32 Starts
function fnEnableDisableJV() {
	//if (document.getElementById("BLK_CUSTOMER__JOINT_VENTURE").checked == true) { //FCUBS_12.0.0 Usabiity changes
	if (document.getElementById("BLK_CUSTCORP__JOINTVENTURE").checked == true) { //FCUBS_12.0.0 Usabiity changes
	//9nt1466 changes for iut sfr 397
		//document.getElementsByName("DIVFooter")[0].children[0].all[33].disabled  = false; 
		fnEnableSubSystemButton(document.getElementById('CVS_JV').children[0]);	
	} else {
	//9nt1466 changes for iut sfr 397
		//document.getElementsByName("DIVFooter")[0].children[0].all[33].disabled  = true;
		fnDisableSubSystemButton(document.getElementById('CVS_JV').children[0]);
	}
	return true;
}
//FCUBS11.2 ITR1 SFR#32 Ends

//////////////////////////////////////// LIMITS_11.3.1 ////////////////////////////////////////////
// LIMITS_11.3.1 post_load defaulting is moved to here
function fnOnClickBtnPopulate(event) {
	//9NT1606_12_4_RETRO_12_3_26230186 start
	document.getElementById("BLK_CUSTPERSONAL__SEX").checked= false;
	document.getElementById("BLK_CUSTPERSONAL__SEX2").checked= false;
	document.getElementById("BLK_CUSTPERSONAL__SEX3").checked= false;
	document.getElementById("BLK_CUSTPERSONAL__SEX4").checked= false;
	document.getElementById("BLK_CUSTPERSONAL__CUST_COMM_MODE").checked= false;
	document.getElementById("BLK_CUSTPERSONAL__CUST_COMM_MODE2").checked= false;
	document.getElementById("BLK_CUSTPERSONAL__RESSTATUS").checked= false;
	document.getElementById("BLK_CUSTPERSONAL__RESSTATUS2").checked= false;
	
	//9NT1606_12_4_RETRO_12_3_26230186 end
	if (document.getElementsByName("LBRN")[0].value=='')
		document.getElementsByName("LBRN")[0].value = mainWin.CurrentBranch;
	fnDisableElement(document.getElementsByName("LBRN")[0]);//ITR1#53
	var resp = fnProcessAction('DEFAULT', document.getElementById('TBLPageTAB_HEADER'));
	var l_cust_no = document.getElementById("BLK_CUSTOMER__CUSTNO").value;
	//9NT1620#1203SUPPORT#19303321 changes starts
			if (document.getElementById("BLK_CUSTOMER__SNAME").value != null)
		document.getElementById("BLK_CUSTOMER__SNAME").value = "";
		//9NT1620#1203SUPPORT#19303321 changes ends

	if (resp != 'SUCCESS' || !l_cust_no) {
		prepareCIF();
		//16522265  changes start
		//showErrorAlerts('ST-MAND-001', 'E', 'Customer No~');
            var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
			//var returnVal = displayResponse(messageNode);		//120_CITI120_16593670
		//16495913 changes end
		return true;
	}

	limitArgs.customerNo = l_cust_no;
	limitArgs.localBranch = document.getElementById("BLK_CUSTOMER__LBRN").value;
	enableForm();
	disableMESVFields();//9NT1620_1203_MAT_18273112 added
	fnEnableAllSubSystemButtons();
	fnEnableAllTabs();
	disableTabs("TAB_MFI"); //FCUBS_MF12.0.1_to_MF12.0.2_Port 
	fnDisableKeyFields();
	// FCUBS_12.0.0 Usabiity changes starts
	fnCTYPEChange(); //FCUBS 12.0 itr2 sfr#14004922 
	/* Code Moved to TAB_ADDITIONAL
	if (typeof(document.getElementById("BLK_CUSTOMER__FXNETTCUST")) != 'undefined' && document.getElementById("BLK_CUSTOMER__FXNETTCUST") != null) {
		document.getElementById("BLK_CUSTOMER__FXNETTCUST").value = l_cust_no;
	
	
	
	if (typeof(document.getElementById("BLK_CUSTOMER__TRACK_LIMITS")) != 'undefined' && document.getElementById("BLK_CUSTOMER__TRACK_LIMITS") != null) {
		if(typeof(document.getElementById("BLK_CUSTOMER__LIABID")) != 'undefined' && document.getElementById("BLK_CUSTOMER__LIABID") != null){
			if (document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked) {
				document.getElementById("BLK_CUSTOMER__LIABID").value = l_cust_no;
			} else {
				fnDisableElement(document.getElementById("BLK_CUSTOMER__LIABID"));
			}
		}
	}
	//9nt1466 changes for iut sfr 397 starts
	/*if(typeof(document.getElementById("BLK_CUSTCORP__JOINTVENTURE")) != 'undefined' && document.getElementById("BLK_CUSTCORP__JOINTVENTURE") != null){
		if (document.getElementById("BLK_CUSTCORP__JOINTVENTURE").checked == true) {	
			fnEnableSubSystemButton(document.getElementById('CVS_JV').children[0]);	
		} else {
			fnDisableSubSystemButton(document.getElementById('CVS_JV').children[0]);
		}
	}
	//9nt1466 changes for iut sfr 397 ends
	if (typeof(document.getElementById("BLK_CUSTOMER__CREATEACC")) != 'undefined' && document.getElementById("BLK_CUSTOMER__CREATEACC") != null) 
	fnEnableDisableAcc();//FCUBS_11.3.1 CIF_CASA changes 
	*/ 
	fnDisableElement(document.getElementById("BLK_JOINTVENTURE__PARTY_ID"));		
	fnDisableElement(document.getElementById("BLK_JOINTVENTURE__PARTYNAME"));		
	fnDisableElement(document.getElementById("BLK_JOINTVENTURE__PARTY_RATIO"));
	/*if (functionId == 'STDCIF') {
		if (document.getElementsByName("CTYPE")[2].checked){
			//fnDisableBank();
		
		}
	}*/
	limitArgs.CIFGenerated = true;
	// FCUBS_12.0.0 Usabiity changes ends
	if(document.getElementById("BLK_CUSTOMER__CTYPE").checked== true){ // 9NT1606_12_4_RETRO_12_3_26861749 Added
	//9NT1606_12_4_RETRO_12_3_26384621 start
	document.getElementById("BLK_CUSTPERSONAL__CUST_COMM_MODE").checked= false;
	document.getElementById("BLK_CUSTPERSONAL__CUST_COMM_MODE2").checked= false;
	} //9NT1606_12_4_RETRO_12_3_26861749 Added
	if(document.getElementById("BLK_CUSTOMER__CTYPE2").checked==true){ //9NT1606_12_4_RETRO_12_3_26861749 Added
	document.getElementById("BLK_CUSTCORP__CUSTCOMMMODE").checked= false;
	document.getElementById("BLK_CUSTCORP__CUSTCOMMMODE2").checked= false;
    //9NT1606_12_4_RETRO_12_3_26384621 end
    } //9NT1606_12_4_RETRO_12_3_26861749 Added
	return true;
}

function fnOnClickChkboxTrackLimits_CVS_MAIN(event) {
	if (gAction == 'NEW' || gAction == 'MODIFY') {
		var fld_liab_id = document.getElementById("BLK_CUSTOMER__LIABID");
		if (document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked) {
			fnEnableElement(fld_liab_id);
			setNodeText(selectSingleNode(dbDataDOM,"BLK_CUSTOMER/TRACK_LIMITS"),'Y');  //9NT1606_12_2_RETRO_12_0_3_23652476  added
			//if(!fld_liab_id.value) {  //12.2_SUPPORT_RETRO_23653806 commented
		    //12.2_SUPPORT_RETRO_23653806 starts
			if(document.getElementById("BLK_CUSTOMER__LIABID").value == "") {
			    document.getElementById("BLK_CUSTOMER__LIABID").value = fld_liab_id.value;			    
			}
			//12.2_SUPPORT_RETRO_23653806 ends
			    limitArgs.liabilityNo = fld_liab_id.value = document.getElementById("BLK_CUSTOMER__CUSTNO").value;
			    limitArgs.iChanged = true;
			// } 12.2_SUPPORT_RETRO_23653806 commented
		} else {
			document.getElementById("BLK_CUSTOMER__LIABID").value = "";  //12.2_SUPPORT_RETRO_23653806 added
			fnDisableElement(fld_liab_id);
			setNodeText(selectSingleNode(dbDataDOM,"BLK_CUSTOMER/TRACK_LIMITS"),'N');  //9NT1606_12_2_RETRO_12_0_3_23652476  added
			if (limitArgs.iChanged && !(limitArgs.isLoaded)) {
				limitArgs.liabilityNo = fld_liab_id.value = "";
				limitArgs.iChanged = false;
			}
		}
	}
}

function fnOnBlurLIABID_CVS_MAIN(event) {
	/*
	*  disp_auto_lov is called because INFRA failed to prepend disp_auto_lov in OnBlur event, when defined thru RAD as fnOnBlurLIABID_CVS_MAIN
	*/
	try {disp_auto_lov('STDCIF','BLK_CUSTOMER','LIABID','Liability Id','LOV_LIABILITY','','','', event);} catch(e) {}
	if (!isAutoLOVOpened) {
		var l_liabilityNo = getEventSourceElement(event).value;
		if (l_liabilityNo != limitArgs.liabilityNo) {
			limitArgs.liabilityNo = l_liabilityNo;
			limitArgs.isLoaded = false;
			limitArgs.iChanged = false;
		}
	}
}

function fnPostReturnValToParent_LOV_LIABILITY_KERNEL(event) {
	var l_liabilityNo = document.getElementById("BLK_CUSTOMER__LIABID").value;
	if (l_liabilityNo != limitArgs.liabilityNo) {
		limitArgs.liabilityNo = l_liabilityNo;
		limitArgs.isLoaded = false;
		limitArgs.iChanged = false;
	}
	return true;
}

function fnPreLoad_CVS_LIM_KERNEL() {
	var trackLimitsEnabled = false;  //9NT1606_12_2_RETRO_12_0_3_23652476  added
	//121_21064380 commented starts
	/*limitArgs.trackLimits = document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked;
	limitArgs.customerNo = document.getElementById("BLK_CUSTOMER__CUSTNO").value;
	limitArgs.liabilityNo = document.getElementById("BLK_CUSTOMER__LIABID").value;*/
	//limitArgs.sname = document.getElementById("BLK_CUSTOMER__SNAME").value;  // 114_JMDFGL_16200195 ADDED 9NT1606#1203SUPPORT#19822002 commented
	//121_21064380 commented  ends
	//121_21064380 starts
	if (typeof(document.getElementById("BLK_CUSTOMER__TRACK_LIMITS")) != 'undefined' && document.getElementById("BLK_CUSTOMER__TRACK_LIMITS") != null) 
	limitArgs.trackLimits = document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked;
	//else  //9NT1606_12_2_RETRO_12_0_3_23652476  commented else												
	limitArgs.trackLimits = getNodeText( selectSingleNode(dbDataDOM,"BLK_CUSTOMER/TRACK_LIMITS")) 
	limitArgs.customerNo = document.getElementById("BLK_CUSTOMER__CUSTNO").value;
if (typeof(document.getElementById("BLK_CUSTOMER__LIABID")) != 'undefined' && document.getElementById("BLK_CUSTOMER__LIABID") != null) 
	limitArgs.liabilityNo = document.getElementById("BLK_CUSTOMER__LIABID").value;
	
else
        //Bug_28038515 Changes Starts
		{
	// limitArgs.liabilityNo = getNodeText( selectSingleNode(dbDataDOM,"BLK_CUSTOMER/LIABID"))  
        limitArgs.liabilityNo=limitArgs.customerNo;
		}
        appendData();
        //Bug_28038515 Changes Ends
	//121_21064380 ends
	// 9NT1606#1203SUPPORT#19822002  changes starts
	if (document.getElementsByName("CTYPE")[0].checked) {
	//limitArgs.sname = document.getElementById("BLK_CUSTOMER__NAME").value; // 24968965_WELLS_FARGO commented
	limitArgs.sname = document.getElementById("BLK_CUSTOMER__FULLNAME").value;  // 24968965_WELLS_FARGO
	}
	if (document.getElementsByName("CTYPE")[1].checked||document.getElementsByName("CTYPE")[2].checked) {
limitArgs.sname =document.getElementById("BLK_CUSTCORP__CNAME").value;
	
	}	
	// 9NT1606#1203SUPPORT#19822002  changes ends
	
	//loan sector changes sampath starts
	if (document.getElementsByName("CTYPE")[3].checked||document.getElementsByName("CTYPE")[4].checked||document.getElementsByName("CTYPE")[5].checked||document.getElementsByName("CTYPE")[6].checked) {
limitArgs.sname =document.getElementById("BLK_CUSTCORP__CNAME").value;
	
	}
	//loan sector changes sampath ends
	
	limitArgs.localBranch = document.getElementsByName("LBRN")[0].value;
	//FCUBS_12.2.0.0.0_SUPPORT_23655284 comment starts
	//if (gAction) {
		//if (limitArgs.trackLimits) {
	//FCUBS_12.2.0.0.0_SUPPORT_23655284 comment ends
			if (limitArgs.trackLimits == 'Y' || trackLimitsEnabled == true) {  //(limitArgs.trackLimits == true)) {//1203_20218742 added  // (added == true)   //9NT1606_12_2_RETRO_12_0_3_23652476 
			limitArgs.isReadOnly = false;
			//if (limitArgs.customerNo == limitArgs.liabilityNo) {  //FCUBS_12.2.0.0.0_SUPPORT_23652655 commented
			if((gAction == 'NEW' && limitArgs.customerNo == limitArgs.liabilityNo) || //1203_22710923
			(gAction == 'MODIFY' && getNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/ONCEAUTH")) == 'N')){  //FCUBS_12.2.0.0.0_SUPPORT_23652655 added  //1203_22688055 added condition for MODIFY action
			//FCUBS_12.2.0.0.0_SUPPORT_23655284 ends
				limitArgs.limitsMode = 'NEW';
			} else {
				limitArgs.limitsMode = 'LOAD';
			}
		} else {
			limitArgs.isReadOnly = true;
			showErrorAlerts('ST-CIF-L002');
			return false; // can be skipped to view it as read only
		}
	//}  //FCUBS_12.2.0.0.0_SUPPORT_23655284 commented
	return true;
}

function fnPostLoad_CVS_LIM_KERNEL() {
	//if (gAction) { //FCUBS_12.2.0.0.0_SUPPORT_23655284 commented
          //FCUBS_12.2_RETRO_BUG#23656001 comment starts
           /*
		if (parent.limitArgs.isReadOnly || parent.limitArgs.isAuthorized) {
			parent.limitArgs.isReadOnly = true;
			disableForm();
		} else */
              //FCUBS_12.2_RETRO_BUG#23656001 comment ends
                  if (parent.limitArgs.limitsMode == 'NEW') {
			enableForm();
			var fld_liab_no = document.getElementById("BLK_CUST_LIAB__LIAB_NO");
			fnDisableElement(fld_liab_no);
			if (!parent.limitArgs.isLoaded) {
				// flush old data
				eraseDataOf('BLK_CUST_LIAB');
				// default values
				document.getElementById("BLK_CUST_LIAB__CUST_NO").value = parent.limitArgs.customerNo;
				fld_liab_no.value = parent.limitArgs.liabilityNo;
				var fld_liab_name = document.getElementById("BLK_CUST_LIAB__LIAB_NAME");
				if (!fld_liab_name.value)
					//fld_liab_name.value = parent.limitArgs.liabilityNo; //114_JMDFGL_16200195 CHANGES
					fld_liab_name.value = parent.limitArgs.sname; //114_JMDFGL_16200195 ADDED

				var fld_liab_branch = document.getElementById("BLK_CUST_LIAB__LIAB_BRANCH");
				if (!fld_liab_branch.value)
					fld_liab_branch.value = parent.limitArgs.localBranch;
			    //fnDisableElement(fld_liab_branch); //9NT1606_12_4_RETRO_12_3_26818173  added //9NT1606_12_4_RETRO_12_3_27143112 commented 
				var fld_liab_ccy = document.getElementById("BLK_CUST_LIAB__LIAB_CCY");
				if (!fld_liab_ccy.value)
					fld_liab_ccy.value = mainWin.BranchLcy;
				// pickup UDF
				fnProcessAction('PICKLIABUDF');
			}
			document.getElementById("BLK_CUST_LIAB__LIAB_NAME").value = parent.document.getElementById("BLK_CUSTOMER__FULLNAME").value; //Bug_28995677
		} else if (parent.limitArgs.limitsMode == 'LOAD'  && (!viewMnt)) { //9NT1606_12_4_RETRO_12_3_26724251 changes
		       //Bug_29491312 uncommenting starts
		       fnDisableAllUnderBlock("TBLPageTAB_MAIN");//FCUBS_12.2_RETRO_BUG#23656001 commented
		       //Bug_29491312 uncommenting ends
			   //Bug_29491312 comment starts			   
                       /* //FCUBS_12.2_RETRO_BUG#23656001 starts			
			//enableForm();  //FCUBS_12.2.0.0.0_SUPPORT_23655284 commented
			var fld_liab_no = document.getElementById("BLK_CUST_LIAB__LIAB_NO");
			fnDisableElement(fld_liab_no);
			var prevAction;  //FCUBS_12.2.0.0.0_SUPPORT_23655284 added
			if(gAction == 'MODIFY') {
				enableForm(); //FCUBS_12.2.0.0.0_SUPPORT_23655284 added
				fnDisableElement(document.getElementById("BLK_CUST_LIAB__MAIN_LIAB_NO"));
				fnDisableElement(document.getElementById("BLK_CUST_LIAB__CATEGORY"));
			   	fnDisableElement(document.getElementById("BLK_CUST_LIAB__FX_CLEAN_RISK_LIMIT"));
				fnDisableElement(document.getElementById("BLK_CUST_LIAB__SEC_CLEAN_RISK_LIMIT"));
				fnDisableElement(document.getElementById("BLK_CUST_LIAB__SEC_PSTL_RISK_LIMIT"));
				fnDisableElement(document.getElementById("BLK_CUST_LIAB__OVERALL_SCOREI")); //FCUBS_12.2.0.0.0_SUPPORT_23655284 added
				//Fcubs_12.4_SAIGON COMMERCIAL BANK_Bug_27894587 starts
				var fld_liab_branch1 = document.getElementById("BLK_CUST_LIAB__LIAB_BRANCH");
				if (!fld_liab_branch1.value)
					fld_liab_branch1.value = parent.limitArgs.localBranch;
				document.getElementById("BLK_CUST_LIAB__LIAB_BRANCH")=fld_liab_branch.value;
				//Fcubs_12.4_SAIGON COMMERCIAL BANK_Bug_27894587 ends
			}
			//FCUBS_12.2_RETRO_BUG#23656001 ends */
			//Bug_29491312 comment ends			
			//12.2_SUPPORT_RETRO_23664149 start
			var l_liabilityNo1 = document.getElementById("BLK_CUST_LIAB__LIAB_NO").value;
			//if (!parent.limitArgs.isLoaded) {
			//if (!parent.limitArgs.isLoaded || l_liabilityNo1 != parent.limitArgs.liabilityNo) { //9NT1606_12.4_CNSL_33502861 commented
			if (!parent.limitArgs.isLoaded && l_liabilityNo1 != parent.limitArgs.liabilityNo) { //9NT1606_12.4_CNSL_33502861 added
			// 12.2_SUPPORT_RETRO_23664149 End
				// default key data
				document.getElementById("BLK_CUST_LIAB__CUST_NO").value = parent.limitArgs.customerNo;
				document.getElementById("BLK_CUST_LIAB__LIAB_NO").value = parent.limitArgs.liabilityNo;
				// load existing liability
				//FCUBS_12.2.0.0.0_SUPPORT_23655284 starts
				prevAction = gAction;
				gAction = 'LOADLIAB';
				fnProcessAction('LOADLIAB');
				gAction = prevAction;
				//FCUBS_12.2.0.0.0_SUPPORT_23655284 ends
			}
		}
		fnDisableElement(document.getElementById("BLK_CUST_LIAB__LIAB_BRANCH")); //9NT1606_12_4_RETRO_12_3_27143112 added 
	//}  //FCUBS_12.2.0.0.0_SUPPORT_23655284 commented
	return true;
}
//FCUBS_12.2.0.0.0_SUPPORT_23655284 starts
function fnGetCreditRating(){
    var len = document.getElementById("BLK_LIAB_RATING").tBodies[0].rows.length;
	var msob_tchk = 0;
	var selected_row = '';
    for(i = 0;i < len; i++) {
        if(document.getElementById("BLK_LIAB_RATING").tBodies[0].rows[i].cells[5].getElementsByTagName("INPUT")[0]) {
          if(document.getElementById("BLK_LIAB_RATING").tBodies[0].rows[i].cells[5].getElementsByTagName("INPUT")[0].checked) {
            msob_tchk = msob_tchk +1; 
            selected_row = i ; 
           	}
		}
	}
	if (msob_tchk > 1 ) {
        //alert ( 'Please Select One Record');
		showErrorAlerts('IN-HEAR-283');
		document.getElementById("BLK_LIAB_RATING").tBodies[0].rows[selected_row].cells[5].getElementsByTagName("INPUT")[0].checked = false;
        return false ;
    }	
	return true;
}
//FCUBS_12.2.0.0.0_SUPPORT_23655284 ends

function fnPreSave_CVS_LIM_KERNEL() {
	if (!parent.limitArgs.isReadOnly) {
		parent.limitArgs.isLoaded = true;
	}
	return true;
}

function fnPreLoad_CVS_LIM_SCORE_KERNEL() {
	return true;
}

function fnPostLoad_CVS_LIM_SCORE_KERNEL() {
	//if (parent.parent.limitArgs.isReadOnly || parent.parent.limitArgs.limitsMode == 'LOAD') {  //FCUBS_12.2.0.0.0_SUPPORT_23655284 commented
	if (parent.parent.limitArgs.isReadOnly) {  //FCUBS_12.2.0.0.0_SUPPORT_23655284 commented
		disableForm();
	}
	return true;
}

function fnPreLoad_CVS_LIM_RATING_KERNEL() {
	return true;
}

function fnPostLoad_CVS_LIM_RATING_KERNEL() {
	//if (parent.parent.limitArgs.isReadOnly || parent.parent.limitArgs.limitsMode == 'LOAD') { //FCUBS_12.2.0.0.0_SUPPORT_23655284 commented
	if (parent.parent.limitArgs.isReadOnly) {  //FCUBS_12.2.0.0.0_SUPPORT_23655284 commented
		disableForm();
	}
	return true;
}

function fnPreLoad_CVS_LIM_LINKAGE_KERNEL() {
	return true;
}

function fnPostLoad_CVS_LIM_LINKAGE_KERNEL() {
	if (parent.parent.limitArgs.isReadOnly) {
		disableForm();
	}
	document.getElementById("BLK_CUST_LIAB__UI_CUST_NO").value = parent.parent.limitArgs.customerNo;
	document.getElementById("BLK_CUST_LIAB__UI_LIAB_NO").value = parent.parent.limitArgs.liabilityNo;
	document.getElementById("BLK_CUST_LIAB__UI_LIAB_NAME").value = parent.document.getElementById("BLK_CUST_LIAB__LIAB_NAME").value;
	return true;
}

function fnPreLoad_CVS_LIM_UDF_KERNEL(screenArgs) {
	return true;
}

function fnPostLoad_CVS_LIM_UDF_KERNEL(screenArgs) {
	//RETRO SFR#23656280 comment starts
	/*var bblk = document.getElementById('BLK_LIAB_UDF');
	var readOnlyMode = parent.parent.limitArgs.isReadOnly || parent.parent.limitArgs.limitsMode == 'LOAD' || !gAction;
	fnSwitchToUDFMode(bblk, readOnlyMode);
	if (readOnlyMode) {
		disableForm();
	}*/ 
	//RETRO SFR#23656280 comment ends
	disableForm(); //RETRO SFR#23656280 added 
	return true;
}

function fnPreSave_CVS_LIM_UDF_KERNEL(screenArgs) {
	return true;
}
////////////////////END///////////////// LIMITS_11.3.1 ////////////////////END////////////////////

//FCUBS_11.3.1 CIF_CASA changes starts
function fnPreLoad_CVS_ACC_KERNEL(screenArgs) {
	try {
		if (gAction) {
			if (!document.getElementById("BLK_CUSTOMER__CREATEACC").checked) {
				showErrorAlerts('ST-CIF-AC07');
				return false;
			}
			screenArgs['CREATECUSTACC'] = document.getElementById("BLK_CUSTOMER__CREATEACC").checked;
			screenArgs['CUSTNO'] = document.getElementsByName("CUSTNO")[0].value;
			//screenArgs['CUSTNAME'] = document.getElementById("BLK_CUSTOMER__SNAME").value; // 1202_17346846 
			screenArgs['BRANCH'] = document.getElementById("BLK_CUSTOMER__LBRN").value;
			//screenArgs['TRACK_LIMITS'] = document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked;
			//screenArgs['LIABID'] = document.getElementById("BLK_CUSTOMER__LIABID").value;
       screenArgs['FULLNAME'] = document.getElementById("BLK_CUSTOMER__FULLNAME").value;//9NT1606_12_4_RETRO_12_3_27143099 added
			 //9NT1525-12.0RETRO-JMDFGL-14570025 Starts
		    if (document.getElementsByName("CTYPE")[0].checked) {
				screenArgs['CTYPE']= 'I';
				screenArgs['CUSTNAME'] = document.getElementById("BLK_CUSTOMER__NAME").value;//1202_17346846
			}
			if (document.getElementsByName("CTYPE")[1].checked) {
				screenArgs['CTYPE']= 'C';  
				  screenArgs['CUSTNAME'] = document.getElementById("BLK_CUSTCORP__CNAME").value;//  1202_17346846
			}//9NT1587_FCUBS_12.0.2_DEV_Joint Holder Maintanance_CHANGES_UT_ISSUE starts
			if (functionId == 'STDCIF') {
			    
			    if (document.getElementsByName("CTYPE")[2].checked) {
				    screenArgs['CTYPE']='B';
				screenArgs['CUSTNAME'] = document.getElementById("BLK_CUSTCORP__CNAME").value;//  1202_17346846
			    }
			    //9NT1525-12.0RETRO-JMDFGL-14570025 Ends
			}////9NT1587_FCUBS_12.0.2_DEV_Joint Holder Maintanance_CHANGES_UT_ISSUE ends
			
			//loan sector sampath changes starts
			if (functionId == 'STDCIF') {
			    
			    if (document.getElementsByName("CTYPE")[3].checked) {
				    screenArgs['CTYPE']='U';
				 screenArgs['CUSTNAME'] = document.getElementById("BLK_CUSTCORP__CNAME").value;
			    }
			}

			if (functionId == 'STDCIF') {
			    
			    if (document.getElementsByName("CTYPE")[4].checked) {
				    screenArgs['CTYPE']='R';
				 screenArgs['CUSTNAME'] = document.getElementById("BLK_CUSTCORP__CNAME").value;
			    }
			}
			
			if (functionId == 'STDCIF') {
			    
			    if (document.getElementsByName("CTYPE")[5].checked) {
				    screenArgs['CTYPE']='S';
				 screenArgs['CUSTNAME'] = document.getElementById("BLK_CUSTCORP__CNAME").value;
			    }
			}

			if (functionId == 'STDCIF') {
			    
			    if (document.getElementsByName("CTYPE")[6].checked) {
				    screenArgs['CTYPE']='N';
				 screenArgs['CUSTNAME'] = document.getElementById("BLK_CUSTCORP__CNAME").value;
			    }
			}

			//loan sector sampath changes ends
			
		}
		return true;
	} catch(e) {
		return false;
	}
}
function fnEnableDisableAcc() {
	if (document.getElementById("BLK_CUSTOMER__CREATEACC").checked == true) {
		limitArgs.isAccountLocked = false; //9NT1462 ITR1 13330438
		fnEnableSubSystemButton(document.getElementById('STCCUACC').children[0]);	
	} else {
		fnDisableSubSystemButton(document.getElementById('STCCUACC').children[0]);
	}
	return true;
}
//FCUBS_11.3.1 CIF_CASA changes ends

//FCUBS_FCUBS_12.0.0 Usabiity changes BY Gokul Starts
function fnCTYPEChange() {     //FCUBS 12.0 itr2 sfr#14004922 
    //9NT1501 ITR -1 SFR - 13902635 Starts
	//fnDisableAllTabs();
	if (functionId == 'STDCIF') {
		enableTabs("TAB_PERSONAL~TAB_CORPORATE~TAB_DIRECTOR~TAB_ADDITIONAL~TAB_AUXILIARY~TAB_CHECKLIST","~");
	}
	else if (functionId == 'STDCIFAD')	{
		enableTabs("TAB_PERSONAL~TAB_CORPORATE~TAB_CHECKLIST","~");
	}
	//9NT1501 ITR -1 SFR - 13902635 Ends	
	var Cust1 = document.getElementsByName("CTYPE")[0];
	var Cust2 = document.getElementsByName("CTYPE")[1];
	var Cust3 = document.getElementsByName("CTYPE")[2];
	//9NT1501 ITR -1 SFR - 13902635 Starts
	
	//loan sector changes sampath starts
	var Cust4 = document.getElementsByName("CTYPE")[3];
	var Cust5 = document.getElementsByName("CTYPE")[4];
	var Cust6 = document.getElementsByName("CTYPE")[5];
	var Cust7 = document.getElementsByName("CTYPE")[6];
	//loan sector changes sampath ends
	
	if(Cust1.checked){
		if (functionId == 'STDCIF')
		{
			disableTabs("TAB_CORPORATE~TAB_DIRECTOR","~");
			fnDisableSubSystemButton(document.getElementById('CVS_JV').children[0]);
		}
		else if (functionId == 'STDCIFAD')	
		{
			disableTabs("TAB_CORPORATE");
		}	
		expandcontent('TAB_PERSONAL');	
	}
	if(Cust2.checked){
		disableTabs("TAB_PERSONAL");
		expandcontent('TAB_CORPORATE');
	}
	if (functionId == 'STDCIF')
		if(Cust3.checked){
			disableTabs("TAB_PERSONAL");
			expandcontent('TAB_CORPORATE');
		}
		
		//loan sector changes sampath starts
	if (functionId == 'STDCIF')
		if(Cust4.checked){
			disableTabs("TAB_PERSONAL");
			expandcontent('TAB_CORPORATE');
		}
	if (functionId == 'STDCIF')
		if(Cust5.checked){
			disableTabs("TAB_PERSONAL");
			expandcontent('TAB_CORPORATE');
		}
	if (functionId == 'STDCIF')
		if(Cust6.checked){
			disableTabs("TAB_PERSONAL");
			expandcontent('TAB_CORPORATE');
		}
	if (functionId == 'STDCIF')
		if(Cust7.checked){
			disableTabs("TAB_PERSONAL");
			expandcontent('TAB_CORPORATE');
		}

	//loan sector changes sampath ends
	
	//fnEnableTabs(Cust1,Cust2,Cust3);
	//9NT1501 ITR -1 SFR - 13902635 Ends
	return true;	
//}9NT1501 ITR -1 SFR - 13929641 Commented
}
/*
9NT1501 ITR -1 SFR - 13902635 starts commented as it is not used
function fnEnableTabs(Cust1,Cust2,Cust3) {
	var tablist0 = document.getElementById('tablist').children;
	var tablist0length = tablist0.length;
	for (var i = 0; i < tablist0length; i++) {
		var elem = tablist0[i].children[0];		
		if(elem.id == "TAB_PERSONAL" && Cust2.checked ) {
			expandcontent('TAB_CORPORATE');
			continue;
		}
		if (functionId == 'STDCIF') {
			if(elem.id == "TAB_PERSONAL" && Cust3.checked ) {
				expandcontent('TAB_CORPORATE');
				continue;
			}	
		}
		if((elem.id == "TAB_CORPORATE" || elem.id == "TAB_DIRECTOR" )&& Cust1.checked)	{
			expandcontent('TAB_PERSONAL');	
			continue;
		}	
		if (elem.onclick0 && !elem.onclick) {
			if (tablist0[i].id != 'current')
				elem.className = 'Htaball';
			elem.onmouseover = elem.onmouseover0;
			elem.onfocus = elem.onfocus0;
			elem.onmouseout = elem.onmouseout0;
			elem.onblur = elem.onblur0;
			elem.onkeydown = elem.onkeydown0;
			elem.onclick = elem.onclick0;
		}
	}
	return true;
}
*/
function fnValidateMandatory() {
    var validate = true;
	var Cust1 = document.getElementsByName("CTYPE")[0];
	var Cust2 = document.getElementsByName("CTYPE")[1];
	var Cust3 = document.getElementsByName("CTYPE")[2];
    var fldSetElem = document.getElementsByTagName("fieldset");
    var eleArray = new Array("INPUT", "SELECT", "TEXTAREA");
//FCUBS_12.0.0 DMS changes Starts    
   	try
	{
//FCUBS_12.0.0 DMS changes Ends    

    for (var fs = 0; fs < fldSetElem.length; fs++) {
        if (fldSetElem[fs].getAttribute("type") == "ME" && fldSetElem[fs].getAttribute("view") == "SE" && fldSetElem[fs].getAttribute("MESVNODE") == "false") 
		continue;
        for (var i in eleArray) {
            var elements = fldSetElem[fs].getElementsByTagName(eleArray[i]);
            var tempVal = "";
            for (var elemIndex = 0; elemIndex < elements.length; elemIndex++) {
                if (elements[elemIndex] && elements[elemIndex].type.toUpperCase() == "RADIO") 
				continue;
				if (Cust2.checked  && (elements[elemIndex].id == 'BLK_CUSTPERSONAL__LANG' || elements[elemIndex].id == 'BLK_CUSTOMER__ADDRLN1' || elements[elemIndex].id == 'BLK_CUSTOMER__COUNTRY' || elements[elemIndex].id == 'BLK_CUSTOMER__NLTY')) 
				continue;	
				//loan sector sampath changes starts
				if (Cust4.checked  && (elements[elemIndex].id == 'BLK_CUSTPERSONAL__LANG' || elements[elemIndex].id == 'BLK_CUSTOMER__ADDRLN1' || elements[elemIndex].id == 'BLK_CUSTOMER__COUNTRY' || elements[elemIndex].id == 'BLK_CUSTOMER__NLTY')) 
				continue;
				if (Cust5.checked  && (elements[elemIndex].id == 'BLK_CUSTPERSONAL__LANG' || elements[elemIndex].id == 'BLK_CUSTOMER__ADDRLN1' || elements[elemIndex].id == 'BLK_CUSTOMER__COUNTRY' || elements[elemIndex].id == 'BLK_CUSTOMER__NLTY')) 
				continue;
				if (Cust6.checked  && (elements[elemIndex].id == 'BLK_CUSTPERSONAL__LANG' || elements[elemIndex].id == 'BLK_CUSTOMER__ADDRLN1' || elements[elemIndex].id == 'BLK_CUSTOMER__COUNTRY' || elements[elemIndex].id == 'BLK_CUSTOMER__NLTY')) 
				continue;
				if (Cust7.checked  && (elements[elemIndex].id == 'BLK_CUSTPERSONAL__LANG' || elements[elemIndex].id == 'BLK_CUSTOMER__ADDRLN1' || elements[elemIndex].id == 'BLK_CUSTOMER__COUNTRY' || elements[elemIndex].id == 'BLK_CUSTOMER__NLTY')) 
				continue;
				//loan sector sampath changes ends
				if(Cust1.checked  && (elements[elemIndex].id == 'BLK_CUSTCORP__LANGUAGE' || elements[elemIndex].id == 'BLK_CUSTCORP__CADDR1' || elements[elemIndex].id == 'BLK_CUSTCORP__CNTRY' || elements[elemIndex].id == 'BLK_CUSTCORP__NATIONALITY')) 
				continue;
				if (functionId == 'STDCIF') {
					if(Cust3.checked  && (elements[elemIndex].id == 'BLK_CUSTPERSONAL__LANG' || elements[elemIndex].id == 'BLK_CUSTOMER__ADDRLN1' || elements[elemIndex].id == 'BLK_CUSTOMER__COUNTRY' || elements[elemIndex].id == 'BLK_CUSTOMER__NLTY')) 
					continue;
				}
                if (elements[elemIndex].getAttribute("REQUIRED") == -1) {
                    tempVal = getFieldData(elements[elemIndex]);
					
			if (!(Cust1.checked && elements[elemIndex].id == 'BLK_CUSTCORPDIR__DIRNAME')){//9NT1606_12_4_RETRO_12_3_26913146 added
                    if (isNull(tempVal)) {
                        var label = fnGetLabel(elements[elemIndex]);
                        appendErrorCode('ST-COM013', label);
                        validate = false;
                    }
					} //9NT1606_12_4_RETRO_12_3_26913146 starts added
				}
            }
        }
    }
//FCUBS_12.0.0 DMS changes Starts    
}
	catch(e)
	{
		//do nothing..
	}	
//FCUBS_12.0.0 DMS changes Ends    
    return validate;
}

function fnInTab_TAB_ADDITIONAL_KERNEL()  { 
//9NT1620_1203_DEV changes starts
	if(document.getElementById("BLK_CUSTOMER__ALLOWVRTLACCNTS").checked==false ){
	fnDisableElement(document.getElementById("BLK_CUSTOMER__VRTLCUSTOMERID"));
	}	
	//9NT1620_1203_DEV changes ends	
	if (limitArgs.CIFGenerated) {
		if (document.getElementsByName("CTYPE")[2].checked || document.getElementsByName("CTYPE")[1].checked || document.getElementsByName("CTYPE")[3].checked  || document.getElementsByName("CTYPE")[4].checked || document.getElementsByName("CTYPE")[5].checked || document.getElementsByName("CTYPE")[6].checked){//loan sector sampath changes
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__SAME_PERM_ADDR"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__ADDRESS_CODE"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DADD1"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DADD2"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DADD3"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DADD4"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__CNTY"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DCNTRY")); //FATCA Changes 12.0.2
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DPIN_CODE"));// 9NT1620# 1203RETRO#18709202 changes added
		}
		var l_cust_no = document.getElementById("BLK_CUSTOMER__CUSTNO").value;
		document.getElementById("BLK_CUSTOMER__FXNETTCUST").value = l_cust_no;
		if (document.getElementById("BLK_CUSTOMER__TRACK_LIMITS").checked) {
			if (document.getElementById("BLK_CUSTOMER__LIABID").value == "")  //FCUBS_12.2.0.0.0_SUPPORT_23657266 added
				document.getElementById("BLK_CUSTOMER__LIABID").value = l_cust_no;
		} else {
			fnDisableElement(document.getElementById("BLK_CUSTOMER__LIABID"));
		}
	}
	// 9NT1620# 1203RETRO#18709202   changes added starts
	if (gAction == 'MODIFY') {
			if (document.getElementsByName("CTYPE")[2].checked || document.getElementsByName("CTYPE")[1].checked || document.getElementsByName("CTYPE")[3].checked || document.getElementsByName("CTYPE")[4].checked || document.getElementsByName("CTYPE")[5].checked || document.getElementsByName("CTYPE")[6].checked){ //loan sector sampath changes
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__SAME_PERM_ADDR"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__ADDRESS_CODE"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DADD1"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DADD2"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DADD3"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DADD4"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__CNTY"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DCNTRY"));
			fnDisableElement(document.getElementById("BLK_CUSTPERSONAL__DPIN_CODE"));	
	
}	
}
//9NT1620# 1203RETRO#18709202  changes added ends 	
//9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17053088 starts
	var freq =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUSTOMER/FREQ"));
	var stmtDay =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUSTOMER/STMTDAY"));
    document.getElementsByName('FREQ')[0].value = freq;
	fnpopulate('FREQ','STMTDAY');
	document.getElementsByName('STMTDAY')[0].value = stmtDay;
//9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17053088 ends
fnEnableElement(document.getElementById("BLK_CUSTOMER__BTN_SNCKSTATUS")); //Bug#21425319 added
	return true;
}

function fnInTab_TAB_CORPORATE_KERNEL()  { 
	if (limitArgs.CIFGenerated) {
		if (document.getElementById("BLK_CUSTCORP__JOINTVENTURE").checked == true) {	
			fnEnableSubSystemButton(document.getElementById('CVS_JV').children[0]);	
		} else {
			fnDisableSubSystemButton(document.getElementById('CVS_JV').children[0]);
		}
		if (functionId == 'STDCIF') {
			if (document.getElementsByName("CTYPE")[2].checked){
				//fnDisableBank();
			}
		}
	}	
	return true;
}

function fnDisableBank() {
	fnDisableElement(document.getElementById("BLK_CUSTCORP__NAME"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__CADDR1"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__CADDR2"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__CADDR3"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__CADDR4"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__CNTRY"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__NATIONALITY"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__LANGUAGE"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__TELEPHONE"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__FAXX"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__EMAILID"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__MOBILENUMBER"));
	fnDisableElement(document.getElementsByName("CUSTCOMMMODE")[0]);
	fnDisableElement(document.getElementsByName("CUSTCOMMMODE")[1]);
	fnDisableElement(document.getElementById("BLK_CUSTCORP__KYC_DETAILS"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__KYCREFNO"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__JOINTVENTURE"));
	fnDisableElement(document.getElementById("BLK_CUSTCORP__NATID"));
	return true;
}

//Bug_28995677 Change starts
/*function fnChangeTab(event){
	//9NT1606_12_4_RETRO_12_3_27107106 Changes Starts
	//if (functionId == 'STDCIFAD') {  //FCUBS 12.0 itr2 sfr#14004922
	if (functionId == 'STDCIFAD' && gAction != "") {
	//9NT1606_12_4_RETRO_12_3_27107106 Changes Ends
		expandcontent('TAB_CHECKLIST');
		document.getElementById("cmdAddRow_BLK_CUSTDOC_CHKLIST").focus();//9NT1501 SFR#14004922
		return true;
       }
else {
	expandcontent('TAB_ADDITIONAL');
	document.getElementById("BLK_CUSTPERSONAL__SAME_PERM_ADDR").focus();
	return true;
}
}
*/
//Bug_28995677 Change ends

function fnPreLoad_CVS_JV_KERNEL(screenArgs) {
	if (gAction) {
			if (!document.getElementById("BLK_CUSTCORP__JOINTVENTURE").checked) {
				//alert('Joint Venture is not selected'); //NLS Changes 12.0.1
				showErrorAlerts('ST-CIF-JV');
				return false;
			}
		}
	return true;
}
//FCUBS_FCUBS_12.0.0 Usabiity changes BY Gokul ends

//9NT1525 IMPSUPP 14549770 begins
function fnPreLaunchForm_CVS_MAIN_KERNEL(screenArgs)
 {
	if (document.getElementsByName("CTYPE")[0].checked == true)	
	{
		scrArgSource['STDKYCMN'] = "BLK_CUSTPERSONAL__KYCREFNO~";
	}	
	else
	{
		scrArgSource['STDKYCMN'] = "BLK_CUSTCORP__KYCREFNO~";
	}
	return true;
}
//9NT1525 IMPSUPP 14549770 ends	 
//FC12.0.2_Combined_statement Starts
function addOption(selectbox, value, text)
{
	var optn = document.createElement("OPTION");
	setNodeText(optn,text);
	optn.value = value;
	selectbox.options.add(optn);

	return true;
}

function removeAllOptions(selectbox)
{
	var i;
	for(i=selectbox.options.length-1;i>=0;i--)
	{
	selectbox.remove(i);
	}
}

function fnpopulate(fieldname,popfield)
{
	var value,i;
	var field;
	value=document.getElementsByName(fieldname)[0].value;
	field=document.getElementsByName(popfield)[0];
	removeAllOptions(field);
	switch(value)
	{
		case 'A':
               	addOption(field,"12","December");
			addOption(field,"1", "January");
			addOption(field,"2","February");
			addOption(field,"3","March");
			addOption(field,"4","April");
			addOption(field,"5","May");
			addOption(field,"6","June");
			addOption(field,"7","July");
			addOption(field,"8","August");
			addOption(field,"9","September");
			addOption(field,"10","October");
			addOption(field,"11","November");
			break;
		case 'S':
                     addOption(field,"6","June");
			addOption(field,"7","July");
			addOption(field,"8","August");
			addOption(field,"9","September");
			addOption(field,"10","October");
			addOption(field,"11","November");
                     addOption(field,"12","December");
			addOption(field,"1", "January");
			addOption(field,"2","February");
			addOption(field,"3","March");
			addOption(field,"4","April");
			addOption(field,"5","May");
                     break;
		case 'Q':
			addOption(field,"3","March");
			addOption(field,"4","April");
			addOption(field,"5","May");
			addOption(field,"6","June");
			addOption(field,"7","July");
			addOption(field,"8","August");
			addOption(field,"9","September");
			addOption(field,"10","October");
			addOption(field,"11","November");
			addOption(field,"12","December");
			addOption(field,"1", "January");
			addOption(field,"2","February");
			break;
		case 'M':
			for (i=1;i<=31 ;i++ )
			{
			  addOption(field,""+i, ""+i);
			}
			addOption(field,"","");
			break;
		case 'F':
		case 'W':
			addOption(field,"6", "Friday");
			addOption(field,"7", "Saturday");
			addOption(field,"1","Sunday");
			addOption(field,"2","Monday");
			addOption(field,"3","Tuesday");
			addOption(field,"4", "Wednesday"); //9NT1587_FCUBS_12.0.2_DEV_ITR1_SFR#17311607 changes
			addOption(field,"5", "Thursday");
			break;
		case 'D':
			addOption(field,"","");
		break;

		default:
			 addOption(field,"","");
	}
}
//FC12.0.2_Combined_statement Ends

  //FCUBS_MF12.0.1_to_MF12.0.2_Port Starts
function fnShowSubscreen_CVS_ID_MASTER(){
	/*var screenArgs = new Array();
	screenArgs['SCREEN_NAME'] = 'CVS_ID_MASTER';
	screenArgs['FUNCTION_ID'] = 'STDCIF';
	screenArgs['LANG'] = dlgArg.mainWin.frames["Global"].LangCode;
	//screenArgs['LANG'] = mainWin.LangCode;
	screenArgs['UI_XML'] = 'STDCIF';        
	if(l_headerTabPage && l_headerTabPage != '')
        	appendData(document.getElementById("TBLPage" + l_headerTabPage));
	appendData(document.getElementById('TBLPageAll'));
	//screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+dlgArg.mainWin.frames["Global"].LangCode+'/STDCIF.xml',screenArgs['SCREEN_NAME']);
	screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+mainWin.LangCode+'/STDCIF.xml',screenArgs['SCREEN_NAME']);
	//screenArgs
	fnShowSubScreen(screenArgs);*/
	fnSubScreenMain('STDCIF', 'STDCIF', 'CVS_ID_MASTER',false);
}

function fnPreLoad_CVS_ID_MASTER_KERNEL(screenArgs)
{
             //screenArgs['BRN']=dlgArg.mainWin.frames['Global'].CurrentBranch;
			screenArgs['BRN']=mainWin.CurrentBranch;
            screenArgs['CUSTNAME']=document.getElementById("BLK_CUSTOMER__NAME").value;
            screenArgs['CUSTNO']=document.getElementById("BLK_CUSTOMER__CUSTNO").value;
            return true;
}    

function fnPostLoad_CVS_ID_MASTER_KERNEL(screenArgs) {
	document.getElementById("BLK_ID_MASTER__CUSTOMER_NO").value = dlgArg.openerDoc.getElementById('CUSTNO').value;
	enableForm();
    return true;
}
 //9NT1606# 1202SUPPORT#17999926 changes starts commented
/*function fnPostExecuteQuery_KERNEL() 
{
document.getElementsByName("BTN_IDENTIDET")[0].disabled = false;
document.getElementsByName("BTN_CHKLIST")[0].disabled = false;
}*/
//9NT1606# 1202SUPPORT#17999926 changes ends 

function fnShowSubscreen_CVS_ID_DETAIL(){
	/*var screenArgs = new Array();
	screenArgs['SCREEN_NAME'] = 'CVS_ID_DETAIL';
	screenArgs['FUNCTION_ID'] = 'STDCIF';
	screenArgs['LANG'] = dlgArg.mainWin.frames["Global"].LangCode;
	//screenArgs['LANG'] = mainWin.LangCode;
	screenArgs['UI_XML'] = 'STDCIF';        
	if(l_headerTabPage && l_headerTabPage != '')
        	appendData(document.getElementById("TBLPage" + l_headerTabPage));
	appendData(document.getElementById('TBLPageAll'));
	//screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+dlgArg.mainWin.frames["Global"].LangCode+'/STDCIF.xml',screenArgs['SCREEN_NAME']);
	screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+mainWin.LangCode+'/STDCIF.xml',screenArgs['SCREEN_NAME']);
	fnShowSubScreen(screenArgs);*/
	fnSubScreenMain('STDCIF', 'STDCIF', 'CVS_ID_DETAIL',false);
}
function fnPreLoad_CVS_ID_DETAIL_KERNEL(screenArgs)
{
  var totalRows = document.getElementById("BLK_ID_DET_MAIN").tBodies[0].rows.length;
  var RowIndex = getRowIndex();
  var rowRef = document.getElementById("BLK_ID_DET_MAIN").tBodies[0].rows;

    for( i=0 ; i < totalRows ; i++ ) 
	{	   
	   if (rowRef[i].cells[0].getElementsByTagName("INPUT")[0].checked)
	   {
	      screenArgs['DOCUMENT_TYPE'] = document.getElementById('BLK_ID_DET_MAIN__DOCUMENT_TYPE')[i].value;
		  screenArgs['SNO'] = document.getElementById('BLK_ID_DET_MAIN__SNO')[i].value;
	      rowRef[i].cells[0].getElementsByTagName("INPUT")[0].checked=true; 
	 }
    }
	return true;
}

function fnPostLoad_CVS_ID_DETAIL_KERNEL(screenArgs) {
  	//document.getElementById("BLK_IDDETAIL__DOCUMENT_TYPE").value = dlgArg.openerDoc.getElementById('DOCUMENT_TYPE').value;
	document.getElementById("BLK_IDDETAIL__DOCUMENT_TYPE").value = parent.document.getElementById('BLK_ID_DET_MAIN__DOCUMENT_TYPE').value;
	enableForm();
	appendData(document.getElementById('TBLPageAll'));
    return true;
}

function fnShowSubscreen_CVS_CHKLIST(){
	/*var screenArgs = new Array();
	screenArgs['SCREEN_NAME'] = 'CVS_CHKLIST';
	screenArgs['FUNCTION_ID'] = 'STDCIF';
	//screenArgs['LANG'] = dlgArg.mainWin.frames["Global"].LangCode;
	screenArgs['LANG'] = mainWin.LangCode;
	screenArgs['UI_XML'] = 'STDCIF';
	if(l_headerTabPage && l_headerTabPage != '')
        	appendData(document.getElementById("TBLPage" + l_headerTabPage));
	appendData(document.getElementById('TBLPageAll'));
	//screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+dlgArg.mainWin.frames["Global"].LangCode+'/STDCIF.xml',screenArgs['SCREEN_NAME']);
	screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+mainWin.LangCode+'/STDCIF.xml',screenArgs['SCREEN_NAME']);
	screenArgs
	fnShowSubScreen(screenArgs);*/
	fnSubScreenMain('STDCIF', 'STDCIF', 'CVS_CHKLIST',false);
}
function fnPostLoad_CVS_CHKLIST_KERNEL() {
	document.getElementById("cmdAddRow_BLK_CHKLIST").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CHKLIST").style.visibility="HIDDEN";
    return true;
}
function fnPostAddRow_BLK_ID_DET_MAIN_KERNEL()
{
    var pageno = document.getElementById("CurrPage__BLK_ID_DET_MAIN").innerText; 
	var tableRef =  document.getElementById("BLK_ID_DET_MAIN");
	var rows = tableRef.tBodies[0].rows;
	var len = rows.length;
	if (pageno == 1)
	 {document.getElementsByName("SNO")[len-1].value = len;}
	else
	 {document.getElementsByName("SNO")[len-1].value = ((pageno-1)*15)+len;} 
   return true;
}

function fnPostDeleteRow_BLK_ID_DET_MAIN_KERNEL()
{
  var index = newRow.rowIndex;
  var cellRef = newRow.cells;
  var pageno = document.getElementById("CurrPage__BLK_ID_DET_MAIN").innerText;
  var startvalue;
  var endvalue;
  
	  startvalue = (pageno-1)*15 +1;
	  endvalue = startvalue + 14; 
		for( var rowIndex = 0 ; rowIndex < endvalue ; rowIndex ++ ) 
		{
			document.getElementsByName("SNO")[rowIndex].value = startvalue;
			document.getElementsByName("SNO")[rowIndex].disabled=true;
            startvalue++;
		}   
   return true;
}
function fnblacklistfocusout()
{
	
	var x = parseInt(document.getElementsByName("BLACKLIST_COUNT")[0].value);
	var y = 1;
	var len = document.getElementsByName("BLACKLISTED").length; 
	//var temp = dbDataDOM.selectNodes("//BLK_MFI1/BLACKLIST_COUNT").text;	
	var temp = dbDataDOM.selectSingleNode("//BLACKLIST_COUNT").text; //11.0.MF.1 ITR1 SFR 260 changes
    for(var i=0;i<len;i++)
	{
	   if ( document.getElementsByName("BLACKLISTED")[i].checked == true)
	    {		
			//if ( x = 'NaN')
			if ( dbDataDOM.selectSingleNode("//BLACKLIST_COUNT").text == "") //11.0.MF.1 ITR1 SFR 260 changes
			{
				document.getElementsByName("BLACKLIST_COUNT")[i].value = 1;
			}
			else
			{
				document.getElementsByName("BLACKLIST_COUNT")[i].value = x + y;
			}
	    }
        if ( document.getElementsByName("BLACKLISTED")[i].checked == false)
	    {	        		
			if (temp = '')
			{
				document.getElementsByName("BLACKLIST_COUNT")[i].value = '';
			}		
			else
			{
				document.getElementsByName("BLACKLIST_COUNT")[i].value = dbDataDOM.selectSingleNode("//BLACKLIST_COUNT").text; 
			}
	    }
	}	
	return;
}

function fnmfitypfocusout()
{
    var custyp = document.getElementsByName("MFI_CUST_TYPE")[0].value ;
    var len = document.getElementsByName("MFI_CUST_TYPE").length;
    for(var i=0;i<len;i++)
	{
	if(document.getElementsByName("MFI_CUST_TYPE")[i].checked == true)
		{	
		custyp = document.getElementsByName("MFI_CUST_TYPE")[i].value;
        if (custyp == 'C' || custyp == 'G') 
			  {			 
			  document.getElementsByName("BLK_MFI1__ACCOUNT_OFFICER")[i].disabled= true;
                          document.getElementsByName("BLK_MFI1__ACCOUNT_OFFICER")[i].value='';
			  document.getElementsByName("BLK_MFI1__ACCOUNT_OFFICER")[i].nextSibling.disabled = true;
			  } 
		if (custyp == 'I')
			{
             document.getElementsByName("BLK_MFI1__ACCOUNT_OFFICER")[i].disabled= false;
			 document.getElementsByName("BLK_MFI1__ACCOUNT_OFFICER")[i].nextSibling.disabled = false;
			}
		}
    }

  return;
}
function fnmfifocusout()
{
	var len = document.getElementsByName("MFI_CUSTOMER").length; 
    for(var i=0;i<len;i++)
	{
	   if ( document.getElementsByName("MFI_CUSTOMER")[i].checked == true)
	    {		
			document.getElementsByName("MFI_CUSTOMER")[i].value = 'Y';
			enableTabs("TAB_MFI","~");
			appendData();
			//FCUBS_12.0.3_ZAO_UNICREDIT_19471120 Changes Starts
			/*	appendData(document.getElementById("TBLPageAll"));
				createDOM(dbStrRootTableName);	*/
			//FCUBS_12.0.3_ZAO_UNICREDIT_19471120 Changes Ends
				appendData(document.getElementById("TBLPageAll"));
				g_prev_gAction = gAction; 

				if (gAction = 'MODIFY')
				{
					gAction = 'MODFY'
				}
				if (gAction = 'NEW')
				{
					gAction = 'NEWW'
				}
				fcjRequestDOM = buildUBSXml(); 
				servletURL = "FCClientHandler";
				fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
				   if(fcjResponseDOM) 
					{
					 if (!fnProcessResponse()) 
						{
						return;
						}		       
					}	 		
				gAction = g_prev_gAction;
				return;
	    }
        if ( document.getElementsByName("MFI_CUSTOMER")[i].checked == false)
	    {	        
			disableTabs("TAB_MFI");
			document.getElementsByName("MFI_CUSTOMER")[i].value = 'N';
			//dbDataDOM.selectNodes("//STTM_MFI_DETAILS").removeAll();

		}
	}	
	return;
}

function fnInTab_TAB_MFI_KERNEL(){
	document.getElementsByName("cmdAddRow_BLK_TRAINING")[0].style.visibility="HIDDEN";
	document.getElementsByName("cmdDelRow_BLK_TRAINING")[0].style.visibility="HIDDEN";
   //12.2_SUPPORT_RETRO_23657168 START
	fnEnableElement(document.getElementsByName("BTN_CHKLIST")[0]);
	fnEnableElement(document.getElementsByName("BTN_IDENTIDET")[0]);  
  if (gAction == 'MODIFY'){
			document.getElementsByName("MFI_CUST_TYPE")[0].disabled=true;
			document.getElementsByName("MFI_CUST_TYPE")[1].disabled=true;
			document.getElementsByName("MFI_CUST_TYPE")[2].disabled=true;
	}   
   return true;  
   //12.2_SUPPORT_RETRO_23657168 END  
}	
//FCUBS_MF12.0.1_to_MF12.0.2_Port Ends
//9NT1620_1203_DEV changes starts
function fndisableVrtlCustomerId(){  
if(document.getElementById("BLK_CUSTOMER__ALLOWVRTLACCNTS").checked ){
	fnEnableElement(document.getElementById("BLK_CUSTOMER__VRTLCUSTOMERID"));
	}
	else{
	fnDisableElement(document.getElementById("BLK_CUSTOMER__VRTLCUSTOMERID"));	
	}
	}
	 
//9NT1620_1203_DEV  changes ends

//1203_IUSDBOA_19161766 changes start
function fnInTab_TAB_AUXILIARY_KERNEL()	
{ 
//diable LOV 1
    if (document.getElementById("BLK_CUSTOMER__VALTYP1").value != 'V' ) 		
		document.getElementById("BLK_CUSTOMER__UDF1").nextSibling.style.visibility="hidden"	
		
//disable LOV 2
	  if (document.getElementById("BLK_CUSTOMER__VALTYP2").value != 'V') 
		document.getElementById("BLK_CUSTOMER__UDF2").nextSibling.style.visibility="hidden"	
		
//disable LOV 3
	  if (document.getElementById("BLK_CUSTOMER__VALTYP3").value != 'V' ) 
		document.getElementById("BLK_CUSTOMER__UDF3").nextSibling.style.visibility="hidden"	
		
//disable LOV 4	
	  if (document.getElementById("BLK_CUSTOMER__VALTYP4").value != 'V') 
		document.getElementById("BLK_CUSTOMER__UDF4").nextSibling.style.visibility="hidden"	
		
//disable LOV 5
	  if (document.getElementById("BLK_CUSTOMER__VALTYP5").value != 'V' ) 
		document.getElementById("BLK_CUSTOMER__UDF5").nextSibling.style.visibility="hidden"	
	
	return true;  //12.2_SUPPORT_RETRO_23657168 added

}
//1203_IUSDBOA_19161766 changes end
//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range starts
function fnPreExit_KERNEL()
{

  if (document.getElementById("BLK_CUSTOMER__CUSTNO").value != null  && gAction!='') 
		{
		var resp = fnProcessAction('CANCEL', document.getElementById('TBLPageTAB_HEADER'));
		}
		
return true;
}
//FCUBS_12_2_0_0_0_DEV_CIF_CASA_Range ends

//12.1 Sanction Check Changes start
//Bug#21425319 commented
//function fnInTab_TAB_ADDITIONAL_KERNEL()	
//{ 

 //fnEnableElement(document.getElementById("BLK_CUSTOMER__BTN_SNCKSTATUS"));

//}
//Bug#21425319 commented

function fnCheckSnckstatus(){
    gAction = 'CUSSNCKSTATUS';
	var resp = fnProcessAction('CUSSNCKSTATUS', document.getElementById('TBLPageTAB_HEADER'));
		
	if (resp != 'SUCCESS' ) {
	       var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
			if (msgStatus == 'FAILURE') {
					  return false;
				 }
	}
}


//12.1 Sanction Check Changes end