/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2004 - 2015  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.

Modified By : Kore Sampath Kumar
Modified Reason : Prince Bank AML Changes
------------------------------------------------------------------------------------------
*/

var defaultFullName = false;

function fnDefaultFullName() {
	//alert("DEfauling name");
	//debugger;
	if (document.querySelector('input[name="CTYPE"]:checked').value == "I" && (document.getElementById("BLK_CUSTOMER__NAME").value == "" || document.getElementById("BLK_CUSTOMER__NAME").value == document.getElementById("BLK_CUSTOMER__FULLNAME").value || defaultFullName)) {
		document.getElementById("BLK_CUSTOMER__NAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.substring(0,35);
		document.getElementById("BLK_CUSTOMER__NAME").value = document.getElementById("BLK_CUSTOMER__NAME").value.toUpperCase();
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/NAME"), document.getElementById("BLK_CUSTOMER__NAME").value);
	} else if (document.querySelector('input[name="CTYPE"]:checked').value == "C" || document.querySelector('input[name="CTYPE"]:checked').value == "U" || document.querySelector('input[name="CTYPE"]:checked').value == "R" || document.querySelector('input[name="CTYPE"]:checked').value == "S" || document.querySelector('input[name="CTYPE"]:checked').value == "N") { //loan sector changes sampath starts
		if (document.getElementById("BLK_CUSTCORP__CNAME").value == "") {
			document.getElementById("BLK_CUSTCORP__CNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.substring(0,35);
			document.getElementById("BLK_CUSTCORP__CNAME").value = document.getElementById("BLK_CUSTCORP__CNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTCORP/CNAME"), document.getElementById("BLK_CUSTCORP__CNAME").value);
		}
		
		if (document.getElementById("BLK_CUSTCORP__CORPNAME").value == "") {
			document.getElementById("BLK_CUSTCORP__CORPNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.substring(0,26);
			document.getElementById("BLK_CUSTCORP__CORPNAME").value = document.getElementById("BLK_CUSTCORP__CORPNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTCORP/CORPNAME"), document.getElementById("BLK_CUSTCORP__CORPNAME").value);
		}
	}
	
	defaultFullName = false;
}

function fnDefaultCorrName() {
	if (document.querySelector('input[name="CTYPE"]:checked').value == "I") {
		if (document.getElementById("BLK_CUSTOMER__FULLNAME").value == "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__NAME").value;
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/FULLNAME"), document.getElementById("BLK_CUSTOMER__FULLNAME").value);
		}		
	} else if (document.querySelector('input[name="CTYPE"]:checked').value == "C" || document.querySelector('input[name="CTYPE"]:checked').value == "U" || document.querySelector('input[name="CTYPE"]:checked').value == "R" || document.querySelector('input[name="CTYPE"]:checked').value == "S" || document.querySelector('input[name="CTYPE"]:checked').value == "N") { //loan sector changes sampath starts
		if (document.getElementById("BLK_CUSTOMER__FULLNAME").value == "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTCORP__CNAME").value;
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/FULLNAME"), document.getElementById("BLK_CUSTOMER__FULLNAME").value);
		}
		if (document.getElementById("BLK_CUSTCORP__CORPNAME").value == "") {
			document.getElementById("BLK_CUSTCORP__CORPNAME").value = document.getElementById("BLK_CUSTCORP__CNAME").value.substring(0,26);
			document.getElementById("BLK_CUSTCORP__CORPNAME").value = document.getElementById("BLK_CUSTCORP__CORPNAME").value.toUpperCase();
			setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTCORP/CORPNAME"), document.getElementById("BLK_CUSTCORP__CORPNAME").value);
		}
	}
}

function fnDefaultName() {
	if (document.querySelector('input[name="CTYPE"]:checked').value == "I") {
		if (document.getElementById("BLK_CUSTPERSONAL__FSTNAME").value != "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTPERSONAL__FSTNAME").value;
		}
		if (document.getElementById("BLK_CUSTPERSONAL__MIDNAME").value != "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value + " " + document.getElementById("BLK_CUSTPERSONAL__MIDNAME").value;
		}
		if (document.getElementById("BLK_CUSTPERSONAL__LSTNAME").value != "") {
			document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value + " " + document.getElementById("BLK_CUSTPERSONAL__LSTNAME").value;
		}
		document.getElementById("BLK_CUSTOMER__FULLNAME").value = document.getElementById("BLK_CUSTOMER__FULLNAME").value.toUpperCase();
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/FULLNAME"), document.getElementById("BLK_CUSTOMER__FULLNAME").value);
		defaultFullName = true;
		fnDefaultFullName();
	}
}

function fnDefaultUidVal() {
	if (document.getElementById("BLK_CUSTOMER__UIDNAME").value == "PASSPORT") { //  
		var res = document.getElementById("BLK_CUSTOMER__UIDVAL").value;
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTPERSONAL/PPTNO"),res);
		document.getElementById("BLK_CUSTPERSONAL__PPTNO").value = res;
		
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTPERSONAL/PPTISSDT"), document.getElementById("BLK_CUSTOMER__UNIQUE_ID_ISS_DT").value);
		document.getElementById("BLK_CUSTPERSONAL__PPTISSDTI").value = document.getElementById("BLK_CUSTOMER__UNIQUE_ID_ISS_DT").value;		
		//Prince Bank AML Changes Starts
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTPERSONAL/PPTEXPDT"),document.getElementById("BLK_CUSTOMER__UNIQUE_ID_EXP_DTI").value);
		document.getElementById("BLK_CUSTPERSONAL__PPTEXPDTI").value = document.getElementById("BLK_CUSTOMER__UNIQUE_ID_EXP_DTI").value;
		//Prince Bank AML Changes Ends
	} else if (document.getElementById("BLK_CUSTOMER__UIDNAME").value == "NATIONAL ID") {
		var res = document.getElementById("BLK_CUSTOMER__UIDVAL").value;
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTPERSONAL/NATIONID"),res);
		document.getElementById("BLK_CUSTPERSONAL__NATIONID").value = res;		
	} else if (document.getElementById("BLK_CUSTOMER__UIDNAME").value == "TAX ID") {
		var res = document.getElementById("BLK_CUSTOMER__UIDVAL").value;
		setNodeText(selectSingleNode(dbDataDOM,"//BLK_CUSTOMER/TAXIDNO"),res);
		document.getElementById("BLK_CUSTOMER__TAXIDNO").value = res;		
	}
	
	return true;
}

function fnValidateLim(ev) {
	if (document.querySelector('input[name="CTYPE"]:checked').value == "I") {
		if (document.getElementById("BLK_CUSTOMER__NAME") == null || document.getElementById("BLK_CUSTOMER__NAME").value == "" || document.getElementById("BLK_CUSTOMER__FULLNAME").value == "") {
			ev.stopImmediatePropagation();
			alert("Name not entered yet! Please enter name and then visit limits!");
			return false;
		}
	} else if (document.querySelector('input[name="CTYPE"]:checked').value == "C" || document.querySelector('input[name="CTYPE"]:checked').value == "U" || document.querySelector('input[name="CTYPE"]:checked').value == "R" || document.querySelector('input[name="CTYPE"]:checked').value == "S" || document.querySelector('input[name="CTYPE"]:checked').value == "N") { //loan sector changes sampath starts
		if (document.getElementById("BLK_CUSTCORP__CNAME") == null || document.getElementById("BLK_CUSTCORP__CNAME").value == "" || document.getElementById("BLK_CUSTOMER__FULLNAME").value == "") {
			ev.stopImmediatePropagation();
			alert("Name not entered yet! Please enter name and then visit limits!");
			return false;
		}
	}
	
	if (document.getElementById("BLK_CUSTOMER__LIABID") == null || document.getElementById("BLK_CUSTOMER__LIABID").value == "") {
		ev.stopImmediatePropagation();
		alert("Liability ID not entered yet! Please visit Additional tab and then visit limits!");
		return false;
	}
}

function fnBtnP() {
	//alert("P pressed");
	var x = document.getElementById("CVS_LIM");
	if (x.addEventListener) {
		x.addEventListener("click", fnValidateLim, true);
	} else if (x.attachEvent) {
		x.attachEvent("onclick", fnValidateLim, true);
	}
}
