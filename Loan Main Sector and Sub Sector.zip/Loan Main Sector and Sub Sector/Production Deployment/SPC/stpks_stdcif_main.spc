CREATE OR REPLACE PACKAGE  stpks_stdcif_main AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcif_main.spc
  **
  ** Module     : Static Maintenance
  ** 
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  ** 
  ** 
  ** No part of this work may be reproduced, stored in a retrieval system, adopted 
  ** or transmitted in any form or by any means, electronic, mechanical, 
  ** photographic, graphic, optic recording or otherwise, translated in any 
  ** language or computer language, without the prior written permission of 
  ** Oracle and/or its affiliates. 
  ** 
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East), 
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :  
  Changed By         :  
  Change Description :  
  
  -------------------------------------------------------------------------------------------------------
  */
  
  
TYPE ty_tb_v_sttms_corp_directors IS TABLE OF sttm_corp_directors%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_cust_group IS TABLE OF sttm_cust_group%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_cust_shareholder IS TABLE OF sttm_cust_shareholder%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_lmtms_issuer_limit IS TABLE OF lmtm_issuer_limit%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_fstms_customer_ccy IS TABLE OF fstm_customer_ccy%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_cust_mt920_maint IS TABLE OF sttm_cust_mt920_maint%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__sttms_linkedacc_details IS TABLE OF sttm_linkedacc_details%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_cust_jv IS TABLE OF sttm_cust_jv%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_sttms_cust_doc_checklist IS TABLE OF sttm_cust_doc_checklist%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_stvws_cust_liab_score IS TABLE OF stvw_cust_liab_score%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_stvws_cust_liab_rating IS TABLE OF stvw_cust_liab_rating%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_stvws_cust_liab_exposure IS TABLE OF stvw_cust_liab_exposure%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_stvws_cust_liab_udf IS TABLE OF stvw_cust_liab_udf%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_mftbs_cust_id_master IS TABLE OF mftb_cust_id_master%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_mfvws_training IS TABLE OF mfvw_training%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_mftbs_mfi_checklist IS TABLE OF mftb_mfi_checklist%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cstbs_snck_detail IS TABLE OF cstb_snck_detail%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_customer_channel_info IS TABLE OF sttm_customer_channel_info%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_corp_directors_custom IS TABLE OF sttm_corp_directors_custom%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__custcorp_contact_custom IS TABLE OF sttm_custcorp_contact_custom%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_corp_directortype_custom IS TABLE OF sttm_corp_directortype_custom%ROWTYPE INDEX BY BINARY_INTEGER;

TYPE ty_stdcif IS RECORD (
      v_sttms_customer     sttm_customer%ROWTYPE,
      v_sttms_cust_personal     sttm_cust_personal%ROWTYPE,
      v_sttms_cust_corporate     sttm_cust_corporate%ROWTYPE,
      v_sttms_corp_directors    ty_tb_v_sttms_corp_directors,
      v_sttms_cust_group    ty_tb_v_sttms_cust_group,
      v_sttms_cust_shareholder    ty_tb_v_sttms_cust_shareholder,
      v_sttms_cust_domestic     sttm_cust_domestic%ROWTYPE,
      v_sttms_cust_professional     sttm_cust_professional%ROWTYPE,
      v_lmtms_issuer_master     lmtm_issuer_master%ROWTYPE,
      v_lmtms_issuer_limit    ty_tb_v_lmtms_issuer_limit,
      v_fstms_customer_ccy    ty_tb_v_fstms_customer_ccy,
      v_sttms_cust_mt920_maint    ty_tb_v_sttms_cust_mt920_maint,
      v_lmtms_liab     lmtm_liab%ROWTYPE,
      v_sttms_linkedacc_details    ty_tb__sttms_linkedacc_details,
      v_sttms_cust_jv    ty_tb_v_sttms_cust_jv,
      v_sttms_cust_doc_checklist    ty_tb_sttms_cust_doc_checklist,
      v_cust_doctype_remarks     sttm_cust_doctype_remarks%ROWTYPE,
      v_stvws_cust_liab     stvw_cust_liab%ROWTYPE,
      v_stvws_cust_liab_score    ty_tb_v_stvws_cust_liab_score,
      v_stvws_cust_liab_rating    ty_tb_v_stvws_cust_liab_rating,
      v_stvws_cust_liab_exposure    ty_tb_stvws_cust_liab_exposure,
      v_stvws_cust_liab_udf    ty_tb_v_stvws_cust_liab_udf,
      v_cstb_ui_columns     cstb_ui_columns%ROWTYPE,
      v_sttms_customer__a     sttm_customer%ROWTYPE,
      v_sttms_cust_personal__a     sttm_cust_personal%ROWTYPE,
      v_sttms_cust_seg_mapping     sttm_cust_seg_mapping%ROWTYPE,
      v_sttms_mfi_details     sttm_mfi_details%ROWTYPE,
      v_mftms_ao_cif_linkage     mftm_ao_cif_linkage%ROWTYPE,
      v_mftbs_cust_id_master    ty_tb_v_mftbs_cust_id_master,
      v_mftbs_cust_id_detail     mftb_cust_id_detail%ROWTYPE,
      v_mfvws_training    ty_tb_v_mfvws_training,
      v_mfvws_cif_det     mfvw_cif_det%ROWTYPE,
      v_mftbs_mfi_checklist    ty_tb_v_mftbs_mfi_checklist,
      v_cstbs_snck_master     cstb_snck_master%ROWTYPE,
      v_cstbs_snck_detail    ty_tb_v_cstbs_snck_detail,
      v_cstbs_snck_status     cstb_snck_status%ROWTYPE,
      v_customer_channel_info    ty_tb_v_customer_channel_info,
      v_sttm_customer_custom     sttm_customer_custom%ROWTYPE,
      v_cust_corporate_custom     sttm_cust_corporate_custom%ROWTYPE,
      v_corp_directors_custom    ty_tb_v_corp_directors_custom,
      v_custcorp_contact_custom    ty_tb__custcorp_contact_custom,
      v_corp_directortype_custom    ty_tb_corp_directortype_custom,
                  ty_miccustm Mipks_Miccustm_Main.ty_miccustm,
                  ty_stccifj Stpks_Stccifj_Main.ty_stccifj,
                  ty_sicdiarc Stpks_Sicdiarc_Main.ty_sicdiarc,
                  ty_csccurln Cspks_Csccurln_Main.ty_csccurln,
                  ty_stcciftx Stpks_Stcciftx_Main.ty_stcciftx,
                  ty_stccrdsa Stpks_Stccrdsa_Main.ty_stccrdsa,
                  ty_cscofacm Cspks_Cscofacm_Main.ty_cscofacm,
                  ty_stccuacc Stpks_Stccuacc_Main.ty_stccuacc,
                  ty_stcnsck Stpks_Stcnsck_Main.ty_stcnsck,
                  ty_cscupdoc Cspks_Cscupdoc_Main.ty_cscupdoc,
                  Udf_Details Copkss_Udf_Upload.ty_upl_func_udf,
                  Desc_Fields    Cspks_Req_Global.Ty_Tb_Xml_Data,
                  Addl_Info    Cspks_Req_Global.Ty_Addl_info );


FUNCTION  Fn_Get_Curr_Stage RETURN VARCHAR2 ;
FUNCTION  Fn_Get_Tanked_Stat RETURN VARCHAR2 ;
PROCEDURE Pr_Set_Skip_Sys;
PROCEDURE Pr_Set_Activate_Sys;
FUNCTION  Fn_Skip_Sys RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Kernel;
PROCEDURE Pr_Set_Activate_Kernel;
FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Custom;
PROCEDURE Pr_Set_Activate_Custom;
FUNCTION  Fn_Skip_Custom RETURN BOOLEAN;
FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Wrk_stdcif  IN   OUT stpks_stdcif_Main.ty_stdcif,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Populate_Record_Master (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_stdcif          IN  stpks_stdcif_Main.Ty_stdcif,
                        p_Record_Master     IN OUT Sttbs_Record_Master%ROWTYPE,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;

FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2, 
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_stdcif       IN  OUT stpks_stdcif_Main.Ty_stdcif,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Extract_Custom_Data (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 
FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_exchange_pattern  IN     VARCHAR2,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Int_Main    (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_stdcif          IN OUT  stpks_stdcif_Main.ty_stdcif,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 

FUNCTION Fn_main       (p_source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_stdcif          IN OUT  stpks_stdcif_Main.ty_stdcif,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 


FUNCTION Fn_Process_Request (p_source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Get_Node_Data ( 
p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
END stpks_stdcif_main;
/
CREATE OR REPLACE SYNONYM stpkss_stdcif_main FOR stpks_stdcif_main
/