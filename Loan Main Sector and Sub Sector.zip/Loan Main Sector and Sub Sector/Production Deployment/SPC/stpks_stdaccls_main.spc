CREATE OR REPLACE PACKAGE  stpks_stdaccls_main AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdaccls_main.spc
  **
  ** Module     : Static Maintenance
  ** 
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  ** 
  ** 
  ** No part of this work may be reproduced, stored in a retrieval system, adopted 
  ** or transmitted in any form or by any means, electronic, mechanical, 
  ** photographic, graphic, optic recording or otherwise, translated in any 
  ** language or computer language, without the prior written permission of 
  ** Oracle and/or its affiliates. 
  ** 
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East), 
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :  
  Changed By         :  
  Change Description :  
  
  -------------------------------------------------------------------------------------------------------
  */
  
  
TYPE ty_tb_v_account_class_status IS TABLE OF sttm_account_class_status%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__cstms_accprod_status_gl IS TABLE OF cstm_accprod_status_gl%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_ac_stat_drv IS TABLE OF sttm_ac_stat_drv%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_ttms_aclass_amtblk_order IS TABLE OF sttm_aclass_amtblk_order%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_aclass_products IS TABLE OF sttm_aclass_products%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_aclass_txncode IS TABLE OF sttm_aclass_txncode%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_accls_brn_restr IS TABLE OF sttm_accls_brn_restr%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_accls_ccy_restr IS TABLE OF sttm_accls_ccy_restr%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_sttms_accls_ccy_balances IS TABLE OF sttm_accls_ccy_balances%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_accls_cat_restr IS TABLE OF sttm_accls_cat_restr%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_accls_cus_restr IS TABLE OF sttm_accls_cus_restr%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_aclass_interim_dr_amt IS TABLE OF sttm_aclass_interim_dr_amt%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_aclass_interim_cr_amt IS TABLE OF sttm_aclass_interim_cr_amt%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_aclass_report_gen_time IS TABLE OF sttm_aclass_report_gen_time%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_report_gen_time__gen1 IS TABLE OF sttm_aclass_report_gen_time%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_aclass_doctype IS TABLE OF sttm_aclass_doctype%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_accls_minmax_amt_ccy IS TABLE OF sttm_accls_minmax_amt_ccy%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_aclass_adep_rest IS TABLE OF sttm_aclass_adep_rest%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_aclass_denom_dep IS TABLE OF sttm_aclass_denom_dep%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_accls_min_bal IS TABLE OF sttm_accls_min_bal%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__sttms_accls_min_bal_det IS TABLE OF sttm_accls_min_bal_det%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_acclass_channel IS TABLE OF sttm_acclass_channel%ROWTYPE INDEX BY BINARY_INTEGER;

TYPE ty_stdaccls IS RECORD (
     v_sttms_account_class     sttm_account_class%ROWTYPE,
     v_account_class_status    ty_tb_v_account_class_status,
     v_cstms_accprod_status_gl    ty_tb__cstms_accprod_status_gl,
     v_sttms_ac_stat_drv    ty_tb_v_sttms_ac_stat_drv,
     v_sttms_aclass_amtblk_order    ty_tb_ttms_aclass_amtblk_order,
     v_sttms_aclass_products    ty_tb_v_sttms_aclass_products,
     v_sttms_aclass_txncode    ty_tb_v_sttms_aclass_txncode,
     v_sttms_accls_brn_restr    ty_tb_v_sttms_accls_brn_restr,
     v_sttms_accls_ccy_restr    ty_tb_v_sttms_accls_ccy_restr,
     v_sttms_accls_ccy_balances    ty_tb_sttms_accls_ccy_balances,
     v_sttms_accls_cat_restr    ty_tb_v_sttms_accls_cat_restr,
     v_sttms_accls_cus_restr    ty_tb_v_sttms_accls_cus_restr,
     v_aclass_interim_dr_amt    ty_tb_v_aclass_interim_dr_amt,
     v_aclass_interim_cr_amt    ty_tb_v_aclass_interim_cr_amt,
     v_aclass_report_gen_time    ty_tb_v_aclass_report_gen_time,
     v_report_gen_time__gen1    ty_tb_v_report_gen_time__gen1,
     v_sttms_acl_notice_pref     sttm_acl_notice_pref%ROWTYPE,
     v_cstb_ui_columns     cstb_ui_columns%ROWTYPE,
     v_sttms_aclass_doctype    ty_tb_v_sttms_aclass_doctype,
     v_accls_minmax_amt_ccy    ty_tb_v_accls_minmax_amt_ccy,
     v_sttms_aclass_adep_rest    ty_tb_v_sttms_aclass_adep_rest,
     v_sttms_aclass_denom_dep    ty_tb_v_sttms_aclass_denom_dep,
     v_sttms_accls_min_bal    ty_tb_v_sttms_accls_min_bal,
     v_sttms_accls_min_bal_det    ty_tb__sttms_accls_min_bal_det,
     v_sttms_acclass_channel    ty_tb_v_sttms_acclass_channel,
                 ty_mictracl Mipks_Mictracl_Main.ty_mictracl,
                 Udf_Details Copkss_Udf_Upload.ty_upl_func_udf,
                 Desc_Fields    Cspks_Req_Global.Ty_Tb_Xml_Data,
                 Addl_Info    Cspks_Req_Global.Ty_Addl_info );

FUNCTION  Fn_Get_Curr_Stage RETURN VARCHAR2 ;
FUNCTION  Fn_Get_Tanked_Stat RETURN VARCHAR2 ;
PROCEDURE Pr_Set_Skip_Sys;
PROCEDURE Pr_Set_Activate_Sys;
FUNCTION  Fn_Skip_Sys RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Kernel;
PROCEDURE Pr_Set_Activate_Kernel;
FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Custom;
PROCEDURE Pr_Set_Activate_Custom;
FUNCTION  Fn_Skip_Custom RETURN BOOLEAN;
FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Wrk_stdaccls  IN   OUT stpks_stdaccls_Main.ty_stdaccls,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Populate_Record_Master (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_stdaccls          IN  stpks_stdaccls_Main.Ty_stdaccls,
                        p_Record_Master     IN OUT Sttbs_Record_Master%ROWTYPE,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;

FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2, 
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_stdaccls       IN  OUT stpks_stdaccls_Main.Ty_stdaccls,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Extract_Custom_Data (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 
FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_exchange_pattern  IN     VARCHAR2,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Int_Main    (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_stdaccls          IN OUT  stpks_stdaccls_Main.ty_stdaccls,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 

FUNCTION Fn_main       (p_source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_stdaccls          IN OUT  stpks_stdaccls_Main.ty_stdaccls,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 


FUNCTION Fn_Process_Request (p_source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Get_Node_Data ( 
p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
END stpks_stdaccls_main;
/
CREATE OR REPLACE SYNONYM stpkss_stdaccls_main FOR stpks_stdaccls_main
/