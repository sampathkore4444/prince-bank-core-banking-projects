create table CLTB_LOAN_SECTOR_DTLS_CUSTOM
(
  loan_account_number VARCHAR2(35),
  branch_code         VARCHAR2(3),
  main_sector         VARCHAR2(255),
  sub_sector          VARCHAR2(255),
  of_which_sector     VARCHAR2(255)
)
/
alter table CLTB_LOAN_SECTOR_DTLS_CUSTOM add primary key (LOAN_ACCOUNT_NUMBER, BRANCH_CODE)
/
create table STTB_LOAN_SECTOR_DETAILS
(
  main_sector_code     VARCHAR2(35),
  main_sector_desc     VARCHAR2(255),
  sub_sector_code      VARCHAR2(35),
  sub_sector_desc      VARCHAR2(255),
  of_which_sector_code VARCHAR2(35),
  of_which_sector_desc VARCHAR2(255),
  sub_sector_seq       NUMBER
)
/
create table CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
(
  loan_account_number VARCHAR2(35),
  branch_code         VARCHAR2(3),
  main_sector         VARCHAR2(255),
  sub_sector          VARCHAR2(255),
  of_which_sector     VARCHAR2(255),
  unique_seq_no       VARCHAR2(25)
)
/
-- Create table
create table STTB_CUSTOMER_CAT
(
  cust_type      CHAR(1),
  cust_type_desc VARCHAR2(105),
  cust_cat       VARCHAR2(25),
  cust_cat_desc  VARCHAR2(255)
)
/
alter table STTB_CUSTOMER_CAT add primary key (CUST_TYPE, CUST_CAT)
/
ALTER TABLE STTM_ACCLS_CAT_RESTR MODIFY (CUST_CAT VARCHAR2(25))
/
alter table sttm_customer modify customer_category varchar2(25)
/
alter table sttm_core_customer modify customer_category varchar2(25)
/
