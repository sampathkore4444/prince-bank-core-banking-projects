CREATE OR REPLACE PACKAGE BODY STPKS_STDCIF_CUSTOM AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcif_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2018 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         : Techurate Dev Team
  Change Description : AML Integrations

  Changed By         : Kore Sampath Kumar
  Change Description : Prince Bank AML Changes

  Changed By         : Kore Sampath Kumar
  Change Description : Coral Integration with Flexcube Changes

  Changed By         : Kore Sampath Kumar
  Change Description : Fix for storing customer custom fields itnto custom table

  Changed By         : Kore Sampath Kumar
  Change Description : Auto CIF Account Changes for Mobile Banking

  Changed By         : Kore Sampath Kumar
  Change Description : Delete CIF from coral table to avoid passing old scan id to AML

  Changed By         : Kore Sampath Kumar
  Change Description : AML New Workflow changes

  Changed By         : Kore Sampath Kumar
  Change Description : pin code and address code issue for digital banking

  Changed By         : Kore Sampath Kumar
  Change Description : Make Address codes to be inputted from request xml from DAP

  Changed By         : Kore Sampath Kumar
  Change Description : Delete Issue From DAP For Auto Account Creation With CIF Creation Starts

  Changed By         : Kore Sampath Kumar
  Change Description : EAccount Changes

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdcif_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  --Prince Bank AML Changes Starts
  FUNCTION Phone_validate(P_NUMBER IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    IF P_NUMBER IS NOT NULL THEN
      IF REGEXP_LIKE(P_NUMBER, '^[0-9_\(\)]+$') THEN
        RETURN TRUE;
      ELSE
        RETURN FALSE;
      END IF;
    ELSE
      RETURN TRUE;
    END IF;
  END PHONE_VALIDATE;
  --Prince Bank AML Changes Ends

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdcif           IN OUT stpks_stdcif_Main.ty_stdcif,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_type_structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdcif_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  --Coral Integration with Flexcube Changes Starts

  FUNCTION FN_GET_FUNC_FIELD_VAL(P_TBL_UPL_UDF     IN COPKSS_UDF_UPLOAD.TY_UPL_FUNC_UDF,
                                 P_FUNCTIONID      IN VARCHAR2,
                                 P_FIELD_NAME      IN VARCHAR2,
                                 P_FIELD_NUM       OUT NUMBER,
                                 P_FIELD_VAL       OUT VARCHAR2,
                                 P_ERROR_CODE      IN OUT VARCHAR2,
                                 P_ERROR_PARAMETER IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_FIELD_NAME VARCHAR2(100);
  BEGIN
    DBG('In Fn_Get_Func_Field_Val..Multi..');

    FOR I IN P_TBL_UPL_UDF.FIRST .. P_TBL_UPL_UDF.LAST LOOP
      L_FIELD_NAME := P_TBL_UPL_UDF(I).FIELD_NAME;
      IF SUBSTR(L_FIELD_NAME, 1, 10) = 'FIELD_VAL_' THEN
        BEGIN
          SELECT FIELD_NAME
            INTO L_FIELD_NAME
            FROM CSTMS_FUNCTION_UDF_FIELDS_MAP A
           WHERE FUNCTION_ID = P_FUNCTIONID
             AND A.FIELD_NUM = SUBSTR(L_FIELD_NAME, 11)
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Field is not Linked for the product..');
            P_ERROR_CODE      := 'UV-UDFUP004';
            P_ERROR_PARAMETER := P_FIELD_NAME;
            RETURN FALSE;
        END;
      END IF;
      IF L_FIELD_NAME = P_FIELD_NAME THEN
        P_FIELD_VAL := P_TBL_UPL_UDF(I).FIELD_VAL;
        EXIT;
      END IF;
    END LOOP;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  Fn_Get_Func_Field_Val..');
      DBG(SQLERRM);
      P_ERROR_CODE      := 'UV-UDFUPOTH';
      P_ERROR_PARAMETER := 'Fn_Get_Func_Field_Val~' || SQLCODE;
      RETURN FALSE;
  END FN_GET_FUNC_FIELD_VAL;

  FUNCTION FN_GET_RISK_LEVEL_CNT(P_COUNTRY_CODE IN VARCHAR2) RETURN NUMBER IS
    L_VALUE NUMBER;
  BEGIN
    SELECT DECODE(CODE, 'P', 5, 'V', 4, 'H', 3, 'M', '2', 'L', 1, 5)
      INTO L_VALUE
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = 'RISK_LEVEL_CNT'
       AND VALUE = P_COUNTRY_CODE;

    RETURN L_VALUE;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_VALUE;
  END FN_GET_RISK_LEVEL_CNT;

  FUNCTION FN_GET_LMTM_TYPE_CODE(P_CODE IN VARCHAR2, P_TYPE IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.CODE%TYPE IS
    L_CODE LMTM_TYPE_VALUES.CODE%TYPE;
  BEGIN
    SELECT CODE
      INTO L_CODE
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = P_TYPE
       AND VALUE = P_CODE;

    RETURN L_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_CODE;
  END FN_GET_LMTM_TYPE_CODE;

  FUNCTION FN_HTTP_CALL_PRINCE(P_OUT_MSG        CLOB,
                               P_IN_RESP        IN OUT CLOB,
                               P_url            IN VARCHAR2,
                               p_soapaction_url in varchar2,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_BUFFER_SIZE    NUMBER(10) := 1024;
    L_SUBSTRING_MSG  VARCHAR2(32767);
    L_RAW_DATA       RAW(2000);
    L_CLOB_RESPONSE  CLOB;
    L_URL            CSTB_PARAM.PARAM_VAL%TYPE;
    L_RESP_OK        BOOLEAN;
    L_RESP_NUM       NUMBER;
    l_soapaction_url CSTB_PARAM.PARAM_VAL%TYPE;
  BEGIN

    DEBUG.PR_DEBUG('IF', 'In PR_HTTP_CALL');
    DEBUG.PR_DEBUG('IF', '~' || LENGTH(P_OUT_MSG));
    debug.pr_cdebug('IF', 'XML is ' || P_OUT_MSG);

    DBMS_LOB.CREATETEMPORARY(LOB_LOC => L_CLOB_RESPONSE, CACHE => TRUE);
    UTL_HTTP.SET_TRANSFER_TIMEOUT(60);

    SELECT PARAM_VAL
      INTO l_url
      FROM CSTB_PARAM_CUSTOM
     WHERE param_name = UPPER(P_url); --'CORAL_VALIDATION_WS_URL';

    SELECT param_VAL
      INTO l_soapaction_url
      FROM cstb_param_custom
     where param_name = p_soapaction_url;

    DEBUG.PR_DEBUG('IF', 'l_url-->' || L_URL);
    L_HTTP_REQUEST := UTL_HTTP.BEGIN_REQUEST(URL          => L_URL,
                                             METHOD       => 'POST',
                                             HTTP_VERSION => 'HTTP/1.1');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST, 'User-Agent', 'Mozilla/4.0');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST, 'Connection', 'close');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST,
                        'Content-Length',
                        LENGTH(P_OUT_MSG));
    UTL_HTTP.set_header(l_http_request, 'SOAPAction', l_soapaction_url);
    <<REQUEST_LOOP>>
    FOR I IN 0 .. CEIL(LENGTH(P_OUT_MSG) / L_BUFFER_SIZE) - 1 LOOP
      L_SUBSTRING_MSG := SUBSTR(P_OUT_MSG,
                                I * L_BUFFER_SIZE + 1,
                                L_BUFFER_SIZE);
      DEBUG.PR_DEBUG('FOR', 'L_SUBSTRING_MSG-->' || i || '--' || L_URL);

      BEGIN
        L_RAW_DATA := UTL_RAW.CAST_TO_RAW(L_SUBSTRING_MSG);
        UTL_HTTP.WRITE_RAW(R => L_HTTP_REQUEST, DATA => L_RAW_DATA);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('IF', 'Request Loop NDF');
          EXIT REQUEST_LOOP;
      END;
    END LOOP REQUEST_LOOP;
    L_HTTP_RESPONSE := UTL_HTTP.GET_RESPONSE(L_HTTP_REQUEST);
    DEBUG.PR_DEBUG('IF',
                   'Response> status_code: "' ||
                   L_HTTP_RESPONSE.STATUS_CODE || '"');
    L_RESP_OK := FALSE;
    SELECT DECODE(L_HTTP_RESPONSE.STATUS_CODE, 200, 1, 0)
      INTO L_RESP_NUM
      FROM DUAL;
    -- IF l_http_response.status_code = 200 THEN
    IF L_RESP_NUM = 1 THEN
      L_RESP_OK := TRUE;
    ELSIF L_RESP_NUM = 0 THEN
      L_RESP_OK := FALSE;
    END IF;

    IF L_RESP_OK THEN
      BEGIN

        LOOP
          UTL_HTTP.READ_RAW(L_HTTP_RESPONSE, L_RAW_DATA, L_BUFFER_SIZE);
          L_CLOB_RESPONSE := L_CLOB_RESPONSE ||
                             UTL_RAW.CAST_TO_VARCHAR2(L_RAW_DATA);
        END LOOP RESPONSE_LOOP;
      EXCEPTION
        WHEN UTL_HTTP.END_OF_BODY THEN
          UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IF', SQLERRM);
          DEBUG.PR_DEBUG('IF', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
      END;
      --  DBG('Out of Loop');
      DEBUG.PR_DEBUG('IF',
                     'Length of response-->' ||
                     DBMS_LOB.GETLENGTH(L_CLOB_RESPONSE));
      DEBUG.PR_DEBUG('IF',
                     'value of response-->' ||
                     DBMS_LOB.SUBSTR(L_CLOB_RESPONSE, 32767));
      P_IN_RESP := L_CLOB_RESPONSE;

    END IF;

    IF L_HTTP_REQUEST.PRIVATE_HNDL IS NOT NULL THEN
      UTL_HTTP.END_REQUEST(L_HTTP_REQUEST);
    END IF;

    IF L_HTTP_RESPONSE.PRIVATE_HNDL IS NOT NULL THEN
      UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
    END IF;

    DBMS_LOB.FREETEMPORARY(L_CLOB_RESPONSE);

    IF L_RESP_OK THEN
      DEBUG.PR_DEBUG('IF', 'OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      DEBUG.PR_DEBUG('IF', 'PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In WOT...Return false now...' || SQLERRM ||
                     dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_HTTP_CALL_PRINCE;

  --Coral Integration with Flexcube Changes Ends

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdcif           IN OUT stpks_stdcif_Main.Ty_stdcif,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
    --Prince Bank AML Changes Starts
    L_COUNT NUMBER;
    --Prince Bank AML Changes Ends
    --Coral Integration with Flexcube Changes Starts
    l_val_count number;
    --Coral Integration with Flexcube Changes Ends
  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory');

    --Prince Bank AML Changes Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      --Make Address codes to be inputted from request xml from DAP starts
      IF p_Source IN ('DIGIBANK2', 'DIGIKYC', 'FLEXIPRINCE')  OR
         CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN
         ('DIGIBANK2', 'DIGIKYC', 'FLEXIPRINCE') THEN --EAccount Changes added DIGIKYC --Flexi Changes added FLEXIPRINCE

    DBG('P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45='||P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45);
      DBG('P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD94='||P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD94);
      DBG('P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87='||P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87);
      DBG('P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD86='||P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD86);
      DBG('P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD90='||P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD90);
      DBG('P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD54='||P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD54);

      G_FIELD45 := P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45;
      G_FIELD94 := P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD94;

    --Flexi Changes Starts
    G_FIELD86 := P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD86;
      G_FIELD87 := P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87; --flexi changes for corporate

    IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('I') AND
           P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) AND
           G_FIELD_45_TEMP IS NULL AND
           (p_Source = 'FLEXIPRINCE' OR
           CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('FLEXIPRINCE')) THEN

          G_FIELD_45_TEMP := G_FIELD45;
        END IF;
    --Flexi Changes Ends

        P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD45 := NULL;
        P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD94 := NULL;
        P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD87 := NULL;
        P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD86 := NULL;
        P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD90 := NULL;
        P_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD54 := NULL;
      END IF;
      --Make Address codes to be inputted from request xml from DAP ends

      DBG('P_ACTION_CODE=' || P_ACTION_CODE);

      --Coral Integration with Flexcube Changes Starts
      IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('I', 'C') THEN
        for i in (select * from sttm_validate_uid) loop
          if p_stdcif.v_sttms_customer.unique_id_name = i.uid_type then
            select count(1)
              into l_val_count
              from dual
             where regexp_like(p_stdcif.v_sttms_customer.unique_id_value,
                               i.regex);

            if l_val_count < 1 then
              P_ERR_CODE := 'ST-UID-01';
              --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              PR_LOG_ERROR('STDCIF', 'FLEXCUBE', P_ERR_CODE, '');
              RETURN FALSE;
            end if;

          end if;
        end loop;

        if p_stdcif.v_sttms_customer.unique_id_name = 'NATIONAL ID' and
           p_stdcif.v_sttms_customer.unique_id_value <>
           p_stdcif.v_sttms_cust_personal.p_national_id

         then
          P_ERR_CODE := 'ST-UID-01';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', P_ERR_CODE, '');
          RETURN FALSE;

        elsif p_stdcif.v_sttms_customer.unique_id_name <> 'PASSPORT' and
              p_stdcif.v_sttms_customer.unique_id_value <>
              p_stdcif.v_sttms_cust_personal.passport_no then
          P_ERR_CODE := 'ST-UID-01';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', P_ERR_CODE, '');
          RETURN FALSE;

        elsif

         p_stdcif.v_sttms_customer.unique_id_name = 'TAX ID' and
         p_stdcif.v_sttms_customer.unique_id_value <>
         p_stdcif.v_sttms_customer.TAXID_NO then
          P_ERR_CODE := 'ST-UID-01';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', P_ERR_CODE, '');
          RETURN FALSE;
        end if;
        if p_stdcif.v_sttms_customer.unique_id_name <> 'NATIONAL ID' and
           p_stdcif.v_sttms_customer.unique_id_value =
           p_stdcif.v_sttms_cust_personal.p_national_id then
          p_stdcif.v_sttms_cust_personal.p_national_id := null;

        elsif p_stdcif.v_sttms_customer.unique_id_name <> 'PASSPORT' and
              p_stdcif.v_sttms_customer.unique_id_value =
              p_stdcif.v_sttms_cust_personal.passport_no then
          p_stdcif.v_sttms_cust_personal.passport_no  := null;
          p_stdcif.v_sttms_cust_personal.ppt_iss_date := null;
          p_stdcif.v_sttms_cust_personal.ppt_exp_date := null;
        elsif p_stdcif.v_sttms_customer.unique_id_name <> 'TAX ID' and
              p_stdcif.v_sttms_customer.unique_id_value =
              p_stdcif.v_sttms_customer.TAXID_NO then

          p_stdcif.v_sttms_customer.TAXID_NO := null;

        end if;
      END IF;
      --Coral Integration with Flexcube Changes Ends

      --Validations for Individual Customers
      IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

        IF P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION IS NULL THEN
          DBG('Occupation should not be null for Individual customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-017', '');
        END IF;

        IF P_STDCIF.V_STTMS_CUST_PERSONAL.RESIDENT_STATUS IS NULL THEN
          DBG('Resident Status should not be null for Individual customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-007', '');
        END IF;

        IF P_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER IS NULL THEN
          DBG('Mobile Number should not be null for Individual customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-005', '');
        END IF;

        IF P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY IS NULL THEN
          DBG('Birth Country should not be null for Individual customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-006', '');
        END IF;

        --MOBILE NUMBER VALIDATION
        IF P_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER IS NOT NULL THEN
          IF NOT
              PHONE_VALIDATE(P_STDCIF.V_STTMS_CUST_PERSONAL.MOBILE_NUMBER) THEN
            DBG('Invalid Phone Number ');
            P_ERR_CODE := 'LSVAL-01';
            RETURN FALSE;

          END IF;
        END IF;

        --Monthly Income Validation
        IF P_STDCIF.v_sttm_customer_custom.PROFIT_BASED_CCY IS NULL AND CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') <> 'DIGIKYC' THEN --EAccount Changes added DIGIKYC
          DBG('Monthly Income should not be null for Individual customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-019', '');
        END IF;

      END IF;

      --Validations for Corporate Customers
      --IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN --loan sector sampath commented
	  IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C','U','R','S','N') THEN --loan sector sampath changes

        IF p_stdcif.v_sttms_cust_personal__a.telephone IS NULL THEN
          DBG('Mobile Number should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-005', '');
        END IF;

        IF P_STDCIF.V_CUST_CORPORATE_CUSTOM.COMPLEX_STRUCTURE IS NULL THEN
          DBG('Complex Structure should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-002', '');
        END IF;
        IF P_STDCIF.V_CUST_CORPORATE_CUSTOM.TYPE_OF_ORG IS NULL THEN
          DBG('Type of Organization should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-003', '');
        END IF;
        IF P_STDCIF.V_CUST_CORPORATE_CUSTOM.FORM_OF_ORG IS NULL THEN
          DBG('Form of Organization should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-004', '');
        END IF;

        IF P_STDCIF.v_sttms_cust_corporate.INCORP_DATE IS NULL THEN
          DBG('Incorporation Date should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-012', '');
        END IF;

        IF P_STDCIF.v_sttms_cust_corporate.CAPITAL IS NULL AND
           CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') <> 'FLEXIPRINCE' THEN --flexi changes added FLEXIPRINCE
          DBG('Capital should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-013', '');
        END IF;

        IF P_STDCIF.v_sttms_cust_corporate.AMOUNTS_CCY IS NULL THEN
          DBG('Currency of Amounts should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-014', '');
        END IF;

        IF P_STDCIF.v_sttms_cust_corporate.business_Description IS NULL AND
           CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') <> 'FLEXIPRINCE' THEN --flexi changes added FLEXIPRINCE
          DBG('Business Description should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-015', '');
        END IF;

        IF P_STDCIF.V_CUST_CORPORATE_CUSTOM.resident_status IS NULL THEN
          DBG('Resident Status should not be null for corporate customers');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-018', '');
        END IF;

        DBG('Before assingning directors');
        FOR K IN 1 .. P_STDCIF.V_STTMS_CORP_DIRECTORS.COUNT LOOP
          DBG('Dir Name:' || P_STDCIF.V_STTMS_CORP_DIRECTORS(K)
              .DIRECTOR_NAME);
          DBG('SlNo:' || P_STDCIF.V_STTMS_CORP_DIRECTORS(K).SLNO);
          P_STDCIF.v_corp_directors_custom(K).SLNO := K;
        END LOOP;

      END IF;

      --VALIDATIONS FOR ISSUE AND EXPIRY DATES FOR PASSPORT AND NATIONAL ID AND CIVIL SERVANT CARD AND DRIVER LICENSE
      IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('PASSPORT') THEN
        IF P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN
          DBG('Passport issue date or passport expiry date cannot be null.');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-MAN011', '');
        END IF;
      END IF;

      IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('NATIONAL ID') THEN
        DBG('P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT=' ||
            P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT);
        DBG('P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT=' ||
            P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT);

        IF P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN

          DBG('National ID Issue date or National ID Expiry date cannot be null.');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-001', '');
        END IF;
      END IF;

      IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('CIVIL SERVANT CARD') THEN
        IF P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN

          DBG('Civil Servant Card Issue date or Expiry date cannot be null.');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-008', '');
        END IF;
      END IF;

      IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('DRIVER LICENSE') THEN
        IF P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN

          DBG('Driver License Issue date or Expiry date cannot be null.');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-009', '');
        END IF;
      END IF;

      IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN
         ('GOVERNMENT ISSUED ID') THEN
        IF P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN

          DBG('Government Issue ID Issue date or Expiry date cannot be null.');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-020', '');
        END IF;
      END IF;

      IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('TAX ID') THEN
        IF P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_ISS_DT IS NULL OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT IS NULL THEN

          DBG('Tax Issue date or Expiry date cannot be null.');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-021', '');
        END IF;
      END IF;

      --Check for duplicate unique identifier value
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTM_CUSTOMER
         WHERE UNIQUE_ID_NAME = P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME
           AND UNIQUE_ID_VALUE = P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE
           AND CUSTOMER_NO <> P_STDCIF.v_sttms_customer.CUSTOMER_NO
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;

      IF L_COUNT <> 0 THEN
        PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-PRIN-016', '');
        RETURN FALSE; --Coral Integration with Flexcube Changes
      END IF;
    END IF;
    --Prince Bank AML Changes Ends

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcif_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdcif           IN stpks_stdcif_Main.ty_stdcif,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcif_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdcif           IN stpks_stdcif_Main.ty_stdcif,
                                       p_Prev_stdcif      IN OUT stpks_stdcif_Main.ty_stdcif,
                                       p_Wrk_stdcif       IN OUT stpks_stdcif_Main.ty_stdcif,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)

   RETURN BOOLEAN IS

    --Coral Integration with Flexcube Changes
    L_COUNT          NUMBER;
    L_FULL_NAME_CHK  STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_DATE_CHK       STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_DATE_CHK1      VARCHAR2(100); --Auto CIF Account Changes for Mobile Banking
    L_COUNTRY_CHK    STTMS_CUSTOMER.COUNTRY%TYPE;
    L_OUT_MSG        CLOB;
    L_IN_RESP        CLOB;
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_ATTR_NODES     DBMS_XMLDOM.DOMNAMEDNODEMAP;
    L_ATTR_NODE      DBMS_XMLDOM.DOMNODE;
    L_ATTRIBUTE_NAME VARCHAR2(50);
    L_NODE_NAME      VARCHAR2(50);
    L_NODE_VALUE     VARCHAR2(100);
    P                DBMS_XMLPARSER.PARSER;
    L_DOC            DBMS_XMLDOM.DOMDOCUMENT;
    L_ROOT_ELEMENT   DBMS_XMLDOM.DOMELEMENT;
    L_CHILD_NODES    DBMS_XMLDOM.DOMNODELIST;
    L_CHILD_NODE     DBMS_XMLDOM.DOMNODE;
    L_TEXT_NODE      DBMS_XMLDOM.DOMNODE;
    L_BASE_NODES     DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODES1    DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODE      DBMS_XMLDOM.DOMNODE;
    -- V_XML_DATA         CLOB;
    L_HIT_VALUE           VARCHAR2(100);
    L_RTN_SCAN_ID         VARCHAR2(4000);
    L_RTN_ENCRYPT_SCAN_ID VARCHAR2(4000);
    L_SEARCH_NAME         VARCHAR2(4000);
    L_RETURN_STATUS       VARCHAR2(100);

    L_PEP_FLAG           VARCHAR2(2);
    L_COMPLEX_STRUCTURE  VARCHAR2(1000);
    L_NATIONALITY        VARCHAR2(100);
    L_ADVERSE_MEDIA_FLAG VARCHAR2(2);
    L_REL_HIGH_RISK_FLAG VARCHAR2(2);
    L_CHANNEL            VARCHAR2(5);
    L_PROD_RISK          VARCHAR2(2);
    L_ASSET_VALUE        VARCHAR2(2);
    L_STR                VARCHAR2(2);
    L_BEHAVIOUR_TREND    VARCHAR2(2);
    L_OCCUPATION         VARCHAR2(1000);

    L_RISK_FACTORS VARCHAR2(1000);
    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE TYPE_RISK_SCORE;
    L_MAX_INDEX  NUMBER;
    L_MAX_VALUE  NUMBER;
    L_REF        VARCHAR2(16);
    L_SEQ        NUMBER;
    L_RISK_LEVEL CHAR(1);

    L_FIELD_NUM      NUMBER;
    L_SECURITY_NO_1  CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
    L_SECURITY_NO_2  CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_4%TYPE;
    L_BIRTH_COUNTRY  STTMS_CUSTOMER.COUNTRY%TYPE;
    L_COUNTRY        STTMS_CUSTOMER.COUNTRY%TYPE;
    L_P_COUNTRY      STTMS_CUSTOMER.COUNTRY%TYPE;
    L_ECO_SECTOR     STTMS_CUSTOMER_CUSTOM.ECONOMIC_SEC%TYPE;
    L_R_COUNTRY      STTMS_CUST_CORPORATE.R_COUNTRY%TYPE;
    L_INCORP_COUNTRY STTMS_CUST_CORPORATE.INCORP_COUNTRY%TYPE;

    L_PREV_FULL_NAME_CHK     STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_PREV_DATE_CHK          STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_PREV_COUNTRY_CHK       STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_BIRTH_COUNTRY     STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_COUNTRY           STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_NATIONALITY       STTMS_CUSTOMER.NATIONALITY%TYPE;
    L_PREV_P_COUNTRY         STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_ECO_SECTOR        STTMS_CUSTOMER_CUSTOM.ECONOMIC_SEC%TYPE;
    L_PREV_OCCUPATION        STTMS_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_PREV_COMPLEX_STRUCTURE VARCHAR2(1000);

    L_PREV_SECURITY_NO_1 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
    L_PREV_SECURITY_NO_2 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_4%TYPE;

    L_PREV_R_COUNTRY      STTMS_CUST_CORPORATE.R_COUNTRY%TYPE;
    L_PREV_INCORP_COUNTRY STTMS_CUST_CORPORATE.INCORP_COUNTRY%TYPE;
    --Coral Integration with Flexcube Changes

    --AML New WorkFlow Changes Starts
    L_STTB_CORAL_WS_LOG STTB_CORAL_WS_LOG%ROWTYPE;
    --AML New WorkFlow Changes Ends

  L_SCAN_OPTION VARCHAR2(3);

  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

    --Coral Integration with Flexcube Changes Starts
    -- IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

    IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE NOT IN ('B') OR
       P_SOURCE <> 'FLEXCUBE' THEN --added DAP Issue Condition here
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) AND
         CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') <> 'FLEXIPRINCE' THEN --Flexi changes Added AND Condition

        DBG('I AM IN SAVE');

        IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

          L_FULL_NAME_CHK := TRIM(P_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);

          L_DATE_CHK := TO_DATE(P_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                'DD/MM/RRRR');

          --Auto CIF Account Changes for Mobile Banking starts
          DBG('DATE IN FORMAT1=' ||
              TO_CHAR(p_stdcif.v_sttms_cust_personal.date_of_birth,
                      Cspks_Req_Global.g_Ws_Date_Format));

          DBG('DATE IN FORMAT2=' || SUBSTR(TO_CHAR(p_stdcif.v_sttms_cust_personal.date_of_birth,
                                                   Cspks_Req_Global.g_Ws_Date_Format),
                                           1,
                                           4));

          L_DATE_CHK1 := SUBSTR(TO_CHAR(p_stdcif.v_sttms_cust_personal.date_of_birth,
                                        Cspks_Req_Global.g_Ws_Date_Format),
                                1,
                                4);

      --EAccount Changes Starts
          IF P_SOURCE = 'DIGIKYC' THEN

            L_COUNTRY_CHK := P_STDCIF.v_sttms_cust_personal.BIRTH_COUNTRY;

          ELSE --EAccount Changes
          --Auto CIF Account Changes for Mobile Banking ends

          L_COUNTRY_CHK := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;

      END IF; --EAccount Changes Changes

          --Risk Factors
          L_PEP_FLAG := '0|';

      --EAccount Changes Starts
          IF P_SOURCE = 'DIGIKYC' THEN

            L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY),
                                            FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.COUNTRY),
                                            FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY),
                                            FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY));
      /*TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.COUNTRY),
                                            FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY),
                                            FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY));*/
          ELSE
            --EAccount Changes Ends
          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY));

          END IF; --EAccount Changes added END IF

      L_MAX_INDEX := 1;
          L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

          FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

            IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
              L_MAX_VALUE := L_RISK_SCORE(G);
              L_MAX_INDEX := G;
            END IF;
          END LOOP;

      --EAccount Changes Starts
          IF P_SOURCE = 'DIGIKYC' THEN

      IF L_MAX_INDEX = 1 THEN
              L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY;
            ELSIF L_MAX_INDEX = 2 THEN
              L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
            ELSIF L_MAX_INDEX = 3 THEN
              L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;
            ELSE
              L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY;
            END IF;
      /*
            IF L_MAX_INDEX = 1 THEN
              L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
            ELSIF L_MAX_INDEX = 2 THEN
              L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;
            ELSE
              L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY;
            END IF;*/

          ELSE
            --EAccount Changes Ends
          IF L_MAX_INDEX = 1 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY;
          ELSIF L_MAX_INDEX = 2 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
          ELSIF L_MAX_INDEX = 3 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;
          ELSE
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY;
          END IF;

      END IF; --EAccount Changes added END IF

          --L_ADVERSE_MEDIA_FLAG := '0';
          L_REL_HIGH_RISK_FLAG := '2|';


          IF P_SOURCE NOT IN ('DIGIKYC') THEN
            --EAccount Changes added IF condition
            L_CHANNEL := 'BFTF|';
          ELSE
            --EAccount Changes added ELSE condition
            L_CHANNEL := 'NFTF|'; --EAccount Changes
          END IF; --EAccount Changes added END IF condition

          --Auto CIF Account Changes for Mobile Banking starts
          IF P_SOURCE <> 'FLEXCUBE' OR P_SOURCE IN ('DIGIKYC') THEN
            --EAccount Changes added AND condition

            L_PROD_RISK := '4|';

          ELSE

            L_PROD_RISK := '0|';

          END IF;
          --Auto CIF Account Changes for Mobile Banking ends

          L_ASSET_VALUE     := '0|';
          L_STR             := '0|';

          --EAccount Changes Starts
          IF P_SOURCE IN ('DIGIKYC') THEN

            L_BEHAVIOUR_TREND := '0|';

          ELSE --EAccount Changes added ELSE

          L_BEHAVIOUR_TREND := '1|';

          END IF; --EAccount Changes added End IF

      --EAccount Changes Starts
          IF P_SOURCE IN ('DIGIKYC') THEN

            L_SCAN_OPTION := '1|3';

          ELSE --EAccount Changes added ELSE

            L_SCAN_OPTION := '3|3';

          END IF; --EAccount Changes added END IF


      --EAccount Changes Starts
          IF P_SOURCE = 'DIGIKYC' THEN

            L_OCCUPATION := '0';

          ELSE
            --EAccount Changes Ends
          L_OCCUPATION      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR') ||
                               FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');

          END IF; --EAccount Changes added END IF

      /*L_RISK_FACTORS := L_PEP_FLAG || L_NATIONALITY || '|' ||
          L_ADVERSE_MEDIA_FLAG || L_REL_HIGH_RISK_FLAG ||
          L_CHANNEL || L_PROD_RISK || L_ASSET_VALUE ||
          L_STR || L_BEHAVIOUR_TREND || L_OCCUPATION;*/

          L_RISK_FACTORS := L_PEP_FLAG || L_NATIONALITY || '|' ||
                            L_REL_HIGH_RISK_FLAG || L_CHANNEL ||
                            L_PROD_RISK || L_ASSET_VALUE || L_STR ||
                            L_BEHAVIOUR_TREND || L_OCCUPATION;

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_1',
                                       L_FIELD_NUM,
                                       L_SECURITY_NO_1,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_1 L_SECURITY_NO_1=' ||
              L_SECURITY_NO_1);

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_2',
                                       L_FIELD_NUM,
                                       L_SECURITY_NO_2,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_2 L_SECURITY_NO_2=' ||
              L_SECURITY_NO_2);

          DBG('L_SECURITY_NO_1=' || L_SECURITY_NO_1);
          DBG('L_SECURITY_NO_2=' || L_SECURITY_NO_2);

          IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('PASSPORT') AND
             (L_SECURITY_NO_1 IS NULL OR L_SECURITY_NO_2 IS NULL) THEN
            DBG('Passport Security Numbers should be input by user');
            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-008', '');
            RETURN FALSE;
          END IF;

        --ELSIF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN --loan sector sampath commented
		ELSIF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C','U','R','S','N') THEN --loan sector sampath changes

          DBG(P_STDCIF.V_STTMS_CUST_CORPORATE.CORPORATE_NAME);
          DBG(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE);
          DBG(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);

          L_FULL_NAME_CHK := TRIM(P_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);

          L_DATE_CHK := TO_DATE(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                'DD/MM/RRRR');

          --Auto CIF Account Changes for Mobile Banking starts
          DBG('DATE IN FORMAT1=' ||
              TO_CHAR(p_stdcif.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                      Cspks_Req_Global.g_Ws_Date_Format));

          DBG('DATE IN FORMAT2=' || SUBSTR(TO_CHAR(p_stdcif.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                                   Cspks_Req_Global.g_Ws_Date_Format),
                                           1,
                                           4));

          L_DATE_CHK1 := SUBSTR(TO_CHAR(p_stdcif.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                        Cspks_Req_Global.g_Ws_Date_Format),
                                1,
                                4);

          --Auto CIF Account Changes for Mobile Banking ends

          L_COUNTRY_CHK := P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY;

          --Risk Factors
          L_PEP_FLAG := '0|';

          L_COMPLEX_STRUCTURE := CASE
                                  P_STDCIF.V_CUST_CORPORATE_CUSTOM.COMPLEX_STRUCTURE
                                   WHEN 'LESS THAN 3 LAYERS' THEN
                                    '2|'
                                   WHEN 'MORE THAN OR EQUAL TO 3 LAYERS' THEN
                                    '1|'
                                 END;

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY));

          L_MAX_INDEX := 1;
          L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

          FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

            IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
              L_MAX_VALUE := L_RISK_SCORE(G);
              L_MAX_INDEX := G;
            END IF;
          END LOOP;

          IF L_MAX_INDEX = 1 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY;
          ELSIF L_MAX_INDEX = 2 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY;
          ELSE
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY;
          END IF;

          --L_ADVERSE_MEDIA_FLAG := '0';
          L_REL_HIGH_RISK_FLAG := '2|';
          L_CHANNEL            := 'BFTF|';

          IF P_SOURCE <> 'FLEXCUBE' THEN

            L_PROD_RISK := '4|';

          ELSE

            L_PROD_RISK := '0|';

          END IF;

      L_SCAN_OPTION := '3|3';

          L_PROD_RISK       := '0|';
          L_ASSET_VALUE     := '0|';
          L_STR             := '0|';
          L_BEHAVIOUR_TREND := '1|';
          L_OCCUPATION      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR') ||
                               FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');

          /*L_RISK_FACTORS := L_PEP_FLAG || L_COMPLEX_STRUCTURE ||
          L_NATIONALITY || '|' || L_ADVERSE_MEDIA_FLAG ||
          L_REL_HIGH_RISK_FLAG || L_CHANNEL || L_PROD_RISK ||
          L_ASSET_VALUE || L_STR || L_BEHAVIOUR_TREND ||
          L_OCCUPATION;*/

          L_RISK_FACTORS := L_PEP_FLAG || L_COMPLEX_STRUCTURE ||
                            L_NATIONALITY || '|' || L_REL_HIGH_RISK_FLAG ||
                            L_CHANNEL || L_PROD_RISK || L_ASSET_VALUE ||
                            L_STR || L_BEHAVIOUR_TREND || L_OCCUPATION;

        END IF;

        IF L_FULL_NAME_CHK IS NULL THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Full Name';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --OVPKS.PR_APPENDTBL('ST-MAN01', 'Full Name');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-MAN01', 'Full Name');
          RETURN FALSE;
        END IF;

        IF L_DATE_CHK IS NULL THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Date of Birth';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --OVPKS.PR_APPENDTBL('ST-MAN01', 'Date of Birth');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-MAN01', 'Date of Birth');
          RETURN FALSE;
        END IF;

        IF (L_FULL_NAME_CHK IS NULL OR L_DATE_CHK IS NULL OR
           L_COUNTRY_CHK IS NULL) THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Country';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --OVPKS.PR_APPENDTBL('ST-MAN01', 'Country');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-MAN01', 'Country');
          RETURN FALSE;
        END IF;

        DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT=' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT);
        DBG('P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT=' ||
            P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT);
        DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME=' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME);

        L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
         <soapenv:Header/>
         <soapenv:Body>
            <tem:OnlineScan>

               <tem:AuthUser>AMLSVC</tem:AuthUser>

               <tem:AuthPswd>AMLSVC</tem:AuthPswd>

               <tem:Username>' || GLOBAL.USER_ID ||
                     '</tem:Username>

               <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                     '</tem:BrCode>

               <tem:SysName>FCUBS</tem:SysName>

               <tem:ScanOption>' || L_SCAN_OPTION ||
                     '</tem:ScanOption>

               <tem:UniqueNo>' ||
                     P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO ||
                     '</tem:UniqueNo>

               <tem:SearchName>' || L_FULL_NAME_CHK ||
                     '</tem:SearchName>

               <tem:SearchCountry>' || L_COUNTRY_CHK ||
                     '</tem:SearchCountry>

               <tem:SearchDOB>' || L_DATE_CHK1 ||
                     '</tem:SearchDOB>

               <tem:SearchID>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME = 'PASSPORT' THEN
                        P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE
                       ELSE
                        NULL
                     END || '</tem:SearchID>

               <tem:PassportVerify>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        1
                       ELSE
                        NULL
                     END || '</tem:PassportVerify>

               <tem:SecurityNo1>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        L_SECURITY_NO_1
                       ELSE
                        NULL
                     END || '</tem:SecurityNo1>

               <tem:PassExpiryDtVerify>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        1
                       ELSE
                        NULL
                     END || '</tem:PassExpiryDtVerify>

               <tem:PassExpiryDate>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        TO_CHAR(P_WRK_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT,
                                'YYMMDD')
                       ELSE
                        NULL
                     END || '</tem:PassExpiryDate>

               <tem:SecurityNo2>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        L_SECURITY_NO_2
                       ELSE
                        NULL
                     END || '</tem:SecurityNo2>

               <tem:RiskFactors>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        '1#' || L_RISK_FACTORS
                       WHEN 'C' THEN
                        '2#' || L_RISK_FACTORS
						--loan sector sampath changes starts
                       WHEN 'U' THEN
                        '2#' || L_RISK_FACTORS
                       WHEN 'R' THEN
                        '2#' || L_RISK_FACTORS
                       WHEN 'S' THEN
                        '2#' || L_RISK_FACTORS
                       WHEN 'N' THEN
                        '2#' || L_RISK_FACTORS
                       --loan sector sampath changes ends
                     END || '</tem:RiskFactors>

               <tem:Content></tem:Content>

               <tem:RtnHit>1</tem:RtnHit>

               <tem:RtnScanID>0</tem:RtnScanID>

               <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
            </tem:OnlineScan>
         </soapenv:Body>
      </soapenv:Envelope>';

        /*L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
           <soapenv:Header/>
           <soapenv:Body>
              <tem:OnlineScan>

                 <tem:AuthUser>AMLSVC</tem:AuthUser>

                 <tem:AuthPswd>AMLSVC</tem:AuthPswd>

                 <tem:Username>' || GLOBAL.USER_ID ||
                     '</tem:Username>

                 <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                     '</tem:BrCode>

                 <tem:SysName>FCUBS</tem:SysName>

                 <tem:ScanOption>3|3</tem:ScanOption>

                 <tem:UniqueNo>' ||
                     P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO ||
                     '</tem:UniqueNo>

                 <tem:SearchName>' || L_FULL_NAME_CHK ||
                     '</tem:SearchName>

                 <tem:SearchCountry>' || L_COUNTRY_CHK ||
                     '</tem:SearchCountry>

                 <tem:SearchDOB>' ||
                     TO_CHAR(L_DATE_CHK, 'RRRR') ||
                     '</tem:SearchDOB>

                 <tem:SearchID></tem:SearchID>

                 <tem:PassportVerify></tem:PassportVerify>

                 <tem:SecurityNo1></tem:SecurityNo1>

                 <tem:PassExpiryDtVerify></tem:PassExpiryDtVerify>

                 <tem:PassExpiryDate></tem:PassExpiryDate>

                 <tem:SecurityNo2></tem:SecurityNo2>

                 <tem:RiskFactors>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        '1#' || L_RISK_FACTORS
                       WHEN 'C' THEN
                        '2#' || L_RISK_FACTORS
                     END || '</tem:RiskFactors>

                 <tem:Content></tem:Content>

                 <tem:RtnHit>1</tem:RtnHit>

                 <tem:RtnScanID>0</tem:RtnScanID>

                 <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
              </tem:OnlineScan>
           </soapenv:Body>
        </soapenv:Envelope>';*/

        --Log ONLINE_SCAN request xml
        SELECT FC_CORAL_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

        L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

        DBG('L_REF=' || L_REF);

        --Condition not to log second time
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_CORAL_WS_LOG
           WHERE ACTION = P_ACTION_CODE
             AND CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
             AND SCAN_ID IS NOT NULL;
        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;

        DBG('L_COUNT=' || L_COUNT);

        IF (L_COUNT = 0) THEN

          STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_WS_LOG(L_REF,
                                                    P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                    SYSDATE,
                                                    'ONLINE_SCAN',
                                                    P_ACTION_CODE,
                                                    L_OUT_MSG);

          /*INSERT INTO STTB_CORAL_WS_LOG
            (UNIQUE_REFERENCE_NO, CUSTOMER_NO, INVOKE_DATE, REQ_TYPE, REQ_MSG)
          VALUES
            (L_REF, P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO, SYSDATE, 'ONLINE_SCAN', L_OUT_MSG);*/

          IF NOT FN_HTTP_CALL_PRINCE(L_OUT_MSG,
                                     L_IN_RESP,
                                     'CORAL_VALIDATION_WS_URL',
                                     'CORAL_SOAPACTION_WS_URL',
                                     P_ERR_CODE,
                                     P_ERR_PARAMS)

           THEN

            DBG('FAILED DURING INVOCATION OF CORAL WEBSERVICES');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);

            P_ERR_CODE := 'ST-CRL-003';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          END IF;

          DBG('L_IN_RESP=' || L_IN_RESP);

          P := DBMS_XMLPARSER.NEWPARSER;
          DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
          DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
          L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
          L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
          L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                             'Fault');
          --Parsing failure response from coral
          IF (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) THEN

            FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
              L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
              L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
              L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
              --
              FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
                L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
                L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
                L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
                L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
                IF L_NODE_NAME = 'faultcode' THEN
                  P_ERR_CODE := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'faultstring' THEN
                  P_ERR_PARAMS := L_NODE_VALUE;
                END IF;

                P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                                '-- The Webservices returned a fail XML';
              END LOOP;
            END LOOP;

            OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);

          ELSE

            --Parsing Success Response from coral
            L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                             'OnlineScanResponse');

            FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) - 1 LOOP
              L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
              L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
              L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
              --
              FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
                L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
                L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
                L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
                L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
                --
                IF L_NODE_NAME = 'RtnHit' THEN
                  L_HIT_VALUE := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'RtnScanID' THEN
                  L_RTN_SCAN_ID := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'RtnEnCryptScanID' THEN
                  L_RTN_ENCRYPT_SCAN_ID := L_NODE_VALUE;
                END IF;

              END LOOP;
            END LOOP;

            DBG('L_HIT_VALUE=' || L_HIT_VALUE);
            DBG('L_RTN_SCAN_ID=' || L_RTN_SCAN_ID);
            DBG('L_RTN_ENCRYPT_SCAN_ID=' || L_RTN_ENCRYPT_SCAN_ID);

            IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 OR
               INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'F') > 0 THEN
              L_RETURN_STATUS := 'HIT';
            ELSE
              L_RETURN_STATUS := 'NO HIT';
            END IF;

            SELECT /*DECODE(UPPER(SUBSTR(L_HIT_VALUE, 0, 1)),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            'Y',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            'HIT',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            'NO HIT'),*/
            --SUBSTR(L_HIT_VALUE, 1, 1)
             SUBSTR(L_HIT_VALUE, INSTR(L_HIT_VALUE, '|') + 1, 1)
              INTO /*L_RETURN_STATUS,*/ L_RISK_LEVEL
              FROM DUAL;

      --EAccount Changes Starts
            IF P_SOURCE = 'DIGIKYC' THEN
              L_RISK_LEVEL := 'L';
            END IF;
            --EAccount Changes Ends

            DBG('BEFORE UPDATING RESPONSE IN THE LOG TABLE=' || L_REF);
            --Update ONLINE_SCAN xml ws response
            STPKS_CORAL_WS_LOG.PR_UPDATE_CORAL_WS_LOG(L_REF,
                                                      L_RTN_SCAN_ID,
                                                      L_RETURN_STATUS,
                                                      L_RISK_LEVEL,
                                                      L_HIT_VALUE,
                                                      L_IN_RESP);

            STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_DATA(L_RTN_SCAN_ID,
                                                    L_RETURN_STATUS,
                                                    L_FULL_NAME_CHK,
                                                    L_DATE_CHK,
                                                    L_COUNTRY_CHK,
                                                    GLOBAL.APPLICATION_DATE,
                                                    'open',
                                                    GLOBAL.CURRENT_BRANCH);

            DBG('L_RETURN_STATUS=' || L_RETURN_STATUS);

            IF L_RETURN_STATUS = 'HIT' OR L_RISK_LEVEL = 'H' THEN

              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'ST-PRIN-023',
                           L_RTN_SCAN_ID);

            END IF;

          END IF;

        ELSE
          --added to show same alert again if we click second time
          --AML New Workflow changes Starts

          BEGIN
            SELECT *
              INTO L_STTB_CORAL_WS_LOG
              FROM STTB_CORAL_WS_LOG
             WHERE ACTION = P_ACTION_CODE
               AND CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
               AND SCAN_ID IS NOT NULL;
          EXCEPTION
            WHEN OTHERS THEN
              L_STTB_CORAL_WS_LOG := NULL;
          END;

          IF L_STTB_CORAL_WS_LOG.STATUS = 'HIT' OR
             L_STTB_CORAL_WS_LOG.RISK_LEVEL = 'H' THEN

            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'ST-PRIN-023',
                         L_STTB_CORAL_WS_LOG.SCAN_ID);

          END IF;
          --AML New Workflow changes Ends
        END IF;

      END IF;

      /*IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN

        DBG('I AM IN MODIFY');

        IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

          L_FULL_NAME_CHK      := TRIM(P_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);
          L_PREV_FULL_NAME_CHK := TRIM(P_PREV_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);

          L_DATE_CHK      := TO_DATE(P_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                     'DD/MM/RRRR');
          L_PREV_DATE_CHK := TO_DATE(P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                     'DD/MM/RRRR');

          L_COUNTRY_CHK      := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;
          L_PREV_COUNTRY_CHK := P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;

          L_BIRTH_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);
          L_PREV_BIRTH_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);

          L_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          L_PREV_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUSTOMER.COUNTRY);

          L_NATIONALITY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
          L_PREV_NATIONALITY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);

          L_P_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);
          L_PREV_P_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);

          L_ECO_SECTOR      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR');
          L_PREV_ECO_SECTOR := FN_GET_LMTM_TYPE_CODE(P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR');

          L_OCCUPATION      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');
          L_PREV_OCCUPATION := FN_GET_LMTM_TYPE_CODE(P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');

          --Risk Factors
          L_PEP_FLAG := '0|';

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY));

          L_MAX_INDEX := 1;
          L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

          FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

            IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
              L_MAX_VALUE := L_RISK_SCORE(G);
              L_MAX_INDEX := G;
            END IF;
          END LOOP;

          IF L_MAX_INDEX = 1 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY;
          ELSIF L_MAX_INDEX = 2 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
          ELSIF L_MAX_INDEX = 3 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;
          ELSE
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY;
          END IF;

          DBG('P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY=' ||

              P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);

          --L_ADVERSE_MEDIA_FLAG := '0';
          L_REL_HIGH_RISK_FLAG := '2|';
          L_CHANNEL            := 'BFTF|';
          L_PROD_RISK          := '0|';
          L_ASSET_VALUE        := '0|';
          L_STR                := '0|';
          L_BEHAVIOUR_TREND    := '1|';
          L_OCCUPATION         := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                        'ECO_SECTOR') ||
                                  FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                        'OCCUPATION');

          \*L_RISK_FACTORS := L_PEP_FLAG || L_NATIONALITY || '|' ||
          L_ADVERSE_MEDIA_FLAG || L_REL_HIGH_RISK_FLAG ||
          L_CHANNEL || L_PROD_RISK || L_ASSET_VALUE ||
          L_STR || L_BEHAVIOUR_TREND || L_OCCUPATION;*\

          L_RISK_FACTORS := L_PEP_FLAG || L_NATIONALITY || '|' ||
                            L_REL_HIGH_RISK_FLAG || L_CHANNEL || L_PROD_RISK ||
                            L_ASSET_VALUE || L_STR || L_BEHAVIOUR_TREND ||
                            L_OCCUPATION;

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_1',
                                       L_FIELD_NUM,
                                       L_SECURITY_NO_1,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_1 L_SECURITY_NO_1=' ||
              L_SECURITY_NO_1);

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_2',
                                       L_FIELD_NUM,
                                       L_SECURITY_NO_2,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_2 L_SECURITY_NO_2=' ||
              L_SECURITY_NO_2);

          DBG('L_SECURITY_NO_1=' || L_SECURITY_NO_1);
          DBG('L_SECURITY_NO_2=' || L_SECURITY_NO_2);

          IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('PASSPORT') AND
             (L_SECURITY_NO_1 IS NULL OR L_SECURITY_NO_2 IS NULL) THEN
            DBG('Passport Security Numbers should be input by user');
            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-008', '');
            RETURN FALSE;
          END IF;

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_PREV_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_1',
                                       L_FIELD_NUM,
                                       L_PREV_SECURITY_NO_1,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_1 L_PREV_SECURITY_NO_1=' ||
              L_PREV_SECURITY_NO_1);

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_PREV_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_2',
                                       L_FIELD_NUM,
                                       L_PREV_SECURITY_NO_2,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_2 L_PREV_SECURITY_NO_1=' ||
              L_PREV_SECURITY_NO_1);

          DBG('L_PREV_SECURITY_NO_1=' || L_PREV_SECURITY_NO_1);
          DBG('L_PREV_SECURITY_NO_2=' || L_PREV_SECURITY_NO_2);

        ELSIF P_PREV_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN

          DBG(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.CORPORATE_NAME);
          DBG(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE);
          DBG(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);

          L_FULL_NAME_CHK      := TRIM(P_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);
          L_PREV_FULL_NAME_CHK := TRIM(P_PREV_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);

          L_DATE_CHK      := TO_DATE(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                     'DD/MM/RRRR');
          L_PREV_DATE_CHK := TO_DATE(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                     'DD/MM/RRRR');

          L_COUNTRY_CHK      := P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY;
          L_PREV_COUNTRY_CHK := P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY;

          L_COMPLEX_STRUCTURE := CASE
                                  P_STDCIF.V_CUST_CORPORATE_CUSTOM.COMPLEX_STRUCTURE
                                   WHEN 'LESS THAN 3 LAYERS' THEN
                                    '2|'
                                   WHEN 'MORE THAN OR EQUAL TO 3 LAYERS' THEN
                                    '1|'
                                 END;

          L_PREV_COMPLEX_STRUCTURE := CASE
                                       P_PREV_STDCIF.V_CUST_CORPORATE_CUSTOM.COMPLEX_STRUCTURE
                                        WHEN 'LESS THAN 3 LAYERS' THEN
                                         '2|'
                                        WHEN 'MORE THAN OR EQUAL TO 3 LAYERS' THEN
                                         '1|'
                                      END;

          L_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);
          L_PREV_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);

          L_R_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);
          L_PREV_R_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);

          L_INCORP_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);
          L_PREV_INCORP_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);

          L_ECO_SECTOR      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR');
          L_PREV_ECO_SECTOR := FN_GET_LMTM_TYPE_CODE(P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR');

          L_OCCUPATION      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');
          L_PREV_OCCUPATION := FN_GET_LMTM_TYPE_CODE(P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');

          --Risk Factors
          L_PEP_FLAG := '0|';

          L_COMPLEX_STRUCTURE := CASE
                                  P_STDCIF.V_CUST_CORPORATE_CUSTOM.COMPLEX_STRUCTURE
                                   WHEN 'LESS THAN 3 LAYERS' THEN
                                    '2|'
                                   WHEN 'MORE THAN OR EQUAL TO 3 LAYERS' THEN
                                    '1|'
                                 END;

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY));

          L_MAX_INDEX := 1;
          L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

          FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

            IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
              L_MAX_VALUE := L_RISK_SCORE(G);
              L_MAX_INDEX := G;
            END IF;
          END LOOP;

          IF L_MAX_INDEX = 1 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY;
          ELSIF L_MAX_INDEX = 2 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY;
          ELSE
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY;
          END IF;

          --L_ADVERSE_MEDIA_FLAG := '0';
          L_REL_HIGH_RISK_FLAG := '2|';
          L_CHANNEL            := 'BFTF|';
          L_PROD_RISK          := '0|';
          L_ASSET_VALUE        := '0|';
          L_STR                := '0|';
          L_BEHAVIOUR_TREND    := '1|';
          L_OCCUPATION         := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                        'ECO_SECTOR') ||
                                  FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                        'OCCUPATION');

          \*L_RISK_FACTORS := L_PEP_FLAG || L_COMPLEX_STRUCTURE ||
          L_NATIONALITY || '|' || L_ADVERSE_MEDIA_FLAG ||
          L_REL_HIGH_RISK_FLAG || L_CHANNEL || L_PROD_RISK ||
          L_ASSET_VALUE || L_STR || L_BEHAVIOUR_TREND ||
          L_OCCUPATION;*\

          L_RISK_FACTORS := L_PEP_FLAG || L_COMPLEX_STRUCTURE ||
                            L_NATIONALITY || '|' || L_REL_HIGH_RISK_FLAG ||
                            L_CHANNEL || L_PROD_RISK || L_ASSET_VALUE ||
                            L_STR || L_BEHAVIOUR_TREND || L_OCCUPATION;

        END IF;
        --PUT HERE

        IF L_FULL_NAME_CHK IS NULL THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Full Name';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          OVPKS.PR_APPENDTBL('ST-MAN01', 'Full Name');
        END IF;

        IF L_DATE_CHK IS NULL THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Date of Birth';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          OVPKS.PR_APPENDTBL('ST-MAN01', 'Date of Birth');
        END IF;

        IF (L_FULL_NAME_CHK IS NULL OR L_DATE_CHK IS NULL OR
           L_COUNTRY_CHK IS NULL) THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Country';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          OVPKS.PR_APPENDTBL('ST-MAN01', 'Country');
        END IF;

        DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT=' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT);
        DBG('P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT=' ||
            P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT);
        DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME=' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME);

        L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
           <soapenv:Header/>
           <soapenv:Body>
              <tem:OnlineScan>

                 <tem:AuthUser>AMLSVC</tem:AuthUser>

                 <tem:AuthPswd>AMLSVC</tem:AuthPswd>

                 <tem:Username>' || GLOBAL.USER_ID ||
                     '</tem:Username>

                 <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                     '</tem:BrCode>

                 <tem:SysName>FCUBS</tem:SysName>

                 <tem:ScanOption>3|3</tem:ScanOption>

                 <tem:UniqueNo>' ||
                     P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO ||
                     '</tem:UniqueNo>

                 <tem:SearchName>' || L_FULL_NAME_CHK ||
                     '</tem:SearchName>

                 <tem:SearchCountry>' || L_COUNTRY_CHK ||
                     '</tem:SearchCountry>

                 <tem:SearchDOB>' ||
                     TO_CHAR(L_DATE_CHK, 'RRRR') || '</tem:SearchDOB>

                 <tem:SearchID>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME = 'PASSPORT' THEN
                        P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE
                       ELSE
                        NULL
                     END || '</tem:SearchID>

                 <tem:PassportVerify>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        1
                       ELSE
                        NULL
                     END || '</tem:PassportVerify>

                 <tem:SecurityNo1>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        L_SECURITY_NO_1
                       ELSE
                        NULL
                     END || '</tem:SecurityNo1>

                 <tem:PassExpiryDtVerify>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        1
                       ELSE
                        NULL
                     END || '</tem:PassExpiryDtVerify>

                 <tem:PassExpiryDate>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        TO_CHAR(P_WRK_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT,
                                'YYMMDD')
                       ELSE
                        NULL
                     END || '</tem:PassExpiryDate>

                 <tem:SecurityNo2>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        L_SECURITY_NO_2
                       ELSE
                        NULL
                     END || '</tem:SecurityNo2>

                 <tem:RiskFactors>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        '1#' || L_RISK_FACTORS
                       WHEN 'C' THEN
                        '2#' || L_RISK_FACTORS
                     END || '</tem:RiskFactors>

                 <tem:Content></tem:Content>

                 <tem:RtnHit>1</tem:RtnHit>

                 <tem:RtnScanID>0</tem:RtnScanID>

                 <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
              </tem:OnlineScan>
           </soapenv:Body>
        </soapenv:Envelope>';

        \*L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
           <soapenv:Header/>
           <soapenv:Body>
              <tem:OnlineScan>

                 <tem:AuthUser>AMLSVC</tem:AuthUser>

                 <tem:AuthPswd>AMLSVC</tem:AuthPswd>

                 <tem:Username>' || GLOBAL.USER_ID ||
                     '</tem:Username>

                 <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                     '</tem:BrCode>

                 <tem:SysName>FCUBS</tem:SysName>

                 <tem:ScanOption>3|3</tem:ScanOption>

                 <tem:UniqueNo>' ||
                     P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO ||
                     '</tem:UniqueNo>

                 <tem:SearchName>' || L_FULL_NAME_CHK ||
                     '</tem:SearchName>

                 <tem:SearchCountry>' || L_COUNTRY_CHK ||
                     '</tem:SearchCountry>

                 <tem:SearchDOB>' ||
                     TO_CHAR(L_DATE_CHK, 'RRRR') ||
                     '</tem:SearchDOB>

                 <tem:SearchID></tem:SearchID>

                 <tem:PassportVerify></tem:PassportVerify>

                 <tem:SecurityNo1></tem:SecurityNo1>

                 <tem:PassExpiryDtVerify></tem:PassExpiryDtVerify>

                 <tem:PassExpiryDate></tem:PassExpiryDate>

                 <tem:SecurityNo2></tem:SecurityNo2>

                 <tem:RiskFactors>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        '1#' || L_RISK_FACTORS
                       WHEN 'C' THEN
                        '2#' || L_RISK_FACTORS
                     END || '</tem:RiskFactors>

                 <tem:Content></tem:Content>

                 <tem:RtnHit>1</tem:RtnHit>

                 <tem:RtnScanID>0</tem:RtnScanID>

                 <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
              </tem:OnlineScan>
           </soapenv:Body>
        </soapenv:Envelope>';*\

        --Log ONLINE_SCAN request xml
        SELECT FC_CORAL_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

        L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

        DBG('L_REF=' || L_REF);

        --Condition not to log second time
        IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
          IF L_SECURITY_NO_1 IS NOT NULL AND L_SECURITY_NO_2 IS NOT NULL THEN
            BEGIN
              SELECT COUNT(1)
                INTO L_COUNT
                FROM STTB_MODIFY_IND_CUST
               WHERE ACTION_CODE = P_ACTION_CODE
                 AND CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
                 AND CUST_CATEGORY = 'I'
                 AND CURR_FULL_NAME_CHK = L_FULL_NAME_CHK
                 AND CURR_DATE_CHK = L_DATE_CHK
                 AND CURR_COUNTRY_CHK = L_COUNTRY_CHK
                 AND CURR_BIRTH_COUNTRY =
                     P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY
                 AND CURR_COUNTRY = P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
                    -- AND CURR_NATIONALITY = L_NATIONALITY
                 AND CURR_P_COUNTRY =
                     P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY
                 AND CURR_ECO_SECTOR =
                     P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC
                 AND CURR_OCCUPATION =
                     P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION
                 AND CURR_SECURITY_NO_1 = L_SECURITY_NO_1
                 AND CURR_SECURITY_NO_2 = L_SECURITY_NO_2
                 AND REFERENCE_NO IN
                     (SELECT MAX(REFERENCE_NO)
                        FROM STTB_MODIFY_IND_CUST
                       WHERE ACTION_CODE = P_ACTION_CODE
                         AND CUSTOMER_NO =
                             P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
                         AND CUST_CATEGORY = 'I');

            EXCEPTION
              WHEN OTHERS THEN
                L_COUNT := 0;
            END;
          ELSE
            BEGIN
              SELECT COUNT(1)
                INTO L_COUNT
                FROM STTB_MODIFY_IND_CUST
               WHERE ACTION_CODE = P_ACTION_CODE
                 AND CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
                 AND CUST_CATEGORY = 'I'
                 AND CURR_FULL_NAME_CHK = L_FULL_NAME_CHK
                 AND CURR_DATE_CHK = L_DATE_CHK
                 AND CURR_COUNTRY_CHK = L_COUNTRY_CHK
                 AND CURR_BIRTH_COUNTRY =
                     P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY
                 AND CURR_COUNTRY = P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
                    -- AND CURR_NATIONALITY = L_NATIONALITY
                 AND CURR_P_COUNTRY =
                     P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY
                 AND CURR_ECO_SECTOR =
                     P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC
                 AND CURR_OCCUPATION =
                     P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION
                 AND (CURR_SECURITY_NO_1 IS NULL OR
                     CURR_SECURITY_NO_2 IS NULL OR
                     (CURR_SECURITY_NO_1 IS NULL AND
                     CURR_SECURITY_NO_2 IS NULL))
                 AND REFERENCE_NO IN
                     (SELECT MAX(REFERENCE_NO)
                        FROM STTB_MODIFY_IND_CUST
                       WHERE ACTION_CODE = P_ACTION_CODE
                         AND CUSTOMER_NO =
                             P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
                         AND CUST_CATEGORY = 'I');

            EXCEPTION
              WHEN OTHERS THEN
                L_COUNT := 0;
            END;
          END IF;

          DBG('L_COUNT=' || L_COUNT);

          IF L_COUNT = 0 THEN
            STPKS_CORAL_WS_LOG.PR_INSERT_MODIFY_IND_CUST(L_REF,
                                                         P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                         P_ACTION_CODE,
                                                         'I',
                                                         L_FULL_NAME_CHK,
                                                         L_DATE_CHK,
                                                         L_COUNTRY_CHK,
                                                         P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY,
                                                         P_STDCIF.V_STTMS_CUSTOMER.COUNTRY,
                                                         P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY,
                                                         P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY,
                                                         P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                         P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                         L_SECURITY_NO_1,
                                                         L_SECURITY_NO_2,
                                                         SYSDATE);
          END IF;

          DBG('L_FULL_NAME_CHK=' || L_FULL_NAME_CHK);
          DBG('L_PREV_FULL_NAME_CHK=' || L_PREV_FULL_NAME_CHK);
          DBG('L_DATE_CHK=' || L_DATE_CHK);
          DBG('L_PREV_DATE_CHK=' || L_PREV_DATE_CHK);
          DBG('L_COUNTRY_CHK=' || L_COUNTRY_CHK);
          DBG('L_PREV_COUNTRY_CHK=' || L_PREV_COUNTRY_CHK);
          DBG('L_BIRTH_COUNTRY=' ||
              P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);
          DBG('L_PREV_BIRTH_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);
          DBG('L_COUNTRY=' || P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          DBG('L_PREV_COUNTRY=' || P_PREV_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          DBG('P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY=' ||
              P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
          DBG('P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY=' ||
              P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
          DBG('L_P_COUNTRY=' || P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);
          DBG('L_PREV_P_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);
          DBG('L_ECO_SECTOR=' ||
              P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_PREV_ECO_SECTOR=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_OCCUPATION=' || P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);
          DBG('L_PREV_OCCUPATION=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);
          DBG('L_SECURITY_NO_1=' || L_SECURITY_NO_1);
          DBG('L_PREV_SECURITY_NO_1=' || L_PREV_SECURITY_NO_1);
          DBG('L_SECURITY_NO_2=' || L_SECURITY_NO_2);
          DBG('L_PREV_SECURITY_NO_2=' || L_PREV_SECURITY_NO_2);

        ELSIF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM STTB_MODIFY_CORP_CUST
             WHERE ACTION_CODE = P_ACTION_CODE
               AND CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
               AND CUST_CATEGORY = 'C'
               AND CURR_FULL_NAME_CHK = L_FULL_NAME_CHK
               AND CURR_DATE_CHK = L_DATE_CHK
               AND CURR_COUNTRY_CHK = L_COUNTRY_CHK

               AND CURR_COMPLEX_STRUCT = L_COMPLEX_STRUCTURE
               AND CURR_COUNTRY = P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY
               AND CURR_R_COUNTRY = P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY
               AND CURR_INCORP_COUNTRY =
                   P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY
               AND CURR_ECO_SECTOR =
                   P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC
               AND CURR_OCCUPATION =
                   P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION
               AND REFERENCE_NO IN
                   (SELECT MAX(REFERENCE_NO)
                      FROM STTB_MODIFY_CORP_CUST
                     WHERE ACTION_CODE = P_ACTION_CODE
                       AND CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
                       AND CUST_CATEGORY = 'C');
          EXCEPTION
            WHEN OTHERS THEN
              L_COUNT := 0;
          END;

          DBG('L_COUNT=' || L_COUNT);

          IF L_COUNT = 0 THEN
            STPKS_CORAL_WS_LOG.PR_INSERT_MODIFY_CORP_CUST(L_REF,
                                                          P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                          P_ACTION_CODE,
                                                          'C',
                                                          L_FULL_NAME_CHK,
                                                          L_DATE_CHK,
                                                          L_COUNTRY_CHK,
                                                          L_COMPLEX_STRUCTURE,
                                                          P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY,
                                                          P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY,
                                                          P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY,

                                                          P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                          P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                          SYSDATE);
          END IF;

          DBG('L_FULL_NAME_CHK=' || L_FULL_NAME_CHK);
          DBG('L_PREV_FULL_NAME_CHK=' || L_PREV_FULL_NAME_CHK);
          DBG('L_DATE_CHK=' || L_DATE_CHK);
          DBG('L_PREV_DATE_CHK=' || L_PREV_DATE_CHK);
          DBG('L_COUNTRY_CHK=' || L_COUNTRY_CHK);
          DBG('L_PREV_COUNTRY_CHK=' || L_PREV_COUNTRY_CHK);
          DBG('L_COUNTRY=' || P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);
          DBG('L_PREV_COUNTRY=' || P_PREV_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);
          DBG('L_COMPLEX_STRUCTURE=' || L_COMPLEX_STRUCTURE);
          DBG('L_PREV_COMPLEX_STRUCTURE=' || L_PREV_COMPLEX_STRUCTURE);
          DBG('L_R_COUNTRY=' || P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);
          DBG('L_PREV_R_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);
          DBG('L_INCORP_COUNTRY=' ||
              P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);
          DBG('L_PREV_INCORP_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);
          DBG('L_ECO_SECTOR=' ||
              P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_PREV_ECO_SECTOR=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_INCORP_COUNTRY=' ||
              P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);
          DBG('L_PREV_INCORP_COUNTRY=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);

        END IF;

        IF L_COUNT = 0 AND
           ((P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
           (L_FULL_NAME_CHK <> L_PREV_FULL_NAME_CHK OR
           L_DATE_CHK <> L_PREV_DATE_CHK OR
           L_COUNTRY_CHK <> L_PREV_COUNTRY_CHK OR
           P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY OR
           P_STDCIF.V_STTMS_CUSTOMER.COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUSTOMER.COUNTRY OR
           -- L_NATIONALITY <> L_PREV_NATIONALITY OR --it covers countries
           P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY <>
           P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY OR
           P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC <>
           P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION <>
           P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION OR
           L_SECURITY_NO_1 <> L_PREV_SECURITY_NO_1 OR
           L_SECURITY_NO_2 <> L_PREV_SECURITY_NO_2))

           OR (P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' AND
           (L_FULL_NAME_CHK <> L_PREV_FULL_NAME_CHK OR
           L_DATE_CHK <> L_PREV_DATE_CHK OR
           L_COUNTRY_CHK <> L_PREV_COUNTRY_CHK OR
           L_COMPLEX_STRUCTURE <> L_PREV_COMPLEX_STRUCTURE OR
           P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY OR
           P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY OR
           P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC <>
           P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION <>
           P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION))) THEN

          STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_WS_LOG(L_REF,
                                                    P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                    SYSDATE,
                                                    'ONLINE_SCAN',
                                                    P_ACTION_CODE,
                                                    L_OUT_MSG);

          \* INSERT
            INTO STTB_CORAL_WS_LOG(UNIQUE_REFERENCE_NO,
                                   CUSTOMER_NO,
                                   INVOKE_DATE,
                                   REQ_TYPE,
                                   REQ_MSG) VALUES(L_REF,
                                                   P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                   SYSDATE,
                                                   'ONLINE_SCAN',
                                                   L_OUT_MSG);
          *\

          IF NOT FN_HTTP_CALL_PRINCE(L_OUT_MSG,
                                     L_IN_RESP,
                                     'CORAL_VALIDATION_WS_URL',
                                     'CORAL_SOAPACTION_WS_URL',
                                     P_ERR_CODE,
                                     P_ERR_PARAMS)

           THEN

            DBG('FAILED DURING INVOCATION OF CORAL WEBSERVICES');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);

            P_ERR_CODE := 'ST-CRL-003';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          END IF;

          DBG('L_IN_RESP=' || L_IN_RESP);

          P := DBMS_XMLPARSER.NEWPARSER;
          DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
          DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
          L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
          L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
          L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                             'Fault');
          --Parsing failure response from coral
          IF (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) THEN

            FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
              L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
              L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
              L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
              --
              FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
                L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
                L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
                L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
                L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
                IF L_NODE_NAME = 'faultcode' THEN
                  P_ERR_CODE := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'faultstring' THEN
                  P_ERR_PARAMS := L_NODE_VALUE;
                END IF;

                P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                                '-- The Webservices returned a fail XML';
              END LOOP;
            END LOOP;

            OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);

          ELSE

            --Parsing Success Response from coral
            L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                             'OnlineScanResponse');

            FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) - 1 LOOP
              L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
              L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
              L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
              --
              FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
                L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
                L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
                L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
                L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
                --
                IF L_NODE_NAME = 'RtnHit' THEN
                  L_HIT_VALUE := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'RtnScanID' THEN
                  L_RTN_SCAN_ID := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'RtnEnCryptScanID' THEN
                  L_RTN_ENCRYPT_SCAN_ID := L_NODE_VALUE;
                END IF;

              END LOOP;
            END LOOP;

            DBG('L_HIT_VALUE=' || L_HIT_VALUE);
            DBG('L_RTN_SCAN_ID=' || L_RTN_SCAN_ID);
            DBG('L_RTN_ENCRYPT_SCAN_ID=' || L_RTN_ENCRYPT_SCAN_ID);

            IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 OR
               INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'F') > 0 THEN
              L_RETURN_STATUS := 'HIT';
            ELSE
              L_RETURN_STATUS := 'NO HIT';
            END IF;

            SELECT \*DECODE(UPPER(SUBSTR(L_HIT_VALUE, 0, 1)),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'Y',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'HIT',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'NO HIT'),*\
                                                                                                                                                                                                                                                                                                                                                                                                                                              --SUBSTR(L_HIT_VALUE, 1, 1)*\
             SUBSTR(L_HIT_VALUE, INSTR(L_HIT_VALUE, '|') + 1, 1)
              INTO \*L_RETURN_STATUS,*\ L_RISK_LEVEL
              FROM DUAL;

            DBG('BEFORE UPDATING RESPONSE IN THE LOG TABLE=' || L_REF);
            --Update ONLINE_SCAN xml ws response
            STPKS_CORAL_WS_LOG.PR_UPDATE_CORAL_WS_LOG(L_REF,
                                                      L_RTN_SCAN_ID,
                                                      L_RETURN_STATUS,
                                                      L_RISK_LEVEL,
                                                      L_IN_RESP);

            STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_DATA(L_RTN_SCAN_ID,
                                                    L_RETURN_STATUS,
                                                    L_FULL_NAME_CHK,
                                                    L_DATE_CHK,
                                                    L_COUNTRY_CHK,
                                                    GLOBAL.APPLICATION_DATE,
                                                    'open',
                                                    GLOBAL.CURRENT_BRANCH);

            DBG('L_RETURN_STATUS=' || L_RETURN_STATUS);

            IF L_RETURN_STATUS = 'HIT' OR L_RISK_LEVEL = 'H' THEN

              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'ST-PRIN-023',
                           L_RTN_SCAN_ID);

            END IF;

          END IF;
        END IF;

      END IF;*/

      --END IF;

      --Second API call during auth
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) AND
         CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') <> 'FLEXIPRINCE' THEN --Flexi changes added AND Condition
        DBG('INSIDE AUTH ACTION');
        --Get the scan id
        /*BEGIN
          SELECT SCAN_ID
            INTO L_RTN_SCAN_ID
            FROM STTM_CORAL_DATA_CUSTOM
           WHERE FULL_NAME = TRIM(P_STDCIF.V_STTMS_CUSTOMER.FULL_NAME)
             AND DATEOFBIRTH = TO_DATE(P_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                       'DD/MM/RRRR')
             AND COUNTRY = P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
             AND BRANCH_CODE = P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH
             AND MAKER_DT = P_STDCIF.V_STTMS_CUSTOMER.MAKER_DT_STAMP;
        EXCEPTION
          WHEN OTHERS THEN
            L_RTN_SCAN_ID := NULL;
        END;*/

        BEGIN
          SELECT SCAN_ID, HIT_VALUE
            INTO L_RTN_SCAN_ID, L_HIT_VALUE
            FROM STTB_CORAL_WS_LOG
           WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
             AND UNIQUE_REFERENCE_NO =
                 (SELECT MAX(UNIQUE_REFERENCE_NO)
                    FROM STTB_CORAL_WS_LOG
                   WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
                     AND ACTION <> 'AUTH');
          --AND STATUS NOT IN ('PENDING');
        EXCEPTION
          WHEN OTHERS THEN
            L_RTN_SCAN_ID := NULL;
        END;

        DBG('L_RTN_SCAN_ID=' || L_RTN_SCAN_ID);
        DBG('L_HIT_VALUE=' || L_HIT_VALUE);

        IF L_HIT_VALUE NOT IN ('NNN|L', 'NNN|M') AND
           CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') <> 'FLEXIPRINCE'  THEN --Flexi Changes added AND Condition
          IF L_RTN_SCAN_ID IS NULL THEN

            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', ' ST-PRIN-022', '');

            RETURN FALSE;

          END IF;

          L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
       <soapenv:Header/>
       <soapenv:Body>
          <tem:OnlineStatus>

             <tem:AuthUser>AMLSVC</tem:AuthUser>

             <tem:AuthPass>AMLSVC</tem:AuthPass>

             <tem:Username>' || GLOBAL.USER_ID ||
                       '</tem:Username>

             <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                       '</tem:BrCode>

             <tem:SysName>FCUBS</tem:SysName>

             <tem:ScanOption>3</tem:ScanOption>
             <tem:UniqueNo></tem:UniqueNo>


             <tem:scanID>' || L_RTN_SCAN_ID ||
                       '</tem:scanID>

             <tem:rtnResult></tem:rtnResult>
          </tem:OnlineStatus>
       </soapenv:Body>
    </soapenv:Envelope>';

          --Log ONLINE_STATUS request xml
          SELECT FC_CORAL_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

          L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) ||
                   LPAD(L_SEQ, 9, '0');

          DBG('L_REF=' || L_REF);

          STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_WS_LOG(L_REF,
                                                    P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                    SYSDATE,
                                                    'ONLINE_STATUS',
                                                    P_ACTION_CODE,
                                                    L_OUT_MSG);

          IF NOT FN_HTTP_CALL_PRINCE(L_OUT_MSG,
                                     L_IN_RESP,
                                     'CORAL_VALIDATION_CONFIRM_URL',
                                     'CORAL_SOAPACTION_CONFIRM_URL',
                                     P_ERR_CODE,
                                     P_ERR_PARAMS)

           THEN

            DBG(SQLERRM ||
                ' Failed durINg Invocation of COral Webservices ' ||
                P_ERR_CODE);
            P_ERR_CODE := 'ST-CRL-003';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          END IF;

          DBG('L_IN_RESP=' || L_IN_RESP);
          P := DBMS_XMLPARSER.NEWPARSER;
          DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
          DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
          L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
          L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
          L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                             'Fault');
          if (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) then

            FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
              L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
              L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
              L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
              --
              FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
                l_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
                L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
                L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
                L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);

                IF L_NODE_NAME = 'faultcode' THEN
                  P_ERR_CODE := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'faultstring' THEN
                  P_ERR_PARAMS := L_NODE_VALUE;
                END IF;
                dbg('The Webservices returned a Failed Webservice XML ' ||
                    P_ERR_CODE || P_ERR_PARAMS);
                P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                                '-- The Webservices returned a fail XML';
              END LOOP;
            END LOOP;
            OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);

          Else
            L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                             'OnlineStatusResponse');

            FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) LOOP
              L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
              L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
              L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
              --
              FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
                L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
                L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
                L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
                L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
                --
                IF L_NODE_NAME = 'rtnResult' THEN
                  L_HIT_VALUE := L_NODE_VALUE;
                  DBG('L_HIT_VALUE DURING SECOND WEBSERVICE CALL=' ||
                      L_HIT_VALUE);

                END IF;
              END LOOP;
            END LOOP;
            SELECT DECODE(L_HIT_VALUE,
                          'P',
                          'PENDING',
                          'R',
                          'REJECTED',
                          'G',
                          'APPROVED',
                          L_HIT_VALUE)
              INTO L_RETURN_STATUS
              FROM DUAL;
            dbg('L_RETURN_STATUS=' || L_RETURN_STATUS);

            --Update ONLINE_SCAN xml ws response
            STPKS_CORAL_WS_LOG.PR_UPDATE_CORAL_WS_LOG(L_REF,
                                                      L_RTN_SCAN_ID,
                                                      L_RETURN_STATUS,
                                                      L_IN_RESP);

            UPDATE STTMS_CORAL_DATA_CUSTOM
               SET HIT_TYPE = L_RETURN_STATUS
             WHERE SCAN_ID = L_RTN_SCAN_ID
               AND FULL_NAME = TRIM(P_STDCIF.V_STTMS_CUSTOMER.FULL_NAME)
               AND DATEOFBIRTH = TO_DATE(P_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                         'DD/MM/RRRR')
               AND COUNTRY = P_STDCIF.V_STTMS_CUSTOMER.COUNTRY
               AND BRANCH_CODE = P_STDCIF.V_STTMS_CUSTOMER.LOCAL_BRANCH
               AND MAKER_DT = P_STDCIF.V_STTMS_CUSTOMER.MAKER_DT_STAMP;

            DBG(SQL%ROWCOUNT || L_RTN_SCAN_ID);

            IF L_RETURN_STATUS IN ('REJECTED') THEN
              P_ERR_CODE := 'ST-PRIN-010';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;
            END IF;

            IF L_RETURN_STATUS IN ('PENDING') THEN
              P_ERR_CODE := 'ST-PRIN-011';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;
            END IF;
          END IF;

        END IF;
      END IF;
    END IF; --Fix for Bank Customer Type
    --Coral Integration with Flexcube Changes Ends

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcif_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdcif           IN stpks_stdcif_Main.Ty_stdcif,
                                        p_Prev_stdcif      IN OUT stpks_stdcif_Main.Ty_stdcif,
                                        p_Wrk_stdcif       IN OUT stpks_stdcif_Main.Ty_stdcif,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

  --Make Address codes to be inputted from request xml from DAP starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN


        IF p_Source IN ('DIGIBANK2', 'DIGIKYC', 'FLEXIPRINCE') OR
         CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN
         ('DIGIBANK2', 'DIGIKYC', 'FLEXIPRINCE') THEN --Flexi changes added AND condition
        --EAccount Changes added DIGIKYC

    DBG('g_field45=' || g_field45);
        DBG('g_field94=' || g_field94);
        DBG('g_field86=' || g_field86);
        DBG('g_field87=' || g_field87);

        p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD45 := NVL(g_field45,
                                                           g_field94 /*G_FIELD86*/); --flexi added nvl condition
        p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD94 := g_field94;

    p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86 := g_field86; --flexi for corporate
        p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD87 := g_field87; --flexi for corporate

        DBG('p_stdcif.v_sttms_customer__a.pincode==' ||
            p_stdcif.v_sttms_customer__a.pincode);
        DBG('p_WRK_stdcif.v_sttms_customer__a.pincode==' ||
            p_WRK_stdcif.v_sttms_customer__a.pincode);

    IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B', 'U', 'R', 'S', 'N') THEN --loan sector sampath changes
          IF NVL(P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD32, 'N') = 'N' THEN
            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86 := NVL(g_field86,
                                                               g_field87); --flexi for corporate

            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD87 := p_stdcif.v_sttms_customer__a.pincode;

            --P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY; --flexi for corporate
          ELSE
            P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY := P_WRK_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86   := NVL(g_field86,
                                                                 g_field87);

            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD87 := p_stdcif.v_sttms_customer__a.pincode;

          END IF;

          DBG('p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86=' ||
              p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86);

        END IF;

        dbg('p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD87=' ||
            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD87);
        END IF;

    END IF;

--Make Address codes to be inputted from request xml form DAP ends

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcif_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdcif           IN stpks_stdcif_Main.Ty_stdcif,
                            p_Prev_stdcif      IN stpks_stdcif_Main.Ty_stdcif,
                            p_Wrk_stdcif       IN OUT stpks_stdcif_Main.Ty_stdcif,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..');

    --sampath starts for pin code and address code issue

    IF p_Source IN ('DIGIBANK2', 'DIGIKYC', 'FLEXIPRINCE') OR CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('DIGIBANK2', 'DIGIKYC', 'FLEXIPRINCE') THEN --EAccount Changes added DIGIKYC --Flexi Changes added FLEXIPRINCE

      --P_SOURCE <> 'FLEXCUBE' THEN

      P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD6 := P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;

    END IF;

    --sampath ends for pin code and address code issue

    --Fix for storing customer custom fields itnto custom table Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      p_Wrk_stdcif.v_sttm_customer_custom.customer_no := p_stdcif.v_sttms_customer.customer_no;
    END IF;
    --Fix for storing customer custom fields itnto custom table Ends

  --flexi starts
    IF (p_Source IN ('FLEXIPRINCE') OR CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('FLEXIPRINCE')) AND P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      IF P_WRK_STDCIF.v_custcorp_contact_custom.COUNT > 0 THEN

        FOR G IN 1 .. P_WRK_STDCIF.v_custcorp_contact_custom.COUNT LOOP

          P_WRK_STDCIF.v_custcorp_contact_custom(G).CUSTOMER_NO := p_stdcif.v_sttms_customer.CUSTOMER_NO;

        END LOOP;

      END IF;

      DBG('P_WRK_STDCIF.v_corp_directors_custom.COUNT=' ||
          P_WRK_STDCIF.v_corp_directors_custom.COUNT);

      IF P_WRK_STDCIF.v_corp_directors_custom.COUNT > 0 THEN

        FOR G IN 1 .. P_WRK_STDCIF.v_corp_directors_custom.COUNT LOOP

           DBG('p_stdcif.v_corp_directors_custom(G).director_type='||p_stdcif.v_corp_directors_custom(G).director_type);
           DBG('P_WRK_STDCIF.v_corp_directors_custom(G).director_type='||P_WRK_STDCIF.v_corp_directors_custom(G).director_type);

          P_WRK_STDCIF.v_corp_directors_custom(G).CUSTOMER_NO := p_stdcif.v_sttms_customer.CUSTOMER_NO;
          --P_WRK_STDCIF.v_corp_directors_custom(G).director_type := p_stdcif.v_corp_directors_custom(G).director_type;

        END LOOP;

      END IF;

      IF P_WRK_STDCIF.v_corp_directortype_custom.COUNT > 0 THEN

        FOR G IN 1 .. P_WRK_STDCIF.v_corp_directortype_custom.COUNT LOOP

          DBG('p_stdcif.v_corp_directortype_custom(G).director_type='||p_stdcif.v_corp_directortype_custom(G).director_type);
          DBG('P_WRK_STDCIF.v_corp_directortype_custom(G).remarks='||P_WRK_STDCIF.v_corp_directortype_custom(G).remarks);

          P_WRK_STDCIF.v_corp_directortype_custom(G).CUSTOMER_NO := p_stdcif.v_sttms_customer.CUSTOMER_NO;

          P_WRK_STDCIF.v_corp_directors_custom(G).director_type := p_stdcif.v_corp_directortype_custom(G).director_type;

          --P_WRK_STDCIF.v_corp_directors_custom(G).director_type := p_stdcif.v_corp_directors_custom(G).director_type;

        END LOOP;

      END IF;

      IF P_WRK_STDCIF.v_corp_directortype_custom.COUNT <>
         P_WRK_STDCIF.v_sttms_corp_directors.COUNT THEN

        PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-FLEXI-01', '');

        RETURN FALSE;

      END IF;

      FOR G IN 1 .. P_WRK_STDCIF.v_corp_directortype_custom.COUNT LOOP

        IF P_WRK_STDCIF.v_corp_directortype_custom(G)
         .SNO <> P_WRK_STDCIF.v_sttms_corp_directors(G).SLNO THEN

          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-FLEXI-02', '');

          RETURN FALSE;

        END IF;

      END LOOP;

     --flexi joint starts

     IF P_WRK_STDCIF.v_sttms_customer.CUSTOMER_TYPE = 'I' THEN

      DBG('P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT='||P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT);

      DBG('P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.ACCOUNT_TYPE='||P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.ACCOUNT_TYPE);


      IF P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT > 0 THEN

        --IF P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.ACCOUNT_TYPE = 'S' THEN

        P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.AC_DESC := P_WRK_STDCIF.v_sttms_customer.CUSTOMER_NAME1;

          FOR G IN 1 .. P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT.COUNT LOOP

            DBG('CUSTOMER NAME=' || P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(G)
                                                        .JOINT_HOLDER_DESCRIPTION);

            DBG('P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.MODE_OF_OPERATION='||P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.MODE_OF_OPERATION);

            IF P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.MODE_OF_OPERATION = 'E' THEN

              P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.AC_DESC := P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.AC_DESC ||
                                                         ' / ' || P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(G)
                                                        .JOINT_HOLDER_DESCRIPTION;

            ELSIF P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.MODE_OF_OPERATION IN
                  ('J', 'M') THEN

              P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.AC_DESC := P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.AC_DESC ||
                                                         ' & ' || P_WRK_STDCIF.TY_STCCUACC.V_STVWS_AUTO_ACC_JOINT(G)
                                                        .JOINT_HOLDER_DESCRIPTION;

            END IF;

            DBG('P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.AC_DESC='||P_WRK_STDCIF.ty_stccuacc.v_stvws_auto_account.AC_DESC);

          END LOOP;

        --END IF;

      END IF;
      END IF;
      --flexi joint ends
    END IF;

  --Make Address codes to be inputted from request xml flexi starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      DBG('p_Source==' || p_Source);
      DBG('P_ACTION_CODE====' || P_ACTION_CODE);

      IF p_Source IN (/*'DIGIBANK2', 'DIGIKYC', */'FLEXIPRINCE') OR
         CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN
         (/*'DIGIBANK2', 'DIGIKYC',*/ 'FLEXIPRINCE') THEN
        --EAccount Changes added DIGIKYC

        DBG('g_field45=' || g_field45);
        DBG('g_field94=' || g_field94);
        DBG('g_field86=' || g_field86);
        DBG('g_field87=' || g_field87);
        DBG('p_stdcif.v_sttms_customer__a.pincode=' ||
            p_stdcif.v_sttms_customer__a.pincode);
        dbg('p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD45=' ||
            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD45);

        dbg('G_FIELD_45_TEMP=' || G_FIELD_45_TEMP);

        IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE NOT IN ('I') AND
           P_ACTION_CODE NOT IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN

          p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD45 := NVL(g_field45,
                                                             g_field94 /*G_FIELD86*/); --flexi added nvl condition
        ELSE
          p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD45 := G_FIELD_45_TEMP;
        END IF;

        p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD94 := g_field94;

        p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86 := g_field86; --flexi for corporate
        p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD87 := g_field87; --flexi for corporate

        DBG('P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD32=' ||
            P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD32);

        --IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B') THEN --loan sector sampath commented
		IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B', 'U','R','S','N') THEN --loan sector sampath changes
          IF NVL(P_WRK_STDCIF.V_CSTB_UI_COLUMNS.CHAR_FIELD32, 'N') = 'N' THEN
            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86 := NULL; -- NVL(g_field86,
            --g_field87); --flexi for corporate

            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD87 := p_stdcif.v_sttms_customer__a.pincode;
            --P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY := P_WRK_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY; --flexi for corporate

          ELSE
            P_WRK_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY := P_WRK_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86   := NVL(g_field86,
                                                                 g_field87);

            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD87 := p_stdcif.v_sttms_customer__a.pincode;
            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86 := p_stdcif.v_sttms_customer__a.pincode;
          END IF;

          DBG('p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86=' ||
              p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD86);
          DBG('p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD45=' ||
              p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD45);

        END IF;

      END IF;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      DBG('p_Source==' || p_Source);

      DBG('P_ACTION_CODE====' || P_ACTION_CODE);

      IF p_Source IN ( /*'DIGIBANK2', 'DIGIKYC', */ 'FLEXIPRINCE') OR
         CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN
         ( /*'DIGIBANK2', 'DIGIKYC', */ 'FLEXIPRINCE') THEN

        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('I') THEN

          IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN

            DBG('g_field45=' || g_field45);
            DBG('g_field94=' || g_field94);

            p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD94 := g_field45;

          END IF;

        END IF;

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

          DBG('g_field45=' || g_field45);
          DBG('g_field94=' || g_field94);

          p_Wrk_stdcif.V_CSTB_UI_COLUMNS.CHAR_FIELD94 := G_FIELD_45_TEMP;

        END IF;

      END IF;

    END IF;

    --Make Address codes to be inputted from request xml flexi ends

    --flexi ends

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcif_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdcif           IN stpks_stdcif_Main.Ty_stdcif,
                             p_prev_stdcif      IN stpks_stdcif_Main.Ty_stdcif,
                             p_wrk_stdcif       IN OUT stpks_stdcif_Main.Ty_stdcif,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_FIELD_VAL_2  CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_2%type;
    L_FIELD_VAL_3  CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_3%type;
    L_FIELD_VAL_4  CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_4%type;
    L_FIELD_VAL_5  CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_5%type;
    L_FIELD_VAL_6  CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_6%type;
    L_FIELD_VAL_7  CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_7%type;
    L_FIELD_VAL_8  CSTM_FUNCTION_USERDEF_FIELDS.Field_Val_8%type;
    REC_DATA_TABLE CSPKS_AML_INTEGRATION_CUSTOM.TY_DATA_TABLE;
    L_HIT_VAL      VARCHAR2(20);

    --Coral Integration with Flexcube Changes Commented Starts
    /*--AML Dup Changes
    L_COUNT          NUMBER;
    L_COUNT2         NUMBER;
    L_RETURN_SCAN_ID VARCHAR2(50);
    --AML Dup Changes*/
    --Coral Integration with Flexcube Changes Commented Ends

    --Coral Integration with Flexcube Changes Starts
    L_COUNT          NUMBER;
    L_FULL_NAME_CHK  STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_DATE_CHK       STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_DATE_CHK1      VARCHAR2(100); --Auto CIF Account Changes for Mobile Banking
    L_COUNTRY_CHK    STTMS_CUSTOMER.COUNTRY%TYPE;
    L_OUT_MSG        CLOB;
    L_IN_RESP        CLOB;
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_ATTR_NODES     DBMS_XMLDOM.DOMNAMEDNODEMAP;
    L_ATTR_NODE      DBMS_XMLDOM.DOMNODE;
    L_ATTRIBUTE_NAME VARCHAR2(50);
    L_NODE_NAME      VARCHAR2(50);
    L_NODE_VALUE     VARCHAR2(100);
    P                DBMS_XMLPARSER.PARSER;
    L_DOC            DBMS_XMLDOM.DOMDOCUMENT;
    L_ROOT_ELEMENT   DBMS_XMLDOM.DOMELEMENT;
    L_CHILD_NODES    DBMS_XMLDOM.DOMNODELIST;
    L_CHILD_NODE     DBMS_XMLDOM.DOMNODE;
    L_TEXT_NODE      DBMS_XMLDOM.DOMNODE;
    L_BASE_NODES     DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODES1    DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODE      DBMS_XMLDOM.DOMNODE;
    -- V_XML_DATA         CLOB;
    L_HIT_VALUE           VARCHAR2(100);
    L_RTN_SCAN_ID         VARCHAR2(4000);
    L_RTN_ENCRYPT_SCAN_ID VARCHAR2(4000);
    L_SEARCH_NAME         VARCHAR2(4000);
    L_RETURN_STATUS       VARCHAR2(100);

    L_PEP_FLAG           VARCHAR2(2);
    L_COMPLEX_STRUCTURE  VARCHAR2(1000);
    L_NATIONALITY        VARCHAR2(100);
    L_ADVERSE_MEDIA_FLAG VARCHAR2(2);
    L_REL_HIGH_RISK_FLAG VARCHAR2(2);
    L_CHANNEL            VARCHAR2(5);
    L_PROD_RISK          VARCHAR2(2);
    L_ASSET_VALUE        VARCHAR2(2);
    L_STR                VARCHAR2(2);
    L_BEHAVIOUR_TREND    VARCHAR2(2);
    L_OCCUPATION         VARCHAR2(1000);

    L_RISK_FACTORS VARCHAR2(1000);
    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE TYPE_RISK_SCORE;
    L_MAX_INDEX  NUMBER;
    L_MAX_VALUE  NUMBER;
    L_REF        VARCHAR2(16);
    L_SEQ        NUMBER;
    L_RISK_LEVEL CHAR(1);

    L_FIELD_NUM      NUMBER;
    L_SECURITY_NO_1  CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
    L_SECURITY_NO_2  CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_4%TYPE;
    L_BIRTH_COUNTRY  STTMS_CUSTOMER.COUNTRY%TYPE;
    L_COUNTRY        STTMS_CUSTOMER.COUNTRY%TYPE;
    L_P_COUNTRY      STTMS_CUSTOMER.COUNTRY%TYPE;
    L_ECO_SECTOR     STTMS_CUSTOMER_CUSTOM.ECONOMIC_SEC%TYPE;
    L_R_COUNTRY      STTMS_CUST_CORPORATE.R_COUNTRY%TYPE;
    L_INCORP_COUNTRY STTMS_CUST_CORPORATE.INCORP_COUNTRY%TYPE;

    L_PREV_FULL_NAME_CHK     STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_PREV_DATE_CHK          STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_PREV_COUNTRY_CHK       STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_BIRTH_COUNTRY     STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_COUNTRY           STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_NATIONALITY       STTMS_CUSTOMER.NATIONALITY%TYPE;
    L_PREV_P_COUNTRY         STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_ECO_SECTOR        STTMS_CUSTOMER_CUSTOM.ECONOMIC_SEC%TYPE;
    L_PREV_OCCUPATION        STTMS_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_PREV_COMPLEX_STRUCTURE VARCHAR2(1000);

    L_PREV_SECURITY_NO_1 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
    L_PREV_SECURITY_NO_2 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_4%TYPE;

    L_PREV_R_COUNTRY        STTMS_CUST_CORPORATE.R_COUNTRY%TYPE;
    L_PREV_INCORP_COUNTRY   STTMS_CUST_CORPORATE.INCORP_COUNTRY%TYPE;
    L_INSERT_FLAG           BOOLEAN := FALSE;
    L_STTB_MODIFY_IND_CUST  STTB_MODIFY_IND_CUST%ROWTYPE;
    L_STTB_MODIFY_CORP_CUST STTB_MODIFY_CORP_CUST%ROWTYPE;
    --Coral Integration with Flexcube Changes Ends

    --Auto CIF Account Changes for Mobile Banking Starts
    L_UDF_RECORD        CSTMS_FUNCTION_USERDEF_FIELDS%ROWTYPE;
    L_STTB_CORAL_WS_LOG STTB_CORAL_WS_LOG%ROWTYPE;
    --Auto CIF Account Changes for Mobile Banking Ends

  --Flexi Starts
    L_SCAN_ID STTB_CORAL_WS_LOG.SCAN_ID%TYPE;
    --Flexi Ends

  BEGIN

    Dbg('In Fn_Post_Upload_Db..');
    dbg('P_ACTION_CODE' || P_ACTION_CODE);

    --Coral Integration with Flexcube Changes Commented Starts
    /* --AML Dup Changes
    SELECT COUNT(*)
      INTO L_COUNT
      FROM STTB_RECORD_MASTER
     WHERE KEY_ID =
           '~STTM_CUSTOMER~' || P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO || '~'
       AND AUTH_STAT = 'U'
       AND LATEST_AUTH_MOD_NO < 1;
    dbg(';L_COUNT=' || L_COUNT);

    SELECT COUNT(*)
      INTO L_COUNT2
      FROM CSTB_AML_MSG_LOG_CUSTOM
     WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;

    --AML Dup Changes

    --AML Integrations Changes Starts
    --      IF P_ACTION_CODE IN ('NEW') THEN
    IF P_ACTION_CODE IN ('NEW') AND p_Source_Operation = 'STDCIF_NEW' AND
       (L_COUNT = 1 OR GLOBAL.USER_ID = 'BANKON') AND L_COUNT2 = 0 THEN

      BEGIN

        L_FIELD_VAL_3 := CSPKS_AML_INTEGRATION_CUSTOM.FN_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                                 'SECURITY_NO_1');
        L_FIELD_VAL_4 := CSPKS_AML_INTEGRATION_CUSTOM.FN_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                                 'SECURITY_NO_2');
        L_FIELD_VAL_6 := CSPKS_AML_INTEGRATION_CUSTOM.FN_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                                 'RISK_LEVEL');
        L_FIELD_VAL_7 := CSPKS_AML_INTEGRATION_CUSTOM.FN_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                                 'CHANNEL_ID');
        L_FIELD_VAL_8 := CSPKS_AML_INTEGRATION_CUSTOM.FN_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                                 'SCAN_ID');

        \*  IF L_FIELD_VAL_8 IS NOT NULL THEN
           DBG('UDF Scan ID should not be input by user');
           PR_LOG_ERROR('STDCIF','FLEXCUBE','ST-AML-004', '');
           RETURN FALSE;
        END IF;*\

        IF L_FIELD_VAL_7 IS NOT NULL THEN
          DBG('Interface ID should not be input by user');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-005', '');
          RETURN FALSE;
        END IF;

        IF L_FIELD_VAL_6 IS NOT NULL THEN
          DBG('Risk Level should not be input by user');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-006', '');
          RETURN FALSE;
        END IF;

        IF P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME = 'PASSPORT' THEN
          IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C', 'B') THEN
            DBG('Passport details should not be input for Corporate/Bank Customer');
            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-007', '');
            RETURN FALSE;
          END IF;

          IF P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('I') THEN
            IF L_FIELD_VAL_4 IS NULL OR L_FIELD_VAL_3 IS NULL THEN
              DBG('Passport Security Number should be input by user');
              PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-008', '');
              RETURN FALSE;
            END IF;

            IF P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.PPT_EXP_DATE IS NULL THEN
              DBG('Passport Expiry Date should be input by user');
              PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-009', '');
              RETURN FALSE;
            END IF;
          END IF;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to SELECT UDF Value');
          DBG(SQLERRM);
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-003', '');
          RETURN FALSE;
      END;

      DBG('Calling CSPKS_AML_INTEGRATION_CUSTOM.FN_INVOKE_AMLWS');

      IF NOT CSPKS_AML_INTEGRATION_CUSTOM.FN_INVOKE_AMLWS(REC_DATA_TABLE,
                                                          P_WRK_STDCIF) THEN

        DBG('Failed in CSPKS_AML_INTEGRATION_CUSTOM.FN_INVOKE_AMLWS - ST-AML-001');
        DBG(SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-AML-001', '');
        RETURN FALSE;

      END IF;

      BEGIN
        \*            UPDATE CSTM_FUNCTION_USERDEF_FIELDS
        SET FIELD_VAL_2 = DECODE(REC_DATA_TABLE.RETURN_HIT,'N','Yes','Y','No','F','No'),
        FIELD_VAL_7 = GLOBAL_ADDON.INTERFACE_ID,
        FIELD_VAL_8 = REC_DATA_TABLE.RETURN_SCAN_ID
        WHERE FUNCTION_ID = 'STDCIF'
        AND REC_KEY = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO || '~';*\

        SELECT DECODE(REC_DATA_TABLE.RETURN_HIT,
                      'N',
                      'Yes',
                      'Y',
                      'No',
                      'F',
                      'No')
          INTO L_HIT_VAL
          FROM DUAL;

        IF NOT
            CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                           'SCAN_ID',
                                                           REC_DATA_TABLE.RETURN_SCAN_ID) THEN
          RETURN FALSE;
        END IF;
        IF NOT CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                              'AML_VALIDATED',
                                                              L_HIT_VAL) THEN
          RETURN FALSE;
        END IF;
        IF NOT
            CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                           'CHANNEL_ID',
                                                           GLOBAL_ADDON.INTERFACE_ID) THEN
          RETURN FALSE;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to update UDF Value');
          DBG(SQLERRM);
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-002', '');
          RETURN FALSE;
      END;
      --AML Dup Changes
    ELSIF L_COUNT2 = 1 THEN

      SELECT RETURN_SCAN_ID,
             DECODE(RETURN_HIT, 'N', 'Yes', 'Y', 'No', 'F', 'No')
        INTO L_RETURN_SCAN_ID, L_HIT_VAL
        FROM CSTB_AML_MSG_LOG_CUSTOM
       WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO;

      IF NOT
          CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                         'SCAN_ID',
                                                         L_RETURN_SCAN_ID) THEN
        RETURN FALSE;
      END IF;
      IF NOT CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                            'AML_VALIDATED',
                                                            L_HIT_VAL) THEN
        RETURN FALSE;
      END IF;
      IF NOT
          CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                         'CHANNEL_ID',
                                                         GLOBAL_ADDON.INTERFACE_ID) THEN
        RETURN FALSE;
      END IF;
      --AML Dup Changes

    END IF;
    --AML Integrations Changes Ends*/

    --Coral Integration with Flexcube Changes Commented Ends

    --Coral Integration with Flexcube Changes Commented Starts
    IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE NOT IN ('B') THEN
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY)  AND
         CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') <> 'FLEXIPRINCE' THEN --Flexi changes

        DBG('I AM IN MODIFY');

        IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

          L_FULL_NAME_CHK      := TRIM(P_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);
          L_PREV_FULL_NAME_CHK := TRIM(P_PREV_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);

          L_DATE_CHK := TO_DATE(P_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                'DD/MM/RRRR');

          --Auto CIF Account Changes for Mobile Banking starts
          L_DATE_CHK1 := SUBSTR(TO_CHAR(p_stdcif.v_sttms_cust_personal.date_of_birth,
                                        Cspks_Req_Global.g_Ws_Date_Format),
                                1,
                                4);
          --Auto CIF Account Changes for Mobile Banking ends

          L_PREV_DATE_CHK := TO_DATE(P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.DATE_OF_BIRTH,
                                     'DD/MM/RRRR');

          L_COUNTRY_CHK      := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;
          L_PREV_COUNTRY_CHK := P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;

          L_BIRTH_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);
          L_PREV_BIRTH_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);

          L_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          L_PREV_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUSTOMER.COUNTRY);

          L_NATIONALITY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
          L_PREV_NATIONALITY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);

          L_P_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);
          L_PREV_P_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);

          L_ECO_SECTOR      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR');
          L_PREV_ECO_SECTOR := FN_GET_LMTM_TYPE_CODE(P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR');

          L_OCCUPATION      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');
          L_PREV_OCCUPATION := FN_GET_LMTM_TYPE_CODE(P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');

          --Risk Factors
          L_PEP_FLAG := '0|';

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY));

          L_MAX_INDEX := 1;
          L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

          FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

            IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
              L_MAX_VALUE := L_RISK_SCORE(G);
              L_MAX_INDEX := G;
            END IF;
          END LOOP;

          IF L_MAX_INDEX = 1 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY;
          ELSIF L_MAX_INDEX = 2 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.COUNTRY;
          ELSIF L_MAX_INDEX = 3 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY;
          ELSE
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY;
          END IF;

          DBG('P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY=' ||

              P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);

          --L_ADVERSE_MEDIA_FLAG := '0';
          L_REL_HIGH_RISK_FLAG := '2|';
          L_CHANNEL            := 'BFTF|';

          --Auto CIF Account Changes for Mobile Banking starts
          IF P_SOURCE <> 'FLEXCUBE' THEN

            L_PROD_RISK := '4|';

          ELSE

            L_PROD_RISK := '0|';

          END IF;
          --Auto CIF Account Changes for Mobile Banking ends

          L_ASSET_VALUE     := '0|';
          L_STR             := '0|';
          L_BEHAVIOUR_TREND := '1|';
          L_OCCUPATION      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR') ||
                               FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');

          L_RISK_FACTORS := L_PEP_FLAG || L_NATIONALITY || '|' ||
                            L_REL_HIGH_RISK_FLAG || L_CHANNEL ||
                            L_PROD_RISK || L_ASSET_VALUE || L_STR ||
                            L_BEHAVIOUR_TREND || L_OCCUPATION;

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_1',
                                       L_FIELD_NUM,
                                       L_SECURITY_NO_1,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_1 L_SECURITY_NO_1=' ||
              L_SECURITY_NO_1);

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_2',
                                       L_FIELD_NUM,
                                       L_SECURITY_NO_2,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_2 L_SECURITY_NO_2=' ||
              L_SECURITY_NO_2);

          DBG('L_SECURITY_NO_1=' || L_SECURITY_NO_1);
          DBG('L_SECURITY_NO_2=' || L_SECURITY_NO_2);

          IF P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME IN ('PASSPORT') AND
             (L_SECURITY_NO_1 IS NULL OR L_SECURITY_NO_2 IS NULL) THEN
            DBG('Passport Security Numbers should be input by user');
            PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-AML-008', '');
            RETURN FALSE;
          END IF;

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_PREV_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_1',
                                       L_FIELD_NUM,
                                       L_PREV_SECURITY_NO_1,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_1 L_PREV_SECURITY_NO_1=' ||
              L_PREV_SECURITY_NO_1);

          --Get SECURITY_NO_1 UDF Field Value
          IF NOT FN_GET_FUNC_FIELD_VAL(P_PREV_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SECURITY_NO_2',
                                       L_FIELD_NUM,
                                       L_PREV_SECURITY_NO_2,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
            --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            --RETURN FALSE;
          END IF;

          DBG('UDF Field - SECURITY_NO_2 L_PREV_SECURITY_NO_1=' ||
              L_PREV_SECURITY_NO_1);

          DBG('L_PREV_SECURITY_NO_1=' || L_PREV_SECURITY_NO_1);
          DBG('L_PREV_SECURITY_NO_2=' || L_PREV_SECURITY_NO_2);

        --ELSIF P_PREV_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN --loan sector sampath commented
		ELSIF P_PREV_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C','U','R','S','N') THEN --loan sector sampath changes

          DBG(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.CORPORATE_NAME);
          DBG(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE);
          DBG(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);

          L_FULL_NAME_CHK      := TRIM(P_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);
          L_PREV_FULL_NAME_CHK := TRIM(P_PREV_STDCIF.V_STTMS_CUSTOMER.FULL_NAME);

          L_DATE_CHK := TO_DATE(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                'DD/MM/RRRR');

          --Auto CIF Account Changes for Mobile Banking starts
          L_DATE_CHK1 := SUBSTR(TO_CHAR(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                        Cspks_Req_Global.g_Ws_Date_Format),
                                1,
                                4);
          --Auto CIF Account Changes for Mobile Banking ends

          L_PREV_DATE_CHK := TO_DATE(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_DATE,
                                     'DD/MM/RRRR');

          L_COUNTRY_CHK      := P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY;
          L_PREV_COUNTRY_CHK := P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY;

          L_COMPLEX_STRUCTURE := CASE
                                  P_STDCIF.V_CUST_CORPORATE_CUSTOM.COMPLEX_STRUCTURE
                                   WHEN 'LESS THAN 3 LAYERS' THEN
                                    '2|'
                                   WHEN 'MORE THAN OR EQUAL TO 3 LAYERS' THEN
                                    '1|'
                                 END;

          L_PREV_COMPLEX_STRUCTURE := CASE
                                       P_PREV_STDCIF.V_CUST_CORPORATE_CUSTOM.COMPLEX_STRUCTURE
                                        WHEN 'LESS THAN 3 LAYERS' THEN
                                         '2|'
                                        WHEN 'MORE THAN OR EQUAL TO 3 LAYERS' THEN
                                         '1|'
                                      END;

          L_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);
          L_PREV_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);

          L_R_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);
          L_PREV_R_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);

          L_INCORP_COUNTRY      := FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);
          L_PREV_INCORP_COUNTRY := FN_GET_RISK_LEVEL_CNT(P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);

          L_ECO_SECTOR      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR');
          L_PREV_ECO_SECTOR := FN_GET_LMTM_TYPE_CODE(P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR');

          L_OCCUPATION      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');
          L_PREV_OCCUPATION := FN_GET_LMTM_TYPE_CODE(P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');

          --Risk Factors
          L_PEP_FLAG := '0|';

          L_COMPLEX_STRUCTURE := CASE
                                  P_STDCIF.V_CUST_CORPORATE_CUSTOM.COMPLEX_STRUCTURE
                                   WHEN 'LESS THAN 3 LAYERS' THEN
                                    '2|'
                                   WHEN 'MORE THAN OR EQUAL TO 3 LAYERS' THEN
                                    '1|'
                                 END;

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY),
                                          FN_GET_RISK_LEVEL_CNT(P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY));

          L_MAX_INDEX := 1;
          L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

          FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

            IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
              L_MAX_VALUE := L_RISK_SCORE(G);
              L_MAX_INDEX := G;
            END IF;
          END LOOP;

          IF L_MAX_INDEX = 1 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY;
          ELSIF L_MAX_INDEX = 2 THEN
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY;
          ELSE
            L_NATIONALITY := P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY;
          END IF;

          --L_ADVERSE_MEDIA_FLAG := '0';
          L_REL_HIGH_RISK_FLAG := '2|';
          L_CHANNEL            := 'BFTF|';

          --Auto CIF Account Changes for Mobile Banking starts
          IF P_SOURCE <> 'FLEXCUBE' THEN

            L_PROD_RISK := '4|';

          ELSE

            L_PROD_RISK := '0|';

          END IF;
          --Auto CIF Account Changes for Mobile Banking ends

          L_ASSET_VALUE     := '0|';
          L_STR             := '0|';
          L_BEHAVIOUR_TREND := '1|';
          L_OCCUPATION      := FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                     'ECO_SECTOR') ||
                               FN_GET_LMTM_TYPE_CODE(P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                     'OCCUPATION');

          L_RISK_FACTORS := L_PEP_FLAG || L_COMPLEX_STRUCTURE ||
                            L_NATIONALITY || '|' || L_REL_HIGH_RISK_FLAG ||
                            L_CHANNEL || L_PROD_RISK || L_ASSET_VALUE ||
                            L_STR || L_BEHAVIOUR_TREND || L_OCCUPATION;

        END IF;
        -- END IF;

        IF L_FULL_NAME_CHK IS NULL THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Full Name';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --OVPKS.PR_APPENDTBL('ST-MAN01', 'Full Name');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-MAN01', 'Full Name');
          RETURN FALSE;
        END IF;

        IF L_DATE_CHK IS NULL THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Date of Birth';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --OVPKS.PR_APPENDTBL('ST-MAN01', 'Date of Birth');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-MAN01', 'Date of Birth');
          RETURN FALSE;
        END IF;

        IF (L_FULL_NAME_CHK IS NULL OR L_DATE_CHK IS NULL OR
           L_COUNTRY_CHK IS NULL) THEN

          P_ERR_CODE   := 'ST-MAN01';
          P_ERR_PARAMS := 'Country';
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --OVPKS.PR_APPENDTBL('ST-MAN01', 'Country');
          PR_LOG_ERROR('STDCIF', 'FLEXCUBE', 'ST-MAN01', 'Country');
          RETURN FALSE;
        END IF;

        DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT=' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT);
        DBG('P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT=' ||
            P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_EXP_DT);
        DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME=' ||
            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME);

        L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
         <soapenv:Header/>
         <soapenv:Body>
            <tem:OnlineScan>

               <tem:AuthUser>AMLSVC</tem:AuthUser>

               <tem:AuthPswd>AMLSVC</tem:AuthPswd>

               <tem:Username>' || GLOBAL.USER_ID ||
                     '</tem:Username>

               <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                     '</tem:BrCode>

               <tem:SysName>FCUBS</tem:SysName>

               <tem:ScanOption>3|3</tem:ScanOption>

               <tem:UniqueNo>' ||
                     P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO ||
                     '</tem:UniqueNo>

               <tem:SearchName>' || L_FULL_NAME_CHK ||
                     '</tem:SearchName>

               <tem:SearchCountry>' || L_COUNTRY_CHK ||
                     '</tem:SearchCountry>

               <tem:SearchDOB>' || L_DATE_CHK1 ||
                     '</tem:SearchDOB>

               <tem:SearchID>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME = 'PASSPORT' THEN
                        P_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_VALUE
                       ELSE
                        NULL
                     END || '</tem:SearchID>

               <tem:PassportVerify>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        1
                       ELSE
                        NULL
                     END || '</tem:PassportVerify>

               <tem:SecurityNo1>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        L_SECURITY_NO_1
                       ELSE
                        NULL
                     END || '</tem:SecurityNo1>

               <tem:PassExpiryDtVerify>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        1
                       ELSE
                        NULL
                     END || '</tem:PassExpiryDtVerify>

               <tem:PassExpiryDate>' || CASE
                       WHEN P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
                            P_WRK_STDCIF.V_STTMS_CUSTOMER.UNIQUE_ID_NAME =
                            'PASSPORT' THEN
                        TO_CHAR(P_WRK_STDCIF.V_STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT,
                                'YYMMDD')
                       ELSE
                        NULL
                     END || '</tem:PassExpiryDate>

               <tem:SecurityNo2>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        L_SECURITY_NO_2
                       ELSE
                        NULL
                     END || '</tem:SecurityNo2>

               <tem:RiskFactors>' ||
                     CASE P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE
                       WHEN 'I' THEN
                        '1#' || L_RISK_FACTORS
                       WHEN 'C' THEN
                        '2#' || L_RISK_FACTORS
						--loan sector sampath changes starts
                       WHEN 'U' THEN
                        '2#' || L_RISK_FACTORS
                       WHEN 'R' THEN
                        '2#' || L_RISK_FACTORS
                       WHEN 'S' THEN
                        '2#' || L_RISK_FACTORS
                       WHEN 'N' THEN
                        '2#' || L_RISK_FACTORS
                       --loan sector sampath changes ends
                     END || '</tem:RiskFactors>

               <tem:Content></tem:Content>

               <tem:RtnHit>1</tem:RtnHit>

               <tem:RtnScanID>0</tem:RtnScanID>

               <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
            </tem:OnlineScan>
         </soapenv:Body>
      </soapenv:Envelope>';

        --Log ONLINE_SCAN request xml
        SELECT FC_CORAL_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

        L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

        DBG('L_REF=' || L_REF);

        --Condition not to log second time
        IF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' THEN

          DBG('L_FULL_NAME_CHK=' || L_FULL_NAME_CHK);
          DBG('L_PREV_FULL_NAME_CHK=' || L_PREV_FULL_NAME_CHK);
          DBG('L_DATE_CHK=' || L_DATE_CHK);
          DBG('L_PREV_DATE_CHK=' || L_PREV_DATE_CHK);
          DBG('L_COUNTRY_CHK=' || L_COUNTRY_CHK);
          DBG('L_PREV_COUNTRY_CHK=' || L_PREV_COUNTRY_CHK);
          DBG('L_BIRTH_COUNTRY=' ||
              P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);
          DBG('L_PREV_BIRTH_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);
          DBG('L_COUNTRY=' || P_WRK_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          DBG('L_PREV_COUNTRY=' || P_PREV_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.NATIONALITY=' ||
              P_WRK_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
          DBG('P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY=' ||
              P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
          DBG('L_P_COUNTRY=' ||
              P_WRK_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);
          DBG('L_PREV_P_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);
          DBG('L_ECO_SECTOR=' ||
              P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_ECO_SECTOR=' ||
              P_WRK_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_PREV_ECO_SECTOR=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_OCCUPATION=' ||
              P_WRK_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);
          DBG('L_PREV_OCCUPATION=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);
          DBG('L_SECURITY_NO_1=' || L_SECURITY_NO_1);
          DBG('L_PREV_SECURITY_NO_1=' || L_PREV_SECURITY_NO_1);
          DBG('L_SECURITY_NO_2=' || L_SECURITY_NO_2);
          DBG('L_PREV_SECURITY_NO_2=' || L_PREV_SECURITY_NO_2);

          L_INSERT_FLAG := FALSE;
          BEGIN
            SELECT *
              INTO L_STTB_MODIFY_IND_CUST
              FROM STTB_MODIFY_IND_CUST
             WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
               AND MOD_NO = P_STDCIF.V_STTMS_CUSTOMER.MOD_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_INSERT_FLAG := TRUE;
          END;

          IF L_INSERT_FLAG THEN
            STPKS_CORAL_WS_LOG.PR_INSERT_MODIFY_IND_CUST(L_REF,
                                                         P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                         P_ACTION_CODE,
                                                         'I',
                                                         L_FULL_NAME_CHK,
                                                         L_DATE_CHK,
                                                         L_COUNTRY_CHK,
                                                         P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY,
                                                         P_STDCIF.V_STTMS_CUSTOMER.COUNTRY,
                                                         P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY,
                                                         P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY,
                                                         P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                         P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                         L_SECURITY_NO_1,
                                                         L_SECURITY_NO_2,
                                                         SYSDATE,
                                                         P_STDCIF.V_STTMS_CUSTOMER.MOD_NO);
          END IF;

          DBG('L_FULL_NAME_CHK=' || L_FULL_NAME_CHK);
          DBG('L_PREV_FULL_NAME_CHK=' || L_PREV_FULL_NAME_CHK);
          DBG('L_DATE_CHK=' || L_DATE_CHK);
          DBG('L_PREV_DATE_CHK=' || L_PREV_DATE_CHK);
          DBG('L_COUNTRY_CHK=' || L_COUNTRY_CHK);
          DBG('L_PREV_COUNTRY_CHK=' || L_PREV_COUNTRY_CHK);
          DBG('L_BIRTH_COUNTRY=' ||
              P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);
          DBG('L_PREV_BIRTH_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY);
          DBG('L_COUNTRY=' || P_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          DBG('L_PREV_COUNTRY=' || P_PREV_STDCIF.V_STTMS_CUSTOMER.COUNTRY);
          DBG('P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY=' ||
              P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
          DBG('P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY=' ||
              P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY);
          DBG('L_P_COUNTRY=' || P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);
          DBG('L_PREV_P_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY);
          DBG('L_ECO_SECTOR=' ||
              P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_PREV_ECO_SECTOR=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_OCCUPATION=' ||
              P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);
          DBG('L_PREV_OCCUPATION=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);
          DBG('L_SECURITY_NO_1=' || L_SECURITY_NO_1);
          DBG('L_PREV_SECURITY_NO_1=' || L_PREV_SECURITY_NO_1);
          DBG('L_SECURITY_NO_2=' || L_SECURITY_NO_2);
          DBG('L_PREV_SECURITY_NO_2=' || L_PREV_SECURITY_NO_2);

        --ELSIF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' THEN --loan sector sampath commented
		ELSIF P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C','U','R','S','N') THEN --loan sector sampath changes

          L_INSERT_FLAG := FALSE;
          BEGIN
            SELECT *
              INTO L_STTB_MODIFY_CORP_CUST
              FROM STTB_MODIFY_CORP_CUST
             WHERE CUSTOMER_NO = P_WRK_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
               AND MOD_NO = P_STDCIF.V_STTMS_CUSTOMER.MOD_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_INSERT_FLAG := TRUE;
          END;

          IF L_INSERT_FLAG THEN
            STPKS_CORAL_WS_LOG.PR_INSERT_MODIFY_CORP_CUST(L_REF,
                                                          P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                          P_ACTION_CODE,
                                                          'C',
                                                          L_FULL_NAME_CHK,
                                                          L_DATE_CHK,
                                                          L_COUNTRY_CHK,
                                                          L_COMPLEX_STRUCTURE,
                                                          P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY,
                                                          P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY,
                                                          P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY,

                                                          P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC,
                                                          P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION,
                                                          SYSDATE,
                                                          P_STDCIF.V_STTMS_CUSTOMER.MOD_NO);
          END IF;

          DBG('L_FULL_NAME_CHK=' || L_FULL_NAME_CHK);
          DBG('L_PREV_FULL_NAME_CHK=' || L_PREV_FULL_NAME_CHK);
          DBG('L_DATE_CHK=' || L_DATE_CHK);
          DBG('L_PREV_DATE_CHK=' || L_PREV_DATE_CHK);
          DBG('L_COUNTRY_CHK=' || L_COUNTRY_CHK);
          DBG('L_PREV_COUNTRY_CHK=' || L_PREV_COUNTRY_CHK);
          DBG('L_COUNTRY=' || P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);
          DBG('L_PREV_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY);
          DBG('L_COMPLEX_STRUCTURE=' || L_COMPLEX_STRUCTURE);
          DBG('L_PREV_COMPLEX_STRUCTURE=' || L_PREV_COMPLEX_STRUCTURE);
          DBG('L_R_COUNTRY=' || P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);
          DBG('L_PREV_R_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY);
          DBG('L_INCORP_COUNTRY=' ||
              P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);
          DBG('L_PREV_INCORP_COUNTRY=' ||
              P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY);
          DBG('L_ECO_SECTOR=' ||
              P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_PREV_ECO_SECTOR=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC);
          DBG('L_INCORP_COUNTRY=' ||
              P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);
          DBG('L_PREV_INCORP_COUNTRY=' ||
              P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION);

          --END IF;
        END IF;

        IF L_INSERT_FLAG AND
           ((P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'I' AND
           (L_FULL_NAME_CHK <> L_PREV_FULL_NAME_CHK OR
           L_DATE_CHK <> L_PREV_DATE_CHK OR
           L_COUNTRY_CHK <> L_PREV_COUNTRY_CHK OR
           P_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.BIRTH_COUNTRY OR
           P_STDCIF.V_STTMS_CUSTOMER.COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUSTOMER.COUNTRY OR
           -- L_NATIONALITY <> L_PREV_NATIONALITY OR --it covers countries
           P_STDCIF.V_STTMS_CUSTOMER.NATIONALITY <>
           P_PREV_STDCIF.V_STTMS_CUSTOMER.NATIONALITY OR
           P_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUST_PERSONAL.P_COUNTRY OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC <>
           P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION <>
           P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION OR
           L_SECURITY_NO_1 <> L_PREV_SECURITY_NO_1 OR
           L_SECURITY_NO_2 <> L_PREV_SECURITY_NO_2))

           --OR (P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE = 'C' AND --loan sector sampath commented
		   OR (P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE IN ('C','U','R','S','N') AND --loan sector sampath changes
           (L_FULL_NAME_CHK <> L_PREV_FULL_NAME_CHK OR
           L_DATE_CHK <> L_PREV_DATE_CHK OR
           L_COUNTRY_CHK <> L_PREV_COUNTRY_CHK OR
           L_COMPLEX_STRUCTURE <> L_PREV_COMPLEX_STRUCTURE OR
           P_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUSTOMER__A.COUNTRY OR
           P_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.R_COUNTRY OR
           P_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY <>
           P_PREV_STDCIF.V_STTMS_CUST_CORPORATE.INCORP_COUNTRY OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC <>
           P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.ECONOMIC_SEC OR
           P_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION <>
           P_PREV_STDCIF.V_STTM_CUSTOMER_CUSTOM.OCCUPATION))) THEN

          DBG('Calling Webservice as changes include one of above parameter');
          STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_WS_LOG(L_REF,
                                                    P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                    SYSDATE,
                                                    'ONLINE_SCAN',
                                                    P_ACTION_CODE,
                                                    L_OUT_MSG);

          /* INSERT
            INTO STTB_CORAL_WS_LOG(UNIQUE_REFERENCE_NO,
                                   CUSTOMER_NO,
                                   INVOKE_DATE,
                                   REQ_TYPE,
                                   REQ_MSG) VALUES(L_REF,
                                                   P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                   SYSDATE,
                                                   'ONLINE_SCAN',
                                                   L_OUT_MSG);
          */

          IF NOT FN_HTTP_CALL_PRINCE(L_OUT_MSG,
                                     L_IN_RESP,
                                     'CORAL_VALIDATION_WS_URL',
                                     'CORAL_SOAPACTION_WS_URL',
                                     P_ERR_CODE,
                                     P_ERR_PARAMS)

           THEN

            DBG('FAILED DURING INVOCATION OF CORAL WEBSERVICES');
            DBG('P_ERR_CODE=' || P_ERR_CODE);
            DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);

            P_ERR_CODE := 'ST-CRL-003';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          END IF;

          DBG('L_IN_RESP=' || L_IN_RESP);

          P := DBMS_XMLPARSER.NEWPARSER;
          DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
          DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
          L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
          L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
          L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                             'Fault');
          --Parsing failure response from coral
          IF (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) THEN

            FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
              L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
              L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
              L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
              --
              FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
                L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
                L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
                L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
                L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
                IF L_NODE_NAME = 'faultcode' THEN
                  P_ERR_CODE := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'faultstring' THEN
                  P_ERR_PARAMS := L_NODE_VALUE;
                END IF;

                P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                                '-- The Webservices returned a fail XML';
              END LOOP;
            END LOOP;

            OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);

          ELSE

            --Parsing Success Response from coral
            L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                             'OnlineScanResponse');

            FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) - 1 LOOP
              L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
              L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
              L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
              --
              FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
                L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
                L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
                L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
                L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
                --
                IF L_NODE_NAME = 'RtnHit' THEN
                  L_HIT_VALUE := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'RtnScanID' THEN
                  L_RTN_SCAN_ID := L_NODE_VALUE;
                ELSIF L_NODE_NAME = 'RtnEnCryptScanID' THEN
                  L_RTN_ENCRYPT_SCAN_ID := L_NODE_VALUE;
                END IF;

              END LOOP;
            END LOOP;

            DBG('L_HIT_VALUE=' || L_HIT_VALUE);
            DBG('L_RTN_SCAN_ID=' || L_RTN_SCAN_ID);
            DBG('L_RTN_ENCRYPT_SCAN_ID=' || L_RTN_ENCRYPT_SCAN_ID);

            IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 OR
               INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'F') > 0 THEN
              L_RETURN_STATUS := 'HIT';
            ELSE
              L_RETURN_STATUS := 'NO HIT';
            END IF;

            SELECT SUBSTR(L_HIT_VALUE, INSTR(L_HIT_VALUE, '|') + 1, 1)
              INTO L_RISK_LEVEL
              FROM DUAL;

            DBG('BEFORE UPDATING RESPONSE IN THE LOG TABLE=' || L_REF);
            --Update ONLINE_SCAN xml ws response
            STPKS_CORAL_WS_LOG.PR_UPDATE_CORAL_WS_LOG(L_REF,
                                                      L_RTN_SCAN_ID,
                                                      L_RETURN_STATUS,
                                                      L_RISK_LEVEL,
                                                      L_HIT_VALUE, --added for temp fix
                                                      L_IN_RESP);

            STPKS_CORAL_WS_LOG.PR_INSERT_CORAL_DATA(L_RTN_SCAN_ID,
                                                    L_RETURN_STATUS,
                                                    L_FULL_NAME_CHK,
                                                    L_DATE_CHK,
                                                    L_COUNTRY_CHK,
                                                    GLOBAL.APPLICATION_DATE,
                                                    'open',
                                                    GLOBAL.CURRENT_BRANCH);

            DBG('L_RETURN_STATUS=' || L_RETURN_STATUS);

            IF L_RETURN_STATUS = 'HIT' OR L_RISK_LEVEL = 'H' THEN

              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'ST-PRIN-023',
                           L_RTN_SCAN_ID);

            END IF;

          END IF;
        END IF;
      END IF;

      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_DELETE, 'VERSIONDELETE') THEN
        DBG('INSIDE DELETE ACTION');

        FOR G IN (SELECT *
                    FROM STTB_RECORD_LOG
                   WHERE KEY_ID =
                         '~STTM_CUSTOMER~' ||
                         P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO || '~'
                     AND RECORD_STAT = 'M'
                     AND AUTH_STAT = 'U'
                     AND MAKER_ID = GLOBAL.USER_ID) LOOP

          STPKS_CORAL_WS_LOG.PR_DELETE_MODIFY_IND_CUST(P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                       G.MOD_NO);
        END LOOP;
      END IF;
    END IF; --Fix for Bank Type Customer
    --Coral Integration with Flexcube Changes Commented Ends

    --Auto CIF Account Changes for Mobile Banking Starts
    IF P_ACTION_CODE = 'NEW' AND P_SOURCE <> 'FLEXCUBE' THEN

      BEGIN
        SELECT *
          INTO L_STTB_CORAL_WS_LOG
          FROM STTB_CORAL_WS_LOG
         WHERE CUSTOMER_NO = p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO
           AND UNIQUE_REFERENCE_NO =
               (SELECT MAX(UNIQUE_REFERENCE_NO)
                  FROM STTB_CORAL_WS_LOG
                 WHERE CUSTOMER_NO = P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_NO
                   AND ACTION <> 'AUTH');
      EXCEPTION
        WHEN OTHERS THEN
          L_STTB_CORAL_WS_LOG := NULL;
      END;

      IF INSTR(SUBSTR(L_STTB_CORAL_WS_LOG.HIT_VALUE, 1, 3), 'Y') > 0 OR
         INSTR(SUBSTR(L_STTB_CORAL_WS_LOG.HIT_VALUE, 1, 3), 'F') > 0 THEN
        L_RETURN_STATUS := 'HIT';
      ELSE
        L_RETURN_STATUS := 'NO HIT';
      END IF;

      --Update UDF value
      IF NOT
          CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                         'RISK_LEVEL',
                                                         L_RETURN_STATUS || ',' ||
                                                         L_STTB_CORAL_WS_LOG.RISK_LEVEL) THEN
        RETURN FALSE;
      END IF;

      IF NOT
          CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                         'SCAN_ID',
                                                         L_STTB_CORAL_WS_LOG.SCAN_ID) THEN
        RETURN FALSE;
      END IF;


    --flexi starts
        IF P_SOURCE = 'FLEXIPRINCE' OR CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('FLEXIPRINCE')  THEN

          IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'RISK_LEVEL',
                                       L_FIELD_NUM,
                                       L_RISK_LEVEL,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
          END IF;

          DBG('UDF Field - L_RISK_LEVEL=' || L_RISK_LEVEL);

          IF NOT
              CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                             'RISK_LEVEL',
                                                             L_RISK_LEVEL) THEN
            RETURN FALSE;
          END IF;

          IF NOT FN_GET_FUNC_FIELD_VAL(P_STDCIF.UDF_DETAILS,
                                       P_FUNCTION_ID,
                                       'SCAN_ID',
                                       L_FIELD_NUM,
                                       L_SCAN_ID,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fetching the Field Value..');
          END IF;

          DBG('UDF Field - L_SCAN_ID=' || L_SCAN_ID);

          IF NOT
              CSPKS_AML_INTEGRATION_CUSTOM.FN_UPDATE_UDF_VAL(p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO,
                                                             'SCAN_ID',
                                                             L_SCAN_ID) THEN
            RETURN FALSE;
          END IF;

        END IF;
        --flexi ends

      BEGIN
        SELECT *
          INTO L_UDF_RECORD
          FROM CSTMS_FUNCTION_USERDEF_FIELDS
         WHERE FUNCTION_ID = 'STDCIF'
           AND REC_KEY = p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO || '~';
      END;

      DBG('BEFORE UPDATING RESPONSE IN THE LOG TABLE=' ||
          L_UDF_RECORD.FIELD_VAL_3);
      DBG('BEFORE UPDATING RESPONSE IN THE LOG TABLE=' ||
          L_UDF_RECORD.FIELD_VAL_6);
      DBG('BEFORE UPDATING RESPONSE IN THE LOG TABLE=' ||
          L_UDF_RECORD.FIELD_VAL_7);
    END IF;

    --Auto CIF Account Changes for Mobile Banking ends

    --Delete CIF from coral table to avoid passing old scan id to AML Starts
    IF (P_STDCIF.V_STTMS_CUSTOMER.CUSTOMER_TYPE NOT IN ('B') OR
       P_SOURCE <> 'FLEXCUBE') AND --added DAP Issue Condition here
       p_Action_Code IN (CSPKS_REQ_GLOBAL.P_DELETE, 'VERSIONDELETE') THEN

      DBG('ABOUT TO DELETE CUSTOMER FROM CORAL LOG TABLE');

      STPKS_CORAL_WS_LOG.PR_DELETE_CORAL_WS_LOG_OVD(P_STDCIF.v_sttms_customer.CUSTOMER_NO);

    --Delete Issue From DAP For Auto Account Creation With CIF Creation Starts
      DBG('P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT=' ||
          P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT);

      IF NVL(P_WRK_STDCIF.V_STTMS_CUSTOMER.AUTO_CREATE_ACCOUNT, 'N') = 'Y' THEN

        DBG('p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO=' ||
            p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO);
        DBG('NVL(p_stdcif.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                   p_stdcif.V_STTMS_CUSTOMER.LOCAL_BRANCH)=' ||
            NVL(p_stdcif.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                p_stdcif.V_STTMS_CUSTOMER.LOCAL_BRANCH));

        dbg('p_wrk_stdcif.V_STTMS_CUSTOMER.LOCAL_BRANCH=' ||
            p_wrk_stdcif.V_STTMS_CUSTOMER.LOCAL_BRANCH);

        dbg('P_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH=' ||
            P_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH);
        dbg('P_WRK_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH=' ||
            P_WRK_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH);

        BEGIN
          DELETE FROM STVWS_AUTO_ACCOUNT
           WHERE CUST_NO = p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO

             AND BRANCH_CODE =
                 NVL(p_stdcif.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                     p_wrk_stdcif.V_STTMS_CUSTOMER.LOCAL_BRANCH);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('In WOT of acc_no' || SQLERRM);
            RETURN FALSE;
        END;

        BEGIN

          DELETE FROM STTM_AUTO_LIAB_DETAILS
           WHERE CUST_NO = p_stdcif.V_STTMS_CUSTOMER.CUSTOMER_NO
             AND LIAB_BRANCH = P_WRK_STDCIF.V_STVWS_CUST_LIAB.LIAB_BRANCH;
          --NVL(p_stdcif.TY_STCCUACC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
          --  p_stdcif.V_STTMS_CUSTOMER.LOCAL_BRANCH);

        EXCEPTION
          WHEN OTHERS THEN

            DBG('FAILED TO DELETE FROM STTM_AUTO_LIAB_DETAILS TABLE');

            RETURN FALSE;

        END;

      END IF;

    --Delete Issue From DAP For Auto Account Creation With CIF Creation Ends

    END IF;
    --Delete CIF from coral table to avoid passing old scan id to AML Ends

  IF p_Source IN ('FLEXIPRINCE') AND
       P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) THEN

      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_CORAL_WS_LOG
       WHERE CUSTOMER_NO = p_stdcif.v_sttms_customer.CUSTOMER_NO;

      IF L_COUNT = 0 THEN

        --Get Unique Reference No
        SELECT FC_CORAL_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

        L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

        DBG('L_REF=' || L_REF);

        --Get SCAN_ID
        IF NOT FN_GET_FUNC_FIELD_VAL(p_wrk_stdcif.UDF_DETAILS,
                                     P_FUNCTION_ID,
                                     'SCAN_ID',
                                     L_FIELD_NUM,
                                     L_SCAN_ID,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
          DBG('Failed in Fetching the Field Value..');
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --RETURN FALSE;
        END IF;

        DBG('L_SCAN_ID=' || L_SCAN_ID);

        --Get RISK_LEVEL
        IF NOT FN_GET_FUNC_FIELD_VAL(p_wrk_stdcif.UDF_DETAILS,
                                     P_FUNCTION_ID,
                                     'RISK_LEVEL',
                                     L_FIELD_NUM,
                                     L_RISK_LEVEL,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
          DBG('Failed in Fetching the Field Value..');
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --RETURN FALSE;
        END IF;

        DBG('L_RISK_LEVEL=' || L_RISK_LEVEL);

        --Get HIT_VALUE
        IF NOT FN_GET_FUNC_FIELD_VAL(p_wrk_stdcif.UDF_DETAILS,
                                     P_FUNCTION_ID,
                                     'HIT_VALUE',
                                     L_FIELD_NUM,
                                     L_HIT_VALUE,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
          DBG('Failed in Fetching the Field Value..');
          --OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          --RETURN FALSE;
        END IF;

        DBG('L_HIT_VALUE=' || L_HIT_VALUE);

        IF NOT STPKS_CORAL_WS_LOG.FN_INSERT_CORAL_WS_LOG(L_REF,
                                                         p_stdcif.v_sttms_customer.CUSTOMER_NO,
                                                         L_SCAN_ID,
                                                         SYSDATE,
                                                         'ONLINE_SCAN',
                                                         NULL,--STATUS

                                                         P_ACTION_CODE,
                                                         L_RISK_LEVEL,
                                                         L_HIT_VALUE) THEN
          RETURN FALSE;

        ELSE

        DBG('LOGGED IN AML SCAN DETAILS');

        END IF;
      END IF;

    END IF;

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcif_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdcif           IN stpks_stdcif_Main.Ty_stdcif,
                        p_Wrk_stdcif       IN OUT stpks_stdcif_Main.Ty_stdcif,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts flexi
    L_COUNT NUMBER := 0;
    --sampath ends flexi
  BEGIN

    Dbg('In Fn_Pre_Query..=' || CSPKS_REQ_GLOBAL.P_QUERY);
    DBG('P_ACTION_CODE=' || P_ACTION_CODE);

  --sampath starts flexi
    IF (P_SOURCE = 'FLEXIPRINCE' OR CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('FLEXIPRINCE')) AND P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN

      DBG('INSIDE EXECUTE QUERY');

      SELECT *
        BULK COLLECT
        INTO p_Wrk_stdcif.v_sttms_corp_directors
        FROM STTM_CORP_DIRECTORS
       WHERE CUSTOMER_NO = p_stdcif.v_sttms_customer.CUSTOMER_NO;

      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CORP_DIRECTORS
       WHERE CUSTOMER_NO = p_stdcif.v_sttms_customer.CUSTOMER_NO;

      DBG('L_COUNT=' || L_COUNT);

      FOR G IN (SELECT *
                  FROM STTM_CORP_DIRECTORS
                 WHERE CUSTOMER_NO = p_stdcif.v_sttms_customer.CUSTOMER_NO) LOOP

        DBG('G.DIRECTOR_NAME=' || G.DIRECTOR_NAME);

        p_Wrk_stdcif.v_sttms_corp_directors(1).CUSTOMER_NO := p_stdcif.v_sttms_customer.CUSTOMER_NO;
        p_Wrk_stdcif.v_sttms_corp_directors(1).DIRECTOR_NAME := G.DIRECTOR_NAME;
        p_Wrk_stdcif.v_sttms_corp_directors(1).SLNO := G.SLNO;

        DBG('p_Wrk_stdcif.v_sttms_corp_directors(1).DIRECTOR_NAME=' || p_Wrk_stdcif.v_sttms_corp_directors(1)
            .DIRECTOR_NAME);

      END LOOP;

      SELECT ECONOMIC_SEC
        INTO p_Wrk_stdcif.v_sttm_customer_custom.ECONOMIC_SEC
        FROM STTM_CUSTOMER_CUSTOM
       WHERE CUSTOMER_NO = p_stdcif.v_sttms_customer.CUSTOMER_NO;

      DBG('p_Wrk_stdcif.v_sttm_customer_custom.ECONOMIC_SEC=' ||
          p_Wrk_stdcif.v_sttm_customer_custom.ECONOMIC_SEC);

    END IF;

    --sampath ends flexi

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcif_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdcif           IN stpks_stdcif_Main.ty_stdcif,
                         p_wrk_stdcif       IN OUT stpks_stdcif_Main.ty_stdcif,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
    --sampath starts flexi
    L_COUNT NUMBER := 0;
    --sampath ends flexi
  BEGIN

    Dbg('In Fn_Post_Query..');

  --sampath starts flexi
    IF (P_SOURCE = 'FLEXIPRINCE' OR CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('FLEXIPRINCE')) AND P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN

      DBG('INSIDE EXECUTE QUERY');

      SELECT *
        BULK COLLECT
        INTO p_Wrk_stdcif.v_sttms_corp_directors
        FROM STTM_CORP_DIRECTORS
       WHERE CUSTOMER_NO = p_stdcif.v_sttms_customer.CUSTOMER_NO;

      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CORP_DIRECTORS
       WHERE CUSTOMER_NO = p_stdcif.v_sttms_customer.CUSTOMER_NO;

      DBG('L_COUNT=' || L_COUNT);

      FOR G IN (SELECT *
                  FROM STTM_CORP_DIRECTORS
                 WHERE CUSTOMER_NO = p_stdcif.v_sttms_customer.CUSTOMER_NO) LOOP

        DBG('G.DIRECTOR_NAME=' || G.DIRECTOR_NAME);

        p_Wrk_stdcif.v_sttms_corp_directors(1).CUSTOMER_NO := p_stdcif.v_sttms_customer.CUSTOMER_NO;
        p_Wrk_stdcif.v_sttms_corp_directors(G.SLNO).DIRECTOR_NAME := G.DIRECTOR_NAME;
        p_Wrk_stdcif.v_sttms_corp_directors(G.SLNO).SLNO := G.SLNO;

        DBG('p_Wrk_stdcif.v_sttms_corp_directors(1).DIRECTOR_NAME=' || p_Wrk_stdcif.v_sttms_corp_directors(1)
            .DIRECTOR_NAME);

      END LOOP;

    END IF;

    --sampath ends flexi

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdcif_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdcif_custom;
