
CREATE OR REPLACE TYPE FAILED_TXNS_QUEUE_TYPE AS OBJECT(message_content VARCHAR2(4000))
/
--Create a Queue Table
BEGIN
       DBMS_AQADM.CREATE_QUEUE_TABLE(
           queue_table        => 'IFTB_FAILED_ONLINE_TXNS_QUEUE',
           queue_payload_type => 'FAILED_TXNS_QUEUE_TYPE',--'SYS.AQ$_JMS_TEXT_MESSAGE',
           multiple_consumers => FALSE
       );
   END;
/

--Create a Queue   
BEGIN
   
   DBMS_AQADM.CREATE_QUEUE(
       queue_name  => 'FAILED_TXNS_QUEUE',
       queue_table => 'IFTB_FAILED_ONLINE_TXNS_QUEUE'
   );
END;
/

--Start the Queue
BEGIN
   DBMS_AQADM.START_QUEUE(queue_name => 'FAILED_TXNS_QUEUE');
END;
   
  / 
  
  --Check Queue Information
    SELECT * 
   FROM USER_QUEUE_TABLES q;
   
   SELECT q.*
   FROM USER_QUEUES q;
   
   select * from IFTB_FAILED_ONLINE_TXNS_QUEUE;
   SELECT * FROM DBA_QUEUE_SUBSCRIBERS WHERE OWNER = 'P1FCHPRFM';
   
   
   
--We need at least one subscriber before start enqueuing. Note it is not required as queue table is created with as multiple_consumers => FALSE
begin
  DBMS_AQADM.ADD_SUBSCRIBER(queue_name => 'aq_queue',
                            subscriber => sys.aq$_agent('queue_subscriber_test',
                                                        'message_queue',
                                                        null));
end;