CREATE OR REPLACE PACKAGE BODY IFPKS_ZOMBIE_BOT_UTILS AS

  PROCEDURE PR_DEQUEUE_MESSAGE AS
  
    DEQUEUE_OPTIONS    DBMS_AQ.DEQUEUE_OPTIONS_T;
    MESSAGE_PROPERTIES DBMS_AQ.MESSAGE_PROPERTIES_T;
    MESSAGE_HANDLE     RAW(16);
    MSG_CONTENT        FAILED_TXNS_QUEUE_TYPE;
  
    L_MAIL_CONN    UTL_SMTP.CONNECTION;
    L_MAIL_HOST    VARCHAR2(100) := '10.80.81.2';
    L_MAIL_PORT_NO VARCHAR2(100) := 25;
    L_USER_ID      VARCHAR2(100) := 'support.app';
    L_PASSWORD     VARCHAR2(100) := 'PB@123!2020@';
  
    L_FROM_ADDRESS VARCHAR2(100) := 'y.raroth@princebank.com.kh';
  
    L_TO_ADDRESS VARCHAR2(100) := 'y.raroth@princebank.com.kh';
  
    L_MAIL_SUBJECT VARCHAR2(100) := 'Alert: *CBS Automation Jobs are either not Running/Stopped or not Scheduled*';
  
    L_MAIL_TEXT VARCHAR2(32767); --:= 'Job $L_JOB_NAME is down. Please check!!';
  
    L_START_TEXT       VARCHAR2(32767);
    L_TABLEROWCOL_DATA VARCHAR2(32767) := '';
    L_JOB_TEXT         VARCHAR2(32767);
    L_END_TEXT         VARCHAR2(32767);
  
    CURSOR FAILED_ENQUEUED_TXNS IS
      SELECT * FROM IFTB_FAILED_ONLINE_TXNS_QUEUE;
  
  BEGIN
  
    --DEQUEUE_OPTIONS.WAIT := DBMS_AQ.NO_WAIT;
    DEQUEUE_OPTIONS.WAIT := 1;
    --DEQUEUE_OPTIONS.CONSUMER_NAME := 'QUEUE_SUBSCRIBER'; -- SPECIFY THE CONSUMER NAME
  
    --DEQUEUE_OPTIONS.NAVIGATION := DBMS_AQ.FIRST_MESSAGE; --pls check
    DEQUEUE_OPTIONS.VISIBILITY := DBMS_AQ.ON_COMMIT;
  
    -- SET THE WAIT TIME IN SECONDS (E.G., 10 SECONDS)
    --DEQUEUE_OPTIONS.WAIT := 10;
  
    LOOP
      DBMS_AQ.DEQUEUE(QUEUE_NAME         => 'FAILED_TXNS_QUEUE',
                      DEQUEUE_OPTIONS    => DEQUEUE_OPTIONS,
                      MESSAGE_PROPERTIES => MESSAGE_PROPERTIES,
                      PAYLOAD            => MSG_CONTENT,
                      MSGID              => MESSAGE_HANDLE);
    
      -- PROCESS THE DEQUEUED MESSAGE
      DBMS_OUTPUT.PUT_LINE('Dequeued Message: ' ||
                           MSG_CONTENT.MESSAGE_CONTENT);
    
      DEBUG.PR_DEBUG('AC',
                     'Dequeued Message: ' || MSG_CONTENT.MESSAGE_CONTENT);
    
      EXIT WHEN message_handle IS NULL;
    
      L_MAIL_CONN := UTL_smtp.open_connection(L_MAIL_HOST, L_MAIL_PORT_NO);
    
      --utl_smtp.starttls(L_MAIL_CONN);
    
      UTL_SMTP.AUTH(L_MAIL_CONN, L_USER_ID, L_PASSWORD, schemes => 'PLAIN');
    
      utl_smtp.mail(L_MAIL_CONN, L_FROM_ADDRESS);
      utl_smtp.rcpt(L_MAIL_CONN, L_TO_ADDRESS);
    
      UTL_smtp.open_data(L_MAIL_CONN);
    
      UTL_SMTP.write_data(L_MAIL_CONN,
                          'Date: ' ||
                          TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') ||
                          UTL_TCP.crlf);
      UTL_SMTP.write_data(L_MAIL_CONN,
                          'To: ' || L_TO_ADDRESS || UTL_TCP.crlf);
      UTL_SMTP.write_data(L_MAIL_CONN,
                          'From: ' || L_FROM_ADDRESS || UTL_TCP.crlf);
      UTL_SMTP.write_data(L_MAIL_CONN,
                          'Subject: ' || L_MAIL_SUBJECT || UTL_TCP.crlf);
    
      UTL_smtp.write_data(L_MAIL_CONN,
                          'MIME-Version: ' || '1.0' || UTL_tcp.CRLF);
    
      UTL_smtp.write_data(L_MAIL_CONN, 'Content-Type: ' || 'text/html;');
    
      UTL_smtp.write_data(L_MAIL_CONN,
                          'Content-Transfer-Encoding: ' || 'base64' ||
                          UTL_tcp.CRLF);
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF);
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || '');
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || '');
    
      L_START_TEXT := '<html><body><div><p>Dear CBS Team,</p><p>Good Day!!</p>
<p> This is to inform you that the below transactions are failed. Request to take an action ASAP.</p>';
    
      L_JOB_TEXT := '<table bgcolor="#ffcc5c" style="border: 6px solid #ff6f69;"><tr><th bgcolor="#ffeead">Job Code</th><th></th><th></th><th bgcolor="#ffeead">Job Status</th></tr>' ||
                    '$L_TABLEROWCOL_DATA' || '</table>';
    
      FOR G IN FAILED_ENQUEUED_TXNS LOOP
      
        L_TABLEROWCOL_DATA := L_TABLEROWCOL_DATA || '<tr><td>' ||
                              G.USER_DATA.MESSAGE_CONTENT ||
                              '</td><td></td><td></td><td>' || 'Failed' ||
                              '</td><tr></tr>';
      
      END LOOP;
    
      L_JOB_TEXT := REPLACE(L_JOB_TEXT,
                            '$L_TABLEROWCOL_DATA',
                            L_TABLEROWCOL_DATA);
    
      dbms_output.put_line('L_JOB_TEXT=' || L_JOB_TEXT);
    
      L_END_TEXT := '<p>Thank You.</p><p>Regards,</p><p>CBS Zombie Bot</p></div> </body></html>';
    
      L_MAIL_TEXT := L_START_TEXT || L_JOB_TEXT || L_END_TEXT;
    
      DBMS_OUTPUT.PUT_LINE('L_MAIL_TEXT=' || L_MAIL_TEXT);
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || L_MAIL_TEXT);
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || '');
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || '');
    
      UTL_smtp.close_data(L_MAIL_CONN);
      UTL_smtp.quit(L_MAIL_CONN);
    
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED WHILE DEQUEUING THE TXN');
  END PR_DEQUEUE_MESSAGE;

  PROCEDURE PR_MAIL_ALERT_ZOMBIE_PROCESS AS
  
    L_MAIL_CONN    UTL_SMTP.CONNECTION;
    L_MAIL_HOST    VARCHAR2(100) := '10.80.81.2';
    L_MAIL_PORT_NO VARCHAR2(100) := 25;
    L_USER_ID      VARCHAR2(100) := 'support.app';
    L_PASSWORD     VARCHAR2(100) := 'PB@123!2020@';
  
    L_FROM_ADDRESS VARCHAR2(100) := 'y.raroth@princebank.com.kh';
  
    L_TO_ADDRESS VARCHAR2(100) := 'y.raroth@princebank.com.kh';
  
    L_MAIL_SUBJECT VARCHAR2(100) := 'Alert: *CBS Automation Jobs are either not Running/Stopped or not Scheduled*';
  
    L_MAIL_TEXT VARCHAR2(32767); --:= 'Job $L_JOB_NAME is down. Please check!!';
  
    L_START_TEXT       VARCHAR2(32767);
    L_TABLEROWCOL_DATA VARCHAR2(32767) := '';
    L_JOB_TEXT         VARCHAR2(32767);
    L_END_TEXT         VARCHAR2(32767);
    L_COUNT            NUMBER := 0;
  
    CURSOR C1 IS
      SELECT JOB_NAME, TRIGGER_STATE, NEXT_FIRE_TIME, ERROR
        FROM SMVW_JOB_SCHEDULE
       WHERE JOB_NAME IN ('BAKONG_INCOMING_PROCESS',
                          'BAKONG_IN_HANDOFF',
                          'FAST_INCOMING_HANDOFF',
                          'FAST_INCOMING_PROCESS',
                          'PR_PROCESS_AIA_SI_PAYMENTS')
         AND TRIGGER_STATE NOT IN ('LBL_SCHEDULED', 'SCHEDULED');
  
    L_FAILED_TXNS_COUNT NUMBER := 0;
  
  BEGIN
  
    --GLOBAL.PR_INIT('000', 'SYSTEM');
  
    DEBUG.PR_DEBUG('IF', 'START OF PR_MAIL_ALERT_PROCESS');
  
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM SMVW_JOB_SCHEDULE
       WHERE JOB_NAME IN ('BAKONG_INCOMING_PROCESS',
                          'BAKONG_IN_HANDOFF',
                          'FAST_INCOMING_HANDOFF',
                          'FAST_INCOMING_PROCESS',
                          'PR_PROCESS_AIA_SI_PAYMENTS')
         AND TRIGGER_STATE NOT IN ('LBL_SCHEDULED', 'SCHEDULED');
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;
  
    BEGIN
      SELECT COUNT(1)
        INTO L_FAILED_TXNS_COUNT
        FROM IFTB_FAILED_ONLINE_TXNS_QUEUE;
    EXCEPTION
      WHEN OTHERS THEN
        L_FAILED_TXNS_COUNT := 0;
    END;
  
    IF L_COUNT > 0 THEN
    
      L_MAIL_CONN := UTL_smtp.open_connection(L_MAIL_HOST, L_MAIL_PORT_NO);
    
      --utl_smtp.starttls(L_MAIL_CONN);
    
      UTL_SMTP.AUTH(L_MAIL_CONN, L_USER_ID, L_PASSWORD, schemes => 'PLAIN');
    
      utl_smtp.mail(L_MAIL_CONN, L_FROM_ADDRESS);
      utl_smtp.rcpt(L_MAIL_CONN, L_TO_ADDRESS);
    
      UTL_smtp.open_data(L_MAIL_CONN);
    
      UTL_SMTP.write_data(L_MAIL_CONN,
                          'Date: ' ||
                          TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') ||
                          UTL_TCP.crlf);
      UTL_SMTP.write_data(L_MAIL_CONN,
                          'To: ' || L_TO_ADDRESS || UTL_TCP.crlf);
      UTL_SMTP.write_data(L_MAIL_CONN,
                          'From: ' || L_FROM_ADDRESS || UTL_TCP.crlf);
      UTL_SMTP.write_data(L_MAIL_CONN,
                          'Subject: ' || L_MAIL_SUBJECT || UTL_TCP.crlf);
    
      UTL_smtp.write_data(L_MAIL_CONN,
                          'MIME-Version: ' || '1.0' || UTL_tcp.CRLF);
    
      UTL_smtp.write_data(L_MAIL_CONN, 'Content-Type: ' || 'text/html;');
    
      UTL_smtp.write_data(L_MAIL_CONN,
                          'Content-Transfer-Encoding: ' || 'base64' ||
                          UTL_tcp.CRLF);
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF);
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || '');
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || '');
    
      L_START_TEXT := '<html><body><div><p>Dear CBS Team,</p><p>Good Day!!</p>
<p> This is to inform you that the below jobs are either not running/stopped or not scheduled in the MOCKPSET Environment. I request you to check and take further action. If not, I keep sending mails for every 30 seconds.</p>';
    
      L_JOB_TEXT := '<table bgcolor="#ffcc5c" style="border: 6px solid #ff6f69;"><tr><th bgcolor="#ffeead">Job Code</th><th></th><th></th><th bgcolor="#ffeead">Job Status</th></tr>' ||
                    '$L_TABLEROWCOL_DATA' || '</table>';
    
      FOR G IN C1 LOOP
      
        L_TABLEROWCOL_DATA := L_TABLEROWCOL_DATA || '<tr><td>' ||
                              G.JOB_NAME || '</td><td></td><td></td><td>' ||
                              G.TRIGGER_STATE || '</td><tr></tr>';
      
      END LOOP;
    
      L_JOB_TEXT := REPLACE(L_JOB_TEXT,
                            '$L_TABLEROWCOL_DATA',
                            L_TABLEROWCOL_DATA);
    
      dbms_output.put_line('L_JOB_TEXT=' || L_JOB_TEXT);
    
      L_END_TEXT := '<p>Kindly allow me to sleep. Anways, Happy to serve you always!!</p><p>Thank You.</p><p>Regards,</p><p>CBS Zombie Bot</p></div> </body></html>';
    
      L_MAIL_TEXT := L_START_TEXT || L_JOB_TEXT || L_END_TEXT;
    
      DBMS_OUTPUT.PUT_LINE('L_MAIL_TEXT=' || L_MAIL_TEXT);
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || L_MAIL_TEXT);
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || '');
    
      UTL_smtp.write_data(L_MAIL_CONN, UTL_tcp.CRLF || '');
    
      UTL_smtp.close_data(L_MAIL_CONN);
      UTL_smtp.quit(L_MAIL_CONN);
    
    END IF;
  
    IF L_FAILED_TXNS_COUNT > 0 THEN
    
      PR_DEQUEUE_MESSAGE;
    
    END IF;
  
    DEBUG.PR_DEBUG('IF', 'END OF PR_MAIL_ALERT_ZOMBIE_PROCESS');
  
  EXCEPTION
    WHEN UTL_smtp.transient_error OR UTL_smtp.permanent_error THEN
    
      DEBUG.PR_DEBUG('IF',
                     'ÉRROR CODE IN PR_MAIL_ALERT_ZOMBIE_PROCESS=' ||
                     SQLCODE);
      DEBUG.PR_DEBUG('IF',
                     'ÉRROR MESSAGE IN PR_MAIL_ALERT_ZOMBIE_PROCESS=' ||
                     SQLCODE);
    
      UTL_smtp.quit(L_MAIL_CONN);
    WHEN OTHERS THEN
    
      DEBUG.PR_DEBUG('IF',
                     'ÉRROR CODE IN PR_MAIL_ALERT_ZOMBIE_PROCESS=' ||
                     SQLCODE);
      DEBUG.PR_DEBUG('IF',
                     'ÉRROR MESSAGE IN PR_MAIL_ALERT_ZOMBIE_PROCESS=' ||
                     SQLCODE);
      UTL_smtp.quit(L_MAIL_CONN);
    
  END PR_MAIL_ALERT_ZOMBIE_PROCESS;

  PROCEDURE PR_MAIL_ALERT_PROCESS(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    DEBUG.PR_DEBUG('IF', 'Inside PR_MAIL_ALERT_PROCESS');
  
    DEBUG.PR_DEBUG('IF', 'paramName = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'paramValue = ' || PARAMVALUE);
  
    PR_MAIL_ALERT_ZOMBIE_PROCESS;
  
    DEBUG.PR_DEBUG('IF', 'Successful return from PR_MAIL_ALERT_PROCESS');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'Exception during PR_MAIL_ALERT_PROCESS' || SQLERRM);
  END PR_MAIL_ALERT_PROCESS;

END IFPKS_ZOMBIE_BOT_UTILS;
