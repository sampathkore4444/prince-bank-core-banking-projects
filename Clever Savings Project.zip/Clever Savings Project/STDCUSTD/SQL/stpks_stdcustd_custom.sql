CREATE OR REPLACE PACKAGE BODY stpks_stdcustd_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcustd_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdcustd_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdcustd         IN OUT stpks_stdcustd_Main.ty_stdcustd,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..=' || p_Action_Code);
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdcustd_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdcustd         IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
    --sampath starts
    L_MIN_TOP_UP_AMT ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    --sampath ends
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory=' || p_Action_Code);
  
    --sampath starts
  
    DBG('p_Action_Code=' || p_Action_Code);
  
    p_stdcustd.v_ictm_td_details_custom.BRN := p_stdcustd.v_sttms_cust_account.BRANCH_CODE;
    p_stdcustd.v_ictm_td_details_custom.ACC := p_stdcustd.v_sttms_cust_account.CUST_AC_NO;
    p_stdcustd.v_ictm_td_details_custom.CCY := p_stdcustd.v_sttms_cust_account.CCY;
  
    IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS NOT IN
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN
    
      Pr_Log_Error(p_Source,
                   p_Function_Id,
                   'AC-CLS-006',
                   p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);
    
      RETURN FALSE;
    
    END IF;
  
    IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
       ('CLE1',
        'CLE2',
        'CLE3',
        'SY01',
        'SY02',
        'GY01',
        'GY02',
        'RY01',
        'RY02') THEN
    
      p_stdcustd.v_ictm_td_details_custom.BRN := p_stdcustd.v_sttms_cust_account.BRANCH_CODE;
      p_stdcustd.v_ictm_td_details_custom.ACC := p_stdcustd.v_sttms_cust_account.CUST_AC_NO;
      p_stdcustd.v_ictm_td_details_custom.CCY := p_stdcustd.v_sttms_cust_account.CCY;
    
      IF p_Action_Code = 'COMPUTE' THEN
      
        BEGIN
          SELECT B.CODE
            INTO L_MIN_TOP_UP_AMT
            FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
           WHERE A.TYPE = B.TYPE
             AND A.TYPE = 'CLEVERSAV_MINTOP'
             AND B.VALUE = p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
            --p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := 200;
        END;
      
        DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
            p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      
        IF p_stdcustd.v_sttms_cust_account.CCY = 'USD' THEN
        
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT;
        
        ELSIF p_stdcustd.v_sttms_cust_account.CCY = 'KHR' THEN
        
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT * 4000;
        
        END IF;
      
      END IF;
    
      IF p_Action_Code IN (CSPKS_REQ_GLOBAL.P_NEW,CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      
        IF p_stdcustd.v_ictms_acc.AUTO_ROLLOVER = 'Y' THEN
        
          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-003',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);
        
          RETURN FALSE;
        
        END IF;
      
        IF p_stdcustd.v_ictms_acc.MOVE_INT_TO_UNCLAIMED = 'Y' THEN
        
          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-004',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);
        
          RETURN FALSE;
        
        END IF;
      
        IF p_stdcustd.v_ictms_acc.MOVE_PRIC_TO_UNCLAIMED = 'Y' THEN
        
          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-005',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);
        
          RETURN FALSE;
        
        END IF;
      
        IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT IS NULL THEN
        
          Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-002', NULL);
        
          RETURN FALSE;
        
        END IF;
      
        IF p_stdcustd.v_sttms_cust_account.CCY = 'USD' THEN
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <
             L_MIN_TOP_UP_AMT THEN
          
            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-001',
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
        IF p_stdcustd.v_sttms_cust_account.CCY = 'KHR' THEN
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <
             L_MIN_TOP_UP_AMT * 4000 THEN
          
            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-001',
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
      END IF;
    
    END IF;
  
    --sampath ends
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdcustd         IN stpks_stdcustd_Main.ty_stdcustd,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdcustd         IN stpks_stdcustd_Main.ty_stdcustd,
                                       p_Prev_stdcustd    IN OUT stpks_stdcustd_Main.ty_stdcustd,
                                       p_Wrk_stdcustd     IN OUT stpks_stdcustd_Main.ty_stdcustd,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdcustd         IN stpks_stdcustd_Main.Ty_stdcustd,
                                        p_Prev_stdcustd    IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                                        p_Wrk_stdcustd     IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdcustd         IN stpks_stdcustd_Main.Ty_stdcustd,
                            p_Prev_stdcustd    IN stpks_stdcustd_Main.Ty_stdcustd,
                            p_Wrk_stdcustd     IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..apple=' || p_Action_Code);
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdcustd         IN stpks_stdcustd_Main.Ty_stdcustd,
                             p_prev_stdcustd    IN stpks_stdcustd_Main.Ty_stdcustd,
                             p_wrk_stdcustd     IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdcustd         IN stpks_stdcustd_Main.Ty_stdcustd,
                        p_Wrk_stdcustd     IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
    --sampath starts
    L_ICTM_TD_DETAILS_CUSTOM ICTM_TD_DETAILS_CUSTOM%ROWTYPE;
    --sampath ends
  BEGIN
  
    Dbg('In Fn_Pre_Query..=' || p_Action_Code);
  
    IF p_Action_Code IN ('NEW', '', '', 'MODIFY') THEN
    
      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
    
      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
    
      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT;
    
    END IF;
  
    /*IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
      
     DBG('P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE=' ||
          P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE);
    
      DBG('P_STDCUSTD.v_sttms_cust_account.CCY=' ||
          P_STDCUSTD.v_sttms_cust_account.CCY);
    
    
      BEGIN
      
        SELECT *
          INTO L_ICTM_TD_DETAILS_CUSTOM
          FROM Ictm_Td_Details_Custom A
         WHERE A.ACC = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          L_ICTM_TD_DETAILS_CUSTOM := NULL;
      END;
    
      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT;
    
    END IF;*/
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdcustd         IN stpks_stdcustd_Main.ty_stdcustd,
                         p_wrk_stdcustd     IN OUT stpks_stdcustd_Main.ty_stdcustd,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
    --sampath starts
    L_ICTM_TD_DETAILS_CUSTOM ICTM_TD_DETAILS_CUSTOM%ROWTYPE;
    --sampath ends
  
  BEGIN
  
    Dbg('In Fn_Post_Query..1=' || p_Action_Code);
  
    IF p_Action_Code IN ('NEW', '', '', 'MODIFY') THEN
    
      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
    
      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
    
      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT;
    
    END IF;
  
    IF P_ACTION_CODE IN ('EXECUTEQUERY', 'AUTH') THEN
    
      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
    
      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
    
      DBG('P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE=' ||
          P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE);
    
      DBG('P_STDCUSTD.v_sttms_cust_account.CCY=' ||
          P_STDCUSTD.v_sttms_cust_account.CCY);
    
      BEGIN
      
        SELECT *
          INTO L_ICTM_TD_DETAILS_CUSTOM
          FROM Ictm_Td_Details_Custom A
         WHERE A.ACC = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO
           AND A.BRN = P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          L_ICTM_TD_DETAILS_CUSTOM := NULL;
      END;
    
      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT;
    
    END IF;
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdcustd_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdcustd_custom;
