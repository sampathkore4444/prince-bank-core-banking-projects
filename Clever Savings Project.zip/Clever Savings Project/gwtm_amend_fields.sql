prompt Importing table gwtm_amend_fields...
set feedback off
set define off
insert into gwtm_amend_fields (EXT_SYSTEM, SOURCE_OPERATION, NODE_NAME, FIELD_NAME, RAD_FUNCTION_ID, ORIGIN_SYSTEM)
values ('FLEXCUBE', 'STDCUSTD_MODIFY', 'ICTM_TD_DETAILS_CUSTOM', 'MIN_TOP_UP_AMT', 'STDCUSTD', 'FLEXCUBE');

prompt Done.
