CREATE OR REPLACE

PACKAGE BODY icpks_icdredmn_kernel AS

  PKG_CASCADE_NXTMATDT VARCHAR2(1) := 'N';
  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'icpks_icdredmn_Kernel ==>' || P_MSG;
    DEBUG.PR_DEBUG('IC', L_MSG);
  END DBG;
  FUNCTION FN_DEF_TY_TDVWS_TD_REDEMPTION(P_TY_TDVWS_TD_REDEMPTION     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                         TY_TB_V_TDREDMPAYOUT_DETAILS IN OUT ICPKS_FCJ_ICDREDMN.TY_TB_PAYOUTDETS,
                                         P_TY_BCPAYOUTDETS            IN OUT ICTMS_BCPAYOUT_DETAILS%ROWTYPE,
                                         P_TY_PCPAYOUTDETS            IN OUT ICTMS_PCPAYOUT_DETAILS%ROWTYPE,
                                         P_STDCUSAC                   IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                         P_ICDREDMN                   IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN)
    RETURN BOOLEAN;

  FUNCTION FN_DEF_WRK_ICDREDMN(P_WRK_ICDREDMN               IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                               P_TY_TDVWS_TD_REDEMPTION     IN TDVWS_TD_REDEMPTION%ROWTYPE,
                               TY_TB_V_TDREDMPAYOUT_DETAILS IN ICPKS_FCJ_ICDREDMN.TY_TB_PAYOUTDETS,
                               P_TY_BCPAYOUTDETS            IN ICTMS_BCPAYOUT_DETAILS%ROWTYPE,
                               P_TY_PCPAYOUTDETS            IN ICTMS_PCPAYOUT_DETAILS%ROWTYPE,
                               P_STDCUSAC                   IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN;
  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');
  END PR_SKIP_HANDLER;

  FUNCTION FN_ADDPAYIN_VALIDATE(P_FUNCTION_ID IN VARCHAR2,
                                P_ACTION_CODE IN VARCHAR2,
                                P_ICDREDMN    IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                P_ERR_FLAG    IN OUT NUMBER) RETURN BOOLEAN IS
    L_COUNT            NUMBER := 0;
    GL_COUNT           NUMBER := 0;
    CASHGL_COUNT       NUMBER := 0;
    L_PAYIN_TOTAL      NUMBER(22, 3) := 0;
    L_PAYIN_PERCENTAGE NUMBER(22, 3) := 0;
    L_ACC_BAL          STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    OFFSETFCY_AMOUNT   NUMBER;
    OFFSET_XRATE       ACTBS_HANDOFF.EXCH_RATE%TYPE;
    CHEQUE_COUNT       NUMBER := 0;
    SAV_COUNT          NUMBER := 0;
    L_ERROR_CODE       VARCHAR2(10);
    L_RESULT           VARCHAR2(1);
    L_BAL_MULTIMODE    STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_LIM_BAL          STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    CURSOR CUR_FACILITY_LINKAGE(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM STTM_CUST_ACCOUNT_LINKAGES
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;
    TYPE TY_FACILITY_LINKAGE IS TABLE OF CUR_FACILITY_LINKAGE%ROWTYPE INDEX BY BINARY_INTEGER;
    L_FACILITY_LINKAGE TY_FACILITY_LINKAGE;
    TYPE TY_EXPIRY_DATE IS TABLE OF GETM_FACILITY.LINE_EXPIRY_DATE%TYPE INDEX BY BINARY_INTEGER;
    L_EXPIRED_DATE    TY_EXPIRY_DATE;
    L_ERR_CODE        ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM       VARCHAR2(2000);
    L_EXPIRY_COUNT    NUMBER := 0;
    L_EXPIRY_DATE     DATE;
    L_LIAB_NO         VARCHAR2(20);
    L_AC_STAT_DORMANT STTMS_CUST_ACCOUNT.AC_STAT_DORMANT%TYPE;
    L_ACCOUNT_CLASS   STTM_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_AVL_BAL_REQ     STTM_ACCOUNT_CLASS.AVAIL_BAL_REQD%TYPE;
    L_AC_OPEN_DATE    STTMS_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
    L_ADD_CCY         STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_PROD            ICTB_ACC_PR.PROD%TYPE;
    L_INT_START_DATE  ICTM_ACC.INT_START_DATE%TYPE;
    L_TD_AMOUNT       ICTM_TD_DETAILS.TD_AMOUNT%TYPE;
    L_MAT_DATE        ICTM_ACC.MATURITY_DATE%TYPE;
    L_SECTORCODE      DETM_CLG_BRN_CODE.SECTOR_CODE%TYPE;
    L_CRVALDT         DATE;
    L_DRVALDT         DATE;
    L_LATE_CLEARING   VARCHAR2(10);
    L_RESULT1         VARCHAR2(1);
    L_CUST_ACC_REC    STTM_CUST_ACCOUNT%ROWTYPE;
    L_BALREC          STTM_ACCOUNT_BALANCE%ROWTYPE;
    L_ACC_CLASS_REC   STTM_ACCOUNT_CLASS%ROWTYPE;
    L_PR_INT          ICTM_PR_INT%ROWTYPE;
    L_PAY_MTHD        ICTM_PR_INT.PAYMENT_METHOD%TYPE;
    L_CHQ_STL_DAYS    STTM_BRANCH.CHEQUE_STALE_DAYS%TYPE;
  BEGIN
    DBG('Inside fn_payinout_validate');
    IF P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS = 'Y' AND
       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT IS NOT NULL THEN
      IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT = 0 THEN
        DBG('Payin  account details cannot be null');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-19', '');
        P_ERR_FLAG := -1;
        RETURN FALSE;
      END IF;
    END IF;
    DBG('First checking for v_ictms_tdredpayin_details count :' ||
        P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT);
    IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT > 0 THEN
      BEGIN
        SELECT PROD
          INTO L_PROD
          FROM ICTM_ACC_PR
         WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
           AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      
        SELECT PAYMENT_METHOD
          INTO L_PAY_MTHD
          FROM ICTM_PR_INT
         WHERE PRODUCT_CODE = L_PROD;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Error while selecting payment method' || SQLERRM);
      END;
    
      IF NVL(L_PAY_MTHD, 'B') = 'D' THEN
      
        DBG('Add funds feature is not supported for Discounted Deposit');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-550', '');
        P_ERR_FLAG := -1;
      END IF;
    
      FOR I IN P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.FIRST .. P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.LAST LOOP
        DBG('p_icdredmn.v_ictms_tdredpayin_details(i).multimode_payopt....' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
            .MULTIMODE_PAYOPT);
        IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
         .MULTIMODE_PAYOPT NOT IN ('S', 'G', 'Q') OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
           .MULTIMODE_PAYOPT IS NULL THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-TD-100',
                       '@ICTMS_TD_DETAILS.PAYIN_OPTION~');
          P_ERR_FLAG := -1;
        END IF;
        IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'S' THEN
          DBG('looping for payin details' || I || '  FIR ACCC ' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
              .MULTIMODE_OFFSET_BRN);
          IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
           .MULTIMODE_OFFSET_BRN IS NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .MULTIMODE_TDOFFSET_ACC IS NULL THEN
            DBG('Payin offset account cannot be null');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS400', '');
            P_ERR_FLAG := -1;
            RETURN FALSE;
          END IF;
          IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
           .MULTIMODE_OFFSET_BRN IS NOT NULL THEN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM STTMS_BRANCH
             WHERE BRANCH_CODE = P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                  .MULTIMODE_OFFSET_BRN
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';
            IF L_COUNT = 0 THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-115',
                           '@ICTMS_TD_DETAILS.OFFSET_BRN~' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                           .MULTIMODE_OFFSET_BRN || '~');
              P_ERR_FLAG := -1;
            END IF;
          END IF;
          IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                           .MULTIMODE_OFFSET_BRN,
                                           P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                           .MULTIMODE_TDOFFSET_ACC,
                                           L_CUST_ACC_REC) THEN
            DBG('Failed in select from sttm_cust_account');
          END IF;
        
          CVPKS_UTILS.GET_ACCOUNT_CLASS(L_CUST_ACC_REC.ACCOUNT_CLASS,
                                        L_ACC_CLASS_REC,
                                        L_ERR_CODE);
        
          IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                                      .MULTIMODE_OFFSET_BRN,
                                                      P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                                      .MULTIMODE_TDOFFSET_ACC,
                                                      'N',
                                                      L_BALREC) THEN
            DEBUG.PR_DEBUG('AC',
                           'Failed in Get_Sttm_Account_Balance .. : ' ||
                           SQLERRM);
          END IF;
          L_CUST_ACC_REC.ACY_AVL_BAL := L_BALREC.ACY_WITHDRAWABLE_BAL;
        
          IF L_CUST_ACC_REC.AC_STAT_FROZEN = 'Y' THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'AC-VAC04',
                         '@ICTMS_TD_DETAILS.OFFSET_ACC~' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                         .MULTIMODE_TDOFFSET_ACC || '~');
          
          END IF;
          IF L_CUST_ACC_REC.AC_STAT_NO_DR = 'Y' THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'AC-VAC07',
                         '@' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                         .MULTIMODE_TDOFFSET_ACC || '~');
          END IF;
          IF L_BALREC.AC_STAT_DORMANT = 'Y' THEN
            DBG('Dormant account');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'AC-VAC05',
                         P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                         .MULTIMODE_TDOFFSET_ACC);
          END IF;
          IF CUR_FACILITY_LINKAGE%ISOPEN THEN
            CLOSE CUR_FACILITY_LINKAGE;
          END IF;
          OPEN CUR_FACILITY_LINKAGE(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                    .MULTIMODE_OFFSET_BRN,
                                    P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                    .MULTIMODE_TDOFFSET_ACC);
          FETCH CUR_FACILITY_LINKAGE BULK COLLECT
            INTO L_FACILITY_LINKAGE;
          L_EXPIRY_COUNT := 0;
          IF L_FACILITY_LINKAGE.COUNT > 0 THEN
            FOR J IN 1 .. L_FACILITY_LINKAGE.COUNT LOOP
              DBG('Customer no ' || L_FACILITY_LINKAGE(J).CUSTOMER_NO);
              BEGIN
                SELECT LIABILITY_NO
                  INTO L_LIAB_NO
                  FROM STTM_CUSTOMER
                 WHERE CUSTOMER_NO = L_FACILITY_LINKAGE(J).CUSTOMER_NO;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('In when others ' || SQLERRM);
                  L_LIAB_NO := NULL;
              END;
              IF L_FACILITY_LINKAGE(J).LINKAGE_TYPE = 'F' THEN
                IF NOT
                    ELPKS_FACILITY_SERVICE.FN_GET_LINE_EXP_DT(L_FACILITY_LINKAGE(J)
                                                              .LINKED_REF_NO,
                                                              L_LIAB_NO,
                                                              L_EXPIRY_DATE,
                                                              L_ERR_CODE,
                                                              L_ERR_PARAM) THEN
                  DBG('Failed in Elpks_Facility_Service.Fn_Get_Line_Exp_Dt' ||
                      SQLERRM);
                  RETURN FALSE;
                ELSE
                  L_EXPIRED_DATE(J) := L_EXPIRY_DATE;
                END IF;
              
                IF (L_EXPIRED_DATE(J) < GLOBAL.APPLICATION_DATE) THEN
                  L_EXPIRY_COUNT := L_EXPIRY_COUNT + 1;
                END IF;
              END IF;
              DBG('Calculated Balance Amount greater than limit balance...error message... : ' || J);
            END LOOP;
          END IF;
          DBG('i outer loop : ' || I);
          CLOSE CUR_FACILITY_LINKAGE;
          IF L_EXPIRY_COUNT > 0 THEN
            DBG('Inside expired  OD lines ');
            IF NOT ACPKS_MISC.FN_GETAVLBAL(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                           .MULTIMODE_OFFSET_BRN,
                                           P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                           .MULTIMODE_TDOFFSET_ACC,
                                           L_ACC_BAL,
                                           'Y',
                                           'N',
                                           'Y') THEN
              DBG('Failed in call to fn_getavlbal for the TD Offset Account.');
              RETURN FALSE;
            END IF;
          ELSE
            DBG('Inside available OD lines ');
            IF NOT ACPKS_MISC.FN_GETAVLBAL(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                           .MULTIMODE_OFFSET_BRN,
                                           P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                           .MULTIMODE_TDOFFSET_ACC,
                                           L_ACC_BAL,
                                           'Y',
                                           'Y',
                                           'Y') THEN
              DBG('Failed in call to fn_getavlbal for the TD Offset Account.');
              RETURN FALSE;
            END IF;
          END IF;
          DBG('Offset Branch ' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
              .MULTIMODE_OFFSET_BRN);
          DBG('Offset Account ' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
              .MULTIMODE_TDOFFSET_ACC);
        
          P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I).MULTIMODE_TDOFFSET_CCY := L_CUST_ACC_REC.CCY;
        
          DBG('l_avl_bal_req ----->' || L_ACC_CLASS_REC.AVAIL_BAL_REQD);
          DBG('Got avl bal as --->' || L_ACC_BAL);
          DBG('offsetccy ----->' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
              .MULTIMODE_TDOFFSET_CCY);
          DBG('global.lcy ----->' || GLOBAL.LCY);
          IF NVL(L_ACC_CLASS_REC.AVAIL_BAL_REQD, 'N') = 'Y' THEN
            IF ((P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
               .MULTIMODE_TDOFFSET_CCY = GLOBAL.LCY) AND
               (P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY = GLOBAL.LCY)) OR
               (P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
               .MULTIMODE_TDOFFSET_CCY =
                P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY) THEN
              DBG('In the case where td , offset ccy r same as local ccy....');
              DBG('hv to compare acc avl bal with offset lcy amt.....');
              IF (NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0) <
                 NVL(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                      .MULTIMODE_TDAMOUNT,
                      0)) THEN
                DBG('TD Amount greater than available balance...calculating balance amount...');
                IF NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0) > 0 THEN
                  L_BAL_MULTIMODE := NVL(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                         .MULTIMODE_TDAMOUNT,
                                         0) -
                                     NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0);
                ELSE
                  L_BAL_MULTIMODE := NVL(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                         .MULTIMODE_TDAMOUNT,
                                         0);
                END IF;
                IF (NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0) <= NVL(L_ACC_BAL, 0)) THEN
                  DBG('Total Amount greater than available balance...calculating limit balance amount...');
                  IF NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0) > 0 THEN
                    L_LIM_BAL := NVL(L_ACC_BAL, 0) -
                                 NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0);
                  ELSE
                    L_LIM_BAL := NVL(L_ACC_BAL, 0);
                  END IF;
                END IF;
                IF (NVL(L_BAL_MULTIMODE, 0) <= NVL(L_LIM_BAL, 0)) THEN
                  DBG('Calculated Balance Amount less than limit balance...override message... ' ||
                      L_LIM_BAL || ' balance Td amount ' ||
                      L_BAL_MULTIMODE);
                  L_ERR_PARAM := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                 .MULTIMODE_TDOFFSET_ACC;
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'ST-ACC-010',
                               L_ERR_PARAM);
                
                ELSIF (NVL(L_BAL_MULTIMODE, 0) > NVL(L_LIM_BAL, 0)) THEN
                  IF L_EXPIRY_COUNT > 0 THEN
                    DBG('Calculated Balance Amount greater than limit balance expired error message ' ||
                        L_LIM_BAL || ' balance Td amount ' ||
                        L_BAL_MULTIMODE);
                    L_ERR_PARAM := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                   .MULTIMODE_TDOFFSET_ACC;
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-ACC-012',
                                 L_ERR_PARAM);
                  ELSE
                    DBG('Calculated Balance Amount greater than limit balance avl error message ' ||
                        L_LIM_BAL || ' balance Td amount ' ||
                        L_BAL_MULTIMODE);
                    L_ERR_PARAM := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                   .MULTIMODE_TDOFFSET_ACC;
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-ACC-011',
                                 L_ERR_PARAM);
                  END IF;
                END IF;
              END IF;
            ELSE
              OFFSETFCY_AMOUNT := NULL;
              OFFSET_XRATE     := NULL;
              DBG('its in the else part of forign currency');
            
              IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS     (I).BRN,
                                                 P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY,
                                                 P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS     (I)
                                                 .MULTIMODE_TDOFFSET_CCY,
                                                 P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS     (I)
                                                 .MULTIMODE_TDAMOUNT,
                                                 'Y',
                                                 OFFSETFCY_AMOUNT,
                                                 OFFSET_XRATE,
                                                 P_ERR_FLAG) THEN
                DBG('failed');
                DBG(SQLERRM);
                RETURN FALSE;
              END IF;
              DBG('so comparing acc avl bal with offset fcy amt...as this will hv the td offset amt in ac ccy...');
              IF (NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0) <
                 NVL(OFFSETFCY_AMOUNT, 0)) THEN
              
                DBG('TD Amount greater than available balance...calculating balance amount...');
                IF NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0) > 0 THEN
                  L_BAL_MULTIMODE := NVL(OFFSETFCY_AMOUNT, 0) -
                                     NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0);
                ELSE
                  L_BAL_MULTIMODE := NVL(OFFSETFCY_AMOUNT, 0);
                END IF;
                IF (NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0) <= NVL(L_ACC_BAL, 0)) THEN
                  DBG('Total Amount greater than available balance...calculating limit balance amount...');
                  IF NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0) > 0 THEN
                    L_LIM_BAL := NVL(L_ACC_BAL, 0) -
                                 NVL(L_CUST_ACC_REC.ACY_AVL_BAL, 0);
                  ELSE
                    L_LIM_BAL := NVL(L_ACC_BAL, 0);
                  END IF;
                END IF;
                IF (NVL(L_BAL_MULTIMODE, 0) <= NVL(L_LIM_BAL, 0)) THEN
                  DBG('Calculated Balance Amount less than limit balance...override message... ' ||
                      L_LIM_BAL || ' balance Td amount ' ||
                      L_BAL_MULTIMODE);
                  L_ERR_PARAM := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                 .MULTIMODE_TDOFFSET_ACC;
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'ST-ACC-010',
                               L_ERR_PARAM);
                
                ELSIF (NVL(L_BAL_MULTIMODE, 0) > NVL(L_LIM_BAL, 0)) THEN
                  IF L_EXPIRY_COUNT > 0 THEN
                    DBG('Calculated Balance Amount greater than limit balance expired error message ' ||
                        L_LIM_BAL || ' balance Td amount ' ||
                        L_BAL_MULTIMODE);
                    L_ERR_PARAM := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                   .MULTIMODE_TDOFFSET_ACC;
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-ACC-012',
                                 L_ERR_PARAM);
                  ELSE
                    DBG('Calculated Balance Amount greater than limit balance avl error message ' ||
                        L_LIM_BAL || ' balance Td amount ' ||
                        L_BAL_MULTIMODE);
                    L_ERR_PARAM := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                                   .MULTIMODE_TDOFFSET_ACC;
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-ACC-011',
                                 L_ERR_PARAM);
                  END IF;
                END IF;
              END IF;
            END IF;
          END IF;
        
          SAV_COUNT := SAV_COUNT + 1;
        ELSIF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
         .MULTIMODE_PAYOPT = 'G' THEN
          GL_COUNT := GL_COUNT + 1;
        ELSIF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
         .MULTIMODE_PAYOPT = 'Q' THEN
          DBG(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I).CHQ_INSTUMENTNO);
          DBG(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I).CHQ_INSTRUMENT_DATE);
          DBG(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I).CLG_BANK_CODE);
          DBG(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I).CLG_BRANCH_CODE);
          DBG(P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I).CLG_PRODUCT_CODE);
          IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
           .CHQ_INSTUMENTNO IS NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CLG_BANK_CODE IS NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CLG_BRANCH_CODE IS NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CLG_PRODUCT_CODE IS NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CHQ_INSTRUMENT_DATE IS NULL THEN
            P_ERR_FLAG := -1;
            DBG('Cheque Instrument no,Clearing Bank Code and Clearing Branch Code,Clearing Product,Cheque date is mandatory');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-ACC-250',
                         'Cheque Instrument no,Clearing Bank Code,Clearing Branch Code,Clearing Product,Cheque date');
          END IF;
        
          IF NOT GLOBALS_FRC.FN_GET_BRN_REC_WRP(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                                L_ERR_CODE,
                                                L_ERR_PARAM) THEN
            DBG('Failed in globals_frc.Fn_Get_Brn_Rec_Wrp bec of - ' ||
                L_ERR_CODE);
            L_CHQ_STL_DAYS := NULL;
          ELSE
            DBG('Rec exists for the branch in cache..');
            L_CHQ_STL_DAYS := GLOBALS_FRC.G_TBL_STTM_BRANCH_REC.CHEQUE_STALE_DAYS;
          END IF;
          DBG('l_chq_stl_days.-->' || L_CHQ_STL_DAYS);
          IF L_CHQ_STL_DAYS IS NOT NULL THEN
          
            IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CHQ_INSTRUMENT_DATE <=
                GLOBAL.APPLICATION_DATE - L_CHQ_STL_DAYS THEN
              DBG('Cheque date cannot be lesser than stale days');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-VALS-003', '');
              RETURN FALSE;
            END IF;
          END IF;
          IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
           .CHQ_INSTRUMENT_DATE > GLOBAL.APPLICATION_DATE
          
           THEN
            DBG('Cheque date cannot be greater than today');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE'
                         
                        ,
                         'TD-VALS-002',
                         '');
            RETURN FALSE;
          END IF;
          CHEQUE_COUNT := CHEQUE_COUNT + 1;
        END IF;
        IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I).MULTIMODE_PAYOPT <> 'Q' THEN
          DBG('not cheque');
          IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
           .CHQ_INSTUMENTNO IS NOT NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CLG_BANK_CODE IS NOT NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CLG_BRANCH_CODE IS NOT NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CLG_PRODUCT_CODE IS NOT NULL OR P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CHQ_INSTRUMENT_DATE IS NOT NULL THEN
            DBG('Cheque Instrument no,Clearing Bank Code and Clearing Branch Code should be null while Payin option is not Cheque.');
            P_ERR_FLAG := -1;
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-342', '');
          END IF;
        END IF;
        L_PAYIN_TOTAL := L_PAYIN_TOTAL + P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                        .MULTIMODE_TDAMOUNT;
      
        IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
         .MULTIMODE_PERCENTAGE IS NOT NULL THEN
          L_PAYIN_PERCENTAGE := L_PAYIN_PERCENTAGE + P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                               .MULTIMODE_PERCENTAGE;
        END IF;
      END LOOP;
    END IF;
    IF GL_COUNT > 1 THEN
      DBG('payin for GL or Cash cannot be greater than 1');
      P_ERR_FLAG := -1;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-214', '');
    END IF;
    IF CHEQUE_COUNT > 1 THEN
      DBG('Payin Option Cannot be Greater than one with Cheque');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-254', '');
      P_ERR_FLAG := -1;
      RETURN FALSE;
    END IF;
  
    IF CHEQUE_COUNT >= 1 AND (SAV_COUNT >= 1 OR GL_COUNT >= 1) THEN
      DBG('Other Payin Options not allowed while Payin option Cheque Selected.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-255', '');
      P_ERR_FLAG := -1;
      RETURN FALSE;
    END IF;
    DBG('gl_count-->' || GL_COUNT);
    DBG('l_payin_total is :' || L_PAYIN_TOTAL);
    IF L_PAYIN_TOTAL <>
       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT THEN
      DBG('Payin Details is not equal to Additional amount');
      P_ERR_FLAG := -1;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-206', '');
    END IF;
    DBG('l_payin_percentage is :' || L_PAYIN_PERCENTAGE);
  
    IF NOT (L_PAYIN_PERCENTAGE = 0 OR L_PAYIN_PERCENTAGE = 100) THEN
      DBG('Total Payin Percentage is not consistent');
      P_ERR_FLAG := -1;
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-207', '');
    END IF;
  
    RETURN TRUE;
  END FN_ADDPAYIN_VALIDATE;

  FUNCTION FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                        P_ICDREDMN         IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Build_Type_Structure..');
  
    DBG('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Build_Type_Structure ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_BUILD_TYPE_STRUCTURE;

  FUNCTION FN_PRE_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CHILD_FUNCTION   IN VARCHAR2,
                                  P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                  P_ICDREDMN         IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
    L_YEARS              NUMBER;
    L_MONTHS             NUMBER;
    L_DAYS               NUMBER;
    L_INT_START_DATE     ICTMS_ACC.INT_START_DATE%TYPE;
    L_CALC_DATE          DATE;
    L_RECOMPUTE_MAT_DATE STTM_ACCOUNT_CLASS.RECOMPUTE_MAT_DATE%TYPE;
  
    L_CASCADE_MONTH  ICTM_ACC.CASCADE_MONTH%TYPE;
    L_NEXT_MAT_DT_BK DATE;
  
    L_CUST_ACC_REC STTM_CUST_ACCOUNT%ROWTYPE;
    L_AVL_DATE     ACTB_FUNCOL.AVAILABLEDATE%TYPE;
    L_CNT_CHKPAYIN NUMBER := 0;
  
  BEGIN
  
    DBG('In Fn_Pre_Check_Mandatory..');
  
    IF P_ACTION_CODE = 'NEW' THEN
      IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO,
                                       L_CUST_ACC_REC) THEN
        DBG('Failed in select from sttm_cust_account');
      END IF;
    
      SELECT COUNT(*)
        INTO L_CNT_CHKPAYIN
        FROM ICTM_TDPAYIN_DETAILS
       WHERE BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE
         AND ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
         AND MULTIMODE_PAYOPT = 'Q';
    
      DBG('l_cnt_chkpayin--->' || L_CNT_CHKPAYIN);
      IF L_CNT_CHKPAYIN > 0 THEN
        L_AVL_DATE := ICPKS_BOD.GET_CHQ_AVL_DATE(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                                 P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO,
                                                 NULL);
        DBG('l_avl_date-->' || L_AVL_DATE);
        IF (L_AVL_DATE IS NOT NULL AND L_AVL_DATE > GLOBAL.APPLICATION_DATE) OR
           (L_CUST_ACC_REC.AC_OPEN_DATE = GLOBAL.APPLICATION_DATE) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-TOP-036', NULL);
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND P_SOURCE <> 'FLEXCUBE' THEN
      DBG('Action code is NEW and source is not FLEXCUBE and action flag is ' ||
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG);
      IF P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'E' THEN
        DBG('MANUAL ROLLOVER PREF' ||
            P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF);
        BEGIN
          SELECT MATURITY_DATE
            INTO L_INT_START_DATE
            FROM ICTMS_ACC
           WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Cannot fetch maturity date, returning false');
            RETURN FALSE;
        END;
        IF P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF = 'A' THEN
          BEGIN
            SELECT NVL(ORIG_TENOR_YEARS, 0),
                   NVL(ORIG_TENOR_MONTHS, 0),
                   NVL(ORIG_TENOR_DAYS, 0),
                   CASCADE_MONTH
              INTO L_YEARS, L_MONTHS, L_DAYS, L_CASCADE_MONTH
              FROM ICTM_ACC
             WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
               AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
          
            P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY := L_YEARS;
            P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM := L_MONTHS;
            P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD := L_DAYS;
          
            DBG('Interest start date-->' || L_INT_START_DATE);
            DBG('Account  Tenor days-->' ||
                P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD);
            DBG('Account  Tenor Months-->' ||
                P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM);
            DBG('Account  Tenor Years-->' ||
                P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY);
            P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                               L_MONTHS +
                                                                               L_YEARS * 12) +
                                                                    L_DAYS;
          
            IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND NVL(L_DAYS, 0) = 0 THEN
              L_NEXT_MAT_DT_BK := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
              IF NOT
                  STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
                P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
              END IF;
            
              IF L_NEXT_MAT_DT_BK <>
                 P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
                DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
                PKG_CASCADE_NXTMATDT := 'Y';
              END IF;
            
            END IF;
          
            DBG('NEXT MATURITY DATE-->' ||
                P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('No tenor information available');
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY      := 0;
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM      := 0;
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD      := 0;
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE,
                                                                                 L_MONTHS +
                                                                                 L_YEARS * 12) +
                                                                      L_DAYS;
            
              IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND NVL(L_DAYS, 0) = 0 THEN
                L_NEXT_MAT_DT_BK := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
                IF NOT
                    STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                            P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
                  P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
                END IF;
              
                IF L_NEXT_MAT_DT_BK <>
                   P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
                  DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
                  PKG_CASCADE_NXTMATDT := 'Y';
                END IF;
              
              END IF;
            
          END;
        ELSIF P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF = 'L' THEN
          BEGIN
          
            SELECT NVL(DEFAULT_TENOR_YEARS, 0),
                   NVL(DEFAULT_TENOR_MONTHS, 0),
                   NVL(DEFAULT_TENOR_DAYS, 0),
                   CASCADE_MONTH
              INTO P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY,
                   P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM,
                   P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD,
                   L_CASCADE_MONTH
              FROM STTM_ACCOUNT_CLASS
             WHERE ACCOUNT_CLASS IN
                   (SELECT ACCOUNT_CLASS
                      FROM STTM_CUST_ACCOUNT
                     WHERE CUST_AC_NO =
                           P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
                       AND BRANCH_CODE =
                           P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Failed in defaulting tenor');
          END;
          DBG('Interest start date-->' || L_INT_START_DATE);
          DBG('Account class Tenor days-->' ||
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD);
          DBG('Account class Tenor Months-->' ||
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM);
          DBG('Account class Tenor Years-->' ||
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY);
        
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                             P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM +
                                                                             P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY * 12) +
                                                                  P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD;
        
          IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
             NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) = 0 THEN
            L_NEXT_MAT_DT_BK := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
            END IF;
          
            IF L_NEXT_MAT_DT_BK <>
               P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
              DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
              PKG_CASCADE_NXTMATDT := 'Y';
            END IF;
          
          END IF;
        
          DBG('NEXT MATURITY DATE-->' ||
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
        
        ELSE
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD      := NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD,
                                                                      0);
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM      := NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM,
                                                                      0);
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY      := NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY,
                                                                      0);
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                             P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM +
                                                                             P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY * 12) +
                                                                  P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD;
        
          IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
             NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) = 0 THEN
            L_NEXT_MAT_DT_BK := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
            END IF;
          
            IF L_NEXT_MAT_DT_BK <>
               P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
              DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
              PKG_CASCADE_NXTMATDT := 'Y';
            END IF;
          
          END IF;
        
        END IF;
      
      ELSIF (P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'T') THEN
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD      := NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD,
                                                                    0);
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM      := NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM,
                                                                    0);
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY      := NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY,
                                                                    0);
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                           P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM +
                                                                           P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY * 12) +
                                                                P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD;
      
        BEGIN
          SELECT CASCADE_MONTH
            INTO L_CASCADE_MONTH
            FROM ICTM_ACC
           WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            L_CASCADE_MONTH := 'N';
        END;
        IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
           NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) = 0 THEN
          L_NEXT_MAT_DT_BK := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                      P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
            P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
          END IF;
        
          IF L_NEXT_MAT_DT_BK <>
             P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
            DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
            PKG_CASCADE_NXTMATDT := 'Y';
          END IF;
        
        END IF;
      
      ELSE
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD      := NULL;
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM      := NULL;
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY      := NULL;
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := NULL;
      END IF;
    END IF;
  
    DBG('p_action_code' || P_ACTION_CODE);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       P_SOURCE <> 'FLEXBRANCH' THEN
      IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT > 0 THEN
        FOR I IN 1 .. P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.LAST LOOP
          IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).PAYOUTTYPE = 'C' THEN
            DBG('Cash option for TD PayOUT is not allowed for ICDREDMN screen');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'ST-VALS-011',
                         '@ICTMS_TDREDMPAYOUT_DETAILS. ' ||
                         '~@ICTMS_TDREDMPAYOUT_DETAILS.PAYOUTTYPE');
          END IF;
        END LOOP;
      END IF;
    END IF;
  
    DBG('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    DBG('In Fn_Post_Check_Mandatory..');
  
    DBG('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CHILD_FUNCTION   IN VARCHAR2,
                                       P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                       P_PREV_ICDREDMN    IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                       P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_DESC   STTM_CUST_ACCOUNT.AC_DESC%TYPE;
    L_CUSTNO STTM_CUST_ACCOUNT.CUST_NO%TYPE;
    L_CCY    STTM_CUST_ACCOUNT.CCY%TYPE;
    L_BAL    STTM_CUST_ACCOUNT.ACY_CURR_BALANCE%TYPE;
    L_CNT    NUMBER := 0;
  
    L_BALREC STTM_ACCOUNT_BALANCE%ROWTYPE;
  BEGIN
  
    DBG('In Fn_Pre_Default_And_Validate..');
    DBG('p_icdredmn.v_cstb_ui_columns.CHAR_FIELD84' ||
        P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84);
    P_WRK_ICDREDMN := P_ICDREDMN;
  
    DBG('p_Source-' || P_SOURCE);
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTM_CUST_ACCOUNT
     WHERE CUST_AC_NO = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
       AND BRANCH_CODE = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
  
    IF P_SOURCE <> 'FLEXCUBE' AND L_CNT > 0 THEN
    
      BEGIN
        SELECT DISTINCT AC_DESC, CUST_NO, CCY
          INTO L_DESC, L_CUSTNO, L_CCY
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
           AND BRANCH_CODE =
               P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found');
          P_ERR_CODE   := 'IC-BOD17';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
      END;
    
      IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                                  P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO,
                                                  'N',
                                                  L_BALREC) THEN
        DEBUG.PR_DEBUG('AC',
                       'Failed in Get_Sttm_Account_Balance .. : ' ||
                       SQLERRM);
      END IF;
      L_BAL := L_BALREC.ACY_CURR_ACC_BAL;
    
      IF L_DESC <> P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_DESC THEN
        P_ERR_CODE   := 'LD-VALS-012';
        P_ERR_PARAMS := 'Account Description';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      
      END IF;
      IF L_CUSTNO <> P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CUST_ID THEN
        P_ERR_CODE   := 'LD-VALS-012';
        P_ERR_PARAMS := 'Customer Id';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      IF L_CCY <> P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY THEN
        P_ERR_CODE   := 'LD-VALS-012';
        P_ERR_PARAMS := 'Currency';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      IF L_BAL <> P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_AMT THEN
        P_ERR_CODE   := 'LD-VALS-012';
        P_ERR_PARAMS := 'Balance';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

  FUNCTION FN_POST_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                        P_PREV_ICDREDMN    IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                        P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_TY_TDVWS_TD_REDEMPTION     TDVWS_TD_REDEMPTION%ROWTYPE;
    TY_TB_V_TDREDMPAYOUT_DETAILS ICPKS_FCJ_ICDREDMN.TY_TB_PAYOUTDETS;
    L_TY_BCPAYOUTDETS            ICTMS_BCPAYOUT_DETAILS%ROWTYPE;
    L_TY_PCPAYOUTDETS            ICTMS_PCPAYOUT_DETAILS%ROWTYPE;
    L_TY_STDCUSAC                STPKS_STDCUSAC_MAIN.TY_STDCUSAC;
    L_OVERRIDE_FLAG              VARCHAR2(30000);
    L_ERR_TBL                    OVPKS.TBL_ERROR;
    L_MULTI_TRIP_ID              VARCHAR2(1000);
    L_SOURCE                     VARCHAR2(50);
    L_ACTION_CODE                VARCHAR2(50);
    L_OPERATION_CODE             VARCHAR2(100);
    L_TBL_CHGDETS                ICPKS_FCJ_ICDREDMN.TBL_CHGDETS;
    L_TY_MISDETAILS              MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE;
    L_TBL_UDFDETAILS             UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF;
    L_TY_SUBSYS                  ICPKS_FCJ_ICDREDMN.TBL_NODE;
    L_COUNT                      NUMBER;
    L_AUTO_AUTH                  VARCHAR2(10);
    L_AUTO_GEN_FLAG              VARCHAR2(1);
    L_USER_ID                    ICTB_TDREDEMPTION_MASTER.CHECKER_ID%TYPE;
    L_CUSTOMER                   STTM_CUST_ACCOUNT.CUST_NO%TYPE;
    L_MFI_COUNT                  NUMBER;
  
    L_MIN_TDAYS          STTM_ACCOUNT_CLASS.MIN_TENOR_DAYS%TYPE;
    L_MAX_TDAYS          STTM_ACCOUNT_CLASS.MAX_TENOR_DAYS%TYPE;
    L_MIN_TMONTHS        STTM_ACCOUNT_CLASS.MIN_TENOR_MONTHS%TYPE;
    L_MAX_TMONTHS        STTM_ACCOUNT_CLASS.MAX_TENOR_MONTHS%TYPE;
    L_MIN_TYEARS         STTM_ACCOUNT_CLASS.MIN_TENOR_YEARS%TYPE;
    L_MAX_TYEARS         STTM_ACCOUNT_CLASS.MAX_TENOR_YEARS%TYPE;
    L_PRM_MIN_MAT_DATE   DATE;
    L_PRM_MAX_MAT_DATE   DATE;
    L_INT_START_DATE     ICTMS_ACC.INT_START_DATE%TYPE;
    L_OLD_INT_START_DATE ICTMS_ACC.INT_START_DATE%TYPE;
    L_MIN_DAYS           NUMBER;
    L_MAX_DAYS           NUMBER;
    L_HOLTREATREQD       VARCHAR2(1);
    L_ACCOUNT_CLASS      STTM_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;
    L_RES                DATE;
    L_MONTH_END_DEP      STTM_ACCOUNT_CLASS.MONTH_END_DEPOSIT%TYPE;
    L_WRK_DAY            DATE;
    L_ERROR              VARCHAR2(10);
    L_MONTH_END_FLG      BOOLEAN := FALSE;
    L_HOL_PREF           STTM_ACCOUNT_CLASS.HOLIDAY_CALENDAR%TYPE;
    L_ORIG_DAYS          NUMBER;
    L_RECOMPUTE_MAT_DATE STTM_ACCOUNT_CLASS.RECOMPUTE_MAT_DATE%TYPE;
  
    CURSOR CR_DENOMDEPOSIT(PACCOUNT IN VARCHAR2) IS
      SELECT SC.CUST_AC_NO,
             SC.BRANCH_CODE,
             SC.CERTIFICATE_NO,
             NULL REFERENCE_NUMBER,
             SC.DENOMINATION_VALUE,
             'N',
             SC.NEW_STATUS
        FROM STTMS_DENOM_DEP_CERTIF SC
       WHERE SC.CUST_AC_NO = PACCOUNT
         AND NOT EXISTS (SELECT 1
                FROM STTMS_DENOM_REDMN_BLK SR
               WHERE SC.CUST_AC_NO = SR.CUST_AC_NO
                 AND SC.BRANCH_CODE = SR.BRANCH_CODE
                 AND SC.CERTIFICATE_NO = SR.CERTIFICATE_NO
                 AND SR.BLOCK_OR_REDEM = 'R')
         AND SC.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND NEW_STATUS IN ('I', 'O', 'D', 'P')
       ORDER BY SC.CERTIFICATE_NO;
    L_REDEEM_AMT STTMS_DENOM_REDMN_BLK.CERTIFICATE_AMOUNT%TYPE;
  
    L_CONT_VAR_ROLL ICTMS_ACC_PR.CONT_VAR_ROLL%TYPE;
  
    L_SUM_REDEMTION   NUMBER;
    L_SUM_CERTIFICATE NUMBER;
    L_REDEM_CERTIF    NUMBER;
    L_DENM_DEPOSIT    STTM_ACCOUNT_CLASS.DENM_DEPOSIT%TYPE;
  
    L_CERT_COUNT NUMBER;
    L_TD_BAL     NUMBER;
  
    L_ALLOW_TENOR_CHANGE CHAR(1);
    L_MATURITY_DATE      ICTM_ACC.MATURITY_DATE%TYPE;
    SI_COUNT             NUMBER;
    L_TY_ICDREDMN        ICPKS_ICDREDMN_MAIN.TY_ICDREDMN;
  
    L_CASCADE_MONTH         ICTM_ACC.CASCADE_MONTH%TYPE;
    L_AC_OPEN_DATE          STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
    L_NEXT_MATURITY_DATE_BK DATE;
  
    L_ACC_AVL_BAL   STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_ERR_FLAG      NUMBER := 0;
    L_ICDREDMN      ICPKS_ICDREDMN_MAIN.TY_ICDREDMN;
    L_STDCUSTD      STPKS_STDCUSTD_MAIN.TY_STDCUSTD;
    L_MIN_AMOUNT    STTMS_ACCLS_MINMAX_AMT_CCY.MIN_AMOUNT%TYPE;
    L_MAX_AMOUNT    STTMS_ACCLS_MINMAX_AMT_CCY.MAX_AMOUNT%TYPE;
    L_DENOM_DEP     STTM_ACCOUNT_CLASS.DENM_DEPOSIT%TYPE;
    L_CCY           STTM_CUST_ACCOUNT.CCY%TYPE;
    L_CUST_ACC_REC  STTM_CUST_ACCOUNT%ROWTYPE;
    L_ICTMS_ACC     ICTM_ACC%ROWTYPE;
    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;
  
    L_REC_ACC_PR ICTB_ACC_PR%ROWTYPE;
  
    L_REDM_INT_PAYOUT ICTM_ACC.REDM_INT_PAYOUT%TYPE;
    L_CNT             NUMBER := 0;
    L_VAR             NUMBER := 0;
  
  BEGIN
  
    DBG('In Fn_Post_Default_And_Validate..');
  
    IF P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY, 'COMPUTE') THEN
      L_ICTMS_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO,
                                                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
    END IF;
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('brn-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
      DBG('acc-->' || P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO);
      DBG('brn-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
      DBG('acc-->' || P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO);
      IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                       P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO,
                                       L_CUST_ACC_REC) THEN
        DBG('Failed in select from sttm_cust_account');
      END IF;
    
      IF NVL(L_CUST_ACC_REC.ACC_TANKED_STAT, 'N') = 'Y' THEN
        DBG('Account is in tanked status.Operation cannot be performed');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TOP-035', '');
        RETURN FALSE;
      END IF;
    
      CVPKS_UTILS.GET_ACCOUNT_CLASS(L_CUST_ACC_REC.ACCOUNT_CLASS,
                                    L_ACC_CLASS_REC,
                                    P_ERR_CODE);
    
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG <> 'E' AND
         (P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS = 'Y' OR
         P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT IS NOT NULL) THEN
        DBG('Add funds feature is not supported for Redemption Process');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-21', '');
        L_ERR_FLAG := 1;
      END IF;
      IF NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT, 0) < 0 THEN
        DBG('Additonal amt cannot be given in negative');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-24', '');
        L_ERR_FLAG := 1;
      END IF;
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'E' THEN
        IF (NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS, 'N') = 'Y' AND
           P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT IS NULL) OR
           (NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS, 'N') <> 'Y' AND
           P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT IS NOT NULL) THEN
          DBG('Additional amount to be given if add funds is selected');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-23', '');
          L_ERR_FLAG := 1;
        END IF;
      END IF;
    
      IF NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS, 'N') = 'Y' AND
         L_ICTMS_ACC.MATURITY_DATE < GLOBAL.APPLICATION_DATE THEN
        IF P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT > 0 THEN
          DBG('Additional Amount can not be specified after Maturity date');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-22', '');
        END IF;
      END IF;
    
      IF NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS, 'N') = 'N' OR
         P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT IS NULL THEN
        IF P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT > 0 THEN
          DBG('Additional payin details should not be provided if add funds is not seleted');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-27', '');
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('p_wrk_icdredmn.v_ictbs_tdredemption_master.add_funds--' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS);
      DBG('p_icdredmn.v_ictbs_tdredemption_master.add_funds--' ||
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS);
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS = 'Y' AND
         P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT IS NOT NULL THEN
        BEGIN
          SELECT NVL(MIN_AMOUNT, 0), NVL(MAX_AMOUNT, 0)
            INTO L_MIN_AMOUNT, L_MAX_AMOUNT
            FROM STTMS_ACCLS_MINMAX_AMT_CCY
           WHERE ACCOUNT_CLASS = L_ACC_CLASS_REC.ACCOUNT_CLASS
             AND CCY = P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY;
          DBG('Selecting minimum amount : ' || L_MIN_AMOUNT);
          DBG('Selecting maximum amount : ' || L_MAX_AMOUNT);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT NVL(MIN_AMOUNT, 0), NVL(MAX_AMOUNT, 0)
                INTO L_MIN_AMOUNT, L_MAX_AMOUNT
                FROM STTMS_ACCLS_MINMAX_AMT_CCY
               WHERE ACCOUNT_CLASS = L_ACCOUNT_CLASS
                 AND CCY = '*.*';
              DBG('Selecting minimum amount for ccy *.* : ' ||
                  L_MIN_AMOUNT);
              DBG('Selecting maximum amount for ccy *.* : ' ||
                  L_MAX_AMOUNT);
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                L_MIN_AMOUNT := 0;
                L_MAX_AMOUNT := 0;
                DBG('Assigning Mininum and Maximum Amount has zero when it is not maintained');
            END;
          WHEN OTHERS THEN
            DBG('Min Max Amount not maintained for the account currency');
        END;
        IF L_MAX_AMOUNT = 0 THEN
          DBG('Max amount is not maintained..ovrride..');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-199', '');
        ELSIF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT >
              L_MAX_AMOUNT THEN
          DBG('TD along with additional amount cannot be greater than the maximum amount required');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-16', '');
          L_ERR_FLAG := 1;
        END IF;
      
        IF L_ACC_CLASS_REC.DENM_DEPOSIT = 'Y' THEN
          DBG('Add funds feature is not supported for Denominated Deposits..');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-17', '');
          L_ERR_FLAG := 1;
        END IF;
        IF P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT = 0 THEN
          DBG('Error ');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-19', '');
          L_ERR_FLAG := 1;
        END IF;
      END IF;
    
      IF L_ERR_FLAG <> 0 THEN
        DBG('fn_validate_deposits returning false');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, 'COMPUTE') THEN
      IF NOT (NVL(L_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED, 'N') = 'Y' OR
          NVL(L_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED, 'N') = 'Y') THEN
        IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG != 'E' THEN
        
          SELECT COUNT(1)
            INTO L_COUNT
            FROM ACVWS_ALL_AC_ENTRIES
           WHERE AC_BRANCH =
                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE
             AND AC_NO = P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND EVENT = 'DEBK'
             AND TRN_DT = GLOBAL.APPLICATION_DATE
             AND VALUE_DT < GLOBAL.APPLICATION_DATE;
        
          IF L_COUNT = 1 THEN
          
            DBG('Backdated TD created pending liqudiation exists on' ||
                L_REC_ACC_PR.NEXT_LIQ_DT);
          
            IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE = 'N' THEN
              DBG('Its a full redemption');
              P_ERR_CODE := 'TD-DDEP-34';
            ELSE
              DBG('Its a Partial redemption');
            
              P_ERR_CODE := 'TD-DDEP-30';
            END IF;
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          
          END IF;
        END IF;
      END IF;
    END IF;
  
    BEGIN
      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      
        SELECT CONT_VAR_ROLL
          INTO L_CONT_VAR_ROLL
          FROM ICTMS_ACC_PR
         WHERE ACC = P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
           AND BRN = P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        DBG('This is account level continue variance>>: ' ||
            L_CONT_VAR_ROLL);
        IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONT_VAR_ROLL <>
           L_CONT_VAR_ROLL THEN
          DBG('you are going to modify the continue variance on rollover');
          P_ERR_CODE   := 'ST-VALS-081';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END IF;
        DBG('This is modified continue variance>>: ' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONT_VAR_ROLL);
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failing..! Not picking any data');
    END;
  
    P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF;
  
    L_REDM_INT_PAYOUT := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_INT_PAYOUT;
    DBG('l_redm_int_payout--->' || L_REDM_INT_PAYOUT);
  
    DBG('cspks_req_global.p_New' || CSPKS_REQ_GLOBAL.P_NEW);
    DBG('p_icdredmn.v_tdredmpayout_details.COUNT' ||
        P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT);
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, 'COMPUTE') THEN
      IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT > 0 THEN
        FOR I IN 1 .. P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.LAST LOOP
          IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
           .REDM_PAYOUT_COMP = 'I' AND L_REDM_INT_PAYOUT = 'I' THEN
            DBG('Interest Payout Component should not be selected as redemption interest payout type is of Interest booking account');
            P_ERR_CODE   := 'TD-RED-51';
            P_ERR_PARAMS := '~;';
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        
          IF L_REDM_INT_PAYOUT = 'R' THEN
            IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).REDM_PAYOUT_COMP = 'I' THEN
              DBG('coming here');
              IF P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
               .PERCENTAGE <> 100 OR P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                 .PERCENTAGE IS NULL THEN
                DBG('Interest percentange should be given as 100 only');
                P_ERR_CODE   := 'TD-RED-55';
                P_ERR_PARAMS := '~;';
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
              L_VAR := L_VAR + 1;
            END IF;
          END IF;
        
          IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
           .REDM_PAYOUT_COMP = 'I' AND L_REDM_INT_PAYOUT = 'R' AND P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
             .PAYOUTTYPE IN ('P', 'Y', 'B', 'C', 'L') THEN
            DBG('Interest payout account should be only CASA account');
            P_ERR_CODE   := 'TD-RED-53';
            P_ERR_PARAMS := '~;';
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        
          IF L_REDM_INT_PAYOUT = 'P' AND P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
            .REDM_PAYOUT_COMP = 'I' THEN
            DBG('Interest Payout Component should not be provided for Full Redemption Payout ');
            P_ERR_CODE   := 'IC-REDMN-23';
            P_ERR_PARAMS := '~;';
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        
        END LOOP;
      END IF;
      IF NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG,
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG) = 'R' THEN
        IF L_REDM_INT_PAYOUT = 'R' AND L_VAR < 1 AND
           P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT > 0 THEN
        
          DBG('Interest Payout Component should be provided as redemption interest payout type is of Redemption Interest payout account');
          P_ERR_CODE := 'IC-REDMN-24';
        
          P_ERR_PARAMS := '~;';
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      
        IF L_REDM_INT_PAYOUT = 'R' THEN
          FOR I IN 1 .. P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT LOOP
            IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).REDM_PAYOUT_COMP = 'I' THEN
              L_CNT := L_CNT + 1;
            END IF;
          END LOOP;
        END IF;
        DBG('l_cnt is ' || L_CNT);
        IF (L_CNT) > 1 THEN
          DBG('Interest percentage cannot be splitted');
          P_ERR_CODE   := 'TD-RED-54';
          P_ERR_PARAMS := '~;';
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    DBG('p_icdredmn.v_tdredmpayout_details.COUNT for Child TD >' ||
        P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT > 0 THEN
        DBG('p_icdredmn.ty_iccrefpo.v_ictbs_redem_by_td.account_class >' ||
            P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.ACCOUNT_CLASS);
        FOR I IN 1 .. P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.LAST LOOP
          IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
           .PAYOUTTYPE = 'Y' AND
              P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.ACCOUNT_CLASS IS NULL THEN
            DBG('TD Payout Details not provided');
            PR_LOG_ERROR('ICDREDMN', 'FLEXCUBE', 'TD-RED-28', '');
            RETURN FALSE;
          END IF;
        END LOOP;
      END IF;
    END IF;
  
    BEGIN
      IF SMPKSS.FN_CHECK_AUTO_AUTH(GLOBAL.USER_ID,
                                   P_FUNCTION_ID,
                                   GLOBAL.CURRENT_BRANCH) THEN
        L_AUTO_AUTH := 'Y';
      ELSE
        L_AUTO_AUTH := 'N';
      END IF;
    END;
  
    IF P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_QUERY, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM ICTBS_TDREDEMPTION_MASTER A, STTMS_CUSTOMER B
         WHERE A.REDEM_REF_NO =
               P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO
           AND A.BRANCH_CODE =
               P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE
           AND A.CUST_ID = B.CUSTOMER_NO
           AND ((B.GROUP_CODE IS NOT NULL AND EXISTS
                (SELECT 1
                    FROM STVWS_USER_GROUP C
                   WHERE C.USER_ID = GLOBAL.USER_ID
                     AND C.GROUP_CODE = B.GROUP_CODE)) OR
               B.GROUP_CODE IS NULL)
              
           AND ((B.ACCESS_GROUP IS NOT NULL AND EXISTS
                (SELECT 1
                    FROM STVWS_USER_ACCESS C
                   WHERE C.USER_ID = GLOBAL.USER_ID
                     AND C.ACCESS_GROUP = B.ACCESS_GROUP)) OR
               B.ACCESS_GROUP IS NULL);
      
        IF L_COUNT = 0 THEN
          DBG('User restricted to view this account' ||
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO);
          P_ERR_CODE   := 'ST-GRP01';
          P_ERR_PARAMS := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
       P_FUNCTION_ID = 'ICDREDRN' AND P_SOURCE <> 'FLEXCUBE' AND
       P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84 = 'Y' THEN
      DBG('Into renewal simulation');
      RETURN TRUE;
    END IF;
  
    IF (P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       P_SOURCE <> 'FLEXCUBE' AND
       P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'T') THEN
      DBG('Values Not Related to Tenor Modification Will be Cleared');
      BEGIN
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_BY              := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE            := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_AMT             := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.WAVE_PENALTY               := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_CD                    := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_TXN_CCY               := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_EXCH_RATE             := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_TXN_AMT               := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHQ_DATE                   := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHARGES                    := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BENEF_NAME                 := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PASSPORT_NO                := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR1                      := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR2                      := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_NARRATIVE             := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_BRN_CODE           := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_ACC_NO             := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_CCY            := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_EXCH_RATE          := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_AMT            := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_NARRATIVE          := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_NO                      := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_TXN_CCY                 := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_EXCH_RATE               := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_TXN_AMT                 := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_NARRATIVE               := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SCODE                      := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.XREF                       := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.FCCREF                     := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PAYBRN                     := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MICR_NO                    := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR3                      := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TRN_DT                     := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_CTRY_CODE             := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.WAIVE_INTEREST             := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_BRANCH                  := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ALLOW_PREPAYMENT           := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SUPPRESS_REDEMPTION_ADVICE := '';
        P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD1                          := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONT_VAR_ROLL              := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.INTRATE_CUMAMT_REQD        := '';
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE               := '';
      
        P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK := P_PREV_ICDREDMN.V_STTMS_DENOM_REDMN_BLK;
        P_WRK_ICDREDMN.TY_ICCREFPO             := P_PREV_ICDREDMN.TY_ICCREFPO;
      
        IF P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT > 0 THEN
          P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS := L_TY_ICDREDMN.V_TDREDMPAYOUT_DETAILS;
          NULL;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('format_error_backtrace-->' ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DBG('Failed in Clearing Values');
      END;
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
       P_FUNCTION_ID = 'ICDRDSIM' AND
       P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84 = 'Y' THEN
      DBG('Into redemption simulation');
      ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77 := 'SIMULATION';
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) OR
       (P_SOURCE <> 'FLEXCUBE' AND
       NVL(P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84, 'N') = 'Y' AND
       P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY)) THEN
      DBG('p_icdredmn.v_cstb_ui_columns.CHAR_FIELD84' ||
          P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84);
      L_ACTION_CODE := 'TDRedemSave';
      L_SOURCE      := P_SOURCE;
      IF NOT FN_DEF_TY_TDVWS_TD_REDEMPTION(L_TY_TDVWS_TD_REDEMPTION,
                                           TY_TB_V_TDREDMPAYOUT_DETAILS,
                                           L_TY_BCPAYOUTDETS,
                                           L_TY_PCPAYOUTDETS,
                                           L_TY_STDCUSAC,
                                           P_ICDREDMN) THEN
        DBG('Failed in fn_def_ty_iavws_td_redmption');
        P_ERR_CODE   := 'TD-RED-11';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    
      DBG('l_ty_bcpayoutdets.bankcode::' || L_TY_BCPAYOUTDETS.BANKCODE);
    
      FOR I IN 1 .. TY_TB_V_TDREDMPAYOUT_DETAILS.COUNT LOOP
        DBG('ty_tb_v_tdredmpayout_details.INSTNO::' || TY_TB_V_TDREDMPAYOUT_DETAILS(I)
            .INSTNO);
      
      END LOOP;
    
      IF NOT ICPKS_FCJ_ICDREDMN.FN_MAIN(L_SOURCE,
                                        'IC',
                                        L_ACTION_CODE,
                                        L_MULTI_TRIP_ID,
                                        L_TY_TDVWS_TD_REDEMPTION,
                                        TY_TB_V_TDREDMPAYOUT_DETAILS,
                                        L_TY_BCPAYOUTDETS,
                                        L_TY_PCPAYOUTDETS,
                                        L_TY_STDCUSAC,
                                        L_TY_SUBSYS,
                                        L_TBL_CHGDETS,
                                        L_TY_MISDETAILS,
                                        L_TBL_UDFDETAILS,
                                        L_OVERRIDE_FLAG,
                                        L_ERR_TBL) THEN
        DBG('error in icpks_fcj_icdredmn.fn_main');
        OVPKSS.PR_READTBL(P_ERR_CODE, P_ERR_PARAMS);
        DBG('error in icpks_fcj_icdredmn.fn_main ' || P_ERR_CODE || '~' ||
            P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    
      L_TY_TDVWS_TD_REDEMPTION.MAKERID    := GLOBAL.USER_ID;
      L_TY_TDVWS_TD_REDEMPTION.MAKERSTAMP := FN_MNTSTAMP;
      L_TY_TDVWS_TD_REDEMPTION.AUTHSTAT   := 'U';
      L_TY_TDVWS_TD_REDEMPTION.CONTSTAT   := 'A';
    
      IF NOT FN_DEF_WRK_ICDREDMN(P_WRK_ICDREDMN,
                                 L_TY_TDVWS_TD_REDEMPTION,
                                 TY_TB_V_TDREDMPAYOUT_DETAILS,
                                 L_TY_BCPAYOUTDETS,
                                 L_TY_PCPAYOUTDETS,
                                 L_TY_STDCUSAC) THEN
        DBG('Failed in second conversion');
        RETURN FALSE;
      END IF;
    
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'E' AND
         P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT > 0 THEN
        P_ERR_CODE   := 'TD-RED-101';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    
    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) AND
          P_FUNCTION_ID = 'ICDREDAU' THEN
    
      L_USER_ID     := GLOBAL.USER_ID;
      L_ACTION_CODE := 'TDRedemAuth';
      L_SOURCE      := P_SOURCE;
      IF NOT FN_DEF_TY_TDVWS_TD_REDEMPTION(L_TY_TDVWS_TD_REDEMPTION,
                                           TY_TB_V_TDREDMPAYOUT_DETAILS,
                                           L_TY_BCPAYOUTDETS,
                                           L_TY_PCPAYOUTDETS,
                                           L_TY_STDCUSAC,
                                           P_ICDREDMN) THEN
        DBG('Failed in fn_def_ty_iavws_td_redmption');
        P_ERR_CODE   := 'TD-RED-11';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    
      IF NVL(P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84, 'N') = 'N' THEN
      
        IF NOT ICPKS_FCJ_ICDREDMN.FN_QUERY_REDEMPTION_TBLS(L_TY_TDVWS_TD_REDEMPTION,
                                                           TY_TB_V_TDREDMPAYOUT_DETAILS,
                                                           L_TY_BCPAYOUTDETS,
                                                           L_TY_PCPAYOUTDETS,
                                                           L_TY_STDCUSAC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
          DBG('Failed in icpks_fcj_icdredmn.fn_query_redemption_tbls...' ||
              P_ERR_CODE || '~' || P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
    
      IF L_TY_TDVWS_TD_REDEMPTION.MAKERID = GLOBAL.USER_ID AND
         P_SOURCE IN ('FLEXCUBE') THEN
        DBG('User is Same - Maker and Checker cannot be same...');
        OVPKSS.PR_APPENDTBL('LD-AU013', NULL);
        RETURN FALSE;
      END IF;
    
      IF NOT ICPKS_FCJ_ICDREDMN.FN_MAIN(L_SOURCE,
                                        'IC',
                                        L_ACTION_CODE,
                                        L_MULTI_TRIP_ID,
                                        L_TY_TDVWS_TD_REDEMPTION,
                                        TY_TB_V_TDREDMPAYOUT_DETAILS,
                                        L_TY_BCPAYOUTDETS,
                                        L_TY_PCPAYOUTDETS,
                                        L_TY_STDCUSAC,
                                        L_TY_SUBSYS,
                                        L_TBL_CHGDETS,
                                        L_TY_MISDETAILS,
                                        L_TBL_UDFDETAILS,
                                        L_OVERRIDE_FLAG,
                                        L_ERR_TBL) THEN
        DBG('error in icpks_fcj_icdredmn.fn_main');
        OVPKSS.PR_READTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      BEGIN
      
        L_TY_TDVWS_TD_REDEMPTION.CHECKERID := L_USER_ID;
      
        L_TY_TDVWS_TD_REDEMPTION.CHECKERSTAMP := FN_MNTSTAMP;
        L_TY_TDVWS_TD_REDEMPTION.AUTHSTAT     := 'A';
        L_TY_TDVWS_TD_REDEMPTION.CONTSTAT     := 'A';
      
        UPDATE ICTB_TDREDEMPTION_MASTER TDREM
           SET TDREM.AUTH_STATUS      = L_TY_TDVWS_TD_REDEMPTION.AUTHSTAT,
               TDREM.CHECKER_ID       = L_TY_TDVWS_TD_REDEMPTION.CHECKERID,
               TDREM.CHECKER_DT_STAMP = L_TY_TDVWS_TD_REDEMPTION.CHECKERSTAMP,
               TDREM.CONTRACT_STATUS  = L_TY_TDVWS_TD_REDEMPTION.CONTSTAT
        
         WHERE TDREM.REDEM_REF_NO = L_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
      END;
      IF NOT FN_DEF_WRK_ICDREDMN(P_WRK_ICDREDMN,
                                 L_TY_TDVWS_TD_REDEMPTION,
                                 TY_TB_V_TDREDMPAYOUT_DETAILS,
                                 L_TY_BCPAYOUTDETS,
                                 L_TY_PCPAYOUTDETS,
                                 L_TY_STDCUSAC) THEN
        DBG('Failed in second conversion');
        RETURN FALSE;
      END IF;
    
    ELSIF P_ACTION_CODE = 'COMPUTE' OR
          (P_SOURCE <> 'FLEXCUBE' AND
          NVL(P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84, 'N') = 'Y' AND
          P_ACTION_CODE = 'NEW') THEN
      DBG('p_icdredmn.v_cstb_ui_columns.CHAR_FIELD84' ||
          P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84);
      L_ACTION_CODE                                                   := 'TDRedemCompute';
      L_SOURCE                                                        := P_SOURCE;
      L_TY_TDVWS_TD_REDEMPTION.BRN_CODE                               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      L_TY_TDVWS_TD_REDEMPTION.ACTION_FLAG                            := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG;
      ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77 := 'SIMULATION';
      IF NOT FN_DEF_TY_TDVWS_TD_REDEMPTION(L_TY_TDVWS_TD_REDEMPTION,
                                           TY_TB_V_TDREDMPAYOUT_DETAILS,
                                           L_TY_BCPAYOUTDETS,
                                           L_TY_PCPAYOUTDETS,
                                           L_TY_STDCUSAC,
                                           P_ICDREDMN) THEN
        DBG('Failed in fn_def_ty_iavws_td_redmption');
        P_ERR_CODE   := 'TD-RED-11';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      IF NOT ICPKS_FCJ_ICDREDMN.FN_MAIN(L_SOURCE,
                                        'IC',
                                        L_ACTION_CODE,
                                        L_MULTI_TRIP_ID,
                                        L_TY_TDVWS_TD_REDEMPTION,
                                        TY_TB_V_TDREDMPAYOUT_DETAILS,
                                        L_TY_BCPAYOUTDETS,
                                        L_TY_PCPAYOUTDETS,
                                        L_TY_STDCUSAC,
                                        L_TY_SUBSYS,
                                        L_TBL_CHGDETS,
                                        L_TY_MISDETAILS,
                                        L_TBL_UDFDETAILS,
                                        L_OVERRIDE_FLAG,
                                        L_ERR_TBL) THEN
        DBG('error in icpks_fcj_icdredmn.fn_main');
        OVPKSS.PR_READTBL(P_ERR_CODE, P_ERR_PARAMS);
        DBG('error in icpks_fcj_icdredmn.fn_main' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
      IF NOT FN_DEF_WRK_ICDREDMN(P_WRK_ICDREDMN,
                                 L_TY_TDVWS_TD_REDEMPTION,
                                 TY_TB_V_TDREDMPAYOUT_DETAILS,
                                 L_TY_BCPAYOUTDETS,
                                 L_TY_PCPAYOUTDETS,
                                 L_TY_STDCUSAC) THEN
        DBG('Failed in second conversion');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'E' AND
         P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT > 0 THEN
        DBG('Calling fn_addpayin_validate..');
        IF NOT FN_ADDPAYIN_VALIDATE(P_FUNCTION_ID,
                                    P_ACTION_CODE,
                                    P_WRK_ICDREDMN,
                                    L_ERR_FLAG) THEN
          DBG('Failed in fn_addpayin_validate..');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    DBG('p_Action_Code::-->' || P_ACTION_CODE);
    IF P_ACTION_CODE IN ('DENOMPOP') THEN
      DBG('Redem_ref_no--->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO);
      IF CR_DENOMDEPOSIT%ISOPEN THEN
        DBG('Cursor is open--->' ||
            P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO);
        CLOSE CR_DENOMDEPOSIT;
      END IF;
      OPEN CR_DENOMDEPOSIT(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO);
      FETCH CR_DENOMDEPOSIT BULK COLLECT
        INTO P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK;
      CLOSE CR_DENOMDEPOSIT;
    
      DBG('Inserted records :' ||
          P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      IF P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS.LAST LOOP
          IF (P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE IS NOT NULL) AND
             (P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).PAYOUTTYPE = 'D' OR P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
             .PAYOUTTYPE = 'B' OR P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
             .PAYOUTTYPE = 'P') THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-VALS-000', '');
          
          END IF;
        END LOOP;
      END IF;
      IF (P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE IS NOT NULL) THEN
        DBG('the rt product is..' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-RED-000', '');
      END IF;
    END IF;
  
    BEGIN
      SELECT COUNT(*)
        INTO L_CERT_COUNT
        FROM STTMS_CUST_ACCOUNT A, STTMS_ACCOUNT_CLASS B
       WHERE A.ACCOUNT_CLASS = B.ACCOUNT_CLASS
         AND B.DENM_DEPOSIT = 'Y'
         AND A.CUST_AC_NO =
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
         AND A.BRANCH_CODE =
             P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      DBG('l_cert_count-->' || NVL(L_CERT_COUNT, 0));
      DBG('Count wrk variable' ||
          P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
      DBG('Count Variable' || P_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
      IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
        IF NVL(L_CERT_COUNT, 0) > 0 AND
           P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT = 0 THEN
          DBG('l_cert_count-->' || L_CERT_COUNT);
          P_ERR_CODE   := 'TD-RED-30';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in count of Denomination deposit');
    END;
  
    IF P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT > 0 THEN
    
      SELECT NVL(TD_AMOUNT, 0) - NVL(REDEM_AMT, 0)
        INTO L_TD_BAL
        FROM ICTMS_TD_DETAILS
       WHERE BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE
         AND ACC = P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO;
      DBG('l_td_bal-->' || L_TD_BAL);
    
      DBG('Getting count:-->' ||
          P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
    
      FOR I IN P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.FIRST .. P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.LAST LOOP
        DBG('block_or_redem' || P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
            .BLOCK_OR_REDEM);
        IF P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I).BLOCK_OR_REDEM = 'R' THEN
          L_REDEEM_AMT   := NVL(L_REDEEM_AMT, 0) + P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                           .CERTIFICATE_AMOUNT;
          L_REDEM_CERTIF := NVL(L_REDEM_CERTIF, 0) + 1;
        END IF;
      END LOOP;
    
      DBG('Going to populate' || P_ACTION_CODE);
      IF P_ACTION_CODE IN ('POPULATED', 'NEW', 'EXECUTEQUERY') THEN
        DBG('Going for action');
        BEGIN
          SELECT SUM(DENOMINATION_VALUE)
            INTO L_SUM_REDEMTION
            FROM STTM_DENOM_DEP_CERTIF
           WHERE CUST_AC_NO =
                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRANCH_CODE = GLOBAL.APPLICATION_DATE
             AND NEW_STATUS = 'R';
        EXCEPTION
          WHEN OTHERS THEN
            L_SUM_REDEMTION := 0;
        END;
        BEGIN
          SELECT COUNT(CERTIFICATE_NO)
            INTO L_SUM_CERTIFICATE
            FROM STTM_DENOM_DEP_CERTIF
           WHERE CUST_AC_NO =
                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRANCH_CODE = GLOBAL.APPLICATION_DATE
             AND NEW_STATUS = 'R';
        EXCEPTION
          WHEN OTHERS THEN
            L_SUM_CERTIFICATE := 0;
        END;
        P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD80 := NVL(L_SUM_REDEMTION,
                                                             0) +
                                                         NVL(L_REDEEM_AMT,
                                                             0);
        P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD81 := NVL(L_SUM_CERTIFICATE,
                                                             0) +
                                                         NVL(L_REDEM_CERTIF,
                                                             0);
        DBG('Total Redemption Amount' ||
            P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD80);
        DBG('Total Redemption Certificate' ||
            P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD81);
      END IF;
      DBG('After populate' || P_ACTION_CODE);
      DBG('After delete' || P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
    END IF;
  
    DBG('l_redeem_amt' || L_REDEEM_AMT);
    DBG('redemption_amt' ||
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_AMT);
  
    IF L_CERT_COUNT > 0 AND
       NVL(P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84, 'N') = 'N' THEN
    
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE = 'N' THEN
        IF NVL(L_REDEEM_AMT, 0) != NVL(L_TD_BAL, 0) AND
           P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
          P_ERR_CODE   := 'TD-RED-25';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      ELSE
        IF NVL(L_REDEEM_AMT, 0) !=
           NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_AMT, 0) AND
           P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
          P_ERR_CODE   := 'TD-RED-25';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN
       (STPKS_FCMAINT_SERVICE.P_MODIFY, STPKS_FCMAINT_SERVICE.P_NEW) THEN
      DBG('acn and branch ' ||
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO || ' ' ||
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
      BEGIN
        SELECT CUST_NO, AC_OPEN_DATE
          INTO L_CUSTOMER, L_AC_OPEN_DATE
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
           AND BRANCH_CODE =
               P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        SELECT COUNT(1)
          INTO L_MFI_COUNT
          FROM STTMS_CUSTOMER SC
         WHERE SC.MFI_CUSTOMER = 'Y'
           AND SC.CUSTOMER_NO = L_CUSTOMER;
        DBG('customer id $ ' || L_CUSTOMER || ' count $ ' || L_MFI_COUNT);
        IF L_MFI_COUNT > 0 THEN
          IF NOT STPKS_STDCIF_KERNEL.FN_MFI_CHK_ACCESS(GLOBAL.USER_ID,
                                                       L_CUSTOMER,
                                                       NULL,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN
            DBG('returned false from  fn_MFi_chk_access');
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('**', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          DBG('Exception  with -->: ' || SQLCODE || ':' || SQLERRM);
      END;
    END IF;
  
    DBG('Inside tenor validation');
    DBG('Action Flag-->' ||
        P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG);
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH,
                         CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY) AND
       (P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF = 'I') AND
       (P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'E' OR
       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'T') THEN
      BEGIN
      
        IF P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD IS NULL AND
           P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM IS NULL AND
           P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY IS NULL THEN
          DBG('Rollover tenor should not be blank if independent tenor is selected');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-144', '');
        END IF;
      
        SELECT NVL(MIN_TENOR_DAYS, 0),
               NVL(MAX_TENOR_DAYS, 0),
               NVL(MIN_TENOR_MONTHS, 0),
               NVL(MAX_TENOR_MONTHS, 0),
               NVL(MIN_TENOR_YEARS, 0),
               NVL(MAX_TENOR_YEARS, 0)
          INTO L_MIN_TDAYS,
               L_MAX_TDAYS,
               L_MIN_TMONTHS,
               L_MAX_TMONTHS,
               L_MIN_TYEARS,
               L_MAX_TYEARS
        
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS IN
               (SELECT ACCOUNT_CLASS
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO =
                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
                   AND BRANCH_CODE =
                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
      
        SELECT INT_START_DATE, MATURITY_DATE
          INTO L_OLD_INT_START_DATE, L_INT_START_DATE
          FROM ICTMS_ACC
         WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
           AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        DBG('Interest Start date' || L_INT_START_DATE);
        DBG('Minimum Days' || L_MIN_TDAYS);
        DBG('Minimum months' || L_MIN_TMONTHS);
        DBG('Minimum years' || L_MIN_TYEARS);
      
        L_MIN_DAYS := ADD_MONTHS(L_OLD_INT_START_DATE + L_MIN_TDAYS,
                                 L_MIN_TMONTHS + L_MIN_TYEARS * 12) -
                      L_OLD_INT_START_DATE;
      
        L_MAX_DAYS := ADD_MONTHS(L_OLD_INT_START_DATE + L_MAX_TDAYS,
                                 L_MAX_TMONTHS + L_MAX_TYEARS * 12) -
                      L_OLD_INT_START_DATE;
      
        DBG('Minimum tenor ' || L_MIN_DAYS);
        DBG('Maximum tenor' || L_MAX_DAYS);
      
        L_PRM_MIN_MAT_DATE := L_INT_START_DATE + L_MIN_DAYS;
        L_PRM_MAX_MAT_DATE := L_INT_START_DATE + L_MAX_DAYS;
      
        DBG('Minimum maturity date' || L_PRM_MIN_MAT_DATE);
        DBG('Maximum maturity date' || L_PRM_MAX_MAT_DATE);
      
        DBG('pkg_cascade_nxtmatdt' || PKG_CASCADE_NXTMATDT);
      
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                               NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM,
                                                                                   0) +
                                                                               NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY,
                                                                                   0) * 12) +
                                                                    NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD,
                                                                        0);
      
        IF PKG_CASCADE_NXTMATDT = 'N' THEN
        
          IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE <
             L_PRM_MIN_MAT_DATE THEN
            DBG('Maturity date is less than minimum maturity date');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-106', '');
          
          ELSIF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE >
                L_PRM_MAX_MAT_DATE THEN
            DBG('Maturity date is greater than maximum maturity date');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-107', '');
          
          END IF;
        
        ELSE
        
          IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE <
             L_PRM_MIN_MAT_DATE THEN
            DBG('Maturity date is less than minimum maturity date OVERRIDE');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-115', '');
          
          ELSIF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE >
                L_PRM_MAX_MAT_DATE THEN
            DBG('Maturity date is greater than maximum maturity dateOVERRIDE');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-116', '');
          
          END IF;
        END IF;
        PKG_CASCADE_NXTMATDT := 'N';
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No record exits');
      END;
    
    END IF;
  
    P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
  
    DBG(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY || '~' ||
        P_PREV_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY);
    DBG(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD || '~' ||
        P_PREV_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD);
    DBG(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM || '~' ||
        P_PREV_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       ((NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY, '00') <>
       NVL(P_PREV_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY, '00')) OR
       (NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, '00') <>
       NVL(P_PREV_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, '00')) OR
       (NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM, '00') <>
       NVL(P_PREV_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM, '00'))) THEN
      BEGIN
        SELECT ACCOUNT_CLASS, MONTH_END_DEPOSIT, HOLIDAY_CALENDAR
          INTO L_ACCOUNT_CLASS, L_MONTH_END_DEP, L_HOL_PREF
          FROM STTM_ACCOUNT_CLASS
         WHERE HOLIDAY_CALENDAR NOT IN 'N'
           AND ACCOUNT_CLASS IN
               (SELECT ACCOUNT_CLASS
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO =
                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
                   AND BRANCH_CODE =
                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
      
        IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG <> 'T' THEN
          SELECT MATURITY_DATE, ORIG_TENOR_DAYS, CASCADE_MONTH
            INTO L_INT_START_DATE, L_ORIG_DAYS, L_CASCADE_MONTH
            FROM ICTMS_ACC
           WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        ELSE
          SELECT INT_START_DATE, CASCADE_MONTH
            INTO L_INT_START_DATE, L_CASCADE_MONTH
            FROM ICTMS_ACC
           WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                                 NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM,
                                                                                     0) +
                                                                                 NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY,
                                                                                     0) * 12) +
                                                                      NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD,
                                                                          0);
        
          IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
             NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) = 0 THEN
          
            L_NEXT_MATURITY_DATE_BK := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
            DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
              P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MATURITY_DATE_BK;
            END IF;
          
            IF L_NEXT_MATURITY_DATE_BK <>
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
              DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
              PKG_CASCADE_NXTMATDT := 'Y';
            END IF;
          
          END IF;
          DBG('p_wrk_icdredmn.v_ictbs_tdredemption_master.next_mat_date1--->' ||
              P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
        
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_MONTHS := NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM,
                                                                       0);
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_YEARS  := NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY,
                                                                       0);
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_DAYS   := NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD,
                                                                       0);
        END IF;
      
        DBG('Maturity Date before holiday check :-  ' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
        IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE IS NOT NULL THEN
          L_RES := NULL;
          DBG('Holiday Treatment starts');
          DBG('l_month_end_dep : ' || L_MONTH_END_DEP);
          DBG('Interest start date : ' || L_INT_START_DATE);
        
          IF L_MONTH_END_DEP = 'Y' AND
             NVL(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) = 0 THEN
          
            DBG('Checking last working day of the account open date');
            IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT(L_HOL_PREF,
                                                      P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                                      P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY,
                                                      LAST_DAY(L_INT_START_DATE),
                                                      L_WRK_DAY,
                                                      L_ERROR) THEN
            
              DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
            END IF;
          
            IF L_WRK_DAY = L_INT_START_DATE OR
               L_INT_START_DATE = LAST_DAY(L_INT_START_DATE) THEN
              L_MONTH_END_FLG := TRUE;
            END IF;
          END IF;
          IF L_MONTH_END_FLG THEN
            DBG('Checking for month end deposit');
            IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT(L_HOL_PREF,
                                                      P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                                      P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY,
                                                      LAST_DAY(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE),
                                                      L_RES,
                                                      L_ERROR) THEN
            
              DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
            END IF;
            L_RES := NVL(L_RES,
                         LAST_DAY(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE));
          
            IF P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE <>
               LAST_DAY(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'IC-MSC022',
                           P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE || '~' ||
                           LAST_DAY(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) || '~');
            END IF;
          
            IF L_RES <>
               LAST_DAY(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
              IF L_RES <
                 LAST_DAY(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'IC-MSC009',
                             LAST_DAY(P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) || '~' ||
                             L_RES || '~');
              END IF;
            
            END IF;
          ELSE
          
            IF NOT ICPKS_HOLIDAY.FN_GET_MATURITY_DATE(L_ACCOUNT_CLASS,
                                                      P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                                      P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY,
                                                      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE,
                                                      L_RES,
                                                      P_FUNCTION_ID) THEN
              DBG('icpks_holiday.Fn_Get_maturity_date but continuing...');
            END IF;
            L_RES := NVL(L_RES,
                         P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
            DBG('After holiday treatment : Old maturity date ' ||
                P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE ||
                '  New maturity date ' || L_RES);
          
            IF L_RES <>
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
              IF L_RES >
                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'IC-MSC002',
                             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE || '~' ||
                             L_RES || '~');
              ELSE
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'IC-MSC009',
                             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE || '~' ||
                             L_RES || '~');
              END IF;
            END IF;
          
            IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'T' THEN
            
              DBG('p_wrk_icdredmn.v_ictbs_tdredemption_master.TENOR_YY-->' ||
                  P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY);
              DBG('p_wrk_icdredmn.v_ictbs_tdredemption_master.TENOR_MM-->' ||
                  P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM);
              DBG('p_wrk_icdredmn.v_ictbs_tdredemption_master.TENOR_DD-->' ||
                  P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD);
              IF NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) > 30 AND
                 NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY, 0) +
                 NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM, 0) > 0 THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC015', NULL);
              END IF;
              IF NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM, 0) > 11 THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC004', NULL);
              END IF;
              IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM < 0 THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC013', NULL);
              END IF;
              IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY < 0 THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC014', NULL);
              END IF;
              IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD < 0 THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC012', NULL);
              END IF;
            
            END IF;
          
          END IF;
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_RES;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Holiday treatment query returned no data found');
        
          DBG('p_icdredmn.v_ictbs_tdredemption_master.acc_no' ||
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO);
          DBG('p_icdredmn.v_ictbs_tdredemption_master.branch_code' ||
              P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
          IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG <> 'T' THEN
            SELECT MATURITY_DATE, ORIG_TENOR_DAYS, CASCADE_MONTH
              INTO L_INT_START_DATE, L_ORIG_DAYS, L_CASCADE_MONTH
              FROM ICTMS_ACC
             WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
               AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
          ELSE
            SELECT INT_START_DATE, CASCADE_MONTH
              INTO L_INT_START_DATE, L_CASCADE_MONTH
              FROM ICTMS_ACC
             WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
               AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
          END IF;
          DBG('l_int_start_date' || L_INT_START_DATE);
          DBG('l_orig_days' || L_ORIG_DAYS);
          DBG('l_cascade_month' || L_CASCADE_MONTH);
        
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                                 NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM,
                                                                                     0) +
                                                                                 NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY,
                                                                                     0) * 12) +
                                                                      NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD,
                                                                          0);
        
          IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
             NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) = 0 THEN
          
            L_NEXT_MATURITY_DATE_BK := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
            DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
              P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MATURITY_DATE_BK;
            END IF;
          
            IF L_NEXT_MATURITY_DATE_BK <>
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
              DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
              PKG_CASCADE_NXTMATDT := 'Y';
            END IF;
          
          END IF;
          DBG('p_wrk_icdredmn.v_ictbs_tdredemption_master.next_mat_date1--->' ||
              P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
        
      END;
    
      DBG('p_wrk_icdredmn.v_ictbs_tdredemption_master.next_mat_date ' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
      IF L_INT_START_DATE >=
         P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE AND
         P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG <> 'T' THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-BOD18', NULL);
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
       P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'E' THEN
      BEGIN
      
        SELECT NVL(RECOMPUTE_MAT_DATE, 'N')
          INTO L_RECOMPUTE_MAT_DATE
          FROM STTM_ACCOUNT_CLASS
         WHERE HOLIDAY_CALENDAR NOT IN 'N'
           AND ACCOUNT_CLASS IN
               (SELECT ACCOUNT_CLASS
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO =
                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
                   AND BRANCH_CODE =
                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_RECOMPUTE_MAT_DATE := 'N';
          DBG('Failed to fetch recompute maturity date flag from account class but continuing');
      END;
    
      IF (P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF = 'L' AND
         L_RECOMPUTE_MAT_DATE = 'N') OR (P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF <> 'L' AND
         L_RECOMPUTE_MAT_DATE = 'Y') THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC011', '');
        DBG('Recompute maturity date on rollover preference will be ignored');
      END IF;
    END IF;
  
    DBG('p_wrk_icdredmn count::-->' ||
        P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
    DBG('p_Action_Code111' || P_ACTION_CODE);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
    
      FOR REC_RED_CERTF IN (SELECT *
                              FROM STTM_DENOM_REDMN_BLK
                             WHERE REFERENCE_NO =
                                   P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO
                               AND BLOCK_OR_REDEM = 'R') LOOP
        DBG('rec_red_certf.certificate_no' || REC_RED_CERTF.CERTIFICATE_NO);
        DELETE FROM STTM_DENM_CERTIF_HIST
         WHERE CERTIFICATE_NO = REC_RED_CERTF.CERTIFICATE_NO
           AND CUST_AC_NO = REC_RED_CERTF.CUST_AC_NO
           AND BRANCH_CODE = REC_RED_CERTF.BRANCH_CODE;
        INSERT INTO STTM_DENM_CERTIF_HIST
          (CUST_AC_NO,
           BRANCH_CODE,
           DENOMINATION_ID,
           CERTIFICATE_NO,
           DENOMINATION_VALUE,
           STATUS,
           ISSUE_DATE,
           STATUS_CHANGE_REASON,
           STATUS_CHANGE_DATE)
          SELECT CUST_AC_NO,
                 BRANCH_CODE,
                 DENOMINATION_ID,
                 CERTIFICATE_NO,
                 DENOMINATION_VALUE,
                 NEW_STATUS,
                 ISSUE_DATE,
                 STATUS_CHANGE_REASON,
                 STATUS_CHANGE_DATE
            FROM STTM_DENOM_DEP_CERTIF
           WHERE CERTIFICATE_NO = REC_RED_CERTF.CERTIFICATE_NO
             AND CUST_AC_NO = REC_RED_CERTF.CUST_AC_NO
             AND BRANCH_CODE = REC_RED_CERTF.BRANCH_CODE;
      
        DBG('INSERTED ROWS :: ' || SQL%ROWCOUNT);
        UPDATE STTM_DENOM_DEP_CERTIF
           SET PREVIOUS_STATUS      = NEW_STATUS,
               NEW_STATUS           = 'R',
               STATUS_CHANGE_DATE   = GLOBAL.APPLICATION_DATE,
               STATUS_CHANGE_REASON = 'Deposit redeemed'
         WHERE CERTIFICATE_NO = REC_RED_CERTF.CERTIFICATE_NO
           AND CUST_AC_NO = REC_RED_CERTF.CUST_AC_NO
           AND BRANCH_CODE = REC_RED_CERTF.BRANCH_CODE;
        DBG('UPDATED ROWS :: ' || SQL%ROWCOUNT);
      END LOOP;
    
    ELSIF (P_SOURCE <> 'FLEXCUBE' AND L_AUTO_AUTH = 'Y' AND
          P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW) OR
          (P_SOURCE = 'FLEXCUBE' AND L_AUTO_AUTH = 'Y' AND
          P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW) THEN
      DBG('p_wrk_icdredmn count::-->' ||
          P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
      DBG('p_Action_Code' || P_ACTION_CODE);
      IF P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT > 0 THEN
        FOR I IN P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.FIRST .. P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.LAST LOOP
          IF P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I).BLOCK_OR_REDEM = 'R' THEN
            DBG('block_or_redem::-->' || P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                .BLOCK_OR_REDEM);
            DELETE FROM STTM_DENM_CERTIF_HIST
             WHERE CERTIFICATE_NO = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                  .CERTIFICATE_NO
               AND CUST_AC_NO = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                  .CUST_AC_NO
               AND BRANCH_CODE = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                  .BRANCH_CODE;
            INSERT INTO STTM_DENM_CERTIF_HIST
              (CUST_AC_NO,
               BRANCH_CODE,
               DENOMINATION_ID,
               CERTIFICATE_NO,
               DENOMINATION_VALUE,
               STATUS,
               ISSUE_DATE,
               STATUS_CHANGE_REASON,
               STATUS_CHANGE_DATE)
              SELECT CUST_AC_NO,
                     BRANCH_CODE,
                     DENOMINATION_ID,
                     CERTIFICATE_NO,
                     DENOMINATION_VALUE,
                     NEW_STATUS,
                     ISSUE_DATE,
                     STATUS_CHANGE_REASON,
                     STATUS_CHANGE_DATE
                FROM STTM_DENOM_DEP_CERTIF
               WHERE CERTIFICATE_NO = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                    .CERTIFICATE_NO
                 AND CUST_AC_NO = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                    .CUST_AC_NO
                 AND BRANCH_CODE = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                    .BRANCH_CODE;
            DBG('INSERTED ROWS :: ' || SQL%ROWCOUNT);
            UPDATE STTM_DENOM_DEP_CERTIF
               SET PREVIOUS_STATUS      = NEW_STATUS,
                   NEW_STATUS           = 'R',
                   STATUS_CHANGE_DATE   = GLOBAL.APPLICATION_DATE,
                   STATUS_CHANGE_REASON = 'Deposit redeemed'
             WHERE CERTIFICATE_NO = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                  .CERTIFICATE_NO
               AND CUST_AC_NO = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                  .CUST_AC_NO
               AND BRANCH_CODE = P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                  .BRANCH_CODE;
            DBG('UPDATED ROWS :: ' || SQL%ROWCOUNT);
          
          END IF;
        END LOOP;
      END IF;
    END IF;
  
    DBG('GET VALUE');
  
    IF P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT > 0 THEN
      FOR I IN P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.FIRST .. P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.LAST LOOP
        P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I).REFERENCE_NO := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO;
      END LOOP;
    END IF;
  
    DBG('Before Goal Account...');
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'T' THEN
      DBG('Tenor Change...');
      BEGIN
        SELECT ALLOW_TENOR_CHANGE
          INTO L_ALLOW_TENOR_CHANGE
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               (SELECT ACCOUNT_CLASS
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO =
                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
                   AND BRANCH_CODE =
                       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in querying in sttm_account_class');
          L_ALLOW_TENOR_CHANGE := 'N';
      END;
      IF NVL(L_ALLOW_TENOR_CHANGE, 'N') = 'N' THEN
        DBG('Tenor Modification Facility Not available for this TD Account');
        OVPKSS.PR_APPENDTBL('ST-GOL-04', NULL);
      END IF;
      IF NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) = 0 AND
         NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM, 0) = 0 AND
         NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY, 0) = 0 THEN
        DBG('Tenor Details Should be entered for Tenor Change Operation');
        OVPKSS.PR_APPENDTBL('ST-GOL-08', NULL);
      END IF;
      DBG('Inside Tenor Change Case');
      BEGIN
        SELECT MATURITY_DATE
          INTO L_MATURITY_DATE
          FROM ICTMS_ACC
         WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
           AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in ictm acc Query');
      END;
      DBG('INDEPENDENT Tenor years-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY);
      DBG('INDEPENDENT Months-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM);
      DBG('INDEPENDENT Days-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD);
      DBG('L_INT_START_DATE-->' || L_INT_START_DATE);
      DBG('L_MATURITY_DATE-->' || L_MATURITY_DATE);
      DBG('p_wrk_icdredmn.v_ictbs_tdredemption_master.next_mat_date-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
      IF (GLOBAL.APPLICATION_DATE >= L_MATURITY_DATE) THEN
        DBG('Account Already Matured');
        OVPKSS.PR_APPENDTBL('ST-GOL-07', '');
      END IF;
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE <
         GLOBAL.APPLICATION_DATE THEN
        DBG('Tenor Modification is not allowed for Elapsed Tenor');
        OVPKSS.PR_APPENDTBL('ST-GOL-05', '');
      END IF;
    END IF;
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'R' AND
       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE = 'N' THEN
      SELECT COUNT(*)
        INTO SI_COUNT
        FROM SITB_INSTRUCTION I, SITB_CONTRACT_MASTER M
       WHERE M.INSTRUCTION_NO = I.INSTRUCTION_NO
         AND I.INST_VERSION_NO =
             (SELECT NVL(MAX(LATEST_VERSION_NO), 0)
                FROM SITBS_INSTRUCTION
               WHERE INSTRUCTION_NO = M.INSTRUCTION_NO)
         AND M.VERSION_NO = I.LATEST_VERSION_NO
         AND I.INST_STATUS <> 'S'
            
         AND M.CR_ACCOUNT = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
         AND BRANCH = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      DBG('The si instruction count after checking from the table :: ' ||
          SI_COUNT);
      IF SI_COUNT > 0 THEN
        OVPKSS.PR_APPENDTBL('ST-GOL-09', '');
      END IF;
    END IF;
  
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM ICTB_TDREDEMPTION_MASTER
       WHERE ACC_NO = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
         AND BRANCH_CODE =
             P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in ICTB_TDREDEMPTION_MASTER Count Query');
        L_COUNT := 0;
    END;
    P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_SEQ_NO := L_COUNT + 1;
  
    DBG('Action code is -->' || P_ACTION_CODE);
    DBG('l_auto_auth is -->' || L_AUTO_AUTH);
    DBG('Redem mode is -->' ||
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE);
    DBG('Redem flag is -->' ||
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG);
    IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH AND
       P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE = 'N' AND
       P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'R') OR
       (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
       NVL(L_AUTO_AUTH, 'N') = 'Y' AND
       P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE = 'N' AND
       P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG = 'R') THEN
      DBG('full redemption, so deleting the fatca obligation');
      BEGIN
        SELECT ACCOUNT_CLASS
          INTO L_ACCOUNT_CLASS
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO =
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
           AND BRANCH_CODE =
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while fetching accountclass:' || SQLERRM);
      END;
      IF NOT STPKSS_FATCA_OBLIG_ENTRY.FN_POPULATE_OBLIG(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE ||
                                                        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO,
                                                        'A',
                                                        'FLEXCUBE',
                                                        'IC',
                                                        L_ACCOUNT_CLASS,
                                                        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CUST_ID,
                                                        NULL,
                                                        GLOBAL.APPLICATION_DATE,
                                                        NULL,
                                                        NULL,
                                                        NULL,
                                                        'D') THEN
        DBG('failed while deleting obligation: ' || SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Add payin count' ||
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT);
    DBG('Next maturity date' ||
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_AUTH) THEN
      IF P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT > 0 THEN
        FOR I IN P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.FIRST .. P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.LAST LOOP
          IF P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
           .MULTIMODE_PAYOPT = 'Q' THEN
            DBG('p_wrk_icdredmn.v_ictms_tdredpayin_details(i).chq_avl_date' || P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
                .CHQ_AVL_DATE);
            IF P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(I)
             .CHQ_AVL_DATE >=
                P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
              DBG('Cheque available date should be less than Maturity Date');
              OVPKSS.PR_APPENDTBL('TD-DDEP-33', '');
            END IF;
          END IF;
        END LOOP;
      END IF;
    END IF;
  
    IF NOT ACPKS_UTILS.FN_VALIDATEANDRETRYFORACC(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO,
                                                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAMS) THEN
      DBG('Failed in acpks_utils.fn_ValidateAndRetryForAcc : ' || SQLERRM || '~' ||
          P_ERR_CODE);
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
      --sampath starts
      IF CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') = 'EXTSYS' AND
       CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDREDMN' AND P_ERR_CODE IN ('AC-VAC07','AC-VAC04') THEN
       
       P_ERR_CODE := NULL;
       
       RETURN TRUE;
       
       END IF;
      --sampath ends
      
      RETURN FALSE;
    END IF;
  
    DBG('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DEFAULT_AND_VALIDATE;

  FUNCTION FN_PRE_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_ICDREDMN         IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Pre_Resolve_Ref_Numbers..');
  
    DBG('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_RESOLVE_REF_NUMBERS;
  FUNCTION FN_POST_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_ICDREDMN         IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Post_Resolve_Ref_Numbers..');
  
    DBG('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of icpks_icdredmn_Main.Fn_Post_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_RESOLVE_REF_NUMBERS;
  FUNCTION FN_PRE_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                  P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Product_Default..');
  
    DBG('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PRODUCT_DEFAULT;

  FUNCTION FN_POST_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                   P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Product_Default..');
  
    DBG('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PRODUCT_DEFAULT;

  FUNCTION FN_PRE_UNLOCK(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN OUT VARCHAR2,
                         P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Unlock..');
  
    DBG('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UNLOCK;

  FUNCTION FN_POST_UNLOCK(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN OUT VARCHAR2,
                          P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Unlock');
  
    DBG('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UNLOCK;

  FUNCTION FN_PRE_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                P_PREV_ICDREDMN    IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Subsys_Pickup..');
  
    DBG('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_SUBSYS_PICKUP;

  FUNCTION FN_POST_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                 P_PREV_ICDREDMN    IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                 P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Subsys_Pickup..');
  
    DBG('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_SUBSYS_PICKUP;

  FUNCTION FN_PRE_ENRICH(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                         P_PREV_ICDREDMN    IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                         P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Enrich..');
  
    DBG('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_ENRICH;

  FUNCTION FN_POST_ENRICH(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                          P_PREV_ICDREDMN    IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                          P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Enrich..');
  
    DBG('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_ENRICH;

  FUNCTION FN_PRE_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_CHILD_FUNCTION   IN VARCHAR2,
                            P_MULTI_TRIP_ID    IN VARCHAR2,
                            P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                            P_PREV_ICDREDMN    IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                            P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_YEARS              NUMBER;
    L_MONTHS             NUMBER;
    L_DAYS               NUMBER;
    L_INT_START_DATE     ICTMS_ACC.INT_START_DATE%TYPE;
    L_CALC_DATE          DATE;
    L_RECOMPUTE_MAT_DATE STTM_ACCOUNT_CLASS.RECOMPUTE_MAT_DATE%TYPE;
  
    L_CASCADE_MONTH  STTM_ACCOUNT_CLASS.CASCADE_MONTH%TYPE;
    L_NEXT_MAT_DT_BK DATE;
  BEGIN
  
    DBG('In Fn_Pre_Upload_Db..');
  
    BEGIN
    
      SELECT NVL(RECOMPUTE_MAT_DATE, 'N'),
             NVL(DEFAULT_TENOR_YEARS, 0),
             NVL(DEFAULT_TENOR_MONTHS, 0),
             NVL(DEFAULT_TENOR_DAYS, 0),
             CASCADE_MONTH
        INTO L_RECOMPUTE_MAT_DATE,
             L_YEARS,
             L_MONTHS,
             L_DAYS,
             L_CASCADE_MONTH
        FROM STTM_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS IN
             (SELECT ACCOUNT_CLASS
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO =
                     P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
                 AND BRANCH_CODE =
                     P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE);
    
      SELECT MATURITY_DATE
        INTO L_INT_START_DATE
        FROM ICTMS_ACC
       WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
         AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed in defaulting tenor');
    END;
  
    DBG('Fl_recompute_mat_date-->' || L_RECOMPUTE_MAT_DATE);
    DBG('l_years-->' || L_YEARS);
    DBG('l_months' || L_MONTHS);
    DBG('l_days' || L_DAYS);
  
    DBG('Maturity date' || L_INT_START_DATE);
  
    IF (P_ACTION_CODE = 'DEFLT_TENOR' AND L_RECOMPUTE_MAT_DATE = 'Y') OR
       P_ACTION_CODE = 'ACCLSTENOR'
    
     THEN
    
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF := 'L';
    
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY := L_YEARS;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM := L_MONTHS;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD := L_DAYS;
    
      DBG('Interest start date-->' || L_INT_START_DATE);
      DBG('Account class Tenor days-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD);
      DBG('Account class Tenor Months-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM);
      DBG('Account class Tenor Years-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY);
    
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                             L_MONTHS +
                                                                             L_YEARS * 12) +
                                                                  L_DAYS;
    
      IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND NVL(L_DAYS, 0) = 0 THEN
        L_NEXT_MAT_DT_BK := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                    P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
        END IF;
      
        IF L_NEXT_MAT_DT_BK <>
           P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
          DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
          PKG_CASCADE_NXTMATDT := 'Y';
        END IF;
      
      END IF;
    
      DBG('NEXT MATURITY DATE-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
    
    ELSIF (P_ACTION_CODE = 'DEFLT_TENOR' AND L_RECOMPUTE_MAT_DATE = 'N') OR
          P_ACTION_CODE = 'ACCTENOR' THEN
    
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF := 'A';
    
      BEGIN
      
        SELECT NVL(ORIG_TENOR_YEARS, 0),
               NVL(ORIG_TENOR_MONTHS, 0),
               NVL(ORIG_TENOR_DAYS, 0),
               CASCADE_MONTH
          INTO L_YEARS, L_MONTHS, L_DAYS, L_CASCADE_MONTH
          FROM ICTM_ACC
         WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
           AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY := L_YEARS;
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM := L_MONTHS;
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD := L_DAYS;
      
        DBG('Interest start date-->' || L_INT_START_DATE);
        DBG('Account  Tenor days-->' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD);
        DBG('Account  Tenor Months-->' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM);
        DBG('Account  Tenor Years-->' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY);
        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                               L_MONTHS +
                                                                               L_YEARS * 12) +
                                                                    L_DAYS;
      
        IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND NVL(L_DAYS, 0) = 0 THEN
          L_NEXT_MAT_DT_BK := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
          END IF;
        
          IF L_NEXT_MAT_DT_BK <>
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
            DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
            PKG_CASCADE_NXTMATDT := 'Y';
          END IF;
        
        END IF;
      
        DBG('NEXT MATURITY DATE-->' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No tenor information available');
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY := 0;
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM := 0;
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD := 0;
        
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE,
                                                                                 L_MONTHS +
                                                                                 L_YEARS * 12) +
                                                                      L_DAYS;
        
          IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND NVL(L_DAYS, 0) = 0 THEN
            L_NEXT_MAT_DT_BK := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                        P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
              P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
            END IF;
          
            IF L_NEXT_MAT_DT_BK <>
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
              DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
              PKG_CASCADE_NXTMATDT := 'Y';
            END IF;
          
          END IF;
        
      END;
    
    END IF;
  
    IF P_ACTION_CODE = 'NEXTMATDT' THEN
    
      DBG('Computing next Maturity Date based on tenor');
    
      IF NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) > 30 AND
         NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY, 0) +
         NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM, 0) > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC015', NULL);
      END IF;
    
      IF NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM, 0) > 11 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC004', NULL);
      END IF;
    
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC013', NULL);
      END IF;
    
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC014', NULL);
      END IF;
    
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC012', NULL);
      END IF;
    
      SELECT MATURITY_DATE, CASCADE_MONTH
        INTO L_INT_START_DATE, L_CASCADE_MONTH
        FROM ICTMS_ACC
       WHERE ACC = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
         AND BRN = P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      DBG('independent tenor years-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY);
      DBG('Months-->' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM);
      DBG('Days-->' || P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD);
      DBG('l_int_start_date-->' || L_INT_START_DATE);
    
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := ADD_MONTHS(L_INT_START_DATE,
                                                                             NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM,
                                                                                 0) +
                                                                             NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY,
                                                                                 0) * 12) +
                                                                  NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD,
                                                                      0);
    
      IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
         NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD, 0) = 0 THEN
        L_NEXT_MAT_DT_BK := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_INT_START_DATE,
                                                    P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE) THEN
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE := L_NEXT_MAT_DT_BK;
        END IF;
      
        IF L_NEXT_MAT_DT_BK <>
           P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE THEN
          DBG('NEXT MATURITY DATE CHANGES BECAUSE OF CASCADING');
          PKG_CASCADE_NXTMATDT := 'Y';
        END IF;
      
      END IF;
    
      DBG(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
    
      DBG('Next Maturity Date=>' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE);
    
    END IF;
  
    DBG('Assigning cont_var_roll to the work variable');
  
    DBG('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UPLOAD_DB;

  FUNCTION FN_FORM_MSG(P_ERR_CODE   IN VARCHAR2,
                       P_ERR_PARAMS IN VARCHAR2,
                       P_LANG_CODE  IN SMTBS_LANGUAGE.LANG_CODE%TYPE,
                       P_CONF       OUT VARCHAR2) RETURN VARCHAR2 IS
  
    I         INTEGER;
    L_TYPE    CHAR(1);
    L_CONF    CHAR(1);
    L_FORMULA ERTBS_MSGS.DERIVED_MSG%TYPE;
    L_MSG     ERTBS_MSGS.MESSAGE%TYPE;
    L_PARAM   VARCHAR2(32767);
  BEGIN
    DBG('Inside Fn_Form_Msg..' || P_ERR_CODE || '::' || P_ERR_PARAMS || '::' ||
        P_LANG_CODE || '::' || P_CONF);
    IF NOT OVPKSS.FN_GETMSGANDTYPE(P_ERR_CODE,
                                   P_LANG_CODE,
                                   L_MSG,
                                   L_TYPE,
                                   L_CONF,
                                   L_FORMULA) THEN
      L_MSG := 'Missing Error Code ' || P_ERR_CODE;
    ELSE
      I       := 1;
      L_PARAM := CSPKES_MISC.FN_GETPARAM(P_ERR_PARAMS, I, '~');
      WHILE (L_PARAM <> 'EOPL') LOOP
        L_MSG   := REPLACE(L_MSG, '$' || I, L_PARAM);
        I       := I + 1;
        L_PARAM := CSPKES_MISC.FN_GETPARAM(P_ERR_PARAMS, I, '~');
      END LOOP;
    END IF;
    DBG('Returning true from Fn_Form_Msg.. ');
    P_CONF := L_CONF;
    RETURN L_MSG;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of Ftpks_Fcj_FtdConon.Fn_Form_Msg');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN 'Missing Error Code ' || P_ERR_CODE;
  END FN_FORM_MSG;

  FUNCTION FN_LOG_OVERRIDES(P_WRK_ICDREDMN IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                            P_ERR_CODE     IN OUT VARCHAR2,
                            P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_ERROR_CODE      VARCHAR2(255);
    L_ERROR_PARAMETER VARCHAR2(255);
    L_OVD_SEQ_NO      NUMBER := 0;
    L_RUNNING_NO      NUMBER := 0;
    L_TYPE            VARCHAR2(1);
    L_COUNT           NUMBER := 0;
    L_DUP_COUNT       NUMBER;
    L_VERSION         CSTB_CONTRACT.LATEST_VERSION_NO%TYPE;
    L_OVD_STATUS      CSTBS_CONTRACT_OVD.OVD_STATUS%TYPE;
    L_CONFIRMED       ERTBS_MSGS.CONFIRMATION_REQD%TYPE;
    L_MSG             ERTBS_MSGS.MESSAGE%TYPE;
    L_E_MAIL_OVD      CSTB_PARAM.PARAM_VAL%TYPE;
    L_MOD_NO          NUMBER;
  
    CURSOR OVD_CUR(C_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE,
                   C_LANG     ERTB_MSGS.LANGUAGE%TYPE) IS
      SELECT B.*
        FROM MSTMS_EMAIL_OVD_DETAIL B, MSTMS_EMAIL_OVD A
       WHERE B.OVERRIDE_CODE = C_ERR_CODE
         AND B.LANGUAGE = C_LANG
         AND A.OVERRIDE_CODE = B.OVERRIDE_CODE
         AND A.LANGUAGE = B.LANGUAGE
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O';
  
  BEGIN
    DBG('In Fn_Insert_Ovd..');
    DBG('Selecting Event Seq No ...');
  
    L_MOD_NO := 1;
    BEGIN
    
      L_E_MAIL_OVD := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('E_MAIL_OVD'), 'N');
    
    EXCEPTION
      WHEN OTHERS THEN
        L_E_MAIL_OVD := 'N';
    END;
    L_COUNT := OVPKS.GL_TBLERROR.COUNT;
    DBG('Insert ovd' || L_COUNT);
    IF L_COUNT > 0 THEN
      FOR I IN OVPKS.GL_TBLERROR.FIRST .. OVPKS.GL_TBLERROR.LAST LOOP
        L_ERROR_CODE      := OVPKS.GL_TBLERROR(I).ERR_CODE;
        L_ERROR_PARAMETER := OVPKS.GL_TBLERROR(I).PARAMS;
        L_TYPE            := OVPKSS.FN_GETTYPE(TRIM(REPLACE(L_ERROR_CODE,
                                                            '~',
                                                            '')));
        IF L_TYPE = 'D' THEN
          L_OVD_STATUS := 'U';
        ELSE
          L_OVD_STATUS := NULL;
        END IF;
        BEGIN
          SELECT COUNT(*)
            INTO L_DUP_COUNT
            FROM CSTB_CONTRACT_OVD
           WHERE CONTRACT_REF_NO =
                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO
             AND EVENT_SEQ_NO = L_MOD_NO
             AND MODULE = 'IC'
             AND ERR_CODE = L_ERROR_CODE
             AND
                
                 NVL(LTRIM(RTRIM(PARAMETERS, '~'), '~'), '*') =
                 NVL(LTRIM(RTRIM(L_ERROR_PARAMETER, '~'), '~'), '*');
        EXCEPTION
          WHEN OTHERS THEN
            DBG('failed here...');
        END;
        IF L_TYPE IN ('O', 'A', 'D') AND L_DUP_COUNT = 0 THEN
          IF L_E_MAIL_OVD = 'Y' THEN
            BEGIN
              FOR CUR_DET IN OVD_CUR(L_ERROR_CODE, GLOBAL.LANG) LOOP
                L_RUNNING_NO := L_RUNNING_NO + 1;
                L_MSG        := FN_FORM_MSG(L_ERROR_CODE,
                                            L_ERROR_PARAMETER,
                                            GLOBAL.LANG,
                                            L_CONFIRMED);
                DBG('Populating Mstbs_Dly_Msg_Out with Running_No:: ' ||
                    L_RUNNING_NO || ' and Message::' || L_MSG);
                INSERT INTO MSTBS_DLY_MSG_OUT
                  (DCN,
                   BRANCH,
                   RUNNING_NO,
                   REFERENCE_NO,
                   ESN,
                   MODULE,
                   MEDIA,
                   LANGUAGE,
                   ADDRESS1,
                   MESSAGE,
                   TOBE_EMAILED,
                   MSG_STATUS,
                   HOLD_STATUS,
                   AUTH_STAT,
                   ONCE_AUTH)
                VALUES
                  (NULL,
                   GLOBAL.CURRENT_BRANCH,
                   L_RUNNING_NO,
                   P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO,
                   L_MOD_NO,
                   'IC',
                   'MAIL',
                   GLOBAL.LANG,
                   CUR_DET.EMAIL_ADDRESS,
                   L_MSG,
                   'Y',
                   'G',
                   'N',
                   'A',
                   'Y');
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Exception While populating the Mstbs_Dly_Msg_Out::' ||
                    SQLERRM);
                NULL;
            END;
          END IF;
          L_OVD_SEQ_NO := L_OVD_SEQ_NO + 1;
          DBG('Before inserting first ' || L_ERROR_CODE);
          BEGIN
            INSERT INTO CSTB_CONTRACT_OVD
              (CONTRACT_REF_NO,
               EVENT_SEQ_NO,
               OVD_SEQ_NO,
               MODULE,
               ERR_CODE,
               PARAMETERS,
               OVD_STATUS,
               TXN_BRANCH,
               MAKER_ID,
               FUNCTION_ID)
            VALUES
              (P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO,
               L_MOD_NO,
               L_OVD_SEQ_NO,
               'IC',
               L_ERROR_CODE,
               L_ERROR_PARAMETER,
               L_OVD_STATUS,
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_ID,
               'ICDREDMN');
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              DBG('Its cmg inside...');
              UPDATE CSTB_CONTRACT_OVD
                 SET MODULE     = 'IC',
                     ERR_CODE   = L_ERROR_CODE,
                     PARAMETERS = L_ERROR_PARAMETER
               WHERE CONTRACT_REF_NO =
                     P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO
                 AND EVENT_SEQ_NO = L_MOD_NO
                 AND OVD_SEQ_NO = L_OVD_SEQ_NO;
            WHEN OTHERS THEN
              DBG('Others Exception While Populating the Cstb Contrat Ovd ...');
              DBG(SQLERRM);
          END;
        END IF;
        DBG('inserted the ovd' || L_ERROR_CODE);
      END LOOP;
    END IF;
    DBG('Returning from Fn_Log_Overrides');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Log_Overrides ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_LOG_OVERRIDES;

  FUNCTION FN_POST_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_MULTI_TRIP_ID    IN VARCHAR2,
                             P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                             P_PREV_ICDREDMN    IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                             P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_AUTH_STATUS VARCHAR2(3);
    L_MAKER_ID    ICTB_TDREDEMPTION_MASTER.MAKER_ID%TYPE;
  
    L_ICCREFPO         ICPKS_ICCREFPO_MAIN.TY_ICCREFPO;
    L_PREV_ICCREFPO    ICPKS_ICCREFPO_MAIN.TY_ICCREFPO;
    L_WRK_ICCREFPO     ICPKS_ICCREFPO_MAIN.TY_ICCREFPO;
    L_SOURCE_OPERATION VARCHAR2(100) := P_SOURCE_OPERATION;
    L_MAIN_FUNCTION    SMTB_MENU.FUNCTION_ID%TYPE := P_FUNCTION_ID;
  
    L_ESN             CSTB_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE;
    L_VERSION         CSTB_CONTRACT.LATEST_VERSION_NO%TYPE;
    L_COUNT           NUMBER := 0;
    L_ERROR_CODE      VARCHAR2(255);
    L_ERROR_PARAMETER VARCHAR2(255);
    L_TYPE            VARCHAR2(1);
    L_OVD_STATUS      CSTBS_CONTRACT_OVD.OVD_STATUS%TYPE;
    L_CONFIRMED       ERTBS_MSGS.CONFIRMATION_REQD%TYPE;
    L_OVD_SEQ_NO      NUMBER := 0;
  
  BEGIN
  
    DBG('In Fn_Post_Upload_Db..');
    DBG('simulation flag is ' || P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84);
    IF NVL(P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84, 'N') = 'N' THEN
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) THEN
      
        IF NOT ICPKS_ICDREDMN_MAIN.FN_SYS_UPLOAD_DB(P_SOURCE,
                                                    P_SOURCE_OPERATION,
                                                    P_FUNCTION_ID,
                                                    P_ACTION_CODE,
                                                    P_ICDREDMN,
                                                    P_PREV_ICDREDMN,
                                                    P_WRK_ICDREDMN,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
          DBG('Failed in sys upload db..... ');
          RETURN FALSE;
        END IF;
      
        DBG('p_wrk_icdredmn.ty_iccrefpo ');
      
        L_ICCREFPO      := P_ICDREDMN.TY_ICCREFPO;
        L_PREV_ICCREFPO := P_PREV_ICDREDMN.TY_ICCREFPO;
        L_WRK_ICCREFPO  := P_WRK_ICDREDMN.TY_ICCREFPO;
      
        DBG('p_wrk_icdredmn.ty_iccrefpo.v_ictbs_redem_by_bc.ref_no  ' ||
            P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.REF_NO);
      
        DBG('l_wrk_iccrefpo.v_ictbs_redem_by_bc.redem_ref_no  ' ||
            L_WRK_ICCREFPO.V_ICTBS_REDEM_BY_BC.REF_NO);
      
        IF P_SOURCE = 'FLEXCUBE' THEN
          L_SOURCE_OPERATION := 'ICCREFPO_' || P_ACTION_CODE;
        END IF;
      
        IF NOT ICPKS_ICCREFPO_MAIN.FN_SYS_UPLOAD_DB(P_SOURCE,
                                                    L_SOURCE_OPERATION,
                                                    P_FUNCTION_ID,
                                                    P_ACTION_CODE,
                                                    L_MAIN_FUNCTION,
                                                    L_ICCREFPO,
                                                    L_PREV_ICCREFPO,
                                                    L_WRK_ICCREFPO,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
          DBG('Failed in callform update....');
          RETURN FALSE;
        END IF;
      
        DBG('p_Wrk_icdredmn.v_ictbs_tdredemption_master.AUTH_STATUS' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS);
        IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS = 'U' THEN
          DBG('Before inserting into sttb_record_log');
          INSERT INTO STTB_RECORD_LOG
            (KEY_ID,
             MOD_NO,
             BRANCH_CODE,
             FUNCTION_ID,
             TABLE_NAME,
             MAKER_ID,
             MAKER_DT_STAMP,
             CHECKER_ID,
             CHECKER_DT_STAMP,
             AUTH_STAT,
             PRINT_STAT,
             REMARKS,
             REC_DATA,
             MSG_ID,
             TANKING_STATUS,
             ACTION_CODE,
             REQ_NO,
             MAKER_REMARKS,
             CHECKER_REMARKS)
          VALUES
            ('~ICTB_TDREDEMPTION_MASTER~' ||
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO || '~',
             '1',
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
             'ICDREDMN',
             'ICTB_TDREDEMPTION_MASTER',
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_ID,
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_DT_STAMP,
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_ID,
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_DT_STAMP,
             P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS,
             '',
             '',
             '',
             '',
             'N',
             'N',
             '',
             '',
             '');
          DBG('Record successfully inserted into sttb_record_log...');
        
        END IF;
      
      END IF;
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_DELETE) THEN
        P_WRK_ICDREDMN := P_ICDREDMN;
        BEGIN
          SELECT AUTH_STATUS, MAKER_ID
            INTO L_AUTH_STATUS, L_MAKER_ID
            FROM ICTB_TDREDEMPTION_MASTER
           WHERE REDEM_REF_NO =
                 P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            RETURN TRUE;
        END;
        IF L_AUTH_STATUS = 'A' THEN
          P_ERR_CODE   := 'IC-REDMN-15';
          P_ERR_PARAMS := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO;
          RETURN FALSE;
        END IF;
        IF L_MAKER_ID <> GLOBAL.USER_ID THEN
          P_ERR_CODE   := 'ST-VALS-010';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
        IF NOT ICPKS_ICDREDMN_MAIN.FN_SYS_UPLOAD_DB(P_SOURCE,
                                                    P_SOURCE_OPERATION,
                                                    P_FUNCTION_ID,
                                                    P_ACTION_CODE,
                                                    P_ICDREDMN,
                                                    P_PREV_ICDREDMN,
                                                    P_WRK_ICDREDMN,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
          DBG('Failed in sys upload db..... ');
          RETURN FALSE;
        END IF;
      
        DELETE FROM STTB_RECORD_LOG
         WHERE KEY_ID =
               '~ICTB_TDREDEMPTION_MASTER~' ||
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO || '~';
        DBG('deleted Auth Status Successfully...' || SQL%ROWCOUNT);
      
      END IF;
    
      IF ((P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
         SMPKS.FN_CHECK_AUTO_AUTH(GLOBAL.USER_ID,
                                    P_FUNCTION_ID,
                                    GLOBAL.CURRENT_BRANCH)) OR
         P_SOURCE <> 'FLEXCUBE') THEN
        DBG(' action_code coming ' || P_ACTION_CODE ||
            'with refernence no is ' ||
            P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO);
        UPDATE STTB_RECORD_LOG
           SET AUTH_STAT        = 'A',
               CHECKER_ID       = GLOBAL.USER_ID,
               CHECKER_DT_STAMP = BCPKSS_UTILS.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE)
         WHERE KEY_ID =
               '~ICTB_TDREDEMPTION_MASTER~' ||
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO || '~';
        DBG('Updated Auth Status Successfully...' || SQL%ROWCOUNT);
      END IF;
    
    END IF;
    DBG('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UPLOAD_DB;

  FUNCTION FN_PRE_PROCESS(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_CHILD_FUNCTION   IN VARCHAR2,
                          P_MULTI_TRIP_ID    IN VARCHAR2,
                          P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                          P_PREV_ICDREDMN    IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                          P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Process..');
  
    DBG('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PROCESS;

  FUNCTION FN_POST_PROCESS(P_SOURCE           IN VARCHAR2,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_FUNCTION_ID      IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_CHILD_FUNCTION   IN VARCHAR2,
                           P_MULTI_TRIP_ID    IN VARCHAR2,
                           P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                           P_PREV_ICDREDMN    IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                           P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_TY_TDVWS_TD_REDEMPTION     TDVWS_TD_REDEMPTION%ROWTYPE;
    TY_TB_V_TDREDMPAYOUT_DETAILS ICPKS_FCJ_ICDREDMN.TY_TB_PAYOUTDETS;
    L_TY_BCPAYOUTDETS            ICTMS_BCPAYOUT_DETAILS%ROWTYPE;
    L_TY_PCPAYOUTDETS            ICTMS_PCPAYOUT_DETAILS%ROWTYPE;
    L_TY_STDCUSAC                STPKS_STDCUSAC_MAIN.TY_STDCUSAC;
    L_OVERRIDE_FLAG              VARCHAR2(30000);
    L_ERR_TBL                    OVPKS.TBL_ERROR;
    L_MULTI_TRIP_ID              VARCHAR2(1000);
    L_SOURCE                     VARCHAR2(50);
    L_ACTION_CODE                VARCHAR2(50);
    L_OPERATION_CODE             VARCHAR2(100);
    L_TBL_CHGDETS                ICPKS_FCJ_ICDREDMN.TBL_CHGDETS;
    L_TY_MISDETAILS              MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE;
    L_TBL_UDFDETAILS             UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF;
    L_TY_SUBSYS                  ICPKS_FCJ_ICDREDMN.TBL_NODE;
  
    L_USER_ID ICTB_TDREDEMPTION_MASTER.CHECKER_ID%TYPE;
  
    CURSOR CR_ACC_UDEVALS(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM ICTMS_ACC_UDEVALS
       WHERE BRN = P_BRN
         AND ACC = P_ACC;
    TYPE TY_ACC_UDEVALS IS TABLE OF ICTMS_ACC_UDEVALS%ROWTYPE;
    TB_ACC_UDEVALS TY_ACC_UDEVALS;
  
    L_ERROR_CODE      VARCHAR2(1000) := NULL;
    L_ERROR_CODE_TYPE ERTBS_MSGS.TYPE%TYPE;
    L_OVERRIDE_COUNT  NUMBER := 0;
    L_ERROR_COUNT     NUMBER := 0;
  
  BEGIN
  
    DBG('In Fn_Post_Process..');
  
    DBG('Action code-->' || P_ACTION_CODE);
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) AND
       P_FUNCTION_ID <> 'ICDREDAU' AND
       NVL(P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84, 'N') <> 'Y' THEN
    
      L_USER_ID     := GLOBAL.USER_ID;
      L_USER_ID     := GLOBAL.USER_ID;
      L_ACTION_CODE := 'TDRedemAuth';
      L_SOURCE      := P_SOURCE;
    
      IF NOT FN_DEF_TY_TDVWS_TD_REDEMPTION(L_TY_TDVWS_TD_REDEMPTION,
                                           TY_TB_V_TDREDMPAYOUT_DETAILS,
                                           L_TY_BCPAYOUTDETS,
                                           L_TY_PCPAYOUTDETS,
                                           L_TY_STDCUSAC,
                                           P_ICDREDMN) THEN
        DBG('Failed in fn_def_ty_iavws_td_redmption');
        P_ERR_CODE   := 'TD-RED-11';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    
      IF NVL(P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD84, 'N') = 'N' THEN
      
        IF NOT ICPKS_FCJ_ICDREDMN.FN_QUERY_REDEMPTION_TBLS(L_TY_TDVWS_TD_REDEMPTION,
                                                           TY_TB_V_TDREDMPAYOUT_DETAILS,
                                                           L_TY_BCPAYOUTDETS,
                                                           L_TY_PCPAYOUTDETS,
                                                           L_TY_STDCUSAC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
          DBG('Failed in icpks_fcj_icdredmn.fn_query_redemption_tbls...' ||
              P_ERR_CODE || '~' || P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
      IF NOT ICPKS_FCJ_ICDREDMN.FN_MAIN(L_SOURCE,
                                        'IC',
                                        L_ACTION_CODE,
                                        L_MULTI_TRIP_ID,
                                        L_TY_TDVWS_TD_REDEMPTION,
                                        TY_TB_V_TDREDMPAYOUT_DETAILS,
                                        L_TY_BCPAYOUTDETS,
                                        L_TY_PCPAYOUTDETS,
                                        L_TY_STDCUSAC,
                                        L_TY_SUBSYS,
                                        L_TBL_CHGDETS,
                                        L_TY_MISDETAILS,
                                        L_TBL_UDFDETAILS,
                                        L_OVERRIDE_FLAG,
                                        L_ERR_TBL) THEN
        DBG('error in icpks_fcj_icdredmn.fn_main');
        OVPKSS.PR_READTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      BEGIN
      
        L_TY_TDVWS_TD_REDEMPTION.CHECKERID := L_USER_ID;
      
        L_TY_TDVWS_TD_REDEMPTION.CHECKERSTAMP := FN_MNTSTAMP;
        L_TY_TDVWS_TD_REDEMPTION.AUTHSTAT     := 'A';
        L_TY_TDVWS_TD_REDEMPTION.CONTSTAT     := 'A';
      
        UPDATE ICTB_TDREDEMPTION_MASTER TDREM
           SET TDREM.AUTH_STATUS      = L_TY_TDVWS_TD_REDEMPTION.AUTHSTAT,
               TDREM.CHECKER_ID       = L_TY_TDVWS_TD_REDEMPTION.CHECKERID,
               TDREM.CHECKER_DT_STAMP = L_TY_TDVWS_TD_REDEMPTION.CHECKERSTAMP,
               TDREM.CONTRACT_STATUS  = L_TY_TDVWS_TD_REDEMPTION.CONTSTAT
        
         WHERE TDREM.REDEM_REF_NO = L_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
      END;
      IF NOT FN_DEF_WRK_ICDREDMN(P_WRK_ICDREDMN,
                                 L_TY_TDVWS_TD_REDEMPTION,
                                 TY_TB_V_TDREDMPAYOUT_DETAILS,
                                 L_TY_BCPAYOUTDETS,
                                 L_TY_PCPAYOUTDETS,
                                 L_TY_STDCUSAC) THEN
        DBG('Failed in second conversion');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) THEN
      OPEN CR_ACC_UDEVALS(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO);
      FETCH CR_ACC_UDEVALS BULK COLLECT
        INTO TB_ACC_UDEVALS;
      CLOSE CR_ACC_UDEVALS;
    
      IF TB_ACC_UDEVALS.COUNT > 0 THEN
        FOR K IN 1 .. TB_ACC_UDEVALS.COUNT LOOP
          DBG('tb_acc_udevals(k).ude_id ' || TB_ACC_UDEVALS(K).UDE_ID);
          DBG('tb_acc_udevals.CCY ' ||
              P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY);
          DBG('tb_acc_udevals(k).Prod ' || TB_ACC_UDEVALS(K).PROD);
          DBG('tb_acc_udevals(k).ude_eff_dt ' || TB_ACC_UDEVALS(K)
              .UDE_EFF_DT);
          DBG('tb_acc_udevals(k).ude_value ' || TB_ACC_UDEVALS(K)
              .UDE_VALUE);
          DBG('tb_acc_udevals(k).ude_variance ' || TB_ACC_UDEVALS(K)
              .UDE_VARIANCE);
          DBG('tb_acc_udevals(k).brn ' || TB_ACC_UDEVALS(K).BRN);
          IF NOT ICPKS_UTIL.FN_VALIDATE_MIN_MAX_UDE(TB_ACC_UDEVALS                                (K)
                                                    .UDE_ID,
                                                    P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY,
                                                    TB_ACC_UDEVALS                                (K).PROD,
                                                    TB_ACC_UDEVALS                                (K)
                                                    .UDE_EFF_DT,
                                                    TB_ACC_UDEVALS                                (K)
                                                    .RATE_CODE,
                                                    TB_ACC_UDEVALS                                (K)
                                                    .TD_RATE_CODE,
                                                    TB_ACC_UDEVALS                                (K)
                                                    .UDE_VALUE,
                                                    TB_ACC_UDEVALS                                (K)
                                                    .UDE_VARIANCE,
                                                    TB_ACC_UDEVALS                                (K).BRN,
                                                    'FLEXCUBE',
                                                    P_FUNCTION_ID,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
            DBG('Failed in Min Max validation');
            RETURN FALSE;
          END IF;
        
          IF NOT ICPKS_UTIL.FN_VALIDATE_MIN_MAX_VARIANCE(TB_ACC_UDEVALS                                (K)
                                                         .UDE_ID,
                                                         P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY,
                                                         TB_ACC_UDEVALS                                (K).PROD,
                                                         TB_ACC_UDEVALS                                (K)
                                                         .UDE_VARIANCE,
                                                         'FLEXCUBE',
                                                         P_FUNCTION_ID,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
            DBG('Failed in Min Max Variance validation');
          END IF;
        
        END LOOP;
      END IF;
    END IF;
  
    IF P_ACTION_CODE NOT IN (CSPKS_REQ_GLOBAL.P_DELETE,
                             CSPKS_REQ_GLOBAL.P_AUTH,
                             CSPKS_REQ_GLOBAL.P_COPY) THEN
      DBG('Calling the overirides....');
      IF NOT FN_LOG_OVERRIDES(P_WRK_ICDREDMN, P_ERR_CODE, P_ERR_PARAMS) THEN
        DBG('Failed in log overrides');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_ACTION_CODE = 'COMPUTE' AND (OVPKSS.GL_TBLERROR.COUNT > 0) THEN
      FOR OVERRIDE_COUNT IN OVPKSS.GL_TBLERROR.FIRST .. OVPKSS.GL_TBLERROR.LAST LOOP
        L_ERROR_CODE      := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT).ERR_CODE;
        L_ERROR_CODE_TYPE := OVPKSS.FN_GETTYPE(L_ERROR_CODE);
        DBG('l_Error_Code-->' || L_ERROR_CODE || 'l_Error_Code_Type-->' ||
            L_ERROR_CODE_TYPE);
        IF (L_ERROR_CODE_TYPE IN ('O', 'A', 'D')) THEN
          L_OVERRIDE_COUNT := L_OVERRIDE_COUNT + 1;
        ELSIF (L_ERROR_CODE_TYPE IN ('E', 'X')) THEN
          L_ERROR_COUNT := L_ERROR_COUNT + 1;
        END IF;
      END LOOP;
      DBG('l_override_count-->' || L_OVERRIDE_COUNT || 'l_error_count-->' ||
          L_ERROR_COUNT);
      IF (L_OVERRIDE_COUNT > 0 AND L_ERROR_COUNT = 0) THEN
        OVPKSS.PR_INITERRTBL;
      END IF;
    END IF;
  
    DBG('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PROCESS;

  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CHILD_FUNCTION   IN VARCHAR2,
                        P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                        P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                        P_QRYDATA_REQD     IN VARCHAR2,
                        P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                        P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
    ISL_COUNT   NUMBER;
    L_MULTI_BRN SMTB_USER.MULTIBRANCH_ACCESS%TYPE;
    L_COUNT     NUMBER;
  BEGIN
  
    DBG('In Fn_Pre_Query..');
  
    DBG('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Pre_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;

  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CHILD_FUNCTION   IN VARCHAR2,
                         P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                         P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                         P_QRYDATA_REQD     IN VARCHAR2,
                         P_ICDREDMN         IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                         P_WRK_ICDREDMN     IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    CURSOR C_V_ICTBS_REDEM_ACC_PR IS
      SELECT *
        FROM ICTB_REDEM_ACC_PR
       WHERE REDEM_REF_NO =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO
         AND ACC =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_AC_NO
         AND BRN =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.BRANCH_CODE;
    CURSOR C_V_ICTBS_REDEM_ACC_EFFDT IS
      SELECT *
        FROM ICTB_REDEM_ACC_EFFDT
       WHERE REDEM_REF_NO =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO
         AND ACC =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_AC_NO
         AND BRN =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.BRANCH_CODE;
    CURSOR C_V_ICTBS_REDEM_ACC_UDEVALS IS
      SELECT *
        FROM ICTB_REDEM_ACC_UDEVALS
       WHERE REDEM_REF_NO =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO
         AND BRN =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.BRANCH_CODE
         AND ACC =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_AC_NO;
    CURSOR C_V_ICTBS_REDEM_CHILDTDPAYOUT IS
      SELECT *
        FROM ICTB_REDEM_CHILDTDPAYOUT
       WHERE REDEM_REF_NO =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO;
  
    L_REC_EXISTS BOOLEAN := TRUE;
  
    L_SUM_REDEMTION   NUMBER;
    L_SUM_CERTIFICATE NUMBER;
    L_REDEM_CERTIF    NUMBER;
    L_REDEEM_AMT      STTMS_DENOM_REDMN_BLK.CERTIFICATE_AMOUNT%TYPE;
  
    CURSOR C_V_ICVW_ICTB_REDEM_BY_PC IS
      SELECT *
        FROM ICVW_ICTB_REDEM_BY_PC
       WHERE REDEM_REF_NO =
             P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO;
    L_MASK VARCHAR2(1);
  
    L_IS_FORGOTTEN CHAR(1);
    L_COUNT        NUMBER := 0;
  BEGIN
  
    DBG('In Fn_Post_Query');
    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
    
      DBG('Customer_No: ' ||
          P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CUST_ID);
      BEGIN
        SELECT IS_FORGOTTEN
          INTO L_IS_FORGOTTEN
          FROM STTMS_CUSTOMER
         WHERE STTMS_CUSTOMER.CUSTOMER_NO =
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CUST_ID;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Error while quering from sttms_customer' || SQLERRM);
          L_IS_FORGOTTEN := 'N';
      END;
      DBG('Is_forgotten: ' || L_IS_FORGOTTEN);
      IF NVL(L_IS_FORGOTTEN, 'N') = 'Y' THEN
        DBG('Forgotten Customer Details cannot be Queried');
        P_ERR_CODE   := 'ST-VALS-002';
        P_ERR_PARAMS := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CUST_ID;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    
      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_QUERY, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM ICTBS_TDREDEMPTION_MASTER A, STTMS_CUSTOMER B
           WHERE A.REDEM_REF_NO = NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO,
                                      A.REDEM_REF_NO)
             AND A.BRANCH_CODE = NVL(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                     A.BRANCH_CODE)
             AND A.CUST_ID = B.CUSTOMER_NO
             AND ((B.ACCESS_GROUP IS NOT NULL AND EXISTS
                  (SELECT 1
                      FROM STVWS_USER_ACCESS C
                     WHERE C.USER_ID = GLOBAL.USER_ID
                       AND C.ACCESS_GROUP = B.ACCESS_GROUP)) OR
                 B.ACCESS_GROUP IS NULL);
        
          IF L_COUNT = 0 THEN
            DBG('User restricted to view this account' ||
                P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO);
            P_ERR_CODE   := 'ST-GRP01';
            P_ERR_PARAMS := P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        END;
      END IF;
    
      DBG('Calling Cspks_Req_Utils.Fn_Check_Branch_Rights..');
      IF NOT CSPKS_REQ_UTILS.FN_CHECK_BRANCH_RIGHTS(P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE,
                                                    GLOBAL.USER_ID,
                                                    P_FUNCTION_ID,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DBG('Failed in Cspks_Req_Utils.Fn_Check_Branch_Rights: user does not have rights to query');
        RETURN FALSE;
      END IF;
    
      IF NOT ICPKS_ICDREDMN_MAIN.FN_SKIP_SYS THEN
        IF NOT ICPKS_ICDREDMN_MAIN.FN_SYS_QUERY(P_SOURCE,
                                                P_SOURCE_OPERATION,
                                                P_FUNCTION_ID,
                                                P_ACTION_CODE,
                                                P_FULL_DATA,
                                                P_WITH_LOCK,
                                                P_QRYDATA_REQD,
                                                P_ICDREDMN,
                                                P_WRK_ICDREDMN,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
          DBG('Failed in Fn_Pre_Upload_Db..');
          RETURN FALSE;
        END IF;
      END IF;
    
      IF P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG <> 'T' THEN
        BEGIN
          SELECT TD_AMOUNT + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0)
            INTO P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD1
            FROM ICTM_TD_DETAILS
           WHERE ACC = P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRN =
                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in ICTM_TD_DEATILS Query');
        END;
      END IF;
    
      BEGIN
        SELECT *
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD
          FROM ICTB_REDEM_BY_TD
         WHERE REDEM_REF_NO =
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in Selecting The Previous Master Recotrd..');
          L_REC_EXISTS := FALSE;
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in Selecting The Previous Master Recotrd..');
          L_REC_EXISTS := FALSE;
      END;
    
      DBG('Get the Record For :ICTBS_REDEM_BY_TD');
      BEGIN
        SELECT *
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD
          FROM ICTB_REDEM_BY_TD
         WHERE REDEM_REF_NO =
               P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in Selecting The Record For :ICTBS_REDEM_BY_TD');
      END;
      DBG('Get the Record For :ICTBS_REDEM_BY_PC');
      BEGIN
        SELECT *
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC
          FROM ICTB_REDEM_BY_PC
         WHERE REDEM_REF_NO =
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in Selecting The Record For :ICTBS_REDEM_BY_PC');
      END;
      DBG('Get the Record For :ICTBS_REDEM_BY_BC');
      BEGIN
        SELECT *
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC
          FROM ICTB_REDEM_BY_BC
         WHERE REDEM_REF_NO =
               P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO;
        DBG('p_wrk_icdredmn.ty_iccrefpo.v_ictbs_redem_by_bc ' ||
            P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BANKCODE);
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in Selecting The Record For :ICTBS_REDEM_BY_BC');
      END;
      DBG('Get the Record For :ICTBS_REDEM_ACC');
      BEGIN
        SELECT *
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC
          FROM ICTB_REDEM_ACC
         WHERE REDEM_REF_NO =
               P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO
           AND ACC =
               P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_AC_NO
           AND BRN =
               P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in Selecting The Record For :ICTBS_REDEM_ACC');
      END;
      DBG('Get the Record For :ICTBS_REDEM_ACC_PR');
      OPEN C_V_ICTBS_REDEM_ACC_PR;
      LOOP
        FETCH C_V_ICTBS_REDEM_ACC_PR BULK COLLECT
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR;
        EXIT WHEN C_V_ICTBS_REDEM_ACC_PR%NOTFOUND;
      END LOOP;
      CLOSE C_V_ICTBS_REDEM_ACC_PR;
      DBG('Get the Record For :ICTBS_REDEM_ACC_EFFDT');
      OPEN C_V_ICTBS_REDEM_ACC_EFFDT;
      LOOP
        FETCH C_V_ICTBS_REDEM_ACC_EFFDT BULK COLLECT
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT;
        EXIT WHEN C_V_ICTBS_REDEM_ACC_EFFDT%NOTFOUND;
      END LOOP;
      CLOSE C_V_ICTBS_REDEM_ACC_EFFDT;
      DBG('Get the Record For :ICTBS_REDEM_ACC_UDEVALS');
      OPEN C_V_ICTBS_REDEM_ACC_UDEVALS;
      LOOP
        FETCH C_V_ICTBS_REDEM_ACC_UDEVALS BULK COLLECT
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS;
        EXIT WHEN C_V_ICTBS_REDEM_ACC_UDEVALS%NOTFOUND;
      END LOOP;
      CLOSE C_V_ICTBS_REDEM_ACC_UDEVALS;
      DBG('Get the Record For :ICTBS_REDEM_CHILDTDPAYOUT');
      OPEN C_V_ICTBS_REDEM_CHILDTDPAYOUT;
      LOOP
        FETCH C_V_ICTBS_REDEM_CHILDTDPAYOUT BULK COLLECT
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT;
        EXIT WHEN C_V_ICTBS_REDEM_CHILDTDPAYOUT%NOTFOUND;
      END LOOP;
      CLOSE C_V_ICTBS_REDEM_CHILDTDPAYOUT;
      DBG('Get the Record For :ICTBS_REDEM_CHILDPCPAYOUT');
      BEGIN
        SELECT *
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT
          FROM ICTB_REDEM_CHILDPCPAYOUT
         WHERE REDEM_REF_NO =
               P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in Selecting The Record For :ICTBS_REDEM_CHILDPCPAYOUT');
      END;
      DBG('Get the Record For :ICTBS_REDEM_CHILDBCPAYOUT');
      BEGIN
        SELECT *
          INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT
          FROM ICTB_REDEM_CHILDBCPAYOUT
         WHERE REDEM_REF_NO =
               P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in Selecting The Record For :ICTBS_REDEM_CHILDBCPAYOUT');
      END;
    
      L_MASK := SMPKS_MASK_USER.FN_SETUSRCTX(GLOBAL.USER_ID, P_FUNCTION_ID);
      DBG('Action Code -->' || P_ACTION_CODE || 'Masking -->' || L_MASK);
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY AND L_MASK = 'Y' THEN
        DBG('Masking for Redem Beneficiary..');
        OPEN C_V_ICVW_ICTB_REDEM_BY_PC;
        LOOP
          FETCH C_V_ICVW_ICTB_REDEM_BY_PC
            INTO P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC;
          EXIT WHEN C_V_ICVW_ICTB_REDEM_BY_PC%NOTFOUND;
        END LOOP;
        CLOSE C_V_ICVW_ICTB_REDEM_BY_PC;
      END IF;
    
      DBG('Going to populate' || P_ACTION_CODE ||
          P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
      IF P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT > 0 THEN
        FOR I IN P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.FIRST .. P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.LAST LOOP
          DBG('block_or_redem' || P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
              .BLOCK_OR_REDEM);
          IF P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I).BLOCK_OR_REDEM = 'R' THEN
            L_REDEEM_AMT   := NVL(L_REDEEM_AMT, 0) + P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                             .CERTIFICATE_AMOUNT;
            L_REDEM_CERTIF := NVL(L_REDEM_CERTIF, 0) + 1;
          END IF;
        END LOOP;
        DBG('Going for action');
        BEGIN
          SELECT SUM(DENOMINATION_VALUE)
            INTO L_SUM_REDEMTION
            FROM STTM_DENOM_DEP_CERTIF
           WHERE CUST_AC_NO =
                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRANCH_CODE = GLOBAL.APPLICATION_DATE
             AND NEW_STATUS = 'R';
        EXCEPTION
          WHEN OTHERS THEN
            L_SUM_REDEMTION := 0;
        END;
        BEGIN
          SELECT COUNT(CERTIFICATE_NO)
            INTO L_SUM_CERTIFICATE
            FROM STTM_DENOM_DEP_CERTIF
           WHERE CUST_AC_NO =
                 P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO
             AND BRANCH_CODE = GLOBAL.APPLICATION_DATE
             AND NEW_STATUS = 'R';
        EXCEPTION
          WHEN OTHERS THEN
            L_SUM_CERTIFICATE := 0;
        END;
        P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD80 := NVL(L_SUM_REDEMTION,
                                                             0) +
                                                         NVL(L_REDEEM_AMT,
                                                             0);
        P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD81 := NVL(L_SUM_CERTIFICATE,
                                                             0) +
                                                         NVL(L_REDEM_CERTIF,
                                                             0);
        DBG('Total Redemption Amount' ||
            P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD80);
        DBG('Total Redemption Certificate' ||
            P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD81);
        DBG('After populate' || P_ACTION_CODE);
        DBG('After delete' || P_WRK_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT);
      END IF;
    END IF;
  
    DBG('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of icpks_icdredmn_Kernel.Fn_Post_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

  FUNCTION FN_DEF_TY_TDVWS_TD_REDEMPTION(P_TY_TDVWS_TD_REDEMPTION     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                         TY_TB_V_TDREDMPAYOUT_DETAILS IN OUT ICPKS_FCJ_ICDREDMN.TY_TB_PAYOUTDETS,
                                         P_TY_BCPAYOUTDETS            IN OUT ICTMS_BCPAYOUT_DETAILS%ROWTYPE,
                                         P_TY_PCPAYOUTDETS            IN OUT ICTMS_PCPAYOUT_DETAILS%ROWTYPE,
                                         P_STDCUSAC                   IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                         P_ICDREDMN                   IN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN)
    RETURN BOOLEAN IS
    I         NUMBER := 0;
    L_IDX     NUMBER := 1;
    L_GL_CODE STTMS_PAYIN_MODE.GL_CODE%TYPE;
  BEGIN
    DBG('Populating the redemption master tables');
    DBG('1-->' || P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO);
    DBG('2-->' || P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO);
    DBG('3-->' || P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHQ_DATE);
    IF P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO IS NOT NULL OR
       P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO IS NOT NULL THEN
      DBG('searcing for the values');
      P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO;
      P_TY_TDVWS_TD_REDEMPTION.BRN_CODE                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
      P_TY_TDVWS_TD_REDEMPTION.AC_NO                      := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO;
      P_TY_TDVWS_TD_REDEMPTION.CUST_ID                    := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CUST_ID;
      P_TY_TDVWS_TD_REDEMPTION.ACC_DESC                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_DESC;
      P_TY_TDVWS_TD_REDEMPTION.ACC_AMT                    := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_AMT;
      P_TY_TDVWS_TD_REDEMPTION.ACTION_FLAG                := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG;
      P_TY_TDVWS_TD_REDEMPTION.TENOR_DD                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD;
      P_TY_TDVWS_TD_REDEMPTION.TENOR_MM                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM;
      P_TY_TDVWS_TD_REDEMPTION.TENOR_YY                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY;
      P_TY_TDVWS_TD_REDEMPTION.NEXT_MAT_DATE              := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE;
      P_TY_TDVWS_TD_REDEMPTION.REDEMPTION_BY              := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_BY;
      P_TY_TDVWS_TD_REDEMPTION.CCY                        := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY;
      P_TY_TDVWS_TD_REDEMPTION.REDEMPTION_MODE            := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE;
      P_TY_TDVWS_TD_REDEMPTION.REDEMPTION_AMT             := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_AMT;
      P_TY_TDVWS_TD_REDEMPTION.WAVE_PENALTY               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.WAVE_PENALTY;
      P_TY_TDVWS_TD_REDEMPTION.BANK_CD                    := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_CD;
      P_TY_TDVWS_TD_REDEMPTION.BANK_TXN_CCY               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_TXN_CCY;
      P_TY_TDVWS_TD_REDEMPTION.BANK_EXCH_RATE             := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_EXCH_RATE;
      P_TY_TDVWS_TD_REDEMPTION.BANK_TXN_AMT               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_TXN_AMT;
      P_TY_TDVWS_TD_REDEMPTION.CHQ_DATE                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHQ_DATE;
      P_TY_TDVWS_TD_REDEMPTION.CHARGES                    := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHARGES;
      P_TY_TDVWS_TD_REDEMPTION.BENEF_NAME                 := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BENEF_NAME;
      P_TY_TDVWS_TD_REDEMPTION.PASSPORT_NO                := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PASSPORT_NO;
      P_TY_TDVWS_TD_REDEMPTION.ADDR1                      := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR1;
      P_TY_TDVWS_TD_REDEMPTION.ADDR2                      := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR2;
      P_TY_TDVWS_TD_REDEMPTION.BANK_NARRATIVE             := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_NARRATIVE;
      P_TY_TDVWS_TD_REDEMPTION.SAVINGS_BRN_CODE           := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_BRN_CODE;
      P_TY_TDVWS_TD_REDEMPTION.SAVINGS_ACC_NO             := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_ACC_NO;
      P_TY_TDVWS_TD_REDEMPTION.SAVINGS_TXN_CCY            := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_CCY;
      P_TY_TDVWS_TD_REDEMPTION.SAVINGS_EXCH_RATE          := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_EXCH_RATE;
      P_TY_TDVWS_TD_REDEMPTION.SAVINGS_TXN_AMT            := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_AMT;
      P_TY_TDVWS_TD_REDEMPTION.SAVINGS_NARRATIVE          := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_NARRATIVE;
      P_TY_TDVWS_TD_REDEMPTION.GL_NO                      := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_NO;
      P_TY_TDVWS_TD_REDEMPTION.GL_TXN_CCY                 := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_TXN_CCY;
      P_TY_TDVWS_TD_REDEMPTION.GL_EXCH_RATE               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_EXCH_RATE;
      P_TY_TDVWS_TD_REDEMPTION.GL_TXN_AMT                 := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_TXN_AMT;
      P_TY_TDVWS_TD_REDEMPTION.GL_NARRATIVE               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_NARRATIVE;
      P_TY_TDVWS_TD_REDEMPTION.MAKERID                    := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_ID;
      P_TY_TDVWS_TD_REDEMPTION.CHECKERID                  := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_ID;
      P_TY_TDVWS_TD_REDEMPTION.MAKERSTAMP                 := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_DT_STAMP;
      P_TY_TDVWS_TD_REDEMPTION.CHECKERSTAMP               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_DT_STAMP;
      P_TY_TDVWS_TD_REDEMPTION.AUTHSTAT                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS;
      P_TY_TDVWS_TD_REDEMPTION.CONTSTAT                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONTRACT_STATUS;
      P_TY_TDVWS_TD_REDEMPTION.SCODE                      := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SCODE;
      P_TY_TDVWS_TD_REDEMPTION.XREF                       := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.XREF;
      P_TY_TDVWS_TD_REDEMPTION.FCCREF                     := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.FCCREF;
      P_TY_TDVWS_TD_REDEMPTION.PAYBRN                     := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PAYBRN;
      P_TY_TDVWS_TD_REDEMPTION.MICR_NO                    := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MICR_NO;
      P_TY_TDVWS_TD_REDEMPTION.ADDR3                      := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR3;
      P_TY_TDVWS_TD_REDEMPTION.TRN_DT                     := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TRN_DT;
      P_TY_TDVWS_TD_REDEMPTION.BANK_CTRY_CODE             := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_CTRY_CODE;
      P_TY_TDVWS_TD_REDEMPTION.WAIVE_INTEREST             := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.WAIVE_INTEREST;
      P_TY_TDVWS_TD_REDEMPTION.GL_BRANCH                  := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_BRANCH;
      P_TY_TDVWS_TD_REDEMPTION.ALLOW_PREPAYMENT           := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ALLOW_PREPAYMENT;
      P_TY_TDVWS_TD_REDEMPTION.SUPPRESS_REDEMPTION_ADVICE := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SUPPRESS_REDEMPTION_ADVICE;
      P_TY_TDVWS_TD_REDEMPTION.MATURITY_AMOUNT            := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MATURITY_AMOUNT;
      P_TY_TDVWS_TD_REDEMPTION.INTEREST_RATE              := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.INTEREST_RATE;
      P_TY_TDVWS_TD_REDEMPTION.AUTHSTAT                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS;
      P_TY_TDVWS_TD_REDEMPTION.MAKERID                    := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_ID;
      P_TY_TDVWS_TD_REDEMPTION.CHECKERID                  := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_ID;
      P_TY_TDVWS_TD_REDEMPTION.MAKERSTAMP                 := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_DT_STAMP;
      P_TY_TDVWS_TD_REDEMPTION.CHECKERSTAMP               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_DT_STAMP;
      P_TY_TDVWS_TD_REDEMPTION.CONTSTAT                   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONTRACT_STATUS;
      P_TY_TDVWS_TD_REDEMPTION.INTEREST_RATE              := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.INTEREST_RATE;
      P_TY_TDVWS_TD_REDEMPTION.MATURITY_AMOUNT            := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MATURITY_AMOUNT;
      P_TY_TDVWS_TD_REDEMPTION.MATURITY_AMOUNT            := P_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD1;
      P_TY_TDVWS_TD_REDEMPTION.CONT_VAR_ROLL              := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONT_VAR_ROLL;
      P_TY_TDVWS_TD_REDEMPTION.INTRATE_CUMAMT_REQD        := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.INTRATE_CUMAMT_REQD;
      P_TY_TDVWS_TD_REDEMPTION.PRODUCT_CODE               := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE;
    
      P_TY_TDVWS_TD_REDEMPTION.ORG_DAYS     := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_DAYS;
      P_TY_TDVWS_TD_REDEMPTION.ORG_MONTHS   := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_MONTHS;
      P_TY_TDVWS_TD_REDEMPTION.ORG_YEARS    := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_YEARS;
      P_TY_TDVWS_TD_REDEMPTION.REDEM_SEQ_NO := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_SEQ_NO;
    
      DBG('p_icdredmn.v_ictbs_tdredemption_master.add_funds-->' ||
          P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS);
      P_TY_TDVWS_TD_REDEMPTION.ADD_FUNDS      := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS;
      P_TY_TDVWS_TD_REDEMPTION.ADDITIONAL_AMT := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT;
    
      P_TY_TDVWS_TD_REDEMPTION.REDEM_INT_PAYOUT := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_INT_PAYOUT;
    END IF;
    DBG('Populating the payout details for ty_tb_v_tdredmpayout_details');
    IF P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.COUNT > 0 AND
       P_TY_TDVWS_TD_REDEMPTION.ACTION_FLAG <> 'T' THEN
      FOR I IN P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.FIRST .. P_ICDREDMN.V_TDREDMPAYOUT_DETAILS.LAST LOOP
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).BRN := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).BRN;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).ACC := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).ACC;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).CCY := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).CCY;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).PAYOUTTYPE := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                      .PAYOUTTYPE;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).OFFSET_BRN := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                      .OFFSET_BRN;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).OFFSET_ACC := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                      .OFFSET_ACC;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).OFFSET_CCY := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                      .OFFSET_CCY;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).PERCENTAGE := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                      .PERCENTAGE;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).REDMAMT := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                   .REDMAMT;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).NARRATIVE := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                     .NARRATIVE;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).REF_NO := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                  .REF_NO;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).SEQNO := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                 .SEQNO;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).XRATE := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                 .XRATE;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).REDEM_REF_NO := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                        .REDEM_REF_NO;
      
        DBG('p_icdredmn.v_tdredmpayout_details(i).INSTNO::' || P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
            .INSTNO);
        DBG('p_icdredmn.v_tdredmpayout_details(i).WAIVE_ISSUE_CHG::' || P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
            .WAIVE_ISSUE_CHG);
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).INSTNO := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                  .INSTNO;
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).WAIVE_ISSUE_CHG := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                           .WAIVE_ISSUE_CHG;
      
        TY_TB_V_TDREDMPAYOUT_DETAILS(I).REDM_PAYOUT_COMP := P_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
                                                            .REDM_PAYOUT_COMP;
      
      END LOOP;
    END IF;
  
    DBG('p_icdredmn.v_ictms_tdredpayin_details.count--->' ||
        P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT);
    IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.COUNT > 0 AND
       P_TY_TDVWS_TD_REDEMPTION.ACTION_FLAG <> 'T' THEN
      FOR M IN P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.FIRST .. P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS.LAST LOOP
        DBG('p_icdredmn.v_ictms_tdredpayin_details(m).MULTIMODE_PAYOPT--->' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
            .MULTIMODE_PAYOPT);
      
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).BRN := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).ACC := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).CCY := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY;
      
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_PAYOPT := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                        .MULTIMODE_PAYOPT;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_TDAMOUNT := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                          .MULTIMODE_TDAMOUNT;
      
        IF P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M).MULTIMODE_PAYOPT = 'G' THEN
          DBG('Account branch:---' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M).BRN);
          DBG('Payout Option:---' || P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
              .MULTIMODE_PAYOPT);
        
          BEGIN
            SELECT GL_CODE
              INTO L_GL_CODE
              FROM STTMS_PAYIN_MODE
             WHERE BRANCH_CODE =
                   P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE
               AND PAYIN_OPTION = P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                  .MULTIMODE_PAYOPT
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
            DBG('l_gl_code:---' || L_GL_CODE);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('l_gl_code not required for payin S---');
              L_GL_CODE := NULL;
          END;
        
          ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_OFFSET_BRN := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE;
        
          ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_TDOFFSET_ACC := L_GL_CODE;
        
          ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_TDOFFSET_CCY := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY;
        
        ELSE
          ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_OFFSET_BRN := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                              .MULTIMODE_OFFSET_BRN;
          ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_TDOFFSET_ACC := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                                .MULTIMODE_TDOFFSET_ACC;
          ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_TDOFFSET_CCY := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                                .MULTIMODE_TDOFFSET_CCY;
        END IF;
      
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).REFERENCE_NO := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                    .REFERENCE_NO;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULTIMODE_PERCENTAGE := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                            .MULTIMODE_PERCENTAGE;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).MULITMODE_XRATE := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                       .MULITMODE_XRATE;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).SEQNO := M;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).CHQ_INSTUMENTNO := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                       .CHQ_INSTUMENTNO;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).CLG_BANK_CODE := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                     .CLG_BANK_CODE;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).CLG_BRANCH_CODE := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                       .CLG_BRANCH_CODE;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).CLG_PRODUCT_CODE := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                        .CLG_PRODUCT_CODE;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).CHQ_INSTRUMENT_DATE := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                           .CHQ_INSTRUMENT_DATE;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).DRAWEE_AC_NO := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                    .DRAWEE_AC_NO;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).ROUTING_NO := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                  .ROUTING_NO;
      
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).REDEM_REF_NO := P_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO;
      
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).CLEARING_REF_NO := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                       .CLEARING_REF_NO;
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(L_IDX).CHQ_AVL_DATE := P_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(M)
                                                                    .CHQ_AVL_DATE;
        L_IDX := L_IDX + 1;
      END LOOP;
    
    END IF;
  
    DBG('Populating the payout details for p_ty_bcpayoutdets');
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BANKCODE IS NOT NULL THEN
      P_TY_BCPAYOUTDETS.BRN          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BRN;
      P_TY_BCPAYOUTDETS.ACC          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.ACC;
      P_TY_BCPAYOUTDETS.CCY          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CCY;
      P_TY_BCPAYOUTDETS.REF_NO       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.REF_NO;
      P_TY_BCPAYOUTDETS.SCODE        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.SCODE;
      P_TY_BCPAYOUTDETS.XREF         := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.XREF;
      P_TY_BCPAYOUTDETS.MICR_NO      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.MICR_NO;
      P_TY_BCPAYOUTDETS.TRN_DT       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.TRN_DT;
      P_TY_BCPAYOUTDETS.BANKCODE     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BANKCODE;
      P_TY_BCPAYOUTDETS.CHQ_AMT      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHQ_AMT;
      P_TY_BCPAYOUTDETS.CHQ_CCY      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHQ_CCY;
      P_TY_BCPAYOUTDETS.CHQ_DATE     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHQ_DATE;
      P_TY_BCPAYOUTDETS.XRATE        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.XRATE;
      P_TY_BCPAYOUTDETS.PAYBRN       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.PAYBRN;
      P_TY_BCPAYOUTDETS.WAVE_PENALTY := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.WAVE_PENALTY;
      P_TY_BCPAYOUTDETS.CHARGES      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHARGES;
      P_TY_BCPAYOUTDETS.BENFNAME     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BENFNAME;
      P_TY_BCPAYOUTDETS.BENFADD1     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BENFADD1;
      P_TY_BCPAYOUTDETS.BENFADD2     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BENFADD2;
      P_TY_BCPAYOUTDETS.BENFADD3     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BENFADD3;
      P_TY_BCPAYOUTDETS.OTHERDETS    := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.OTHERDETS;
      P_TY_BCPAYOUTDETS.NARRATIVE    := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.NARRATIVE;
      P_TY_BCPAYOUTDETS.COUNTRY_CODE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.COUNTRY_CODE;
      P_TY_BCPAYOUTDETS.CHQ_PERCENT  := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHQ_PERCENT;
    END IF;
    DBG('Populating the payout details for p_ty_pcpayoutdets');
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCBANKCODE IS NOT NULL THEN
      P_TY_PCPAYOUTDETS.BRN            := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.BRN;
      P_TY_PCPAYOUTDETS.ACC            := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.ACC;
      P_TY_PCPAYOUTDETS.CCY            := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.CCY;
      P_TY_PCPAYOUTDETS.PCBANKCODE     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCBANKCODE;
      P_TY_PCPAYOUTDETS.PCOFFSET_BRN   := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCOFFSET_BRN;
      P_TY_PCPAYOUTDETS.PCOFFSET_ACC   := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCOFFSET_ACC;
      P_TY_PCPAYOUTDETS.PCOFFSET_CCY   := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCOFFSET_CCY;
      P_TY_PCPAYOUTDETS.BENFNAME       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.BENFNAME;
      P_TY_PCPAYOUTDETS.BENFADD1       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.BENFADD1;
      P_TY_PCPAYOUTDETS.BENFADD2       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.BENFADD2;
      P_TY_PCPAYOUTDETS.OTHERDETS      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.OTHERDETS;
      P_TY_PCPAYOUTDETS.NARRATIVE      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.NARRATIVE;
      P_TY_PCPAYOUTDETS.CUSTBANKCODE   := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.CUSTBANKCODE;
      P_TY_PCPAYOUTDETS.CUSTACCNO      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.CUSTACCNO;
      P_TY_PCPAYOUTDETS.CGNEWTWORKCODE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.CGNEWTWORKCODE;
      P_TY_PCPAYOUTDETS.TXNCCY         := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.TXNCCY;
      P_TY_PCPAYOUTDETS.TXNAMT         := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.TXNAMT;
      P_TY_PCPAYOUTDETS.XRATE          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.XRATE;
      P_TY_PCPAYOUTDETS.REFNO          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.REFNO;
      P_TY_PCPAYOUTDETS.PCPERCENTAGE   := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCPERCENTAGE;
    END IF;
    DBG('Populating the customer account details ');
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_NO IS NOT NULL THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.JOINT_AC_INDICATOR;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL              := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.DR_GL;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO            := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_NO;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO         := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_AC_NO;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL              := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CR_GL;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY                := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CCY;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.BRANCH_CODE;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.ALT_AC_NO;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.AC_OPEN_DATE;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC            := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.AC_DESC;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.ACCOUNT_TYPE;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.ACCOUNT_CLASS;
    END IF;
    DBG('Populating the ictm acc details');
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BRN IS NOT NULL THEN
      P_STDCUSAC.V_ICTMS_ACC.BRN                      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BRN;
      P_STDCUSAC.V_ICTMS_ACC.ACC                      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ACC;
      P_STDCUSAC.V_ICTMS_ACC.CALC_ACC                 := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CALC_ACC;
      P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC                 := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BOOK_ACC;
      P_STDCUSAC.V_ICTMS_ACC.HAS_IS                   := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.HAS_IS;
      P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE           := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.INT_START_DATE;
      P_STDCUSAC.V_ICTMS_ACC.LAST_IS_DATE             := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.LAST_IS_DATE;
      P_STDCUSAC.V_ICTMS_ACC.ACC_TYPE                 := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ACC_TYPE;
      P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN                 := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BOOK_BRN;
      P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER            := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.AUTO_ROLLOVER;
      P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CLOSE_ON_MATURITY;
      P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED    := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.MOVE_INT_TO_UNCLAIMED;
      P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED   := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.MOVE_PRIC_TO_UNCLAIMED;
      P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE            := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.MATURITY_DATE;
      P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC             := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.PRINC_LIQ_AC;
      P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE            := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ROLLOVER_TYPE;
      P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT             := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ROLLOVER_AMT;
      P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH         := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.PRINC_LIQ_BRANCH;
      P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.NEXT_MATURITY_DATE;
      P_STDCUSAC.V_ICTMS_ACC.BOOK_CCY                 := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BOOK_CCY;
      P_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV             := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.HAS_DRCR_ADV;
      P_STDCUSAC.V_ICTMS_ACC.RD_FLAG                  := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_FLAG;
      P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN    := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_AUTO_PMNT_TAKEDOWN;
      P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_MOVE_MAT_TO_UNCLAIMED;
      P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_MOVE_FUNDS_ON_OVD;
      P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS         := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_TAKEDOWN_DAYS;
      P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_TAKEDOWN_MONTHS;
      P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_TAKEDOWN_YEARS;
      P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC           := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_PAYMENT_ACC;
      P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN           := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_PAYMENT_BRN;
      P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY           := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_PAYMENT_CCY;
      P_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_INSTALLMENT_AMT;
      P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT             := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_PAY_SCHDT;
      P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CHARGE_BOOK_BRN;
      P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CHARGE_BOOK_ACC;
      P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_CCY          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CHARGE_BOOK_CCY;
      P_STDCUSAC.V_ICTMS_ACC.OVERRIDE_AMT_BLOCK       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.OVERRIDE_AMT_BLOCK;
      P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE           := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CHG_START_DATE;
      P_STDCUSAC.V_ICTMS_ACC.BVT_DATE                 := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BVT_DATE;
      P_STDCUSAC.V_ICTMS_ACC.COMBVT_DATE              := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.COMBVT_DATE;
      P_STDCUSAC.V_ICTMS_ACC.TENOR_CODE               := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.TENOR_CODE;
      P_STDCUSAC.V_ICTMS_ACC.AUTO_EXTENSION           := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.AUTO_EXTENSION;
      P_STDCUSAC.V_ICTMS_ACC.LIQUIDATION_AMT          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.LIQUIDATION_AMT;
      P_STDCUSAC.V_ICTMS_ACC.LAST_ROLLOVER_DATE       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.LAST_ROLLOVER_DATE;
      P_STDCUSAC.V_ICTMS_ACC.ALLOW_PREPAYMENT         := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ALLOW_PREPAYMENT;
    END IF;
    DBG('Populating the ictm acc pr details');
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR.COUNT > 0 AND
       P_TY_TDVWS_TD_REDEMPTION.ACTION_FLAG <> 'T' THEN
      FOR I IN P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR.FIRST .. P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR.LAST LOOP
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).BRN := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).BRN;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).ACC := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).ACC;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).PROD;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).WAIVE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                              .WAIVE;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).GEN_UCA := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                                .GEN_UCA;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).RECORD_STAT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                                    .RECORD_STAT;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).ONCE_AUTH := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                                  .ONCE_AUTH;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).UDE_CCY := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                                .UDE_CCY;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).MIN_AMT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                                .MIN_AMT;
        DBG('1');
        P_STDCUSAC.V_ICTMS_ACC_PR(I).MAX_AMT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                                .MAX_AMT;
        P_STDCUSAC.V_ICTMS_ACC_PR(I).FREE_TXN := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                                 .FREE_TXN;
        P_STDCUSAC.V_ICTMS_ACC_PR(I).CONT_VAR_ROLL := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I)
                                                      .CONT_VAR_ROLL;
      END LOOP;
    END IF;
    DBG('Populating the values in ictm_acc_pr_effdt table');
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT.COUNT > 0 THEN
      FOR I IN P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT.FIRST .. P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT.LAST LOOP
        P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).BRN := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).BRN;
        P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ACC := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).ACC;
        P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).PROD := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).PROD;
        P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).UDE_EFF_DT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I)
                                                      .UDE_EFF_DT;
        P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).RECORD_STAT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I)
                                                       .RECORD_STAT;
        P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ONCE_AUTH := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I)
                                                     .ONCE_AUTH;
      END LOOP;
    END IF;
    DBG('Populating the values in ictm_acc_pr_udevals table');
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS.COUNT > 0 AND
       P_TY_TDVWS_TD_REDEMPTION.ACTION_FLAG <> 'T' THEN
      FOR I IN P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS.FIRST .. P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS.LAST LOOP
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BRN := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).BRN;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).ACC := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).ACC;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).PROD := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).PROD;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_EFF_DT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                        .UDE_EFF_DT;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_ID := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                    .UDE_ID;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_VALUE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                       .UDE_VALUE;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).RATE_CODE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                       .RATE_CODE;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).AUTH_STAT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                       .AUTH_STAT;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).RECORD_STAT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                         .RECORD_STAT;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BASE_RATE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                       .BASE_RATE;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BASE_SPREAD := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                         .BASE_SPREAD;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).TD_RATE_CODE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                          .TD_RATE_CODE;
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_VARIANCE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I)
                                                          .UDE_VARIANCE;
      END LOOP;
    END IF;
  
    DBG('p_icdredmn.ty_iccrefpo.v_ictbs_redem_childtdpayout ' ||
        P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT.COUNT);
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT.COUNT > 0 AND
       P_TY_TDVWS_TD_REDEMPTION.ACTION_FLAG <> 'T' THEN
      DBG('Coming here with count ' ||
          P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT.COUNT);
      FOR I IN P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT.FIRST .. P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT.LAST LOOP
      
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        DBG('p_stdcusac.v_sttms_cust_account.cust_ac_no  ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                             .PAYOUTTYPE;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BANKCODE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                           .BANKCODE;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_BRN := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                             .OFFSET_BRN;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_ACC := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                             .OFFSET_ACC;
        DBG('Offset acc ' || P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
            .OFFSET_ACC);
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_CCY := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                             .OFFSET_CCY;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PERCENTAGE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                             .PERCENTAGE;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).REDMAMT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                          .REDMAMT;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BENFNAME := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                           .BENFNAME;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BENFADD1 := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                           .BENFADD1;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BENFADD2 := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                           .BENFADD2;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OTHERDETS := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                            .OTHERDETS;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).NARRATIVE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                            .NARRATIVE;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).XRATE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                        .XRATE;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).REF_NO := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                         .REF_NO;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).SEQNO := I;
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I)
                                                                   .PAYOUT_COMPONENT;
      END LOOP;
    END IF;
  
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCBANKCODE IS NOT NULL THEN
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BRN          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.BRN;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.ACC          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.ACC;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.CCY          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.CCY;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE   := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCBANKCODE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_BRN := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCOFFSET_BRN;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_ACC := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCOFFSET_ACC;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_CCY := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCOFFSET_CCY;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCPERCENTAGE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCPERCENTAGE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFNAME     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.BENFNAME;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD1     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.BENFADD1;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD2     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.BENFADD2;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.OTHERDETS    := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.OTHERDETS;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.NARRATIVE    := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.NARRATIVE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.XRATE        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.XRATE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.REFNO        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.REFNO;
    END IF;
  
    IF P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BANKCODE IS NOT NULL THEN
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BRN          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BRN;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.ACC          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.ACC;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CCY          := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CCY;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.REF_NO       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.REF_NO;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.SCODE        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.SCODE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XREF         := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.XREF;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.MICR_NO      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.MICR_NO;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.TRN_DT       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.TRN_DT;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BANKCODE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_AMT      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHQ_AMT;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_CCY      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHQ_CCY;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_DATE     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHQ_DATE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_PERCENT  := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHQ_PERCENT;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XRATE        := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.XRATE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.PAYBRN       := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.PAYBRN;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.WAVE_PENALTY := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.WAVE_PENALTY;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHARGES      := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHARGES;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFNAME     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BENFNAME;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD1     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BENFADD1;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD2     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BENFADD2;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD3     := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BENFADD3;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.OTHERDETS    := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.OTHERDETS;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.NARRATIVE    := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.NARRATIVE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.COUNTRY_CODE := P_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.COUNTRY_CODE;
    END IF;
  
    DBG('Returning success from fn_def_Ty_tdvws_td_redemption');
    RETURN TRUE;
  END FN_DEF_TY_TDVWS_TD_REDEMPTION;

  FUNCTION FN_DEF_WRK_ICDREDMN(P_WRK_ICDREDMN               IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                               P_TY_TDVWS_TD_REDEMPTION     IN TDVWS_TD_REDEMPTION%ROWTYPE,
                               TY_TB_V_TDREDMPAYOUT_DETAILS IN ICPKS_FCJ_ICDREDMN.TY_TB_PAYOUTDETS,
                               P_TY_BCPAYOUTDETS            IN ICTMS_BCPAYOUT_DETAILS%ROWTYPE,
                               P_TY_PCPAYOUTDETS            IN ICTMS_PCPAYOUT_DETAILS%ROWTYPE,
                               P_STDCUSAC                   IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    I     NUMBER := 0;
    L_IDX NUMBER := 1;
  BEGIN
  
    IF P_TY_TDVWS_TD_REDEMPTION.AC_NO IS NOT NULL THEN
      DBG('Populating the redemption master table values');
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO               := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE                := P_TY_TDVWS_TD_REDEMPTION.BRN_CODE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_NO                     := P_TY_TDVWS_TD_REDEMPTION.AC_NO;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CUST_ID                    := P_TY_TDVWS_TD_REDEMPTION.CUST_ID;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_DESC                   := P_TY_TDVWS_TD_REDEMPTION.ACC_DESC;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACC_AMT                    := P_TY_TDVWS_TD_REDEMPTION.ACC_AMT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG                := P_TY_TDVWS_TD_REDEMPTION.ACTION_FLAG;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_DD                   := P_TY_TDVWS_TD_REDEMPTION.TENOR_DD;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_MM                   := P_TY_TDVWS_TD_REDEMPTION.TENOR_MM;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TENOR_YY                   := P_TY_TDVWS_TD_REDEMPTION.TENOR_YY;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE              := P_TY_TDVWS_TD_REDEMPTION.NEXT_MAT_DATE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_BY              := P_TY_TDVWS_TD_REDEMPTION.REDEMPTION_BY;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CCY                        := P_TY_TDVWS_TD_REDEMPTION.CCY;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE            := P_TY_TDVWS_TD_REDEMPTION.REDEMPTION_MODE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEMPTION_AMT             := P_TY_TDVWS_TD_REDEMPTION.REDEMPTION_AMT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.WAVE_PENALTY               := P_TY_TDVWS_TD_REDEMPTION.WAVE_PENALTY;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_CD                    := P_TY_TDVWS_TD_REDEMPTION.BANK_CD;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_TXN_CCY               := P_TY_TDVWS_TD_REDEMPTION.BANK_TXN_CCY;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_EXCH_RATE             := P_TY_TDVWS_TD_REDEMPTION.BANK_EXCH_RATE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_TXN_AMT               := P_TY_TDVWS_TD_REDEMPTION.BANK_TXN_AMT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHQ_DATE                   := P_TY_TDVWS_TD_REDEMPTION.CHQ_DATE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHARGES                    := P_TY_TDVWS_TD_REDEMPTION.CHARGES;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BENEF_NAME                 := P_TY_TDVWS_TD_REDEMPTION.BENEF_NAME;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PASSPORT_NO                := P_TY_TDVWS_TD_REDEMPTION.PASSPORT_NO;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR1                      := P_TY_TDVWS_TD_REDEMPTION.ADDR1;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR2                      := P_TY_TDVWS_TD_REDEMPTION.ADDR2;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_NARRATIVE             := P_TY_TDVWS_TD_REDEMPTION.BANK_NARRATIVE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_BRN_CODE           := P_TY_TDVWS_TD_REDEMPTION.SAVINGS_BRN_CODE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_ACC_NO             := P_TY_TDVWS_TD_REDEMPTION.SAVINGS_ACC_NO;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_CCY            := P_TY_TDVWS_TD_REDEMPTION.SAVINGS_TXN_CCY;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_EXCH_RATE          := P_TY_TDVWS_TD_REDEMPTION.SAVINGS_EXCH_RATE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_AMT            := P_TY_TDVWS_TD_REDEMPTION.SAVINGS_TXN_AMT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SAVINGS_NARRATIVE          := P_TY_TDVWS_TD_REDEMPTION.SAVINGS_NARRATIVE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_NO                      := P_TY_TDVWS_TD_REDEMPTION.GL_NO;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_TXN_CCY                 := P_TY_TDVWS_TD_REDEMPTION.GL_TXN_CCY;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_EXCH_RATE               := P_TY_TDVWS_TD_REDEMPTION.GL_EXCH_RATE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_TXN_AMT                 := P_TY_TDVWS_TD_REDEMPTION.GL_TXN_AMT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_NARRATIVE               := P_TY_TDVWS_TD_REDEMPTION.GL_NARRATIVE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_ID                   := P_TY_TDVWS_TD_REDEMPTION.MAKERID;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_ID                 := P_TY_TDVWS_TD_REDEMPTION.CHECKERID;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_DT_STAMP             := P_TY_TDVWS_TD_REDEMPTION.MAKERSTAMP;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_DT_STAMP           := P_TY_TDVWS_TD_REDEMPTION.CHECKERSTAMP;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS                := P_TY_TDVWS_TD_REDEMPTION.AUTHSTAT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONTRACT_STATUS            := P_TY_TDVWS_TD_REDEMPTION.CONTSTAT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SCODE                      := P_TY_TDVWS_TD_REDEMPTION.SCODE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.XREF                       := P_TY_TDVWS_TD_REDEMPTION.XREF;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.FCCREF                     := P_TY_TDVWS_TD_REDEMPTION.FCCREF;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PAYBRN                     := P_TY_TDVWS_TD_REDEMPTION.PAYBRN;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MICR_NO                    := P_TY_TDVWS_TD_REDEMPTION.MICR_NO;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDR3                      := P_TY_TDVWS_TD_REDEMPTION.ADDR3;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.TRN_DT                     := P_TY_TDVWS_TD_REDEMPTION.TRN_DT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.BANK_CTRY_CODE             := P_TY_TDVWS_TD_REDEMPTION.BANK_CTRY_CODE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.WAIVE_INTEREST             := P_TY_TDVWS_TD_REDEMPTION.WAIVE_INTEREST;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.GL_BRANCH                  := P_TY_TDVWS_TD_REDEMPTION.GL_BRANCH;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ALLOW_PREPAYMENT           := P_TY_TDVWS_TD_REDEMPTION.ALLOW_PREPAYMENT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.SUPPRESS_REDEMPTION_ADVICE := P_TY_TDVWS_TD_REDEMPTION.SUPPRESS_REDEMPTION_ADVICE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MATURITY_AMOUNT            := P_TY_TDVWS_TD_REDEMPTION.MATURITY_AMOUNT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.INTEREST_RATE              := P_TY_TDVWS_TD_REDEMPTION.INTEREST_RATE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_ID                   := P_TY_TDVWS_TD_REDEMPTION.MAKERID;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_ID                 := P_TY_TDVWS_TD_REDEMPTION.CHECKERID;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MAKER_DT_STAMP             := P_TY_TDVWS_TD_REDEMPTION.MAKERSTAMP;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CHECKER_DT_STAMP           := P_TY_TDVWS_TD_REDEMPTION.CHECKERSTAMP;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONTRACT_STATUS            := P_TY_TDVWS_TD_REDEMPTION.CONTSTAT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS                := P_TY_TDVWS_TD_REDEMPTION.AUTHSTAT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.INTEREST_RATE              := P_TY_TDVWS_TD_REDEMPTION.INTEREST_RATE;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.MATURITY_AMOUNT            := P_TY_TDVWS_TD_REDEMPTION.MATURITY_AMOUNT;
      P_WRK_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD1                          := P_TY_TDVWS_TD_REDEMPTION.PRINCIPAL_AMOUNT;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.CONT_VAR_ROLL              := P_TY_TDVWS_TD_REDEMPTION.CONT_VAR_ROLL;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.INTRATE_CUMAMT_REQD        := P_TY_TDVWS_TD_REDEMPTION.INTRATE_CUMAMT_REQD;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE               := P_TY_TDVWS_TD_REDEMPTION.PRODUCT_CODE;
    
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_DAYS     := P_TY_TDVWS_TD_REDEMPTION.ORG_DAYS;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_MONTHS   := P_TY_TDVWS_TD_REDEMPTION.ORG_MONTHS;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ORG_YEARS    := P_TY_TDVWS_TD_REDEMPTION.ORG_YEARS;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_SEQ_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_SEQ_NO;
    
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS      := P_TY_TDVWS_TD_REDEMPTION.ADD_FUNDS;
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT := P_TY_TDVWS_TD_REDEMPTION.ADDITIONAL_AMT;
    
      P_WRK_ICDREDMN.V_ICTBS_TDREDEMPTION_MASTER.REDEM_INT_PAYOUT := P_TY_TDVWS_TD_REDEMPTION.REDEM_INT_PAYOUT;
    
    END IF;
    DBG('Populating the payout details for ty_tb_v_tdredmpayout_details');
    IF TY_TB_V_TDREDMPAYOUT_DETAILS.COUNT > 0 THEN
      FOR I IN TY_TB_V_TDREDMPAYOUT_DETAILS.FIRST .. TY_TB_V_TDREDMPAYOUT_DETAILS.LAST LOOP
        DBG('p_Ty_tdvws_td_redemption.REDEM_REF_NO;  ' ||
            P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO);
        DBG('i value  ' || I);
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).REDEM_REF_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
        DBG('p_wrk_icdredmn.v_tdredmpayout_details(i).redem_ref_no  ' || P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
            .REDEM_REF_NO);
      
        DBG('ty_tb_v_tdredmpayout_details(i).INSTNO::' || TY_TB_V_TDREDMPAYOUT_DETAILS(I)
            .INSTNO);
        DBG('ty_tb_v_tdredmpayout_details(i).WAIVE_ISSUE_CHG::' || TY_TB_V_TDREDMPAYOUT_DETAILS(I)
            .WAIVE_ISSUE_CHG);
      
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).BRN := TY_TB_V_TDREDMPAYOUT_DETAILS(I).BRN;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).ACC := TY_TB_V_TDREDMPAYOUT_DETAILS(I).ACC;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).CCY := TY_TB_V_TDREDMPAYOUT_DETAILS(I).CCY;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).PAYOUTTYPE := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                               .PAYOUTTYPE;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).OFFSET_BRN := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                               .OFFSET_BRN;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).OFFSET_ACC := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                               .OFFSET_ACC;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).OFFSET_CCY := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                               .OFFSET_CCY;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).PERCENTAGE := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                               .PERCENTAGE;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).REDMAMT := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                            .REDMAMT;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).NARRATIVE := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                              .NARRATIVE;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).REF_NO := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                           .REF_NO;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).SEQNO := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                          .SEQNO;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).XRATE := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                          .XRATE;
      
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).INSTNO := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                           .INSTNO;
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).WAIVE_ISSUE_CHG := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                                    .WAIVE_ISSUE_CHG;
      
        DBG('p_wrk_icdredmn.v_tdredmpayout_details(i).INSTNO::' || P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
            .INSTNO);
        DBG('p_wrk_icdredmn.v_tdredmpayout_details(i).WAIVE_ISSUE_CHG::' || P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I)
            .WAIVE_ISSUE_CHG);
      
        P_WRK_ICDREDMN.V_TDREDMPAYOUT_DETAILS(I).REDM_PAYOUT_COMP := TY_TB_V_TDREDMPAYOUT_DETAILS(I)
                                                                     .REDM_PAYOUT_COMP;
      END LOOP;
    END IF;
  
    DBG('REpopulating the additional payin details--' ||
        ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN.COUNT);
  
    IF ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN.COUNT > 0 THEN
    
      FOR M IN ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN.FIRST .. ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN.LAST LOOP
        DBG('brn-->' || ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M).BRN);
        DBG('acc-->' || ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M).ACC);
        DBG('ccy-->' || ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M).CCY);
        DBG('REDEM_REF_NO-->' || ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
            .REDEM_REF_NO);
        DBG('seq no-->' || ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M).SEQNO);
        DBG('l_idx--->' || L_IDX);
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).BRN := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M).BRN;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).ACC := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M).ACC;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).CCY := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M).CCY;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).MULTIMODE_PAYOPT := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                             .MULTIMODE_PAYOPT;
        DBG('icpks_fcj_icdredmn.g_ty_tb_addnapyin(m).MULTIMODE_PAYOPT-->' || ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
            .MULTIMODE_PAYOPT);
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).MULTIMODE_TDAMOUNT := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                               .MULTIMODE_TDAMOUNT;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).MULTIMODE_OFFSET_BRN := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                                 .MULTIMODE_OFFSET_BRN;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).MULTIMODE_TDOFFSET_ACC := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                                   .MULTIMODE_TDOFFSET_ACC;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).MULTIMODE_TDOFFSET_CCY := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                                   .MULTIMODE_TDOFFSET_CCY;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).REFERENCE_NO := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                         .REFERENCE_NO;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).MULTIMODE_PERCENTAGE := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                                 .MULTIMODE_PERCENTAGE;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).MULITMODE_XRATE := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                            .MULITMODE_XRATE;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).SEQNO := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                  .SEQNO;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).CHQ_INSTUMENTNO := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                            .CHQ_INSTUMENTNO;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).CLG_BANK_CODE := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                          .CLG_BANK_CODE;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).CLG_BRANCH_CODE := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                            .CLG_BRANCH_CODE;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).CLG_PRODUCT_CODE := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                             .CLG_PRODUCT_CODE;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).CHQ_INSTRUMENT_DATE := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                                .CHQ_INSTRUMENT_DATE;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).DRAWEE_AC_NO := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                         .DRAWEE_AC_NO;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).ROUTING_NO := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                       .ROUTING_NO;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).REDEM_REF_NO := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                         .REDEM_REF_NO;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).CLEARING_REF_NO := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                            .CLEARING_REF_NO;
        P_WRK_ICDREDMN.V_ICTMS_TDREDPAYIN_DETAILS(L_IDX).CHQ_AVL_DATE := ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN(M)
                                                                         .CHQ_AVL_DATE;
        L_IDX := L_IDX + 1;
      END LOOP;
    END IF;
  
    DBG('Re populating the bc payout details');
  
    IF P_TY_BCPAYOUTDETS.BANKCODE IS NOT NULL THEN
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BRN          := P_TY_BCPAYOUTDETS.BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.ACC          := P_TY_BCPAYOUTDETS.ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CCY          := P_TY_BCPAYOUTDETS.CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.REF_NO       := P_TY_BCPAYOUTDETS.REF_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.REDEM_REF_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.SCODE        := P_TY_BCPAYOUTDETS.SCODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.XREF         := P_TY_BCPAYOUTDETS.XREF;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.MICR_NO      := P_TY_BCPAYOUTDETS.MICR_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.TRN_DT       := P_TY_BCPAYOUTDETS.TRN_DT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BANKCODE     := P_TY_BCPAYOUTDETS.BANKCODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHQ_AMT      := P_TY_BCPAYOUTDETS.CHQ_AMT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHQ_CCY      := P_TY_BCPAYOUTDETS.CHQ_CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHQ_DATE     := P_TY_BCPAYOUTDETS.CHQ_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.XRATE        := P_TY_BCPAYOUTDETS.XRATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.PAYBRN       := P_TY_BCPAYOUTDETS.PAYBRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.WAVE_PENALTY := P_TY_BCPAYOUTDETS.WAVE_PENALTY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHARGES      := P_TY_BCPAYOUTDETS.CHARGES;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BENFNAME     := P_TY_BCPAYOUTDETS.BENFNAME;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BENFADD1     := P_TY_BCPAYOUTDETS.BENFADD1;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BENFADD2     := P_TY_BCPAYOUTDETS.BENFADD2;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.BENFADD3     := P_TY_BCPAYOUTDETS.BENFADD3;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.OTHERDETS    := P_TY_BCPAYOUTDETS.OTHERDETS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.NARRATIVE    := P_TY_BCPAYOUTDETS.NARRATIVE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.COUNTRY_CODE := P_TY_BCPAYOUTDETS.COUNTRY_CODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_BC.CHQ_PERCENT  := P_TY_BCPAYOUTDETS.CHQ_PERCENT;
    END IF;
    DBG('Re populating the pc payout details');
    IF P_TY_PCPAYOUTDETS.PCBANKCODE IS NOT NULL THEN
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.BRN            := P_TY_PCPAYOUTDETS.BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.ACC            := P_TY_PCPAYOUTDETS.ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.CCY            := P_TY_PCPAYOUTDETS.CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCBANKCODE     := P_TY_PCPAYOUTDETS.PCBANKCODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCOFFSET_BRN   := P_TY_PCPAYOUTDETS.PCOFFSET_BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCOFFSET_ACC   := P_TY_PCPAYOUTDETS.PCOFFSET_ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCOFFSET_CCY   := P_TY_PCPAYOUTDETS.PCOFFSET_CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.BENFNAME       := P_TY_PCPAYOUTDETS.BENFNAME;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.BENFADD1       := P_TY_PCPAYOUTDETS.BENFADD1;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.BENFADD2       := P_TY_PCPAYOUTDETS.BENFADD2;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.OTHERDETS      := P_TY_PCPAYOUTDETS.OTHERDETS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.NARRATIVE      := P_TY_PCPAYOUTDETS.NARRATIVE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.CUSTBANKCODE   := P_TY_PCPAYOUTDETS.CUSTBANKCODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.CUSTACCNO      := P_TY_PCPAYOUTDETS.CUSTACCNO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.CGNEWTWORKCODE := P_TY_PCPAYOUTDETS.CGNEWTWORKCODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.TXNCCY         := P_TY_PCPAYOUTDETS.TXNCCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.TXNAMT         := P_TY_PCPAYOUTDETS.TXNAMT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.XRATE          := P_TY_PCPAYOUTDETS.XRATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.REFNO          := P_TY_PCPAYOUTDETS.REFNO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.REDEM_REF_NO   := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_PC.PCPERCENTAGE   := P_TY_PCPAYOUTDETS.PCPERCENTAGE;
    END IF;
    DBG('Populating the customer account details ');
  
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS IS NOT NULL THEN
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.JOINT_AC_INDICATOR := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.DR_GL              := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_NO            := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CUST_AC_NO         := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CR_GL              := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.CCY                := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.BRANCH_CODE        := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.ALT_AC_NO          := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.AC_OPEN_DATE       := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.AC_DESC            := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.ACCOUNT_TYPE       := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.ACCOUNT_CLASS      := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_BY_TD.REDEM_REF_NO       := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
    END IF;
    DBG('Populating the ictb_redem_acc values ');
    IF P_STDCUSAC.V_ICTMS_ACC.ACC IS NOT NULL THEN
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BRN                      := P_STDCUSAC.V_ICTMS_ACC.BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ACC                      := P_STDCUSAC.V_ICTMS_ACC.ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.REDEM_REF_NO             := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CALC_ACC                 := P_STDCUSAC.V_ICTMS_ACC.CALC_ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BOOK_ACC                 := P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.HAS_IS                   := P_STDCUSAC.V_ICTMS_ACC.HAS_IS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.INT_START_DATE           := P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.LAST_IS_DATE             := P_STDCUSAC.V_ICTMS_ACC.LAST_IS_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ACC_TYPE                 := P_STDCUSAC.V_ICTMS_ACC.ACC_TYPE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BOOK_BRN                 := P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.AUTO_ROLLOVER            := P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CLOSE_ON_MATURITY        := P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.MOVE_INT_TO_UNCLAIMED    := P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.MOVE_PRIC_TO_UNCLAIMED   := P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.MATURITY_DATE            := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.PRINC_LIQ_AC             := P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ROLLOVER_TYPE            := P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ROLLOVER_AMT             := P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.PRINC_LIQ_BRANCH         := P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.NEXT_MATURITY_DATE       := P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BOOK_CCY                 := P_STDCUSAC.V_ICTMS_ACC.BOOK_CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.HAS_DRCR_ADV             := P_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_FLAG                  := P_STDCUSAC.V_ICTMS_ACC.RD_FLAG;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_AUTO_PMNT_TAKEDOWN    := P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_MOVE_MAT_TO_UNCLAIMED := P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_MOVE_FUNDS_ON_OVD     := P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_TAKEDOWN_DAYS         := P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_TAKEDOWN_MONTHS       := P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_TAKEDOWN_YEARS        := P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_PAYMENT_ACC           := P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_PAYMENT_BRN           := P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_PAYMENT_CCY           := P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_INSTALLMENT_AMT       := P_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.RD_PAY_SCHDT             := P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CHARGE_BOOK_BRN          := P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CHARGE_BOOK_ACC          := P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CHARGE_BOOK_CCY          := P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.OVERRIDE_AMT_BLOCK       := P_STDCUSAC.V_ICTMS_ACC.OVERRIDE_AMT_BLOCK;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.CHG_START_DATE           := P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.BVT_DATE                 := P_STDCUSAC.V_ICTMS_ACC.BVT_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.COMBVT_DATE              := P_STDCUSAC.V_ICTMS_ACC.COMBVT_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.TENOR_CODE               := P_STDCUSAC.V_ICTMS_ACC.TENOR_CODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.AUTO_EXTENSION           := P_STDCUSAC.V_ICTMS_ACC.AUTO_EXTENSION;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.LIQUIDATION_AMT          := P_STDCUSAC.V_ICTMS_ACC.LIQUIDATION_AMT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.LAST_ROLLOVER_DATE       := P_STDCUSAC.V_ICTMS_ACC.LAST_ROLLOVER_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC.ALLOW_PREPAYMENT         := P_STDCUSAC.V_ICTMS_ACC.ALLOW_PREPAYMENT;
    END IF;
    DBG('Populating the ictb acc pr details');
    IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
      FOR I IN P_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).BRN := P_STDCUSAC.V_ICTMS_ACC_PR(I).BRN;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).ACC := P_STDCUSAC.V_ICTMS_ACC_PR(I).ACC;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).REDEM_REF_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).PROD := P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).WAIVE := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                    .WAIVE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).GEN_UCA := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                      .GEN_UCA;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).RECORD_STAT := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                          .RECORD_STAT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).ONCE_AUTH := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                        .ONCE_AUTH;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).UDE_CCY := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                      .UDE_CCY;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).MIN_AMT := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                      .MIN_AMT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).MAX_AMT := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                      .MAX_AMT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).FREE_TXN := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                       .FREE_TXN;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_PR(I).CONT_VAR_ROLL := P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                                                            .CONT_VAR_ROLL;
      
      END LOOP;
    END IF;
    DBG('Populating the ictb acc pr effdt details');
    IF P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT.COUNT > 0 THEN
      FOR I IN P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT.FIRST .. P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT.LAST LOOP
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).BRN := P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).BRN;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).ACC := P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ACC;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).REDEM_REF_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).PROD := P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).PROD;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).UDE_EFF_DT := P_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
                                                                            .UDE_EFF_DT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).RECORD_STAT := P_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
                                                                             .RECORD_STAT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_EFFDT(I).ONCE_AUTH := P_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
                                                                           .ONCE_AUTH;
      END LOOP;
    END IF;
    DBG('Populating the values in ictb acc udevals');
    IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
      FOR I IN P_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).BRN := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BRN;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).REDEM_REF_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).ACC := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).ACC;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).PROD := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).PROD;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).UDE_EFF_DT := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                              .UDE_EFF_DT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).UDE_ID := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                          .UDE_ID;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).UDE_VALUE := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                             .UDE_VALUE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).RATE_CODE := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                             .RATE_CODE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).AUTH_STAT := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                             .AUTH_STAT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).RECORD_STAT := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                               .RECORD_STAT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).BASE_RATE := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                             .BASE_RATE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).BASE_SPREAD := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                               .BASE_SPREAD;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).TD_RATE_CODE := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                                .TD_RATE_CODE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_ACC_UDEVALS(I).UDE_VARIANCE := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                                                                .UDE_VARIANCE;
      END LOOP;
    END IF;
  
    IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
      DBG('Coming here ' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
      FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).REDEM_REF_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).BRN := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BRN;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).ACC := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).ACC;
        DBG('Child td payout account is ' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).ACC);
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).CCY := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).PAYOUTTYPE := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                .PAYOUTTYPE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).BANKCODE := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                              .BANKCODE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).OFFSET_BRN := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                .OFFSET_BRN;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).OFFSET_ACC := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                .OFFSET_ACC;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).OFFSET_CCY := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                .OFFSET_CCY;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).PERCENTAGE := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                .PERCENTAGE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).REDMAMT := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                             .REDMAMT;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).BENFNAME := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                              .BENFNAME;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).BENFADD1 := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                              .BENFADD1;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).BENFADD2 := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                              .BENFADD2;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).OTHERDETS := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                               .OTHERDETS;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).NARRATIVE := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                               .NARRATIVE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).XRATE := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                           .XRATE;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).REF_NO := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                            .REF_NO;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).SEQNO := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                           .SEQNO;
        P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDTDPAYOUT(I).PAYOUT_COMPONENT := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                      .PAYOUT_COMPONENT;
      END LOOP;
    END IF;
  
    IF P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE IS NOT NULL THEN
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.REDEM_REF_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.BRN          := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.ACC          := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.CCY          := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCBANKCODE   := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCOFFSET_BRN := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCOFFSET_ACC := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCOFFSET_CCY := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.PCPERCENTAGE := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCPERCENTAGE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.BENFNAME     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFNAME;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.BENFADD1     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD1;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.BENFADD2     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD2;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.OTHERDETS    := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.OTHERDETS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.NARRATIVE    := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.NARRATIVE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.XRATE        := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.XRATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDPCPAYOUT.REFNO        := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.REFNO;
    
    END IF;
  
    IF P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE IS NOT NULL THEN
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.REDEM_REF_NO := P_TY_TDVWS_TD_REDEMPTION.REDEM_REF_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BRN          := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.ACC          := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.ACC;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CCY          := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.REF_NO       := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.REF_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.SCODE        := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.SCODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.XREF         := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XREF;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.MICR_NO      := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.MICR_NO;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.TRN_DT       := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.TRN_DT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BANKCODE     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHQ_AMT      := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_AMT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHQ_CCY      := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_CCY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHQ_DATE     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_DATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHQ_PERCENT  := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_PERCENT;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.XRATE        := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XRATE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.PAYBRN       := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.PAYBRN;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.WAVE_PENALTY := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.WAVE_PENALTY;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.CHARGES      := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHARGES;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BENFNAME     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFNAME;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BENFADD1     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD1;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BENFADD2     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD2;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.BENFADD3     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD3;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.OTHERDETS    := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.OTHERDETS;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.NARRATIVE    := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.NARRATIVE;
      P_WRK_ICDREDMN.TY_ICCREFPO.V_ICTBS_REDEM_CHILDBCPAYOUT.COUNTRY_CODE := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.COUNTRY_CODE;
    END IF;
    DBG('Returning success from fn_def_wrk_icdredmn');
  
    DBG('Returning success from fn_def_wrk_icdredmn');
  
    RETURN TRUE;
  END FN_DEF_WRK_ICDREDMN;

END ICPKS_ICDREDMN_KERNEL;
