create table ICTB_TD_REDEM_MASTER_CUSTOM
(
  redem_ref_no        VARCHAR2(16),
  branch_code         VARCHAR2(3),
  acc_no              VARCHAR2(20),
  cust_id             VARCHAR2(9),
  waive_insurance_fee CHAR(1),
  insurance_amount    NUMBER
)
/
alter table ICTB_TD_REDEM_MASTER_CUSTOM add primary key (REDEM_REF_NO)
/