insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CLEVER_SAVINGS_INT_DAYS', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SAMPATH1', to_date('16-12-2016', 'dd-mm-yyyy'), 'SAMPATH2', to_date('16-12-2016', 'dd-mm-yyyy'), 'TRACK DAYS TO CALCULATE PENALTY CORRECTLY', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CLEVER_SAVINGS_TOPUP_AMT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Top Up of all amounts done for the month', null, 'N', null, 'N');

COMMIT;
