insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'INTEREST_RATE_2Y', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'INTEREST_RATE_3Y', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'SLAB_1', 'N', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'TAX_RATE', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'TOPUP_EXTRA_RAT2', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'TOPUP_EXTRA_RAT3', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'INTEREST_RATE_1Y', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'INTEREST_RATE_2Y', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'INTEREST_RATE_3Y', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'SLAB_1', 'N', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'SLAB_2', 'N', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'SLAB_3', 'N', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'TAX_RATE', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'TOPUP_EXTRA_RAT1', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'TOPUP_EXTRA_RAT2', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'TOPUP_EXTRA_RAT3', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLR1', 'INTEREST_RATE_3Y', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLR1', 'SLAB_1', 'N', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLR1', 'TAX_RATE', 'R', 'N');

insert into ICTM_RULE_UDE (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLR1', 'TOPUP_EXTRA_RAT3', 'R', 'N');

COMMIT;
