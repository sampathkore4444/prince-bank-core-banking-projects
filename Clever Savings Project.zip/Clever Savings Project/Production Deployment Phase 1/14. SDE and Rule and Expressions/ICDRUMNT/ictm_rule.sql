insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CLE2', 'CREDIT INTEREST - TD - TENOR SLAB', null, 'O', 'A', 'Y', 6, 'SAMPATH2', to_date('08-02-2023 11:20:58', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('08-02-2023 11:22:19', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CLE3', 'CREDIT INTEREST - TD - TENOR SLAB', null, 'O', 'A', 'Y', 10, 'CSOTTHORN', to_date('08-02-2023 16:16:34', 'dd-mm-yyyy hh24:mi:ss'), 'OPERATOR4', to_date('08-02-2023 16:17:52', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CLR1', 'CREDIT INTEREST - TD - TENOR SLAB', null, 'O', 'A', 'Y', 2, 'SAMPATH2', to_date('08-02-2023 10:54:42', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('08-02-2023 10:55:28', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

COMMIT;
