insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE2', 'CLEVER_SAVINGS_INT_DAYS');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE2', 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE2', 'DAYS');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE2', 'DEPOSIT_AMOUNT');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE2', 'YEAR');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE3', 'CLEVER_SAVINGS_INT_DAYS');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE3', 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE3', 'CLEVER_SAVINGS_TOPUP_TODAY');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE3', 'DAYS');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE3', 'DEPOSIT_AMOUNT');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLE3', 'YEAR');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLR1', 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLR1', 'DAYS');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLR1', 'DEPOSIT_AMOUNT');

insert into ICTM_RULE_SDE (RULE_ID, SDE_ID)
values ('CLR1', 'YEAR');

COMMIT;
