insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('SY02', 'SY02', 'USD', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'OPERATOR4', 'CSOTTHORN', to_date('08-02-2023 16:05:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 16:05:59', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('SY01', 'SY01', 'KHR', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'OPERATOR4', 'CSOTTHORN', to_date('08-02-2023 16:13:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 16:13:56', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('GY02', 'GY02', 'USD', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 11:44:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 11:44:06', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('GY01', 'GY01', 'KHR', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 11:43:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 11:43:43', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('RY01', 'RY01', 'USD', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:57:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:57:43', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('RY01', 'RY01', 'KHR', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:57:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:57:58', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('RY02', 'RY02', 'KHR', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:58:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:58:11', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('GY01', 'GY01', 'USD', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 11:43:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 11:43:50', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('GY02', 'GY02', 'KHR', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 11:44:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 11:44:01', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('RY02', 'RY02', 'USD', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:58:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:58:21', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('SY01', 'SY01', 'USD', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'OPERATOR4', 'CSOTTHORN', to_date('08-02-2023 16:05:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 16:06:18', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('SY02', 'SY02', 'KHR', to_date('08-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'OPERATOR4', 'CSOTTHORN', to_date('08-02-2023 16:05:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 16:06:27', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

COMMIT;
