CREATE OR REPLACE PACKAGE BODY STPKS_DIGITAL_UTLITIES IS

FUNCTION FN_DELETE_SPL_ACC_NO(P_ACC_NO IN VARCHAR2, P_BRN_NO IN VARCHAR2)
    RETURN NUMBER IS

    PRAGMA AUTONOMOUS_TRANSACTION;

    l_count number;

  BEGIN

    DELETE FROM P1FCHPRFM.STTM_CUST_RANGE_DETAIL
     WHERE start_range = P_ACC_NO
       AND branch_code = P_BRN_NO;

    COMMIT;

    RETURN 1; --success

  EXCEPTION

    WHEN OTHERS THEN
      ROLLBACK;
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'FAILED IN FN_UPDATE_SPL_ACC_NO');
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'ERROR CODE=' || SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'ERROR MESSAGE=' || SQLERRM);

      RETURN 0;

  END FN_DELETE_SPL_ACC_NO;

FUNCTION FN_UPDATE_SPL_ACC_NO(P_ACC_NO IN VARCHAR2, P_BRN_NO IN VARCHAR2)
    RETURN NUMBER IS

    PRAGMA AUTONOMOUS_TRANSACTION;

    l_count number;

  BEGIN

    select count(1)
      into l_count
      from P1FCHPRFM.STTM_CUST_RANGE_DETAIL
     where start_range = P_ACC_NO;

    if l_count > 0 then

      return 2;

    end if;

    INSERT INTO P1FCHPRFM.STTM_CUST_RANGE_DETAIL
    VALUES
      (P_BRN_NO, 'A', P_ACC_NO, P_ACC_NO);

    COMMIT;

    RETURN 1;

  EXCEPTION

    WHEN OTHERS THEN
      ROLLBACK;
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'FAILED IN FN_UPDATE_SPL_ACC_NO');
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'ERROR CODE=' || SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'ERROR MESSAGE=' || SQLERRM);

      RETURN 0;

  END FN_UPDATE_SPL_ACC_NO;

  FUNCTION FN_GET_RFT_UNIQUE_NO_1(P_REF_NO IN VARCHAR2)
    RETURN P1FCHPRFM.cstm_contract_userdef_fields.FIELD_VAL_4%TYPE IS

    L_UNIQUE_NO_1 P1FCHPRFM.cstm_contract_userdef_fields.FIELD_VAL_4%TYPE;

  BEGIN

    SELECT FIELD_VAL_4
      INTO L_UNIQUE_NO_1
      FROM P1FCHPRFM.cstm_contract_userdef_fields
     WHERE CONTRACT_REF_NO = P_REF_NO;

    RETURN L_UNIQUE_NO_1;

  EXCEPTION

    WHEN OTHERS THEN
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'FAILED TO FN_GET_RFT_UNIQUE_NO_1');
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'ERROR CODE=' || SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'ERROR MESSAGE=' || SQLERRM);

      RETURN 0;

  END;

  FUNCTION FN_UPDATE_RFT_UNIQUE_NO_2(P_REF_NO      IN VARCHAR2,
                                     P_UNIQUE_NO_2 IN VARCHAR2) RETURN NUMBER IS

    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    UPDATE P1FCHPRFM.CSTM_CONTRACT_USERDEF_FIELDS
       SET FIELD_VAL_5 = P_UNIQUE_NO_2
     WHERE CONTRACT_REF_NO = P_REF_NO;

    COMMIT;

    RETURN 1;

  EXCEPTION

    WHEN OTHERS THEN
      ROLLBACK;
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'FAILED TO UPDATE UNIQUE NO 2 FOR RFT TXN FROM MOBILE');
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'ERROR CODE=' || SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'ERROR MESSAGE=' || SQLERRM);

      RETURN 0;

  END;

  PROCEDURE PR_GET_ACCOUNT_DETAILS(P_ACC_NO      IN VARCHAR2,
                                   P_ACC_DETAILS OUT SYS_REFCURSOR) IS

  BEGIN
    IF P_ACC_NO IS NOT NULL THEN
      OPEN P_ACC_DETAILS FOR
        SELECT *
          FROM STVW_GET_ACC_DTLS_DIG
         WHERE ACCOUNT_NUMBER = P_ACC_NO;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_ACC_DETAILS := NULL;
  END PR_GET_ACCOUNT_DETAILS;

  PROCEDURE PR_GET_TRN_DETAILS(P_ACC_NO      IN VARCHAR2,
                               P_TRN_DETAILS OUT SYS_REFCURSOR) IS

  BEGIN
    IF P_ACC_NO IS NOT NULL THEN
      OPEN P_TRN_DETAILS FOR
        SELECT *
          FROM STVW_GET_TRN_DTLS_DIG
         WHERE ACCOUNT_NUMBER = P_ACC_NO
        --AND EVENT NOT IN ('CYPO','REVL')
         ORDER BY AC_ENTRY_SR_NO DESC;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_TRN_DETAILS := NULL;
  END PR_GET_TRN_DETAILS;

  FUNCTION fn_calc_int(p_amt      IN NUMBER,
                       p_int_rate IN NUMBER,
                       p_tenor    IN NUMBER) RETURN NUMBER AS
    l_int_amount NUMBER;
  BEGIN
    ----dbg('In Fn_calc_int');
    l_int_amount := p_amt * p_int_rate * (p_tenor / 365) / 100;
    ----dbg('l_Int_Amount = ' || l_int_amount);
    RETURN ROUND(l_int_amount, 2);
  EXCEPTION
    WHEN OTHERS THEN
      l_int_amount := 0;
      RETURN 0;
  END fn_calc_int;

  FUNCTION FN_CALC_TAX(P_INT_AMOUNT IN NUMBER,
                       P_ACC        IN VARCHAR2,
                       P_BRN        IN VARCHAR2) RETURN NUMBER AS
    l_tax_amount NUMBER;
  BEGIN
    ----dbg('In Fn_calc_int');
    l_tax_amount := P_INT_AMOUNT * fn_get_tax_rate(P_ACC, P_BRN) / 100;
    ----dbg('l_tax_amount = ' || l_tax_amount);
    RETURN ROUND(l_tax_amount, 2);
  EXCEPTION
    WHEN OTHERS THEN
      l_tax_amount := 0;
      RETURN 0;
  END FN_CALC_TAX;

  FUNCTION fn_get_tax_rate(p_acc IN VARCHAR2, p_brn IN VARCHAR2)
    RETURN NUMBER IS
    l_tax_rate NUMBER;
  BEGIN
    ----dbg('In Fn_Get_Tax_Rate');

    SELECT ude_value
      INTO l_tax_rate
      FROM P1FCHPRFM.ictm_acc_udevals a
     WHERE acc = p_acc
       AND brn = p_brn
       AND ude_id LIKE '%TAX_RATE%'
       AND ude_eff_dt = (SELECT MAX(ude_eff_dt)
                           FROM P1FCHPRFM.ictm_acc_udevals
                          WHERE acc = a.acc
                            AND brn = a.brn
                            AND ude_id LIKE a.ude_id
                            AND auth_stat = 'A'
                            AND record_stat = 'O')
       AND auth_stat = 'A'
       AND record_stat = 'O';

    --dbg('l_Tax_Rate = ' || l_tax_rate);
    RETURN l_tax_rate;
  EXCEPTION
    WHEN OTHERS THEN
      l_tax_rate := 0;
      RETURN l_tax_rate;
  END fn_get_tax_rate;
  
  --Clever Savings Sampath Starts

  FUNCTION FN_GET_INT_TOPUP_RATE_CLEVER_SAVINGS(P_ACC   IN VARCHAR2,
                                                P_BRN   IN VARCHAR2,
                                                P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE IS
  
    TYPE T IS TABLE OF P1FCHPRFM.ICTMS_PR_INT_UDEVALS%ROWTYPE;
    V T;
  
    L_CUST_ACC P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
  
    CURSOR C1(P_ACC_CLASS P1FCHPRFM.ICTMS_PR_INT_UDEVALS.ACLASS%TYPE,
              P_PROD      P1FCHPRFM.ICTMS_PR_INT_UDEVALS.PRODUCT_CODE%TYPE,
              P_CCY       P1FCHPRFM.ICTMS_PR_INT_UDEVALS.CCY_CODE%TYPE) IS
      SELECT *
        FROM P1FCHPRFM.ICTMS_PR_INT_UDEVALS
       WHERE ACLASS = P_ACC_CLASS
         AND PRODUCT_CODE = P_PROD
         AND CCY_CODE = P_CCY;
  
    L_SLAB1 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB2 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB3 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
  
    L_TOPUP_RATE1 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_TOPUP_RATE2 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_TOPUP_RATE3 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
  
    L_UDE_ID    P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    L_UDE_VALUE P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_PROD      VARCHAR2(4);
    L_RATE      VARCHAR2(24);
    L_RULE      VARCHAR2(10);
  BEGIN
  
    BEGIN
      SELECT prod
        INTO l_prod
        FROM P1FCHPRFM.ictm_acc_pr
       WHERE acc = p_acc
         AND brn = p_brn;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('Unable to get product for ' || p_acc ||
        --' in fn_get_rate_code , returning xxx');
        l_rate := 'xxx';
        RETURN l_rate;
    END;
  
    --dbg('l_prod = ' || l_prod);
  
    IF l_prod <> 'xxx' THEN
      BEGIN
        SELECT rule
          INTO l_rule
          FROM P1FCHPRFM.ictms_pr_int
         WHERE product_code = l_prod;
      EXCEPTION
        WHEN OTHERS THEN
          --dbg('Unable to find the rule , returning xxx');
          l_rate := 'xxx';
          RETURN l_rate;
      END;
    END IF;
  
    --dbg('l_rule = ' || l_rule);
  
    --Get Account Information
    BEGIN
      SELECT *
        INTO L_CUST_ACC
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_CUST_ACC := NULL;
    END;
  
    OPEN C1(L_CUST_ACC.ACCOUNT_CLASS, l_prod, L_CUST_ACC.CCY);
  
    FETCH C1 BULK COLLECT
      INTO V;
    CLOSE C1;
  
    IF L_CUST_ACC.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN
      FOR G IN V.FIRST .. V.LAST LOOP
        IF V(G).UDE_ID = 'SLAB_1' THEN
          L_SLAB1 := V(G).UDE_VALUE;
        ELSIF V(G).UDE_ID = 'SLAB_2' THEN
          L_SLAB2 := V(G).UDE_VALUE;
        ELSIF V(G).UDE_ID = 'SLAB_3' THEN
          L_SLAB3 := V(G).UDE_VALUE;
        ELSIF V(G).UDE_ID = 'TOPUP_EXTRA_RAT1' THEN
          L_TOPUP_RATE1 := V(G).UDE_VALUE;
        ELSIF V(G).UDE_ID = 'TOPUP_EXTRA_RAT2' THEN
          L_TOPUP_RATE2 := V(G).UDE_VALUE;
        ELSIF V(G).UDE_ID = 'TOPUP_EXTRA_RAT3' THEN
          L_TOPUP_RATE3 := V(G).UDE_VALUE;
        END IF;
      
      END LOOP;
    
      IF P_TENOR >= 0 AND P_TENOR <= L_SLAB1 THEN
        L_UDE_VALUE := L_TOPUP_RATE1;
      ELSIF P_TENOR > L_SLAB1 AND P_TENOR <= L_SLAB2 THEN
        L_UDE_VALUE := L_TOPUP_RATE2;
      ELSE
        L_UDE_VALUE := L_TOPUP_RATE3;
      END IF;
    
    END IF;
  
    IF L_CUST_ACC.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN
      FOR G IN V.FIRST .. V.LAST LOOP
        IF V(G).UDE_ID = 'SLAB_1' THEN
          L_SLAB1 := V(G).UDE_VALUE;
        
        ELSIF V(G).UDE_ID = 'TOPUP_EXTRA_RAT2' THEN
          L_TOPUP_RATE2 := V(G).UDE_VALUE;
        ELSIF V(G).UDE_ID = 'TOPUP_EXTRA_RAT3' THEN
          L_TOPUP_RATE3 := V(G).UDE_VALUE;
        END IF;
      
      END LOOP;
    
      IF P_TENOR >= 0 AND P_TENOR <= L_SLAB1 THEN
        L_UDE_VALUE := L_TOPUP_RATE2;
      
      ELSE
        L_UDE_VALUE := L_TOPUP_RATE3;
      END IF;
    
    END IF;
  
    IF L_CUST_ACC.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN
      FOR G IN V.FIRST .. V.LAST LOOP
        IF V(G).UDE_ID = 'SLAB_1' THEN
          L_SLAB1 := V(G).UDE_VALUE;
        
        ELSIF V(G).UDE_ID = 'TOPUP_EXTRA_RAT3' THEN
          L_TOPUP_RATE3 := V(G).UDE_VALUE;
        END IF;
      
      END LOOP;
    
      IF P_TENOR >= 0 AND P_TENOR <= 366 /*L_SLAB1*/ THEN
      
        L_UDE_VALUE := L_TOPUP_RATE3;
      END IF;
    
    END IF;
  
    --dbg('L_UDE_ID=' || L_UDE_ID);
  
    RETURN L_UDE_VALUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_UDE_VALUE;
  END FN_GET_INT_TOPUP_RATE_CLEVER_SAVINGS;

  FUNCTION FN_GET_RATE_CODE_CUSTOM_CLEVER_SAVINGS(P_ACC   IN VARCHAR2,
                                                  P_BRN   IN VARCHAR2,
                                                  P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE IS
  
    TYPE T IS TABLE OF P1FCHPRFM.ICTMS_PR_INT_UDEVALS%ROWTYPE;
    V T;
  
    L_CUST_ACC P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
  
    CURSOR C1(P_ACC_CLASS P1FCHPRFM.ICTMS_PR_INT_UDEVALS.ACLASS%TYPE,
              P_PROD      P1FCHPRFM.ICTMS_PR_INT_UDEVALS.PRODUCT_CODE%TYPE,
              P_CCY       P1FCHPRFM.ICTMS_PR_INT_UDEVALS.CCY_CODE%TYPE) IS
      SELECT *
        FROM P1FCHPRFM.ICTMS_PR_INT_UDEVALS
       WHERE ACLASS = P_ACC_CLASS
         AND PRODUCT_CODE = P_PROD
         AND CCY_CODE = P_CCY;
  
    L_SLAB1 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB2 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB3 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
  
    L_UDE_ID P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    L_PROD   VARCHAR2(4);
    L_RATE   VARCHAR2(24);
    L_RULE   VARCHAR2(10);
  BEGIN
  
    BEGIN
      SELECT prod
        INTO l_prod
        FROM P1FCHPRFM.ictm_acc_pr
       WHERE acc = p_acc
         AND brn = p_brn;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('Unable to get product for ' || p_acc ||
        --' in fn_get_rate_code , returning xxx');
        l_rate := 'xxx';
        RETURN l_rate;
    END;
  
    --dbg('l_prod = ' || l_prod);
  
    IF l_prod <> 'xxx' THEN
      BEGIN
        SELECT rule
          INTO l_rule
          FROM P1FCHPRFM.ictms_pr_int
         WHERE product_code = l_prod;
      EXCEPTION
        WHEN OTHERS THEN
          --dbg('Unable to find the rule , returning xxx');
          l_rate := 'xxx';
          RETURN l_rate;
      END;
    END IF;
  
    --dbg('l_rule = ' || l_rule);
  
    --Get Account Information
    BEGIN
      SELECT *
        INTO L_CUST_ACC
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_CUST_ACC := NULL;
    END;
  
    OPEN C1(L_CUST_ACC.ACCOUNT_CLASS, l_prod, L_CUST_ACC.CCY);
  
    FETCH C1 BULK COLLECT
      INTO V;
    CLOSE C1;
  
    FOR G IN V.FIRST .. V.LAST LOOP
      IF V(G).UDE_ID = 'SLAB_1' THEN
        L_SLAB1 := V(G).UDE_VALUE;
        --EXIT;
      ELSIF V(G).UDE_ID = 'SLAB_2' THEN
        L_SLAB2 := V(G).UDE_VALUE;
        --EXIT;
      ELSIF V(G).UDE_ID = 'SLAB_3' THEN
        L_SLAB3 := V(G).UDE_VALUE;
        --EXIT;
      END IF;
    
    END LOOP;
  
    dbms_output.put_line('L_SLAB1=' || L_SLAB1);
    dbms_output.put_line('L_SLAB2=' || L_SLAB2);
    dbms_output.put_line('L_SLAB3=' || L_SLAB3);
  
    dbms_output.put_line('P_TENOR=' || P_TENOR);
  
    IF L_CUST_ACC.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN
    
      IF P_TENOR >= 0 AND P_TENOR <= 366 THEN--L_SLAB1 THEN
        L_UDE_ID := 'INTEREST_RATE_3Y';
      
      END IF;
    
    ELSIF L_CUST_ACC.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN
    
      IF P_TENOR >= 0 AND P_TENOR <= L_SLAB1 THEN
        L_UDE_ID := 'INTEREST_RATE_2Y';
      ELSE
        L_UDE_ID := 'INTEREST_RATE_3Y';
      END IF;
    
    ELSE
    
      IF P_TENOR >= 0 AND P_TENOR <= L_SLAB1 THEN
        L_UDE_ID := 'INTEREST_RATE_1Y';
      ELSIF P_TENOR > L_SLAB1 AND P_TENOR <= L_SLAB2 THEN
        L_UDE_ID := 'INTEREST_RATE_2Y';
      ELSE
        L_UDE_ID := 'INTEREST_RATE_3Y';
      END IF;
    
    END IF;
  
    --dbg('L_UDE_ID=' || L_UDE_ID);
    dbms_output.put_line('L_UDE_ID=' || L_UDE_ID);
  
    RETURN L_UDE_ID;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END FN_GET_RATE_CODE_CUSTOM_CLEVER_SAVINGS;

  FUNCTION fn_get_int_rate_CLEVER_SAVINGS_FOR_HIST_MB(p_acc IN VARCHAR2,
                                                      p_brn IN VARCHAR2)
    RETURN NUMBER IS
    l_int_rate   NUMBER;
    l_rule       NUMBER;
    l_rate       P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    l_tenor      NUMBER := 0;
    rec_ictm_acc P1FCHPRFM.ictm_acc%ROWTYPE;
  BEGIN
    --dbg('In Fn_Get_Int_Rate');
  
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc
       WHERE acc = p_acc
         AND brn = p_brn;
    
      P1FCHPRFM.GLOBAL.pr_init(rec_ictm_acc.brn, 'SYSTEM');
    
      SELECT ABS(rec_ictm_acc.int_start_date -
                 P1FCHPRFM.GLOBAL.application_date /* rec_ictm_acc.maturity_date*/)
        INTO l_tenor
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('unable to find the Ictm_Acc for ' || p_acc || '~' || p_brn);
        --dbg('Setting int rate to 0');
        dbms_output.put_line('Setting int rate to 0');
        l_int_rate := 0;
        RETURN l_int_rate;
    END;
  
    --dbg('l_Tenor =' || l_tenor);
    dbms_output.put_line('l_tenor=' || l_tenor);
  
    IF l_tenor >= 0 THEN
      --l_rate := fn_get_rate_code(p_acc, p_brn, l_tenor); sampath commented
    
      l_rate := FN_GET_RATE_CODE_CUSTOM_CLEVER_SAVINGS(p_acc,
                                                       p_brn,
                                                       l_tenor);
      --dbg('Got rate code as ' || l_rate);
    
      BEGIN
        SELECT ude_value
          INTO l_int_rate
          FROM P1FCHPRFM.ictm_acc_udevals a
         WHERE acc = p_acc
           AND brn = p_brn
           AND ude_id = l_rate
           AND ude_eff_dt = (SELECT MAX(ude_eff_dt)
                               FROM P1FCHPRFM.ictm_acc_udevals
                              WHERE acc = a.acc
                                AND brn = a.brn
                                AND ude_id = a.ude_id);
      EXCEPTION
        WHEN OTHERS THEN
          --dbg('Failed to get the value for ' || l_rate);
          --dbg('Setting int_rate to 0');
          l_int_rate := 0;
      END;
    
      RETURN l_int_rate;
    ELSE
    
      RETURN 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      l_int_rate := 0;
      RETURN l_int_rate;
  END fn_get_int_rate_CLEVER_SAVINGS_FOR_HIST_MB;

  FUNCTION fn_get_int_rate_CLEVER_SAVINGS(p_acc IN VARCHAR2,
                                          p_brn IN VARCHAR2) RETURN NUMBER IS
    l_int_rate   NUMBER;
    l_rule       NUMBER;
    l_rate       P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    l_tenor      NUMBER := 0;
    rec_ictm_acc P1FCHPRFM.ictm_acc%ROWTYPE;
  BEGIN
    --dbg('In Fn_Get_Int_Rate');
  
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc
       WHERE acc = p_acc
         AND brn = p_brn;
    
      --P1FCHPRFM.GLOBAL.pr_init(rec_ictm_acc.brn, 'SYSTEM');
    
      SELECT ABS(rec_ictm_acc.int_start_date -
                 P1FCHPRFM.GLOBAL.application_date /* rec_ictm_acc.maturity_date*/)
        INTO l_tenor
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('unable to find the Ictm_Acc for ' || p_acc || '~' || p_brn);
        --dbg('Setting int rate to 0');
        dbms_output.put_line('Setting int rate to 0');
        l_int_rate := 0;
        RETURN l_int_rate;
    END;
  
    --dbg('l_Tenor =' || l_tenor);
    dbms_output.put_line('l_tenor=' || l_tenor);
  
    IF l_tenor >= 0 THEN
      --l_rate := fn_get_rate_code(p_acc, p_brn, l_tenor); sampath commented
    
      l_rate := FN_GET_RATE_CODE_CUSTOM_CLEVER_SAVINGS(p_acc,
                                                       p_brn,
                                                       l_tenor);
      --dbg('Got rate code as ' || l_rate);
    
      BEGIN
        SELECT ude_value
          INTO l_int_rate
          FROM P1FCHPRFM.ictm_acc_udevals a
         WHERE acc = p_acc
           AND brn = p_brn
           AND ude_id = l_rate
           AND ude_eff_dt = (SELECT MAX(ude_eff_dt)
                               FROM P1FCHPRFM.ictm_acc_udevals
                              WHERE acc = a.acc
                                AND brn = a.brn
                                AND ude_id = a.ude_id);
      EXCEPTION
        WHEN OTHERS THEN
          --dbg('Failed to get the value for ' || l_rate);
          --dbg('Setting int_rate to 0');
          l_int_rate := 0;
      END;
    
      RETURN l_int_rate;
    ELSE
    
      RETURN 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      l_int_rate := 0;
      RETURN l_int_rate;
  END fn_get_int_rate_CLEVER_SAVINGS;

  PROCEDURE PR_RETURN_TD_DETAILS_CLEVER_SAVINGS(P_ACC            IN VARCHAR2,
                                                P_BRN            IN VARCHAR2,
                                                P_INT_RATE       OUT NUMBER,
                                                P_INT_AMT        OUT NUMBER,
                                                P_TAX_AMT        OUT NUMBER,
                                                P_MATURITY_AMT   OUT NUMBER,
                                                P_PLAN_NAME      OUT VARCHAR2,
                                                P_MON_TOPUP_RATE OUT NUMBER,
                                                P_MON_TOPUP_AMT  OUT NUMBER) IS
  
    L_STTM_CUST_ACCOUNT      P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    rec_ictm_acc             P1FCHPRFM.ictm_acc%ROWTYPE;
    l_tenor                  NUMBER := 0;
    L_ICTM_TD_DETAILS        P1FCHPRFM.ICTM_TD_DETAILS%ROWTYPE;
    L_CYTM_CCY_DEFN_MASTER   P1FCHPRFM.CYTM_CCY_DEFN_MASTER%ROWTYPE;
    L_ICTM_TD_DETAILS_CUSTOM P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM%ROWTYPE;
  
  BEGIN
  
    --get Branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    P1FCHPRFM.GLOBAL.pr_init(L_STTM_CUST_ACCOUNT.BRANCH_CODE, 'SYSTEM');
    P1FCHPRFM.CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') := 'ICDRDSIM';
  
    --get td information
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc
       WHERE acc = P_ACC
         AND brn = P_BRN; --L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    
      SELECT ABS(rec_ictm_acc.int_start_date - rec_ictm_acc.maturity_date)
        INTO l_tenor
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('Setting int rate to 0');
        P_INT_RATE := 0;
    END;
  
    --Get initial Deposit
    BEGIN
      SELECT *
        INTO L_ICTM_TD_DETAILS
        FROM P1FCHPRFM.ICTM_TD_DETAILS
       WHERE ACC = P_ACC
         AND BRN = P_BRN; --L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        L_ICTM_TD_DETAILS := NULL;
    END;
  
    P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'BEFORE CALLING INT RATE PR');
  
    --GET INTEREST RATE
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS NOT IN
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN
      --Added IF condtion Clever Savings
    
      P_INT_RATE := FN_GET_INT_RATE(P_ACC, P_BRN); --L_STTM_CUST_ACCOUNT.BRANCH_CODE);
    
    ELSE
      --Added ELSE condtion Clever Savings
    
      P_INT_RATE := FN_GET_INT_RATE_CLEVER_SAVINGS(P_ACC, P_BRN);
    
      --  L_STTM_CUST_ACCOUNT.BRANCH_CODE);
    
    END IF; --Added END IF condtion Clever Savings
  
    DBMS_OUTPUT.PUT_LINE('P_INT_RATE=' || P_INT_RATE);
  
    P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'AFTER CALLING INT RATE PR');
  
    --GET INTEREST AMOUNT
  
    PR_TD_INT_TAX_AMT(L_ICTM_TD_DETAILS, P_INT_AMT, P_TAX_AMT);
  
    P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'AFTER CALLING INTEREST=' || P_INT_AMT);
  
    --Maturity Amount
    P_MATURITY_AMT := NVL(L_ICTM_TD_DETAILS.TD_AMOUNT, 0) +
                      NVL(L_ICTM_TD_DETAILS.TOPUP_AMT, 0) -
                      NVL(L_ICTM_TD_DETAILS.REDEM_AMT, 0) +
                      (P_INT_AMT - P_TAX_AMT);
  
    DBMS_OUTPUT.PUT_LINE('P_MATURITY_AMT BEFORE ROUNDING=' ||
                         P_MATURITY_AMT);
  
    --Rounding Mechanism
    SELECT *
      INTO L_CYTM_CCY_DEFN_MASTER
      FROM P1FCHPRFM.CYTM_CCY_DEFN_MASTER
     WHERE CCY_CODE = L_STTM_CUST_ACCOUNT.CCY;
  
    P_MATURITY_AMT := P1FCHPRFM.ROUND_TO(P_MATURITY_AMT,
                                         L_CYTM_CCY_DEFN_MASTER.CCY_ROUND_UNIT);
  
    DBMS_OUTPUT.PUT_LINE('P_MATURITY_AMT AFTER ROUNDING=' ||
                         P_MATURITY_AMT);
  
    --plan name
    BEGIN
      SELECT ACCOUNT_CLASS || '-' || DESCRIPTION
        INTO P_PLAN_NAME
        FROM P1FCHPRFM.STTM_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS = L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS;
    EXCEPTION
      WHEN OTHERS THEN
        P_PLAN_NAME := NULL;
    END;
  
    DBMS_OUTPUT.PUT_LINE('P_PLAN_NAME=' || P_PLAN_NAME);
  
    --Monthly topup rate
  
    --Tenor
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc
       WHERE acc = p_acc
         AND brn = P_BRN; --L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    
      SELECT ABS(rec_ictm_acc.int_start_date -
                 P1FCHPRFM.GLOBAL.application_date /*rec_ictm_acc.maturity_date*/)
        INTO l_tenor
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        l_tenor := 0;
    END;
  
    DBMS_OUTPUT.PUT_LINE('l_tenor=' || l_tenor);
  
    P_MON_TOPUP_RATE := FN_GET_INT_TOPUP_RATE_CLEVER_SAVINGS(P_ACC,
                                                             P_BRN, --L_STTM_CUST_ACCOUNT.BRANCH_CODE,
                                                             l_tenor);
  
    P_MON_TOPUP_RATE := NVL(P_MON_TOPUP_RATE, 0) + NVL(P_INT_RATE, 0);
    DBMS_OUTPUT.PUT_LINE('P_MON_TOPUP_RATE=' || P_MON_TOPUP_RATE);
  
    --Monthly Topup Amount
    BEGIN
      SELECT *
        INTO L_ICTM_TD_DETAILS_CUSTOM
        FROM P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM A
       WHERE A.ACC = P_ACC
         AND A.BRN = P_BRN; --L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        L_ICTM_TD_DETAILS_CUSTOM := NULL;
    END;
  
    --P_MON_TOPUP_AMT := L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT;
    
    P_MON_TOPUP_AMT := FN_GET_TD_MIN_TOPUP_AMT(P_ACC, P_BRN, L_ICTM_TD_DETAILS_CUSTOM.CCY, P1FCHPRFM.GLOBAL.APPLICATION_DATE);
  
  EXCEPTION
    WHEN OTHERS THEN
      P1FCHPRFM.DEBUG.PR_DEBUG('IC',
                               'FAILED IN PR_RETURN_TD_DETAILS_CLEVER_SAVINGS');
      P1FCHPRFM.DEBUG.PR_DEBUG('IC',
                               'ERROR CODE IN PR_RETURN_TD_DETAILS_CLEVER_SAVINGS=' ||
                               SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('IC',
                               'ERROR MESSAGE IN PR_RETURN_TD_DETAILS_CLEVER_SAVINGS=' ||
                               SQLERRM);
  END PR_RETURN_TD_DETAILS_CLEVER_SAVINGS;

  --Clever Savings Sampath Ends

  --=====================================================================================================
  FUNCTION fn_get_int_rate(p_acc IN VARCHAR2, p_brn IN VARCHAR2)
    RETURN NUMBER IS
    l_int_rate   NUMBER;
    l_rule       NUMBER;
    l_rate       P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    l_tenor      NUMBER := 0;
    rec_ictm_acc P1FCHPRFM.ictm_acc%ROWTYPE;
  BEGIN
    --dbg('In Fn_Get_Int_Rate');

    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc
       WHERE acc = p_acc
         AND brn = p_brn;

      SELECT ABS(rec_ictm_acc.int_start_date - rec_ictm_acc.maturity_date)
        INTO l_tenor
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('unable to find the Ictm_Acc for ' || p_acc || '~' || p_brn);
        --dbg('Setting int rate to 0');
        l_int_rate := 0;
        RETURN l_int_rate;
    END;

    --dbg('l_Tenor =' || l_tenor);

    IF l_tenor > 0 THEN
      --l_rate := fn_get_rate_code(p_acc, p_brn, l_tenor); sampath commented

      l_rate := FN_GET_RATE_CODE_CUSTOM(p_acc, p_brn, l_tenor);
      --dbg('Got rate code as ' || l_rate);

      BEGIN
        SELECT ude_value
          INTO l_int_rate
          FROM P1FCHPRFM.ictm_acc_udevals a
         WHERE acc = p_acc
           AND brn = p_brn
           AND ude_id = l_rate
           AND ude_eff_dt = (SELECT MAX(ude_eff_dt)
                               FROM P1FCHPRFM.ictm_acc_udevals
                              WHERE acc = a.acc
                                AND brn = a.brn
                                AND ude_id = a.ude_id);
      EXCEPTION
        WHEN OTHERS THEN
          --dbg('Failed to get the value for ' || l_rate);
          --dbg('Setting int_rate to 0');
          l_int_rate := 0;
      END;

      RETURN l_int_rate;
    ELSE
      RETURN 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      l_int_rate := 0;
      RETURN l_int_rate;
  END fn_get_int_rate;

  FUNCTION FN_GET_RATE_CODE_CUSTOM(P_ACC   IN VARCHAR2,
                                   P_BRN   IN VARCHAR2,
                                   P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE IS

    TYPE T IS TABLE OF P1FCHPRFM.ICTMS_PR_INT_UDEVALS%ROWTYPE;
    V T;

    L_CUST_ACC P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;

    CURSOR C1(P_ACC_CLASS P1FCHPRFM.ICTMS_PR_INT_UDEVALS.ACLASS%TYPE,
              P_PROD      P1FCHPRFM.ICTMS_PR_INT_UDEVALS.PRODUCT_CODE%TYPE,
              P_CCY       P1FCHPRFM.ICTMS_PR_INT_UDEVALS.CCY_CODE%TYPE) IS
      SELECT *
        FROM P1FCHPRFM.ICTMS_PR_INT_UDEVALS
       WHERE ACLASS = P_ACC_CLASS
         AND PRODUCT_CODE = P_PROD
         AND CCY_CODE = P_CCY;

    L_SLAB1  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB2  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB3  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB4  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB5  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB6  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB7  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB8  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB9  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB10 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB11 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_UDE_ID P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    L_PROD   VARCHAR2(4);
    L_RATE   VARCHAR2(24);
    L_RULE   VARCHAR2(10);
  BEGIN

    BEGIN
      SELECT prod
        INTO l_prod
        FROM P1FCHPRFM.ictm_acc_pr
       WHERE acc = p_acc
         AND brn = p_brn;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('Unable to get product for ' || p_acc ||
        --' in fn_get_rate_code , returning xxx');
        l_rate := 'xxx';
        RETURN l_rate;
    END;

    --dbg('l_prod = ' || l_prod);

    IF l_prod <> 'xxx' THEN
      BEGIN
        SELECT rule
          INTO l_rule
          FROM P1FCHPRFM.ictms_pr_int
         WHERE product_code = l_prod;
      EXCEPTION
        WHEN OTHERS THEN
          --dbg('Unable to find the rule , returning xxx');
          l_rate := 'xxx';
          RETURN l_rate;
      END;
    END IF;

    --dbg('l_rule = ' || l_rule);

    --Get Account Information
    BEGIN
      SELECT *
        INTO L_CUST_ACC
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_CUST_ACC := NULL;
    END;

    OPEN C1(L_CUST_ACC.ACCOUNT_CLASS, l_prod, L_CUST_ACC.CCY);

    FETCH C1 BULK COLLECT
      INTO V;
    CLOSE C1;

    /*FOR G IN V.FIRST .. V.LAST LOOP
      IF V(G).UDE_ID = 'SLAB_1' THEN
        L_SLAB1 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_2' THEN
        L_SLAB2 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_3' THEN
        L_SLAB3 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_4' THEN
        L_SLAB4 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_5' THEN
        L_SLAB5 := V(G).UDE_VALUE;
      END IF;
    END LOOP;

    IF P_TENOR >= L_SLAB1 AND P_TENOR <= L_SLAB2 THEN
      L_RATE_CODE := 'INT_RATE_1M';
    ELSIF P_TENOR > L_SLAB2 AND P_TENOR <= L_SLAB3 THEN
      L_RATE_CODE := 'INT_RATE_3M';
    ELSIF P_TENOR > L_SLAB3 AND P_TENOR <= L_SLAB4 THEN
      L_RATE_CODE := 'INT_RATE_6M';
    ELSIF P_TENOR > L_SLAB4 AND P_TENOR <= L_SLAB5 THEN
      L_RATE_CODE := 'INT_RATE_12M';
    ELSIF P_TENOR > L_SLAB5 THEN
      L_RATE_CODE := 'INT_RATE_A1Y';
    END IF;*/

    FOR G IN V.FIRST .. V.LAST LOOP
      IF V(G).UDE_ID = 'SLAB_1' THEN
        L_SLAB1 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_2' THEN
        L_SLAB2 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_3' THEN
        L_SLAB3 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_4' THEN
        L_SLAB4 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_5' THEN
        L_SLAB5 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_6' THEN
        L_SLAB6 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_7' THEN
        L_SLAB7 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_8' THEN
        L_SLAB8 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_9' THEN
        L_SLAB9 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_10' THEN
        L_SLAB10 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_11' THEN
        L_SLAB11 := V(G).UDE_VALUE;
      END IF;
    END LOOP;

    IF P_TENOR >= L_SLAB1 AND P_TENOR <= L_SLAB2 THEN
      L_UDE_ID := 'INT_RATE_1M';
    ELSIF P_TENOR > L_SLAB2 AND P_TENOR <= L_SLAB3 THEN
      L_UDE_ID := 'INT_RATE_3M';
    ELSIF P_TENOR > L_SLAB3 AND P_TENOR <= L_SLAB4 THEN
      L_UDE_ID := 'INT_RATE_6M';
    ELSIF P_TENOR > L_SLAB4 AND P_TENOR <= L_SLAB5 THEN
      L_UDE_ID := 'INT_RATE_9M';
    ELSIF P_TENOR > L_SLAB5 AND P_TENOR <= L_SLAB6 THEN
      L_UDE_ID := 'INT_RATE_1Y';
    ELSIF P_TENOR > L_SLAB6 AND P_TENOR <= L_SLAB7 THEN
      L_UDE_ID := 'INT_RATE_2Y';
    ELSIF P_TENOR > L_SLAB7 AND P_TENOR <= L_SLAB8 THEN
      L_UDE_ID := 'INT_RATE_3Y';
    ELSIF P_TENOR > L_SLAB8 AND P_TENOR <= L_SLAB9 THEN
      L_UDE_ID := 'INT_RATE_4Y';
    ELSIF P_TENOR > L_SLAB9 THEN
      L_UDE_ID := 'INT_RATE_5Y';
    END IF;

    --dbg('L_UDE_ID=' || L_UDE_ID);

    RETURN L_UDE_ID;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END FN_GET_RATE_CODE_CUSTOM;

  /*FUNCTION FN_GET_RATE_CODE_CUSTOM(P_ACC   IN VARCHAR2,
                                   P_BRN   IN VARCHAR2,
                                   P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE IS

    TYPE T IS TABLE OF P1FCHPRFM.ICTMS_PR_INT_UDEVALS%ROWTYPE;
    V T;

    L_CUST_ACC P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;

    CURSOR C1(P_ACC_CLASS P1FCHPRFM.ICTMS_PR_INT_UDEVALS.ACLASS%TYPE,
              P_PROD      P1FCHPRFM.ICTMS_PR_INT_UDEVALS.PRODUCT_CODE%TYPE,
              P_CCY       P1FCHPRFM.ICTMS_PR_INT_UDEVALS.CCY_CODE%TYPE) IS
      SELECT *
        FROM P1FCHPRFM.ICTMS_PR_INT_UDEVALS A
       WHERE ACLASS = P_ACC_CLASS
         AND PRODUCT_CODE = P_PROD
         AND CCY_CODE = P_CCY
         AND UDE_EFF_DT = (SELECT MAX(UDE_EFF_DT)
                             FROM P1FCHPRFM.ICTMS_PR_INT_UDEVALS
                            WHERE ACLASS = A.ACLASS
                              AND PRODUCT_CODE = A.PRODUCT_CODE
                              AND CCY_CODE = A.CCY_CODE
                              AND UDE_ID = A.UDE_ID);

    L_SLAB1  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB2  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB3  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB4  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB5  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB6  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB7  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB8  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB9  P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB10 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB11 P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_UDE_ID P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    L_PROD   VARCHAR2(4);
    L_RATE   VARCHAR2(24);
    L_RULE   VARCHAR2(10);
  BEGIN

    BEGIN
      SELECT PROD
        INTO L_PROD
        FROM P1FCHPRFM.ICTM_ACC_PR
       WHERE ACC = P_ACC
         AND BRN = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        --DBG('Unable to get product for ' || P_ACC ||
          --  ' in fn_get_rate_code , returning xxx');
        L_RATE := 'xxx';
        RETURN L_RATE;
    END;

    --DBG('l_prod = ' || L_PROD);

    IF L_PROD <> 'xxx' THEN
      BEGIN
        SELECT RULE
          INTO L_RULE
          FROM P1FCHPRFM.ICTMS_PR_INT
         WHERE PRODUCT_CODE = L_PROD;
      EXCEPTION
        WHEN OTHERS THEN
          --DBG('Unable to find the rule , returning xxx');
          L_RATE := 'xxx';
          RETURN L_RATE;
      END;
    END IF;

    --DBG('l_rule = ' || L_RULE);

    --GET ACCOUNT INFORMATION
    BEGIN
      SELECT *
        INTO L_CUST_ACC
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_CUST_ACC := NULL;
    END;

    OPEN C1(L_CUST_ACC.ACCOUNT_CLASS, L_PROD, L_CUST_ACC.CCY);

    FETCH C1 BULK COLLECT
      INTO V;
    CLOSE C1;

    FOR G IN V.FIRST .. V.LAST LOOP
      IF V(G).UDE_ID = 'SLAB_1' THEN
        L_SLAB1 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_2' THEN
        L_SLAB2 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_3' THEN
        L_SLAB3 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_4' THEN
        L_SLAB4 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_5' THEN
        L_SLAB5 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_6' THEN
        L_SLAB6 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_7' THEN
        L_SLAB7 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_8' THEN
        L_SLAB8 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_9' THEN
        L_SLAB9 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_10' THEN
        L_SLAB10 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_11' THEN
        L_SLAB11 := V(G).UDE_VALUE;
      END IF;
    END LOOP;

    IF P_TENOR >= L_SLAB1 AND P_TENOR <= L_SLAB2 THEN
      L_UDE_ID := 'INT_RATE_1M';
    ELSIF P_TENOR > L_SLAB2 AND P_TENOR <= L_SLAB3 THEN
      L_UDE_ID := 'INT_RATE_3M';
    ELSIF P_TENOR > L_SLAB3 AND P_TENOR <= L_SLAB4 THEN
      L_UDE_ID := 'INT_RATE_6M';
    ELSIF P_TENOR > L_SLAB4 AND P_TENOR <= L_SLAB5 THEN
      L_UDE_ID := 'INT_RATE_9M';
    ELSIF P_TENOR > L_SLAB5 AND P_TENOR <= L_SLAB6 THEN
      L_UDE_ID := 'INT_RATE_1Y';
    ELSIF P_TENOR > L_SLAB6 AND P_TENOR <= L_SLAB7 THEN
      L_UDE_ID := 'INT_RATE_2Y';
    ELSIF P_TENOR > L_SLAB7 AND P_TENOR <= L_SLAB8 THEN
      L_UDE_ID := 'INT_RATE_3Y';
    ELSIF P_TENOR > L_SLAB8 AND P_TENOR <= L_SLAB9 THEN
      L_UDE_ID := 'INT_RATE_4Y';
    ELSIF P_TENOR > L_SLAB9 THEN
      L_UDE_ID := 'INT_RATE_5Y';
    END IF;

    --DBG('L_UDE_ID=' || L_UDE_ID);

    RETURN L_UDE_ID;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END FN_GET_RATE_CODE_CUSTOM;*/

  PROCEDURE PR_RETURN_TD_DETAILS(P_ACC          IN VARCHAR2,
                                 P_INT_RATE     OUT NUMBER,
                                 P_INT_AMT      OUT NUMBER,
                                 P_TAX_AMT      OUT NUMBER,
                                 P_MATURITY_AMT OUT NUMBER) IS
    L_STTM_CUST_ACCOUNT    P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    rec_ictm_acc           P1FCHPRFM.ictm_acc%ROWTYPE;
    l_tenor                NUMBER := 0;
    L_ICTM_TD_DETAILS      P1FCHPRFM.ICTM_TD_DETAILS%ROWTYPE;
    L_CYTM_CCY_DEFN_MASTER P1FCHPRFM.CYTM_CCY_DEFN_MASTER%ROWTYPE;

  BEGIN

    --get Branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_ACC;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;

  P1FCHPRFM.GLOBAL.pr_init(L_STTM_CUST_ACCOUNT.BRANCH_CODE,'SYSTEM');
  P1FCHPRFM.CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') := 'ICDRDSIM';

    --get td information
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc
       WHERE acc = P_ACC
         AND brn = L_STTM_CUST_ACCOUNT.BRANCH_CODE;

      SELECT ABS(rec_ictm_acc.int_start_date - rec_ictm_acc.maturity_date)
        INTO l_tenor
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('Setting int rate to 0');
        P_INT_RATE := 0;
    END;

    --Get initial Deposit
    BEGIN
      SELECT *
        INTO L_ICTM_TD_DETAILS
        FROM P1FCHPRFM.ICTM_TD_DETAILS
       WHERE ACC = P_ACC
         AND BRN = L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        L_ICTM_TD_DETAILS := NULL;
    END;

    P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'BEFORE CALLING INT RATE PR');

    --GET INTEREST RATE
    P_INT_RATE := FN_GET_INT_RATE(P_ACC, L_STTM_CUST_ACCOUNT.BRANCH_CODE);

    P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'AFTER CALLING INT RATE PR');

    --GET INTEREST AMOUNT

    PR_TD_INT_TAX_AMT(L_ICTM_TD_DETAILS, P_INT_AMT, P_TAX_AMT);

    P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'AFTER CALLING INTEREST=' || P_INT_AMT);

    /*P_INT_AMT := FN_CALC_INT(NVL(L_ICTM_TD_DETAILS.TD_AMOUNT, 0) +
    NVL(L_ICTM_TD_DETAILS.TOPUP_AMT, 0) -
    NVL(L_ICTM_TD_DETAILS.REDEM_AMT, 0),
    P_INT_RATE,
    L_TENOR);*/

    --Get Tax AMount
    /*P_TAX_AMT := FN_CALC_TAX(P_INT_AMT,
    P_ACC,
    L_STTM_CUST_ACCOUNT.BRANCH_CODE);*/

    --Maturity Amount
    P_MATURITY_AMT := NVL(L_ICTM_TD_DETAILS.TD_AMOUNT, 0) +
                      NVL(L_ICTM_TD_DETAILS.TOPUP_AMT, 0) -
                      NVL(L_ICTM_TD_DETAILS.REDEM_AMT, 0) +
                      (P_INT_AMT - P_TAX_AMT);

    --Rounding Mechanism
    SELECT *
      INTO L_CYTM_CCY_DEFN_MASTER
      FROM P1FCHPRFM.CYTM_CCY_DEFN_MASTER
     WHERE CCY_CODE = L_STTM_CUST_ACCOUNT.CCY;

    P_MATURITY_AMT := P1FCHPRFM.ROUND_TO(P_MATURITY_AMT,
                                         L_CYTM_CCY_DEFN_MASTER.CCY_ROUND_UNIT);

  EXCEPTION
    WHEN OTHERS THEN
      P1FCHPRFM.DEBUG.PR_DEBUG('IC', 'FAILED IN PR_RETURN_TD_DETAILS');
      P1FCHPRFM.DEBUG.PR_DEBUG('IC', 'ERROR CODE IN PR_RETURN_TD_DETAILS='||SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('IC', 'ERROR MESSAGE IN PR_RETURN_TD_DETAILS='||SQLERRM);
  END PR_RETURN_TD_DETAILS;

  --Inter bank transfer Bank names and BIC Codes
  PROCEDURE PR_GET_IBFT_BANK_BIC_CODE(P_BNAME_BIC_DTLS OUT SYS_REFCURSOR) IS

  BEGIN
    OPEN P_BNAME_BIC_DTLS FOR
      SELECT * FROM P1FCHPRFM.STVW_IBFT_BANK_NAME_BIC_CODE;
  EXCEPTION
    WHEN OTHERS THEN

      P_BNAME_BIC_DTLS := NULL;

  END PR_GET_IBFT_BANK_BIC_CODE;

  --Bank Names
  PROCEDURE PR_GET_INTER_BANK_NAMES(P_BANK_DETAILS OUT SYS_REFCURSOR) IS

  BEGIN
    OPEN P_BANK_DETAILS FOR
      SELECT * FROM LMTW_TYPE_VALUES;
  EXCEPTION
    WHEN OTHERS THEN
      P_BANK_DETAILS := NULL;
  END PR_GET_INTER_BANK_NAMES;

  --Fast Charge
  PROCEDURE PR_GET_FAST_CHARGE_DTLS(P_PROD_CODE IN VARCHAR2,
                                    P_ARC_DTLS  OUT SYS_REFCURSOR) IS

  BEGIN
    OPEN P_ARC_DTLS FOR
      SELECT * FROM IFTW_ARC_MAINT WHERE COD_PROD_ACC_CLS = P_PROD_CODE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ARC_DTLS := NULL;
  END PR_GET_FAST_CHARGE_DTLS;

--Standing Instructions Summary
  PROCEDURE PR_GET_SI_DTLS(P_SI_DTLS OUT SYS_REFCURSOR) IS
    BEGIN
    OPEN P_SI_DTLS FOR
      SELECT * FROM P1FCHPRFM.SIVW_INS_SUMMARY;
  EXCEPTION
    WHEN OTHERS THEN
      P_SI_DTLS := NULL;
  END PR_GET_SI_DTLS;

   --List of Standing Instructions for a customer
  PROCEDURE PR_GET_SI_DTLS(P_COUNTER_PARTY IN P1FCHPRFM.SIVW_INS_SUMMARY.COUNTERPARTY%TYPE,
                          P_SI_DTLS OUT SYS_REFCURSOR) IS
    BEGIN
    OPEN P_SI_DTLS FOR
      SELECT * FROM P1FCHPRFM.SIVW_INS_SUMMARY WHERE COUNTERPARTY = P_COUNTER_PARTY;
  EXCEPTION
    WHEN OTHERS THEN
      P_SI_DTLS := NULL;
  END PR_GET_SI_DTLS;

  --Return Joint Details
  FUNCTION FN_GET_JOINT_DTLS(P_AC_NO  IN STVW_CUST_JOINT_DTLS_DIG.CUST_AC_NO%TYPE,
                             P_MOB_NO IN STVW_CUST_JOINT_DTLS_DIG.MOBILE_NUMBER%TYPE)
    RETURN STVW_CUST_JOINT_DTLS_DIG.CUSTOMER_NO%TYPE IS
    L_CUST_NO STVW_CUST_JOINT_DTLS_DIG.CUSTOMER_NO%TYPE;
  BEGIN

    SELECT A.CUSTOMER_NO
      INTO L_CUST_NO
      FROM STVW_CUST_JOINT_DTLS_DIG A
     WHERE A.CUST_AC_NO = P_AC_NO
       AND A.MOBILE_NUMBER = P_MOB_NO;

    RETURN L_CUST_NO;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_CUST_NO;
  END FN_GET_JOINT_DTLS;

  --Get CASA by CIF no
  FUNCTION FN_GET_CASA_BY_CIF_DIG(P_CUST_NO IN STVW_GET_CASA_BY_CIF_DIG.CUST_NO%TYPE)
    RETURN STVW_GET_CASA_BY_CIF_DIG.CUST_AC_NO%TYPE AS
    L_CUST_NO STVW_GET_CASA_BY_CIF_DIG.CUST_NO%TYPE;
  BEGIN

    SELECT A.CUST_AC_NO
      INTO L_CUST_NO
      FROM STVW_GET_CASA_BY_CIF_DIG A
     WHERE A.CUST_NO = P_CUST_NO;

    RETURN L_CUST_NO;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_CUST_NO;
  END FN_GET_CASA_BY_CIF_DIG;

  PROCEDURE PR_GET_CHARGE(P_AMT1    IN NUMBER,
                          P_AMT2    IN NUMBER,
                          P_CHARGE1 OUT NUMBER,
                          P_CHARGE2 OUT NUMBER)

   IS

  BEGIN

    IF P_AMT1 >= 2000000 AND P_AMT2 <= 10000000 THEN

      P_CHARGE1 := 1700;
      P_CHARGE2 := 300;

    ELSIF P_AMT1 >= 10000001 AND P_AMT2 <= 20000000 THEN

      P_CHARGE1 := 2600;
      P_CHARGE2 := 400;

    ELSIF P_AMT1 >= 20000001 AND P_AMT2 <= 40000000 THEN

      P_CHARGE1 := 3500;
      P_CHARGE2 := 500;

    ELSIF P_AMT1 >= 40000001 AND P_AMT2 <= 60000000 THEN

      P_CHARGE1 := 4400;
      P_CHARGE2 := 600;

    ELSIF P_AMT1 >= 60000001 AND P_AMT2 <= 80000000 THEN

      P_CHARGE1 := 5300;
      P_CHARGE2 := 700;

    ELSIF P_AMT1 >= 80000001 AND P_AMT2 <= 100000000 THEN

      P_CHARGE1 := 6200;
      P_CHARGE2 := 800;

    ELSIF P_AMT1 >= 100000001 AND P_AMT2 <= 120000000 THEN

      P_CHARGE1 := 7100;
      P_CHARGE2 := 900;

    ELSIF P_AMT1 >= 120000001 AND P_AMT2 <= 140000000 THEN

      P_CHARGE1 := 8000;
      P_CHARGE2 := 1000;

    ELSIF P_AMT1 >= 140000001 AND P_AMT2 <= 160000000 THEN

      P_CHARGE1 := 8900;
      P_CHARGE2 := 1100;

    ELSIF P_AMT1 >= 160000001 AND P_AMT2 <= 180000000 THEN

      P_CHARGE1 := 9800;
      P_CHARGE2 := 1200;

    ELSIF P_AMT1 >= 180000001 AND P_AMT2 <= 200000000 THEN

      P_CHARGE1 := 10700;
      P_CHARGE2 := 1300;

    ELSIF P_AMT1 >= 200000001 AND P_AMT2 <= 220000000 THEN

      P_CHARGE1 := 11600;
      P_CHARGE2 := 1400;

    ELSIF P_AMT1 >= 220000001 AND P_AMT2 <= 240000000 THEN

      P_CHARGE1 := 12500;
      P_CHARGE2 := 1500;

    ELSIF P_AMT1 >= 240000001 AND P_AMT2 <= 260000000 THEN

      P_CHARGE1 := 13400;
      P_CHARGE2 := 1600;

    ELSIF P_AMT1 >= 260000001 AND P_AMT2 <= 280000000 THEN

      P_CHARGE1 := 14300;
      P_CHARGE2 := 1700;

    ELSIF P_AMT1 >= 280000001 AND P_AMT2 <= 300000000 THEN

      P_CHARGE1 := 15200;
      P_CHARGE2 := 1800;

    ELSIF P_AMT1 >= 300000001 AND P_AMT2 <= 320000000 THEN

      P_CHARGE1 := 16100;
      P_CHARGE2 := 1900;

    ELSIF P_AMT1 >= 320000001 AND P_AMT2 <= 340000000 THEN

      P_CHARGE1 := 17000;
      P_CHARGE2 := 2000;

    ELSIF P_AMT1 >= 340000001 AND P_AMT2 <= 360000000 THEN

      P_CHARGE1 := 17900;
      P_CHARGE2 := 2100;

    ELSIF P_AMT1 >= 360000001 AND P_AMT2 <= 380000000 THEN

      P_CHARGE1 := 18800;
      P_CHARGE2 := 2200;

    ELSIF P_AMT1 >= 380000001 AND P_AMT2 <= 400000000 THEN

      P_CHARGE1 := 19700;
      P_CHARGE2 := 2300;

    ELSIF P_AMT1 >= 400000001 AND P_AMT2 <= 420000000 THEN

      P_CHARGE1 := 20600;
      P_CHARGE2 := 2400;

    ELSIF P_AMT1 >= 420000001 THEN

      P_CHARGE1 := 21500;
      P_CHARGE2 := 2500;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN

      NULL;

  END PR_GET_CHARGE;
PROCEDURE PR_TD_INT_TAX_AMT(P_TD_DETAILS IN P1FCHPRFM.ICTM_TD_DETAILS%ROWTYPE,
                              P_INT_AMT    OUT NUMBER,
                              P_TAX_AMT    OUT NUMBER) IS
    L_ICTM_ACC          P1FCHPRFM.ICTM_ACC%ROWTYPE;
    L_PAYOUT_COUNT      NUMBER := 0;
    L_TAX_AMT           P1FCHPRFM.ICTBS_ENTRIES.AMT%TYPE;
    L_REDEM_FULL_FLAG   VARCHAR2(1);
    L_NET_INT_AFTER_TAX P1FCHPRFM.ICTBS_ENTRIES.AMT%TYPE;
    L_ERR_CODE          P1FCHPRFM.ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM         P1FCHPRFM.ERTB_MSGS.MESSAGE%TYPE;
    L_PROD              VARCHAR2(4);
    l_rule              P1FCHPRFM.ictms_pr_int.RULE%TYPE;
    L_INT_AMOUNT        NUMBER;
    L_ICDREDMN          P1FCHPRFM.TDVW_TD_REDEMPTION%ROWTYPE;
    L_TB_CALC_BRKUP     P1FCHPRFM.STPKS_STDTDTOP_UTILS.TY_TB_RED_BRKUP;
  BEGIN

    P1FCHPRFM.DEBUG.PR_DEBUG('IC', ' INSIDE  PR_TD_INT_TAX_AMT');

    BEGIN
      SELECT *
        INTO L_ICTM_ACC
        FROM P1FCHPRFM.ICTM_ACC
       WHERE BRN = P_TD_DETAILS.BRN
         AND ACC = P_TD_DETAILS.ACC;
    EXCEPTION
      WHEN OTHERS THEN
        L_ICTM_ACC := null;
    END;

    P1FCHPRFM.DEBUG.PR_DEBUG('IC', ' APPLE1');

    BEGIN
      SELECT COUNT(*)
        INTO L_PAYOUT_COUNT
        FROM P1FCHPRFM.ICTM_TDPAYOUT_DETAILS
       WHERE BRN = P_TD_DETAILS.BRN
         AND ACC = P_TD_DETAILS.ACC
         AND PAYOUT_COMPONENT = 'I';
    EXCEPTION
      WHEN OTHERS THEN
        L_PAYOUT_COUNT := 0;
    END;

    P1FCHPRFM.DEBUG.PR_DEBUG('IC', ' L_PAYOUT_COUNT=' || L_PAYOUT_COUNT);

    BEGIN
      SELECT prod
        INTO l_prod
        FROM P1FCHPRFM.ictm_acc_pr
       WHERE acc = P_TD_DETAILS.ACC
         AND brn = P_TD_DETAILS.BRN;
    EXCEPTION
      WHEN OTHERS THEN
        --dbg('Unable to get product for ' || p_acc ||
        --' in fn_get_rate_code , returning xxx');
        L_PROD := 'XXXX';
    END;

    P1FCHPRFM.DEBUG.PR_DEBUG('IC', ' L_PROD=' || L_PROD);

    IF l_prod <> 'xxx' THEN
      BEGIN
        SELECT rule
          INTO l_rule
          FROM P1FCHPRFM.ictms_pr_int
         WHERE product_code = l_prod;
      EXCEPTION
        WHEN OTHERS THEN
          --dbg('Unable to find the rule , returning xxx');
          l_rule := 'xxx';
      END;
    END IF;

    P1FCHPRFM.DEBUG.PR_DEBUG('IC', ' l_rule=' || l_rule);

    IF (L_ICTM_ACC.BOOK_ACC <> L_ICTM_ACC.ACC OR L_PAYOUT_COUNT > 0) THEN

      P1FCHPRFM.DEBUG.PR_DEBUG('IC', ' Acc pr found so calling calc ');

      DELETE p1fchprfm.ICTW_MEMO_BOOKING WHERE ACC = P_TD_DETAILS.ACC;

      IF NOT P1FCHPRFM.ICPKS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_TD_DETAILS.BRN,
                                                          P_TD_DETAILS.ACC,
                                                          L_ERR_CODE,
                                                          L_ERR_PARAM) THEN
        --DEBUG.PR_DEBUG('IC', 'Failed to resolve account');
        NULL;
      END IF;

      P1FCHPRFM.ICPKS_TEST.PR_ICALC(P_TD_DETAILS.BRN,
                                    P_TD_DETAILS.ACC,
                                    L_PROD,

                                    NULL,
                                    NULL);

      SELECT SUM(DECODE(A.DRCR_IND, 'C', A.AMT, -A.AMT))
        INTO L_INT_AMOUNT
        FROM P1FCHPRFM.ICTW_MEMO_BOOKING A, P1FCHPRFM.ICTM_RULE_FRM B
       WHERE A.FRM_NO = B.FRM_NO
         AND A.BRN = P_TD_DETAILS.BRN
         AND A.ACC = P_TD_DETAILS.ACC
         AND A.PROD = L_PROD
         AND A.IS_TAX != 'Y'
         AND B.RULE_ID = L_RULE
         AND B.BOOK_FLAG = 'B';

      P_INT_AMT := L_INT_AMOUNT;

      --DEBUG.PR_DEBUG('IC', ' The interest amount is ' || L_INT_AMOUNT);

      /*PR_PUTITS(P_REC.DCN,
      1,
      'INTAMT',
      TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY, L_INT_AMOUNT)));*/

      SELECT NVL(SUM(AMT), 0)
        INTO L_TAX_AMT
        FROM P1FCHPRFM.ICTW_MEMO_BOOKING
       WHERE BRN = P_TD_DETAILS.BRN
         AND ACC = P_TD_DETAILS.ACC
         AND PROD = L_PROD
         AND IS_TAX = 'Y';
      --DEBUG.PR_DEBUG('IC', ' The tax amount is ' || L_TAX_AMT);

      --P_TAX_AMT := L_INT_AMOUNT - L_TAX_AMT;

      P_TAX_AMT := L_TAX_AMT;

      /*PR_PUTITS(P_REC.DCN,
      1,
      'NETINTAFTERTAX',
      TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY, L_NET_INT_AFTER_TAX)));*/

    ELSE

      IF P1FCHPRFM.STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_TD_DETAILS.ACC,
                                                               P_TD_DETAILS.BRN) THEN
        P1FCHPRFM.STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('Y');

        P1FCHPRFM.ICPKS_MAINT.PR_GET_FULL_REDEM(L_REDEM_FULL_FLAG);
        P1FCHPRFM.ICPKS_MAINT.PR_SET_FULL_REDEM(NULL);

        L_ICDREDMN.BRN_CODE := P_TD_DETAILS.BRN;
        L_ICDREDMN.AC_NO    := P_TD_DETAILS.ACC;

        L_ICDREDMN.WAVE_PENALTY   := 'Y';
        L_ICDREDMN.REDEMPTION_AMT := 0;
        L_ICDREDMN.CCY            := P_TD_DETAILS.CCY;
        /*DEBUG.PR_DEBUG('IC',
        'calling stpks_stdtdtop_utils.fn_matamt_comp to calculate Maturity Amount before Top-Up');*/
        IF NOT P1FCHPRFM.STPKS_STDTDTOP_UTILS.FN_MATAMT_COMP('FLEXCUBE',
                                                             'NEW',
                                                             L_ICDREDMN,
                                                             L_TB_CALC_BRKUP,
                                                             L_ERR_CODE,
                                                             L_ERR_PARAM) THEN
          --DEBUG.PR_DEBUG('IC', 'failed after calling fn_matamt_comp');
          L_ERR_CODE  := 'ST-TDMAT-01';
          L_ERR_PARAM := NULL;
          --RETURN FALSE;
        END IF;
        P1FCHPRFM.ICPKSS_MAINT.PR_SET_FULL_REDEM(L_REDEM_FULL_FLAG);
        P1FCHPRFM.STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('');

        P_INT_AMT := P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST;
        L_TAX_AMT := P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;
        /* DEBUG.PR_DEBUG('IC',
                       ' The interest amount is ' ||
                       STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST);
        DEBUG.PR_DEBUG('IC',
                       ' The tax amount is ' ||
                       STPKS_STDTDTOP_UTILS.G_TOTAL_TAX);*/

        --P_TAX_AMT := P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST -
        -- P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;

        P_TAX_AMT := P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;
        /*PR_PUTITS(P_REC.DCN,
        1,
        'NETINTAFTERTAX',
        TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY,
                                   L_NET_INT_AFTER_TAX)));*/

        P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST := 0;
        P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_TAX      := 0;
      ELSE
        /*
        STPKS_STDCUSAC_UTILS_1.PR_CALC_MATURITY(L_ACC_PR.BRN,
                                                L_ACC_PR.ACC,
                                                L_ACC_PR.PROD,
                                                L_TOTAL_AMT);*/

        P_INT_AMT := P1FCHPRFM.STPKS_STDCUSAC_UTILS_1.G_TOTAL_INTEREST;
        L_TAX_AMT := P1FCHPRFM.STPKS_STDCUSAC_UTILS_1.G_TOTAL_TAX;
        /*DEBUG.PR_DEBUG('IC',
                       ' The interest amount is ' ||
                       STPKS_STDCUSAC_UTILS_1.G_TOTAL_INTEREST);
        DEBUG.PR_DEBUG('IC',
                       ' The tax amount is ' ||
                       STPKS_STDCUSAC_UTILS_1.G_TOTAL_TAX);*/
        --P_TAX_AMT := P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST -
        --P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;

        P_TAX_AMT := P1FCHPRFM.STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;

        /* PR_PUTITS(P_REC.DCN,
        1,
        'NETINTAFTERTAX',
        TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY,
                                   L_NET_INT_AFTER_TAX)));*/
        P1FCHPRFM.STPKS_STDCUSAC_UTILS_1.G_TOTAL_INTEREST := 0;
        P1FCHPRFM.STPKS_STDCUSAC_UTILS_1.G_TOTAL_TAX      := 0;
      END IF;

    END IF;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      P1FCHPRFM.DEBUG.PR_DEBUG('IC', 'FAILED IN PR_TD_INT_TAX_AMT');
      P1FCHPRFM.DEBUG.PR_DEBUG('IC', 'ERROR CODE IN PR_TD_INT_TAX_AMT='||SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('IC', 'ERROR MESSAGE IN PR_TD_INT_TAX_AMT='||SQLERRM);

  END PR_TD_INT_TAX_AMT;

  PROCEDURE PR_CREATE_AIA_SI(P_POLICY_NO    IN VARCHAR2,
                             P_HOLDER_NAME  IN VARCHAR2,
                             P_HOLDER_EMAIL IN VARCHAR2,
                             P_HOLDER_PHONE IN VARCHAR2,
                             P_CUSTOMER_NO  in varchar2,
                             P_CUST_NAME    IN VARCHAR2,
                             P_CUST_AC_NO   in varchar2,
                             P_CCY          IN VARCHAR2,
                             P_AMT          IN NUMBER,
                             P_FREQ         IN VARCHAR2,
                             P_PAY_DATE     IN DATE,
                             P_EXPIRY_DATE  IN DATE,
                             P_STATUS       OUT NUMBER,
                             P_ERROR_CODE   OUT VARCHAR2,
                             P_ERROR_MSG    OUT VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    A EXCEPTION;
    L_AIA_PARTNER_RECEIPT_REF VARCHAR2(100);
    L_SEQ VARCHAR2(100);
  BEGIN

    IF P_POLICY_NO IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '1';
      P_ERROR_MSG  := 'POLICY NO IS NULL';

      RETURN;

    END IF;

    IF P_HOLDER_NAME IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '2';
      P_ERROR_MSG  := 'POLICY HOLDER NAME IS NULL';

      RETURN;

    END IF;

    /*IF P_HOLDER_EMAIL IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '3';
      P_ERROR_MSG  := 'POLICY HOLDER EMAIL IS NULL';
      RETURN;

    END IF;

    IF P_HOLDER_PHONE IS NULL THEN

      --RAISE A;
      P_STATUS     := 0;
      P_ERROR_CODE := '4';
      P_ERROR_MSG  := 'POLICY HOLDER PHONE IS NULL';
      RETURN;

    END IF;*/

    IF P_CUSTOMER_NO IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '5';
      P_ERROR_MSG  := 'CUSTOMER NO IS NULL';
      RETURN;

    END IF;

    IF P_CUST_AC_NO IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '6';
      P_ERROR_MSG  := 'POLICY CUSTOMER ACCOUNT IS NULL';
      RETURN;

    END IF;

    IF P_CCY IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '7';
      P_ERROR_MSG  := 'POLICY CCY IS NULL';
      RETURN;

    END IF;

    IF P_AMT IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '8';
      P_ERROR_MSG  := 'POLICY AMOUNT IS NULL';
      RETURN;

    END IF;

    IF P_FREQ IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '9';
      P_ERROR_MSG  := 'POLICY FREQUENCY IS NULL';
      RETURN;

    END IF;

    IF P_PAY_DATE IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '10';
      P_ERROR_MSG  := 'POLICY PAY DATE IS NULL';
      RETURN;

    END IF;

    IF P_EXPIRY_DATE IS NULL THEN

      --RAISE A;

      P_STATUS     := 0;
      P_ERROR_CODE := '11';
      P_ERROR_MSG  := 'POLICY EXPIRY DATE IS NULL';
      RETURN;

    END IF;

    --Generate AIA Partner Receipt Ref no

    SELECT P1FCHPRFM.TRSQ_AIA_PARTNER_RECEIPT_REF.NEXTVAL INTO L_SEQ  FROM DUAL;

    L_AIA_PARTNER_RECEIPT_REF := SUBSTR(TO_CHAR(SYSDATE, 'YYMM'), 2) || LPAD(L_SEQ, 9, '0');

    INSERT INTO P1FCHPRFM.IFTB_AIA_SI_MASTER
      (BANK_CODE,
       BANK_NAME,
       RECEIPT_DATE,
       PAYMENT_CHANNEL,
       TRANSACTION_TYPE,
       PARTNER_RECEIPT_REF,
       AIA_POLICY_NO,
       PREMIUM_AMT,
       AIA_RECEIPT_REF,
       PRODUCT_TYPE,
       POLICY_STATUS,
       CURRENT_BILL_FREQ,
       UPDATE_BILL_FREQ,
       EXPIRY_DATE,
       PAYMENT_DATE,
       CCY,
       policy_holder_name,
       policy_holder_email,
       policy_holder_phone,
       CUSTOMER_NO,
       CUST_NAME,
       CUST_AC_NO,
       AIA_AC_NO,
       MAKER_ID,
       MAKER_DT_STAMP,
       CHECKER_ID,
       CHECKER_DT_STAMP,
       RECORD_STAT,
       AUTH_STAT,
       MOD_NO,
       ONCE_AUTH)
    VALUES
      (10,
       'PRINCE BANK',
       TO_CHAR(SYSDATE, 'DD-MON-YY'),
       'MB',
       'Create',
       --'PRR123', --P_PARTNER_RECEIPT_REF,
       L_AIA_PARTNER_RECEIPT_REF,
       P_POLICY_NO,
       P_AMT,
       'ARR123', --P_AIA_RECEIPT_REF,
       'FLX',
       'IF',
       CASE P_FREQ WHEN 'MONTHLY' THEN '12' --1,
       WHEN 'SEMI_ANNUAL' THEN '2' WHEN 'ANNUAL' THEN '1' END,
       'N/A',
       TO_CHAR(P_EXPIRY_DATE, 'DD-MON-YY'),
       P_PAY_DATE,
       P_CCY,
       P_HOLDER_NAME,
       P_HOLDER_EMAIL,
       P_HOLDER_PHONE,
       P_CUSTOMER_NO,
       P_CUST_NAME,
       P_CUST_AC_NO,
       '789', --P_AIA_AC_NO
       'SYSTEM',
       SYSDATE,
       'SYSTEM',
       SYSDATE,
       'O',
       'A',
       1,
       'Y');

    IF SQL%ROWCOUNT = 1 THEN
      dbms_output.put_line('inside if');
      P_STATUS := 1;
      COMMIT;
    ELSE
      dbms_output.put_line('inside else');
      P_STATUS := 0;
      RAISE A;
    END IF;

  EXCEPTION
    WHEN A THEN
      P_STATUS     := 0;
      P_ERROR_CODE := SQLCODE;
      P_ERROR_MSG  := SQLERRM;
      dbms_output.put_line('ERROR LINE NUMBER=' ||
                           DBMS_UTILITY.format_error_backtrace);
    WHEN DUP_VAL_ON_INDEX THEN
      P_STATUS     := 0;
      P_ERROR_CODE := '-1';
      P_ERROR_MSG  := 'DUPLICATE POLICY NO';

    WHEN OTHERS THEN
      P_STATUS     := 0;
      P_ERROR_CODE := SQLCODE;
      P_ERROR_MSG  := SQLERRM;
      dbms_output.put_line('ERROR LINE NUMBER=' ||
                           DBMS_UTILITY.format_error_backtrace);
      /*P1FCHPRFM.DEBUG.PR_DEBUG('IF', 'FAILED IN PR_CREATE_AIA_SI');
      P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                               'ERROR CODE IN PR_CREATE_AIA_SI=' || SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                               'ERROR MESSAGE IN PR_CREATE_AIA_SI=' ||
                               SQLERRM);*/
  END PR_CREATE_AIA_SI;

  /*PROCEDURE PR_MODIFY_AIA_SI(P_POLICY_NO        IN VARCHAR2,
                             P_UPDATE_BILL_FREQ IN VARCHAR2,
                             P_STATUS           OUT NUMBER) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    UPDATE P1FCHPRFM.IFTB_AIA_SI_MASTER
       SET TRANSACTION_TYPE = 'Change',
           UPDATE_BILL_FREQ = CASE P_UPDATE_BILL_FREQ
                                WHEN 'MONTHLY' THEN
                                 '12' --1,
                                WHEN 'SEMI_ANNUAL' THEN
                                 '2'
                                WHEN 'ANNUAL' THEN
                                 '1'
                              END
     WHERE AIA_POLICY_NO = P_POLICY_NO;

    COMMIT;

    IF SQL%ROWCOUNT = 1 THEN
      P_STATUS := 1;
    ELSE
      P_STATUS := 0;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      P1FCHPRFM.DEBUG.PR_DEBUG('IF', 'FAILED IN PR_MODIFY_AIA_SI');
      P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                               'ERROR CODE IN PR_MODIFY_AIA_SI=' || SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                               'ERROR MESSAGE IN PR_MODIFY_AIA_SI=' ||
                               SQLERRM);
  END PR_MODIFY_AIA_SI;*/

  PROCEDURE PR_CANCEL_AIA_SI(P_POLICY_NO  IN VARCHAR2,
                             P_STATUS     OUT NUMBER,
                             P_ERROR_CODE OUT VARCHAR2,
                             P_ERROR_MSG  OUT VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    A EXCEPTION;
    L_COUNT NUMBER;
    l_rowid ROWID;

  BEGIN

    IF P_POLICY_NO IS NULL THEN

      P_STATUS     := 0;
      P_ERROR_CODE := '1';
      P_ERROR_MSG  := 'POLICY NO IS NULL';

      RETURN;

    END IF;

    /*
    UPDATE P1FCHPRFM.IFTB_AIA_SI_MASTER
       SET TRANSACTION_TYPE = 'delete', RECORD_STAT = 'C', MOD_NO = MOD_NO + 1
     WHERE AIA_POLICY_NO = P_POLICY_NO
       AND AUTH_STAT = 'A'
       AND TRANSACTION_TYPE <> 'delete'
       AND RECORD_STAT <> 'C'
       AND MOD_NO = 1;*/

    --check if not available starts
    SELECT COUNT(1)
      INTO L_COUNT
      FROM P1FCHPRFM.IFTB_AIA_SI_MASTER
     WHERE AIA_POLICY_NO = P_POLICY_NO
       AND AUTH_STAT = 'A'
       AND TRANSACTION_TYPE <> 'delete'
       AND RECORD_STAT <> 'C';

    IF L_COUNT = 0 THEN
      P_STATUS     := 0;
      P_ERROR_CODE := '12';
      P_ERROR_MSG  := 'POLICY NO IS NOT AVAILABLE';

      RETURN;
    END IF;
    --check if not available ends

    INSERT INTO P1FCHPRFM.IFTB_AIA_SI_MASTER_HIST
      SELECT bank_code,
             bank_name,
             receipt_date,
             payment_channel,
             'delete',--transaction_type,
             partner_receipt_ref,
             aia_policy_no,
             premium_amt,
             aia_receipt_ref,
             product_type,
             policy_status,
             current_bill_freq,
             update_bill_freq,
             first_due_date,
             next_due_date,
             expiry_date,
             payment_date,
             ccy,
             policy_holder_name,
             policy_holder_phone,
             policy_holder_email,
             customer_no,
             cust_ac_no,
             aia_ac_no,
             cust_name,
             maker_id,
             maker_dt_stamp,
             checker_id,
             checker_dt_stamp,
             auth_stat,
             record_stat,
             once_auth,
             mod_no,
             P1FCHPRFM.TRSQ_AIASI_SEQID.nextval
        FROM P1FCHPRFM.IFTB_AIA_SI_MASTER
       WHERE AIA_POLICY_NO = P_POLICY_NO
         AND AUTH_STAT = 'A'
         AND TRANSACTION_TYPE <> 'delete'
         AND RECORD_STAT <> 'C'; -- RETURNING rowid into l_rowid;

    --UPDATE P1FCHPRFM.IFTB_AIA_SI_MASTER_HIST SET TRANSACTION_TYPE = 'delete'
    --where rowid = l_rowid;

    DELETE FROM P1FCHPRFM.IFTB_AIA_SI_MASTER
     WHERE AIA_POLICY_NO = P_POLICY_NO
       AND AUTH_STAT = 'A'
       AND TRANSACTION_TYPE <> 'delete'
       AND RECORD_STAT <> 'C';

    IF SQL%ROWCOUNT = 1 THEN
      P_STATUS := 1;
      COMMIT;

    ELSE
      P_STATUS := 0;
      COMMIT;

      RAISE A;
    END IF;

  EXCEPTION
    WHEN A THEN
      P_STATUS     := 0;
      P_ERROR_CODE := SQLCODE;
      P_ERROR_MSG  := SQLERRM;
      dbms_output.put_line('ERROR LINE NUMBER=' ||
                           DBMS_UTILITY.format_error_backtrace);
    WHEN OTHERS THEN
      P_STATUS     := 0;
      P_ERROR_CODE := SQLCODE;
      P_ERROR_MSG  := SQLERRM;
      P1FCHPRFM.DEBUG.PR_DEBUG('IF', 'FAILED IN PR_CANCEL_AIA_SI');
      P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                               'ERROR CODE IN PR_CANCEL_AIA_SI=' || SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                               'ERROR MESSAGE IN PR_CANCEL_AIA_SI=' ||
                               SQLERRM);
  END PR_CANCEL_AIA_SI;

  PROCEDURE PR_GET_FC_CHARGE(P_PRODUCT      IN VARCHAR2,
                             P_TXN_AMT      IN NUMBER,
                             P_TXN_CCY      IN VARCHAR2,
                             P_COUNTRY_CODE IN VARCHAR2,
                             P_SENDER_ACC   IN VARCHAR2,
                             P_CHARGE       OUT NUMBER,
                             P_CHG_CCY      OUT VARCHAR2,
                             P_STATUS       OUT VARCHAR2 /*,
                                                                                                                                                                                                                                                                                                                                                                                         P_ERROR_CODE   OUT VARCHAR2,
                                                                                                                                                                                                                                                                                                                                                                                         P_ERROR_MSG    OUT VARCHAR2*/)

   IS

    L_COMM_FEE_P P1FCHPRFM.LMTM_TYPE_VALUES.CODE%TYPE;
    L_COMM_FEE_M P1FCHPRFM.LMTM_TYPE_VALUES.CODE%TYPE;
    L_CABLE_FEE  P1FCHPRFM.LMTM_TYPE_VALUES.CODE%TYPE;
    L_COVER_CORR P1FCHPRFM.LMTM_TYPE_VALUES.CODE%TYPE;

  BEGIN

    ----Start PPSHV Fee
  IF P_PRODUCT = 'PSHV' THEN

        IF P_TXN_AMT > 0 THEN

            P_CHARGE := 0.1;

        END IF;

        P_CHG_CCY := 'USD';

      IF P_CHARGE IS NOT NULL THEN
        P_STATUS := 'S';

      ELSE
        P_STATUS := 'F';
      END IF;

    END IF;
  ---- End PPSHV Fee

  EXCEPTION
    WHEN OTHERS THEN

      P1FCHPRFM.DEBUG.PR_DEBUG('IF', 'FAILED IN PR_GET_FC_CHARGE');
      P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                               'ERROR CODE IN PR_GET_FC_CHARGE=' || SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                               'ERROR MESSAGE IN PR_GET_FC_CHARGE=' ||
                               SQLERRM);

  END PR_GET_FC_CHARGE;

  FUNCTION FN_UPDATE_PRE_LOAN_ALERT(P_UNIQUE_SEQ_NO  IN VARCHAR2,
                                    P_ACCOUNT_NUMBER IN VARCHAR2,
                                    P_CUSTOMER_ID    IN VARCHAR2)
    RETURN NUMBER IS

    PRAGMA AUTONOMOUS_TRANSACTION;

    P_STATUS number;

  BEGIN

    P1FCHPRFM.DEBUG.PR_DEBUG('IF', 'before updating');

    UPDATE STVW_LOAN_REPAY_PRE_DUE_ALERT A
       SET A.IS_ALERT_SENT = 'Y', A.ALERT_SENT_TIME_TO_CUST = SYSDATE
     WHERE A.UNIQUE_SEQ_NO = P_UNIQUE_SEQ_NO
       AND A.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
       AND A.CUSTOMER_ID = P_CUSTOMER_ID;

    P1FCHPRFM.DEBUG.PR_DEBUG('IF', 'before updating=' || SQL%ROWCOUNT);

    IF SQL%ROWCOUNT = 1 THEN
      P_STATUS := 1;

    ELSE
      P_STATUS := 0;

    END IF;

    COMMIT;

    RETURN P_STATUS;

  EXCEPTION

    WHEN OTHERS THEN

      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'FAILED IN FN_UPDATE_PRE_LOAN_ALERT');
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'ERROR CODE IN FN_UPDATE_PRE_LOAN_ALERT=' ||
                               SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'ERROR MESSAGE IN FN_UPDATE_PRE_LOAN_ALERT=' ||
                               SQLERRM);
      P_STATUS := 0;

      RETURN P_STATUS;

  END FN_UPDATE_PRE_LOAN_ALERT;

  FUNCTION FN_UPDATE_POST_LOAN_ALERT(P_UNIQUE_SEQ_NO  IN VARCHAR2,
                                     P_ACCOUNT_NUMBER IN VARCHAR2,
                                     P_CUSTOMER_ID    IN VARCHAR2)
    RETURN NUMBER IS

    PRAGMA AUTONOMOUS_TRANSACTION;

    P_STATUS number;

  BEGIN

    UPDATE STVW_LOAN_REPAY_POST_DUE_ALERT A
       SET A.IS_ALERT_SENT = 'Y', A.ALERT_SENT_TIME_TO_CUST = SYSDATE
     WHERE A.UNIQUE_SEQ_NO = P_UNIQUE_SEQ_NO
       AND A.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
       AND A.CUSTOMER_ID = P_CUSTOMER_ID;

    IF SQL%ROWCOUNT = 1 THEN
      P_STATUS := 1;

    ELSE
      P_STATUS := 0;

    END IF;

    COMMIT;

    RETURN P_STATUS;

  EXCEPTION

    WHEN OTHERS THEN

      P1FCHPRFM.DEBUG.PR_DEBUG('AC', 'FAILED IN FN_UPDATE_POST_LOAN_ALERT');
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'ERROR CODE IN FN_UPDATE_POST_LOAN_ALERT=' ||
                               SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'ERROR MESSAGE IN FN_UPDATE_POST_LOAN_ALERT=' ||
                               SQLERRM);
      P_STATUS := 0;

      RETURN P_STATUS;

  END FN_UPDATE_POST_LOAN_ALERT;

  FUNCTION FN_GET_FORMATTED_AMOUNT(P_CCY IN VARCHAR2, P_AMOUNT IN NUMBER)
    RETURN VARCHAR2 AS

    L_FORMATTED_AMOUNT VARCHAR2(30);

  BEGIN

    L_FORMATTED_AMOUNT := P1FCHPRFM.STPKS_ALERT_UTILS.FN_GET_FORMATTED_AMOUNT(P_CCY,
                                                                              P_AMOUNT);

    RETURN L_FORMATTED_AMOUNT;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_FORMATTED_AMOUNT;

  END FN_GET_FORMATTED_AMOUNT;

  PROCEDURE PR_GET_E_STATEMENT_TXNS(P_ACC_NO    IN VARCHAR2,
                                    P_FROM_DT   IN VARCHAR2,
                                    P_TO_DT     IN VARCHAR2,
                                    P_STMT_TXNS OUT SYS_REFCURSOR) IS

    L_DYNAMIC_SQL_STMT VARCHAR2(32767);

  BEGIN
    IF P_ACC_NO IS NOT NULL AND P_FROM_DT IS NOT NULL AND
       P_TO_DT IS NOT NULL THEN
    /*
      L_DYNAMIC_SQL_STMT := 'WITH OPEN_BAL AS
 (SELECT AC_NO CASA, CR_BAL - DR_BAL BALANCE
    FROM (SELECT AC_NO,
                 SUM(DECODE(DRCR_IND,
                            ''D'',
                            DECODE(AC_CCY, ''KHR'', FCY_AMOUNT, LCY_AMOUNT),
                            0)) DR_BAL,
                 SUM(DECODE(DRCR_IND,
                            ''C'',
                            DECODE(AC_CCY, ''KHR'', FCY_AMOUNT, LCY_AMOUNT),
                            0)) CR_BAL
            FROM ACTB_HISTORY
           WHERE AC_NO = ''' || P_ACC_NO || '''
             AND TRN_CODE NOT IN (''RVL'')
             AND TRN_DT < ''' || P_FROM_DT || '''
           GROUP BY AC_NO))
SELECT ROW_NUMBER() OVER(ORDER BY AC_ENTRY_SR_NO) REC, --1
       TRN_DT, --2
       TRN_REF_NO, --3
       CHECK_NO, --4
       TRN_DESC, --5
       VALUE_DT,
       --TRN_CODE,
       DEBIT, --6
       CREDIT, --7
       ACY_BAL, --8
       NVL(BALANCE, 0) -
       (SUM(DEBIT) OVER(PARTITION BY AC_NO ORDER BY AC_ENTRY_SR_NO)) +
       (SUM(CREDIT) OVER(PARTITION BY AC_NO ORDER BY AC_ENTRY_SR_NO)) END_BAL, --9
       NVL(BALANCE, 0) OPENING_BALANCE, --10
       AC_CCY,
       AC_NO
  FROM (SELECT A.AC_NO,
               A.AC_ENTRY_SR_NO,
               A.TRN_DT,
               A.VALUE_DT,
               DECODE(A.DRCR_IND, ''D'', 1, 0) *
               DECODE(A.AC_CCY, ''USD'', A.LCY_AMOUNT, NVL(A.FCY_AMOUNT, 0)) DEBIT,
               DECODE(A.DRCR_IND, ''C'', 1, 0) *
               DECODE(A.AC_CCY, ''USD'', A.LCY_AMOUNT, NVL(A.FCY_AMOUNT, 0)) CREDIT,
               DECODE(A.DRCR_IND, ''D'', -1, 1) *
               DECODE(A.AC_CCY, ''USD'', A.LCY_AMOUNT, NVL(A.FCY_AMOUNT, 0)) ACY_BAL,
               D.BALANCE,
               A.AC_CCY,
               NVL(NVL(E.ADDL_TEXT, F.NARRATIVE),
                   (SELECT DECODE(A.DRCR_IND,
                                  ''D'',
                                  DEBIT_NARRATION,
                                  CREDIT_NARRATION)
                      FROM STTM_TRN_CODE_ESTATEMENT
                     WHERE TRN_CODE = A.TRN_CODE)) TRN_DESC,
               --NVL((SELECT TRN_DESC FROM STTM_TRN_CODE WHERE TRN_CODE=A.TRN_CODE),NVL(E.ADDL_TEXT,F.NARRATIVE)) TRN_DESC,
               A.TRN_REF_NO,
               G.CHECK_NO
          FROM CAVW_ENTRIES A
         INNER JOIN STTM_CUST_ACCOUNT C
            ON A.AC_NO = C.CUST_AC_NO
          LEFT JOIN OPEN_BAL D
            ON A.AC_NO = D.CASA
          LEFT JOIN CSTB_ADDL_TEXT E
            ON A.TRN_REF_NO = E.REFERENCE_NO
           AND A.EVENT_SR_NO = E.EVNT_SEQ_NO
          LEFT JOIN (SELECT REPLACE(NARRATIVE, CHR(10), '''') NARRATIVE,
                           TRN_REF_NO
                      FROM DETB_RTL_TELLER) F
            ON A.TRN_REF_NO = F.TRN_REF_NO
          LEFT JOIN CAVW_CHECK_DETAILS G
            ON A.TRN_REF_NO = G.REMARKS
           AND A.AC_NO = G.ACCOUNT
           AND A.INSTRUMENT_CODE = G.CHECK_NO
         WHERE TRN_CODE NOT IN (''RVL'')
           AND AC_NO = ''' || P_ACC_NO || '''
           AND TRN_DT >= ''' || P_FROM_DT ||
                            ''' AND TRN_DT <= ''' || P_TO_DT || '''
           AND C.ACCOUNT_CLASS NOT IN (''ST10'')
         ORDER BY A.AC_ENTRY_SR_NO) G
 ORDER BY AC_ENTRY_SR_NO DESC';

   DBMS_OUTPUT.put_line('L_DYNAMIC_SQL_STMT='||L_DYNAMIC_SQL_STMT);*/

     -- OPEN P_STMT_TXNS FOR L_DYNAMIC_SQL_STMT;

        P1FCHPRFM.STPKS_DIGITAL_UTILS.PR_GET_E_STATEMENT_TXNS(P_ACC_NO,P_FROM_DT,P_TO_DT,P_STMT_TXNS);

    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_STMT_TXNS := NULL;
  END PR_GET_E_STATEMENT_TXNS;
  
  --Clever Savings Sampath Starts
  FUNCTION FN_GET_CLEVER_SAVINGS_PAYIN_ACC(P_ACC IN VARCHAR2,
                                           P_BRN IN VARCHAR2,
                                           P_CCY IN VARCHAR2)
    RETURN p1fchprfm.STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE AS
  
    L_ICTM_TDPAYIN_DETAILS p1fchprfm.ICTM_TDPAYIN_DETAILS%ROWTYPE;
  
  BEGIN
  
    BEGIN
    
      SELECT *
        INTO L_ICTM_TDPAYIN_DETAILS
        FROM p1fchprfm.ICTM_TDPAYIN_DETAILS A
       WHERE A.ACC = P_ACC
         AND A.BRN = P_BRN
         AND A.CCY = P_CCY;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_ICTM_TDPAYIN_DETAILS := NULL;
    END;
  
    P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                             'PAY IN ACCOUNT NO=' ||
                             L_ICTM_TDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC);
  
    P1FCHPRFM.DEBUG.PR_DEBUG('IF',
                             'PAY IN ACCOUNT BRANCH=' ||
                             L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN);
  
    RETURN L_ICTM_TDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_ICTM_TDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC;
    
  END FN_GET_CLEVER_SAVINGS_PAYIN_ACC;

  FUNCTION FN_GET_TD_MIN_TOPUP_AMT(P_ACC      IN VARCHAR2,
                                   P_BRN      IN VARCHAR2,
                                   P_CCY      IN VARCHAR2,
                                   P_DUE_DATE IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE AS
  
    L_MIN_TOP_UP_AMT    P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN              VARCHAR2(25);
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN
    
      --Get the plan. 3 plans
    
      IF TO_DATE(P_DUE_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
      
        L_PLAN := 'SILVER_PLAN_A';
      
      ELSIF TO_DATE(P_DUE_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE > 366
           
            AND
            TO_DATE(P_DUE_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 731 THEN
      
        L_PLAN := 'SILVER_PLAN_B';
      
      ELSE
      
        L_PLAN := 'SILVER_PLAN_C';
      
      END IF;
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN
    
      --Get the plan. 2 plans
    
      IF TO_DATE(P_DUE_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
      
        L_PLAN := 'GOLD_PLAN_A';
      
      ELSE
      
        L_PLAN := 'GOLD_PLAN_B';
      
      END IF;
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN
    
      --Get the plan. 1 plan
    
      L_PLAN := 'RUBY_PLAN_A';
    
    END IF;
  
    BEGIN
      SELECT B.CODE
        INTO L_MIN_TOP_UP_AMT
        FROM P1FCHPRFM.LMTM_TYPE_OF_TYPES A, P1FCHPRFM.LMTM_TYPE_VALUES B
       WHERE A.TYPE = B.TYPE
         AND A.TYPE = 'CLEVERSAV_MINTOP'
         AND B.VALUE = L_PLAN;
    
    EXCEPTION
      WHEN OTHERS THEN
        P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                                 'FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
      
    END;
  
    P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                             'MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
                             L_MIN_TOP_UP_AMT);
  
    IF P_CCY = 'USD' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT;
    
    ELSIF P_CCY = 'KHR' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT * 4000;
    
    END IF;
  
    RETURN L_MIN_TOP_UP_AMT;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_MIN_TOP_UP_AMT;
  END FN_GET_TD_MIN_TOPUP_AMT;

  FUNCTION FN_GET_TD_INTRATE_TOPUP_AMT(P_ACC        IN VARCHAR2,
                                       P_BRN        IN VARCHAR2,
                                       P_CCY        IN VARCHAR2,
                                       P_TOPUP_DATE IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE AS
  
    L_INT_TOP_UP_RATE   P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN              VARCHAR2(25);
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN
    
      --Get the plan. 3 plans
    
      IF TO_DATE(P_TOPUP_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
      
        L_INT_TOP_UP_RATE := 'SILVER_PLAN_A';
      
      ELSIF TO_DATE(P_TOPUP_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE > 366
           
            AND
            TO_DATE(P_TOPUP_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 731 THEN
      
        L_INT_TOP_UP_RATE := 'SILVER_PLAN_B';
      
      ELSE
      
        L_INT_TOP_UP_RATE := 'SILVER_PLAN_C';
      
      END IF;
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN
    
      --Get the plan. 2 plans
    
      IF TO_DATE(P_TOPUP_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
      
        L_INT_TOP_UP_RATE := 'GOLD_PLAN_A';
      
      ELSE
      
        L_INT_TOP_UP_RATE := 'GOLD_PLAN_B';
      
      END IF;
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN
    
      --Get the plan. 1 plan
    
      L_INT_TOP_UP_RATE := 'RUBY_PLAN_A';
    
    END IF;
  
    BEGIN
      SELECT B.CODE
        INTO L_INT_TOP_UP_RATE
        FROM P1FCHPRFM.LMTM_TYPE_OF_TYPES A, P1FCHPRFM.LMTM_TYPE_VALUES B
       WHERE A.TYPE = B.TYPE
         AND A.TYPE = 'CLEVERSAV_MINTOP'
         AND B.VALUE = L_PLAN;
    
    EXCEPTION
      WHEN OTHERS THEN
        P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                                 'FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
      
    END;
  
    P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                             'MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
                             L_INT_TOP_UP_RATE);
  
    IF P_CCY = 'USD' THEN
    
      L_INT_TOP_UP_RATE := L_INT_TOP_UP_RATE;
    
    ELSIF P_CCY = 'KHR' THEN
    
      L_INT_TOP_UP_RATE := L_INT_TOP_UP_RATE * 4000;
    
    END IF;
  
    RETURN L_INT_TOP_UP_RATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_INT_TOP_UP_RATE;
  END FN_GET_TD_INTRATE_TOPUP_AMT;

  FUNCTION FN_UPDATE_CLEVER_SAV_OVERDUE_ACCS(P_SEQ_NO  IN VARCHAR2,
                                             P_CUST_NO IN VARCHAR2,
                                             P_ACC     IN VARCHAR2)
    RETURN NUMBER IS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
    P_STATUS number;
  
  BEGIN
  
    P1FCHPRFM.DEBUG.PR_DEBUG('IF', 'before updating');
  
    UPDATE IFVW_CLEVER_SAVINGS_OVERDUE_ACCS A
       SET A.STATUS = 'Y', A.ALERT_SENT_TIME = SYSDATE
     WHERE A.SEQ_NO = P_SEQ_NO
       AND A.CUSTOMER_NO = P_CUST_NO
       AND A.ACC = P_ACC;
  
    P1FCHPRFM.DEBUG.PR_DEBUG('IF', 'before updating=' || SQL%ROWCOUNT);
  
    DBMS_OUTPUT.put_line('row modified=' || SQL%ROWCOUNT);
  
    IF SQL%ROWCOUNT = 1 THEN
      P_STATUS := 1;
    
    ELSE
      P_STATUS := 0;
    
    END IF;
  
    COMMIT;
  
    RETURN P_STATUS;
  
  EXCEPTION
  
    WHEN OTHERS THEN
    
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'FAILED IN FN_UPDATE_CLEVER_SAV_OVERDUE_ACCS');
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'ERROR CODE IN FN_UPDATE_CLEVER_SAV_OVERDUE_ACCS=' ||
                               SQLCODE);
      P1FCHPRFM.DEBUG.PR_DEBUG('AC',
                               'ERROR MESSAGE IN FN_UPDATE_CLEVER_SAV_OVERDUE_ACCS=' ||
                               SQLERRM);
    
      DBMS_OUTPUT.put_line('ERROR CODE=' || SQLCODE);
      DBMS_OUTPUT.put_line('ERROR MESSAGE=' || SQLERRM);
    
      P_STATUS := 0;
    
      RETURN P_STATUS;
    
  END FN_UPDATE_CLEVER_SAV_OVERDUE_ACCS;
  --Clever Savings Sampath Ends

END STPKS_DIGITAL_UTLITIES;
