CREATE OR REPLACE PACKAGE BODY ICPKS_MAINT_CUSTOM IS

  PROCEDURE DBG(X VARCHAR2) IS
    L_LEN NUMBER := 0;
    L_IND NUMBER := 1;
  BEGIN
    IF LENGTH(X) < 255 THEN
      DEBUG.PR_DEBUG('IC', 'icpks_maint_custom-->' || X);
    ELSE
      L_LEN := LENGTH(X);
      WHILE L_IND < L_LEN LOOP
        DEBUG.PR_DEBUG('IC',
                       'icpks_maint_custom-->' || SUBSTR(X, L_IND, 255));
        L_IND := L_IND + 255;
      END LOOP;
    END IF;
  END DBG;

  FUNCTION FN_GET_EXT_SDE_VALS(P_BRN     ICTBS_CALC_QUEUE.BRN%TYPE,
                               P_ACC     ICTBS_CALC_QUEUE.ACC%TYPE,
                               P_SDE_ID  VARCHAR2,
                               P_FROM_DT DATE,
                               P_END_DT  DATE)
    RETURN ICPKS_MAINT.TB_ACC_SDE_VALS IS

    --sampath starts
    L_FROM_DATE DATE;
    --sampath ends

   --sampath starts
    L_TD_UPFRONT_PREMAT_FLAG       NUMBER := 0;
    L_TD_UPFRONT_BOOK_FLAG         NUMBER := 0;
    L_TD_UPFRONT_AUTOROLLOVER_FLAG NUMBER := 0;
    --sampath ends

   --EAccount sampath starts
    L_EACCOUNT_100_DEPOSIT_FLAG NUMBER := 0;
    L_EACCOUNT_500_DEPOSIT_FLAG NUMBER := 0;
    L_AMOUNT_100_COUNT          NUMBER := 0;
    L_AMOUNT_500_COUNT          NUMBER := 0;
    L_EACCOUNT_INT_RATE         NUMBER := 0;
    L_COUNT_DAYS_OF_MONTH       NUMBER := 0;
    L_KHQR_PAY_COUNT            NUMBER := 0;
    L_EACCOUNT_KHQR_INT_RATE    NUMBER := 0;
    L_CCY                       STTM_CUST_ACCOUNT.CCY%TYPE;
    --EAccount sampath ends
	
	--Clever Savings Plan Starts
  
    L_CLEVER_SAVINGS_TOPUP_AMT_FOR_MONTH NUMBER := 0;
    L_CLEVER_SAVINGS_CARRY_FWD_TOPUP     NUMBER := 0;
    L_CLEVER_SAVINGS_REV_TOPUP_AMT       NUMBER := 0;
    L_CLEVER_SAVINGS_INT_DAYS            NUMBER := 0;
    L_TOPUP_COUNT_DONE_TODAY             NUMBER := 0;
    L_TOPUP_DONE_TODAY                   NUMBER := 0;
    L_AC_OPEN_DATE STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
    --Clever Savings Plan Ends


    L_TB_ACC_SDE_VALS ICPKS_MAINT.TB_ACC_SDE_VALS;
  BEGIN
    DBG('Inside fn_get_ext_sde_vals');
    DBG('p_sde_id: ' || P_SDE_ID);

    --sampath starts
    IF P_SDE_ID = 'TRACK_DAYS' THEN

      DBG('ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE=' ||
          ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE);

      L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;

      DBG('L_FROM_DATE=' || L_FROM_DATE);

      DBG('P_END_DT=' || P_END_DT);

      --ICPKSS_CALC.G_DAYS_INT := P_END_DT - L_FROM_DATE + 1;

      ICPKSS_CALC.G_DAYS_INT := GLOBAL.APPLICATION_DATE -
                                ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;-- + 1;

      DBG('ICPKSS_CALC.G_DAYS_INT=' || ICPKSS_CALC.G_DAYS_INT);

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := ICPKSS_CALC.G_DAYS_INT;

    DBG('Days From Start Initial--> ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    END IF;

    --sampath ends

  --sampath starts
    IF P_SDE_ID = 'TD_UPFRONT_PREMAT_FLAG' THEN

      DBG('INSIDE TD UPFRONT PRE MATURE FLAG' ||
          ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE);

      --L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;

      DBG('L_FROM_DATE=' || L_FROM_DATE);

      DBG('P_END_DT=' || P_END_DT);


      L_TD_UPFRONT_PREMAT_FLAG := CASE ICPKS_MAINT.G_FULL_REDEM
                                    WHEN 'Y' THEN
                                     1
                                    ELSE
                                     0
                                  END;

      DBG('L_TD_UPFRONT_PREMAT_FLAG=' || L_TD_UPFRONT_PREMAT_FLAG);

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_TD_UPFRONT_PREMAT_FLAG;

    END IF;

    IF P_SDE_ID = 'TD_UPFRONT_BOOK_FLAG' THEN

      DBG('INSIDE TD UPFRONT BOOK FLAG');

      --L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;

      DBG('L_FROM_DATE=' || L_FROM_DATE);

      DBG('P_END_DT=' || P_END_DT);


      L_TD_UPFRONT_BOOK_FLAG := CASE
                                 stpks_stdcusac_utils_2.G_TD_UPFRONT_BOOK_FLAG
                                  WHEN 'Y' THEN
                                   1
                                  ELSE
                                   0
                                END;

      DBG('L_TD_UPFRONT_BOOK_FLAG=' || L_TD_UPFRONT_BOOK_FLAG);

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_TD_UPFRONT_BOOK_FLAG;

      DBG('TD UPFRONT BOOK FLAG= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    END IF;

    IF P_SDE_ID = 'TD_UPFRONT_AUTOROLLOVER_FLAG' THEN

      DBG('INSIDE TD AUTO ROLLOVER FLAG');

      --L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;

      DBG('L_FROM_DATE=' || L_FROM_DATE);

      DBG('P_END_DT=' || P_END_DT);


      L_TD_UPFRONT_AUTOROLLOVER_FLAG := CASE
                                          WHEN ICPKS_BOD.pkg_ictm_acc.auto_rollover = 'Y' AND
                                               ICPKS_BOD_CUSTOM.G_TD_UPFRONT_ROLLOVER_AMT_FLAG = 'Y' THEN
                                           1
                                          ELSE
                                           0
                                        END;

      DBG('L_TD_UPFRONT_AUTOROLLOVER_FLAG=' ||
          L_TD_UPFRONT_AUTOROLLOVER_FLAG);

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_TD_UPFRONT_AUTOROLLOVER_FLAG;

      DBG('TD UPFRONT AUTOROLLOVER FLAG= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    END IF;

    --sampath ends

  --EAccount sampath starts
  IF P_SDE_ID = 'EACCOUNT_INT_RATE' THEN

      DBG('INSIDE EACCOUNT_INT_RATE');

      DBG('P_FROM_DT=' || P_FROM_DT);

      DBG('P_END_DT=' || P_END_DT);

      SELECT CCY
        INTO L_CCY
        FROM STTM_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;

      IF L_CCY = 'USD' THEN

        BEGIN

          SELECT COUNT(1)
            INTO L_AMOUNT_100_COUNT
            FROM CAVW_ENTRIES A
           WHERE A.AC_NO = P_ACC
             AND A.DRCR_IND = 'C'
             AND A.LCY_AMOUNT >= 100
             AND A.value_dt >= P_FROM_DT
             AND A.value_dt <= P_END_DT
             AND A.EVENT NOT IN ('CYPO', 'REVR')
             AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION

          WHEN OTHERS THEN

            L_AMOUNT_100_COUNT := 0;

        END;

        DBG('L_AMOUNT_100_COUNT=' || L_AMOUNT_100_COUNT);

        BEGIN

          SELECT COUNT(1)
            INTO L_AMOUNT_500_COUNT
            FROM CAVW_ENTRIES A
           WHERE A.AC_NO = P_ACC
             AND A.DRCR_IND = 'C'
             AND A.LCY_AMOUNT >= 500
             AND A.value_dt >= P_FROM_DT
             AND A.value_dt <= P_END_DT
             AND A.EVENT NOT IN ('CYPO', 'REVR')
             AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION

          WHEN OTHERS THEN

            L_AMOUNT_500_COUNT := 0;

        END;

        DBG('L_AMOUNT_500_COUNT=' || L_AMOUNT_500_COUNT);

      ELSE

        BEGIN

          SELECT COUNT(1)
            INTO L_AMOUNT_100_COUNT
            FROM CAVW_ENTRIES A
           WHERE A.AC_NO = P_ACC
             AND A.DRCR_IND = 'C'
             AND A.FCY_AMOUNT >= 400000
             AND A.value_dt >= P_FROM_DT
             AND A.value_dt <= P_END_DT
             AND A.EVENT NOT IN ('CYPO', 'REVR')
             AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION

          WHEN OTHERS THEN

            L_AMOUNT_100_COUNT := 0;

        END;

        DBG('L_AMOUNT_100_COUNT=' || L_AMOUNT_100_COUNT);

        BEGIN

          SELECT COUNT(1)
            INTO L_AMOUNT_500_COUNT
            FROM CAVW_ENTRIES A
           WHERE A.AC_NO = P_ACC
             AND A.DRCR_IND = 'C'
             AND A.FCY_AMOUNT >= 2000000
             AND A.value_dt >= P_FROM_DT
             AND A.value_dt <= P_END_DT
             AND A.EVENT NOT IN ('CYPO', 'REVR')
             AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

        EXCEPTION

          WHEN OTHERS THEN

            L_AMOUNT_500_COUNT := 0;

        END;

        DBG('L_AMOUNT_500_COUNT=' || L_AMOUNT_500_COUNT);

      END IF;

      IF L_AMOUNT_500_COUNT <> 0 THEN

        L_EACCOUNT_INT_RATE := 2;

      ELSIF L_AMOUNT_100_COUNT <> 0 THEN

        L_EACCOUNT_INT_RATE := 1;

      ELSE

        L_EACCOUNT_INT_RATE := 0;

      END IF;

      DBG('FINAL EACCOUNT_INT_RATE=' || L_EACCOUNT_INT_RATE);

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_EACCOUNT_INT_RATE;

      DBG('EACCOUNT_INT_RATE= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    END IF;

    IF P_SDE_ID = 'EACCOUNT_KHQR_INT_RATE' THEN

      DBG('INSIDE EACCOUNT_INT_RATE');

      DBG('P_FROM_DT=' || P_FROM_DT);

      DBG('P_END_DT=' || P_END_DT);

      BEGIN

        SELECT COUNT(1)
          INTO L_KHQR_PAY_COUNT
          FROM CAVW_ENTRIES A
         WHERE A.AC_NO = P_ACC
           AND A.DRCR_IND = 'D'
           AND A.PRODUCT IN ('PRQR', 'BQRP')
           AND A.value_dt >= P_FROM_DT
           AND A.value_dt <= P_END_DT
           AND A.EVENT NOT IN ('CYPO', 'REVR');
        --AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');

      EXCEPTION

        WHEN OTHERS THEN

          L_KHQR_PAY_COUNT := 0;

      END;

      DBG('L_KHQR_PAY_COUNT=' || L_KHQR_PAY_COUNT);

      IF L_KHQR_PAY_COUNT >= 3 THEN

        L_EACCOUNT_KHQR_INT_RATE := 1;

      ELSE

        L_EACCOUNT_KHQR_INT_RATE := 0;

      END IF;

      DBG('FINAL EACCOUNT_KHQR_INT_RATE FLAG FLAG=' ||
          L_EACCOUNT_KHQR_INT_RATE);

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_EACCOUNT_KHQR_INT_RATE;

      DBG('EACCOUNT_KHQR_INT_RATE= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    END IF;

    IF P_SDE_ID = 'COUNT_DAYS_OF_MONTH' THEN

      DBG('INSIDE COUNT_DAYS_OF_MONTH');

      DBG('P_FROM_DT=' || P_FROM_DT);

      DBG('P_END_DT=' || P_END_DT);

      --L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;

      --DBG('L_FROM_DATE=' || L_FROM_DATE);

      --ICPKSS_CALC.G_DAYS_INT := P_END_DT - L_FROM_DATE + 1;

      --L_COUNT_DAYS_OF_MONTH := GLOBAL.APPLICATION_DATE - P_FROM_DT + 1;

      L_COUNT_DAYS_OF_MONTH := GLOBAL.APPLICATION_DATE -
                               trunc(global.application_date, 'mm') + 1;

      DBG('L_COUNT_DAYS_OF_MONTH=' || L_COUNT_DAYS_OF_MONTH);

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_COUNT_DAYS_OF_MONTH;

      DBG('COUNT_DAYS_OF_MONTH=' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    END IF;
  --EAccount sampath ends
  
  --Clever Savings Plan Starts
  
    IF P_SDE_ID = 'CLEVER_SAVINGS_TOPUP_AMT' THEN
    
      DBG('INSIDE CLEVER_SAVINGS_TOPUP_AMT');
    
      DBG('P_FROM_DT=' || P_FROM_DT);
    
      DBG('P_END_DT=' || P_END_DT);
    
      --if there is a top up today then make sure to execute the below only once on cosolidated days on consolidated amount and make the flag as FLASE so that
      --it does not execute again during the same eod 
      --otherwise it is calculating 2 times with different number for days
    
      --if there is no topup then below exact code works fine
    
      --Get Account Details and Liquidation Details
    
      BEGIN
      
        SELECT SUM(TOPUP_AMT)
          INTO L_CLEVER_SAVINGS_TOPUP_AMT_FOR_MONTH
          FROM TDTB_EVENT_DETAILS A, ICTB_ACC_PR B
         WHERE A.ACC = B.ACC
           AND A.BRN = B.BRN
           AND A.ACC = P_ACC
           AND A.BRN = P_BRN
           AND A.EVENT_DATE > B.LAST_LIQ_DT
           AND A.EVENT_DATE <= B.NEXT_LIQ_DT;
        --AND A.EVENT_DATE >= P_FROM_DT
        --AND A.EVENT_DATE <= P_END_DT;
        --AND A.EVENT_DATE BETWEEN P_FROM_DT AND P_END_DT;
      
      EXCEPTION
      
        WHEN OTHERS THEN
        
          L_CLEVER_SAVINGS_TOPUP_AMT_FOR_MONTH := 0;
        
      END;
    
      DBG('L_CLEVER_SAVINGS_TOPUP_AMT_FOR_MONTH=' ||
          L_CLEVER_SAVINGS_TOPUP_AMT_FOR_MONTH);
    
      L_TB_ACC_SDE_VALS.DELETE;
    
      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_CLEVER_SAVINGS_TOPUP_AMT_FOR_MONTH;
    
      DBG('CLEVER_SAVINGS_TOPUP_AMT= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);
    
    END IF;
  
    IF P_SDE_ID = 'CLEVER_SAVINGS_TOPUP_TODAY' THEN
    
      DBG('INSIDE TOPUP_DONE_TODAY');
    
      DBG('P_FROM_DT=' || P_FROM_DT);
    
      DBG('P_END_DT=' || P_END_DT);
    
      --if there is a top up today then make sure to execute the below only once on cosolidated days on consolidated amount and make the flag as FLASE so that
      --it does not execute again during the same eod 
      --otherwise it is calculating 2 times with different number for days
    
      --if there is no topup then below exact code works fine
    
      BEGIN
      
        SELECT COUNT(1)
          INTO L_TOPUP_COUNT_DONE_TODAY
          FROM TDTB_EVENT_DETAILS A
         WHERE A.ACC = P_ACC
           AND A.BRN = P_BRN
           AND A.EVENT_DATE = GLOBAL.application_date;
      
      EXCEPTION
      
        WHEN OTHERS THEN
        
          L_TOPUP_COUNT_DONE_TODAY := 0;
        
      END;
    
      DBG('L_TOPUP_COUNT_DONE_TODAY=' || L_TOPUP_COUNT_DONE_TODAY);
    
      IF L_TOPUP_COUNT_DONE_TODAY > 0 THEN
      
        L_TOPUP_DONE_TODAY := 1;
      
      ELSE
      
        L_TOPUP_DONE_TODAY := 0;
      
      END IF;
    
      DBG('L_TOPUP_DONE_TODAY=' || L_TOPUP_DONE_TODAY);
    
      L_TB_ACC_SDE_VALS.DELETE;
    
      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_TOPUP_DONE_TODAY;
    
      DBG('TOPUP_DONE_TODAY= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);
    
    END IF;
  
    IF P_SDE_ID = 'CLEVER_SAVINGS_INT_DAYS' THEN
    
      DBG('INSIDE CLEVER SAVINGS INT DAYS COUNT');
    
      DBG('ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE=' ||
          ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE);
    
      DBG('L_FROM_DATE=' || L_FROM_DATE);
    
      DBG('P_END_DT=' || P_END_DT);
    
      --ICPKSS_CALC.G_DAYS_INT := P_END_DT - L_FROM_DATE + 1;
    
      BEGIN
        SELECT ST.AC_OPEN_DATE
          INTO L_AC_OPEN_DATE
          FROM STTMS_CUST_ACCOUNT ST
         WHERE CUST_AC_NO = P_ACC
           AND BRANCH_CODE = P_BRN;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_AC_OPEN_DATE := NULL;
      END;
    
     -- L_CLEVER_SAVINGS_INT_DAYS := GLOBAL.APPLICATION_DATE -
      --                             ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE + 1;
      
      L_CLEVER_SAVINGS_INT_DAYS := GLOBAL.application_date - L_AC_OPEN_DATE + 1;
      
      DBG('L_CLEVER_SAVINGS_INT_DAYS=' || L_CLEVER_SAVINGS_INT_DAYS);
    
      L_TB_ACC_SDE_VALS.DELETE;
    
      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_CLEVER_SAVINGS_INT_DAYS;
    
      DBG('Days From Start Initial--> ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);
    
    END IF;
  
    IF P_SDE_ID = 'CLEVER_SAVINGS_CARRY_FWD_TOPUP' THEN
    
      DBG('INSIDE CLEVER_SAVINGS_CARRY_FWD_TOPUP');
    
      DBG('P_FROM_DT=' || P_FROM_DT);
    
      DBG('P_END_DT=' || P_END_DT);
    
      BEGIN
      
        SELECT SUM(TOPUP_AMT)
          INTO L_CLEVER_SAVINGS_CARRY_FWD_TOPUP
          FROM TDTB_EVENT_DETAILS A
         WHERE A.ACC = P_ACC
           AND A.BRN = P_BRN;
        --AND A.EVENT_DATE >= P_FROM_DT
        --AND A.EVENT_DATE <= P_END_DT;
        --AND A.EVENT_DATE BETWEEN P_FROM_DT AND P_END_DT;
      
      EXCEPTION
      
        WHEN OTHERS THEN
        
          L_CLEVER_SAVINGS_CARRY_FWD_TOPUP := 0;
        
      END;
    
      DBG('L_CLEVER_SAVINGS_CARRY_FWD_TOPUP=' ||
          L_CLEVER_SAVINGS_CARRY_FWD_TOPUP);
    
      L_TB_ACC_SDE_VALS.DELETE;
    
      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_CLEVER_SAVINGS_CARRY_FWD_TOPUP;
    
      DBG('CLEVER_SAVINGS_CARRY_FWD_TOPUP= ' || L_TB_ACC_SDE_VALS(1)
          .SDE_VAL);
    
    END IF;
  
    IF P_SDE_ID = 'CLEVER_SAVINGS_REV_TOPUP_AMT' THEN
    
      DBG('INSIDE CLEVER_SAVINGS_REV_TOPUP_AMT');
    
      DBG('P_FROM_DT=' || P_FROM_DT);
    
      DBG('P_END_DT=' || P_END_DT);
    
      BEGIN
      
        SELECT SUM(TOPUP_AMT)
          INTO L_CLEVER_SAVINGS_REV_TOPUP_AMT
          FROM TDTB_EVENT_DETAILS A
         WHERE A.ACC = P_ACC
           AND A.BRN = P_BRN;
        --AND A.EVENT_DATE >= P_FROM_DT
        --AND A.EVENT_DATE <= P_END_DT;
        --AND A.EVENT_DATE BETWEEN P_FROM_DT AND P_END_DT;
      
      EXCEPTION
      
        WHEN OTHERS THEN
        
          L_CLEVER_SAVINGS_REV_TOPUP_AMT := 0;
        
      END;
    
      DBG('L_CLEVER_SAVINGS_REV_TOPUP_AMT=' ||
          L_CLEVER_SAVINGS_REV_TOPUP_AMT);
    
      L_TB_ACC_SDE_VALS.DELETE;
    
      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_CLEVER_SAVINGS_REV_TOPUP_AMT;
    
      DBG('CLEVER_SAVINGS_REV_TOPUP_AMT= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);
    
    END IF;
  
    --Clever Savings Plan Ends

    DBG('Returning from fn_get_ext_sde_vals');
    RETURN L_TB_ACC_SDE_VALS;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_get_ext_sde_vals');
      RETURN L_TB_ACC_SDE_VALS;
  END FN_GET_EXT_SDE_VALS;

  FUNCTION FN_GET_IL_SDE(P_BRANCH_CODE     IN ILTBS_SYS_ACCOUNT.SYSTEM_ACCOUNT_BRANCH%TYPE,
                         P_SYS_AC_NO       IN ILTBS_SYS_ACCOUNT.SYSTEM_ACCOUNT%TYPE,
                         P_FROM_DT         IN ILTBS_VD_BALANCES.VALUE_DATE%TYPE,
                         P_TO_DT           IN ILTBS_VD_BALANCES.VALUE_DATE%TYPE,
                         P_SDE_ID          IN ICTMS_SDE.SDE_ID%TYPE,
                         P_TB_ACC_SDE_VALS IN OUT ICPKSS_MAINT.TB_ACC_SDE_VALS,
                         P_ERROR_CODE      IN OUT VARCHAR2,
                         P_ERROR_PARAMETER IN OUT VARCHAR2,
                         P_FN_CALL_ID      IN NUMBER,
                         P_TB_CUSTOM_DATA  IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_get_il_sde');

    DBG('Returning from fn_get_il_sde');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_get_il_sde');
      RETURN FALSE;
  END FN_GET_IL_SDE;

  FUNCTION FN_GET_SDE_VALS(P_BRN            ICTBS_CALC_QUEUE.BRN%TYPE,
                           P_ACC            ICTBS_CALC_QUEUE.ACC%TYPE,
                           P_SDE_ID         VARCHAR2,
                           P_FROM_DT        DATE,
                           P_END_DT         DATE,
                           P_FN_CALL_ID     NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN ICPKS_MAINT.TB_ACC_SDE_VALS IS
    L_TB_ACC_SDE_VALS ICPKS_MAINT.TB_ACC_SDE_VALS;

    /*--sampath starts
    L_FROM_DATE DATE;
    --sampath ends*/
  BEGIN
    DBG('Inside icpks_maint_custom.fn_get_sde_vals for sde_id ' ||
        P_SDE_ID);

    /* --sampath starts
    IF P_SDE_ID = 'TRACK_DAYS' THEN

      L_FROM_DATE            := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;
      ICPKSS_CALC.G_DAYS_INT := P_END_DT - L_FROM_DATE + 1;

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := ICPKSS_CALC.G_DAYS_INT;

    END IF;

    DBG('Days From Start Initial--> ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    --sampath ends*/

    DBG('Returning successfully from icpks_maint_cluster.fn_get_sde_vals');
    RETURN L_TB_ACC_SDE_VALS;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_get_il_sde' || SQLERRM);
      RETURN L_TB_ACC_SDE_VALS;
  END FN_GET_SDE_VALS;

  FUNCTION FN_GET_LIQN_DT(P_BRN            IN VARCHAR2,
                          P_ACC            IN VARCHAR2,
                          P_PROD           IN VARCHAR2,
                          P_FN_CALL_ID     IN NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN DATE IS
    L_NEXT_LIQ_DT DATE;
  BEGIN
    DBG('Inside icpks_maint_custom.fn_get_liqn_dt');

    DBG('Returning from icpks_maint_custom.fn_get_liqn_dt');
    RETURN L_NEXT_LIQ_DT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of icpks_maint_custom.fn_get_liqn_dt');
      RETURN NULL;
  END FN_GET_LIQN_DT;

END ICPKS_MAINT_CUSTOM;
