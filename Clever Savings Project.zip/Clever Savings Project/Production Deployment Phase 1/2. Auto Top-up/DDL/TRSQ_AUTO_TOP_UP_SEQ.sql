-- Create sequence 
create sequence TRSQ_AUTO_TOP_UP_SEQ
minvalue 1
maxvalue 9999999999999
start with 1
increment by 1
cache 20;
