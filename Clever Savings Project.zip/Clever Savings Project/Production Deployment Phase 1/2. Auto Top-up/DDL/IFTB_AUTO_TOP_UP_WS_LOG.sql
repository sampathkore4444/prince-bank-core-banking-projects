-- Create table
create table IFTB_AUTO_TOP_UP_WS_LOG
(
  reference_no  VARCHAR2(105),
  invoke_date   TIMESTAMP(6),
  customer_no   VARCHAR2(105),
  cust_ac_no    VARCHAR2(105),
  req_type      VARCHAR2(25),
  req_msg       CLOB,
  res_msg       CLOB,
  status        CHAR(1),
  addl_info     VARCHAR2(105),
  error_code    VARCHAR2(105),
  error_message VARCHAR2(255)
)
/
alter table IFTB_AUTO_TOP_UP_WS_LOG add primary key (REFERENCE_NO)
/