-- Create table
create table IFTB_AUTO_TOP_UP_TEST
(
  acc     VARCHAR2(25),
  brn     VARCHAR2(3),
  ccy     VARCHAR2(3),
  type    VARCHAR2(25),
  time_in DATE
)
/