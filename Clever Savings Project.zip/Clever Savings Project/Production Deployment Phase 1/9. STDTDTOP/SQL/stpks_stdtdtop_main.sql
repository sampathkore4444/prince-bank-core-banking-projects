CREATE OR REPLACE PACKAGE BODY stpks_stdtdtop_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : stpks_stdtdtop_main.sql
     **
     ** Module     : Static Maintenance
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Ui_Name            VARCHAR2(50) := 'STDTDTOP';
   g_stdtdtop         stpks_stdtdtop_Main.ty_stdtdtop;
   g_Req_Key                 VARCHAR2(32767);
   g_Key_Id                  VARCHAR2(32767);
   g_Post_Upl_Stat     VARCHAR2(1);
   g_Curr_Stage        VARCHAR2(20);
   g_Tanking_Status      VARCHAR2(1);
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Kernel    BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'stpks_stdtdtop_Main ==>'||p_Msg;
         Debug.Pr_Debug('ST' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'STDTDTOP';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   FUNCTION  Fn_Get_Curr_Stage RETURN VARCHAR2 IS
   BEGIN
      RETURN g_Curr_Stage;
   END  Fn_Get_Curr_Stage;
   FUNCTION  Fn_Get_Tanked_Stat RETURN VARCHAR2 IS
   BEGIN
      RETURN g_Tanking_Status;
   END  Fn_get_tanked_stat;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      stpks_stdtdtop_Kernel.Pr_Skip_Handler (P_Stage);
      stpks_stdtdtop_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Kernel IS
   BEGIN
      g_Skip_Kernel := TRUE;
   END Pr_Set_Skip_Kernel;
   PROCEDURE Pr_Set_Activate_Kernel IS
   BEGIN
      g_Skip_Kernel := FALSE;
   END Pr_Set_Activate_Kernel;
   FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN IS
   BEGIN
      IF g_curr_stage IS NOT NULL THEN
         RETURN G_Skip_Kernel;
      ELSIF Cspks_Req_Global.g_Release_Type = Cspks_Req_Global.p_Kernel THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Kernel;
      END IF;
   END  Fn_Skip_Kernel;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF g_curr_stage IS NOT NULL THEN
         RETURN G_Skip_Custom;
      ELSIF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_stdtdtop       IN   OUT stpks_stdtdtop_Main.ty_stdtdtop,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_TDTOPUP_DETAIL' THEN
            p_stdtdtop.v_ictbs_tdtopup_detail.BRN := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.ACC := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.CCY := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_VALUE_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_VALUE_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_stdtdtop.v_ictbs_tdtopup_detail.MATAMT_BEFORE_TOPUP := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.INTRATE_BEFORE_TOPUP := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.NARRATIVE := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('ACCOUNT_DESC') :=Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_stdtdtop.v_ictbs_tdtopup_detail.TD_OPEN_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_stdtdtop.v_ictbs_tdtopup_detail.TD_OPEN_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_stdtdtop.v_ictbs_tdtopup_detail.TENOR_DD := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.TENOR_MM := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.TENOR_YY := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_stdtdtop.v_ictbs_tdtopup_detail.MATDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_stdtdtop.v_ictbs_tdtopup_detail.MATDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_stdtdtop.v_ictbs_tdtopup_detail.TDAMT_BEFORE_TOPUP := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.TDAMT_AFTER_TOPUP := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.MATAMT_AFTER_TOPUP := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.INTRATE_AFTER_TOPUP := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.EXT_REFERENCE := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('CUSTOMER_DESC') :=Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.CUST_NO := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.REMITTER_NAME := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.MAKER_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_stdtdtop.v_ictbs_tdtopup_detail.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_stdtdtop.v_ictbs_tdtopup_detail.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_stdtdtop.v_ictbs_tdtopup_detail.CHECKER_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_stdtdtop.v_ictbs_tdtopup_detail.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_stdtdtop.v_ictbs_tdtopup_detail.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_stdtdtop.v_ictbs_tdtopup_detail.MOD_NO := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.RECORD_STAT := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.AUTH_STAT := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictbs_tdtopup_detail.ONCE_AUTH := Cspks_Req_Global.Fn_GetVal;
         ELSIF  l_Node = 'BLK_TDTOPUP_PAYIN' THEN
            l_Dsn_Rec_Cnt_2 :=  p_stdtdtop.v_ictms_tdtopup_payin.count +1 ;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_PAYOPT := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_TDAMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_OFFSET_BRN := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_TDOFFSET_ACC := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_PERCENTAGE := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).TOPUP_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).BRN := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).ACC := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).SEQNO := Cspks_Req_Global.Fn_GetVal;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).topup_ref_no :=p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).acc :=p_stdtdtop.v_ictbs_tdtopup_detail.acc;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).brn :=p_stdtdtop.v_ictbs_tdtopup_detail.brn;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_stdtdtop.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of stpks_stdtdtop_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_stdtdtop       IN   OUT stpks_stdtdtop_Main.ty_stdtdtop,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_TDTOPUP_DETAIL','Tdtopup-Detail-Full','Tdtopup-Detail-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key IN( 'ACCOUNT_BRANCH','BRN')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.BRN := l_Val;
               ELSIF l_Key IN( 'AC_NO','ACC')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.ACC := l_Val;
               ELSIF l_Key = 'CCY' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.CCY := l_Val;
               ELSIF l_Key = 'TOPUP_REF_NO' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_REF_NO := l_Val;
               ELSIF l_Key IN( 'TOPUP_AMT','TOPUP_AMOUNT')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_AMOUNT := l_Val;
               ELSIF l_Key IN( 'VALUEDATE','TOPUP_VALUE_DATE')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_VALUE_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_VALUE_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key IN( 'MATURITY_AMT','MATAMT_BEFORE_TOPUP')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.MATAMT_BEFORE_TOPUP := l_Val;
               ELSIF l_Key IN( 'INTEREST_RATE','INTRATE_BEFORE_TOPUP')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.INTRATE_BEFORE_TOPUP := l_Val;
               ELSIF l_Key = 'NARRATIVE' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.NARRATIVE := l_Val;
               ELSIF l_Key IN( 'ACC_DESC','ACCOUNT_DESC')  THEN
                  p_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('ACCOUNT_DESC') := l_Val;
               ELSIF l_Key = 'TOPUP_DATE' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'TD_OPEN_DATE' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_stdtdtop.v_ictbs_tdtopup_detail.TD_OPEN_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_stdtdtop.v_ictbs_tdtopup_detail.TD_OPEN_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key IN( 'DAYS','TENOR_DD')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.TENOR_DD := l_Val;
               ELSIF l_Key IN( 'MONTHS','TENOR_MM')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.TENOR_MM := l_Val;
               ELSIF l_Key IN( 'YEARS','TENOR_YY')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.TENOR_YY := l_Val;
               ELSIF l_Key IN( 'MATDT','MATDATE')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_stdtdtop.v_ictbs_tdtopup_detail.MATDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_stdtdtop.v_ictbs_tdtopup_detail.MATDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'TDAMT_BEFORE_TOPUP' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.TDAMT_BEFORE_TOPUP := l_Val;
               ELSIF l_Key = 'TDAMT_AFTER_TOPUP' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.TDAMT_AFTER_TOPUP := l_Val;
               ELSIF l_Key = 'MATAMT_AFTER_TOPUP' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.MATAMT_AFTER_TOPUP := l_Val;
               ELSIF l_Key IN( 'INT_RATE_OPTION','INTRATE_AFTER_TOPUP')  THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.INTRATE_AFTER_TOPUP := l_Val;
               ELSIF l_Key = 'EXT_REFERENCE' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.EXT_REFERENCE := l_Val;
               ELSIF l_Key IN( 'CUSTOMER_NAME','CUSTOMER_DESC')  THEN
                  p_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('CUSTOMER_DESC') := l_Val;
               ELSIF l_Key = 'CUST_NO' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.CUST_NO := l_Val;
               ELSIF l_Key = 'REMITTER_NAME' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.REMITTER_NAME := l_Val;
               ELSIF l_Key = 'MAKER' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.MAKER_ID := l_Val;
               ELSIF l_Key = 'MAKERSTAMP' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_stdtdtop.v_ictbs_tdtopup_detail.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_stdtdtop.v_ictbs_tdtopup_detail.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'CHECKER' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.CHECKER_ID := l_Val;
               ELSIF l_Key = 'CHECKERSTAMP' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_stdtdtop.v_ictbs_tdtopup_detail.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_stdtdtop.v_ictbs_tdtopup_detail.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'MODNO' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.MOD_NO := l_Val;
               ELSIF l_Key = 'TXNSTAT' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.RECORD_STAT := l_Val;
               ELSIF l_Key = 'AUTHSTAT' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.AUTH_STAT := l_Val;
               ELSIF l_Key = 'ONCEAUTH' THEN
                  p_stdtdtop.v_ictbs_tdtopup_detail.ONCE_AUTH := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         ELSIF  l_Node IN ( 'BLK_TDTOPUP_PAYIN','Tdtopup-Payin') THEN
            l_Dsn_Rec_Cnt_2 :=  p_stdtdtop.v_ictms_tdtopup_payin.count +1 ;
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key IN( 'FUND_OPT','MULTIMODE_PAYOPT')  THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_PAYOPT := l_Val;
               ELSIF l_Key IN( 'AMNT','MULTIMODE_TDAMOUNT')  THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_TDAMOUNT := l_Val;
               ELSIF l_Key IN( 'OFFSET_BRN','MULTIMODE_OFFSET_BRN')  THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_OFFSET_BRN := l_Val;
               ELSIF l_Key IN( 'OFFSET_ACCOUNT','MULTIMODE_TDOFFSET_ACC')  THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_TDOFFSET_ACC := l_Val;
               ELSIF l_Key IN( 'PECENT','MULTIMODE_PERCENTAGE')  THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).MULTIMODE_PERCENTAGE := l_Val;
               ELSIF l_Key = 'TOPUP_REF_NO' THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).TOPUP_REF_NO := l_Val;
               ELSIF l_Key = 'BRN' THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).BRN := l_Val;
               ELSIF l_Key = 'ACC' THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).ACC := l_Val;
               ELSIF l_Key = 'SEQNO' THEN
                  p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).SEQNO := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).topup_ref_no :=p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).acc :=p_stdtdtop.v_ictbs_tdtopup_detail.acc;
            p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).brn :=p_stdtdtop.v_ictbs_tdtopup_detail.brn;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_stdtdtop.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of stpks_stdtdtop_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_stdtdtop          IN stpks_stdtdtop_Main.ty_stdtdtop,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_1_Lvl_Counter := 0;
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_TDTOPUP_DETAIL',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','BRN',p_stdtdtop.v_ictbs_tdtopup_detail.brn);
      Cspks_Req_Global.Pr_Write('V','ACC',p_stdtdtop.v_ictbs_tdtopup_detail.acc);
      Cspks_Req_Global.Pr_Write('V','CCY',p_stdtdtop.v_ictbs_tdtopup_detail.ccy);
      Cspks_Req_Global.Pr_Write('V','TOPUP_REF_NO',p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no);
      Cspks_Req_Global.Pr_Write('V','TOPUP_AMOUNT',p_stdtdtop.v_ictbs_tdtopup_detail.topup_amount);
      IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date) <>
            p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date THEN
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','TOPUP_VALUE_DATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','MATAMT_BEFORE_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup);
      Cspks_Req_Global.Pr_Write('V','INTRATE_BEFORE_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup);
      Cspks_Req_Global.Pr_Write('V','NARRATIVE',p_stdtdtop.v_ictbs_tdtopup_detail.narrative);
      l_Desc_Vc := NULL;
      BEGIN
         l_Desc_Vc := p_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('ACCOUNT_DESC');
      EXCEPTION
         WHEN OTHERS THEN
            Dbg(SQLERRM);
            Dbg('Failed in Populating Description Field   :ACCOUNT_DESC');
      END;
      Cspks_Req_Global.Pr_Write('V','ACCOUNT_DESC',l_Desc_Vc);
      IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.topup_date) <>
            p_stdtdtop.v_ictbs_tdtopup_detail.topup_date THEN
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.topup_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.topup_date,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','TOPUP_DATE',l_Date_Val);
      IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date) <>
            p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date THEN
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','TD_OPEN_DATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','TENOR_DD',p_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd);
      Cspks_Req_Global.Pr_Write('V','TENOR_MM',p_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm);
      Cspks_Req_Global.Pr_Write('V','TENOR_YY',p_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy);
      IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.matdate) <>
            p_stdtdtop.v_ictbs_tdtopup_detail.matdate THEN
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.matdate,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.matdate,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','MATDATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','TDAMT_BEFORE_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup);
      Cspks_Req_Global.Pr_Write('V','TDAMT_AFTER_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup);
      Cspks_Req_Global.Pr_Write('V','MATAMT_AFTER_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup);
      Cspks_Req_Global.Pr_Write('V','INTRATE_AFTER_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup);
      Cspks_Req_Global.Pr_Write('V','EXT_REFERENCE',p_stdtdtop.v_ictbs_tdtopup_detail.ext_reference);
      l_Desc_Vc := NULL;
      BEGIN
         l_Desc_Vc := p_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('CUSTOMER_DESC');
      EXCEPTION
         WHEN OTHERS THEN
            Dbg(SQLERRM);
            Dbg('Failed in Populating Description Field   :CUSTOMER_DESC');
      END;
      Cspks_Req_Global.Pr_Write('V','CUSTOMER_DESC',l_Desc_Vc);
      Cspks_Req_Global.Pr_Write('V','CUST_NO',p_stdtdtop.v_ictbs_tdtopup_detail.cust_no);
      Cspks_Req_Global.Pr_Write('V','REMITTER_NAME',p_stdtdtop.v_ictbs_tdtopup_detail.remitter_name);
      Cspks_Req_Global.Pr_Write('V','MAKER',p_stdtdtop.v_ictbs_tdtopup_detail.maker_id);
      IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp) <>
            p_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','MAKERSTAMP',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','CHECKER',p_stdtdtop.v_ictbs_tdtopup_detail.checker_id);
      IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp) <>
            p_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','CHECKERSTAMP',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','MODNO',p_stdtdtop.v_ictbs_tdtopup_detail.mod_no);
      Cspks_Req_Global.Pr_Write('V','TXNSTAT',p_stdtdtop.v_ictbs_tdtopup_detail.record_stat);
      Cspks_Req_Global.Pr_Write('V','AUTHSTAT',p_stdtdtop.v_ictbs_tdtopup_detail.auth_stat);
      Cspks_Req_Global.Pr_Write('V','ONCEAUTH',p_stdtdtop.v_ictbs_tdtopup_detail.once_auth);

      --Dbg('Building Childs Of :BLK_TDTOPUP_DETAIL..');
      l_Dsn_Rec_Cnt_2 := 0;
      IF p_stdtdtop.v_ictms_tdtopup_payin.COUNT > 0 THEN
         FOR i_2 IN  1..p_stdtdtop.v_ictms_tdtopup_payin.COUNT LOOP
            l_Dsn_Rec_Cnt_2 := i_2;
            l_Master_Childs  :=  l_Master_Childs +1;
            l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','BLK_TDTOPUP_PAYIN',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','MULTIMODE_PAYOPT',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_payopt);
            Cspks_Req_Global.Pr_Write('V','MULTIMODE_TDAMOUNT',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_tdamount);
            Cspks_Req_Global.Pr_Write('V','MULTIMODE_OFFSET_BRN',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_offset_brn);
            Cspks_Req_Global.Pr_Write('V','MULTIMODE_TDOFFSET_ACC',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_tdoffset_acc);
            Cspks_Req_Global.Pr_Write('V','MULTIMODE_PERCENTAGE',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_percentage);
            Cspks_Req_Global.Pr_Write('V','TOPUP_REF_NO',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).topup_ref_no);
            Cspks_Req_Global.Pr_Write('V','BRN',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).brn);
            Cspks_Req_Global.Pr_Write('V','ACC',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).acc);
            Cspks_Req_Global.Pr_Write('V','SEQNO',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).seqno);
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_stdtdtop          IN stpks_stdtdtop_Main.ty_stdtdtop,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF (  p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no IS NOT NULL 
          )
          THEN
            l_1_Lvl_Counter := 0;
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Tdtopup-Detail-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','ACCOUNT_BRANCH',p_stdtdtop.v_ictbs_tdtopup_detail.brn);
            Cspks_Req_Global.Pr_Write('V','AC_NO',p_stdtdtop.v_ictbs_tdtopup_detail.acc);
            Cspks_Req_Global.Pr_Write('V','CCY',p_stdtdtop.v_ictbs_tdtopup_detail.ccy);
            Cspks_Req_Global.Pr_Write('V','TOPUP_REF_NO',p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no);
            Cspks_Req_Global.Pr_Write('V','TOPUP_AMT',p_stdtdtop.v_ictbs_tdtopup_detail.topup_amount);
            IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date) <>
                  p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date THEN
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','VALUEDATE',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','MATURITY_AMT',p_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup);
            Cspks_Req_Global.Pr_Write('V','INTEREST_RATE',p_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup);
            Cspks_Req_Global.Pr_Write('V','NARRATIVE',p_stdtdtop.v_ictbs_tdtopup_detail.narrative);
            l_Desc_Vc := NULL;
            BEGIN
               l_Desc_Vc := p_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('ACCOUNT_DESC');
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Populating Description Field   :ACCOUNT_DESC');
            END;
            Cspks_Req_Global.Pr_Write('V','ACC_DESC',l_Desc_Vc);
            IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.topup_date) <>
                  p_stdtdtop.v_ictbs_tdtopup_detail.topup_date THEN
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.topup_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.topup_date,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','TOPUP_DATE',l_Date_Val);
            IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date) <>
                  p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date THEN
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','TD_OPEN_DATE',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','DAYS',p_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd);
            Cspks_Req_Global.Pr_Write('V','MONTHS',p_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm);
            Cspks_Req_Global.Pr_Write('V','YEARS',p_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy);
            IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.matdate) <>
                  p_stdtdtop.v_ictbs_tdtopup_detail.matdate THEN
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.matdate,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.matdate,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','MATDT',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','TDAMT_BEFORE_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup);
            Cspks_Req_Global.Pr_Write('V','TDAMT_AFTER_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup);
            Cspks_Req_Global.Pr_Write('V','MATAMT_AFTER_TOPUP',p_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup);
            Cspks_Req_Global.Pr_Write('V','INT_RATE_OPTION',p_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup);
            Cspks_Req_Global.Pr_Write('V','EXT_REFERENCE',p_stdtdtop.v_ictbs_tdtopup_detail.ext_reference);
            l_Desc_Vc := NULL;
            BEGIN
               l_Desc_Vc := p_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('CUSTOMER_DESC');
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Populating Description Field   :CUSTOMER_DESC');
            END;
            Cspks_Req_Global.Pr_Write('V','CUSTOMER_NAME',l_Desc_Vc);
            Cspks_Req_Global.Pr_Write('V','CUST_NO',p_stdtdtop.v_ictbs_tdtopup_detail.cust_no);
            Cspks_Req_Global.Pr_Write('V','REMITTER_NAME',p_stdtdtop.v_ictbs_tdtopup_detail.remitter_name);
            Cspks_Req_Global.Pr_Write('V','MAKER',p_stdtdtop.v_ictbs_tdtopup_detail.maker_id);
            IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp) <>
                  p_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','MAKERSTAMP',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','CHECKER',p_stdtdtop.v_ictbs_tdtopup_detail.checker_id);
            IF trunc(p_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp) <>
                  p_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','CHECKERSTAMP',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','MODNO',p_stdtdtop.v_ictbs_tdtopup_detail.mod_no);
            Cspks_Req_Global.Pr_Write('V','TXNSTAT',p_stdtdtop.v_ictbs_tdtopup_detail.record_stat);
            Cspks_Req_Global.Pr_Write('V','AUTHSTAT',p_stdtdtop.v_ictbs_tdtopup_detail.auth_stat);

            --Dbg('Building Childs Of :BLK_TDTOPUP_DETAIL..');
            l_Dsn_Rec_Cnt_2 := 0;
            IF p_stdtdtop.v_ictms_tdtopup_payin.COUNT > 0 THEN
               FOR i_2 IN  1..p_stdtdtop.v_ictms_tdtopup_payin.COUNT LOOP
                  l_Dsn_Rec_Cnt_2 := i_2;
                  l_Master_Childs  :=  l_Master_Childs +1;
                  l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
                  l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
                  Cspks_Req_Global.Pr_Write('P','Tdtopup-Payin',l_Level_Format);
                  Cspks_Req_Global.Pr_Write('V','FUND_OPT',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_payopt);
                  Cspks_Req_Global.Pr_Write('V','AMNT',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_tdamount);
                  Cspks_Req_Global.Pr_Write('V','OFFSET_BRN',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_offset_brn);
                  Cspks_Req_Global.Pr_Write('V','OFFSET_ACCOUNT',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_tdoffset_acc);
                  Cspks_Req_Global.Pr_Write('V','PECENT',p_stdtdtop.v_ictms_tdtopup_payin(l_Dsn_Rec_Cnt_2).multimode_percentage);
               END LOOP;
            END IF;
         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Tdtopup-Detail-PK','1');
         l_Key_Cols := 'TOPUP_REF_NO~';
         l_Key_Vals := p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_stdtdtop IN  stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO';
      IF p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no IS Null THEN
         Dbg('Field topup_ref_no is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'ICTBS_TDTOPUP_DETAIL';
         l_Fld := 'ICTBS_TDTOPUP_DETAIL.ACC';
         IF p_stdtdtop.v_ictbs_tdtopup_detail.acc IS Null THEN
            Dbg('Mandatory Key Column acc Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;

         l_Blk := 'ICTMS_TDTOPUP_PAYIN';
         l_Count := p_stdtdtop.v_ictms_tdtopup_payin.COUNT;
         IF l_Count > 0 THEN
            FOR l_index IN 1 .. p_stdtdtop.v_ictms_tdtopup_payin.COUNT LOOP
               l_Fld := 'ICTMS_TDTOPUP_PAYIN.SEQNO';
               IF p_stdtdtop.v_ictms_tdtopup_payin(l_Index).seqno IS Null THEN
                  Dbg('Primary Key Column seqno Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
            END LOOP;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_stdtdtop     IN  stpks_stdtdtop_Main.ty_stdtdtop,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      IF p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_AMOUNT IS NOT NULL THEN
         IF p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_AMOUNT < 0 THEN
            Dbg('Invalid Value For The Field  :TOPUP_AMOUNT:'||p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_AMOUNT);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_AMOUNT||'~@ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT~@ICTBS_TDTOPUP_DETAIL') ;
         END IF;
      END IF;
      l_Count      := p_stdtdtop.v_ictms_tdtopup_payin.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            l_Key := NULL;
            IF p_stdtdtop.v_ictms_tdtopup_payin(l_index).MULTIMODE_PAYOPT IS NOT NULL THEN
               IF p_stdtdtop.v_ictms_tdtopup_payin(l_index).MULTIMODE_PAYOPT NOT IN ('S','G','C') THEN
                  dbg('Invalid Value For The Field  :MULTIMODE_PAYOPT:'||p_stdtdtop.v_ictms_tdtopup_payin(l_index).MULTIMODE_PAYOPT);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.SEQNO')||'-'||
                  p_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_stdtdtop.v_ictms_tdtopup_payin(l_index).MULTIMODE_PAYOPT||'~@ICTMS_TDTOPUP_PAYIN.MULTIMODE_PAYOPT'||'~'||l_Key||'~@ICTMS_TDTOPUP_PAYIN') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Duplicate Records Check For :v_ictms_tdtopup_payin..');
      l_Count      := p_stdtdtop.v_ictms_tdtopup_payin.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_count LOOP
            l_key := NULL;
            IF l_index < l_Count THEN
               FOR l_index1 IN l_index+1 .. l_Count LOOP
                  IF (NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).topup_ref_no,'@')=  NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index1).topup_ref_no,'@')) AND (NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).brn,'@')=  NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index1).brn,'@')) AND (NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).acc,'@')=  NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index1).acc,'@')) AND (NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno,-1)=  NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index1).seqno,-1)) THEN
                     Dbg('Duplicare Record Found for :'||l_Key);
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.TOPUP_REF_NO')||'-'||
                     p_stdtdtop.v_ictms_tdtopup_payin(l_index).topup_ref_no||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.BRN')||'-'||
                     p_stdtdtop.v_ictms_tdtopup_payin(l_index).brn||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.ACC')||'-'||
                     p_stdtdtop.v_ictms_tdtopup_payin(l_index).acc||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.SEQNO')||'-'||
                     p_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno;
                     Pr_Log_Error(p_Source,'ST-VALS-009','@ICTMS_TDTOPUP_PAYIN~'||l_Key);
                  END IF;
               END LOOP;
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_stdtdtop     IN  OUT stpks_stdtdtop_Main.ty_stdtdtop,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      l_Count      := p_Wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
      IF l_count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            IF p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).MULTIMODE_PAYOPT IS NULL THEN
               p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).MULTIMODE_PAYOPT := 'S';
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Merge_Amendables        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_stdtdtop     IN  stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Prev_stdtdtop IN stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Wrk_stdtdtop IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Wrk_Count      NUMBER := 0 ;
      l_Deleted_Recs   NUMBER := 0;
      l_Modified_Flds  VARCHAR2(32000):= NULL;
      l_Key            VARCHAR2(5000):= NULL;
      l_Mod_Fld        VARCHAR2(100):= NULL;
      i                NUMBER := 1;
      l_Rec_Found      BOOLEAN := FALSE;
      l_Rec_Modified   BOOLEAN := FALSE;
      l_Rec_Sent       BOOLEAN := FALSE;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Pk_Or_Full     VARCHAR2(5) :='FULL';
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Mod_No         NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Amendable_Nodes Cspks_Req_Global.Ty_Amend_Nodes;
      l_Amendable_Fields Cspks_Req_Global.Ty_Amend_Fields;
      N_v_ictms_tdtopup_payin       stpks_stdtdtop_Main.Ty_Tb_v_ictms_tdtopup_payin;

      FUNCTION Fn_Amendable(p_Item IN VARCHAR2) RETURN BOOLEAN IS
      BEGIN
         IF l_Amendable_Fields.EXISTS(p_Item) THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END Fn_Amendable;
   BEGIN

      Dbg('In Fn_Sys_Merge_Amendables');

      Dbg('Calling Cspks_Req_Utils.Fn_Get_Amendable_Details..');
      IF NOT Cspks_Req_Utils.Fn_Get_Amendable_Details(p_source ,
         p_Source_Operation,
         l_Amendable_Nodes,
         l_Amendable_Fields,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      l_Blk := 'ICTBS_TDTOPUP_DETAIL';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_fld := 'ICTBS_TDTOPUP_DETAIL.BRN';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.BRN') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.brn := p_stdtdtop.v_ictbs_tdtopup_detail.brn;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.brn IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.brn,'@') <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.brn,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.ACC';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.ACC') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.acc := p_stdtdtop.v_ictbs_tdtopup_detail.acc;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.acc IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.acc,'@') <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.acc,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.CCY';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.CCY') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ccy := p_stdtdtop.v_ictbs_tdtopup_detail.ccy;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.ccy IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ccy,'@') <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_amount := p_stdtdtop.v_ictbs_tdtopup_detail.topup_amount;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.topup_amount IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_amount,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.topup_amount,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TOPUP_VALUE_DATE';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TOPUP_VALUE_DATE') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date := p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date,global.min_date) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.MATAMT_BEFORE_TOPUP';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.MATAMT_BEFORE_TOPUP') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup := p_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.INTRATE_BEFORE_TOPUP';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.INTRATE_BEFORE_TOPUP') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup := p_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.NARRATIVE';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.NARRATIVE') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.narrative := p_stdtdtop.v_ictbs_tdtopup_detail.narrative;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.narrative IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.narrative,'@') <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.narrative,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TOPUP_DATE';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TOPUP_DATE') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_date := p_stdtdtop.v_ictbs_tdtopup_detail.topup_date;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.topup_date IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_date,global.min_date) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.topup_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TD_OPEN_DATE';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TD_OPEN_DATE') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.td_open_date := p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.td_open_date,global.min_date) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.td_open_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TENOR_DD';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TENOR_DD') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd := p_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TENOR_MM';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TENOR_MM') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm := p_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TENOR_YY';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TENOR_YY') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy := p_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.MATDATE';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.MATDATE') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matdate := p_stdtdtop.v_ictbs_tdtopup_detail.matdate;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.matdate IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matdate,global.min_date) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.matdate,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TDAMT_BEFORE_TOPUP';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TDAMT_BEFORE_TOPUP') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup := p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.TDAMT_AFTER_TOPUP';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.TDAMT_AFTER_TOPUP') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup := p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.MATAMT_AFTER_TOPUP';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.MATAMT_AFTER_TOPUP') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup := p_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.INTRATE_AFTER_TOPUP';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.INTRATE_AFTER_TOPUP') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup := p_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup,-1) <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.EXT_REFERENCE';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.EXT_REFERENCE') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ext_reference := p_stdtdtop.v_ictbs_tdtopup_detail.ext_reference;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.ext_reference IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ext_reference,'@') <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.ext_reference,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.CUST_NO';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.CUST_NO') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.cust_no := p_stdtdtop.v_ictbs_tdtopup_detail.cust_no;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.cust_no IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.cust_no,'@') <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.cust_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDTOPUP_DETAIL.REMITTER_NAME';
      IF Fn_Amendable('ICTBS_TDTOPUP_DETAIL.REMITTER_NAME') THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.remitter_name := p_stdtdtop.v_ictbs_tdtopup_detail.remitter_name;
      ELSE
         IF p_stdtdtop.v_ictbs_tdtopup_detail.remitter_name IS NOT NULL THEN
            IF NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.remitter_name,'@') <>
               NVL(p_stdtdtop.v_ictbs_tdtopup_detail.remitter_name,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;

      l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
      IF  l_Rec_Modified THEN
         IF l_Modified_Flds IS NOT NULL THEN
            i :=  1;
            l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
            WHILE l_Mod_Fld <> 'EOPL' LOOP
               Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
               i := i +1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
            END LOOP;
         END IF;
      END IF;
      l_Blk := 'ICTMS_TDTOPUP_PAYIN';
      l_Count      := p_stdtdtop.v_ictms_tdtopup_payin.COUNT;
      l_Wrk_Count  := p_Wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
      IF l_Count > 0 THEN
         FOR l_index IN 1..l_Count  LOOP
            l_Rec_Found := FALSE;
            l_Rec_Modified := FALSE;
            l_Modified_Flds := NULL;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno,-1)=  NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).seqno,-1)) THEN
                     Dbg('Record Found..');
                     l_Rec_Found := TRUE;
                     l_fld := 'ICTMS_TDTOPUP_PAYIN.MULTIMODE_PAYOPT';
                     IF Fn_Amendable('ICTMS_TDTOPUP_PAYIN.MULTIMODE_PAYOPT') THEN
                        p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_payopt := p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_payopt;
                     ELSE
                        IF p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_payopt IS NOT NULL THEN
                           IF NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_payopt,'@') <>
                              NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_payopt,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDTOPUP_PAYIN.MULTIMODE_TDAMOUNT';
                     IF Fn_Amendable('ICTMS_TDTOPUP_PAYIN.MULTIMODE_TDAMOUNT') THEN
                        p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_tdamount := p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_tdamount;
                     ELSE
                        IF p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_tdamount IS NOT NULL THEN
                           IF NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_tdamount,-1) <>
                              NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_tdamount,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDTOPUP_PAYIN.MULTIMODE_OFFSET_BRN';
                     IF Fn_Amendable('ICTMS_TDTOPUP_PAYIN.MULTIMODE_OFFSET_BRN') THEN
                        p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_offset_brn := p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_offset_brn;
                     ELSE
                        IF p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_offset_brn IS NOT NULL THEN
                           IF NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_offset_brn,'@') <>
                              NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_offset_brn,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDTOPUP_PAYIN.MULTIMODE_TDOFFSET_ACC';
                     IF Fn_Amendable('ICTMS_TDTOPUP_PAYIN.MULTIMODE_TDOFFSET_ACC') THEN
                        p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_tdoffset_acc := p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_tdoffset_acc;
                     ELSE
                        IF p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_tdoffset_acc IS NOT NULL THEN
                           IF NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_tdoffset_acc,'@') <>
                              NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_tdoffset_acc,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDTOPUP_PAYIN.MULTIMODE_PERCENTAGE';
                     IF Fn_Amendable('ICTMS_TDTOPUP_PAYIN.MULTIMODE_PERCENTAGE') THEN
                        p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_percentage := p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_percentage;
                     ELSE
                        IF p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_percentage IS NOT NULL THEN
                           IF NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).multimode_percentage,-1) <>
                              NVL(p_stdtdtop.v_ictms_tdtopup_payin(l_index).multimode_percentage,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;

                     l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
                     IF  l_Rec_modified THEN
                        IF l_Modified_Flds IS NOT NULL THEN
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.SEQNO')||'-'||
                           p_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno;
                           i :=  1;
                           l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           WHILE l_mod_fld <> 'EOPL' LOOP
                              Pr_Log_Error(p_Source,'ST-AMND-003','@'||l_Mod_Fld||'~@'||l_Blk||'~'||l_Key );
                              i := i +1;
                              l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           END LOOP;
                        END IF;
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               p_Wrk_stdtdtop.v_ictms_tdtopup_payin(p_Wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT +1 ) :=  p_stdtdtop.v_ictms_tdtopup_payin(l_index);
               IF l_Amendable_Nodes.EXISTS('ICTMS_TDTOPUP_PAYIN') THEN
                  IF l_Amendable_Nodes('ICTMS_TDTOPUP_PAYIN').New_Allowed = 'N' THEN
                     Dbg('New Record Cannot Be Added..');
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.SEQNO')||'-'||
                     p_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno;
                     Pr_Log_Error(p_source,'ST-AMND-004',l_key||'~@'||l_blk);
                  END IF;
               ELSE
                  Dbg('New Record Cannot Be Added..');
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.SEQNO')||'-'||
                  p_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno;
                  Pr_Log_Error(p_Source,'ST-AMND-004',l_key||'~@'||l_blk);
               END IF;
            END IF;
         END LOOP;
      END IF;

      IF l_Amendable_Nodes.EXISTS('ICTMS_TDTOPUP_PAYIN') THEN
         IF l_Amendable_Nodes('ICTMS_TDTOPUP_PAYIN').All_Records = 'Y' THEN
            Dbg('Logic For Deleting Some Records From Work Record  if Not sent..');
            l_Wrk_Count := p_Wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
            l_Count     := p_stdtdtop.v_ictms_tdtopup_payin.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_count  LOOP
                  l_Rec_Found := FALSE;
                  IF l_Count > 0 THEN
                     FOR l_index IN 1..l_Count  LOOP
                        IF (NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).seqno,-1)=  NVL(p_stdtdtop.v_ictms_tdtopup_payin  (l_index).seqno,-1)) THEN
                           Dbg('Record Found..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_Rec_Found THEN
                     Dbg('Adding  a Record...');
                     N_v_ictms_tdtopup_payin(N_v_ictms_tdtopup_payin.COUNT +1 ) :=  p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index1);
                  ELSE
                     l_Deleted_Recs := l_Deleted_Recs +1;
                     IF l_Amendable_Nodes.EXISTS('ICTMS_TDTOPUP_PAYIN') THEN
                        IF l_Amendable_Nodes('ICTMS_TDTOPUP_PAYIN').Delete_Allowed = 'N' THEN
                           Dbg('Record Cannot Be Deleted..');
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.SEQNO')||'-'||
                           p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).seqno;
                           Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                        END IF;
                     ELSE
                        Dbg('Record Cannot Be Deleted..');
                        l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.SEQNO')||'-'||
                        p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index1).seqno;
                        Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            p_Wrk_stdtdtop.v_ictms_tdtopup_payin:= N_v_ictms_tdtopup_payin;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Merge_Amendables..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Merge_Amendables..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Merge_Amendables;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_stdtdtop IN  stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_stdtdtop     IN  stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER  := 0;
      l_Dsn_Rec_Cnt_3 NUMBER := 0;
      l_Bnd_Cntr_3    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      l_Blk := 'ICTBS_TDTOPUP_DETAIL';
      l_Fld := 'ICTBS_TDTOPUP_DETAIL.ACC';
      IF p_wrk_stdtdtop.v_ictbs_tdtopup_detail.ACC IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT distinct a.CUST_AC_NO,a.ac_desc,a.CUST_NO,a.ccy,c.customer_name1 FROM STTM_CUST_ACCOUNT a, ictm_acc_pr b, sttm_customer c WHERE a.account_class in (select distinct account_class from STTM_ACCOUNT_CLASS where ac_class_type = 'Y' and allow_topup = 'Y' and ONCE_AUTH = 'Y' and record_stat <> 'C') AND a.CUST_NO IN (select c.customer_no from sttm_customer c where (c.group_code is not null and exists(select 1 from stvws_user_group g where g.user_id = GLOBAL.user_id and g.group_code = c.group_code)) OR c.group_code is null) and a.ONCE_AUTH = 'Y' and a.record_stat = 'O' AND a.BRANCH_CODE = P_wrk_stdtdtop.v_ictbs_tdtopup_detail.BRN and a.BRANCH_CODE = b.BRN and a.CUST_AC_NO = b.ACC and b.waive = 'N' and b.prod in(select d.PRODUCT_CODE from ictms_product_definition d, ICTMs_PR_INT e where nvl(d.tax, 'N') = 'N' and d.product_code = e.product_code and e.payment_method <> 'D' and NVL(MUDARABAH_PRODUCT, 'N') = 'N') AND C.CUSTOMER_NO = A.CUST_NO AND C.AUTH_STAT = 'A' AND C.RECORD_STAT = 'O' ORDER BY CUST_AC_NO) WHERE CUST_AC_NO = P_wrk_stdtdtop.v_ictbs_tdtopup_detail.ACC;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :ACC:'||p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ACC);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ACC||'~@ICTBS_TDTOPUP_DETAIL.ACC~@ICTBS_TDTOPUP_DETAIL') ;
         END IF;
      END IF;
      l_Count      := p_Wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
      IF l_Count > 0 THEN
         FOR l_Index  IN 1 .. l_Count LOOP
            l_Blk := 'ICTMS_TDTOPUP_PAYIN';
            l_Fld := 'ICTMS_TDTOPUP_PAYIN.MULTIMODE_TDOFFSET_ACC';
            IF p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).MULTIMODE_TDOFFSET_ACC IS NOT NULL THEN
               SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT c.cust_ac_no ACC, c.branch_code, c.ccy CCY, c.ac_desc ADESC, 'A' PAYIN FROM sttm_cust_account c, sttm_account_class e WHERE c.once_auth = 'Y' AND c.record_stat = 'O' and e.ac_class_type <> 'Y' and c.account_class = e.account_class and 'S' = P_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).MULTIMODE_PAYOPT UNION SELECT d.gl_code ACC, d.branch_code, '', e.gl_desc ADESC, d.payin_option PAYIN FROM sttms_payin_mode d, gltm_glmaster e WHERE d.gl_code = e.gl_code AND P_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).MULTIMODE_PAYOPT ='G' AND d.payin_option = 'G' AND d.branch_code = GLOBAL.current_branch AND d.once_auth = 'Y' AND d.record_stat = 'O') WHERE ACC = P_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).MULTIMODE_TDOFFSET_ACC;
               IF l_lov_count = 0  THEN
                  Dbg('Invalid Value For The Field  :MULTIMODE_TDOFFSET_ACC:'||p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).MULTIMODE_TDOFFSET_ACC);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDTOPUP_PAYIN.SEQNO')||'-'||
                  p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).MULTIMODE_TDOFFSET_ACC||'~@ICTMS_TDTOPUP_PAYIN.MULTIMODE_TDOFFSET_ACC'||'~'||l_Key||'~@ICTMS_TDTOPUP_PAYIN') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_stdtdtop     IN  stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Prev_stdtdtop IN OUT  stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Wrk_stdtdtop IN OUT  stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Prev_Key_Tags       VARCHAR2(32767);
      l_Prev_Key_Vals       VARCHAR2(32767);
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      IF p_Source <> 'FLEXCUBE'  THEN
         BEGIN
            SELECT Base_Data_From_Fc
            INTO   l_Base_Data_From_Fc
            FROM   Cotms_Source
            WHERE  Source_Code = p_Source;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               Dbg('Failed in Selecting Source '||p_Source);
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-VALS-002';
               p_Err_Params  := p_Source;
               RETURN FALSE;
         END;
      END IF;
      l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO')||'-'||
      p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no;
      l_Prev_Key_Tags := 'TOPUP_REF_NO~';
      l_Prev_Key_Vals := p_prev_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no||'~';
      Dbg('Calling Cspks_Req_Utils.Fn_Maint_Basic_Validations..');
      IF NOT Cspks_Req_Utils.Fn_Maint_Basic_Validations (p_source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Mod_No,
         p_stdtdtop.v_ictbs_tdtopup_detail.Mod_No,
         p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Auth_Stat,
         p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Record_Stat,
         p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Once_Auth,
         l_Prev_Key_Tags,
         l_Prev_Key_Vals,
         g_Key_Id,
         l_Key,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Maint_Basic_Validations..');
         RETURN FALSE;
      END IF;
      IF ( p_Action_Code IN (Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Delete,Cspks_Req_Global.p_Version_Delete,Cspks_Req_Global.p_Query) OR
            ( p_Action_Code = Cspks_Req_Global.p_Modify AND NVL(p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Once_Auth,'N') = 'Y')) THEN
         p_Wrk_stdtdtop := p_Prev_stdtdtop;
         p_wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No := p_stdtdtop.v_ictbs_tdtopup_detail.Mod_No;
         p_Wrk_stdtdtop.Addl_Info := p_stdtdtop.Addl_Info ;
      ELSE
         p_Wrk_stdtdtop := p_stdtdtop;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Auth THEN
         IF p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No IS NULL THEN
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No           := p_prev_stdtdtop.v_ictbs_tdtopup_detail.Mod_No;
         END IF;
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Checker_dt_stamp   := fn_mntstamp;
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Checker_id         := Global.user_id;
      ELSIF p_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen) THEN
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Auth_Stat        := 'U';
         IF NOT Cspks_Req_Global.Fn_UnTanking THEN
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Maker_Id         := Global.User_Id;
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Maker_Dt_Stamp   := Fn_Mntstamp;
         ELSE
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Maker_Id         := NVL(p_stdtdtop.v_ictbs_tdtopup_detail.Maker_Id,Global.User_Id);
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Maker_Dt_Stamp   := NVL(p_stdtdtop.v_ictbs_tdtopup_detail.Maker_Dt_Stamp,Fn_Mntstamp);
         END IF;

         IF p_Action_Code = Cspks_Req_Global.p_New THEN
            IF NOT Cspks_Req_Global.Fn_UnTanking THEN
               p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No           := 1;
            ELSE
               p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No := NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No,1);
            END IF;
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Record_Stat      := 'O';
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Once_Auth        := 'N';
         ELSE
            IF NOT Cspks_Req_Global.Fn_UnTanking THEN
               p_wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No           := NVL(p_prev_stdtdtop.v_ictbs_tdtopup_detail.Mod_No,0)+1;
            ELSE
               p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No           := NVL(p_stdtdtop.v_ictbs_tdtopup_detail.Mod_No,1);
            END IF;
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Once_Auth           := NVL(p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Once_Auth,'N');
            p_wrk_stdtdtop.v_ictbs_tdtopup_detail.Record_Stat           := NVL(p_prev_stdtdtop.v_ictbs_tdtopup_detail.Record_Stat,'O');
         END IF;
         IF p_Action_Code = Cspks_Req_Global.p_Close THEN
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Record_Stat      := 'C';
         ELSIF p_Action_Code = Cspks_Req_Global.p_Reopen THEN
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Record_Stat      := 'O';
         END IF;
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Checker_id         := Null;
         p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Checker_Dt_Stamp         := Null;
      ELSIF p_Action_Code IN ( Cspks_Req_Global.p_Delete,Cspks_Req_Global.p_Version_Delete) THEN
         IF p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No IS NULL THEN
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No           := p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Mod_No;
         END IF;
      END IF;
      IF p_Action_Code in  (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify) THEN
         Dbg('Calling .Fn_Sys_Basic_Vals..');
         IF NOT Fn_Sys_Basic_Vals(p_Source,
            p_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Basic_Vals..');
            RETURN FALSE;
         END IF;

         IF p_Action_Code = Cspks_Req_Global.p_New OR  ( p_Action_Code = Cspks_Req_Global.p_Modify AND p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Once_Auth = 'N') THEN
            Dbg('Calling .Fn_Sys_Default_Vals..');
            IF NOT Fn_Sys_Default_Vals(p_Source,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in .Fn_Sys_Default_Vals..');
               RETURN FALSE;
            END IF;

         END IF;
         IF p_Action_Code = Cspks_Req_Global.p_Modify AND p_Prev_stdtdtop.v_ictbs_tdtopup_detail.Once_Auth = 'Y'THEN
            Dbg('Calling Fn_Sys_Merge_Amendables..');
            IF NOT Fn_Sys_Merge_Amendables(p_Source,
               p_Source_Operation,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in .Fn_Sys_Merge_Amendables..');
               RETURN FALSE;
            END IF;
         END IF;

         Dbg('Calling .Fn_Sys_Check_Mandatory_Nodes..');
         IF NOT Fn_Sys_Check_Mandatory_Nodes(p_source,
            p_Wrk_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Check_Mandatory_Nodes..');
            RETURN FALSE;
         END IF;

         Dbg('Calling  .Fn_Sys_Lov_Vals..');
         IF NOT Fn_Sys_Lov_Vals(p_source,
            p_Wrk_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Lov_Vals..');
            RETURN FALSE;
         END IF;

      END IF;
      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of stpks_stdtdtop_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_stdtdtop  IN   OUT stpks_stdtdtop_Main.Ty_stdtdtop,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      IF P_wrk_stdtdtop.v_ictbs_tdtopup_detail.ACC IS NOT NULL THEN 
      BEGIN
      SELECT AC_DESC,CUSTOMER_NAME1 INTO P_wrk_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('ACCOUNT_DESC'),P_wrk_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('CUSTOMER_DESC')   FROM (SELECT distinct a.CUST_AC_NO,a.ac_desc,a.CUST_NO,a.ccy,c.customer_name1 FROM STTM_CUST_ACCOUNT a, ictm_acc_pr b, sttm_customer c WHERE a.account_class in (select distinct account_class from STTM_ACCOUNT_CLASS where ac_class_type = 'Y' and allow_topup = 'Y' and ONCE_AUTH = 'Y' and record_stat <> 'C') AND a.CUST_NO IN (select c.customer_no from sttm_customer c where (c.group_code is not null and exists(select 1 from stvws_user_group g where g.user_id = GLOBAL.user_id and g.group_code = c.group_code)) OR c.group_code is null) and a.ONCE_AUTH = 'Y' and a.record_stat = 'O' AND a.BRANCH_CODE = P_wrk_stdtdtop.v_ictbs_tdtopup_detail.BRN and a.BRANCH_CODE = b.BRN and a.CUST_AC_NO = b.ACC and b.waive = 'N' and b.prod in(select d.PRODUCT_CODE from ictms_product_definition d, ICTMs_PR_INT e where nvl(d.tax, 'N') = 'N' and d.product_code = e.product_code and e.payment_method <> 'D' and NVL(MUDARABAH_PRODUCT, 'N') = 'N') AND C.CUSTOMER_NO = A.CUST_NO AND C.AUTH_STAT = 'A' AND C.RECORD_STAT = 'O' ORDER BY CUST_AC_NO) WHERE CUST_AC_NO = P_wrk_stdtdtop.v_ictbs_tdtopup_detail.ACC AND ROWNUM < 2;
      EXCEPTION
      WHEN OTHERS THEN
      P_wrk_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('ACCOUNT_DESC') := NULL;
      P_wrk_stdtdtop.Desc_Fields('ICTBS_TDTOPUP_DETAIL')(1)('CUSTOMER_DESC') := NULL;
      dbg(SQLERRM);
      dbg('Failed in selecting the Desc Fields For  :ACC');
      END;
      END IF;
         Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
         RETURN TRUE;
      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Sys_Query_Desc_Fields;
      FUNCTION Fn_Sys_Query  ( p_Source    IN  VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
         p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
         p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
         p_QryData_Reqd       IN  VARCHAR2,
         p_stdtdtop         IN  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Wrk_stdtdtop  IN   OUT stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Err_Code          IN OUT VARCHAR2,
         p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS
         l_Key            VARCHAR2(5000):= NULL;
         l_Count          NUMBER := 0;
         l_Wrk_Count          NUMBER := 0;
         l_Key_Tags       VARCHAR2(32767);
         l_Key_Vals       VARCHAR2(32767);
         l_Rec_Exists        BOOLEAN := TRUE;
         RECORD_LOCKED    EXCEPTION;
         PRAGMA EXCEPTION_INIT( RECORD_LOCKED, -54 );
         l_Dsn_Rec_Cnt_1 NUMBER := 0;
         l_Bnd_Cntr_1    NUMBER := 0;
         l_Dsn_Rec_Cnt_2 NUMBER := 0;
         l_Bnd_Cntr_2    NUMBER := 0;
         Cursor c_v_ictms_tdtopup_payin IS
         SELECT *
         FROM   ICTM_TDTOPUP_PAYIN
         WHERE topup_ref_no = p_wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
          AND acc = p_wrk_stdtdtop.v_ictbs_tdtopup_detail.acc
          AND brn = p_wrk_stdtdtop.v_ictbs_tdtopup_detail.brn
         ;
      BEGIN
         Dbg('In Fn_Sys_Query..');
         IF p_QryData_Reqd = 'Q' THEN
            Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
            IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Wrk_stdtdtop,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
               RETURN FALSE;
            END IF;
         ELSE
            l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO')||'-'||
            p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no;
            Dbg('Get The Master Record...');
            IF NVL(p_With_Lock,'N') = 'Y' THEN
               BEGIN
                  SELECT *
                  INTO   p_wrk_stdtdtop.v_ictbs_tdtopup_detail
                  FROM  ICTB_TDTOPUP_DETAIL
                  WHERE topup_ref_no = p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
                   FOR UPDATE NOWAIT;
               EXCEPTION
                  WHEN RECORD_LOCKED THEN
                     Dbg('Failed to Obtain the Lock..');
                     Pr_Log_Error(p_Source,'ST-LOCK-001',NULL);
                     RETURN FALSE;
                  WHEN No_Data_Found THEN
                     Dbg('Failed in Selecting The Master Recotrd..');
                     Dbg('Record Does not Exist..');
                     l_Rec_Exists := FALSE;
               END;

            ELSE
               BEGIN
                  SELECT *
                  INTO   p_Wrk_stdtdtop.v_ictbs_tdtopup_detail
                  FROM  ICTB_TDTOPUP_DETAIL
                  WHERE topup_ref_no = p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
                  ;
               EXCEPTION
                  WHEN no_data_found THEN
                     Dbg('Failed in Selecting The Master Recotrd..');
                     Dbg('Record Does not Exist..');
                     p_Err_Code    := 'ST-VALS-002';
                     p_Err_Params  := l_Key;
                     RETURN FALSE;
               END;

            END IF;
            IF p_Full_Data = 'Y' AND l_Rec_Exists THEN
               Dbg('Get the Record For :ICTBS_TDTOPUP_DETAIL');
               BEGIN
                  SELECT *
                  INTO p_Wrk_stdtdtop.v_ictbs_tdtopup_detail
                  FROM   ICTB_TDTOPUP_DETAIL
                  WHERE topup_ref_no = p_wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
                  ;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg(SQLERRM);
                     Dbg('Failed in Selecting The Record For :ICTBS_TDTOPUP_DETAIL');
               END;
               Dbg('Get the Record For :ICTMS_TDTOPUP_PAYIN');
               OPEN c_v_ictms_tdtopup_payin;
               LOOP
                  FETCH c_v_ictms_tdtopup_payin
                  BULK COLLECT INTO p_Wrk_stdtdtop.v_ictms_tdtopup_payin;
                   EXIT WHEN c_v_ictms_tdtopup_payin%NOTFOUND;
               END LOOP;
               CLOSE c_v_ictms_tdtopup_payin;

            END IF;
            IF p_QryData_Reqd = 'Y' THEN
               Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
               IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  p_Action_Code,
                  p_Wrk_stdtdtop,
                  p_Err_Code  ,
                  p_Err_Params ) THEN
                  Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
                  RETURN FALSE;
               END IF;
            END IF;

         END IF;
         Dbg('Returning Success From Fn_Sys_Query..');
         RETURN TRUE;
      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Sys_Query ..');
            Debug.Pr_Debug('**',SQLERRM);
            IF  c_v_ictms_tdtopup_payin%ISOPEN THEN
               CLOSE c_v_ictms_tdtopup_payin;
            END IF;
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Sys_Query;
      FUNCTION Fn_Sys_Upload_Db         (p_Source            IN VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
         p_stdtdtop     IN  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Prev_stdtdtop     IN  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Wrk_stdtdtop      IN OUT  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Err_Code          IN OUT VARCHAR2,
         p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN   IS
         l_Count             NUMBER:= 0;
         l_Ins_Count         NUMBER:= 0;
         l_Upd_Count         NUMBER:= 0;
         l_Del_Count         NUMBER:= 0;
         l_Wrk_Count         NUMBER:= 0;
         l_Prev_Count        NUMBER:= 0;
         l_Rec_Found         BOOLEAN:= FALSE;
         l_Row_Id            ROWID;
         l_Key               VARCHAR2(5000):= NULL;
         l_Auth_Stat         VARCHAR2(1) := 'A';
         l_Base_Data_From_Fc VARCHAR2(1):= 'Y';
         I_v_ictms_tdtopup_payin       stpks_stdtdtop_Main.Ty_Tb_v_ictms_tdtopup_payin;
         U_v_ictms_tdtopup_payin       stpks_stdtdtop_Main.Ty_Tb_v_ictms_tdtopup_payin;
         D_v_ictms_tdtopup_payin       stpks_stdtdtop_Main.Ty_Tb_v_ictms_tdtopup_payin;
      BEGIN
         Dbg('In Fn_Sys_Upload_Db..');
         IF p_Action_Code = Cspks_Req_Global.p_new THEN

            Dbg('Inserting Into ICTBS_TDTOPUP_DETAIL..');
            BEGIN
               IF  p_wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no IS NOT NULL THEN
                  Dbg('Record Sent..');
                  INSERT INTO  ICTB_TDTOPUP_DETAIL
                  VALUES p_wrk_stdtdtop.v_ictbs_tdtopup_detail;
               END IF;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed In Insert intoICTBS_TDTOPUP_DETAIL..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@ICTBS_TDTOPUP_DETAIL';
                  RETURN FALSE;
            END;

            Dbg('Inserting Into ICTMS_TDTOPUP_PAYIN..');
            BEGIN
               l_Count      := p_wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
               FORALL l_index IN  1..l_count
               INSERT INTO ICTM_TDTOPUP_PAYIN
               VALUES p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_index);
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed In Insert intoICTMS_TDTOPUP_PAYIN..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@ICTMS_TDTOPUP_PAYIN';
                  RETURN FALSE;
            END;
         ELSIF p_Action_Code = Cspks_Req_Global.p_modify THEN

            Dbg('Updating Single Record Node :  ICTBS_TDTOPUP_DETAIL..');
            BEGIN
               UPDATE ICTB_TDTOPUP_DETAIL
               SET
               BRN = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.BRN,
               ACC = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ACC,
               CCY = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.CCY,
               TOPUP_AMOUNT = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_AMOUNT,
               TOPUP_VALUE_DATE = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_VALUE_DATE,
               MATAMT_BEFORE_TOPUP = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.MATAMT_BEFORE_TOPUP,
               INTRATE_BEFORE_TOPUP = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.INTRATE_BEFORE_TOPUP,
               NARRATIVE = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.NARRATIVE,
               TOPUP_DATE = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TOPUP_DATE,
               TD_OPEN_DATE = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TD_OPEN_DATE,
               TENOR_DD = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TENOR_DD,
               TENOR_MM = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TENOR_MM,
               TENOR_YY = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TENOR_YY,
               MATDATE = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.MATDATE,
               TDAMT_BEFORE_TOPUP = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TDAMT_BEFORE_TOPUP,
               TDAMT_AFTER_TOPUP = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.TDAMT_AFTER_TOPUP,
               MATAMT_AFTER_TOPUP = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.MATAMT_AFTER_TOPUP,
               INTRATE_AFTER_TOPUP = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.INTRATE_AFTER_TOPUP,
               EXT_REFERENCE = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.EXT_REFERENCE,
               CUST_NO = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.CUST_NO,
               REMITTER_NAME = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.REMITTER_NAME,
               MAKER_ID = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.MAKER_ID,
               MAKER_DT_STAMP = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.MAKER_DT_STAMP,
               CHECKER_ID = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.CHECKER_ID,
               CHECKER_DT_STAMP = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.CHECKER_DT_STAMP,
               MOD_NO = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.MOD_NO,
               RECORD_STAT = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.RECORD_STAT,
               AUTH_STAT = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.AUTH_STAT,
               ONCE_AUTH = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ONCE_AUTH
WHERE topup_ref_no = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed in Insert Into ICTBS_TDTOPUP_DETAIL..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@ICTBS_TDTOPUP_DETAIL';
                  RETURN FALSE;
            END;


            Dbg('Preapring Insert and Update Types for  ICTMS_TDTOPUP_PAYIN..');
            l_Wrk_Count  := p_Wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
            l_Prev_Count := p_Prev_stdtdtop.v_ictms_tdtopup_payin.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index IN 1 .. l_Wrk_Count LOOP
                  l_Rec_Found    := FALSE;
                  IF l_Prev_Count >  0 THEN
                     FOR l_index1 IN 1..l_Prev_Count  LOOP
                        IF (NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno,-1)=  NVL(p_Prev_stdtdtop.v_ictms_tdtopup_payin  (l_index1).seqno,-1)) THEN
                           Dbg('Record Has Been Found.Update Case..');
                           l_rec_found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_rec_found THEN
                     Dbg('Record is Modified...');
                     U_v_ictms_tdtopup_payin(U_v_ictms_tdtopup_payin.COUNT +1 ) :=  p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index);
                  ELSE
                     Dbg('Record is Added...');
                     I_v_ictms_tdtopup_payin(I_v_ictms_tdtopup_payin.COUNT +1 ) :=  p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index);
                  END IF;
               END LOOP;
            END IF;

            Dbg('Preapring Delete Types for  ICTMS_TDTOPUP_PAYIN..');
            l_Wrk_Count  := p_wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
            l_Prev_Count := p_prev_stdtdtop.v_ictms_tdtopup_payin.COUNT;
            IF l_Prev_Count > 0 THEN
               FOR l_index1 IN 1 .. l_Prev_Count LOOP
                  l_Rec_Found    := FALSE;
                  IF l_Wrk_Count >  0 THEN
                     FOR l_index IN 1..l_Wrk_Count  LOOP
                        IF (NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno,-1)=  NVL(p_Prev_stdtdtop.v_ictms_tdtopup_payin  (l_index1).seqno,-1)) THEN
                           Dbg('Record Has Been Found.Update Case..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF NOT l_Rec_Found THEN
                     Dbg('Record is Deleted...');
                     D_v_ictms_tdtopup_payin(D_v_ictms_tdtopup_payin.COUNT +1 ) :=  p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_index1);
                  END IF;
               END LOOP;
            END IF;
            l_Del_Count  := D_v_ictms_tdtopup_payin.COUNT;
            Dbg('Records Deleted  :'||l_Del_Count);
            IF l_Del_Count > 0 THEN
               FOR l_index IN 1 .. l_del_count LOOP
                  Dbg('Deleting Record...');
                  DELETE ICTM_TDTOPUP_PAYIN
                  WHERE topup_ref_no = D_v_ictms_tdtopup_payin(l_index).topup_ref_no
                   AND brn = D_v_ictms_tdtopup_payin(l_index).brn
                   AND acc = D_v_ictms_tdtopup_payin(l_index).acc
                   AND seqno = D_v_ictms_tdtopup_payin(l_index).seqno
                  ;
               END LOOP;
            END IF;
            l_Ins_Count  := I_v_ictms_tdtopup_payin.COUNT;
            Dbg('New Records Added  :'||l_ins_count);
            BEGIN
               l_Count      := I_v_ictms_tdtopup_payin.COUNT;
               FORALL l_Index IN  1..l_count
               INSERT INTO ICTM_TDTOPUP_PAYIN
               VALUES I_v_ictms_tdtopup_payin(l_index);
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed in Insert IntoICTMS_TDTOPUP_PAYIN..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@ICTMS_TDTOPUP_PAYIN';
                  RETURN FALSE;
            END;
            l_Upd_Count  := U_v_ictms_tdtopup_payin.COUNT;
            Dbg('Records Modified  :'||l_Upd_Count);
            IF l_Upd_Count > 0 THEN
               FOR l_index IN 1 .. l_Upd_Count LOOP
                  Dbg('Updating The  Record...');
                  BEGIN
                     UPDATE ICTM_TDTOPUP_PAYIN
                     SET
                     MULTIMODE_PAYOPT = U_v_ictms_tdtopup_payin(l_index).MULTIMODE_PAYOPT,
                     MULTIMODE_TDAMOUNT = U_v_ictms_tdtopup_payin(l_index).MULTIMODE_TDAMOUNT,
                     MULTIMODE_OFFSET_BRN = U_v_ictms_tdtopup_payin(l_index).MULTIMODE_OFFSET_BRN,
                     MULTIMODE_TDOFFSET_ACC = U_v_ictms_tdtopup_payin(l_index).MULTIMODE_TDOFFSET_ACC,
                     MULTIMODE_PERCENTAGE = U_v_ictms_tdtopup_payin(l_index).MULTIMODE_PERCENTAGE
WHERE topup_ref_no = U_v_ictms_tdtopup_payin(l_index).topup_ref_no
 AND brn = U_v_ictms_tdtopup_payin(l_index).brn
 AND acc = U_v_ictms_tdtopup_payin(l_index).acc
 AND seqno = U_v_ictms_tdtopup_payin(l_index).seqno
;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Dbg('Failed in Updating ICTMS_TDTOPUP_PAYIN..');
                        Dbg(SQLERRM);
                        p_Err_Code    := 'ST-UPLD-001';
                        p_Err_Params  := '@ICTMS_TDTOPUP_PAYIN';
                        RETURN FALSE;
                  END;
               END LOOP;
            END IF;
         ELSIF p_Action_Code = Cspks_Req_Global.p_delete THEN
            Dbg('Action Code '||p_Action_Code);
            Dbg('Deleting The Data..');

            
            DELETE ICTM_TDTOPUP_PAYIN
            WHERE topup_ref_no = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
             AND acc = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.acc
             AND brn = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.brn
            ;

            DELETE ICTB_TDTOPUP_DETAIL WHERE topup_ref_no = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
            ;


         ELSIF p_Action_Code IN (Cspks_Req_Global.p_Auth,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen ) THEN
            l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO')||'-'||
            p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no;
            BEGIN
               SELECT ROWID
               INTO   l_row_id
               FROM  ICTB_TDTOPUP_DETAIL
               WHERE topup_ref_no = p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
               ;
            EXCEPTION
               WHEN No_Data_Found THEN
                  Dbg('Failed in Selecting The Previous Master Recotrd..');
                  p_Err_Code    := 'ST-VALS-002';
                  p_Err_Params  := l_key;
                  RETURN FALSE;
            END;

            IF NOT Cspks_Req_Utils.Fn_Maint_Operations(p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               'ICTB_TDTOPUP_DETAIL',
               l_Row_Id,
               p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.mod_no,
               p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Maker_dt_Stamp,
               p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Checker_dt_Stamp,
               g_Key_Id,
               l_Key,
               p_Err_Code,
               p_Err_params) THEN
               Dbg('Failed in Cspks_Req_Utils.Fn_Maint_Basic_Validations');
               RETURN FALSE;
            END IF;

         END IF;

         Dbg('Returning Success From Fn_Sys_Upload_Db');
         RETURN TRUE;
      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Sys_Upload_Db ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_params  := NULL;
            RETURN FALSE;
      END Fn_Sys_Upload_Db;
      FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
         p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
         p_stdtdtop       IN   OUT stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Err_Code          IN OUT VARCHAR2,
         p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
         l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

      BEGIN

         Dbg('In Fn_Build_Ws_Type..');

         IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
            IF NOT Fn_Sys_Build_Fc_Type(p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Addl_Info ,
               p_STDTDTOP,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Sys_Build_Fc_Type..');
               RETURN FALSE;
            END IF;
         ELSE
            IF NOT Fn_Sys_Build_Ws_Type(p_source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Addl_Info ,
               p_STDTDTOP,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Sys_Build_Ws_Type..');
               RETURN FALSE;
            END IF;
         END IF;
         Pr_Skip_Handler('POSTTYPE');
         IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
            IF NOT stpks_stdtdtop_Kernel.Fn_Post_Build_Type_Structure(p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               l_Child_Function,
               p_Addl_Info ,
               p_STDTDTOP,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Post_Build_Type_Structure..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
            IF NOT stpks_stdtdtop_Custom.Fn_Post_Build_Type_Structure(p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               l_Child_Function,
               p_Addl_Info ,
               p_STDTDTOP,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in stpks_stdtdtop_Custom.Fn_Post_Build_Type_Structure..');
               RETURN FALSE;
            END IF;
         END IF;
         Dbg('Returning Success From Fn_Build_Type..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of stpks_stdtdtop_Main.Fn_Build_Type ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Build_Type;
      FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                                 p_source_operation  IN     VARCHAR2,
                                 p_Function_id       IN     VARCHAR2,
                                 p_action_code       IN     VARCHAR2,
         p_exchange_pattern   IN  VARCHAR2,
         p_stdtdtop          IN stpks_stdtdtop_Main.ty_stdtdtop,
         p_err_code        IN OUT VARCHAR2,
         p_err_params      IN OUT VARCHAR2)
      RETURN BOOLEAN   IS

         l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

      BEGIN

         dbg('In Fn_Build_Ts_List..');

         IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
            IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
               p_source_operation,
               p_Function_id,
               p_action_code,
               p_stdtdtop,
               p_err_code,
               p_err_params)  THEN
               dbg('Failed in Fn_Sys_Build_Fc_Ts');
               RETURN FALSE;
            END IF;
         ELSE
            IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
               p_source_operation,
               p_Function_id,
               p_action_code,
               p_exchange_pattern,
               p_stdtdtop,
               p_err_code,
               p_err_params)  THEN
               dbg('Failed in Fn_Sys_Build_Ws_Ts');
               RETURN FALSE;
            END IF;
         END IF;

         dbg('Returning from Fn_Build_Ts_List');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            debug.pr_debug('**','In when others of stpks_stdtdtop_Main.Fn_Build_Ts_List ..');
            debug.pr_debug('**',SQLERRM);
            p_err_code    := 'ST-OTHR-001';
            p_err_params  := NULL;
            RETURN FALSE;
      END Fn_Build_Ts_List;
      FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
         p_stdtdtop       IN  OUT stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Err_Code          IN OUT VARCHAR2,
         p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN   IS
         l_Key_Cols        VARCHAR2(32767);
         l_Key_Vals        VARCHAR2(32767);
         l_Func_Type       VARCHAR2(32767);
      BEGIN

         Dbg('In Fn_Get_Key_Information..');
         l_Key_Cols := 'TOPUP_REF_NO~';
         l_Key_Vals := p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no||'~';
         Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
         IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            'FCCMAINTENANCE',
            'ICTBS_TDTOPUP_DETAIL',
            'BLK_TDTOPUP_DETAIL',
            'Tdtopup-Detail',
            l_Key_Cols,
            l_Key_Vals,
            p_stdtdtop.Addl_Info,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
            RETURN FALSE;
         END IF;
         IF p_stdtdtop.Addl_Info.EXISTS('RECORD_KEY') THEN
            G_Req_Key :=  p_stdtdtop.Addl_Info('RECORD_KEY');
         END IF;
         IF p_stdtdtop.Addl_Info.EXISTS('KEY_ID') THEN
            G_Key_Id :=  p_stdtdtop.Addl_Info('KEY_ID');
         END IF;
         p_stdtdtop.Addl_Info('SENT_MOD_NO') :=p_stdtdtop.v_ictbs_tdtopup_detail.Mod_No;
         Dbg('Returning Succsess From Fn_Get_Key_Information..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of stpks_stdtdtop_Main.Fn_Get_Key_Information..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Get_Key_Information;
      FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
         p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
         p_stdtdtop IN OUT  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Err_Code       IN  OUT VARCHAR2,
         p_Err_Params     IN  OUT VARCHAR2)
        RETURN BOOLEAN IS

         l_Pk_Or_Full      VARCHAR2(10) :=  'FULL';
         l_Blk      VARCHAR2(100) ;
         l_Fld      VARCHAR2(100) ;
         l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
         l_Source_Operation      VARCHAR2(100) := p_Source_Operation;

      BEGIN

         Dbg('In Fn_Check_Mandatory..');

         IF p_Pk_Or_Full = 'FULL' OR p_Action_Code = Cspks_Req_Global.p_New THEN
            l_Pk_Or_Full := 'FULL';
         ELSE
            l_Pk_Or_Full := p_Pk_Or_Full;
         END IF;
         Pr_Skip_Handler('PREMAND');
         IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
            IF NOT stpks_stdtdtop_Custom.Fn_Pre_Check_Mandatory (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               p_stdtdtop,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in  stpks_stdtdtop_Custom.Fn_Pre_Check_Mandatory..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
            IF NOT stpks_stdtdtop_Kernel.Fn_Pre_Check_Mandatory (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               p_stdtdtop,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in  stpks_stdtdtop_Kernel.Fn_Pre_Check_Mandatory..');
               RETURN FALSE;
            END IF;
         END IF;

         IF NOT stpks_stdtdtop_Main.Fn_Skip_Sys THEN
            Dbg('Calling   Fn_Sys_Check_Mandatory..');
            IF NOT Fn_Sys_Check_Mandatory(p_Source,
               l_Pk_Or_Full,
               p_stdtdtop,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Sys_Check_Mandatory..');
               RETURN FALSE;
            END IF;
         END IF;

         Pr_Skip_Handler('POSTMAND');
         IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
            IF NOT stpks_stdtdtop_Kernel.Fn_Post_Check_Mandatory (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               l_Pk_Or_Full,
               p_stdtdtop,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in  stpks_stdtdtop_Kernel.Fn_Post_Check_Mandatory..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
            IF NOT stpks_stdtdtop_Custom.Fn_Post_Check_Mandatory (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               l_Pk_Or_Full,
               p_stdtdtop,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in  stpks_stdtdtop_Custom.Fn_Post_Check_Mandatory..');
               RETURN FALSE;
            END IF;
         END IF;
         Dbg('Returning Success From Fn_Check_Mandatory..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of stpks_stdtdtop_Main.Fn_Check_Mandatory ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Check_Mandatory;
      FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
         p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
         p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
         p_QryData_Reqd       IN  VARCHAR2,
         p_stdtdtop         IN  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Wrk_stdtdtop  IN   OUT  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Err_Code          IN OUT VARCHAR2,
         p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         l_Key_Vals VARCHAR2(32767);
         l_Tanked_data_Found             BOOLEAN := FALSE;
         l_Bld_Type_From_Tanked_Data     BOOLEAN := FALSE;
         l_Mod_No                        NUMBER;
         l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
         l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
         l_Skip_kernel      BOOLEAN := FALSE;
         l_Skip_custom      BOOLEAN := FALSE;

      BEGIN

         Dbg('In Fn_Query..');

         l_Mod_No := p_stdtdtop.v_ictbs_tdtopup_detail.Mod_No;
         Dbg('Calling Cspks_Req_Utils.Fn_Get_From_Tanked.');
         IF NOT Cspks_Req_Utils.Fn_Get_Tanked_Data (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            g_Key_Id,
            l_Mod_No,
            NVL(p_With_Lock,'N'),
            l_Tanked_data_Found,
            l_Bld_Type_From_Tanked_Data,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Cspks_Req_Utils.Fn_Get_From_Tanked.');
            Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         END IF;

         IF l_Tanked_data_Found THEN
            IF l_Bld_Type_From_Tanked_Data THEN
               IF NOT  Fn_Sys_Build_Fc_Type(p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  p_Action_Code,
                  p_stdtdtop.Addl_Info,
                  p_Wrk_stdtdtop,
                  p_Err_Code,
                  p_Err_Params)  THEN
                  Dbg('Failed in Fn_Sys_Build_Fc_Type..');
                  l_Tanked_data_Found      := FALSE;
                  Pr_Log_Error(p_Source,'ST-TANK-001',NULL);
               END IF;
               g_Curr_Stage := 'POSTTANKQRY' ;
               l_Skip_kernel:= g_Skip_kernel;
               stpks_stdtdtop_Main.Pr_Set_Skip_kernel;
               l_Skip_custom:= g_Skip_custom;
               stpks_stdtdtop_Main.Pr_Set_Skip_custom;
               Pr_Skip_Handler('POSTTANKQRY');
               Dbg('Calling Post Query Hooks After Query Of Tanked Data');
               IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
                  IF NOT stpks_stdtdtop_Kernel.Fn_Post_Query (p_Source,
                     p_Source_operation,
                     p_Function_id,
                     p_Action_Code,
                     p_Function_Id  ,
                     p_Full_Data,
                     p_With_Lock,
                     p_Qrydata_Reqd,
                     p_stdtdtop,
                     p_Wrk_stdtdtop,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Post_Query of Tanked Data');
                     RETURN FALSE;
                  END IF;
               END IF;
               Dbg('Calling Post Query Hooks After Query Of Tanked Data');
               IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
                  IF NOT stpks_stdtdtop_Custom.Fn_Post_Query (p_Source,
                     p_Source_operation,
                     p_Function_id,
                     p_Action_Code,
                     p_Function_Id  ,
                     p_Full_Data,
                     p_With_Lock,
                     p_Qrydata_Reqd,
                     p_stdtdtop,
                     p_Wrk_stdtdtop,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in stpks_stdtdtop_Custom.Fn_Post_Query of Tanked Data');
                     RETURN FALSE;
                  END IF;
               END IF;
               g_Skip_kernel:= l_Skip_kernel;
               g_Skip_custom:= l_Skip_custom;
               g_Curr_Stage := NULL ;
            END IF ;
         ELSE
            Dbg('Query From Base Tables..');
            Pr_Skip_Handler('PREQRY');
            IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
               IF NOT stpks_stdtdtop_Custom.Fn_Pre_Query (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  p_Action_Code,
                  p_function_Id  ,
                  p_Full_Data  ,
                  p_With_Lock,
                  p_QryData_Reqd,
                  p_stdtdtop,
                  p_Wrk_stdtdtop,
                  p_Err_Code  ,
                  p_Err_Params ) THEN
                  Dbg('Failed in stpks_stdtdtop_Custom.Fn_Pre_Query..');
                  RETURN FALSE;
               END IF;
            END IF;
            IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
               IF NOT stpks_stdtdtop_Kernel.Fn_Pre_Query (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  p_Action_Code,
                  p_function_Id  ,
                  p_Full_Data  ,
                  p_With_Lock,
                  p_QryData_Reqd,
                  p_stdtdtop,
                  p_Wrk_stdtdtop,
                  p_Err_Code  ,
                  p_Err_Params ) THEN
                  Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Pre_Query..');
                  RETURN FALSE;
               END IF;
            END IF;
            IF NOT stpks_stdtdtop_Main.Fn_Skip_Sys THEN
               IF NOT Fn_Sys_Query (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  p_Action_Code,
                  p_Full_Data  ,
                  p_With_Lock,
                  p_QryData_Reqd,
                  p_stdtdtop,
                  p_Wrk_stdtdtop,
                  p_Err_Code  ,
                  p_Err_Params ) THEN
                  Dbg('Failed in Fn_Sys_Query..');
                  RETURN FALSE;
               END IF;
            END IF;
            Pr_Skip_Handler('POSTQRY');
            IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
               IF NOT stpks_stdtdtop_Kernel.Fn_Post_Query (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  p_Action_Code,
                  p_function_Id  ,
                  p_Full_Data  ,
                  p_With_Lock,
                  p_QryData_Reqd,
                  p_stdtdtop,
                  p_Wrk_stdtdtop,
                  p_Err_Code  ,
                  p_Err_Params ) THEN
                  Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Post_Query..');
                  RETURN FALSE;
               END IF;
            END IF;
            IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
               IF NOT stpks_stdtdtop_Custom.Fn_Post_Query (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  p_Action_Code,
                  p_function_Id  ,
                  p_Full_Data  ,
                  p_With_Lock,
                  p_QryData_Reqd,
                  p_stdtdtop,
                  p_Wrk_stdtdtop,
                  p_Err_Code  ,
                  p_Err_Params ) THEN
                  Dbg('Failed in stpks_stdtdtop_Custom.Fn_Post_Query..');
                  RETURN FALSE;
               END IF;
            END IF;
         END IF;
         Dbg('Returning Success From Fn_Query..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Query ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Query;
      FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
         p_stdtdtop     IN  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Prev_stdtdtop IN OUT  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Wrk_stdtdtop IN OUT  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Err_Code          IN OUT VARCHAR2,
         p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN   IS
         l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
         l_Check_Amendables  VARCHAR2(1) := 'N';
         l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
         l_Full_data    VARCHAR2(1) := 'N';
         l_With_Lock    VARCHAR2(1) := 'Y';
         l_Qrydata_Reqd    VARCHAR2(1) := 'N';
         l_Pk_Or_Full      VARCHAR2(10) := 'FULL';


      BEGIN

         Dbg('In Fn_Default_And_Validate..');

         l_Full_data   := 'Y';
         Dbg('Calling  Fn_Query..');
         IF NOT Fn_Query(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Full_data,
            l_With_Lock,
            l_Qrydata_Reqd,
            p_stdtdtop,
            p_Prev_stdtdtop,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Query..');
            RETURN FALSE;
         END IF;
         Pr_Skip_Handler('PREDFLT');
         IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
            IF NOT stpks_stdtdtop_Custom.Fn_Pre_Default_And_Validate (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in stpks_stdtdtop_Custom.Fn_Pre_Default_And_Validate..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
            IF NOT stpks_stdtdtop_Kernel.Fn_Pre_Default_And_Validate (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Pre_Default_And_Validate..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_Sys THEN
            Dbg('Calling in Fn_Sys_Default_and_Validate..');
            IF NOT Fn_Sys_Default_and_Validate (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Default_and_Validate..');
               RETURN FALSE;
            END IF;
         END IF;
         Pr_Skip_Handler('POSTDFLT');
         IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
            IF NOT stpks_stdtdtop_Kernel.Fn_Post_Default_And_Validate (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Post_Default_And_Validate..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
            IF NOT stpks_stdtdtop_Custom.Fn_Post_Default_And_Validate (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_function_Id  ,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in stpks_stdtdtop_Custom.Fn_Post_Default_And_Validate..');
               RETURN FALSE;
            END IF;
         END IF;
         IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
            Dbg('Calling  Fn_Check_Mandatory..');
            IF NOT Fn_Check_Mandatory(p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               l_Pk_Or_Full,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Check_Mandatory..');
               RETURN FALSE;
            END IF;
         END IF;
         Dbg('Returning Success From Fn_Default_And_Validate..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of stpks_stdtdtop_Main.Fn_Default_And_Validate ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Default_And_Validate;
      FUNCTION Fn_Upload_Db  (p_Source            IN VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
         p_Post_Upl_Stat    IN     VARCHAR2,
         p_Multi_Trip_Id    IN  VARCHAR2,
         p_stdtdtop     IN  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Prev_stdtdtop     IN  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Wrk_stdtdtop      IN OUT  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Err_Code          IN OUT VARCHAR2,
         p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN   IS
         l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
         l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
         l_Row_Id            ROWID;
         l_Key  VARCHAR2(32767);
         l_Fld  VARCHAR2(32767);


      BEGIN

         Dbg('In Fn_Upload_Db..');

         Pr_Skip_Handler('PREUPLD');
         IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
            IF NOT stpks_stdtdtop_Custom.Fn_Pre_Upload_Db (p_Source,
               p_Source_operation,
               p_Function_id,
               p_Action_Code,
               p_function_Id  ,
               p_Post_Upl_Stat,
               p_Multi_Trip_Id,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in stpks_stdtdtop_Custom.Fn_Pre_Upload_Db..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
            IF NOT stpks_stdtdtop_Kernel.Fn_Pre_Upload_Db (p_Source,
               p_Source_operation,
               p_Function_id,
               p_Action_Code,
               p_function_Id  ,
               p_Post_Upl_Stat,
               p_Multi_Trip_Id,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Pre_Upload_Db..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_Sys THEN
            IF NOT Fn_Sys_Upload_Db (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Pre_Upload_Db..');
               RETURN FALSE;
            END IF;
         END IF;

         Pr_Skip_Handler('POSTUPLD');
         IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
            IF NOT stpks_stdtdtop_Kernel.Fn_Post_Upload_Db (p_Source,
               p_Source_operation,
               p_Function_id,
               p_Action_Code,
               p_function_Id  ,
               p_Post_Upl_Stat,
               p_Multi_Trip_Id,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Post_Upload_Db..');
               RETURN FALSE;
            END IF;
         END IF;
         IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
            IF NOT stpks_stdtdtop_Custom.Fn_Post_Upload_Db (p_Source,
               p_Source_operation,
               p_Function_id,
               p_Action_Code,
               p_function_Id  ,
               p_Post_Upl_Stat,
               p_Multi_Trip_Id,
               p_stdtdtop,
               p_Prev_stdtdtop,
               p_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in stpks_stdtdtop_Custom.Fn_Post_Upload_Db..');
               RETURN FALSE;
            END IF;
         END IF;
         Dbg('Returning Success  From Fn_Upload_Db..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of stpks_stdtdtop_Main.Fn_Upload_Db ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Upload_Db;
      FUNCTION Fn_Populate_Record_Master (p_Source            IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
                                 p_stdtdtop          IN  stpks_stdtdtop_Main.Ty_stdtdtop,
                                 p_Record_Master     IN OUT Sttbs_Record_Master%ROWTYPE,
                                 p_Err_Code          IN OUT VARCHAR2,
                                 p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         l_Summary_Rec     ICVW_TDTOPUP_SUMMARY%ROWTYPE;
         l_Summary_Rec_Found BOOLEAN := TRUE;
      BEGIN

         Dbg('In Fn_Populate_Record_Master..');

         IF  p_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen) THEN
            Dbg('Populating Record Master ..');
            IF g_Key_Id IS NOT NULL THEN
               Dbg('Get the Master Record...');
               BEGIN
                  SELECT *
                  INTO   l_Summary_Rec
                  FROM  ICVW_TDTOPUP_SUMMARY
                  WHERE topup_ref_no = p_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no
                   ;
               EXCEPTION
                  WHEN Others  THEN
                     Dbg('Failed in Selecting For Summary Record..');
                     Pr_Log_Error(p_Source,'ST-SUMM-001',NULL);
                     l_Summary_Rec_Found := FALSE;
               END;
               IF l_Summary_Rec_Found THEN
                  Dbg('Summary Record Found..');
                  p_Record_Master.Key_Id := g_Key_Id;
                  p_Record_Master.AUTH_STAT := l_Summary_Rec.AUTH_STAT;
                  p_Record_Master.RECORD_STAT := l_Summary_Rec.RECORD_STAT;
                  p_Record_Master.CHAR_FLD_1 := l_Summary_Rec.ACC;
                  p_Record_Master.CHAR_FLD_2 := l_Summary_Rec.AC_DESC;
                  p_Record_Master.DATE_FLD_1 := l_Summary_Rec.TD_OPEN_DATE;
                  p_Record_Master.DATE_FLD_2 := l_Summary_Rec.TOPUP_DATE;
                  p_Record_Master.DATE_FLD_3 := l_Summary_Rec.TOPUP_VALUE_DATE;
                  p_Record_Master.NUM_FLD_1 := l_Summary_Rec.TOPUP_AMOUNT;
                  p_Record_Master.CHAR_FLD_3 := l_Summary_Rec.TOPUP_REF_NO;
                  p_Record_Master.NUM_FLD_2 := l_Summary_Rec.TDAMT_AFTER_TOPUP;
                  p_Record_Master.NUM_FLD_3 := l_Summary_Rec.INTRATE_AFTER_TOPUP;
                  p_Record_Master.DATE_FLD_4 := l_Summary_Rec.MATDATE;
                  p_Record_Master.NUM_FLD_4 := l_Summary_Rec.MATAMT_AFTER_TOPUP;
                  p_Record_Master.CHAR_FLD_4 := l_Summary_Rec.CUSTOMER_NO;
                  p_Record_Master.CHAR_FLD_5 := l_Summary_Rec.CUSTOMER_NAME1;
                  p_Record_Master.CHAR_FLD_6 := l_Summary_Rec.CCY;
                  p_Record_Master.CHAR_FLD_7 := l_Summary_Rec.BRN;
                  p_Record_Master.CHAR_FLD_8 := l_Summary_Rec.MAKER_ID;
                  p_Record_Master.DATE_FLD_5 := l_Summary_Rec.MAKER_DT_STAMP;
               END IF;
            END IF;
         END IF;

         Dbg('Returning Success From Fn_Populate_Record_Master..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others Of Fn_Populate_Record_Master ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
      END Fn_Populate_Record_Master;

      FUNCTION Fn_Tank_Modification   (p_Source            IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
                                 p_Tanking_Status    IN OUT VARCHAR2,
                                 p_Err_Code          IN OUT VARCHAR2,
                                 p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

      BEGIN

         Dbg('In Fn_Tank_Modification..');
         p_Tanking_Status := 'N';
         IF Cspks_Req_Utils.Fn_Tank_Modification(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Rolling Back The Modification..');
            p_Tanking_Status := 'T';
            g_Tanking_Status := 'T';
            ROLLBACK TO Sp_Main_Stdtdtop;
         END IF;

         Dbg('Returning Success From Fn_Tank_Modification..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Tank_Modification ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
      END Fn_Tank_Modification;

      FUNCTION Fn_Maint_Log (p_Source            IN     VARCHAR2,
                                 p_Source_Operation IN     VARCHAR2,
                                 p_Function_Id      IN     VARCHAR2,
                                 p_Action_Code      IN     VARCHAR2,
                                 p_Multi_Trip_Id       IN     VARCHAR2,
                                 p_Request_No          IN     VARCHAR2,
                                 p_Record_Master     IN  Sttbs_Record_Master%ROWTYPE,
                                 p_stdtdtop          IN  stpks_stdtdtop_Main.Ty_stdtdtop,
                                 p_Prev_stdtdtop          IN  stpks_stdtdtop_Main.Ty_stdtdtop,
                                 p_wrk_stdtdtop          IN  stpks_stdtdtop_Main.Ty_stdtdtop,
         p_Tanking_Status IN VARCHAR2,
                                 p_Err_Code          IN OUT VARCHAR2,
                                 p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         l_Main_Function VARCHAR2(50) := p_Function_id;
         l_Auth_Stat       VARCHAR2(32767):= NULL;
         l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
         l_Key_Id         VARCHAR2(32767):= g_Key_Id;
         l_Mod_No          NUMBER := 1;
         l_Blk             VARCHAR2(32767):= NULL;
         l_Fld             VARCHAR2(32767):= NULL;
         l_Dbt             VARCHAR2(32767):= NULL;
         l_Dbc             VARCHAR2(32767):= NULL;
         l_Rec_Action      VARCHAR2(32767):= 'M';
         l_Dtl_Key          VARCHAR2(32767):= NULL;
         l_Prev_Count      NUMBER := 0;
         l_Wrk_Count      NUMBER := 0;
         l_Count          NUMBER := 0;
         l_Log_Count       NUMBER := 0;
         l_Fld_Count       NUMBER := 0;
         l_Matched_Rec     NUMBER := 0;
         l_Rec_Found       BOOLEAN:= FALSE;
         l_Prev_Found       BOOLEAN:= FALSE;
         l_Wrk_Found       BOOLEAN:= FALSE;
         l_Rec_Modified    BOOLEAN:= FALSE;
         l_Record_log      Sttbs_Record_Log%ROWTYPE;
         l_Field_log       Sttbs_Field_log%ROWTYPE;
         l_wrk_stdtdtop      stpks_stdtdtop_Main.Ty_stdtdtop;
         l_Skip_kernel      BOOLEAN := FALSE;
         l_Skip_custom      BOOLEAN := FALSE;
         l_Tb_Field_Log    Cspks_Req_Global.Ty_Tb_Fld_Log;

         PROCEDURE Pr_Log_Change(p_Dbc     IN VARCHAR2,
                                    p_Action  IN VARCHAR2,
                                    p_Old_Val IN VARCHAR2,
                                    p_New_Val IN VARCHAR2) IS
         BEGIN
            IF NVL(p_Old_Val,'@') <> NVL(p_New_Val,'@') THEN
                l_Fld_Count := l_Fld_Count +1;
               l_Log_Count := NVL(l_Tb_Field_Log.COUNT,0) +1;
               l_Field_log.Detail_Key := l_Dtl_Key;
               l_Field_log.Block_Name := l_Blk;
               l_Field_log.Field_Name := p_Dbc;
               l_Field_log.Table_Name := l_Dbt;
               l_Field_log.Item_no := l_Fld_Count;
               l_Field_log.Record_Stat := p_Action;
               IF length(p_Old_Val)>2000 THEN
                  l_Field_log.Old_Value := Substr(p_Old_Val,1,2000);
               ELSE
                  l_Field_log.Old_Value := p_Old_Val;
               END IF;
               IF length(p_New_Val)>2000 THEN
                  l_Field_log.New_Value := Substr(p_New_Val,1,2000);
               ELSE
                  l_Field_log.New_Value := p_New_Val;
               END IF;
               l_Tb_Field_Log(l_Log_Count) := l_Field_log;
            END IF;
         END Pr_Log_Change;

      BEGIN

         Dbg('In Fn_Maint_Log');

         IF  p_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Auth,Cspks_Req_Global.p_Delete,Cspks_Req_Global.p_Version_Delete) THEN
            Dbg('Maintenance Log is Required ..');
            IF l_Key_Id IS NOT NULL THEN
               IF p_Action_Code IN( Cspks_Req_Global.p_auth,Cspks_Req_Global.p_Delete,Cspks_Req_Global.p_Version_Delete) THEN
                  IF p_stdtdtop.v_ictbs_tdtopup_detail.Mod_no IS NOT NULL THEN
                     l_Mod_No           := p_stdtdtop.v_ictbs_tdtopup_detail.Mod_No;
                  ELSE
                     l_Mod_No           := p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Mod_No;
                  END IF;
               ELSE
                  l_mod_no           := p_wrk_stdtdtop.v_ictbs_tdtopup_detail.mod_no;
               END IF;
                 l_Auth_Stat := NVL(p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.Auth_Stat,'U') ;
               IF NOT Cspks_Req_Utils.Fn_Maint_Log(p_Source,
                   p_Source_Operation  ,
                   p_Function_Id ,
                   p_Action_Code,
                   p_Multi_Trip_Id ,
                   p_Request_No ,
                  'ICTBS_TDTOPUP_DETAIL',
                  l_Key_Id,
                  l_Mod_No,
                  l_Auth_Stat,
                  p_Tanking_Status ,
                  p_Record_Master ,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in   Cspks_Req_Utils.Fn_Maint_Log..');
                  RETURN FALSE;
               END IF;
               IF Cspks_Req_Utils.Fn_Field_Log_Reqd(p_Function_Id,p_Action_Code) THEN
                  l_Field_log.Key_id := l_Key_Id;
                  l_Field_log.Mod_No := l_Mod_No;
                  l_Field_log.Function_id := p_Function_Id;

                  l_Dbt := 'ICTB_TDTOPUP_DETAIL';

                  l_Blk := 'ICTBS_TDTOPUP_DETAIL';
                  l_Rec_Modified := FALSE;
                  l_Prev_Found := FALSE;
                  l_Wrk_Found := FALSE;

                  IF p_Prev_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no IS NOT NULL THEN
                     Dbg('Record Has Been Sent..');
                     l_prev_found := TRUE;
                  END IF;
                  IF p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no IS NOT NULL THEN
                     Dbg('Record Has Been Sent..');
                     l_Wrk_Found := TRUE;
                  END IF;
                  IF l_Prev_Found   THEN
                     l_Dtl_key := '~ICTB_TDTOPUP_DETAIL~'||p_Prev_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no||'~';
                  ELSIF l_Wrk_Found   THEN
                     l_Dtl_key := '~ICTB_TDTOPUP_DETAIL~'||p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no||'~';
                  END IF;
                  IF l_Wrk_Found  OR l_Prev_Found THEN
                     IF l_Wrk_Found  AND l_Prev_Found THEN
                        l_rec_action := 'M';
                     ELSIF l_wrk_found  AND ( NOT l_Prev_Found) THEN
                        l_Rec_Action := 'N';
                     ELSIF (NOT l_wrk_Found)  AND l_Prev_Found THEN
                        l_Rec_Action := 'D';
                     END IF;
                     Pr_Log_Change('BRN',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.brn,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.brn);
Pr_Log_Change('ACC',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.acc,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.acc);
Pr_Log_Change('CCY',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.ccy,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ccy);
Pr_Log_Change('TOPUP_REF_NO',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_ref_no);
Pr_Log_Change('TOPUP_AMOUNT',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.topup_amount,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_amount);
Pr_Log_Change('TOPUP_VALUE_DATE',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_value_date);
Pr_Log_Change('MATAMT_BEFORE_TOPUP',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matamt_before_topup);
Pr_Log_Change('INTRATE_BEFORE_TOPUP',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.intrate_before_topup);
Pr_Log_Change('NARRATIVE',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.narrative,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.narrative);
Pr_Log_Change('TOPUP_DATE',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.topup_date,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.topup_date);
Pr_Log_Change('TD_OPEN_DATE',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.td_open_date,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.td_open_date);
Pr_Log_Change('TENOR_DD',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_dd);
Pr_Log_Change('TENOR_MM',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_mm);
Pr_Log_Change('TENOR_YY',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tenor_yy);
Pr_Log_Change('MATDATE',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.matdate,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matdate);
Pr_Log_Change('TDAMT_BEFORE_TOPUP',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tdamt_before_topup);
Pr_Log_Change('TDAMT_AFTER_TOPUP',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.tdamt_after_topup);
Pr_Log_Change('MATAMT_AFTER_TOPUP',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.matamt_after_topup);
Pr_Log_Change('INTRATE_AFTER_TOPUP',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.intrate_after_topup);
Pr_Log_Change('EXT_REFERENCE',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.ext_reference,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.ext_reference);
Pr_Log_Change('CUST_NO',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.cust_no,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.cust_no);
Pr_Log_Change('REMITTER_NAME',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.remitter_name,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.remitter_name);
Pr_Log_Change('MAKER_ID',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.maker_id,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.maker_id);
Pr_Log_Change('MAKER_DT_STAMP',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.maker_dt_stamp);
Pr_Log_Change('CHECKER_ID',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.checker_id,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.checker_id);
Pr_Log_Change('CHECKER_DT_STAMP',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.checker_dt_stamp);
Pr_Log_Change('MOD_NO',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.mod_no,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.mod_no);
Pr_Log_Change('RECORD_STAT',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.record_stat,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.record_stat);
Pr_Log_Change('AUTH_STAT',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.auth_stat,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.auth_stat);
Pr_Log_Change('ONCE_AUTH',l_Rec_Action,p_Prev_stdtdtop.v_ictbs_tdtopup_detail.once_auth,p_Wrk_stdtdtop.v_ictbs_tdtopup_detail.once_auth);


                                    END IF;


                  l_Dbt := 'ICTM_TDTOPUP_PAYIN';
                  l_Blk := 'ICTMS_TDTOPUP_PAYIN';
                  l_Wrk_Count  := p_Wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
                  l_Prev_Count      := p_Prev_stdtdtop.v_ictms_tdtopup_payin.COUNT;
                  IF l_Wrk_count > 0 THEN
                     FOR l_Index IN 1..l_Wrk_count  LOOP
                        l_Dtl_key := '~ICTM_TDTOPUP_PAYIN~'||p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).topup_ref_no||'~'||p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).brn||'~'||p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).acc||'~'||p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_index).seqno||'~';
                        l_Rec_Found := FALSE;
                        l_Rec_Modified := FALSE;
                        IF l_Prev_count > 0 THEN
                           FOR l_Index1 IN 1..l_Prev_count  LOOP
                              IF (NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).seqno,-1)=  NVL(p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index1).seqno,-1)) THEN
                                 Dbg('Record Found..');
                                 l_Rec_Found := TRUE;
                                 l_Matched_Rec := l_Index1;
                                 Pr_Log_Change('MULTIMODE_PAYOPT','M',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index1).multimode_payopt,p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_payopt);
Pr_Log_Change('MULTIMODE_TDAMOUNT','M',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index1).multimode_tdamount,p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_tdamount);
Pr_Log_Change('MULTIMODE_OFFSET_BRN','M',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index1).multimode_offset_brn,p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_offset_brn);
Pr_Log_Change('MULTIMODE_TDOFFSET_ACC','M',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index1).multimode_tdoffset_acc,p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_tdoffset_acc);
Pr_Log_Change('MULTIMODE_PERCENTAGE','M',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index1).multimode_percentage,p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_percentage);
Pr_Log_Change('SEQNO','M',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index1).seqno,p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).seqno);



                                                            END IF;
                           END LOOP;
                        END IF;
                        IF NOT l_rec_found THEN
                           Dbg('New Record Found..');
                           Pr_Log_Change('MULTIMODE_PAYOPT','N',NULL,p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_payopt);
Pr_Log_Change('MULTIMODE_TDAMOUNT','N',NULL,p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_tdamount);
Pr_Log_Change('MULTIMODE_OFFSET_BRN','N',NULL,p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_offset_brn);
Pr_Log_Change('MULTIMODE_TDOFFSET_ACC','N',NULL,p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_tdoffset_acc);
Pr_Log_Change('MULTIMODE_PERCENTAGE','N',NULL,p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_percentage);
Pr_Log_Change('SEQNO','N',NULL,p_wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index).seqno);


                                                END IF;
                     END LOOP;
                  END IF;
                  l_Prev_count      := p_Prev_stdtdtop.v_ictms_tdtopup_payin.COUNT;
                  l_Wrk_Count  := p_Wrk_stdtdtop.v_ictms_tdtopup_payin.COUNT;
                  IF l_Prev_Count > 0 THEN
                     FOR l_Index IN 1..l_Prev_count  LOOP
                        l_Rec_Found := FALSE;
                        l_Rec_Modified := FALSE;
                        IF l_Wrk_Count > 0 THEN
                           FOR l_Index1 IN 1..l_Wrk_Count  LOOP
                              IF (NVL(p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).seqno,-1)=  NVL(p_Wrk_stdtdtop.v_ictms_tdtopup_payin(l_Index1).seqno,-1)) THEN
                                 Dbg('Record Found..');
                                 l_Rec_Found := TRUE;
                                 EXIT;

                              END IF;
                           END LOOP;
                        END IF;
                        IF NOT l_Rec_Found THEN
                           Dbg('Record Deleted..');
                           l_Dtl_key := '~ICTM_TDTOPUP_PAYIN~'||p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).topup_ref_no||'~'||p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).brn||'~'||p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).acc||'~'||p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).seqno||'~';
                           Pr_Log_Change('MULTIMODE_PAYOPT','D',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_payopt,NULL);
Pr_Log_Change('MULTIMODE_TDAMOUNT','D',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_tdamount,NULL);
Pr_Log_Change('MULTIMODE_OFFSET_BRN','D',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_offset_brn,NULL);
Pr_Log_Change('MULTIMODE_TDOFFSET_ACC','D',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_tdoffset_acc,NULL);
Pr_Log_Change('MULTIMODE_PERCENTAGE','D',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).multimode_percentage,NULL);
Pr_Log_Change('SEQNO','D',p_Prev_stdtdtop.v_ictms_tdtopup_payin(l_Index).seqno,NULL);


                                                END IF;
                     END LOOP;
                  END IF;

                  l_Count      := l_Tb_Field_Log.COUNT;
                  IF l_Count   > 0 THEN
                     Dbg('Inserting Into Field Log..');
                     BEGIN
                        FORALL l_Index IN  1..l_count
                        INSERT INTO STTBS_FIELD_LOG
                        VALUES l_Tb_Field_Log(l_index);
                     EXCEPTION
                        WHEN OTHERS THEN
                           Dbg('Failed in Insert into Field Log..');
                           Dbg(SQLERRM);
                           p_Err_Code    := 'ST-UPLD-001';
                           p_Err_Params  := '@STTBS_FIELD_LOG';
                     END;
                  END IF;

               END IF;
               g_curr_stage := 'POSTMAINTLOG';
               l_Skip_kernel:= g_Skip_kernel;
               stpks_stdtdtop_Main.Pr_Set_Skip_KERNEL;
               l_Skip_custom:= g_Skip_custom;
               stpks_stdtdtop_Main.Pr_Set_Skip_CUSTOM;
               l_Wrk_stdtdtop:=p_Wrk_stdtdtop;
               Pr_Skip_Handler('POSTMAINTLOG');
               Dbg('Calling Post Upload Hooks For any Additional Logging');
               IF NOT stpks_stdtdtop_Main.Fn_Skip_kernel  THEN
                  IF NOT stpks_stdtdtop_Kernel.Fn_Post_Upload_Db (p_Source,
                     p_Source_operation,
                     p_Function_id,
                     p_Action_Code,
                     p_function_Id  ,
                     g_Post_Upl_Stat,
                     p_Multi_Trip_Id,
                     p_stdtdtop,
                     p_Prev_stdtdtop,
                     l_Wrk_stdtdtop,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in stpks_stdtdtop_Kernel.Fn_Post_Upload_Db After Logging');
                     RETURN FALSE;
                  END IF;
               END IF;
               Dbg('Calling Post Upload Hooks For any Additional Logging');
               IF NOT stpks_stdtdtop_Main.Fn_Skip_custom  THEN
                  IF NOT stpks_stdtdtop_Custom.Fn_Post_Upload_Db (p_Source,
                     p_Source_operation,
                     p_Function_id,
                     p_Action_Code,
                     p_function_Id  ,
                     g_Post_Upl_Stat,
                     p_Multi_Trip_Id,
                     p_stdtdtop,
                     p_Prev_stdtdtop,
                     l_Wrk_stdtdtop,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in stpks_stdtdtop_Custom.Fn_Post_Upload_Db After Logging');
                     RETURN FALSE;
                  END IF;
               END IF;
               g_Skip_kernel:= l_Skip_kernel;
               g_Skip_custom:= l_Skip_custom;
               g_curr_stage := NULL;
            END IF;
         END IF;

         Dbg('Returning Success From Fn_Maint_Log..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Maint_Log ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
      END Fn_Maint_Log;

      FUNCTION Fn_Extract_Custom_Data (p_Source   IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
                                 p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                                 p_Status            IN OUT VARCHAR2 ,
                                 p_Err_Code          IN OUT VARCHAR2,
                                 p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         E_Failure_Exception     EXCEPTION;
         l_stdtdtop     stpks_stdtdtop_Main.Ty_stdtdtop;

      BEGIN

         Dbg('In Fn_Extract_Custom_Data.. ');
         IF NOT  Fn_Build_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info,
            l_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Build_Type..');
            p_Status      := 'F';
            RAISE e_Failure_Exception;
         END IF;
         Dbg('Calling  Fn_Get_Key_Information..');
         IF NOT  Fn_Get_Key_Information(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Get_Key_Information..');
            RAISE e_Failure_Exception;
         END IF;
         p_Addl_Info := l_stdtdtop.Addl_Info;
         Dbg('Returning from Fn_Extract_Custom_Data..');
         RETURN TRUE;

      EXCEPTION
         WHEN E_Failure_Exception THEN
            Dbg('From E_Failure_Exception of Fn_Extract_Custom_Data..');
            p_Status        := 'F';
            Dbg('Errors     :'||p_Err_Code);
            Dbg('Parameters :'||p_Err_Params);
            RETURN TRUE;
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Extract_Custom_Data..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Status      := 'F';
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
      END Fn_Extract_Custom_Data;

      FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
                                 p_Exchange_Pattern  IN     VARCHAR2,
                                 p_Status            IN OUT VARCHAR2 ,
                                 p_Err_Code          IN OUT VARCHAR2,
                                 p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         E_Failure_Exception     EXCEPTION;

      BEGIN

         Dbg('In Fn_Rebuild_Ts_List ');
         IF NOT  Fn_Build_Ts_List(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Exchange_Pattern,
            g_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Build_Ts_List');
            p_Status      := 'F';
            RETURN FALSE;
         END IF;
         Dbg('Returning Success From Fn_Rebuild_Ts_List..');
         RETURN TRUE;

      EXCEPTION
         WHEN E_Failure_Exception THEN
            Dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List');
            p_Status        := 'F';
            Dbg('Errors     :'||p_Err_Code);
            Dbg('Parameters :'||p_Err_Params);
            RETURN TRUE;
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Rebuild_Ts_List..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Status      := 'F';
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
      END Fn_Rebuild_Ts_List;

      FUNCTION Fn_Get_Node_Data (
         p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
         p_Err_Code          IN OUT VARCHAR2,
         p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN   IS
         l_Cntr NUMBER := 0;
      BEGIN

         Dbg('In Fn_Get_Node_Data..');
         l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
         p_Node_Data(l_Cntr).Node_Name := 'BLK_TDTOPUP_DETAIL';
         p_Node_Data(l_Cntr).Xsd_Node := 'Tdtopup-Detail';
         p_Node_Data(l_Cntr).Node_Parent := '';
         p_Node_Data(l_Cntr).Node_Relation_Type := '1';
         p_Node_Data(l_Cntr).Query_Node := '0';
         p_Node_Data(l_Cntr).Node_Fields := 'BRN~ACC~CCY~TOPUP_REF_NO~TOPUP_AMOUNT~TOPUP_VALUE_DATE~MATAMT_BEFORE_TOPUP~INTRATE_BEFORE_TOPUP~NARRATIVE~ACCOUNT_DESC~TOPUP_DATE~TD_OPEN_DATE~TENOR_DD~TENOR_MM~TENOR_YY~MATDATE~TDAMT_BEFORE_TOPUP~TDA';
         p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'MT_AFTER_TOPUP~MATAMT_AFTER_TOPUP~INTRATE_AFTER_TOPUP~EXT_REFERENCE~CUSTOMER_DESC~CUST_NO~REMITTER_NAME~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH~';
         p_Node_Data(l_Cntr).Node_Tags := 'ACCOUNT_BRANCH~AC_NO~CCY~TOPUP_REF_NO~TOPUP_AMT~VALUEDATE~MATURITY_AMT~INTEREST_RATE~NARRATIVE~ACC_DESC~TOPUP_DATE~TD_OPEN_DATE~DAYS~MONTHS~YEARS~MATDT~TDAMT_BEFORE_TOPUP~TDAMT_AFTER_TOPUP~MATAMT_AFTE';
         p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'R_TOPUP~INT_RATE_OPTION~EXT_REFERENCE~CUSTOMER_NAME~CUST_NO~REMITTER_NAME~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH~';

         l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
         p_Node_Data(l_Cntr).Node_Name := 'BLK_TDTOPUP_PAYIN';
         p_Node_Data(l_Cntr).Xsd_Node := 'Tdtopup-Payin';
         p_Node_Data(l_Cntr).Node_Parent := 'BLK_TDTOPUP_DETAIL';
         p_Node_Data(l_Cntr).Node_Relation_Type := 'N';
         p_Node_Data(l_Cntr).Query_Node := '0';
         p_Node_Data(l_Cntr).Node_Fields := 'MULTIMODE_PAYOPT~MULTIMODE_TDAMOUNT~MULTIMODE_OFFSET_BRN~MULTIMODE_TDOFFSET_ACC~MULTIMODE_PERCENTAGE~TOPUP_REF_NO~BRN~ACC~SEQNO~';
         p_Node_Data(l_Cntr).Node_Tags := 'FUND_OPT~AMNT~OFFSET_BRN~OFFSET_ACCOUNT~PECENT~TOPUP_REF_NO~BRN~ACC~SEQNO~';

         Dbg('Returning From Fn_Get_Node_Data.. ');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others Of stpks_stdtdtop_Main.Fn_Get_Node_Data..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := NULL;
            RETURN FALSE;
      END Fn_Get_Node_Data;
      FUNCTION Fn_Int_Main   (p_Source            IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_action_Code       IN     VARCHAR2,
                                 p_Multi_Trip_Id     IN     VARCHAR2,
                                 p_Request_No        IN     VARCHAR2,
                                 p_stdtdtop          IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                                 p_Status            IN OUT VARCHAR2 ,
                                 p_Err_Code          IN OUT VARCHAR2,
                                 p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         E_Failure_Exception     EXCEPTION;
         E_Override_Exception    EXCEPTION;
         l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
         l_Post_Upl_Stat         VARCHAR2(1) :='A';
         l_Prev_Auth_Stat        VARCHAR2(1) :='U';
         l_Wrk_stdtdtop    stpks_stdtdtop_Main.Ty_stdtdtop;
         l_Prev_stdtdtop    stpks_stdtdtop_Main.Ty_stdtdtop;
         l_Dmy_stdtdtop    stpks_stdtdtop_Main.Ty_stdtdtop;
         l_Pk_Or_Full    VARCHAR2(5) :='PK';
         l_Full_Data    VARCHAR2(1) := 'Y';
         l_With_Lock    VARCHAR2(1) := 'N';
         l_Qrydata_Reqd    VARCHAR2(1) := 'Y';
         l_Count         NUMBER;
         l_Action_Code       VARCHAR2(100):= p_Action_Code;
         l_Record_Master     Sttbs_Record_Master%ROWTYPE;
         l_Sent_Mod_No                NUMBER;
         l_Tanking_Status                VARCHAR2(1) := 'N';

      BEGIN

         Dbg('In Fn_Int_Main..');

         SAVEPOINT Sp_Int_Main_Stdtdtop;
         p_Status := 'S';
         g_Tanking_Status := l_Tanking_Status;
         g_stdtdtop := p_stdtdtop;
         l_Wrk_stdtdtop := p_stdtdtop;

         Dbg('Calling  Fn_Check_Mandatory..');
         IF NOT Fn_Check_Mandatory(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Pk_Or_Full,
            p_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Check_Mandatory..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         IF NOT  Fn_Get_Key_Information(p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Get_Key_Information..');
            RAISE e_Failure_Exception;
         END IF;
         l_Sent_Mod_No := p_stdtdtop.v_ictbs_tdtopup_detail.Mod_No;
         Dbg('Calling Cspks_Req_Utils.Fn_Process_Tanked_Entries..');
         IF NOT Cspks_Req_Utils.Fn_Process_Tanked_Entries(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            g_Key_Id,
            l_Sent_Mod_No,
            l_Action_Code,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  Cspks_Req_Utils.Fn_Process_Tanked_Entries..');
            RAISE E_Failure_Exception;
         END IF;

         IF p_Action_Code = Cspks_Req_Global.p_query THEN
            Dbg('Calling in Fn_Query..');
            IF NOT Fn_Query(p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               l_Full_data,
               l_with_lock,
               l_Qrydata_Reqd,
               p_stdtdtop,
               l_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Query..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
         ELSE
            Dbg('Calling  Fn_Default_And_Validate..');
            IF NOT Fn_Default_And_Validate (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               p_stdtdtop,
               l_Prev_stdtdtop,
               l_Wrk_stdtdtop,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Default_And_Validate..');
               pr_log_error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;

            -- Get Resultant Error Type
            l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
            IF l_Resultant_Error_Type <> 'E' THEN
               Dbg('Calling  Fn_Upload_Db..');
               IF NOT Fn_Upload_Db (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  l_Action_Code,
                  l_Post_Upl_Stat,
                  p_Multi_Trip_Id,
                  p_stdtdtop,
                  l_Prev_stdtdtop,
                  l_Wrk_stdtdtop,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in Fn_Upload_Db..');
                  pr_log_error(p_Source,p_Err_Code, p_Err_Params);
                  RAISE E_Failure_Exception;
               END IF;
               IF  l_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen) THEN
                  l_Prev_Auth_Stat := NVL(l_Prev_stdtdtop.v_ictbs_tdtopup_detail.Auth_Stat,'A') ;
                  --Get Upload Status
                  Dbg('Calling Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
                  IF NOT Cspks_Req_Utils.Fn_Get_Auto_Auth_Status (p_Source,
                     p_Source_Operation,
                     p_Function_Id,
                     l_Action_Code,
                     l_Prev_Auth_Stat,
                     p_Multi_Trip_Id,
                     P_Request_No,
                     l_Post_Upl_Stat,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
                     Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
                     RAISE E_Failure_Exception;
                  END IF;

                  IF l_Post_Upl_Stat NOT IN ('A','U','O') THEN
                     Dbg('Cannot Proceed Further..');
                     RAISE E_Failure_Exception;
                  ELSE
                     IF l_post_upl_stat = 'A'THEN
                        Dbg('Calling  Fn_Upload_Db..');
                        IF NOT Fn_Upload_Db (p_Source,
                           p_Source_Operation,
                           p_Function_Id,
                           Cspks_Req_Global.p_auth,
                           l_Post_Upl_Stat,
                           p_Multi_Trip_Id,
                           p_stdtdtop,
                           l_Prev_stdtdtop,
                           l_Wrk_stdtdtop,
                           p_Err_Code,
                           p_Err_Params) THEN
                           Dbg('Failed in Fn_Upload_Db..');
                           Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                           RAISE E_Failure_Exception;
                        END IF;
                     END IF;
                  END IF;
               END IF;
               --Get Upload Status
               Dbg('Calling  Cspks_Req_Utils.Fn_Get_Upload_Status..');
               IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
                  p_source_operation,
                  p_Function_Id,
                  l_Action_Code,
                  p_Multi_Trip_Id,
                  P_Request_No,
                  l_Post_Upl_Stat,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
                  Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
                  RAISE E_Failure_Exception;
               END IF;

               IF l_Post_Upl_Stat IN ('A','U') THEN
                  Dbg('Success Case...');
                  IF l_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Auth,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Query,Cspks_Req_Global.p_Version_Delete ) THEN
                     IF NOT Fn_Query(p_Source,
                        p_Source_Operation,
                        p_Function_Id,
                        l_Action_Code,
                        l_Full_Data,
                        l_With_Lock,
                        l_Qrydata_Reqd,
                        l_Wrk_stdtdtop,
                        l_Wrk_stdtdtop,
                        p_Err_Code,
                        p_Err_Params) THEN
                        Dbg('Failed in Fn_Query..');
                        Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                        RAISE E_Failure_Exception;
                     END IF;
                  END IF;
               ELSIF l_Post_Upl_Stat ='O' THEN
                  Dbg('Raising Override Exception..');
                  RAISE E_Override_Exception;
               ELSE
                  Dbg('Not Feasible to Proceed..');
                  RAISE E_Failure_Exception;
               END IF;
            ELSE
               Dbg('Encountered Errros..');
               RAISE E_Failure_Exception;
            END IF;
            Dbg('Calling Fn_Populate_Record_Master..');
            IF NOT Fn_Populate_Record_Master(p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               l_Wrk_stdtdtop,
               l_Record_Master,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Populate_Record_Master..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            IF NOT Fn_Tank_Modification(p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               l_Tanking_Status,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Rolling Back the Modification..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;

         END IF; -- Action Code

         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         g_stdtdtop := l_wrk_stdtdtop;
         g_post_upl_stat := l_Post_Upl_Stat;
         Dbg('Calling  Cspks_Req_Utils.Fn_Maint_Log..');
         IF NOT Fn_Maint_Log(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_Multi_Trip_Id,
            p_Request_No,
            l_Record_Master,
            p_stdtdtop,
            l_Prev_stdtdtop,
            l_Wrk_stdtdtop,
            l_Tanking_Status,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in   Cspks_Req_Utils.Fn_Maint_Log..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
         IF l_Action_Code = Cspks_Req_Global.p_Delete AND p_Source = 'FLEXCUBE'  THEN
            l_Wrk_stdtdtop := l_Dmy_stdtdtop;
         END IF;
         p_stdtdtop := l_wrk_stdtdtop;
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);

         Dbg('Returning Success From Fn_Int_Main..');
         RETURN TRUE;

      EXCEPTION
         WHEN E_Failure_Exception THEN
            Dbg('From E_Failure_Exception of Fn_Int_Main..');
            ROLLBACK TO Sp_Int_Main_Stdtdtop;
            p_Status        := 'F';
            l_Post_Upl_Stat := 'F';
            Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
            Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
            Dbg('Errors     :'||p_Err_Code);
            Dbg('Parameters :'||p_Err_Params);
            RETURN TRUE;

         WHEN E_Override_Exception THEN
            Dbg('From E_Override_Exception of Fn_Int_Main');
            p_Status        := 'O';
            l_post_upl_stat := 'O';
            IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
               Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
               p_Err_Code    := 'ST-OTHR-001';
               p_Err_Params  := Null;
               RETURN FALSE;
            END IF;
            Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
            Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
            Dbg('Errors     :'||p_Err_Code);
            Dbg('Parameters :'||p_Err_Params);
            RETURN TRUE;

         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Int_Main ..');
            Debug.Pr_Debug('**',SQLERRM);
            ROLLBACK TO Sp_Int_Main_Stdtdtop;
            p_Status      := 'F';
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
      END Fn_Int_Main;

      FUNCTION Fn_Main   (p_Source            IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
                                 p_Multi_Trip_Id     IN     VARCHAR2,
                                 p_Request_No        IN     VARCHAR2,
                                 p_stdtdtop          IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                                 p_Status            IN OUT VARCHAR2 ,
                                 p_Err_Code          IN OUT VARCHAR2,
                                 p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         E_Failure_Exception     EXCEPTION;
         E_Override_Exception    EXCEPTION;

      BEGIN

         Dbg('In Fn_Main..');
         SAVEPOINT Sp_Main_Stdtdtop;
         Dbg('Calling  Fn_Int_Main..');
         IF NOT  Fn_Int_Main(p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Multi_Trip_Id,
            p_Request_No,
            p_stdtdtop,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Int_Main..');
            RAISE E_Failure_Exception;
         END IF;
         IF p_Status = 'F' THEN
            RAISE E_Failure_Exception;
         ELSIF p_Status = 'O' THEN
            RAISE E_Override_Exception;
         END IF;
         Dbg('Returning Success From Fn_Main..');
         RETURN TRUE;

      EXCEPTION
         WHEN E_Failure_Exception THEN
            Dbg('From E_Failure_Exception of Fn_Main');
            ROLLBACK TO Sp_Main_Stdtdtop;
            p_Status      := 'F';
            RETURN TRUE;

         WHEN E_Override_Exception THEN
            Dbg('From E_Override_Exception of Fn_Main..');
            p_Status      := 'O';
            RETURN TRUE;

         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Main ..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Status      := 'F';
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            ROLLBACK TO Sp_Main_Stdtdtop;
            RETURN FALSE;
      END Fn_Main;

      FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                                 p_Source_Operation  IN     VARCHAR2,
                                 p_Function_Id       IN     VARCHAR2,
                                 p_Action_Code       IN     VARCHAR2,
                                 p_Exchange_Pattern  IN     VARCHAR2,
                                 p_Multi_Trip_Id     IN     VARCHAR2,
                                 p_Request_No        IN     VARCHAR2,
                                 p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                                 p_Status            IN OUT VARCHAR2 ,
                                 p_Err_Code          IN OUT VARCHAR2,
                                 p_Err_Params        IN OUT VARCHAR2)
      RETURN BOOLEAN IS

         l_stdtdtop     stpks_stdtdtop_Main.ty_stdtdtop;

      BEGIN

         Dbg('In Fn_Process_Request ');
         IF NOT  Fn_Build_Type(p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Addl_Info,
            l_stdtdtop,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Build_Type..');
            p_status      := 'F';
            RETURN FALSE;
         END IF;
         IF Cspks_Req_Global.Fn_UnTanking THEN
            IF NOT  Fn_Int_Main(p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Multi_Trip_Id,
               p_Request_No,
               l_stdtdtop,
               p_Status,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_main..');
               RETURN FALSE;
            END IF;
         ELSE
            IF NOT  Fn_Main(p_source,
               p_Source_Operation,
               p_Function_id,
               p_Action_Code,
               p_Multi_Trip_Id,
               p_Request_No,
               l_stdtdtop,
               p_Status,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_main..');
               RETURN FALSE;
            END IF;
         END IF;

         p_addl_info := l_stdtdtop.Addl_Info;
         IF Cspks_Req_Global.Fn_Build_Resp THEN
            Cspks_Req_Global.Pr_Reset;
            IF NOT  Fn_Build_Ts_List(p_Source,
               p_Source_Operation,
               p_Function_id,
               p_Action_Code,
               p_Exchange_Pattern,
               l_stdtdtop,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List..');
               p_Status      := 'F';
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Close_Ts;
         END IF;
         Dbg('Returning Success From Fn_Process_Request..');
         RETURN TRUE;

      EXCEPTION
         WHEN OTHERS THEN
            Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
            Debug.Pr_Debug('**',SQLERRM);
            p_Status      := 'F';
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
      END Fn_Process_Request;

   END stpks_stdtdtop_main;
/