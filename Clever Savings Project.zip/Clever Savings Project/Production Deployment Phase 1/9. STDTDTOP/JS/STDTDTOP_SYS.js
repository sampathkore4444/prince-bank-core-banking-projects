/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2023, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : STDTDTOP_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = 'N';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TDTOPUP_DETAIL":"BRN~ACC~CCY~TOPUP_REF_NO~TOPUP_AMOUNT~TOPUP_VALUE_DATE~MATAMT_BEFORE_TOPUP~INTRATE_BEFORE_TOPUP~NARRATIVE~ACCOUNT_DESC~TOPUP_DATE~TD_OPEN_DATE~TENOR_DD~TENOR_MM~TENOR_YY~MATDATE~TDAMT_BEFORE_TOPUP~TDAMT_AFTER_TOPUP~MATAMT_AFTER_TOPUP~INTRATE_AFTER_TOPUP~EXT_REFERENCE~CUSTOMER_DESC~CUST_NO~REMITTER_NAME~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH","BLK_TDTOPUP_PAYIN":"MULTIMODE_PAYOPT~MULTIMODE_TDAMOUNT~MULTIMODE_OFFSET_BRN~MULTIMODE_TDOFFSET_ACC~MULTIMODE_PERCENTAGE~TOPUP_REF_NO~BRN~ACC~SEQNO"};

var multipleEntryPageSize = {"BLK_TDTOPUP_PAYIN" :"15" };

var multipleEntrySVBlocks = "";

var tabMEBlks = {"CVS_MAIN__TAB_MAIN":"BLK_TDTOPUP_PAYIN"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TDTOPUP_DETAIL">BRN~ACC~CCY~TOPUP_REF_NO~TOPUP_AMOUNT~TOPUP_VALUE_DATE~MATAMT_BEFORE_TOPUP~INTRATE_BEFORE_TOPUP~NARRATIVE~ACCOUNT_DESC~TOPUP_DATE~TD_OPEN_DATE~TENOR_DD~TENOR_MM~TENOR_YY~MATDATE~TDAMT_BEFORE_TOPUP~TDAMT_AFTER_TOPUP~MATAMT_AFTER_TOPUP~INTRATE_AFTER_TOPUP~EXT_REFERENCE~CUSTOMER_DESC~CUST_NO~REMITTER_NAME~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH</FN>'; 
msgxml += '      <FN PARENT="BLK_TDTOPUP_DETAIL" RELATION_TYPE="N" TYPE="BLK_TDTOPUP_PAYIN">MULTIMODE_PAYOPT~MULTIMODE_TDAMOUNT~MULTIMODE_OFFSET_BRN~MULTIMODE_TDOFFSET_ACC~MULTIMODE_PERCENTAGE~TOPUP_REF_NO~BRN~ACC~SEQNO</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "BLK_TDTOPUP_DETAIL__BRN" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR SUMMARY SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml_sum=""; 
msgxml_sum += '    <FLD>'; 
msgxml_sum += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TDTOPUP_SUMMARY">AUTHSTAT~TXNSTAT~ACC~AC_DESC~TD_OPEN_DATE~TOPUP_DATE~TOPUP_VALUE_DATE~TOPUP_AMOUNT~TOPUP_REF_NO~TDAMT_AFTER_TOPUP~INTRATE_AFTER_TOPUP~MATDATE~MATAMT_AFTER_TOPUP~CUSTOMER_NO~CUSTOMER_NAME1~CCY~BRN~MAKER_ID~MAKER_DT_STAMP</FN>'; 
msgxml_sum += '    </FLD>'; 

var detailFuncId = "STDTDTOP";
var defaultWhereClause = "CUSTOMER_NO IN (select a.customer_no from sttm_customer a where (a.group_code is not null and exists ( select 1 from stvws_user_group b where b.user_id = GLOBAL.user_id and b.group_code= a.group_code)) OR a.group_code is null)";
var defaultOrderByClause ="";
var multiBrnWhereClause ="CUSTOMER_NO IN (select a.customer_no from sttm_customer a where (a.group_code is not null and exists ( select 1 from stvws_user_group b where b.user_id = GLOBAL.user_id and b.group_code= a.group_code)) OR a.group_code is null)";
var g_SummaryType ="S";
var g_SummaryBtnCount =0;
var g_SummaryBlock ="BLK_TDTOPUP_SUMMARY";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TDTOPUP_DETAIL" : "","BLK_TDTOPUP_PAYIN" : "BLK_TDTOPUP_DETAIL~N"}; 

 var dataSrcLocationArray = new Array("BLK_TDTOPUP_DETAIL","BLK_TDTOPUP_PAYIN"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside STDTDTOP.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside STDTDTOP.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TDTOPUP_DETAIL__TOPUP_REF_NO";
pkFields[0] = "BLK_TDTOPUP_DETAIL__TOPUP_REF_NO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_TDTOPUP_DETAIL":["BTN_COMPUTE","BTN_POPULATE","EXT_REFERENCE","INTRATE_AFTER_TOPUP","INTRATE_BEFORE_TOPUP","MATAMT_AFTER_TOPUP","MATAMT_BEFORE_TOPUP","NARRATIVE","TDAMT_AFTER_TOPUP","TDAMT_BEFORE_TOPUP","TD_OPEN_DATEI","TOPUP_AMOUNT","TOPUP_DATE","TOPUP_VALUE_DATEI"],"BLK_TDTOPUP_PAYIN":["MULTIMODE_OFFSET_BRN","MULTIMODE_PAYOPT","MULTIMODE_PERCENTAGE","MULTIMODE_TDAMOUNT","MULTIMODE_TDOFFSET_ACC","SEQNO"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TDTOPUP_DETAIL__ACC__LOV_ACC_NO":["BLK_TDTOPUP_DETAIL__ACC~BLK_TDTOPUP_DETAIL__ACCOUNT_DESC~BLK_TDTOPUP_DETAIL__CUST_NO~BLK_TDTOPUP_DETAIL__CCY~BLK_TDTOPUP_DETAIL__CUSTOMER_DESC~","BLK_TDTOPUP_DETAIL__BRN!VARCHAR2","N~N~N~N~N",""],"BLK_TDTOPUP_PAYIN__MULTIMODE_TDOFFSET_ACC__LOV_PAYINOFFSETACC":["BLK_TDTOPUP_PAYIN__MULTIMODE_TDOFFSET_ACC~BLK_TDTOPUP_PAYIN__MULTIMODE_OFFSET_BRN~~~~","BLK_TDTOPUP_PAYIN__MULTIMODE_PAYOPT!VARCHAR2~BLK_TDTOPUP_PAYIN__MULTIMODE_PAYOPT!VARCHAR2","N~N~N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_TDTOPUP_PAYIN");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array(); 

 var CallFormRelat=new Array(); 

 var CallRelatType= new Array(); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["STDTDTOP"]="KERNEL";
ArrPrntFunc["STDTDTOP"]="";
ArrPrntOrigin["STDTDTOP"]="";
ArrRoutingType["STDTDTOP"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["STDTDTOP"]="N";
ArrCustomModified["STDTDTOP"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {};
var scrArgSource = {};
var scrArgVals = {};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"2"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------