CREATE OR REPLACE PACKAGE  stpks_stdcustd_main AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcustd_main.spc
  **
  ** Module     : Static Maintenance
  ** 
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  ** 
  ** 
  ** No part of this work may be reproduced, stored in a retrieval system, adopted 
  ** or transmitted in any form or by any means, electronic, mechanical, 
  ** photographic, graphic, optic recording or otherwise, translated in any 
  ** language or computer language, without the prior written permission of 
  ** Oracle and/or its affiliates. 
  ** 
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East), 
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :  
  Changed By         :  
  Change Description :  
  
  -------------------------------------------------------------------------------------------------------
  */
  
  
TYPE ty_tb_v_account_prov_percent IS TABLE OF sttm_account_prov_percent%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_bic_code IS TABLE OF sttm_bic_code%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__accstat_replines_detail IS TABLE OF sttm_accstat_replines_detail%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_sttms_ac_linked_entities IS TABLE OF sttm_ac_linked_entities%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_custac_products IS TABLE OF sttm_custac_products%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_custac_txncode IS TABLE OF sttm_custac_txncode%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_custac_crdr_lmts IS TABLE OF sttm_custac_crdr_lmts%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_ictms_acc_pr IS TABLE OF ictm_acc_pr%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_ictms_acc_effdt IS TABLE OF ictm_acc_effdt%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_ictms_acc_udevals IS TABLE OF ictm_acc_udevals%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__account_report_gen_time IS TABLE OF sttm_account_report_gen_time%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_report_gen_time__gen1 IS TABLE OF sttm_account_report_gen_time%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cstbs_ui_columns__mult IS TABLE OF cstb_ui_columns%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_account_nominees IS TABLE OF sttm_account_nominees%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_ictms_tdpayin_details IS TABLE OF ictm_tdpayin_details%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_ictms_tdpayout_details IS TABLE OF ictm_tdpayout_details%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cust_account_linkages IS TABLE OF sttm_cust_account_linkages%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_customer IS TABLE OF sttm_customer%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_sttms_doctype_check_list IS TABLE OF sttm_doctype_check_list%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_od_coll_linkages IS TABLE OF sttm_od_coll_linkages%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_sttms_intermediary IS TABLE OF sttm_intermediary%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cstbs_snck_detail IS TABLE OF cstb_snck_detail%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_ui_columns__int_payout IS TABLE OF cstb_ui_columns%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__ictms_tdaddnlpayin_dtls IS TABLE OF ictm_tdaddnlpayin_dtls%ROWTYPE INDEX BY BINARY_INTEGER;

TYPE ty_stdcustd IS RECORD (
      v_sttms_cust_account     sttm_cust_account%ROWTYPE,
      v_account_prov_percent    ty_tb_v_account_prov_percent,
      v_sttms_bic_code    ty_tb_v_sttms_bic_code,
      v_accstat_replines_detail    ty_tb__accstat_replines_detail,
      v_sttms_ac_linked_entities    ty_tb_sttms_ac_linked_entities,
      v_sttms_account_maint_instr     sttm_account_maint_instr%ROWTYPE,
      v_sttms_custac_products    ty_tb_v_sttms_custac_products,
      v_sttms_custac_txncode    ty_tb_v_sttms_custac_txncode,
      v_sttms_custac_crdr_lmts    ty_tb_v_sttms_custac_crdr_lmts,
      v_ictms_acc_pr    ty_tb_v_ictms_acc_pr,
      v_ictms_acc     ictm_acc%ROWTYPE,
      v_ictms_acc_effdt    ty_tb_v_ictms_acc_effdt,
      v_ictms_acc_udevals    ty_tb_v_ictms_acc_udevals,
      v_account_report_gen_time    ty_tb__account_report_gen_time,
      v_report_gen_time__gen1    ty_tb_v_report_gen_time__gen1,
      v_ictms_td_details     ictm_td_details%ROWTYPE,
      v_cstbs_ui_columns     cstb_ui_columns%ROWTYPE,
      v_cstbs_ui_columns__mult    ty_tb_v_cstbs_ui_columns__mult,
      v_sttms_account_bal_tov     sttm_account_bal_tov%ROWTYPE,
      v_sftms_cust_subscription     sftm_cust_subscription%ROWTYPE,
      v_sttms_acc_notice_pref     sttm_acc_notice_pref%ROWTYPE,
      v_sttms_account_nominees    ty_tb_v_sttms_account_nominees,
      v_cstbs_ui_columns__brnst     cstb_ui_columns%ROWTYPE,
      v_ictms_dcd_master     ictm_dcd_master%ROWTYPE,
      v_acvws_crtur_lmt_bal     acvw_crtur_lmt_bal%ROWTYPE,
      v_ictms_tdpayin_details    ty_tb_v_ictms_tdpayin_details,
      v_ictms_tdpayout_details    ty_tb_v_ictms_tdpayout_details,
      v_sttm_account_tod_renew     sttm_account_tod_renew%ROWTYPE,
      v_cust_account_linkages    ty_tb_v_cust_account_linkages,
      v_sttms_customer    ty_tb_v_sttms_customer,
      v_sttms_doctype_check_list    ty_tb_sttms_doctype_check_list,
      v_sttms_doctype_remarks     sttm_doctype_remarks%ROWTYPE,
      v_svtm_cif_pri_cust     svtm_cif_pri_cust%ROWTYPE,
      v_sttms_od_coll_linkages    ty_tb_v_sttms_od_coll_linkages,
      v_stvws_chqbk_request     stvw_chqbk_request%ROWTYPE,
      v_stvws_dc_request     stvw_dc_request%ROWTYPE,
      v_sttms_intermediary    ty_tb_v_sttms_intermediary,
      v_cstbs_snck_master     cstb_snck_master%ROWTYPE,
      v_cstbs_snck_detail    ty_tb_v_cstbs_snck_detail,
      v_cstbs_snck_status     cstb_snck_status%ROWTYPE,
      v_cstbs_ui_columns__snck     cstb_ui_columns%ROWTYPE,
      v_ui_columns__int_payout    ty_tb_v_ui_columns__int_payout,
      v_ictms_tdaddnlpayin_dtls    ty_tb__ictms_tdaddnlpayin_dtls,
      v_ictm_td_details_custom     ictm_td_details_custom%ROWTYPE,
                  ty_csccusln Cspks_Csccusln_Main.ty_csccusln,
                  ty_icccspcn Icpks_Icccspcn_Main.ty_icccspcn,
                  ty_icchspcn Icpks_Icchspcn_Main.ty_icchspcn,
                  ty_iccinstr Icpks_Iccinstr_Main.ty_iccinstr,
                  ty_micacctm Mipks_Micacctm_Main.ty_micacctm,
                  ty_sicdiary Sipks_Sicdiary_Main.ty_sicdiary,
                  ty_stccusbl Stpks_Stccusbl_Main.ty_stccusbl,
                  ty_stcaclos Stpks_Stcaclos_Main.ty_stcaclos,
                  ty_svcacsig Svpks_Svcacsig_Main.ty_svcacsig,
                  ty_stccrdsa Stpks_Stccrdsa_Main.ty_stccrdsa,
                  ty_icctdfpo Icpks_Icctdfpo_Main.ty_icctdfpo,
                  ty_cscofacm Cspks_Cscofacm_Main.ty_cscofacm,
                  ty_iccintpo Icpks_Iccintpo_Main.ty_iccintpo,
                  ty_stcsweep Stpks_Stcsweep_Main.ty_stcsweep,
                  ty_stcrlhis Stpks_Stcrlhis_Main.ty_stcrlhis,
                  ty_stcrlihi Stpks_Stcrlihi_Main.ty_stcrlihi,
                  ty_cscupdoc Cspks_Cscupdoc_Main.ty_cscupdoc,
                  ty_stcoswp Stpks_Stcoswp_Main.ty_stcoswp,
                  ty_stcchnlm Stpks_Stcchnlm_Main.ty_stcchnlm,
                  ty_stcdendp Stpks_Stcdendp_Main.ty_stcdendp,
                  Udf_Details Copkss_Udf_Upload.ty_upl_func_udf,
                  Desc_Fields    Cspks_Req_Global.Ty_Tb_Xml_Data,
                  Addl_Info    Cspks_Req_Global.Ty_Addl_info );


FUNCTION  Fn_Get_Curr_Stage RETURN VARCHAR2 ;
FUNCTION  Fn_Get_Tanked_Stat RETURN VARCHAR2 ;
PROCEDURE Pr_Set_Skip_Sys;
PROCEDURE Pr_Set_Activate_Sys;
FUNCTION  Fn_Skip_Sys RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Kernel;
PROCEDURE Pr_Set_Activate_Kernel;
FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Custom;
PROCEDURE Pr_Set_Activate_Custom;
FUNCTION  Fn_Skip_Custom RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Master;
PROCEDURE Pr_Set_Activate_Master;
FUNCTION  Fn_Skip_Master RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Child;
PROCEDURE Pr_Set_Activate_Child;
FUNCTION  Fn_Skip_Child RETURN BOOLEAN;
PROCEDURE Pr_Convert_Child_To_Master   (
p_Child_stdcustd     IN  stpks_stdcustd_Main.ty_stdcustd,
p_Master_STDCUSAC     IN OUT  Stpks_Stdcusac_Main.ty_STDCUSAC);
PROCEDURE Pr_Convert_Master_To_Child (
p_Master_STDCUSAC     IN  Stpks_Stdcusac_Main.ty_STDCUSAC,
p_Child_stdcustd     IN  OUT stpks_stdcustd_Main.ty_stdcustd);
FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Wrk_stdcustd  IN   OUT stpks_stdcustd_Main.ty_stdcustd,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Populate_Record_Master (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_stdcustd          IN  stpks_stdcustd_Main.Ty_stdcustd,
                        p_Record_Master     IN OUT Sttbs_Record_Master%ROWTYPE,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;

FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2, 
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_stdcustd       IN  OUT stpks_stdcustd_Main.Ty_stdcustd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Extract_Custom_Data (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 
FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_exchange_pattern  IN     VARCHAR2,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Int_Main    (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_stdcustd          IN OUT  stpks_stdcustd_Main.ty_stdcustd,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 

FUNCTION Fn_main       (p_source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_stdcustd          IN OUT  stpks_stdcustd_Main.ty_stdcustd,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ; 


FUNCTION Fn_Process_Request (p_source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Get_Node_Data ( 
p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
END stpks_stdcustd_main;
/
CREATE OR REPLACE SYNONYM stpkss_stdcustd_main FOR stpks_stdcustd_main
/