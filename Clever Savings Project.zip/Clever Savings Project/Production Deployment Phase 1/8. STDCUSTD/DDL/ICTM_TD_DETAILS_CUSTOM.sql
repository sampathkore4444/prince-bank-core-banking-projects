create table ICTM_TD_DETAILS_CUSTOM
(
  brn            VARCHAR2(3),
  acc            VARCHAR2(20),
  ccy            VARCHAR2(3),
  min_top_up_amt NUMBER(22,3)
)
/
alter table ICTM_TD_DETAILS_CUSTOM add primary key (BRN, ACC, CCY)
/