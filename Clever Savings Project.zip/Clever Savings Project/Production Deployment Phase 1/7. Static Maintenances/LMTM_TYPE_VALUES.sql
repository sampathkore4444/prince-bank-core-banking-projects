insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_KH', 'RUBY_PLAN_A', '1000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_KH', 'GOLD_PLAN_A', '600000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_KH', 'GOLD_PLAN_B', '1000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_KH', 'SILVER_PLAN_A', '400000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_KH', 'SILVER_PLAN_B', '600000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_KH', 'SILVER_PLAN_C', '1000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_US', 'RUBY_PLAN_A', '250');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_US', 'GOLD_PLAN_A', '150');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_US', 'GOLD_PLAN_B', '250');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_US', 'SILVER_PLAN_A', '100');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_US', 'SILVER_PLAN_B', '150');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLESAV_INSFEE_US', 'SILVER_PLAN_C', '250');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLEVERSAV_MINTOP', 'GOLD_PLAN_A', '300');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLEVERSAV_MINTOP', 'GOLD_PLAN_B', '350');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLEVERSAV_MINTOP', 'SILVER_PLAN_A', '200');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLEVERSAV_MINTOP', 'SILVER_PLAN_B', '300');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLEVERSAV_MINTOP', 'SILVER_PLAN_C', '350');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CLEVERSAV_MINTOP', 'RUBY_PLAN_A', '350');

COMMIT;
