insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CLESAV_INSFEE_KH', 'Clever Savings plan Insurance Fee in KHR', 'SAMPATH2', 'SAMPATH2', to_date('20-03-2024 11:51:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-03-2024 11:51:20', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '2', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CLESAV_INSFEE_US', 'Clever Savings plan Insurance Fee in USD', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 11:44:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 11:44:26', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '2', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CLEVERSAV_MINTOP', 'Clever Savings Minimum Top Up Amount in USD Amount', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 17:22:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 17:22:43', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '3', 'Y');

COMMIT;
