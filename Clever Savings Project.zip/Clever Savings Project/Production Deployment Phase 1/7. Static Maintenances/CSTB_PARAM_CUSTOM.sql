prompt Importing table CSTB_PARAM_CUSTOM...
set feedback off
set define off
insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CLEVER_SAV_PUSH_NOTIF_URL', 'http://integration-uat1.princeplc.com.kh/prnc-app/external/v1.0/push', 'N'); --UAT

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CLEVER_SAV_PUSH_NOTIF_UID', 'prince', 'N'); --UAT

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CLEVER_SAV_PUSH_NOTIF_PWD', 'qwer!@#$', 'N'); --UAT

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CLEVER_SAV_PUSH_NOTIF_URL', 'https://integration.princeplc.com.kh/prnc-app/external/v1.0/push', 'N'); --PROD

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CLEVER_SAV_PUSH_NOTIF_UID', 'princesupport', 'N'); --PROD

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('CLEVER_SAV_PUSH_NOTIF_PWD', '@RftSupport#2020', 'N'); --PROD

prompt Done.
