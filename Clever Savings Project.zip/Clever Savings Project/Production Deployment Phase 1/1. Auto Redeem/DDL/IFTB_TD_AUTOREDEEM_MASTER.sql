-- Create table
create table IFTB_TD_AUTOREDEEM_MASTER
(
  seq_no         VARCHAR2(105) not null,
  acc            VARCHAR2(105),
  brn            VARCHAR2(3),
  ccy            VARCHAR2(3),
  tdredeem_refno VARCHAR2(20),
  tdredeem_date  DATE,
  status         CHAR(1),
  tried_status   CHAR(1)
)
/
alter table IFTB_TD_AUTOREDEEM_MASTER add primary key (SEQ_NO)
/