-- Create table
create table IFTB_CLEVER_SAVINGS_OVERDUE_ACCS
(
  seq_no          VARCHAR2(25),
  customer_no     VARCHAR2(25),
  acc             VARCHAR2(25),
  brn             VARCHAR2(3),
  ccy             VARCHAR2(3),
  due_date        DATE,
  auto_close_date DATE,
  status          CHAR(1) default 'N',
  alert_sent_time DATE
)
/
alter table IFTB_CLEVER_SAVINGS_OVERDUE_ACCS add primary key (SEQ_NO)
/