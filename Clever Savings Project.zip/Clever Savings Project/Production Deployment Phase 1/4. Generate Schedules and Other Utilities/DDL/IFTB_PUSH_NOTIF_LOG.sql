-- Create table
create table IFTB_PUSH_NOTIF_LOG
(
  cust_no     VARCHAR2(12),
  action_code VARCHAR2(10),
  content     VARCHAR2(3500),
  time_sent   DATE
)
/
alter table IFTB_PUSH_NOTIF_LOG add primary key (CUST_NO, ACTION_CODE)
/