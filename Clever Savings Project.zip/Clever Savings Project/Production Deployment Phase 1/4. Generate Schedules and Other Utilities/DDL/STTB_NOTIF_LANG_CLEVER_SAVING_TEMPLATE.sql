-- Create table
create table STTB_NOTIF_LANG_CLEVER_SAVING_TEMPLATE
(
  language      VARCHAR2(3),
  trigger_alert VARCHAR2(25),
  message       NVARCHAR2(255)
)
/
alter table STTB_NOTIF_LANG_CLEVER_SAVING_TEMPLATE add primary key (LANGUAGE, TRIGGER_ALERT)
/