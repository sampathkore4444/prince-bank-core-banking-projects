-- Create table
create table IFTB_CLEVER_SAV_PUSH_NOTIFICATION
(
  customer_no VARCHAR2(9),
  cust_ac_no  VARCHAR2(20),
  ccy         VARCHAR2(3),
  branch_code VARCHAR2(3),
  action_code VARCHAR2(100),
  status      CHAR(1) default 'N',
  timestamp   DATE
)
/
alter table IFTB_CLEVER_SAV_PUSH_NOTIFICATION add primary key (CUSTOMER_NO, CUST_AC_NO, CCY, BRANCH_CODE, ACTION_CODE)
/