-- Create table
create table IFTB_TD_TOPUP_SCHEDULES
(
  acc                 VARCHAR2(20),
  brn                 VARCHAR2(3),
  ccy                 VARCHAR2(3),
  due_date            DATE,
  due_date_with_grace DATE,
  auto_topup_amt      NUMBER,
  principal_bal       NUMBER
)
/
--alter table IFTB_TD_TOPUP_SCHEDULES add primary key (ACC, BRN, CCY)
alter table IFTB_TD_TOPUP_SCHEDULES add primary key (ACC, BRN, CCY) disable novalidate
/
