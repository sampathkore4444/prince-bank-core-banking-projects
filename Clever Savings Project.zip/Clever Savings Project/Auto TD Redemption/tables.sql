-- Create table
create table IFTB_TD_AUTOREDEEM_MASTER
(
  seq_no         VARCHAR2(105) not null,
  acc            VARCHAR2(105),
  brn            VARCHAR2(3),
  ccy            VARCHAR2(3),
  tdredeem_refno VARCHAR2(20),
  tdredeem_date  DATE,
  status         CHAR(1),
  tried_status   CHAR(1)
)
/
alter table IFTB_TD_AUTOREDEEM_MASTER add primary key (SEQ_NO)
/
-- Create table
create table IFTB_AUTO_REDEMPTION_WS_LOG
(
  reference_no VARCHAR2(105) primary key,
  invoke_date  TIMESTAMP(6),
  customer_no  VARCHAR2(105),
  cust_ac_no   VARCHAR2(105),
  req_type     VARCHAR2(25),
  req_msg      CLOB,
  res_msg      CLOB,
  status       CHAR(1),
  addl_info    VARCHAR2(105)
)
/
create sequence TRSQ_AUTO_TDREDEEM_SEQ
minvalue 1
maxvalue 9999999999999
start with 1
increment by 1
cache 20;
/