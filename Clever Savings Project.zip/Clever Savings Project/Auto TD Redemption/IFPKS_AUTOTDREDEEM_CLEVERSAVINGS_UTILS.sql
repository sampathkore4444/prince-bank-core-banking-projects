CREATE OR REPLACE PACKAGE BODY IFPKS_AUTOTDREDEEM_CLEVERSAVINGS_UTILS AS

  PROCEDURE PR_GET_FORMATTED_XML(P_XML           IN VARCHAR2,
                                 P_FORMATTED_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_FORMATTED_XML := P_XML;
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '<S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSCcyService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSRTService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '   </S:Body>', NULL);
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Envelope>', NULL);
  
  END PR_GET_FORMATTED_XML;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_TDREDEEMPTION_CLEVERSAVINGS_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_INSERT_WS_LOG(P_SEQ_NO    IN VARCHAR2,
                             P_INVOKE_TS IN TIMESTAMP,
                             P_ACC       IN VARCHAR2,
                             P_REQ_TYPE  IN VARCHAR2,
                             P_REQ_MSG   IN VARCHAR2,
                             P_ADDL_INFO IN VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    INSERT INTO IFTB_AUTO_REDEMPTION_WS_LOG
      (REFERENCE_NO, INVOKE_DATE, CUST_AC_NO, REQ_TYPE, REQ_MSG, ADDL_INFO)
    VALUES
      (P_SEQ_NO, P_INVOKE_TS, P_ACC, P_REQ_TYPE, P_REQ_MSG, P_ADDL_INFO);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_WS_LOG=' || SQLERRM);
  END PR_INSERT_WS_LOG;

  PROCEDURE PR_UPDATE_WS_LOG(P_SEQ_NO   IN VARCHAR2,
                             P_RESPONSE IN CLOB,
                             P_STATUS   IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF IFTB_AUTO_TOP_UP_WS_LOG');
  
    UPDATE IFTB_AUTO_REDEMPTION_WS_LOG
       SET RES_MSG = P_RESPONSE, STATUS = P_STATUS
     WHERE REFERENCE_NO = P_SEQ_NO;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_WS_LOG=' || SQLERRM);
  END PR_UPDATE_WS_LOG;

  PROCEDURE PR_INSERT_TD_AUTO_REDEEM_MASTER(P_SEQ_NO         IN VARCHAR2,
                                            P_ACC            IN VARCHAR2,
                                            P_BRN            IN VARCHAR2,
                                            P_CCY            IN VARCHAR2,
                                            P_TDREDEEM_REFNO IN VARCHAR2,
                                            P_TDREDEEM_DATE  IN DATE,
                                            P_STATUS         IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_INSERT_TD_AUTO_REDEEM_MASTER');
  
    INSERT INTO IFTB_TD_AUTOREDEEM_MASTER
      (SEQ_NO, ACC, BRN, CCY, TDREDEEM_REFNO, TDREDEEM_DATE, STATUS)
    VALUES
      (P_SEQ_NO,
       P_ACC,
       P_BRN,
       P_CCY,
       P_TDREDEEM_REFNO,
       P_TDREDEEM_DATE,
       P_STATUS);
  
    COMMIT;
  
    DBG('END OF PR_INSERT_TD_AUTO_REDEEM_MASTER');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_TD_AUTO_REDEEM_MASTER');
      DBG('ERROR CODE IN PR_INSERT_TD_AUTO_REDEEM_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_TD_AUTO_REDEEM_MASTER=' || SQLERRM);
  END PR_INSERT_TD_AUTO_REDEEM_MASTER;

  PROCEDURE PR_UPDATE_TD_AUTO_REDEEM_MASTER(P_SEQ_NO         IN VARCHAR2,
                                            P_ACC            IN VARCHAR2,
                                            P_BRN            IN VARCHAR2,
                                            P_CCY            IN VARCHAR2,
                                            P_TDREDEEM_REFNO IN VARCHAR2,
                                            P_STATUS         IN CHAR,
                                            P_TRIED_STATUS   IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_TD_AUTO_REDEEM_MASTER');
  
    UPDATE IFTB_TD_AUTOREDEEM_MASTER
       SET TDREDEEM_REFNO = P_TDREDEEM_REFNO,
           STATUS         = P_STATUS,
           TRIED_STATUS   = P_TRIED_STATUS
     WHERE SEQ_NO = P_SEQ_NO
       AND ACC = P_ACC
       AND BRN = P_BRN
       AND CCY = P_CCY;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_TD_AUTO_REDEEM_MASTER');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_TD_AUTO_REDEEM_MASTER');
      DBG('ERROR CODE IN PR_UPDATE_TD_AUTO_REDEEM_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_TD_AUTO_REDEEM_MASTER=' || SQLERRM);
  END PR_UPDATE_TD_AUTO_REDEEM_MASTER;

  PROCEDURE PR_PROCESS_AUTOTDREDEEM(PARAMNAME  VARCHAR2,
                                    PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    PR_PROCESS_AUTOTDREDEEM;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_AUTOTDREDEEM');
      DBG('ERROR CODE IN PR_PROCESS_AUTOTDREDEEM=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_AUTOTDREDEEM=' || SQLERRM);
    
  END PR_PROCESS_AUTOTDREDEEM;

  PROCEDURE PR_PROCESS_AUTOTDREDEEM AS
    --(P_ACC IN VARCHAR2, --TD Account
    -- P_CCY IN VARCHAR2, --TD Account Currency
    -- P_BRN IN VARCHAR2) AS
    --TD Account Branch
  
    L_ICTM_TDPAYOUT_DETAILS ICTM_TDPAYOUT_DETAILS%ROWTYPE;
  
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
  
    L_STATUS_MSG VARCHAR2(105);
    L_ERROR_DESC VARCHAR2(255);
  
    L_RESPONSE VARCHAR2(32767) := '';
    L_XML      VARCHAR2(32767);
    L_SEQ      VARCHAR2(100);
  
    L_TDREDEEM_REF_NO ICTB_TDREDEMPTION_MASTER.REDEM_REF_NO%TYPE;
  
    CURSOR C1 IS
    
      SELECT * FROM IFTB_TD_AUTOREDEEM_MASTER A WHERE A.STATUS = 'N';
  
  BEGIN
  
    DBG('INSIDE PR_PROCESS_AUTOTDREDEEM');
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        SAVEPOINT A;
      
        --GLOBAL.PR_INIT('000', 'SYSTEM');
      
        GLOBAL.PR_INIT(G.BRN, 'SYSTEM');
        
         DBG('INSIDE PR_PROCESS_AUTOTDREDEEM');
      
        --SEQUENCE GENERATION FOR MSGID AND REF ID
        SELECT TRSQ_AUTO_TDREDEEM_SEQ.NEXTVAL INTO L_SEQ FROM DUAL;
      
        L_SEQ := SUBSTR(TO_CHAR(SYSDATE, 'YYMM'), 2) || LPAD(L_SEQ, 9, '0');
      
        /*  --insert into master table
        PR_INSERT_TD_AUTO_REDEEM_MASTER(L_SEQ,
                                        P_ACC,
                                        P_BRN,
                                        P_CCY,
                                        NULL,
                                        GLOBAL.APPLICATION_DATE,
                                        'N');*/
      
        L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSTDService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:CREATETDREDEM_FSFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>EXTSYS</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            
            <fcub:MSGID></fcub:MSGID>
            
            <fcub:CORRELID></fcub:CORRELID>
            <fcub:USERID>SYSTEM</fcub:USERID>
            
            <fcub:ENTITY></fcub:ENTITY>
            <fcub:BRANCH>$L_BRN_CODE</fcub:BRANCH>
            
            <fcub:MODULEID>IC</fcub:MODULEID>
            <fcub:SERVICE>FCUBSTDService</fcub:SERVICE>
            <fcub:OPERATION>CreateTDRedem</fcub:OPERATION>
            
            <fcub:SOURCE_OPERATION></fcub:SOURCE_OPERATION>
            
            <fcub:SOURCE_USERID></fcub:SOURCE_USERID>
            
            <fcub:DESTINATION></fcub:DESTINATION>
            
            <fcub:MULTITRIPID></fcub:MULTITRIPID>
            
            <fcub:FUNCTIONID></fcub:FUNCTIONID>
            
            <fcub:ACTION></fcub:ACTION>
            
            <fcub:MSGSTAT></fcub:MSGSTAT>
            
            <fcub:SNAPSHOTID></fcub:SNAPSHOTID>
            
            <fcub:PASSWORD></fcub:PASSWORD>
            
            <fcub:ADDL>
               <!--Zero or more repetitions:-->
               <fcub:PARAM>
                  <fcub:NAME></fcub:NAME>
                  <fcub:VALUE></fcub:VALUE>
               </fcub:PARAM>
            </fcub:ADDL>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Ictms-Tdredmpayout-Master-Full>
               
               <fcub:WAIVEINT></fcub:WAIVEINT>
               
               <fcub:SUPPRESS_REDEMPTION_ADVICE></fcub:SUPPRESS_REDEMPTION_ADVICE>
               
               <fcub:REDEM_REF_NO></fcub:REDEM_REF_NO>
               
               <fcub:ACBRN>$L_TD_ACC_BRN</fcub:ACBRN>
               <fcub:TERM_ACNO>$L_TD_ACCOUNT</fcub:TERM_ACNO>
               
               <fcub:CUST_ID></fcub:CUST_ID>
               
               <fcub:ACCOUNT_CCY></fcub:ACCOUNT_CCY>
               
               <fcub:AC_DESC></fcub:AC_DESC>
               
               <fcub:CUST_ACC_BAL></fcub:CUST_ACC_BAL>
               
               <fcub:ACTION_FLAG>R</fcub:ACTION_FLAG>
               
               <fcub:DAYS></fcub:DAYS>
               
               <fcub:DEFAULT_MONTHS1></fcub:DEFAULT_MONTHS1>
               
               <fcub:YEARS_SS></fcub:YEARS_SS>
               
               <fcub:NEXT_MAT_DATE></fcub:NEXT_MAT_DATE>
               
               <fcub:REDEM_MODE>N</fcub:REDEM_MODE>
               
               <fcub:REDEMPTION_AMT></fcub:REDEMPTION_AMT>
               
               <fcub:WAIVE_PENALTY></fcub:WAIVE_PENALTY>
               
               <fcub:INPTBY></fcub:INPTBY>
               
               <fcub:CHECHKERID></fcub:CHECHKERID>
               
               <fcub:MAKDTTIME></fcub:MAKDTTIME>
               
               <fcub:CHECKERDT></fcub:CHECKERDT>
               
               <fcub:AUTHSTAT></fcub:AUTHSTAT>
               
               <fcub:TXNSTAT></fcub:TXNSTAT>
               
               <fcub:PRN_AMT></fcub:PRN_AMT>
               
               <fcub:MATURITY_AMT></fcub:MATURITY_AMT>
               
               <fcub:INTEREST_RATE></fcub:INTEREST_RATE>
               
               <fcub:ROLLTENOR></fcub:ROLLTENOR>
               
               <fcub:CONTVARROLL></fcub:CONTVARROLL>
               
               <fcub:INTRATE_CUMAMT_REQD></fcub:INTRATE_CUMAMT_REQD>
               
               <fcub:REDEMAMT></fcub:REDEMAMT>
               
               <fcub:NUM_CERTIFICATE_REDM></fcub:NUM_CERTIFICATE_REDM>
               
               <fcub:PRODUCT_CODE></fcub:PRODUCT_CODE>
               
               <fcub:ADDFNDS></fcub:ADDFNDS>
               
               <fcub:ADD_AMT></fcub:ADD_AMT>
               
               <fcub:REDM_INT_PAYOUT>R</fcub:REDM_INT_PAYOUT>
               <!--Zero or more repetitions:-->
               <fcub:Ictms-Tdredmpayout-Details>
                  
                  <fcub:PAYOUTTYPE>S</fcub:PAYOUTTYPE>
                  
                  <fcub:OFFSET_BRN>$L_PPAYOUT_AC_BRN</fcub:OFFSET_BRN>
                  
                  <fcub:OFFSET_ACC>$L_PPAYOUT_ACOUNT</fcub:OFFSET_ACC>
                  
                  <fcub:PERCENTAGE>100</fcub:PERCENTAGE>
                  
                  <fcub:REDMAMT></fcub:REDMAMT>
                  
                  <fcub:NARRATIVE></fcub:NARRATIVE>
                  
                  <fcub:WAIVEISSUCHG></fcub:WAIVEISSUCHG>
                  
                  <fcub:INSTNO></fcub:INSTNO>
                  
                  <fcub:REDM_PAYOUT_COMP>P</fcub:REDM_PAYOUT_COMP>
               </fcub:Ictms-Tdredmpayout-Details>
			    <fcub:Ictms-Tdredmpayout-Details>
                  
                  <fcub:PAYOUTTYPE>S</fcub:PAYOUTTYPE>
                  
                  <fcub:OFFSET_BRN>$L_IPAYOUT_AC_BRN</fcub:OFFSET_BRN>
                  
                  <fcub:OFFSET_ACC>$L_IPAYOUT_ACOUNT</fcub:OFFSET_ACC>
                  
                  <fcub:PERCENTAGE>100</fcub:PERCENTAGE>
                  
                  <fcub:REDMAMT></fcub:REDMAMT>
                  
                  <fcub:NARRATIVE></fcub:NARRATIVE>
                  
                  <fcub:WAIVEISSUCHG></fcub:WAIVEISSUCHG>
                  
                  <fcub:INSTNO></fcub:INSTNO>
                  
                  <fcub:REDM_PAYOUT_COMP>I</fcub:REDM_PAYOUT_COMP>
               </fcub:Ictms-Tdredmpayout-Details>
               <!--Zero or more repetitions:-->
               <fcub:Denom-Deposit>
                  
                  <fcub:CERTIFICATE_NO></fcub:CERTIFICATE_NO>
                  
                  <fcub:CERTIFICATE_AMOUNT></fcub:CERTIFICATE_AMOUNT>
                  
                  <fcub:REDEEM></fcub:REDEEM>
                  
                  <fcub:CERTIFICATE_STATUS></fcub:CERTIFICATE_STATUS>
               </fcub:Denom-Deposit>
               <!--Zero or more repetitions:-->
               <fcub:Redem-Payin-Dtls>
                  
                  <fcub:PAYIN_OPTION></fcub:PAYIN_OPTION>
                  
                  <fcub:AMT></fcub:AMT>
                  
                  <fcub:OFFSET_BRN></fcub:OFFSET_BRN>
                  
                  <fcub:OFFSET_ACC></fcub:OFFSET_ACC>
                  
                  <fcub:PECENT></fcub:PECENT>
                  
                  <fcub:CHQINSTNO></fcub:CHQINSTNO>
                  
                  <fcub:PRODUCT_F></fcub:PRODUCT_F>
                  
                  <fcub:CHQ_ADTE></fcub:CHQ_ADTE>
                  
                  <fcub:DRAWEE_ACCOUNT></fcub:DRAWEE_ACCOUNT>
                  
                  <fcub:ROUTING_NO></fcub:ROUTING_NO>
               </fcub:Redem-Payin-Dtls>
            </fcub:Ictms-Tdredmpayout-Master-Full>
         </fcub:FCUBS_BODY>
      </fcub:CREATETDREDEM_FSFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
      
        L_XML := REPLACE(L_XML, '$L_BRN_CODE', G.BRN);
        L_XML := REPLACE(L_XML, '$L_TD_ACCOUNT', G.ACC);
        L_XML := REPLACE(L_XML, '$L_TD_ACC_BRN', G.BRN);
      
        --Get payout Account for Principal only for the redemption
        BEGIN
        
          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = G.ACC
             AND A.BRN = G.BRN
             AND PAYOUT_COMPONENT = 'P'
             AND PAYOUTTYPE = 'S';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;
      
        DBG('OFFSET ACCOUNT FOR THE PRINCIPAL=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC);
        DBG('OFFSET BRANCH FOR THE PRINCIPAL=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN);
      
        L_XML := REPLACE(L_XML,
                         '$L_PPAYOUT_AC_BRN',
                         L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN);
        L_XML := REPLACE(L_XML,
                         '$L_PPAYOUT_ACOUNT',
                         L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC);
      
        --Get payout Account for Interest
        BEGIN
        
          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = G.ACC
             AND A.BRN = G.BRN
             AND PAYOUT_COMPONENT = 'I'
             AND PAYOUTTYPE = 'S';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;
      
        DBG('OFFSET ACCOUNT FOR THE INTEREST=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC);
        DBG('OFFSET BRANCH FOR THE INTEREST=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN);
      
        L_XML := REPLACE(L_XML,
                         '$L_IPAYOUT_AC_BRN',
                         L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN);
        L_XML := REPLACE(L_XML,
                         '$L_IPAYOUT_ACOUNT',
                         L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC);
      
        DBG('FINAL REQUEST XML='||L_XML);
        
        --log ws call
      
        PR_INSERT_WS_LOG(L_SEQ,
                         SYSTIMESTAMP,
                         G.ACC,
                         'CreateTDRedem',
                         L_XML,
                         'TD Auto Redeem Call');
      
        --call
        L_RESPONSE := process_http('http://10.80.80.200:8002/' ||
                                   'FCUBSTDService/FCUBSTDService',
                                   L_XML,
                                   'text/xml;charset=utf-8');
      
        DBG('L_RESPONSE=' || L_RESPONSE);
      
        PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
      
        DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
      
        P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
      
        --Check if returned error or success
        L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CREATETDREDEM_FSFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                        .GETSTRINGVAL;
      
        IF L_STATUS_MSG <> 'SUCCESS' THEN
        
          DBG('FAILED IN AUTO REDEEMING THE ACCOUNT');
        
          --L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/CREATETDTOPUP_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
          --      .GETSTRINGVAL;
        
          PR_UPDATE_TD_AUTO_REDEEM_MASTER(G.SEQ_NO,
                                          G.ACC,
                                          G.BRN,
                                          G.CCY,
                                          NULL,
                                          'N',
                                          'F');
        
          PR_UPDATE_WS_LOG(L_SEQ, L_RESPONSE, 'F');
        
          ROLLBACK TO A;
        
          CONTINUE;
        
          --RETURN FALSE;
        
        ELSE
        
          DBG('SUCCESS IN AUTO REDEEMING THE ACCOUNT');
        
          L_TDREDEEM_REF_NO := P_DOCUMENT_XML.EXTRACT('/CREATETDREDEM_FSFS_RES/FCUBS_BODY/Ictms-Tdredmpayout-Master-Full/REDEM_REF_NO/text()')
                               .GETSTRINGVAL;
        
          PR_UPDATE_TD_AUTO_REDEEM_MASTER(G.SEQ_NO,
                                          G.ACC,
                                          G.BRN,
                                          G.CCY,
                                          L_TDREDEEM_REF_NO,
                                          'Y',
                                          'S');
        
          PR_UPDATE_WS_LOG(L_SEQ, L_RESPONSE, 'S');
        
          COMMIT;
        
          --RETURN TRUE;
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO A;
          DBG('FAILED IN FN_PROCESS_AUTOTDREDEEM');
          DBG('ERROR LINE NUMBER FN_PROCESS_AUTOTDREDEEM=' ||
              DBMS_UTILITY.format_error_backtrace);
          DBG('ERROR CODE IN FN_PROCESS_AUTOTDREDEEM=' || SQLCODE);
          DBG('ERROR MESSAGE in FN_PROCESS_AUTOTDREDEEM=' || SQLERRM);
          CONTINUE;
          --RETURN FALSE;
      
      END;
    
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO A;
      DBG('FAILED IN PR_PROCESS_AUTOTDREDEEM');
      DBG('ERROR LINE NUMBER PR_PROCESS_AUTOTDREDEEM=' ||
          DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE IN PR_PROCESS_AUTOTDREDEEM=' || SQLCODE);
      DBG('ERROR MESSAGE in PR_PROCESS_AUTOTDREDEEM=' || SQLERRM);
    
    --RETURN FALSE;
  END PR_PROCESS_AUTOTDREDEEM;

END IFPKS_AUTOTDREDEEM_CLEVERSAVINGS_UTILS;
