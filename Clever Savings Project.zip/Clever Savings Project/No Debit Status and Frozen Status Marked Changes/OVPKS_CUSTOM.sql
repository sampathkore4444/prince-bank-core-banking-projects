CREATE OR REPLACE PACKAGE BODY ovpks_custom AS

  PROCEDURE DBG(X IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('OV', X);
  END DBG;

  FUNCTION FN_PRE_GETTYPE(PERRCODE IN ERTBS_MSGS.ERR_CODE%TYPE,
                          PTYPE    IN OUT CHAR) RETURN CHAR IS
    L_TYPE CHAR(1);
  
  BEGIN
    DBG('Inside Fn_pre_Gettype ...');
    L_TYPE := PTYPE;
  
    --sampath starts
    DBG('SOURCE CODE=' || CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));
    DBG('FUNCTION ID=' || CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'));
    DBG('PERRCODE=' || PERRCODE);
  
    IF CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') = 'EXTSYS' AND
       CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDREDMN' THEN
    
      DBG('INSIDE APPLE');
    
      PTYPE := 'O';
      
      L_TYPE := PTYPE;
    
    END IF;
    --sampath ends
  
    DBG('Returning Successfully from Fn_pre_Gettype..');
    RETURN L_TYPE;
  END FN_PRE_GETTYPE;

  FUNCTION FN_POST_GETTYPE(PERRCODE IN ERTBS_MSGS.ERR_CODE%TYPE,
                           PTYPE    IN OUT CHAR) RETURN CHAR IS
    L_TYPE CHAR(1);
  
  BEGIN
    DBG('Inside Fn_post_Gettype ...');
    L_TYPE := PTYPE;
    
    
    --sampath starts
    DBG('SOURCE CODE=' || CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));
    DBG('FUNCTION ID=' || CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'));
    DBG('PERRCODE=' || PERRCODE);
  
    IF CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') = 'EXTSYS' AND
       CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDREDMN' THEN
    
      DBG('INSIDE APPLE');
    
      PTYPE := 'O';
      
      L_TYPE := PTYPE;
    
    END IF;
    --sampath ends
    
    DBG('Returning Successfully from Fn_post_Gettype..');
    RETURN L_TYPE;
  END FN_POST_GETTYPE;

  FUNCTION FN_PRE_GETMSGANDTYPE(PERRORCODE IN ERTBS_MSGS.ERR_CODE%TYPE,
                                PLANGCODE  IN SMTBS_LANGUAGE.LANG_CODE%TYPE,
                                PERRORMSG  IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                                PERRORTYPE IN OUT CHAR,
                                PCONFIRM   IN OUT CHAR,
                                PFORMULA   IN OUT ERTBS_MSGS.DERIVED_MSG%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside Fn_pre_Getmsgandtype ...');
  
    DBG('Returning Successfully from Fn_pre_Getmsgandtype..');
    RETURN TRUE;
  END FN_PRE_GETMSGANDTYPE;

  FUNCTION FN_POST_GETMSGANDTYPE(PERRORCODE IN ERTBS_MSGS.ERR_CODE%TYPE,
                                 PLANGCODE  IN SMTBS_LANGUAGE.LANG_CODE%TYPE,
                                 PERRORMSG  IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                                 PERRORTYPE IN OUT CHAR,
                                 PCONFIRM   IN OUT CHAR,
                                 PFORMULA   IN OUT ERTBS_MSGS.DERIVED_MSG%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside Fn_post_Getmsgandtype ...');
  
    DBG('Returning Successfully from Fn_post_Getmsgandtype..');
    RETURN TRUE;
  END FN_POST_GETMSGANDTYPE;

  PROCEDURE PR_PRE_APPENDTBL(PERRCODE IN ERTBS_MSGS.ERR_CODE%TYPE,
                             PPARAMS  IN VARCHAR2,
                             PAMT     IN NUMBER) AS
  BEGIN
    DBG('Inside Pr_pre_Appendtbl ...');
  
    DBG('Returning Successfully from Pr_pre_Appendtbl..');
  END PR_PRE_APPENDTBL;

  PROCEDURE PR_POST_APPENDTBL(PERRCODE IN ERTBS_MSGS.ERR_CODE%TYPE,
                              PPARAMS  IN VARCHAR2,
                              PAMT     IN NUMBER) AS
  BEGIN
    DBG('Inside Pr_post_Appendtbl ...');
  
    DBG('Returning Successfully from Pr_post_Appendtbl..');
  END PR_POST_APPENDTBL;

  PROCEDURE PR_PRE_APPENDTBL(PERRCODE IN ERTBS_MSGS.ERR_CODE%TYPE,
                             PPARAMS  IN VARCHAR2) AS
  BEGIN
    DBG('Inside Pr_pre_Appendtbl ...');
  
    DBG('Returning Successfully from Pr_pre_Appendtbl..');
  END PR_PRE_APPENDTBL;

  PROCEDURE PR_POST_APPENDTBL(PERRCODE IN ERTBS_MSGS.ERR_CODE%TYPE,
                              PPARAMS  IN VARCHAR2) AS
  BEGIN
    DBG('Inside Pr_post_Appendtbl ...');
  
    DBG('Returning Successfully from Pr_post_Appendtbl..');
  END PR_POST_APPENDTBL;
END OVPKS_CUSTOM;
