CREATE OR REPLACE PACKAGE BODY cspks_upload_Custom AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'cspks_upload_Custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('IF', L_MSG);
  END DBG;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_PRE_WHAT_TO_DO(P_ACTION_ON_OVERRIDE  IN CHAR,
                             P_ACTION_ON_EXCEPTION IN CHAR,
                             P_STATUS_ON_SAVE      IN CHAR,
                             P_WHAT_TO_DO          IN OUT CHAR,
                             P_AUTH_STATUS         IN OUT CHAR,
                             P_ERROR_CODE          IN OUT VARCHAR2,
                             P_ERROR_PARAMETER     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Pre_What_To_Do');
  
    --sampath starts
  
    IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('SOURCE') AND
       CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('FUNCTIONID') THEN
    
      DBG('SOURCE CODE=' || CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));
      DBG('FUNCTION ID=' || CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'));
      DBG('P_ERROR_CODE=' || P_ERROR_CODE);
    
      IF CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') = 'EXTSYS' AND
         CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDREDMN' THEN
      
        DBG('INSIDE APPLE');
      
        P_WHAT_TO_DO := 'P';
      
        CSPKS_UPLOAD.Pr_Set_Skip_Kernel;
      
        -- P_ERROR_CODE := null;
      
      END IF;
    
    END IF;
  
    --sampath ends
  
    DBG('Returning success from Fn_Pre_What_To_Do');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of cspks_upload_Custom.Fn_Pre_What_To_Do ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERROR_CODE      := 'ST-OTHR-001';
      P_ERROR_PARAMETER := NULL;
      RETURN FALSE;
  END FN_PRE_WHAT_TO_DO;

  FUNCTION FN_POST_WHAT_TO_DO(P_ACTION_ON_OVERRIDE  IN CHAR,
                              P_ACTION_ON_EXCEPTION IN CHAR,
                              P_STATUS_ON_SAVE      IN CHAR,
                              P_WHAT_TO_DO          IN OUT CHAR,
                              P_AUTH_STATUS         IN OUT CHAR,
                              P_ERROR_CODE          IN OUT VARCHAR2,
                              P_ERROR_PARAMETER     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Post_What_To_Do');
  
    DBG('Returning success from Fn_Post_What_To_Do');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of cspks_upload_Custom.Fn_Post_What_To_Do ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
    
      RETURN FALSE;
  END FN_POST_WHAT_TO_DO;

END CSPKS_UPLOAD_CUSTOM;
