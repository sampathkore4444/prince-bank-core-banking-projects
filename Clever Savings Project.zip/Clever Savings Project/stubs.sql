declare
  L_LCY_AMOUNT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  L_EXCH_RATE  ACTB_DAILY_LOG.EXCH_RATE%TYPE;
  P_ERR_CODE VARCHAR2(100);
begin

  IF NOT Cypkss.Fn_Amt1_To_Amt2('001',
                                'KHR',
                                'USD',
                                'COMM',
                                'B',
                                '20000', --KHR amount nothing but FCY Amount
                                'Y',
                                L_LCY_AMOUNT, --USD amount nothing but LCY Amount
                                L_EXCH_RATE,
                                P_ERR_CODE) THEN
    DBMS_OUTPUT.PUT_LINE('Error while computing LCY ' || P_ERR_CODE);
    P_ERR_CODE := SQLCODE;
    --RETURN FALSE;
  
  ELSE
  
    DBMS_OUTPUT.PUT_LINE('DERIVED FCY AMOUNT FOR SELL RATE=' || L_LCY_AMOUNT);
  
  END IF;

exception
  when others then
null;
end;
