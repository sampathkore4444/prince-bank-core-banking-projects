SELECT 
  TRUNC(SYSDATE, 'MM') + LEVEL AS schedule_date,
  amount
FROM 
  (SELECT DATE '2023-07-01' AS start_date, 1000 AS amount FROM dual) -- Replace with your start date and amount
CONNECT BY 
  LEVEL <= 12 -- Number of months you want to generate

-- Additional Conditions (if needed) --
-- WHERE schedule_date <= DATE '2024-06-30' -- Specify end date if required
-- ORDER BY schedule_date ASC -- Optional: Sort the results if needed


--Without grace period
WITH recursive_schedule (schedule_date, amount) AS (
  SELECT 
    TRUNC(SYSDATE) AS schedule_date,
    100 AS amount -- Starting amount for the first schedule
  FROM dual
  UNION ALL
  SELECT 
    ADD_MONTHS(schedule_date, 1),
    amount -- Incrementing amount for each subsequent schedule
  FROM recursive_schedule
  WHERE schedule_date < ADD_MONTHS(TRUNC(SYSDATE), 11) -- Generating schedules up to 12 months
)
SELECT schedule_date, amount FROM recursive_schedule;

--withOUT grace period
WITH recursive_schedule(schedule_date,
amount) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_OPEN_DATE('000115364',
                                                              '035',
                                                              'USD')) AS schedule_date,
         0 AS amount -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_MIN_TOPUP_AMT
    FROM dual
  UNION ALL
  SELECT ADD_MONTHS(schedule_date, 1), IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_MIN_TOPUP_AMT('000115364',
                                                            '035',
                                                            'USD') -- Incrementing amount for each subsequent schedule
    FROM recursive_schedule
   WHERE schedule_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_OPEN_DATE('000115364',
                                                                         '035',
                                                                         'USD')),
                    IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TENOR_IN_MONTHS('000115364',
                                                                      '035',
                                                                      'USD')) -- Generating schedules up to 12 months
  )
SELECT schedule_date, amount FROM recursive_schedule;


--with grace period

WITH recursive_schedule(schedule_date,
amount, topup_date_with_grace) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_OPEN_DATE('000115364',
                                                              '035',
                                                              'USD')) AS schedule_date,
         0 AS amount, -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_MIN_TOPUP_AMT
         null as topup_date_with_grace
      FROM dual
  UNION ALL
  SELECT ADD_MONTHS(schedule_date, 1), IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_MIN_TOPUP_AMT('000115364',
                                                            '035',
                                                            'USD') -- Incrementing amount for each subsequent schedule
          , ADD_MONTHS(schedule_date, 1) + 3                                                
    FROM recursive_schedule
   WHERE schedule_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_OPEN_DATE('000115364',
                                                                         '035',
                                                                         'USD')),
                    IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TENOR_IN_MONTHS('000115364',
                                                                      '035',
                                                                      'USD')) -- Generating schedules up to 12 months
  )
SELECT schedule_date, amount, topup_date_with_grace FROM recursive_schedule;

--with grace proper query

WITH recursive_schedule(schedule_date,
amount, topup_date_with_grace) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_OPEN_DATE('000115364',
                                                              '035',
                                                              'USD')) AS schedule_date,
         0 AS amount, -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_MIN_TOPUP_AMT
         null as topup_date_with_grace
      FROM dual
  UNION ALL
  SELECT ADD_MONTHS(schedule_date, 1), IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_MIN_TOPUP_AMT('000115364',
                                                            '035',
                                                            'USD') -- Incrementing amount for each subsequent schedule
          , DECODE(ADD_MONTHS(schedule_date, 1),IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_MATURITY_DATE('000115364',
                                                            '035',
                                                            'USD')/*'20-FEB-25'*/,NULL,ADD_MONTHS(TO_CHAR(schedule_date,'DD-MON-YYYY'), 1) + 3)                                            
    FROM recursive_schedule
   WHERE schedule_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_OPEN_DATE('000115364',
                                                                         '035',
                                                                         'USD')),
                    IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TENOR_IN_MONTHS('000115364',
                                                                      '035',
                                                                      'USD')) -- Generating schedules up to 12 months
  )
SELECT schedule_date, amount, topup_date_with_grace FROM recursive_schedule;

--with grace proper query
WITH recursive_schedule(original_topup_date,
min_topup_amount, topup_date_with_grace) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_OPEN_DATE('000115364',
                                                              '035',
                                                              'USD')) AS original_topup_date,
         0 AS amount, -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_MIN_TOPUP_AMT
         null as topup_date_with_grace
      FROM dual
  UNION ALL
  SELECT ADD_MONTHS(original_topup_date, 1), IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_MIN_TOPUP_AMT('000115364',
                                                            '035',
                                                            'USD') -- Incrementing amount for each subsequent schedule
          , DECODE(ADD_MONTHS(original_topup_date, 1),IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_MATURITY_DATE('000115364',
                                                            '035',
                                                            'USD')/*'20-FEB-25'*/,NULL,ADD_MONTHS(TO_CHAR(original_topup_date,'DD-MON-YYYY'), 1) + 3)                                            
    FROM recursive_schedule
   WHERE original_topup_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TD_OPEN_DATE('000115364',
                                                                         '035',
                                                                         'USD')),
                    IFPKS_CLEVER_SAVINGS_UTILS.FN_GET_TENOR_IN_MONTHS('000115364',
                                                                      '035',
                                                                      'USD')) -- Generating schedules up to 12 months
  )
SELECT original_topup_date, min_topup_amount, topup_date_with_grace FROM recursive_schedule;