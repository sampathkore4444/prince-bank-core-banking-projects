CREATE OR REPLACE PACKAGE BODY IFPKS_CLEVER_SAVINGS_UTILS_REP AS

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'IFPKS_CLEVER_SAVINGS_UTILS_REP ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  FUNCTION FN_GET_BRANCH_DATE(P_BRN IN VARCHAR2) RETURN STTM_DATES.TODAY%TYPE AS
    L_TODAY STTM_DATES.TODAY%TYPE;
  BEGIN
  
    SELECT A.TODAY
      INTO L_TODAY
      FROM STTM_DATES A
     WHERE A.BRANCH_CODE = P_BRN;
  
    RETURN L_TODAY;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_TODAY;
  END FN_GET_BRANCH_DATE;

  FUNCTION FN_GET_REMINDER_MSG(P_LANG       IN VARCHAR2,
                               P_WHEN_ALERT IN VARCHAR2)
  
   RETURN STTB_NOTIF_LANG_TEMPLATE_CLEVER_SAV.MESSAGE%TYPE AS
  
    L_REMINDER_MSG STTB_NOTIF_LANG_TEMPLATE_CLEVER_SAV.MESSAGE%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT MESSAGE
        INTO L_REMINDER_MSG
        FROM STTB_NOTIF_LANG_TEMPLATE_CLEVER_SAV A
       WHERE A.LANGUAGE = P_LANG
         AND A.TRIGGER_ALERT = P_WHEN_ALERT;
    EXCEPTION
      WHEN OTHERS THEN
        L_REMINDER_MSG := NULL;
    END;
  
    RETURN L_REMINDER_MSG;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      RETURN L_REMINDER_MSG;
    
  END FN_GET_REMINDER_MSG;

  FUNCTION FN_GET_ACCOUNT_DTLS(P_ACC IN VARCHAR2,
                               P_BRN IN VARCHAR2,
                               P_CCY IN VARCHAR2)
    RETURN STTM_CUST_ACCOUNT%ROWTYPE AS
    L_STTM_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
  
  BEGIN
  
    BEGIN
    
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_aCC
         AND A.BRANCH_CODE = P_BRN
         AND A.CCY = P_CCY
         AND A.RECORD_STAT = 'O'
         AND A.ONCE_AUTH = 'Y';
    
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    RETURN L_STTM_CUST_ACCOUNT;
  
  EXCEPTION
    WHEN OTHERS THEN
      L_STTM_CUST_ACCOUNT := NULL;
    
      RETURN L_STTM_CUST_ACCOUNT;
    
  END FN_GET_ACCOUNT_DTLS;

  FUNCTION FN_GET_TD_MIN_TOPUP_AMT(P_ACC      IN VARCHAR2,
                                   P_BRN      IN VARCHAR2,
                                   P_CCY      IN VARCHAR2,
                                   P_DUE_DATE IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE AS
  
    L_MIN_TOP_UP_AMT    ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN              VARCHAR2(25);
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN
    
      --Get the plan. 3 plans
    
      IF TO_DATE(P_DUE_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
      
        L_PLAN := 'SILVER_PLAN_A';
      
      ELSIF TO_DATE(P_DUE_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE > 366
           
            AND
            TO_DATE(P_DUE_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 731 THEN
      
        L_PLAN := 'SILVER_PLAN_B';
      
      ELSE
      
        L_PLAN := 'SILVER_PLAN_C';
      
      END IF;
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN
    
      --Get the plan. 2 plans
    
      IF TO_DATE(P_DUE_DATE) - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
      
        L_PLAN := 'GOLD_PLAN_A';
      
      ELSE
      
        L_PLAN := 'GOLD_PLAN_B';
      
      END IF;
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN
    
      --Get the plan. 1 plan
    
      L_PLAN := 'RUBY_PLAN_A';
    
    END IF;
  
    BEGIN
      SELECT B.CODE
        INTO L_MIN_TOP_UP_AMT
        FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
       WHERE A.TYPE = B.TYPE
         AND A.TYPE = 'CLEVERSAV_MINTOP'
         AND B.VALUE = L_PLAN;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
      
    END;
  
    DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
        L_MIN_TOP_UP_AMT);
  
    IF P_CCY = 'USD' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT;
    
    ELSIF P_CCY = 'KHR' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT * 4000;
    
    END IF;
  
    RETURN L_MIN_TOP_UP_AMT;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_MIN_TOP_UP_AMT;
  END FN_GET_TD_MIN_TOPUP_AMT;

  PROCEDURE PR_GET_TD_TOPUP_SCHEDULES(P_ACC             IN VARCHAR2,
                                      P_BRN             IN VARCHAR2,
                                      P_CCY             IN VARCHAR2,
                                      P_TOPUP_SCHEDULES OUT SYS_REFCURSOR) IS
  
    L_DYNAMIC_SQL_STMT VARCHAR2(32767);
  
    l_original_topup_date   VARCHAR2(100);
    l_min_topup_amount      VARCHAR2(100);
    l_topup_date_with_grace VARCHAR2(100);
    L_INITIAL_DEPOSIT       NUMBER;
    L_TD_PRINCIPAL_BAL      NUMBER;
    L_TENOR                 NUMBER;
    L_COUNT                 NUMBER := 1;
    L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    IF P_ACC IS NOT NULL AND P_BRN IS NOT NULL AND P_CCY IS NOT NULL THEN
    
      --Get Account Details
      L_CUST_ACCOUNT := FN_GET_ACCOUNT_DTLS(P_ACC, P_BRN, P_CCY);
    
      L_DYNAMIC_SQL_STMT := '
WITH recursive_schedule(original_topup_date,
min_topup_amount, topup_date_with_grace) AS
 (SELECT TRUNC(IFPKS_CLEVER_SAVINGS_UTILS_REP.FN_GET_TD_OPEN_DATE(''' ||
                            P_ACC || ''',
                                                              ''' ||
                            P_BRN || ''',
                                                              ''' ||
                            P_CCY ||
                            ''')) AS original_topup_date,
         0 AS amount, -- Starting amount for the first schedule. here instead of zero, you can replace with below IFPKS_CLEVER_SAVINGS_UTILS_REP.FN_GET_TD_MIN_TOPUP_AMT
         null as topup_date_with_grace
      FROM dual
  UNION ALL
  SELECT ADD_MONTHS(original_topup_date, 1), IFPKS_CLEVER_SAVINGS_UTILS_REP.FN_GET_TD_MIN_TOPUP_AMT(''' ||
                            P_ACC || ''',
                                                              ''' ||
                            P_BRN || ''',
                                                              ''' ||
                            P_CCY ||
                            ''') -- Incrementing amount for each subsequent schedule
          , DECODE(ADD_MONTHS(original_topup_date, 1),IFPKS_CLEVER_SAVINGS_UTILS_REP.FN_GET_MATURITY_DATE(''' ||
                            P_ACC || ''',
                                                              ''' ||
                            P_BRN || ''',
                                                              ''' ||
                            P_CCY ||
                            '''),NULL,ADD_MONTHS(TO_CHAR(original_topup_date,''DD - MON - YYYY''), 1) + 3)
    FROM recursive_schedule
   WHERE original_topup_date <
         ADD_MONTHS(TRUNC(IFPKS_CLEVER_SAVINGS_UTILS_REP.FN_GET_TD_OPEN_DATE(''' ||
                            P_ACC || ''',
                                                              ''' ||
                            P_BRN || ''',
                                                              ''' ||
                            P_CCY ||
                            ''')),
                    IFPKS_CLEVER_SAVINGS_UTILS_REP.FN_GET_TENOR_IN_MONTHS(''' ||
                            P_ACC || ''',
                                                              ''' ||
                            P_BRN || ''',
                                                              ''' ||
                            P_CCY ||
                            ''')) -- Generating schedules up to 12 months
  )
SELECT original_topup_date, min_topup_amount, topup_date_with_grace FROM recursive_schedule';
    
      DBMS_OUTPUT.put_line('L_DYNAMIC_SQL_STMT=' || L_DYNAMIC_SQL_STMT);
    
      DELETE FROM IFTB_TD_TOPUP_SCHEDULES
       WHERE ACC = P_ACC
         AND BRN = P_BRN
         AND CCY = P_CCY;
    
      --COMMIT;
    
      --get initial deposit
      L_INITIAL_DEPOSIT := FN_GET_TD_INIT_BAL(P_ACC, P_BRN, P_CCY);
      L_TENOR           := FN_GET_TENOR_IN_MONTHS(P_ACC, P_BRN, P_CCY);
    
      OPEN P_TOPUP_SCHEDULES FOR L_DYNAMIC_SQL_STMT;
    
      --populate into the table
      LOOP
        FETCH P_TOPUP_SCHEDULES
          INTO L_ORIGINAL_TOPUP_DATE,
               L_MIN_TOPUP_AMOUNT,
               L_TOPUP_DATE_WITH_GRACE;
      
        EXIT WHEN P_TOPUP_SCHEDULES%NOTFOUND;
      
        DBMS_OUTPUT.PUT_LINE(L_ORIGINAL_TOPUP_DATE || ',' ||
                             L_MIN_TOPUP_AMOUNT || ',' ||
                             L_TOPUP_DATE_WITH_GRACE);
      
        L_MIN_TOPUP_AMOUNT := FN_GET_TD_MIN_TOPUP_AMT(P_ACC,
                                                      P_BRN,
                                                      P_CCY,
                                                      L_ORIGINAL_TOPUP_DATE);
      
        IF L_COUNT = L_TENOR + 1 THEN
        
          L_MIN_TOPUP_AMOUNT := 0;
        
        END IF;
      
        L_TD_PRINCIPAL_BAL := L_INITIAL_DEPOSIT + L_MIN_TOPUP_AMOUNT;
      
        INSERT INTO IFTB_TD_TOPUP_SCHEDULES
        VALUES
          (P_ACC,
           P_BRN,
           P_CCY,
           L_ORIGINAL_TOPUP_DATE,
           L_TOPUP_DATE_WITH_GRACE,
           L_MIN_TOPUP_AMOUNT,
           L_TD_PRINCIPAL_BAL);
      
        L_INITIAL_DEPOSIT := L_TD_PRINCIPAL_BAL;
      
        L_COUNT := L_COUNT + 1;
      
      END LOOP;
    
      COMMIT;
    
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
    
      P_TOPUP_SCHEDULES := NULL;
      DBMS_OUTPUT.put_line('ERROR CODE=' || SQLCODE);
      DBMS_OUTPUT.put_line('ERROR MESSAGE=' || SQLERRM);
  END PR_GET_TD_TOPUP_SCHEDULES;

  FUNCTION FN_GET_TD_INIT_BAL(P_ACC IN VARCHAR2,
                              P_BRN IN VARCHAR2,
                              P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.ictm_td.TD_AMOUNT%TYPE AS
  
    L_ICTM_TD  P1FCHPRFM.ictm_td%ROWTYPE;
    L_INIT_BAL P1FCHPRFM.ictm_td.TD_AMOUNT%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT *
        INTO L_ICTM_TD
        FROM P1FCHPRFM.ictm_td A
       WHERE A.ACC = P_ACC
         AND A.BRN = P_BRN
         AND A.CCY = P_CCY;
    EXCEPTION
      WHEN OTHERS THEN
        L_ICTM_TD := NULL;
    END;
  
    L_INIT_BAL := L_ICTM_TD.TD_AMOUNT;
  
    RETURN L_INIT_BAL;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_INIT_BAL;
  END FN_GET_TD_INIT_BAL;

  FUNCTION FN_GET_TD_OPEN_DATE(P_ACC IN VARCHAR2,
                               P_BRN IN VARCHAR2,
                               P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE AS
  
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    L_AC_OPEN_DATE      P1FCHPRFM.STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    L_AC_OPEN_DATE := L_STTM_CUST_ACCOUNT.AC_OPEN_DATE;
  
    RETURN L_AC_OPEN_DATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_AC_OPEN_DATE;
  END FN_GET_TD_OPEN_DATE;

  FUNCTION FN_GET_TENOR_IN_MONTHS(P_ACC IN VARCHAR2,
                                  P_BRN IN VARCHAR2,
                                  P_CCY IN VARCHAR2) RETURN NUMBER AS
  
    L_STTM_CUST_ACCOUNT    P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    rec_ictm_acc           P1FCHPRFM.ictm_acc%ROWTYPE;
    l_tenor_in_months      NUMBER := 0;
    L_ICTM_TD_DETAILS      P1FCHPRFM.ICTM_TD_DETAILS%ROWTYPE;
    L_CYTM_CCY_DEFN_MASTER P1FCHPRFM.CYTM_CCY_DEFN_MASTER%ROWTYPE;
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    --get td information
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc A
       WHERE A.acc = P_ACC
         AND A.brn = L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    
      /* SELECT ABS(rec_ictm_acc.int_start_date - rec_ictm_acc.maturity_date)
      INTO l_tenor_in_months
      FROM DUAL;*/
    
      l_tenor_in_months := ABS(MONTHS_BETWEEN(rec_ictm_acc.int_start_date,
                                              rec_ictm_acc.maturity_date));
    
    EXCEPTION
      WHEN OTHERS THEN
        l_tenor_in_months := 0;
    END;
  
    RETURN l_tenor_in_months;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_tenor_in_months;
    
  END FN_GET_TENOR_IN_MONTHS;

  FUNCTION FN_GET_TD_MIN_TOPUP_AMT(P_ACC IN VARCHAR2,
                                   P_BRN IN VARCHAR2,
                                   P_CCY IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE AS
  
    L_MIN_TOP_UP_AMT    ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN              VARCHAR2(25);
    L_TODAY_DATE        STTM_DATES.TODAY%TYPE;
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    L_TODAY_DATE := FN_GET_BRANCH_DATE(P_BRN);
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN
    
      --Get the plan. 3 plans
    
      IF L_TODAY_DATE - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
      
        L_PLAN := 'SILVER_PLAN_A';
      
      ELSIF L_TODAY_DATE - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE > 366
           
            AND
            GLOBAL.application_date - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 731 THEN
      
        L_PLAN := 'SILVER_PLAN_B';
      
      ELSE
      
        L_PLAN := 'SILVER_PLAN_C';
      
      END IF;
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN
    
      --Get the plan. 2 plans
    
      IF L_TODAY_DATE - L_STTM_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
      
        L_PLAN := 'GOLD_PLAN_A';
      
      ELSE
      
        L_PLAN := 'GOLD_PLAN_B';
      
      END IF;
    
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN
    
      --Get the plan. 1 plan
    
      L_PLAN := 'RUBY_PLAN_A';
    
    END IF;
  
    BEGIN
      SELECT B.CODE
        INTO L_MIN_TOP_UP_AMT
        FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
       WHERE A.TYPE = B.TYPE
         AND A.TYPE = 'CLEVERSAV_MINTOP'
         AND B.VALUE = L_PLAN;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
      
    END;
  
    DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
        L_MIN_TOP_UP_AMT);
  
    IF P_CCY = 'USD' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT;
    
    ELSIF P_CCY = 'KHR' THEN
    
      L_MIN_TOP_UP_AMT := L_MIN_TOP_UP_AMT * 4000;
    
    END IF;
  
    RETURN L_MIN_TOP_UP_AMT;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_MIN_TOP_UP_AMT;
  END FN_GET_TD_MIN_TOPUP_AMT;

  FUNCTION FN_GET_MATURITY_DATE(P_ACC IN VARCHAR2,
                                P_BRN IN VARCHAR2,
                                P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.ictm_acc.MATURITY_DATE%TYPE AS
  
    L_STTM_CUST_ACCOUNT P1FCHPRFM.STTM_CUST_ACCOUNT%ROWTYPE;
    rec_ictm_acc        P1FCHPRFM.ictm_acc%ROWTYPE;
    L_MATURITY_DATE     P1FCHPRFM.ictm_acc.MATURITY_DATE%TYPE;
  
  BEGIN
  
    --get branch
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM P1FCHPRFM.STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    --get td information
    BEGIN
      SELECT *
        INTO rec_ictm_acc
        FROM P1FCHPRFM.ictm_acc A
       WHERE A.acc = P_ACC
         AND A.brn = L_STTM_CUST_ACCOUNT.BRANCH_CODE;
    
      L_MATURITY_DATE := rec_ictm_acc.maturity_date;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_MATURITY_DATE := NULL;
    END;
  
    RETURN L_MATURITY_DATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_MATURITY_DATE;
    
  END FN_GET_MATURITY_DATE;

END IFPKS_CLEVER_SAVINGS_UTILS_REP;
