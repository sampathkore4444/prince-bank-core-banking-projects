CREATE OR REPLACE PACKAGE IFPKS_CLEVER_SAVINGS_UTILS_REP AS

  PROCEDURE PR_GET_TD_TOPUP_SCHEDULES(P_ACC             IN VARCHAR2,
                                      P_BRN             IN VARCHAR2,
                                      P_CCY             IN VARCHAR2,
                                      P_TOPUP_SCHEDULES OUT SYS_REFCURSOR);

  FUNCTION FN_GET_TD_OPEN_DATE(P_ACC IN VARCHAR2,
                               P_BRN IN VARCHAR2,
                               P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;

  FUNCTION FN_GET_TENOR_IN_MONTHS(P_ACC IN VARCHAR2,
                                  P_BRN IN VARCHAR2,
                                  P_CCY IN VARCHAR2) RETURN NUMBER;

  FUNCTION FN_GET_TD_INIT_BAL(P_ACC IN VARCHAR2,
                              P_BRN IN VARCHAR2,
                              P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.ictm_td.TD_AMOUNT%TYPE;

  FUNCTION FN_GET_TD_MIN_TOPUP_AMT(P_ACC IN VARCHAR2,
                                   P_BRN IN VARCHAR2,
                                   P_CCY IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;

  FUNCTION FN_GET_MATURITY_DATE(P_ACC IN VARCHAR2,
                                P_BRN IN VARCHAR2,
                                P_CCY IN VARCHAR2)
    RETURN P1FCHPRFM.ictm_acc.MATURITY_DATE%TYPE;

END IFPKS_CLEVER_SAVINGS_UTILS_REP;
