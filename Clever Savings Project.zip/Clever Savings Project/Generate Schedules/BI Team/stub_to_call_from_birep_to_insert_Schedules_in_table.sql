declare
  P_TOPUP_SCHEDULES     sys_refcursor;
  original_topup_date   VARCHAR2(100);
  min_topup_amount      VARCHAR2(100);
  topup_date_with_grace VARCHAR2(100);

begin

  P1FCHPRFM.IFPKS_CLEVER_SAVINGS_UTILS_REP.PR_GET_TD_TOPUP_SCHEDULES('000115364',
                                                       '035',
                                                       'USD',
                                                       P_TOPUP_SCHEDULES);

  --DBMS_OUTPUT.PUT_LINE('P_TOPUP_SCHEDULES='||P_TOPUP_SCHEDULES.COUNT); 

  loop
    fetch P_TOPUP_SCHEDULES
      into original_topup_date, min_topup_amount, topup_date_with_grace;
  
    exit when P_TOPUP_SCHEDULES%notfound;
  
   -- DBMS_OUTPUT.put_LINE(original_topup_date || ',' || min_topup_amount || ',' ||
       --                  topup_date_with_grace);
  end loop;

EXCEPTION
  WHEN OTHERS THEN
    P_TOPUP_SCHEDULES := NULL;
    DBMS_OUTPUT.PUT_LINE('ERROR CODE=' || SQLCODE);
    DBMS_OUTPUT.PUT_LINE('ERROR MESSAGE=' || sQLERRM);
    DBMS_OUTPUT.PUT_LINE('ERROR LINE NUMBER=' ||
                         DBMS_UTILITY.format_error_backtrace);
END;