SELECT 
  TRUNC(SYSDATE, 'MM') + LEVEL AS schedule_date,
  amount
FROM 
  (SELECT DATE '2023-07-01' AS start_date, 1000 AS amount FROM dual) -- Replace with your start date and amount
CONNECT BY 
  LEVEL <= 12 -- Number of months you want to generate

-- Additional Conditions (if needed) --
-- WHERE schedule_date <= DATE '2024-06-30' -- Specify end date if required
-- ORDER BY schedule_date ASC -- Optional: Sort the results if needed