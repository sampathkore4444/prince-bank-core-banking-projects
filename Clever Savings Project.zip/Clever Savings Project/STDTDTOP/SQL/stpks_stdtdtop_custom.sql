CREATE OR REPLACE PACKAGE BODY stpks_stdtdtop_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdtdtop_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdtdtop_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdtdtop         IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdtdtop_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdtdtop         IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
    --sampath starts
    L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
    L_LIQUIDAITON_COUNT     NUMBER := 0;
    L_ICTM_TDPAYOUT_DETAILS ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    --sampath ends
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    --sampath starts
    IF P_ACTION_CODE = 'NEW' THEN
      --Get Account Class
      BEGIN
      
        SELECT *
          INTO L_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
           AND A.BRANCH_CODE = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
           AND A.RECORD_STAT = 'O'
           AND A.ONCE_AUTH = 'Y';
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_ACCOUNT := NULL;
      END;
    
      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN
         ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN
      
        --Get TD Payout CASA ACCOUNT Details
        BEGIN
        
          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
             AND PAYOUT_COMPONENT = 'P'
             AND PAYOUTTYPE = 'S';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;
      
        BEGIN
          SELECT COUNT(1)
            INTO L_LIQUIDAITON_COUNT
            FROM CAVW_ENTRIES A
           WHERE (A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                 A.RELATED_ACCOUNT = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC)
             AND PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
             AND EVENT = 'ILIQ'
             AND AMOUNT_TAG = 'ILIQ';
          -- AND TRN_CODE = 'PTP'; --TOP UP EXTRA RATE LIQUIDATION
        
        EXCEPTION
        
          WHEN OTHERS THEN
          
            L_LIQUIDAITON_COUNT := 0;
          
        END;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN
        
          IF L_CUST_ACCOUNT.CCY = 'USD' THEN
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT > 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 200 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '200-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 2
          
            IF L_LIQUIDAITON_COUNT > 22 AND L_LIQUIDAITON_COUNT < 25 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 200 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '200-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 3
          
            IF L_LIQUIDAITON_COUNT > 34 AND L_LIQUIDAITON_COUNT < 37 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 200 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '200-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
          IF L_CUST_ACCOUNT.CCY = 'KHR' THEN
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT > 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 800000 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '800000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 2
          
            IF L_LIQUIDAITON_COUNT > 22 AND L_LIQUIDAITON_COUNT < 25 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 800000 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '800000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 3
          
            IF L_LIQUIDAITON_COUNT > 34 AND L_LIQUIDAITON_COUNT < 37 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 800000 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '800000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
        END IF;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN
        
          IF L_CUST_ACCOUNT.CCY = 'USD' THEN
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT > 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 300 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '300-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 2
          
            IF L_LIQUIDAITON_COUNT > 22 AND L_LIQUIDAITON_COUNT < 25 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 300 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '300-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
          IF L_CUST_ACCOUNT.CCY = 'KHR' THEN
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT > 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 1200000 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1200000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 2
          
            IF L_LIQUIDAITON_COUNT > 22 AND L_LIQUIDAITON_COUNT < 25 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 1200000 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1200000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
        END IF;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN
        
          IF L_CUST_ACCOUNT.CCY = 'USD' THEN
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT > 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 350 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '350-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
          IF L_CUST_ACCOUNT.CCY = 'KHR' THEN
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT > 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 1400000 THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1400000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
        END IF;
      
      END IF;
    
    END IF;
    --sampath ends 
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdtdtop         IN stpks_stdtdtop_Main.ty_stdtdtop,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdtdtop         IN stpks_stdtdtop_Main.ty_stdtdtop,
                                       p_Prev_stdtdtop    IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                                       p_Wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdtdtop         IN stpks_stdtdtop_Main.Ty_stdtdtop,
                                        p_Prev_stdtdtop    IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                                        p_Wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdtdtop         IN stpks_stdtdtop_Main.Ty_stdtdtop,
                            p_Prev_stdtdtop    IN stpks_stdtdtop_Main.Ty_stdtdtop,
                            p_Wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdtdtop         IN stpks_stdtdtop_Main.Ty_stdtdtop,
                             p_prev_stdtdtop    IN stpks_stdtdtop_Main.Ty_stdtdtop,
                             p_wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdtdtop         IN stpks_stdtdtop_Main.Ty_stdtdtop,
                        p_Wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdtdtop         IN stpks_stdtdtop_Main.ty_stdtdtop,
                         p_wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdtdtop_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdtdtop_custom;
