insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('AC-CLS-000', 'ENG', 'Top Up Amount can not be greater than Minimum Topup Amount Allowed for the plan $1', 'E', 'N', 'STDCUSAC', 1, 'N', 'E', null, 'N', null, null, null, null);

COMMIT;
