CREATE OR REPLACE PACKAGE BODY stpks_stdcustd_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcustd_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdcustd_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  --Referral Sampath Starts
  FUNCTION FN_GET_SALE_CHANNEL(P_ACC_NO IN STTM_CUST_ACCOUNT.CUST_NO%TYPE)
    RETURN STTM_CUST_TD_REFERRAL_CUSTOM.SALE_CHANNEL%TYPE AS

    L_SALE_CHANNEL STTM_CUST_TD_REFERRAL_CUSTOM.SALE_CHANNEL%TYPE;

  BEGIN

    BEGIN

      SELECT A.SALE_CHANNEL
        INTO L_SALE_CHANNEL
        FROM STTM_CUST_TD_REFERRAL_CUSTOM A
       WHERE A.ACC = P_ACC_NO;

    EXCEPTION
      WHEN OTHERS THEN

        L_SALE_CHANNEL := NULL;

    END;

    DBG('L_SALE_CHANNEL=' || L_SALE_CHANNEL);

    IF L_SALE_CHANNEL IS NULL THEN

      BEGIN

        SELECT A.SALE_CHANNEL
          INTO L_SALE_CHANNEL
          FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
         WHERE A.ACC = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN

          L_SALE_CHANNEL := NULL;

      END;

    END IF;

    DBG('L_SALE_CHANNEL=' || L_SALE_CHANNEL);

    RETURN L_SALE_CHANNEL;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING THE SALE CHANNEL DETAILS');

      L_SALE_CHANNEL := NULL;
      RETURN L_SALE_CHANNEL;

  END FN_GET_SALE_CHANNEL;

  FUNCTION FN_GET_CUST_NAME(P_PERSON_TYPE IN VARCHAR2,
                            P_ACC_NO      IN STTM_CUST_ACCOUNT.CUST_NO%TYPE)
    RETURN STTM_CUSTOMER.CUSTOMER_NAME1%TYPE AS

    L_CUST_NAME STTM_CUSTOMER.CUSTOMER_NAME1%TYPE;

    L_REFERRAL_PERSON      STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;
    L_RELATIONSHIP_OFFICER STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;

  BEGIN

    IF P_PERSON_TYPE = 'RP' THEN
      BEGIN

        SELECT REFERRAL_PERSON
          INTO L_REFERRAL_PERSON
          FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
         WHERE A.ACC = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_REFERRAL_PERSON := NULL;

      END;

      DBG('L_REFERRAL_PERSON=' || L_REFERRAL_PERSON);

      IF L_REFERRAL_PERSON IS NULL THEN

        BEGIN

          SELECT A.REFERRAL_PERSON
            INTO L_REFERRAL_PERSON
            FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
           WHERE A.ACC = P_ACC_NO;

        EXCEPTION
          WHEN OTHERS THEN

            L_REFERRAL_PERSON := NULL;

        END;

      END IF;

      DBG('L_REFERRAL_PERSON=' || L_REFERRAL_PERSON);

      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_CUST_NAME
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO = L_REFERRAL_PERSON;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NAME := NULL;
      END;

    END IF;

    IF P_PERSON_TYPE = 'RO' THEN

      BEGIN

        SELECT A.RELATIONSHIP_OFFICER
          INTO L_RELATIONSHIP_OFFICER
          FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
         WHERE A.acc = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_RELATIONSHIP_OFFICER := NULL;

      END;

      DBG('L_RELATIONSHIP_OFFICER=' || L_RELATIONSHIP_OFFICER);

      IF L_RELATIONSHIP_OFFICER IS NULL THEN

        BEGIN

          SELECT A.RELATIONSHIP_OFFICER
            INTO L_RELATIONSHIP_OFFICER
            FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
           WHERE A.ACC = P_ACC_NO;

        EXCEPTION
          WHEN OTHERS THEN

            L_RELATIONSHIP_OFFICER := NULL;

        END;

      END IF;

      DBG('L_RELATIONSHIP_OFFICER=' || L_RELATIONSHIP_OFFICER);

      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_CUST_NAME
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO = L_RELATIONSHIP_OFFICER;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NAME := NULL;
      END;

    END IF;

    DBG('L_CUST_NAME=' || L_CUST_NAME);

    RETURN L_CUST_NAME;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING THE CUSTOMER NAME');

      L_CUST_NAME := NULL;
      RETURN L_CUST_NAME;

  END FN_GET_CUST_NAME;

  FUNCTION FN_GET_CUST_NO(P_PERSON_TYPE IN VARCHAR2,
                          P_ACC_NO      IN STTM_CUST_ACCOUNT.CUST_NO%TYPE)
    RETURN STTM_CUSTOMER.CUSTOMER_NAME1%TYPE AS

    L_CUST_NAME STTM_CUSTOMER.CUSTOMER_NAME1%TYPE;

    L_REFERRAL_PERSON      STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;
    L_RELATIONSHIP_OFFICER STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;

  BEGIN

    IF P_PERSON_TYPE = 'RP' THEN
      BEGIN

        SELECT REFERRAL_PERSON
          INTO L_REFERRAL_PERSON
          FROM STTM_CUST_TD_REFERRAL_CUSTOM A
         WHERE A.ACC = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_REFERRAL_PERSON := NULL;

      END;

      DBG('L_REFERRAL_PERSON=' || L_REFERRAL_PERSON);

      IF L_REFERRAL_PERSON IS NULL THEN

        BEGIN

          SELECT A.REFERRAL_PERSON
            INTO L_REFERRAL_PERSON
            FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
           WHERE A.ACC = P_ACC_NO;

        EXCEPTION
          WHEN OTHERS THEN

            L_REFERRAL_PERSON := NULL;

        END;

      END IF;

      DBG('L_REFERRAL_PERSON=' || L_REFERRAL_PERSON);

      RETURN L_REFERRAL_PERSON;



    END IF;

    IF P_PERSON_TYPE = 'RO' THEN

      BEGIN

        SELECT A.RELATIONSHIP_OFFICER
          INTO L_RELATIONSHIP_OFFICER
          FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
         WHERE A.acc = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_RELATIONSHIP_OFFICER := NULL;

      END;

      DBG('L_RELATIONSHIP_OFFICER=' || L_RELATIONSHIP_OFFICER);

      IF L_RELATIONSHIP_OFFICER IS NULL THEN

        BEGIN

          SELECT A.RELATIONSHIP_OFFICER
            INTO L_RELATIONSHIP_OFFICER
            FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
           WHERE A.ACC = P_ACC_NO;

        EXCEPTION
          WHEN OTHERS THEN

            L_RELATIONSHIP_OFFICER := NULL;

        END;

      END IF;

      DBG('L_RELATIONSHIP_OFFICER=' || L_RELATIONSHIP_OFFICER);

      RETURN L_RELATIONSHIP_OFFICER;



    END IF;



  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING THE CUSTOMER NAME');

       IF P_PERSON_TYPE = 'RP' THEN
      RETURN L_REFERRAL_PERSON;
    END IF;

      IF P_PERSON_TYPE = 'RO' THEN
      RETURN L_RELATIONSHIP_OFFICER;
    END IF;

  END FN_GET_CUST_NO;


  PROCEDURE PR_INSERT_REFERRAL_DTLS(P_STDCUSTD IN OUT stpks_stdcustd_Main.ty_stdcustd) AS

    PRAGMA AUTONOMOUS_TRANSACTION;

    L_COUNT_REFFERAL_PERSON      NUMBER := 0;
    L_COUNT_RELATIONSHIP_OFFICER NUMBER := 0;

    L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM%ROWTYPE;

  BEGIN

   DBG('P_STDCUSTD.v_cust_td_referral_custom.REFERRAL_PERSON='||P_STDCUSTD.v_cust_td_referral_custom.REFERRAL_PERSON);

    --Check if referral_person and relationship_officer are CIF no's
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT_REFFERAL_PERSON
        FROM STTM_CUSTOMER A
       WHERE A.CUSTOMER_NO =
             P_STDCUSTD.v_cust_td_referral_custom.REFERRAL_PERSON;
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT_REFFERAL_PERSON := 0;
    END;

    DBG('L_COUNT_REFFERAL_PERSON='||L_COUNT_REFFERAL_PERSON);

    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT_RELATIONSHIP_OFFICER
        FROM STTM_CUSTOMER A
       WHERE A.CUSTOMER_NO =
             P_STDCUSTD.v_cust_td_referral_custom.relationship_officer;
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT_RELATIONSHIP_OFFICER := 0;
    END;

    DBG('L_COUNT_RELATIONSHIP_OFFICER='||L_COUNT_RELATIONSHIP_OFFICER);

    IF L_COUNT_REFFERAL_PERSON >=0 AND L_COUNT_RELATIONSHIP_OFFICER = 1 THEN

    DBG('INSIDE IF CONDITION');

      BEGIN
        INSERT INTO STTM_CUST_TD_REFERRAL_TEMP_CUSTOM
        VALUES
          (P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE,
           P_STDCUSTD.v_sttms_cust_account.cust_Ac_no,
           P_STDCUSTD.v_sttms_cust_account.CCY,
           DECODE(L_COUNT_REFFERAL_PERSON, 0, NULL,P_STDCUSTD.v_cust_td_referral_custom.REFERRAL_PERSON),
           P_STDCUSTD.v_cust_td_referral_custom.relationship_officer,
           P_STDCUSTD.v_cust_td_referral_custom.sale_channel);

        COMMIT;

      EXCEPTION
        WHEN OTHERS THEN
          UPDATE STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
             SET A.REFERRAL_PERSON      = DECODE(L_COUNT_REFFERAL_PERSON, 0, NULL,P_STDCUSTD.v_cust_td_referral_custom.REFERRAL_PERSON),
                 A.RELATIONSHIP_OFFICER = P_STDCUSTD.v_cust_td_referral_custom.relationship_officer,
                 A.SALE_CHANNEL         = P_STDCUSTD.v_cust_td_referral_custom.sale_channel
           WHERE A.BRN = P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE
             AND A.ACC = P_STDCUSTD.v_sttms_cust_account.cust_Ac_no
             AND A.CCY = P_STDCUSTD.v_sttms_cust_account.CCY;
          COMMIT;
      END;

    ELSE

    DBG('INSIDE ELSE CONDITION');

      BEGIN
        SELECT *
          INTO L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM
          FROM STTM_CUST_TD_REFERRAL_TEMP_CUSTOM A
         WHERE A.ACC = P_STDCUSTD.v_cust_td_referral_custom.ACC;
      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM := NULL;
      END;

      DBG('L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.ACC='||L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.ACC);
      DBG('L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.BRN='||L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.BRN);

      DBG('L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.REFERRAL_PERSON='||L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.REFERRAL_PERSON);
      DBG('L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.RELATIONSHIP_OFFICER='||L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.RELATIONSHIP_OFFICER);
      DBG('L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.SALE_CHANNEL='||L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.SALE_CHANNEL);

      IF L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.ACC IS NOT NULL AND
         L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.BRN IS NOT NULL THEN

        P_STDCUSTD.v_cust_td_referral_custom.REFERRAL_PERSON      := L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.REFERRAL_PERSON;
        P_STDCUSTD.v_cust_td_referral_custom.RELATIONSHIP_OFFICER := L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.RELATIONSHIP_OFFICER;
        P_STDCUSTD.v_cust_td_referral_custom.SALE_CHANNEL         := L_STTM_CUST_TD_REFERRAL_TEMP_CUSTOM.SALE_CHANNEL;

      END IF;

      DBG('P_STDCUSTD.v_cust_td_referral_custom.REFERRAL_PERSON='||P_STDCUSTD.v_cust_td_referral_custom.REFERRAL_PERSON);
      DBG('P_STDCUSTD.v_cust_td_referral_custom.RELATIONSHIP_OFFICER='||P_STDCUSTD.v_cust_td_referral_custom.RELATIONSHIP_OFFICER);
      DBG('P_STDCUSTD.v_cust_td_referral_custom.SALE_CHANNEL='||P_STDCUSTD.v_cust_td_referral_custom.SALE_CHANNEL);

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_REFERRAL_DTLS');
  END PR_INSERT_REFERRAL_DTLS;
  --Referral Sampath Ends

  FUNCTION FN_GET_MIN_TOPUP_AMOUNT(P_PLAN IN VARCHAR2, P_CCY IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.CODE%TYPE IS
    L_MIN_TOPUP_AMOUNT NUMBER;
  BEGIN

    BEGIN

      IF P_CCY = 'USD' THEN

        SELECT B.CODE
          INTO L_MIN_TOPUP_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CLEVERSAV_MINTOP'
           AND B.VALUE = P_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';

      ELSIF P_CCY = 'KHR' THEN

        SELECT B.CODE * 4000
          INTO L_MIN_TOPUP_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CLEVERSAV_MINTOP'
           AND B.VALUE = P_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';

      END IF;

      RETURN L_MIN_TOPUP_AMOUNT;

    EXCEPTION
      WHEN OTHERS THEN

        L_MIN_TOPUP_AMOUNT := 0;

        RETURN L_MIN_TOPUP_AMOUNT;

    END;

  EXCEPTION
    WHEN OTHERS THEN

      DBG('FAILED IN FN_GET_MIN_TOPUP_AMOUNT');
      DBG('ERROR CODE IN FN_GET_MIN_TOPUP_AMOUNT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MIN_TOPUP_AMOUNT=' || SQLERRM);

  END FN_GET_MIN_TOPUP_AMOUNT;

  --Pro Savings Sampath Starts
  FUNCTION FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(P_PLAN IN VARCHAR2,
                                           P_CCY  IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.CODE%TYPE IS
    L_MIN_TOPUP_AMOUNT NUMBER;
  BEGIN

    BEGIN

      IF P_CCY = 'USD' THEN

        SELECT B.CODE
          INTO L_MIN_TOPUP_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'PRO_TOPUP_USD_I'
           AND B.VALUE = P_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';

      ELSIF P_CCY = 'KHR' THEN

        SELECT B.CODE
          INTO L_MIN_TOPUP_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'PRO_TOPUP_KHR_I'
           AND B.VALUE = P_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';

      END IF;

      RETURN L_MIN_TOPUP_AMOUNT;

    EXCEPTION
      WHEN OTHERS THEN

        L_MIN_TOPUP_AMOUNT := 0;

        RETURN L_MIN_TOPUP_AMOUNT;

    END;

  EXCEPTION
    WHEN OTHERS THEN

      DBG('FAILED IN FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV');
      DBG('ERROR CODE IN FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV=' || SQLERRM);

  END FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV;

  FUNCTION FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV(P_PLAN IN VARCHAR2,
                                             P_CCY  IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.CODE%TYPE IS
    L_INITIAL_DEP_AMOUNT NUMBER;
  BEGIN

    BEGIN

      IF P_CCY = 'USD' THEN

        SELECT B.CODE
          INTO L_INITIAL_DEP_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'PRO_SAV_DEP_USD'
           AND B.VALUE = P_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';

      ELSIF P_CCY = 'KHR' THEN

        SELECT B.CODE
          INTO L_INITIAL_DEP_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'PRO_SAV_DEP_KHR'
           AND B.VALUE = P_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';

      END IF;

      RETURN L_INITIAL_DEP_AMOUNT;

    EXCEPTION
      WHEN OTHERS THEN

        L_INITIAL_DEP_AMOUNT := 0;

        RETURN L_INITIAL_DEP_AMOUNT;

    END;

  EXCEPTION
    WHEN OTHERS THEN

      DBG('FAILED IN FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV');
      DBG('ERROR CODE IN FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV=' || SQLERRM);

  END FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV;

  FUNCTION FN_GET_TEMP_MIN_TOP_UP_AMT(p_stdcustd IN stpks_stdcustd_Main.ty_stdcustd)
    RETURN STTM_CUST_TD_DTLS_TEMP_CUSTOM.MIN_TOP_UP_AMT%TYPE AS

    L_MIN_TOP_UP_AMT STTM_CUST_TD_DTLS_TEMP_CUSTOM.MIN_TOP_UP_AMT%TYPE;

  BEGIN

    SELECT MIN_TOP_UP_AMT
      INTO L_MIN_TOP_UP_AMT
      FROM STTM_CUST_TD_DTLS_TEMP_CUSTOM A
     WHERE A.ACC = p_stdcustd.v_sttms_cust_account.cust_Ac_no
       AND A.BRN = p_stdcustd.v_sttms_cust_account.BRANCH_CODE;

    DBG('L_MIN_TOP_UP_AMT=' || L_MIN_TOP_UP_AMT);

    RETURN L_MIN_TOP_UP_AMT;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_MIN_TOP_UP_AMT;

  END FN_GET_TEMP_MIN_TOP_UP_AMT;

  PROCEDURE PR_INSERT_MIN_TOPUP_DTLS(P_STDCUSTD IN OUT stpks_stdcustd_Main.ty_stdcustd) AS

    PRAGMA AUTONOMOUS_TRANSACTION;

    L_STTM_CUST_TD_DTLS_TEMP_CUSTOM STTM_CUST_TD_DTLS_TEMP_CUSTOM%ROWTYPE;

  BEGIN

    DBG('INSIDE IF CONDITION');

    BEGIN
      INSERT INTO STTM_CUST_TD_DTLS_TEMP_CUSTOM
      VALUES
        (P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE,
         P_STDCUSTD.v_sttms_cust_account.cust_Ac_no,
         P_STDCUSTD.v_sttms_cust_account.CCY,
         P_STDCUSTD.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      COMMIT;

    EXCEPTION
      WHEN OTHERS THEN
        UPDATE STTM_CUST_TD_DTLS_TEMP_CUSTOM A
           SET A.MIN_TOP_UP_AMT = P_STDCUSTD.v_ictm_td_details_custom.MIN_TOP_UP_AMT

         WHERE A.BRN = P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE
           AND A.ACC = P_STDCUSTD.v_sttms_cust_account.cust_Ac_no
           AND A.CCY = P_STDCUSTD.v_sttms_cust_account.CCY;
        COMMIT;
    END;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_MIN_TOPUP_DTLS');
  END PR_INSERT_MIN_TOPUP_DTLS;

  --Pro Savings Sampath Ends

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdcustd         IN OUT stpks_stdcustd_Main.ty_stdcustd,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  --Pro Savings Sampath Starts
    L_PLAN VARCHAR2(25);
    --Pro Savings Sampath Ends

  BEGIN

    Dbg('In Fn_Post_Build_type_structure..=' || p_Action_Code);

  --Pro Savings Sampath Starts
    IF p_Action_Code = 'DEFAULT' THEN

      IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

        L_PLAN := '60K_PLAN';

        p_stdcustd.v_ictms_td_details.TD_AMOUNT := FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV(L_PLAN,
                                                                                     p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
            ('PS03', 'PS04') THEN

        --Get the plan. 2 plans

        L_PLAN := '200K_PLAN';

        p_stdcustd.v_ictms_td_details.TD_AMOUNT := FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                                                     p_stdcustd.v_sttms_cust_account.CCY);

      END IF;

    END IF;
    --Pro Savings Sampath Ends

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdcustd_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdcustd         IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

    --sampath starts
    L_MIN_TOPUP_AMOUNT ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    L_PLAN             VARCHAR2(25);
    L_COUNT            NUMBER := 0;
    --sampath ends

  --Pro Savings Sampath Starts
    L_STTM_CUST_ACCOUNT_PAYIN  STTM_CUST_ACCOUNT%ROWTYPE;
    L_STTM_CUST_ACCOUNT_PAYOUT STTM_CUST_ACCOUNT%ROWTYPE;

    L_PAYIN_ACC STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PAYIN_BRN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_PAYIN_CCY STTM_CUST_ACCOUNT.CCY%TYPE;

    L_PAYOUT_ACC STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PAYOUT_BRN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_PAYOUT_CCY STTM_CUST_ACCOUNT.CCY%TYPE;

    L_CASA_ACCOUNT_PAYOUT STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_INITIAL_DEPOSIT     ictms_td_details.TD_AMOUNT%TYPE;
    --Pro Savings Sampath Ends

  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory=' || p_Action_Code);

  --Referral Sampath Starts Fix for storing customer custom fields into custom table

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, /*CSPKS_REQ_GLOBAL.P_MODIFY,*/
                         CSPKS_REQ_GLOBAL.p_Query) THEN
      dbg('p_stdcustd.v_sttms_cust_account.auth_stat=' ||
          p_stdcustd.v_sttms_cust_account.auth_stat);
      p_stdcustd.v_cust_td_referral_custom.brn := p_stdcustd.v_sttms_cust_account.branch_code;
      p_stdcustd.v_cust_td_referral_custom.acc := p_stdcustd.v_sttms_cust_account.cust_ac_no;
      p_stdcustd.v_cust_td_referral_custom.ccy := p_stdcustd.v_sttms_cust_account.ccy;

      p_stdcustd.v_cust_td_referral_custom.sale_channel := FN_GET_SALE_CHANNEL(p_stdcustd.v_sttms_cust_account.CUST_AC_NO);

      p_stdcustd.v_cust_td_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                    p_stdcustd.v_sttms_cust_account.CUST_AC_NO);
      p_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER := FN_GET_CUST_NAME('RO',
                                                                                    p_stdcustd.v_sttms_cust_account.CUST_AC_NO);

      dbg('p_stdcustd.v_cust_td_referral_custom.referral_person 11=' ||
          p_stdcustd.v_cust_td_referral_custom.referral_person);

    END IF;
    --Referral Sampath Ends Fix for storing customer custom fields into custom table


    --sampath starts

    DBG('p_Action_Code=' || p_Action_Code);

    p_stdcustd.v_ictm_td_details_custom.BRN := p_stdcustd.v_sttms_cust_account.BRANCH_CODE;
    p_stdcustd.v_ictm_td_details_custom.ACC := p_stdcustd.v_sttms_cust_account.CUST_AC_NO;
    p_stdcustd.v_ictm_td_details_custom.CCY := p_stdcustd.v_sttms_cust_account.CCY;

    IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS NOT IN
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02', 'PS01',
        'PS02',
        'PS03',
        'PS04') THEN --Pro Savings Sampath Changes

       IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT IS NOT NULL THEN

       p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := NULL;

       END IF;

      IF NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT, 0) > 0 THEN
        
      --IF NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT, 0) IS NOT NULL THEN

        Pr_Log_Error(p_Source,
                     p_Function_Id,
                     'AC-CLS-006',
                     p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

        RETURN FALSE;

      END IF;

    END IF;

    IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CUST_ACCOUNT A
       WHERE A.CUST_NO = p_stdcustd.v_sttms_cust_account.CUST_NO
         AND A.ACCOUNT_CLASS IN
             ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02')
         AND A.RECORD_STAT = 'O';

      IF L_COUNT >= 99 THEN

        Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-008', NULL);

        RETURN FALSE;

      END IF;

      p_stdcustd.v_ictm_td_details_custom.BRN := p_stdcustd.v_sttms_cust_account.BRANCH_CODE;
      p_stdcustd.v_ictm_td_details_custom.ACC := p_stdcustd.v_sttms_cust_account.CUST_AC_NO;
      p_stdcustd.v_ictm_td_details_custom.CCY := p_stdcustd.v_sttms_cust_account.CCY;

      IF p_Action_Code = 'COMPUTE' THEN

        /*BEGIN
          SELECT B.CODE
            INTO L_MIN_TOP_UP_AMT
            FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
           WHERE A.TYPE = B.TYPE
             AND A.TYPE = 'CLEVERSAV_MINTOP'
             AND B.VALUE = p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
            --p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := 200;
        END;*/

        IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
           ('RY01', 'RY02') THEN

          L_PLAN := 'RUBY_PLAN_A';

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN,
                                                        p_stdcustd.v_sttms_cust_account.CCY);

        ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
              ('GY01', 'GY02') THEN

          --Get the plan. 2 plans

          IF GLOBAL.application_date -
             p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 365 THEN

            L_PLAN := 'GOLD_PLAN_A';

          ELSE

            L_PLAN := 'GOLD_PLAN_B';

          END IF;

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                        p_stdcustd.v_sttms_cust_account.CCY);

        ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
              ('SY01', 'SY02') THEN

          --Get the plan. 3 plans

          IF GLOBAL.application_date -
             p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 365 THEN

            L_PLAN := 'SILVER_PLAN_A';

          ELSIF GLOBAL.application_date -
                p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE > 365

                AND GLOBAL.application_date -
                p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 730 THEN

            L_PLAN := 'SILVER_PLAN_B';

          ELSE

            L_PLAN := 'SILVER_PLAN_C';

          END IF;

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                        p_stdcustd.v_sttms_cust_account.CCY);

        END IF;



        DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
            p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

        IF p_stdcustd.v_sttms_cust_account.CCY = 'USD' THEN

          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_MIN_TOPUP_AMOUNT;

        ELSIF p_stdcustd.v_sttms_cust_account.CCY = 'KHR' THEN

          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_MIN_TOPUP_AMOUNT;

        END IF;

      END IF;

      IF p_Action_Code IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
         
         --Pro Savings Sampath Starts not to change the minimum top up amount for clever savigs
        IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
           ('RY01', 'RY02') THEN
        
          L_PLAN := 'RUBY_PLAN_A';
        
          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN,
                                                        p_stdcustd.v_sttms_cust_account.CCY);
        
        ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
              ('GY01', 'GY02') THEN
        
          --Get the plan. 2 plans
        
          IF GLOBAL.application_date -
             p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 365 THEN
          
            L_PLAN := 'GOLD_PLAN_A';
          
          ELSE
          
            L_PLAN := 'GOLD_PLAN_B';
          
          END IF;
        
          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                        p_stdcustd.v_sttms_cust_account.CCY);
        
        ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
              ('SY01', 'SY02') THEN
        
          --Get the plan. 3 plans
        
          IF GLOBAL.application_date -
             p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 365 THEN
          
            L_PLAN := 'SILVER_PLAN_A';
          
          ELSIF GLOBAL.application_date -
                p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE > 365
               
                AND GLOBAL.application_date -
                p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 730 THEN
          
            L_PLAN := 'SILVER_PLAN_B';
          
          ELSE
          
            L_PLAN := 'SILVER_PLAN_C';
          
          END IF;
        
          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                        p_stdcustd.v_sttms_cust_account.CCY);
        
        END IF;
        --Pro Savings Sampath Starts not to change the minimum top up amount for clever savigs

        IF p_stdcustd.v_ictms_acc.AUTO_ROLLOVER = 'Y' THEN

          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-003',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

          RETURN FALSE;

        END IF;

        IF p_stdcustd.v_ictms_acc.MOVE_INT_TO_UNCLAIMED = 'Y' THEN

          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-004',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

          RETURN FALSE;

        END IF;

        IF p_stdcustd.v_ictms_acc.MOVE_PRIC_TO_UNCLAIMED = 'Y' THEN

          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-005',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

          RETURN FALSE;

        END IF;

        IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT IS NULL THEN

          Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-002', NULL);

          RETURN FALSE;

        END IF;

        IF p_stdcustd.v_sttms_cust_account.CCY = 'USD' THEN
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <
             L_MIN_TOPUP_AMOUNT THEN

            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-001',
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

            RETURN FALSE;

          END IF;

      --Pro Savings Sampath Starts not to change the minimum top up amount for clever savings
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <>
             L_MIN_TOPUP_AMOUNT THEN

            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-012',
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

            RETURN FALSE;

          END IF;
          --Pro Savings Sampath Ends not to change the minimum top up amount for clever savings

        END IF;

        IF p_stdcustd.v_sttms_cust_account.CCY = 'KHR' THEN
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <
      L_MIN_TOPUP_AMOUNT THEN
             --L_MIN_TOPUP_AMOUNT * 4000 THEN Pro Savings Fix for clever savings


            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-001',
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

            RETURN FALSE;

          END IF;

      --Pro Savings Sampath Starts not to change the minimum top up amount for clever savings
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <>
             L_MIN_TOPUP_AMOUNT THEN

            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-012',
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

            RETURN FALSE;

          END IF;
          --Pro Savings Sampath Ends not to change the minimum top up amount for clever savings

        END IF;

      END IF;

    END IF;

    --sampath ends


  --Pro Savings Sampath Starts
    IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
       ('PS01', 'PS02', 'PS03', 'PS04') THEN

      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CUST_ACCOUNT A
       WHERE A.CUST_NO = p_stdcustd.v_sttms_cust_account.CUST_NO
         AND A.ACCOUNT_CLASS IN ('PS01', 'PS02', 'PS03', 'PS04')
         AND A.RECORD_STAT = 'O';

      IF L_COUNT >= 99 THEN

        Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-013', NULL);

        RETURN FALSE;

      END IF;

      --validation for initial deposit
      IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

        L_PLAN := '60K_PLAN';

        L_INITIAL_DEPOSIT := FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV(L_PLAN,
                                                               p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
            ('PS03', 'PS04') THEN

        L_PLAN := '200K_PLAN';

        L_INITIAL_DEPOSIT := FN_GET_INITIAL_DEP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                               p_stdcustd.v_sttms_cust_account.CCY);

      END IF;

      DBG('L_INITIAL_DEPOSIT=' || L_INITIAL_DEPOSIT);
      DBG('L_INITIAL_DEPOSIT=' || (70 / 100) * L_INITIAL_DEPOSIT);
      DBG('NVL(p_stdcustd.v_ictms_td_details.TD_AMOUNT, 0)=' ||
          NVL(p_stdcustd.v_ictms_td_details.TD_AMOUNT, 0));

      IF p_Action_Code IN ('NEW', 'MODIFY') THEN

        IF NVL(p_stdcustd.v_ictms_td_details.TD_AMOUNT, 0) <
           (70 / 100) * L_INITIAL_DEPOSIT THEN

          Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-011', NULL);

          RETURN FALSE;

         NULL;

        END IF;

        IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
           ('PS01', 'PS02') THEN

          L_PLAN := '60K_PLAN';

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN,
                                                                p_stdcustd.v_sttms_cust_account.CCY);

        ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
              ('PS03', 'PS04') THEN

          --Get the plan. 2 plans

          L_PLAN := '200K_PLAN';

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                                p_stdcustd.v_sttms_cust_account.CCY);

        END IF;

        IF NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT, 0) <
           (50 / 100) * L_MIN_TOPUP_AMOUNT THEN

          Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-011', NULL);

          RETURN FALSE;

        END IF;

      END IF;

      --Validation for payin

      IF P_STDCUSTD.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN

        FOR I IN 1 .. P_STDCUSTD.V_ICTMS_TDPAYIN_DETAILS.LAST LOOP
          DBG('Validation For Payin' ||
              P_STDCUSTD.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
          --IF P_STDCUSTD.V_ICTMS_TDPAYIN_DETAILS(I).PAYINTYPE = 'S' THEN

          L_PAYIN_ACC := P_STDCUSTD.V_ICTMS_TDPAYIN_DETAILS(I)
                         .MULTIMODE_TDOFFSET_ACC;

          L_PAYIN_BRN := P_STDCUSTD.V_ICTMS_TDPAYIN_DETAILS(I)
                         .MULTIMODE_OFFSET_BRN;

          --L_PAYIN_CCY := P_STDCUSTD.V_ICTMS_TDPAYIN_DETAILS(I)
          --.MULTIMODE_TDOFFSET_CCY;

          IF L_PAYIN_ACC IS NOT NULL THEN
            EXIT;
          END IF;

        --END IF;

        END LOOP;

      END IF;

      DBG('L_PAYIN_ACC=' || L_PAYIN_ACC);

      DBG('L_PAYIN_BRN=' || L_PAYIN_BRN);

      --DBG('L_PAYIN_CCY=' || L_PAYIN_CCY);

      BEGIN
        SELECT *
          INTO L_STTM_CUST_ACCOUNT_PAYIN
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = L_PAYIN_ACC
           AND A.BRANCH_CODE = L_PAYIN_BRN;
        --AND A.CCY = L_PAYIN_CCY;
      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_ACCOUNT_PAYIN := NULL;
      END;

      --Validation for payout

      IF P_STDCUSTD.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN

        FOR I IN 1 .. P_STDCUSTD.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
          DBG('Validation For Payout' ||
              P_STDCUSTD.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
          IF P_STDCUSTD.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'S' THEN

            L_PAYOUT_ACC := P_STDCUSTD.V_ICTMS_TDPAYOUT_DETAILS(I)
                            .OFFSET_ACC;

            L_PAYOUT_BRN := P_STDCUSTD.V_ICTMS_TDPAYOUT_DETAILS(I)
                            .OFFSET_BRN;

            --L_PAYOUT_CCY := P_STDCUSTD.V_ICTMS_TDPAYOUT_DETAILS(I)
            --.OFFSET_CCY;

            IF L_PAYOUT_ACC IS NOT NULL THEN
              EXIT;
            END IF;

          END IF;

        END LOOP;

      END IF;

      DBG('L_PAYOUT_ACC=' || L_PAYOUT_ACC);

      DBG('L_PAYOUT_BRN=' || L_PAYOUT_BRN);

      --DBG('L_PAYOUT_CCY=' || L_PAYOUT_CCY);

      BEGIN
        SELECT *
          INTO L_STTM_CUST_ACCOUNT_PAYOUT
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = L_PAYOUT_ACC
           AND A.BRANCH_CODE = L_PAYOUT_BRN;
        --AND A.CCY = L_PAYOUT_CCY;
      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_ACCOUNT_PAYOUT := NULL;
      END;

      IF L_STTM_CUST_ACCOUNT_PAYIN.ACCOUNT_CLASS NOT IN
         ('CA06', 'CA07', 'CA08', 'CA09') OR
         L_STTM_CUST_ACCOUNT_PAYOUT.ACCOUNT_CLASS NOT IN
         ('CA06', 'CA07', 'CA08', 'CA09') THEN

        Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-009', NULL);

        RETURN FALSE;

      END IF;

      p_stdcustd.v_ictm_td_details_custom.BRN := p_stdcustd.v_sttms_cust_account.BRANCH_CODE;
      p_stdcustd.v_ictm_td_details_custom.ACC := p_stdcustd.v_sttms_cust_account.CUST_AC_NO;
      p_stdcustd.v_ictm_td_details_custom.CCY := p_stdcustd.v_sttms_cust_account.CCY;

      IF p_Action_Code = 'COMPUTE' THEN

        /*BEGIN
          SELECT B.CODE
            INTO L_MIN_TOP_UP_AMT
            FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
           WHERE A.TYPE = B.TYPE
             AND A.TYPE = 'CLEVERSAV_MINTOP'
             AND B.VALUE = p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN GETTING THE MIN TOP UP AMOUNT FOR THE ACCOUNT CLASS');
            --p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := 200;
        END;*/

        IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
           ('PS01', 'PS02') THEN

          L_PLAN := '60K_PLAN';

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN,
                                                                p_stdcustd.v_sttms_cust_account.CCY);

        ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
              ('PS03', 'PS04') THEN

          --Get the plan. 2 plans

          L_PLAN := '200K_PLAN';

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                                p_stdcustd.v_sttms_cust_account.CCY);

        END IF;

        DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
            p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

        IF p_stdcustd.v_sttms_cust_account.CCY = 'USD' THEN

          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := CASE
                                                                  WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                           0) =
                                                                       (50 / 100) *
                                                                       L_MIN_TOPUP_AMOUNT THEN
                                                                   p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT

                                                                  WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                           0) >
                                                                       (50 / 100) *
                                                                       L_MIN_TOPUP_AMOUNT THEN
                                                                   p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT
                                                                  ELSE
                                                                   GREATEST(NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                                0),
                                                                            L_MIN_TOPUP_AMOUNT)
                                                                END;

        ELSIF p_stdcustd.v_sttms_cust_account.CCY = 'KHR' THEN

          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := CASE
                                                                  WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                           0) =
                                                                       (50 / 100) *
                                                                       L_MIN_TOPUP_AMOUNT THEN
                                                                   p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT

                                                                  WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                           0) >
                                                                       (50 / 100) *
                                                                       L_MIN_TOPUP_AMOUNT THEN
                                                                   p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT

                                                                  ELSE
                                                                   GREATEST(NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                                0),
                                                                            L_MIN_TOPUP_AMOUNT)

                                                                END;

        END IF;

      END IF;

      IF p_Action_Code IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

        /*IF p_stdcustd.v_ictms_acc.AUTO_ROLLOVER = 'Y' THEN

          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-003',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

          RETURN FALSE;

        END IF;*/

        IF p_stdcustd.v_ictms_acc.MOVE_INT_TO_UNCLAIMED = 'Y' THEN

          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-004',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

          RETURN FALSE;

        END IF;

        IF p_stdcustd.v_ictms_acc.MOVE_PRIC_TO_UNCLAIMED = 'Y' THEN

          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'AC-CLS-005',
                       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

          RETURN FALSE;

        END IF;

        IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT IS NULL THEN

          Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-002', NULL);

          RETURN FALSE;

        END IF;

        IF p_stdcustd.v_sttms_cust_account.CCY = 'USD' THEN
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <
             (50 / 100) * L_MIN_TOPUP_AMOUNT THEN

            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-001',
                         L_MIN_TOPUP_AMOUNT ||
                         p_stdcustd.v_sttms_cust_account.CCY || ' for ' ||
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

            RETURN FALSE;

          END IF;

        END IF;

        IF p_stdcustd.v_sttms_cust_account.CCY = 'KHR' THEN
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <
             (50 / 100) * L_MIN_TOPUP_AMOUNT THEN

            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-001',
                         L_MIN_TOPUP_AMOUNT ||
                         p_stdcustd.v_sttms_cust_account.CCY || ' for ' ||
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

            RETURN FALSE;

          END IF;

        END IF;

      END IF;

    END IF;
    --Pro Savings Sampath Ends

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdcustd         IN stpks_stdcustd_Main.ty_stdcustd,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdcustd         IN stpks_stdcustd_Main.ty_stdcustd,
                                       p_Prev_stdcustd    IN OUT stpks_stdcustd_Main.ty_stdcustd,
                                       p_Wrk_stdcustd     IN OUT stpks_stdcustd_Main.ty_stdcustd,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  --Pro Savings Sampath Starts
    L_MIN_TOPUP_AMOUNT ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;
    L_PLAN             VARCHAR2(25);
    --Pro Savings Sampath Ends

  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

  --Referral Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY
                         /*,CSPKS_REQ_GLOBAL.P_AUTH*/) THEN

      dbg('p_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER=' ||
          p_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER);
      dbg('p_wrk_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER=' ||
          p_wrk_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER);

      IF p_Source IN ('FLEXIPRINCE', 'FLEXCUBE') THEN

        IF p_wrk_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER IS NULL THEN
          DBG('Relationship officer should not be null for Individual customers');
          PR_LOG_ERROR(p_Function_id, 'FLEXCUBE', 'ST-PRIN-024', '');
          RETURN FALSE;
        END IF;

        IF p_wrk_stdcustd.v_cust_td_referral_custom.SALE_CHANNEL IS NULL THEN
          DBG('Sale Channel should not be null for Individual customers');
          PR_LOG_ERROR(p_Function_id, 'FLEXCUBE', 'ST-PRIN-025', '');
          RETURN FALSE;
        END IF;

        p_wrk_stdcustd.v_cust_td_referral_custom.brn := p_wrk_stdcustd.v_sttms_cust_account.branch_code;
      p_wrk_stdcustd.v_cust_td_referral_custom.acc := p_wrk_stdcustd.v_sttms_cust_account.cust_ac_no;
      p_wrk_stdcustd.v_cust_td_referral_custom.ccy := p_wrk_stdcustd.v_sttms_cust_account.ccy;

      dbg('p_wrk_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER=' ||
          p_wrk_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER);

      PR_INSERT_REFERRAL_DTLS(p_wrk_stdcustd);

      p_WRK_stdcustd.v_cust_td_referral_custom.sale_channel := FN_GET_SALE_CHANNEL(p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);

      p_WRK_stdcustd.v_cust_td_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                        p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);
      p_WRK_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER := FN_GET_CUST_NAME('RO',
                                                                                        p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);


      END IF;

    END IF;
    --Referral Sampath Ends

  --Pro Savings Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
         ('PS01', 'PS02', 'PS03', 'PS04') THEN

        IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
           ('PS01', 'PS02') THEN

          L_PLAN := '60K_PLAN';

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN,
                                                                p_stdcustd.v_sttms_cust_account.CCY);

        ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
              ('PS03', 'PS04') THEN

          --Get the plan. 2 plans

          L_PLAN := '200K_PLAN';

          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                                p_stdcustd.v_sttms_cust_account.CCY);

        END IF;

        IF p_stdcustd.v_sttms_cust_account.CCY = 'USD' THEN
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <
             (50 / 100) * L_MIN_TOPUP_AMOUNT THEN

            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-001',
                         L_MIN_TOPUP_AMOUNT || ' ' ||
                         p_stdcustd.v_sttms_cust_account.CCY || ' for ' ||
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

            RETURN FALSE;

          END IF;

        END IF;

        IF p_stdcustd.v_sttms_cust_account.CCY = 'KHR' THEN
          IF p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT <
             (50 / 100) * L_MIN_TOPUP_AMOUNT THEN

            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'AC-CLS-001',
                         L_MIN_TOPUP_AMOUNT ||
                         p_stdcustd.v_sttms_cust_account.CCY || ' for ' ||
                         p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS);

            RETURN FALSE;

          END IF;

        END IF;

        PR_INSERT_MIN_TOPUP_DTLS(p_wrk_stdcustd);

      END IF;
    END IF;

    --Pro Savings Sampath Ends

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdcustd         IN stpks_stdcustd_Main.Ty_stdcustd,
                                        p_Prev_stdcustd    IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                                        p_Wrk_stdcustd     IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdcustd         IN stpks_stdcustd_Main.Ty_stdcustd,
                            p_Prev_stdcustd    IN stpks_stdcustd_Main.Ty_stdcustd,
                            p_Wrk_stdcustd     IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..apple=' || p_Action_Code);

  --Referral Sampath Starts Fix for storing customer custom fields into custom table
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY, CSPKS_REQ_GLOBAL.P_AUTH) THEN
      p_wrk_stdcustd.v_cust_td_referral_custom.brn := p_wrk_stdcustd.v_sttms_cust_account.branch_code;
      p_wrk_stdcustd.v_cust_td_referral_custom.acc := p_wrk_stdcustd.v_sttms_cust_account.cust_ac_no;
      p_wrk_stdcustd.v_cust_td_referral_custom.ccy := p_wrk_stdcustd.v_sttms_cust_account.ccy;

      dbg('p_wrk_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER=' ||
          p_wrk_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER);

      /*PR_INSERT_REFERRAL_DTLS(p_wrk_stdcustd);

      dbg('p_WRK_stdcustd.v_cust_td_referral_custom.referral_person=' ||
          p_WRK_stdcustd.v_cust_td_referral_custom.referral_person);

      dbg('p_stdcustd.v_cust_td_referral_custom.referral_person=' ||
          p_stdcustd.v_cust_td_referral_custom.referral_person);

      dbg('p_stdcustd.v_sttms_cust_account.auth_stat=' ||
          p_stdcustd.v_sttms_cust_account.auth_stat);*/

      p_WRK_stdcustd.v_cust_td_referral_custom.sale_channel := FN_GET_SALE_CHANNEL(p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);

      p_WRK_stdcustd.v_cust_td_referral_custom.referral_person      := FN_GET_CUST_NO('RP',
                                                                                        p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);
      p_WRK_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER := FN_GET_CUST_NO('RO',
                                                                                         p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);

      dbg('p_WRK_stdcustd.v_cust_td_referral_custom.sale_channel=' ||
          p_WRK_stdcustd.v_cust_td_referral_custom.sale_channel);

      dbg('p_WRK_stdcustd.v_cust_td_referral_custom.referral_person=' ||
          p_WRK_stdcustd.v_cust_td_referral_custom.referral_person);

      dbg('p_WRK_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER=' ||
          p_WRK_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER);
    END IF;
    --Referral Sampath Ends Fix for storing customer custom fields into custom table


    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdcustd         IN stpks_stdcustd_Main.Ty_stdcustd,
                             p_prev_stdcustd    IN stpks_stdcustd_Main.Ty_stdcustd,
                             p_wrk_stdcustd     IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');
	
	--Clever Savings Sampath Starts
    DBG('ACTION CODE=' || CSPKS_REQ_GLOBAL.G_HEADER('ACTION'));

    IF CSPKS_REQ_GLOBAL.G_HEADER('ACTION') = 'AUTH' AND
       NVL(p_stdcustd.v_sttms_cust_account.ONCE_AUTH, 'N') = 'N' AND
       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      IFPKS_CLEVER_SAVINGS_UTILS.PR_INSERT_PUSH_NOTIF_STATUS(p_stdcustd.v_sttms_cust_account.CUST_NO,
                                                          p_stdcustd.v_sttms_cust_account.CUST_AC_NO,
                                                          p_stdcustd.v_sttms_cust_account.CCY,
                                                          p_stdcustd.v_sttms_cust_account.BRANCH_CODE,
                                                          'NEW',
                                                          NULL);

      IF NOT IFPKS_CLEVER_SAVINGS_UTILS.FN_PUSH_NOTIFICATION(p_stdcustd.v_sttms_cust_account.CUST_NO,
                                                          'NEW') THEN

        DBG('FAILED IN PUSHING THE NOTIFICATION');

        IFPKS_CLEVER_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(p_stdcustd.v_sttms_cust_account.CUST_NO,
                                                            p_stdcustd.v_sttms_cust_account.CUST_AC_NO,
                                                            p_stdcustd.v_sttms_cust_account.CCY,
                                                            p_stdcustd.v_sttms_cust_account.BRANCH_CODE,
                                                            'NEW',
                                                            'F');



      ELSE

        DBG('SUCCESS IN PUSHING THE NOTIFICATION');

        IFPKS_CLEVER_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(p_stdcustd.v_sttms_cust_account.CUST_NO,
                                                            p_stdcustd.v_sttms_cust_account.CUST_AC_NO,
                                                            p_stdcustd.v_sttms_cust_account.CCY,
                                                            p_stdcustd.v_sttms_cust_account.BRANCH_CODE,
                                                            'NEW',
                                                            'S');


      END IF;



    END IF;

    --Clever Savings Sampath Ends

   --Pro Savings Sampath Starts
    DBG('ACTION CODE=' || CSPKS_REQ_GLOBAL.G_HEADER('ACTION'));

    IF CSPKS_REQ_GLOBAL.G_HEADER('ACTION') = 'AUTH' AND
       NVL(p_stdcustd.v_sttms_cust_account.ONCE_AUTH, 'N') = 'N' AND
       p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
       ('PS01', 'PS02', 'PS03', 'PS04') THEN

      IFPKS_PRO_SAVINGS_UTILS.PR_INSERT_PUSH_NOTIF_STATUS(p_stdcustd.v_sttms_cust_account.CUST_NO,
                                                          p_stdcustd.v_sttms_cust_account.CUST_AC_NO,
                                                          p_stdcustd.v_sttms_cust_account.CCY,
                                                          p_stdcustd.v_sttms_cust_account.BRANCH_CODE,
                                                          'NEW',
                                                          NULL);

      IF NOT IFPKS_PRO_SAVINGS_UTILS.FN_PUSH_NOTIFICATION(p_stdcustd.v_sttms_cust_account.CUST_NO,
                                                          'NEW') THEN

        DBG('FAILED IN PUSHING THE NOTIFICATION');

        IFPKS_PRO_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(p_stdcustd.v_sttms_cust_account.CUST_NO,
                                                            p_stdcustd.v_sttms_cust_account.CUST_AC_NO,
                                                            p_stdcustd.v_sttms_cust_account.CCY,
                                                            p_stdcustd.v_sttms_cust_account.BRANCH_CODE,
                                                            'NEW',
                                                            'F');



      ELSE

        DBG('SUCCESS IN PUSHING THE NOTIFICATION');

        IFPKS_PRO_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(p_stdcustd.v_sttms_cust_account.CUST_NO,
                                                            p_stdcustd.v_sttms_cust_account.CUST_AC_NO,
                                                            p_stdcustd.v_sttms_cust_account.CCY,
                                                            p_stdcustd.v_sttms_cust_account.BRANCH_CODE,
                                                            'NEW',
                                                            'S');


      END IF;



    END IF;

    --Pro Savings Sampath Ends

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdcustd         IN stpks_stdcustd_Main.Ty_stdcustd,
                        p_Wrk_stdcustd     IN OUT stpks_stdcustd_Main.Ty_stdcustd,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
    --sampath starts
    L_ICTM_TD_DETAILS_CUSTOM ICTM_TD_DETAILS_CUSTOM%ROWTYPE;
    L_PLAN                   VARCHAR2(25);
    L_MIN_TOPUP_AMOUNT       NUMBER;
    --sampath ends
  BEGIN

    Dbg('In Fn_Pre_Query..=' || p_Action_Code);

    IF p_Action_Code IN ('NEW', '', '', 'MODIFY') AND
       p_stdcustd.v_sttms_cust_account.account_class in
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);

      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      --p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT;

      IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN

        L_PLAN := 'RUBY_PLAN_A';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN,
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
            ('GY01', 'GY02') THEN

        --Get the plan. 2 plans

        IF GLOBAL.application_date -
           p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 365 THEN

          L_PLAN := 'GOLD_PLAN_A';

        ELSE

          L_PLAN := 'GOLD_PLAN_B';

        END IF;

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
            ('SY01', 'SY02') THEN

        --Get the plan. 3 plans

        IF GLOBAL.application_date -
           p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 365 THEN

          L_PLAN := 'SILVER_PLAN_A';

        ELSIF GLOBAL.application_date -
              p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE > 365

              AND GLOBAL.application_date -
              p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 730 THEN

          L_PLAN := 'SILVER_PLAN_B';

        ELSE

          L_PLAN := 'SILVER_PLAN_C';

        END IF;

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      END IF;

      DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_MIN_TOPUP_AMOUNT;

    END IF;

  --Pro Savings Sampath Starts
    IF p_Action_Code IN ('NEW', '', '', 'MODIFY') AND
       p_stdcustd.v_sttms_cust_account.account_class in
       ('PS01', 'PS02', 'PS03', 'PS04') THEN

      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);

      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      --p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT;

      IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

        L_PLAN := '60K_PLAN';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN,
                                                              p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
            ('PS03', 'PS04') THEN

        --Get the plan. 2 plans

        L_PLAN := '200K_PLAN';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                              p_stdcustd.v_sttms_cust_account.CCY);

      END IF;

      DBG('L_PLAN=' || L_PLAN);
      DBG('L_MIN_TOPUP_AMOUNT=' || L_MIN_TOPUP_AMOUNT);

      DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := CASE
                                                                  WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                           0) =
                                                                       (50 / 100) *
                                                                       L_MIN_TOPUP_AMOUNT THEN
                                                                   p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT

                                                                  WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                           0) >
                                                                       (50 / 100) *
                                                                       L_MIN_TOPUP_AMOUNT THEN
                                                                   p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT

                                                                  ELSE
                                                                   GREATEST(NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                                0),
                                                                            L_MIN_TOPUP_AMOUNT)
                                                                END;

    END IF;
    --Pro Savings Sampath Ends

    /*IF P_ACTION_CODE = 'EXECUTEQUERY' THEN

     DBG('P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE=' ||
          P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE);

      DBG('P_STDCUSTD.v_sttms_cust_account.CCY=' ||
          P_STDCUSTD.v_sttms_cust_account.CCY);


      BEGIN

        SELECT *
          INTO L_ICTM_TD_DETAILS_CUSTOM
          FROM Ictm_Td_Details_Custom A
         WHERE A.ACC = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO;

      EXCEPTION
        WHEN OTHERS THEN

          L_ICTM_TD_DETAILS_CUSTOM := NULL;
      END;

      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT;

    END IF;*/

  --Referral Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_QUERY) THEN

      dbg('p_WRK_stdcustd.v_cust_td_referral_custom.referral_person=' ||
          p_WRK_stdcustd.v_cust_td_referral_custom.referral_person);

      dbg('p_stdcustd.v_cust_td_referral_custom.referral_person=' ||
          p_stdcustd.v_cust_td_referral_custom.referral_person);

      dbg('p_stdcustd.v_sttms_cust_account.auth_stat=' ||
          p_stdcustd.v_sttms_cust_account.auth_stat);

      p_WRK_stdcustd.v_cust_td_referral_custom.sale_channel := FN_GET_SALE_CHANNEL(p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);

      p_WRK_stdcustd.v_cust_td_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                        p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);
      p_WRK_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER := FN_GET_CUST_NAME('RO',
                                                                                        p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);

    END IF;
    --Referral Sampath Ends

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcustd_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdcustd         IN stpks_stdcustd_Main.ty_stdcustd,
                         p_wrk_stdcustd     IN OUT stpks_stdcustd_Main.ty_stdcustd,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
    --sampath starts
    L_ICTM_TD_DETAILS_CUSTOM ICTM_TD_DETAILS_CUSTOM%ROWTYPE;
    L_PLAN                   VARCHAR2(25);
    L_MIN_TOPUP_AMOUNT       NUMBER;
    L_CUST_ACCOUNT           STTM_CUST_ACCOUNT%ROWTYPE;
    --sampath ends

  BEGIN

    Dbg('In Fn_Post_Query..1=' || p_Action_Code);

    IF p_Action_Code IN ('NEW', '', '', 'MODIFY') AND
       p_stdcustd.v_sttms_cust_account.account_class in
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);

      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      --p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT;

      IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN

        L_PLAN := 'RUBY_PLAN_A';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN,
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
            ('GY01', 'GY02') THEN

        --Get the plan. 2 plans

        IF GLOBAL.application_date -
           p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 366 THEN

          L_PLAN := 'GOLD_PLAN_A';

        ELSE

          L_PLAN := 'GOLD_PLAN_B';

        END IF;

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
            ('SY01', 'SY02') THEN

        --Get the plan. 3 plans

        IF GLOBAL.application_date -
           p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 366 THEN

          L_PLAN := 'SILVER_PLAN_A';

        ELSIF GLOBAL.application_date -
              p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE > 366

              AND GLOBAL.application_date -
              p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 731 THEN

          L_PLAN := 'SILVER_PLAN_B';

        ELSE

          L_PLAN := 'SILVER_PLAN_C';

        END IF;

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      END IF;

      DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_MIN_TOPUP_AMOUNT;

    END IF;

  --Pro Savings Sampath Starts
    IF p_Action_Code IN ('NEW', '', '', 'MODIFY') AND
       p_stdcustd.v_sttms_cust_account.account_class in
       ('PS01', 'PS02', 'PS03', 'PS04') THEN

      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);

      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      --p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT;

      IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

        L_PLAN := '60K_PLAN';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN,
                                                              p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN
            ('PS03', 'PS04') THEN

        L_PLAN := '200K_PLAN';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                              p_stdcustd.v_sttms_cust_account.CCY);

      END IF;

      DBG('L_MIN_TOPUP_AMOUNT=' || L_MIN_TOPUP_AMOUNT);

      DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := CASE
                                                                  WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                           0) =
                                                                       (50 / 100) *
                                                                       L_MIN_TOPUP_AMOUNT THEN
                                                                   p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT

                                                                  WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                           0) >
                                                                       (50 / 100) *
                                                                       L_MIN_TOPUP_AMOUNT THEN
                                                                   p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT

                                                                  ELSE
                                                                   GREATEST(FN_GET_TEMP_MIN_TOP_UP_AMT(p_stdcustd),
                                                                            NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                                0),
                                                                            L_MIN_TOPUP_AMOUNT)
                                                                END;

    END IF;
    --Pro Savinsg Sampath Ends

    IF P_ACTION_CODE IN ('/*EXECUTEQUERY*/', 'AUTH') AND
       p_stdcustd.v_sttms_cust_account.account_class in
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);

      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      DBG('P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE=' ||
          P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE);

      DBG('P_STDCUSTD.v_sttms_cust_account.CCY=' ||
          P_STDCUSTD.v_sttms_cust_account.CCY);

      BEGIN

        SELECT *
          INTO L_ICTM_TD_DETAILS_CUSTOM
          FROM Ictm_Td_Details_Custom A
         WHERE A.ACC = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO
           AND A.BRN = P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE;

      EXCEPTION
        WHEN OTHERS THEN

          L_ICTM_TD_DETAILS_CUSTOM := NULL;
      END;

      --ELSE

      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT;

      -- END IF;

      /*IF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN

        L_PLAN := 'RUBY_PLAN_A';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN,
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN

        --Get the plan. 2 plans

        IF GLOBAL.application_date - p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 365 THEN

          L_PLAN := 'GOLD_PLAN_A';

        ELSE

          L_PLAN := 'GOLD_PLAN_B';

        END IF;

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      ELSIF p_stdcustd.v_sttms_cust_account.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN

        --Get the plan. 3 plans

        IF GLOBAL.application_date - p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 365 THEN

          L_PLAN := 'SILVER_PLAN_A';

        ELSIF GLOBAL.application_date - p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE > 365

              AND
              GLOBAL.application_date - p_stdcustd.v_sttms_cust_account.AC_OPEN_DATE <= 730 THEN

          L_PLAN := 'SILVER_PLAN_B';

        ELSE

          L_PLAN := 'SILVER_PLAN_C';

        END IF;

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                      p_stdcustd.v_sttms_cust_account.CCY);

      END IF;

      DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_MIN_TOPUP_AMOUNT;*/

    END IF;

  --Pro Savings Sampath Starts
    IF P_ACTION_CODE IN ('/*EXECUTEQUERY*/', 'AUTH') AND
       p_stdcustd.v_sttms_cust_account.account_class in
       ('PS01', 'PS02', 'PS03', 'PS04') THEN

      DBG('P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);
      DBG('P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO=' ||
          P_WRK_STDCUSTD.v_sttms_cust_account.CUST_AC_NO);

      dbg('p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);
      dbg('p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      DBG('P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE=' ||
          P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE);

      DBG('P_STDCUSTD.v_sttms_cust_account.CCY=' ||
          P_STDCUSTD.v_sttms_cust_account.CCY);

      BEGIN

        SELECT *
          INTO L_ICTM_TD_DETAILS_CUSTOM
          FROM Ictm_Td_Details_Custom A
         WHERE A.ACC = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO
           AND A.BRN = P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE;

      EXCEPTION
        WHEN OTHERS THEN

          L_ICTM_TD_DETAILS_CUSTOM := NULL;
      END;

      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT;

    END IF;
    --Pro Savings Sampath Ends

    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN

      BEGIN

        SELECT *
          INTO L_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO
           AND A.RECORD_STAT = 'O'
           AND A.ONCE_AUTH = 'Y';

      EXCEPTION
        WHEN OTHERS THEN

          L_CUST_ACCOUNT := NULL;
      END;

      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN
         ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN
        BEGIN

          SELECT *
            INTO L_ICTM_TD_DETAILS_CUSTOM
            FROM Ictm_Td_Details_Custom A
           WHERE A.ACC = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO;
          -- AND A.BRN = P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE;

        EXCEPTION
          WHEN OTHERS THEN

            L_ICTM_TD_DETAILS_CUSTOM := NULL;
        END;

      END IF;

      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN

        L_PLAN := 'RUBY_PLAN_A';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN,
                                                      --L_ICTM_TD_DETAILS_CUSTOM.CCY
                                                      L_CUST_ACCOUNT.CCY);

      ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN

        --Get the plan. 2 plans

        IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 365 THEN

          L_PLAN := 'GOLD_PLAN_A';

        ELSE

          L_PLAN := 'GOLD_PLAN_B';

        END IF;

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                      L_ICTM_TD_DETAILS_CUSTOM.CCY);

      ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN

        --Get the plan. 3 plans

        IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN

          L_PLAN := 'SILVER_PLAN_A';

        ELSIF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE > 366

              AND
              GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 730 THEN

          L_PLAN := 'SILVER_PLAN_B';

        ELSE

          L_PLAN := 'SILVER_PLAN_C';

        END IF;

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT(L_PLAN, --pass the plan here
                                                      L_ICTM_TD_DETAILS_CUSTOM.CCY);

      END IF;

      DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN
         ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

        p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := L_MIN_TOPUP_AMOUNT;

      ELSE

        p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := NULL;

      END IF;

    END IF;

  --Pro Savings Sampath Starts
    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN

      BEGIN

        SELECT *
          INTO L_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO
           AND A.RECORD_STAT = 'O'
           AND A.ONCE_AUTH = 'Y';

      EXCEPTION
        WHEN OTHERS THEN

          L_CUST_ACCOUNT := NULL;
      END;

      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02', 'PS03', 'PS04') THEN
        BEGIN

          SELECT *
            INTO L_ICTM_TD_DETAILS_CUSTOM
            FROM Ictm_Td_Details_Custom A
           WHERE A.ACC = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO;
          -- AND A.BRN = P_STDCUSTD.v_sttms_cust_account.BRANCH_CODE;

        EXCEPTION
          WHEN OTHERS THEN

            L_ICTM_TD_DETAILS_CUSTOM := NULL;
        END;

      END IF;

      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

        L_PLAN := '60K_PLAN';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN,
                                                              --L_ICTM_TD_DETAILS_CUSTOM.CCY
                                                              L_CUST_ACCOUNT.CCY);

      ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS03', 'PS04') THEN

        --Get the plan. 2 plans

        L_PLAN := '200K_PLAN';

        L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                              L_ICTM_TD_DETAILS_CUSTOM.CCY);

      END IF;

      DBG('MINIMUM TOP UP REQUIRED FOR THIS ACCOUNT CLASS=' ||
          p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT);

      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02', 'PS03', 'PS04') THEN

      BEGIN

        SELECT *
          INTO L_ICTM_TD_DETAILS_CUSTOM
          FROM ICTM_TD_DETAILS_CUSTOM A
         WHERE A.ACC = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO
           ;

      EXCEPTION
        WHEN OTHERS THEN

          L_ICTM_TD_DETAILS_CUSTOM := NULL;
      END;

        p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := NVL(L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT, CASE
                                                                    WHEN NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                             FN_GET_TEMP_MIN_TOP_UP_AMT(p_WRK_stdcustd)) =
                                                                         (50 / 100) *
                                                                         L_MIN_TOPUP_AMOUNT THEN
                                                                     NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                         FN_GET_TEMP_MIN_TOP_UP_AMT(p_WRK_stdcustd))


                                                                    ELSE
                                                                     GREATEST(FN_GET_TEMP_MIN_TOP_UP_AMT(p_WRK_stdcustd),
                                                                              NVL(p_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT,
                                                                                  0),
                                                                              L_MIN_TOPUP_AMOUNT)

                                                                  END);

      --ELSE

       -- p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := NULL;

      END IF;

    END IF;
    --Pro Savings Sampath Ends

    IF P_ACTION_CODE IN ('NEW', 'AUTH', 'EXECUTEQUERY') AND
       p_stdcustd.v_sttms_cust_account.account_class NOT in
       ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02','PS01',
        'PS02',
        'PS03',
        'PS04') THEN --Pro Savings Sampath Changes

      BEGIN

        SELECT *
          INTO L_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO
           AND A.RECORD_STAT = 'O'
           AND A.ONCE_AUTH = 'Y';

      EXCEPTION
        WHEN OTHERS THEN

          L_CUST_ACCOUNT := NULL;
      END;

      p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := null;

    END IF;

    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN

      BEGIN

        SELECT *
          INTO L_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = P_STDCUSTD.v_sttms_cust_account.CUST_AC_NO
           AND A.RECORD_STAT = 'O'
           AND A.ONCE_AUTH = 'Y';

      EXCEPTION
        WHEN OTHERS THEN

          L_CUST_ACCOUNT := NULL;
      END;

      IF L_CUST_ACCOUNT.ACCOUNT_CLASS NOT IN
         ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02',
          'PS01',
          'PS02',
          'PS03',
          'PS04') THEN --Pro Savings Sampath Changes

        p_WRK_stdcustd.v_ictm_td_details_custom.MIN_TOP_UP_AMT := NULL;

      END IF;

    END IF;

  --Referral Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_QUERY) THEN

      p_WRK_stdcustd.v_cust_td_referral_custom.sale_channel         := FN_GET_SALE_CHANNEL(p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);
      p_WRK_stdcustd.v_cust_td_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                        p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);
      p_WRK_stdcustd.v_cust_td_referral_custom.RELATIONSHIP_OFFICER := FN_GET_CUST_NAME('RO',
                                                                                        p_WRK_stdcustd.v_sttms_cust_account.CUST_AC_NO);

    END IF;
   --Referral Sampath Ends

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdcustd_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdcustd_custom;
