DECLARE
  l_cavw_entries           cavw_entries%rowtype;
  L_REVERSE_TAX_AMOUNT     ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  L_DRCR                   VARCHAR2(1);
  tb_AccHandoff            acpkss.tbl_AcHoff;
  L_VALUE_DATE             DATE;
  RELATED_CUSTOMER         VARCHAR2(20);
  L_NETTING_INDICATOR      VARCHAR2(1);
  L_MIS_HEAD               VARCHAR2(20);
  L_ICTM_TDPAYOUT_DETAILS  ICTM_TDPAYOUT_DETAILS%ROWTYPE;
  L_PAYOUTCASA_CCY         STTM_CUST_ACCOUNT.CCY%TYPE;
  L_RATE_FLAG              NUMBER;
  L_EXCH_RATE              ACTB_DAILY_LOG.EXCH_RATE%TYPE;
  L_LCY_AMOUNT             ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  L_FCY_AMOUNT             ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
  L_ICTB_ACC_PR            ICTB_ACC_PR%ROWTYPE;
  L_REVERSE_EXTRA_ACCRUALS ICTB_ENTRIES.ACCRUED_AMT%TYPE;
  P_ERR_CODE               VARCHAR2(100);
  P_PROD                   VARCHAR2(100);
  P_CCY                    VARCHAR2(100);
  P_ACC                    VARCHAR2(100);
  P_BRN                    VARCHAR2(100);
  P_ERR_PARAM              VARCHAR2(100);
BEGIN

  --TD Account currency is KHR and Payout CASA Currency is KHR

  GLOBAL.PR_INIT('001', 'SYSTEM');

  P_PROD := 'TEST';

  P_CCY := 'KHR'; --TD Account Currency

  IF P_CCY = 'KHR' THEN
    L_REVERSE_EXTRA_ACCRUALS := 25000;
  ELSE
    L_REVERSE_EXTRA_ACCRUALS := 1;
  END IF;

  P_ACC := '000113671'; --TD Account
  P_BRN := '001'; --TD branch

  --Get Rate
  IF P_CCY = 'KHR' THEN
    IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                            P_CCY, --KHR
                            GLOBAL.LCY, --USD
                            'STANDARD',
                            
                            'M',
                            
                            L_EXCH_RATE,
                            L_RATE_FLAG,
                            P_ERR_CODE) THEN
    
      DEBUG.PR_DEBUG('AC', 'FAILED IN GETTING EXCHANGE RATE ');
    
    ELSE
    
      DEBUG.PR_DEBUG('AC',
                     'DERIVED EXCHANGE RATE FOR SELL RATE=' || L_EXCH_RATE);
    
      DBMS_OUTPUT.PUT_LINE('L_EXCH_RATE=' || L_EXCH_RATE);
    
      --convert Amount using above Rate
      --derive lcy amount    
      IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                    P_CCY,
                                    GLOBAL.lcy,
                                    'STANDARD',
                                    'M',
                                    L_REVERSE_EXTRA_ACCRUALS, --khr amount FCYAMOUNT
                                    'Y',
                                    L_LCY_AMOUNT, --usd amount
                                    L_EXCH_RATE,
                                    P_ERR_CODE) THEN
        DEBUG.pr_debug('AC', 'Error while computing LCY ' || P_ERR_CODE);
        P_ERR_CODE := SQLCODE;
      
      ELSE
      
        DEBUG.PR_DEBUG('AC',
                       'DERIVED LCY AMOUNT FOR SELL RATE=' || L_LCY_AMOUNT);
        DBMS_OUTPUT.PUT_LINE('L_LCY_AMOUNT=' || L_LCY_AMOUNT);
      
      END IF;
    
    END IF;
  
  ELSE
  
    L_LCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;
  
    L_FCY_AMOUNT := NULL;
  
  END IF;

  TB_ACCHANDOFF(1) := NULL;

  TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
  TB_ACCHANDOFF(1).MODULE := 'IC';
  TB_ACCHANDOFF(1).AMOUNT_TAG := 'IACR'; --pls check
  TB_ACCHANDOFF(1).EVENT := 'IACR'; --pls check
  TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
  TB_ACCHANDOFF(1).TRN_CODE := 'TCS'; -- P_TXN_CODE; --pls check
  TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(1).TRN_REF_NO := '001SAMPTEST12345';
  TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

  TB_ACCHANDOFF(1).VALUE_DT := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
  TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
  TB_ACCHANDOFF(1).EXTERNAL_REF_NO := '001SAMPTEST12345';
  TB_ACCHANDOFF(1).NETTING_IND := 'N';
  TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

  TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

  TB_ACCHANDOFF(1).AC_NO := '344310001'; --debit TAX GL

  TB_ACCHANDOFF(1).AC_CCY := P_CCY;

  IF P_CCY = 'KHR' THEN
  
    TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(1).FCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;
    TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;
  
  ELSIF P_CCY = 'USD' THEN
  
    TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
    TB_ACCHANDOFF(1).EXCH_RATE := NULL;
  
  END IF;

  TB_ACCHANDOFF(1).PRODUCT := P_PROD;

  DEBUG.PR_DEBUG('AC', ' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
  DEBUG.PR_DEBUG('AC', ' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
  DEBUG.PR_DEBUG('AC', ' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
  DEBUG.PR_DEBUG('AC', ' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
  DEBUG.PR_DEBUG('AC',
                 ' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
  DEBUG.PR_DEBUG('AC', ' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
  DEBUG.PR_DEBUG('AC', ' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
  DEBUG.PR_DEBUG('AC', ' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
  DEBUG.PR_DEBUG('AC',
                 ' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
  DEBUG.PR_DEBUG('AC', ' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
  DEBUG.PR_DEBUG('AC',
                 ' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
  DEBUG.PR_DEBUG('AC',
                 ' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
  DEBUG.PR_DEBUG('AC',
                 ' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
  DEBUG.PR_DEBUG('AC',
                 ' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
  DEBUG.PR_DEBUG('AC', ' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
  DEBUG.PR_DEBUG('AC', ' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
  DEBUG.PR_DEBUG('AC', ' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
  DEBUG.PR_DEBUG('AC', ' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
  DEBUG.PR_DEBUG('AC', ' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
  DEBUG.PR_DEBUG('AC', ' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
  DEBUG.PR_DEBUG('AC', ' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

  DEBUG.PR_DEBUG('AC', ' Finished credit leg');

  TB_ACCHANDOFF(2) := NULL;

  TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
  TB_ACCHANDOFF(2).MODULE := 'IC';
  TB_ACCHANDOFF(2).AMOUNT_TAG := 'IACR'; --pls check
  TB_ACCHANDOFF(2).EVENT := 'IACR'; --pls check
  TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
  TB_ACCHANDOFF(2).TRN_CODE := 'TCS'; -- P_TXN_CODE; --pls check
  TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(2).TRN_REF_NO := '001SAMPTEST12345';
  TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

  TB_ACCHANDOFF(2).VALUE_DT := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
  TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
  TB_ACCHANDOFF(2).EXTERNAL_REF_NO := '001SAMPTEST12345';
  TB_ACCHANDOFF(2).NETTING_IND := 'N';
  TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

  TB_ACCHANDOFF(2).AC_BRANCH := P_BRN;

  TB_ACCHANDOFF(2).AC_NO := '623110001';

  TB_ACCHANDOFF(2).AC_CCY := P_CCY;

  IF P_CCY = 'KHR' THEN
  
    TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(2).FCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;
    TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;
  
  ELSIF P_CCY = 'USD' THEN
  
    TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
    TB_ACCHANDOFF(2).EXCH_RATE := NULL;
  
  END IF;

  TB_ACCHANDOFF(2).PRODUCT := P_PROD;

  DEBUG.PR_DEBUG('AC', ' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
  DEBUG.PR_DEBUG('AC', ' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
  DEBUG.PR_DEBUG('AC', ' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
  DEBUG.PR_DEBUG('AC', ' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
  DEBUG.PR_DEBUG('AC',
                 ' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
  DEBUG.PR_DEBUG('AC', ' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
  DEBUG.PR_DEBUG('AC', ' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
  DEBUG.PR_DEBUG('AC', ' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
  DEBUG.PR_DEBUG('AC',
                 ' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
  DEBUG.PR_DEBUG('AC', ' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
  DEBUG.PR_DEBUG('AC',
                 ' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
  DEBUG.PR_DEBUG('AC',
                 ' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
  DEBUG.PR_DEBUG('AC',
                 ' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
  DEBUG.PR_DEBUG('AC',
                 ' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
  DEBUG.PR_DEBUG('AC', ' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
  DEBUG.PR_DEBUG('AC', ' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
  DEBUG.PR_DEBUG('AC', ' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
  DEBUG.PR_DEBUG('AC', ' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
  DEBUG.PR_DEBUG('AC', ' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
  DEBUG.PR_DEBUG('AC', ' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
  DEBUG.PR_DEBUG('AC', ' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

  DEBUG.PR_DEBUG('AC', ' Finished debit leg');

  IF NOT ACPKSS.FN_ACHANDOFF(TB_ACCHANDOFF(2).TRN_REF_NO,
                             1,
                             GLOBAL.APPLICATION_DATE,
                             TB_ACCHANDOFF,
                             'B',
                             'N',
                             'N',
                             GLOBAL.USER_ID,
                             P_ERR_CODE,
                             P_ERR_PARAM) THEN
    DEBUG.PR_DEBUG('AC', 'Acc Handoff Failed with ' || P_ERR_CODE);
    DBMS_OUTPUT.PUT_LINE('Failed - ACC ENTRY=' || P_ERR_CODE);
  
  ELSE
  
    DEBUG.PR_DEBUG('AC', 'SUCCESS IN REVERSING THE EXTRA ACCRUALS');
    DBMS_OUTPUT.PUT_LINE('Success - ACC ENTRY');
  
  END IF;

END;

--select * from actb_Daily_log where trn_ref_no = '001SAMPTEST12345'
