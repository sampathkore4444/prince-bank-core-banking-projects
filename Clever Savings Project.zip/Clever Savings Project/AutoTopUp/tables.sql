-- Create table
create table IFTB_AUTO_TOP_UP_WS_LOG
(
  reference_no VARCHAR2(105) not null,
  invoke_date  TIMESTAMP(6),
  customer_no  VARCHAR2(105),
  cust_ac_no   VARCHAR2(105),
  req_type     VARCHAR2(25),
  req_msg      CLOB,
  res_msg      CLOB,
  status       CHAR(1),
  addl_info    VARCHAR2(105)
)
/
alter table IFTB_AUTO_TOP_UP_WS_LOG add primary key (REFERENCE_NO)
/ 

-- Create table
create table IFTB_AUTO_TOPUP_MASTER
(
  seq_no          VARCHAR2(105) not null,
  acc             VARCHAR2(105),
  brn             VARCHAR2(3),
  ccy             VARCHAR2(3),
  td_topup_ref_no VARCHAR2(20),
  pay_in_ofs_acc  VARCHAR2(105),
  pay_in_ofs_brn  VARCHAR2(3),
  top_up_date     DATE,
  top_up_amount   NUMBER,
  retry_count     NUMBER,
  status          CHAR(1)
)
alter table IFTB_AUTO_TOPUP_MASTER add primary key (SEQ_NO)
/ 
 -- Create sequence 
create sequence TRSQ_AUTO_TOP_UP_SEQ
minvalue 1
maxvalue 9999999999999
start with 1
increment by 1
cache 20;
