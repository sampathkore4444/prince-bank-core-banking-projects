CREATE OR REPLACE PROCEDURE PR_PROCESS_AUTO_TOPUP_UTILS(P_PARAM_NAMES VARCHAR2,
                                                        P_PARAM_VALS  VARCHAR2) AS

  L_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;

  L_RESPONSE VARCHAR2(32767) := '';
  L_XML      VARCHAR2(32767);
  L_REF      VARCHAR2(100);
  L_SEQ      VARCHAR2(100);

  CURSOR C1 IS
  
    SELECT *
      FROM STTM_CUST_ACCOUNT A
     WHERE A.ACCOUNT_CLASS = 'TOPUP' --pls check and include all 3 products
       AND A.RECORD_STAT = 'O'
       AND A.ONCE_AUTH = 'Y'
       AND 3 <= (SELECT NVL(B.RETRY_COUNT,0)
                   FROM IFTB_AUTO_TOPUP_MASTER B
                  WHERE B.CUSTOMER_NO = A.CUST_NO
                    AND B.CUST_AC_NO = A.CUST_AC_NO
                    --AND B.TOP_UP_DATE
                    ); --pls include retry count with date also

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'PR_PROCESS_AUTO_TOPUP_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_INSERT_WS_LOG(P_SEQ_NO    IN VARCHAR2,
                             P_INVOKE_TS IN TIMESTAMP,
                             P_CUST_NO   IN VARCHAR2,
                             P_AC_NO     IN VARCHAR2,
                             P_REQ_TYPE  IN VARCHAR2,
                             P_REQ_MSG   IN VARCHAR2,
                             P_ADDL_INFO IN VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    INSERT INTO IFTB_AUTO_TOP_UP_WS_LOG
      (REFERENCE_NO,
       INVOKE_DATE,
       CUSTOMER_NO,
       CUST_AC_NO,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_INVOKE_TS,
       P_CUST_NO,
       P_AC_NO,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_WS_LOG=' || SQLERRM);
  END PR_INSERT_WS_LOG;

  PROCEDURE PR_UPDATE_WS_LOG(P_SEQ_NO   IN VARCHAR2,
                             P_RESPONSE IN CLOB,
                             P_STATUS   IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF IFTB_AUTO_TOP_UP_WS_LOG');
  
    UPDATE IFTB_AUTO_TOP_UP_WS_LOG
       SET RES_MSG = P_RESPONSE, STATUS = P_STATUS
     WHERE REFERENCE_NO = P_SEQ_NO;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_WS_LOG=' || SQLERRM);
  END PR_UPDATE_WS_LOG;

  PROCEDURE PR_INSERT_TD_AUTO_TOPUP_MASTER(P_SEQ_NO      IN VARCHAR2,
                                           P_CUST_NO     IN VARCHAR2,
                                           P_CUST_ACC    IN VARCHAR2,
                                           P_TOP_UP_DATE IN DATE,
                                           P_TOP_UP_AMT  IN NUMBER,
                                           P_RETRY_COUNT IN NUMBER,
                                           P_STATUS      IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_INSERT_TD_AUTO_TOPUP_MASTER');
  
    INSERT INTO IFTB_AUTO_TOPUP_MASTER
      (reference_no,
       customer_no,
       cust_ac_no,
       TOP_UP_DATE,
       TOP_UP_AMOUNT,
       RETRY_COUNT,
       STATUS)
    VALUES
      (P_SEQ_NO,
       P_CUST_NO,
       P_CUST_ACC,
       P_TOP_UP_DATE,
       P_TOP_UP_AMT,
       P_RETRY_COUNT,
       P_STATUS);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_TD_AUTO_TOPUP_MASTER');
      DBG('ERROR CODE IN PR_INSERT_TD_AUTO_TOPUP_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_TD_AUTO_TOPUP_MASTER=' || SQLERRM);
  END PR_INSERT_TD_AUTO_TOPUP_MASTER;

  PROCEDURE PR_UPDATE_TD_AUTO_TOPUP_MASTER(P_SEQ_NO   IN VARCHAR2,
                                           P_CUST_NO  IN VARCHAR2,
                                           P_CUST_ACC IN VARCHAR2,
                                           P_STATUS   IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_TD_AUTO_TOPUP_MASTER');
  
    UPDATE IFTB_MIN_TO_MAJ_MASTER
       SET STATUS = P_STATUS
     WHERE REFERENCE_NO = P_SEQ_NO
       AND CUSTOMER_NO = P_CUST_NO
       AND CUST_AC_NO = P_CUST_ACC;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_TD_AUTO_TOPUP_MASTER');
      DBG('ERROR CODE IN PR_UPDATE_TD_AUTO_TOPUP_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_TD_AUTO_TOPUP_MASTER=' || SQLERRM);
  END PR_UPDATE_TD_AUTO_TOPUP_MASTER;

BEGIN

  FOR G IN C1 LOOP
  
    BEGIN
    
      SAVEPOINT A;
    
      GLOBAL.PR_INIT('000', 'SYSTEM');
    
      -- DBG('G.CUSTOMER_NO=' || G.CUSTOMER_NO);
      DBG('G.CUST_AC_NO=' || G.CUST_AC_NO);
      DBG('G.BRANCH_CODE=' || G.BRANCH_CODE);
    
      GLOBAL.PR_INIT(G.BRANCH_CODE, 'SYSTEM');
    
      --SEQUENCE GENERATION FOR MSGID AND REF ID
      SELECT TRSQ_AUTO_TOP_UP_SEQ.NEXTVAL INTO L_SEQ FROM DUAL;
    
      L_REF := SUBSTR(TO_CHAR(SYSDATE, 'YYMM'), 2) || LPAD(L_SEQ, 9, '0');
    
      --insert into master table
      PR_INSERT_TD_AUTO_TOPUP_MASTER(L_REF,
                                     G.CUST_NO,
                                     G.CUST_AC_NO,
                                     NULL, --G.TOP_UP_DATE, --pls check
                                     NULL, --G.TOP_UP_AMT, --pls check
                                     1, --RETRY_COUNT--pls check
                                     'N');
    
      L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSAccService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:CREATETDTOPUP_FSFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>EXTSYS</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>

            <fcub:MSGID></fcub:MSGID>

            <fcub:CORRELID></fcub:CORRELID>
            <fcub:USERID>SYSTEM</fcub:USERID>

            <fcub:ENTITY></fcub:ENTITY>
            <fcub:BRANCH>$L_BRN_CODE</fcub:BRANCH>

            <fcub:MODULEID>ST</fcub:MODULEID>
            <fcub:SERVICE>FCUBSAccService</fcub:SERVICE>
            <fcub:OPERATION>CreateTDTopUp</fcub:OPERATION>

            <fcub:SOURCE_OPERATION></fcub:SOURCE_OPERATION>

            <fcub:SOURCE_USERID></fcub:SOURCE_USERID>

            <fcub:DESTINATION></fcub:DESTINATION>

            <fcub:MULTITRIPID></fcub:MULTITRIPID>

            <fcub:FUNCTIONID></fcub:FUNCTIONID>

            <fcub:ACTION></fcub:ACTION>

            <fcub:MSGSTAT></fcub:MSGSTAT>

            <fcub:SNAPSHOTID></fcub:SNAPSHOTID>

            <fcub:PASSWORD></fcub:PASSWORD>

            <fcub:ADDL>
               <!--Zero or more repetitions:-->
               <fcub:PARAM>
                  <fcub:NAME></fcub:NAME>
                  <fcub:VALUE></fcub:VALUE>
               </fcub:PARAM>
            </fcub:ADDL>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Tdtopup-Detail-Full>

               <fcub:ACCOUNT_BRANCH>$L_BRN_CODE</fcub:ACCOUNT_BRANCH>
               <fcub:AC_NO>$L_CUST_TD_AC_NO</fcub:AC_NO>

               <fcub:CCY></fcub:CCY>

               <fcub:TOPUP_REF_NO></fcub:TOPUP_REF_NO>

               <fcub:TOPUP_AMT>$L_TOPUP_AMT</fcub:TOPUP_AMT>

               <fcub:VALUEDATE></fcub:VALUEDATE>

               <fcub:MATURITY_AMT></fcub:MATURITY_AMT>

               <fcub:INTEREST_RATE></fcub:INTEREST_RATE>

               <fcub:NARRATIVE></fcub:NARRATIVE>

               <fcub:ACC_DESC></fcub:ACC_DESC>

               <fcub:TOPUP_DATE></fcub:TOPUP_DATE>

               <fcub:TD_OPEN_DATE></fcub:TD_OPEN_DATE>

               <fcub:DAYS></fcub:DAYS>

               <fcub:MONTHS></fcub:MONTHS>

               <fcub:YEARS></fcub:YEARS>

               <fcub:MATDT></fcub:MATDT>

               <fcub:TDAMT_BEFORE_TOPUP></fcub:TDAMT_BEFORE_TOPUP>

               <fcub:TDAMT_AFTER_TOPUP></fcub:TDAMT_AFTER_TOPUP>

               <fcub:MATAMT_AFTER_TOPUP></fcub:MATAMT_AFTER_TOPUP>

               <fcub:INT_RATE_OPTION></fcub:INT_RATE_OPTION>

               <fcub:EXT_REFERENCE></fcub:EXT_REFERENCE>

               <fcub:CUSTOMER_NAME></fcub:CUSTOMER_NAME>

               <fcub:CUST_NO></fcub:CUST_NO>

               <fcub:REMITTER_NAME></fcub:REMITTER_NAME>

               <fcub:MAKER></fcub:MAKER>

               <fcub:MAKERSTAMP></fcub:MAKERSTAMP>

               <fcub:CHECKER></fcub:CHECKER>

               <fcub:CHECKERSTAMP></fcub:CHECKERSTAMP>

               <fcub:MODNO></fcub:MODNO>

               <fcub:TXNSTAT></fcub:TXNSTAT>

               <fcub:AUTHSTAT></fcub:AUTHSTAT>

               <fcub:Tdtopup-Payin>

                  <fcub:FUND_OPT></fcub:FUND_OPT>

                  <fcub:AMNT>$L_TOPUP_AMT</fcub:AMNT>

                  <fcub:OFFSET_BRN>$L_PAYIN_ACCOUNT_BRN</fcub:OFFSET_BRN>

                  <fcub:OFFSET_ACCOUNT>$L_PAYIN_ACCOUNT</fcub:OFFSET_ACCOUNT>

                  <fcub:PECENT></fcub:PECENT>
               </fcub:Tdtopup-Payin>
            </fcub:Tdtopup-Detail-Full>
         </fcub:FCUBS_BODY>
      </fcub:CREATETDTOPUP_FSFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
    
      L_XML := REPLACE(L_XML, '$L_BRN_CODE', L_CUST_ACCOUNT.BRANCH_CODE);
      L_XML := REPLACE(L_XML, '$L_CUST_TD_AC_NO', G.CUST_AC_NO);
      L_XML := REPLACE(L_XML, '$L_TOPUP_AMT', NULL); --pls check
      L_XML := REPLACE(L_XML, '$L_PAYIN_ACCOUNT_BRN', NULL); --pls check
      L_XML := REPLACE(L_XML, '$L_PAYIN_ACCOUNT', NULL); --pls check
    
      --log ws call
    
      PR_INSERT_WS_LOG(L_REF,
                       SYSTIMESTAMP,
                       G.CUST_NO,
                       G.CUST_AC_NO,
                       'NEW',
                       L_XML,
                       'TD Auto Top-up Call');
    
      --call
    
      L_RESPONSE := process_http('http://10.80.80.79:8007/' ||
                                 'FCUBSAccService/FCUBSAccService',
                                 L_XML,
                                 'text/xml;charset=utf-8');
    
      DBG('L_RESPONSE=' || L_RESPONSE);
    
      IF instr(L_RESPONSE, 'Record Successfully Saved and Authorized') > 0 THEN
      
        PR_UPDATE_TD_AUTO_TOPUP_MASTER(L_REF, G.CUST_NO, G.CUST_AC_NO, 'Y');
      
        PR_UPDATE_WS_LOG(L_REF, L_RESPONSE, 'S');
      
        COMMIT;
      
      ELSE
      
        PR_UPDATE_WS_LOG(L_REF, L_RESPONSE, 'F');
      
        ROLLBACK TO A;
      
        CONTINUE;
      
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN PR_PROCESS_AUTO_TOPUP');
        DBG('ERROR LINE NUMBER PR_PROCESS_AUTO_TOPUP=' ||
            DBMS_UTILITY.format_error_backtrace);
        DBG('ERROR CODE IN PR_PROCESS_AUTO_TOPUP=' || SQLCODE);
        DBG('ERROR MESSAGE in PR_PROCESS_AUTO_TOPUP=' || SQLERRM);
        CONTINUE;
    END;
  END LOOP;

END PR_PROCESS_AUTO_TOPUP_UTILS;
