/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2023, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : ICDREDMN_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = 'N';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_ICTMS_TDREDMPAYOUT_MASTER":"WAIVE_INTEREST~SUPPRESS_REDEMPTION_ADVICE~REDEM_REF_NO~BRANCH_CODE~ACC_NO~CUST_ID~CCY~ACC_DESC~ACC_AMT~ACTION_FLAG~TENOR_DD~TENOR_MM~TENOR_YY~NEXT_MAT_DATE~REDEMPTION_MODE~REDEMPTION_AMT~WAVE_PENALTY~MAKER_ID~CHECKER_ID~MAKER_DT_STAMP~CHECKER_DT_STAMP~AUTHSTAT~TXNSTAT~PRINCIPAL_AMOUNT~MATURITY_AMOUNT~INTEREST_RATE~ROLL_TENOR_PREF~CONTVARROLL~INTRATE_CUMAMT_REQD~TOTAL_AMT_REDEMPTION~NUM_CERTIFICATE_REDM~PRODUCT_CODE~REDEM_SEQ_NO~ORG_YEARS~ORG_MONTHS~ORG_DAYS~ADDFUNDS~ADDTIONALAMT~REDEM_INT_PAYOUT~WAIVE_INSURANCE_FEE~INSURANCE_AMOUNT","BLK_ICTMS_TDREDMPAYOUT_DETAILS":"PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~PERCENTAGE~REDMAMT~NARRATIVE~WAIVE~INSTNO~REDM_PAYOUT_COMP","BLK_DENOM_DEPOSIT":"CUST_AC_NO1~BRANCH_CODE1~CERTIFICATE_NO~REFERENCE_NO~CERTIFICATE_AMOUNT~BLOCK_OR_REDEM~CERTIFICATE_STATUS","BLK_REDEM_PAYIN_DTLS":"BRN~ACC~CCY~MMPAYOPT~MMTDAMT~MMOFFBRN~MMOFFACC~MMOFFCCY~REFNO~MMPERCENT~MMXRATE~SEQNO~CHQINSTNO~CLGBANK~CLGBRN~CLGPROD~CHQINSTDATE~DRAWEEACNO~ROUTINGNO~REDEMREFNO"};

var multipleEntryPageSize = {"BLK_ICTMS_TDREDMPAYOUT_DETAILS" :"15" ,"BLK_DENOM_DEPOSIT" :"15" ,"BLK_REDEM_PAYIN_DTLS" :"15" };

var multipleEntrySVBlocks = "";

var tabMEBlks = {"CVS_MAIN__TAB_MAIN":"BLK_ICTMS_TDREDMPAYOUT_DETAILS~BLK_REDEM_PAYIN_DTLS","CVS_DENOM__TAB_MAIN":"BLK_DENOM_DEPOSIT"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_ICTMS_TDREDMPAYOUT_MASTER">WAIVE_INTEREST~SUPPRESS_REDEMPTION_ADVICE~REDEM_REF_NO~BRANCH_CODE~ACC_NO~CUST_ID~CCY~ACC_DESC~ACC_AMT~ACTION_FLAG~TENOR_DD~TENOR_MM~TENOR_YY~NEXT_MAT_DATE~REDEMPTION_MODE~REDEMPTION_AMT~WAVE_PENALTY~MAKER_ID~CHECKER_ID~MAKER_DT_STAMP~CHECKER_DT_STAMP~AUTHSTAT~TXNSTAT~PRINCIPAL_AMOUNT~MATURITY_AMOUNT~INTEREST_RATE~ROLL_TENOR_PREF~CONTVARROLL~INTRATE_CUMAMT_REQD~TOTAL_AMT_REDEMPTION~NUM_CERTIFICATE_REDM~PRODUCT_CODE~REDEM_SEQ_NO~ORG_YEARS~ORG_MONTHS~ORG_DAYS~ADDFUNDS~ADDTIONALAMT~REDEM_INT_PAYOUT~WAIVE_INSURANCE_FEE~INSURANCE_AMOUNT</FN>'; 
msgxml += '      <FN PARENT="BLK_ICTMS_TDREDMPAYOUT_MASTER" RELATION_TYPE="N" TYPE="BLK_ICTMS_TDREDMPAYOUT_DETAILS">PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~PERCENTAGE~REDMAMT~NARRATIVE~WAIVE~INSTNO~REDM_PAYOUT_COMP</FN>'; 
msgxml += '      <FN PARENT="BLK_ICTMS_TDREDMPAYOUT_MASTER" RELATION_TYPE="N" TYPE="BLK_DENOM_DEPOSIT">CUST_AC_NO1~BRANCH_CODE1~CERTIFICATE_NO~REFERENCE_NO~CERTIFICATE_AMOUNT~BLOCK_OR_REDEM~CERTIFICATE_STATUS</FN>'; 
msgxml += '      <FN PARENT="BLK_ICTMS_TDREDMPAYOUT_MASTER" RELATION_TYPE="N" TYPE="BLK_REDEM_PAYIN_DTLS">BRN~ACC~CCY~MMPAYOPT~MMTDAMT~MMOFFBRN~MMOFFACC~MMOFFCCY~REFNO~MMPERCENT~MMXRATE~SEQNO~CHQINSTNO~CLGBANK~CLGBRN~CLGPROD~CHQINSTDATE~DRAWEEACNO~ROUTINGNO~REDEMREFNO</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "BLK_ICTMS_TDREDMPAYOUT_MASTER__BRANCH_CODE" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR SUMMARY SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml_sum=""; 
msgxml_sum += '    <FLD>'; 
msgxml_sum += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_SUMMARY">REDEM_REF_NO~BRANCH_CODE~ACC_NO~CUST_ID~MAKER_ID~CHECKER_ID~AUTH_STATUS~CONTRACT_STATUS</FN>'; 
msgxml_sum += '    </FLD>'; 

var detailFuncId = "ICDREDMN";
var defaultWhereClause = "CUST_ID IN (select a.customer_no from sttm_customer a where (a.group_code is not null and exists ( select 1 from stvws_user_group b where b.user_id = GLOBAL.user_id and b.group_code= a.group_code)) OR a.group_code is null ) and CUST_ID IN (select c.customer_no from sttm_customer c where (c.access_group is not null and exists ( select 1 from stvws_user_access d where d.user_id = GLOBAL.user_id and d.access_group = c.access_group)) OR c.access_group is null ) and branch_code = global.current_branch AND CUST_ID NOT IN (SELECT FC.CUSTOMER_NO FROM STTMS_CUST_FORGET_DETAIL FC WHERE PROCESS_STATUS = 'P')";
var defaultOrderByClause ="";
var multiBrnWhereClause ="CUST_ID IN (select c.customer_no from sttm_customer c where (c.access_group is not null and exists ( select 1 from stvws_user_access d where d.user_id = GLOBAL.user_id and d.access_group = c.access_group)) OR c.access_group is null ) and branch_code = global.current_branch AND CUST_ID NOT IN (SELECT FC.CUSTOMER_NO FROM STTMS_CUST_FORGET_DETAIL FC WHERE PROCESS_STATUS = 'P')";
var g_SummaryType ="S";
var g_SummaryBtnCount =0;
var g_SummaryBlock ="BLK_SUMMARY";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_ICTMS_TDREDMPAYOUT_MASTER" : "","BLK_ICTMS_TDREDMPAYOUT_DETAILS" : "BLK_ICTMS_TDREDMPAYOUT_MASTER~N","BLK_DENOM_DEPOSIT" : "BLK_ICTMS_TDREDMPAYOUT_MASTER~N","BLK_REDEM_PAYIN_DTLS" : "BLK_ICTMS_TDREDMPAYOUT_MASTER~N"}; 

 var dataSrcLocationArray = new Array("BLK_ICTMS_TDREDMPAYOUT_MASTER","BLK_ICTMS_TDREDMPAYOUT_DETAILS","BLK_DENOM_DEPOSIT","BLK_REDEM_PAYIN_DTLS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside ICDREDMN.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside ICDREDMN.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_ICTMS_TDREDMPAYOUT_MASTER__REDEM_REF_NO";
pkFields[0] = "BLK_ICTMS_TDREDMPAYOUT_MASTER__REDEM_REF_NO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_ICTMS_TDREDMPAYOUT_MASTER__ACC_NO__LOV_TERM_DEP_AC_NO":["BLK_ICTMS_TDREDMPAYOUT_MASTER__ACC_NO~BLK_ICTMS_TDREDMPAYOUT_MASTER__ACC_DESC~BLK_ICTMS_TDREDMPAYOUT_MASTER__CUST_ID~BLK_ICTMS_TDREDMPAYOUT_MASTER__CCY~BLK_ICTMS_TDREDMPAYOUT_MASTER__ACC_AMT~BLK_ICTMS_TDREDMPAYOUT_MASTER__CONTVARROLL~BLK_ICTMS_TDREDMPAYOUT_MASTER__REDEM_INT_PAYOUT~","BLK_ICTMS_TDREDMPAYOUT_MASTER__BRANCH_CODE!VARCHAR2","N~N~N~N~N~N~N",""],"BLK_ICTMS_TDREDMPAYOUT_MASTER__PRODUCT_CODE__LOV_PRODUCT_CODE":["BLK_ICTMS_TDREDMPAYOUT_MASTER__PRODUCT_CODE~~","","N~N",""],"BLK_ICTMS_TDREDMPAYOUT_DETAILS__OFFSET_ACC__LOV_OFFSETACC":["BLK_ICTMS_TDREDMPAYOUT_DETAILS__OFFSET_ACC~~BLK_ICTMS_TDREDMPAYOUT_DETAILS__OFFSET_BRN~~","BLK_ICTMS_TDREDMPAYOUT_MASTER__ACC_NO!~BLK_ICTMS_TDREDMPAYOUT_DETAILS__PAYOUTTYPE!~BLK_ICTMS_TDREDMPAYOUT_DETAILS__PAYOUTTYPE!~BLK_ICTMS_TDREDMPAYOUT_DETAILS__PAYOUTTYPE!","N~N~N~N",""],"BLK_REDEM_PAYIN_DTLS__MMOFFACC__LOV_PAYINOFFACC":["BLK_REDEM_PAYIN_DTLS__MMOFFACC~BLK_REDEM_PAYIN_DTLS__MMOFFBRN~BLK_REDEM_PAYIN_DTLS__MMOFFCCY~~~","BLK_REDEM_PAYIN_DTLS__MMPAYOPT!VARCHAR2","N~N~N~N~N",""],"BLK_REDEM_PAYIN_DTLS__CLGPROD__LOV_PAYINCLGPRD":["BLK_REDEM_PAYIN_DTLS__CLGPROD~~","","N~N",""],"BLK_REDEM_PAYIN_DTLS__ROUTINGNO__LOV_ROUTINGNO":["BLK_REDEM_PAYIN_DTLS__ROUTINGNO~BLK_REDEM_PAYIN_DTLS__CLGBRN~BLK_REDEM_PAYIN_DTLS__CLGBANK~","","N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_ICTMS_TDREDMPAYOUT_DETAILS","BLK_DENOM_DEPOSIT","BLK_REDEM_PAYIN_DTLS");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("ICCREFPO~BLK_ICTMS_TDREDMPAYOUT_MASTER"); 

 var CallFormRelat=new Array("ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO = ICTBS_REDEM_BY_TD.REDEM_REF_NO"); 

 var CallRelatType= new Array("1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["ICDREDMN"]="KERNEL";
ArrPrntFunc["ICDREDMN"]="";
ArrPrntOrigin["ICDREDMN"]="";
ArrRoutingType["ICDREDMN"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["ICDREDMN"]="N";
ArrCustomModified["ICDREDMN"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"ICCREFPO":""};
var scrArgSource = {"ICCREFPO":""};
var scrArgVals = {"ICCREFPO":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"ICCREFPO":""};
var dpndntOnSrvs = {"ICCREFPO":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"2"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------