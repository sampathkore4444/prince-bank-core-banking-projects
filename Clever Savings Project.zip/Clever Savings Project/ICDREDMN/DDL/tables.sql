CREATE TABLE ICTB_TD_REDEM_MASTER_CUSTOM(redem_ref_no varchar2(16) primary key,branch_code varchar2(3),acc_no varchar2(20),cust_id varchar2(9), WAIVE_INSURANCE_FEE CHAR(1), INSURANCE_AMOUNT NUMBER)
