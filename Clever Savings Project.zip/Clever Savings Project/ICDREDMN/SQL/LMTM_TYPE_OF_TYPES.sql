insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CLESAV_INSFEE_KH', 'Clever Savings plan Insurance Fee in KHR', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 20:32:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 20:32:49', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CLESAV_INSFEE_US', 'Clever Savings plan Insurance Fee in USD', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 20:29:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 20:29:17', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('CLEVERSAV_MINTOP', 'Clever Savings Minimum Top Up Amount in USD Amount', 'SAMPATH2', 'SAMPATH2', to_date('05-03-2023 11:24:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-03-2023 11:24:46', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
