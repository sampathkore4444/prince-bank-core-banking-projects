CREATE OR REPLACE PACKAGE BODY icpks_icdredmn_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : icpks_icdredmn_main.sql
     **
     ** Module     : Interest And Charges
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Original_Action    VARCHAR2(100);
   g_Action_Code    VARCHAR2(100);
   g_Addl_Info       Cspks_Req_Global.Ty_Addl_Info;
   g_Ui_Name            VARCHAR2(50) := 'ICDREDMN';
   g_Req_Key                 VARCHAR2(32767);
   g_icdredmn         icpks_icdredmn_Main.Ty_icdredmn;
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Kernel    BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'icpks_icdredmn_Main ==>'||p_Msg;
         Debug.Pr_Debug('IC' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'ICDREDMN';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      icpks_icdredmn_Kernel.Pr_Skip_Handler (P_Stage);
      icpks_icdredmn_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Kernel IS
   BEGIN
      g_Skip_Kernel := TRUE;
   END Pr_Set_Skip_Kernel;
   PROCEDURE Pr_Set_Activate_Kernel IS
   BEGIN
      g_Skip_Kernel := FALSE;
   END Pr_Set_Activate_Kernel;
   FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type = Cspks_Req_Global.p_Kernel THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Kernel;
      END IF;
   END  Fn_Skip_Kernel;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION  Fn_Get_Original_Action RETURN VARCHAR2 IS
   BEGIN
      RETURN G_Original_Action;
   END  Fn_Get_Original_Action;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_icdredmn       IN   OUT icpks_icdredmn_Main.ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_5    NUMBER;
      l_Bnd_Cntr_5    NUMBER;
      l_Dsn_Rec_Cnt_6    NUMBER;
      l_Bnd_Cntr_6    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_ICTMS_TDREDMPAYOUT_MASTER' THEN
            p_icdredmn.v_ictbs_tdredemption_master.WAIVE_INTEREST := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.SUPPRESS_REDEMPTION_ADVICE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.REDEM_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.BRANCH_CODE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ACC_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.CUST_ID := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.CCY := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ACC_DESC := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ACC_AMT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.TENOR_DD := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.TENOR_MM := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.TENOR_YY := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_icdredmn.v_ictbs_tdredemption_master.NEXT_MAT_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_icdredmn.v_ictbs_tdredemption_master.NEXT_MAT_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_MODE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_AMT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.WAVE_PENALTY := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.MAKER_ID := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.CHECKER_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_icdredmn.v_ictbs_tdredemption_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_icdredmn.v_ictbs_tdredemption_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_icdredmn.v_ictbs_tdredemption_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_icdredmn.v_ictbs_tdredemption_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_icdredmn.v_ictbs_tdredemption_master.AUTH_STATUS := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.CONTRACT_STATUS := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_cstb_ui_columns.CHAR_FIELD1 := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.MATURITY_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.INTEREST_RATE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ROLL_TENOR_PREF := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.CONT_VAR_ROLL := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.INTRATE_CUMAMT_REQD := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_cstb_ui_columns.CHAR_FIELD80 := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_cstb_ui_columns.CHAR_FIELD81 := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.PRODUCT_CODE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.REDEM_SEQ_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ORG_YEARS := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ORG_MONTHS := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ORG_DAYS := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ADD_FUNDS := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.ADDITIONAL_AMT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictbs_tdredemption_master.REDEM_INT_PAYOUT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_td_redem_master_custom.WAIVE_INSURANCE_FEE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_td_redem_master_custom.INSURANCE_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_td_redem_master_custom.redem_ref_no :=p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
         ELSIF  l_Node = 'BLK_ICTMS_TDREDMPAYOUT_DETAILS' THEN
            l_Dsn_Rec_Cnt_2 :=  p_icdredmn.v_tdredmpayout_details.count +1 ;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).PAYOUTTYPE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).OFFSET_BRN := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).OFFSET_ACC := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).PERCENTAGE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).REDMAMT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).NARRATIVE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).WAIVE_ISSUE_CHG := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).INSTNO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).REDM_PAYOUT_COMP := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).redem_ref_no :=p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
         ELSIF  l_Node = 'BLK_DENOM_DEPOSIT' THEN
            l_Dsn_Rec_Cnt_5 :=  p_icdredmn.v_sttms_denom_redmn_blk.count +1 ;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).CUST_AC_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).BRANCH_CODE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).CERTIFICATE_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).REFERENCE_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).CERTIFICATE_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).BLOCK_OR_REDEM := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).CERTIFICATE_STATUS := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).reference_no :=p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).cust_ac_no :=p_icdredmn.v_ictbs_tdredemption_master.acc_no;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).branch_code :=p_icdredmn.v_ictbs_tdredemption_master.branch_code;
         ELSIF  l_Node = 'BLK_REDEM_PAYIN_DTLS' THEN
            l_Dsn_Rec_Cnt_6 :=  p_icdredmn.v_ictms_tdredpayin_details.count +1 ;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).BRN := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).ACC := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CCY := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_PAYOPT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_TDAMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_OFFSET_BRN := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_TDOFFSET_ACC := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_TDOFFSET_CCY := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).REFERENCE_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_PERCENTAGE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULITMODE_XRATE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).SEQNO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CHQ_INSTUMENTNO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CLG_BANK_CODE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CLG_BRANCH_CODE := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CLG_PRODUCT_CODE := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CHQ_INSTRUMENT_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CHQ_INSTRUMENT_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).DRAWEE_AC_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).ROUTING_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).REDEM_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).redem_ref_no :=p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
         ELSIF  l_Node = '' THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='ICCREFPO_'||p_Action_Code;
            END IF;
            p_icdredmn.Ty_iccrefpo := NULL;
            l_key_vals :='REDEM_REF_NO'||'>'||p_icdredmn.v_ictbs_tdredemption_master.REDEM_REF_NO;
            Dbg('Calling Icpks_Iccrefpo_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Icpks_Iccrefpo_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'ICCREFPO',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_icdredmn.Ty_iccrefpo,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Icpks_Iccrefpo_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_icdredmn.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_icdredmn       IN   OUT icpks_icdredmn_Main.ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_5    NUMBER;
      l_Bnd_Cntr_5    NUMBER;
      l_Dsn_Rec_Cnt_6    NUMBER;
      l_Bnd_Cntr_6    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_ICTMS_TDREDMPAYOUT_MASTER','Ictms-Tdredmpayout-Master-Full','Ictms-Tdredmpayout-Master-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key IN( 'WAIVEINT','WAIVE_INTEREST')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.WAIVE_INTEREST := l_Val;
               ELSIF l_Key = 'SUPPRESS_REDEMPTION_ADVICE' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.SUPPRESS_REDEMPTION_ADVICE := l_Val;
               ELSIF l_Key = 'REDEM_REF_NO' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.REDEM_REF_NO := l_Val;
               ELSIF l_Key IN( 'ACBRN','BRANCH_CODE')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.BRANCH_CODE := l_Val;
               ELSIF l_Key IN( 'TERM_ACNO','ACC_NO')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ACC_NO := l_Val;
               ELSIF l_Key = 'CUST_ID' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.CUST_ID := l_Val;
               ELSIF l_Key IN( 'ACCOUNT_CCY','CCY')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.CCY := l_Val;
               ELSIF l_Key IN( 'AC_DESC','ACC_DESC')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ACC_DESC := l_Val;
               ELSIF l_Key IN( 'CUST_ACC_BAL','ACC_AMT')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ACC_AMT := l_Val;
               ELSIF l_Key = 'ACTION_FLAG' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG := l_Val;
               ELSIF l_Key IN( 'DAYS','TENOR_DD')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.TENOR_DD := l_Val;
               ELSIF l_Key IN( 'DEFAULT_MONTHS1','TENOR_MM')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.TENOR_MM := l_Val;
               ELSIF l_Key IN( 'YEARS_SS','TENOR_YY')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.TENOR_YY := l_Val;
               ELSIF l_Key = 'NEXT_MAT_DATE' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_icdredmn.v_ictbs_tdredemption_master.NEXT_MAT_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_icdredmn.v_ictbs_tdredemption_master.NEXT_MAT_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key IN( 'REDEM_MODE','REDEMPTION_MODE')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_MODE := l_Val;
               ELSIF l_Key = 'REDEMPTION_AMT' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_AMT := l_Val;
               ELSIF l_Key IN( 'WAIVE_PENALTY','WAVE_PENALTY')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.WAVE_PENALTY := l_Val;
               ELSIF l_Key IN( 'INPTBY','MAKER_ID')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.MAKER_ID := l_Val;
               ELSIF l_Key IN( 'CHECHKERID','CHECKER_ID')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.CHECKER_ID := l_Val;
               ELSIF l_Key IN( 'MAKDTTIME','MAKER_DT_STAMP')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_icdredmn.v_ictbs_tdredemption_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_icdredmn.v_ictbs_tdredemption_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key IN( 'CHECKERDT','CHECKER_DT_STAMP')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_icdredmn.v_ictbs_tdredemption_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_icdredmn.v_ictbs_tdredemption_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'AUTHSTAT' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.AUTH_STATUS := l_Val;
               ELSIF l_Key = 'TXNSTAT' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.CONTRACT_STATUS := l_Val;
               ELSIF l_Key IN( 'PRN_AMT','PRINCIPAL_AMOUNT')  THEN
                  p_icdredmn.v_cstb_ui_columns.CHAR_FIELD1 := l_Val;
               ELSIF l_Key IN( 'MATURITY_AMT','MATURITY_AMOUNT')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.MATURITY_AMOUNT := l_Val;
               ELSIF l_Key = 'INTEREST_RATE' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.INTEREST_RATE := l_Val;
               ELSIF l_Key IN( 'ROLLTENOR','ROLL_TENOR_PREF')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ROLL_TENOR_PREF := l_Val;
               ELSIF l_Key = 'CONTVARROLL' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.CONT_VAR_ROLL := l_Val;
               ELSIF l_Key = 'INTRATE_CUMAMT_REQD' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.INTRATE_CUMAMT_REQD := l_Val;
               ELSIF l_Key IN( 'REDEMAMT','TOTAL_AMT_REDEMPTION')  THEN
                  p_icdredmn.v_cstb_ui_columns.CHAR_FIELD80 := l_Val;
               ELSIF l_Key = 'NUM_CERTIFICATE_REDM' THEN
                  p_icdredmn.v_cstb_ui_columns.CHAR_FIELD81 := l_Val;
               ELSIF l_Key = 'PRODUCT_CODE' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.PRODUCT_CODE := l_Val;
               ELSIF l_Key = 'REDEM_SEQ_NO' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.REDEM_SEQ_NO := l_Val;
               ELSIF l_Key = 'ORG_YEARS' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ORG_YEARS := l_Val;
               ELSIF l_Key = 'ORG_MONTHS' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ORG_MONTHS := l_Val;
               ELSIF l_Key = 'ORG_DAYS' THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ORG_DAYS := l_Val;
               ELSIF l_Key IN( 'ADDFNDS','ADDFUNDS')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ADD_FUNDS := l_Val;
               ELSIF l_Key IN( 'ADD_AMT','ADDTIONALAMT')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.ADDITIONAL_AMT := l_Val;
               ELSIF l_Key IN( 'REDM_INT_PAYOUT','REDEM_INT_PAYOUT')  THEN
                  p_icdredmn.v_ictbs_tdredemption_master.REDEM_INT_PAYOUT := l_Val;
               ELSIF l_Key = 'WAIVE_INSURANCE_FEE' THEN
                  p_icdredmn.v_td_redem_master_custom.WAIVE_INSURANCE_FEE := l_Val;
               ELSIF l_Key = 'INSURANCE_AMOUNT' THEN
                  p_icdredmn.v_td_redem_master_custom.INSURANCE_AMOUNT := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_icdredmn.v_td_redem_master_custom.redem_ref_no :=p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
         ELSIF  l_Node IN ( 'BLK_ICTMS_TDREDMPAYOUT_DETAILS','Ictms-Tdredmpayout-Details') THEN
            l_Dsn_Rec_Cnt_2 :=  p_icdredmn.v_tdredmpayout_details.count +1 ;
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'PAYOUTTYPE' THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).PAYOUTTYPE := l_Val;
               ELSIF l_Key = 'OFFSET_BRN' THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).OFFSET_BRN := l_Val;
               ELSIF l_Key = 'OFFSET_ACC' THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).OFFSET_ACC := l_Val;
               ELSIF l_Key = 'PERCENTAGE' THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).PERCENTAGE := l_Val;
               ELSIF l_Key = 'REDMAMT' THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).REDMAMT := l_Val;
               ELSIF l_Key = 'NARRATIVE' THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).NARRATIVE := l_Val;
               ELSIF l_Key IN( 'WAIVEISSUCHG','WAIVE')  THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).WAIVE_ISSUE_CHG := l_Val;
               ELSIF l_Key = 'INSTNO' THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).INSTNO := l_Val;
               ELSIF l_Key = 'REDM_PAYOUT_COMP' THEN
                  p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).REDM_PAYOUT_COMP := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).redem_ref_no :=p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
         ELSIF  l_Node IN ( 'BLK_DENOM_DEPOSIT','Denom-Deposit') THEN
            l_Dsn_Rec_Cnt_5 :=  p_icdredmn.v_sttms_denom_redmn_blk.count +1 ;
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'CUST_AC_NO1' THEN
                  p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).CUST_AC_NO := l_Val;
               ELSIF l_Key = 'BRANCH_CODE1' THEN
                  p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).BRANCH_CODE := l_Val;
               ELSIF l_Key = 'CERTIFICATE_NO' THEN
                  p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).CERTIFICATE_NO := l_Val;
               ELSIF l_Key = 'REFERENCE_NO' THEN
                  p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).REFERENCE_NO := l_Val;
               ELSIF l_Key = 'CERTIFICATE_AMOUNT' THEN
                  p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).CERTIFICATE_AMOUNT := l_Val;
               ELSIF l_Key IN( 'REDEEM','BLOCK_OR_REDEM')  THEN
                  p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).BLOCK_OR_REDEM := l_Val;
               ELSIF l_Key = 'CERTIFICATE_STATUS' THEN
                  p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).CERTIFICATE_STATUS := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).reference_no :=p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).cust_ac_no :=p_icdredmn.v_ictbs_tdredemption_master.acc_no;
            p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).branch_code :=p_icdredmn.v_ictbs_tdredemption_master.branch_code;
         ELSIF  l_Node IN ( 'BLK_REDEM_PAYIN_DTLS','Redem-Payin-Dtls') THEN
            l_Dsn_Rec_Cnt_6 :=  p_icdredmn.v_ictms_tdredpayin_details.count +1 ;
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'BRN' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).BRN := l_Val;
               ELSIF l_Key = 'ACC' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).ACC := l_Val;
               ELSIF l_Key = 'CCY' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CCY := l_Val;
               ELSIF l_Key IN( 'PAYIN_OPTION','MMPAYOPT')  THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_PAYOPT := l_Val;
               ELSIF l_Key IN( 'AMT','MMTDAMT')  THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_TDAMOUNT := l_Val;
               ELSIF l_Key IN( 'OFFSET_BRN','MMOFFBRN')  THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_OFFSET_BRN := l_Val;
               ELSIF l_Key IN( 'OFFSET_ACC','MMOFFACC')  THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_TDOFFSET_ACC := l_Val;
               ELSIF l_Key = 'MMOFFCCY' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_TDOFFSET_CCY := l_Val;
               ELSIF l_Key = 'REFNO' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).REFERENCE_NO := l_Val;
               ELSIF l_Key IN( 'PECENT','MMPERCENT')  THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULTIMODE_PERCENTAGE := l_Val;
               ELSIF l_Key = 'MMXRATE' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).MULITMODE_XRATE := l_Val;
               ELSIF l_Key = 'SEQNO' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).SEQNO := l_Val;
               ELSIF l_Key = 'CHQINSTNO' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CHQ_INSTUMENTNO := l_Val;
               ELSIF l_Key = 'CLGBANK' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CLG_BANK_CODE := l_Val;
               ELSIF l_Key = 'CLGBRN' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CLG_BRANCH_CODE := l_Val;
               ELSIF l_Key IN( 'PRODUCT_F','CLGPROD')  THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CLG_PRODUCT_CODE := l_Val;
               ELSIF l_Key IN( 'CHQ_ADTE','CHQINSTDATE')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CHQ_INSTRUMENT_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).CHQ_INSTRUMENT_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key IN( 'DRAWEE_ACCOUNT','DRAWEEACNO')  THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).DRAWEE_AC_NO := l_Val;
               ELSIF l_Key IN( 'ROUTING_NO','ROUTINGNO')  THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).ROUTING_NO := l_Val;
               ELSIF l_Key = 'REDEMREFNO' THEN
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).REDEM_REF_NO := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).redem_ref_no :=p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
         ELSIF  l_Node IN ( '','') THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='ICCREFPO_'||p_Action_Code;
            END IF;
            p_icdredmn.Ty_iccrefpo := NULL;
            l_key_vals :='REDEM_REF_NO'||'>'||p_icdredmn.v_ictbs_tdredemption_master.REDEM_REF_NO;
            Dbg('Calling Icpks_Iccrefpo_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Icpks_Iccrefpo_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'ICCREFPO',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_icdredmn.Ty_iccrefpo,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Icpks_Iccrefpo_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_icdredmn.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_icdredmn          IN icpks_icdredmn_Main.ty_icdredmn,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_5    NUMBER;
      l_Bnd_Cntr_5    NUMBER;
      l_Dsn_Rec_Cnt_6    NUMBER;
      l_Bnd_Cntr_6    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_1_Lvl_Counter := 0;
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_ICTMS_TDREDMPAYOUT_MASTER',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','WAIVE_INTEREST',p_icdredmn.v_ictbs_tdredemption_master.waive_interest);
      Cspks_Req_Global.Pr_Write('V','SUPPRESS_REDEMPTION_ADVICE',p_icdredmn.v_ictbs_tdredemption_master.suppress_redemption_advice);
      Cspks_Req_Global.Pr_Write('V','REDEM_REF_NO',p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no);
      Cspks_Req_Global.Pr_Write('V','BRANCH_CODE',p_icdredmn.v_ictbs_tdredemption_master.branch_code);
      Cspks_Req_Global.Pr_Write('V','ACC_NO',p_icdredmn.v_ictbs_tdredemption_master.acc_no);
      Cspks_Req_Global.Pr_Write('V','CUST_ID',p_icdredmn.v_ictbs_tdredemption_master.cust_id);
      Cspks_Req_Global.Pr_Write('V','CCY',p_icdredmn.v_ictbs_tdredemption_master.ccy);
      Cspks_Req_Global.Pr_Write('V','ACC_DESC',p_icdredmn.v_ictbs_tdredemption_master.acc_desc);
      Cspks_Req_Global.Pr_Write('V','ACC_AMT',p_icdredmn.v_ictbs_tdredemption_master.acc_amt);
      Cspks_Req_Global.Pr_Write('V','ACTION_FLAG',p_icdredmn.v_ictbs_tdredemption_master.action_flag);
      Cspks_Req_Global.Pr_Write('V','TENOR_DD',p_icdredmn.v_ictbs_tdredemption_master.tenor_dd);
      Cspks_Req_Global.Pr_Write('V','TENOR_MM',p_icdredmn.v_ictbs_tdredemption_master.tenor_mm);
      Cspks_Req_Global.Pr_Write('V','TENOR_YY',p_icdredmn.v_ictbs_tdredemption_master.tenor_yy);
      IF trunc(p_icdredmn.v_ictbs_tdredemption_master.next_mat_date) <>
            p_icdredmn.v_ictbs_tdredemption_master.next_mat_date THEN
         l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.next_mat_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.next_mat_date,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','NEXT_MAT_DATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','REDEMPTION_MODE',p_icdredmn.v_ictbs_tdredemption_master.redemption_mode);
      Cspks_Req_Global.Pr_Write('V','REDEMPTION_AMT',p_icdredmn.v_ictbs_tdredemption_master.redemption_amt);
      Cspks_Req_Global.Pr_Write('V','WAVE_PENALTY',p_icdredmn.v_ictbs_tdredemption_master.wave_penalty);
      Cspks_Req_Global.Pr_Write('V','MAKER_ID',p_icdredmn.v_ictbs_tdredemption_master.maker_id);
      Cspks_Req_Global.Pr_Write('V','CHECKER_ID',p_icdredmn.v_ictbs_tdredemption_master.checker_id);
      IF trunc(p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp) <>
            p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','MAKER_DT_STAMP',l_Date_Val);
      IF trunc(p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp) <>
            p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','CHECKER_DT_STAMP',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','AUTHSTAT',p_icdredmn.v_ictbs_tdredemption_master.auth_status);
      Cspks_Req_Global.Pr_Write('V','TXNSTAT',p_icdredmn.v_ictbs_tdredemption_master.contract_status);
      Cspks_Req_Global.Pr_Write('V','PRINCIPAL_AMOUNT',p_icdredmn.v_cstb_ui_columns.char_field1);
      Cspks_Req_Global.Pr_Write('V','MATURITY_AMOUNT',p_icdredmn.v_ictbs_tdredemption_master.maturity_amount);
      Cspks_Req_Global.Pr_Write('V','INTEREST_RATE',p_icdredmn.v_ictbs_tdredemption_master.interest_rate);
      Cspks_Req_Global.Pr_Write('V','ROLL_TENOR_PREF',p_icdredmn.v_ictbs_tdredemption_master.roll_tenor_pref);
      Cspks_Req_Global.Pr_Write('V','CONTVARROLL',p_icdredmn.v_ictbs_tdredemption_master.cont_var_roll);
      Cspks_Req_Global.Pr_Write('V','INTRATE_CUMAMT_REQD',p_icdredmn.v_ictbs_tdredemption_master.intrate_cumamt_reqd);
      Cspks_Req_Global.Pr_Write('V','TOTAL_AMT_REDEMPTION',p_icdredmn.v_cstb_ui_columns.char_field80);
      Cspks_Req_Global.Pr_Write('V','NUM_CERTIFICATE_REDM',p_icdredmn.v_cstb_ui_columns.char_field81);
      Cspks_Req_Global.Pr_Write('V','PRODUCT_CODE',p_icdredmn.v_ictbs_tdredemption_master.product_code);
      Cspks_Req_Global.Pr_Write('V','REDEM_SEQ_NO',p_icdredmn.v_ictbs_tdredemption_master.redem_seq_no);
      Cspks_Req_Global.Pr_Write('V','ORG_YEARS',p_icdredmn.v_ictbs_tdredemption_master.org_years);
      Cspks_Req_Global.Pr_Write('V','ORG_MONTHS',p_icdredmn.v_ictbs_tdredemption_master.org_months);
      Cspks_Req_Global.Pr_Write('V','ORG_DAYS',p_icdredmn.v_ictbs_tdredemption_master.org_days);
      Cspks_Req_Global.Pr_Write('V','ADDFUNDS',p_icdredmn.v_ictbs_tdredemption_master.add_funds);
      Cspks_Req_Global.Pr_Write('V','ADDTIONALAMT',p_icdredmn.v_ictbs_tdredemption_master.additional_amt);
      Cspks_Req_Global.Pr_Write('V','REDEM_INT_PAYOUT',p_icdredmn.v_ictbs_tdredemption_master.redem_int_payout);
      Cspks_Req_Global.Pr_Write('V','WAIVE_INSURANCE_FEE',p_icdredmn.v_td_redem_master_custom.waive_insurance_fee);
      Cspks_Req_Global.Pr_Write('V','INSURANCE_AMOUNT',p_icdredmn.v_td_redem_master_custom.insurance_amount);

      --Dbg('Building Childs Of :BLK_ICTMS_TDREDMPAYOUT_MASTER..');
      l_Dsn_Rec_Cnt_2 := 0;
      IF p_icdredmn.v_tdredmpayout_details.COUNT > 0 THEN
         FOR i_2 IN  1..p_icdredmn.v_tdredmpayout_details.COUNT LOOP
            l_Dsn_Rec_Cnt_2 := i_2;
            l_Master_Childs  :=  l_Master_Childs +1;
            l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','BLK_ICTMS_TDREDMPAYOUT_DETAILS',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','PAYOUTTYPE',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).payouttype);
            Cspks_Req_Global.Pr_Write('V','OFFSET_BRN',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).offset_brn);
            Cspks_Req_Global.Pr_Write('V','OFFSET_ACC',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).offset_acc);
            Cspks_Req_Global.Pr_Write('V','PERCENTAGE',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).percentage);
            Cspks_Req_Global.Pr_Write('V','REDMAMT',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).redmamt);
            Cspks_Req_Global.Pr_Write('V','NARRATIVE',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).narrative);
            Cspks_Req_Global.Pr_Write('V','WAIVE',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).waive_issue_chg);
            Cspks_Req_Global.Pr_Write('V','INSTNO',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).instno);
            Cspks_Req_Global.Pr_Write('V','REDM_PAYOUT_COMP',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).redm_payout_comp);
         END LOOP;
      END IF;
      l_Dsn_Rec_Cnt_5 := 0;
      IF p_icdredmn.v_sttms_denom_redmn_blk.COUNT > 0 THEN
         FOR i_5 IN  1..p_icdredmn.v_sttms_denom_redmn_blk.COUNT LOOP
            l_Dsn_Rec_Cnt_5 := i_5;
            l_Master_Childs  :=  l_Master_Childs +1;
            l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','BLK_DENOM_DEPOSIT',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','CUST_AC_NO1',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).cust_ac_no);
            Cspks_Req_Global.Pr_Write('V','BRANCH_CODE1',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).branch_code);
            Cspks_Req_Global.Pr_Write('V','CERTIFICATE_NO',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).certificate_no);
            Cspks_Req_Global.Pr_Write('V','REFERENCE_NO',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).reference_no);
            Cspks_Req_Global.Pr_Write('V','CERTIFICATE_AMOUNT',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).certificate_amount);
            Cspks_Req_Global.Pr_Write('V','BLOCK_OR_REDEM',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).block_or_redem);
            Cspks_Req_Global.Pr_Write('V','CERTIFICATE_STATUS',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).certificate_status);
         END LOOP;
      END IF;
      l_Dsn_Rec_Cnt_6 := 0;
      IF p_icdredmn.v_ictms_tdredpayin_details.COUNT > 0 THEN
         FOR i_6 IN  1..p_icdredmn.v_ictms_tdredpayin_details.COUNT LOOP
            l_Dsn_Rec_Cnt_6 := i_6;
            l_Master_Childs  :=  l_Master_Childs +1;
            l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','BLK_REDEM_PAYIN_DTLS',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','BRN',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).brn);
            Cspks_Req_Global.Pr_Write('V','ACC',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).acc);
            Cspks_Req_Global.Pr_Write('V','CCY',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).ccy);
            Cspks_Req_Global.Pr_Write('V','MMPAYOPT',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_payopt);
            Cspks_Req_Global.Pr_Write('V','MMTDAMT',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_tdamount);
            Cspks_Req_Global.Pr_Write('V','MMOFFBRN',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_offset_brn);
            Cspks_Req_Global.Pr_Write('V','MMOFFACC',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_tdoffset_acc);
            Cspks_Req_Global.Pr_Write('V','MMOFFCCY',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_tdoffset_ccy);
            Cspks_Req_Global.Pr_Write('V','REFNO',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).reference_no);
            Cspks_Req_Global.Pr_Write('V','MMPERCENT',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_percentage);
            Cspks_Req_Global.Pr_Write('V','MMXRATE',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).mulitmode_xrate);
            Cspks_Req_Global.Pr_Write('V','SEQNO',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).seqno);
            Cspks_Req_Global.Pr_Write('V','CHQINSTNO',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instumentno);
            Cspks_Req_Global.Pr_Write('V','CLGBANK',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).clg_bank_code);
            Cspks_Req_Global.Pr_Write('V','CLGBRN',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).clg_branch_code);
            Cspks_Req_Global.Pr_Write('V','CLGPROD',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).clg_product_code);
            IF trunc(p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instrument_date) <>
                  p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instrument_date THEN
               l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instrument_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instrument_date,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','CHQINSTDATE',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','DRAWEEACNO',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).drawee_ac_no);
            Cspks_Req_Global.Pr_Write('V','ROUTINGNO',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).routing_no);
            Cspks_Req_Global.Pr_Write('V','REDEMREFNO',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).redem_ref_no);
         END LOOP;
      END IF;
      l_Level_Format      := l_0_Lvl_Counter;
      l_Cntr_Before := l_Master_Childs;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='ICCREFPO_'||p_Action_Code;
      END IF;
      IF NOT Icpks_Iccrefpo_Main.Fn_Build_Ts_List(p_source,
         l_Source_Operation,
         'ICCREFPO',
         p_Action_Code,
         p_Function_Id,
         p_icdredmn.ty_iccrefpo,
         l_Level_Format,
         l_1_Lvl_Counter,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         RETURN FALSE;
      END IF;
      l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_icdredmn          IN icpks_icdredmn_Main.ty_icdredmn,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_5    NUMBER;
      l_Bnd_Cntr_5    NUMBER;
      l_Dsn_Rec_Cnt_6    NUMBER;
      l_Bnd_Cntr_6    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF ( (  p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no IS NOT NULL 
          ) OR(  p_icdredmn.v_cstb_ui_columns.char_field1 IS NOT NULL 
          ) OR(  p_icdredmn.v_td_redem_master_custom.redem_ref_no IS NOT NULL 
          ) )
          THEN
            l_1_Lvl_Counter := 0;
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Ictms-Tdredmpayout-Master-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','WAIVEINT',p_icdredmn.v_ictbs_tdredemption_master.waive_interest);
            Cspks_Req_Global.Pr_Write('V','SUPPRESS_REDEMPTION_ADVICE',p_icdredmn.v_ictbs_tdredemption_master.suppress_redemption_advice);
            Cspks_Req_Global.Pr_Write('V','REDEM_REF_NO',p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no);
            Cspks_Req_Global.Pr_Write('V','ACBRN',p_icdredmn.v_ictbs_tdredemption_master.branch_code);
            Cspks_Req_Global.Pr_Write('V','TERM_ACNO',p_icdredmn.v_ictbs_tdredemption_master.acc_no);
            Cspks_Req_Global.Pr_Write('V','CUST_ID',p_icdredmn.v_ictbs_tdredemption_master.cust_id);
            Cspks_Req_Global.Pr_Write('V','ACCOUNT_CCY',p_icdredmn.v_ictbs_tdredemption_master.ccy);
            Cspks_Req_Global.Pr_Write('V','AC_DESC',p_icdredmn.v_ictbs_tdredemption_master.acc_desc);
            Cspks_Req_Global.Pr_Write('V','CUST_ACC_BAL',p_icdredmn.v_ictbs_tdredemption_master.acc_amt);
            Cspks_Req_Global.Pr_Write('V','ACTION_FLAG',p_icdredmn.v_ictbs_tdredemption_master.action_flag);
            Cspks_Req_Global.Pr_Write('V','DAYS',p_icdredmn.v_ictbs_tdredemption_master.tenor_dd);
            Cspks_Req_Global.Pr_Write('V','DEFAULT_MONTHS1',p_icdredmn.v_ictbs_tdredemption_master.tenor_mm);
            Cspks_Req_Global.Pr_Write('V','YEARS_SS',p_icdredmn.v_ictbs_tdredemption_master.tenor_yy);
            IF trunc(p_icdredmn.v_ictbs_tdredemption_master.next_mat_date) <>
                  p_icdredmn.v_ictbs_tdredemption_master.next_mat_date THEN
               l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.next_mat_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.next_mat_date,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','NEXT_MAT_DATE',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','REDEM_MODE',p_icdredmn.v_ictbs_tdredemption_master.redemption_mode);
            Cspks_Req_Global.Pr_Write('V','REDEMPTION_AMT',p_icdredmn.v_ictbs_tdredemption_master.redemption_amt);
            Cspks_Req_Global.Pr_Write('V','WAIVE_PENALTY',p_icdredmn.v_ictbs_tdredemption_master.wave_penalty);
            Cspks_Req_Global.Pr_Write('V','INPTBY',p_icdredmn.v_ictbs_tdredemption_master.maker_id);
            Cspks_Req_Global.Pr_Write('V','CHECHKERID',p_icdredmn.v_ictbs_tdredemption_master.checker_id);
            IF trunc(p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp) <>
                  p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','MAKDTTIME',l_Date_Val);
            IF trunc(p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp) <>
                  p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','CHECKERDT',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','AUTHSTAT',p_icdredmn.v_ictbs_tdredemption_master.auth_status);
            Cspks_Req_Global.Pr_Write('V','TXNSTAT',p_icdredmn.v_ictbs_tdredemption_master.contract_status);
            Cspks_Req_Global.Pr_Write('V','PRN_AMT',p_icdredmn.v_cstb_ui_columns.char_field1);
            Cspks_Req_Global.Pr_Write('V','MATURITY_AMT',p_icdredmn.v_ictbs_tdredemption_master.maturity_amount);
            Cspks_Req_Global.Pr_Write('V','INTEREST_RATE',p_icdredmn.v_ictbs_tdredemption_master.interest_rate);
            Cspks_Req_Global.Pr_Write('V','ROLLTENOR',p_icdredmn.v_ictbs_tdredemption_master.roll_tenor_pref);
            Cspks_Req_Global.Pr_Write('V','CONTVARROLL',p_icdredmn.v_ictbs_tdredemption_master.cont_var_roll);
            Cspks_Req_Global.Pr_Write('V','INTRATE_CUMAMT_REQD',p_icdredmn.v_ictbs_tdredemption_master.intrate_cumamt_reqd);
            Cspks_Req_Global.Pr_Write('V','REDEMAMT',p_icdredmn.v_cstb_ui_columns.char_field80);
            Cspks_Req_Global.Pr_Write('V','NUM_CERTIFICATE_REDM',p_icdredmn.v_cstb_ui_columns.char_field81);
            Cspks_Req_Global.Pr_Write('V','PRODUCT_CODE',p_icdredmn.v_ictbs_tdredemption_master.product_code);
            Cspks_Req_Global.Pr_Write('V','ADDFNDS',p_icdredmn.v_ictbs_tdredemption_master.add_funds);
            Cspks_Req_Global.Pr_Write('V','ADD_AMT',p_icdredmn.v_ictbs_tdredemption_master.additional_amt);
            Cspks_Req_Global.Pr_Write('V','REDM_INT_PAYOUT',p_icdredmn.v_ictbs_tdredemption_master.redem_int_payout);
            Cspks_Req_Global.Pr_Write('V','WAIVE_INSURANCE_FEE',p_icdredmn.v_td_redem_master_custom.waive_insurance_fee);
            Cspks_Req_Global.Pr_Write('V','INSURANCE_AMOUNT',p_icdredmn.v_td_redem_master_custom.insurance_amount);

            --Dbg('Building Childs Of :BLK_ICTMS_TDREDMPAYOUT_MASTER..');
            l_Dsn_Rec_Cnt_2 := 0;
            IF p_icdredmn.v_tdredmpayout_details.COUNT > 0 THEN
               FOR i_2 IN  1..p_icdredmn.v_tdredmpayout_details.COUNT LOOP
                  l_Dsn_Rec_Cnt_2 := i_2;
                  l_Master_Childs  :=  l_Master_Childs +1;
                  l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
                  l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
                  Cspks_Req_Global.Pr_Write('P','Ictms-Tdredmpayout-Details',l_Level_Format);
                  Cspks_Req_Global.Pr_Write('V','PAYOUTTYPE',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).payouttype);
                  Cspks_Req_Global.Pr_Write('V','OFFSET_BRN',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).offset_brn);
                  Cspks_Req_Global.Pr_Write('V','OFFSET_ACC',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).offset_acc);
                  Cspks_Req_Global.Pr_Write('V','PERCENTAGE',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).percentage);
                  Cspks_Req_Global.Pr_Write('V','REDMAMT',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).redmamt);
                  Cspks_Req_Global.Pr_Write('V','NARRATIVE',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).narrative);
                  Cspks_Req_Global.Pr_Write('V','WAIVEISSUCHG',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).waive_issue_chg);
                  Cspks_Req_Global.Pr_Write('V','INSTNO',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).instno);
                  Cspks_Req_Global.Pr_Write('V','REDM_PAYOUT_COMP',p_icdredmn.v_tdredmpayout_details(l_Dsn_Rec_Cnt_2).redm_payout_comp);
               END LOOP;
            END IF;
            l_Dsn_Rec_Cnt_5 := 0;
            IF p_icdredmn.v_sttms_denom_redmn_blk.COUNT > 0 THEN
               FOR i_5 IN  1..p_icdredmn.v_sttms_denom_redmn_blk.COUNT LOOP
                  l_Dsn_Rec_Cnt_5 := i_5;
                  l_Master_Childs  :=  l_Master_Childs +1;
                  l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
                  l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
                  Cspks_Req_Global.Pr_Write('P','Denom-Deposit',l_Level_Format);
                  Cspks_Req_Global.Pr_Write('V','CERTIFICATE_NO',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).certificate_no);
                  Cspks_Req_Global.Pr_Write('V','CERTIFICATE_AMOUNT',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).certificate_amount);
                  Cspks_Req_Global.Pr_Write('V','REDEEM',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).block_or_redem);
                  Cspks_Req_Global.Pr_Write('V','CERTIFICATE_STATUS',p_icdredmn.v_sttms_denom_redmn_blk(l_Dsn_Rec_Cnt_5).certificate_status);
               END LOOP;
            END IF;
            l_Dsn_Rec_Cnt_6 := 0;
            IF p_icdredmn.v_ictms_tdredpayin_details.COUNT > 0 THEN
               FOR i_6 IN  1..p_icdredmn.v_ictms_tdredpayin_details.COUNT LOOP
                  l_Dsn_Rec_Cnt_6 := i_6;
                  l_Master_Childs  :=  l_Master_Childs +1;
                  l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
                  l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
                  Cspks_Req_Global.Pr_Write('P','Redem-Payin-Dtls',l_Level_Format);
                  Cspks_Req_Global.Pr_Write('V','PAYIN_OPTION',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_payopt);
                  Cspks_Req_Global.Pr_Write('V','AMT',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_tdamount);
                  Cspks_Req_Global.Pr_Write('V','OFFSET_BRN',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_offset_brn);
                  Cspks_Req_Global.Pr_Write('V','OFFSET_ACC',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_tdoffset_acc);
                  Cspks_Req_Global.Pr_Write('V','PECENT',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).multimode_percentage);
                  Cspks_Req_Global.Pr_Write('V','CHQINSTNO',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instumentno);
                  Cspks_Req_Global.Pr_Write('V','PRODUCT_F',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).clg_product_code);
                  IF trunc(p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instrument_date) <>
                        p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instrument_date THEN
                     l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instrument_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
                  ELSE
                     l_Date_Val :=  TO_CHAR( p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).chq_instrument_date,Cspks_Req_Global.g_Ws_Date_Format);
                  END IF;
                  Cspks_Req_Global.Pr_Write('V','CHQ_ADTE',l_Date_Val);
                  Cspks_Req_Global.Pr_Write('V','DRAWEE_ACCOUNT',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).drawee_ac_no);
                  Cspks_Req_Global.Pr_Write('V','ROUTING_NO',p_icdredmn.v_ictms_tdredpayin_details(l_Dsn_Rec_Cnt_6).routing_no);
               END LOOP;
            END IF;
            l_Level_Format      := l_0_Lvl_Counter;
            l_Cntr_Before := l_Master_Childs;
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='ICCREFPO_'||p_Action_Code;
            END IF;
            IF NOT Icpks_Iccrefpo_Main.Fn_Build_Ts_List(p_source,
               l_Source_Operation,
               'ICCREFPO',
               p_Action_Code,
               p_Function_Id,
               p_icdredmn.ty_iccrefpo,
               l_Level_Format,
               l_1_Lvl_Counter,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List');
               RETURN FALSE;
            END IF;
            l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Ictms-Tdredmpayout-Master-PK','1');
         l_Key_Cols := 'REDEM_REF_NO~';
         l_Key_Vals := p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_icdredmn IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO';
      IF p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no IS Null THEN
         Dbg('Field redem_ref_no is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'ICTBS_TDREDEMPTION_MASTER';
         l_Fld := 'ICTBS_TDREDEMPTION_MASTER.ACC_NO';
         IF p_icdredmn.v_ictbs_tdredemption_master.acc_no IS Null THEN
            Dbg('Mandatory Key Column acc_no Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;

         l_Blk := 'ICTMS_TDREDMPAYOUT_DETAILS';
         l_Count := p_icdredmn.v_tdredmpayout_details.COUNT;
         IF l_Count > 0 THEN
            FOR l_index IN 1 .. p_icdredmn.v_tdredmpayout_details.COUNT LOOP
               l_Fld := 'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO';
               IF p_icdredmn.v_tdredmpayout_details(l_Index).seqno IS Null THEN
                  Dbg('Primary Key Column seqno Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
            END LOOP;
         END IF;

         l_Blk := 'STTMS_DENOM_REDMN_BLK';
         l_Count := p_icdredmn.v_sttms_denom_redmn_blk.COUNT;
         IF l_Count > 0 THEN
            FOR l_index IN 1 .. p_icdredmn.v_sttms_denom_redmn_blk.COUNT LOOP
               l_Fld := 'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO';
               IF p_icdredmn.v_sttms_denom_redmn_blk(l_Index).certificate_no IS Null THEN
                  Dbg('Primary Key Column certificate_no Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
            END LOOP;
         END IF;

         l_Blk := 'ICTMS_TDREDPAYIN_DETAILS';
         l_Count := p_icdredmn.v_ictms_tdredpayin_details.COUNT;
         IF l_Count > 0 THEN
            FOR l_index IN 1 .. p_icdredmn.v_ictms_tdredpayin_details.COUNT LOOP
               l_Fld := 'ICTMS_TDREDPAYIN_DETAILS.ACC';
               IF p_icdredmn.v_ictms_tdredpayin_details(l_Index).acc IS Null THEN
                  Dbg('Primary Key Column acc Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
               l_Fld := 'ICTMS_TDREDPAYIN_DETAILS.SEQNO';
               IF p_icdredmn.v_ictms_tdredpayin_details(l_Index).seqno IS Null THEN
                  Dbg('Primary Key Column seqno Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
               l_Fld := 'ICTMS_TDREDPAYIN_DETAILS.BRN';
               IF p_icdredmn.v_ictms_tdredpayin_details(l_Index).brn IS Null THEN
                  Dbg('Primary Key Column brn Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
            END LOOP;
         END IF;

         l_Blk := 'ICTB_TD_REDEM_MASTER_CUSTOM';
         l_Rec_Sent  := FALSE;
         l_Fld := 'ICTB_TD_REDEM_MASTER_CUSTOM.REDEM_REF_NO';
         IF p_icdredmn.v_td_redem_master_custom.redem_ref_no IS Null THEN
            IF l_Rec_Sent  THEN
               Dbg('Primary key Column redem_ref_no Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-002','@'||l_Fld||'~@'||l_Blk) ;
            END IF;
         ELSE
            l_Rec_Sent  := TRUE;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.ty_icdredmn,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      IF p_icdredmn.v_ictbs_tdredemption_master.WAIVE_INTEREST IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.WAIVE_INTEREST NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :WAIVE_INTEREST:'||p_icdredmn.v_ictbs_tdredemption_master.WAIVE_INTEREST);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.WAIVE_INTEREST||'~@ICTBS_TDREDEMPTION_MASTER.WAIVE_INTEREST~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.SUPPRESS_REDEMPTION_ADVICE IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.SUPPRESS_REDEMPTION_ADVICE NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :SUPPRESS_REDEMPTION_ADVICE:'||p_icdredmn.v_ictbs_tdredemption_master.SUPPRESS_REDEMPTION_ADVICE);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.SUPPRESS_REDEMPTION_ADVICE||'~@ICTBS_TDREDEMPTION_MASTER.SUPPRESS_REDEMPTION_ADVICE~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.CONTRACT_STATUS IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.CONTRACT_STATUS NOT IN ('K','V','S','A','H') THEN
            dbg('Invalid Value For The Field  :CONTRACT_STATUS:'||p_icdredmn.v_ictbs_tdredemption_master.CONTRACT_STATUS);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.CONTRACT_STATUS||'~@ICTBS_TDREDEMPTION_MASTER.CONTRACT_STATUS~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG NOT IN ('E','R','T') THEN
            dbg('Invalid Value For The Field  :ACTION_FLAG:'||p_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG||'~@ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_MODE IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_MODE NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :REDEMPTION_MODE:'||p_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_MODE);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_MODE||'~@ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.WAVE_PENALTY IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.WAVE_PENALTY NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :WAVE_PENALTY:'||p_icdredmn.v_ictbs_tdredemption_master.WAVE_PENALTY);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.WAVE_PENALTY||'~@ICTBS_TDREDEMPTION_MASTER.WAVE_PENALTY~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.AUTH_STATUS IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.AUTH_STATUS NOT IN ('U','A') THEN
            dbg('Invalid Value For The Field  :AUTH_STATUS:'||p_icdredmn.v_ictbs_tdredemption_master.AUTH_STATUS);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.AUTH_STATUS||'~@ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.ROLL_TENOR_PREF IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.ROLL_TENOR_PREF NOT IN ('L','A','I') THEN
            dbg('Invalid Value For The Field  :ROLL_TENOR_PREF:'||p_icdredmn.v_ictbs_tdredemption_master.ROLL_TENOR_PREF);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.ROLL_TENOR_PREF||'~@ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.CONT_VAR_ROLL IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.CONT_VAR_ROLL NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :CONT_VAR_ROLL:'||p_icdredmn.v_ictbs_tdredemption_master.CONT_VAR_ROLL);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.CONT_VAR_ROLL||'~@ICTBS_TDREDEMPTION_MASTER.CONT_VAR_ROLL~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.INTRATE_CUMAMT_REQD IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.INTRATE_CUMAMT_REQD NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :INTRATE_CUMAMT_REQD:'||p_icdredmn.v_ictbs_tdredemption_master.INTRATE_CUMAMT_REQD);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.INTRATE_CUMAMT_REQD||'~@ICTBS_TDREDEMPTION_MASTER.INTRATE_CUMAMT_REQD~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.ADD_FUNDS IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.ADD_FUNDS NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :ADD_FUNDS:'||p_icdredmn.v_ictbs_tdredemption_master.ADD_FUNDS);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.ADD_FUNDS||'~@ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.ADDITIONAL_AMT IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.ADDITIONAL_AMT < 0 THEN
            Dbg('Invalid Value For The Field  :ADDITIONAL_AMT:'||p_icdredmn.v_ictbs_tdredemption_master.ADDITIONAL_AMT);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.ADDITIONAL_AMT||'~@ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      IF p_icdredmn.v_ictbs_tdredemption_master.REDEM_INT_PAYOUT IS NOT NULL THEN
         IF p_icdredmn.v_ictbs_tdredemption_master.REDEM_INT_PAYOUT NOT IN ('I','R','P') THEN
            dbg('Invalid Value For The Field  :REDEM_INT_PAYOUT:'||p_icdredmn.v_ictbs_tdredemption_master.REDEM_INT_PAYOUT);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_icdredmn.v_ictbs_tdredemption_master.REDEM_INT_PAYOUT||'~@ICTBS_TDREDEMPTION_MASTER.REDEM_INT_PAYOUT~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      l_Count      := p_icdredmn.v_tdredmpayout_details.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            l_Key := NULL;
            IF p_icdredmn.v_tdredmpayout_details(l_index).PAYOUTTYPE IS NOT NULL THEN
               IF p_icdredmn.v_tdredmpayout_details(l_index).PAYOUTTYPE NOT IN ('S','G','B','P','Y','D','L','C') THEN
                  dbg('Invalid Value For The Field  :PAYOUTTYPE:'||p_icdredmn.v_tdredmpayout_details(l_index).PAYOUTTYPE);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                  p_icdredmn.v_tdredmpayout_details(l_index).seqno;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_icdredmn.v_tdredmpayout_details(l_index).PAYOUTTYPE||'~@ICTMS_TDREDMPAYOUT_DETAILS.PAYOUTTYPE'||'~'||l_Key||'~@ICTMS_TDREDMPAYOUT_DETAILS') ;
               END IF;
            END IF;
            IF p_icdredmn.v_tdredmpayout_details(l_index).WAIVE_ISSUE_CHG IS NOT NULL THEN
               IF p_icdredmn.v_tdredmpayout_details(l_index).WAIVE_ISSUE_CHG NOT IN ('Y','N') THEN
                  dbg('Invalid Value For The Field  :WAIVE_ISSUE_CHG:'||p_icdredmn.v_tdredmpayout_details(l_index).WAIVE_ISSUE_CHG);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                  p_icdredmn.v_tdredmpayout_details(l_index).seqno;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_icdredmn.v_tdredmpayout_details(l_index).WAIVE_ISSUE_CHG||'~@ICTMS_TDREDMPAYOUT_DETAILS.WAIVE_ISSUE_CHG'||'~'||l_Key||'~@ICTMS_TDREDMPAYOUT_DETAILS') ;
               END IF;
            END IF;
            IF p_icdredmn.v_tdredmpayout_details(l_index).REDM_PAYOUT_COMP IS NOT NULL THEN
               IF p_icdredmn.v_tdredmpayout_details(l_index).REDM_PAYOUT_COMP NOT IN ('P','I') THEN
                  dbg('Invalid Value For The Field  :REDM_PAYOUT_COMP:'||p_icdredmn.v_tdredmpayout_details(l_index).REDM_PAYOUT_COMP);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                  p_icdredmn.v_tdredmpayout_details(l_index).seqno;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_icdredmn.v_tdredmpayout_details(l_index).REDM_PAYOUT_COMP||'~@ICTMS_TDREDMPAYOUT_DETAILS.REDM_PAYOUT_COMP'||'~'||l_Key||'~@ICTMS_TDREDMPAYOUT_DETAILS') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Duplicate Records Check For :v_tdredmpayout_details..');
      l_Count      := p_icdredmn.v_tdredmpayout_details.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_count LOOP
            l_key := NULL;
            IF l_index < l_Count THEN
               FOR l_index1 IN l_index+1 .. l_Count LOOP
                  IF (NVL(p_icdredmn.v_tdredmpayout_details(l_index).redem_ref_no,'@')=  NVL(p_icdredmn.v_tdredmpayout_details(l_index1).redem_ref_no,'@')) AND (NVL(p_icdredmn.v_tdredmpayout_details(l_index).seqno,'@')=  NVL(p_icdredmn.v_tdredmpayout_details(l_index1).seqno,'@')) THEN
                     Dbg('Duplicare Record Found for :'||l_Key);
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.REDEM_REF_NO')||'-'||
                     p_icdredmn.v_tdredmpayout_details(l_index).redem_ref_no||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                     p_icdredmn.v_tdredmpayout_details(l_index).seqno;
                     Pr_Log_Error(p_Source,'ST-VALS-009','@ICTMS_TDREDMPAYOUT_DETAILS~'||l_Key);
                  END IF;
               END LOOP;
            END IF;
         END LOOP;
      END IF;
      l_Count      := p_icdredmn.v_sttms_denom_redmn_blk.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            l_Key := NULL;
            IF p_icdredmn.v_sttms_denom_redmn_blk(l_index).BLOCK_OR_REDEM IS NOT NULL THEN
               IF p_icdredmn.v_sttms_denom_redmn_blk(l_index).BLOCK_OR_REDEM NOT IN ('R','N') THEN
                  dbg('Invalid Value For The Field  :BLOCK_OR_REDEM:'||p_icdredmn.v_sttms_denom_redmn_blk(l_index).BLOCK_OR_REDEM);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO')||'-'||
                  p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_icdredmn.v_sttms_denom_redmn_blk(l_index).BLOCK_OR_REDEM||'~@STTMS_DENOM_REDMN_BLK.BLOCK_OR_REDEM'||'~'||l_Key||'~@STTMS_DENOM_REDMN_BLK') ;
               END IF;
            END IF;
            IF p_icdredmn.v_sttms_denom_redmn_blk(l_index).CERTIFICATE_STATUS IS NOT NULL THEN
               IF p_icdredmn.v_sttms_denom_redmn_blk(l_index).CERTIFICATE_STATUS NOT IN ('I','D','P','R','B','O') THEN
                  dbg('Invalid Value For The Field  :CERTIFICATE_STATUS:'||p_icdredmn.v_sttms_denom_redmn_blk(l_index).CERTIFICATE_STATUS);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO')||'-'||
                  p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_icdredmn.v_sttms_denom_redmn_blk(l_index).CERTIFICATE_STATUS||'~@STTMS_DENOM_REDMN_BLK.CERTIFICATE_STATUS'||'~'||l_Key||'~@STTMS_DENOM_REDMN_BLK') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Duplicate Records Check For :v_sttms_denom_redmn_blk..');
      l_Count      := p_icdredmn.v_sttms_denom_redmn_blk.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_count LOOP
            l_key := NULL;
            IF l_index < l_Count THEN
               FOR l_index1 IN l_index+1 .. l_Count LOOP
                  IF (NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index).cust_ac_no,'@')=  NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index1).cust_ac_no,'@')) AND (NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index).reference_no,'@')=  NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index1).reference_no,'@')) AND (NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no,'@')=  NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_no,'@')) THEN
                     Dbg('Duplicare Record Found for :'||l_Key);
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CUST_AC_NO')||'-'||
                     p_icdredmn.v_sttms_denom_redmn_blk(l_index).cust_ac_no||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.REFERENCE_NO')||'-'||
                     p_icdredmn.v_sttms_denom_redmn_blk(l_index).reference_no||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO')||'-'||
                     p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no;
                     Pr_Log_Error(p_Source,'ST-VALS-009','@STTMS_DENOM_REDMN_BLK~'||l_Key);
                  END IF;
               END LOOP;
            END IF;
         END LOOP;
      END IF;
      l_Count      := p_icdredmn.v_ictms_tdredpayin_details.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            l_Key := NULL;
            IF p_icdredmn.v_ictms_tdredpayin_details(l_index).MULTIMODE_PAYOPT IS NOT NULL THEN
               IF p_icdredmn.v_ictms_tdredpayin_details(l_index).MULTIMODE_PAYOPT NOT IN ('S','G','Q') THEN
                  dbg('Invalid Value For The Field  :MULTIMODE_PAYOPT:'||p_icdredmn.v_ictms_tdredpayin_details(l_index).MULTIMODE_PAYOPT);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_icdredmn.v_ictms_tdredpayin_details(l_index).MULTIMODE_PAYOPT||'~@ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_PAYOPT'||'~'||l_Key||'~@ICTMS_TDREDPAYIN_DETAILS') ;
               END IF;
            END IF;
            IF p_icdredmn.v_ictms_tdredpayin_details(l_index).MULTIMODE_TDAMOUNT IS NOT NULL THEN
               IF p_icdredmn.v_ictms_tdredpayin_details(l_index).MULTIMODE_TDAMOUNT < 0 THEN
                  Dbg('Invalid Value For The Field  :MULTIMODE_TDAMOUNT:'||p_icdredmn.v_ictms_tdredpayin_details(l_index).MULTIMODE_TDAMOUNT);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_icdredmn.v_ictms_tdredpayin_details(l_index).MULTIMODE_TDAMOUNT||'~@ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDAMOUNT'||'~'||l_Key||'~@ICTMS_TDREDPAYIN_DETAILS') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Duplicate Records Check For :v_ictms_tdredpayin_details..');
      l_Count      := p_icdredmn.v_ictms_tdredpayin_details.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_count LOOP
            l_key := NULL;
            IF l_index < l_Count THEN
               FOR l_index1 IN l_index+1 .. l_Count LOOP
                  IF (NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).acc,'@')=  NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index1).acc,'@')) AND (NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).redem_ref_no,'@')=  NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index1).redem_ref_no,'@')) AND (NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).seqno,-1)=  NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index1).seqno,-1)) AND (NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).brn,'@')=  NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index1).brn,'@')) THEN
                     Dbg('Duplicare Record Found for :'||l_Key);
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                     p_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.REDEM_REF_NO')||'-'||
                     p_icdredmn.v_ictms_tdredpayin_details(l_index).redem_ref_no||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                     p_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                     p_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                     Pr_Log_Error(p_Source,'ST-VALS-009','@ICTMS_TDREDPAYIN_DETAILS~'||l_Key);
                  END IF;
               END LOOP;
            END IF;
         END LOOP;
      END IF;
      IF p_icdredmn.v_td_redem_master_custom.WAIVE_INSURANCE_FEE IS NOT NULL THEN
         IF p_icdredmn.v_td_redem_master_custom.WAIVE_INSURANCE_FEE NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :WAIVE_INSURANCE_FEE:'||p_icdredmn.v_td_redem_master_custom.WAIVE_INSURANCE_FEE);
            Pr_Log_Error(p_Source,'ST-VALS-012',p_icdredmn.v_td_redem_master_custom.WAIVE_INSURANCE_FEE||'~@ICTB_TD_REDEM_MASTER_CUSTOM.WAIVE_INSURANCE_FEE~@ICTB_TD_REDEM_MASTER_CUSTOM') ;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_icdredmn     IN  OUT icpks_icdredmn_Main.ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      IF p_Wrk_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG IS NULL THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG := 'R';
      END IF;
      l_Count      := p_Wrk_icdredmn.v_tdredmpayout_details.COUNT;
      IF l_count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            IF p_Wrk_icdredmn.v_tdredmpayout_details(l_index).WAIVE_ISSUE_CHG IS NULL THEN
               p_Wrk_icdredmn.v_tdredmpayout_details(l_index).WAIVE_ISSUE_CHG := 'Y';
            END IF;
            IF p_Wrk_icdredmn.v_tdredmpayout_details(l_index).REDM_PAYOUT_COMP IS NULL THEN
               p_Wrk_icdredmn.v_tdredmpayout_details(l_index).REDM_PAYOUT_COMP := 'P';
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Merge_Amendables        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Prev_icdredmn IN icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn IN OUT icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Wrk_Count      NUMBER := 0 ;
      l_Deleted_Recs   NUMBER := 0;
      l_Modified_Flds  VARCHAR2(32000):= NULL;
      l_Key            VARCHAR2(5000):= NULL;
      l_Mod_Fld        VARCHAR2(100):= NULL;
      i                NUMBER := 1;
      l_Rec_Found      BOOLEAN := FALSE;
      l_Rec_Modified   BOOLEAN := FALSE;
      l_Rec_Sent       BOOLEAN := FALSE;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Pk_Or_Full     VARCHAR2(5) :='FULL';
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Mod_No         NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Amendable_Nodes Cspks_Req_Global.Ty_Amend_Nodes;
      l_Amendable_Fields Cspks_Req_Global.Ty_Amend_Fields;
      N_v_tdredmpayout_details       icpks_icdredmn_Main.Ty_Tb_v_tdredmpayout_details;
      N_v_sttms_denom_redmn_blk       icpks_icdredmn_Main.Ty_Tb_v_sttms_denom_redmn_blk;
      N_v_ictms_tdredpayin_details       icpks_icdredmn_Main.Ty_Tb_ictms_tdredpayin_details;

      FUNCTION Fn_Amendable(p_Item IN VARCHAR2) RETURN BOOLEAN IS
      BEGIN
         IF l_Amendable_Fields.EXISTS(p_Item) THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END Fn_Amendable;
   BEGIN

      Dbg('In Fn_Sys_Merge_Amendables');

      Dbg('Calling Cspks_Req_Utils.Fn_Get_Amendable_Details..');
      IF NOT Cspks_Req_Utils.Fn_Get_Amendable_Details(p_source ,
         p_Source_Operation,
         l_Amendable_Nodes,
         l_Amendable_Fields,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      l_Blk := 'ICTBS_TDREDEMPTION_MASTER';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_fld := 'ICTBS_TDREDEMPTION_MASTER.WAIVE_INTEREST';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.WAIVE_INTEREST') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.waive_interest := p_icdredmn.v_ictbs_tdredemption_master.waive_interest;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.waive_interest IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.waive_interest,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.waive_interest,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.GL_BRANCH';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.GL_BRANCH') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_branch := p_icdredmn.v_ictbs_tdredemption_master.gl_branch;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.gl_branch IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_branch,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.gl_branch,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ALLOW_PREPAYMENT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ALLOW_PREPAYMENT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.allow_prepayment := p_icdredmn.v_ictbs_tdredemption_master.allow_prepayment;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.allow_prepayment IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.allow_prepayment,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.allow_prepayment,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.SUPPRESS_REDEMPTION_ADVICE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.SUPPRESS_REDEMPTION_ADVICE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.suppress_redemption_advice := p_icdredmn.v_ictbs_tdredemption_master.suppress_redemption_advice;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.suppress_redemption_advice IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.suppress_redemption_advice,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.suppress_redemption_advice,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.MUDARABAH_REDMN';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.MUDARABAH_REDMN') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.mudarabah_redmn := p_icdredmn.v_ictbs_tdredemption_master.mudarabah_redmn;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.mudarabah_redmn IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.mudarabah_redmn,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.mudarabah_redmn,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.CONTRACT_STATUS';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.CONTRACT_STATUS') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.contract_status := p_icdredmn.v_ictbs_tdredemption_master.contract_status;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.contract_status IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.contract_status,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.contract_status,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.BRANCH_CODE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.branch_code := p_icdredmn.v_ictbs_tdredemption_master.branch_code;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.branch_code IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.branch_code,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.branch_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ACC_NO';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ACC_NO') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.acc_no := p_icdredmn.v_ictbs_tdredemption_master.acc_no;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.acc_no IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.acc_no,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.acc_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.CUST_ID';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.CUST_ID') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.cust_id := p_icdredmn.v_ictbs_tdredemption_master.cust_id;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.cust_id IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.cust_id,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.cust_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ACC_DESC';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ACC_DESC') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.acc_desc := p_icdredmn.v_ictbs_tdredemption_master.acc_desc;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.acc_desc IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.acc_desc,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.acc_desc,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ACC_AMT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ACC_AMT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.acc_amt := p_icdredmn.v_ictbs_tdredemption_master.acc_amt;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.acc_amt IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.acc_amt,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.acc_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ACTION_FLAG') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.action_flag := p_icdredmn.v_ictbs_tdredemption_master.action_flag;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.action_flag IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.action_flag,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.action_flag,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.TENOR_DD';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.TENOR_DD') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.tenor_dd := p_icdredmn.v_ictbs_tdredemption_master.tenor_dd;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.tenor_dd IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.tenor_dd,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.tenor_dd,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.TENOR_MM';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.TENOR_MM') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.tenor_mm := p_icdredmn.v_ictbs_tdredemption_master.tenor_mm;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.tenor_mm IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.tenor_mm,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.tenor_mm,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.TENOR_YY';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.TENOR_YY') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.tenor_yy := p_icdredmn.v_ictbs_tdredemption_master.tenor_yy;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.tenor_yy IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.tenor_yy,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.tenor_yy,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.NEXT_MAT_DATE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.next_mat_date := p_icdredmn.v_ictbs_tdredemption_master.next_mat_date;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.next_mat_date IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.next_mat_date,global.min_date) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.next_mat_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.REDEMPTION_BY';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.REDEMPTION_BY') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.redemption_by := p_icdredmn.v_ictbs_tdredemption_master.redemption_by;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.redemption_by IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.redemption_by,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.redemption_by,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.CCY';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.CCY') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.ccy := p_icdredmn.v_ictbs_tdredemption_master.ccy;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.ccy IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.ccy,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.REDEMPTION_MODE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.redemption_mode := p_icdredmn.v_ictbs_tdredemption_master.redemption_mode;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.redemption_mode IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.redemption_mode,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.redemption_mode,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.REDEMPTION_AMT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.REDEMPTION_AMT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.redemption_amt := p_icdredmn.v_ictbs_tdredemption_master.redemption_amt;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.redemption_amt IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.redemption_amt,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.redemption_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.WAVE_PENALTY';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.WAVE_PENALTY') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.wave_penalty := p_icdredmn.v_ictbs_tdredemption_master.wave_penalty;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.wave_penalty IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.wave_penalty,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.wave_penalty,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.BANK_CD';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.BANK_CD') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_cd := p_icdredmn.v_ictbs_tdredemption_master.bank_cd;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.bank_cd IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_cd,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.bank_cd,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.BANK_TXN_CCY';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.BANK_TXN_CCY') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_txn_ccy := p_icdredmn.v_ictbs_tdredemption_master.bank_txn_ccy;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.bank_txn_ccy IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_txn_ccy,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.bank_txn_ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.BANK_EXCH_RATE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.BANK_EXCH_RATE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_exch_rate := p_icdredmn.v_ictbs_tdredemption_master.bank_exch_rate;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.bank_exch_rate IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_exch_rate,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.bank_exch_rate,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.BANK_TXN_AMT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.BANK_TXN_AMT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_txn_amt := p_icdredmn.v_ictbs_tdredemption_master.bank_txn_amt;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.bank_txn_amt IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_txn_amt,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.bank_txn_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.CHQ_DATE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.CHQ_DATE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.chq_date := p_icdredmn.v_ictbs_tdredemption_master.chq_date;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.chq_date IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.chq_date,global.min_date) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.chq_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.CHARGES';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.CHARGES') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.charges := p_icdredmn.v_ictbs_tdredemption_master.charges;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.charges IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.charges,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.charges,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.BENEF_NAME';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.BENEF_NAME') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.benef_name := p_icdredmn.v_ictbs_tdredemption_master.benef_name;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.benef_name IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.benef_name,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.benef_name,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.PASSPORT_NO';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.PASSPORT_NO') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.passport_no := p_icdredmn.v_ictbs_tdredemption_master.passport_no;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.passport_no IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.passport_no,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.passport_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ADDR1';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ADDR1') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.addr1 := p_icdredmn.v_ictbs_tdredemption_master.addr1;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.addr1 IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.addr1,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.addr1,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ADDR2';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ADDR2') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.addr2 := p_icdredmn.v_ictbs_tdredemption_master.addr2;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.addr2 IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.addr2,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.addr2,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.BANK_NARRATIVE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.BANK_NARRATIVE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_narrative := p_icdredmn.v_ictbs_tdredemption_master.bank_narrative;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.bank_narrative IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_narrative,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.bank_narrative,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.SAVINGS_BRN_CODE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.SAVINGS_BRN_CODE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_brn_code := p_icdredmn.v_ictbs_tdredemption_master.savings_brn_code;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.savings_brn_code IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_brn_code,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.savings_brn_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.SAVINGS_ACC_NO';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.SAVINGS_ACC_NO') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_acc_no := p_icdredmn.v_ictbs_tdredemption_master.savings_acc_no;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.savings_acc_no IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_acc_no,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.savings_acc_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_CCY';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_CCY') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_txn_ccy := p_icdredmn.v_ictbs_tdredemption_master.savings_txn_ccy;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.savings_txn_ccy IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_txn_ccy,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.savings_txn_ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.SAVINGS_EXCH_RATE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.SAVINGS_EXCH_RATE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_exch_rate := p_icdredmn.v_ictbs_tdredemption_master.savings_exch_rate;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.savings_exch_rate IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_exch_rate,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.savings_exch_rate,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_AMT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.SAVINGS_TXN_AMT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_txn_amt := p_icdredmn.v_ictbs_tdredemption_master.savings_txn_amt;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.savings_txn_amt IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_txn_amt,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.savings_txn_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.SAVINGS_NARRATIVE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.SAVINGS_NARRATIVE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_narrative := p_icdredmn.v_ictbs_tdredemption_master.savings_narrative;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.savings_narrative IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.savings_narrative,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.savings_narrative,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.GL_NO';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.GL_NO') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_no := p_icdredmn.v_ictbs_tdredemption_master.gl_no;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.gl_no IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_no,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.gl_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.GL_TXN_CCY';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.GL_TXN_CCY') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_txn_ccy := p_icdredmn.v_ictbs_tdredemption_master.gl_txn_ccy;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.gl_txn_ccy IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_txn_ccy,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.gl_txn_ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.GL_EXCH_RATE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.GL_EXCH_RATE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_exch_rate := p_icdredmn.v_ictbs_tdredemption_master.gl_exch_rate;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.gl_exch_rate IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_exch_rate,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.gl_exch_rate,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.GL_TXN_AMT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.GL_TXN_AMT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_txn_amt := p_icdredmn.v_ictbs_tdredemption_master.gl_txn_amt;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.gl_txn_amt IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_txn_amt,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.gl_txn_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.GL_NARRATIVE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.GL_NARRATIVE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_narrative := p_icdredmn.v_ictbs_tdredemption_master.gl_narrative;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.gl_narrative IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.gl_narrative,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.gl_narrative,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.SCODE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.SCODE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.scode := p_icdredmn.v_ictbs_tdredemption_master.scode;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.scode IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.scode,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.scode,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.XREF';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.XREF') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.xref := p_icdredmn.v_ictbs_tdredemption_master.xref;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.xref IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.xref,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.xref,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.FCCREF';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.FCCREF') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.fccref := p_icdredmn.v_ictbs_tdredemption_master.fccref;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.fccref IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.fccref,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.fccref,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.PAYBRN';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.PAYBRN') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.paybrn := p_icdredmn.v_ictbs_tdredemption_master.paybrn;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.paybrn IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.paybrn,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.paybrn,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.MICR_NO';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.MICR_NO') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.micr_no := p_icdredmn.v_ictbs_tdredemption_master.micr_no;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.micr_no IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.micr_no,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.micr_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ADDR3';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ADDR3') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.addr3 := p_icdredmn.v_ictbs_tdredemption_master.addr3;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.addr3 IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.addr3,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.addr3,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.TRN_DT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.TRN_DT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.trn_dt := p_icdredmn.v_ictbs_tdredemption_master.trn_dt;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.trn_dt IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.trn_dt,global.min_date) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.trn_dt,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.BANK_CTRY_CODE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.BANK_CTRY_CODE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_ctry_code := p_icdredmn.v_ictbs_tdredemption_master.bank_ctry_code;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.bank_ctry_code IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.bank_ctry_code,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.bank_ctry_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.MATURITY_AMOUNT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.MATURITY_AMOUNT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.maturity_amount := p_icdredmn.v_ictbs_tdredemption_master.maturity_amount;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.maturity_amount IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.maturity_amount,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.maturity_amount,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.INTEREST_RATE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.INTEREST_RATE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.interest_rate := p_icdredmn.v_ictbs_tdredemption_master.interest_rate;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.interest_rate IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.interest_rate,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.interest_rate,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.MAKER_ID';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.MAKER_ID') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.maker_id := p_icdredmn.v_ictbs_tdredemption_master.maker_id;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.maker_id IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.maker_id,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.maker_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.CHECKER_ID';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.CHECKER_ID') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.checker_id := p_icdredmn.v_ictbs_tdredemption_master.checker_id;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.checker_id IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.checker_id,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.checker_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.MAKER_DT_STAMP';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.MAKER_DT_STAMP') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp := p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp,global.min_date) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.maker_dt_stamp,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.CHECKER_DT_STAMP';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.CHECKER_DT_STAMP') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp := p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp,global.min_date) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.checker_dt_stamp,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.AUTH_STATUS') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.auth_status := p_icdredmn.v_ictbs_tdredemption_master.auth_status;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.auth_status IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.auth_status,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.auth_status,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ROLL_TENOR_PREF') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.roll_tenor_pref := p_icdredmn.v_ictbs_tdredemption_master.roll_tenor_pref;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.roll_tenor_pref IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.roll_tenor_pref,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.roll_tenor_pref,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.CONT_VAR_ROLL';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.CONT_VAR_ROLL') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.cont_var_roll := p_icdredmn.v_ictbs_tdredemption_master.cont_var_roll;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.cont_var_roll IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.cont_var_roll,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.cont_var_roll,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.INTRATE_CUMAMT_REQD';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.INTRATE_CUMAMT_REQD') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.intrate_cumamt_reqd := p_icdredmn.v_ictbs_tdredemption_master.intrate_cumamt_reqd;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.intrate_cumamt_reqd IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.intrate_cumamt_reqd,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.intrate_cumamt_reqd,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.product_code := p_icdredmn.v_ictbs_tdredemption_master.product_code;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.product_code IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.product_code,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.product_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.REDEM_SEQ_NO';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.REDEM_SEQ_NO') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_seq_no := p_icdredmn.v_ictbs_tdredemption_master.redem_seq_no;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.redem_seq_no IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_seq_no,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.redem_seq_no,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ORG_YEARS';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ORG_YEARS') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.org_years := p_icdredmn.v_ictbs_tdredemption_master.org_years;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.org_years IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.org_years,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.org_years,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ORG_MONTHS';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ORG_MONTHS') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.org_months := p_icdredmn.v_ictbs_tdredemption_master.org_months;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.org_months IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.org_months,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.org_months,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ORG_DAYS';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ORG_DAYS') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.org_days := p_icdredmn.v_ictbs_tdredemption_master.org_days;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.org_days IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.org_days,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.org_days,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ADD_FUNDS') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.add_funds := p_icdredmn.v_ictbs_tdredemption_master.add_funds;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.add_funds IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.add_funds,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.add_funds,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.ADDITIONAL_AMT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.additional_amt := p_icdredmn.v_ictbs_tdredemption_master.additional_amt;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.additional_amt IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.additional_amt,-1) <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.additional_amt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'ICTBS_TDREDEMPTION_MASTER.REDEM_INT_PAYOUT';
      IF Fn_Amendable('ICTBS_TDREDEMPTION_MASTER.REDEM_INT_PAYOUT') THEN
         p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_int_payout := p_icdredmn.v_ictbs_tdredemption_master.redem_int_payout;
      ELSE
         IF p_icdredmn.v_ictbs_tdredemption_master.redem_int_payout IS NOT NULL THEN
            IF NVL(p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_int_payout,'@') <>
               NVL(p_icdredmn.v_ictbs_tdredemption_master.redem_int_payout,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;

      l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
      IF  l_Rec_Modified THEN
         IF l_Modified_Flds IS NOT NULL THEN
            i :=  1;
            l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
            WHILE l_Mod_Fld <> 'EOPL' LOOP
               Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
               i := i +1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
            END LOOP;
         END IF;
      END IF;
      l_Blk := 'ICTMS_TDREDMPAYOUT_DETAILS';
      l_Count      := p_icdredmn.v_tdredmpayout_details.COUNT;
      l_Wrk_Count  := p_Wrk_icdredmn.v_tdredmpayout_details.COUNT;
      IF l_Count > 0 THEN
         FOR l_index IN 1..l_Count  LOOP
            l_Rec_Found := FALSE;
            l_Rec_Modified := FALSE;
            l_Modified_Flds := NULL;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_icdredmn.v_tdredmpayout_details(l_index).seqno,'@')=  NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).seqno,'@')) THEN
                     Dbg('Record Found..');
                     l_Rec_Found := TRUE;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.BRN';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.BRN') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).brn := p_icdredmn.v_tdredmpayout_details(l_index).brn;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).brn IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).brn,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).brn,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.ACC';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.ACC') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).acc := p_icdredmn.v_tdredmpayout_details(l_index).acc;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).acc IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).acc,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).acc,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.CCY';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.CCY') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).ccy := p_icdredmn.v_tdredmpayout_details(l_index).ccy;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).ccy,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.PAYOUTTYPE';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.PAYOUTTYPE') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).payouttype := p_icdredmn.v_tdredmpayout_details(l_index).payouttype;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).payouttype IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).payouttype,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).payouttype,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_BRN';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_BRN') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).offset_brn := p_icdredmn.v_tdredmpayout_details(l_index).offset_brn;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).offset_brn IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).offset_brn,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).offset_brn,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_ACC';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_ACC') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).offset_acc := p_icdredmn.v_tdredmpayout_details(l_index).offset_acc;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).offset_acc IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).offset_acc,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).offset_acc,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_CCY';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_CCY') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).offset_ccy := p_icdredmn.v_tdredmpayout_details(l_index).offset_ccy;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).offset_ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).offset_ccy,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).offset_ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.PERCENTAGE';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.PERCENTAGE') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).percentage := p_icdredmn.v_tdredmpayout_details(l_index).percentage;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).percentage IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).percentage,-1) <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).percentage,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.REDMAMT';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.REDMAMT') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).redmamt := p_icdredmn.v_tdredmpayout_details(l_index).redmamt;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).redmamt IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).redmamt,-1) <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).redmamt,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.NARRATIVE';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.NARRATIVE') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).narrative := p_icdredmn.v_tdredmpayout_details(l_index).narrative;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).narrative IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).narrative,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).narrative,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.REF_NO';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.REF_NO') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).ref_no := p_icdredmn.v_tdredmpayout_details(l_index).ref_no;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).ref_no IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).ref_no,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).ref_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.WAIVE_ISSUE_CHG';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.WAIVE_ISSUE_CHG') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).waive_issue_chg := p_icdredmn.v_tdredmpayout_details(l_index).waive_issue_chg;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).waive_issue_chg IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).waive_issue_chg,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).waive_issue_chg,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.INSTNO';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.INSTNO') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).instno := p_icdredmn.v_tdredmpayout_details(l_index).instno;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).instno IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).instno,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).instno,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDMPAYOUT_DETAILS.REDM_PAYOUT_COMP';
                     IF Fn_Amendable('ICTMS_TDREDMPAYOUT_DETAILS.REDM_PAYOUT_COMP') THEN
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).redm_payout_comp := p_icdredmn.v_tdredmpayout_details(l_index).redm_payout_comp;
                     ELSE
                        IF p_icdredmn.v_tdredmpayout_details(l_index).redm_payout_comp IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).redm_payout_comp,'@') <>
                              NVL(p_icdredmn.v_tdredmpayout_details(l_index).redm_payout_comp,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;

                     l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
                     IF  l_Rec_modified THEN
                        IF l_Modified_Flds IS NOT NULL THEN
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                           p_icdredmn.v_tdredmpayout_details(l_index).seqno;
                           i :=  1;
                           l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           WHILE l_mod_fld <> 'EOPL' LOOP
                              Pr_Log_Error(p_Source,'ST-AMND-003','@'||l_Mod_Fld||'~@'||l_Blk||'~'||l_Key );
                              i := i +1;
                              l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           END LOOP;
                        END IF;
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               p_Wrk_icdredmn.v_tdredmpayout_details(p_Wrk_icdredmn.v_tdredmpayout_details.COUNT +1 ) :=  p_icdredmn.v_tdredmpayout_details(l_index);
               IF l_Amendable_Nodes.EXISTS('ICTMS_TDREDMPAYOUT_DETAILS') THEN
                  IF l_Amendable_Nodes('ICTMS_TDREDMPAYOUT_DETAILS').New_Allowed = 'N' THEN
                     Dbg('New Record Cannot Be Added..');
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                     p_icdredmn.v_tdredmpayout_details(l_index).seqno;
                     Pr_Log_Error(p_source,'ST-AMND-004',l_key||'~@'||l_blk);
                  END IF;
               ELSE
                  Dbg('New Record Cannot Be Added..');
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                  p_icdredmn.v_tdredmpayout_details(l_index).seqno;
                  Pr_Log_Error(p_Source,'ST-AMND-004',l_key||'~@'||l_blk);
               END IF;
            END IF;
         END LOOP;
      END IF;

      IF l_Amendable_Nodes.EXISTS('ICTMS_TDREDMPAYOUT_DETAILS') THEN
         IF l_Amendable_Nodes('ICTMS_TDREDMPAYOUT_DETAILS').All_Records = 'Y' THEN
            Dbg('Logic For Deleting Some Records From Work Record  if Not sent..');
            l_Wrk_Count := p_Wrk_icdredmn.v_tdredmpayout_details.COUNT;
            l_Count     := p_icdredmn.v_tdredmpayout_details.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_count  LOOP
                  l_Rec_Found := FALSE;
                  IF l_Count > 0 THEN
                     FOR l_index IN 1..l_Count  LOOP
                        IF (NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).seqno,'@')=  NVL(p_icdredmn.v_tdredmpayout_details  (l_index).seqno,'@')) THEN
                           Dbg('Record Found..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_Rec_Found THEN
                     Dbg('Adding  a Record...');
                     N_v_tdredmpayout_details(N_v_tdredmpayout_details.COUNT +1 ) :=  p_Wrk_icdredmn.v_tdredmpayout_details(l_Index1);
                  ELSE
                     l_Deleted_Recs := l_Deleted_Recs +1;
                     IF l_Amendable_Nodes.EXISTS('ICTMS_TDREDMPAYOUT_DETAILS') THEN
                        IF l_Amendable_Nodes('ICTMS_TDREDMPAYOUT_DETAILS').Delete_Allowed = 'N' THEN
                           Dbg('Record Cannot Be Deleted..');
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                           p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).seqno;
                           Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                        END IF;
                     ELSE
                        Dbg('Record Cannot Be Deleted..');
                        l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDMPAYOUT_DETAILS.SEQNO')||'-'||
                        p_Wrk_icdredmn.v_tdredmpayout_details(l_index1).seqno;
                        Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            p_Wrk_icdredmn.v_tdredmpayout_details:= N_v_tdredmpayout_details;
         END IF;
      END IF;
      l_Blk := 'STTMS_DENOM_REDMN_BLK';
      l_Count      := p_icdredmn.v_sttms_denom_redmn_blk.COUNT;
      l_Wrk_Count  := p_Wrk_icdredmn.v_sttms_denom_redmn_blk.COUNT;
      IF l_Count > 0 THEN
         FOR l_index IN 1..l_Count  LOOP
            l_Rec_Found := FALSE;
            l_Rec_Modified := FALSE;
            l_Modified_Flds := NULL;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no,'@')=  NVL(p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_no,'@')) THEN
                     Dbg('Record Found..');
                     l_Rec_Found := TRUE;
                     l_fld := 'STTMS_DENOM_REDMN_BLK.BRANCH_CODE';
                     IF Fn_Amendable('STTMS_DENOM_REDMN_BLK.BRANCH_CODE') THEN
                        p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).branch_code := p_icdredmn.v_sttms_denom_redmn_blk(l_index).branch_code;
                     ELSE
                        IF p_icdredmn.v_sttms_denom_redmn_blk(l_index).branch_code IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).branch_code,'@') <>
                              NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index).branch_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'STTMS_DENOM_REDMN_BLK.CERTIFICATE_AMOUNT';
                     IF Fn_Amendable('STTMS_DENOM_REDMN_BLK.CERTIFICATE_AMOUNT') THEN
                        p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_amount := p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_amount;
                     ELSE
                        IF p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_amount IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_amount,-1) <>
                              NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_amount,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'STTMS_DENOM_REDMN_BLK.BLOCK_OR_REDEM';
                     IF Fn_Amendable('STTMS_DENOM_REDMN_BLK.BLOCK_OR_REDEM') THEN
                        p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).block_or_redem := p_icdredmn.v_sttms_denom_redmn_blk(l_index).block_or_redem;
                     ELSE
                        IF p_icdredmn.v_sttms_denom_redmn_blk(l_index).block_or_redem IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).block_or_redem,'@') <>
                              NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index).block_or_redem,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'STTMS_DENOM_REDMN_BLK.CERTIFICATE_STATUS';
                     IF Fn_Amendable('STTMS_DENOM_REDMN_BLK.CERTIFICATE_STATUS') THEN
                        p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_status := p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_status;
                     ELSE
                        IF p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_status IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_status,'@') <>
                              NVL(p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_status,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;

                     l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
                     IF  l_Rec_modified THEN
                        IF l_Modified_Flds IS NOT NULL THEN
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO')||'-'||
                           p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no;
                           i :=  1;
                           l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           WHILE l_mod_fld <> 'EOPL' LOOP
                              Pr_Log_Error(p_Source,'ST-AMND-003','@'||l_Mod_Fld||'~@'||l_Blk||'~'||l_Key );
                              i := i +1;
                              l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           END LOOP;
                        END IF;
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               p_Wrk_icdredmn.v_sttms_denom_redmn_blk(p_Wrk_icdredmn.v_sttms_denom_redmn_blk.COUNT +1 ) :=  p_icdredmn.v_sttms_denom_redmn_blk(l_index);
               IF l_Amendable_Nodes.EXISTS('STTMS_DENOM_REDMN_BLK') THEN
                  IF l_Amendable_Nodes('STTMS_DENOM_REDMN_BLK').New_Allowed = 'N' THEN
                     Dbg('New Record Cannot Be Added..');
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO')||'-'||
                     p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no;
                     Pr_Log_Error(p_source,'ST-AMND-004',l_key||'~@'||l_blk);
                  END IF;
               ELSE
                  Dbg('New Record Cannot Be Added..');
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO')||'-'||
                  p_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no;
                  Pr_Log_Error(p_Source,'ST-AMND-004',l_key||'~@'||l_blk);
               END IF;
            END IF;
         END LOOP;
      END IF;

      IF l_Amendable_Nodes.EXISTS('STTMS_DENOM_REDMN_BLK') THEN
         IF l_Amendable_Nodes('STTMS_DENOM_REDMN_BLK').All_Records = 'Y' THEN
            Dbg('Logic For Deleting Some Records From Work Record  if Not sent..');
            l_Wrk_Count := p_Wrk_icdredmn.v_sttms_denom_redmn_blk.COUNT;
            l_Count     := p_icdredmn.v_sttms_denom_redmn_blk.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_count  LOOP
                  l_Rec_Found := FALSE;
                  IF l_Count > 0 THEN
                     FOR l_index IN 1..l_Count  LOOP
                        IF (NVL(p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_no,'@')=  NVL(p_icdredmn.v_sttms_denom_redmn_blk  (l_index).certificate_no,'@')) THEN
                           Dbg('Record Found..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_Rec_Found THEN
                     Dbg('Adding  a Record...');
                     N_v_sttms_denom_redmn_blk(N_v_sttms_denom_redmn_blk.COUNT +1 ) :=  p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_Index1);
                  ELSE
                     l_Deleted_Recs := l_Deleted_Recs +1;
                     IF l_Amendable_Nodes.EXISTS('STTMS_DENOM_REDMN_BLK') THEN
                        IF l_Amendable_Nodes('STTMS_DENOM_REDMN_BLK').Delete_Allowed = 'N' THEN
                           Dbg('Record Cannot Be Deleted..');
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO')||'-'||
                           p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_no;
                           Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                        END IF;
                     ELSE
                        Dbg('Record Cannot Be Deleted..');
                        l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'STTMS_DENOM_REDMN_BLK.CERTIFICATE_NO')||'-'||
                        p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index1).certificate_no;
                        Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            p_Wrk_icdredmn.v_sttms_denom_redmn_blk:= N_v_sttms_denom_redmn_blk;
         END IF;
      END IF;
      l_Blk := 'ICTMS_TDREDPAYIN_DETAILS';
      l_Count      := p_icdredmn.v_ictms_tdredpayin_details.COUNT;
      l_Wrk_Count  := p_Wrk_icdredmn.v_ictms_tdredpayin_details.COUNT;
      IF l_Count > 0 THEN
         FOR l_index IN 1..l_Count  LOOP
            l_Rec_Found := FALSE;
            l_Rec_Modified := FALSE;
            l_Modified_Flds := NULL;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).acc,'@')=  NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).acc,'@')) AND (NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).seqno,-1)=  NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).seqno,-1)) AND (NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).brn,'@')=  NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).brn,'@')) THEN
                     Dbg('Record Found..');
                     l_Rec_Found := TRUE;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.CCY';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.CCY') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).ccy := p_icdredmn.v_ictms_tdredpayin_details(l_index).ccy;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).ccy,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_PAYOPT';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_PAYOPT') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_payopt := p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_payopt;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_payopt IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_payopt,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_payopt,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDAMOUNT';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDAMOUNT') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_tdamount := p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdamount;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdamount IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_tdamount,-1) <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdamount,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_offset_brn := p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_offset_brn;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_offset_brn IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_offset_brn,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_offset_brn,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_tdoffset_acc := p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdoffset_acc;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdoffset_acc IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_tdoffset_acc,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdoffset_acc,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDOFFSET_CCY';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDOFFSET_CCY') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_tdoffset_ccy := p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdoffset_ccy;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdoffset_ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_tdoffset_ccy,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_tdoffset_ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.REFERENCE_NO';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.REFERENCE_NO') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).reference_no := p_icdredmn.v_ictms_tdredpayin_details(l_index).reference_no;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).reference_no IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).reference_no,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).reference_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_PERCENTAGE';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_PERCENTAGE') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_percentage := p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_percentage;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_percentage IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).multimode_percentage,-1) <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).multimode_percentage,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.MULITMODE_XRATE';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.MULITMODE_XRATE') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).mulitmode_xrate := p_icdredmn.v_ictms_tdredpayin_details(l_index).mulitmode_xrate;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).mulitmode_xrate IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).mulitmode_xrate,-1) <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).mulitmode_xrate,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.CHQ_INSTUMENTNO';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.CHQ_INSTUMENTNO') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).chq_instumentno := p_icdredmn.v_ictms_tdredpayin_details(l_index).chq_instumentno;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).chq_instumentno IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).chq_instumentno,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).chq_instumentno,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.CLG_BANK_CODE';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.CLG_BANK_CODE') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).clg_bank_code := p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_bank_code;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_bank_code IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).clg_bank_code,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_bank_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.CLG_BRANCH_CODE';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.CLG_BRANCH_CODE') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).clg_branch_code := p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_branch_code;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_branch_code IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).clg_branch_code,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_branch_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.CLG_PRODUCT_CODE';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.CLG_PRODUCT_CODE') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).clg_product_code := p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_product_code;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_product_code IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).clg_product_code,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).clg_product_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.CHQ_INSTRUMENT_DATE';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.CHQ_INSTRUMENT_DATE') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).chq_instrument_date := p_icdredmn.v_ictms_tdredpayin_details(l_index).chq_instrument_date;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).chq_instrument_date IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).chq_instrument_date,global.min_date) <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).chq_instrument_date,global.min_date)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.DRAWEE_AC_NO';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.DRAWEE_AC_NO') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).drawee_ac_no := p_icdredmn.v_ictms_tdredpayin_details(l_index).drawee_ac_no;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).drawee_ac_no IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).drawee_ac_no,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).drawee_ac_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'ICTMS_TDREDPAYIN_DETAILS.ROUTING_NO';
                     IF Fn_Amendable('ICTMS_TDREDPAYIN_DETAILS.ROUTING_NO') THEN
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).routing_no := p_icdredmn.v_ictms_tdredpayin_details(l_index).routing_no;
                     ELSE
                        IF p_icdredmn.v_ictms_tdredpayin_details(l_index).routing_no IS NOT NULL THEN
                           IF NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).routing_no,'@') <>
                              NVL(p_icdredmn.v_ictms_tdredpayin_details(l_index).routing_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;

                     l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
                     IF  l_Rec_modified THEN
                        IF l_Modified_Flds IS NOT NULL THEN
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                           p_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                           Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                           p_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                           Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                           p_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                           i :=  1;
                           l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           WHILE l_mod_fld <> 'EOPL' LOOP
                              Pr_Log_Error(p_Source,'ST-AMND-003','@'||l_Mod_Fld||'~@'||l_Blk||'~'||l_Key );
                              i := i +1;
                              l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           END LOOP;
                        END IF;
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               p_Wrk_icdredmn.v_ictms_tdredpayin_details(p_Wrk_icdredmn.v_ictms_tdredpayin_details.COUNT +1 ) :=  p_icdredmn.v_ictms_tdredpayin_details(l_index);
               IF l_Amendable_Nodes.EXISTS('ICTMS_TDREDPAYIN_DETAILS') THEN
                  IF l_Amendable_Nodes('ICTMS_TDREDPAYIN_DETAILS').New_Allowed = 'N' THEN
                     Dbg('New Record Cannot Be Added..');
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                     p_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                     p_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                     p_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                     Pr_Log_Error(p_source,'ST-AMND-004',l_key||'~@'||l_blk);
                  END IF;
               ELSE
                  Dbg('New Record Cannot Be Added..');
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                  p_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                  Pr_Log_Error(p_Source,'ST-AMND-004',l_key||'~@'||l_blk);
               END IF;
            END IF;
         END LOOP;
      END IF;

      IF l_Amendable_Nodes.EXISTS('ICTMS_TDREDPAYIN_DETAILS') THEN
         IF l_Amendable_Nodes('ICTMS_TDREDPAYIN_DETAILS').All_Records = 'Y' THEN
            Dbg('Logic For Deleting Some Records From Work Record  if Not sent..');
            l_Wrk_Count := p_Wrk_icdredmn.v_ictms_tdredpayin_details.COUNT;
            l_Count     := p_icdredmn.v_ictms_tdredpayin_details.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_count  LOOP
                  l_Rec_Found := FALSE;
                  IF l_Count > 0 THEN
                     FOR l_index IN 1..l_Count  LOOP
                        IF (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).acc,'@')=  NVL(p_icdredmn.v_ictms_tdredpayin_details  (l_index).acc,'@')) AND (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).seqno,-1)=  NVL(p_icdredmn.v_ictms_tdredpayin_details  (l_index).seqno,-1)) AND (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).brn,'@')=  NVL(p_icdredmn.v_ictms_tdredpayin_details  (l_index).brn,'@')) THEN
                           Dbg('Record Found..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_Rec_Found THEN
                     Dbg('Adding  a Record...');
                     N_v_ictms_tdredpayin_details(N_v_ictms_tdredpayin_details.COUNT +1 ) :=  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_Index1);
                  ELSE
                     l_Deleted_Recs := l_Deleted_Recs +1;
                     IF l_Amendable_Nodes.EXISTS('ICTMS_TDREDPAYIN_DETAILS') THEN
                        IF l_Amendable_Nodes('ICTMS_TDREDPAYIN_DETAILS').Delete_Allowed = 'N' THEN
                           Dbg('Record Cannot Be Deleted..');
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                           p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).acc||':'||
                           Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                           p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).seqno||':'||
                           Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                           p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).brn;
                           Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                        END IF;
                     ELSE
                        Dbg('Record Cannot Be Deleted..');
                        l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).acc||':'||
                        Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).seqno||':'||
                        Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                        p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index1).brn;
                        Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            p_Wrk_icdredmn.v_ictms_tdredpayin_details:= N_v_ictms_tdredpayin_details;
         END IF;
      END IF;

      l_Blk := 'ICTB_TD_REDEM_MASTER_CUSTOM';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_Rec_Sent := FALSE;
      IF p_icdredmn.v_td_redem_master_custom.redem_ref_no IS NOT NULL THEN
         dbg('Record Has Been Sent..');
         p_Wrk_icdredmn.v_td_redem_master_custom.redem_ref_no := p_icdredmn.v_td_redem_master_custom.redem_ref_no;
         l_Rec_Sent := TRUE;
      END IF;
      IF l_Rec_Sent THEN
         l_fld := 'ICTB_TD_REDEM_MASTER_CUSTOM.BRANCH_CODE';
         IF Fn_Amendable('ICTB_TD_REDEM_MASTER_CUSTOM.BRANCH_CODE') THEN
            p_Wrk_icdredmn.v_td_redem_master_custom.branch_code := p_icdredmn.v_td_redem_master_custom.branch_code;
         ELSE
            IF p_icdredmn.v_td_redem_master_custom.branch_code IS NOT NULL THEN
               IF NVL(p_Wrk_icdredmn.v_td_redem_master_custom.branch_code,'@') <>
                  NVL(p_icdredmn.v_td_redem_master_custom.branch_code,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'ICTB_TD_REDEM_MASTER_CUSTOM.ACC_NO';
         IF Fn_Amendable('ICTB_TD_REDEM_MASTER_CUSTOM.ACC_NO') THEN
            p_Wrk_icdredmn.v_td_redem_master_custom.acc_no := p_icdredmn.v_td_redem_master_custom.acc_no;
         ELSE
            IF p_icdredmn.v_td_redem_master_custom.acc_no IS NOT NULL THEN
               IF NVL(p_Wrk_icdredmn.v_td_redem_master_custom.acc_no,'@') <>
                  NVL(p_icdredmn.v_td_redem_master_custom.acc_no,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'ICTB_TD_REDEM_MASTER_CUSTOM.CUST_ID';
         IF Fn_Amendable('ICTB_TD_REDEM_MASTER_CUSTOM.CUST_ID') THEN
            p_Wrk_icdredmn.v_td_redem_master_custom.cust_id := p_icdredmn.v_td_redem_master_custom.cust_id;
         ELSE
            IF p_icdredmn.v_td_redem_master_custom.cust_id IS NOT NULL THEN
               IF NVL(p_Wrk_icdredmn.v_td_redem_master_custom.cust_id,'@') <>
                  NVL(p_icdredmn.v_td_redem_master_custom.cust_id,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'ICTB_TD_REDEM_MASTER_CUSTOM.WAIVE_INSURANCE_FEE';
         IF Fn_Amendable('ICTB_TD_REDEM_MASTER_CUSTOM.WAIVE_INSURANCE_FEE') THEN
            p_Wrk_icdredmn.v_td_redem_master_custom.waive_insurance_fee := p_icdredmn.v_td_redem_master_custom.waive_insurance_fee;
         ELSE
            IF p_icdredmn.v_td_redem_master_custom.waive_insurance_fee IS NOT NULL THEN
               IF NVL(p_Wrk_icdredmn.v_td_redem_master_custom.waive_insurance_fee,'@') <>
                  NVL(p_icdredmn.v_td_redem_master_custom.waive_insurance_fee,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'ICTB_TD_REDEM_MASTER_CUSTOM.INSURANCE_AMOUNT';
         IF Fn_Amendable('ICTB_TD_REDEM_MASTER_CUSTOM.INSURANCE_AMOUNT') THEN
            p_Wrk_icdredmn.v_td_redem_master_custom.insurance_amount := p_icdredmn.v_td_redem_master_custom.insurance_amount;
         ELSE
            IF p_icdredmn.v_td_redem_master_custom.insurance_amount IS NOT NULL THEN
               IF NVL(p_Wrk_icdredmn.v_td_redem_master_custom.insurance_amount,-1) <>
                  NVL(p_icdredmn.v_td_redem_master_custom.insurance_amount,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;

         l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
         IF  l_Rec_Modified THEN
            IF l_Modified_Flds IS NOT NULL THEN
               i :=  1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
               WHILE l_Mod_Fld <> 'EOPL' LOOP
                  Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
                  i := i +1;
                  l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
               END LOOP;
            END IF;
         END IF;
      ELSE

         IF l_Amendable_Nodes.EXISTS('ICTB_TD_REDEM_MASTER_CUSTOM') THEN
            IF l_Amendable_Nodes('ICTB_TD_REDEM_MASTER_CUSTOM').All_Records = 'Y' THEN
               p_Wrk_icdredmn.v_td_redem_master_custom :=NULL;
            END IF;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Merge_Amendables..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Merge_Amendables..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Merge_Amendables;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_icdredmn IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER  := 0;
      l_Dsn_Rec_Cnt_3 NUMBER := 0;
      l_Bnd_Cntr_3    NUMBER  := 0;
      l_Dsn_Rec_Cnt_4 NUMBER := 0;
      l_Bnd_Cntr_4    NUMBER  := 0;
      l_Dsn_Rec_Cnt_5 NUMBER := 0;
      l_Bnd_Cntr_5    NUMBER  := 0;
      l_Dsn_Rec_Cnt_6 NUMBER := 0;
      l_Bnd_Cntr_6    NUMBER  := 0;
      l_Dsn_Rec_Cnt_7 NUMBER := 0;
      l_Bnd_Cntr_7    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      l_Blk := 'ICTBS_TDREDEMPTION_MASTER';
      l_Fld := 'ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE';
      IF p_wrk_icdredmn.v_ictbs_tdredemption_master.PRODUCT_CODE IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT D.PRODUCT_CODE,C.PRODUCT_DESCRIPTION FROM detm_rt_preferences D,CSTMS_PRODUCT C WHERE D.REDEMPTION_ALLOWED='Y' AND D.PRODUCT_CODE=C.PRODUCT_CODE AND C.RECORD_STAT='O' AND C.AUTH_STAT='A') WHERE PRODUCT_CODE = P_wrk_icdredmn.v_ictbs_tdredemption_master.PRODUCT_CODE;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :PRODUCT_CODE:'||p_Wrk_icdredmn.v_ictbs_tdredemption_master.PRODUCT_CODE);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_icdredmn.v_ictbs_tdredemption_master.PRODUCT_CODE||'~@ICTBS_TDREDEMPTION_MASTER.PRODUCT_CODE~@ICTBS_TDREDEMPTION_MASTER') ;
         END IF;
      END IF;
      l_Count      := p_Wrk_icdredmn.v_ictms_tdredpayin_details.COUNT;
      IF l_Count > 0 THEN
         FOR l_Index  IN 1 .. l_Count LOOP
            l_Blk := 'ICTMS_TDREDPAYIN_DETAILS';
            l_Fld := 'ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC';
            IF p_wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).MULTIMODE_TDOFFSET_ACC IS NOT NULL THEN
               SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (select a.ac_gl_no, nvl(a.branch_code,global.current_branch)branch_code, decode(a.ac_or_gl, 'A', a.ac_gl_Ccy, '') ccy, a.ac_gl_desc ADESC, a.ac_or_gl PAYIN from sttb_account a where a.ac_or_GL = DECODE(P_wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).MULTIMODE_PAYOPT, 'S', 'A', 'G', 'G') and ((a.ac_or_GL = 'G' and exists (select 1 from sttms_payin_mode c where c.branch_code = global.current_branch and c.payin_option = 'G' and c.gl_code = a.ac_gl_no) or (a.ac_or_GL = 'A' and exists (select '1' from sttm_cust_account where cust_ac_no = a.ac_gl_no and branch_Code = a.branch_code and account_type <> 'Y' AND CUST_NO IN (SELECT X.CUSTOMER_NO FROM STTMS_CUSTOMER X WHERE((X.access_group IS NOT NULL AND EXISTS (SELECT 1 FROM Stvw_User_Access c WHERE c.USER_ID = GLOBAL.USER_ID AND c.access_group = X.access_group)) OR X.access_group IS NULL)))))) and a.once_auth = 'Y' and a.ac_gl_rec_Status = 'O') WHERE AC_GL_NO = P_wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).MULTIMODE_TDOFFSET_ACC;
               IF l_lov_count = 0  THEN
                  Dbg('Invalid Value For The Field  :MULTIMODE_TDOFFSET_ACC:'||p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).MULTIMODE_TDOFFSET_ACC);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).MULTIMODE_TDOFFSET_ACC||'~@ICTMS_TDREDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC'||'~'||l_Key||'~@ICTMS_TDREDPAYIN_DETAILS') ;
               END IF;
            END IF;
            l_Fld := 'ICTMS_TDREDPAYIN_DETAILS.CLG_PRODUCT_CODE';
            IF p_wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).CLG_PRODUCT_CODE IS NOT NULL THEN
               SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT PRODUCT_CODE,PRODUCT_DESCRIPTION FROM cstm_product WHERE MODULE='CG' AND PRODUCT_TYPE='OC'AND RECORD_STAT='O' AND AUTH_STAT='A' AND ONCE_AUTH='Y') WHERE PRODUCT_CODE = P_wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).CLG_PRODUCT_CODE;
               IF l_lov_count = 0  THEN
                  Dbg('Invalid Value For The Field  :CLG_PRODUCT_CODE:'||p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).CLG_PRODUCT_CODE);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).CLG_PRODUCT_CODE||'~@ICTMS_TDREDPAYIN_DETAILS.CLG_PRODUCT_CODE'||'~'||l_Key||'~@ICTMS_TDREDPAYIN_DETAILS') ;
               END IF;
            END IF;
            l_Fld := 'ICTMS_TDREDPAYIN_DETAILS.ROUTING_NO';
            IF p_wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).ROUTING_NO IS NOT NULL THEN
               SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT DECODE(FIRST,'S',SEC,'B', BNK,BRN) || DECODE(SECOND,'S',SEC,'B', BNK,BRN) || DECODE(LAST,'S',SEC,'B', BNK,BRN) ROUTING_NO,BRN,BNK FROM (SELECT brn.sector_code "SEC",brn.branch_code "BRN",brn.bank_code "BNK",(SELECT ROUTING_MASK FROM STTM_BANK) ROUTING_MASK,(SELECT SUBSTR(ROUTING_MASK,0,1) FROM STTM_BANK) FIRST,(SELECT SUBSTR(ROUTING_MASK,LENGTH(ROUTING_MASK),1) FROM STTM_BANK) LAST,(SELECT SUBSTR(REPLACE(REPLACE(ROUTING_MASK,SUBSTR(ROUTING_MASK,0,1),''),SUBSTR(ROUTING_MASK,LENGTH(ROUTING_MASK),1),''),0,1) FROM STTM_BANK) SECOND FROM detm_clg_brn_code brn, detm_clg_bank_code bnk WHERE brn.bank_code = bnk.clg_bank_code AND brn.bank_code NOT IN (SELECT CLG_BANK_CD FROM STTM_BANK) ORDER BY branch_code) ROUTING_DET) WHERE ROUTING_NO = P_wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).ROUTING_NO;
               IF l_lov_count = 0  THEN
                  Dbg('Invalid Value For The Field  :ROUTING_NO:'||p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).ROUTING_NO);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.ACC')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).acc||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.SEQNO')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).seqno||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTMS_TDREDPAYIN_DETAILS.BRN')||'-'||
                  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).brn;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_Index).ROUTING_NO||'~@ICTMS_TDREDPAYIN_DETAILS.ROUTING_NO'||'~'||l_Key||'~@ICTMS_TDREDPAYIN_DETAILS') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Prev_icdredmn IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_icdredmn  IN   OUT icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      l_Dsn_Rec_Cnt_3 NUMBER := 0;
      l_Bnd_Cntr_3    NUMBER := 0;
      l_Dsn_Rec_Cnt_5 NUMBER := 0;
      l_Bnd_Cntr_5    NUMBER := 0;
      l_Dsn_Rec_Cnt_6 NUMBER := 0;
      l_Bnd_Cntr_6    NUMBER := 0;
      l_Dsn_Rec_Cnt_7 NUMBER := 0;
      l_Bnd_Cntr_7    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Sys_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_icdredmn         IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn  IN   OUT icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Wrk_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists        BOOLEAN := TRUE;
      RECORD_LOCKED    EXCEPTION;
      PRAGMA EXCEPTION_INIT( RECORD_LOCKED, -54 );
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      l_Dsn_Rec_Cnt_5 NUMBER := 0;
      l_Bnd_Cntr_5    NUMBER := 0;
      l_Dsn_Rec_Cnt_6 NUMBER := 0;
      l_Bnd_Cntr_6    NUMBER := 0;
      l_Dsn_Rec_Cnt_7 NUMBER := 0;
      l_Bnd_Cntr_7    NUMBER := 0;
      Cursor c_v_tdredmpayout_details IS
      SELECT *
      FROM   ICTM_TDREDMPAYOUT_DETAILS
      WHERE redem_ref_no = p_wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
      ;
      Cursor c_v_sttms_denom_redmn_blk IS
      SELECT *
      FROM   STTM_DENOM_REDMN_BLK
      WHERE BLOCK_OR_REDEM='R' AND reference_no = p_wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
       AND cust_ac_no = p_wrk_icdredmn.v_ictbs_tdredemption_master.acc_no
       AND branch_code = p_wrk_icdredmn.v_ictbs_tdredemption_master.branch_code
      ;
      Cursor c_v_ictms_tdredpayin_details IS
      SELECT *
      FROM   ICTM_TDREDPAYIN_DETAILS
      WHERE redem_ref_no = p_wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
      ;
   BEGIN
      Dbg('In Fn_Sys_Query..');
      IF p_QryData_Reqd = 'Q' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_icdredmn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      ELSE
         l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'ICTBS_TDREDEMPTION_MASTER.REDEM_REF_NO')||'-'||
         p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no;
         Dbg('Get The Master Record...');
         IF NVL(p_With_Lock,'N') = 'Y' THEN
            BEGIN
               SELECT *
               INTO   p_wrk_icdredmn.v_ictbs_tdredemption_master
               FROM  ICTB_TDREDEMPTION_MASTER
               WHERE redem_ref_no = p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
                FOR UPDATE NOWAIT;
            EXCEPTION
               WHEN RECORD_LOCKED THEN
                  Dbg('Failed to Obtain the Lock..');
                  Pr_Log_Error(p_Source,'ST-LOCK-001',NULL);
                  RETURN FALSE;
               WHEN No_Data_Found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  l_Rec_Exists := FALSE;
            END;

         ELSE
            BEGIN
               SELECT *
               INTO   p_Wrk_icdredmn.v_ictbs_tdredemption_master
               FROM  ICTB_TDREDEMPTION_MASTER
               WHERE redem_ref_no = p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
               ;
            EXCEPTION
               WHEN no_data_found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  p_Err_Code    := 'ST-VALS-002';
                  p_Err_Params  := l_Key;
                  RETURN FALSE;
            END;

         END IF;
         IF p_Full_Data = 'Y' AND l_Rec_Exists THEN
            Dbg('Get the Record For :ICTBS_TDREDEMPTION_MASTER');
            BEGIN
               SELECT *
               INTO p_Wrk_icdredmn.v_ictbs_tdredemption_master
               FROM   ICTB_TDREDEMPTION_MASTER
               WHERE redem_ref_no = p_wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :ICTBS_TDREDEMPTION_MASTER');
            END;
            Dbg('Get the Record For :ICTMS_TDREDMPAYOUT_DETAILS');
            OPEN c_v_tdredmpayout_details;
            LOOP
               FETCH c_v_tdredmpayout_details
               BULK COLLECT INTO p_Wrk_icdredmn.v_tdredmpayout_details;
                EXIT WHEN c_v_tdredmpayout_details%NOTFOUND;
            END LOOP;
            CLOSE c_v_tdredmpayout_details;
            Dbg('Get the Record For :STTMS_DENOM_REDMN_BLK');
            OPEN c_v_sttms_denom_redmn_blk;
            LOOP
               FETCH c_v_sttms_denom_redmn_blk
               BULK COLLECT INTO p_Wrk_icdredmn.v_sttms_denom_redmn_blk;
                EXIT WHEN c_v_sttms_denom_redmn_blk%NOTFOUND;
            END LOOP;
            CLOSE c_v_sttms_denom_redmn_blk;
            Dbg('Get the Record For :ICTMS_TDREDPAYIN_DETAILS');
            OPEN c_v_ictms_tdredpayin_details;
            LOOP
               FETCH c_v_ictms_tdredpayin_details
               BULK COLLECT INTO p_Wrk_icdredmn.v_ictms_tdredpayin_details;
                EXIT WHEN c_v_ictms_tdredpayin_details%NOTFOUND;
            END LOOP;
            CLOSE c_v_ictms_tdredpayin_details;
            Dbg('Get the Record For :ICTB_TD_REDEM_MASTER_CUSTOM');
            BEGIN
               SELECT *
               INTO p_Wrk_icdredmn.v_td_redem_master_custom
               FROM   ICTB_TD_REDEM_MASTER_CUSTOM
               WHERE redem_ref_no = p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :ICTB_TD_REDEM_MASTER_CUSTOM');
            END;

         END IF;
         IF p_QryData_Reqd = 'Y' THEN
            Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
            IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Wrk_icdredmn,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
               RETURN FALSE;
            END IF;
         END IF;

      END IF;
      Dbg('Returning Success From Fn_Sys_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         IF  c_v_tdredmpayout_details%ISOPEN THEN
            CLOSE c_v_tdredmpayout_details;
         END IF;
         IF  c_v_sttms_denom_redmn_blk%ISOPEN THEN
            CLOSE c_v_sttms_denom_redmn_blk;
         END IF;
         IF  c_v_ictms_tdredpayin_details%ISOPEN THEN
            CLOSE c_v_ictms_tdredpayin_details;
         END IF;
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query;
   FUNCTION Fn_Sys_Upload_Db         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Prev_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn      IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Count             NUMBER:= 0;
      l_Ins_Count         NUMBER:= 0;
      l_Upd_Count         NUMBER:= 0;
      l_Del_Count         NUMBER:= 0;
      l_Wrk_Count         NUMBER:= 0;
      l_Prev_Count        NUMBER:= 0;
      l_Rec_Found         BOOLEAN:= FALSE;
      l_Row_Id            ROWID;
      l_Key               VARCHAR2(5000):= NULL;
      l_Auth_Stat         VARCHAR2(1) := 'A';
      l_Base_Data_From_Fc VARCHAR2(1):= 'Y';
      I_v_tdredmpayout_details       icpks_icdredmn_Main.Ty_Tb_v_tdredmpayout_details;
      U_v_tdredmpayout_details       icpks_icdredmn_Main.Ty_Tb_v_tdredmpayout_details;
      D_v_tdredmpayout_details       icpks_icdredmn_Main.Ty_Tb_v_tdredmpayout_details;
      I_v_sttms_denom_redmn_blk       icpks_icdredmn_Main.Ty_Tb_v_sttms_denom_redmn_blk;
      U_v_sttms_denom_redmn_blk       icpks_icdredmn_Main.Ty_Tb_v_sttms_denom_redmn_blk;
      D_v_sttms_denom_redmn_blk       icpks_icdredmn_Main.Ty_Tb_v_sttms_denom_redmn_blk;
      I_v_ictms_tdredpayin_details       icpks_icdredmn_Main.Ty_Tb_ictms_tdredpayin_details;
      U_v_ictms_tdredpayin_details       icpks_icdredmn_Main.Ty_Tb_ictms_tdredpayin_details;
      D_v_ictms_tdredpayin_details       icpks_icdredmn_Main.Ty_Tb_ictms_tdredpayin_details;
   BEGIN
      Dbg('In Fn_Sys_Upload_Db..');
      IF p_Action_Code = Cspks_Req_Global.p_new THEN

         Dbg('Inserting Into ICTBS_TDREDEMPTION_MASTER..');
         BEGIN
            IF  p_wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  ICTB_TDREDEMPTION_MASTER
               VALUES p_wrk_icdredmn.v_ictbs_tdredemption_master;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoICTBS_TDREDEMPTION_MASTER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@ICTBS_TDREDEMPTION_MASTER';
               RETURN FALSE;
         END;

         Dbg('Inserting Into ICTMS_TDREDMPAYOUT_DETAILS..');
         BEGIN
            l_Count      := p_wrk_icdredmn.v_tdredmpayout_details.COUNT;
            FORALL l_index IN  1..l_count
            INSERT INTO ICTM_TDREDMPAYOUT_DETAILS
            VALUES p_wrk_icdredmn.v_tdredmpayout_details(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoICTMS_TDREDMPAYOUT_DETAILS..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@ICTMS_TDREDMPAYOUT_DETAILS';
               RETURN FALSE;
         END;

         Dbg('Inserting Into STTMS_DENOM_REDMN_BLK..');
         BEGIN
            l_Count      := p_wrk_icdredmn.v_sttms_denom_redmn_blk.COUNT;
            FORALL l_index IN  1..l_count
            INSERT INTO STTM_DENOM_REDMN_BLK
            VALUES p_wrk_icdredmn.v_sttms_denom_redmn_blk(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoSTTMS_DENOM_REDMN_BLK..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@STTMS_DENOM_REDMN_BLK';
               RETURN FALSE;
         END;

         Dbg('Inserting Into ICTMS_TDREDPAYIN_DETAILS..');
         BEGIN
            l_Count      := p_wrk_icdredmn.v_ictms_tdredpayin_details.COUNT;
            FORALL l_index IN  1..l_count
            INSERT INTO ICTM_TDREDPAYIN_DETAILS
            VALUES p_wrk_icdredmn.v_ictms_tdredpayin_details(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoICTMS_TDREDPAYIN_DETAILS..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@ICTMS_TDREDPAYIN_DETAILS';
               RETURN FALSE;
         END;

         Dbg('Inserting Into ICTB_TD_REDEM_MASTER_CUSTOM..');
         BEGIN
            IF  p_wrk_icdredmn.v_td_redem_master_custom.redem_ref_no IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  ICTB_TD_REDEM_MASTER_CUSTOM
               VALUES p_wrk_icdredmn.v_td_redem_master_custom;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoICTB_TD_REDEM_MASTER_CUSTOM..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@ICTB_TD_REDEM_MASTER_CUSTOM';
               RETURN FALSE;
         END;
      ELSIF p_Action_Code = Cspks_Req_Global.p_modify THEN

         Dbg('Updating Single Record Node :  ICTBS_TDREDEMPTION_MASTER..');
         BEGIN
            UPDATE ICTB_TDREDEMPTION_MASTER
            SET
            WAIVE_INTEREST = p_Wrk_icdredmn.v_ictbs_tdredemption_master.WAIVE_INTEREST,
            GL_BRANCH = p_Wrk_icdredmn.v_ictbs_tdredemption_master.GL_BRANCH,
            ALLOW_PREPAYMENT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ALLOW_PREPAYMENT,
            SUPPRESS_REDEMPTION_ADVICE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.SUPPRESS_REDEMPTION_ADVICE,
            MUDARABAH_REDMN = p_Wrk_icdredmn.v_ictbs_tdredemption_master.MUDARABAH_REDMN,
            CONTRACT_STATUS = p_Wrk_icdredmn.v_ictbs_tdredemption_master.CONTRACT_STATUS,
            BRANCH_CODE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.BRANCH_CODE,
            ACC_NO = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ACC_NO,
            CUST_ID = p_Wrk_icdredmn.v_ictbs_tdredemption_master.CUST_ID,
            ACC_DESC = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ACC_DESC,
            ACC_AMT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ACC_AMT,
            ACTION_FLAG = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ACTION_FLAG,
            TENOR_DD = p_Wrk_icdredmn.v_ictbs_tdredemption_master.TENOR_DD,
            TENOR_MM = p_Wrk_icdredmn.v_ictbs_tdredemption_master.TENOR_MM,
            TENOR_YY = p_Wrk_icdredmn.v_ictbs_tdredemption_master.TENOR_YY,
            NEXT_MAT_DATE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.NEXT_MAT_DATE,
            REDEMPTION_BY = p_Wrk_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_BY,
            CCY = p_Wrk_icdredmn.v_ictbs_tdredemption_master.CCY,
            REDEMPTION_MODE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_MODE,
            REDEMPTION_AMT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.REDEMPTION_AMT,
            WAVE_PENALTY = p_Wrk_icdredmn.v_ictbs_tdredemption_master.WAVE_PENALTY,
            BANK_CD = p_Wrk_icdredmn.v_ictbs_tdredemption_master.BANK_CD,
            BANK_TXN_CCY = p_Wrk_icdredmn.v_ictbs_tdredemption_master.BANK_TXN_CCY,
            BANK_EXCH_RATE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.BANK_EXCH_RATE,
            BANK_TXN_AMT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.BANK_TXN_AMT,
            CHQ_DATE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.CHQ_DATE,
            CHARGES = p_Wrk_icdredmn.v_ictbs_tdredemption_master.CHARGES,
            BENEF_NAME = p_Wrk_icdredmn.v_ictbs_tdredemption_master.BENEF_NAME,
            PASSPORT_NO = p_Wrk_icdredmn.v_ictbs_tdredemption_master.PASSPORT_NO,
            ADDR1 = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ADDR1,
            ADDR2 = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ADDR2,
            BANK_NARRATIVE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.BANK_NARRATIVE,
            SAVINGS_BRN_CODE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.SAVINGS_BRN_CODE,
            SAVINGS_ACC_NO = p_Wrk_icdredmn.v_ictbs_tdredemption_master.SAVINGS_ACC_NO,
            SAVINGS_TXN_CCY = p_Wrk_icdredmn.v_ictbs_tdredemption_master.SAVINGS_TXN_CCY,
            SAVINGS_EXCH_RATE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.SAVINGS_EXCH_RATE,
            SAVINGS_TXN_AMT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.SAVINGS_TXN_AMT,
            SAVINGS_NARRATIVE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.SAVINGS_NARRATIVE,
            GL_NO = p_Wrk_icdredmn.v_ictbs_tdredemption_master.GL_NO,
            GL_TXN_CCY = p_Wrk_icdredmn.v_ictbs_tdredemption_master.GL_TXN_CCY,
            GL_EXCH_RATE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.GL_EXCH_RATE,
            GL_TXN_AMT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.GL_TXN_AMT,
            GL_NARRATIVE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.GL_NARRATIVE,
            SCODE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.SCODE,
            XREF = p_Wrk_icdredmn.v_ictbs_tdredemption_master.XREF,
            FCCREF = p_Wrk_icdredmn.v_ictbs_tdredemption_master.FCCREF,
            PAYBRN = p_Wrk_icdredmn.v_ictbs_tdredemption_master.PAYBRN,
            MICR_NO = p_Wrk_icdredmn.v_ictbs_tdredemption_master.MICR_NO,
            ADDR3 = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ADDR3,
            TRN_DT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.TRN_DT,
            BANK_CTRY_CODE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.BANK_CTRY_CODE,
            MATURITY_AMOUNT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.MATURITY_AMOUNT,
            INTEREST_RATE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.INTEREST_RATE,
            MAKER_ID = p_Wrk_icdredmn.v_ictbs_tdredemption_master.MAKER_ID,
            CHECKER_ID = p_Wrk_icdredmn.v_ictbs_tdredemption_master.CHECKER_ID,
            MAKER_DT_STAMP = p_Wrk_icdredmn.v_ictbs_tdredemption_master.MAKER_DT_STAMP,
            CHECKER_DT_STAMP = p_Wrk_icdredmn.v_ictbs_tdredemption_master.CHECKER_DT_STAMP,
            AUTH_STATUS = p_Wrk_icdredmn.v_ictbs_tdredemption_master.AUTH_STATUS,
            ROLL_TENOR_PREF = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ROLL_TENOR_PREF,
            CONT_VAR_ROLL = p_Wrk_icdredmn.v_ictbs_tdredemption_master.CONT_VAR_ROLL,
            INTRATE_CUMAMT_REQD = p_Wrk_icdredmn.v_ictbs_tdredemption_master.INTRATE_CUMAMT_REQD,
            PRODUCT_CODE = p_Wrk_icdredmn.v_ictbs_tdredemption_master.PRODUCT_CODE,
            REDEM_SEQ_NO = p_Wrk_icdredmn.v_ictbs_tdredemption_master.REDEM_SEQ_NO,
            ORG_YEARS = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ORG_YEARS,
            ORG_MONTHS = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ORG_MONTHS,
            ORG_DAYS = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ORG_DAYS,
            ADD_FUNDS = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ADD_FUNDS,
            ADDITIONAL_AMT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.ADDITIONAL_AMT,
            REDEM_INT_PAYOUT = p_Wrk_icdredmn.v_ictbs_tdredemption_master.REDEM_INT_PAYOUT
WHERE redem_ref_no = p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert Into ICTBS_TDREDEMPTION_MASTER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@ICTBS_TDREDEMPTION_MASTER';
               RETURN FALSE;
         END;




         IF  p_Wrk_icdredmn.v_td_redem_master_custom.redem_ref_no IS NOT NULL THEN
            Dbg('Record Sent..');
            Dbg('Updating Single Record Node :  ICTB_TD_REDEM_MASTER_CUSTOM..');
            BEGIN
               UPDATE ICTB_TD_REDEM_MASTER_CUSTOM
               SET
               BRANCH_CODE = p_Wrk_icdredmn.v_td_redem_master_custom.BRANCH_CODE,
               ACC_NO = p_Wrk_icdredmn.v_td_redem_master_custom.ACC_NO,
               CUST_ID = p_Wrk_icdredmn.v_td_redem_master_custom.CUST_ID,
               WAIVE_INSURANCE_FEE = p_Wrk_icdredmn.v_td_redem_master_custom.WAIVE_INSURANCE_FEE,
               INSURANCE_AMOUNT = p_Wrk_icdredmn.v_td_redem_master_custom.INSURANCE_AMOUNT
WHERE redem_ref_no = p_Wrk_icdredmn.v_td_redem_master_custom.redem_ref_no
;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed in Insert Into ICTB_TD_REDEM_MASTER_CUSTOM..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@ICTB_TD_REDEM_MASTER_CUSTOM';
                  RETURN FALSE;
            END;
            IF SQL%ROWCOUNT = 0 THEN
               BEGIN
                  INSERT INTO  ICTB_TD_REDEM_MASTER_CUSTOM
                  VALUES p_Wrk_icdredmn.v_td_redem_master_custom;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Insert Into ICTB_TD_REDEM_MASTER_CUSTOM..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@ICTB_TD_REDEM_MASTER_CUSTOM';
                     RETURN FALSE;
               END;
            END IF;
         ELSE
            dbg('Check If The Record Is Already Present for  ICTB_TD_REDEM_MASTER_CUSTOM. .');
            IF  p_prev_icdredmn.v_td_redem_master_custom.redem_ref_no IS NOT NULL THEN
               Dbg('Prev Data Exists And Not Sent For  ICTB_TD_REDEM_MASTER_CUSTOM. Delete the Existing Record.');
               DELETE ICTB_TD_REDEM_MASTER_CUSTOM
               WHERE redem_ref_no = p_Prev_icdredmn.v_td_redem_master_custom.redem_ref_no
               ;
            END IF;
         END IF;

         Dbg('Preapring Insert and Update Types for  ICTMS_TDREDMPAYOUT_DETAILS..');
         l_Wrk_Count  := p_Wrk_icdredmn.v_tdredmpayout_details.COUNT;
         l_Prev_Count := p_Prev_icdredmn.v_tdredmpayout_details.COUNT;
         IF l_Wrk_Count > 0 THEN
            FOR l_index IN 1 .. l_Wrk_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Prev_Count >  0 THEN
                  FOR l_index1 IN 1..l_Prev_Count  LOOP
                     IF (NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index).seqno,'@')=  NVL(p_Prev_icdredmn.v_tdredmpayout_details  (l_index1).seqno,'@')) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_rec_found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF l_rec_found THEN
                  Dbg('Record is Modified...');
                  U_v_tdredmpayout_details(U_v_tdredmpayout_details.COUNT +1 ) :=  p_Wrk_icdredmn.v_tdredmpayout_details(l_index);
               ELSE
                  Dbg('Record is Added...');
                  I_v_tdredmpayout_details(I_v_tdredmpayout_details.COUNT +1 ) :=  p_Wrk_icdredmn.v_tdredmpayout_details(l_index);
               END IF;
            END LOOP;
         END IF;

         Dbg('Preapring Delete Types for  ICTMS_TDREDMPAYOUT_DETAILS..');
         l_Wrk_Count  := p_wrk_icdredmn.v_tdredmpayout_details.COUNT;
         l_Prev_Count := p_prev_icdredmn.v_tdredmpayout_details.COUNT;
         IF l_Prev_Count > 0 THEN
            FOR l_index1 IN 1 .. l_Prev_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Wrk_Count >  0 THEN
                  FOR l_index IN 1..l_Wrk_Count  LOOP
                     IF (NVL(p_Wrk_icdredmn.v_tdredmpayout_details(l_index).seqno,'@')=  NVL(p_Prev_icdredmn.v_tdredmpayout_details  (l_index1).seqno,'@')) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_Rec_Found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF NOT l_Rec_Found THEN
                  Dbg('Record is Deleted...');
                  D_v_tdredmpayout_details(D_v_tdredmpayout_details.COUNT +1 ) :=  p_Prev_icdredmn.v_tdredmpayout_details(l_index1);
               END IF;
            END LOOP;
         END IF;
         l_Del_Count  := D_v_tdredmpayout_details.COUNT;
         Dbg('Records Deleted  :'||l_Del_Count);
         IF l_Del_Count > 0 THEN
            FOR l_index IN 1 .. l_del_count LOOP
               Dbg('Deleting Record...');
               DELETE ICTM_TDREDMPAYOUT_DETAILS
               WHERE redem_ref_no = D_v_tdredmpayout_details(l_index).redem_ref_no
                AND seqno = D_v_tdredmpayout_details(l_index).seqno
               ;
            END LOOP;
         END IF;
         l_Ins_Count  := I_v_tdredmpayout_details.COUNT;
         Dbg('New Records Added  :'||l_ins_count);
         BEGIN
            l_Count      := I_v_tdredmpayout_details.COUNT;
            FORALL l_Index IN  1..l_count
            INSERT INTO ICTM_TDREDMPAYOUT_DETAILS
            VALUES I_v_tdredmpayout_details(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert IntoICTMS_TDREDMPAYOUT_DETAILS..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@ICTMS_TDREDMPAYOUT_DETAILS';
               RETURN FALSE;
         END;
         l_Upd_Count  := U_v_tdredmpayout_details.COUNT;
         Dbg('Records Modified  :'||l_Upd_Count);
         IF l_Upd_Count > 0 THEN
            FOR l_index IN 1 .. l_Upd_Count LOOP
               Dbg('Updating The  Record...');
               BEGIN
                  UPDATE ICTM_TDREDMPAYOUT_DETAILS
                  SET
                  BRN = U_v_tdredmpayout_details(l_index).BRN,
                  ACC = U_v_tdredmpayout_details(l_index).ACC,
                  CCY = U_v_tdredmpayout_details(l_index).CCY,
                  PAYOUTTYPE = U_v_tdredmpayout_details(l_index).PAYOUTTYPE,
                  OFFSET_BRN = U_v_tdredmpayout_details(l_index).OFFSET_BRN,
                  OFFSET_ACC = U_v_tdredmpayout_details(l_index).OFFSET_ACC,
                  OFFSET_CCY = U_v_tdredmpayout_details(l_index).OFFSET_CCY,
                  PERCENTAGE = U_v_tdredmpayout_details(l_index).PERCENTAGE,
                  REDMAMT = U_v_tdredmpayout_details(l_index).REDMAMT,
                  NARRATIVE = U_v_tdredmpayout_details(l_index).NARRATIVE,
                  REF_NO = U_v_tdredmpayout_details(l_index).REF_NO,
                  WAIVE_ISSUE_CHG = U_v_tdredmpayout_details(l_index).WAIVE_ISSUE_CHG,
                  INSTNO = U_v_tdredmpayout_details(l_index).INSTNO,
                  REDM_PAYOUT_COMP = U_v_tdredmpayout_details(l_index).REDM_PAYOUT_COMP
WHERE redem_ref_no = U_v_tdredmpayout_details(l_index).redem_ref_no
 AND seqno = U_v_tdredmpayout_details(l_index).seqno
;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Updating ICTMS_TDREDMPAYOUT_DETAILS..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@ICTMS_TDREDMPAYOUT_DETAILS';
                     RETURN FALSE;
               END;
            END LOOP;
         END IF;

         Dbg('Preapring Insert and Update Types for  STTMS_DENOM_REDMN_BLK..');
         l_Wrk_Count  := p_Wrk_icdredmn.v_sttms_denom_redmn_blk.COUNT;
         l_Prev_Count := p_Prev_icdredmn.v_sttms_denom_redmn_blk.COUNT;
         IF l_Wrk_Count > 0 THEN
            FOR l_index IN 1 .. l_Wrk_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Prev_Count >  0 THEN
                  FOR l_index1 IN 1..l_Prev_Count  LOOP
                     IF (NVL(p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no,'@')=  NVL(p_Prev_icdredmn.v_sttms_denom_redmn_blk  (l_index1).certificate_no,'@')) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_rec_found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF l_rec_found THEN
                  Dbg('Record is Modified...');
                  U_v_sttms_denom_redmn_blk(U_v_sttms_denom_redmn_blk.COUNT +1 ) :=  p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index);
               ELSE
                  Dbg('Record is Added...');
                  I_v_sttms_denom_redmn_blk(I_v_sttms_denom_redmn_blk.COUNT +1 ) :=  p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index);
               END IF;
            END LOOP;
         END IF;

         Dbg('Preapring Delete Types for  STTMS_DENOM_REDMN_BLK..');
         l_Wrk_Count  := p_wrk_icdredmn.v_sttms_denom_redmn_blk.COUNT;
         l_Prev_Count := p_prev_icdredmn.v_sttms_denom_redmn_blk.COUNT;
         IF l_Prev_Count > 0 THEN
            FOR l_index1 IN 1 .. l_Prev_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Wrk_Count >  0 THEN
                  FOR l_index IN 1..l_Wrk_Count  LOOP
                     IF (NVL(p_Wrk_icdredmn.v_sttms_denom_redmn_blk(l_index).certificate_no,'@')=  NVL(p_Prev_icdredmn.v_sttms_denom_redmn_blk  (l_index1).certificate_no,'@')) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_Rec_Found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF NOT l_Rec_Found THEN
                  Dbg('Record is Deleted...');
                  D_v_sttms_denom_redmn_blk(D_v_sttms_denom_redmn_blk.COUNT +1 ) :=  p_Prev_icdredmn.v_sttms_denom_redmn_blk(l_index1);
               END IF;
            END LOOP;
         END IF;
         l_Del_Count  := D_v_sttms_denom_redmn_blk.COUNT;
         Dbg('Records Deleted  :'||l_Del_Count);
         IF l_Del_Count > 0 THEN
            FOR l_index IN 1 .. l_del_count LOOP
               Dbg('Deleting Record...');
               DELETE STTM_DENOM_REDMN_BLK
               WHERE cust_ac_no = D_v_sttms_denom_redmn_blk(l_index).cust_ac_no
                AND reference_no = D_v_sttms_denom_redmn_blk(l_index).reference_no
                AND certificate_no = D_v_sttms_denom_redmn_blk(l_index).certificate_no
               ;
            END LOOP;
         END IF;
         l_Ins_Count  := I_v_sttms_denom_redmn_blk.COUNT;
         Dbg('New Records Added  :'||l_ins_count);
         BEGIN
            l_Count      := I_v_sttms_denom_redmn_blk.COUNT;
            FORALL l_Index IN  1..l_count
            INSERT INTO STTM_DENOM_REDMN_BLK
            VALUES I_v_sttms_denom_redmn_blk(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert IntoSTTMS_DENOM_REDMN_BLK..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@STTMS_DENOM_REDMN_BLK';
               RETURN FALSE;
         END;
         l_Upd_Count  := U_v_sttms_denom_redmn_blk.COUNT;
         Dbg('Records Modified  :'||l_Upd_Count);
         IF l_Upd_Count > 0 THEN
            FOR l_index IN 1 .. l_Upd_Count LOOP
               Dbg('Updating The  Record...');
               BEGIN
                  UPDATE STTM_DENOM_REDMN_BLK
                  SET
                  BRANCH_CODE = U_v_sttms_denom_redmn_blk(l_index).BRANCH_CODE,
                  CERTIFICATE_AMOUNT = U_v_sttms_denom_redmn_blk(l_index).CERTIFICATE_AMOUNT,
                  BLOCK_OR_REDEM = U_v_sttms_denom_redmn_blk(l_index).BLOCK_OR_REDEM,
                  CERTIFICATE_STATUS = U_v_sttms_denom_redmn_blk(l_index).CERTIFICATE_STATUS
WHERE cust_ac_no = U_v_sttms_denom_redmn_blk(l_index).cust_ac_no
 AND reference_no = U_v_sttms_denom_redmn_blk(l_index).reference_no
 AND certificate_no = U_v_sttms_denom_redmn_blk(l_index).certificate_no
;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Updating STTMS_DENOM_REDMN_BLK..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@STTMS_DENOM_REDMN_BLK';
                     RETURN FALSE;
               END;
            END LOOP;
         END IF;

         Dbg('Preapring Insert and Update Types for  ICTMS_TDREDPAYIN_DETAILS..');
         l_Wrk_Count  := p_Wrk_icdredmn.v_ictms_tdredpayin_details.COUNT;
         l_Prev_Count := p_Prev_icdredmn.v_ictms_tdredpayin_details.COUNT;
         IF l_Wrk_Count > 0 THEN
            FOR l_index IN 1 .. l_Wrk_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Prev_Count >  0 THEN
                  FOR l_index1 IN 1..l_Prev_Count  LOOP
                     IF (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).acc,'@')=  NVL(p_Prev_icdredmn.v_ictms_tdredpayin_details  (l_index1).acc,'@')) AND (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).seqno,-1)=  NVL(p_Prev_icdredmn.v_ictms_tdredpayin_details  (l_index1).seqno,-1)) AND (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).brn,'@')=  NVL(p_Prev_icdredmn.v_ictms_tdredpayin_details  (l_index1).brn,'@')) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_rec_found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF l_rec_found THEN
                  Dbg('Record is Modified...');
                  U_v_ictms_tdredpayin_details(U_v_ictms_tdredpayin_details.COUNT +1 ) :=  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index);
               ELSE
                  Dbg('Record is Added...');
                  I_v_ictms_tdredpayin_details(I_v_ictms_tdredpayin_details.COUNT +1 ) :=  p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index);
               END IF;
            END LOOP;
         END IF;

         Dbg('Preapring Delete Types for  ICTMS_TDREDPAYIN_DETAILS..');
         l_Wrk_Count  := p_wrk_icdredmn.v_ictms_tdredpayin_details.COUNT;
         l_Prev_Count := p_prev_icdredmn.v_ictms_tdredpayin_details.COUNT;
         IF l_Prev_Count > 0 THEN
            FOR l_index1 IN 1 .. l_Prev_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Wrk_Count >  0 THEN
                  FOR l_index IN 1..l_Wrk_Count  LOOP
                     IF (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).acc,'@')=  NVL(p_Prev_icdredmn.v_ictms_tdredpayin_details  (l_index1).acc,'@')) AND (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).seqno,-1)=  NVL(p_Prev_icdredmn.v_ictms_tdredpayin_details  (l_index1).seqno,-1)) AND (NVL(p_Wrk_icdredmn.v_ictms_tdredpayin_details(l_index).brn,'@')=  NVL(p_Prev_icdredmn.v_ictms_tdredpayin_details  (l_index1).brn,'@')) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_Rec_Found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF NOT l_Rec_Found THEN
                  Dbg('Record is Deleted...');
                  D_v_ictms_tdredpayin_details(D_v_ictms_tdredpayin_details.COUNT +1 ) :=  p_Prev_icdredmn.v_ictms_tdredpayin_details(l_index1);
               END IF;
            END LOOP;
         END IF;
         l_Del_Count  := D_v_ictms_tdredpayin_details.COUNT;
         Dbg('Records Deleted  :'||l_Del_Count);
         IF l_Del_Count > 0 THEN
            FOR l_index IN 1 .. l_del_count LOOP
               Dbg('Deleting Record...');
               DELETE ICTM_TDREDPAYIN_DETAILS
               WHERE acc = D_v_ictms_tdredpayin_details(l_index).acc
                AND redem_ref_no = D_v_ictms_tdredpayin_details(l_index).redem_ref_no
                AND seqno = D_v_ictms_tdredpayin_details(l_index).seqno
                AND brn = D_v_ictms_tdredpayin_details(l_index).brn
               ;
            END LOOP;
         END IF;
         l_Ins_Count  := I_v_ictms_tdredpayin_details.COUNT;
         Dbg('New Records Added  :'||l_ins_count);
         BEGIN
            l_Count      := I_v_ictms_tdredpayin_details.COUNT;
            FORALL l_Index IN  1..l_count
            INSERT INTO ICTM_TDREDPAYIN_DETAILS
            VALUES I_v_ictms_tdredpayin_details(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert IntoICTMS_TDREDPAYIN_DETAILS..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@ICTMS_TDREDPAYIN_DETAILS';
               RETURN FALSE;
         END;
         l_Upd_Count  := U_v_ictms_tdredpayin_details.COUNT;
         Dbg('Records Modified  :'||l_Upd_Count);
         IF l_Upd_Count > 0 THEN
            FOR l_index IN 1 .. l_Upd_Count LOOP
               Dbg('Updating The  Record...');
               BEGIN
                  UPDATE ICTM_TDREDPAYIN_DETAILS
                  SET
                  CCY = U_v_ictms_tdredpayin_details(l_index).CCY,
                  MULTIMODE_PAYOPT = U_v_ictms_tdredpayin_details(l_index).MULTIMODE_PAYOPT,
                  MULTIMODE_TDAMOUNT = U_v_ictms_tdredpayin_details(l_index).MULTIMODE_TDAMOUNT,
                  MULTIMODE_OFFSET_BRN = U_v_ictms_tdredpayin_details(l_index).MULTIMODE_OFFSET_BRN,
                  MULTIMODE_TDOFFSET_ACC = U_v_ictms_tdredpayin_details(l_index).MULTIMODE_TDOFFSET_ACC,
                  MULTIMODE_TDOFFSET_CCY = U_v_ictms_tdredpayin_details(l_index).MULTIMODE_TDOFFSET_CCY,
                  REFERENCE_NO = U_v_ictms_tdredpayin_details(l_index).REFERENCE_NO,
                  MULTIMODE_PERCENTAGE = U_v_ictms_tdredpayin_details(l_index).MULTIMODE_PERCENTAGE,
                  MULITMODE_XRATE = U_v_ictms_tdredpayin_details(l_index).MULITMODE_XRATE,
                  CHQ_INSTUMENTNO = U_v_ictms_tdredpayin_details(l_index).CHQ_INSTUMENTNO,
                  CLG_BANK_CODE = U_v_ictms_tdredpayin_details(l_index).CLG_BANK_CODE,
                  CLG_BRANCH_CODE = U_v_ictms_tdredpayin_details(l_index).CLG_BRANCH_CODE,
                  CLG_PRODUCT_CODE = U_v_ictms_tdredpayin_details(l_index).CLG_PRODUCT_CODE,
                  CHQ_INSTRUMENT_DATE = U_v_ictms_tdredpayin_details(l_index).CHQ_INSTRUMENT_DATE,
                  DRAWEE_AC_NO = U_v_ictms_tdredpayin_details(l_index).DRAWEE_AC_NO,
                  ROUTING_NO = U_v_ictms_tdredpayin_details(l_index).ROUTING_NO
WHERE acc = U_v_ictms_tdredpayin_details(l_index).acc
 AND redem_ref_no = U_v_ictms_tdredpayin_details(l_index).redem_ref_no
 AND seqno = U_v_ictms_tdredpayin_details(l_index).seqno
 AND brn = U_v_ictms_tdredpayin_details(l_index).brn
;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Updating ICTMS_TDREDPAYIN_DETAILS..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@ICTMS_TDREDPAYIN_DETAILS';
                     RETURN FALSE;
               END;
            END LOOP;
         END IF;
      ELSIF p_Action_Code = Cspks_Req_Global.p_delete THEN
         Dbg('Action Code '||p_Action_Code);
         Dbg('Deleting The Data..');

         
         DELETE ICTB_TD_REDEM_MASTER_CUSTOM
         WHERE redem_ref_no = p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
         ;

         
         DELETE ICTM_TDREDPAYIN_DETAILS
         WHERE redem_ref_no = p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
         ;

         
         DELETE STTM_DENOM_REDMN_BLK
         WHERE BLOCK_OR_REDEM='R' AND reference_no = p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
          AND cust_ac_no = p_Wrk_icdredmn.v_ictbs_tdredemption_master.acc_no
          AND branch_code = p_Wrk_icdredmn.v_ictbs_tdredemption_master.branch_code
         ;

         
         DELETE ICTM_TDREDMPAYOUT_DETAILS
         WHERE redem_ref_no = p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
         ;

         DELETE ICTB_TDREDEMPTION_MASTER WHERE redem_ref_no = p_Wrk_icdredmn.v_ictbs_tdredemption_master.redem_ref_no
         ;



      END IF;

      Dbg('Returning Success From Fn_Sys_Upload_Db');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Upload_Db;
   FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_icdredmn       IN   OUT icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Build_Ws_Type..');

      IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
         IF NOT Fn_Sys_Build_Fc_Type(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_ICDREDMN,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Fc_Type..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT Fn_Sys_Build_Ws_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_ICDREDMN,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Ws_Type..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTTYPE');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_ICDREDMN,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_ICDREDMN,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Build_Type..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Build_Type ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Type;
   FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_exchange_pattern   IN  VARCHAR2,
      p_icdredmn          IN icpks_icdredmn_Main.ty_icdredmn,
      p_err_code        IN OUT VARCHAR2,
      p_err_params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

   BEGIN

      dbg('In Fn_Build_Ts_List..');

      IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
         IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_icdredmn,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Fc_Ts');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            p_icdredmn,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Ws_Ts');
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning from Fn_Build_Ts_List');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of icpks_icdredmn_Main.Fn_Build_Ts_List ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Build_Ts_List;
   FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_icdredmn       IN  OUT icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Key_Cols        VARCHAR2(32767);
      l_Key_Vals        VARCHAR2(32767);
      l_Func_Type       VARCHAR2(32767);
   BEGIN

      Dbg('In Fn_Get_Key_Information..');
      l_Key_Cols := 'REDEM_REF_NO~';
      l_Key_Vals := p_icdredmn.v_ictbs_tdredemption_master.redem_ref_no||'~';
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
      IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code ,
         'TRANSACTION',
         'ICTBS_TDREDEMPTION_MASTER',
         'BLK_ICTMS_TDREDMPAYOUT_MASTER',
         'Ictms-Tdredmpayout-Master',
         l_Key_Cols,
         l_Key_Vals,
         p_icdredmn.Addl_Info,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
         RETURN FALSE;
      END IF;
      IF p_icdredmn.Addl_Info.EXISTS('RECORD_KEY') THEN
         G_Req_Key :=  p_icdredmn.Addl_Info('RECORD_KEY');
      END IF;
      Dbg('Returning Succsess From Fn_Get_Key_Information..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Get_Key_Information..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Key_Information;
   FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_icdredmn IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
     RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;

   BEGIN

      Dbg('In Fn_Check_Mandatory..');

      Pr_Skip_Handler('PREMAND');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Pk_Or_Full,
            p_Function_Id  ,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  icpks_icdredmn_Custom.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Pk_Or_Full,
            p_Function_Id  ,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  icpks_icdredmn_Kernel.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      l_iccrefpo := p_icdredmn.ty_iccrefpo;
      Dbg('Calling Icpks_Iccrefpo_Main.Fn_Check_Mandatory..');
      IF NOT Icpks_Iccrefpo_Main.Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         'ICCREFPO',
         p_Action_Code,
         l_Main_Function,
         p_Pk_Or_Full,
         l_iccrefpo,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Icpks_Iccrefpo_Main.Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RETURN FALSE;
      END IF;
      p_icdredmn.ty_iccrefpo:=l_iccrefpo;

      Pr_Skip_Handler('POSTMAND');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Pk_Or_Full,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Pk_Or_Full,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Check_Mandatory;
   FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_icdredmn         IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn  IN   OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Wrk_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);

   BEGIN

      Dbg('In Fn_Query..');

      Pr_Skip_Handler('PREQRY');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_pre_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock,
            p_QryData_Reqd,
            p_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_pre_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock,
            p_QryData_Reqd,
            p_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Full_Data = 'Y' THEN
         l_Key_Vals :='REDEM_REF_NO'||'>'||p_wrk_icdredmn.v_ictbs_tdredemption_master.REDEM_REF_NO;
         l_Wrk_iccrefpo := p_Wrk_icdredmn.Ty_iccrefpo;
         Dbg('Calling Icpks_Iccrefpo_Main. Fn_Query..');
         IF NOT Icpks_Iccrefpo_Main.Fn_Query (p_Source,
            p_Source_Operation,
            'ICCREFPO',
            p_Action_Code,
            l_Main_Function,
            l_Key_Vals,
            p_QryData_Reqd,
            l_iccrefpo,
            l_Wrk_iccrefpo,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Icpks_Iccrefpo_Main. Fn_Query..');
            RETURN FALSE;
         END IF;

          p_Wrk_icdredmn.Ty_iccrefpo := l_Wrk_iccrefpo;

      END IF;
      Pr_Skip_Handler('SYSDESC');
      IF p_QryData_Reqd = 'Y' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_icdredmn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      END IF;

      Pr_Skip_Handler('POSTQRY');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock ,
            p_QryData_Reqd,
            p_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock ,
            p_QryData_Reqd,
            p_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Query..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Query;
   FUNCTION Fn_Resolve_Ref_Numbers         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;

   BEGIN

      Dbg('In Fn_Resolve_Ref_Numbers..');

      Pr_Skip_Handler('PREMAND');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Pre_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Pre_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTMAND');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Resolve_Ref_Numbers..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Resolve_Ref_Numbers ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Resolve_Ref_Numbers;
   FUNCTION Fn_Product_Default         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn      IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'ICDREDMN';
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Key_Id  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);

      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Wrk_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;

   BEGIN

      Dbg('In Fn_Product_Default..');

      Pr_Skip_Handler('PREPRDDFLT');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Pre_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Pre_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
      IF NOT Fn_Sys_Query_Desc_Fields(p_Source,
         p_Source_Operation,
         p_Function_Id,
         Cspks_Req_Global.p_prddflt,
         p_Wrk_icdredmn,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('POSTPRDDFLT');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Product_Default..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Product_Default ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Product_Default;
   FUNCTION Fn_Unlock         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN  OUT  VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'ICDREDMN';


   BEGIN

      Dbg('In Fn_Unlock..');

      Pr_Skip_Handler('PREUNLOCK');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Pre_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Pre_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTUNLOCK');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Unlock..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Unlock ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Unlock;
   FUNCTION Fn_Subsys_Pickup         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Prev_icdredmn IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn      IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'ICDREDMN';

      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Prev_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Wrk_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;

   BEGIN

      Dbg('In Fn_Subsys_Pickup..');

      Pr_Skip_Handler('PRESUBSYSPKP');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Pre_Subsys_Pickup..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Pre_Subsys_Pickup..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTSUBSYSPKP');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_prev_icdredmn,
            p_wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Subsys_Pickup ..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_prev_icdredmn,
            p_wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Subsys_Pickup ..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Subsys_Pickup..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Subsys_Pickup ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Subsys_Pickup;
   FUNCTION Fn_Enrich         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Prev_icdredmn IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn      IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'ICDREDMN';

      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Prev_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Wrk_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;

   BEGIN

      Dbg('In Fn_Enrich..');

      Pr_Skip_Handler('PREENRICH');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom. Fn_Pre_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel. Fn_Pre_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Calling in Fn_Sys_Query_Desc_Field..');
      IF NOT Fn_Sys_Query_Desc_Fields(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Wrk_icdredmn,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Sys_Query_Desc_Field..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('POSTENRICH');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning  Success From Fn_Enrich..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of icpks_icdredmn_Main.Fn_Enrich ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Enrich;
   FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN OUT    VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Prev_icdredmn IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation       VARCHAR2(100) := p_source_Operation;
      l_Full_Data    VARCHAR2(1) := 'N';
      l_With_Lock    VARCHAR2(1) := 'Y';
      l_Qrydata_Reqd    VARCHAR2(1) := 'N';
      l_Pk_Or_Full      VARCHAR2(10) := 'FULL';

      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Prev_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Wrk_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;

   BEGIN

      Dbg('In Fn_Default_And_Validate..');

      l_Full_data   := 'Y';
      Dbg('Calling  Fn_Query..');
      IF NOT Fn_Query(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         l_Full_data,
         l_With_Lock,
         l_Qrydata_Reqd,
         p_icdredmn,
         p_Prev_icdredmn,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Query..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('PREDFLT');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Pre_Default_And_Validate');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Pre_Default_And_Validate');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='ICCREFPO_'||p_Action_Code;
      END IF;
      l_iccrefpo := p_icdredmn.Ty_iccrefpo;
      l_Prev_iccrefpo := p_Prev_icdredmn.Ty_iccrefpo;
      l_Wrk_iccrefpo := p_Wrk_icdredmn.Ty_iccrefpo;
      Dbg('Calling Icpks_Iccrefpo_Main.Fn_Default_And_Validate..');
      IF NOT Icpks_Iccrefpo_Main.Fn_Default_And_Validate (p_Source,
         l_Source_Operation,
         'ICCREFPO',
         p_Action_Code,
         p_Function_Id,
         l_iccrefpo,
         l_Prev_iccrefpo,
         l_Wrk_iccrefpo,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Icpks_Iccrefpo_Main.Fn_Default_And_Validate..');
         RETURN FALSE;
      END IF;
      p_Prev_icdredmn.Ty_iccrefpo:= l_Prev_iccrefpo;
      p_Wrk_icdredmn.Ty_iccrefpo:= l_Wrk_iccrefpo;


      Pr_Skip_Handler('POSTDFLT');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  icpks_icdredmn_Kernel.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  icpks_icdredmn_Custom.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
         Dbg('Calling  Fn_Check_Mandatory..');
         IF NOT Fn_Check_Mandatory(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Pk_Or_Full,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_default_and_validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Default_And_Validate;
   FUNCTION Fn_Upload_Db  (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Prev_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn      IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Key_Id  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);

      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Prev_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Wrk_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;

   BEGIN

      Dbg('In Fn_Upload_Db..');

      Pr_Skip_Handler('PREUPLD');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Delete THEN
         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='ICCREFPO_'||p_Action_Code;
         END IF;
         l_iccrefpo := p_icdredmn.Ty_iccrefpo;
         l_Prev_iccrefpo := p_Prev_icdredmn.Ty_iccrefpo;
         l_Wrk_iccrefpo := p_Wrk_icdredmn.Ty_iccrefpo;
         Dbg('Calling  Icpks_Iccrefpo_Main.Fn_Upload_Db..');
         IF NOT Icpks_Iccrefpo_Main.Fn_Upload_Db (p_Source,
            l_Source_operation,
            p_Function_id,
            p_Action_Code,
            l_Main_Function,
            p_Multi_Trip_Id,
            l_iccrefpo,
            l_Prev_iccrefpo,
            l_Wrk_iccrefpo,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Icpks_Iccrefpo_Main.Fn_Upload_Db..');
            RETURN FALSE;
         END IF;
         p_Wrk_icdredmn.Ty_iccrefpo:= l_Wrk_iccrefpo;


      END IF;
      Pr_Skip_Handler('POSTUPLD');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success  From Fn_Upload_Db..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Upload_Db;
   FUNCTION Fn_Process         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Prev_icdredmn     IN  icpks_icdredmn_Main.Ty_icdredmn,
      p_Wrk_icdredmn      IN OUT  icpks_icdredmn_Main.Ty_icdredmn,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'ICDREDMN';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;

      l_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Prev_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;
      l_Wrk_iccrefpo    Icpks_Iccrefpo_Main.Ty_iccrefpo;

   BEGIN

      Dbg('In Fn_Process..');

      Pr_Skip_Handler('PREPROCESS');
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Pre_Process (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_multi_trip_id,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  icpks_icdredmn_Custom.Fn_Pre_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Pre_Process (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_multi_trip_id,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  icpks_icdredmn_Kernel.Fn_Pre_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTPROCESS');
      IF NOT icpks_icdredmn_Main.Fn_Skip_kernel  THEN
         IF NOT icpks_icdredmn_Kernel.Fn_Post_Process (p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Kernel.Fn_Post_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT icpks_icdredmn_Main.Fn_Skip_custom  THEN
         IF NOT icpks_icdredmn_Custom.Fn_Post_Process (p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_icdredmn,
            p_Prev_icdredmn,
            p_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in icpks_icdredmn_Custom.Fn_Post_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='ICCREFPO_'||p_Action_Code;
      END IF;
      l_iccrefpo := p_icdredmn.ty_iccrefpo;
      l_Prev_iccrefpo := p_Prev_icdredmn.Ty_iccrefpo;
      l_Wrk_iccrefpo := p_Wrk_icdredmn.Ty_iccrefpo;
      Dbg('Calling Icpks_Iccrefpo_Main.Fn_Process..');
      IF NOT Icpks_Iccrefpo_Main.Fn_Process(p_Source,
         l_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Function_Id  ,
         p_Multi_Trip_Id,
         l_iccrefpo,
         l_Prev_iccrefpo,
         l_Wrk_iccrefpo,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed In Icpks_Iccrefpo_Main.Fn_Process..');
         RETURN FALSE;
      END IF;
      p_Wrk_icdredmn.Ty_iccrefpo:= l_Wrk_iccrefpo;


      Dbg('Returning Success From Fn_Process..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of icpks_icdredmn_Main.Fn_Process ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Process;
   FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;

   BEGIN

      Dbg('In Fn_Rebuild_Ts_List..');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         g_icdredmn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Dbg('Returning Success From Fn_Rebuild_Ts_List..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List..');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Rebuild_Ts_List..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Rebuild_Ts_List;

   FUNCTION Fn_Get_Node_Data (
      p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Cntr NUMBER := 0;
   BEGIN

      Dbg('In Fn_Get_Node_Data..');
      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_ICTMS_TDREDMPAYOUT_MASTER';
      p_Node_Data(l_Cntr).Xsd_Node := 'Ictms-Tdredmpayout-Master';
      p_Node_Data(l_Cntr).Node_Parent := '';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'WAIVE_INTEREST~SUPPRESS_REDEMPTION_ADVICE~REDEM_REF_NO~BRANCH_CODE~ACC_NO~CUST_ID~CCY~ACC_DESC~ACC_AMT~ACTION_FLAG~TENOR_DD~TENOR_MM~TENOR_YY~NEXT_MAT_DATE~REDEMPTION_MODE~REDEMPTION_AMT~WAVE_PENALTY~';
      p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'MAKER_ID~CHECKER_ID~MAKER_DT_STAMP~CHECKER_DT_STAMP~AUTHSTAT~TXNSTAT~PRINCIPAL_AMOUNT~MATURITY_AMOUNT~INTEREST_RATE~ROLL_TENOR_PREF~CONTVARROLL~INTRATE_CUMAMT_REQD~TOTAL_AMT_REDEMPTION~NUM_CERTIFICATE';
      p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'_REDM~PRODUCT_CODE~REDEM_SEQ_NO~ORG_YEARS~ORG_MONTHS~ORG_DAYS~ADDFUNDS~ADDTIONALAMT~REDEM_INT_PAYOUT~WAIVE_INSURANCE_FEE~INSURANCE_AMOUNT~';
      p_Node_Data(l_Cntr).Node_Tags := 'WAIVEINT~SUPPRESS_REDEMPTION_ADVICE~REDEM_REF_NO~ACBRN~TERM_ACNO~CUST_ID~ACCOUNT_CCY~AC_DESC~CUST_ACC_BAL~ACTION_FLAG~DAYS~DEFAULT_MONTHS1~YEARS_SS~NEXT_MAT_DATE~REDEM_MODE~REDEMPTION_AMT~WAIVE_PENALT';
      p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'Y~INPTBY~CHECHKERID~MAKDTTIME~CHECKERDT~AUTHSTAT~TXNSTAT~PRN_AMT~MATURITY_AMT~INTEREST_RATE~ROLLTENOR~CONTVARROLL~INTRATE_CUMAMT_REQD~REDEMAMT~NUM_CERTIFICATE_REDM~PRODUCT_CODE~REDEM_SEQ_NO~ORG_YEARS~';
      p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'ORG_MONTHS~ORG_DAYS~ADDFNDS~ADD_AMT~REDM_INT_PAYOUT~WAIVE_INSURANCE_FEE~INSURANCE_AMOUNT~';

      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_ICTMS_TDREDMPAYOUT_DETAILS';
      p_Node_Data(l_Cntr).Xsd_Node := 'Ictms-Tdredmpayout-Details';
      p_Node_Data(l_Cntr).Node_Parent := 'BLK_ICTMS_TDREDMPAYOUT_MASTER';
      p_Node_Data(l_Cntr).Node_Relation_Type := 'N';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~PERCENTAGE~REDMAMT~NARRATIVE~WAIVE~INSTNO~REDM_PAYOUT_COMP~';
      p_Node_Data(l_Cntr).Node_Tags := 'PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~PERCENTAGE~REDMAMT~NARRATIVE~WAIVEISSUCHG~INSTNO~REDM_PAYOUT_COMP~';

      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_DENOM_DEPOSIT';
      p_Node_Data(l_Cntr).Xsd_Node := 'Denom-Deposit';
      p_Node_Data(l_Cntr).Node_Parent := 'BLK_ICTMS_TDREDMPAYOUT_MASTER';
      p_Node_Data(l_Cntr).Node_Relation_Type := 'N';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'CUST_AC_NO1~BRANCH_CODE1~CERTIFICATE_NO~REFERENCE_NO~CERTIFICATE_AMOUNT~BLOCK_OR_REDEM~CERTIFICATE_STATUS~';
      p_Node_Data(l_Cntr).Node_Tags := 'CUST_AC_NO1~BRANCH_CODE1~CERTIFICATE_NO~REFERENCE_NO~CERTIFICATE_AMOUNT~REDEEM~CERTIFICATE_STATUS~';

      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_REDEM_PAYIN_DTLS';
      p_Node_Data(l_Cntr).Xsd_Node := 'Redem-Payin-Dtls';
      p_Node_Data(l_Cntr).Node_Parent := 'BLK_ICTMS_TDREDMPAYOUT_MASTER';
      p_Node_Data(l_Cntr).Node_Relation_Type := 'N';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'BRN~ACC~CCY~MMPAYOPT~MMTDAMT~MMOFFBRN~MMOFFACC~MMOFFCCY~REFNO~MMPERCENT~MMXRATE~SEQNO~CHQINSTNO~CLGBANK~CLGBRN~CLGPROD~CHQINSTDATE~DRAWEEACNO~ROUTINGNO~REDEMREFNO~';
      p_Node_Data(l_Cntr).Node_Tags := 'BRN~ACC~CCY~PAYIN_OPTION~AMT~OFFSET_BRN~OFFSET_ACC~MMOFFCCY~REFNO~PECENT~MMXRATE~SEQNO~CHQINSTNO~CLGBANK~CLGBRN~PRODUCT_F~CHQ_ADTE~DRAWEE_ACCOUNT~ROUTING_NO~REDEMREFNO~';

      IF NOT Icpks_Iccrefpo_Main.Fn_Get_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Icpks_Iccrefpo_Main.Fn_Get_Node_Data..');
         RETURN FALSE;
      END IF;
      Dbg('Returning From Fn_Get_Node_Data.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of icpks_icdredmn_Main.Fn_Get_Node_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Node_Data;
   FUNCTION Fn_Main       (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_icdredmn          IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;
      E_Hold_Exception        EXCEPTION;
      l_Post_Upl_Stat    VARCHAR2(1) :='A';
      l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
      l_action_code           VARCHAR2(100) := p_Action_Code;
      l_Wrk_icdredmn     icpks_icdredmn_Main.Ty_icdredmn;
      l_Prev_icdredmn    icpks_icdredmn_Main.Ty_icdredmn;
      l_Dmy_icdredmn    icpks_icdredmn_Main.Ty_icdredmn;
      l_Pk_Or_Full    VARCHAR2(5) :='PK';
      l_Full_Data    VARCHAR2(1) := 'Y';
      l_With_Lock    VARCHAR2(1) := 'N';
      l_Qrydata_Reqd    VARCHAR2(1) := 'Y';
      l_Count         NUMBER;
      l_Rollback_Reqd    VARCHAR2(1) := 'N';
      l_Prev_Auth_Stat        VARCHAR2(1) :='U';

   BEGIN

      Dbg('In Fn_Main');

      SAVEPOINT Sp_Main_Icdredmn;
      p_Status := 'S';
      g_Addl_Info.DELETE;
      g_icdredmn := p_icdredmn;
      g_Original_Action := p_Action_Code ;
      g_Action_Code :=  p_Action_Code ;

      Dbg('Calling  Fn_Resolve_Ref_Numbers..');
      IF NOT Fn_Resolve_Ref_Numbers(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_icdredmn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Resolve_Ref_Numbers..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling in Fn_Unlock..');
      IF NOT Fn_Unlock(p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_icdredmn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Unlock..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling  Fn_Check_Mandatory..');
      IF NOT Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         l_Pk_Or_Full,
         p_icdredmn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling  Fn_Get_Key_Information..');
      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_icdredmn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      IF p_Action_Code  = Cspks_Req_Global.p_Query THEN
         Dbg('Calling Fn_Query..');
         IF NOT Fn_Query(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Full_data,
            l_With_Lock,
            l_Qrydata_Reqd,
            p_icdredmn,
            l_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Query..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
      ELSIF p_Action_code  = Cspks_Req_Global.p_Prddflt THEN
         Dbg('Calling  Fn_Product_Default..');
         Dbg('Failed in Fn_Product_Default..');
         IF NOT Fn_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_icdredmn,
            l_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Product_Default..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSIF SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_SubsysPickup))  = Cspks_Req_Global.p_SubsysPickup THEN
         Dbg('Calling  Fn_Subsys_Pickup..');
         IF NOT Fn_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_icdredmn,
            l_Prev_icdredmn,
            l_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Subsys_Pickup..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSIF SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  = Cspks_Req_Global.p_Enrich THEN
         Dbg('Calling  Fn_Enrich..');
         IF NOT Fn_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_icdredmn,
            l_Prev_icdredmn,
            l_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Enrich..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSE
         IF NOT Fn_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_icdredmn,
            l_Prev_icdredmn,
            l_Wrk_icdredmn,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Default_And_Validate..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         -- Get Resultant Error Type
         g_autoauth := 'U';
         l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
         IF l_Resultant_Error_Type <> 'E' THEN
            Dbg('Calling  Fn_Upload_Db..');
            IF NOT Fn_Upload_Db (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               p_icdredmn,
               l_Prev_icdredmn,
               l_Wrk_icdredmn,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Upload_Db..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            Dbg('Calling  Fn_Process..');
            IF NOT Fn_Process (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               p_icdredmn,
               l_Prev_icdredmn,
               l_Wrk_icdredmn,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Process..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            IF  l_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Reverse,Cspks_Req_Global.p_Rollover,Cspks_Req_Global.p_Confirm,Cspks_Req_Global.p_Liquidate ) THEN
               l_Prev_Auth_Stat := 'A';
               --Get Upload Status
               Dbg('Calling Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
               IF NOT Cspks_Req_Utils.Fn_Get_Auto_Auth_Status (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  l_Action_Code,
                  l_Prev_Auth_Stat,
                  p_Multi_Trip_Id,
                  P_Request_No,
                  l_Post_Upl_Stat,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
                  Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                  RAISE E_Failure_Exception;
               END IF;

               IF l_Post_Upl_Stat = 'A'THEN
                  Dbg('Calling Fn_Process With Auth as Action Code..');
                  IF NOT Fn_Process (p_Source,
                     p_Source_Operation,
                     p_Function_Id,
                     Cspks_Req_Global.p_Auth,
                     p_Multi_Trip_Id,
                     l_Wrk_icdredmn,
                     l_Prev_icdredmn,
                     l_Wrk_icdredmn,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in Fn_Process..');
                     Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                     RAISE E_Failure_Exception;
                  END IF;
               END IF;
            END IF;
         END IF;
      END IF;
      --Get Upload Status
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Upload_Status..');
      IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_Multi_Trip_Id,
         P_Request_No,
         l_Post_Upl_Stat,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      IF l_Post_Upl_Stat IN('A','U') THEN
         p_status := 'S';
         IF p_Action_code  <> Cspks_Req_Global.p_Prddflt AND
            SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  <> Cspks_Req_Global.p_Enrich THEN
            Dbg('Calling  Fn_Query..');
            IF NOT Fn_Query(p_source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               l_Full_Data,
               l_With_Lock,
               l_Qrydata_Reqd,
               p_icdredmn,
               l_Wrk_icdredmn,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Query..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
         END IF;
      ELSIF l_Post_Upl_Stat ='O' THEN
         Dbg('New/First time Overides..');
         p_Status := 'O';
         RAISE E_Override_Exception;
      ELSIF l_Post_Upl_Stat = 'H'    THEN
         Dbg('Keeping on Hold..');
         RAISE E_Hold_Exception;
      ELSE
         Dbg('Not Feasible to Upload The Data...');
         RAISE E_Failure_Exception;
      END IF;
      IF p_Action_Code  = Cspks_Req_Global.p_Prddflt OR
         p_Action_Code  = Cspks_Req_Global.p_Copy OR
         SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  = Cspks_Req_Global.p_Enrich OR
         SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_SubsysPickup))  = Cspks_Req_Global.p_SubsysPickup THEN
         ROLLBACK TO Sp_Main_Icdredmn;
      END IF;

      p_icdredmn := l_Wrk_icdredmn;
      g_icdredmn := l_Wrk_icdredmn;
      Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
      Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
      Dbg('Errors     :'||p_Err_Code);
      Dbg('Parameters :'||p_Err_Params);

      Dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Main');
         p_Status        := 'F';
         l_Post_Upl_Stat := 'F';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Main..');
         p_Status        := 'O';
         l_Post_Upl_Stat := 'O';
         IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
            Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
         END IF;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Hold_Exception THEN
         Dbg('From E_Hold_Exception of Fn_Main..');
         l_Post_Upl_Stat := 'H';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         ROLLBACK TO Sp_Main_Icdredmn;
         IF NOT  Fn_main(p_Source,
            p_Source_operation,
            p_Function_Id,
            Cspks_Req_Global.p_Hold,
            p_Multi_Trip_Id,
            p_Request_No,
            p_icdredmn,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;

         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Main ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Main;

   FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_icdredmn     icpks_icdredmn_Main.ty_icdredmn;

   BEGIN

      Dbg('In Fn_Process_Request ..');
      IF NOT  Fn_Build_Type(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Addl_Info,
         l_icdredmn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      IF NOT  Fn_Main(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Multi_Trip_Id,
         p_Request_No,
         l_icdredmn,
         p_Status,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_main..');
         RETURN FALSE;
      END IF;

      p_Addl_Info := l_icdredmn.Addl_Info;
      Cspks_Req_Global.Pr_Reset;
      Dbg('Calling  Fn_Build_Ts_List..');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         l_icdredmn,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Cspks_Req_Global.Pr_Close_Ts;
      Dbg('Returning Success From Fn_Process_Request ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Process_Request;

END icpks_icdredmn_main;
/