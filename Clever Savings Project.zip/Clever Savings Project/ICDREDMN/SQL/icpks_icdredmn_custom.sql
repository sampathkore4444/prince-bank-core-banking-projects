CREATE OR REPLACE PACKAGE BODY icpks_icdredmn_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : icpks_icdredmn_custom.sql
  **
  ** Module     : Interest And Charges
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'icpks_icdredmn_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IC', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION Fn_Post_Build_Type_Structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_icdredmn         IN OUT icpks_icdredmn_Main.ty_icdredmn,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_Type_Structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Build_Type_Structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  --clever savings sampath starts
  PROCEDURE PR_GET_FORMATTED_XML(P_XML           IN VARCHAR2,
                                 P_FORMATTED_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_FORMATTED_XML := P_XML;
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '<S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSCcyService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSRTService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '   </S:Body>', NULL);
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Envelope>', NULL);
  
  END PR_GET_FORMATTED_XML;

  FUNCTION FN_GET_INSURANCE_PLAN_AMOUNT(P_INSURANCE_PLAN IN VARCHAR2,
                                        P_CCY            IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.CODE%TYPE IS
    L_INSURANCE_PLAN_AMOUNT NUMBER;
  BEGIN
  
    BEGIN
    
      IF P_CCY = 'USD' THEN
      
        SELECT B.CODE
          INTO L_INSURANCE_PLAN_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CLESAV_INSFEE_US'
           AND B.VALUE = P_INSURANCE_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';
      
      ELSIF P_CCY = 'KHR' THEN
      
        SELECT B.CODE
          INTO L_INSURANCE_PLAN_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'CLESAV_INSFEE_KH'
           AND B.VALUE = P_INSURANCE_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';
      
      END IF;
    
      RETURN L_INSURANCE_PLAN_AMOUNT;
    
    EXCEPTION
      WHEN OTHERS THEN
      
        L_INSURANCE_PLAN_AMOUNT := 0;
      
        RETURN L_INSURANCE_PLAN_AMOUNT;
      
    END;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('FAILED IN FN_GET_INSURANCE_PLAN_AMOUNT');
      DBG('ERROR CODE IN FN_GET_INSURANCE_PLAN_AMOUNT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_INSURANCE_PLAN_AMOUNT=' || SQLERRM);
    
  END FN_GET_INSURANCE_PLAN_AMOUNT;

  FUNCTION FN_GET_INSURANCE_CASA_ACC_CCY(P_INSURANCE_CASA_ACC IN VARCHAR2)
    RETURN STTM_CUST_ACCOUNT.CCY%TYPE AS
  
    L_CCY STTM_CUST_ACCOUNT.CCY%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT CCY
        INTO L_CCY
        FROM STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_INSURANCE_CASA_ACC
         AND A.RECORD_STAT = 'O'
         AND A.ONCE_AUTH = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        L_CCY := NULL;
    END;
  
    RETURN L_CCY;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_INSURANCE_CASA_ACC_CCY');
      DBG('ERROR CODE IN FN_GET_INSURANCE_CASA_ACC_CCY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_INSURANCE_CASA_ACC_CCY=' || SQLERRM);
      RETURN L_CCY;
    
  END FN_GET_INSURANCE_CASA_ACC_CCY;
  --clever savings sampath ends

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                  p_icdredmn         IN OUT icpks_icdredmn_Main.ty_icdredmn,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    --clever savings sampath starts
    L_XML               VARCHAR2(32767);
    L_RESPONSE          VARCHAR2(32767) := '';
    L_CUST_ACCOUNT      STTM_CUST_ACCOUNT%ROWTYPE;
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
    L_STATUS_MSG        VARCHAR2(105);
    L_ERROR_DESC        VARCHAR2(255);
    L_REFERENCE_NO   ICTB_TD_REDEM_MASTER_CUSTOM.REDEM_REF_NO%TYPE;
    L_CASA_ACCOUNT      STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_INSURANCE_AMOUNT  LMTM_TYPE_VALUES.CODE%TYPE;
    L_INSURANCE_CCY     STTM_CUST_ACCOUNT.CCY%TYPE;
    L_INSURANCE_PLAN    VARCHAR2(100);
    --clever savings sampath ends
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory..');
  
    --clever savings sampath starts
    IF p_Action_Code = 'AUTH' THEN
    
      --Get Account class of the TD Account
      BEGIN
      
        SELECT *
          INTO L_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = p_icdredmn.v_ictbs_tdredemption_master.ACC_NO
           AND A.BRANCH_CODE =
               p_icdredmn.v_ictbs_tdredemption_master.BRANCH_CODE
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_ACCOUNT := NULL;
      END;
    
      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN
         ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN
      
        IF NVL(p_icdredmn.v_td_redem_master_custom.WAIVE_INSURANCE_FEE, 'N') <> 'Y' THEN
        
          L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSRTService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:CREATETRANSACTION_FSFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>EXTSYS</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:MSGID></fcub:MSGID>
            <fcub:CORRELID></fcub:CORRELID>
            <fcub:USERID>SYSTEM</fcub:USERID>
            <fcub:ENTITY></fcub:ENTITY>
            <fcub:BRANCH>' || GLOBAL.current_branch ||
                   '</fcub:BRANCH>
            <fcub:MODULEID></fcub:MODULEID>
            <fcub:SERVICE>FCUBSRTService</fcub:SERVICE>
            <fcub:OPERATION>CreateTransaction</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Transaction-Details>
               <fcub:XREF>$L_XREF</fcub:XREF>
               <fcub:FCCREF></fcub:FCCREF>
               <fcub:PRD>CLIF</fcub:PRD>
               <fcub:ESN></fcub:ESN>
               <fcub:EVNTCD></fcub:EVNTCD>
               <fcub:BRN>' ||
                   p_icdredmn.v_ictbs_tdredemption_master.BRANCH_CODE ||
                   '</fcub:BRN>
               <fcub:MODULE></fcub:MODULE>
               <fcub:TXNBRN>' ||
                   p_icdredmn.v_ictbs_tdredemption_master.BRANCH_CODE ||
                   '</fcub:TXNBRN>
               <fcub:TXNACC>$L_CASA_ACCOUNT</fcub:TXNACC>
               <fcub:TXNCCY>$L_CCY_CASA_ACCOUNT</fcub:TXNCCY>
               <fcub:TXNAMT>$L_INSURANCE_AMOUNT</fcub:TXNAMT>
               <fcub:TXNTRN></fcub:TXNTRN>
               <fcub:CREDITCARDNO></fcub:CREDITCARDNO>
               <fcub:CC_HOLDER_NAME></fcub:CC_HOLDER_NAME>
               <fcub:OFFSETBRN>' ||
                   p_icdredmn.v_ictbs_tdredemption_master.BRANCH_CODE ||
                   '</fcub:OFFSETBRN>
               <fcub:OFFSETCCY>$L_CHARGE_GL_CCY</fcub:OFFSETCCY>
               
               <fcub:OFFSETTRN></fcub:OFFSETTRN>
               <fcub:SDBREFNO></fcub:SDBREFNO>
               <fcub:Charge-Details>
                  <fcub:CHGCOMP>Clever Savings Insurance Fee</fcub:CHGCOMP>
                  <fcub:WAIVER></fcub:WAIVER>
                  <fcub:CHGAMT>$L_INSURANCE_AMOUNT</fcub:CHGAMT>
                  <fcub:CHGCCY>$L_CCY_CASA_ACCOUNT</fcub:CHGCCY>
               </fcub:Charge-Details>
           </fcub:Transaction-Details>
         </fcub:FCUBS_BODY>
      </fcub:CREATETRANSACTION_FSFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
        
          /* L_XML := REPLACE(L_XML, '$L_BRN', L_BRN);
          
          L_XML := REPLACE(L_XML,
                           '$L_TXN_AMT',
                           p_ifdncsft.v_iftbs_ncs_master.DR_AMOUNT);
          
          L_XML := REPLACE(L_XML, '$L_SETTLEMENT_ACC', L_SETTLEMENT_ACC);*/
        
          --$L_CASA_ACCOUNT
          BEGIN
          
            SELECT *
              BULK COLLECT
              INTO P_ICDREDMN.v_tdredmpayout_details
              FROM ICTMS_TDREDMPAYOUT_DETAILS A
             WHERE A.REF_NO =
                   P_ICDREDMN.v_ictbs_tdredemption_master.redem_ref_no
               AND A.PAYOUTTYPE = 'S';
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED IN GETTING THE TD PAYOUT CASA DETAILS');
              RETURN FALSE;
          END;
        
          FOR G IN 1 .. P_ICDREDMN.v_tdredmpayout_details.COUNT LOOP
          
            L_CASA_ACCOUNT := P_ICDREDMN.v_tdredmpayout_details(G)
                              .OFFSET_ACC;
          
            IF L_CASA_ACCOUNT IS NOT NULL THEN
              EXIT;
            END IF;
          
          END LOOP;
        
          --Replace CASA Account
          L_XML := REPLACE(L_XML, '$L_CASA_ACCOUNT', L_CASA_ACCOUNT);
        
          --get above casa account currency
          L_INSURANCE_CCY := FN_GET_INSURANCE_CASA_ACC_CCY(L_CASA_ACCOUNT);
        
          --Replace CASA Account
          L_XML := REPLACE(L_XML, '$L_CCY_CASA_ACCOUNT', L_INSURANCE_CCY);
        
          --Get insurance Amount based on the plan
          IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN
          
            L_INSURANCE_AMOUNT := FN_GET_INSURANCE_PLAN_AMOUNT('RUBY_PLAN_A',
                                                               L_INSURANCE_CCY);
          
          ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN
          
            --Get the plan. 2 plans
          
            IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
            
              L_INSURANCE_PLAN := 'GOLD_PLAN_A';
            
            ELSE
            
              L_INSURANCE_PLAN := 'GOLD_PLAN_B';
            
            END IF;
          
            L_INSURANCE_AMOUNT := FN_GET_INSURANCE_PLAN_AMOUNT(L_INSURANCE_PLAN, --pass the plan here
                                                               L_INSURANCE_CCY);
          
          ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN
          
            --Get the plan. 3 plans
          
            IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
            
              L_INSURANCE_PLAN := 'SILVER_PLAN_A';
            
            ELSIF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE > 366
                 
                  AND
                  GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 731 THEN
            
              L_INSURANCE_PLAN := 'SILVER_PLAN_B';
            
            ELSE
            
              L_INSURANCE_PLAN := 'SILVER_PLAN_C';
            
            END IF;
          
            L_INSURANCE_AMOUNT := FN_GET_INSURANCE_PLAN_AMOUNT(L_INSURANCE_PLAN, --pass the plan here
                                                               L_INSURANCE_CCY);
          
          END IF;
        
          --Replace Txn Amount with Insurance Amount
          L_XML := REPLACE(L_XML, '$L_INSURANCE_AMOUNT', L_INSURANCE_AMOUNT);
        
          DBG('Final Request xml=' || L_XML);
        
          L_RESPONSE := process_http('http://10.80.80.200:8002/' ||
                                     'FCUBSRTService/FCUBSRTService',
                                     L_XML,
                                     'text/xml;charset=utf-8');
        
          DBG('L_RESPONSE=' || L_RESPONSE);
        
          --Get Cosmetic XML
          PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
        
          DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
        
          P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
        
          --Check if returned error or success
          L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                          .GETSTRINGVAL;
        
          IF L_STATUS_MSG <> 'SUCCESS' THEN
          
            DBG('INSIDE FAILED');
          
            p_Err_Code := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/ECODE/text()')
                          .GETSTRINGVAL;
          
            p_Err_Params := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                            .GETSTRINGVAL;
          
            DBG('p_Err_Code=' || p_Err_Code);
            DBG('p_Err_Params=' || p_Err_Params);
          
            Pr_Log_Error(p_Function_id,
                         p_Source,
                         '', --pls put the error code
                         p_Err_Params);
          
            RETURN FALSE;
          
          ELSE
          
            DBG('SUCCESS');
          
            L_REFERENCE_NO := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/FCCREF/text()')
                                 .GETSTRINGVAL;
          
            DBG('L_REFERENCE_NO=' || L_REFERENCE_NO);
          
          END IF;
        
        END IF;
      
      END IF;
    
    END IF;
    --clever savings sampath ends
  
    Dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_icdredmn         IN icpks_icdredmn_Main.ty_icdredmn,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                                       p_Prev_icdredmn    IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                       p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                                        p_Prev_icdredmn    IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                        p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                      p_Source_Operation IN VARCHAR2,
                                      p_Function_Id      IN VARCHAR2,
                                      p_Action_Code      IN VARCHAR2,
                                      p_icdredmn         IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                      p_Err_Code         IN OUT VARCHAR2,
                                      p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Pre_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Resolve_Ref_Numbers;
  FUNCTION Fn_Post_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_icdredmn         IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Post_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of icpks_icdredmn_Main.Fn_Post_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Resolve_Ref_Numbers;
  FUNCTION Fn_Pre_Product_Default(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                                  p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Product_Default..');
  
    Dbg('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Product_Default;

  FUNCTION Fn_Post_Product_Default(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                                   p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Product_Default..');
  
    Dbg('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Product_Default;

  FUNCTION Fn_Pre_Unlock(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN OUT VARCHAR2,
                         p_icdredmn         IN icpks_icdredmn_Main.ty_icdredmn,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Unlock..');
  
    Dbg('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Unlock;

  FUNCTION Fn_Post_Unlock(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN OUT VARCHAR2,
                          p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Unlock');
  
    Dbg('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Unlock;

  FUNCTION Fn_Pre_Subsys_Pickup(p_Source           IN VARCHAR2,
                                p_Source_Operation IN VARCHAR2,
                                p_Function_Id      IN VARCHAR2,
                                p_Action_code      IN VARCHAR2,
                                p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                                p_Prev_icdredmn    IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                p_Err_Code         IN OUT VARCHAR2,
                                p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Subsys_Pickup..');
  
    Dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Subsys_Pickup;

  FUNCTION Fn_Post_Subsys_Pickup(p_Source           IN VARCHAR2,
                                 p_Source_Operation IN VARCHAR2,
                                 p_Function_Id      IN VARCHAR2,
                                 p_Action_code      IN VARCHAR2,
                                 p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                                 p_Prev_icdredmn    IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                 p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                                 p_Err_Code         IN OUT VARCHAR2,
                                 p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Subsys_Pickup..');
  
    Dbg('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Subsys_Pickup;

  FUNCTION Fn_Pre_Enrich(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_id      IN VARCHAR2,
                         p_Action_code      IN VARCHAR2,
                         p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                         p_Prev_icdredmn    IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                         p_wrk_icdredmn     IN OUT icpks_icdredmn_Main.ty_icdredmn,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Enrich..');
  
    Dbg('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Enrich ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Enrich;

  FUNCTION Fn_Post_Enrich(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                          p_Prev_icdredmn    IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                          p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Enrich..');
  
    Dbg('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Enrich ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Enrich;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                            p_Prev_icdredmn    IN icpks_icdredmn_Main.Ty_icdredmn,
                            p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                             p_Prev_icdredmn    IN icpks_icdredmn_Main.Ty_icdredmn,
                             p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Process(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_Child_Function   IN VARCHAR2,
                          p_Multi_Trip_Id    IN VARCHAR2,
                          p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                          p_Prev_icdredmn    IN icpks_icdredmn_Main.Ty_icdredmn,
                          p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Process..');
  
    Dbg('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Process;

  FUNCTION Fn_Post_Process(p_Source           IN VARCHAR2,
                           p_Source_Operation IN VARCHAR2,
                           p_Function_id      IN VARCHAR2,
                           p_Action_Code      IN VARCHAR2,
                           p_Child_Function   IN VARCHAR2,
                           p_Multi_Trip_Id    IN VARCHAR2,
                           p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                           p_Prev_icdredmn    IN icpks_icdredmn_Main.Ty_icdredmn,
                           p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                           p_Err_Code         IN OUT VARCHAR2,
                           p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Process..');
  
    Dbg('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Process;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                        p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Pre_Query ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_icdredmn         IN icpks_icdredmn_Main.Ty_icdredmn,
                         p_Wrk_icdredmn     IN OUT icpks_icdredmn_Main.Ty_icdredmn,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    dbg('In Fn_Post_Query');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of icpks_icdredmn_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_post_query;

END icpks_icdredmn_custom;
