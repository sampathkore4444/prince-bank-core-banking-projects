GRANT SELECT ON P1FCHPRFM.ictb_tdtopup_detail TO FCCNDG --in P1FCHPRFM

/
CREATE OR REPLACE VIEW ICVW_TDTOPUP_HIST_CLEVER_SAVINGS_DIG AS
SELECT topup.acc,
       cust_acc.ac_desc,
       topup.TD_OPEN_DATE,
       topup.TOPUP_DATE,
       topup.TOPUP_VALUE_DATE,
       topup.TOPUP_AMOUNT,
       topup.topup_ref_no,
       topup.TDAMT_AFTER_TOPUP,
       topup.INTRATE_AFTER_TOPUP,
       topup.TENOR_DD,
       topup.TENOR_MM,
       topup.TENOR_YY,
       topup.MATDATE,
       topup.MATAMT_AFTER_TOPUP,
       cust.customer_no,
       cust.customer_name1,
       topup.ccy,
       topup.brn,
       topup.MAKER_ID,
       topup.MAKER_DT_STAMP,
       topup.MATAMT_BEFORE_TOPUP,
       topup.INTRATE_BEFORE_TOPUP,
       topup.TDAMT_BEFORE_TOPUP,
       topup.NARRATIVE,
       topup.EXT_REFERENCE,
       topup.RECORD_STAT,
       topup.AUTH_STAT,
       topup.ONCE_AUTH,
       topup.CHECKER_ID,
       topup.CHECKER_DT_STAMP,
       topup.MOD_NO,
       STPKS_DIGITAL_UTLITIES.FN_GET_INT_TOPUP_RATE_CLEVER_SAVINGS(cust_acc.cust_ac_no,cust_acc.branch_code,topup.topup_date - cust_acc.Ac_Open_Date) + STPKS_DIGITAL_UTLITIES.fn_get_int_rate_CLEVER_SAVINGS_FOR_HIST_MB(cust_acc.cust_ac_no,cust_acc.branch_code) "TOPUP_RATE",
       STPKS_DIGITAL_UTLITIES.FN_GET_CLEVER_SAVINGS_PAYIN_ACC(cust_acc.cust_ac_no,cust_acc.branch_code,cust_acc.ccy) "AUTO_DEBIT_ACC"
  FROM p1fchprfm.ictb_tdtopup_detail topup,
       p1fchprfm.sttm_cust_account   cust_acc,
       p1fchprfm.sttm_customer       cust
where topup.acc = cust_acc.cust_ac_no
   and topup.brn = cust_acc.branch_code
   and topup.cust_no = cust.customer_no
   and cust_acc.account_class in ('SY01','SY02','GY01','GY02', 'RY01','RY02')
 /
 
CREATE TABLE IFTB_CLEVER_SAVINGS_OVERDUE_ACCS(SEQ_NO VARCHAR2(25) PRIMARY KEY, CUSTOMER_NO VARCHAR2(25), ACC VARCHAR2(25), BRN VARCHAR2(3), CCY VARCHAR2(3), DUE_DATE DATE, AUTO_CLOSE_DATE DATE, STATUS CHAR(1) DEFAULT 'N', ALERT_SENT_TIME DATE)
/ 
GRANT SELECT, UPDATE ON P1FCHPRFM.IFTB_CLEVER_SAVINGS_OVERDUE_ACCS TO FCCNDG
/ 
CREATE OR REPLACE VIEW IFVW_CLEVER_SAVINGS_OVERDUE_ACCS AS SELECT * FROM P1FCHPRFM.IFTB_CLEVER_SAVINGS_OVERDUE_ACCS
/
GRANT SELECT ON P1FCHPRFM.ICTM_TDPAYIN_DETAILS TO FCCNDG
/
GRANT SELECT ON P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM TO FCCNDG
