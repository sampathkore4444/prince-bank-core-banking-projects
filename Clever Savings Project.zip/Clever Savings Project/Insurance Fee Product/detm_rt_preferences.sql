prompt Importing table detm_rt_preferences...
set feedback off
set define off
insert into detm_rt_preferences (PRODUCT_CODE, RD_PAYMENTS, CASH_GL_POSTING_ALWD, TRACK_RECEIVABLE, TXN_LIMIT, REVERSAL_INCLUDES_CHARGES, PARTIAL_REV_ALLOWED, SWITCH_PRODUCT, BLOCK_EXP_DAYS, RETAIL_LENDING_PRODUCT, PC_TXN, REDEMPTION_ALLOWED, FT_TXN)
values ('CLIF', 'N', 'N', 'N', 300, 'Y', 'N', 'N', null, 'N', 'N', 'N', 'N');

prompt Done.
