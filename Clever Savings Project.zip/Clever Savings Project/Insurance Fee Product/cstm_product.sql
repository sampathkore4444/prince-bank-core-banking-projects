prompt Importing table cstm_product...
set feedback off
set define off
insert into cstm_product (PRODUCT_CODE, PRODUCT_DESCRIPTION, PRODUCT_SLOGAN, PRODUCT_REMARKS, PRODUCT_START_DATE, PRODUCT_END_DATE, PRODUCT_GROUP, WAREHOUSE_CODE, PART_OF_PRODUCT, MODULE, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, POOL_CODE, NO_OF_LEGS, BRANCHES_LIST, CURRENCIES_LIST, CATEGORIES_LIST, NORMAL_RATE_VARIANCE, MAXIMUM_RATE_VARIANCE, PRODUCT_TYPE, RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED, RTH_CLASS, ASSET_CATEGORIES_LIST, LOCATION_LIST, GEN_MT103P, INCLUDE_FOR_TDS_CALC, INSTRUMENT_PRODUCT_ALLOW, PORTFOLIO_PRODUCT_ALLOW)
values ('CLIF', 'Clever Savings Insurance Fee', 'Clever Savings Insurance Fee', null, to_date('01-01-2021', 'dd-mm-yyyy'), null, 'CASART', null, null, 'RT', 'O', 'A', 'Y', 'SAMPATH2', to_date('08-02-2023 17:54:42', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('08-02-2023 17:54:43', 'dd-mm-yyyy hh24:mi:ss'), 1, null, null, 'D', 'D', null, 3.00000, 100.00000, 'OT', 'B', 'COMM', null, null, null, null, null, null, null);

prompt Done.
