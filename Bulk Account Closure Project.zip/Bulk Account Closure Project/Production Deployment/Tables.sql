	-- Create table
create table STTM_ZOMBIE_ACCOUNTS_EA01
(
  customer_number     VARCHAR2(8),
  branch_code         VARCHAR2(3),
  account_number      VARCHAR2(9),
  account_name        VARCHAR2(255),
  account_open_date   DATE,
  account_status      CHAR(1),
  account_class       VARCHAR2(4),
  acy_account_balance NUMBER(22,3),
  ccy                 VARCHAR2(3),
  report_date         DATE,
  status_closed       CHAR(1) default 'N',
  record_stat         CHAR(1) default 'O'
)
/
alter table STTM_ZOMBIE_ACCOUNTS_EA01 add primary key(ACCOUNT_NUMBER)
/
-- Create table
create table IFTB_ZOMBIE_CUST_ACCOUNTS_EA01_WS_LOG
(
  reference_no   VARCHAR2(105),
  invoke_date    TIMESTAMP(6),
  cust_no        VARCHAR2(105),
  cust_ac_no     VARCHAR2(105),
  branch_code    VARCHAR2(3),
  req_msg        CLOB,
  res_msg        CLOB,
  status         CHAR(1),
  ccy            VARCHAR2(3),
  error_codes    VARCHAR2(255),
  error_messages VARCHAR2(1000)
)
/
alter table IFTB_ZOMBIE_CUST_ACCOUNTS_EA01_WS_LOG add primary key (REFERENCE_NO, CUST_NO, CUST_AC_NO, BRANCH_CODE)
/



-- Create table
create table STTM_ZOMBIE_ACCOUNTS_SA07
(
  customer_number     VARCHAR2(8),
  branch_code         VARCHAR2(3),
  account_number      VARCHAR2(9),
  account_name        VARCHAR2(255),
  account_open_date   DATE,
  account_status      CHAR(1),
  account_class       VARCHAR2(4),
  acy_account_balance NUMBER(22,3),
  ccy                 VARCHAR2(3),
  report_date         DATE,
  status_closed       CHAR(1) default 'N',
  record_stat         CHAR(1) default 'O'
)
/
-- Create/Recreate primary, unique and foreign key constraints 
alter table STTM_ZOMBIE_ACCOUNTS_SA07 add primary key (ACCOUNT_NUMBER)
/

-- Create table
create table IFTB_ZOMBIE_CUST_ACCOUNTS_WS_LOG
(
  reference_no   VARCHAR2(105),
  invoke_date    TIMESTAMP(6),
  cust_no        VARCHAR2(105),
  cust_ac_no     VARCHAR2(105),
  branch_code    VARCHAR2(3),
  req_msg        CLOB,
  res_msg        CLOB,
  status         CHAR(1),
  ccy            VARCHAR2(3),
  error_codes    VARCHAR2(255),
  error_messages VARCHAR2(1000)
)
/
-- Create/Recreate primary, unique and foreign key constraints 
alter table IFTB_ZOMBIE_CUST_ACCOUNTS_WS_LOG add primary key (REFERENCE_NO, CUST_NO, CUST_AC_NO, BRANCH_CODE)
/

-- Create sequence 
create sequence TRSQ_ZOMBIE_CUST_ACCS
minvalue 1
maxvalue 9999999999999
start with 1
increment by 1
cache 20;
/