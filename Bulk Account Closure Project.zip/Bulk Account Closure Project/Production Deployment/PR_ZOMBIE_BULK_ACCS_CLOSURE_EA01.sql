CREATE OR REPLACE PROCEDURE PR_ZOMBIE_BULK_ACCS_CLOSURE_EA01
 AS

  L_RESPONSE          VARCHAR2(32000) := '';
  L_FORMATTED_RES_MSG CLOB;
  P_DOCUMENT_XML      XMLTYPE;
  L_XML               VARCHAR2(32000);
  L_PASSWORD          VARCHAR2(100);
  L_REF               VARCHAR2(100);
  L_SEQ               VARCHAR2(100);

  L_MSG_ID   GWTB_MSG_IN_LOG.MSG_ID%TYPE;
  L_CORR_ID  GWTB_MSG_IN_LOG.CORREL_ID%TYPE;
  L_BRN_CODE STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
  L_CUST_ACC STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;

  L_STATUS_MSG      VARCHAR2(105);
  L_ERROR_DESC      VARCHAR2(255);
  L_ERROR_CODE_LIST VARCHAR2(1000);
  L_ERROR_MSGS_LIST VARCHAR2(1000);

  PROCEDURE PR_GET_FORMATTED_XML(P_XML           IN VARCHAR2,
                                 P_FORMATTED_XML OUT VARCHAR2) IS

    --P_COSMETIC_XML VARCHAR2(32000);

  BEGIN

    P_FORMATTED_XML := P_XML;

    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">',
                               NULL);

    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '<S:Body>', NULL);

    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSAccService"',
                               NULL);

    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<?xml version="1.0" encoding="UTF-8"?>',
                               NULL);

    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '   </S:Body>', NULL);
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Body>', NULL);

    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Envelope>', NULL);

  END PR_GET_FORMATTED_XML;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_TDREDEEMPTION_CLEVERSAVINGS_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_INSERT_ZOMBIE_WS_LOG(P_SEQ_NO    IN VARCHAR2,
                                    P_INVOKE_TS IN TIMESTAMP,
                                    P_CUST_NO   IN VARCHAR2,
                                    P_ACC       IN VARCHAR2,
                                    P_BRN       IN VARCHAR2,
                                    P_CCY       IN VARCHAR2,
                                    P_REQ_TYPE  IN VARCHAR2,
                                    P_REQ_MSG   IN VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    INSERT INTO IFTB_ZOMBIE_CUST_ACCOUNTS_EA01_WS_LOG
      (REFERENCE_NO,
       INVOKE_DATE,
       CUST_NO,
       CUST_AC_NO,
       BRANCH_CODE,
       CCY,
       REQ_MSG)
    VALUES
      (P_SEQ_NO, P_INVOKE_TS, P_CUST_NO, P_ACC, P_BRN, P_CCY, P_REQ_MSG);

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_ZOMBIE_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_ZOMBIE_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_ZOMBIE_WS_LOG=' || SQLERRM);
  END PR_INSERT_ZOMBIE_WS_LOG;

  PROCEDURE PR_UPDATE_ZOMBIE_WS_LOG(P_SEQ_NO      IN VARCHAR2,
                                    P_RESPONSE    IN CLOB,
                                    P_STATUS      IN CHAR,
                                    P_ERROR_CODES IN VARCHAR2,
                                    P_ERROR_MSGS  IN VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_ZOMBIE_WS_LOG');

    UPDATE IFTB_ZOMBIE_CUST_ACCOUNTS_EA01_WS_LOG
       SET RES_MSG        = P_RESPONSE,
           STATUS         = P_STATUS,
           ERROR_CODES    = P_ERROR_CODES,
           ERROR_MESSAGES = P_ERROR_MSGS
     WHERE REFERENCE_NO = P_SEQ_NO;

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_ZOMBIE_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_ZOMBIE_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_ZOMBIE_WS_LOG=' || SQLERRM);
  END PR_UPDATE_ZOMBIE_WS_LOG;

  PROCEDURE PR_UPDATE_ZOMBIE_ACC_STAT_MASTER(P_SEQ_NO      IN VARCHAR2,
                                             P_ACC         IN VARCHAR2,
                                             P_BRN         IN VARCHAR2,
                                             P_CCY         IN VARCHAR2,
                                             P_RECORD_STAT IN VARCHAR2,
                                             P_STAT_CLOSE  IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    DBG('START OF PR_UPDATE_ZOMBIE_ACC_STAT_MASTER');

    UPDATE STTM_ZOMBIE_ACCOUNTS_EA01 A
       SET RECORD_STAT = P_RECORD_STAT, STATUS_CLOSED = P_STAT_CLOSE
     WHERE A.ACCOUNT_NUMBER = P_ACC
       AND BRANCH_CODE = P_BRN
       AND CCY = P_CCY;

    COMMIT;

    DBG('END OF PR_UPDATE_ZOMBIE_ACC_STAT_MASTER');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_ZOMBIE_ACC_STAT_MASTER');
      DBG('ERROR CODE IN PR_UPDATE_ZOMBIE_ACC_STAT_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_ZOMBIE_ACC_STAT_MASTER=' || SQLERRM);
  END PR_UPDATE_ZOMBIE_ACC_STAT_MASTER;

BEGIN

  FOR G IN (SELECT *
              FROM STTM_ZOMBIE_ACCOUNTS_EA01 A
             WHERE A.STATUS_CLOSED = 'N'
               AND RECORD_STAT = 'O'
               --AND A.ACCOUNT_NUMBER = '000442646'
               ) LOOP

    BEGIN

      GLOBAL.PR_INIT(G.BRANCH_CODE, 'SYSTEM');

      SAVEPOINT A;

      L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSAccService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:CLOSECUSTACC_IOPK_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>DIGIBANK</fcub:SOURCE>
                <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
                <fcub:MSGID>L_MSG_ID</fcub:MSGID>
                <fcub:CORRELID>L_CORR_ID</fcub:CORRELID>
                <fcub:USERID>SYSTEM</fcub:USERID>
                <fcub:ENTITY>ENTITY_ID1</fcub:ENTITY>
                <fcub:BRANCH>L_BRN_CODE</fcub:BRANCH>
                <fcub:MODULEID>ST</fcub:MODULEID>
                <fcub:SERVICE>FCUBSAccService</fcub:SERVICE>
                <fcub:OPERATION>CloseCustAcc</fcub:OPERATION>
                <fcub:SOURCE_OPERATION></fcub:SOURCE_OPERATION>
                <fcub:SOURCE_USERID></fcub:SOURCE_USERID>
                <fcub:DESTINATION></fcub:DESTINATION>
                <fcub:MULTITRIPID></fcub:MULTITRIPID>
                <fcub:FUNCTIONID></fcub:FUNCTIONID>
                <fcub:ACTION>CLOSE</fcub:ACTION>
                <fcub:MSGSTAT></fcub:MSGSTAT>
                <fcub:SNAPSHOTID></fcub:SNAPSHOTID>
                <fcub:PASSWORD></fcub:PASSWORD>

            <fcub:ADDL>
               <!--Zero or more repetitions:-->
               <fcub:PARAM>
                  <fcub:NAME></fcub:NAME>
                  <fcub:VALUE></fcub:VALUE>
               </fcub:PARAM>
            </fcub:ADDL>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Cust-Account-IO>
               <fcub:BRN>L_BRN_CODE</fcub:BRN>
               <fcub:ACC>L_CUST_ACC</fcub:ACC>

               <fcub:MAKER></fcub:MAKER>

               <fcub:MAKERSTAMP></fcub:MAKERSTAMP>

               <fcub:MODNO></fcub:MODNO>
            </fcub:Cust-Account-IO>
         </fcub:FCUBS_BODY>
      </fcub:CLOSECUSTACC_IOPK_REQ>
   </soapenv:Body>
</soapenv:Envelope>';

      --SEQUENCE GENERATION FOR MSGID AND REF ID
      SELECT TRSQ_ZOMBIE_CUST_ACCS.NEXTVAL INTO L_SEQ FROM DUAL;

      L_REF := SUBSTR(TO_CHAR(SYSDATE, 'YYMM'), 2) || LPAD(L_SEQ, 9, '0');

      L_XML := REPLACE(L_XML, 'L_MSG_ID', L_REF);
      L_XML := REPLACE(L_XML, 'L_CORR_ID', L_REF);
      L_XML := REPLACE(L_XML, 'L_BRN_CODE', G.BRANCH_CODE);
      L_XML := REPLACE(L_XML, 'L_CUST_ACC', G.ACCOUNT_NUMBER);

      --log ws call

      PR_INSERT_ZOMBIE_WS_LOG(L_REF,
                              SYSTIMESTAMP,
                              G.CUSTOMER_NUMBER,
                              G.ACCOUNT_NUMBER,
                              G.BRANCH_CODE,
                              G.CCY,
                              'CLOSE',
                              L_XML);

      L_RESPONSE := process_http('http://192.168.20.172:8001/' ||
                                 'FCUBSAccService/FCUBSAccService',
                                 L_XML,
                                 'text/xml;charset=utf-8');

      DBG('L_RESPONSE=' || L_RESPONSE);

      PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);

      DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);

      P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);

      --Check if returned error or success
      BEGIN
        L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CLOSECUSTACC_IOPK_RES/FCUBS_HEADER/MSGSTAT/text()')
                        .GETSTRINGVAL; --pls check
      EXCEPTION
        WHEN OTHERS THEN
          L_STATUS_MSG := '*.*';
      END;

      --DBMS_OUTPUT.put_line('L_STATUS_MSG=' || L_STATUS_MSG);

      IF NVL(L_STATUS_MSG, '*.*') = 'SUCCESS' THEN

        PR_UPDATE_ZOMBIE_ACC_STAT_MASTER(L_REF,
                                         G.ACCOUNT_NUMBER,
                                         G.BRANCH_CODE,
                                         G.CCY,
                                         'C',
                                         'Y');

        PR_UPDATE_ZOMBIE_WS_LOG(L_REF, L_RESPONSE, 'S', NULL, NULL);

      ELSE

        --Get the list of error codes
        BEGIN
          SELECT LISTAGG(ecode, ',') WITHIN GROUP(ORDER BY NULL)
            INTO L_ERROR_CODE_LIST
            FROM XMLTable('declare namespace ns="http://fcubs.ofss.com/service/FCUBSAccService";
       //ns:ERROR/ns:ECODE' PASSING
                          XMLTYPE(L_RESPONSE) COLUMNS ecode VARCHAR2(100) PATH '.');

        EXCEPTION
          WHEN OTHERS THEN
            L_ERROR_CODE_LIST := NULL;
        END;

        --DBMS_OUTPUT.put_line('L_ERROR_CODE_LIST=' || L_ERROR_CODE_LIST);

        --Get the list of error messages
        BEGIN
          SELECT LISTAGG(emessage, ',') WITHIN GROUP(ORDER BY NULL)
            INTO L_ERROR_MSGS_LIST
            FROM XMLTable('declare namespace ns="http://fcubs.ofss.com/service/FCUBSAccService";
       //ns:ERROR/ns:EDESC' PASSING
                          XMLTYPE(L_RESPONSE) COLUMNS emessage
                          VARCHAR2(100) PATH '.');

        EXCEPTION
          WHEN OTHERS THEN
            L_ERROR_MSGS_LIST := NULL;
        END;

        --DBMS_OUTPUT.put_line('L_ERROR_MSGS_LIST=' || L_ERROR_MSGS_LIST);

        PR_UPDATE_ZOMBIE_ACC_STAT_MASTER(L_REF,
                                         G.ACCOUNT_NUMBER,
                                         G.BRANCH_CODE,
                                         G.CCY,
                                         'O',
                                         'N');

        PR_UPDATE_ZOMBIE_WS_LOG(L_REF,
                                L_RESPONSE,
                                'F',
                                L_ERROR_CODE_LIST,
                                L_ERROR_MSGS_LIST);

        ROLLBACK TO A;

        CONTINUE;

      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN PROCESSING THE CURRENT ACCOUNT');
        DBG('ERROR LINE NUMBER WHILE PROCESSING THE CURRENT ACCOUNT=' ||
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        DBG('ERROR CODE WHILE PROCESSING THE CURRENT ACCOUNT=' || SQLCODE);
        DBG('ERROR MESSAGE WHILE PROCESSING THE CURRENT ACCOUNT=' ||
            SQLERRM);

         --dbms_output.put_line('Error code='||SQLCODE);
         --dbms_output.put_line('Error message='||SQLERRM);
         --dbms_output.put_line('Error line number='||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

        ROLLBACK TO A;

        CONTINUE;

    END;

  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK TO A;
    DBG('FAILED IN PR_ZOMBIE_BULK_ACCS_CLOSURE_EA01');
    DBG('ERROR LINE NUMBER PR_ZOMBIE_BULK_ACCS_CLOSURE_EA01=' ||
        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    DBG('ERROR CODE IN PR_ZOMBIE_BULK_ACCS_CLOSURE_EA01=' || SQLCODE);
    DBG('ERROR MESSAGE in PR_ZOMBIE_BULK_ACCS_CLOSURE_EA01=' || SQLERRM);
END PR_ZOMBIE_BULK_ACCS_CLOSURE_EA01;
