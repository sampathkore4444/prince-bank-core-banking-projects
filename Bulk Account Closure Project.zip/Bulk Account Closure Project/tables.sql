--Created a new table


CREATE TABLE STTM_ZOMBIE_CUST_ACCOUNTS AS select a.branch_code, a.cust_ac_no, A.CCY, a.cust_no, a.record_stat
  from  sttm_cust_account a, sttm_account_balance b
where a.cust_ac_no = b.cust_ac_no
   and a.branch_code = b.cust_ac_brn
   and a.account_class IN ('EA01','EA02')
   and a.record_stat = 'O'
   and (a.ACY_AVL_BAL = 0 and b.ACY_WITHDRAWABLE_BAL = 0 and
       b.ACY_UNCOLLECTED = 0 and b.ACY_BLOCKED_AMT = 0 and
       b.WITHDRAWABLE_UNCOLLED_FUND = 0 and b.RECEIVABLE_AMOUNT = 0 and
       b.ACY_ECA_BLOCKED_AMT = 0 and b.ACY_UNAUTH_CR = 0 and
       b.ACY_CURR_ACC_BAL = 0)

/

ALTER TABLE STTM_ZOMBIE_CUST_ACCOUNTS ADD (STATUS_CLOSED CHAR(1) DEFAULT 'N', MSG_ID VARCHAR2(255));

/

ALTER TABLE STTM_ZOMBIE_CUST_ACCOUNTS ADD PRIMARY KEY(BRANCH_CODE, CUST_AC_NO, CCY)

/

create sequence TRSQ_ZOMBIE_CUST_ACCS
minvalue 1
maxvalue 9999999999999
start with 1
increment by 1
cache 20
/

-- Create table
create table IFTB_ZOMBIE_CUST_ACCOUNTS_WS_LOG
(
  reference_no   VARCHAR2(105) not null,
  invoke_date    TIMESTAMP(6),
  cust_no        VARCHAR2(105) not null,
  cust_ac_no     VARCHAR2(105) not null,
  branch_code    VARCHAR2(3) not null,
  req_msg        CLOB,
  res_msg        CLOB,
  status         CHAR(1),
  ccy            VARCHAR2(3),
  error_codes    VARCHAR2(255),
  error_messages VARCHAR2(1000)
)
/
alter table IFTB_ZOMBIE_CUST_ACCOUNTS_WS_LOG add primary key (REFERENCE_NO, CUST_NO, CUST_AC_NO, BRANCH_CODE)
/


