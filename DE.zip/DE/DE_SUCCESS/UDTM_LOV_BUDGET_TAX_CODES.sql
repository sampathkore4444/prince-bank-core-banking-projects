prompt Importing table UDTM_LOV...
set feedback off
set define off
insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205973', 'Light box', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205972', 'Other', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205975', 'Name card', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205974', 'Sticker', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205969', 'Annual report', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205968', 'I-stand for outdoor', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205971', 'T&C book', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205970', 'Leaflet', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205976', 'PVC Banner', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205982', 'Video for SHE conference ', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205981', 'Video Nailboy', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205984', 'PVC', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205983', 'Booth fixing', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205978', 'VIP Lounge', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205977', 'Info corner', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205980', 'Pchum Benh video', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205979', 'Animation video', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205956', 'Women''s right day', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205955', 'Valentine day', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205958', 'Moon festival', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205957', 'Pchum Ben', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205952', 'lkhon khol mask', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205951', 'Temporary Signage', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205954', 'Khmer New Year', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205953', 'Chinese New Year', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205959', 'Water festival', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205965', 'Parasol', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205964', 'Outdoor booth', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205967', 'I-stand/x-stand', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205966', 'J-flag', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205961', 'TV commercial', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205960', 'Christmas', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205963', 'Premium booth', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205962', 'Product clip', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206007', 'Distribution - Customer', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206006', 'Reverse Umbrella', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206009', 'BRM - Customer', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206008', 'Distribution - Team', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206003', 'Helmet', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206002', 'Raincoat', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206005', 'Pin', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206004', 'Cap', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206010', 'BRM - Team', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206016', 'External sale campaign', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206015', 'Internal sale campaign', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206018', 'EQUIPMENTS', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206017', 'Branches signage tax', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206012', 'Quaterly award - branch', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206011', 'Marketing - Team', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206014', 'Quaterly award - Back office', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206013', 'Quaterly award - BR', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205990', 'T-shirt - round neck', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205989', 'Premium gift set', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205992', 'Pen - normal', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205991', 'Name card holder', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205986', 'Actor and Actress', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205985', 'Bank form ', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205988', 'DCP Convertion 30 sec', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205987', 'Membership card', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205993', 'Eco bag', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205999', 'Pen - mental', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205998', 'Shopping bag', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206001', 'Notebook', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11206000', 'LED Umbrella', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205995', 'Keychain', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205994', 'T-shirt - Polo neck', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205997', 'Desk calendar', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205996', 'Wall calendar', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205917', 'Big Activiation at Major', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205918', 'Small event at Major', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205919', 'Customer workshop - PP', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205914', 'Roadshow', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205915', 'Grand opening', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205916', 'Customer Party', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205923', 'JCI', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205924', 'Financial Literacy Day', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205925', 'EFMA', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205920', 'Customer workshop - Provincial', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205921', 'Branches own activities', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205922', 'Riel Day', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205913', 'Digital news ads', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205904', 'TV airing', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205905', 'Radio airing', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205906', 'Digital ads', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205901', 'Billboard.LED', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205902', 'City bus', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205903', 'Business Directory', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205910', 'Print ads/magazine', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205911', 'Major Cineplex sponsorship', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205912', 'Jaguar Capital Royal Investment sponsorship', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205907', 'Google ads', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205908', 'SEO', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205909', 'Facebook', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205942', 'Major Cinema &Prince Bank annual partnership party', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205943', 'CSPro Training', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205944', 'Education video clip', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205939', 'Networking event', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205940', 'Exhibition - Trade fair/family/kid/education', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205941', 'Charity event ', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205948', 'Digital Marketing ', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205949', 'Agency Retainer', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205950', 'Miscellaneous', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205945', 'Animation Element', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205946', 'Cabinet ', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205947', 'Men power', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205938', 'The fourth world heritage', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205929', 'Dog Coach Donation', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205930', 'Cambodia Construction Summit and EXPO 2018', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205931', 'GAC', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205926', 'CYEA', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205927', 'Signing Ceremony', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205928', 'SHE', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205935', 'National career fair', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205936', 'PP Sa-art', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205937', '6th Charity concert and exhibition festival at ITC  ', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205932', 'Woman and Finance', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205933', 'Couple run', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('BUDGET_CODE', '11205934', 'Business Presentation', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EX10%-OTHER', 'Accrued Taxes Payable - Rental Furniture, Fixture, Equipment, Other', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'IN10%-BUILDING', 'Accrued Taxes Payable - Rental Building Office', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'INT-Re15%', 'Accrued Taxes Payable -  Interest Expense - Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'IN10%-OTHER', 'Accrued Taxes Payable - Rental Furniture, Fixture, Equipment, Other', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EX10%-BUILDING', 'Accrued Taxes Payable - Rental Building Office', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'IN15%', 'Accrued Taxes Payable - Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EX15%', 'Accrued Taxes Payable - Services - Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'IN14%', 'Accrued Taxes Payable - Services - Non Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EX14%', 'Accrued Taxes Payable - Services - Non Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'SAV14%', 'Saving & Demand Deposit - Non-Resident (14%)', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'SAV4%', 'Saving & Demand Deposit - Resident (4%)', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'TIM14%', 'Time Deposit - Non-Resident (14%)', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'TIM6%', 'Time Deposit - Resident (6%)', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'TOS', 'Accrued And Withheld Payroll Taxes Payable', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EXFB20%', 'Accrued Taxes Payable - Fringe Benefits 20%', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'INT-NonRes14%', 'Accrued Taxes Payable -  Interest Expense - Non Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'PRE1%', 'Accrued Income Taxes Payable - Current Year', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'INFB20%', 'Accrued Taxes Payable - Fringe Benefits 20%', 'N');

prompt Done.
