prompt Importing table GITM_FILE_NAMES...
set feedback off
set define off
insert into GITM_FILE_NAMES (INTERFACE_CODE, FILE_NAME)
values ('DEUPLOAD', 'DE.csv');

prompt Done.
