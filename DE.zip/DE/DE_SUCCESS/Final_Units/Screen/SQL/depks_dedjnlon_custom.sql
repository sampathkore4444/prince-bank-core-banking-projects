CREATE OR REPLACE PACKAGE BODY depks_dedjnlon_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : depks_dedjnlon_custom.sql
  **
  ** Module     : Data Entry
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2019 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
     ** Changed by         :  Kore Sampath Kumar
  ** Changed On         :  02-August-2019
  ** Change Description :  DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code
  ** Search String      :  DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'depks_dedjnlon_Custom ==>' || p_Msg;
      Debug.Pr_Debug('DE', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION Fn_Post_Build_Type_Structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_dedjnlon         IN OUT depks_dedjnlon_Main.ty_dedjnlon,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_Type_Structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Build_Type_Structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                  p_dedjnlon         IN OUT depks_dedjnlon_Main.ty_dedjnlon,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory..');
  
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
    
      IF P_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM.COUNT > 0 THEN
      
        FOR L_INDEX IN 1 .. P_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM.COUNT LOOP
        
          IF P_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX)
           .DEPT_CODE IS NULL THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'DE-PRIN-01', NULL);
            RETURN FALSE;
          END IF;
        
        END LOOP;
      END IF;
    
    END IF;
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code Ends
  
    Dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_dedjnlon         IN depks_dedjnlon_Main.ty_dedjnlon,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                                       p_Prev_dedjnlon    IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                       p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                                        p_Prev_dedjnlon    IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                        p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                      p_Source_Operation IN VARCHAR2,
                                      p_Function_Id      IN VARCHAR2,
                                      p_Action_Code      IN VARCHAR2,
                                      p_dedjnlon         IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                      p_Err_Code         IN OUT VARCHAR2,
                                      p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Pre_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Resolve_Ref_Numbers;
  FUNCTION Fn_Post_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_dedjnlon         IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Post_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of depks_dedjnlon_Main.Fn_Post_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Resolve_Ref_Numbers;
  FUNCTION Fn_Pre_Product_Default(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                                  p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Product_Default..');
  
    Dbg('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Product_Default;

  FUNCTION Fn_Post_Product_Default(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                                   p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Product_Default..');
  
    Dbg('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Product_Default;

  FUNCTION Fn_Pre_Unlock(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN OUT VARCHAR2,
                         p_dedjnlon         IN depks_dedjnlon_Main.ty_dedjnlon,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Unlock..');
  
    Dbg('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Unlock;

  FUNCTION Fn_Post_Unlock(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN OUT VARCHAR2,
                          p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Unlock');
  
    Dbg('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Unlock;

  FUNCTION Fn_Pre_Subsys_Pickup(p_Source           IN VARCHAR2,
                                p_Source_Operation IN VARCHAR2,
                                p_Function_Id      IN VARCHAR2,
                                p_Action_code      IN VARCHAR2,
                                p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                                p_Prev_dedjnlon    IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                p_Err_Code         IN OUT VARCHAR2,
                                p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Subsys_Pickup..');
  
    Dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Subsys_Pickup;

  FUNCTION Fn_Post_Subsys_Pickup(p_Source           IN VARCHAR2,
                                 p_Source_Operation IN VARCHAR2,
                                 p_Function_Id      IN VARCHAR2,
                                 p_Action_code      IN VARCHAR2,
                                 p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                                 p_Prev_dedjnlon    IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                 p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                                 p_Err_Code         IN OUT VARCHAR2,
                                 p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Subsys_Pickup..');
  
    Dbg('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Subsys_Pickup;

  FUNCTION Fn_Pre_Enrich(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_id      IN VARCHAR2,
                         p_Action_code      IN VARCHAR2,
                         p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                         p_Prev_dedjnlon    IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                         p_wrk_dedjnlon     IN OUT depks_dedjnlon_Main.ty_dedjnlon,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Enrich..');
  
    Dbg('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Enrich ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Enrich;

  FUNCTION Fn_Post_Enrich(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                          p_Prev_dedjnlon    IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                          p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Enrich..');
  
    Dbg('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Enrich ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Enrich;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                            p_Prev_dedjnlon    IN depks_dedjnlon_Main.Ty_dedjnlon,
                            p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                             p_Prev_dedjnlon    IN depks_dedjnlon_Main.Ty_dedjnlon,
                             p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code starts
    L_COUNT NUMBER := 0;
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code ends
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
    
      DBG('Inserting Into DETBS_JRNL_TXN_DTL_CUSTOM..');
      BEGIN
        L_COUNT := P_WRK_DEDJNLON.v_detbs_jrnl_txn_dtl_custom.COUNT;
      
        FOR L_INDEX IN 1 .. L_COUNT LOOP
        
          P_WRK_DEDJNLON.v_detbs_jrnl_txn_dtl_custom(L_INDEX).reference_no := P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(L_INDEX)
                                                                              .reference_no;
        
          P_WRK_DEDJNLON.v_detbs_jrnl_txn_dtl_custom(L_INDEX).serial_no := P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(L_INDEX)
                                                                           .serial_no;
        
          INSERT INTO DETBS_JRNL_TXN_DTL_CUSTOM
          VALUES P_WRK_DEDJNLON.v_detbs_jrnl_txn_dtl_custom
            (L_INDEX);
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed In Insert intoDETBS_JRNL_TXN_DETAIL..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@DETBS_JRNL_TXN_DETAIL';
          RETURN FALSE;
      END;
    
    END IF;
  
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code ends
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Process(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_Child_Function   IN VARCHAR2,
                          p_Multi_Trip_Id    IN VARCHAR2,
                          p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                          p_Prev_dedjnlon    IN depks_dedjnlon_Main.Ty_dedjnlon,
                          p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Process..');
  
    Dbg('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Process;

  FUNCTION Fn_Post_Process(p_Source           IN VARCHAR2,
                           p_Source_Operation IN VARCHAR2,
                           p_Function_id      IN VARCHAR2,
                           p_Action_Code      IN VARCHAR2,
                           p_Child_Function   IN VARCHAR2,
                           p_Multi_Trip_Id    IN VARCHAR2,
                           p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                           p_Prev_dedjnlon    IN depks_dedjnlon_Main.Ty_dedjnlon,
                           p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                           p_Err_Code         IN OUT VARCHAR2,
                           p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Process..');
  
    Dbg('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Process;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                        p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Pre_Query ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_dedjnlon         IN depks_dedjnlon_Main.Ty_dedjnlon,
                         p_Wrk_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code starts
    CURSOR MULITJR_DTL_CUSTOM IS
      SELECT *
        FROM DETBS_JRNL_TXN_DTL_CUSTOM
       WHERE REFERENCE_NO =
             P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_MASTER.REFERENCE_NO;
    L_COUNT NUMBER;
    L_INDEX NUMBER := 0;
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code ends
  BEGIN
  
    dbg('In Fn_Post_Query');
  
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code starts
    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
    
      L_COUNT := P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail.COUNT;
    
      DBG('L_COUNT=' || L_COUNT);
    
      /*SELECT COUNT(1)
        INTO L_COUNT
        FROM STVW_MULTI_JOURNAL_ENTRY
       WHERE REFERENCE_NO = P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(1)
            .REFERENCE_NO
         AND SERIAL_NO = P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(1)
            .SERIAL_NO;
      
      DBG('L_COUNT=' || L_COUNT);*/
    
      /*FOR G IN (SELECT *
                  FROM STVW_MULTI_JOURNAL_ENTRY
                 WHERE REFERENCE_NO = P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(1)
                      .REFERENCE_NO) LOOP
      
        DBG('INSIDE FOR LOOP');
        DBG('G.REFERENCE_NO=' || G.REFERENCE_NO);
        DBG('G.SERIAL_NO=' || G.SERIAL_NO);
      
        P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).REFERENCE_NO := G.REFERENCE_NO;
        P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).SERIAL_NO := G.SERIAL_NO;
      
        P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).BUDGET_CODE := G.BUDGET_CODE;
        P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).TAX_CODE := G.TAX_CODE;
        P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).SUPPLIER_CODE := G.SUPPLIER_CODE;
      
        DBG(P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).BUDGET_CODE);
        DBG(P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).TAX_CODE);
        DBG(P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX)
            .SUPPLIER_CODE);
      
        L_INDEX := L_INDEX + 1;
      END LOOP;*/
    
      /*FOR L_INDEX IN 1 .. L_COUNT LOOP
      
        P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).REFERENCE_NO := P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(L_INDEX)
                                                                            .REFERENCE_NO;
        P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).SERIAL_NO := P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(L_INDEX)
                                                                         .SERIAL_NO;
      
        SELECT BUDGET_CODE, TAX_CODE, SUPPLIER_CODE
          INTO P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX)
               .BUDGET_CODE,
               P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX).TAX_CODE,
               P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX)
               .SUPPLIER_CODE
          FROM DETBS_JRNL_TXN_DTL_CUSTOM
         WHERE REFERENCE_NO = P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(L_INDEX)
              .REFERENCE_NO
           AND SERIAL_NO = P_WRK_DEDJNLON.v_detbs_jrnl_txn_detail(L_INDEX)
              .SERIAL_NO;
      
        DBG('BUDGET CODE=' || P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX)
            .BUDGET_CODE);
      
        DBG('TAX CODE=' || P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX)
            .TAX_CODE);
      
        DBG('SUPPLIER CODE=' || P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(L_INDEX)
            .SUPPLIER_CODE);
      
      END LOOP;*/
    
      /*IF NOT DEPKS_DEDJNLON_MAIN.Fn_Sys_Query(P_SOURCE,
                                              P_SOURCE_OPERATION,
                                              P_FUNCTION_ID,
                                              P_ACTION_CODE,
                                              P_FULL_DATA,
                                              P_WITH_LOCK,
                                              P_QRYDATA_REQD,
                                              P_DEDJNLON,
                                              P_WRK_DEDJNLON,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
        DBG('Failed while calling DEPKS_DEDJNLON_MAIN.FN_SYS_QUERY');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;*/
    
      OPEN MULITJR_DTL_CUSTOM;
      LOOP
        DBG('in loop of c_deferred_charge_details');
        FETCH MULITJR_DTL_CUSTOM BULK COLLECT
          INTO P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM;
        DBG('count of deferred details in post_query: ' ||
            P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM.COUNT);
        EXIT WHEN MULITJR_DTL_CUSTOM%NOTFOUND;
      END LOOP;
    
      /*IF P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM.COUNT > 0 THEN
        DBG('INSIDE IF');
        FOR I IN 1 .. P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM.COUNT LOOP
          DBG('INSIDE COUNT');
          DBG(P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(I).BUDGET_CODE);
          P_WRK_DEDJNLON.DESC_FIELDS('DETBS_JRNL_TXN_DTL_CUSTOM')(I)('BUDGET_CODE') := P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(I)
                                                                                       .BUDGET_CODE;
        
          P_WRK_DEDJNLON.DESC_FIELDS('DETBS_JRNL_TXN_DTL_CUSTOM')(I)('TAX_CODE') := P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(I)
                                                                                    .TAX_CODE;
        
          P_WRK_DEDJNLON.DESC_FIELDS('DETBS_JRNL_TXN_DTL_CUSTOM')(I)('SUPPLIER_CODE') := P_WRK_DEDJNLON.V_DETBS_JRNL_TXN_DTL_CUSTOM(I)
                                                                                         .SUPPLIER_CODE;
        END LOOP;
      
      END IF;*/
    
    END IF;
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code ends
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedjnlon_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_post_query;

END depks_dedjnlon_custom;
/