insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EX15%', 'Accrued Taxes Payable - Services - Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'IN15%', 'Accrued Taxes Payable - Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EX14%', 'Accrued Taxes Payable - Services - Non Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'IN14%', 'Accrued Taxes Payable - Services - Non Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EX10%-BUILDING', 'Accrued Taxes Payable - Rental Building Office', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'IN10%-BUILDING', 'Accrued Taxes Payable - Rental Building Office', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EX10%-OTHER', 'Accrued Taxes Payable - Rental Furniture, Fixture, Equipment, Other', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'IN10%-OTHER', 'Accrued Taxes Payable - Rental Furniture, Fixture, Equipment, Other', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'INT-Re15%', 'Accrued Taxes Payable -  Interest Expense - Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'INT-NonRes14%', 'Accrued Taxes Payable -  Interest Expense - Non Resident', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'EXFB20%', 'Accrued Taxes Payable - Fringe Benefits 20%', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'INFB20%', 'Accrued Taxes Payable - Fringe Benefits 20%', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'PRE1%', 'Accrued Income Taxes Payable - Current Year', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'TOS', 'Accrued And Withheld Payroll Taxes Payable', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'SAV4%', 'Saving & Demand Deposit - Resident (4%)', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'SAV14%', 'Saving & Demand Deposit - Non-Resident (14%)', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'TIM6%', 'Time Deposit - Resident (6%)', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('TAX_CODE', 'TIM14%', 'Time Deposit - Non-Resident (14%)', 'N');

COMMIT;
