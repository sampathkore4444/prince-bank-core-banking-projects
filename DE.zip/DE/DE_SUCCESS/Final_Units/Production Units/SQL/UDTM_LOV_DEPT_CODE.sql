insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0100', 'EXECUTIVE OFFICE', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0110', 'CEO''s Office', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0120', 'Special Projects', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0130', 'Public Affairs', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0200', 'RISK DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0210', 'Credit Risk', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0220', 'Operation Risk', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0230', 'Credit Admin & Collection', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0300', 'COMPLIANCE DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0310', 'Compliance Department', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0311', 'AML/CFT', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0312', 'Regulatory Compliancec', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0400', 'INTERNAL AUDIT DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0410', 'HO Audit', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0420', 'Branch Audit', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0430', 'Investigation', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0440', 'Quality Assurance', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0450', 'Information Security & Audit', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0500', 'LEGAL AFFAIRS DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0510', 'Legal &Corporate Affairs Department', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0511', 'Legal Affairs', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0512', 'Corporate Affairs', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0513', 'Regulatory Affairs', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0600', 'HUMAN RESOURCE DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0610', 'Recruitment & Talent', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0620', 'Learning & Development', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0630', 'Compensation & Benefit', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0640', 'HR Strategy & Performance Management', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0700', 'OPERATIONS DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0710', 'Credit Operations', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0720', 'Centralized Operations', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0730', 'Administration', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0740', 'System and Methods', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0800', 'FINANCE AND ACCOUNTING DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0810', 'Finance', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0820', 'Treasury & ALM', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0830', 'Strategic Planning', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0900', 'INFORMATION TECHNOLOGY DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0910', 'IT Infrastructure', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0920', 'Digital Banking', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0930', 'Enterprise Solution and IT', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0940', 'Core Banking', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0950', 'Branchcless Banking Project', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '0960', 'Security Operation Center', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1000', 'DIGITAL &DATA DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1010', 'Data & Analytics', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1020', 'Digital Channels', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1030', 'Fintechs & Collaborations', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1040', 'Digital Innovation Projects', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1100', 'BUSINESS DIVISION', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1110', 'Distribution', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1120', 'Retail Financial Services', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1130', 'Alternative Channels', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1140', 'Business Financial Services', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1150', 'Business Excution', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('DEPARTMENT_CODE', '1160', 'Corporate Social Responibility ', 'N');

COMMIT;
