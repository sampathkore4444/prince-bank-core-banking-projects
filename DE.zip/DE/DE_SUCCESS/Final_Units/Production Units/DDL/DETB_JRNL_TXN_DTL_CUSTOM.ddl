create table DETB_JRNL_TXN_DTL_CUSTOM
(
  reference_no  VARCHAR2(16) not null,
  serial_no     NUMBER not null,
  budget_code   VARCHAR2(20),
  tax_code      VARCHAR2(20),
  supplier_code VARCHAR2(20),
  dept_code     VARCHAR2(20)
)
/
alter table DETB_JRNL_TXN_DTL_CUSTOM
  add primary key (REFERENCE_NO, SERIAL_NO)
/