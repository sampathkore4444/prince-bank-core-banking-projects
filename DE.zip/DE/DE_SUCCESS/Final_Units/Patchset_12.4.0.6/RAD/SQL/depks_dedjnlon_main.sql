CREATE OR REPLACE PACKAGE BODY depks_dedjnlon_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : depks_dedjnlon_main.sql
     **
     ** Module     : Data Entry
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Original_Action    VARCHAR2(100);
   g_Action_Code    VARCHAR2(100);
   g_Addl_Info       Cspks_Req_Global.Ty_Addl_Info;
   g_Ui_Name            VARCHAR2(50) := 'DEDJNLON';
   g_Req_Key                 VARCHAR2(32767);
   g_Txn_Udf_Key    VARCHAR2(32767);
   g_dedjnlon         depks_dedjnlon_Main.Ty_dedjnlon;
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Kernel    BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'depks_dedjnlon_Main ==>'||p_Msg;
         Debug.Pr_Debug('DE' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'DEDJNLON';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      depks_dedjnlon_Kernel.Pr_Skip_Handler (P_Stage);
      depks_dedjnlon_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Kernel IS
   BEGIN
      g_Skip_Kernel := TRUE;
   END Pr_Set_Skip_Kernel;
   PROCEDURE Pr_Set_Activate_Kernel IS
   BEGIN
      g_Skip_Kernel := FALSE;
   END Pr_Set_Activate_Kernel;
   FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type = Cspks_Req_Global.p_Kernel THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Kernel;
      END IF;
   END  Fn_Skip_Kernel;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION  Fn_Get_Original_Action RETURN VARCHAR2 IS
   BEGIN
      RETURN G_Original_Action;
   END  Fn_Get_Original_Action;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_dedjnlon       IN   OUT depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_6    NUMBER;
      l_Bnd_Cntr_6    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_DETBS_JRNL_TXN_MASTER' THEN
            p_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.BATCH_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.CURR_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.TEMPLATE_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_dedjnlon.v_detbs_jrnl_txn_master.VALUE_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_dedjnlon.v_detbs_jrnl_txn_master.VALUE_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_dedjnlon.v_detbs_jrnl_txn_master.BOOK_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_dedjnlon.v_detbs_jrnl_txn_master.BOOK_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_dedjnlon.v_detbs_jrnl_txn_master.BRANCH_CODE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.CCY := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.TOTAL_DR := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.TOTAL_CR := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.MAKER_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_dedjnlon.v_detbs_jrnl_txn_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_dedjnlon.v_detbs_jrnl_txn_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_dedjnlon.v_detbs_jrnl_txn_master.CHECKER_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_dedjnlon.v_detbs_jrnl_txn_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_dedjnlon.v_detbs_jrnl_txn_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_dedjnlon.v_detbs_jrnl_txn_master.AUTH_STATUS := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.CONTRACT_STATUS := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_master.FUND_ID := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_cstbs_ui_columns.NUM_FIELD24 := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_cstbs_ui_columns.NUM_FIELD25 := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_cstbs_ui_columns.CHAR_FIELD1 := Cspks_Req_Global.Fn_GetVal;
         ELSIF  l_Node = 'BLK_DETBS_JRNL_TXN_DETAIL' THEN
            l_Dsn_Rec_Cnt_2 :=  p_dedjnlon.v_detbs_jrnl_txn_detail.count +1 ;
            l_Dsn_Rec_Cnt_6 :=  p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.count +1 ;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).REFERENCE_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).SERIAL_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).USER_REF_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).DR_CR := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).BRANCH_CODE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).AC_OR_GL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).AC_GL_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).CCY := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).TXN_CODE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).INSTRUMENT_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).LCY_AMOUNT := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ADDL_TEXT := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.Desc_Fields('DETBS_JRNL_TXN_DETAIL')(l_Dsn_Rec_Cnt_2)('ACC_DESC') :=Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).RELATED_CUSTOMER := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).EXCH_RATE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).UI_AC_GL_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).BUDGET_CODE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).TAX_CODE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).SUPPLIER_CODE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).DEPT_CODE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).reference_no :=p_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
            p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).reference_no :=p_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
         ELSIF  l_Node = 'BLK_DETBS_BATCH_MASTER' THEN
            p_dedjnlon.v_detbs_batch_master.BATCH_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_batch_master.DESCRIPTION := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_batch_master.DR_CHK_TOTAL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_batch_master.CR_CHK_TOTAL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_batch_master.DR_ENT_TOTAL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_batch_master.CR_ENT_TOTAL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_detbs_batch_master.batch_no :=p_dedjnlon.v_detbs_jrnl_txn_master.batch_no;
            p_dedjnlon.v_detbs_batch_master.branch_code :=p_dedjnlon.v_detbs_jrnl_txn_master.branch_code;
         ELSIF  l_Node = 'BLK_DEVWS_BATCH_MASTER' THEN
            p_dedjnlon.v_devws_batch_master.BRANCH_CODE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.BATCH_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.DESCRIPTION := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.TYPE := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.LAST_OPER_ID := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.LAST_AUTH_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_dedjnlon.v_devws_batch_master.LAST_OPER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_dedjnlon.v_devws_batch_master.LAST_OPER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_dedjnlon.v_devws_batch_master.LAST_AUTH_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_dedjnlon.v_devws_batch_master.LAST_AUTH_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_dedjnlon.v_devws_batch_master.LOCKED := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.CURR_NO := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.DR_CHK_TOTAL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.CR_CHK_TOTAL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.DR_ENT_TOTAL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.CR_ENT_TOTAL := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.AUTH_STAT := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.UPLOADED := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.BALANCING := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.SYSTEM_BATCH := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.POSITION_REQD := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.DELETE_STAT := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.v_devws_batch_master.branch_code :=p_dedjnlon.v_detbs_jrnl_txn_master.branch_code;
            p_dedjnlon.v_devws_batch_master.batch_no :=p_dedjnlon.v_detbs_jrnl_txn_master.batch_no;
         ELSIF  l_Node = 'BLK_MISDETAILS' THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='MICTRMIS_'||p_Action_Code;
            END IF;
            p_dedjnlon.Ty_mictrmis := NULL;
            l_key_vals :='CONTRACT_REF_NO'||'>'||p_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO;
            Dbg('Calling Mipks_Mictrmis_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Mipks_Mictrmis_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'MICTRMIS',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_dedjnlon.Ty_mictrmis,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Mipks_Mictrmis_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node = Cspks_Req_Global.p_Txn_Udf_Blk  THEN
            l_Count :=  p_dedjnlon.Txn_Udf_Details.count ;
            l_Count :=  l_Count +1 ;
            p_dedjnlon.Txn_Udf_Details(l_Count).Field_Name := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.Txn_Udf_Details(l_Count).Field_Val := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.Txn_Udf_Details(l_Count).Data_Type := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.Txn_Udf_Details(l_Count).Val_Type := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.Txn_Udf_Details(l_Count).Field_Description := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.Txn_Udf_Details(l_Count).Mandatory := Cspks_Req_Global.Fn_GetVal;
            p_dedjnlon.Txn_Udf_Details(l_Count).Field_Val_Desc := Cspks_Req_Global.Fn_GetVal;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_dedjnlon.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_dedjnlon       IN   OUT depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_6    NUMBER;
      l_Bnd_Cntr_6    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_DETBS_JRNL_TXN_MASTER','Detbs-Jrnl-Txn-Master-Full','Detbs-Jrnl-Txn-Master-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'REFERENCE_NO' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO := l_Val;
               ELSIF l_Key = 'BATCH_NO' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.BATCH_NO := l_Val;
               ELSIF l_Key = 'CURR_NO' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.CURR_NO := l_Val;
               ELSIF l_Key IN( 'TEMPLATE_CODE','TEMPLATE_ID')  THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.TEMPLATE_ID := l_Val;
               ELSIF l_Key = 'VALUE_DATE' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_dedjnlon.v_detbs_jrnl_txn_master.VALUE_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_dedjnlon.v_detbs_jrnl_txn_master.VALUE_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'BOOK_DATE' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_dedjnlon.v_detbs_jrnl_txn_master.BOOK_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_dedjnlon.v_detbs_jrnl_txn_master.BOOK_DATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'BRANCH_CODE' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.BRANCH_CODE := l_Val;
               ELSIF l_Key = 'CCY' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.CCY := l_Val;
               ELSIF l_Key = 'TOTAL_DR' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.TOTAL_DR := l_Val;
               ELSIF l_Key = 'TOTAL_CR' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.TOTAL_CR := l_Val;
               ELSIF l_Key = 'MAKER' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.MAKER_ID := l_Val;
               ELSIF l_Key = 'MAKDTTIME' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_dedjnlon.v_detbs_jrnl_txn_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_dedjnlon.v_detbs_jrnl_txn_master.MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key IN( 'CHECHKERID','CHKR')  THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.CHECKER_ID := l_Val;
               ELSIF l_Key = 'CHKDTTIME' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_dedjnlon.v_detbs_jrnl_txn_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_dedjnlon.v_detbs_jrnl_txn_master.CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'AUTHSTAT' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.AUTH_STATUS := l_Val;
               ELSIF l_Key = 'TXNSTAT' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.CONTRACT_STATUS := l_Val;
               ELSIF l_Key = 'FUNDID' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_master.FUND_ID := l_Val;
               ELSIF l_Key IN( 'REC_NO','RECORD_NO')  THEN
                  p_dedjnlon.v_cstbs_ui_columns.NUM_FIELD24 := l_Val;
               ELSIF l_Key = 'TOTAL_NO' THEN
                  p_dedjnlon.v_cstbs_ui_columns.NUM_FIELD25 := l_Val;
               ELSIF l_Key = 'SUBSYSSTAT' THEN
                  p_dedjnlon.v_cstbs_ui_columns.CHAR_FIELD1 := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         ELSIF  l_Node IN ( 'BLK_DETBS_JRNL_TXN_DETAIL','Detbs-Jrnl-Txn-Detail') THEN
            l_Dsn_Rec_Cnt_2 :=  p_dedjnlon.v_detbs_jrnl_txn_detail.count +1 ;
            l_Dsn_Rec_Cnt_6 :=  p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.count +1 ;
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'REFERENCE_NO' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).REFERENCE_NO := l_Val;
               ELSIF l_Key = 'SERIAL_NO' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).SERIAL_NO := l_Val;
               ELSIF l_Key = 'USER_REF_NO' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).USER_REF_NO := l_Val;
               ELSIF l_Key = 'DR_CR' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).DR_CR := l_Val;
               ELSIF l_Key = 'BRANCH_CODE' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).BRANCH_CODE := l_Val;
               ELSIF l_Key IN( 'ACCORGL','AC_OR_GL')  THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).AC_OR_GL := l_Val;
               ELSIF l_Key = 'AC_GL_NO' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).AC_GL_NO := l_Val;
               ELSIF l_Key = 'CCY' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).CCY := l_Val;
               ELSIF l_Key = 'AMOUNT' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).AMOUNT := l_Val;
               ELSIF l_Key = 'TXN_CODE' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).TXN_CODE := l_Val;
               ELSIF l_Key = 'INSTRUMENT_NO' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).INSTRUMENT_NO := l_Val;
               ELSIF l_Key = 'LCY_AMOUNT' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).LCY_AMOUNT := l_Val;
               ELSIF l_Key = 'ADDL_TEXT' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ADDL_TEXT := l_Val;
               ELSIF l_Key IN( 'ACDESC','ACC_DESC')  THEN
                  p_dedjnlon.Desc_Fields('DETBS_JRNL_TXN_DETAIL')(l_Dsn_Rec_Cnt_2)('ACC_DESC') := l_Val;
               ELSIF l_Key IN( 'CUSTOMER','RELATED_CUSTOMER')  THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).RELATED_CUSTOMER := l_Val;
               ELSIF l_Key = 'EXCH_RATE' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).EXCH_RATE := l_Val;
               ELSIF l_Key IN( 'ACCOUNT','UI_AC_GL_NO')  THEN
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).UI_AC_GL_NO := l_Val;
               ELSIF l_Key = 'BUDGET_CODE' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).BUDGET_CODE := l_Val;
               ELSIF l_Key = 'TAX_CODE' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).TAX_CODE := l_Val;
               ELSIF l_Key = 'SUPPLIER_CODE' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).SUPPLIER_CODE := l_Val;
               ELSIF l_Key = 'DEPT_CODE' THEN
                  p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).DEPT_CODE := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).reference_no :=p_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
            p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).reference_no :=p_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
         ELSIF  l_Node IN ( 'BLK_DETBS_BATCH_MASTER','Detbs-Batch-Master') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'BATCH_NO' THEN
                  p_dedjnlon.v_detbs_batch_master.BATCH_NO := l_Val;
               ELSIF l_Key = 'DESCRIPTION' THEN
                  p_dedjnlon.v_detbs_batch_master.DESCRIPTION := l_Val;
               ELSIF l_Key IN( 'DEBIT','DR_CHK_TOTAL')  THEN
                  p_dedjnlon.v_detbs_batch_master.DR_CHK_TOTAL := l_Val;
               ELSIF l_Key IN( 'CREDIT','CR_CHK_TOTAL')  THEN
                  p_dedjnlon.v_detbs_batch_master.CR_CHK_TOTAL := l_Val;
               ELSIF l_Key = 'DR_ENT_TOTAL' THEN
                  p_dedjnlon.v_detbs_batch_master.DR_ENT_TOTAL := l_Val;
               ELSIF l_Key = 'CR_ENT_TOTAL' THEN
                  p_dedjnlon.v_detbs_batch_master.CR_ENT_TOTAL := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_dedjnlon.v_detbs_batch_master.batch_no :=p_dedjnlon.v_detbs_jrnl_txn_master.batch_no;
            p_dedjnlon.v_detbs_batch_master.branch_code :=p_dedjnlon.v_detbs_jrnl_txn_master.branch_code;
         ELSIF  l_Node IN ( 'BLK_DEVWS_BATCH_MASTER','Devws-Batch-Master') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'BRANCH_CODE' THEN
                  p_dedjnlon.v_devws_batch_master.BRANCH_CODE := l_Val;
               ELSIF l_Key IN( 'BATCH_NUMBER','BATCH_NO')  THEN
                  p_dedjnlon.v_devws_batch_master.BATCH_NO := l_Val;
               ELSIF l_Key = 'DESCRIPTION' THEN
                  p_dedjnlon.v_devws_batch_master.DESCRIPTION := l_Val;
               ELSIF l_Key = 'TYPE' THEN
                  p_dedjnlon.v_devws_batch_master.TYPE := l_Val;
               ELSIF l_Key IN( 'LAST_OPERATED_BY','LAST_OPER_ID')  THEN
                  p_dedjnlon.v_devws_batch_master.LAST_OPER_ID := l_Val;
               ELSIF l_Key IN( 'LAST_AUTHORISED_BY','LAST_AUTH_ID')  THEN
                  p_dedjnlon.v_devws_batch_master.LAST_AUTH_ID := l_Val;
               ELSIF l_Key IN( 'MAKERDT','LAST_OPER_DT_STAMP')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_dedjnlon.v_devws_batch_master.LAST_OPER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_dedjnlon.v_devws_batch_master.LAST_OPER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key IN( 'CHECKERDT','LAST_AUTH_DT_STAMP')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_dedjnlon.v_devws_batch_master.LAST_AUTH_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_dedjnlon.v_devws_batch_master.LAST_AUTH_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'LOCKED' THEN
                  p_dedjnlon.v_devws_batch_master.LOCKED := l_Val;
               ELSIF l_Key = 'CURR_NO' THEN
                  p_dedjnlon.v_devws_batch_master.CURR_NO := l_Val;
               ELSIF l_Key IN( 'DEBIT','DR_CHK_TOTAL')  THEN
                  p_dedjnlon.v_devws_batch_master.DR_CHK_TOTAL := l_Val;
               ELSIF l_Key IN( 'CREDIT','CR_CHK_TOTAL')  THEN
                  p_dedjnlon.v_devws_batch_master.CR_CHK_TOTAL := l_Val;
               ELSIF l_Key IN( 'DEBIT','DR_ENT_TOTAL')  THEN
                  p_dedjnlon.v_devws_batch_master.DR_ENT_TOTAL := l_Val;
               ELSIF l_Key IN( 'CREDIT','CR_ENT_TOTAL')  THEN
                  p_dedjnlon.v_devws_batch_master.CR_ENT_TOTAL := l_Val;
               ELSIF l_Key = 'AUTH_STAT' THEN
                  p_dedjnlon.v_devws_batch_master.AUTH_STAT := l_Val;
               ELSIF l_Key = 'UPLOADED' THEN
                  p_dedjnlon.v_devws_batch_master.UPLOADED := l_Val;
               ELSIF l_Key = 'BALANCING' THEN
                  p_dedjnlon.v_devws_batch_master.BALANCING := l_Val;
               ELSIF l_Key IN( 'SYS_1','SYSTEM_BATCH')  THEN
                  p_dedjnlon.v_devws_batch_master.SYSTEM_BATCH := l_Val;
               ELSIF l_Key IN( 'POSITION','POSITION_REQD')  THEN
                  p_dedjnlon.v_devws_batch_master.POSITION_REQD := l_Val;
               ELSIF l_Key IN( 'STATUS','DELETE_STAT')  THEN
                  p_dedjnlon.v_devws_batch_master.DELETE_STAT := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_dedjnlon.v_devws_batch_master.branch_code :=p_dedjnlon.v_detbs_jrnl_txn_master.branch_code;
            p_dedjnlon.v_devws_batch_master.batch_no :=p_dedjnlon.v_detbs_jrnl_txn_master.batch_no;
         ELSIF  l_Node IN ( 'BLK_MISDETAILS','Misdetails') THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='MICTRMIS_'||p_Action_Code;
            END IF;
            p_dedjnlon.Ty_mictrmis := NULL;
            l_key_vals :='CONTRACT_REF_NO'||'>'||p_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO;
            Dbg('Calling Mipks_Mictrmis_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Mipks_Mictrmis_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'MICTRMIS',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_dedjnlon.Ty_mictrmis,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Mipks_Mictrmis_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node = Cspks_Req_Global.p_Txn_Udf_Node  THEN
            l_Count :=  p_dedjnlon.Txn_Udf_Details.count ;
            l_Count :=  l_Count +1 ;
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               IF l_Key IN('FLDNAME','FIELD_NAME') THEN
                  p_dedjnlon.Txn_Udf_Details(l_Count).Field_Name := l_Val;
               ELSIF l_Key IN( 'FLDVAL','FIELD_VAL') THEN
                  p_dedjnlon.Txn_Udf_Details(l_Count).Field_Val := l_Val;
               ELSIF l_Key IN( 'DATATYPE','DATA_TYPE') THEN
                  p_dedjnlon.Txn_Udf_Details(l_Count).Data_Type := l_Val;
               ELSIF l_Key IN( 'VALTYPE','VAL_TYPE') THEN
                  p_dedjnlon.Txn_Udf_Details(l_Count).Val_TYpe := l_Val;
               ELSIF l_Key IN( 'FIELDDESC','FIELD_DESCRIPTION') THEN
                  p_dedjnlon.Txn_Udf_Details(l_Count).Field_Description := l_Val;
               ELSIF l_Key IN( 'MANDATORY','MANDATORY') THEN
                  p_dedjnlon.Txn_Udf_Details(l_Count).Mandatory := l_Val;
               ELSIF l_Key IN( 'FLDVALDESC','FIELD_VAL_DESC') THEN
                  p_dedjnlon.Txn_Udf_Details(l_Count).Field_Val_Desc := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_dedjnlon.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon          IN depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_6    NUMBER;
      l_Bnd_Cntr_6    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_1_Lvl_Counter := 0;
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_DETBS_JRNL_TXN_MASTER',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','REFERENCE_NO',p_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
      Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_dedjnlon.v_detbs_jrnl_txn_master.batch_no);
      Cspks_Req_Global.Pr_Write('V','CURR_NO',p_dedjnlon.v_detbs_jrnl_txn_master.curr_no);
      Cspks_Req_Global.Pr_Write('V','TEMPLATE_ID',p_dedjnlon.v_detbs_jrnl_txn_master.template_id);
      IF trunc(p_dedjnlon.v_detbs_jrnl_txn_master.value_date) <>
            p_dedjnlon.v_detbs_jrnl_txn_master.value_date THEN
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.value_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.value_date,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','VALUE_DATE',l_Date_Val);
      IF trunc(p_dedjnlon.v_detbs_jrnl_txn_master.book_date) <>
            p_dedjnlon.v_detbs_jrnl_txn_master.book_date THEN
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.book_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.book_date,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','BOOK_DATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','BRANCH_CODE',p_dedjnlon.v_detbs_jrnl_txn_master.branch_code);
      Cspks_Req_Global.Pr_Write('V','CCY',p_dedjnlon.v_detbs_jrnl_txn_master.ccy);
      Cspks_Req_Global.Pr_Write('V','TOTAL_DR',p_dedjnlon.v_detbs_jrnl_txn_master.total_dr);
      Cspks_Req_Global.Pr_Write('V','TOTAL_CR',p_dedjnlon.v_detbs_jrnl_txn_master.total_cr);
      Cspks_Req_Global.Pr_Write('V','MAKER',p_dedjnlon.v_detbs_jrnl_txn_master.maker_id);
      IF trunc(p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp) <>
            p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','MAKDTTIME',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','CHKR',p_dedjnlon.v_detbs_jrnl_txn_master.checker_id);
      IF trunc(p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp) <>
            p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','CHKDTTIME',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','AUTHSTAT',p_dedjnlon.v_detbs_jrnl_txn_master.auth_status);
      Cspks_Req_Global.Pr_Write('V','TXNSTAT',p_dedjnlon.v_detbs_jrnl_txn_master.contract_status);
      Cspks_Req_Global.Pr_Write('V','FUNDID',p_dedjnlon.v_detbs_jrnl_txn_master.fund_id);
      Cspks_Req_Global.Pr_Write('V','RECORD_NO',p_dedjnlon.v_cstbs_ui_columns.num_field24);
      Cspks_Req_Global.Pr_Write('V','TOTAL_NO',p_dedjnlon.v_cstbs_ui_columns.num_field25);
      Cspks_Req_Global.Pr_Write('V','SUBSYSSTAT',p_dedjnlon.v_cstbs_ui_columns.char_field1);

      --Dbg('Building Childs Of :BLK_DETBS_JRNL_TXN_MASTER..');
      l_Dsn_Rec_Cnt_2 := 0;
      IF p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT > 0 THEN
         FOR i_2 IN  1..p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT LOOP
            l_Dsn_Rec_Cnt_2 := i_2;
            l_Dsn_Rec_Cnt_6 := 0;
            IF p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT > 0 THEN
               FOR i_6 IN  1..p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT LOOP
                  IF NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(i_6).reference_no,'@') = NVL(p_dedjnlon.v_detbs_jrnl_txn_master.reference_no,'@') THEN
                     l_Dsn_Rec_Cnt_6 := i_6;
                     EXIT;
                  END IF;
               END LOOP;
            END IF;
            l_Master_Childs  :=  l_Master_Childs +1;
            l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','BLK_DETBS_JRNL_TXN_DETAIL',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','REFERENCE_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).reference_no);
            Cspks_Req_Global.Pr_Write('V','SERIAL_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).serial_no);
            Cspks_Req_Global.Pr_Write('V','USER_REF_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).user_ref_no);
            Cspks_Req_Global.Pr_Write('V','DR_CR',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).dr_cr);
            Cspks_Req_Global.Pr_Write('V','BRANCH_CODE',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).branch_code);
            Cspks_Req_Global.Pr_Write('V','AC_OR_GL',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ac_or_gl);
            Cspks_Req_Global.Pr_Write('V','AC_GL_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ac_gl_no);
            Cspks_Req_Global.Pr_Write('V','CCY',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ccy);
            Cspks_Req_Global.Pr_Write('V','AMOUNT',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).amount);
            Cspks_Req_Global.Pr_Write('V','TXN_CODE',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).txn_code);
            Cspks_Req_Global.Pr_Write('V','INSTRUMENT_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).instrument_no);
            Cspks_Req_Global.Pr_Write('V','LCY_AMOUNT',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).lcy_amount);
            Cspks_Req_Global.Pr_Write('V','ADDL_TEXT',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).addl_text);
            l_Desc_Vc := NULL;
            BEGIN
               l_Desc_Vc := p_dedjnlon.Desc_Fields('DETBS_JRNL_TXN_DETAIL')(l_Dsn_Rec_Cnt_2)('ACC_DESC');
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Populating Description Field   :ACC_DESC');
            END;
            Cspks_Req_Global.Pr_Write('V','ACC_DESC',l_Desc_Vc);
            Cspks_Req_Global.Pr_Write('V','RELATED_CUSTOMER',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).related_customer);
            Cspks_Req_Global.Pr_Write('V','EXCH_RATE',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).exch_rate);
            Cspks_Req_Global.Pr_Write('V','UI_AC_GL_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ui_ac_gl_no);
            IF l_Dsn_rec_cnt_6 > 0 THEN
               Cspks_Req_Global.Pr_Write('V','BUDGET_CODE',p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).budget_code);
               Cspks_Req_Global.Pr_Write('V','TAX_CODE',p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).tax_code);
               Cspks_Req_Global.Pr_Write('V','SUPPLIER_CODE',p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).supplier_code);
               Cspks_Req_Global.Pr_Write('V','DEPT_CODE',p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).dept_code);
            ELSE
               Cspks_Req_Global.Pr_Write('V','BUDGET_CODE',NULL);
               Cspks_Req_Global.Pr_Write('V','TAX_CODE',NULL);
               Cspks_Req_Global.Pr_Write('V','SUPPLIER_CODE',NULL);
               Cspks_Req_Global.Pr_Write('V','DEPT_CODE',NULL);
            END IF;
         END LOOP;
      END IF;
      l_Master_Childs  :=  l_Master_Childs +1;
      l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_DETBS_BATCH_MASTER',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_dedjnlon.v_detbs_batch_master.batch_no);
      Cspks_Req_Global.Pr_Write('V','DESCRIPTION',p_dedjnlon.v_detbs_batch_master.description);
      Cspks_Req_Global.Pr_Write('V','DR_CHK_TOTAL',p_dedjnlon.v_detbs_batch_master.dr_chk_total);
      Cspks_Req_Global.Pr_Write('V','CR_CHK_TOTAL',p_dedjnlon.v_detbs_batch_master.cr_chk_total);
      Cspks_Req_Global.Pr_Write('V','DR_ENT_TOTAL',p_dedjnlon.v_detbs_batch_master.dr_ent_total);
      Cspks_Req_Global.Pr_Write('V','CR_ENT_TOTAL',p_dedjnlon.v_detbs_batch_master.cr_ent_total);
      l_Master_Childs  :=  l_Master_Childs +1;
      l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_DEVWS_BATCH_MASTER',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','BRANCH_CODE',p_dedjnlon.v_devws_batch_master.branch_code);
      Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_dedjnlon.v_devws_batch_master.batch_no);
      Cspks_Req_Global.Pr_Write('V','DESCRIPTION',p_dedjnlon.v_devws_batch_master.description);
      Cspks_Req_Global.Pr_Write('V','TYPE',p_dedjnlon.v_devws_batch_master.type);
      Cspks_Req_Global.Pr_Write('V','LAST_OPER_ID',p_dedjnlon.v_devws_batch_master.last_oper_id);
      Cspks_Req_Global.Pr_Write('V','LAST_AUTH_ID',p_dedjnlon.v_devws_batch_master.last_auth_id);
      IF trunc(p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp) <>
            p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','LAST_OPER_DT_STAMP',l_Date_Val);
      IF trunc(p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp) <>
            p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp THEN
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','LAST_AUTH_DT_STAMP',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','LOCKED',p_dedjnlon.v_devws_batch_master.locked);
      Cspks_Req_Global.Pr_Write('V','CURR_NO',p_dedjnlon.v_devws_batch_master.curr_no);
      Cspks_Req_Global.Pr_Write('V','DR_CHK_TOTAL',p_dedjnlon.v_devws_batch_master.dr_chk_total);
      Cspks_Req_Global.Pr_Write('V','CR_CHK_TOTAL',p_dedjnlon.v_devws_batch_master.cr_chk_total);
      Cspks_Req_Global.Pr_Write('V','DR_ENT_TOTAL',p_dedjnlon.v_devws_batch_master.dr_ent_total);
      Cspks_Req_Global.Pr_Write('V','CR_ENT_TOTAL',p_dedjnlon.v_devws_batch_master.cr_ent_total);
      Cspks_Req_Global.Pr_Write('V','AUTH_STAT',p_dedjnlon.v_devws_batch_master.auth_stat);
      Cspks_Req_Global.Pr_Write('V','UPLOADED',p_dedjnlon.v_devws_batch_master.uploaded);
      Cspks_Req_Global.Pr_Write('V','BALANCING',p_dedjnlon.v_devws_batch_master.balancing);
      Cspks_Req_Global.Pr_Write('V','SYSTEM_BATCH',p_dedjnlon.v_devws_batch_master.system_batch);
      Cspks_Req_Global.Pr_Write('V','POSITION_REQD',p_dedjnlon.v_devws_batch_master.position_reqd);
      Cspks_Req_Global.Pr_Write('V','DELETE_STAT',p_dedjnlon.v_devws_batch_master.delete_stat);
      l_Level_Format      := l_0_Lvl_Counter;
      l_Cntr_Before := l_Master_Childs;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='MICTRMIS_'||p_Action_Code;
      END IF;
      IF NOT Mipks_Mictrmis_Main.Fn_Build_Ts_List(p_source,
         l_Source_Operation,
         'MICTRMIS',
         p_Action_Code,
         p_Function_Id,
         p_dedjnlon.ty_mictrmis,
         l_Level_Format,
         l_1_Lvl_Counter,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         RETURN FALSE;
      END IF;
      l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

      l_Parent_Format   := '1';
      IF p_dedjnlon.Txn_Udf_Details.COUNT > 0 THEN
         FOR i IN p_dedjnlon.Txn_Udf_Details.FIRST .. p_dedjnlon.Txn_Udf_Details.LAST LOOP
            l_Master_Childs := l_Master_Childs +1;
            l_Level_Format      := l_Parent_Format||'.' ||l_Master_Childs;
            Cspks_Req_Global.pr_Write('P',Cspks_Req_Global.P_Txn_Udf_Blk,l_level_Format);
            Cspks_Req_Global.pr_Write('V','FLDNAME',p_dedjnlon.Txn_Udf_Details(i).Field_Name);
            Cspks_Req_Global.pr_Write('V','FLDVAL',p_dedjnlon.Txn_Udf_Details(i).Field_Val);
            Cspks_Req_Global.pr_Write('V','DATATYP',p_dedjnlon.Txn_Udf_Details(i).Data_Type);
            Cspks_Req_Global.pr_Write('V','VALTYP',p_dedjnlon.Txn_Udf_Details(i).Val_Type);
            Cspks_Req_Global.pr_Write('V','FIELDDESC',p_dedjnlon.Txn_Udf_Details(i).Field_Description);
            Cspks_Req_Global.pr_Write('V','MANDATORY',p_dedjnlon.Txn_Udf_Details(i).Mandatory);
            Cspks_Req_Global.pr_Write('V','FLDVALDESC',p_dedjnlon.Txn_Udf_Details(i).Field_Val_Desc);
         END LOOP;
      END IF;

      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_dedjnlon          IN depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_6    NUMBER;
      l_Bnd_Cntr_6    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF ( (  p_dedjnlon.v_detbs_jrnl_txn_master.reference_no IS NOT NULL 
          ) OR(  p_dedjnlon.v_cstbs_ui_columns.char_field1 IS NOT NULL 
          ) OR(  p_dedjnlon.v_detbs_jrnl_txn_master.reference_no IS NOT NULL 
          ) OR(  p_dedjnlon.v_cstbs_ui_columns.char_field1 IS NOT NULL 
          ) )
          THEN
            l_1_Lvl_Counter := 0;
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Detbs-Jrnl-Txn-Master-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','REFERENCE_NO',p_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
            Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_dedjnlon.v_detbs_jrnl_txn_master.batch_no);
            Cspks_Req_Global.Pr_Write('V','CURR_NO',p_dedjnlon.v_detbs_jrnl_txn_master.curr_no);
            Cspks_Req_Global.Pr_Write('V','TEMPLATE_CODE',p_dedjnlon.v_detbs_jrnl_txn_master.template_id);
            IF trunc(p_dedjnlon.v_detbs_jrnl_txn_master.value_date) <>
                  p_dedjnlon.v_detbs_jrnl_txn_master.value_date THEN
               l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.value_date,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.value_date,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','VALUE_DATE',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','BRANCH_CODE',p_dedjnlon.v_detbs_jrnl_txn_master.branch_code);
            Cspks_Req_Global.Pr_Write('V','CCY',p_dedjnlon.v_detbs_jrnl_txn_master.ccy);
            Cspks_Req_Global.Pr_Write('V','TOTAL_DR',p_dedjnlon.v_detbs_jrnl_txn_master.total_dr);
            Cspks_Req_Global.Pr_Write('V','TOTAL_CR',p_dedjnlon.v_detbs_jrnl_txn_master.total_cr);
            Cspks_Req_Global.Pr_Write('V','MAKER',p_dedjnlon.v_detbs_jrnl_txn_master.maker_id);
            IF trunc(p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp) <>
                  p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','MAKDTTIME',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','CHECHKERID',p_dedjnlon.v_detbs_jrnl_txn_master.checker_id);
            IF trunc(p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp) <>
                  p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','CHKDTTIME',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','AUTHSTAT',p_dedjnlon.v_detbs_jrnl_txn_master.auth_status);
            Cspks_Req_Global.Pr_Write('V','TXNSTAT',p_dedjnlon.v_detbs_jrnl_txn_master.contract_status);
            Cspks_Req_Global.Pr_Write('V','FUNDID',p_dedjnlon.v_detbs_jrnl_txn_master.fund_id);
            Cspks_Req_Global.Pr_Write('V','REC_NO',p_dedjnlon.v_cstbs_ui_columns.num_field24);
            Cspks_Req_Global.Pr_Write('V','TOTAL_NO',p_dedjnlon.v_cstbs_ui_columns.num_field25);

            --Dbg('Building Childs Of :BLK_DETBS_JRNL_TXN_MASTER..');
            l_Dsn_Rec_Cnt_2 := 0;
            IF p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT > 0 THEN
               FOR i_2 IN  1..p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT LOOP
                  l_Dsn_Rec_Cnt_2 := i_2;
                  l_Dsn_Rec_Cnt_6 := 0;
                  IF p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT > 0 THEN
                     FOR i_6 IN  1..p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT LOOP
                        IF NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(i_6).reference_no,'@') = NVL(p_dedjnlon.v_detbs_jrnl_txn_master.reference_no,'@') THEN
                           l_Dsn_Rec_Cnt_6 := i_6;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  l_Master_Childs  :=  l_Master_Childs +1;
                  l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
                  l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
                  Cspks_Req_Global.Pr_Write('P','Detbs-Jrnl-Txn-Detail',l_Level_Format);
                  Cspks_Req_Global.Pr_Write('V','SERIAL_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).serial_no);
                  Cspks_Req_Global.Pr_Write('V','USER_REF_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).user_ref_no);
                  Cspks_Req_Global.Pr_Write('V','DR_CR',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).dr_cr);
                  Cspks_Req_Global.Pr_Write('V','BRANCH_CODE',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).branch_code);
                  Cspks_Req_Global.Pr_Write('V','ACCORGL',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ac_or_gl);
                  Cspks_Req_Global.Pr_Write('V','CCY',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ccy);
                  Cspks_Req_Global.Pr_Write('V','AMOUNT',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).amount);
                  Cspks_Req_Global.Pr_Write('V','TXN_CODE',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).txn_code);
                  Cspks_Req_Global.Pr_Write('V','INSTRUMENT_NO',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).instrument_no);
                  Cspks_Req_Global.Pr_Write('V','LCY_AMOUNT',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).lcy_amount);
                  Cspks_Req_Global.Pr_Write('V','ADDL_TEXT',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).addl_text);
                  l_Desc_Vc := NULL;
                  BEGIN
                     l_Desc_Vc := p_dedjnlon.Desc_Fields('DETBS_JRNL_TXN_DETAIL')(l_Dsn_Rec_Cnt_2)('ACC_DESC');
                  EXCEPTION
                     WHEN OTHERS THEN
                        Dbg(SQLERRM);
                        Dbg('Failed in Populating Description Field   :ACC_DESC');
                  END;
                  Cspks_Req_Global.Pr_Write('V','ACDESC',l_Desc_Vc);
                  Cspks_Req_Global.Pr_Write('V','CUSTOMER',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).related_customer);
                  Cspks_Req_Global.Pr_Write('V','EXCH_RATE',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).exch_rate);
                  Cspks_Req_Global.Pr_Write('V','ACCOUNT',p_dedjnlon.v_detbs_jrnl_txn_detail(l_Dsn_Rec_Cnt_2).ui_ac_gl_no);
                  IF l_Dsn_rec_cnt_6 > 0 THEN
                     Cspks_Req_Global.Pr_Write('V','BUDGET_CODE',p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).budget_code);
                     Cspks_Req_Global.Pr_Write('V','TAX_CODE',p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).tax_code);
                     Cspks_Req_Global.Pr_Write('V','SUPPLIER_CODE',p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).supplier_code);
                     Cspks_Req_Global.Pr_Write('V','DEPT_CODE',p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Dsn_Rec_Cnt_6).dept_code);
                  ELSE
                     Cspks_Req_Global.Pr_Write('V','BUDGET_CODE',NULL);
                     Cspks_Req_Global.Pr_Write('V','TAX_CODE',NULL);
                     Cspks_Req_Global.Pr_Write('V','SUPPLIER_CODE',NULL);
                     Cspks_Req_Global.Pr_Write('V','DEPT_CODE',NULL);
                  END IF;
               END LOOP;
            END IF;
            IF (  p_dedjnlon.v_detbs_batch_master.branch_code IS NOT NULL 
            AND  p_dedjnlon.v_detbs_batch_master.batch_no IS NOT NULL 
             )
             THEN
               l_Master_Childs  :=  l_Master_Childs +1;
               l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
               l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
               Cspks_Req_Global.Pr_Write('P','Detbs-Batch-Master',l_Level_Format);
               Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_dedjnlon.v_detbs_batch_master.batch_no);
               Cspks_Req_Global.Pr_Write('V','DESCRIPTION',p_dedjnlon.v_detbs_batch_master.description);
               Cspks_Req_Global.Pr_Write('V','DEBIT',p_dedjnlon.v_detbs_batch_master.dr_chk_total);
               Cspks_Req_Global.Pr_Write('V','CREDIT',p_dedjnlon.v_detbs_batch_master.cr_chk_total);
               Cspks_Req_Global.Pr_Write('V','DR_ENT_TOTAL',p_dedjnlon.v_detbs_batch_master.dr_ent_total);
               Cspks_Req_Global.Pr_Write('V','CR_ENT_TOTAL',p_dedjnlon.v_detbs_batch_master.cr_ent_total);
            END IF;
            IF (  p_dedjnlon.v_devws_batch_master.branch_code IS NOT NULL 
            AND  p_dedjnlon.v_devws_batch_master.batch_no IS NOT NULL 
             )
             THEN
               l_Master_Childs  :=  l_Master_Childs +1;
               l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
               l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
               Cspks_Req_Global.Pr_Write('P','Devws-Batch-Master',l_Level_Format);
               Cspks_Req_Global.Pr_Write('V','BATCH_NUMBER',p_dedjnlon.v_devws_batch_master.batch_no);
               Cspks_Req_Global.Pr_Write('V','DESCRIPTION',p_dedjnlon.v_devws_batch_master.description);
               Cspks_Req_Global.Pr_Write('V','LAST_OPERATED_BY',p_dedjnlon.v_devws_batch_master.last_oper_id);
               Cspks_Req_Global.Pr_Write('V','LAST_AUTHORISED_BY',p_dedjnlon.v_devws_batch_master.last_auth_id);
               IF trunc(p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp) <>
                     p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp THEN
                  l_Date_Val :=  TO_CHAR( p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
               ELSE
                  l_Date_Val :=  TO_CHAR( p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
               END IF;
               Cspks_Req_Global.Pr_Write('V','MAKERDT',l_Date_Val);
               IF trunc(p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp) <>
                     p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp THEN
                  l_Date_Val :=  TO_CHAR( p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
               ELSE
                  l_Date_Val :=  TO_CHAR( p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
               END IF;
               Cspks_Req_Global.Pr_Write('V','CHECKERDT',l_Date_Val);
               Cspks_Req_Global.Pr_Write('V','DEBIT',p_dedjnlon.v_devws_batch_master.dr_chk_total);
               Cspks_Req_Global.Pr_Write('V','CREDIT',p_dedjnlon.v_devws_batch_master.cr_chk_total);
               Cspks_Req_Global.Pr_Write('V','BALANCING',p_dedjnlon.v_devws_batch_master.balancing);
            END IF;
            l_Level_Format      := l_0_Lvl_Counter;
            l_Cntr_Before := l_Master_Childs;
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='MICTRMIS_'||p_Action_Code;
            END IF;
            IF NOT Mipks_Mictrmis_Main.Fn_Build_Ts_List(p_source,
               l_Source_Operation,
               'MICTRMIS',
               p_Action_Code,
               p_Function_Id,
               p_dedjnlon.ty_mictrmis,
               l_Level_Format,
               l_1_Lvl_Counter,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List');
               RETURN FALSE;
            END IF;
            l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

         END IF;
         l_Parent_Format   := '1';
         IF p_dedjnlon.Txn_Udf_Details.COUNT > 0 THEN
            FOR i IN p_dedjnlon.Txn_Udf_Details.FIRST .. p_dedjnlon.Txn_Udf_Details.LAST LOOP
               l_Master_Childs := l_Master_Childs +1;
               l_Level_Format      := l_Parent_Format||'.' ||l_Master_Childs;
               Cspks_Req_Global.pr_Write('P',Cspks_Req_Global.p_Txn_Udf_Node,l_level_Format);
               Cspks_Req_Global.pr_Write('V','FLDNAME',p_dedjnlon.Txn_Udf_Details(i).Field_Name);
               Cspks_Req_Global.pr_Write('V','FLDVAL',p_dedjnlon.Txn_Udf_Details(i).Field_Val);
            END LOOP;
         END IF;

      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Detbs-Jrnl-Txn-Master-PK','1');
         l_Key_Cols := 'REFERENCE_NO~';
         l_Key_Vals := p_dedjnlon.v_detbs_jrnl_txn_master.reference_no||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_dedjnlon IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'DETBS_JRNL_TXN_MASTER.REFERENCE_NO';
      IF p_dedjnlon.v_detbs_jrnl_txn_master.reference_no IS Null THEN
         Dbg('Field reference_no is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'DETBS_JRNL_TXN_MASTER';

         l_Blk := 'DETBS_JRNL_TXN_DETAIL';
         l_Count := p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
         IF l_Count > 0 THEN
            FOR l_index IN 1 .. p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT LOOP
               l_Fld := 'DETBS_JRNL_TXN_DETAIL.SERIAL_NO';
               IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_Index).serial_no IS Null THEN
                  Dbg('Primary Key Column serial_no Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
            END LOOP;
         END IF;

         l_Blk := 'DEVWS_BATCH_MASTER';
         l_Rec_Sent  := FALSE;
         l_Fld := 'DEVWS_BATCH_MASTER.BRANCH_CODE';
         IF p_dedjnlon.v_devws_batch_master.branch_code IS Null THEN
            IF l_Rec_Sent  THEN
               Dbg('Primary key Column branch_code Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-002','@'||l_Fld||'~@'||l_Blk) ;
            END IF;
         ELSE
            l_Rec_Sent  := TRUE;
         END IF;
         l_Fld := 'DEVWS_BATCH_MASTER.BATCH_NO';
         IF p_dedjnlon.v_devws_batch_master.batch_no IS Null THEN
            IF l_Rec_Sent  THEN
               Dbg('Primary key Column batch_no Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-002','@'||l_Fld||'~@'||l_Blk) ;
            END IF;
         ELSE
            l_Rec_Sent  := TRUE;
         END IF;

         l_Blk := 'DETBS_JRNL_TXN_DTL_CUSTOM';
         l_Count := p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
         IF l_Count > 0 THEN
            FOR l_index IN 1 .. p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT LOOP
               l_Fld := 'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO';
               IF p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).serial_no IS Null THEN
                  Dbg('Primary Key Column serial_no Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
            END LOOP;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      IF p_dedjnlon.v_detbs_jrnl_txn_master.CONTRACT_STATUS IS NOT NULL THEN
         IF p_dedjnlon.v_detbs_jrnl_txn_master.CONTRACT_STATUS NOT IN ('A','C') THEN
            dbg('Invalid Value For The Field  :CONTRACT_STATUS:'||p_dedjnlon.v_detbs_jrnl_txn_master.CONTRACT_STATUS);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_dedjnlon.v_detbs_jrnl_txn_master.CONTRACT_STATUS||'~@DETBS_JRNL_TXN_MASTER.CONTRACT_STATUS~@DETBS_JRNL_TXN_MASTER') ;
         END IF;
      END IF;
      IF p_dedjnlon.v_detbs_jrnl_txn_master.AUTH_STATUS IS NOT NULL THEN
         IF p_dedjnlon.v_detbs_jrnl_txn_master.AUTH_STATUS NOT IN ('U','A') THEN
            dbg('Invalid Value For The Field  :AUTH_STATUS:'||p_dedjnlon.v_detbs_jrnl_txn_master.AUTH_STATUS);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_dedjnlon.v_detbs_jrnl_txn_master.AUTH_STATUS||'~@DETBS_JRNL_TXN_MASTER.AUTH_STATUS~@DETBS_JRNL_TXN_MASTER') ;
         END IF;
      END IF;
      l_Count      := p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            l_Key := NULL;
            IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).DR_CR IS NOT NULL THEN
               IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).DR_CR NOT IN ('D','C') THEN
                  dbg('Invalid Value For The Field  :DR_CR:'||p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).DR_CR);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.SERIAL_NO')||'-'||
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).DR_CR||'~@DETBS_JRNL_TXN_DETAIL.DR_CR'||'~'||l_Key||'~@DETBS_JRNL_TXN_DETAIL') ;
               END IF;
            END IF;
            IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).INSTRUMENT_NO IS NOT NULL THEN
               l_Inv_Chr :=  Cspks_Req_Utils.Fn_Validate_Restr_Text(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).INSTRUMENT_NO);
               IF l_Inv_Chr is NOT NULL THEN
                  Dbg('Retricted Text :Invalid Value For The Field  :INSTRUMENT_NO:'||p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).INSTRUMENT_NO);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.SERIAL_NO')||'-'||
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no;
                  Pr_Log_Error(p_Source,'ST-VALS-016',l_Inv_Chr||'~'||p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).INSTRUMENT_NO||'~@DETBS_JRNL_TXN_DETAIL.INSTRUMENT_NO'||'~'||l_Key||'~@DETBS_JRNL_TXN_DETAIL') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Duplicate Records Check For :v_detbs_jrnl_txn_detail..');
      l_Count      := p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_count LOOP
            l_key := NULL;
            IF l_index < l_Count THEN
               FOR l_index1 IN l_index+1 .. l_Count LOOP
                  IF (NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).reference_no,'@')=  NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).reference_no,'@')) AND (NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no,-1)=  NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).serial_no,-1)) THEN
                     Dbg('Duplicare Record Found for :'||l_Key);
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.REFERENCE_NO')||'-'||
                     p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).reference_no||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.SERIAL_NO')||'-'||
                     p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no;
                     Pr_Log_Error(p_Source,'ST-VALS-009','@DETBS_JRNL_TXN_DETAIL~'||l_Key);
                  END IF;
               END LOOP;
            END IF;
         END LOOP;
      END IF;
      IF p_dedjnlon.v_devws_batch_master.BALANCING IS NOT NULL THEN
         IF p_dedjnlon.v_devws_batch_master.BALANCING NOT IN ('Y','N') THEN
            dbg('Invalid Value For The Field  :BALANCING:'||p_dedjnlon.v_devws_batch_master.BALANCING);
            Pr_Log_Error(p_Source,'ST-VALS-012',p_dedjnlon.v_devws_batch_master.BALANCING||'~@DEVWS_BATCH_MASTER.BALANCING~@DEVWS_BATCH_MASTER') ;
         END IF;
      END IF;
      Dbg('Duplicate Records Check For :v_detbs_jrnl_txn_dtl_custom..');
      l_Count      := p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_count LOOP
            l_key := NULL;
            IF l_index < l_Count THEN
               FOR l_index1 IN l_index+1 .. l_Count LOOP
                  IF (NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).reference_no,'@')=  NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).reference_no,'@')) AND (NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no,-1)=  NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).serial_no,-1)) THEN
                     Dbg('Duplicare Record Found for :'||l_Key);
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.REFERENCE_NO')||'-'||
                     p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).reference_no||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                     p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no;
                     Pr_Log_Error(p_Source,'ST-VALS-009','@DETBS_JRNL_TXN_DTL_CUSTOM~'||l_Key);
                  END IF;
               END LOOP;
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_dedjnlon     IN  OUT depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      l_Count      := p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
      IF l_count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            IF p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).DR_CR IS NULL THEN
               p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).DR_CR := 'D';
            END IF;
         END LOOP;
      END IF;
      IF p_Wrk_dedjnlon.v_devws_batch_master.BALANCING IS NULL THEN
         p_Wrk_dedjnlon.v_devws_batch_master.BALANCING := 'Y';
      END IF;
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Merge_Amendables        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Wrk_Count      NUMBER := 0 ;
      l_Deleted_Recs   NUMBER := 0;
      l_Modified_Flds  VARCHAR2(32000):= NULL;
      l_Key            VARCHAR2(5000):= NULL;
      l_Mod_Fld        VARCHAR2(100):= NULL;
      i                NUMBER := 1;
      l_Rec_Found      BOOLEAN := FALSE;
      l_Rec_Modified   BOOLEAN := FALSE;
      l_Rec_Sent       BOOLEAN := FALSE;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Pk_Or_Full     VARCHAR2(5) :='FULL';
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Mod_No         NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Amendable_Nodes Cspks_Req_Global.Ty_Amend_Nodes;
      l_Amendable_Fields Cspks_Req_Global.Ty_Amend_Fields;
      N_v_detbs_jrnl_txn_detail       depks_dedjnlon_Main.Ty_Tb_v_detbs_jrnl_txn_detail;
      N_v_detbs_jrnl_txn_dtl_custom       depks_dedjnlon_Main.Ty_Tb_etbs_jrnl_txn_dtl_custom;

      FUNCTION Fn_Amendable(p_Item IN VARCHAR2) RETURN BOOLEAN IS
      BEGIN
         IF l_Amendable_Fields.EXISTS(p_Item) THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END Fn_Amendable;
   BEGIN

      Dbg('In Fn_Sys_Merge_Amendables');

      Dbg('Calling Cspks_Req_Utils.Fn_Get_Amendable_Details..');
      IF NOT Cspks_Req_Utils.Fn_Get_Amendable_Details(p_source ,
         p_Source_Operation,
         l_Amendable_Nodes,
         l_Amendable_Fields,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      l_Blk := 'DETBS_JRNL_TXN_MASTER';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_fld := 'DETBS_JRNL_TXN_MASTER.BATCH_NO';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.BATCH_NO') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.batch_no := p_dedjnlon.v_detbs_jrnl_txn_master.batch_no;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.batch_no IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.batch_no,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.batch_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.CURR_NO';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.CURR_NO') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.curr_no := p_dedjnlon.v_detbs_jrnl_txn_master.curr_no;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.curr_no IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.curr_no,-1) <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.curr_no,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.TEMPLATE_ID';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.TEMPLATE_ID') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.template_id := p_dedjnlon.v_detbs_jrnl_txn_master.template_id;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.template_id IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.template_id,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.template_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.VALUE_DATE';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.VALUE_DATE') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.value_date := p_dedjnlon.v_detbs_jrnl_txn_master.value_date;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.value_date IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.value_date,global.min_date) <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.value_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.BOOK_DATE';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.BOOK_DATE') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.book_date := p_dedjnlon.v_detbs_jrnl_txn_master.book_date;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.book_date IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.book_date,global.min_date) <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.book_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.BRANCH_CODE';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.BRANCH_CODE') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.branch_code := p_dedjnlon.v_detbs_jrnl_txn_master.branch_code;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.branch_code IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.branch_code,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.branch_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.CCY';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.CCY') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.ccy := p_dedjnlon.v_detbs_jrnl_txn_master.ccy;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.ccy IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.ccy,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.TOTAL_DR';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.TOTAL_DR') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.total_dr := p_dedjnlon.v_detbs_jrnl_txn_master.total_dr;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.total_dr IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.total_dr,-1) <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.total_dr,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.TOTAL_CR';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.TOTAL_CR') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.total_cr := p_dedjnlon.v_detbs_jrnl_txn_master.total_cr;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.total_cr IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.total_cr,-1) <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.total_cr,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.MAKER_ID';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.MAKER_ID') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.maker_id := p_dedjnlon.v_detbs_jrnl_txn_master.maker_id;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.maker_id IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.maker_id,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.maker_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.MAKER_DT_STAMP';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.MAKER_DT_STAMP') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp := p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp,global.min_date) <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.maker_dt_stamp,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.CHECKER_ID';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.CHECKER_ID') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.checker_id := p_dedjnlon.v_detbs_jrnl_txn_master.checker_id;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.checker_id IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.checker_id,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.checker_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.CHECKER_DT_STAMP';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.CHECKER_DT_STAMP') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp := p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp,global.min_date) <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.checker_dt_stamp,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.CONTRACT_STATUS';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.CONTRACT_STATUS') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.contract_status := p_dedjnlon.v_detbs_jrnl_txn_master.contract_status;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.contract_status IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.contract_status,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.contract_status,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.AUTH_STATUS';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.AUTH_STATUS') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.auth_status := p_dedjnlon.v_detbs_jrnl_txn_master.auth_status;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.auth_status IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.auth_status,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.auth_status,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'DETBS_JRNL_TXN_MASTER.FUND_ID';
      IF Fn_Amendable('DETBS_JRNL_TXN_MASTER.FUND_ID') THEN
         p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.fund_id := p_dedjnlon.v_detbs_jrnl_txn_master.fund_id;
      ELSE
         IF p_dedjnlon.v_detbs_jrnl_txn_master.fund_id IS NOT NULL THEN
            IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.fund_id,'@') <>
               NVL(p_dedjnlon.v_detbs_jrnl_txn_master.fund_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;

      l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
      IF  l_Rec_Modified THEN
         IF l_Modified_Flds IS NOT NULL THEN
            i :=  1;
            l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
            WHILE l_Mod_Fld <> 'EOPL' LOOP
               Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
               i := i +1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
            END LOOP;
         END IF;
      END IF;
      l_Blk := 'DETBS_JRNL_TXN_DETAIL';
      l_Count      := p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
      l_Wrk_Count  := p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
      IF l_Count > 0 THEN
         FOR l_index IN 1..l_Count  LOOP
            l_Rec_Found := FALSE;
            l_Rec_Modified := FALSE;
            l_Modified_Flds := NULL;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no,-1)=  NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).serial_no,-1)) THEN
                     Dbg('Record Found..');
                     l_Rec_Found := TRUE;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.USER_REF_NO';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.USER_REF_NO') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).user_ref_no := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).user_ref_no;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).user_ref_no IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).user_ref_no,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).user_ref_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.DR_CR';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.DR_CR') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).dr_cr := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).dr_cr;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).dr_cr IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).dr_cr,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).dr_cr,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.BRANCH_CODE';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.BRANCH_CODE') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).branch_code := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).branch_code;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).branch_code IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).branch_code,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).branch_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.AC_OR_GL';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.AC_OR_GL') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).ac_or_gl := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ac_or_gl;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ac_or_gl IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).ac_or_gl,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ac_or_gl,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.AC_GL_NO';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.AC_GL_NO') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).ac_gl_no := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ac_gl_no;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ac_gl_no IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).ac_gl_no,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ac_gl_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.AMOUNT';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.AMOUNT') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).amount := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).amount;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).amount IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).amount,-1) <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).amount,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.CCY';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.CCY') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).ccy := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ccy;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).ccy,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.TXN_CODE';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.TXN_CODE') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).txn_code := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).txn_code;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).txn_code IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).txn_code,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).txn_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.INSTRUMENT_NO';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.INSTRUMENT_NO') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).instrument_no := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).instrument_no;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).instrument_no IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).instrument_no,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).instrument_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.LCY_AMOUNT';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.LCY_AMOUNT') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).lcy_amount := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).lcy_amount;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).lcy_amount IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).lcy_amount,-1) <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).lcy_amount,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.ADDL_TEXT';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.ADDL_TEXT') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).addl_text := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).addl_text;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).addl_text IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).addl_text,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).addl_text,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.RELATED_CUSTOMER';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.RELATED_CUSTOMER') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).related_customer := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).related_customer;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).related_customer IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).related_customer,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).related_customer,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.EXCH_RATE';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.EXCH_RATE') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).exch_rate := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).exch_rate;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).exch_rate IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).exch_rate,-1) <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).exch_rate,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DETAIL.UI_AC_GL_NO';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DETAIL.UI_AC_GL_NO') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).ui_ac_gl_no := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ui_ac_gl_no;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ui_ac_gl_no IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).ui_ac_gl_no,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ui_ac_gl_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;

                     l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
                     IF  l_Rec_modified THEN
                        IF l_Modified_Flds IS NOT NULL THEN
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.SERIAL_NO')||'-'||
                           p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no;
                           i :=  1;
                           l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           WHILE l_mod_fld <> 'EOPL' LOOP
                              Pr_Log_Error(p_Source,'ST-AMND-003','@'||l_Mod_Fld||'~@'||l_Blk||'~'||l_Key );
                              i := i +1;
                              l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           END LOOP;
                        END IF;
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT +1 ) :=  p_dedjnlon.v_detbs_jrnl_txn_detail(l_index);
               IF l_Amendable_Nodes.EXISTS('DETBS_JRNL_TXN_DETAIL') THEN
                  IF l_Amendable_Nodes('DETBS_JRNL_TXN_DETAIL').New_Allowed = 'N' THEN
                     Dbg('New Record Cannot Be Added..');
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.SERIAL_NO')||'-'||
                     p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no;
                     Pr_Log_Error(p_source,'ST-AMND-004',l_key||'~@'||l_blk);
                  END IF;
               ELSE
                  Dbg('New Record Cannot Be Added..');
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.SERIAL_NO')||'-'||
                  p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no;
                  Pr_Log_Error(p_Source,'ST-AMND-004',l_key||'~@'||l_blk);
               END IF;
            END IF;
         END LOOP;
      END IF;

      IF l_Amendable_Nodes.EXISTS('DETBS_JRNL_TXN_DETAIL') THEN
         IF l_Amendable_Nodes('DETBS_JRNL_TXN_DETAIL').All_Records = 'Y' THEN
            Dbg('Logic For Deleting Some Records From Work Record  if Not sent..');
            l_Wrk_Count := p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
            l_Count     := p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_count  LOOP
                  l_Rec_Found := FALSE;
                  IF l_Count > 0 THEN
                     FOR l_index IN 1..l_Count  LOOP
                        IF (NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).serial_no,-1)=  NVL(p_dedjnlon.v_detbs_jrnl_txn_detail  (l_index).serial_no,-1)) THEN
                           Dbg('Record Found..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_Rec_Found THEN
                     Dbg('Adding  a Record...');
                     N_v_detbs_jrnl_txn_detail(N_v_detbs_jrnl_txn_detail.COUNT +1 ) :=  p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_Index1);
                  ELSE
                     l_Deleted_Recs := l_Deleted_Recs +1;
                     IF l_Amendable_Nodes.EXISTS('DETBS_JRNL_TXN_DETAIL') THEN
                        IF l_Amendable_Nodes('DETBS_JRNL_TXN_DETAIL').Delete_Allowed = 'N' THEN
                           Dbg('Record Cannot Be Deleted..');
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.SERIAL_NO')||'-'||
                           p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).serial_no;
                           Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                        END IF;
                     ELSE
                        Dbg('Record Cannot Be Deleted..');
                        l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DETAIL.SERIAL_NO')||'-'||
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index1).serial_no;
                        Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail:= N_v_detbs_jrnl_txn_detail;
         END IF;
      END IF;

      l_Blk := 'DEVWS_BATCH_MASTER';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_Rec_Sent := FALSE;
      IF p_dedjnlon.v_devws_batch_master.branch_code IS NOT NULL AND p_dedjnlon.v_devws_batch_master.batch_no IS NOT NULL THEN
         dbg('Record Has Been Sent..');
         p_Wrk_dedjnlon.v_devws_batch_master.branch_code := p_dedjnlon.v_devws_batch_master.branch_code;
         p_Wrk_dedjnlon.v_devws_batch_master.batch_no := p_dedjnlon.v_devws_batch_master.batch_no;
         l_Rec_Sent := TRUE;
      END IF;
      IF l_Rec_Sent THEN
         l_fld := 'DEVWS_BATCH_MASTER.DESCRIPTION';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.DESCRIPTION') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.description := p_dedjnlon.v_devws_batch_master.description;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.description IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.description,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.description,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.TYPE';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.TYPE') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.type := p_dedjnlon.v_devws_batch_master.type;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.type IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.type,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.type,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.LAST_OPER_ID';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.LAST_OPER_ID') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.last_oper_id := p_dedjnlon.v_devws_batch_master.last_oper_id;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.last_oper_id IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.last_oper_id,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.last_oper_id,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.LAST_AUTH_ID';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.LAST_AUTH_ID') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.last_auth_id := p_dedjnlon.v_devws_batch_master.last_auth_id;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.last_auth_id IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.last_auth_id,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.last_auth_id,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.LAST_OPER_DT_STAMP';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.LAST_OPER_DT_STAMP') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.last_oper_dt_stamp := p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.last_oper_dt_stamp,global.min_date) <>
                  NVL(p_dedjnlon.v_devws_batch_master.last_oper_dt_stamp,global.min_date)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.LAST_AUTH_DT_STAMP';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.LAST_AUTH_DT_STAMP') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.last_auth_dt_stamp := p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.last_auth_dt_stamp,global.min_date) <>
                  NVL(p_dedjnlon.v_devws_batch_master.last_auth_dt_stamp,global.min_date)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.LOCKED';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.LOCKED') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.locked := p_dedjnlon.v_devws_batch_master.locked;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.locked IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.locked,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.locked,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.CURR_NO';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.CURR_NO') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.curr_no := p_dedjnlon.v_devws_batch_master.curr_no;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.curr_no IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.curr_no,-1) <>
                  NVL(p_dedjnlon.v_devws_batch_master.curr_no,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.DR_CHK_TOTAL';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.DR_CHK_TOTAL') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.dr_chk_total := p_dedjnlon.v_devws_batch_master.dr_chk_total;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.dr_chk_total IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.dr_chk_total,-1) <>
                  NVL(p_dedjnlon.v_devws_batch_master.dr_chk_total,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.CR_CHK_TOTAL';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.CR_CHK_TOTAL') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.cr_chk_total := p_dedjnlon.v_devws_batch_master.cr_chk_total;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.cr_chk_total IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.cr_chk_total,-1) <>
                  NVL(p_dedjnlon.v_devws_batch_master.cr_chk_total,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.DR_ENT_TOTAL';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.DR_ENT_TOTAL') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.dr_ent_total := p_dedjnlon.v_devws_batch_master.dr_ent_total;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.dr_ent_total IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.dr_ent_total,-1) <>
                  NVL(p_dedjnlon.v_devws_batch_master.dr_ent_total,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.CR_ENT_TOTAL';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.CR_ENT_TOTAL') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.cr_ent_total := p_dedjnlon.v_devws_batch_master.cr_ent_total;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.cr_ent_total IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.cr_ent_total,-1) <>
                  NVL(p_dedjnlon.v_devws_batch_master.cr_ent_total,-1)  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.AUTH_STAT';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.AUTH_STAT') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.auth_stat := p_dedjnlon.v_devws_batch_master.auth_stat;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.auth_stat IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.auth_stat,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.auth_stat,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.UPLOADED';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.UPLOADED') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.uploaded := p_dedjnlon.v_devws_batch_master.uploaded;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.uploaded IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.uploaded,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.uploaded,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.BALANCING';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.BALANCING') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.balancing := p_dedjnlon.v_devws_batch_master.balancing;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.balancing IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.balancing,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.balancing,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.SYSTEM_BATCH';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.SYSTEM_BATCH') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.system_batch := p_dedjnlon.v_devws_batch_master.system_batch;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.system_batch IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.system_batch,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.system_batch,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.POSITION_REQD';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.POSITION_REQD') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.position_reqd := p_dedjnlon.v_devws_batch_master.position_reqd;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.position_reqd IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.position_reqd,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.position_reqd,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'DEVWS_BATCH_MASTER.DELETE_STAT';
         IF Fn_Amendable('DEVWS_BATCH_MASTER.DELETE_STAT') THEN
            p_Wrk_dedjnlon.v_devws_batch_master.delete_stat := p_dedjnlon.v_devws_batch_master.delete_stat;
         ELSE
            IF p_dedjnlon.v_devws_batch_master.delete_stat IS NOT NULL THEN
               IF NVL(p_Wrk_dedjnlon.v_devws_batch_master.delete_stat,'@') <>
                  NVL(p_dedjnlon.v_devws_batch_master.delete_stat,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;

         l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
         IF  l_Rec_Modified THEN
            IF l_Modified_Flds IS NOT NULL THEN
               i :=  1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
               WHILE l_Mod_Fld <> 'EOPL' LOOP
                  Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
                  i := i +1;
                  l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
               END LOOP;
            END IF;
         END IF;
      ELSE

         IF l_Amendable_Nodes.EXISTS('DEVWS_BATCH_MASTER') THEN
            IF l_Amendable_Nodes('DEVWS_BATCH_MASTER').All_Records = 'Y' THEN
               p_Wrk_dedjnlon.v_devws_batch_master :=NULL;
            END IF;
         END IF;
      END IF;
      l_Blk := 'DETBS_JRNL_TXN_DTL_CUSTOM';
      l_Count      := p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
      l_Wrk_Count  := p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
      IF l_Count > 0 THEN
         FOR l_index IN 1..l_Count  LOOP
            l_Rec_Found := FALSE;
            l_Rec_Modified := FALSE;
            l_Modified_Flds := NULL;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no,-1)=  NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).serial_no,-1)) THEN
                     Dbg('Record Found..');
                     l_Rec_Found := TRUE;
                     l_fld := 'DETBS_JRNL_TXN_DTL_CUSTOM.BUDGET_CODE';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DTL_CUSTOM.BUDGET_CODE') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).budget_code := p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).budget_code;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).budget_code IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).budget_code,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).budget_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DTL_CUSTOM.TAX_CODE';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DTL_CUSTOM.TAX_CODE') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).tax_code := p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).tax_code;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).tax_code IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).tax_code,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).tax_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DTL_CUSTOM.SUPPLIER_CODE';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DTL_CUSTOM.SUPPLIER_CODE') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).supplier_code := p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).supplier_code;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).supplier_code IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).supplier_code,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).supplier_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'DETBS_JRNL_TXN_DTL_CUSTOM.DEPT_CODE';
                     IF Fn_Amendable('DETBS_JRNL_TXN_DTL_CUSTOM.DEPT_CODE') THEN
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).dept_code := p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).dept_code;
                     ELSE
                        IF p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).dept_code IS NOT NULL THEN
                           IF NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).dept_code,'@') <>
                              NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).dept_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;

                     l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
                     IF  l_Rec_modified THEN
                        IF l_Modified_Flds IS NOT NULL THEN
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                           p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no;
                           i :=  1;
                           l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           WHILE l_mod_fld <> 'EOPL' LOOP
                              Pr_Log_Error(p_Source,'ST-AMND-003','@'||l_Mod_Fld||'~@'||l_Blk||'~'||l_Key );
                              i := i +1;
                              l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           END LOOP;
                        END IF;
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT +1 ) :=  p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index);
               IF l_Amendable_Nodes.EXISTS('DETBS_JRNL_TXN_DTL_CUSTOM') THEN
                  IF l_Amendable_Nodes('DETBS_JRNL_TXN_DTL_CUSTOM').New_Allowed = 'N' THEN
                     Dbg('New Record Cannot Be Added..');
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                     p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no;
                     Pr_Log_Error(p_source,'ST-AMND-004',l_key||'~@'||l_blk);
                  END IF;
               ELSE
                  Dbg('New Record Cannot Be Added..');
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                  p_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no;
                  Pr_Log_Error(p_Source,'ST-AMND-004',l_key||'~@'||l_blk);
               END IF;
            END IF;
         END LOOP;
      END IF;

      IF l_Amendable_Nodes.EXISTS('DETBS_JRNL_TXN_DTL_CUSTOM') THEN
         IF l_Amendable_Nodes('DETBS_JRNL_TXN_DTL_CUSTOM').All_Records = 'Y' THEN
            Dbg('Logic For Deleting Some Records From Work Record  if Not sent..');
            l_Wrk_Count := p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
            l_Count     := p_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_count  LOOP
                  l_Rec_Found := FALSE;
                  IF l_Count > 0 THEN
                     FOR l_index IN 1..l_Count  LOOP
                        IF (NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).serial_no,-1)=  NVL(p_dedjnlon.v_detbs_jrnl_txn_dtl_custom  (l_index).serial_no,-1)) THEN
                           Dbg('Record Found..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_Rec_Found THEN
                     Dbg('Adding  a Record...');
                     N_v_detbs_jrnl_txn_dtl_custom(N_v_detbs_jrnl_txn_dtl_custom.COUNT +1 ) :=  p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index1);
                  ELSE
                     l_Deleted_Recs := l_Deleted_Recs +1;
                     IF l_Amendable_Nodes.EXISTS('DETBS_JRNL_TXN_DTL_CUSTOM') THEN
                        IF l_Amendable_Nodes('DETBS_JRNL_TXN_DTL_CUSTOM').Delete_Allowed = 'N' THEN
                           Dbg('Record Cannot Be Deleted..');
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                           p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).serial_no;
                           Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                        END IF;
                     ELSE
                        Dbg('Record Cannot Be Deleted..');
                        l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                        p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1).serial_no;
                        Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom:= N_v_detbs_jrnl_txn_dtl_custom;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Merge_Amendables..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Merge_Amendables..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Merge_Amendables;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_dedjnlon IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER  := 0;
      l_Dsn_Rec_Cnt_3 NUMBER := 0;
      l_Bnd_Cntr_3    NUMBER  := 0;
      l_Dsn_Rec_Cnt_4 NUMBER := 0;
      l_Bnd_Cntr_4    NUMBER  := 0;
      l_Dsn_Rec_Cnt_5 NUMBER := 0;
      l_Bnd_Cntr_5    NUMBER  := 0;
      l_Dsn_Rec_Cnt_6 NUMBER := 0;
      l_Bnd_Cntr_6    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      l_Blk := 'DETBS_JRNL_TXN_MASTER';
      l_Fld := 'DETBS_JRNL_TXN_MASTER.FUND_ID';
      IF p_wrk_dedjnlon.v_detbs_jrnl_txn_master.FUND_ID IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT FUND_ID, FUND_DESCRIPTION, CONTRACT_REF_NO, FUND_REFERENCE_NO, MUDARABAH_FUND FROM AMTMS_FUND_MASTER, CSTBS_CONTRACT A WHERE FUND_REFERENCE_NO = CONTRACT_REF_NO AND PRODUCT = PRODUCT_CODE AND A.CONTRACT_STATUS = 'A' AND A.AUTH_STATUS = 'A' AND (TO_DATE(GLOBAL.APPLICATION_DATE, 'DD-MON-RRRR') BETWEEN FUND_START_DATE AND NVL(FUND_END_DATE, FUND_START_DATE + 20000)) AND A.LATEST_VERSION_NO = VERSION_NO AND FUND_ID IS NOT NULL AND (BRANCH_CODE IN (SELECT BRANCH_CODE FROM STTM_BRANCH WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH AND NVL(FUND_BRANCH, 'N') = 'Y') OR (BRANCH_CODE IN (SELECT BRANCH_CODE FROM STTM_BRANCH WHERE NVL(FUND_BRANCH, 'N') = 'N') AND EXISTS (SELECT * FROM STTM_BRANCH WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH AND NVL(FUND_BRANCH, 'N') = 'N')) AND NVL(MUDARABAH_FUND, 'N') = 'Y') AND NVL(ISLAMIC_SYNDICATION,'N')='N' ) WHERE FUND_ID = P_wrk_dedjnlon.v_detbs_jrnl_txn_master.FUND_ID;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :FUND_ID:'||p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.FUND_ID);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.FUND_ID||'~@DETBS_JRNL_TXN_MASTER.FUND_ID~@DETBS_JRNL_TXN_MASTER') ;
         END IF;
      END IF;
      l_Count      := p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
      IF l_Count > 0 THEN
         FOR l_Index  IN 1 .. l_Count LOOP
            l_Blk := 'DETBS_JRNL_TXN_DTL_CUSTOM';
            l_Fld := 'DETBS_JRNL_TXN_DTL_CUSTOM.BUDGET_CODE';
            IF p_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).BUDGET_CODE IS NOT NULL THEN
               SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT LOV, LOV_DESC FROM UDTM_LOV WHERE FIELD_NAME = 'BUDGET_CODE') WHERE LOV = P_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).BUDGET_CODE;
               IF l_lov_count = 0  THEN
                  Dbg('Invalid Value For The Field  :BUDGET_CODE:'||p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).BUDGET_CODE);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                  p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).BUDGET_CODE||'~@DETBS_JRNL_TXN_DTL_CUSTOM.BUDGET_CODE'||'~'||l_Key||'~@DETBS_JRNL_TXN_DTL_CUSTOM') ;
               END IF;
            END IF;
            l_Fld := 'DETBS_JRNL_TXN_DTL_CUSTOM.TAX_CODE';
            IF p_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).TAX_CODE IS NOT NULL THEN
               SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT LOV, LOV_DESC FROM UDTM_LOV WHERE FIELD_NAME = 'TAX_CODE') WHERE LOV = P_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).TAX_CODE;
               IF l_lov_count = 0  THEN
                  Dbg('Invalid Value For The Field  :TAX_CODE:'||p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).TAX_CODE);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                  p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).TAX_CODE||'~@DETBS_JRNL_TXN_DTL_CUSTOM.TAX_CODE'||'~'||l_Key||'~@DETBS_JRNL_TXN_DTL_CUSTOM') ;
               END IF;
            END IF;
            l_Fld := 'DETBS_JRNL_TXN_DTL_CUSTOM.DEPT_CODE';
            IF p_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).DEPT_CODE IS NOT NULL THEN
               SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT LOV, LOV_DESC FROM UDTM_LOV WHERE FIELD_NAME = 'DEPARTMENT_CODE') WHERE LOV = P_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).DEPT_CODE;
               IF l_lov_count = 0  THEN
                  Dbg('Invalid Value For The Field  :DEPT_CODE:'||p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).DEPT_CODE);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_DTL_CUSTOM.SERIAL_NO')||'-'||
                  p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_Index).DEPT_CODE||'~@DETBS_JRNL_TXN_DTL_CUSTOM.DEPT_CODE'||'~'||l_Key||'~@DETBS_JRNL_TXN_DTL_CUSTOM') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_dedjnlon  IN   OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      l_Dsn_Rec_Cnt_4 NUMBER := 0;
      l_Bnd_Cntr_4    NUMBER := 0;
      l_Dsn_Rec_Cnt_5 NUMBER := 0;
      l_Bnd_Cntr_5    NUMBER := 0;
      l_Dsn_Rec_Cnt_6 NUMBER := 0;
      l_Bnd_Cntr_6    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Querying Query Data Sources..');
      Dbg('Get the Record For :DETBS_BATCH_MASTER');
      BEGIN
         SELECT *
         INTO P_wrk_dedjnlon.v_detbs_batch_master
         FROM   DETB_BATCH_MASTER
         WHERE batch_no = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.batch_no
          AND branch_code = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.branch_code
         ;
      EXCEPTION
         WHEN OTHERS THEN
            Dbg(SQLERRM);
            Dbg('Failed in Selecting The Record For :DETBS_BATCH_MASTER');
      END;
      IF p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT > 0 THEN
         FOR i_2 IN  1..p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT LOOP
            NULL;

         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Sys_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_dedjnlon         IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon  IN   OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Wrk_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists        BOOLEAN := TRUE;
      RECORD_LOCKED    EXCEPTION;
      PRAGMA EXCEPTION_INIT( RECORD_LOCKED, -54 );
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      l_Dsn_Rec_Cnt_4 NUMBER := 0;
      l_Bnd_Cntr_4    NUMBER := 0;
      l_Dsn_Rec_Cnt_6 NUMBER := 0;
      l_Bnd_Cntr_6    NUMBER := 0;
      Cursor c_v_detbs_jrnl_txn_detail IS
      SELECT *
      FROM   DETB_JRNL_TXN_DETAIL
      WHERE reference_no = p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
      ;
      Cursor c_v_detbs_jrnl_txn_dtl_custom IS
      SELECT *
      FROM   DETB_JRNL_TXN_DTL_CUSTOM
      WHERE reference_no = p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
      ;
   BEGIN
      Dbg('In Fn_Sys_Query..');
      IF p_QryData_Reqd = 'Q' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_dedjnlon,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      ELSE
         l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'DETBS_JRNL_TXN_MASTER.REFERENCE_NO')||'-'||
         p_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
         Dbg('Get The Master Record...');
         IF NVL(p_With_Lock,'N') = 'Y' THEN
            BEGIN
               SELECT *
               INTO   p_wrk_dedjnlon.v_detbs_jrnl_txn_master
               FROM  DETB_JRNL_TXN_MASTER
               WHERE reference_no = p_dedjnlon.v_detbs_jrnl_txn_master.reference_no
                FOR UPDATE NOWAIT;
            EXCEPTION
               WHEN RECORD_LOCKED THEN
                  Dbg('Failed to Obtain the Lock..');
                  Pr_Log_Error(p_Source,'ST-LOCK-001',NULL);
                  RETURN FALSE;
               WHEN No_Data_Found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  l_Rec_Exists := FALSE;
            END;

         ELSE
            BEGIN
               SELECT *
               INTO   p_Wrk_dedjnlon.v_detbs_jrnl_txn_master
               FROM  DETB_JRNL_TXN_MASTER
               WHERE reference_no = p_dedjnlon.v_detbs_jrnl_txn_master.reference_no
               ;
            EXCEPTION
               WHEN no_data_found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  p_Err_Code    := 'ST-VALS-002';
                  p_Err_Params  := l_Key;
                  RETURN FALSE;
            END;

         END IF;
         IF p_Full_Data = 'Y' AND l_Rec_Exists THEN
            Dbg('Get the Record For :DETBS_JRNL_TXN_MASTER');
            BEGIN
               SELECT *
               INTO p_Wrk_dedjnlon.v_detbs_jrnl_txn_master
               FROM   DETB_JRNL_TXN_MASTER
               WHERE reference_no = p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :DETBS_JRNL_TXN_MASTER');
            END;
            Dbg('Get the Record For :DETBS_JRNL_TXN_DETAIL');
            OPEN c_v_detbs_jrnl_txn_detail;
            LOOP
               FETCH c_v_detbs_jrnl_txn_detail
               BULK COLLECT INTO p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail;
                EXIT WHEN c_v_detbs_jrnl_txn_detail%NOTFOUND;
            END LOOP;
            CLOSE c_v_detbs_jrnl_txn_detail;
            Dbg('Get the Record For :DEVWS_BATCH_MASTER');
            BEGIN
               SELECT *
               INTO p_Wrk_dedjnlon.v_devws_batch_master
               FROM   DEVW_BATCH_MASTER
               WHERE branch_code = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.branch_code
                AND batch_no = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.batch_no
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :DEVWS_BATCH_MASTER');
            END;
            Dbg('Get the Record For :DETBS_JRNL_TXN_DTL_CUSTOM');
            OPEN c_v_detbs_jrnl_txn_dtl_custom;
            LOOP
               FETCH c_v_detbs_jrnl_txn_dtl_custom
               BULK COLLECT INTO p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom;
                EXIT WHEN c_v_detbs_jrnl_txn_dtl_custom%NOTFOUND;
            END LOOP;
            CLOSE c_v_detbs_jrnl_txn_dtl_custom;

            Dbg('Calling Uvpkss_Udf_Upload.Fn_Query_Cont_Udfdetails..');
            IF NOT Uvpkss_Udf_Upload.Fn_Query_Cont_Udfdetails(p_Function_Id,
                                               g_Txn_Udf_Key,
                                               p_Wrk_dedjnlon.Txn_Udf_Details,
                                               p_Err_Code,
                                               p_Err_Params) THEN
               Dbg('Failed in Uvpkss_Udf_Upload.Fn_Query_Cont_Udfdetails..');
               RETURN FALSE;
            END IF;
         END IF;
         IF p_QryData_Reqd = 'Y' THEN
            Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
            IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Wrk_dedjnlon,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
               RETURN FALSE;
            END IF;
         END IF;

      END IF;
      Dbg('Returning Success From Fn_Sys_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         IF  c_v_detbs_jrnl_txn_detail%ISOPEN THEN
            CLOSE c_v_detbs_jrnl_txn_detail;
         END IF;
         IF  c_v_detbs_jrnl_txn_dtl_custom%ISOPEN THEN
            CLOSE c_v_detbs_jrnl_txn_dtl_custom;
         END IF;
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query;
   FUNCTION Fn_Sys_Upload_Db         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon      IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Count             NUMBER:= 0;
      l_Ins_Count         NUMBER:= 0;
      l_Upd_Count         NUMBER:= 0;
      l_Del_Count         NUMBER:= 0;
      l_Wrk_Count         NUMBER:= 0;
      l_Prev_Count        NUMBER:= 0;
      l_Rec_Found         BOOLEAN:= FALSE;
      l_Row_Id            ROWID;
      l_Key               VARCHAR2(5000):= NULL;
      l_Auth_Stat         VARCHAR2(1) := 'A';
      l_Base_Data_From_Fc VARCHAR2(1):= 'Y';
      I_v_detbs_jrnl_txn_detail       depks_dedjnlon_Main.Ty_Tb_v_detbs_jrnl_txn_detail;
      U_v_detbs_jrnl_txn_detail       depks_dedjnlon_Main.Ty_Tb_v_detbs_jrnl_txn_detail;
      D_v_detbs_jrnl_txn_detail       depks_dedjnlon_Main.Ty_Tb_v_detbs_jrnl_txn_detail;
      I_v_detbs_jrnl_txn_dtl_custom       depks_dedjnlon_Main.Ty_Tb_etbs_jrnl_txn_dtl_custom;
      U_v_detbs_jrnl_txn_dtl_custom       depks_dedjnlon_Main.Ty_Tb_etbs_jrnl_txn_dtl_custom;
      D_v_detbs_jrnl_txn_dtl_custom       depks_dedjnlon_Main.Ty_Tb_etbs_jrnl_txn_dtl_custom;
   BEGIN
      Dbg('In Fn_Sys_Upload_Db..');
      IF p_Action_Code = Cspks_Req_Global.p_new THEN

         Dbg('Inserting Into DETBS_JRNL_TXN_MASTER..');
         BEGIN
            IF  p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  DETB_JRNL_TXN_MASTER
               VALUES p_wrk_dedjnlon.v_detbs_jrnl_txn_master;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoDETBS_JRNL_TXN_MASTER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DETBS_JRNL_TXN_MASTER';
               RETURN FALSE;
         END;

         Dbg('Inserting Into DETBS_JRNL_TXN_DETAIL..');
         BEGIN
            l_Count      := p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
            FORALL l_index IN  1..l_count
            INSERT INTO DETB_JRNL_TXN_DETAIL
            VALUES p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoDETBS_JRNL_TXN_DETAIL..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DETBS_JRNL_TXN_DETAIL';
               RETURN FALSE;
         END;

         Dbg('Inserting Into DEVWS_BATCH_MASTER..');
         BEGIN
            IF  p_wrk_dedjnlon.v_devws_batch_master.branch_code IS NOT NULL AND  p_wrk_dedjnlon.v_devws_batch_master.batch_no IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  DEVW_BATCH_MASTER
               VALUES p_wrk_dedjnlon.v_devws_batch_master;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoDEVWS_BATCH_MASTER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DEVWS_BATCH_MASTER';
               RETURN FALSE;
         END;

         Dbg('Inserting Into DETBS_JRNL_TXN_DTL_CUSTOM..');
         BEGIN
            l_Count      := p_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
            FORALL l_index IN  1..l_count
            INSERT INTO DETB_JRNL_TXN_DTL_CUSTOM
            VALUES p_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoDETBS_JRNL_TXN_DTL_CUSTOM..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DETBS_JRNL_TXN_DTL_CUSTOM';
               RETURN FALSE;
         END;
      ELSIF p_Action_Code = Cspks_Req_Global.p_modify THEN

         Dbg('Updating Single Record Node :  DETBS_JRNL_TXN_MASTER..');
         BEGIN
            UPDATE DETB_JRNL_TXN_MASTER
            SET
            BATCH_NO = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.BATCH_NO,
            CURR_NO = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.CURR_NO,
            TEMPLATE_ID = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.TEMPLATE_ID,
            VALUE_DATE = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.VALUE_DATE,
            BOOK_DATE = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.BOOK_DATE,
            BRANCH_CODE = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.BRANCH_CODE,
            CCY = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.CCY,
            TOTAL_DR = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.TOTAL_DR,
            TOTAL_CR = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.TOTAL_CR,
            MAKER_ID = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.MAKER_ID,
            MAKER_DT_STAMP = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.MAKER_DT_STAMP,
            CHECKER_ID = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.CHECKER_ID,
            CHECKER_DT_STAMP = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.CHECKER_DT_STAMP,
            CONTRACT_STATUS = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.CONTRACT_STATUS,
            AUTH_STATUS = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.AUTH_STATUS,
            FUND_ID = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.FUND_ID
WHERE reference_no = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert Into DETBS_JRNL_TXN_MASTER..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DETBS_JRNL_TXN_MASTER';
               RETURN FALSE;
         END;


         IF  p_Wrk_dedjnlon.v_devws_batch_master.branch_code IS NOT NULL AND  p_Wrk_dedjnlon.v_devws_batch_master.batch_no IS NOT NULL THEN
            Dbg('Record Sent..');
            Dbg('Updating Single Record Node :  DEVWS_BATCH_MASTER..');
            BEGIN
               UPDATE DEVW_BATCH_MASTER
               SET
               DESCRIPTION = p_Wrk_dedjnlon.v_devws_batch_master.DESCRIPTION,
               TYPE = p_Wrk_dedjnlon.v_devws_batch_master.TYPE,
               LAST_OPER_ID = p_Wrk_dedjnlon.v_devws_batch_master.LAST_OPER_ID,
               LAST_AUTH_ID = p_Wrk_dedjnlon.v_devws_batch_master.LAST_AUTH_ID,
               LAST_OPER_DT_STAMP = p_Wrk_dedjnlon.v_devws_batch_master.LAST_OPER_DT_STAMP,
               LAST_AUTH_DT_STAMP = p_Wrk_dedjnlon.v_devws_batch_master.LAST_AUTH_DT_STAMP,
               LOCKED = p_Wrk_dedjnlon.v_devws_batch_master.LOCKED,
               CURR_NO = p_Wrk_dedjnlon.v_devws_batch_master.CURR_NO,
               DR_CHK_TOTAL = p_Wrk_dedjnlon.v_devws_batch_master.DR_CHK_TOTAL,
               CR_CHK_TOTAL = p_Wrk_dedjnlon.v_devws_batch_master.CR_CHK_TOTAL,
               DR_ENT_TOTAL = p_Wrk_dedjnlon.v_devws_batch_master.DR_ENT_TOTAL,
               CR_ENT_TOTAL = p_Wrk_dedjnlon.v_devws_batch_master.CR_ENT_TOTAL,
               AUTH_STAT = p_Wrk_dedjnlon.v_devws_batch_master.AUTH_STAT,
               UPLOADED = p_Wrk_dedjnlon.v_devws_batch_master.UPLOADED,
               BALANCING = p_Wrk_dedjnlon.v_devws_batch_master.BALANCING,
               SYSTEM_BATCH = p_Wrk_dedjnlon.v_devws_batch_master.SYSTEM_BATCH,
               POSITION_REQD = p_Wrk_dedjnlon.v_devws_batch_master.POSITION_REQD,
               DELETE_STAT = p_Wrk_dedjnlon.v_devws_batch_master.DELETE_STAT
WHERE branch_code = p_Wrk_dedjnlon.v_devws_batch_master.branch_code
 AND batch_no = p_Wrk_dedjnlon.v_devws_batch_master.batch_no
;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed in Insert Into DEVWS_BATCH_MASTER..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@DEVWS_BATCH_MASTER';
                  RETURN FALSE;
            END;
            IF SQL%ROWCOUNT = 0 THEN
               BEGIN
                  INSERT INTO  DEVW_BATCH_MASTER
                  VALUES p_Wrk_dedjnlon.v_devws_batch_master;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Insert Into DEVWS_BATCH_MASTER..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@DEVWS_BATCH_MASTER';
                     RETURN FALSE;
               END;
            END IF;
         ELSE
            dbg('Check If The Record Is Already Present for  DEVWS_BATCH_MASTER. .');
            IF  p_prev_dedjnlon.v_devws_batch_master.branch_code IS NOT NULL OR  p_prev_dedjnlon.v_devws_batch_master.batch_no IS NOT NULL THEN
               Dbg('Prev Data Exists And Not Sent For  DEVWS_BATCH_MASTER. Delete the Existing Record.');
               DELETE DEVW_BATCH_MASTER
               WHERE branch_code = p_Prev_dedjnlon.v_devws_batch_master.branch_code
                AND batch_no = p_Prev_dedjnlon.v_devws_batch_master.batch_no
               ;
            END IF;
         END IF;


         Dbg('Preapring Insert and Update Types for  DETBS_JRNL_TXN_DETAIL..');
         l_Wrk_Count  := p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
         l_Prev_Count := p_Prev_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
         IF l_Wrk_Count > 0 THEN
            FOR l_index IN 1 .. l_Wrk_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Prev_Count >  0 THEN
                  FOR l_index1 IN 1..l_Prev_Count  LOOP
                     IF (NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no,-1)=  NVL(p_Prev_dedjnlon.v_detbs_jrnl_txn_detail  (l_index1).serial_no,-1)) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_rec_found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF l_rec_found THEN
                  Dbg('Record is Modified...');
                  U_v_detbs_jrnl_txn_detail(U_v_detbs_jrnl_txn_detail.COUNT +1 ) :=  p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index);
               ELSE
                  Dbg('Record is Added...');
                  I_v_detbs_jrnl_txn_detail(I_v_detbs_jrnl_txn_detail.COUNT +1 ) :=  p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index);
               END IF;
            END LOOP;
         END IF;

         Dbg('Preapring Delete Types for  DETBS_JRNL_TXN_DETAIL..');
         l_Wrk_Count  := p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
         l_Prev_Count := p_prev_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
         IF l_Prev_Count > 0 THEN
            FOR l_index1 IN 1 .. l_Prev_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Wrk_Count >  0 THEN
                  FOR l_index IN 1..l_Wrk_Count  LOOP
                     IF (NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).serial_no,-1)=  NVL(p_Prev_dedjnlon.v_detbs_jrnl_txn_detail  (l_index1).serial_no,-1)) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_Rec_Found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF NOT l_Rec_Found THEN
                  Dbg('Record is Deleted...');
                  D_v_detbs_jrnl_txn_detail(D_v_detbs_jrnl_txn_detail.COUNT +1 ) :=  p_Prev_dedjnlon.v_detbs_jrnl_txn_detail(l_index1);
               END IF;
            END LOOP;
         END IF;
         l_Del_Count  := D_v_detbs_jrnl_txn_detail.COUNT;
         Dbg('Records Deleted  :'||l_Del_Count);
         IF l_Del_Count > 0 THEN
            FOR l_index IN 1 .. l_del_count LOOP
               Dbg('Deleting Record...');
               DELETE DETB_JRNL_TXN_DETAIL
               WHERE reference_no = D_v_detbs_jrnl_txn_detail(l_index).reference_no
                AND serial_no = D_v_detbs_jrnl_txn_detail(l_index).serial_no
               ;
            END LOOP;
         END IF;
         l_Ins_Count  := I_v_detbs_jrnl_txn_detail.COUNT;
         Dbg('New Records Added  :'||l_ins_count);
         BEGIN
            l_Count      := I_v_detbs_jrnl_txn_detail.COUNT;
            FORALL l_Index IN  1..l_count
            INSERT INTO DETB_JRNL_TXN_DETAIL
            VALUES I_v_detbs_jrnl_txn_detail(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert IntoDETBS_JRNL_TXN_DETAIL..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DETBS_JRNL_TXN_DETAIL';
               RETURN FALSE;
         END;
         l_Upd_Count  := U_v_detbs_jrnl_txn_detail.COUNT;
         Dbg('Records Modified  :'||l_Upd_Count);
         IF l_Upd_Count > 0 THEN
            FOR l_index IN 1 .. l_Upd_Count LOOP
               Dbg('Updating The  Record...');
               BEGIN
                  UPDATE DETB_JRNL_TXN_DETAIL
                  SET
                  USER_REF_NO = U_v_detbs_jrnl_txn_detail(l_index).USER_REF_NO,
                  DR_CR = U_v_detbs_jrnl_txn_detail(l_index).DR_CR,
                  BRANCH_CODE = U_v_detbs_jrnl_txn_detail(l_index).BRANCH_CODE,
                  AC_OR_GL = U_v_detbs_jrnl_txn_detail(l_index).AC_OR_GL,
                  AC_GL_NO = U_v_detbs_jrnl_txn_detail(l_index).AC_GL_NO,
                  AMOUNT = U_v_detbs_jrnl_txn_detail(l_index).AMOUNT,
                  CCY = U_v_detbs_jrnl_txn_detail(l_index).CCY,
                  TXN_CODE = U_v_detbs_jrnl_txn_detail(l_index).TXN_CODE,
                  INSTRUMENT_NO = U_v_detbs_jrnl_txn_detail(l_index).INSTRUMENT_NO,
                  LCY_AMOUNT = U_v_detbs_jrnl_txn_detail(l_index).LCY_AMOUNT,
                  ADDL_TEXT = U_v_detbs_jrnl_txn_detail(l_index).ADDL_TEXT,
                  RELATED_CUSTOMER = U_v_detbs_jrnl_txn_detail(l_index).RELATED_CUSTOMER,
                  EXCH_RATE = U_v_detbs_jrnl_txn_detail(l_index).EXCH_RATE,
                  UI_AC_GL_NO = U_v_detbs_jrnl_txn_detail(l_index).UI_AC_GL_NO
WHERE reference_no = U_v_detbs_jrnl_txn_detail(l_index).reference_no
 AND serial_no = U_v_detbs_jrnl_txn_detail(l_index).serial_no
;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Updating DETBS_JRNL_TXN_DETAIL..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@DETBS_JRNL_TXN_DETAIL';
                     RETURN FALSE;
               END;
            END LOOP;
         END IF;

         Dbg('Preapring Insert and Update Types for  DETBS_JRNL_TXN_DTL_CUSTOM..');
         l_Wrk_Count  := p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
         l_Prev_Count := p_Prev_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
         IF l_Wrk_Count > 0 THEN
            FOR l_index IN 1 .. l_Wrk_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Prev_Count >  0 THEN
                  FOR l_index1 IN 1..l_Prev_Count  LOOP
                     IF (NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no,-1)=  NVL(p_Prev_dedjnlon.v_detbs_jrnl_txn_dtl_custom  (l_index1).serial_no,-1)) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_rec_found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF l_rec_found THEN
                  Dbg('Record is Modified...');
                  U_v_detbs_jrnl_txn_dtl_custom(U_v_detbs_jrnl_txn_dtl_custom.COUNT +1 ) :=  p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index);
               ELSE
                  Dbg('Record is Added...');
                  I_v_detbs_jrnl_txn_dtl_custom(I_v_detbs_jrnl_txn_dtl_custom.COUNT +1 ) :=  p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index);
               END IF;
            END LOOP;
         END IF;

         Dbg('Preapring Delete Types for  DETBS_JRNL_TXN_DTL_CUSTOM..');
         l_Wrk_Count  := p_wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
         l_Prev_Count := p_prev_dedjnlon.v_detbs_jrnl_txn_dtl_custom.COUNT;
         IF l_Prev_Count > 0 THEN
            FOR l_index1 IN 1 .. l_Prev_Count LOOP
               l_Rec_Found    := FALSE;
               IF l_Wrk_Count >  0 THEN
                  FOR l_index IN 1..l_Wrk_Count  LOOP
                     IF (NVL(p_Wrk_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index).serial_no,-1)=  NVL(p_Prev_dedjnlon.v_detbs_jrnl_txn_dtl_custom  (l_index1).serial_no,-1)) THEN
                        Dbg('Record Has Been Found.Update Case..');
                        l_Rec_Found := TRUE;
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
               IF NOT l_Rec_Found THEN
                  Dbg('Record is Deleted...');
                  D_v_detbs_jrnl_txn_dtl_custom(D_v_detbs_jrnl_txn_dtl_custom.COUNT +1 ) :=  p_Prev_dedjnlon.v_detbs_jrnl_txn_dtl_custom(l_index1);
               END IF;
            END LOOP;
         END IF;
         l_Del_Count  := D_v_detbs_jrnl_txn_dtl_custom.COUNT;
         Dbg('Records Deleted  :'||l_Del_Count);
         IF l_Del_Count > 0 THEN
            FOR l_index IN 1 .. l_del_count LOOP
               Dbg('Deleting Record...');
               DELETE DETB_JRNL_TXN_DTL_CUSTOM
               WHERE reference_no = D_v_detbs_jrnl_txn_dtl_custom(l_index).reference_no
                AND serial_no = D_v_detbs_jrnl_txn_dtl_custom(l_index).serial_no
               ;
            END LOOP;
         END IF;
         l_Ins_Count  := I_v_detbs_jrnl_txn_dtl_custom.COUNT;
         Dbg('New Records Added  :'||l_ins_count);
         BEGIN
            l_Count      := I_v_detbs_jrnl_txn_dtl_custom.COUNT;
            FORALL l_Index IN  1..l_count
            INSERT INTO DETB_JRNL_TXN_DTL_CUSTOM
            VALUES I_v_detbs_jrnl_txn_dtl_custom(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert IntoDETBS_JRNL_TXN_DTL_CUSTOM..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@DETBS_JRNL_TXN_DTL_CUSTOM';
               RETURN FALSE;
         END;
         l_Upd_Count  := U_v_detbs_jrnl_txn_dtl_custom.COUNT;
         Dbg('Records Modified  :'||l_Upd_Count);
         IF l_Upd_Count > 0 THEN
            FOR l_index IN 1 .. l_Upd_Count LOOP
               Dbg('Updating The  Record...');
               BEGIN
                  UPDATE DETB_JRNL_TXN_DTL_CUSTOM
                  SET
                  BUDGET_CODE = U_v_detbs_jrnl_txn_dtl_custom(l_index).BUDGET_CODE,
                  TAX_CODE = U_v_detbs_jrnl_txn_dtl_custom(l_index).TAX_CODE,
                  SUPPLIER_CODE = U_v_detbs_jrnl_txn_dtl_custom(l_index).SUPPLIER_CODE,
                  DEPT_CODE = U_v_detbs_jrnl_txn_dtl_custom(l_index).DEPT_CODE
WHERE reference_no = U_v_detbs_jrnl_txn_dtl_custom(l_index).reference_no
 AND serial_no = U_v_detbs_jrnl_txn_dtl_custom(l_index).serial_no
;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Updating DETBS_JRNL_TXN_DTL_CUSTOM..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@DETBS_JRNL_TXN_DTL_CUSTOM';
                     RETURN FALSE;
               END;
            END LOOP;
         END IF;
      ELSIF p_Action_Code = Cspks_Req_Global.p_delete THEN
         Dbg('Action Code '||p_Action_Code);
         Dbg('Deleting The Data..');

         
         DELETE DETB_JRNL_TXN_DTL_CUSTOM
         WHERE reference_no = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
         ;

         
         DELETE DEVW_BATCH_MASTER
         WHERE branch_code = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.branch_code
          AND batch_no = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.batch_no
         ;

         
         DELETE DETB_JRNL_TXN_DETAIL
         WHERE reference_no = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
         ;

         DELETE DETB_JRNL_TXN_MASTER WHERE reference_no = p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
         ;



      END IF;

      Dbg('Returning Success From Fn_Sys_Upload_Db');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Upload_Db;
   FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_dedjnlon       IN   OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Build_Ws_Type..');

      IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
         IF NOT Fn_Sys_Build_Fc_Type(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_DEDJNLON,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Fc_Type..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT Fn_Sys_Build_Ws_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_DEDJNLON,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Ws_Type..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTTYPE');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_DEDJNLON,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_DEDJNLON,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Build_Type..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Build_Type ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Type;
   FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_exchange_pattern   IN  VARCHAR2,
      p_dedjnlon          IN depks_dedjnlon_Main.ty_dedjnlon,
      p_err_code        IN OUT VARCHAR2,
      p_err_params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

   BEGIN

      dbg('In Fn_Build_Ts_List..');

      IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
         IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_dedjnlon,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Fc_Ts');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            p_dedjnlon,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Ws_Ts');
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning from Fn_Build_Ts_List');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of depks_dedjnlon_Main.Fn_Build_Ts_List ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Build_Ts_List;
   FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon       IN  OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Key_Cols        VARCHAR2(32767);
      l_Key_Vals        VARCHAR2(32767);
      l_Func_Type       VARCHAR2(32767);
   BEGIN

      Dbg('In Fn_Get_Key_Information..');
      l_Key_Cols := 'REFERENCE_NO~';
      l_Key_Vals := p_dedjnlon.v_detbs_jrnl_txn_master.reference_no||'~';
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
      IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code ,
         'TRANSACTION',
         'DETBS_JRNL_TXN_MASTER',
         'BLK_DETBS_JRNL_TXN_MASTER',
         'Detbs-Jrnl-Txn-Master',
         l_Key_Cols,
         l_Key_Vals,
         p_dedjnlon.Addl_Info,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
         RETURN FALSE;
      END IF;
      IF p_dedjnlon.Addl_Info.EXISTS('RECORD_KEY') THEN
         G_Req_Key :=  p_dedjnlon.Addl_Info('RECORD_KEY');
      END IF;
      IF p_dedjnlon.Addl_Info.EXISTS('TXN_UDF_KEY') THEN
         g_Txn_Udf_Key :=  p_dedjnlon.Addl_Info('TXN_UDF_KEY');
      END IF;
      Dbg('Returning Succsess From Fn_Get_Key_Information..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Get_Key_Information..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Key_Information;
   FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
     RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;

   BEGIN

      Dbg('In Fn_Check_Mandatory..');

      Pr_Skip_Handler('PREMAND');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Pk_Or_Full,
            p_Function_Id  ,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  depks_dedjnlon_Custom.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Pk_Or_Full,
            p_Function_Id  ,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  depks_dedjnlon_Kernel.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      l_mictrmis := p_dedjnlon.ty_mictrmis;
      Dbg('Calling Mipks_Mictrmis_Main.Fn_Check_Mandatory..');
      IF NOT Mipks_Mictrmis_Main.Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         'MICTRMIS',
         p_Action_Code,
         l_Main_Function,
         p_Pk_Or_Full,
         l_mictrmis,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Mipks_Mictrmis_Main.Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RETURN FALSE;
      END IF;
      p_dedjnlon.ty_mictrmis:=l_mictrmis;

      Pr_Skip_Handler('POSTMAND');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Pk_Or_Full,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Pk_Or_Full,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Check_Mandatory;
   FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_dedjnlon         IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon  IN   OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Wrk_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Key        VARCHAR2(5000):= NULL;

   BEGIN

      Dbg('In Fn_Query..');

      Pr_Skip_Handler('PREQRY');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_pre_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock,
            p_QryData_Reqd,
            p_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_pre_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock,
            p_QryData_Reqd,
            p_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Full_Data = 'Y' THEN
         l_Key_Vals :='CONTRACT_REF_NO'||'>'||p_wrk_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO;
         l_Wrk_mictrmis := p_Wrk_dedjnlon.Ty_mictrmis;
         Dbg('Calling Mipks_Mictrmis_Main. Fn_Query..');
         IF NOT Mipks_Mictrmis_Main.Fn_Query (p_Source,
            p_Source_Operation,
            'MICTRMIS',
            p_Action_Code,
            l_Main_Function,
            l_Key_Vals,
            p_QryData_Reqd,
            l_mictrmis,
            l_Wrk_mictrmis,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Mipks_Mictrmis_Main. Fn_Query..');
            RETURN FALSE;
         END IF;

          p_Wrk_dedjnlon.Ty_mictrmis := l_Wrk_mictrmis;

      END IF;
      l_Key_Tags := 'REFERENCE_NO~';
      l_Key_Vals := p_dedjnlon.v_detbs_jrnl_txn_master.reference_no||'~';
      Dbg('Calling Uvpkss_Udf_Upload.Fn_Query_Cont_Udfdetails..');
      IF NOT Uvpkss_Udf_Upload.Fn_Query_Cont_Udfdetails(p_Function_Id,
                                         g_Txn_Udf_Key,
                                         p_Wrk_dedjnlon.Txn_Udf_Details,
                                         p_Err_Code,
                                         p_Err_Params) THEN
         Dbg('Failed in Uvpkss_Udf_Upload.Fn_Query_Cont_Udfdetails..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('SYSDESC');
      IF p_QryData_Reqd = 'Y' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_dedjnlon,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      END IF;

      Pr_Skip_Handler('POSTQRY');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock ,
            p_QryData_Reqd,
            p_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Function_Id  ,
            p_Full_Data  ,
            p_with_lock ,
            p_QryData_Reqd,
            p_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Query..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Query;
   FUNCTION Fn_Resolve_Ref_Numbers         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;

   BEGIN

      Dbg('In Fn_Resolve_Ref_Numbers..');

      Pr_Skip_Handler('PREMAND');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Pre_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Pre_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTMAND');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Resolve_Ref_Numbers (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Resolve_Ref_Numbers..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Resolve_Ref_Numbers..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Resolve_Ref_Numbers ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Resolve_Ref_Numbers;
   FUNCTION Fn_Product_Default         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon      IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'DEDJNLON';
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Key_Id  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);

      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Wrk_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;

   BEGIN

      Dbg('In Fn_Product_Default..');

      Pr_Skip_Handler('PREPRDDFLT');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Pre_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Pre_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
      IF NOT Fn_Sys_Query_Desc_Fields(p_Source,
         p_Source_Operation,
         p_Function_Id,
         Cspks_Req_Global.p_prddflt,
         p_Wrk_dedjnlon,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('POSTPRDDFLT');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Product_Default..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Product_Default..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Product_Default ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Product_Default;
   FUNCTION Fn_Unlock         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN  OUT  VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'DEDJNLON';


   BEGIN

      Dbg('In Fn_Unlock..');

      Pr_Skip_Handler('PREUNLOCK');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Pre_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Pre_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTUNLOCK');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Unlock (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code ,
            p_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Unlock..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Unlock..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Unlock ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Unlock;
   FUNCTION Fn_Subsys_Pickup         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon      IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'DEDJNLON';

      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Prev_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Wrk_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;

   BEGIN

      Dbg('In Fn_Subsys_Pickup..');

      Pr_Skip_Handler('PRESUBSYSPKP');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Pre_Subsys_Pickup..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Pre_Subsys_Pickup..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTSUBSYSPKP');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_prev_dedjnlon,
            p_wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Subsys_Pickup ..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_prev_dedjnlon,
            p_wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Subsys_Pickup ..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Subsys_Pickup..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Subsys_Pickup ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Subsys_Pickup;
   FUNCTION Fn_Enrich         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon      IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'DEDJNLON';

      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Prev_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Wrk_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;

   BEGIN

      Dbg('In Fn_Enrich..');

      Pr_Skip_Handler('PREENRICH');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom. Fn_Pre_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel. Fn_Pre_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Calling in Fn_Sys_Query_Desc_Field..');
      IF NOT Fn_Sys_Query_Desc_Fields(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Wrk_dedjnlon,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Sys_Query_Desc_Field..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('POSTENRICH');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Enrich..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning  Success From Fn_Enrich..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of depks_dedjnlon_Main.Fn_Enrich ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Enrich;
   FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN OUT    VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation       VARCHAR2(100) := p_source_Operation;
      l_Full_Data    VARCHAR2(1) := 'N';
      l_With_Lock    VARCHAR2(1) := 'Y';
      l_Qrydata_Reqd    VARCHAR2(1) := 'N';
      l_Pk_Or_Full      VARCHAR2(10) := 'FULL';

      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Prev_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Wrk_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;

   BEGIN

      Dbg('In Fn_Default_And_Validate..');

      l_Full_data   := 'Y';
      Dbg('Calling  Fn_Query..');
      IF NOT Fn_Query(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         l_Full_data,
         l_With_Lock,
         l_Qrydata_Reqd,
         p_dedjnlon,
         p_Prev_dedjnlon,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Query..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('PREDFLT');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Pre_Default_And_Validate');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Pre_Default_And_Validate');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='MICTRMIS_'||p_Action_Code;
      END IF;
      l_mictrmis := p_dedjnlon.Ty_mictrmis;
      l_Prev_mictrmis := p_Prev_dedjnlon.Ty_mictrmis;
      l_Wrk_mictrmis := p_Wrk_dedjnlon.Ty_mictrmis;
      Dbg('Calling Mipks_Mictrmis_Main.Fn_Default_And_Validate..');
      IF NOT Mipks_Mictrmis_Main.Fn_Default_And_Validate (p_Source,
         l_Source_Operation,
         'MICTRMIS',
         p_Action_Code,
         p_Function_Id,
         l_mictrmis,
         l_Prev_mictrmis,
         l_Wrk_mictrmis,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Mipks_Mictrmis_Main.Fn_Default_And_Validate..');
         RETURN FALSE;
      END IF;
      p_Prev_dedjnlon.Ty_mictrmis:= l_Prev_mictrmis;
      p_Wrk_dedjnlon.Ty_mictrmis:= l_Wrk_mictrmis;


      Pr_Skip_Handler('POSTDFLT');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  depks_dedjnlon_Kernel.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  depks_dedjnlon_Custom.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
         Dbg('Calling  Fn_Check_Mandatory..');
         IF NOT Fn_Check_Mandatory(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Pk_Or_Full,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_default_and_validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Default_And_Validate;
   FUNCTION Fn_Upload_Db  (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon      IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Key_Id  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);

      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Prev_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Wrk_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;

   BEGIN

      Dbg('In Fn_Upload_Db..');

      Pr_Skip_Handler('PREUPLD');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Delete THEN
         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='MICTRMIS_'||p_Action_Code;
         END IF;
         l_mictrmis := p_dedjnlon.Ty_mictrmis;
         l_Prev_mictrmis := p_Prev_dedjnlon.Ty_mictrmis;
         l_Wrk_mictrmis := p_Wrk_dedjnlon.Ty_mictrmis;
         Dbg('Calling  Mipks_Mictrmis_Main.Fn_Upload_Db..');
         IF NOT Mipks_Mictrmis_Main.Fn_Upload_Db (p_Source,
            l_Source_operation,
            p_Function_id,
            p_Action_Code,
            l_Main_Function,
            p_Multi_Trip_Id,
            l_mictrmis,
            l_Prev_mictrmis,
            l_Wrk_mictrmis,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Mipks_Mictrmis_Main.Fn_Upload_Db..');
            RETURN FALSE;
         END IF;
         p_Wrk_dedjnlon.Ty_mictrmis:= l_Wrk_mictrmis;


      END IF;
      Pr_Skip_Handler('POSTUPLD');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_id,
            p_action_code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success  From Fn_Upload_Db..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Upload_Db;
   FUNCTION Fn_Process         (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon     IN  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon      IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'DEDJNLON';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;

      l_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Prev_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;
      l_Wrk_mictrmis    Mipks_Mictrmis_Main.Ty_mictrmis;

   BEGIN

      Dbg('In Fn_Process..');

      Pr_Skip_Handler('PREPROCESS');
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Pre_Process (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_multi_trip_id,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  depks_dedjnlon_Custom.Fn_Pre_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Pre_Process (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_multi_trip_id,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in  depks_dedjnlon_Kernel.Fn_Pre_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTPROCESS');
      IF NOT depks_dedjnlon_Main.Fn_Skip_kernel  THEN
         IF NOT depks_dedjnlon_Kernel.Fn_Post_Process (p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Kernel.Fn_Post_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dedjnlon_Main.Fn_Skip_custom  THEN
         IF NOT depks_dedjnlon_Custom.Fn_Post_Process (p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Function_Id  ,
            p_Multi_Trip_Id,
            p_dedjnlon,
            p_Prev_dedjnlon,
            p_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in depks_dedjnlon_Custom.Fn_Post_Process..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='MICTRMIS_'||p_Action_Code;
      END IF;
      l_mictrmis := p_dedjnlon.ty_mictrmis;
      l_Prev_mictrmis := p_Prev_dedjnlon.Ty_mictrmis;
      l_Wrk_mictrmis := p_Wrk_dedjnlon.Ty_mictrmis;
      Dbg('Calling Mipks_Mictrmis_Main.Fn_Process..');
      IF NOT Mipks_Mictrmis_Main.Fn_Process(p_Source,
         l_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Function_Id  ,
         p_Multi_Trip_Id,
         l_mictrmis,
         l_Prev_mictrmis,
         l_Wrk_mictrmis,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed In Mipks_Mictrmis_Main.Fn_Process..');
         RETURN FALSE;
      END IF;
      p_Wrk_dedjnlon.Ty_mictrmis:= l_Wrk_mictrmis;


      Dbg('Returning Success From Fn_Process..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Process ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Process;
   FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;

   BEGIN

      Dbg('In Fn_Rebuild_Ts_List..');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         g_dedjnlon,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Dbg('Returning Success From Fn_Rebuild_Ts_List..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List..');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Rebuild_Ts_List..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Rebuild_Ts_List;

   FUNCTION Fn_Get_Node_Data (
      p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Cntr NUMBER := 0;
   BEGIN

      Dbg('In Fn_Get_Node_Data..');
      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_DETBS_JRNL_TXN_MASTER';
      p_Node_Data(l_Cntr).Xsd_Node := 'Detbs-Jrnl-Txn-Master';
      p_Node_Data(l_Cntr).Node_Parent := '';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'REFERENCE_NO~BATCH_NO~CURR_NO~TEMPLATE_ID~VALUE_DATE~BOOK_DATE~BRANCH_CODE~CCY~TOTAL_DR~TOTAL_CR~MAKER~MAKDTTIME~CHKR~CHKDTTIME~AUTHSTAT~TXNSTAT~FUNDID~RECORD_NO~TOTAL_NO~SUBSYSSTAT~';
      p_Node_Data(l_Cntr).Node_Tags := 'REFERENCE_NO~BATCH_NO~CURR_NO~TEMPLATE_CODE~VALUE_DATE~BOOK_DATE~BRANCH_CODE~CCY~TOTAL_DR~TOTAL_CR~MAKER~MAKDTTIME~CHECHKERID~CHKDTTIME~AUTHSTAT~TXNSTAT~FUNDID~REC_NO~TOTAL_NO~SUBSYSSTAT~';

      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_DETBS_JRNL_TXN_DETAIL';
      p_Node_Data(l_Cntr).Xsd_Node := 'Detbs-Jrnl-Txn-Detail';
      p_Node_Data(l_Cntr).Node_Parent := 'BLK_DETBS_JRNL_TXN_MASTER';
      p_Node_Data(l_Cntr).Node_Relation_Type := 'N';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'REFERENCE_NO~SERIAL_NO~USER_REF_NO~DR_CR~BRANCH_CODE~AC_OR_GL~AC_GL_NO~CCY~AMOUNT~TXN_CODE~INSTRUMENT_NO~LCY_AMOUNT~ADDL_TEXT~ACC_DESC~RELATED_CUSTOMER~EXCH_RATE~UI_AC_GL_NO~BUDGET_CODE~TAX_CODE~SUPPL';
      p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'IER_CODE~DEPT_CODE~';
      p_Node_Data(l_Cntr).Node_Tags := 'REFERENCE_NO~SERIAL_NO~USER_REF_NO~DR_CR~BRANCH_CODE~ACCORGL~~CCY~AMOUNT~TXN_CODE~INSTRUMENT_NO~LCY_AMOUNT~ADDL_TEXT~ACDESC~CUSTOMER~EXCH_RATE~ACCOUNT~BUDGET_CODE~TAX_CODE~SUPPLIER_CODE~DEPT_CODE~';

      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_DETBS_BATCH_MASTER';
      p_Node_Data(l_Cntr).Xsd_Node := 'Detbs-Batch-Master';
      p_Node_Data(l_Cntr).Node_Parent := 'BLK_DETBS_JRNL_TXN_MASTER';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'BATCH_NO~DESCRIPTION~DR_CHK_TOTAL~CR_CHK_TOTAL~DR_ENT_TOTAL~CR_ENT_TOTAL~';
      p_Node_Data(l_Cntr).Node_Tags := 'BATCH_NO~DESCRIPTION~DEBIT~CREDIT~DR_ENT_TOTAL~CR_ENT_TOTAL~';

      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_DEVWS_BATCH_MASTER';
      p_Node_Data(l_Cntr).Xsd_Node := 'Devws-Batch-Master';
      p_Node_Data(l_Cntr).Node_Parent := 'BLK_DETBS_JRNL_TXN_MASTER';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'BRANCH_CODE~BATCH_NO~DESCRIPTION~TYPE~LAST_OPER_ID~LAST_AUTH_ID~LAST_OPER_DT_STAMP~LAST_AUTH_DT_STAMP~LOCKED~CURR_NO~DR_CHK_TOTAL~CR_CHK_TOTAL~DR_ENT_TOTAL~CR_ENT_TOTAL~AUTH_STAT~UPLOADED~BALANCING~SY';
      p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'STEM_BATCH~POSITION_REQD~DELETE_STAT~';
      p_Node_Data(l_Cntr).Node_Tags := 'BRANCH_CODE~BATCH_NUMBER~DESCRIPTION~TYPE~LAST_OPERATED_BY~LAST_AUTHORISED_BY~MAKERDT~CHECKERDT~LOCKED~CURR_NO~DEBIT~CREDIT~DEBIT~CREDIT~AUTH_STAT~UPLOADED~BALANCING~SYS_1~POSITION~STATUS~';

      IF NOT Mipks_Mictrmis_Main.Fn_Get_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Mipks_Mictrmis_Main.Fn_Get_Node_Data..');
         RETURN FALSE;
      END IF;
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Txn_Udf_Node_Data..');
      IF NOT Cspks_Req_Utils.Fn_Get_Txn_Udf_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Txn_Udf_Node_Data..');
         RETURN FALSE;
      END IF;
      Dbg('Returning From Fn_Get_Node_Data.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of depks_dedjnlon_Main.Fn_Get_Node_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Node_Data;
   FUNCTION Fn_Main       (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_dedjnlon          IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;
      E_Hold_Exception        EXCEPTION;
      l_Post_Upl_Stat    VARCHAR2(1) :='A';
      l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
      l_action_code           VARCHAR2(100) := p_Action_Code;
      l_Wrk_dedjnlon     depks_dedjnlon_Main.Ty_dedjnlon;
      l_Prev_dedjnlon    depks_dedjnlon_Main.Ty_dedjnlon;
      l_Dmy_dedjnlon    depks_dedjnlon_Main.Ty_dedjnlon;
      l_Pk_Or_Full    VARCHAR2(5) :='PK';
      l_Full_Data    VARCHAR2(1) := 'Y';
      l_With_Lock    VARCHAR2(1) := 'N';
      l_Qrydata_Reqd    VARCHAR2(1) := 'Y';
      l_Count         NUMBER;
      l_Rollback_Reqd    VARCHAR2(1) := 'N';
      l_Prev_Auth_Stat        VARCHAR2(1) :='U';

   BEGIN

      Dbg('In Fn_Main');

      SAVEPOINT Sp_Main_Dedjnlon;
      p_Status := 'S';
      g_Addl_Info.DELETE;
      g_dedjnlon := p_dedjnlon;
      g_Original_Action := p_Action_Code ;
      g_Action_Code :=  p_Action_Code ;

      Dbg('Calling  Fn_Resolve_Ref_Numbers..');
      IF NOT Fn_Resolve_Ref_Numbers(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_dedjnlon,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Resolve_Ref_Numbers..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling in Fn_Unlock..');
      IF NOT Fn_Unlock(p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_dedjnlon,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Unlock..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling  Fn_Check_Mandatory..');
      IF NOT Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         l_Pk_Or_Full,
         p_dedjnlon,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      Dbg('Calling  Fn_Get_Key_Information..');
      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_dedjnlon,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      IF p_Action_Code  = Cspks_Req_Global.p_Query THEN
         Dbg('Calling Fn_Query..');
         IF NOT Fn_Query(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Full_data,
            l_With_Lock,
            l_Qrydata_Reqd,
            p_dedjnlon,
            l_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Query..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
      ELSIF p_Action_code  = Cspks_Req_Global.p_Prddflt THEN
         Dbg('Calling  Fn_Product_Default..');
         Dbg('Failed in Fn_Product_Default..');
         IF NOT Fn_Product_Default (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_dedjnlon,
            l_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Product_Default..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSIF SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_SubsysPickup))  = Cspks_Req_Global.p_SubsysPickup THEN
         Dbg('Calling  Fn_Subsys_Pickup..');
         IF NOT Fn_Subsys_Pickup (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_dedjnlon,
            l_Prev_dedjnlon,
            l_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Subsys_Pickup..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSIF SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  = Cspks_Req_Global.p_Enrich THEN
         Dbg('Calling  Fn_Enrich..');
         IF NOT Fn_Enrich (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_dedjnlon,
            l_Prev_dedjnlon,
            l_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Enrich..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

      ELSE
         IF NOT Fn_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_dedjnlon,
            l_Prev_dedjnlon,
            l_Wrk_dedjnlon,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Default_And_Validate..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         -- Get Resultant Error Type
         g_autoauth := 'U';
         l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
         IF l_Resultant_Error_Type <> 'E' THEN
            Dbg('Calling  Fn_Upload_Db..');
            IF NOT Fn_Upload_Db (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               p_dedjnlon,
               l_Prev_dedjnlon,
               l_Wrk_dedjnlon,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Upload_Db..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            Dbg('Calling  Fn_Process..');
            IF NOT Fn_Process (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               p_dedjnlon,
               l_Prev_dedjnlon,
               l_Wrk_dedjnlon,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Process..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            IF  l_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Reverse,Cspks_Req_Global.p_Rollover,Cspks_Req_Global.p_Confirm,Cspks_Req_Global.p_Liquidate ) THEN
               l_Prev_Auth_Stat := 'A';
               --Get Upload Status
               Dbg('Calling Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
               IF NOT Cspks_Req_Utils.Fn_Get_Auto_Auth_Status (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  l_Action_Code,
                  l_Prev_Auth_Stat,
                  p_Multi_Trip_Id,
                  P_Request_No,
                  l_Post_Upl_Stat,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
                  Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                  RAISE E_Failure_Exception;
               END IF;

               IF l_Post_Upl_Stat = 'A'THEN
                  Dbg('Calling Fn_Process With Auth as Action Code..');
                  IF NOT Fn_Process (p_Source,
                     p_Source_Operation,
                     p_Function_Id,
                     Cspks_Req_Global.p_Auth,
                     p_Multi_Trip_Id,
                     l_Wrk_dedjnlon,
                     l_Prev_dedjnlon,
                     l_Wrk_dedjnlon,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in Fn_Process..');
                     Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                     RAISE E_Failure_Exception;
                  END IF;
               END IF;
            END IF;
         END IF;
      END IF;
      --Get Upload Status
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Upload_Status..');
      IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_Multi_Trip_Id,
         P_Request_No,
         l_Post_Upl_Stat,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      IF l_Post_Upl_Stat IN('A','U') THEN
         p_status := 'S';
         IF p_Action_code  <> Cspks_Req_Global.p_Prddflt AND
            SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  <> Cspks_Req_Global.p_Enrich THEN
            Dbg('Calling  Fn_Query..');
            IF NOT Fn_Query(p_source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               l_Full_Data,
               l_With_Lock,
               l_Qrydata_Reqd,
               p_dedjnlon,
               l_Wrk_dedjnlon,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Query..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
         END IF;
      ELSIF l_Post_Upl_Stat ='O' THEN
         Dbg('New/First time Overides..');
         p_Status := 'O';
         RAISE E_Override_Exception;
      ELSIF l_Post_Upl_Stat = 'H'    THEN
         Dbg('Keeping on Hold..');
         RAISE E_Hold_Exception;
      ELSE
         Dbg('Not Feasible to Upload The Data...');
         RAISE E_Failure_Exception;
      END IF;
      IF p_Action_Code  = Cspks_Req_Global.p_Prddflt OR
         p_Action_Code  = Cspks_Req_Global.p_Copy OR
         SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  = Cspks_Req_Global.p_Enrich OR
         SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_SubsysPickup))  = Cspks_Req_Global.p_SubsysPickup THEN
         ROLLBACK TO Sp_Main_Dedjnlon;
      END IF;

      p_dedjnlon := l_Wrk_dedjnlon;
      g_dedjnlon := l_Wrk_dedjnlon;
      Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
      Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
      Dbg('Errors     :'||p_Err_Code);
      Dbg('Parameters :'||p_Err_Params);

      Dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Main');
         p_Status        := 'F';
         l_Post_Upl_Stat := 'F';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Main..');
         p_Status        := 'O';
         l_Post_Upl_Stat := 'O';
         IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
            Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
         END IF;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Hold_Exception THEN
         Dbg('From E_Hold_Exception of Fn_Main..');
         l_Post_Upl_Stat := 'H';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         ROLLBACK TO Sp_Main_Dedjnlon;
         IF NOT  Fn_main(p_Source,
            p_Source_operation,
            p_Function_Id,
            Cspks_Req_Global.p_Hold,
            p_Multi_Trip_Id,
            p_Request_No,
            p_dedjnlon,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;

         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Main ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Main;

   FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_dedjnlon     depks_dedjnlon_Main.ty_dedjnlon;

   BEGIN

      Dbg('In Fn_Process_Request ..');
      IF NOT  Fn_Build_Type(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Addl_Info,
         l_dedjnlon,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      IF NOT  Fn_Main(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Multi_Trip_Id,
         p_Request_No,
         l_dedjnlon,
         p_Status,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_main..');
         RETURN FALSE;
      END IF;

      p_Addl_Info := l_dedjnlon.Addl_Info;
      Cspks_Req_Global.Pr_Reset;
      Dbg('Calling  Fn_Build_Ts_List..');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         l_dedjnlon,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List..');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Cspks_Req_Global.Pr_Close_Ts;
      Dbg('Returning Success From Fn_Process_Request ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Process_Request;

END depks_dedjnlon_main;
/