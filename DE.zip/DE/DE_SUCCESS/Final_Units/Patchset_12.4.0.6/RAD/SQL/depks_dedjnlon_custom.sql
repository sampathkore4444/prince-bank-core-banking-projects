CREATE OR REPLACE PACKAGE BODY depks_dedjnlon_custom AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : depks_dedjnlon_custom.sql
     **
     ** Module     : Data Entry
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'depks_dedjnlon_Custom ==>'||p_Msg;
         Debug.Pr_Debug('DE' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,p_Function_Id,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      Dbg('In Pr_Skip_Handler..');
   END Pr_Skip_Handler;
   FUNCTION Fn_Post_Build_Type_Structure (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_dedjnlon     IN  OUT depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Build_Type_Structure..');

      Dbg('Returning Success From Fn_Post_Build_Type_Structure..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Build_Type_Structure ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Build_Type_Structure;

   FUNCTION Fn_Pre_Check_Mandatory(p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
                              p_pk_or_full        IN  VARCHAR2 DEFAULT 'FULL',
      p_dedjnlon IN OUT  depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN

      IS
   BEGIN

      Dbg('In Fn_Pre_Check_Mandatory..');

      Dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END fn_pre_check_mandatory;

   FUNCTION Fn_Post_Check_Mandatory(p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_dedjnlon IN   depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN

      IS
   BEGIN

      Dbg('In Fn_Post_Check_Mandatory..');

      Dbg('Returning Success From Fn_Post_Check_Mandatory..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Check_Mandatory;

   FUNCTION Fn_Pre_Default_And_Validate (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_dedjnlon IN   depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Default_And_Validate..');

      Dbg('Returning Success From Fn_Pre_Default_And_Validate..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Default_And_Validate;

   FUNCTION Fn_Post_Default_And_Validate (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_dedjnlon IN   depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Default_And_Validate..');

      Dbg('Returning Success From Fn_Post_Default_And_Validate');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Default_And_Validate;

   FUNCTION Fn_Pre_Resolve_Ref_Numbers     (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

   BEGIN

      Dbg('In Fn_Pre_Resolve_Ref_Numbers..');

      Dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Main.Fn_Pre_Resolve_Ref_Numbers ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Resolve_Ref_Numbers;
   FUNCTION Fn_Post_Resolve_Ref_Numbers         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon     IN OUT depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

   BEGIN

      Dbg('In Fn_Post_Resolve_Ref_Numbers..');

      Dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When others of depks_dedjnlon_Main.Fn_Post_Resolve_Ref_Numbers ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Resolve_Ref_Numbers;
   FUNCTION Fn_Pre_Product_Default (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Product_Default..');

      Dbg('Returning Success From Fn_Pre_Product_Default..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Product_Default ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Product_Default;

   FUNCTION Fn_Post_Product_Default (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Product_Default..');

      Dbg('Returning Success From Fn_Post_Product_Default..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Product_Default ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Product_Default;

   FUNCTION Fn_Pre_Unlock (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN  OUT  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Unlock..');

      Dbg('Returning Success From Fn_Pre_Unlock..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Unlock ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Unlock;

   FUNCTION Fn_Post_Unlock (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN  OUT  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Unlock');

      Dbg('Returning Success From Fn_Post_Unlock..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Unlock ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Unlock;

   FUNCTION Fn_Pre_Subsys_Pickup (p_Source    IN  VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
      p_Action_code    IN  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Subsys_Pickup..');

      Dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Subsys_Pickup ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Subsys_Pickup;

   FUNCTION Fn_Post_Subsys_Pickup (p_Source    IN  VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
      p_Action_code    IN  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Subsys_Pickup..');

      Dbg('Returning Success From Fn_Post_Subsys_Pickup..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Subsys_Pickup ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Subsys_Pickup;

   FUNCTION Fn_Pre_Enrich (p_Source    IN  VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
      p_Action_code    IN  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_wrk_dedjnlon IN OUT  depks_dedjnlon_Main.ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Enrich..');

      Dbg('Returning Success From Fn_Pre_Enrich..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Enrich ..');
         Debug.pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Enrich;

   FUNCTION Fn_Post_Enrich (p_Source    IN  VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
      p_Action_Code    IN  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Enrich..');

      Dbg('Returning Success From Fn_Post_Enrich..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Enrich ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Enrich;

   FUNCTION Fn_Pre_Upload_Db (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Upload_Db..');

      Dbg('Returning Success From Fn_Pre_Upload_Db..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Upload_Db;

   FUNCTION Fn_Post_Upload_Db (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Upload_Db..');

      Dbg('Returning Success From Fn_Post_Upload_Db..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Upload_Db;

   FUNCTION Fn_Pre_Process (p_Source    IN  VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_Id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Process..');

      Dbg('Returning Success From Fn_Pre_Process..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Process ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Process;

   FUNCTION Fn_Post_Process (p_Source    IN  VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Prev_dedjnlon IN depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT  depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Process..');

      Dbg('Returning Success From Fn_Post_Process..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Process ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Process;

   FUNCTION Fn_Pre_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd IN  VARCHAR2 ,
      p_dedjnlon IN   depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT   depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Query..');

      Dbg('Returning Success From Fn_Pre_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Pre_Query ..');
         Debug.pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Query;

   FUNCTION Fn_Post_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd IN  VARCHAR2 ,
      p_dedjnlon IN   depks_dedjnlon_Main.Ty_dedjnlon,
      p_Wrk_dedjnlon IN OUT   depks_dedjnlon_Main.Ty_dedjnlon,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      dbg('In Fn_Post_Query');

      Dbg('Returning Success From Fn_Post_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedjnlon_Custom.Fn_Post_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END fn_post_query;


END depks_dedjnlon_custom;
/