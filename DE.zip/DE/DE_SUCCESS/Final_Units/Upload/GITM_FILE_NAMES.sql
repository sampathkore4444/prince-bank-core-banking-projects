insert into GITM_FILE_NAMES (INTERFACE_CODE, FILE_NAME)
values ('DEUPLOAD', 'DE.csv');

COMMIT;
