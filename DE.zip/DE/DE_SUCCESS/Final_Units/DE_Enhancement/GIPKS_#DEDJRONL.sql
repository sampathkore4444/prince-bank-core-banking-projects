CREATE OR REPLACE PACKAGE BODY "GIPKS_#DEDJRONL" IS
  /*
  Custom package for DE incoming file. Created by Profinch.
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Created By        : Aniket
   **    Created on        : 12-Dec-2016
   **    Purpose           : Package for incoming DE files

   **    Modified By       : Aniket
   **    Modified On       : 10-Jul-2018
   **    Reason            : 1. Added code for deriving LCY amount from amount
   **                        2. Added code to check currency rounding
   **    Search Tag        : PRF_CUSTOM_04_10072018

   **    Modified By       : Kore Sampath Kumar
   **    Modified On       : 01-Aug-2019
   **    Reason            : DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code
   **    Search Tag        : DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code
   
   **    Modified By       : Kore Sampath Kumar
   **    Modified On       : 20-April-2020
   **    Reason            : To Validate account balance to prevent from posting to suspense account
   **    Search Tag        : To Validate account balance to prevent from posting to suspense account
   
   **    Modified By       : Kore Sampath Kumar
   **    Modified On       : 20-April-2020
   **    Reason            : To Validate minimum account balance at account class to prevent from posting to suspense account
   **    Search Tag        : To Validate minimum account balance at account class to prevent from posting to suspense account
   
   **    Modified By       : Kore Sampath Kumar
   **    Modified On       : 19-June-2020
   **    Reason            : DE Upload Requirement with Product Code, Segment Code
   **    Search Tag        : DE Upload Requirement with Product Code, Segment Code

    
    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('DE', 'GIPKS_#DEDJRONL-> ' || P_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_SOURCE     VARCHAR2,
                         P_ERR_CODE   VARCHAR2,
                         P_ERR_PARAMS VARCHAR2) IS
    L_FUNCTION_ID SMTB_MENU.FUNCTION_ID%TYPE := 'GIDIFPRS';
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 L_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  --Below function checks the accounting and marks the auth status accordingly
  --This is added to correct the auth status in all places even in case of failures
  PROCEDURE PR_CHK_UPD_AUTH(P_BATCH_NO IN VARCHAR2) IS
    L_BATCH_MASTER_AUTH VARCHAR2(1);
    L_UPLD_MASTER_AUTH  VARCHAR2(1);
    L_ACTB_AUTH         NUMBER;
    L_USER_ID           VARCHAR2(12);
    L_DATE              DATE;
  BEGIN
    L_DATE := STPKS_UPLOAD.FN_DATE_TIME(GLOBAL.APPLICATION_DATE);

    SELECT AUTH_STAT
      INTO L_BATCH_MASTER_AUTH
      FROM DETBS_BATCH_MASTER
     WHERE BATCH_NO = P_BATCH_NO
       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

    DBG('THE AUTH IN BATCH MASTER IS :' || L_BATCH_MASTER_AUTH);

    SELECT AUTH_STAT
      INTO L_UPLD_MASTER_AUTH
      FROM DETBS_UPLOAD_MASTER
     WHERE BATCH_NO = P_BATCH_NO
       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

    DBG('THE AUTH IN UPLOAD MASTER IS :' || L_UPLD_MASTER_AUTH);

    SELECT COUNT(1)
      INTO L_ACTB_AUTH
      FROM ACTBS_DAILY_LOG
     WHERE TRN_REF_NO LIKE GLOBAL.CURRENT_BRANCH || P_BATCH_NO || '%'
       AND BATCH_NO = P_BATCH_NO
       AND NVL(DELETE_STAT, 'X') <> 'D';

    DBG('THE COUNT IN ACTB IS :' || L_ACTB_AUTH);
    IF L_ACTB_AUTH > 0 THEN
      SELECT COUNT(1)
        INTO L_ACTB_AUTH
        FROM ACTBS_DAILY_LOG
       WHERE TRN_REF_NO LIKE GLOBAL.CURRENT_BRANCH || P_BATCH_NO || '%'
         AND BATCH_NO = P_BATCH_NO
         AND NVL(DELETE_STAT, 'X') <> 'D'
         AND AUTH_STAT = 'U';

      DBG('THE UNAUTH IN ACTB IS :' || L_ACTB_AUTH);

      IF L_ACTB_AUTH > 0 THEN
        DBG('UNAUTH ENTRIES EXISTS SO WILL MARK THE BATCH AS UNAUTH');
        IF NVL(L_UPLD_MASTER_AUTH, 'X') = 'A' THEN
          DBG('MARKING UPLOAD MASTER TO UNAUTH');
          UPDATE DETBS_UPLOAD_MASTER
             SET AUTH_STAT        = 'U',
                 CHECKER_ID       = NULL,
                 CHECKER_DT_STAMP = NULL
           WHERE BATCH_NO = P_BATCH_NO
             AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
        END IF;

        IF NVL(L_BATCH_MASTER_AUTH, 'X') = 'A' THEN
          DBG('MARKING BATCH MASTER TO UNAUTH');
          UPDATE DETBS_BATCH_MASTER
             SET AUTH_STAT          = 'U',
                 LAST_AUTH_ID       = NULL,
                 LAST_AUTH_DT_STAMP = NULL
           WHERE BATCH_NO = P_BATCH_NO
             AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
        END IF;
      ELSE
        DBG('ALL ENTRIES AUTHORIZED SO WILL MARK THE BATCH AS AUTH');

        SELECT AUTH_ID
          INTO L_USER_ID
          FROM ACTBS_DAILY_LOG
         WHERE TRN_REF_NO LIKE GLOBAL.CURRENT_BRANCH || P_BATCH_NO || '%'
           AND BATCH_NO = P_BATCH_NO
           AND NVL(DELETE_STAT, 'X') <> 'D'
           AND AUTH_STAT = 'A'
           AND ROWNUM = 1;

        DBG('AUTHORIZER IS :' || L_USER_ID);

        IF NVL(L_UPLD_MASTER_AUTH, 'X') = 'U' THEN
          DBG('MARKING UPLOAD MASTER TO AUTH');
          UPDATE DETBS_UPLOAD_MASTER
             SET AUTH_STAT        = 'A',
                 CHECKER_ID       = L_USER_ID,
                 CHECKER_DT_STAMP = L_DATE
           WHERE BATCH_NO = P_BATCH_NO
             AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
        END IF;

        IF NVL(L_BATCH_MASTER_AUTH, 'X') = 'U' THEN
          DBG('MARKING BATCH MASTER TO AUTH');
          UPDATE DETBS_BATCH_MASTER
             SET AUTH_STAT          = 'A',
                 LAST_AUTH_ID       = L_USER_ID,
                 LAST_AUTH_DT_STAMP = L_DATE
           WHERE BATCH_NO = P_BATCH_NO
             AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
        END IF;
      END IF;
    ELSE
      DBG('NO ACCOUTING PASSED SO WILL MARK EVERYTHING AS UNAUTH');

      UPDATE DETBS_UPLOAD_MASTER
         SET AUTH_STAT = 'U', CHECKER_ID = NULL, CHECKER_DT_STAMP = NULL
       WHERE BATCH_NO = P_BATCH_NO
         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

      UPDATE DETBS_BATCH_MASTER
         SET AUTH_STAT          = 'U',
             LAST_AUTH_ID       = NULL,
             LAST_AUTH_DT_STAMP = NULL
       WHERE BATCH_NO = P_BATCH_NO
         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error during update of auth status');
  END PR_CHK_UPD_AUTH;

  FUNCTION FN_VALIDATE_AND_REPLACE_ACC(P_BRANCH     STTBS_ACCOUNT.BRANCH_CODE%TYPE,
                                       P_AC_NO      STTBS_ACCOUNT.AC_GL_NO%TYPE,
                                       P_DR_CR_IND  DETBS_UPLOAD_DETAIL.DR_CR%TYPE,
                                       P_LCY        STTMS_BRANCH.BRANCH_LCY%TYPE,
                                       P_AC_CCY     STTBS_ACCOUNT.AC_GL_CCY %TYPE,
                                       P_VALUE_DATE DETBS_UPLOAD_DETAIL.VALUE_DATE%TYPE,
                                       P_SUS_AC_NO  IN OUT STTBS_ACCOUNT.AC_GL_NO %TYPE,
                                       P_TRN_CODE   DETBS_UPLOAD_DETAIL.TXN_CODE%TYPE,
                                       P_INSTR_CODE DETBS_UPLOAD_DETAIL.INSTRUMENT_NO%TYPE,
                                       P_AMT        DETBS_UPLOAD_DETAIL.AMOUNT%TYPE,
                                       P_ERR_PARAM  IN OUT GITM_UPLOAD_MASTER.ERROR_PARAM%TYPE)
    RETURN BOOLEAN IS
    L_ACCREC        STTBS_ACCOUNT%ROWTYPE;
    L_SUS_AC_NO     STTBS_ACCOUNT.AC_GL_NO%TYPE;
    L_ACC_CUST_ACCT STTMS_CUST_ACCOUNT.LAST_CCY_CONV_DATE%TYPE;
    L_POST_TO_SUS   BOOLEAN := FALSE;
    L_TYPE          VARCHAR2(1);
    L_CHQ           VARCHAR2(1);
    L_STOP_PMT      VARCHAR2(1);
    L_CHQ_MISS      VARCHAR2(1);
    L_AVL_BAL       NUMBER;
    L_ETYPE         ERTB_MSGS.TYPE%TYPE;
  
  --To Validate minimum account balance at account class to prevent from posting to suspense account starts
    L_BALREC          STTMS_ACCLS_MIN_BAL_DET%ROWTYPE;
    L_MINBALANCE      STTMS_ACCLS_MIN_BAL_DET.MIN_BALANCE%TYPE;
    L_ERROR_CODE_TYPE ERTBS_MSGS.TYPE%TYPE;
  L_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
    --To Validate minimum account balance at account class to prevent from posting to suspense account ends


  BEGIN
    P_ERR_PARAM := NULL;
    DBG(' inside Fn_Validate_And_Replace_Acc ');
    --Verify Account, if invalid then replace with Suspense Account
    IF NOT CVPKS_UTILS.GET_STTB_ACC(P_BRANCH, P_AC_NO, L_ACCREC) THEN
      DBG('Failed to get account record');
      DBG('l_Accrec.Branch_Code ' || L_ACCREC.BRANCH_CODE);
      DBG('p_Branch : ' || P_BRANCH);
      BEGIN
        SELECT DECODE(P_DR_CR_IND,
                      'D',
                      DECODE(P_AC_CCY, P_LCY, REAL_LCY_DR_GL, REAL_FCY_DR_GL),
                      'C',
                      DECODE(P_AC_CCY, P_LCY, REAL_LCY_CR_GL, REAL_FCY_CR_GL))
          INTO L_SUS_AC_NO
          FROM DETMS_UPLOAD_SOURCE_PREF
         WHERE SOURCE_CODE = 'DEUPLD'
           AND RECORD_STAT = 'O'
           AND ONCE_AUTH = 'Y';

        DBG('Selected account as : ' || L_SUS_AC_NO);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          SELECT DECODE(P_AC_CCY, P_LCY, SUSPENSE_GLSL, SUSPENSE_GL_FCY)
            INTO L_SUS_AC_NO
            FROM STTMS_BRANCH
           WHERE BRANCH_CODE = P_BRANCH;

          DBG('Selected account as : ' || L_SUS_AC_NO);
      END;
      IF NVL(L_ACCREC.BRANCH_CODE, '***') <> P_BRANCH THEN
        P_SUS_AC_NO := L_SUS_AC_NO;
        P_ERR_PARAM := 'Wrong Branch Code for account';
        RETURN TRUE;
      END IF;
      P_SUS_AC_NO := L_SUS_AC_NO;
      P_ERR_PARAM := 'Failed to get Account';
      RETURN TRUE;
    END IF;
  
  --Get Account
    BEGIN
      SELECT *
        INTO L_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_AC_NO;
    EXCEPTION
      WHEN OTHERS THEN
        L_CUST_ACCOUNT := NULL;
    END;
  
    --CHECK FOR ACCOUNT BALANCE
    IF ((P_DR_CR_IND = 'D' AND L_ACCREC.AC_OR_GL = 'A' AND P_AMT > 0)
      OR (P_DR_CR_IND = 'C' AND L_ACCREC.AC_OR_GL = 'A' AND P_AMT < 0)) AND L_CUST_ACCOUNT.ACCOUNT_TYPE IN ('S','U')
    THEN
      DBG('DEBIT TRANSACTION NEED TO CHECK THE ACCOUNT BALANCE');
      IF NOT ACPKS_MISC.FN_GETAVLBAL(P_BRANCH
                                    ,P_AC_NO
                                    ,L_AVL_BAL
                                    ,'Y'
                                    ,'Y') THEN
        DBG('FAILED IN AVL BALANCE CHECK');
        P_ERR_PARAM := 'Failed in balance check';
        RETURN FALSE;
      ELSE
        IF L_AVL_BAL < abs(P_AMT) THEN
          DBG('available balance is less!! ' || L_AVL_BAL || '~' || P_AMT);
       --To Validate account balance to prevent from posting to suspense account starts
          RETURN FALSE;
          --To Validate account balance to prevent from posting to suspense account ends

        END IF;
      END IF;
    END IF;
  
  
  --To Validate minimum account balance at account class to prevent from posting to suspense account starts
    IF (P_DR_CR_IND = 'D' AND L_ACCREC.AC_OR_GL = 'A' AND P_AMT > 0) AND L_CUST_ACCOUNT.ACCOUNT_TYPE IN ('S','U') THEN
      DBG('in Min Bal check ');
      BEGIN
      
        IF NOT CVPKS_UTILS.FN_GET_ACC_MIN_BAL(P_BRANCH, P_AC_NO, L_BALREC) THEN
          DBG('No Minimum Balance Record Found');
          --RETURN;
        END IF;
      
        L_MINBALANCE := NVL(L_BALREC.MIN_BALANCE, 0);
        DBG('Min Bal check ' || TO_CHAR(L_MINBALANCE));
        DBG('L_AVL_BAL=' || L_AVL_BAL);
        DBG('P_AMT=' || P_AMT);
      
        IF (L_AVL_BAL - P_AMT) < L_MINBALANCE THEN
        
          IF L_MINBALANCE > 0 THEN
            L_ERROR_CODE_TYPE := OVPKSS.FN_GETTYPE('AC-OVD05');
          END IF;
          DBG(' l_Error_Code_Type ' || L_ERROR_CODE_TYPE);
        
          IF L_ERROR_CODE_TYPE = 'E' THEN
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      EXCEPTION
      
        WHEN OTHERS THEN
          DBG(SQLERRM || ' in Min bal for Aclass');
      END;
    END IF;
    --To Validate minimum account balance at account class to prevent from posting to suspense account ends
  
  
    --Checking for Real and Contingent GL
    IF L_ACCREC.GL_CATEGORY IN ('1', '2', '3', '4') THEN
      L_TYPE := 'R';
    ELSE
      L_TYPE := 'X';
    END IF;
    DBG('l_Accrec.Branch_Code ' || L_ACCREC.BRANCH_CODE);
    DBG('p_Branch : ' || P_BRANCH);
    DBG('l_Accrec.account ' || L_ACCREC.AC_GL_NO);
    L_ETYPE := 'X';
    --Account Close Check
    IF L_ACCREC.AC_GL_REC_STATUS IN ('C', 'X') THEN
      L_POST_TO_SUS := TRUE;
      P_ERR_PARAM   := 'Account Closed';
    END IF;
    --No debit allowed check
    IF (P_DR_CR_IND = 'D' AND NVL(L_ACCREC.AC_STAT_NO_DR, 'n') = 'y') THEN
      L_ETYPE := 'X';
      L_ETYPE := OVPKS.FN_GETTYPE('DE-UPLD-24');

      IF L_ETYPE IN ('E', 'X') THEN
        L_POST_TO_SUS := TRUE;
        P_ERR_PARAM   := 'NO Debit allowed';
      END IF;
    END IF;
    --No Credit Allowed Check
    IF (P_DR_CR_IND = 'C' AND NVL(L_ACCREC.AC_STAT_NO_CR, 'N') = 'Y') THEN
      L_ETYPE := 'X';
      L_ETYPE := OVPKS.FN_GETTYPE('DE-UPLD-25');

      IF L_ETYPE IN ('E', 'X') THEN
        L_POST_TO_SUS := TRUE;
        P_ERR_PARAM   := 'NO Credit allowed';
      END IF;
    END IF;
    --Account Frozen Check
    IF NVL(L_ACCREC.AC_STAT_FROZEN, 'N') = 'Y' THEN
      L_ETYPE := 'X';
      L_ETYPE := OVPKS.FN_GETTYPE('DE-UPLD-22');

      IF L_ETYPE IN ('E', 'X') THEN
        L_POST_TO_SUS := TRUE;
        P_ERR_PARAM   := 'Account Frozen';
      END IF;
    END IF;
    --Account Stat Dormant Check
    IF NVL(L_ACCREC.AC_STAT_DORMANT, 'N') = 'Y' THEN
      L_ETYPE := 'X';
      L_ETYPE := OVPKS.FN_GETTYPE('DE-UPLD-21');

      IF L_ETYPE IN ('E', 'X') THEN
        L_POST_TO_SUS := TRUE;
        P_ERR_PARAM   := 'Account Dormant';
      END IF;
    END IF;
    --DE Post Allowed Check
    IF L_ACCREC.GL_STAT_DE_POST = 'N' THEN
      L_ETYPE := 'X';
      L_ETYPE := OVPKS.FN_GETTYPE('DE-UPLD-23');

      IF L_ETYPE IN ('E', 'X') THEN
        L_POST_TO_SUS := TRUE;
        P_ERR_PARAM   := 'DE Post not allowed';
      END IF;
    END IF;
    --CCY Mismatch Check
    IF L_ACCREC.AC_GL_CCY <> P_AC_CCY THEN
      L_POST_TO_SUS := TRUE;
      P_ERR_PARAM   := 'CCY mismatch';
    END IF;
    --Conversion Date Check
    IF L_ACCREC.AC_OR_GL = 'A' AND NVL(L_ACCREC.AC_NATIVE, 'FC') = 'FC' THEN
      SELECT LAST_CCY_CONV_DATE
        INTO L_ACC_CUST_ACCT
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_BRANCH
         AND CUST_AC_NO = P_AC_NO;

      IF L_ACC_CUST_ACCT IS NOT NULL THEN
        DBG('The conv_date value in record is ' || L_ACC_CUST_ACCT);
        IF TO_CHAR(P_VALUE_DATE, 'YYYYDDD') <
           TO_CHAR(L_ACC_CUST_ACCT, 'YYYYDDD') THEN
          L_POST_TO_SUS := TRUE;
          P_ERR_PARAM   := 'Value Date less than conversion date';
        END IF;
      END IF;
    END IF;
    --CCY Restriction / Branch Restriction / Account Block check for GL
    IF L_ACCREC.AC_OR_GL = 'G' THEN
      IF (NVL(L_ACCREC.GL_CCY_RES, 'X') = 'F' AND P_AC_CCY = P_LCY) OR
         (NVL(L_ACCREC.GL_CCY_RES, 'X') = 'S' AND
         L_ACCREC.AC_GL_CCY <> P_AC_CCY) THEN
        DBG('Failed In Currency Restriction');
        L_POST_TO_SUS := TRUE;
        P_ERR_PARAM   := 'CCY restriction problem';
      END IF;
      IF (L_ACCREC.GL_BRANCH_RES = 'H' AND P_BRANCH <> GLOBAL.HEAD_OFFICE) OR
         (L_ACCREC.GL_CCY_RES = 'B' AND P_BRANCH = GLOBAL.HEAD_OFFICE) THEN
        DBG('Failed In Branch Restriction');
        L_POST_TO_SUS := TRUE;
        P_ERR_PARAM   := 'Branch Restriction';
      END IF;
      IF NVL(L_ACCREC.GL_STAT_BLOCKED, 'N') = 'Y' THEN
        DBG('GL Blocked');
        L_POST_TO_SUS := TRUE;
        P_ERR_PARAM   := 'Account Blocked';
      END IF;
    END IF;
    --Cheque Mandatory for GL
    IF L_ACCREC.AC_OR_GL = 'G' THEN
      BEGIN
        SELECT CHEQUE_MANDATORY
          INTO L_CHQ
          FROM STTMS_TRN_CODE
         WHERE TRN_CODE = P_TRN_CODE
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';

        IF (L_ACCREC.GL_ACLASS_TYPE IN ('2', '3') OR (L_CHQ = 'Y')) AND
           P_INSTR_CODE IS NULL THEN
          DBG('Exceptional condition: Instrument No is NULL for a Misc Dr/Cr Trn ');
          L_POST_TO_SUS := TRUE;
          P_ERR_PARAM   := 'Instrument Code is mandatory';
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_CHQ := NULL;
      END;
    END IF;
    BEGIN
      SELECT CHEQUE_MANDATORY
        INTO L_CHQ
        FROM STTMS_TRN_CODE
       WHERE TRN_CODE = P_TRN_CODE;

    EXCEPTION
      WHEN OTHERS THEN
        L_CHQ := 'N';
    END;
    --Stop Payment Check for Account
    IF L_ACCREC.AC_OR_GL = 'A' AND L_CHQ = 'Y' THEN
      DBG('Stop payment validation ');
      BEGIN
        SELECT 'X'
          INTO L_STOP_PMT
          FROM CATMS_STOP_PAYMENTS
         WHERE BRANCH = L_ACCREC.BRANCH_CODE
           AND ACCOUNT = L_ACCREC.AC_GL_NO
           AND STOP_PAYMENT_TYPE = 'C'
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O'
           AND TO_NUMBER(P_INSTR_CODE) BETWEEN TO_NUMBER(START_CHECK_NO) AND
               TO_NUMBER(END_CHECK_NO);

        DBG(' Stop Payment ' || L_STOP_PMT);
        IF NVL(L_STOP_PMT, 'XX') = 'X' THEN
          DBG(' Check marked for Stop Payment');
          L_POST_TO_SUS := TRUE;
          P_ERR_PARAM   := 'Check marked for Stop Payment';
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(' No Stop Payment');
          L_POST_TO_SUS := FALSE;
      END;
    END IF;
    --Cheque Series Missing Check for Account
    IF L_CHQ = 'Y' AND L_ACCREC.AC_OR_GL = 'A' THEN
      BEGIN
        DBG(' Cheque missmatch validation');
        SELECT 'X'
          INTO L_CHQ_MISS
          FROM CATMS_CHECK_DETAILS
         WHERE BRANCH = L_ACCREC.BRANCH_CODE
           AND ACCOUNT = L_ACCREC.AC_GL_NO
           AND TO_NUMBER(CHECK_NO) = TO_NUMBER(P_INSTR_CODE)
           AND MOD_NO =
               (SELECT MAX(MOD_NO)
                  FROM CATMS_CHECK_DETAILS
                 WHERE BRANCH = L_ACCREC.BRANCH_CODE
                   AND ACCOUNT = L_ACCREC.AC_GL_NO
                   AND TO_NUMBER(CHECK_NO) = TO_NUMBER(P_INSTR_CODE));

        DBG(' Cheque missmatch l_chq_miss = ' || L_CHQ_MISS);
      EXCEPTION
        WHEN OTHERS THEN
          DBG(' Check series missing');
          L_POST_TO_SUS := TRUE;
          P_ERR_PARAM   := ' Check series missing';
      END;
    END IF;
    --Post to Suspense Check
    IF L_POST_TO_SUS THEN
      IF L_TYPE = 'R' THEN
        BEGIN
          SELECT DECODE(P_DR_CR_IND,
                        'D',
                        DECODE(P_AC_CCY,
                               P_LCY,
                               REAL_LCY_DR_GL,
                               REAL_FCY_DR_GL),
                        'C',
                        DECODE(P_AC_CCY,
                               P_LCY,
                               REAL_LCY_CR_GL,
                               REAL_FCY_CR_GL))
            INTO L_SUS_AC_NO
            FROM DETMS_UPLOAD_SOURCE_PREF
           WHERE SOURCE_CODE = 'DEUPLD'
             AND RECORD_STAT = 'O'
             AND ONCE_AUTH = 'Y';

          DBG('Selected account as : ' || L_SUS_AC_NO);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT DECODE(P_AC_CCY, P_LCY, SUSPENSE_GLSL, SUSPENSE_GL_FCY)
              INTO L_SUS_AC_NO
              FROM STTMS_BRANCH
             WHERE BRANCH_CODE = P_BRANCH;

            DBG('Selected account as : ' || L_SUS_AC_NO);
        END;
      ELSIF L_TYPE = 'X' THEN
        BEGIN
          SELECT DECODE(P_DR_CR_IND,
                        'D',
                        DECODE(P_AC_CCY,
                               P_LCY,
                               CONTINGENT_LCY_DR_GL,
                               CONTINGENT_FCY_DR_GL),
                        'C',
                        DECODE(P_AC_CCY,
                               P_LCY,
                               CONTINGENT_LCY_CR_GL,
                               CONTINGENT_FCY_CR_GL))
            INTO L_SUS_AC_NO
            FROM DETMS_UPLOAD_SOURCE_PREF
           WHERE SOURCE_CODE = 'DEUPLD'
             AND RECORD_STAT = 'O'
             AND ONCE_AUTH = 'Y';

          DBG('Selected account as : ' || L_SUS_AC_NO);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT DECODE(P_AC_CCY,
                          P_LCY,
                          CONTINGENT_SUSPENSE_GLSL,
                          CONT_SUSPENSE_GL_FCY)
              INTO L_SUS_AC_NO
              FROM STTMS_BRANCH
             WHERE BRANCH_CODE = P_BRANCH;

            DBG('Selected account as : ' || L_SUS_AC_NO);
        END;
      END IF;
      P_SUS_AC_NO := L_SUS_AC_NO;
    END IF;
    DBG('sucess return from  Fn_Validate_And_Replace_Acc ' || P_SUS_AC_NO);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of validate and replace account -' || SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_AND_REPLACE_ACC;

  FUNCTION FN_UPLOAD(P_INTERFACE_CODE IN VARCHAR2,
                     P_FILE_NAME      IN VARCHAR2,
                     P_PHY_FILE_NAME  IN VARCHAR2,
                     P_PROCESSREFNO   IN VARCHAR2,
                     P_PROCESS_NO     IN NUMBER,
                     P_ERR_CODE       IN OUT VARCHAR2,
                     P_ERROR_PARAMS   IN OUT VARCHAR2,
                     P_STATUS         IN OUT VARCHAR2) RETURN BOOLEAN IS
    TXNREF VARCHAR2(20);
    E_FAILURE_EXCEPTION EXCEPTION;
    P_FORMAT_DETAILS GITM_FORMAT_DEFINITION%ROWTYPE;
    P_COMP_DETAILS   TY_COMP_DETAILS;
    P_FIELD_DETAILS  TY_COMP_FIELDS_DETAILS;
    CURSOR CUR_COMPONENTS IS
      SELECT *
        FROM GITM_COMPONENT_LINKAGE
       WHERE INTERFACE_CODE = P_INTERFACE_CODE
         AND COMPONENT_TYPE = 'BDY'
       ORDER BY SERIAL_NO;

    CURSOR CUR_COMPONENT_FIELDS(P_COMPONENT_NAME IN VARCHAR2) IS
      SELECT *
        FROM GITM_COMPONENT_FIELD_LINKAGE
       WHERE INTERFACE_CODE = P_INTERFACE_CODE
         AND COMPONENT_NAME = P_COMPONENT_NAME
         AND FIELD_TYPE = 'M'
         AND COLUMN_NAME IS NOT NULL
       ORDER BY COMPONENT_NAME, COLUMN_NAME;
    TYPE JRN_CUR IS REF CURSOR;
    JRN                    JRN_CUR;
    L_REF_CURSOR           VARCHAR2(32767) := 'SELECT  ';
    P_SOURCE               VARCHAR2(100);
    P_ACTION_CODE          VARCHAR2(100);
    TYP_SINGLEJRNL_LOG     DETBS_JRNL_LOG%ROWTYPE;
    TYP_DETB_UPLOAD_DETAIL DETB_UPLOAD_DETAIL%ROWTYPE;
    TYP_DEVWS_JRNL_LOG     DEVW_JRNL_LOG%ROWTYPE;
    TYP_DETB_MASTER        DETB_BATCH_MASTER%ROWTYPE;
  --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code starts
    l_gitm_upload_master gitm_upload_master%ROWTYPE;
    TYP_UDTBS_UPLOAD_DETAIL UDTBS_UPLOAD_DETAIL%ROWTYPE;
    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code ends
    L_BATCH_NO             VARCHAR2(4);

    P_ERR_TBL      OVPKS.TBL_ERROR;
    I              NUMBER;
    J              NUMBER;
    PREFERENCENO   DETBS_JRNL_LOG.REFERENCE_NO%TYPE;
    L_SOURCE_CODE  VARCHAR2(20) := NULL;
    L_SUS_AC_NO    STTB_ACCOUNT.AC_GL_NO%TYPE := NULL;
    P_ERR_PARAM    GITM_UPLOAD_MASTER.ERROR_PARAM%TYPE := '';
    L_SEQ          DETBS_UPLOAD_EXCEPTIONS.SEQ_NO%TYPE := 0;
    L_INGOVD       VARCHAR2(1) := 'Y';
    L_MIS_REQUIRED VARCHAR2(1) := 'N';
    L_AUTO_AUTH    VARCHAR2(1) := 'N';
    L_UDF_UPLOAD   VARCHAR2(1) := 'Y';  --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code changed to Y from N as we are using UDF
    L_BALANCING    VARCHAR2(1) := 'Y';
    P_TOTAL_ENT    NUMBER;
    P_ENT_UPLOADED NUMBER;
    P_ENT_REJECTED NUMBER;
    L_FIRST_TIME   NUMBER := 0;
    L_COUNT        NUMBER;
    L_COUNT_JRNL   NUMBER;
    L_TMP_AMOUNT   NUMBER; --PRF_CUSTOM_04_10072018 changes

    CURSOR CR_RECORD_REFERENCE IS
      SELECT RECORD_REFERENCE
        FROM GITM_UPLOAD_MASTER
       WHERE INTERFACE_CODE = P_INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
         AND PROCESS_NO = P_PROCESS_NO
         AND PHY_FILE_NAME = P_PHY_FILE_NAME
         AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
         AND STATUS = 'U'
       ORDER BY RECORD_REFERENCE;

  BEGIN
    DBG('P_FILE_NAME :' || P_FILE_NAME);
    DBG('PHY FILE NAME :' || P_PHY_FILE_NAME);
    BEGIN
      DBG('XYZ 1' || P_INTERFACE_CODE || '-' || P_PROCESS_NO);
      SELECT EXTERNAL_SYSTEM
        INTO L_SOURCE_CODE
        FROM GITM_INTERFACE_DEFINITION
       WHERE INTERFACE_CODE = P_INTERFACE_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('INTERFACE CODE NOT FOUND!!');
        RETURN FALSE;
    END;

    BEGIN
      DBG('XYZ 2');
      SELECT *
        INTO P_FORMAT_DETAILS
        FROM GITM_FORMAT_DEFINITION
       WHERE INTERFACE_CODE = P_INTERFACE_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed To Query gitm_format_definition ' || SQLERRM);
    END;

    DBG('XYZ 3' || P_FORMAT_DETAILS.EXTERNAL_SYSTEM);

    SELECT DECODE(G.UPLOADED_STATUS, 'A', 'Y', 'U', 'N', 'N')
      INTO L_AUTO_AUTH
      FROM COTM_SOURCE_PREF G
     WHERE G.SOURCE_CODE = P_FORMAT_DETAILS.EXTERNAL_SYSTEM
       AND G.MODULE_CODE = 'DE';

    IF NVL(L_AUTO_AUTH, 'N') = 'Y' THEN
      CVPKS_FCJ_CVDUPLOD.CVD_MULTIAUTH_FLAG := 'Y';
    END IF;

    OPEN CUR_COMPONENTS;
    FETCH CUR_COMPONENTS BULK COLLECT
      INTO P_COMP_DETAILS;

    DBG(' P_PROCESSREFNO ' || P_PROCESSREFNO);
    DBG(' P_PROCESS_NO ' || P_PROCESS_NO);
  
   --To Validate account balance to prevent from posting to suspense account starts
    SAVEPOINT ORIGINAL;
    --To Validate account balance to prevent from posting to suspense account ends
 
 
    FOR RECORD_REF IN CR_RECORD_REFERENCE LOOP
      DBG(' Entering Record Reference loop ' ||
          RECORD_REF.RECORD_REFERENCE);
      TXNREF := RECORD_REF.RECORD_REFERENCE;

      FOR I IN P_COMP_DETAILS.FIRST .. P_COMP_DETAILS.LAST LOOP
        IF P_COMP_DETAILS(I).COMPONENT_TYPE = 'BDY' THEN
          OPEN CUR_COMPONENT_FIELDS(P_COMP_DETAILS(I).COMPONENT_NAME);
          FETCH CUR_COMPONENT_FIELDS BULK COLLECT
            INTO P_FIELD_DETAILS;

          FOR J IN P_FIELD_DETAILS.FIRST .. P_FIELD_DETAILS.LAST LOOP
            IF P_FIELD_DETAILS(J).DATA_TYPE = 'VARCHAR2' THEN
              L_REF_CURSOR := L_REF_CURSOR || CHR(10) || 'NVL(trim(U.FLD' || P_FIELD_DETAILS(J)
                             .SERIAL_NO || '),''' || P_FIELD_DETAILS(J)
                             .DEFAULT_PARAMETER || ''') ' || P_FIELD_DETAILS(J)
                             .COLUMN_NAME;
            END IF;
            IF P_FIELD_DETAILS(J).DATA_TYPE = 'DATE' THEN
              L_REF_CURSOR := L_REF_CURSOR || CHR(10) ||
                              'NVL(trim(TO_DATE(U.FLD' || P_FIELD_DETAILS(J)
                             .SERIAL_NO || ',' || '''' ||
                              P_FORMAT_DETAILS.DATE_FORMAT || '''' ||
                              ')),''' || P_FIELD_DETAILS(J)
                             .DEFAULT_PARAMETER || ''')  ' || P_FIELD_DETAILS(J)
                             .COLUMN_NAME;
            END IF;
            IF P_FIELD_DETAILS(J).DATA_TYPE = 'NUMBER' THEN
              L_REF_CURSOR := L_REF_CURSOR || CHR(10) ||
                              'NVL(trim(TO_NUMBER(U.FLD' || P_FIELD_DETAILS(J)
                             .SERIAL_NO || ')), ''' || P_FIELD_DETAILS(J)
                             .DEFAULT_PARAMETER || ''')   ' || P_FIELD_DETAILS(J)
                             .COLUMN_NAME;
            END IF;
            IF J <> P_FIELD_DETAILS.LAST THEN
              L_REF_CURSOR := L_REF_CURSOR || ' ,';
            END IF;
          END LOOP;

          IF CUR_COMPONENT_FIELDS%ISOPEN THEN
            DBG('Closing CUR_COMPONENTS');
            CLOSE CUR_COMPONENT_FIELDS;
          END IF;

      --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code Starts
          /*L_REF_CURSOR := L_REF_CURSOR || ' FROM GITM_UPLOAD_MASTER U' ||
                          CHR(10) || 'WHERE U.INTERFACE_CODE = ' || '''' ||
                          P_INTERFACE_CODE || '''' || ' and ' || CHR(10) ||
                          'U.FILE_NAME = ' || '''' || P_FILE_NAME || '''' ||
                          ' and ' || CHR(10) || 'U.TARGET_TABLE = ' || '''' ||
                          'DETB_UPLOAD_DETAIL' || '''' || ' and' || CHR(10) ||
                          'U.PROCESS_NO = ' || P_PROCESS_NO || ' and' ||
                          CHR(10) || 'U.RECORD_REFERENCE = ' || '''' ||
                          RECORD_REF.RECORD_REFERENCE || '''';*/

      --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code Ends

       --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code Starts
           L_REF_CURSOR := L_REF_CURSOR || ' FROM GITM_UPLOAD_MASTER U' ||
                          CHR(10) || 'WHERE U.INTERFACE_CODE = ' || '''' ||
                          P_INTERFACE_CODE || '''' || ' and ' || CHR(10) ||
                          'U.FILE_NAME = ' || '''' || P_FILE_NAME || '''' ||
                          ' and ' || CHR(10) || 'U.TARGET_TABLE IN (' || '''' ||
                          'DETB_UPLOAD_DETAIL' || '''' || ' , ' || '''' ||
                          'UDTBS_UPLOAD_DETAIL' || '''' || ')' || ' and' || CHR(10) ||
                          'U.PROCESS_NO = ' || P_PROCESS_NO || ' and' ||
                          CHR(10) || 'U.RECORD_REFERENCE = ' || '''' ||
                          RECORD_REF.RECORD_REFERENCE || '''';

          --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code Ends

          DBG('l_ref_cursor >>>>>> ' || L_REF_CURSOR);

          BEGIN
            OPEN JRN FOR L_REF_CURSOR;

            TYP_DETB_UPLOAD_DETAIL := NULL;
            FETCH JRN
              INTO TYP_DETB_UPLOAD_DETAIL.ACCOUNT,
                   TYP_DETB_UPLOAD_DETAIL.ACCOUNT_BRANCH,
                   TYP_DETB_UPLOAD_DETAIL.ADDL_TEXT,
                   TYP_DETB_UPLOAD_DETAIL.AMOUNT,
                   TYP_DETB_UPLOAD_DETAIL.BATCH_NO,
                   TYP_DETB_UPLOAD_DETAIL.BRANCH_CODE,
                   TYP_DETB_UPLOAD_DETAIL.CCY_CD,
                   TYP_DETB_UPLOAD_DETAIL.CURR_NO,
                   TYP_DETB_UPLOAD_DETAIL.DR_CR,
                   TYP_DETB_UPLOAD_DETAIL.EXTERNAL_REF_NO,
                   TYP_UDTBS_UPLOAD_DETAIL.FIELD_VAL_1, --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code
                   TYP_UDTBS_UPLOAD_DETAIL.FIELD_VAL_2, --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code
                   TYP_UDTBS_UPLOAD_DETAIL.FIELD_VAL_3, --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code
                   TYP_UDTBS_UPLOAD_DETAIL.FIELD_VAL_4, --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code
                   TYP_UDTBS_UPLOAD_DETAIL.FIELD_VAL_5, --DE Upload Requirement with Product Code, Segment Code
                   TYP_UDTBS_UPLOAD_DETAIL.FIELD_VAL_6, --DE Upload Requirement with Product Code, Segment Code
                   TYP_DETB_UPLOAD_DETAIL.FIN_CYCLE,
                   TYP_DETB_UPLOAD_DETAIL.INITIATION_DATE,
                   TYP_DETB_UPLOAD_DETAIL.INSTRUMENT_NO,
                   TYP_DETB_UPLOAD_DETAIL.LCY_EQUIVALENT,
                   TYP_DETB_UPLOAD_DETAIL.MIS_CODE,
                   TYP_DETB_UPLOAD_DETAIL.PERIOD_CODE,
                   TYP_DETB_UPLOAD_DETAIL.RELATED_ACCOUNT,
                   TYP_DETB_UPLOAD_DETAIL.RELATED_REF,
                   TYP_DETB_UPLOAD_DETAIL.REL_CUST,
                   TYP_DETB_UPLOAD_DETAIL.SOURCE_CODE,
                   TYP_DETB_UPLOAD_DETAIL.TXN_CODE,
                   TYP_DETB_UPLOAD_DETAIL.UPLOAD_STAT,
                   TYP_DETB_UPLOAD_DETAIL.VALUE_DATE;

            CLOSE JRN;

            IF TYP_DETB_UPLOAD_DETAIL.BATCH_NO IS NULL THEN
              DBG('BATCH NO IS NULL.');
              IF L_BATCH_NO IS NULL THEN
                DBG('BATCH NUMBER WILL BE DERIVED');
                L_BATCH_NO := DEPKS_UPLOAD.FN_FREE_BATCH(GLOBAL.CURRENT_BRANCH);
              END IF;

              DBG('L_BATCH_NO : ' || L_BATCH_NO);
              TYP_DETB_UPLOAD_DETAIL.BATCH_NO := L_BATCH_NO;
            ELSE
              IF L_BATCH_NO IS NULL THEN
                L_BATCH_NO := TYP_DETB_UPLOAD_DETAIL.BATCH_NO;

                SELECT COUNT(1)
                  INTO L_COUNT_JRNL
                  FROM DETB_JRNL_LOG
                 WHERE BATCH_NO = TYP_DETB_UPLOAD_DETAIL.BATCH_NO
                   AND BRANCH_CODE = TYP_DETB_UPLOAD_DETAIL.BRANCH_CODE;

                IF L_COUNT_JRNL <> 0 THEN
                  DBG(TYP_DETB_UPLOAD_DETAIL.BATCH_NO || '~' || TYP_DETB_UPLOAD_DETAIL.BRANCH_CODE);
                  DBG('AS TRANSACTION JOURNAL ALREADY EXITS, RAISE ERROR!!');
                  P_ERR_CODE := 'DE-UPLD-102';
                  P_ERROR_PARAMS := TYP_DETB_UPLOAD_DETAIL.BATCH_NO || '~' || L_COUNT_JRNL;
                  RAISE E_FAILURE_EXCEPTION;
                END IF;
              ELSE
                IF L_BATCH_NO <> TYP_DETB_UPLOAD_DETAIL.BATCH_NO THEN
                  DBG(L_BATCH_NO || '~' || TYP_DETB_UPLOAD_DETAIL.BATCH_NO);
                  DBG('AS BATCH NUMBERS ARE DIFFERENT RAISE ERROR!!');
                  P_ERR_CODE := 'DE-UPLD-101';
                  P_ERROR_PARAMS := L_BATCH_NO || '~' || TYP_DETB_UPLOAD_DETAIL.BATCH_NO || '~' || TYP_DETB_UPLOAD_DETAIL.CURR_NO;
                  RAISE E_FAILURE_EXCEPTION;
                END IF;
              END IF;
            END IF;

            --PRF_CUSTOM_04_10072018 changes starts
            TYP_SINGLEJRNL_LOG := NULL;
            IF TYP_DETB_UPLOAD_DETAIL.AMOUNT IS NULL THEN
              DBG('AMOUNT CANNOT BE NULL, RAISE ERROR');
              P_ERR_CODE := 'IN-HEAR-246';
              P_ERROR_PARAMS := 'AMOUNT CANNOT BE NULL';
              RAISE E_FAILURE_EXCEPTION;
            END IF;

            DBG(TYP_DETB_UPLOAD_DETAIL.EXCH_RATE);
            IF TYP_DETB_UPLOAD_DETAIL.LCY_EQUIVALENT IS NULL THEN
              DBG('LCY IS NULL FOR :' || TYP_DETB_UPLOAD_DETAIL.CCY_CD || '~' || TYP_DETB_UPLOAD_DETAIL.AMOUNT);
              IF TYP_DETB_UPLOAD_DETAIL.CCY_CD = GLOBAL.LCY THEN
                DBG('LCY CASE');
                TYP_DETB_UPLOAD_DETAIL.LCY_EQUIVALENT := TYP_DETB_UPLOAD_DETAIL.AMOUNT;
              ELSE
                DBG('NOT LCY CASE');

                IF TYP_DETB_UPLOAD_DETAIL.EXCH_RATE IS NOT NULL THEN
                  DBG('EXCH RATE IS NOT NULL');
                  TYP_DETB_UPLOAD_DETAIL.LCY_EQUIVALENT := TYP_DETB_UPLOAD_DETAIL.AMOUNT * TYP_DETB_UPLOAD_DETAIL.EXCH_RATE;
                ELSE
                  DBG('EXCH RATE IS NULL');
                  IF NOT CYPKS.FN_AMT1_TO_AMT2(TYP_DETB_UPLOAD_DETAIL.BRANCH_CODE,
                                               TYP_DETB_UPLOAD_DETAIL.CCY_CD,
                                               GLOBAL.LCY,
                                               TYP_DETB_UPLOAD_DETAIL.AMOUNT,
                                               'Y',
                                               TYP_DETB_UPLOAD_DETAIL.LCY_EQUIVALENT,
                                               TYP_DETB_UPLOAD_DETAIL.EXCH_RATE,
                                               P_ERR_CODE) THEN
                    DBG('FAILED WHILE CONVERTING AMOUNT :' || P_ERR_CODE);
                    P_ERROR_PARAMS := 'FAILED WHILE CONVERTING AMOUNT';
                    RAISE E_FAILURE_EXCEPTION;
                  END IF;
                END IF;
              END IF;
            END IF;
            DBG('LCY IS NULL FOR :' ||
                   TYP_DETB_UPLOAD_DETAIL.CCY_CD || '~' ||
                   TYP_DETB_UPLOAD_DETAIL.AMOUNT || '~' ||
                   TYP_DETB_UPLOAD_DETAIL.LCY_EQUIVALENT);

            IF NOT CYPKS.FN_AMT_ROUND(TYP_DETB_UPLOAD_DETAIL.CCY_CD,
                                      TYP_DETB_UPLOAD_DETAIL.AMOUNT,
                                      L_TMP_AMOUNT) THEN
              DBG('Unable to round fcy_amount, cypks.fn_amt_round has returned false');
              P_ERROR_PARAMS := 'FAILED WHILE CONVERTING THE AMOUNT';
              RAISE E_FAILURE_EXCEPTION;
            END IF;

             DBG('l_tmp_amount : ' || L_TMP_AMOUNT);
             DBG('TYP_DETB_UPLOAD_DETAIL.AMOUNT : ' || TYP_DETB_UPLOAD_DETAIL.AMOUNT);

            IF L_TMP_AMOUNT <> TYP_DETB_UPLOAD_DETAIL.AMOUNT THEN
              DBG('Currency decimal position Not matching for amount ' ||
                     TYP_DETB_UPLOAD_DETAIL.AMOUNT ||
                     ' for the Currency ' ||
                     TYP_DETB_UPLOAD_DETAIL.CCY_CD);
              P_ERR_CODE := 'AC-HOF20;';
              P_ERROR_PARAMS := 'AMOUNT NOT ROUNDED TO CCY ROUNDING';
              RAISE E_FAILURE_EXCEPTION;
            END IF;
            --PRF_CUSTOM_04_10072018 changes ends

            TYP_SINGLEJRNL_LOG.CURR_NO        := TYP_DETB_UPLOAD_DETAIL.CURR_NO;
            TYP_SINGLEJRNL_LOG.CCY_CD         := TYP_DETB_UPLOAD_DETAIL.CCY_CD;
            TYP_SINGLEJRNL_LOG.AMOUNT         := TYP_DETB_UPLOAD_DETAIL.AMOUNT;
            TYP_SINGLEJRNL_LOG.LCY_AMOUNT     := TYP_DETB_UPLOAD_DETAIL.LCY_EQUIVALENT;
            TYP_SINGLEJRNL_LOG.DR_CR          := TYP_DETB_UPLOAD_DETAIL.DR_CR;
            TYP_SINGLEJRNL_LOG.ACCOUNT        := TYP_DETB_UPLOAD_DETAIL.ACCOUNT;
            TYP_SINGLEJRNL_LOG.ACCOUNT_BRANCH := TYP_DETB_UPLOAD_DETAIL.ACCOUNT_BRANCH;
            TYP_SINGLEJRNL_LOG.TXN_CODE       := TYP_DETB_UPLOAD_DETAIL.TXN_CODE;
            TYP_SINGLEJRNL_LOG.VALUE_DATE     := TYP_DETB_UPLOAD_DETAIL.VALUE_DATE;
            IF (TYP_DETB_UPLOAD_DETAIL.CCY_CD <> GLOBAL.LCY) THEN
              IF TYP_DETB_UPLOAD_DETAIL.EXCH_RATE IS NOT NULL THEN
                TYP_SINGLEJRNL_LOG.EXCH_RATE := TYP_DETB_UPLOAD_DETAIL.EXCH_RATE;
              ELSE
                TYP_SINGLEJRNL_LOG.EXCH_RATE := TYP_DETB_UPLOAD_DETAIL.AMOUNT /
                                                TYP_DETB_UPLOAD_DETAIL.LCY_EQUIVALENT;
              END IF;
            ELSE
              TYP_SINGLEJRNL_LOG.EXCH_RATE := 1;
            END IF;
            TYP_SINGLEJRNL_LOG.FIN_CYCLE         := TYP_DETB_UPLOAD_DETAIL.FIN_CYCLE;
            TYP_SINGLEJRNL_LOG.INSTRUMENT_NO     := TYP_DETB_UPLOAD_DETAIL.INSTRUMENT_NO;
            TYP_SINGLEJRNL_LOG.PERIOD_CODE       := TYP_DETB_UPLOAD_DETAIL.PERIOD_CODE;
            TYP_SINGLEJRNL_LOG.REL_CUST          := TYP_DETB_UPLOAD_DETAIL.REL_CUST;
            TYP_SINGLEJRNL_LOG.MIS_CODE          := TYP_DETB_UPLOAD_DETAIL.MIS_CODE;
            TYP_SINGLEJRNL_LOG.INITIATION_DATE   := TYP_DETB_UPLOAD_DETAIL.INITIATION_DATE;
            TYP_SINGLEJRNL_LOG.DW_AC_NO          := NULL;
            TYP_SINGLEJRNL_LOG.ACCOUNT_NEW       := NULL;
            TYP_SINGLEJRNL_LOG.MIS_GROUP         := TYP_DETB_UPLOAD_DETAIL.MIS_GROUP;
            TYP_SINGLEJRNL_LOG.FUND_REFERENCE_NO := NULL;
            TYP_SINGLEJRNL_LOG.BATCH_NO          := TYP_DETB_UPLOAD_DETAIL.BATCH_NO;
            TYP_SINGLEJRNL_LOG.BRANCH_CODE       := TYP_DETB_UPLOAD_DETAIL.BRANCH_CODE;
            TYP_DEVWS_JRNL_LOG.ADDLTXT           := TYP_DETB_UPLOAD_DETAIL.ADDL_TEXT;
            TYP_DETB_MASTER.DESCRIPTION          := SUBSTR(P_PHY_FILE_NAME,
                                                           1,
                                                           2) ||
                                                    ' TRANSACTION UPLOAD BATCH - ';
            L_SOURCE_CODE                        := NVL(TYP_DETB_UPLOAD_DETAIL.SOURCE_CODE,
                                                        L_SOURCE_CODE);
            L_SUS_AC_NO                          := NULL;

            DBG('typ_singlejrnl_log.curr_no :' ||
                TYP_SINGLEJRNL_LOG.CURR_NO);
            DBG('typ_singlejrnl_log.ccy_cd :' || TYP_SINGLEJRNL_LOG.CCY_CD);
            DBG('typ_singlejrnl_log.amount :' || TYP_SINGLEJRNL_LOG.AMOUNT);
            DBG('typ_singlejrnl_log.lcy_amount :' ||
                TYP_SINGLEJRNL_LOG.LCY_AMOUNT);
            DBG('typ_singlejrnl_log.dr_cr :' || TYP_SINGLEJRNL_LOG.DR_CR);
            DBG('typ_singlejrnl_log.account :' ||
                TYP_SINGLEJRNL_LOG.ACCOUNT);
            DBG('typ_singlejrnl_log.account_branch :' ||
                TYP_SINGLEJRNL_LOG.ACCOUNT_BRANCH);
            DBG('typ_singlejrnl_log.txn_code :' ||
                TYP_SINGLEJRNL_LOG.TXN_CODE);
            DBG('typ_singlejrnl_log.value_date :' ||
                TYP_SINGLEJRNL_LOG.VALUE_DATE);
            DBG('typ_singlejrnl_log.exch_rate :' ||
                TYP_SINGLEJRNL_LOG.EXCH_RATE);
            DBG('typ_singlejrnl_log.fin_cycle :' ||
                TYP_SINGLEJRNL_LOG.FIN_CYCLE);
            DBG('typ_singlejrnl_log.instrument_no :' ||
                TYP_SINGLEJRNL_LOG.INSTRUMENT_NO);
            DBG('typ_singlejrnl_log.period_code :' ||
                TYP_SINGLEJRNL_LOG.PERIOD_CODE);
            DBG('typ_singlejrnl_log.rel_cust :' ||
                TYP_SINGLEJRNL_LOG.REL_CUST);
            DBG('typ_singlejrnl_log.mis_code :' ||
                TYP_SINGLEJRNL_LOG.MIS_CODE);
            DBG('typ_singlejrnl_log.initiation_date :' ||
                TYP_SINGLEJRNL_LOG.INITIATION_DATE);
            DBG('typ_singlejrnl_log.dw_ac_no :' ||
                TYP_SINGLEJRNL_LOG.DW_AC_NO);
            DBG('typ_singlejrnl_log.account_new :' ||
                TYP_SINGLEJRNL_LOG.ACCOUNT_NEW);
            DBG('typ_singlejrnl_log.mis_group :' ||
                TYP_SINGLEJRNL_LOG.MIS_GROUP);
            DBG('typ_singlejrnl_log.fund_reference_no :' ||
                TYP_SINGLEJRNL_LOG.FUND_REFERENCE_NO);
            DBG('typ_singlejrnl_log.batch_no :' ||
                TYP_SINGLEJRNL_LOG.BATCH_NO);
            DBG('typ_singlejrnl_log.branch_code :' ||
                TYP_SINGLEJRNL_LOG.BRANCH_CODE);
            DBG('typ_devws_jrnl_log.addltxt :' ||
                TYP_DEVWS_JRNL_LOG.ADDLTXT);
            DBG('typ_detb_master.description :' ||
                TYP_DETB_MASTER.DESCRIPTION);
          EXCEPTION
            WHEN E_FAILURE_EXCEPTION THEN
              DBG(' e FAILURE EXCEPTION RAISE  ' || SQLERRM);
              DBG(P_ERR_CODE || '->' || P_ERROR_PARAMS);
              DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
              CLOSE CUR_COMPONENT_FIELDS;
              CLOSE CUR_COMPONENTS;

              ROLLBACK;

              DELETE FROM DETB_UPLOAD_DETAIL
               WHERE BATCH_NO = TYP_DETB_UPLOAD_DETAIL.BATCH_NO
                 AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                 AND UPLOAD_STAT = 'U';

              UPDATE GITM_UPLOAD_MASTER
                 SET STATUS = 'E',
                     ERROR = P_ERR_CODE,
                     ERROR_PARAM = P_ERROR_PARAMS
               WHERE INTERFACE_CODE = P_INTERFACE_CODE
                 AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
                 AND PHY_FILE_NAME = P_PHY_FILE_NAME
                 AND PROCESS_NO = P_PROCESS_NO
                 AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
                 AND STATUS = 'U';

              INSERT INTO DETBS_UPLOAD_EXCEPTIONS
                (BRANCH_CODE,
                 SOURCE_CODE,
                 BATCH_NO,
                 CURR_NO,
                 SEQ_NO,
                 ERR_CODE,
                 PARAMETERS,
                 ERROR_MESSAGE)
              VALUES
                (GLOBAL.CURRENT_BRANCH,
                 L_SOURCE_CODE,
                 TYP_DETB_UPLOAD_DETAIL.BATCH_NO,
                 TYP_DETB_UPLOAD_DETAIL.CURR_NO,
                 L_SEQ,
                 P_ERR_CODE,
                 P_ERROR_PARAMS,
                 TYP_DETB_UPLOAD_DETAIL.BATCH_NO);

              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
              COMMIT;
              RETURN FALSE;
            WHEN OTHERS THEN
              DBG(' Failed in Opening Ref Cursor  ' || SQLERRM);
              DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
              P_ERR_CODE := SQLERRM;
              CLOSE CUR_COMPONENT_FIELDS;
              CLOSE CUR_COMPONENTS;

              P_ERR_CODE := 'IF-ASCUP027';
              P_ERROR_PARAMS := TYP_DETB_UPLOAD_DETAIL.CURR_NO || '~' || SUBSTR(SQLERRM, 1, 50) || ';';
              ROLLBACK;

              DELETE FROM DETB_UPLOAD_DETAIL
               WHERE BATCH_NO = TYP_DETB_UPLOAD_DETAIL.BATCH_NO
                 AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                 AND UPLOAD_STAT = 'U';

              UPDATE GITM_UPLOAD_MASTER
                 SET STATUS = 'E',
                     ERROR = P_ERR_CODE,
                     ERROR_PARAM = P_ERROR_PARAMS
               WHERE INTERFACE_CODE = P_INTERFACE_CODE
                 AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
                 AND PHY_FILE_NAME = P_PHY_FILE_NAME
                 AND PROCESS_NO = P_PROCESS_NO
                 AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
                 AND STATUS = 'U';

              INSERT INTO DETBS_UPLOAD_EXCEPTIONS
                (BRANCH_CODE,
                 SOURCE_CODE,
                 BATCH_NO,
                 CURR_NO,
                 SEQ_NO,
                 ERR_CODE,
                 PARAMETERS,
                 ERROR_MESSAGE)
              VALUES
                (GLOBAL.CURRENT_BRANCH,
                 L_SOURCE_CODE,
                 TYP_DETB_UPLOAD_DETAIL.BATCH_NO,
                 TYP_DETB_UPLOAD_DETAIL.CURR_NO,
                 L_SEQ,
                 P_ERR_CODE,
                 P_ERROR_PARAMS,
                 TYP_DETB_UPLOAD_DETAIL.BATCH_NO);

              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
              COMMIT;
              RETURN FALSE;
          END;
        END IF;
      END LOOP;
      IF CUR_COMPONENTS%ISOPEN THEN
        DBG(' Closing CUR_COMPONENTS');
        CLOSE CUR_COMPONENTS;
      END IF;
      IF CUR_COMPONENT_FIELDS%ISOPEN THEN
        DBG(' Closing CUR_COMPONENT_FIELDS');
        CLOSE CUR_COMPONENT_FIELDS;
      END IF;
      DBG(' l_ref_cursor >>>>>> ' || L_REF_CURSOR);
      BEGIN
        DBG('Calling Main Package....');
        DBG(TYP_SINGLEJRNL_LOG.BATCH_NO);
        DBG(TYP_SINGLEJRNL_LOG.BRANCH_CODE);
        DBG(TYP_SINGLEJRNL_LOG.CURR_NO);
        IF NOT TRPKSS.FN_GET_BATCH_REFNO(TYP_SINGLEJRNL_LOG.BRANCH_CODE,
                                         TYP_SINGLEJRNL_LOG.BATCH_NO,
                                         TYP_SINGLEJRNL_LOG.CURR_NO,
                                         GLOBAL.APPLICATION_DATE,
                                         PREFERENCENO,
                                         P_ERR_CODE) THEN
          DBG(' Failed in Creation of Reference Number....');
        END IF;
        TYP_SINGLEJRNL_LOG.REFERENCE_NO := PREFERENCENO;
        TYP_DETB_MASTER.BRANCH_CODE     := TYP_SINGLEJRNL_LOG.BRANCH_CODE;
        TYP_DETB_MASTER.BATCH_NO        := TYP_SINGLEJRNL_LOG.BATCH_NO;
        DBG('Value...' || TYP_SINGLEJRNL_LOG.BATCH_NO);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.BRANCH_CODE);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.CURR_NO);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.CCY_CD);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.AMOUNT);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.LCY_AMOUNT);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.DR_CR);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.ACCOUNT);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.ACCOUNT_BRANCH);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.TXN_CODE);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.VALUE_DATE);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.EXCH_RATE);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.FIN_CYCLE);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.INSTRUMENT_NO);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.PERIOD_CODE);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.REL_CUST);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.MIS_CODE);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.INITIATION_DATE);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.DW_AC_NO);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.ACCOUNT_NEW);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.MIS_GROUP);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.FUND_REFERENCE_NO);
        DBG('Value...' || TYP_SINGLEJRNL_LOG.REFERENCE_NO);
        TYP_SINGLEJRNL_LOG.REFERENCE_NO := PREFERENCENO;
        P_SOURCE                        := P_FORMAT_DETAILS.EXTERNAL_SYSTEM;
        P_ACTION_CODE                   := 'SingleNew';
        BEGIN
          DBG(' typ_detb_master.Batch_no ' || TYP_DETB_MASTER.BATCH_NO);
          DBG(' typ_detb_master.Description ' ||
              TYP_DETB_MASTER.DESCRIPTION);
          SELECT DESCRIPTION
            INTO TYP_DETB_MASTER.DESCRIPTION
            FROM DETBS_BATCH_MASTER
           WHERE BRANCH_CODE = TYP_DETB_MASTER.BRANCH_CODE
             AND BATCH_NO = TYP_DETB_MASTER.BATCH_NO
             AND TYPE = 'J';

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('NDF' || TYP_DETB_MASTER.BATCH_NO);
            TYP_DETB_MASTER.DESCRIPTION := TYP_DETB_MASTER.DESCRIPTION ||
                                           TYP_DETB_MASTER.BATCH_NO;
            DBG('NDF' || TYP_DETB_MASTER.DESCRIPTION);
        END;
        P_ERR_CODE     := NULL;
        P_ERROR_PARAMS := NULL;
        IF NOT FN_VALIDATE_AND_REPLACE_ACC(TYP_SINGLEJRNL_LOG.ACCOUNT_BRANCH,
                                           TYP_SINGLEJRNL_LOG.ACCOUNT,
                                           TYP_SINGLEJRNL_LOG.DR_CR,
                                           GLOBAL.LCY,
                                           TYP_SINGLEJRNL_LOG.CCY_CD,
                                           TYP_SINGLEJRNL_LOG.VALUE_DATE,
                                           L_SUS_AC_NO,
                                           TYP_SINGLEJRNL_LOG.TXN_CODE,
                                           TYP_SINGLEJRNL_LOG.INSTRUMENT_NO,
                                           TYP_SINGLEJRNL_LOG.AMOUNT,
                                           P_ERR_PARAM) THEN
          DBG(' Failed in Fn_Validate_And_Replace_Acc ');
      
         --To Validate account balance to prevent from posting to suspense account starts
          PR_LOG_ERROR('FLEXCUBE',
                       'DE-UPLOAD01',
                       TYP_SINGLEJRNL_LOG.ACCOUNT);
          ROLLBACK TO ORIGINAL;
          RETURN FALSE;
          --To Validate account balance to prevent from posting to suspense account ends
        
    
          INSERT INTO DETBS_UPLOAD_EXCEPTIONS
            (BRANCH_CODE,
             SOURCE_CODE,
             BATCH_NO,
             CURR_NO,
             SEQ_NO,
             ERR_CODE,
             PARAMETERS,
             ERROR_MESSAGE)
          VALUES
            (TYP_SINGLEJRNL_LOG.BRANCH_CODE,
             L_SOURCE_CODE,
             TYP_SINGLEJRNL_LOG.BATCH_NO,
             TYP_SINGLEJRNL_LOG.CURR_NO,
             TYP_SINGLEJRNL_LOG.CURR_NO + 1,
             'DE-JRN74',
             '',
             TYP_SINGLEJRNL_LOG.ACCOUNT || TYP_SINGLEJRNL_LOG.BRANCH_CODE);

          TYP_SINGLEJRNL_LOG.ACCOUNT := L_SUS_AC_NO;
          P_ERR_CODE                 := 'DE-UPOD00';
          P_ERROR_PARAMS             := P_ERR_PARAM || ' - Acccount ' ||
                                        TYP_SINGLEJRNL_LOG.ACCOUNT ||
                                        ' branch code ' ||
                                        TYP_SINGLEJRNL_LOG.BRANCH_CODE;
          DBG(' Unhandled Exception here -  ' || P_ERR_CODE || '  ' ||
              P_ERROR_PARAMS);
        ELSE
          DBG('Returned True from fn_validate_and_replace_acc - Suspense A/c-' ||
              L_SUS_AC_NO || '-');
          IF NVL(L_SUS_AC_NO, '~') <> '~' THEN
            DBG('Replacing with suspence account .');
            P_ERR_CODE                 := 'DE-UPOD01';
            P_ERROR_PARAMS             := 'SUSPENSE: replaced for Orig A/c ' ||
                                          TYP_SINGLEJRNL_LOG.ACCOUNT ||
                                          ' BRN ' ||
                                          TYP_SINGLEJRNL_LOG.BRANCH_CODE ||
                                          ' - ' || P_ERR_PARAM;
            TYP_DEVWS_JRNL_LOG.ADDLTXT := SUBSTR('SUSPENSE: replaced for Orig A/c ' ||
                                                 TYP_SINGLEJRNL_LOG.ACCOUNT ||
                                                 ' BRN ' ||
                                                 TYP_SINGLEJRNL_LOG.BRANCH_CODE ||
                                                 ' - ' || P_ERR_PARAM,
                                                 1,
                                                 255);
            TYP_SINGLEJRNL_LOG.ACCOUNT := L_SUS_AC_NO;

            INSERT INTO DETBS_UPLOAD_EXCEPTIONS
              (BRANCH_CODE,
               SOURCE_CODE,
               BATCH_NO,
               CURR_NO,
               SEQ_NO,
               ERR_CODE,
               PARAMETERS,
               ERROR_MESSAGE)
            VALUES
              (TYP_SINGLEJRNL_LOG.BRANCH_CODE,
               L_SOURCE_CODE,
               TYP_SINGLEJRNL_LOG.BATCH_NO,
               TYP_SINGLEJRNL_LOG.CURR_NO,
               TYP_SINGLEJRNL_LOG.CURR_NO + 1,
               P_ERR_CODE,
               P_ERROR_PARAMS,
               TYP_DEVWS_JRNL_LOG.ADDLTXT);
          END IF;
        END IF;
        BEGIN
          DBG(' l_first_time ' || L_FIRST_TIME);
          IF L_FIRST_TIME = 0 THEN
            DBG(' First Time..');
            DELETE FROM DETB_UPLOAD_DETAIL
             WHERE SOURCE_CODE = L_SOURCE_CODE
               AND BRANCH_CODE = TYP_SINGLEJRNL_LOG.BRANCH_CODE
               AND BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO;

       --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code starts
            DELETE FROM UDTBS_UPLOAD_DETAIL
             WHERE SOURCE_CODE = L_SOURCE_CODE
               AND BRANCH_CODE = TYP_SINGLEJRNL_LOG.BRANCH_CODE
               AND BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO;
            --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code ends

            L_FIRST_TIME := 1;
          END IF;
          DBG(' Going to Insert into DETB_UPLOAD_DETAIL');
          DBG(' <><><><><><><><><><><><><><><><><><><><><><><><><><>');
          DBG(' CURR_NO : ' || TYP_SINGLEJRNL_LOG.CURR_NO);
          DBG(' <><><><><><><><><><><><><><><><><><><><><><><><><><>');
          DBG('SOURCE_CODE : ' || L_SOURCE_CODE);
          DBG(' BATCH_NO : ' || TYP_SINGLEJRNL_LOG.BATCH_NO);
          DBG('BRANCH_CODE : ' || GLOBAL.CURRENT_BRANCH);
          DBG(' FIN_CYCLE : ' || TYP_SINGLEJRNL_LOG.FIN_CYCLE);
          DBG(' PERIOD_CODE : ' || TYP_SINGLEJRNL_LOG.PERIOD_CODE);
          DBG(' AMOUNT : ' || TYP_SINGLEJRNL_LOG.AMOUNT);
          DBG(' ADDL_TEXT : ' || TYP_DEVWS_JRNL_LOG.ADDLTXT);
          DBG(' TXN_CODE : ' || TYP_SINGLEJRNL_LOG.TXN_CODE);
          DBG(' LCY_EQUIVALENT : ' || TYP_SINGLEJRNL_LOG.LCY_AMOUNT);
          DBG(' ACCOUNT_BRANCH : ' || TYP_SINGLEJRNL_LOG.ACCOUNT_BRANCH);
          DBG(' ACCOUNT : ' || TYP_SINGLEJRNL_LOG.ACCOUNT);
          DBG(' CCY_CD : ' || TYP_SINGLEJRNL_LOG.CCY_CD);
          DBG(' DR_CR : ' || TYP_SINGLEJRNL_LOG.DR_CR);
          DBG(' VALUE_DATE : ' || TYP_SINGLEJRNL_LOG.VALUE_DATE);
          DBG(' <><><><><><><><><><><><><><><><><><><><><><><><><><>');
          INSERT INTO DETBS_UPLOAD_DETAIL
            (SOURCE_CODE,
             BATCH_NO,
             BRANCH_CODE,
             CURR_NO,
             UPLOAD_STAT,
             FIN_CYCLE,
             PERIOD_CODE,
             AMOUNT,
             ADDL_TEXT,
             TXN_CODE,
             LCY_EQUIVALENT,
             ACCOUNT_BRANCH,
             ACCOUNT,
             CCY_CD,
             DR_CR,
             VALUE_DATE,
             REL_CUST,
             MIS_CODE,
             MIS_GROUP,
             MIS_HEAD,
             TXN_MIS_1,
             TXN_MIS_2,
             TXN_MIS_3,
             TXN_MIS_4,
             TXN_MIS_5,
             TXN_MIS_6,
             TXN_MIS_7,
             TXN_MIS_8,
             TXN_MIS_9,
             TXN_MIS_10,
             COMP_MIS_1,
             COMP_MIS_2,
             COMP_MIS_3,
             COMP_MIS_4,
             COMP_MIS_5,
             COMP_MIS_6,
             COMP_MIS_7,
             COMP_MIS_8,
             COMP_MIS_9,
             COMP_MIS_10,
             COST_CODE1,
             COST_CODE2,
             COST_CODE3,
             COST_CODE4,
             COST_CODE5,
             EXTERNAL_REF_NO,
             INSTRUMENT_NO,
             RELATED_ACCOUNT,
             RELATED_REF,
             TXT_FILE_NAME)
          VALUES
            (L_SOURCE_CODE,
             TYP_SINGLEJRNL_LOG.BATCH_NO,
             GLOBAL.CURRENT_BRANCH,
             TYP_SINGLEJRNL_LOG.CURR_NO,
             'U',
             TYP_SINGLEJRNL_LOG.FIN_CYCLE,
             TYP_SINGLEJRNL_LOG.PERIOD_CODE,
             TYP_SINGLEJRNL_LOG.AMOUNT,
             TYP_DEVWS_JRNL_LOG.ADDLTXT,
             TYP_SINGLEJRNL_LOG.TXN_CODE,
             TYP_SINGLEJRNL_LOG.LCY_AMOUNT,
             TYP_SINGLEJRNL_LOG.ACCOUNT_BRANCH,
             TYP_SINGLEJRNL_LOG.ACCOUNT,
             TYP_SINGLEJRNL_LOG.CCY_CD,
             TYP_SINGLEJRNL_LOG.DR_CR,
             TYP_SINGLEJRNL_LOG.VALUE_DATE,
             TYP_DETB_UPLOAD_DETAIL.REL_CUST,
             TYP_DETB_UPLOAD_DETAIL.MIS_CODE,
             TYP_DETB_UPLOAD_DETAIL.MIS_GROUP,
             TYP_DETB_UPLOAD_DETAIL.MIS_HEAD,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_1,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_2,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_3,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_4,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_5,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_6,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_7,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_8,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_9,
             TYP_DETB_UPLOAD_DETAIL.TXN_MIS_10,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_1,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_2,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_3,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_4,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_5,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_6,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_7,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_8,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_9,
             TYP_DETB_UPLOAD_DETAIL.COMP_MIS_10,
             TYP_DETB_UPLOAD_DETAIL.COST_CODE1,
             TYP_DETB_UPLOAD_DETAIL.COST_CODE2,
             TYP_DETB_UPLOAD_DETAIL.COST_CODE3,
             TYP_DETB_UPLOAD_DETAIL.COST_CODE4,
             TYP_DETB_UPLOAD_DETAIL.COST_CODE5,
             TYP_DETB_UPLOAD_DETAIL.EXTERNAL_REF_NO,
             TYP_DETB_UPLOAD_DETAIL.INSTRUMENT_NO,
             TYP_DETB_UPLOAD_DETAIL.RELATED_ACCOUNT,
             TYP_DETB_UPLOAD_DETAIL.RELATED_REF,
             P_PHY_FILE_NAME);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Inserting into detbs_upload_detail ....' ||
                SQLERRM);
            RAISE E_FAILURE_EXCEPTION;
        END;

    --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code starts
        DBG('INSERTING INTO UDTB_UPLOAD_DETAIL TABLE');
        BEGIN

          select *
            into l_gitm_upload_master
            from gitm_upload_master
           where target_table = 'DETB_UPLOAD_DETAIL'
             AND RECORD_REFERENCE = RECORD_REF.RECORD_REFERENCE;

          INSERT INTO UDTB_UPLOAD_DETAIL
            (branch_code,
             source_code,
             batch_no,
             curr_no,
             field_val_1,
             field_val_2,
             field_val_3,
             field_val_4,
             field_val_5, --DE Upload Requirement with Product Code, Segment Code
             field_val_6  --DE Upload Requirement with Product Code, Segment Code
             )
          VALUES
            (GLOBAL.CURRENT_BRANCH,
             L_SOURCE_CODE,
             TYP_SINGLEJRNL_LOG.BATCH_NO,
             TYP_SINGLEJRNL_LOG.CURR_NO,
             l_gitm_upload_master.fld25,
             l_gitm_upload_master.fld26,
             l_gitm_upload_master.fld27,
             l_gitm_upload_master.fld28,
             l_gitm_upload_master.fld29, --DE Upload Requirement with Product Code, Segment Code
             l_gitm_upload_master.fld30  --DE Upload Requirement with Product Code, Segment Code
             );
        EXCEPTION
          WHEN OTHERS THEN
            DBG('ERROR IN INSERTING UDTB_UPLOAD_DETAIL');
            DBG('ERROR CODE='||SQLCODE);
            DBG('ERROR MESSAGE='||SQLERRM);
        END;
        DBG('ROW COUNT OF UDTB_UPLOAD_DETAIL='||SQL%ROWCOUNT);
        --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code ends

        DBG('Success..1..');
        DBG('Success..2..');
        UPDATE GITM_UPLOAD_MASTER
           SET STATUS      = 'P',
               ERROR       = P_ERR_CODE,
               ERROR_PARAM = P_ERROR_PARAMS
         WHERE RECORD_REFERENCE = TXNREF
           AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL';

        DBG('Success after updating....');
      EXCEPTION
        WHEN E_FAILURE_EXCEPTION THEN
          DBG('Failure...');
          P_STATUS := 'E';
          UPDATE GITM_UPLOAD_MASTER
             SET STATUS      = 'E',
                 ERROR       = P_ERR_CODE,
                 ERROR_PARAM = P_ERROR_PARAMS
           WHERE RECORD_REFERENCE = TXNREF
             AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL';

          P_ERR_TBL := OVPKSS.GL_TBLERROR;
          DBG('   p_err_code   ' || P_ERR_CODE);
          DBG('   p_error_params   ' || P_ERROR_PARAMS);
          FOR I IN P_ERR_TBL.FIRST .. P_ERR_TBL.LAST LOOP
            DBG(' p_err_tbl(i).err_code  ' || P_ERR_TBL(I).ERR_CODE ||
                ' error type ' || OVPKSS.FN_GETTYPE(P_ERR_TBL(I).ERR_CODE));
            IF OVPKSS.FN_GETTYPE(P_ERR_TBL(I).ERR_CODE) NOT IN ('I', 'O') THEN
              L_SEQ := L_SEQ + 1;
              BEGIN
                INSERT INTO DETBS_UPLOAD_EXCEPTIONS
                  (BRANCH_CODE,
                   SOURCE_CODE,
                   BATCH_NO,
                   CURR_NO,
                   SEQ_NO,
                   ERR_CODE,
                   PARAMETERS,
                   ERROR_MESSAGE)
                VALUES
                  (TYP_SINGLEJRNL_LOG.BRANCH_CODE,
                   L_SOURCE_CODE,
                   TYP_SINGLEJRNL_LOG.BATCH_NO,
                   TYP_SINGLEJRNL_LOG.CURR_NO,
                   L_SEQ,
                   P_ERR_TBL(I).ERR_CODE,
                   'Failed',
                   OVPKSS.GL_TBLERROR(I).PARAMS);

              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed to insert into Detbs_Upload_Exceptions');
              END;
            END IF;
          END LOOP;
        WHEN OTHERS THEN
          P_STATUS := 'E';
          UPDATE GITM_UPLOAD_MASTER
             SET STATUS      = 'E',
                 ERROR       = P_ERR_CODE,
                 ERROR_PARAM = P_ERROR_PARAMS
           WHERE RECORD_REFERENCE = TXNREF
             AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL';

      END;
      COMMIT;
      L_REF_CURSOR := 'SELECT  ';
      DBG('@@@ End of Loop..');
    END LOOP;
    IF CR_RECORD_REFERENCE%ISOPEN THEN
      DBG('Closing CR_RECORD_REFERENCE');
      CLOSE CR_RECORD_REFERENCE;
    END IF;

    SELECT COUNT(1)
      INTO L_COUNT
      FROM DETB_UPLOAD_MASTER
     WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

    DBG('UPLOAD MASTER COUNT OF BATCH AND BRANCH :' || L_COUNT);
    IF L_COUNT > 0 THEN
      DBG('DUPLICATE IN UPLOAD MASTER. HENCE FAIL!!');
      P_ERR_CODE := 'AD-VAL010';
      ROLLBACK;

      DELETE FROM DETB_UPLOAD_DETAIL
       WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND UPLOAD_STAT = 'U';

      UPDATE GITM_UPLOAD_MASTER
         SET STATUS = 'E'
       WHERE INTERFACE_CODE = P_INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
         AND PHY_FILE_NAME = P_PHY_FILE_NAME
         AND PROCESS_NO = P_PROCESS_NO
         AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
         AND STATUS = 'U';

      INSERT INTO DETBS_UPLOAD_EXCEPTIONS
        (BRANCH_CODE,
         SOURCE_CODE,
         BATCH_NO,
         CURR_NO,
         SEQ_NO,
         ERR_CODE,
         PARAMETERS,
         ERROR_MESSAGE)
      VALUES
        (GLOBAL.CURRENT_BRANCH,
         L_SOURCE_CODE,
         TYP_SINGLEJRNL_LOG.BATCH_NO,
         '99999',
         L_SEQ,
         'AD-VAL010',
         'Failed',
         TYP_SINGLEJRNL_LOG.BATCH_NO);

      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
      COMMIT;
      RETURN FALSE;
    END IF;

    L_COUNT := 0;
    SELECT COUNT(1)
      INTO L_COUNT
      FROM DETB_BATCH_MASTER
     WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

    DBG('BATCH MASTER COUNT OF BATCH AND BRANCH :' || L_COUNT);
    IF L_COUNT > 0 THEN
      DBG('DUPLICATE IN BATCH MASTER. HENCE FAIL!!');
      P_ERR_CODE := 'AD-VAL010';
      ROLLBACK;

      DELETE FROM DETB_UPLOAD_DETAIL
       WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND UPLOAD_STAT = 'U';

      UPDATE GITM_UPLOAD_MASTER
         SET STATUS = 'E'
       WHERE INTERFACE_CODE = P_INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
         AND PHY_FILE_NAME = P_PHY_FILE_NAME
         AND PROCESS_NO = P_PROCESS_NO
         AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
         AND STATUS = 'U';

      INSERT INTO DETBS_UPLOAD_EXCEPTIONS
        (BRANCH_CODE,
         SOURCE_CODE,
         BATCH_NO,
         CURR_NO,
         SEQ_NO,
         ERR_CODE,
         PARAMETERS,
         ERROR_MESSAGE)
      VALUES
        (GLOBAL.CURRENT_BRANCH,
         L_SOURCE_CODE,
         TYP_SINGLEJRNL_LOG.BATCH_NO,
         '99998',
         L_SEQ,
         'AD-VAL010',
         'Failed',
         TYP_SINGLEJRNL_LOG.BATCH_NO);

      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
      COMMIT;
      RETURN FALSE;
    END IF;

    /*L_COUNT := 0;
    SELECT COUNT(1)
      INTO L_COUNT
      FROM DETB_UPLOAD_DETAIL
     WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

    DBG('UPLOAD DETAIL COUNT OF BATCH AND BRANCH :' || L_COUNT);
    IF L_COUNT > 0 THEN
      DBG('DUPLICATE IN UPLOAD DETAIL. HENCE FAIL!!');
      P_ERR_CODE := 'AD-VAL010';
      ROLLBACK;
      RETURN FALSE;
    END IF;*/

    DBG('WILL CHECK FOR BATCH BALANCING');
    SELECT SUM(DECODE(A.DR_CR, 'D', -A.LCY_EQUIVALENT, A.LCY_EQUIVALENT))
      INTO L_COUNT
      FROM DETB_UPLOAD_DETAIL A
     WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    DBG('BATCH BALANCE IS :' || L_COUNT);
    IF L_COUNT <>  0 THEN
      DBG('BATCH IS NOT BALANCED');
      P_ERR_CODE := 'AD-UP01';
      P_ERROR_PARAMS := GLOBAL.CURRENT_BRANCH || ';' || L_COUNT || ',';

      SELECT SUM(DECODE(A.DR_CR, 'D', A.LCY_EQUIVALENT, 0))
        INTO L_COUNT
        FROM DETB_UPLOAD_DETAIL A
       WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

      P_ERROR_PARAMS := P_ERROR_PARAMS || 'DR:' || L_COUNT || ',';

      SELECT SUM(DECODE(A.DR_CR, 'C', A.LCY_EQUIVALENT, 0))
        INTO L_COUNT
        FROM DETB_UPLOAD_DETAIL A
       WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

      P_ERROR_PARAMS := P_ERROR_PARAMS || 'CR:' || L_COUNT || ';';
      ROLLBACK;

      DELETE FROM DETB_UPLOAD_DETAIL
       WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND UPLOAD_STAT = 'U';

      UPDATE GITM_UPLOAD_MASTER
         SET STATUS = 'E'
       WHERE INTERFACE_CODE = P_INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
         AND PHY_FILE_NAME = P_PHY_FILE_NAME
         AND PROCESS_NO = P_PROCESS_NO
         AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
         AND STATUS = 'U';

      INSERT INTO DETBS_UPLOAD_EXCEPTIONS
        (BRANCH_CODE,
         SOURCE_CODE,
         BATCH_NO,
         CURR_NO,
         SEQ_NO,
         ERR_CODE,
         PARAMETERS,
         ERROR_MESSAGE)
      VALUES
        (GLOBAL.CURRENT_BRANCH,
         L_SOURCE_CODE,
         TYP_SINGLEJRNL_LOG.BATCH_NO,
         '0',
         L_SEQ,
         P_ERR_CODE,
         'Failed',
         P_ERROR_PARAMS);

      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
      COMMIT;
      RETURN FALSE;
    END IF;

    DBG('WILL CHECK FOR currency cyrillic');
    FOR X IN (SELECT *
                FROM DETB_UPLOAD_DETAIL A
               WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
                 AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH) LOOP
      IF ((X.AMOUNT*100)-TRUNC(X.AMOUNT*100)) > 0 THEN
        DBG('CURRENCY CONTAINS MORE THAN 2 DECIMALS');
        P_ERR_CODE := 'RE-STMUL084';
        P_ERROR_PARAMS := X.AMOUNT;
        ROLLBACK;

        DELETE FROM DETB_UPLOAD_DETAIL
         WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND UPLOAD_STAT = 'U';

        UPDATE GITM_UPLOAD_MASTER
           SET STATUS = 'E'
         WHERE INTERFACE_CODE = P_INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND PHY_FILE_NAME = P_PHY_FILE_NAME
           AND PROCESS_NO = P_PROCESS_NO
           AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
           AND STATUS = 'U';

        INSERT INTO DETBS_UPLOAD_EXCEPTIONS
          (BRANCH_CODE,
           SOURCE_CODE,
           BATCH_NO,
           CURR_NO,
           SEQ_NO,
           ERR_CODE,
           PARAMETERS,
           ERROR_MESSAGE)
        VALUES
          (GLOBAL.CURRENT_BRANCH,
           L_SOURCE_CODE,
           TYP_SINGLEJRNL_LOG.BATCH_NO,
           X.CURR_NO,
           L_SEQ,
           'RE-STMUL084',
           'Failed',
           X.AMOUNT);

        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
        COMMIT;
        RETURN FALSE;
      END IF;

      IF LENGTH(X.FIN_CYCLE) <>  LENGTHB(X.FIN_CYCLE) THEN
        DBG('FIN CYCLE CONTAINS CYRILLIC');
        P_ERR_CODE := 'CN-CLN-001';
        P_ERROR_PARAMS := 'FIN_CYCLE;';
        ROLLBACK;

        DELETE FROM DETB_UPLOAD_DETAIL
         WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND UPLOAD_STAT = 'U';

        UPDATE GITM_UPLOAD_MASTER
           SET STATUS = 'E'
         WHERE INTERFACE_CODE = P_INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND PHY_FILE_NAME = P_PHY_FILE_NAME
           AND PROCESS_NO = P_PROCESS_NO
           AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
           AND STATUS = 'U';

        INSERT INTO DETBS_UPLOAD_EXCEPTIONS
          (BRANCH_CODE,
           SOURCE_CODE,
           BATCH_NO,
           CURR_NO,
           SEQ_NO,
           ERR_CODE,
           PARAMETERS,
           ERROR_MESSAGE)
        VALUES
          (GLOBAL.CURRENT_BRANCH,
           L_SOURCE_CODE,
           TYP_SINGLEJRNL_LOG.BATCH_NO,
           X.CURR_NO,
           L_SEQ,
           'CN-CLN-001',
           'Failed',
           'PERIOD_CODE;');

        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
        COMMIT;
        RETURN FALSE;
      END IF;

      IF LENGTH(X.PERIOD_CODE) <>  LENGTHB(X.PERIOD_CODE) THEN
        DBG('PERIOD CODE CONTAINS CYRILLIC');
        P_ERR_CODE := 'CN-CLN-001';
        P_ERROR_PARAMS := 'FIN_CYCLE;';
        ROLLBACK;

        DELETE FROM DETB_UPLOAD_DETAIL
         WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND UPLOAD_STAT = 'U';

        UPDATE GITM_UPLOAD_MASTER
           SET STATUS = 'E'
         WHERE INTERFACE_CODE = P_INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND PHY_FILE_NAME = P_PHY_FILE_NAME
           AND PROCESS_NO = P_PROCESS_NO
           AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
           AND STATUS = 'U';

        INSERT INTO DETBS_UPLOAD_EXCEPTIONS
          (BRANCH_CODE,
           SOURCE_CODE,
           BATCH_NO,
           CURR_NO,
           SEQ_NO,
           ERR_CODE,
           PARAMETERS,
           ERROR_MESSAGE)
        VALUES
          (GLOBAL.CURRENT_BRANCH,
           L_SOURCE_CODE,
           TYP_SINGLEJRNL_LOG.BATCH_NO,
           X.CURR_NO,
           L_SEQ,
           'CN-CLN-001',
           'Failed',
           'PERIOD_CODE;');

        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
        COMMIT;
        RETURN FALSE;
      END IF;

      IF LENGTH(X.CCY_CD) <>  LENGTHB(X.CCY_CD) THEN
        DBG('CURRENCY CONTAINS CYRILLIC');
        P_ERR_CODE := 'CN-CLN-001';
        P_ERROR_PARAMS := 'CURRENCY_CODE;';
        ROLLBACK;

        DELETE FROM DETB_UPLOAD_DETAIL
         WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND UPLOAD_STAT = 'U';

        UPDATE GITM_UPLOAD_MASTER
           SET STATUS = 'E'
         WHERE INTERFACE_CODE = P_INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND PHY_FILE_NAME = P_PHY_FILE_NAME
           AND PROCESS_NO = P_PROCESS_NO
           AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
           AND STATUS = 'U';

        INSERT INTO DETBS_UPLOAD_EXCEPTIONS
          (BRANCH_CODE,
           SOURCE_CODE,
           BATCH_NO,
           CURR_NO,
           SEQ_NO,
           ERR_CODE,
           PARAMETERS,
           ERROR_MESSAGE)
        VALUES
          (GLOBAL.CURRENT_BRANCH,
           L_SOURCE_CODE,
           TYP_SINGLEJRNL_LOG.BATCH_NO,
           X.CURR_NO,
           L_SEQ,
           'CN-CLN-001',
           'Failed',
           'CURRENCY_CODE;');

        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
        COMMIT;
        RETURN FALSE;
      END IF;

      IF LENGTH(X.SOURCE_CODE) <>  LENGTHB(X.SOURCE_CODE) THEN
        DBG('SOURCE_CODE CONTAINS CYRILLIC');
        P_ERR_CODE := 'CN-CLN-001';
        P_ERROR_PARAMS := 'SOURCE_CODE;';
        ROLLBACK;

        DELETE FROM DETB_UPLOAD_DETAIL
         WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND UPLOAD_STAT = 'U';

        UPDATE GITM_UPLOAD_MASTER
           SET STATUS = 'E'
         WHERE INTERFACE_CODE = P_INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND PHY_FILE_NAME = P_PHY_FILE_NAME
           AND PROCESS_NO = P_PROCESS_NO
           AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
           AND STATUS = 'U';

        INSERT INTO DETBS_UPLOAD_EXCEPTIONS
          (BRANCH_CODE,
           SOURCE_CODE,
           BATCH_NO,
           CURR_NO,
           SEQ_NO,
           ERR_CODE,
           PARAMETERS,
           ERROR_MESSAGE)
        VALUES
          (GLOBAL.CURRENT_BRANCH,
           L_SOURCE_CODE,
           TYP_SINGLEJRNL_LOG.BATCH_NO,
           X.CURR_NO,
           L_SEQ,
           'CN-CLN-001',
           'Failed',
           'SOURCE_CODE;');

        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
        COMMIT;
        RETURN FALSE;
      END IF;

      IF LENGTH(X.TXN_CODE) <>  LENGTHB(X.TXN_CODE) THEN
        DBG('TXN CODE CONTAINS CYRILLIC');
        P_ERR_CODE := 'CN-CLN-001';
        P_ERROR_PARAMS := 'TXN_CODE;';
        ROLLBACK;

        DELETE FROM DETB_UPLOAD_DETAIL
         WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND UPLOAD_STAT = 'U';

        UPDATE GITM_UPLOAD_MASTER
           SET STATUS = 'E'
         WHERE INTERFACE_CODE = P_INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND PHY_FILE_NAME = P_PHY_FILE_NAME
           AND PROCESS_NO = P_PROCESS_NO
           AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
           AND STATUS = 'U';

        INSERT INTO DETBS_UPLOAD_EXCEPTIONS
          (BRANCH_CODE,
           SOURCE_CODE,
           BATCH_NO,
           CURR_NO,
           SEQ_NO,
           ERR_CODE,
           PARAMETERS,
           ERROR_MESSAGE)
        VALUES
          (GLOBAL.CURRENT_BRANCH,
           L_SOURCE_CODE,
           TYP_SINGLEJRNL_LOG.BATCH_NO,
           '99996',
           L_SEQ,
           'CN-CLN-001',
           'Failed',
           'TXN_CODE;');

        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
        COMMIT;
        RETURN FALSE;
      END IF;

      IF LENGTH(X.DR_CR) <>  LENGTHB(X.DR_CR) THEN
        DBG('CURRENCY CONTAINS CYRILLIC');
        P_ERR_CODE := 'CN-CLN-001';
        P_ERROR_PARAMS := 'DR_CR;';
        ROLLBACK;

        DELETE FROM DETB_UPLOAD_DETAIL
         WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND UPLOAD_STAT = 'U';

        UPDATE GITM_UPLOAD_MASTER
           SET STATUS = 'E'
         WHERE INTERFACE_CODE = P_INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND PHY_FILE_NAME = P_PHY_FILE_NAME
           AND PROCESS_NO = P_PROCESS_NO
           AND TARGET_TABLE = 'DETB_UPLOAD_DETAIL'
           AND STATUS = 'U';

        INSERT INTO DETBS_UPLOAD_EXCEPTIONS
          (BRANCH_CODE,
           SOURCE_CODE,
           BATCH_NO,
           CURR_NO,
           SEQ_NO,
           ERR_CODE,
           PARAMETERS,
           ERROR_MESSAGE)
        VALUES
          (GLOBAL.CURRENT_BRANCH,
           L_SOURCE_CODE,
           TYP_SINGLEJRNL_LOG.BATCH_NO,
           '99996',
           L_SEQ,
           'CN-CLN-001',
           'Failed',
           'DR_CR;');

        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERROR_PARAMS);
        COMMIT;
        RETURN FALSE;
      END IF;
    END LOOP;

    P_STATUS := 'S';
    /*DELETE FROM DETB_UPLOAD_MASTER
     WHERE SOURCE_CODE = L_SOURCE_CODE
       AND BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

    DELETE FROM DETB_BATCH_MASTER
     WHERE BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;*/--commented as this should fail for duplicate batch

    DBG('Insert into DETB_UPLOAD_MASTER - Batch No - ' ||
        TYP_SINGLEJRNL_LOG.BATCH_NO);
    DBG('global.current_branch - ' || GLOBAL.CURRENT_BRANCH);
    DBG('l_source_code - ' || L_SOURCE_CODE);
    DBG('global.user_id - ' || GLOBAL.USER_ID);
    DBG('typ_singlejrnl_log.txn_code - ' || TYP_SINGLEJRNL_LOG.TXN_CODE);
    INSERT INTO DETBS_UPLOAD_MASTER
      (BRANCH_CODE,
       SOURCE_CODE,
       BATCH_NO,
       TOTAL_ENTRIES,
       BALANCING,
       BATCH_DESC,
       MIS_REQUIRED,
       AUTO_AUTH,
       GL_OFFSET_ENTRY_REQD,
       UDF_UPLOAD_REQD,
       OFFSET_GL,
       USER_ID,
       ONCE_AUTH,
       RECORD_STAT,
       TXN_CODE,
       UPLOAD_STAT,
       UPLOAD_DATE,
       UPLOAD_FILE_NAME,
       AUTH_STAT,
       MOD_NO)
    VALUES
      (GLOBAL.CURRENT_BRANCH,
       L_SOURCE_CODE,
       TYP_SINGLEJRNL_LOG.BATCH_NO,
       NULL,
       'Y',
       TYP_DETB_MASTER.DESCRIPTION,
       'N',
       'Y',
       NULL,
       'Y', --DE Upload Requirement with Budget Code, Tax Code, Supplier Code and Department Code changed N to Y
       NULL,
       GLOBAL.USER_ID,
       'N',
       'O',
       TYP_SINGLEJRNL_LOG.TXN_CODE,
       'U',
       GLOBAL.APPLICATION_DATE,
       P_PHY_FILE_NAME,
       'U',
       '1');

    DBG('Going to call fn_batch_upload.. ');
    IF NOT DEPKSS_UPLOAD.FN_BATCH_UPLOAD(GLOBAL.CURRENT_BRANCH,
                                         GLOBAL.APPLICATION_DATE,
                                         GLOBAL.USER_ID,
                                         TYP_SINGLEJRNL_LOG.BATCH_NO,
                                         L_SOURCE_CODE,
                                         L_INGOVD,
                                         GLOBAL.LCY,
                                         GLOBAL.LANG,
                                         L_MIS_REQUIRED,
                                         L_AUTO_AUTH,
                                         L_UDF_UPLOAD,
                                         'N',
                                         'DUM',
                                         NULL,
                                         P_TOTAL_ENT,
                                         P_ENT_UPLOADED,
                                         P_ENT_REJECTED,
                                         P_ERR_CODE,
                                         P_ERROR_PARAMS) THEN
      DBG('Processing Failed for Batch - ' || TYP_SINGLEJRNL_LOG.BATCH_NO);
      PR_CHK_UPD_AUTH(TYP_SINGLEJRNL_LOG.BATCH_NO);
      RETURN FALSE;
    ELSE
      DBG('Processing Sucessfully completed for Batch - ' ||
          TYP_SINGLEJRNL_LOG.BATCH_NO);

      PR_CHK_UPD_AUTH(TYP_SINGLEJRNL_LOG.BATCH_NO);

      IF P_ENT_REJECTED > 0 THEN
        FOR I IN (SELECT *
                    FROM DETB_UPLOAD_EXCEPTIONS
                   WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                     AND SOURCE_CODE = L_SOURCE_CODE
                     AND BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO
                   ORDER BY CURR_NO) LOOP
          DBG('Processing failed for for Batch - ' ||
              TYP_SINGLEJRNL_LOG.BATCH_NO || ' and Curr No -> ' ||
              I.CURR_NO);
          UPDATE GITU_UPLOAD_MASTER
             SET ERROR       = I.ERR_CODE,
                 ERROR_PARAM = I.ERROR_MESSAGE,
                 STATUS      = 'E'
           WHERE EXTERNAL_SYSTEM = I.SOURCE_CODE
             AND FLD20 = I.BATCH_NO
             AND FLD2 = I.BRANCH_CODE
             AND TO_NUMBER(FLD4) = I.CURR_NO;

        END LOOP;
        FOR I IN (SELECT DISTINCT ERR_CODE, PARAMETERS, ERROR_MESSAGE
                    FROM DETB_UPLOAD_EXCEPTIONS
                   WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                     AND SOURCE_CODE = L_SOURCE_CODE
                     AND BATCH_NO = TYP_SINGLEJRNL_LOG.BATCH_NO) LOOP
          OVPKSS.PR_APPENDTBL(I.ERR_CODE, I.PARAMETERS);
        END LOOP;
        GIPKS_INTERFACE_TRIGGER.G_STATUS := 'E';
        RETURN FALSE;
      END IF;
      IF L_BALANCING = 'Y' THEN
        DBG('Before Calling depkss_upload.fn_check_batch_bal');
        IF NOT DEPKSS_UPLOAD.FN_CHECK_BATCH_BAL(GLOBAL.CURRENT_BRANCH,
                                                TYP_SINGLEJRNL_LOG.BATCH_NO,
                                                P_ERR_CODE,
                                                P_ERROR_PARAMS) THEN
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERROR_PARAMS);
          GIPKS_INTERFACE_TRIGGER.G_STATUS := 'E';
          RETURN FALSE;
        END IF;
        DBG('Before Calling depkss_upload.fn_check_batch_bal_txn');
        IF NOT DEPKSS_UPLOAD.FN_CHECK_BATCH_BAL_TXN(GLOBAL.CURRENT_BRANCH,
                                                    TYP_SINGLEJRNL_LOG.BATCH_NO,
                                                    P_ERR_CODE,
                                                    P_ERROR_PARAMS) THEN
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERROR_PARAMS);
          GIPKS_INTERFACE_TRIGGER.G_STATUS := 'E';
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in fn_upload of GIPKS_#DEDJRONL ' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_UPLOAD;
END GIPKS_#DEDJRONL;
