/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2020, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : DEDJNLON_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = 'N';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_DETBS_JRNL_TXN_MASTER":"REFERENCE_NO~BATCH_NO~CURR_NO~TEMPLATE_ID~VALUE_DATE~BOOK_DATE~BRANCH_CODE~CCY~TOTAL_DR~TOTAL_CR~MAKER~MAKDTTIME~CHKR~CHKDTTIME~AUTHSTAT~TXNSTAT~FUNDID~RECORD_NO~TOTAL_NO~SUBSYSSTAT","BLK_DETBS_JRNL_TXN_DETAIL":"REFERENCE_NO~SERIAL_NO~USER_REF_NO~DR_CR~BRANCH_CODE~AC_OR_GL~AC_GL_NO~CCY~AMOUNT~TXN_CODE~INSTRUMENT_NO~LCY_AMOUNT~ADDL_TEXT~ACC_DESC~RELATED_CUSTOMER~EXCH_RATE~UI_AC_GL_NO~BUDGET_CODE~TAX_CODE~SUPPLIER_CODE~DEPT_CODE~SEGMENT_CODE~PRODUCT_CODE","BLK_DETBS_BATCH_MASTER":"BATCH_NO~DESCRIPTION~DR_CHK_TOTAL~CR_CHK_TOTAL~DR_ENT_TOTAL~CR_ENT_TOTAL","BLK_DEVWS_BATCH_MASTER":"BRANCH_CODE~BATCH_NO~DESCRIPTION~TYPE~LAST_OPER_ID~LAST_AUTH_ID~LAST_OPER_DT_STAMP~LAST_AUTH_DT_STAMP~LOCKED~CURR_NO~DR_CHK_TOTAL~CR_CHK_TOTAL~DR_ENT_TOTAL~CR_ENT_TOTAL~AUTH_STAT~UPLOADED~BALANCING~SYSTEM_BATCH~POSITION_REQD~DELETE_STAT"};

var multipleEntryPageSize = {"BLK_DETBS_JRNL_TXN_DETAIL" :"15" };

var multipleEntrySVBlocks = "";

var tabMEBlks = {"CVS_MAIN__TAB_MAIN":"BLK_DETBS_JRNL_TXN_DETAIL"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_DETBS_JRNL_TXN_MASTER">REFERENCE_NO~BATCH_NO~CURR_NO~TEMPLATE_ID~VALUE_DATE~BOOK_DATE~BRANCH_CODE~CCY~TOTAL_DR~TOTAL_CR~MAKER~MAKDTTIME~CHKR~CHKDTTIME~AUTHSTAT~TXNSTAT~FUNDID~RECORD_NO~TOTAL_NO~SUBSYSSTAT</FN>'; 
msgxml += '      <FN PARENT="BLK_DETBS_JRNL_TXN_MASTER" RELATION_TYPE="N" TYPE="BLK_DETBS_JRNL_TXN_DETAIL">REFERENCE_NO~SERIAL_NO~USER_REF_NO~DR_CR~BRANCH_CODE~AC_OR_GL~AC_GL_NO~CCY~AMOUNT~TXN_CODE~INSTRUMENT_NO~LCY_AMOUNT~ADDL_TEXT~ACC_DESC~RELATED_CUSTOMER~EXCH_RATE~UI_AC_GL_NO~BUDGET_CODE~TAX_CODE~SUPPLIER_CODE~DEPT_CODE~SEGMENT_CODE~PRODUCT_CODE</FN>'; 
msgxml += '      <FN PARENT="BLK_DETBS_JRNL_TXN_MASTER" RELATION_TYPE="1" TYPE="BLK_DETBS_BATCH_MASTER">BATCH_NO~DESCRIPTION~DR_CHK_TOTAL~CR_CHK_TOTAL~DR_ENT_TOTAL~CR_ENT_TOTAL</FN>'; 
msgxml += '      <FN PARENT="BLK_DETBS_JRNL_TXN_MASTER" RELATION_TYPE="1" TYPE="BLK_DEVWS_BATCH_MASTER">BRANCH_CODE~BATCH_NO~DESCRIPTION~TYPE~LAST_OPER_ID~LAST_AUTH_ID~LAST_OPER_DT_STAMP~LAST_AUTH_DT_STAMP~LOCKED~CURR_NO~DR_CHK_TOTAL~CR_CHK_TOTAL~DR_ENT_TOTAL~CR_ENT_TOTAL~AUTH_STAT~UPLOADED~BALANCING~SYSTEM_BATCH~POSITION_REQD~DELETE_STAT</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR SUMMARY SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml_sum=""; 
msgxml_sum += '    <FLD>'; 
msgxml_sum += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_DETBS_JRNL_TXN_MASTER">AUTHSTAT~BRANCH_CODE~BATCH_NO~CURR_NO~REFERENCE_NO~VALUE_DATE~TEMPLATE_ID</FN>'; 
msgxml_sum += '    </FLD>'; 

var detailFuncId = "DEDJNLON";
var defaultWhereClause = "BRANCH_CODE = GLOBAL.CURRENT_BRANCH";
var defaultOrderByClause ="BATCH_NO";
var multiBrnWhereClause ="";
var g_SummaryType ="S";
var g_SummaryBtnCount =0;
var g_SummaryBlock ="BLK_DETBS_JRNL_TXN_MASTER";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_DETBS_JRNL_TXN_MASTER" : "","BLK_DETBS_JRNL_TXN_DETAIL" : "BLK_DETBS_JRNL_TXN_MASTER~N","BLK_DETBS_BATCH_MASTER" : "BLK_DETBS_JRNL_TXN_MASTER~1","BLK_DEVWS_BATCH_MASTER" : "BLK_DETBS_JRNL_TXN_MASTER~1"}; 

 var dataSrcLocationArray = new Array("BLK_DETBS_JRNL_TXN_MASTER","BLK_DETBS_JRNL_TXN_DETAIL","BLK_DETBS_BATCH_MASTER","BLK_DEVWS_BATCH_MASTER"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside DEDJNLON.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside DEDJNLON.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_DETBS_JRNL_TXN_MASTER__REFERENCE_NO";
pkFields[0] = "BLK_DETBS_JRNL_TXN_MASTER__REFERENCE_NO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_DETBS_JRNL_TXN_DETAIL":["ACC_DESC","AC_GL_NO","AC_OR_GL","ADDL_TEXT","AMOUNT","BRANCH_CODE","BUDGET_CODE","CCY","DEPT_CODE","DR_CR","EXCH_RATE","INSTRUMENT_NO","LCY_AMOUNT","RELATED_CUSTOMER","SEGMENT_CODE","SERIAL_NO","SUPPLIER_CODE","TAX_CODE","TXN_CODE","UI_AC_GL_NO"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_DETBS_JRNL_TXN_MASTER__TEMPLATE_ID__LOV_TEMPLATE_ID":["BLK_DETBS_JRNL_TXN_MASTER__TEMPLATE_ID~~","","N~N",""],"BLK_DETBS_JRNL_TXN_MASTER__CCY__LOV_CCY":["BLK_DETBS_JRNL_TXN_MASTER__CCY~~","","N~N",""],"BLK_DETBS_JRNL_TXN_MASTER__FUNDID__LOV_FUNDID":["BLK_DETBS_JRNL_TXN_MASTER__FUNDID~~~~~","","N~N~N~N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__BRANCH_CODE__LOV_BRANCH_CODE":["BLK_DETBS_JRNL_TXN_DETAIL__BRANCH_CODE~~","","N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__CCY__LOV_CCY":["BLK_DETBS_JRNL_TXN_DETAIL__CCY~~","","N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__TXN_CODE__LOV_TXN_CODE":["BLK_DETBS_JRNL_TXN_DETAIL__TXN_CODE~~","","N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__RELATED_CUSTOMER__LOV_CUSTOMER":["BLK_DETBS_JRNL_TXN_DETAIL__RELATED_CUSTOMER~~","","N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__UI_AC_GL_NO__LOV_AC_GL_NO":["BLK_DETBS_JRNL_TXN_DETAIL__UI_AC_GL_NO~BLK_DETBS_JRNL_TXN_DETAIL__ACC_DESC~BLK_DETBS_JRNL_TXN_DETAIL__AC_OR_GL~BLK_DETBS_JRNL_TXN_DETAIL__CCY~BLK_DETBS_JRNL_TXN_DETAIL__RELATED_CUSTOMER~","BLK_DETBS_JRNL_TXN_DETAIL__BRANCH_CODE!VARCHAR2~BLK_DETBS_JRNL_TXN_DETAIL__BRANCH_CODE!VARCHAR2","N~N~N~N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__BUDGET_CODE__LOV_BUDGET_CODE":["BLK_DETBS_JRNL_TXN_DETAIL__BUDGET_CODE~~","","N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__TAX_CODE__LOV_TAX_CODE":["BLK_DETBS_JRNL_TXN_DETAIL__TAX_CODE~~","","N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__DEPT_CODE__LOV_DEPT_CODE":["BLK_DETBS_JRNL_TXN_DETAIL__DEPT_CODE~~","","N~N",""],"BLK_DETBS_JRNL_TXN_DETAIL__PRODUCT_CODE__LOV_PRODUCT_CODE":["BLK_DETBS_JRNL_TXN_DETAIL__PRODUCT_CODE~~","","N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_DETBS_JRNL_TXN_DETAIL");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("MICTRMIS~BLK_DETBS_JRNL_TXN_MASTER","CSCTRUDF~BLK_DETBS_JRNL_TXN_MASTER"); 

 var CallFormRelat=new Array("DETBS_JRNL_TXN_MASTER.REFERENCE_NO = CSTBS_CONTRACT__TRN.CONTRACT_REF_NO","DETBS_JRNL_TXN_MASTER.REFERENCE_NO = UDTBS_CONT_UDF_UPLOAD_DETAIL.CONTRACT_REF_NO AND DETBS_JRNL_TXN_MASTER.CURR_NO = UDTBS_CONT_UDF_UPLOAD_DETAIL.EXT_SEQ_NO"); 

 var CallRelatType= new Array("1","1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["DEDJNLON"]="KERNEL";
ArrPrntFunc["DEDJNLON"]="";
ArrPrntOrigin["DEDJNLON"]="";
ArrRoutingType["DEDJNLON"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["DEDJNLON"]="N";
ArrCustomModified["DEDJNLON"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"MICTRMIS":"CONTREF~ESN","CSCTRUDF":""};
var scrArgSource = {"MICTRMIS":"BLK_DETBS_JRNL_TXN_MASTER__REFERENCE_NO~","CSCTRUDF":""};
var scrArgVals = {"MICTRMIS":"~1","CSCTRUDF":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"MICTRMIS":"","CSCTRUDF":""};
var dpndntOnSrvs = {"MICTRMIS":"","CSCTRUDF":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"2","DELETE":"2","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------