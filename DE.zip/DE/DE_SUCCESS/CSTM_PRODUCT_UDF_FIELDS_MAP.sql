prompt Importing table CSTM_PRODUCT_UDF_FIELDS_MAP...
set feedback off
set define off
insert into CSTM_PRODUCT_UDF_FIELDS_MAP (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('0000', 'BUDGET_CODE', 1, 'A');

insert into CSTM_PRODUCT_UDF_FIELDS_MAP (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('0000', 'SUPPLIER_CODE', 3, 'A');

insert into CSTM_PRODUCT_UDF_FIELDS_MAP (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('0000', 'TAX_CODE', 2, 'A');

prompt Done.
