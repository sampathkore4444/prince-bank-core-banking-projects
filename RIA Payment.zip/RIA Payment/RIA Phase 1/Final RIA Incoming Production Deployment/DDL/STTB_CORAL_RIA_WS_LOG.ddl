-- Create table
create table STTB_CORAL_RIA_WS_LOG
(
  unique_reference_no VARCHAR2(16),
  customer_no         VARCHAR2(9),
  scan_id             VARCHAR2(10),
  invoke_date         DATE,
  req_type            VARCHAR2(16),
  req_msg             CLOB,
  res_msg             CLOB,
  status              VARCHAR2(16),
  action              VARCHAR2(25),
  risk_level          CHAR(1),
  hit_value           VARCHAR2(20),
  fc_ref_no           VARCHAR2(16)
)
/
alter table STTB_CORAL_RIA_WS_LOG add primary key (UNIQUE_REFERENCE_NO, FC_REF_NO)
/