CREATE OR REPLACE PACKAGE BODY IFPKS_SANCTION_UTILS AS

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'IFPKS_SANCTION_UTILS ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  
  PROCEDURE PR_INSERT_CORAL_RIA_WS_LOG(P_UNIQUE_REF_NO IN VARCHAR2,
                                   P_CUST_NO       IN VARCHAR2,
                                   P_DATE          IN DATE,
                                   P_REQ_TYPE      IN VARCHAR2,
                                   P_ACTION_CODE   IN VARCHAR2,
                                   P_REQ_MSG       IN CLOB,
                                   P_FCREF_NO      IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('WHO CALLED ME=' || DBMS_UTILITY.format_call_stack);
    
    INSERT INTO STTB_CORAL_RIA_WS_LOG
      (UNIQUE_REFERENCE_NO,
       CUSTOMER_NO,
       INVOKE_DATE,
       REQ_TYPE,
       REQ_MSG,
       ACTION,
       FC_REF_NO)
    VALUES
      (P_UNIQUE_REF_NO,
       P_CUST_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ACTION_CODE,
       P_FCREF_NO);
  
    COMMIT;
  
  END PR_INSERT_CORAL_RIA_WS_LOG;

  PROCEDURE PR_UPDATE_CORAL_RIA_WS_LOG(P_REFERENCE_NO IN VARCHAR2,
                                   P_SCAN_ID      IN VARCHAR2,
                                   P_STATUS       IN CHAR,
                                   P_RISK_LEVEL   IN CHAR,
                                   P_HIT_VALUE    IN VARCHAR2, --added for temp fix
                                   P_RES_MSG      IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('P_REFERENCE_NO=' || P_REFERENCE_NO);
    
    UPDATE STTB_CORAL_RIA_WS_LOG
       SET SCAN_ID    = P_SCAN_ID,
           RISK_LEVEL = P_RISK_LEVEL,
           HIT_VALUE  = P_HIT_VALUE,
           STATUS     = P_STATUS,
           RES_MSG    = P_RES_MSG
     WHERE UNIQUE_REFERENCE_NO = P_REFERENCE_NO;
  
    COMMIT;
  
  END PR_UPDATE_CORAL_RIA_WS_LOG;


  PROCEDURE PR_INSERT_CORAL_MTA_WS_LOG(P_UNIQUE_REF_NO IN VARCHAR2,
                                       P_CUST_NO       IN VARCHAR2,
                                       P_DATE          IN DATE,
                                       P_REQ_TYPE      IN VARCHAR2,
                                       P_ACTION_CODE   IN VARCHAR2,
                                       P_REQ_MSG       IN CLOB,
                                       P_FCREF_NO      IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('WHO CALLED ME=' || DBMS_UTILITY.format_call_stack);
    INSERT INTO STTB_CORAL_MTA_WS_LOG
      (UNIQUE_REFERENCE_NO,
       CUSTOMER_NO,
       INVOKE_DATE,
       REQ_TYPE,
       REQ_MSG,
       ACTION,
       FC_REF_NO)
    VALUES
      (P_UNIQUE_REF_NO,
       P_CUST_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ACTION_CODE,
       P_FCREF_NO);

    COMMIT;

  END PR_INSERT_CORAL_MTA_WS_LOG;

  PROCEDURE PR_UPDATE_CORAL_MTA_WS_LOG(P_REFERENCE_NO IN VARCHAR2,
                                       P_SCAN_ID      IN VARCHAR2,
                                       P_STATUS       IN CHAR,
                                       P_RISK_LEVEL   IN CHAR,
                                       P_HIT_VALUE    IN VARCHAR2, --added for temp fix
                                       P_RES_MSG      IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('P_REFERENCE_NO=' || P_REFERENCE_NO);
    UPDATE STTB_CORAL_MTA_WS_LOG
       SET SCAN_ID    = P_SCAN_ID,
           RISK_LEVEL = P_RISK_LEVEL,
           HIT_VALUE  = P_HIT_VALUE,
           STATUS     = P_STATUS,
           RES_MSG    = P_RES_MSG
     WHERE UNIQUE_REFERENCE_NO = P_REFERENCE_NO;

    COMMIT;

  END PR_UPDATE_CORAL_MTA_WS_LOG;

  PROCEDURE PR_UPDATE_CORAL_MTA_WS_LOG_OVD(P_REFERENCE_NO IN VARCHAR2,
                                           P_SCAN_ID      IN VARCHAR2,
                                           P_STATUS       IN CHAR,
                                           P_RES_MSG      IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('P_REFERENCE_NO=' || P_REFERENCE_NO);
    UPDATE STTB_CORAL_WS_LOG
       SET SCAN_ID = P_SCAN_ID, STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE UNIQUE_REFERENCE_NO = P_REFERENCE_NO;

    COMMIT;

  END PR_UPDATE_CORAL_MTA_WS_LOG_OVD;

  FUNCTION FN_AML_HTTP_CALL(P_OUT_MSG        CLOB,
                            P_IN_RESP        IN OUT CLOB,
                            P_url            IN VARCHAR2,
                            p_soapaction_url in varchar2,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_BUFFER_SIZE    NUMBER(10) := 1024;
    L_SUBSTRING_MSG  VARCHAR2(32767);
    L_RAW_DATA       RAW(2000);
    L_CLOB_RESPONSE  CLOB;
    L_URL            CSTB_PARAM.PARAM_VAL%TYPE;
    L_RESP_OK        BOOLEAN;
    L_RESP_NUM       NUMBER;
    l_soapaction_url CSTB_PARAM.PARAM_VAL%TYPE;
  BEGIN

    DEBUG.PR_DEBUG('IF', 'In PR_HTTP_CALL');
    DEBUG.PR_DEBUG('IF', '~' || LENGTH(P_OUT_MSG));
    debug.pr_cdebug('IF', 'XML is ' || P_OUT_MSG);

    DBMS_LOB.CREATETEMPORARY(LOB_LOC => L_CLOB_RESPONSE, CACHE => TRUE);
    UTL_HTTP.SET_TRANSFER_TIMEOUT(60);

    SELECT PARAM_VAL
      INTO l_url
      FROM CSTB_PARAM_CUSTOM
     WHERE param_name = UPPER(P_url); --'CORAL_VALIDATION_WS_URL';

    SELECT param_VAL
      INTO l_soapaction_url
      FROM cstb_param_custom
     where param_name = p_soapaction_url;

    DEBUG.PR_DEBUG('IF', 'l_url-->' || L_URL);

    dbms_output.put_line('P_OUT_MSG=' || P_OUT_MSG);
    dbms_output.put_line('l_url=' || l_url);

    L_HTTP_REQUEST := UTL_HTTP.BEGIN_REQUEST(URL          => L_URL,
                                             METHOD       => 'POST',
                                             HTTP_VERSION => 'HTTP/1.1');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST, 'User-Agent', 'Mozilla/4.0');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST, 'Connection', 'close');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    UTL_HTTP.SET_HEADER(L_HTTP_REQUEST,
                        'Content-Length',
                        LENGTH(P_OUT_MSG));
    UTL_HTTP.set_header(l_http_request, 'SOAPAction', l_soapaction_url);
    <<REQUEST_LOOP>>
    FOR I IN 0 .. CEIL(LENGTH(P_OUT_MSG) / L_BUFFER_SIZE) - 1 LOOP
      L_SUBSTRING_MSG := SUBSTR(P_OUT_MSG,
                                I * L_BUFFER_SIZE + 1,
                                L_BUFFER_SIZE);
      DEBUG.PR_DEBUG('FOR', 'L_SUBSTRING_MSG-->' || i || '--' || L_URL);

      BEGIN
        L_RAW_DATA := UTL_RAW.CAST_TO_RAW(L_SUBSTRING_MSG);
        UTL_HTTP.WRITE_RAW(R => L_HTTP_REQUEST, DATA => L_RAW_DATA);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('IF', 'Request Loop NDF');
          EXIT REQUEST_LOOP;
      END;
    END LOOP REQUEST_LOOP;
    L_HTTP_RESPONSE := UTL_HTTP.GET_RESPONSE(L_HTTP_REQUEST);
    DEBUG.PR_DEBUG('IF',
                   'Response> status_code: "' ||
                   L_HTTP_RESPONSE.STATUS_CODE || '"');
    L_RESP_OK := FALSE;
    SELECT DECODE(L_HTTP_RESPONSE.STATUS_CODE, 200, 1, 0)
      INTO L_RESP_NUM
      FROM DUAL;

    DBMS_OUTPUT.put_line('L_HTTP_RESPONSE.STATUS_CODE=' ||
                         L_HTTP_RESPONSE.STATUS_CODE);

    -- IF l_http_response.status_code = 200 THEN
    IF L_RESP_NUM = 1 THEN
      L_RESP_OK := TRUE;
    ELSIF L_RESP_NUM = 0 THEN
      L_RESP_OK := FALSE;
    END IF;

    IF L_RESP_OK THEN
      BEGIN

        LOOP
          UTL_HTTP.READ_RAW(L_HTTP_RESPONSE, L_RAW_DATA, L_BUFFER_SIZE);
          L_CLOB_RESPONSE := L_CLOB_RESPONSE ||
                             UTL_RAW.CAST_TO_VARCHAR2(L_RAW_DATA);
        END LOOP RESPONSE_LOOP;
      EXCEPTION
        WHEN UTL_HTTP.END_OF_BODY THEN
          UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IF', SQLERRM);
          DEBUG.PR_DEBUG('IF', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
      END;
      --  DBG('Out of Loop');
      DEBUG.PR_DEBUG('IF',
                     'Length of response-->' ||
                     DBMS_LOB.GETLENGTH(L_CLOB_RESPONSE));
      DEBUG.PR_DEBUG('IF',
                     'value of response-->' ||
                     DBMS_LOB.SUBSTR(L_CLOB_RESPONSE, 32767));
      P_IN_RESP := L_CLOB_RESPONSE;

    END IF;

    IF L_HTTP_REQUEST.PRIVATE_HNDL IS NOT NULL THEN
      UTL_HTTP.END_REQUEST(L_HTTP_REQUEST);
    END IF;

    IF L_HTTP_RESPONSE.PRIVATE_HNDL IS NOT NULL THEN
      UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
    END IF;

    DBMS_LOB.FREETEMPORARY(L_CLOB_RESPONSE);

    IF L_RESP_OK THEN
      DEBUG.PR_DEBUG('IF', 'OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      DEBUG.PR_DEBUG('IF', 'PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In WOT...Return false now...' || SQLERRM ||
                     dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_AML_HTTP_CALL;
  
  FUNCTION FN_RETURN_AML_RESP_RIA(P_SEND_HIGH_CNT IN VARCHAR2,
                                  P_BEN_HIGH_CNT  IN VARCHAR2,
                                  P_CUSTOMER_NO   IN VARCHAR2,
                                  P_SENDER_NAME   IN VARCHAR2,
                                  P_BEN_NAME      IN VARCHAR2,
                                  P_ACTION_CODE   IN VARCHAR2,
                                  P_FCREF_NO      IN VARCHAR2,
                                  P_HIT_STATUS    OUT VARCHAR2,
                                  P_WHO_HIT       OUT CHAR,
                                  P_SCAN_ID       OUT VARCHAR2,
                                  p_Err_Code      IN OUT VARCHAR2,
                                  p_Err_Params    IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  
    L_COUNT          NUMBER;
    L_FULL_NAME_CHK  STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_DATE_CHK       STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_DATE_CHK1      VARCHAR2(100); --Auto CIF Account Changes for Mobile Banking
    L_COUNTRY_CHK    STTMS_CUSTOMER.COUNTRY%TYPE;
    L_OUT_MSG        CLOB;
    L_IN_RESP        CLOB;
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_ATTR_NODES     DBMS_XMLDOM.DOMNAMEDNODEMAP;
    L_ATTR_NODE      DBMS_XMLDOM.DOMNODE;
    L_ATTRIBUTE_NAME VARCHAR2(50);
    L_NODE_NAME      VARCHAR2(50);
    L_NODE_VALUE     VARCHAR2(100);
    P                DBMS_XMLPARSER.PARSER;
    L_DOC            DBMS_XMLDOM.DOMDOCUMENT;
    L_ROOT_ELEMENT   DBMS_XMLDOM.DOMELEMENT;
    L_CHILD_NODES    DBMS_XMLDOM.DOMNODELIST;
    L_CHILD_NODE     DBMS_XMLDOM.DOMNODE;
    L_TEXT_NODE      DBMS_XMLDOM.DOMNODE;
    L_BASE_NODES     DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODES1    DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODE      DBMS_XMLDOM.DOMNODE;
    -- V_XML_DATA         CLOB;
    L_HIT_VALUE           VARCHAR2(100);
    L_RTN_SCAN_ID         VARCHAR2(100);
    L_RTN_ENCRYPT_SCAN_ID VARCHAR2(4000);
    L_SEARCH_NAME         VARCHAR2(4000);
    L_RETURN_STATUS       VARCHAR2(100);
  
    L_PEP_FLAG           VARCHAR2(2);
    L_COMPLEX_STRUCTURE  VARCHAR2(1000);
    L_NATIONALITY        VARCHAR2(100);
    L_ADVERSE_MEDIA_FLAG VARCHAR2(2);
    L_REL_HIGH_RISK_FLAG VARCHAR2(2);
    L_CHANNEL            VARCHAR2(5);
    L_PROD_RISK          VARCHAR2(2);
    L_ASSET_VALUE        VARCHAR2(2);
    L_STR                VARCHAR2(2);
    L_BEHAVIOUR_TREND    VARCHAR2(2);
    L_OCCUPATION         VARCHAR2(1000);
  
    L_RISK_FACTORS VARCHAR2(1000);
    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE TYPE_RISK_SCORE;
    L_MAX_INDEX  NUMBER;
    L_MAX_VALUE  NUMBER;
    L_REF        VARCHAR2(16);
    L_SEQ        NUMBER;
    L_RISK_LEVEL CHAR(1);
  
    L_FIELD_NUM      NUMBER;
    L_SECURITY_NO_1  CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
    L_SECURITY_NO_2  CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_4%TYPE;
    L_BIRTH_COUNTRY  STTMS_CUSTOMER.COUNTRY%TYPE;
    L_COUNTRY        STTMS_CUSTOMER.COUNTRY%TYPE;
    L_P_COUNTRY      STTMS_CUSTOMER.COUNTRY%TYPE;
    L_ECO_SECTOR     STTMS_CUSTOMER_CUSTOM.ECONOMIC_SEC%TYPE;
    L_R_COUNTRY      STTMS_CUST_CORPORATE.R_COUNTRY%TYPE;
    L_INCORP_COUNTRY STTMS_CUST_CORPORATE.INCORP_COUNTRY%TYPE;
  
    L_PREV_FULL_NAME_CHK     STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_PREV_DATE_CHK          STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_PREV_COUNTRY_CHK       STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_BIRTH_COUNTRY     STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_COUNTRY           STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_NATIONALITY       STTMS_CUSTOMER.NATIONALITY%TYPE;
    L_PREV_P_COUNTRY         STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_ECO_SECTOR        STTMS_CUSTOMER_CUSTOM.ECONOMIC_SEC%TYPE;
    L_PREV_OCCUPATION        STTMS_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_PREV_COMPLEX_STRUCTURE VARCHAR2(1000);
  
    L_PREV_SECURITY_NO_1 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
    L_PREV_SECURITY_NO_2 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_4%TYPE;
  
    L_PREV_R_COUNTRY      STTMS_CUST_CORPORATE.R_COUNTRY%TYPE;
    L_PREV_INCORP_COUNTRY STTMS_CUST_CORPORATE.INCORP_COUNTRY%TYPE;
  
    L_STTB_CORAL_WS_LOG STTB_CORAL_WS_LOG%ROWTYPE;
  
    L_SCAN_OPTION VARCHAR2(3);
    
        L_CURR_BRANCH STTM_BRANCH.BRANCH_CODE%TYPE;

  
  BEGIN
  
    L_SCAN_OPTION := '1|3';
  
    L_FULL_NAME_CHK := P_SENDER_NAME || '|' || P_BEN_NAME;
    
        L_CURR_BRANCH := '994';

  
    L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
         <soapenv:Header/>
         <soapenv:Body>
            <tem:OnlineScan>

               <tem:AuthUser>AMLSVC</tem:AuthUser>

               <tem:AuthPswd>AMLSVC</tem:AuthPswd>

               <tem:Username>' || GLOBAL.user_id ||
                 '</tem:Username>

               <tem:BrCode>' || L_CURR_BRANCH ||
                 '</tem:BrCode>

               <tem:SysName>FCUBS</tem:SysName>

               <tem:ScanOption>' || L_SCAN_OPTION ||
                 '</tem:ScanOption>

               <tem:UniqueNo>' || null ||
                 '</tem:UniqueNo>

               <tem:SearchName>' || L_FULL_NAME_CHK ||
                 '</tem:SearchName>

               <tem:SearchCountry>' || P_SEND_HIGH_CNT || '|' ||
                 P_BEN_HIGH_CNT || '</tem:SearchCountry>

               <tem:SearchDOB>' || '' || '|' ||
                 '</tem:SearchDOB>

               <tem:SearchID>

                 |</tem:SearchID>

               <tem:PassportVerify> |
                 </tem:PassportVerify>

               <tem:SecurityNo1>|
                 </tem:SecurityNo1>

               <tem:PassExpiryDtVerify>|
                 </tem:PassExpiryDtVerify>

               <tem:PassExpiryDate>|
                 </tem:PassExpiryDate>

               <tem:SecurityNo2>|
                 </tem:SecurityNo2>

               <tem:RiskFactors></tem:RiskFactors>

               <tem:Content></tem:Content>

               <tem:RtnHit>1</tem:RtnHit>

               <tem:RtnScanID>0</tem:RtnScanID>

               <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
            </tem:OnlineScan>
         </soapenv:Body>
      </soapenv:Envelope>';
  
    DBG('L_OUT_MSG=' || L_OUT_MSG);
  
    --Log ONLINE_SCAN request xml
    SELECT FC_CORAL_MTA_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    DBG('L_REF=' || L_REF);
  
    PR_INSERT_CORAL_RIA_WS_LOG(L_REF,
                               P_CUSTOMER_NO,
                               SYSDATE,
                               'ONLINE_SCAN',
                               P_ACTION_CODE,
                               L_OUT_MSG,
                               P_FCREF_NO);
  
    IF NOT FN_AML_HTTP_CALL(L_OUT_MSG,
                            L_IN_RESP,
                            'CORAL_VALIDATION_WS_URL',
                            'CORAL_SOAPACTION_WS_URL',
                            P_ERR_CODE,
                            P_ERR_PARAMS)
    
     THEN
    
      DBG('FAILED DURING INVOCATION OF CORAL WEBSERVICES');
      DBG('P_ERR_CODE=' || P_ERR_CODE);
      DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);
    
      DBMS_OUTPUT.put_line('P_ERR_CODE=' || P_ERR_CODE);
      DBMS_OUTPUT.put_line('P_ERR_PARAMS=' || P_ERR_PARAMS);
    
      P_ERR_CODE := 'ST-CRL-003';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    DBG('L_IN_RESP=' || L_IN_RESP);
  
    P := DBMS_XMLPARSER.NEWPARSER;
    DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
    DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
    L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
    L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
    L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                       'Fault');
    --Parsing failure response from coral
    IF (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) THEN
    
      FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
        L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
        L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
        L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
        --
        FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
          L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
          L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
          L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
          L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
          IF L_NODE_NAME = 'faultcode' THEN
            P_ERR_CODE := L_NODE_VALUE;
          ELSIF L_NODE_NAME = 'faultstring' THEN
            P_ERR_PARAMS := L_NODE_VALUE;
          END IF;
        
          P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                          '-- The Webservices returned a fail XML';
        END LOOP;
      END LOOP;
    
      OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);
    
    ELSE
    
      --Parsing Success Response from coral
      L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                       'OnlineScanResponse');
    
      FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) - 1 LOOP
        L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
        L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
        L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
        --
        FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
          L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
          L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
          L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
          L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
          --
          IF L_NODE_NAME = 'RtnHit' THEN
            L_HIT_VALUE := L_NODE_VALUE;
          ELSIF L_NODE_NAME = 'RtnScanID' THEN
            L_RTN_SCAN_ID := L_NODE_VALUE;
          ELSIF L_NODE_NAME = 'RtnEnCryptScanID' THEN
            L_RTN_ENCRYPT_SCAN_ID := L_NODE_VALUE;
          END IF;
        
        END LOOP;
      END LOOP;
    
      DBG('L_HIT_VALUE=' || L_HIT_VALUE);
      DBG('L_RTN_SCAN_ID=' || L_RTN_SCAN_ID);
      DBG('L_RTN_ENCRYPT_SCAN_ID=' || L_RTN_ENCRYPT_SCAN_ID);
    
      IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 OR
         INSTR(SUBSTR(L_HIT_VALUE, 5, 3), 'Y') > 0 OR
         INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'F') > 0 THEN
        L_RETURN_STATUS := 'HIT';
      ELSE
        L_RETURN_STATUS := 'NO HIT';
      END IF;
    
      --sampath starts
      /*IF INSTR(L_HIT_VALUE, '|') > 0 THEN
        L_RISK_LEVEL := SUBSTR(L_HIT_VALUE, INSTR(L_HIT_VALUE, '|') + 1, 1);
      ELSE
        L_RISK_LEVEL := '';
      END IF;*/
      --sampath ends
    
      SELECT SUBSTR(L_HIT_VALUE, INSTR(L_HIT_VALUE, '|') + 1, 1)
        INTO L_RISK_LEVEL
        FROM DUAL;
    
      /* --EAccount Changes Starts
      IF P_SOURCE = 'DIGIKYC' THEN
        L_RISK_LEVEL := 'L';
      END IF;
      --EAccount Changes Ends*/
    
      DBG('BEFORE UPDATING RESPONSE IN THE LOG TABLE=' || L_REF);
      --Update ONLINE_SCAN xml ws response
      PR_UPDATE_CORAL_RIA_WS_LOG(L_REF,
                                 L_RTN_SCAN_ID,
                                 L_RETURN_STATUS,
                                 L_RISK_LEVEL,
                                 L_HIT_VALUE,
                                 L_IN_RESP);
    
      DBG('L_RETURN_STATUS=' || L_RETURN_STATUS);
    
      P_HIT_STATUS := L_RETURN_STATUS;
      P_SCAN_ID    := L_RTN_SCAN_ID;
    
      IF L_RETURN_STATUS = 'HIT' OR L_RISK_LEVEL = 'H' THEN
      
        --PR_LOG_ERROR('DEDRTPRM', 'API1', 'ST-PRIN-023', L_RTN_SCAN_ID);
      
        IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 THEN
        
          P_WHO_HIT := 'S'; --Sender Hit
        
        END IF;
      
        IF INSTR(SUBSTR(L_HIT_VALUE, 5, 3), 'Y') > 0 THEN
        
          P_WHO_HIT := 'R'; --Receiver Hit
        
        END IF;
      
        IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 AND
           INSTR(SUBSTR(L_HIT_VALUE, 5, 3), 'Y') > 0 THEN
        
          P_WHO_HIT := 'B'; --Both Sender and Receiver Hit 
        
        END IF;
      
        RETURN FALSE;
      
      ELSE
        RETURN TRUE;
      END IF;
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_AML_RESP_RIA');
      DBG('ERROR CODE IN FN_RETURN_AML_RESP_RIA=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_AML_RESP_RIA=' || SQLCODE);
      DBG('Error line Number=' || dbms_utility.format_error_backtrace);
      DBMS_OUTPUT.put_line('FAILED IN FN_RETURN_AML_RESP_RIA');
      DBMS_OUTPUT.put_line('ERROR CODE IN FN_RETURN_AML_RESP_RIA=' ||
                           SQLCODE);
      DBMS_OUTPUT.put_line('Error line Number=' ||
                           dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_RETURN_AML_RESP_RIA;



  FUNCTION FN_RETURN_AML_RESP_MTA(P_SEND_HIGH_CNT IN VARCHAR2,
                                  P_BEN_HIGH_CNT  IN VARCHAR2,
                                  P_CUSTOMER_NO   IN VARCHAR2,
                                  P_SENDER_NAME   IN VARCHAR2,
                                  P_BEN_NAME      IN VARCHAR2,
                                  P_ACTION_CODE   IN VARCHAR2,
                                  P_FCREF_NO      IN VARCHAR2,
                                  P_HIT_STATUS    OUT VARCHAR2,
                                  P_WHO_HIT       OUT CHAR,
                                  P_SCAN_ID       OUT VARCHAR2,
                                  p_Err_Code      IN OUT VARCHAR2,
                                  p_Err_Params    IN OUT VARCHAR2)
    RETURN BOOLEAN AS

    L_COUNT          NUMBER;
    L_FULL_NAME_CHK  STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_DATE_CHK       STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_DATE_CHK1      VARCHAR2(100); --Auto CIF Account Changes for Mobile Banking
    L_COUNTRY_CHK    STTMS_CUSTOMER.COUNTRY%TYPE;
    L_OUT_MSG        CLOB;
    L_IN_RESP        CLOB;
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_ATTR_NODES     DBMS_XMLDOM.DOMNAMEDNODEMAP;
    L_ATTR_NODE      DBMS_XMLDOM.DOMNODE;
    L_ATTRIBUTE_NAME VARCHAR2(50);
    L_NODE_NAME      VARCHAR2(50);
    L_NODE_VALUE     VARCHAR2(100);
    P                DBMS_XMLPARSER.PARSER;
    L_DOC            DBMS_XMLDOM.DOMDOCUMENT;
    L_ROOT_ELEMENT   DBMS_XMLDOM.DOMELEMENT;
    L_CHILD_NODES    DBMS_XMLDOM.DOMNODELIST;
    L_CHILD_NODE     DBMS_XMLDOM.DOMNODE;
    L_TEXT_NODE      DBMS_XMLDOM.DOMNODE;
    L_BASE_NODES     DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODES1    DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODE      DBMS_XMLDOM.DOMNODE;
    -- V_XML_DATA         CLOB;
    L_HIT_VALUE           VARCHAR2(100);
    L_RTN_SCAN_ID         VARCHAR2(100);
    L_RTN_ENCRYPT_SCAN_ID VARCHAR2(4000);
    L_SEARCH_NAME         VARCHAR2(4000);
    L_RETURN_STATUS       VARCHAR2(100);

    L_PEP_FLAG           VARCHAR2(2);
    L_COMPLEX_STRUCTURE  VARCHAR2(1000);
    L_NATIONALITY        VARCHAR2(100);
    L_ADVERSE_MEDIA_FLAG VARCHAR2(2);
    L_REL_HIGH_RISK_FLAG VARCHAR2(2);
    L_CHANNEL            VARCHAR2(5);
    L_PROD_RISK          VARCHAR2(2);
    L_ASSET_VALUE        VARCHAR2(2);
    L_STR                VARCHAR2(2);
    L_BEHAVIOUR_TREND    VARCHAR2(2);
    L_OCCUPATION         VARCHAR2(1000);

    L_RISK_FACTORS VARCHAR2(1000);
    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE TYPE_RISK_SCORE;
    L_MAX_INDEX  NUMBER;
    L_MAX_VALUE  NUMBER;
    L_REF        VARCHAR2(16);
    L_SEQ        NUMBER;
    L_RISK_LEVEL CHAR(1);

    L_FIELD_NUM      NUMBER;
    L_SECURITY_NO_1  CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
    L_SECURITY_NO_2  CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_4%TYPE;
    L_BIRTH_COUNTRY  STTMS_CUSTOMER.COUNTRY%TYPE;
    L_COUNTRY        STTMS_CUSTOMER.COUNTRY%TYPE;
    L_P_COUNTRY      STTMS_CUSTOMER.COUNTRY%TYPE;
    L_ECO_SECTOR     STTMS_CUSTOMER_CUSTOM.ECONOMIC_SEC%TYPE;
    L_R_COUNTRY      STTMS_CUST_CORPORATE.R_COUNTRY%TYPE;
    L_INCORP_COUNTRY STTMS_CUST_CORPORATE.INCORP_COUNTRY%TYPE;

    L_PREV_FULL_NAME_CHK     STTMS_CUSTOMER.FULL_NAME%TYPE;
    L_PREV_DATE_CHK          STTMS_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_PREV_COUNTRY_CHK       STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_BIRTH_COUNTRY     STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_COUNTRY           STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_NATIONALITY       STTMS_CUSTOMER.NATIONALITY%TYPE;
    L_PREV_P_COUNTRY         STTMS_CUSTOMER.COUNTRY%TYPE;
    L_PREV_ECO_SECTOR        STTMS_CUSTOMER_CUSTOM.ECONOMIC_SEC%TYPE;
    L_PREV_OCCUPATION        STTMS_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_PREV_COMPLEX_STRUCTURE VARCHAR2(1000);

    L_PREV_SECURITY_NO_1 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
    L_PREV_SECURITY_NO_2 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_4%TYPE;

    L_PREV_R_COUNTRY      STTMS_CUST_CORPORATE.R_COUNTRY%TYPE;
    L_PREV_INCORP_COUNTRY STTMS_CUST_CORPORATE.INCORP_COUNTRY%TYPE;

    L_STTB_CORAL_WS_LOG STTB_CORAL_WS_LOG%ROWTYPE;

    L_SCAN_OPTION VARCHAR2(3);

  BEGIN

    L_SCAN_OPTION := '1|3';

    L_FULL_NAME_CHK := P_SENDER_NAME || '|' || P_BEN_NAME;

    L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
         <soapenv:Header/>
         <soapenv:Body>
            <tem:OnlineScan>

               <tem:AuthUser>AMLSVC</tem:AuthUser>

               <tem:AuthPswd>AMLSVC</tem:AuthPswd>

               <tem:Username>' || GLOBAL.user_id ||
                 '</tem:Username>

               <tem:BrCode>' || GLOBAL.current_branch ||
                 '</tem:BrCode>

               <tem:SysName>FCUBS</tem:SysName>

               <tem:ScanOption>' || L_SCAN_OPTION ||
                 '</tem:ScanOption>

               <tem:UniqueNo>' || null ||
                 '</tem:UniqueNo>

               <tem:SearchName>' || L_FULL_NAME_CHK ||
                 '</tem:SearchName>

               <tem:SearchCountry>' || P_SEND_HIGH_CNT || '|' ||
                 P_BEN_HIGH_CNT || '</tem:SearchCountry>

               <tem:SearchDOB>' || '' || '|' ||
                 '</tem:SearchDOB>

               <tem:SearchID>

                 |</tem:SearchID>

               <tem:PassportVerify> |
                 </tem:PassportVerify>

               <tem:SecurityNo1>|
                 </tem:SecurityNo1>

               <tem:PassExpiryDtVerify>|
                 </tem:PassExpiryDtVerify>

               <tem:PassExpiryDate>|
                 </tem:PassExpiryDate>

               <tem:SecurityNo2>|
                 </tem:SecurityNo2>

               <tem:RiskFactors></tem:RiskFactors>

               <tem:Content></tem:Content>

               <tem:RtnHit>1</tem:RtnHit>

               <tem:RtnScanID>0</tem:RtnScanID>

               <tem:RtnEnCryptScanID></tem:RtnEnCryptScanID>
            </tem:OnlineScan>
         </soapenv:Body>
      </soapenv:Envelope>';

    DBG('L_OUT_MSG=' || L_OUT_MSG);

    --Log ONLINE_SCAN request xml
    SELECT FC_CORAL_MTA_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

    DBG('L_REF=' || L_REF);

    PR_INSERT_CORAL_MTA_WS_LOG(L_REF,
                               P_CUSTOMER_NO,
                               SYSDATE,
                               'ONLINE_SCAN',
                               P_ACTION_CODE,
                               L_OUT_MSG,
                               P_FCREF_NO);

    IF NOT FN_AML_HTTP_CALL(L_OUT_MSG,
                            L_IN_RESP,
                            'CORAL_VALIDATION_WS_URL',
                            'CORAL_SOAPACTION_WS_URL',
                            P_ERR_CODE,
                            P_ERR_PARAMS)

     THEN

      DBG('FAILED DURING INVOCATION OF CORAL WEBSERVICES');
      DBG('P_ERR_CODE=' || P_ERR_CODE);
      DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);

      DBMS_OUTPUT.put_line('P_ERR_CODE=' || P_ERR_CODE);
      DBMS_OUTPUT.put_line('P_ERR_PARAMS=' || P_ERR_PARAMS);

      P_ERR_CODE := 'ST-CRL-003';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
    END IF;

    DBG('L_IN_RESP=' || L_IN_RESP);

    P := DBMS_XMLPARSER.NEWPARSER;
    DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
    DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
    L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
    L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
    L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                       'Fault');
    --Parsing failure response from coral
    IF (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) THEN

      FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
        L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
        L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
        L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
        --
        FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
          L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
          L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
          L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
          L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
          IF L_NODE_NAME = 'faultcode' THEN
            P_ERR_CODE := L_NODE_VALUE;
          ELSIF L_NODE_NAME = 'faultstring' THEN
            P_ERR_PARAMS := L_NODE_VALUE;
          END IF;

          P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                          '-- The Webservices returned a fail XML';
        END LOOP;
      END LOOP;

      OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);

    ELSE

      --Parsing Success Response from coral
      L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                       'OnlineScanResponse');

      FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) - 1 LOOP
        L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
        L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
        L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
        --
        FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
          L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
          L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
          L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
          L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
          --
          IF L_NODE_NAME = 'RtnHit' THEN
            L_HIT_VALUE := L_NODE_VALUE;
          ELSIF L_NODE_NAME = 'RtnScanID' THEN
            L_RTN_SCAN_ID := L_NODE_VALUE;
          ELSIF L_NODE_NAME = 'RtnEnCryptScanID' THEN
            L_RTN_ENCRYPT_SCAN_ID := L_NODE_VALUE;
          END IF;

        END LOOP;
      END LOOP;

      DBG('L_HIT_VALUE=' || L_HIT_VALUE);
      DBG('L_RTN_SCAN_ID=' || L_RTN_SCAN_ID);
      DBG('L_RTN_ENCRYPT_SCAN_ID=' || L_RTN_ENCRYPT_SCAN_ID);

      IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 OR
         INSTR(SUBSTR(L_HIT_VALUE, 5, 3), 'Y') > 0 OR
         INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'F') > 0 THEN
        L_RETURN_STATUS := 'HIT';
      ELSE
        L_RETURN_STATUS := 'NO HIT';
      END IF;

      --sampath starts
      /*IF INSTR(L_HIT_VALUE, '|') > 0 THEN
        L_RISK_LEVEL := SUBSTR(L_HIT_VALUE, INSTR(L_HIT_VALUE, '|') + 1, 1);
      ELSE
        L_RISK_LEVEL := '';
      END IF;*/
      --sampath ends

      SELECT SUBSTR(L_HIT_VALUE, INSTR(L_HIT_VALUE, '|') + 1, 1)
        INTO L_RISK_LEVEL
        FROM DUAL;

      /* --EAccount Changes Starts
      IF P_SOURCE = 'DIGIKYC' THEN
        L_RISK_LEVEL := 'L';
      END IF;
      --EAccount Changes Ends*/

      DBG('BEFORE UPDATING RESPONSE IN THE LOG TABLE=' || L_REF);
      --Update ONLINE_SCAN xml ws response
      PR_UPDATE_CORAL_MTA_WS_LOG(L_REF,
                                 L_RTN_SCAN_ID,
                                 L_RETURN_STATUS,
                                 L_RISK_LEVEL,
                                 L_HIT_VALUE,
                                 L_IN_RESP);

      DBG('L_RETURN_STATUS=' || L_RETURN_STATUS);

      P_HIT_STATUS := L_RETURN_STATUS;
      P_SCAN_ID    := L_RTN_SCAN_ID;

      IF L_RETURN_STATUS = 'HIT' OR L_RISK_LEVEL = 'H' THEN

        --PR_LOG_ERROR('DEDRTPRM', 'API1', 'ST-PRIN-023', L_RTN_SCAN_ID);

        IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 THEN

          P_WHO_HIT := 'S'; --Sender Hit

        END IF;

        IF INSTR(SUBSTR(L_HIT_VALUE, 5, 3), 'Y') > 0 THEN

          P_WHO_HIT := 'R'; --Receiver Hit

        END IF;

        IF INSTR(SUBSTR(L_HIT_VALUE, 1, 3), 'Y') > 0 AND
           INSTR(SUBSTR(L_HIT_VALUE, 5, 3), 'Y') > 0 THEN

          P_WHO_HIT := 'B'; --Both Sender and Receiver Hit

        END IF;

        RETURN FALSE;

      ELSE
        RETURN TRUE;
      END IF;

    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_AML_RESP_MTA');
      DBG('ERROR CODE IN FN_RETURN_AML_RESP_MTA=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_AML_RESP_MTA=' || SQLCODE);
      DBG('Error line Number=' || dbms_utility.format_error_backtrace);
      DBMS_OUTPUT.put_line('FAILED IN FN_RETURN_AML_RESP_MTA');
      DBMS_OUTPUT.put_line('ERROR CODE IN FN_RETURN_AML_RESP_MTA=' ||
                           SQLCODE);
      DBMS_OUTPUT.put_line('ERROR MESSAGE IN FN_RETURN_AML_RESP_MTA=' ||
                           SQLCODE);
      DBMS_OUTPUT.put_line('Error line Number=' ||
                           dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_RETURN_AML_RESP_MTA;

  FUNCTION FN_GET_AML_STATUS_MTA(P_RTN_SCAN_ID IN VARCHAR2,
                                 P_CUSTOMER_NO IN VARCHAR2,
                                 P_FCREF_NO    IN VARCHAR2,
                                 p_Err_Code    IN OUT VARCHAR2,
                                 p_Err_Params  IN OUT VARCHAR2)
    RETURN BOOLEAN AS

    L_OUT_MSG        CLOB;
    L_IN_RESP        CLOB;
    L_HTTP_REQUEST   UTL_HTTP.REQ;
    L_HTTP_RESPONSE  UTL_HTTP.RESP;
    L_ATTR_NODES     DBMS_XMLDOM.DOMNAMEDNODEMAP;
    L_ATTR_NODE      DBMS_XMLDOM.DOMNODE;
    L_ATTRIBUTE_NAME VARCHAR2(50);
    L_NODE_NAME      VARCHAR2(50);
    L_NODE_VALUE     VARCHAR2(100);
    P                DBMS_XMLPARSER.PARSER;
    L_DOC            DBMS_XMLDOM.DOMDOCUMENT;
    L_ROOT_ELEMENT   DBMS_XMLDOM.DOMELEMENT;
    L_CHILD_NODES    DBMS_XMLDOM.DOMNODELIST;
    L_CHILD_NODE     DBMS_XMLDOM.DOMNODE;
    L_TEXT_NODE      DBMS_XMLDOM.DOMNODE;
    L_BASE_NODES     DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODES1    DBMS_XMLDOM.DOMNODELIST;
    L_BASE_NODE      DBMS_XMLDOM.DOMNODE;

    L_SEQ           NUMBER;
    L_REF           VARCHAR2(16);
    L_HIT_VALUE     VARCHAR2(100);
    L_RETURN_STATUS VARCHAR2(100);

  BEGIN

    DBG('START OF FN_GET_AML_STATUS_MTA');

    L_OUT_MSG := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
       <soapenv:Header/>
       <soapenv:Body>
          <tem:OnlineStatus>

             <tem:AuthUser>AMLSVC</tem:AuthUser>

             <tem:AuthPass>AMLSVC</tem:AuthPass>

             <tem:Username>' || GLOBAL.USER_ID ||
                 '</tem:Username>

             <tem:BrCode>' || GLOBAL.CURRENT_BRANCH ||
                 '</tem:BrCode>

             <tem:SysName>FCUBS</tem:SysName>

             <tem:ScanOption>3</tem:ScanOption>
             <tem:UniqueNo></tem:UniqueNo>


             <tem:scanID>' || P_RTN_SCAN_ID ||
                 '</tem:scanID>

             <tem:rtnResult></tem:rtnResult>
          </tem:OnlineStatus>
       </soapenv:Body>
    </soapenv:Envelope>';

    --Log ONLINE_STATUS request xml
    SELECT FC_CORAL_MTA_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;

    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');

    DBG('L_REF=' || L_REF);

    PR_INSERT_CORAL_MTA_WS_LOG(L_REF,
                               P_CUSTOMER_NO,
                               SYSDATE,
                               'ONLINE_STATUS',
                               'STATUSSCAN_AUTH',
                               L_OUT_MSG,
                               P_FCREF_NO);

    IF NOT FN_AML_HTTP_CALL(L_OUT_MSG,
                            L_IN_RESP,
                            'CORAL_VALIDATION_CONFIRM_URL',
                            'CORAL_SOAPACTION_CONFIRM_URL',
                            P_ERR_CODE,
                            P_ERR_PARAMS)

     THEN

      DBG(SQLERRM || ' Failed during invocation of Coral Webservices ' ||
          P_ERR_CODE);
      P_ERR_CODE := 'ST-CRL-003';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
    END IF;

    DBG('L_IN_RESP=' || L_IN_RESP);
    P := DBMS_XMLPARSER.NEWPARSER;
    DBMS_XMLPARSER.SETVALIDATIONMODE(P, FALSE);
    DBMS_XMLPARSER.PARSEBUFFER(P, L_IN_RESP);
    L_DOC          := DBMS_XMLPARSER.GETDOCUMENT(P);
    L_ROOT_ELEMENT := DBMS_XMLDOM.GETDOCUMENTELEMENT(L_DOC);
    L_BASE_NODES1  := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                       'Fault');
    if (DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) > 0) then

      FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES1) - 1 LOOP
        L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES1, J);
        L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
        L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
        --
        FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
          l_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
          L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
          L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
          L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);

          IF L_NODE_NAME = 'faultcode' THEN
            P_ERR_CODE := L_NODE_VALUE;
          ELSIF L_NODE_NAME = 'faultstring' THEN
            P_ERR_PARAMS := L_NODE_VALUE;
          END IF;
          dbg('The Webservices returned a Failed Webservice XML ' ||
              P_ERR_CODE || P_ERR_PARAMS);
          P_ERR_PARAMS := P_ERR_CODE || P_ERR_PARAMS ||
                          '-- The Webservices returned a fail XML';
        END LOOP;
      END LOOP;
      OVPKSS.PR_APPENDTBL('ST-CRL-33', P_ERR_PARAMS);

    Else
      L_BASE_NODES := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(L_ROOT_ELEMENT,
                                                       'OnlineStatusResponse');

      FOR J IN 0 .. DBMS_XMLDOM.GETLENGTH(L_BASE_NODES) LOOP
        L_BASE_NODE   := DBMS_XMLDOM.ITEM(L_BASE_NODES, J);
        L_ATTR_NODES  := DBMS_XMLDOM.GETATTRIBUTES(L_BASE_NODE);
        L_CHILD_NODES := DBMS_XMLDOM.GETCHILDNODES(L_BASE_NODE);
        --
        FOR I IN 0 .. DBMS_XMLDOM.GETLENGTH(L_CHILD_NODES) - 1 LOOP
          L_CHILD_NODE := DBMS_XMLDOM.ITEM(L_CHILD_NODES, I);
          L_NODE_NAME  := DBMS_XMLDOM.GETNODENAME(L_CHILD_NODE);
          L_TEXT_NODE  := DBMS_XMLDOM.GETFIRSTCHILD(L_CHILD_NODE);
          L_NODE_VALUE := DBMS_XMLDOM.GETNODEVALUE(L_TEXT_NODE);
          --
          IF L_NODE_NAME = 'rtnResult' THEN
            L_HIT_VALUE := L_NODE_VALUE;
            DBG('L_HIT_VALUE DURING SECOND WEBSERVICE CALL=' ||
                L_HIT_VALUE);

          END IF;
        END LOOP;
      END LOOP;
      SELECT DECODE(L_HIT_VALUE,
                    'P',
                    'PENDING',
                    'R',
                    'REJECTED',
                    'G',
                    'APPROVED',
                    L_HIT_VALUE)
        INTO L_RETURN_STATUS
        FROM DUAL;
      dbg('L_RETURN_STATUS=' || L_RETURN_STATUS);

      --Update ONLINE_SCAN xml ws response
      PR_UPDATE_CORAL_MTA_WS_LOG_OVD(L_REF,
                                     P_RTN_SCAN_ID,
                                     L_RETURN_STATUS,
                                     L_IN_RESP);

      IF L_RETURN_STATUS IN ('REJECTED') THEN
        P_ERR_CODE := 'ST-PRIN-010';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

      IF L_RETURN_STATUS IN ('PENDING') THEN
        P_ERR_CODE := 'ST-PRIN-011';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AML_STATUS_MTA');
      DBG('ERROR CODE IN FN_GET_AML_STATUS_MTA=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AML_STATUS_MTA=' || SQLERRM);
      RETURN FALSE;

  END FN_GET_AML_STATUS_MTA;

END IFPKS_SANCTION_UTILS;
