insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'BEN_ACC_NAME_RIA', 2, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'BEN_BANK_CODE_RIA', 1, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'BEN_COUNTRY_RIA', 7, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'BEN_NATIONALITY_RIA', 12, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'COUNTRY_FROM_RIA', 8, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'COUNTRY_TO_RIA', 9, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'REFERENCE_NO_RIA', 14, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'REG_ADDR_COUNTRY_RIA', 13, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'REMIT_TYPE_RIA', 10, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'SENDER_COUNTRY_RIA', 6, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'SENDER_FIRST_NAME_RIA', 4, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'SENDER_LAST_NAME_RIA', 5, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'SENDER_NATIONALITY_RIA', 11, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAB', 'TYPE_RIA', 3, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'BEN_ACC_NAME_RIA', 2, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'BEN_BANK_CODE_RIA', 1, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'BEN_COUNTRY_RIA', 7, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'BEN_NATIONALITY_RIA', 12, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'COUNTRY_FROM_RIA', 8, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'COUNTRY_TO_RIA', 9, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'REFERENCE_NO_RIA', 14, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'REG_ADDR_COUNTRY_RIA', 13, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'REMIT_TYPE_RIA', 10, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'SENDER_COUNTRY_RIA', 6, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'SENDER_FIRST_NAME_RIA', 4, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'SENDER_LAST_NAME_RIA', 5, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'SENDER_NATIONALITY_RIA', 11, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAI', 'TYPE_RIA', 3, 'A');

COMMIT;
