CREATE OR REPLACE PACKAGE IFPKS_SANCTION_UTILS AS

  FUNCTION FN_AML_HTTP_CALL(P_OUT_MSG        CLOB,
                            P_IN_RESP        IN OUT CLOB,
                            P_url            IN VARCHAR2,
                            p_soapaction_url in varchar2,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_RETURN_AML_RESP(P_REMIT_TYPE      IN VARCHAR2,
                              P_NAT_OR_ADDR_CNT IN VARCHAR2,
                              P_COUNTRY_FROM    IN VARCHAR2,
                              P_COUNTRY_TO      IN VARCHAR2,
                              P_CUSTOMER_NO     IN VARCHAR2,
                              P_CUST_NAME       IN VARCHAR2,
                              P_ACTION_CODE     IN VARCHAR2,
                              P_HIT_STATUS      OUT VARCHAR2,
                              P_SCAN_ID         OUT VARCHAR2,
                              p_Err_Code        IN OUT VARCHAR2,
                              p_Err_Params      IN OUT VARCHAR2)
    RETURN BOOLEAN;

END IFPKS_SANCTION_UTILS;
