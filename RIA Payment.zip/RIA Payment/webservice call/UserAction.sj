function UserAction() {
    var url = "http://10.80.80.35/AMLWS/AMLWS.svc";
var request = new XMLHttpRequest();
request.open("POST", url);
request.send();
console.log(request.response);
}