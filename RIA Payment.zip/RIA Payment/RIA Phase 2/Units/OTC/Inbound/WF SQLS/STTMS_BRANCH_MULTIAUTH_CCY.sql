prompt Importing table STTMS_BRANCH_MULTIAUTH_CCY...
set feedback off
set define off
insert into STTMS_BRANCH_MULTIAUTH_CCY (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'RIAC', 'KHR');

insert into STTMS_BRANCH_MULTIAUTH_CCY (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'RIAC', 'USD');

prompt Done.
