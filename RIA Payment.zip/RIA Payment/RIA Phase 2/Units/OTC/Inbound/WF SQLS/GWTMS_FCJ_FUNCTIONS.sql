prompt Importing table GWTMS_FCJ_FUNCTIONS...
set feedback off
set define off
insert into GWTMS_FCJ_FUNCTIONS (SERVICE_NAME, OPERATION_CODE, FUNCTION_ID, ACTION, DEFAULT_FUNCTION, LOG_REQD)
values ('FCUBSRTService', 'CalcExchangeAmt', 'RIAC', 'CALCEXCHAMT', null, null);

insert into GWTMS_FCJ_FUNCTIONS (SERVICE_NAME, OPERATION_CODE, FUNCTION_ID, ACTION, DEFAULT_FUNCTION, LOG_REQD)
values ('FCUBSRTService', 'EnrichTransaction', 'RIAC', 'ENRICH', null, null);

insert into GWTMS_FCJ_FUNCTIONS (SERVICE_NAME, OPERATION_CODE, FUNCTION_ID, ACTION, DEFAULT_FUNCTION, LOG_REQD)
values ('FCUBSRTService', 'EnrichTransaction', 'RIAC', 'INPUT', null, null);

insert into GWTMS_FCJ_FUNCTIONS (SERVICE_NAME, OPERATION_CODE, FUNCTION_ID, ACTION, DEFAULT_FUNCTION, LOG_REQD)
values ('FCUBSRTService', 'ResolveVirtualAcc', 'RIAC', 'RESOLVEVIRTUALACC', null, null);

insert into GWTMS_FCJ_FUNCTIONS (SERVICE_NAME, OPERATION_CODE, FUNCTION_ID, ACTION, DEFAULT_FUNCTION, LOG_REQD)
values ('FCUBSRTService', 'ReverseTransaction', 'RIAC', 'REVERSE', null, null);

insert into GWTMS_FCJ_FUNCTIONS (SERVICE_NAME, OPERATION_CODE, FUNCTION_ID, ACTION, DEFAULT_FUNCTION, LOG_REQD)
values ('FCUBSRTService', 'CreateTransaction', 'RIAC', 'SAVEAUTOAUTH', null, null);

prompt Done.
