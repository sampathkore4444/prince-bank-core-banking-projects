prompt Importing table fbtb_branch_multiauth_amt...
set feedback off
set define off
insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'RIAC', 'KHR', 400000000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'RIAC', 'KHR', 10000000000000000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'RIAC', 'USD', 100000.000, null, null);

insert into fbtb_branch_multiauth_amt (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT_SLAB, NO_OF_LEVELS_PATH1, NO_OF_LEVELS_PATH2)
values ('ALL', 'RIAC', 'USD', 999999999999.000, null, null);

prompt Done.
