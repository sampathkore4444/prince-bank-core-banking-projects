prompt Importing table FBTB_FUNC_GROUP...
set feedback off
set define off
insert into FBTB_FUNC_GROUP (TRANSACTION_TYPE, FUNCTIONID)
values ('RT', 'RIAC');

prompt Done.
