prompt Importing table cstms_branch_func_control...
set feedback off
set define off
insert into cstms_branch_func_control (FUNCTION_ID, OFFLINE_SUPPORT, REVERSAL_ALLOWED, CONFIRM_SUPPORT)
values ('RIAC', 'Y', 'Y', null);

prompt Done.
