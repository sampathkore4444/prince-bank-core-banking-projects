prompt Importing table STTM_BRANCH_WF_TXN_LIMIT...
set feedback off
set define off
insert into STTM_BRANCH_WF_TXN_LIMIT (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT, OFFLINE_AMT)
values ('ALL', 'RIAC', 'KHR', 0.000, 0.000);

insert into STTM_BRANCH_WF_TXN_LIMIT (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE, AMOUNT, OFFLINE_AMT)
values ('ALL', 'RIAC', 'USD', 0.000, 0.000);

prompt Done.
