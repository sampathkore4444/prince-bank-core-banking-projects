prompt Importing table smtb_function_description...
set feedback off
set define off
insert into smtb_function_description (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'RIAC', 'Teller', 'Cash Transactions', 'RIA Withdrawal Remittance', null, 'WB', '100', 'RIA Withdrawal Remittance', null);

prompt Done.
