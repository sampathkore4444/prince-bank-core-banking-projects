prompt Importing table LMTM_TYPE_VALUES...
set feedback off
set define off
insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RIA_ACCOUNT', '000021058', 'USD');

prompt Done.
