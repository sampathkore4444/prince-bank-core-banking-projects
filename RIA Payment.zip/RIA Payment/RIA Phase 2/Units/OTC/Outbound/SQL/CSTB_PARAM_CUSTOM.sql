prompt Importing table CSTB_PARAM_CUSTOM...
set feedback off
set define off
insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_AUTH_PWD', 'qwer!@#$', 'Y');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_AIA_AUTH_UID', 'prince', 'Y');

prompt Done.
