CREATE OR REPLACE PACKAGE BODY ifpks_ifdriaft_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdriaft_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2022 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdriaft_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  
  PROCEDURE PR_INSERT_XML_DATA_DTLS(P_TRN_REF_NO IN VARCHAR2,
                                    P_XML_TYPE     IN XMLTYPE) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    INSERT INTO test_xml_data_ria_enq_temp VALUES (P_TRN_REF_NO, P_XML_TYPE);
    DBG('INSERTED INTO TEMP TABLE test_xml_data_ria_enq_temp');
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_XML_DATA_DTLS');
      DBG('ERROR CODE IN PR_INSERT_XML_DATA_DTLS=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_XML_DATA_DTLS=' || SQLERRM);
  END PR_INSERT_XML_DATA_DTLS;

  PROCEDURE PR_DELETE_XML_DATA_DTLS(P_TRN_REF_NO IN VARCHAR2) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    DELETE FROM test_xml_data_ria_enq_temp A WHERE A.TRN_REF_NO = P_TRN_REF_NO;
    DBG('DELETED FROM TEMP TABLE test_xml_data_ria_enq_temp');
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_DELETE_XML_DATA_DTLS');
      DBG('ERROR CODE IN PR_DELETE_XML_DATA_DTLS=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_DELETE_XML_DATA_DTLS=' || SQLERRM);
  END PR_DELETE_XML_DATA_DTLS;
  
  FUNCTION FN_CHECK_TXNLIMIT_PER_DAY(p_ifdriaft IN IFPKS_IFDRIAFT_MAIN.Ty_ifdriaft) RETURN BOOLEAN AS
    
  L_CUST_NO        STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    L_RATE_CODE      CSTM_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_RATE_TYPE      CSTM_PRODUCT.RATE_TYPE_PREFERRED%TYPE;
    L_X_RATE_DERIVED CYTM_RATES.MID_RATE%TYPE;
    L_RATE_FLAG      NUMBER;
    l_txn_amt        DETB_RTL_TELLER.TXN_AMOUNT%TYPE;
    L_AMOUNT         STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_AMOUNT1        STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    P_ERR_CODE       VARCHAR2(100);
    P_ERR_PARAM      VARCHAR2(100);
    
  BEGIN
    
  DBG('START OF FN_CHECK_TXNLIMIT_PER_DAY');
  
  DBG('p_ifdriaft.v_iftb_ria_master.DR_ACC_NO='||p_ifdriaft.v_iftb_ria_master.DR_ACC_NO);
  
    
      --Get Customer no for this offset account
      BEGIN
        SELECT CUST_NO
          INTO L_CUST_NO
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = p_ifdriaft.v_iftb_ria_master.DR_ACC_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NO := NULL;
      END;
      
      DBG('L_CUST_NO='||L_CUST_NO);
    
      IF p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY <> p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY AND
         p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY = 'KHR' THEN
        --KHR AMOUNT COMING IN SWITCH
      
        dbg('inside else condition100');
        dbg('amount coming in switch is KHR nothing but ofs_ccy');
        dbg('amount currency in switch is KHR nothing but txn_amount_Derived');
        dbg('account currency is USD');
      
        BEGIN
        
          SELECT RATE_CODE_PREFERRED, RATE_TYPE_PREFERRED
            INTO L_RATE_CODE, L_RATE_TYPE
            FROM CSTMS_PRODUCT
           WHERE PRODUCT_CODE = 'RIAO'
             AND MODULE = 'RT'
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CODE := 'SW-PRD-01';
            DBG('NO DATA FOUND - cstm_product ' || P_ERR_CODE || '~' ||
                P_ERR_PARAM);
            RETURN FALSE;
        END;
      
        --Get Rate
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENt_branch,
                                 p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY, --KHR currency coming in switch
                                 p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY, --USD account ccy
                                 L_RATE_TYPE,
                                 L_RATE_CODE,
                                 GLOBAL.application_date,
                                 GLOBAL.application_date,
                                 L_X_RATE_DERIVED,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;
      
        DBG('L_X_RATE_DERIVED=' || L_X_RATE_DERIVED);
        DBG('p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY=' ||
            p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY);
        DBG('p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY=' ||
            p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY);
        DBG('p_ifdriaft.v_iftb_ria_master.DR_AMOUNT=' ||
            p_ifdriaft.v_iftb_ria_master.DR_AMOUNT);
      
        --Get USD Amount
        IF p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY = 'KHR' AND
           p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY = 'USD' THEN
          IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.CURRENT_BRANCH,
                                        p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY, --KHR currency coming in switch
                                        p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY, --USD account ccy
                                        L_RATE_TYPE,
                                        'S',
                                        p_ifdriaft.v_iftb_ria_master.DR_AMOUNT, --khr amount comnig ni api
                                        --p_ifdriaft.v_iftb_ria_master.DR_AMOUNT, --khr amount coming in switch
                                        'Y',
                                        l_txn_amt,
                                        L_X_RATE_DERIVED, -- l_rate,
                                        P_ERR_PARAM) THEN
            debug.pr_debug('**', '');
            debug.pr_debug('**', SQLERRM);
            p_err_code  := 'ST-OTHR-001';
            P_ERR_PARAM := NULL;
            RETURN FALSE;
          END IF;
        
          --P_TY_ATM_TXN_REC.TXN_AMT_DERIVED := L_TXN_AMT;
        
          DBG('P_TY_ATM_TXN_REC.TXN_AMT_DERIVED FINAL=' || L_TXN_AMT); --THIS IS USD AMOUNT
        
        ELSE
        
          L_TXN_AMT := p_ifdriaft.v_iftb_ria_master.DR_AMOUNT;
        
        END IF;
      
        --sampath ends for cash deposit exchange rate column in acc entry ends
      
        DBG('L_CUST_NO=' || L_CUST_NO);
      
        BEGIN
        
          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE --AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC --P_TY_ATM_TXN_REC.txn_acc_no_fcc
          /*RELATED_CUSTOMER IN
          (SELECT CUST_NO
             FROM STTM_CUST_ACCOUNT
            WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC)*/
          
           AC_NO IN (SELECT CUST_AC_NO
                       FROM STTM_CUST_ACCOUNT
                      WHERE CUST_NO = L_CUST_NO)
          
           AND CUST_GL = 'A'
           AND AUTH_STAT = 'A'
           --AND USER_ID = 'FLEXCUBEUSER'
           AND MODULE = 'RT'
           AND DRCR_IND = 'D'
          --AND B.PAN = '7777777XXXXXXXXXX'
           AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAO'
           AND A.EVENT NOT IN ('CYPO')
           AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');
        
        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;
      
        DBG('L_AMOUNT==' || L_AMOUNT);
      
        --L_AMOUNT1 := (L_AMOUNT / P_TY_ATM_TXN_REC.X_RATE_DERIVED) + L_TXN_AMT;
      
        L_AMOUNT1 := L_AMOUNT + L_TXN_AMT;
      
        DBG('SUM=' || L_AMOUNT1);
      
        IF 3000 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'FLEXCUBE', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;
      
      ELSIF p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY <> --this elseif case never come as txn ccy is always USD
            p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY AND
            p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY = 'USD' --USD AMOUNT COMING IN SWITCH
       THEN
      
        dbg('inside else condition101');
        dbg('amount coming in switch is usd nothing but ofs_ccy');
        dbg('amount currency in switch is usd nothing but txn_amount_Derived');
        dbg('account currency is khr');
      
        BEGIN
        
          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE --AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC
          /*RELATED_CUSTOMER IN
          (SELECT CUST_NO
             FROM STTM_CUST_ACCOUNT
            WHERE CUST_AC_NO = P_TY_RETAILTLR_UPD.TXN_ACC)*/
           AC_NO IN (SELECT CUST_AC_NO
                       FROM STTM_CUST_ACCOUNT
                      WHERE CUST_NO = L_CUST_NO)
           AND CUST_GL = 'A'
           AND AUTH_STAT = 'A'
           --AND USER_ID = 'FLEXCUBEUSER'
           AND MODULE = 'RT'
           AND DRCR_IND = 'D'
          --AND B.PAN = '7777777XXXXXXXXXX'
           AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAO'
           AND A.EVENT NOT IN ('CYPO')
           AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');
        
        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;
      
        DBG('L_AMOUNT==' || L_AMOUNT);
      
        DBG('p_ifdriaft.v_iftb_ria_master.DR_AMOUNT==' ||
            p_ifdriaft.v_iftb_ria_master.DR_AMOUNT);
      
        L_AMOUNT1 := (L_AMOUNT /* / P_TY_ATM_TXN_REC.X_RATE_DERIVED*/
                     ) + p_ifdriaft.v_iftb_ria_master.DR_AMOUNT;
      
        DBG('SUM=' || L_AMOUNT1);
      
        IF 3000 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'FLEXCUBE', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;
      
      ELSE
      
        dbg('inside final else condition');
      
        dbg('L_AMOUNT==' || L_AMOUNT);
      
        BEGIN
        
          SELECT NVL(SUM(NVL(A.LCY_AMOUNT, 0)), 0)
            INTO L_AMOUNT
            FROM ACTB_DAILY_LOG A
           WHERE AC_NO IN (SELECT CUST_AC_NO
                             FROM STTM_CUST_ACCOUNT
                            WHERE CUST_NO = L_CUST_NO)
             AND CUST_GL = 'A'
             AND AUTH_STAT = 'A'
             --AND USER_ID = 'FLEXCUBEUSER'
             AND MODULE = 'RT'
             AND DRCR_IND = 'D'
             AND SUBSTR(A.TRN_REF_NO, 4, 4) = 'RIAO'
             AND A.EVENT NOT IN ('CYPO')
             AND A.AMOUNT_TAG NOT IN ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3');
        
        EXCEPTION
          WHEN OTHERS THEN
            L_AMOUNT := 0;
        END;
      
        DBG('L_AMOUNT==' || L_AMOUNT);
      
        DBG('p_ifdriaft.v_iftb_ria_master.DR_AMOUNT==' ||
            p_ifdriaft.v_iftb_ria_master.DR_AMOUNT);
      
        --Get Rate
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENt_branch,
                                 p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY, --KHR currency coming in switch
                                 'USD', --USD account ccy
                                 L_RATE_TYPE,
                                 L_RATE_CODE,
                                 GLOBAL.application_date,
                                 GLOBAL.application_date,
                                 L_X_RATE_DERIVED,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;
      
        DBG('L_X_RATE_DERIVED=' || L_X_RATE_DERIVED);
      
        IF p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY = p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY AND
           p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY = 'KHR' THEN
        
          DBG('Inside If condition of apple');
        
          L_AMOUNT1 := (L_AMOUNT) +
                       (p_ifdriaft.v_iftb_ria_master.DR_AMOUNT / L_X_RATE_DERIVED);
        
        ELSE
        
          L_AMOUNT1 := (L_AMOUNT) + p_ifdriaft.v_iftb_ria_master.DR_AMOUNT;
        
        END IF;
      
        DBG('SUM=' || L_AMOUNT1);
      
        IF 3000 - L_AMOUNT1 < 0 THEN
          --P_ERR_CODE := 'SW-LMT-001';
          PR_LOG_ERROR('DEDRTPRM', 'FLEXCUBE', 'SW-LMT-001', null);
          RETURN FALSE;
        END IF;
      
      END IF;
  
  
  DBG('RETURNING SUCCESSFULLY FROM FN_CHECK_TXNLIMIT_PER_DAY');
  
  RETURN TRUE;
    
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_CHECK_TXNLIMIT_PER_DAY');
      DBG('ERROR CODE IN FN_CHECK_TXNLIMIT_PER_DAY='||SQLCODE);
      DBG('ERROR MESSAGE IN FN_CHECK_TXNLIMIT_PER_DAY='||SQLERRM);
    
  END FN_CHECK_TXNLIMIT_PER_DAY;

  FUNCTION FN_GET_RISK_LEVEL_CNT(P_COUNTRY_CODE IN VARCHAR2) RETURN NUMBER IS
    L_VALUE NUMBER;
  BEGIN
    SELECT DECODE(CODE, 'P', 5, 'V', 4, 'H', 3, 'M', '2', 'L', 1, 5)
      INTO L_VALUE
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = 'RISK_LEVEL_CNT'
       AND VALUE = P_COUNTRY_CODE;
  
    RETURN L_VALUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_VALUE;
  END FN_GET_RISK_LEVEL_CNT;

  FUNCTION FN_AML_VALIDATION(p_ifdriaft IN OUT IFPKS_IFDRIAFT_MAIN.ty_ifdriaft)
    RETURN BOOLEAN AS
  
    L_CUSTOMER           STTM_CUSTOMER%ROWTYPE;
    L_CUST_TYPE          VARCHAR2(100);
    L_SENDER_NATIONALITY STTM_CUSTOMER.NATIONALITY%TYPE;
    L_COUNTRY_FROM       STTM_CUSTOMER.NATIONALITY%TYPE;
    L_COUNTRY_TO         VARCHAR2(100); --STTM_CUSTOMER.NATIONALITY%TYPE; pls check
    L_SENDER_FIRST_NAME  STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_SENDER_LAST_NAME   STTM_CUST_PERSONAL.LAST_NAME%TYPE;
    L_SENDER_FULLNAME           STTM_CUSTOMER.FULL_NAME%TYPE;
    P_HIT_STATUS         VARCHAR2(100);
    P_WHO_HIT            CHAR(1);
    L_REG_ADDR_COUNTRY   STTM_CUSTOMER.NATIONALITY%TYPE;
    P_SCAN_ID            VARCHAR2(100);
    P_ERR_CODE           VARCHAR2(100);
    P_ERR_PARAM          VARCHAR2(100);
    L_BEN_NATIONALITY    STTM_CUSTOMER.NATIONALITY%TYPE;
    L_BEN_NAME           STTM_CUSTOMER.FULL_NAME%TYPE;
  
    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE   TYPE_RISK_SCORE;
    L_MAX_INDEX    NUMBER;
    L_MAX_VALUE    NUMBER;
    L_HIGH_SEN_CNT STTM_CUSTOMER.NATIONALITY%TYPE;
    L_HIGH_BEN_CNT STTM_CUSTOMER.NATIONALITY%TYPE;
  
  BEGIN
  
    --Get Customer Type
    BEGIN
    
      SELECT *
        INTO L_CUSTOMER
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = p_ifdriaft.v_iftb_ria_master.dr_acc_no);
    
    EXCEPTION
      WHEN OTHERS THEN
        L_CUSTOMER := NULL;
    END;
  
    DBG('L_CUSTOMER.CUSTOMER_TYPE=' || L_CUSTOMER.CUSTOMER_TYPE);
  
    IF L_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
    
      /*BEGIN
        SELECT B.FIRST_NAME, B.LAST_NAME
          INTO L_SENDER_FIRST_NAME, L_SENDER_LAST_NAME
          FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
         WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
           AND A.CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = p_ifdriaft.v_iftb_ria_master.dr_acc_no);
      EXCEPTION
        WHEN OTHERS THEN
          L_SENDER_FIRST_NAME := NULL;
          L_SENDER_LAST_NAME  := NULL;
      END;*/
      
      BEGIN
        SELECT A.FULL_NAME
          INTO L_SENDER_FULLNAME
          FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
         WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
           AND A.CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = p_ifdriaft.v_iftb_ria_master.dr_acc_no);
      EXCEPTION
        WHEN OTHERS THEN
          L_SENDER_FULLNAME := NULL;
      END;
      
      IF INSTR(L_SENDER_FULLNAME, ' ') > 0 THEN
        
      L_SENDER_FIRST_NAME := SUBSTR(L_SENDER_FULLNAME,1, INSTR(L_SENDER_FULLNAME, ' ')-1);
      L_SENDER_LAST_NAME := SUBSTR(L_SENDER_FULLNAME,INSTR(L_SENDER_FULLNAME, ' ')+1);
      
      ELSE
        
      L_SENDER_FIRST_NAME := L_SENDER_FULLNAME;
        L_SENDER_LAST_NAME := NULL;
      END IF;
    
    END IF;
  
    DBG('L_SENDER_FIRST_NAME=' || L_SENDER_FIRST_NAME);
    DBG('L_SENDER_LAST_NAME=' || L_SENDER_LAST_NAME);
  
    --L_SENDER_NATIONALITY := p_ifdriaft.v_iftb_ria_master.REM_NATIONALITY;
  
    --DBG('L_SENDER_NATIONALITY=' || L_SENDER_NATIONALITY);
  
    --L_COUNTRY_FROM := 'KH';
  
    --DBG('L_COUNTRY_FROM=' || L_COUNTRY_FROM);
  
    L_COUNTRY_TO := p_ifdriaft.v_iftb_ria_master.BEN_COUNTRY; --BEN_COUNTRY PLS CHECK
  
    DBG('L_COUNTRY_TO=' || L_COUNTRY_TO);
  
    --DBG('p_ifdriaft.v_iftb_ria_master.ben_nationality=' ||
    --   p_ifdriaft.v_iftb_ria_master.ben_nationality);
  
    --L_BEN_NATIONALITY := FN_GET_BEN_NAT_ISO_CODE(p_ifdriaft.v_iftb_ria_master.ben_nationality);
  
    --DBG('L_BEN_NATIONALITY=' || L_BEN_NATIONALITY);
  
    L_BEN_NAME := p_ifdriaft.v_iftb_ria_master.BEN_FIRSTNAME || ' ' ||
                  p_ifdriaft.v_iftb_ria_master.BEN_LASTNAME;
  
    DBG('L_BEN_NAME=' || L_BEN_NAME);
  
    --L_REG_ADDR_COUNTRY := p_ifdriaft.v_iftb_ria_master.REM_NATIONALITY;
  
    -- DBG('L_REG_ADDR_COUNTRY=' || L_REG_ADDR_COUNTRY);
  
    -- DBG('L_CUST_TYPE=' || L_CUSTOMER.CUSTOMER_TYPE);
  
    --IF L_CUSTOMER.CUSTOMER_TYPE = 'I' THEN
  
    /*--Sender Highest Country    
    L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_SENDER_NATIONALITY),
                                    FN_GET_RISK_LEVEL_CNT(L_COUNTRY_FROM));
    
    L_MAX_INDEX := 1;
    L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);
    
    FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP
    
      IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
        L_MAX_VALUE := L_RISK_SCORE(G);
        L_MAX_INDEX := G;
      END IF;
    END LOOP;
    
    IF L_MAX_INDEX = 1 THEN
      L_HIGH_SEN_CNT := L_SENDER_NATIONALITY;
    ELSE
      --ELSIF L_MAX_INDEX = 2 THEN
      L_HIGH_SEN_CNT := L_COUNTRY_FROM;
    
    END IF;*/
  
    --Beneficiary Highest Country    
    L_RISK_SCORE := TYPE_RISK_SCORE( --FN_GET_RISK_LEVEL_CNT(L_BEN_NATIONALITY),
                                    FN_GET_RISK_LEVEL_CNT(L_COUNTRY_TO));
  
    L_MAX_INDEX := 1;
    L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);
  
    FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP
    
      IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
        L_MAX_VALUE := L_RISK_SCORE(G);
        L_MAX_INDEX := G;
      END IF;
    END LOOP;
  
    IF L_MAX_INDEX = 1 THEN
      -- L_HIGH_BEN_CNT := L_BEN_NATIONALITY;
      --ELSE
      --ELSIF L_MAX_INDEX = 2 THEN
      L_HIGH_BEN_CNT := L_COUNTRY_TO;
    
    END IF;
  
    /*IF NOT FN_GET_AML_VALIDATED_FOR_DAY(L_CUSTOMER.CUSTOMER_NO,
                                        CASE L_CUSTOMER.CUSTOMER_TYPE WHEN 'I' THEN
                                        L_SENDER_FIRST_NAME || ' ' ||
                                        L_SENDER_LAST_NAME WHEN 'C' THEN
                                        L_SENDER_FIRST_NAME END,
                                        L_BEN_NAME,
                                        L_HIGH_SEN_CNT,
                                        L_HIGH_BEN_CNT) THEN
    
      PR_LOG_ERROR('IFDRIAPA', 'FLEXCUBE', 'IF-MTA-025', null);
      RETURN FALSE;
    
    END IF;*/
  
    --Call AML for both Sender and Beneficiary for individual
    /*IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_OUT( --L_HIGH_SEN_CNT,
                                                           L_HIGH_BEN_CNT,
                                                           L_CUSTOMER.CUSTOMER_NO,
                                                           -- CASE
                                                           -- L_CUSTOMER.CUSTOMER_TYPE WHEN 'I' THEN
                                                           --  L_SENDER_FIRST_NAME || ' ' ||
                                                           -- L_SENDER_LAST_NAME WHEN 'C' THEN
                                                           --L_SENDER_FIRST_NAME END,
                                                           L_BEN_NAME,
                                                           'DOSCAN_AUTH',
                                                           p_ifdriaft.v_iftb_ria_master.TRN_REF_NO,
                                                           P_HIT_STATUS,
                                                           P_WHO_HIT,
                                                           P_SCAN_ID,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
    
      
      
      DBG('P_HIT_STATUS=' || P_HIT_STATUS);
    
      DBG('P_WHO_HIT=' || P_WHO_HIT);
    
      PR_LOG_ERROR('IFDRIAFT', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);
      RETURN FALSE;
    
    ELSE
      RETURN TRUE;
    END IF;*/
    
    IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_OUT_NEW( --L_HIGH_SEN_CNT,
                                                           L_HIGH_BEN_CNT,
                                                           L_CUSTOMER.CUSTOMER_NO,
                                                           -- CASE
                                                           -- L_CUSTOMER.CUSTOMER_TYPE WHEN 'I' THEN
                                                           --  L_SENDER_FIRST_NAME || ' ' ||
                                                           -- L_SENDER_LAST_NAME WHEN 'C' THEN
                                                           --L_SENDER_FIRST_NAME END,
                                                           L_BEN_NAME,
                                                           'DOSCAN_AUTH',
                                                           p_ifdriaft.v_iftb_ria_master.TRN_REF_NO,
                                                           P_HIT_STATUS,
                                                           P_WHO_HIT,
                                                           P_SCAN_ID,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
    
      
      
      DBG('P_HIT_STATUS=' || P_HIT_STATUS);
    
      DBG('P_WHO_HIT=' || P_WHO_HIT);
    
      PR_LOG_ERROR('IFDRIAFT', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);
      RETURN FALSE;
    
    ELSE
      RETURN TRUE;
    END IF;
  
    RETURN FALSE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_AML_VALIDATION=' ||
          DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE IN FN_AML_VALIDATION=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_AML_VALIDATION=' || SQLERRM);
      RETURN FALSE;
  END FN_AML_VALIDATION;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_RIA_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_DO_RIA_ENQUIRY RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_DO_RIA_ENQUIRY');
  
    --L_FORMATTED_MSG := '{"channelCode":"MB","insuranceCode":"$L_INSURANCE_CODE","policyNumber":"$L_POLICY_NUMBER"}';
  
    L_FORMATTED_MSG := '{"ChannelCode": "CBS","BankID": "$L_BANK_ID","PayingCorrespID": "$L_PAYIN_CORR_ID","SendingCorrespBranchNo": "$L_SENDING_CORR_ID","DeliveryMethod": "$L_DELIVERY_METHOD","PaymentCurrency": "$L_PAYMENT_CCY","PaymentAmount": "$L_PAYMENT_AMOUNT","BeneCountry" : "$L_BEN_COUNTRY","BeneficiaryCurrency" : "$L_BEN_CNT_CCY"}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_DO_RIA_ENQUIRY');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_DO_RIA_ENQUIRY');
      DBG('ERROR CODE IN FN_DO_RIA_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_DO_RIA_ENQUIRY=' || SQLERRM);
    
  END FN_DO_RIA_ENQUIRY;

  FUNCTION FN_GET_FMT_RIA_ENQ(p_ifdriaft IN OUT IFPKS_IFDRIAFT_MAIN.Ty_ifdriaft)
    RETURN CLOB IS
  
    L_BANK_ID         IFTB_RIA_MASTER.BANK_ID%TYPE;
    L_PAYIN_CORR_ID   IFTB_RIA_MASTER.PAYIN_CORR_ID%TYPE;
    L_SENDING_CORR_ID IFTB_RIA_MASTER.SENDING_CORR_ID%TYPE;
    L_DELIVERY_METHOD IFTB_RIA_MASTER.DELIVERY_METHOD%TYPE;
    L_PAYMENT_CCY     IFTB_RIA_MASTER.CR_ACC_CCY%TYPE;
    L_PAYMENT_AMOUNT  IFTB_RIA_MASTER.CR_AMOUNT%TYPE;
    L_BEN_COUNTRY     IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_BEN_CNT_CCY     IFTB_RIA_MASTER.BEN_CNT_CCY%TYPE;
    L_FORMATTED_MSG   CLOB; --varchar2(4000);
  
  BEGIN
    DBG('START OF FN_GET_FMT_RIA_ENQ');
  
    L_FORMATTED_MSG := FN_DO_RIA_ENQUIRY;
  
    DBG('BEFORE REPLACEMENT OF RIA ACC ENQUIRY JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values  
  
    L_BANK_ID := P_IFDRIAFT.v_iftb_ria_master.BANK_ID;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BANK_ID', L_BANK_ID);
  
    DBG('ASSIGNED VALUE=' || P_IFDRIAFT.v_iftb_ria_master.PAYIN_CORR_ID);
  
    L_PAYIN_CORR_ID := P_IFDRIAFT.v_iftb_ria_master.PAYIN_CORR_ID;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYIN_CORR_ID',
                               L_PAYIN_CORR_ID);
  
    L_SENDING_CORR_ID := GLOBAL.CURRENT_BRANCH; --P_IFDRIAFT.v_iftb_ria_master.SENDING_CORR_ID;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDING_CORR_ID',
                               L_SENDING_CORR_ID);
  
    L_DELIVERY_METHOD := P_IFDRIAFT.v_iftb_ria_master.DELIVERY_METHOD;
  
    L_DELIVERY_METHOD := CASE L_DELIVERY_METHOD
                           WHEN 'CASH_PIKCUP' THEN
                            '1'
                         
                           WHEN 'BANK_DEPOSIT' THEN
                            '2'
                         END;
  
    DBG('L_DELIVERY_METHOD=' || L_DELIVERY_METHOD);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_DELIVERY_METHOD',
                               L_DELIVERY_METHOD);
  
    L_PAYMENT_CCY := 'USD'; --P_IFDRIAFT.v_iftb_ria_master.CR_ACC_CCY; --pls check
  
    DBG('L_PAYMENT_CCY=' || L_PAYMENT_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_CCY',
                               L_PAYMENT_CCY);
  
    L_PAYMENT_AMOUNT := P_IFDRIAFT.v_iftb_ria_master.TXN_AMOUNT; --P_IFDRIAFT.v_iftb_ria_master.CR_AMOUNT; --pls check
  
    DBG('L_PAYMENT_AMOUNT=' || L_PAYMENT_AMOUNT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_AMOUNT',
                               L_PAYMENT_AMOUNT);
  
    L_BEN_COUNTRY := P_IFDRIAFT.v_iftb_ria_master.BEN_COUNTRY;
  
    DBG('L_BEN_COUNTRY=' || L_BEN_COUNTRY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_COUNTRY',
                               L_BEN_COUNTRY);
  
    L_BEN_CNT_CCY := P_IFDRIAFT.v_iftb_ria_master.BEN_CNT_CCY;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_CNT_CCY',
                               L_BEN_CNT_CCY);
  
    DBG('AFTER REPLACEMENT OF RIA ENQUIRY JSON=' || L_FORMATTED_MSG);
  
    /*L_FORMATTED_MSG := '{
      "ChannelCode": "CBS",
      "PayingCorrespID": "73011411",
      "SendingCorrespBranchNo": "001",
      "DeliveryMethod": "1",
      "PaymentCurrency": "USD",
      "PaymentAmount": "10",
      "BeneCountry" : "VN",
      "BeneficiaryCurrency" : "VND"
    }';*/
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_RIA_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_RIA_ENQ');
      DBG('ERROR CODE IN FN_GET_FMT_RIA_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_RIA_ENQ=' || SQLERRM);
  END FN_GET_FMT_RIA_ENQ;

  FUNCTION FN_GET_RIA_PAYMENT_CASHPICKUP RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('START OF FN_GET_RIA_PAYMENT_CASHPICKUP');
  
    L_FORMATTED_MSG := '{"TransactionUniqueNo":"$L_TXN_UNIQUE_NO", "ChannelCode":"CBS", "CountryTo": "$L_COUNTRY_TO", "PaymentCurrency": "$L_PAYMENT_CCY", "PaymentAmount": "$L_PAYMENT_AMT", "CustFirstName": "$L_CUST_FIRST_NAME", "CustLastName": "$L_CUST_LAST_NAME", "CustAddress": "$L_CUST_ADDRESS", "CustCity": "$L_CUST_CITY", "CustDateBirth": "$L_CUST_DOB", "CustOccupation": "$L_CUST_OCCUPATION", "CustID1Type": "$L_CUST_ID_TYPE", "CustID1No": "$L_CUST_ID_NO", "CustID1ExpDate": "$L_CUST_ID_EXPIRY_DATE", "BeneFirstName": "$L_BEN_FIRST_NAME", "BeneLastName": "$L_BEN_LAST_NAME", "BeneCity": "$L_BEN_CITY", "BeneState": "$L_BEN_STATE",
    "AgentCustID": "$L_AGENT_CUST_ID"}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_RIA_PAYMENT_CASHPICKUP');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_RIA_PAYMENT_CASHPICKUP');
      DBG('ERROR CODE IN FN_GET_RIA_PAYMENT_CASHPICKUP=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_RIA_PAYMENT_CASHPICKUP=' || SQLERRM);
    
  END FN_GET_RIA_PAYMENT_CASHPICKUP;

  FUNCTION FN_GET_FMT_RIA_PAYMENT_CASHPIC(p_ifdriaft IN OUT IFPKS_IFDRIAFT_MAIN.ty_ifdriaft)
    RETURN CLOB IS
  
    L_TXN_UNIQUE_NO IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_AMOUNT        VARCHAR2(105);
    L_CCY           VARCHAR2(3);
    L_FORMATTED_MSG CLOB; --varchar2(4000);
  
    L_COUNTRY_TO      IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_PAYMENT_CCY     IFTB_RIA_MASTER.TXN_CCY%TYPE;
    L_PAYMENT_AMT     IFTB_RIA_MASTER.TXN_AMOUNT%TYPE;
    L_CUST_FIRST_NAME STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_CUST_LAST_NAME  STTM_CUST_PERSONAL.LAST_NAME%TYPE;
  
    L_CUST_ADDRESS        STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_CITY           STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_DOB            VARCHAR2(100);
    L_CUST_OCCUPATION     STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_CUST_ID_TYPE        STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_CUST_ID_NO          STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_CUST_ID_EXPIRY_DATE VARCHAR2(100);
    L_BEN_FIRST_NAME      IFTB_RIA_MASTER.BEN_FIRSTNAME%TYPE;
    L_BEN_LAST_NAME       IFTB_RIA_MASTER.BEN_LASTNAME%TYPE;
    L_BEN_CITY            IFTB_RIA_MASTER.BEN_CITY%TYPE;
    L_BEN_STATE           IFTB_RIA_MASTER.BEN_STATE%TYPE;
  
    L_BANK_ID           IFTB_RIA_MASTER.BANK_ID%TYPE;
    L_BANK_ACCOUNT_NO   IFTB_RIA_MASTER.BANK_ACCOUNT_NO%TYPE;
    L_BANK_ACC_COUNTRY  IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_BANK_ACCOUNT_TYPE IFTB_RIA_MASTER.BANK_ACCOUNT_TYPE%TYPE;
    --L_BANK_ROUTING_CODE IFTB_RIA_MASTER.BANK_ROUTING_CODE%TYPE;
  
    L_ADDRESS_LINE1    STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDRESS_LINE2    STTM_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDRESS_LINE3    STTM_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS_LINE4    STTM_CUSTOMER.ADDRESS_LINE4%TYPE;
    L_UNIQUE_ID_NAME   STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_UNIQUE_ID_VALUE  STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_FIRST_NAME       STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_LAST_NAME        STTM_CUST_PERSONAL.LAST_NAME%TYPE;
    L_SENDER_FULLNAME           STTM_CUSTOMER.FULL_NAME%TYPE;
    L_DOB              STTM_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_OCCUPATION       STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_UNIQUE_ID_EXP_DT STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT%TYPE;
    L_AGENT_CUST_ID    STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    
    L_ADDL_FIELDS_VALUES VARCHAR2(32000); --now changes
  
  BEGIN
    DBG('START OF FN_GET_FMT_RIA_PAYMENT_CASHPIC');
  
    L_FORMATTED_MSG := FN_GET_RIA_PAYMENT_CASHPICKUP;
  
    DBG('BEFORE REPLACEMENT OF RIA PAYMENT JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_TXN_UNIQUE_NO := p_ifdriaft.v_iftb_ria_master.TXN_UNIQUE_NO; --need to change to enquiry id
  
    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);
  
    L_COUNTRY_TO := p_ifdriaft.v_iftb_ria_master.BEN_COUNTRY;
  
    DBG('L_COUNTRY_TO=' || L_COUNTRY_TO);
  
    L_PAYMENT_CCY := p_ifdriaft.v_iftb_ria_master.TXN_CCY;
  
    DBG('L_PAYMENT_CCY=' || L_PAYMENT_CCY);
  
    L_PAYMENT_AMT := p_ifdriaft.v_iftb_ria_master.TXN_AMOUNT;
  
    DBG('L_PAYMENT_AMT=' || L_PAYMENT_AMT);
  
    DBG('p_ifdriaft.v_iftb_ria_master.DR_ACC_NO=' ||
        p_ifdriaft.v_iftb_ria_master.DR_ACC_NO);
  
    BEGIN
    
      SELECT A.ADDRESS_LINE1,
             A.ADDRESS_LINE2,
             A.ADDRESS_LINE3,
             A.ADDRESS_LINE4,
             A.UNIQUE_ID_NAME,
             A.UNIQUE_ID_VALUE,
             B.FIRST_NAME,
             B.LAST_NAME,
             B.DATE_OF_BIRTH,
             C.OCCUPATION,
             C.UNIQUE_ID_EXP_DT,
             A.CUSTOMER_NO
      
        INTO L_ADDRESS_LINE1,
             L_ADDRESS_LINE2,
             L_ADDRESS_LINE3,
             L_ADDRESS_LINE4,
             L_UNIQUE_ID_NAME,
             L_UNIQUE_ID_VALUE,
             L_FIRST_NAME,
             L_LAST_NAME,
             L_DOB,
             L_OCCUPATION,
             L_UNIQUE_ID_EXP_DT,
             L_AGENT_CUST_ID
      
        FROM STTM_CUSTOMER A, sttm_cust_personal B, STTM_CUSTOMER_CUSTOM C
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO = C.CUSTOMER_NO
         AND A.customer_no in
             (select cust_no
                from sttm_cust_account
               where cust_ac_no = p_ifdriaft.v_iftb_ria_master.DR_ACC_NO
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A');
    
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    
    BEGIN
        SELECT A.FULL_NAME
          INTO L_SENDER_FULLNAME
          FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
         WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
           AND A.CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = p_ifdriaft.v_iftb_ria_master.dr_acc_no);
      EXCEPTION
        WHEN OTHERS THEN
          L_SENDER_FULLNAME := NULL;
      END;
      
      IF INSTR(L_SENDER_FULLNAME, ' ') > 0 THEN
        
      L_FIRST_NAME := SUBSTR(L_SENDER_FULLNAME,1, INSTR(L_SENDER_FULLNAME, ' ')-1);
      L_LAST_NAME := SUBSTR(L_SENDER_FULLNAME,INSTR(L_SENDER_FULLNAME, ' ')+1);
      
      ELSE
        
      L_FIRST_NAME := L_SENDER_FULLNAME;
      L_LAST_NAME := NULL;
      END IF;
  
    L_CUST_FIRST_NAME := L_FIRST_NAME;
  
    DBG('L_CUST_FIRST_NAME=' || L_CUST_FIRST_NAME);
  
    L_CUST_LAST_NAME := L_LAST_NAME;
  
    DBG('L_CUST_LAST_NAME=' || L_CUST_FIRST_NAME);
  
    L_CUST_ADDRESS := SUBSTR(L_ADDRESS_LINE1 || ',' || L_ADDRESS_LINE2 || ',' ||
                      L_ADDRESS_LINE3 || ',' || L_ADDRESS_LINE4, 1,50);
  
    DBG('L_CUST_ADDRESS=' || L_CUST_ADDRESS);
  
    L_CUST_CITY := L_ADDRESS_LINE1;
  
    DBG('L_CUST_CITY=' || L_CUST_CITY);
  
    L_CUST_DOB := TO_CHAR(L_DOB, 'YYYYMMDD');
  
    DBG('L_CUST_DOB=' || L_CUST_DOB);
  
    L_CUST_OCCUPATION := L_OCCUPATION;
  
    DBG('L_CUST_OCCUPATION=' || L_CUST_OCCUPATION);
  
    L_CUST_ID_TYPE := L_UNIQUE_ID_NAME;
  
    DBG('L_CUST_ID_TYPE=' || L_CUST_ID_TYPE);
  
    L_CUST_ID_NO := L_UNIQUE_ID_VALUE;
  
    DBG('L_CUST_ID_NO=' || L_CUST_ID_NO);
  
    L_CUST_ID_EXPIRY_DATE := TO_CHAR(L_UNIQUE_ID_EXP_DT, 'YYYYMMDD');
  
    DBG('L_CUST_ID_EXPIRY_DATE=' || L_CUST_ID_EXPIRY_DATE);
    
    DBG('L_AGENT_CUST_ID='||L_AGENT_CUST_ID);
  
    L_BEN_FIRST_NAME := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_FIRSTNAME;
  
    DBG('L_BEN_FIRST_NAME=' || L_BEN_FIRST_NAME);
  
    L_BEN_LAST_NAME := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_LASTNAME;
  
    DBG('L_BEN_LAST_NAME=' || L_BEN_LAST_NAME);
  
    L_BEN_CITY := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_CITY;
  
    DBG('L_BEN_CITY=' || L_BEN_CITY);
  
    L_BEN_STATE := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_STATE;
  
    DBG('L_BEN_STATE=' || L_BEN_STATE);
  
    L_AMOUNT := p_ifdriaft.v_IFTB_RIA_MASTER.cr_amount; --p_ifdriaft.v_cstb_ui_columns.CHAR_FIELD7;
  
    DBG('L_AMOUNT=' || L_AMOUNT);
    
    --now chnages starts
       
FOR G IN (SELECT FIELD_NAME, FIELD_VALUE FROM  iftb_ria_addl_fields
     where trn_ref_no = p_ifdriaft.v_IFTB_RIA_MASTER.TRN_REF_NO
       and field_name not in ('CustAddress',
                              'BeneCity',
                              'BeneState',
                              'CustOccupation',
                              'BankAccountType'--,
                              --'BankRoutingCode'
                              )) LOOP
           
    DBG('G.FIELD_NAME G.FIELD_NAME=='||G.FIELD_NAME);                      
--Transfer Reason Changes Starts
IF G.FIELD_NAME = 'TransferReason' THEN
  
  L_ADDL_FIELDS_VALUES := L_ADDL_FIELDS_VALUES || '"' || G.field_name || '": ' || '"' || p_ifdriaft.v_IFTB_RIA_MASTER.PURPOSE_OF_TRANSFER || '"';

ELSE --Transfer Reason Changes 

L_ADDL_FIELDS_VALUES := L_ADDL_FIELDS_VALUES || '"' || G.field_name || '": ' || '"' || G.field_value || '"';

END IF; --Transfer Reason Changes Ends

L_ADDL_FIELDS_VALUES := L_ADDL_FIELDS_VALUES || ',';


END LOOP;

    DBG('L_ADDL_FIELDS_VALUES ORIGINAL=' || L_ADDL_FIELDS_VALUES);
    
    L_ADDL_FIELDS_VALUES := SUBSTR(L_ADDL_FIELDS_VALUES,1,LENGTH(L_ADDL_FIELDS_VALUES)-1);
    --REPLACE(L_ADDL_FIELDS_VALUES, SUBSTR(L_ADDL_FIELDS_VALUES,-1,1),NULL);
    
    DBG('L_ADDL_FIELDS_VALUES MODIFIED=' || L_ADDL_FIELDS_VALUES);
  
    IF L_ADDL_FIELDS_VALUES IS NOT NULL THEN
    
      L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                 '}',
                                 ',' || L_ADDL_FIELDS_VALUES || '}');
    ELSE
    
      L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_ADDL_FIELDS', NULL);
    
    END IF;
    --now changes ends
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COUNTRY_TO',
                               L_COUNTRY_TO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_CCY',
                               L_PAYMENT_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_AMT',
                               L_PAYMENT_AMT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_FIRST_NAME',
                               L_CUST_FIRST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_LAST_NAME',
                               L_CUST_LAST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ADDRESS',
                               L_CUST_ADDRESS);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CUST_CITY', L_CUST_CITY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CUST_DOB', L_CUST_DOB);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_OCCUPATION',
                               L_CUST_OCCUPATION);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_TYPE',
                               L_CUST_ID_TYPE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_NO',
                               L_CUST_ID_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_EXPIRY_DATE',
                               L_CUST_ID_EXPIRY_DATE);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AGENT_CUST_ID', L_AGENT_CUST_ID);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_FIRST_NAME',
                               L_BEN_FIRST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LAST_NAME',
                               L_BEN_LAST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_CITY', L_BEN_CITY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_STATE', L_BEN_STATE);
  
    DBG('BEFORE REPLACEMENT OF RIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_RIA_PAYMENT_CASHPIC');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_RIA_PAYMENT_CASHPIC');
      DBG('ERROR CODE IN FN_GET_FMT_RIA_PAYMENT_CASHPIC=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_RIA_PAYMENT_CASHPIC=' || SQLERRM);
    
  END FN_GET_FMT_RIA_PAYMENT_CASHPIC;

  FUNCTION FN_GET_FMT_RIA_PAY_CASHPIC_DIG(P_TXN_UNIQUE_NO IN VARCHAR2,
                                          P_BEN_COUNTRY   IN VARCHAR2,
                                          P_PAY_CCY       IN VARCHAR2,
                                          P_PAY_AMOUNT    IN VARCHAR2,
                                          P_OFS_ACC       IN VARCHAR2,
                                          P_BEN_FIRSTNAME IN VARCHAR2,
                                          P_BEN_LASTNAME  IN VARCHAR2,
                                          P_BEN_CITY      IN VARCHAR2,
                                          P_BEN_STATE     IN VARCHAR2)
    RETURN CLOB IS
  
    L_TXN_UNIQUE_NO IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_AMOUNT        VARCHAR2(105);
    L_CCY           VARCHAR2(3);
    L_FORMATTED_MSG CLOB; --varchar2(4000);
  
    L_COUNTRY_TO      IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_PAYMENT_CCY     IFTB_RIA_MASTER.TXN_CCY%TYPE;
    L_PAYMENT_AMT     IFTB_RIA_MASTER.TXN_AMOUNT%TYPE;
    L_CUST_FIRST_NAME STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_CUST_LAST_NAME  STTM_CUST_PERSONAL.LAST_NAME%TYPE;
  
    L_CUST_ADDRESS        STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_CITY           STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_DOB            VARCHAR2(100);
    L_CUST_OCCUPATION     STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_CUST_ID_TYPE        STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_CUST_ID_NO          STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_CUST_ID_EXPIRY_DATE VARCHAR2(100);
    L_BEN_FIRST_NAME      IFTB_RIA_MASTER.BEN_FIRSTNAME%TYPE;
    L_BEN_LAST_NAME       IFTB_RIA_MASTER.BEN_LASTNAME%TYPE;
    L_BEN_CITY            IFTB_RIA_MASTER.BEN_CITY%TYPE;
    L_BEN_STATE           IFTB_RIA_MASTER.BEN_STATE%TYPE;
  
    L_BANK_ID           IFTB_RIA_MASTER.BANK_ID%TYPE;
    L_BANK_ACCOUNT_NO   IFTB_RIA_MASTER.BANK_ACCOUNT_NO%TYPE;
    L_BANK_ACC_COUNTRY  IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_BANK_ACCOUNT_TYPE IFTB_RIA_MASTER.BANK_ACCOUNT_TYPE%TYPE;
    --L_BANK_ROUTING_CODE IFTB_RIA_MASTER.BANK_ROUTING_CODE%TYPE;
  
    L_ADDRESS_LINE1    STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDRESS_LINE2    STTM_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDRESS_LINE3    STTM_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS_LINE4    STTM_CUSTOMER.ADDRESS_LINE4%TYPE;
    L_UNIQUE_ID_NAME   STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_UNIQUE_ID_VALUE  STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_FIRST_NAME       STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_LAST_NAME        STTM_CUST_PERSONAL.LAST_NAME%TYPE;
    L_DOB              STTM_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_OCCUPATION       STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_UNIQUE_ID_EXP_DT STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT%TYPE;
  
  BEGIN
    DBG('START OF FN_GET_FMT_RIA_PAY_CASHPIC_DIG');
  
    L_FORMATTED_MSG := FN_GET_RIA_PAYMENT_CASHPICKUP;
  
    DBG('BEFORE REPLACEMENT OF RIA PAYMENT JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_TXN_UNIQUE_NO := P_TXN_UNIQUE_NO; --need to change to enquiry id
  
    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);
  
    L_COUNTRY_TO := P_BEN_COUNTRY;
  
    DBG('L_COUNTRY_TO=' || L_COUNTRY_TO);
  
    L_PAYMENT_CCY := P_PAY_CCY;
  
    DBG('L_PAYMENT_CCY=' || L_PAYMENT_CCY);
  
    L_PAYMENT_AMT := P_PAY_AMOUNT;
  
    DBG('L_PAYMENT_AMT=' || L_PAYMENT_AMT);
  
    DBG('P_OFS_ACC=' || P_OFS_ACC);
  
    BEGIN
    
      SELECT A.ADDRESS_LINE1,
             A.ADDRESS_LINE2,
             A.ADDRESS_LINE3,
             A.ADDRESS_LINE4,
             A.UNIQUE_ID_NAME,
             A.UNIQUE_ID_VALUE,
             B.FIRST_NAME,
             B.LAST_NAME,
             B.DATE_OF_BIRTH,
             C.OCCUPATION,
             C.UNIQUE_ID_EXP_DT
      
        INTO L_ADDRESS_LINE1,
             L_ADDRESS_LINE2,
             L_ADDRESS_LINE3,
             L_ADDRESS_LINE4,
             L_UNIQUE_ID_NAME,
             L_UNIQUE_ID_VALUE,
             L_FIRST_NAME,
             L_LAST_NAME,
             L_DOB,
             L_OCCUPATION,
             L_UNIQUE_ID_EXP_DT
      
        FROM STTM_CUSTOMER A, sttm_cust_personal B, STTM_CUSTOMER_CUSTOM C
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO = C.CUSTOMER_NO
         AND A.customer_no in (select cust_no
                                 from sttm_cust_account
                                where cust_ac_no = P_OFS_ACC
                                  AND RECORD_STAT = 'O'
                                  AND AUTH_STAT = 'A');
    
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  
    L_CUST_FIRST_NAME := L_FIRST_NAME;
  
    DBG('L_CUST_FIRST_NAME=' || L_CUST_FIRST_NAME);
  
    L_CUST_LAST_NAME := L_LAST_NAME;
  
    DBG('L_CUST_LAST_NAME=' || L_CUST_FIRST_NAME);
  
    L_CUST_ADDRESS := substr(L_ADDRESS_LINE1 || ',' || L_ADDRESS_LINE2 || ',' ||
                      L_ADDRESS_LINE3 || ',' || L_ADDRESS_LINE4,1,50);
  
    DBG('L_CUST_ADDRESS=' || L_CUST_ADDRESS);
  
    L_CUST_CITY := L_ADDRESS_LINE1;
  
    DBG('L_CUST_CITY=' || L_CUST_CITY);
  
    L_CUST_DOB := TO_CHAR(L_DOB, 'YYYYMMDD');
  
    DBG('L_CUST_DOB=' || L_CUST_DOB);
  
    L_CUST_OCCUPATION := L_OCCUPATION;
  
    DBG('L_CUST_OCCUPATION=' || L_CUST_OCCUPATION);
  
    L_CUST_ID_TYPE := L_UNIQUE_ID_NAME;
  
    DBG('L_CUST_ID_TYPE=' || L_CUST_ID_TYPE);
  
    L_CUST_ID_NO := L_UNIQUE_ID_VALUE;
  
    DBG('L_CUST_ID_NO=' || L_CUST_ID_NO);
  
    L_CUST_ID_EXPIRY_DATE := TO_CHAR(L_UNIQUE_ID_EXP_DT, 'YYYYMMDD');
  
    DBG('L_CUST_ID_EXPIRY_DATE=' || L_CUST_ID_EXPIRY_DATE);
  
    L_BEN_FIRST_NAME := P_BEN_FIRSTNAME;
  
    DBG('L_BEN_FIRST_NAME=' || L_BEN_FIRST_NAME);
  
    L_BEN_LAST_NAME := P_BEN_LASTNAME;
  
    DBG('L_BEN_LAST_NAME=' || L_BEN_LAST_NAME);
  
    L_BEN_CITY := P_BEN_CITY;
  
    DBG('L_BEN_CITY=' || L_BEN_CITY);
  
    L_BEN_STATE := P_BEN_STATE;
  
    DBG('L_BEN_STATE=' || L_BEN_STATE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COUNTRY_TO',
                               L_COUNTRY_TO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_CCY',
                               L_PAYMENT_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_AMT',
                               L_PAYMENT_AMT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_FIRST_NAME',
                               L_CUST_FIRST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_LAST_NAME',
                               L_CUST_LAST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ADDRESS',
                               L_CUST_ADDRESS);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CUST_CITY', L_CUST_CITY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CUST_DOB', L_CUST_DOB);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_OCCUPATION',
                               L_CUST_OCCUPATION);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_TYPE',
                               L_CUST_ID_TYPE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_NO',
                               L_CUST_ID_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_EXPIRY_DATE',
                               L_CUST_ID_EXPIRY_DATE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_FIRST_NAME',
                               L_BEN_FIRST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LAST_NAME',
                               L_BEN_LAST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_CITY', L_BEN_CITY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_STATE', L_BEN_STATE);
  
    DBG('BEFORE REPLACEMENT OF RIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_RIA_PAY_CASHPIC_DIG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_RIA_PAY_CASHPIC_DIG');
      DBG('ERROR CODE IN FN_GET_FMT_RIA_PAY_CASHPIC_DIG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_RIA_PAY_CASHPIC_DIG=' || SQLERRM);
    
  END FN_GET_FMT_RIA_PAY_CASHPIC_DIG;

  FUNCTION FN_GET_RIA_PAYMENT RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_RIA_PAYMENT');
  
    /*L_FORMATTED_MSG := '{"TransactionUniqueNo":"$L_TXN_UNIQUE_NO", "ChannelCode":"CBS", "CountryTo": "$L_COUNTRY_TO", "PaymentCurrency": "$L_PAYMENT_CCY", "PaymentAmount": "$L_PAYMENT_AMT", "CustFirstName": "$L_CUST_FIRST_NAME", "CustLastName": "$L_CUST_LAST_NAME", "CustAddress": "$L_CUST_ADDRESS", "CustCity": "$L_CUST_CITY", "CustDateBirth": "$L_CUST_DOB", "CustOccupation": "$L_CUST_OCCUPATION", "CustID1Type": "$L_CUST_ID_TYPE", "CustID1No": "$L_CUST_ID_NO", "CustID1ExpDate": "$L_CUST_ID_EXPIRY_DATE", "BeneFirstName": "$L_BEN_FIRST_NAME", "BeneLastName": "$L_BEN_LAST_NAME", "BeneCity": "$L_BEN_CITY", "BeneState": "$L_BEN_STATE", 
    "BankID": "$L_BANK_ID", "BankAccountNo": "$L_BANK_ACCOUNT_NO", "BankRoutingCode": "$L_BANK_ROUTING_CODE", "BankAccountCountry": "$L_BANK_ACC_COUNTRY", 
    "BankAccountType" : "$L_BANK_ACCOUNT_TYPE",
    "AgentCustID": "$L_AGENT_CUST_ID"}';*/
    
    
    L_FORMATTED_MSG := '{"TransactionUniqueNo":"$L_TXN_UNIQUE_NO", "ChannelCode":"CBS", "CountryTo": "$L_COUNTRY_TO", "PaymentCurrency": "$L_PAYMENT_CCY", "PaymentAmount": "$L_PAYMENT_AMT", "CustFirstName": "$L_CUST_FIRST_NAME", "CustLastName": "$L_CUST_LAST_NAME", "CustAddress": "$L_CUST_ADDRESS", "CustCity": "$L_CUST_CITY", "CustDateBirth": "$L_CUST_DOB", "CustOccupation": "$L_CUST_OCCUPATION", "CustID1Type": "$L_CUST_ID_TYPE", "CustID1No": "$L_CUST_ID_NO", "CustID1ExpDate": "$L_CUST_ID_EXPIRY_DATE", "BeneFirstName": "$L_BEN_FIRST_NAME", "BeneLastName": "$L_BEN_LAST_NAME", "BeneCity": "$L_BEN_CITY", "BeneState": "$L_BEN_STATE", 
    "BankID": "$L_BANK_ID", "BankAccountNo": "$L_BANK_ACCOUNT_NO", "BankAccountCountry": "$L_BANK_ACC_COUNTRY", 
    "BankAccountType" : "$L_BANK_ACCOUNT_TYPE",
    "AgentCustID": "$L_AGENT_CUST_ID"}';
    
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_RIA_PAYMENT');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_RIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_RIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_RIA_PAYMENT=' || SQLERRM);
    
  END FN_GET_RIA_PAYMENT;
  
  FUNCTION FN_GET_RIA_PAYMENT_DIG RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_RIA_PAYMENT_DIG');
  
    L_FORMATTED_MSG := '{
"TransactionUniqueNo":"$L_TXN_UNIQUE_NO_RIAA", 
"ChannelCode":"CBS", 
"CountryTo": "$L_BEN_COUNTRY_RIAA", 
"PaymentCurrency": "$L_PAYMENT_CCY", 
"PaymentAmount": "$L_PAYMENT_AMOUNT", 
"CustFirstName": "$L_CUST_FIRST_NAME", 
"CustLastName": "$L_CUST_LAST_NAME", 
"CustAddress": "$L_CUST_ADDRESS", 
"CustCity": "$L_CUST_CITY", 
"CustDateBirth": "$L_CUST_DOB", 
"CustOccupation": "$L_CUST_OCCUPATION", 
"CustID1Type": "$L_CUST_ID_TYPE", 
"CustID1No": "$L_CUST_ID_NO", 
"CustID1ExpDate": "$L_CUST_ID_EXPIRY_DATE", 
"AgentCustID": "$L_AGENT_CUST_ID",
"BeneFirstName": "$L_BEN_FIRST_NAME_RIAA", 
"BeneLastName": "$L_BEN_LAST_NAME_RIAA", 
"BeneCity": "$L_BEN_CITY_RIAA", 
"BeneState": "$L_BEN_STATE_RIAA", 
"BankID": "$L_BANK_ID_RIAA", 
"BankAccountNo": "$L_BEN_ACCOUNT_NO_RIAA", 
"BankRoutingCode": "$L_BANK_ROUTING_CODE_RIAA", 
"BankAccountCountry": "$L_BEN_COUNTRY_RIAA", 
"BankAccountType": "$L_BANK_ACCOUNT_TYPE_RIAA",
"TransferReason": "$L_PURPOSE_OF_TRF_RIAA",
"BeneIDType": "$L_BEN_ID_TYPE_RIAA",
"BeneIDNo": "$L_BEN_ID_NO_RIAA",
"BIC_SWIFT": "$L_BIC_SWIFT_RIAA",
"BenePhoneNo": "$L_BEN_PHONE_RIAA",
"BeneAddress": "$L_BEN_ADDRESS_RIAA",
"CustBeneRelationship": "$L_CUST_BEN_RELATIONSHIP_RIAA",
"UnitaryBankAccountNo": "$L_UNITARY_BANK_ACC_NO_RIAA",
"BeneCellNo": "$L_BEN_CELL_NO_RIAA",
"CustID1IssuedByCountry": "$L_CUST_ID_ISSUED_BY_COUNTRY"
}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_RIA_PAYMENT');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_RIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_RIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_RIA_PAYMENT=' || SQLERRM);
    
  END FN_GET_RIA_PAYMENT_DIG;

  FUNCTION FN_GET_FMT_RIA_PAYMENT(p_ifdriaft IN OUT IFPKS_IFDRIAFT_MAIN.ty_ifdriaft)
    RETURN CLOB IS
  
    L_TXN_UNIQUE_NO IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_AMOUNT        VARCHAR2(105);
    L_CCY           VARCHAR2(3);
    L_FORMATTED_MSG CLOB; --varchar2(4000);
  
    L_COUNTRY_TO      IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_PAYMENT_CCY     IFTB_RIA_MASTER.TXN_CCY%TYPE;
    L_PAYMENT_AMT     IFTB_RIA_MASTER.TXN_AMOUNT%TYPE;
    L_CUST_FIRST_NAME STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_CUST_LAST_NAME  STTM_CUST_PERSONAL.LAST_NAME%TYPE;
  
    L_CUST_ADDRESS        STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_CITY           STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_DOB            VARCHAR2(100);
    L_CUST_OCCUPATION     STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_CUST_ID_TYPE        STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_CUST_ID_NO          STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_CUST_ID_EXPIRY_DATE VARCHAR2(100);
    L_BEN_FIRST_NAME      IFTB_RIA_MASTER.BEN_FIRSTNAME%TYPE;
    L_BEN_LAST_NAME       IFTB_RIA_MASTER.BEN_LASTNAME%TYPE;
    L_BEN_CITY            IFTB_RIA_MASTER.BEN_CITY%TYPE;
    L_BEN_STATE           IFTB_RIA_MASTER.BEN_STATE%TYPE;
  
    L_BANK_ID           IFTB_RIA_MASTER.BANK_ID%TYPE;
    L_BANK_ACCOUNT_NO   IFTB_RIA_MASTER.BANK_ACCOUNT_NO%TYPE;
    L_BANK_ACC_COUNTRY  IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_BANK_ACCOUNT_TYPE IFTB_RIA_MASTER.BANK_ACCOUNT_TYPE%TYPE;
    --L_BANK_ROUTING_CODE IFTB_RIA_MASTER.BANK_ROUTING_CODE%TYPE;
  
    L_ADDRESS_LINE1    STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDRESS_LINE2    STTM_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDRESS_LINE3    STTM_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS_LINE4    STTM_CUSTOMER.ADDRESS_LINE4%TYPE;
    L_UNIQUE_ID_NAME   STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_UNIQUE_ID_VALUE  STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_FIRST_NAME       STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_LAST_NAME        STTM_CUST_PERSONAL.LAST_NAME%TYPE;
    L_SENDER_FULLNAME           STTM_CUSTOMER.FULL_NAME%TYPE;
    L_DOB              STTM_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_OCCUPATION       STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_UNIQUE_ID_EXP_DT STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT%TYPE;
    L_AGENT_CUST_ID    STTM_CUSTOMER.CUSTOMER_NO%TYPE;
  
    L_ADDL_FIELDS_VALUES VARCHAR2(32000);
  
  BEGIN
    DBG('SATRT OF FN_GET_FMT_RIA_PAYMENT');
  
    L_FORMATTED_MSG := FN_GET_RIA_PAYMENT;
  
    DBG('BEFORE REPLACEMENT OF RIA PAYMENT JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_TXN_UNIQUE_NO := p_ifdriaft.v_iftb_ria_master.TXN_UNIQUE_NO; --need to change to enquiry id
  
    DBG('L_TXN_UNIQUE_NO=' || L_TXN_UNIQUE_NO);
  
    L_COUNTRY_TO := p_ifdriaft.v_iftb_ria_master.BEN_COUNTRY;
  
    DBG('L_COUNTRY_TO=' || L_COUNTRY_TO);
  
    L_PAYMENT_CCY := p_ifdriaft.v_iftb_ria_master.TXN_CCY;
  
    DBG('L_PAYMENT_CCY=' || L_PAYMENT_CCY);
  
    L_PAYMENT_AMT := p_ifdriaft.v_iftb_ria_master.TXN_AMOUNT;
  
    DBG('L_PAYMENT_AMT=' || L_PAYMENT_AMT);
  
    DBG('p_ifdriaft.v_iftb_ria_master.DR_ACC_NO=' ||
        p_ifdriaft.v_iftb_ria_master.DR_ACC_NO);
  
    BEGIN
    
      SELECT A.ADDRESS_LINE1,
             A.ADDRESS_LINE2,
             A.ADDRESS_LINE3,
             A.ADDRESS_LINE4,
             A.UNIQUE_ID_NAME,
             A.UNIQUE_ID_VALUE,
             B.FIRST_NAME,
             B.LAST_NAME,
             B.DATE_OF_BIRTH,
             C.OCCUPATION,
             C.UNIQUE_ID_EXP_DT,
             A.CUSTOMER_NO
      
        INTO L_ADDRESS_LINE1,
             L_ADDRESS_LINE2,
             L_ADDRESS_LINE3,
             L_ADDRESS_LINE4,
             L_UNIQUE_ID_NAME,
             L_UNIQUE_ID_VALUE,
             L_FIRST_NAME,
             L_LAST_NAME,
             L_DOB,
             L_OCCUPATION,
             L_UNIQUE_ID_EXP_DT,
             L_AGENT_CUST_ID
      
        FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B, STTM_CUSTOMER_CUSTOM C
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO = C.CUSTOMER_NO
         AND A.CUSTOMER_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_IFDRIAFT.V_IFTB_RIA_MASTER.DR_ACC_NO
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A');
    
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    
    BEGIN
        SELECT A.FULL_NAME
          INTO L_SENDER_FULLNAME
          FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
         WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
           AND A.CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = p_ifdriaft.v_iftb_ria_master.dr_acc_no);
      EXCEPTION
        WHEN OTHERS THEN
          L_SENDER_FULLNAME := NULL;
      END;
      
      IF INSTR(L_SENDER_FULLNAME, ' ') > 0 THEN
        
      L_FIRST_NAME := SUBSTR(L_SENDER_FULLNAME,1, INSTR(L_SENDER_FULLNAME, ' ')-1);
      L_LAST_NAME := SUBSTR(L_SENDER_FULLNAME,INSTR(L_SENDER_FULLNAME, ' ')+1);
      
      ELSE
        
      L_FIRST_NAME := L_SENDER_FULLNAME;
      L_LAST_NAME := NULL;
      END IF;
  
    L_CUST_FIRST_NAME := L_FIRST_NAME;
  
    DBG('L_CUST_FIRST_NAME=' || L_CUST_FIRST_NAME);
  
    L_CUST_LAST_NAME := L_LAST_NAME;
  
    DBG('L_CUST_LAST_NAME=' || L_CUST_FIRST_NAME);
  
    L_CUST_ADDRESS := substr(L_ADDRESS_LINE1 || ',' || L_ADDRESS_LINE2 || ',' ||
                      L_ADDRESS_LINE3 || ',' || L_ADDRESS_LINE4,1,50);
  
    DBG('L_CUST_ADDRESS=' || L_CUST_ADDRESS);
  
    L_CUST_CITY := L_ADDRESS_LINE1;
  
    DBG('L_CUST_CITY=' || L_CUST_CITY);
  
    L_CUST_DOB := TO_CHAR(L_DOB, 'YYYYMMDD');
  
    DBG('L_CUST_DOB=' || L_CUST_DOB);
  
    L_CUST_OCCUPATION := L_OCCUPATION;
  
    DBG('L_CUST_OCCUPATION=' || L_CUST_OCCUPATION);
  
    L_CUST_ID_TYPE := L_UNIQUE_ID_NAME;
  
    DBG('L_CUST_ID_TYPE=' || L_CUST_ID_TYPE);
  
    L_CUST_ID_NO := L_UNIQUE_ID_VALUE;
  
    DBG('L_CUST_ID_NO=' || L_CUST_ID_NO);
  
    L_CUST_ID_EXPIRY_DATE := TO_CHAR(L_UNIQUE_ID_EXP_DT, 'YYYYMMDD');
  
    DBG('L_CUST_ID_EXPIRY_DATE=' || L_CUST_ID_EXPIRY_DATE);
    
    DBG('L_AGENT_CUST_ID='||L_AGENT_CUST_ID);
  
    L_BEN_FIRST_NAME := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_FIRSTNAME;
  
    DBG('L_BEN_FIRST_NAME=' || L_BEN_FIRST_NAME);
  
    L_BEN_LAST_NAME := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_LASTNAME;
  
    DBG('L_BEN_LAST_NAME=' || L_BEN_LAST_NAME);
  
    L_BEN_CITY := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_CITY;
  
    DBG('L_BEN_CITY=' || L_BEN_CITY);
  
    L_BEN_STATE := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_STATE;
  
    DBG('L_BEN_STATE=' || L_BEN_STATE);
  
    L_BANK_ID := p_ifdriaft.v_IFTB_RIA_MASTER.BANK_ID;
  
    DBG('L_BANK_ID=' || L_BANK_ID);
  
    L_BANK_ACCOUNT_NO := p_ifdriaft.v_IFTB_RIA_MASTER.BANK_ACCOUNT_NO;
  
    DBG('L_BANK_ACCOUNT_NO=' || L_BANK_ACCOUNT_NO);
  
    L_BANK_ACC_COUNTRY := p_ifdriaft.v_IFTB_RIA_MASTER.BEN_COUNTRY; --pls check
  
    DBG('L_BANK_ACC_COUNTRY=' || L_BANK_ACC_COUNTRY);
  
    L_BANK_ACCOUNT_TYPE := p_ifdriaft.v_IFTB_RIA_MASTER.BANK_ACCOUNT_TYPE; --pls check
  
    DBG('L_BANK_ACCOUNT_TYPE=' || L_BANK_ACCOUNT_TYPE);
  
    --L_BANK_ROUTING_CODE := p_ifdriaft.v_IFTB_RIA_MASTER.BANK_ROUTING_CODE;
  
    --DBG('L_BANK_ROUTING_CODE=' || L_BANK_ROUTING_CODE);
  
    L_AMOUNT := p_ifdriaft.v_IFTB_RIA_MASTER.cr_amount; --p_ifdriaft.v_cstb_ui_columns.CHAR_FIELD7;
  
    DBG('L_AMOUNT=' || L_AMOUNT);
  
   /* select '"' || field_name || '": ' || '"' || field_value || '"'
      INTO L_ADDL_FIELDS_VALUES
      from iftb_ria_addl_fields
     where trn_ref_no = p_ifdriaft.v_IFTB_RIA_MASTER.TRN_REF_NO
       and field_name not in ('CustAddress',
                              'BeneCity',
                              'BeneState',
                              'CustOccupation',
                              'BankAccountType',
                              'BankRoutingCode');*/
    
    
FOR G IN (SELECT FIELD_NAME, FIELD_VALUE FROM  iftb_ria_addl_fields
     where trn_ref_no = p_ifdriaft.v_IFTB_RIA_MASTER.TRN_REF_NO
       and field_name not in ('CustAddress',
                              'BeneCity',
                              'BeneState',
                              'CustOccupation',
                              'BankAccountType'--,
                              --'BankRoutingCode'
                              )) LOOP
           
    DBG('G.FIELD_NAME G.FIELD_NAME=='||G.FIELD_NAME);                      
--Transfer Reason Changes Starts
IF G.FIELD_NAME = 'TransferReason' THEN
  
  L_ADDL_FIELDS_VALUES := L_ADDL_FIELDS_VALUES || '"' || G.field_name || '": ' || '"' || p_ifdriaft.v_IFTB_RIA_MASTER.PURPOSE_OF_TRANSFER || '"';

ELSE --Transfer Reason Changes 

L_ADDL_FIELDS_VALUES := L_ADDL_FIELDS_VALUES || '"' || G.field_name || '": ' || '"' || G.field_value || '"';

END IF; --Transfer Reason Changes Ends

L_ADDL_FIELDS_VALUES := L_ADDL_FIELDS_VALUES || ',';


END LOOP;

    DBG('L_ADDL_FIELDS_VALUES ORIGINAL=' || L_ADDL_FIELDS_VALUES);
    
    L_ADDL_FIELDS_VALUES := SUBSTR(L_ADDL_FIELDS_VALUES,1,LENGTH(L_ADDL_FIELDS_VALUES)-1);
    --REPLACE(L_ADDL_FIELDS_VALUES, SUBSTR(L_ADDL_FIELDS_VALUES,-1,1),NULL);
    
    DBG('L_ADDL_FIELDS_VALUES MODIFIED=' || L_ADDL_FIELDS_VALUES);
  
    IF L_ADDL_FIELDS_VALUES IS NOT NULL THEN
    
      L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                                 '}',
                                 ',' || L_ADDL_FIELDS_VALUES || '}');
    ELSE
    
      L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_ADDL_FIELDS', NULL);
    
    END IF;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO',
                               L_TXN_UNIQUE_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COUNTRY_TO',
                               L_COUNTRY_TO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_CCY',
                               L_PAYMENT_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_AMT',
                               L_PAYMENT_AMT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_FIRST_NAME',
                               L_CUST_FIRST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_LAST_NAME',
                               L_CUST_LAST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ADDRESS',
                               L_CUST_ADDRESS);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CUST_CITY', L_CUST_CITY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CUST_DOB', L_CUST_DOB);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_OCCUPATION',
                               L_CUST_OCCUPATION);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_TYPE',
                               L_CUST_ID_TYPE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_NO',
                               L_CUST_ID_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_EXPIRY_DATE',
                               L_CUST_ID_EXPIRY_DATE);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AGENT_CUST_ID', L_AGENT_CUST_ID);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_FIRST_NAME',
                               L_BEN_FIRST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LAST_NAME',
                               L_BEN_LAST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_CITY', L_BEN_CITY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_STATE', L_BEN_STATE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BANK_ID', L_BANK_ID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BANK_ACCOUNT_NO',
                               L_BANK_ACCOUNT_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BANK_ACC_COUNTRY',
                               L_BANK_ACC_COUNTRY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BANK_ACCOUNT_TYPE',
                               'Checking');
  
    /*L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BANK_ROUTING_CODE',
                               L_BANK_ROUTING_CODE);*/
  
    DBG('BEFORE REPLACEMENT OF RIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_RIA_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_RIA_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_RIA_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_RIA_PAYMENT=' || SQLERRM);
    
  END FN_GET_FMT_RIA_PAYMENT;

  FUNCTION FN_GET_FMT_RIA_PAYMENT_DIG(P_TXN_UNIQUE_NO_RIAA         IN VARCHAR2,
                                    P_BEN_COUNTRY_RIAA           IN VARCHAR2,
                                    P_PAYMENT_CCY                    IN VARCHAR2,
                                    P_PAYMENT_AMOUNT                 IN VARCHAR2,
                                    P_OFS_ACC                    IN VARCHAR2,
                                    P_BEN_FIRST_NAME_RIAA        IN VARCHAR2,
                                    P_BEN_LAST_NAME_RIAA         IN VARCHAR2,
                                    P_BANK_ID_RIAA               IN VARCHAR2,
                                    P_BEN_ACCOUNT_NO_RIAA        IN VARCHAR2,
                                    P_BEN_CITY_RIAA              IN VARCHAR2,
                                    P_BEN_STATE_RIAA             IN VARCHAR2,
                                    P_BANK_ACCOUNT_TYPE_RIAA     IN VARCHAR2,
                                    P_BANK_ROUTING_CODE_RIAA     IN VARCHAR2,
                                    P_PURPOSE_OF_TRF_RIAA        IN VARCHAR2,
                                    P_BEN_ID_TYPE_RIAA           IN VARCHAR2,
                                    P_BEN_ID_NO_RIAA             IN VARCHAR2,
                                    P_BIC_SWIFT_RIAA             IN VARCHAR2,
                                    P_BEN_PHONE_RIAA             IN VARCHAR2,
                                    P_VALUE_TYPE_RIAA            IN VARCHAR2,
                                    P_BEN_ADDRESS_RIAA           IN VARCHAR2,
                                    P_CUST_BEN_RELATIONSHIP_RIAA IN VARCHAR2,
                                    P_UNITARY_BANK_ACC_NO_RIAA   IN VARCHAR2,
                                    P_BEN_CELL_NO_RIAA           IN VARCHAR2)
    RETURN CLOB IS
  
    L_TXN_UNIQUE_NO_RIAA IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE; --need to change to enquiry id
    L_AMOUNT        VARCHAR2(105);
    L_CCY           VARCHAR2(3);
    L_FORMATTED_MSG CLOB; --varchar2(4000);
  
    L_COUNTRY_TO      IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_PAYMENT_CCY     IFTB_RIA_MASTER.TXN_CCY%TYPE;
    L_PAYMENT_AMOUNT     IFTB_RIA_MASTER.TXN_AMOUNT%TYPE;
    L_CUST_FIRST_NAME STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_CUST_LAST_NAME  STTM_CUST_PERSONAL.LAST_NAME%TYPE;
  
    L_CUST_ADDRESS        STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_CITY           STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_DOB            VARCHAR2(100);
    L_CUST_OCCUPATION     STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_CUST_ID_TYPE        STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_CUST_ID_NO          STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_CUST_ID_EXPIRY_DATE VARCHAR2(100);
L_AGENT_CUST_ID    STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    
  
    L_BANK_ID           IFTB_RIA_MASTER.BANK_ID%TYPE;
    L_BANK_ACCOUNT_NO   IFTB_RIA_MASTER.BANK_ACCOUNT_NO%TYPE;
    L_BANK_ACC_COUNTRY  IFTB_RIA_MASTER.BEN_COUNTRY%TYPE;
    L_BANK_ACCOUNT_TYPE IFTB_RIA_MASTER.BANK_ACCOUNT_TYPE%TYPE;
    
    L_BEN_FIRST_NAME_RIAA      IFTB_RIA_MASTER.BEN_FIRSTNAME%TYPE;
    L_BEN_LAST_NAME_RIAA  IFTB_RIA_MASTER.BEN_LASTNAME%TYPE;
    L_BEN_CITY_RIAA            IFTB_RIA_MASTER.BEN_CITY%TYPE;
    L_BEN_STATE_RIAA IFTB_RIA_MASTER.BEN_STATE%TYPE;
    L_BANK_ID_RIAA  IFTB_RIA_MASTER.BANK_ID%TYPE;
    L_BEN_ACCOUNT_NO_RIAA  VARCHAR2(255);
    L_BANK_ROUTING_CODE_RIAA  VARCHAR2(255);
    L_BEN_COUNTRY_RIAA  VARCHAR2(255);
    L_BANK_ACCOUNT_TYPE_RIAA  VARCHAR2(255);
    L_PURPOSE_OF_TRF_RIAA  VARCHAR2(255);
    L_BEN_ID_TYPE_RIAA  VARCHAR2(255);
    L_BEN_ID_NO_RIAA  VARCHAR2(255);
    L_BIC_SWIFT_RIAA  VARCHAR2(255);
    L_BEN_PHONE_RIAA  VARCHAR2(255);
    L_VALUE_TYPE_RIAA  VARCHAR2(255);
    L_BEN_ADDRESS_RIAA  VARCHAR2(255);
    L_CUST_BEN_RELATIONSHIP_RIAA  VARCHAR2(255);
    L_UNITARY_BANK_ACC_NO_RIAA  VARCHAR2(255);
    L_BEN_CELL_NO_RIAA  VARCHAR2(255);
  
    L_ADDRESS_LINE1    STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDRESS_LINE2    STTM_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDRESS_LINE3    STTM_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS_LINE4    STTM_CUSTOMER.ADDRESS_LINE4%TYPE;
    L_UNIQUE_ID_NAME   STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_UNIQUE_ID_VALUE  STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_FIRST_NAME       STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_LAST_NAME        STTM_CUST_PERSONAL.LAST_NAME%TYPE;
    L_DOB              STTM_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_OCCUPATION       STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_UNIQUE_ID_EXP_DT STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT%TYPE;
    L_NATIONALITY    STTM_CUSTOMER.NATIONALITY%TYPE;
    L_CUST_ID_ISSUED_BY_COUNTRY STTM_CUSTOMER.NATIONALITY%TYPE;
  
  BEGIN
    DBG('SATRT OF FN_GET_FMT_RIA_PAYMENT');
  
    L_FORMATTED_MSG := FN_GET_RIA_PAYMENT_DIG;
  
    DBG('BEFORE REPLACEMENT OF RIA PAYMENT JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_TXN_UNIQUE_NO_RIAA := P_TXN_UNIQUE_NO_RIAA; --need to change to enquiry id
  
    DBG('L_TXN_UNIQUE_NO_RIAA=' || L_TXN_UNIQUE_NO_RIAA);
  
    L_BEN_COUNTRY_RIAA := P_BEN_COUNTRY_RIAA;
  
    DBG('L_BEN_COUNTRY_RIAA=' || L_BEN_COUNTRY_RIAA);
  
    L_PAYMENT_CCY := P_PAYMENT_CCY;
  
    DBG('L_PAYMENT_CCY=' || L_PAYMENT_CCY);
  
    L_PAYMENT_AMOUNT := P_PAYMENT_AMOUNT;
  
    DBG('L_PAYMENT_AMOUNT=' || L_PAYMENT_AMOUNT);
  
    DBG('P_OFS_ACC=' || P_OFS_ACC);
  
    BEGIN
    
      SELECT A.ADDRESS_LINE1,
             A.ADDRESS_LINE2,
             A.ADDRESS_LINE3,
             A.ADDRESS_LINE4,
             A.UNIQUE_ID_NAME,
             A.UNIQUE_ID_VALUE,
             B.FIRST_NAME,
             B.LAST_NAME,
             B.DATE_OF_BIRTH,
             C.OCCUPATION,
             C.UNIQUE_ID_EXP_DT,
             A.NATIONALITY,
             A.CUSTOMER_NO
      
        INTO L_ADDRESS_LINE1,
             L_ADDRESS_LINE2,
             L_ADDRESS_LINE3,
             L_ADDRESS_LINE4,
             L_UNIQUE_ID_NAME,
             L_UNIQUE_ID_VALUE,
             L_FIRST_NAME,
             L_LAST_NAME,
             L_DOB,
             L_OCCUPATION,
             L_UNIQUE_ID_EXP_DT,
             L_NATIONALITY,
             L_AGENT_CUST_ID
      
        FROM STTM_CUSTOMER A, sttm_cust_personal B, STTM_CUSTOMER_CUSTOM C
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.CUSTOMER_NO = C.CUSTOMER_NO
         AND A.customer_no in (select cust_no
                                 from sttm_cust_account
                                where cust_ac_no = P_OFS_ACC
                                  AND RECORD_STAT = 'O'
                                  AND AUTH_STAT = 'A');
    
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  
    L_CUST_FIRST_NAME := L_FIRST_NAME;
  
    DBG('L_CUST_FIRST_NAME=' || L_CUST_FIRST_NAME);
  
    L_CUST_LAST_NAME := L_LAST_NAME;
  
    DBG('L_CUST_LAST_NAME=' || L_CUST_FIRST_NAME);
  
    L_CUST_ADDRESS := substr(L_ADDRESS_LINE1 || ',' || L_ADDRESS_LINE2 || ',' ||
                      L_ADDRESS_LINE3 || ',' || L_ADDRESS_LINE4,1,50);
  
    DBG('L_CUST_ADDRESS=' || L_CUST_ADDRESS);
  
    L_CUST_CITY := L_ADDRESS_LINE1;
  
    DBG('L_CUST_CITY=' || L_CUST_CITY);
  
    L_CUST_DOB := TO_CHAR(L_DOB, 'YYYYMMDD');
  
    DBG('L_CUST_DOB=' || L_CUST_DOB);
  
    L_CUST_OCCUPATION := L_OCCUPATION;
  
    DBG('L_CUST_OCCUPATION=' || L_CUST_OCCUPATION);
  
    L_CUST_ID_TYPE := L_UNIQUE_ID_NAME;
  
    DBG('L_CUST_ID_TYPE=' || L_CUST_ID_TYPE);
  
    L_CUST_ID_NO := L_UNIQUE_ID_VALUE;
  
    DBG('L_CUST_ID_NO=' || L_CUST_ID_NO);
  
    L_CUST_ID_EXPIRY_DATE := TO_CHAR(L_UNIQUE_ID_EXP_DT, 'YYYYMMDD');
  
    DBG('L_CUST_ID_EXPIRY_DATE=' || L_CUST_ID_EXPIRY_DATE);
    
    DBG('L_AGENT_CUST_ID='||L_AGENT_CUST_ID);
  
    L_BEN_FIRST_NAME_RIAA := P_BEN_FIRST_NAME_RIAA;
  
    DBG('L_BEN_FIRST_NAME_RIAA=' || L_BEN_FIRST_NAME_RIAA);
  
    L_BEN_LAST_NAME_RIAA := P_BEN_LAST_NAME_RIAA;
  
    DBG('L_BEN_LAST_NAME_RIAA=' || L_BEN_LAST_NAME_RIAA);
  
    L_BEN_CITY_RIAA := P_BEN_CITY_RIAA;
  
    DBG('L_BEN_CITY_RIAA=' || L_BEN_CITY_RIAA);
  
    L_BEN_STATE_RIAA := P_BEN_STATE_RIAA;
  
    DBG('L_BEN_STATE_RIAA=' || L_BEN_STATE_RIAA);
  
    L_BANK_ID_RIAA := P_BANK_ID_RIAA;
  
    DBG('L_BANK_ID_RIAA=' || L_BANK_ID_RIAA);
  
    L_BEN_ACCOUNT_NO_RIAA := P_BEN_ACCOUNT_NO_RIAA;
  
    DBG('L_BEN_ACCOUNT_NO_RIAA=' || L_BEN_ACCOUNT_NO_RIAA);
    
    L_BANK_ROUTING_CODE_RIAA := P_BANK_ROUTING_CODE_RIAA;
  
    DBG('L_BANK_ROUTING_CODE_RIAA=' || L_BANK_ROUTING_CODE_RIAA);
  
    L_BEN_COUNTRY_RIAA := P_BEN_COUNTRY_RIAA;--L_BANK_ACC_COUNTRY := P_BEN_COUNTRY; --pls check
  
    DBG('L_BEN_COUNTRY_RIAA=' || L_BEN_COUNTRY_RIAA);
  
    L_BANK_ACCOUNT_TYPE_RIAA := P_BANK_ACCOUNT_TYPE_RIAA; --pls check
  
    DBG('L_BANK_ACCOUNT_TYPE_RIAA=' || L_BANK_ACCOUNT_TYPE_RIAA);
    
    L_PURPOSE_OF_TRF_RIAA := P_PURPOSE_OF_TRF_RIAA;
    
    DBG('L_PURPOSE_OF_TRF_RIAA=' || L_PURPOSE_OF_TRF_RIAA);
    
    L_BEN_ID_TYPE_RIAA := P_BEN_ID_TYPE_RIAA;
    
    DBG('L_BEN_ID_TYPE_RIAA=' || L_BEN_ID_TYPE_RIAA);
    
    L_BEN_ID_NO_RIAA := P_BEN_ID_NO_RIAA;
    
    DBG('L_BEN_ID_NO_RIAA=' || L_BEN_ID_NO_RIAA);
    
    L_BIC_SWIFT_RIAA := P_BIC_SWIFT_RIAA;
    
    DBG('L_BIC_SWIFT_RIAA=' || L_BIC_SWIFT_RIAA);
    
    L_BEN_PHONE_RIAA := P_BEN_PHONE_RIAA;
    
    DBG('L_BEN_PHONE_RIAA=' || L_BEN_PHONE_RIAA);
    
    L_VALUE_TYPE_RIAA := P_VALUE_TYPE_RIAA;
    
    DBG('L_VALUE_TYPE_RIAA=' || L_VALUE_TYPE_RIAA);
    
    L_BEN_ADDRESS_RIAA := P_BEN_ADDRESS_RIAA;
    
    DBG('L_BEN_ADDRESS_RIAA=' || L_BEN_ADDRESS_RIAA);
    
    L_CUST_BEN_RELATIONSHIP_RIAA := P_CUST_BEN_RELATIONSHIP_RIAA;
    
    DBG('L_CUST_BEN_RELATIONSHIP_RIAA=' || L_CUST_BEN_RELATIONSHIP_RIAA);
    
    L_UNITARY_BANK_ACC_NO_RIAA := P_UNITARY_BANK_ACC_NO_RIAA;
    
    DBG('L_UNITARY_BANK_ACC_NO_RIAA=' || L_UNITARY_BANK_ACC_NO_RIAA);
    
    L_BEN_CELL_NO_RIAA := P_BEN_CELL_NO_RIAA;
    
    DBG('L_BEN_CELL_NO_RIAA=' || L_BEN_CELL_NO_RIAA);
    
    L_CUST_ID_ISSUED_BY_COUNTRY := L_NATIONALITY;
    
    DBG('L_CUST_ID_ISSUED_BY_COUNTRY=' || L_CUST_ID_ISSUED_BY_COUNTRY);
    
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_UNIQUE_NO_RIAA',
                               L_TXN_UNIQUE_NO_RIAA);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_COUNTRY_TO',
                               L_COUNTRY_TO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_CCY',
                               L_PAYMENT_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAYMENT_AMOUNT',
                               L_PAYMENT_AMOUNT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_FIRST_NAME',
                               L_CUST_FIRST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_LAST_NAME',
                               L_CUST_LAST_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ADDRESS',
                               L_CUST_ADDRESS);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CUST_CITY', L_CUST_CITY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CUST_DOB', L_CUST_DOB);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_OCCUPATION',
                               L_CUST_OCCUPATION);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_TYPE',
                               L_CUST_ID_TYPE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_NO',
                               L_CUST_ID_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_EXPIRY_DATE',
                               L_CUST_ID_EXPIRY_DATE);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_AGENT_CUST_ID',
                               L_AGENT_CUST_ID);
                               
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_FIRST_NAME_RIAA',
                               L_BEN_FIRST_NAME_RIAA);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_LAST_NAME_RIAA',
                               L_BEN_LAST_NAME_RIAA);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_CITY_RIAA',
                               L_BEN_CITY_RIAA);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_STATE_RIAA',
                               L_BEN_STATE_RIAA);                           
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BANK_ID_RIAA',
                               L_BANK_ID_RIAA);    
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ACCOUNT_NO_RIAA',
                               L_BEN_ACCOUNT_NO_RIAA);                            
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BANK_ROUTING_CODE_RIAA',
                               L_BANK_ROUTING_CODE_RIAA); 
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_COUNTRY_RIAA',
                               L_BEN_COUNTRY_RIAA);                            
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BANK_ACCOUNT_TYPE_RIAA',
                               L_BANK_ACCOUNT_TYPE_RIAA); 
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PURPOSE_OF_TRF_RIAA',
                               L_PURPOSE_OF_TRF_RIAA);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_TYPE_RIAA',
                               L_BEN_ID_TYPE_RIAA);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ID_NO_RIAA',
                               L_BEN_ID_NO_RIAA);
     
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BIC_SWIFT_RIAA',
                               L_BIC_SWIFT_RIAA);   
                               
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_PHONE_RIAA',
                               L_BEN_PHONE_RIAA);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_VALUE_TYPE_RIAA',
                               L_VALUE_TYPE_RIAA);                           
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ADDRESS_RIAA',
                               L_BEN_ADDRESS_RIAA);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_BEN_RELATIONSHIP_RIAA',
                               L_CUST_BEN_RELATIONSHIP_RIAA);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_UNITARY_BANK_ACC_NO_RIAA',
                               L_UNITARY_BANK_ACC_NO_RIAA);
    
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_CELL_NO_RIAA',
                               L_BEN_CELL_NO_RIAA);
                               
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CUST_ID_ISSUED_BY_COUNTRY',
                               L_CUST_ID_ISSUED_BY_COUNTRY);
                               
                                                          
                                                                                                                                                                                                                                                                                                                                                               
    DBG('BEFORE REPLACEMENT OF RIA PAYMENT CONFIRMATION JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_RIA_PAYMENT_DIG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_RIA_PAYMENT_DIG');
      DBG('ERROR CODE IN FN_GET_FMT_RIA_PAYMENT_DIG=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_RIA_PAYMENT_DIG=' || SQLERRM);
    
  END FN_GET_FMT_RIA_PAYMENT_DIG;

  PROCEDURE PR_INSERT_RIA_WS_LOG(P_SEQ_NO      IN VARCHAR2,
                                 P_XREF        IN VARCHAR2,
                                 P_INVOKE_DATE IN VARCHAR2,
                                 P_REQ_TYPE    IN VARCHAR2,
                                 P_REQ_MSG     IN VARCHAR2,
                                 P_ADDL_INFO   IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    DBG('START OF PR_INSERT_RIA_WS_LOG');
  
    INSERT INTO IFTB_RIA_WS_OUT_LOG
      (SEQ_NO, TRN_REF_NO, INVOKE_DATE, REQ_TYPE, REQ_MSG, ADDL_INFO)
    VALUES
      (P_SEQ_NO, P_XREF, P_INVOKE_DATE, P_REQ_TYPE, P_REQ_MSG, P_ADDL_INFO);
  
    COMMIT;
  
    DBG('END OF PR_INSERT_RIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_RIA_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_RIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_RIA_WS_LOG=' || SQLERRM);
    
  END PR_INSERT_RIA_WS_LOG;

  PROCEDURE PR_UPDATE_RIA_WS_LOG(P_XREF          IN IFTB_RIA_MASTER.TRN_REF_NO%TYPE,
                                 P_SEQ_NO        IN VARCHAR2,
                                 P_TXN_UNIQUE_NO IN IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE,
                                 P_STATUS        IN CHAR,
                                 P_RES_MSG       IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_RIA_WS_LOG');
  
    UPDATE IFTB_RIA_WS_OUT_LOG
       SET TXN_UNIQUE_NO = P_TXN_UNIQUE_NO,
           
           RES_MSG = P_RES_MSG,
           STATUS  = P_STATUS
     WHERE TRN_REF_NO = P_XREF
       AND SEQ_NO = P_SEQ_NO;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_RIA_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_RIA_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_RIA_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_RIA_WS_LOG=' || SQLERRM);
  END PR_UPDATE_RIA_WS_LOG;

  FUNCTION FN_RIA_WS_CALL(p_RIA_call in varchar2,
                          p_out_msg  VARCHAR2,
                          p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
  
  BEGIN
    dbg('START OF FN_RIA_WS_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
  
    IF p_RIA_call = 'I' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_RIA_OUT_ENQ_URL');
    
    ELSIF p_RIA_call = 'C' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_RIA_PAYCONFIRM_OUT_URL');
    
    END IF;
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
  
    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_RIA_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_RIA_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
                        
    utl_http.set_header(l_http_request, 'content-type', 'application/json;charset=UTF-8');
    
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
  
    UTL_HTTP.set_header(l_http_request, 'USER-REQUEST-ID', global.user_id);
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    utl_http.set_transfer_timeout(300);
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    DBG('l_resp_num=' || l_resp_num);
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    --dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_RIA_WS_CALL;

  FUNCTION fn_msg_upload(p_ifdriaft   IN OUT IFPKS_IFDRIAFT_MAIN.Ty_ifdriaft,
                         P_REQ_TYPE   IN VARCHAR2,
                         P_REQ_MSG    IN OUT CLOB,
                         P_ADDL_INFO  IN VARCHAR2,
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_TXN_UNIQUE_NO VARCHAR2(105);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
    TYPE TYPE_RIA_ENQ_FLDS IS TABLE OF VARCHAR2(105);
    L_RIA_ENQ_FLDS  TYPE_RIA_ENQ_FLDS;
    L_RIA_ENQ_FLDS1 TYPE_RIA_ENQ_FLDS;
    K               NUMBER := 0;
  
    l_transactionUniqueNo IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE;
  
    L_RIA_REFERENCE_NO IFTB_RIA_MASTER.RIA_REFERENCE_NO%TYPE;
    L_ORDER_NO         IFTB_RIA_MASTER.ORDER_NO%TYPE;
    L_RIA_ORDER_NO     IFTB_RIA_MASTER.RIA_ORDER_NO%TYPE;
    L_RIA_PIN          IFTB_RIA_MASTER.RIA_PIN%TYPE;
    
    L_RIA_EXCHANGE_RATE   IFTB_RIA_MASTER.RIA_EXCHANGE_RATE%TYPE;
    L_RIA_RECEIVING_AMT IFTB_RIA_MASTER.RIA_RECEIVING_AMT%TYPE;
  
  BEGIN
  
    dbg('Inside fn_msg_upload');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
  
    --Log Webservice Call
    PR_INSERT_RIA_WS_LOG(L_GEN_SEQ_NO,
                         p_ifdriaft.v_iftb_ria_master.trn_ref_no,
                         fn_sysdate,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);
  
    IF NOT FN_RIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE <> '000' THEN
    
      p_err_code := 'IF-RIA-000';
      
      p_err_params := L_STATUS_MSG;
    
      --OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');
    
      RETURN FALSE;
    
    END IF;
  
    --Handle All Error Codes ad return false
  
    IF P_REQ_TYPE = 'I' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
        
      --insert into 
      PR_INSERT_XML_DATA_DTLS(P_IFDRIAFT.v_iftb_ria_master.TRN_REF_NO,
                                  P_DOCUMENT_XML);
      
        l_transactionUniqueNo := P_DOCUMENT_XML.EXTRACT('/root/data/transactionUniqueNo/text()')
                                 
                                 .GETSTRINGVAL;
      
        DBG('l_transactionUniqueNo =' || l_transactionUniqueNo);
      
        P_IFDRIAFT.v_iftb_ria_master.TXN_UNIQUE_NO := l_transactionUniqueNo;
      
        --RIA Fee
        IF INSTR(L_RESP_IN_XML, '<customerCharge>') > 0 THEN
        
          L_RIA_DYNAMIC_FEE := TO_NUMBER(P_DOCUMENT_XML.EXTRACT('/root/data/customerCharge/text()')
                                         
                                         .GETSTRINGVAL);
        
          DBG('L_RIA_DYNAMIC_FEE=' || L_RIA_DYNAMIC_FEE);
        
        END IF;
        
        L_RIA_EXCHANGE_RATE := P_DOCUMENT_XML.EXTRACT('/root/data/rate/text()')
                     
                     .GETSTRINGVAL;
      
        DBG('L_RIA_EXCHANGE_RATE =' || L_RIA_EXCHANGE_RATE);
      
        P_IFDRIAFT.v_iftb_ria_master.RIA_EXCHANGE_RATE := L_RIA_EXCHANGE_RATE;
      
        DBG('P_IFDRIAFT.v_iftb_ria_master.RIA_EXCHANGE_RATE=' ||
            P_IFDRIAFT.v_iftb_ria_master.RIA_EXCHANGE_RATE);
         
        L_RIA_RECEIVING_AMT := P_DOCUMENT_XML.EXTRACT('/root/data/foreignAmount/text()')
                     
                     .GETSTRINGVAL;
      
        DBG('L_RIA_RECEIVING_AMT =' || L_RIA_RECEIVING_AMT);
      
        P_IFDRIAFT.v_iftb_ria_master.RIA_RECEIVING_AMT := L_RIA_RECEIVING_AMT;
      
        DBG('P_IFDRIAFT.v_iftb_ria_master.RIA_RECEIVING_AMT=' ||
            P_IFDRIAFT.v_iftb_ria_master.RIA_RECEIVING_AMT);   
      
        --Get Required Fields
        WITH t(xml) AS
         (SELECT xmltype(L_RESP_IN_XML) FROM DUAL)
        SELECT x.*
          BULK COLLECT
          INTO L_RIA_ENQ_FLDS
          FROM t,
               xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                      "nq1"),
                        '/root/data/requiredField' passing t.xml columns
                        FieldName varchar2(50) path 'FieldName') x;
      
        --skip those values
        -- L_RIA_ENQ_FLDS1 := TYPE_RIA_ENQ_FLDS();
        --K               := 0;
      
        DBG('L_RIA_ENQ_FLDS.COUNT=' || L_RIA_ENQ_FLDS.COUNT);
      
        /*FOR G IN 1..L_RIA_ENQ_FLDS.COUNT LOOP
        
        IF L_RIA_ENQ_FLDS(G) NOT IN ('BeneCity', 'BeneState') THEN
          L_RIA_ENQ_FLDS1(K) := L_RIA_ENQ_FLDS(G);
          L_RIA_ENQ_FLDS1.EXTEND();
          --K := K + 1;
        END IF;  
        
        END LOOP;*/
      
        --Parse Required Fields
        K := 1;
        BEGIN
          FOR G IN 1 .. L_RIA_ENQ_FLDS.COUNT LOOP
          
            DBG('L_RIA_ENQ_FLDS(G)=' || L_RIA_ENQ_FLDS(G));
          
            --IF L_RIA_ENQ_FLDS(G) IN ('BeneCity', 'BeneState') THEN
            --    L_RIA_ENQ_FLDS.DELETE(G, G);
            -- END IF;
          
            IF L_RIA_ENQ_FLDS(G) IN
               ('BeneCity', 'BeneState', 'BankAccountNo', 'BankAccountType'--, 'BankRoutingCode'
               ) THEN
              NULL;
              continue;
            ELSE
            
              p_ifdriaft.v_iftb_ria_addl_fields(K).TRN_REF_NO := P_IFDRIAFT.v_iftb_ria_master.TRN_REF_NO;
              p_ifdriaft.v_iftb_ria_addl_fields(K).TXN_UNIQUE_NO := P_IFDRIAFT.v_iftb_ria_master.TXN_UNIQUE_NO;
            
              p_ifdriaft.v_iftb_ria_addl_fields(K).FIELD_NAME := L_RIA_ENQ_FLDS(G);
              K := K + 1;
            
            END IF;
          
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;
      
        --populate dynamic field values starts
        DBG('ABOUT TO POPULATE DYNAMIC FIELD VALUES');
        DBG('COUNT OF DYNAMIC FIELD VALUES=' || L_RIA_ENQ_FLDS.COUNT);
        BEGIN
          FOR G IN p_ifdriaft.v_iftb_ria_addl_fields.first .. p_ifdriaft.v_iftb_ria_addl_fields.LAST
          --1 .. L_RIA_ENQ_FLDS.COUNT
           LOOP
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME IN
                ('BeneCity', 'BeneState', 'BankAccountNo', 'BankAccountType'
                )
            
             THEN
            
              CONTINUE;
            
            END IF;
          
            DBG('G VALUE=' || G);
            DBG('p_ifdriaft.v_iftb_ria_addl_fields(G)
               .FIELD_NAME='||p_ifdriaft.v_iftb_ria_addl_fields(G)
               .FIELD_NAME);
          
          --Transfer Reason changes Starts
          IF p_ifdriaft.v_iftb_ria_addl_fields(G)
               .FIELD_NAME = 'TransferReason' THEN
               
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE :=  p_ifdriaft.v_iftb_ria_master.purpose_of_transfer;
               
          END IF;
          --Transfer Reason Changes Ends
            
              IF p_ifdriaft.v_iftb_ria_addl_fields(G)
               .FIELD_NAME = 'CustAddress' THEN
                BEGIN
                
                  SELECT substr(A.ADDRESS_LINE1 || ',' || A.ADDRESS_LINE2 || ',' ||
                         A.ADDRESS_LINE3 || ',' || A.ADDRESS_LINE4,1,50)
                    INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                    FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
                   WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                     AND A.customer_no in
                         (select cust_no
                            from sttm_cust_account
                           where cust_ac_no =
                                 p_ifdriaft.v_iftb_ria_master.dr_acc_no
                             AND RECORD_STAT = 'O'
                             AND AUTH_STAT = 'A');
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('FAILED WHILE FETCHING CUST ADDRESS');
                    DBG('ERROR CODE=' || SQLCODE);
                    DBG('ERROR MESSAGE=' || SQLERRM);
                END;
                
              
              END IF;
            
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustOccupation' THEN
            
              SELECT B.OCCUPATION
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUSTOMER_CUSTOM B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.customer_no in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A') AND A.CUSTOMER_NO = B.CUSTOMER_NO;
            
            IF p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE IS NULL THEN
            
            dbg('Occupation should not be null for Individual customers');
      
        p_err_code := 'ST-PRIN-017';
      
        pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
      
        RETURN FALSE;  
            
            END IF;
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustZipCode' THEN
            
              SELECT A.PINCODE
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A
               WHERE A.customer_no in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            IF p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE IS NULL THEN
            
            dbg('PIN Code Should Not Be Null for Individual Customer');
      
        p_err_code := 'IF-RIA-014';
      
        pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
      
        RETURN FALSE;  
            
            END IF;
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustCityOfBirth' THEN
            
              SELECT A.ADDRESS_LINE2
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A
               WHERE A.customer_no in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustCountryOfBirth' THEN
            
              SELECT B.BIRTH_COUNTRY
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.customer_no in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A') AND A.CUSTOMER_NO = B.CUSTOMER_NO;
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_NAME = 'CustState' THEN
            
              SELECT A.ADDRESS_LINE1
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.customer_no in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A')
                         AND A.CUSTOMER_NO = B.CUSTOMER_NO;
            
            END IF;
          
          END LOOP;
        END;
      
        /*BEGIN
          FOR G IN 1 .. L_RIA_ENQ_FLDS.COUNT LOOP
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustFirstName' THEN
            
              SELECT B.FIRST_NAME
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.customer_no in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustLastName' THEN
            
              SELECT B.LAST_NAME
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustMiddleName' THEN
            
              SELECT B.MIDDLE_NAME
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustMiddleName' THEN
            
              SELECT B.MIDDLE_NAME
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_NAME = 'CustCity' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'PHNOM PENH';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_NAME = 'CustState' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustZipCode' THEN
            
              SELECT B.P_PINCODE
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustCountry' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustPhoneNo' THEN
            
              SELECT B.MOBILE_NUMBER
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustCellNo' THEN
            
              SELECT B.MOBILE_NUMBER
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustID1Type' THEN
            
              SELECT A.UNIQUE_ID_NAME
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUSTOMER_CUSTOM B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_NAME = 'CustID1No' THEN
            
              SELECT A.UNIQUE_ID_VALUE
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUSTOMER_CUSTOM B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustID1IssuedBy' THEN
            
              SELECT B.UNIQUE_ID_ISS_AUTH
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUSTOMER_CUSTOM B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustID1IssuedByState' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustID1IssuedByCountry' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustID1IssuedDate' THEN
            
              SELECT B.UNIQUE_ID_ISS_DT
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUSTOMER_CUSTOM B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustID1ExpDate' THEN
            
              SELECT B.UNIQUE_ID_EXP_DT
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUSTOMER_CUSTOM B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_NAME = 'CustTaxID' THEN
            
              SELECT A.TAXID_NO
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_CORPORATE B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustTaxCountry' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustCountryOfBirth' THEN
            
              SELECT B.BIRTH_COUNTRY
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustCountryofResidence' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustNationality' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustDateBirth' THEN
            
              SELECT B.DATE_OF_BIRTH
                INTO p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE
                FROM STTM_CUSTOMER A, STTM_CUST_PERSONAL B
               WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                 AND A.CUSTOMER_NO in
                     (select cust_no
                        from sttm_cust_account
                       where cust_ac_no =
                             p_ifdriaft.v_iftb_ria_master.dr_acc_no
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A');
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustOccupationID' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustOccupation' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustBusinessSectorID' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustSourceFundsID' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustSourceFunds' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustPaymentMethodID' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustPaymentMethod' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustBeneRelationshipID' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustBeneRelationship' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustEmployerName' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustIncomeAmount' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustIncomeCurrency' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustIncomeFrequency' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustIncomePaymentMethod' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustStateOfBirth' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          
            IF p_ifdriaft.v_iftb_ria_addl_fields(G)
             .FIELD_NAME = 'CustCityOfBirth' THEN
            
              p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE := 'CAMBODIA';
            
            END IF;
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;*/
        --populate dynamic field values ends
      
        PR_UPDATE_RIA_WS_LOG(p_ifdriaft.v_iftb_ria_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'S',
                             L_IN_RESP);
      
      ELSE
      
        PR_UPDATE_RIA_WS_LOG(p_ifdriaft.v_iftb_ria_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             l_transactionUniqueNo,
                             'F',
                             L_IN_RESP);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    IF P_REQ_TYPE = 'C' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'Confirmed Payment' THEN
      
        P_IFDRIAFT.v_iftb_ria_master.RIA_PAY_STATUS := L_STATUS_MSG;
      
        L_RIA_REFERENCE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/ReferenceNumber/text()')
                              
                              .GETSTRINGVAL;
      
        DBG('L_RIA_REFERENCE_NO =' || L_RIA_REFERENCE_NO);
      
        P_IFDRIAFT.v_iftb_ria_master.RIA_REFERENCE_NO := L_RIA_REFERENCE_NO;
      
        L_ORDER_NO := P_DOCUMENT_XML.EXTRACT('/root/data/OrderNo/text()')
                      
                      .GETSTRINGVAL;
      
        DBG('L_ORDER_NO =' || L_ORDER_NO);
      
        P_IFDRIAFT.v_iftb_ria_master.ORDER_NO := L_ORDER_NO;
      
        L_RIA_ORDER_NO := P_DOCUMENT_XML.EXTRACT('/root/data/RiaOrderNo/text()')
                          
                          .GETSTRINGVAL;
      
        DBG('L_RIA_ORDER_NO =' || L_RIA_ORDER_NO);
      
        P_IFDRIAFT.v_iftb_ria_master.RIA_ORDER_NO := L_RIA_ORDER_NO;
      
        L_RIA_PIN := P_DOCUMENT_XML.EXTRACT('/root/data/PIN/text()')
                     
                     .GETSTRINGVAL;
      
        DBG('L_RIA_PIN =' || L_RIA_PIN);
      
        P_IFDRIAFT.v_iftb_ria_master.RIA_PIN := L_RIA_PIN;
      
        DBG('P_IFDRIAFT.v_iftb_ria_master.RIA_PIN=' ||
            P_IFDRIAFT.v_iftb_ria_master.RIA_PIN);
      
      
      
            
            
        /*--Get Required Fields
        WITH t(xml) AS
         (SELECT xmltype(L_RESP_IN_XML) FROM DUAL)
        SELECT x.*
          BULK COLLECT
          INTO L_RIA_ENQ_FLDS
          FROM t,
               xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                      "nq1"),
                        '/root/data/requiredField' passing t.xml columns
                        FieldName varchar2(50) path 'FieldName') x;
        
        --Parse Required Fields
        BEGIN
          FOR G IN 1 .. L_RIA_ENQ_FLDS.COUNT LOOP
          
            p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_NAME := L_RIA_ENQ_FLDS(G);
          
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;*/
      
        PR_UPDATE_RIA_WS_LOG(p_ifdriaft.v_iftb_ria_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'S',
                             L_IN_RESP);
      
        RETURN TRUE;
      
      ELSE
      
        PR_UPDATE_RIA_WS_LOG(p_ifdriaft.v_iftb_ria_master.trn_ref_no,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'F',
                             L_IN_RESP);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION fn_msg_upload_dig(P_TRN_REF_NO IN OUT VARCHAR2,
                             P_REQ_TYPE   IN VARCHAR2,
                             P_REQ_MSG    IN OUT CLOB,
                             P_ADDL_INFO  IN VARCHAR2,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2,
                             P_RIA_PIN    OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_TXN_UNIQUE_NO VARCHAR2(105);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
    TYPE TYPE_RIA_ENQ_FLDS IS VARRAY(5) OF VARCHAR2(105);
    L_RIA_ENQ_FLDS TYPE_RIA_ENQ_FLDS;
  
    l_transactionUniqueNo IFTB_RIA_MASTER.TXN_UNIQUE_NO%TYPE;
  
    L_RIA_REFERENCE_NO IFTB_RIA_MASTER.RIA_REFERENCE_NO%TYPE;
    L_ORDER_NO         IFTB_RIA_MASTER.ORDER_NO%TYPE;
    L_RIA_ORDER_NO     IFTB_RIA_MASTER.RIA_ORDER_NO%TYPE;
    L_RIA_PIN          IFTB_RIA_MASTER.RIA_PIN%TYPE;
  
  BEGIN
    --return true; --only for testing
    dbg('Inside fn_msg_upload_dig');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
  
    --Log Webservice Call
    PR_INSERT_RIA_WS_LOG(L_GEN_SEQ_NO,
                         P_TRN_REF_NO,
                         fn_sysdate,
                         P_REQ_TYPE,
                         P_REQ_MSG,
                         P_ADDL_INFO);
  
    IF NOT FN_RIA_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE <> '000' THEN
    
      p_err_code := 'IF-RIA-000';
      
      p_err_params := L_STATUS_MSG;
    
      --OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');
      
      --Pr_Log_Error('IFDRIAFT', 'FLEXCUBE', p_err_code, L_STATUS_MSG);
    
      RETURN FALSE;
    
    END IF;
  
    --Handle All Error Codes ad return false
  
    IF P_REQ_TYPE = 'C' THEN
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'Confirmed Payment' THEN
      
        L_RIA_REFERENCE_NO := P_DOCUMENT_XML.EXTRACT('/root/data/ReferenceNumber/text()')
                              
                              .GETSTRINGVAL;
      
        DBG('L_RIA_REFERENCE_NO =' || L_RIA_REFERENCE_NO);
      
        L_ORDER_NO := P_DOCUMENT_XML.EXTRACT('/root/data/OrderNo/text()')
                      
                      .GETSTRINGVAL;
      
        DBG('L_ORDER_NO =' || L_ORDER_NO);
      
        L_RIA_ORDER_NO := P_DOCUMENT_XML.EXTRACT('/root/data/RiaOrderNo/text()')
                          
                          .GETSTRINGVAL;
      
        DBG('L_RIA_ORDER_NO =' || L_RIA_ORDER_NO);
      
        L_RIA_PIN := P_DOCUMENT_XML.EXTRACT('/root/data/PIN/text()')
                     
                     .GETSTRINGVAL;
      
        DBG('L_RIA_PIN =' || L_RIA_PIN);
      
        P_RIA_PIN := L_RIA_PIN;
      
        PR_UPDATE_RIA_WS_LOG(P_TRN_REF_NO,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'S',
                             L_IN_RESP);
      
        RETURN TRUE;
      
      ELSE
      
        PR_UPDATE_RIA_WS_LOG(P_TRN_REF_NO,
                             L_GEN_SEQ_NO,
                             NULL, --L_ENQUIRY_ID,
                             'F',
                             L_IN_RESP);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    dbg('Successfully processed fn_msg_upload_dig');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload_dig' ||
          SQLERRM);
      RETURN FALSE;
  END fn_msg_upload_dig;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdriaft         IN OUT ifpks_ifdriaft_Main.ty_ifdriaft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdriaft_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION fn_enrich_product(p_ifdriaft   IN OUT IFPKS_IFDRIAFT_MAIN.Ty_ifdriaft,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no  VARCHAR2(16);
    l_trn_ref_no iftb_rft_master.trn_ref_no%TYPE;
    l_prod       cstm_product%ROWTYPE;
    l_rate       NUMBER;
    l_charge_amt NUMBER := 0;
    l_rate_flag  NUMBER;
  
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_arc_maint    iftm_arc_maint%ROWTYPE;
  
  BEGIN
  
    IF p_ifdriaft.v_iftb_ria_master.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(GLOBAL.current_branch,
                                         'RIAO',
                                         global.application_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdriaft.v_iftb_ria_master.trn_ref_no := l_trn_ref_no;
      
      END IF;
    END IF;
  
    -- charge pickup
    SELECT x.* INTO l_prod FROM cstm_product x WHERE product_code = 'RIAO';
  
    dbg('p_ifdriaft.v_iftb_ria_master.dr_acc_no=' ||
        p_ifdriaft.v_iftb_ria_master.dr_acc_no);
  
    SELECT cust_no, ccy
      INTO l_rel_customer, l_ac_ccy
      FROM sttm_cust_account
     WHERE cust_ac_no = p_ifdriaft.v_iftb_ria_master.dr_acc_no;
  
    dbg('l_ac_ccy=' || l_ac_ccy);
  
    dbg('got l_rel_customer' || l_rel_customer);
  
    IF NOT cspkss_arc.fn_charge_pickup(GLOBAL.current_branch,
                                       'RIAO',
                                       'P',
                                       'RIAO',
                                       p_ifdriaft.v_iftb_ria_master.txn_ccy,
                                       l_rel_customer,
                                       p_ifdriaft.v_iftb_ria_master.txn_ccy,
                                       p_ifdriaft.v_iftb_ria_master.cr_amount,
                                       l_prod.rate_type_preferred,
                                       l_prod.rate_code_preferred,
                                       NULL,
                                       l_rel_customer,
                                       l_ib_flag,
                                       l_arc_maint,
                                       p_err_code,
                                       p_err_params,
                                       p_ifdriaft.v_iftb_ria_master.dr_acc_no,
                                       GLOBAL.current_branch) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;
  
    l_arc_maint.cod_chg_amt := L_RIA_DYNAMIC_FEE;
  
    DBG('l_arc_maint.cod_chg_amt =' || l_arc_maint.cod_chg_amt);
  
    --charge1 starts
    IF l_arc_maint.cod_chg_amt IS NOT NULL THEN
    
      DBG('Populating Charge 1');
    
      p_ifdriaft.v_iftb_ria_out_charge(1).trn_ref_no := p_ifdriaft.v_iftb_ria_master.trn_ref_no;
      p_ifdriaft.v_iftb_ria_out_charge(1).chg_srno := 1;
      p_ifdriaft.v_iftb_ria_out_charge(1).chg1_desc := l_arc_maint.cod_chg_desc;
      p_ifdriaft.v_iftb_ria_out_charge(1).chg1_waiver := 'N';
      p_ifdriaft.v_iftb_ria_out_charge(1).chg1_amt := case
                                                       l_arc_maint.cod_chg_track_prf
                                                        when 'W' then
                                                         0
                                                        else
                                                         l_arc_maint.cod_chg_amt
                                                      end; --waive charges fix
    
      p_ifdriaft.v_iftb_ria_out_charge(1).chg1_ccy := l_arc_maint.cod_chg_ccy;
    
      DBG('p_ifdriaft.v_iftb_ria_out_charge(1).trn_ref_no=' || p_ifdriaft.v_iftb_ria_out_charge(1)
          .trn_ref_no);
      DBG('p_ifdriaft.v_iftb_ria_out_charge(1).chg_srno=' || p_ifdriaft.v_iftb_ria_out_charge(1)
          .chg_srno);
      DBG('p_ifdriaft.v_iftb_ria_out_charge(1).chg1_desc=' || p_ifdriaft.v_iftb_ria_out_charge(1)
          .chg1_desc);
      DBG('p_ifdriaft.v_iftb_ria_out_charge(1).chg1_waiver=' || p_ifdriaft.v_iftb_ria_out_charge(1)
          .chg1_waiver);
      DBG('p_ifdriaft.v_iftb_ria_out_charge(1).chg1_amt=' || p_ifdriaft.v_iftb_ria_out_charge(1)
          .chg1_amt);
      DBG('p_ifdriaft.v_iftb_ria_out_charge(1).chg1_ccy=' || p_ifdriaft.v_iftb_ria_out_charge(1)
          .chg1_ccy);
    
      DBG('p_ifdriaft.v_iftb_ria_out_charge.count=' ||
          p_ifdriaft.v_iftb_ria_out_charge.count);
    
      DBG('global.lcy=' || global.lcy);
      DBG('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);
    
      -- Converting charge into local ccy for display in charge tab
      IF l_arc_maint.cod_chg_ccy <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.current_branch,
                                      l_arc_maint.cod_chg_ccy,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      p_ifdriaft.v_iftb_ria_out_charge(1)
                                      .chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdriaft.v_iftb_ria_out_charge(1).lcy_chg1 := l_charge_amt;
        p_ifdriaft.v_iftb_ria_out_charge(1).xrate := l_rate;
      ELSE
        p_ifdriaft.v_iftb_ria_out_charge(1).lcy_chg1 := p_ifdriaft.v_iftb_ria_out_charge(1)
                                                        .chg1_amt; --l_arc_maint.cod_chg_amt, --waive charges fix
        p_ifdriaft.v_iftb_ria_out_charge(1).xrate := 1;
      END IF;
      dbg('Amount 1 in Local ccy->' || p_ifdriaft.v_iftb_ria_out_charge(1)
          .lcy_chg1);
    
      -- Converting charge into txn ccy
    
      dbg('p_ifdriaft.v_iftb_ria_master.txn_ccy=' ||
          p_ifdriaft.v_iftb_ria_master.txn_ccy);
    
      /*IF l_arc_maint.cod_chg_ccy <> p_ifdriaft.v_iftb_ria_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.current_branch,
                                      l_arc_maint.cod_chg_ccy,
                                      p_ifdriaft.v_iftb_ria_master.txn_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                      p_ifdriaft.v_iftb_ria_out_charge(1)
                                      .chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdriaft.v_iftb_ria_out_charge(1).chg1_in_txn := l_charge_amt;
        p_ifdriaft.v_iftb_ria_out_charge(1).txn_xrate := l_rate;
        dbg(' * Amount 1 in TXN ccy->' || p_ifdriaft.v_iftb_ria_out_charge(1)
            .chg1_in_txn);
      ELSE
        p_ifdriaft.v_iftb_ria_out_charge(1).chg1_in_txn := p_ifdriaft.v_iftb_ria_out_charge(1)
                                                           .chg1_amt; --l_arc_maint.cod_chg_amt; --waive charges fix
        p_ifdriaft.v_iftb_ria_out_charge(1).txn_xrate := 1;
        dbg('** Amount 1 in TXN ccy->' || p_ifdriaft.v_iftb_ria_out_charge(1)
            .chg1_in_txn);
      END IF;*/
    
      -- Converting charge into acc ccy
      IF l_arc_maint.cod_chg_ccy <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.current_branch,
                                      l_arc_maint.cod_chg_ccy,
                                      l_ac_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                      --p_ifdriaft.v_iftb_ria_out_charge(1).chg1_amt, --l_arc_maint.cod_chg_amt, --waive charges fix
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdriaft.v_iftb_ria_out_charge(1).chg1_in_acc := l_charge_amt;
        p_ifdriaft.v_iftb_ria_out_charge(1).acc_xrate := l_rate;
        dbg('* Amount 1 in acc ccy->' || p_ifdriaft.v_iftb_ria_out_charge(1)
            .chg1_in_acc);
      ELSE
        p_ifdriaft.v_iftb_ria_out_charge(1).chg1_in_acc := p_ifdriaft.v_iftb_ria_out_charge(1)
                                                           .chg1_amt; --l_arc_maint.cod_chg_amt; --waive charges fix
        p_ifdriaft.v_iftb_ria_out_charge(1).acc_xrate := 1;
        dbg('** Amount 1 in acc ccy->' || p_ifdriaft.v_iftb_ria_out_charge(1)
            .chg1_in_acc);
      END IF;
    
      --Assigning Charge
      p_ifdriaft.v_iftb_ria_master.tot_chg_amt := p_ifdriaft.v_iftb_ria_out_charge(1)
                                                  .chg1_in_acc;
      --Assigning Total txn amount
      p_ifdriaft.v_iftb_ria_master.net_txn_amt := nvl(p_ifdriaft.v_iftb_ria_master.tot_chg_amt,
                                                      0) + nvl(p_ifdriaft.v_iftb_ria_master.dr_amount,
                                                               0);
    
    END IF;
    --charge1 ends
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdRIAdr_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
    
  END fn_enrich_product;

  FUNCTION FN_POST_ACC_ENTRY(p_ifdriaft IN OUT IFPKS_IFDRIAFT_MAIN.Ty_ifdriaft)
    RETURN BOOLEAN IS
  
    pkg_detb_rtl_teller_rec detbs_rtl_teller%ROWTYPE;
    L_CUST_AC               STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    l_rate                  NUMBER;
    P_ERR_CODE              VARCHAR2(255);
    P_ERR_PARAMS            VARCHAR2(255);
    L_TILL_CASH_GL          DETMS_TIL_VLT_CCY_PARAMS.CASH_GL%TYPE;
    L_TILL_ID               SMTB_USER_TILLS.TILL_ID%TYPE;
    L_LMTM_TYPE_VALUES      LMTM_TYPE_VALUES%ROWTYPE;
    L_TILL_VLT_IND          FBTB_TILL_MASTER.TIL_VLT_IND%TYPE;
    L_ARC_MAINT             IFTM_ARC_MAINT%ROWTYPE;
  
    l_prod              cstm_product%ROWTYPE;
    l_ib_flag           VARCHAR2(1) DEFAULT 'Y';
    l_txn_amt           iftbs_rft_master.txn_amt%TYPE;
    l_txn_amt1          iftbs_rft_master.txn_amt%TYPE;
    l_rate              NUMBER;
    l_rate_code         cstm_product.rate_code_preferred%Type;
    l_rate_code1        cstm_product.rate_code_preferred%Type;
    L_STTM_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
  
  BEGIN
  
    --Enrich once again
    IF NOT fn_enrich_product(p_ifdriaft, p_err_code, p_err_params) THEN
      dbg('Failed in Fn_Enrich_Product');
      RETURN FALSE;
    END IF;
  
    SELECT x.* INTO l_prod FROM cstm_product x WHERE product_code = 'RIAO';
  
    SELECT x.*
      INTO l_cust_ac
      FROM sttm_cust_account x
     WHERE x.cust_ac_no = p_ifdriaft.v_iftb_ria_master.dr_acc_no;
  
    SELECT x.*
      INTO l_cust
      FROM sttm_customer x
     WHERE x.customer_no = l_cust_ac.cust_no;
  
    cspkss_arc.pr_get_arc_row(GLOBAL.current_branch,
                              'RIAO',
                              'P',
                              '*.*', -- trans_type
                              p_ifdriaft.v_iftb_ria_master.txn_ccy,
                              l_ib_flag,
                              l_arc_maint,
                              p_err_code,
                              p_err_params,
                              p_ifdriaft.v_iftb_ria_master.dr_acc_no,
                              GLOBAL.current_branch);
  
    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 1=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);
  
    IF p_err_code IS NOT NULL THEN
      dbg('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
      RETURN FALSE;
    END IF;
  
    IF NOT cspkss_arc.fn_charge_pickup(GLOBAL.current_branch,
                                       l_prod.product_code,
                                       'P',
                                       l_prod.product_code,
                                       p_ifdriaft.v_iftb_ria_master.txn_ccy,
                                       l_cust_ac.cust_no,
                                       p_ifdriaft.v_iftb_ria_master.txn_ccy,
                                       p_ifdriaft.v_iftb_ria_master.cr_amount,
                                       l_prod.rate_type_preferred,
                                       l_prod.rate_code_preferred,
                                       NULL,
                                       l_cust_ac.cust_no,
                                       l_ib_flag,
                                       depks_rtl_teller.pkg_arc_row,
                                       p_err_code,
                                       p_err_params,
                                       p_ifdriaft.v_iftb_ria_master.dr_acc_no,
                                       global.current_branch) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;
  
    DBG('PKG_ARC_ROW.COD_CHG_TYPE2 after charge pickup=' ||
        DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE2);
  
    pkg_detb_rtl_teller_rec.xref := p_ifdriaft.v_iftb_ria_master.trn_ref_no;
  
    pkg_detb_rtl_teller_rec.product_code := 'RIAO';
  
    --Get Arc Maintenance
    SELECT *
      INTO L_ARC_MAINT
      FROM IFTM_ARC_MAINT A
     WHERE A.COD_PROD_ACC_CLS = pkg_detb_rtl_teller_rec.product_code
       AND ROWNUM = 1;
  
    --Get Acc Details
    SELECT x.*
      INTO l_cust_ac
      FROM sttm_cust_account x
     WHERE x.cust_ac_no = p_ifdriaft.v_iftb_ria_master.DR_ACC_NO;
  
    DBG('p_ifdriaft.v_iftb_ria_master.DR_ACC_NO=' ||
        p_ifdriaft.v_iftb_ria_master.DR_ACC_NO);
  
    --GET BEN CUSTOMER DETAILS
    BEGIN
      SELECT X.*
        INTO L_CUST
        FROM STTM_CUSTOMER X
       WHERE X.CUSTOMER_NO = l_cust_ac.cust_no;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN GETTING CUSTOMER DETAILS');
    END;
  
    --pkg_detb_rtl_teller_rec.product_code := 'CCFT';
  
    pkg_detb_rtl_teller_rec.branch_code := GLOBAL.CURRENT_BRANCH;
    pkg_detb_rtl_teller_rec.trn_ref_no  := p_ifdriaft.v_iftb_ria_master.trn_ref_no;
  
    pkg_detb_rtl_teller_rec.txn_acc    := p_ifdriaft.v_iftb_ria_master.CR_ACC_NO;
    pkg_detb_rtl_teller_rec.txn_ccy    := p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY;
    pkg_detb_rtl_teller_rec.txn_branch := '991'; --'001'; --''991'; --GLOBAL.CURRENT_BRANCH; --RIA corporate account
    --pkg_detb_rtl_teller_rec.txn_branch := pkg_detb_rtl_teller_rec.ofs_branch;
  
    pkg_detb_rtl_teller_rec.ofs_acc    := p_ifdriaft.v_iftb_ria_master.DR_ACC_NO;
    pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY;
    pkg_detb_rtl_teller_rec.ofs_amount := p_ifdriaft.v_iftb_ria_master.DR_AMOUNT;
  
    pkg_detb_rtl_teller_rec.ofs_branch := l_cust_ac.Branch_Code; --GLOBAL.current_branch;
  
    pkg_detb_rtl_teller_rec.txn_amount := p_ifdriaft.v_iftb_ria_master.cr_amount; --pls check this
  
    pkg_detb_rtl_teller_rec.txn_trn_code     := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'000'; --transacion code
    pkg_detb_rtl_teller_rec.ofs_trn_code     := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'000'; --transacion code
    pkg_detb_rtl_teller_rec.exch_rate        := p_ifdriaft.v_iftb_ria_master.exch_rate;
    pkg_detb_rtl_teller_rec.trn_dt           := GLOBAL.application_date;
    pkg_detb_rtl_teller_rec.value_dt         := GLOBAL.application_date;
    pkg_detb_rtl_teller_rec.rel_customer     := L_CUST.customer_no;
    pkg_detb_rtl_teller_rec.benef_name       := L_CUST.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := L_CUST.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := L_CUST.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := L_CUST.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := L_CUST.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := GLOBAL.application_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := GLOBAL.USER_ID;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdriaft.v_iftb_ria_master.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdriaft.v_iftb_ria_master.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdriaft.v_iftb_ria_master.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdriaft.v_iftb_ria_master.mod_no;
    pkg_detb_rtl_teller_rec.scode            := 'FLEXCUBE';
    pkg_detb_rtl_teller_rec.dr_acc           := 'OFS';
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;
  
    DBG('p_ifdriaft.v_iftb_ria_out_charge.count=' ||
        p_ifdriaft.v_iftb_ria_out_charge.count);
  
    -- 1
    FOR k IN 1 .. p_ifdriaft.v_iftb_ria_out_charge.count LOOP
      IF k = 1 THEN
        dbg('CHG AMT' || p_ifdriaft.v_iftb_ria_out_charge(k).chg1_amt);
        pkg_detb_rtl_teller_rec.charge_account := p_ifdriaft.v_iftb_ria_master.dr_acc_no;
      
        pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
        pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
        pkg_detb_rtl_teller_rec.chg_amt          := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                    .chg1_amt;
        depks_rtl_teller.pkg_arc_row.cod_chg_amt := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                    .chg1_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt);
        depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;
      
        IF l_arc_maint.cod_chg_ccy <> l_cust_ac.ccy THEN
          IF NOT cypkss.fn_amt1_to_amt2(global.current_branch,
                                        l_arc_maint.cod_chg_ccy,
                                        l_cust_ac.ccy,
                                        l_prod.rate_type_preferred,
                                        l_prod.rate_code_preferred,
                                        p_ifdriaft.v_iftb_ria_out_charge(k)
                                        .chg1_amt,
                                        'Y',
                                        pkg_detb_rtl_teller_rec.chg_in_acy,
                                        pkg_detb_rtl_teller_rec.chg_ccy_acy_rate,
                                        p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy       := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                      .chg1_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
        END IF;
      
        DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
            pkg_detb_rtl_teller_rec.chg_in_acy);
        DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
            pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);
      
        pkg_detb_rtl_teller_rec.chg_in_lcy   := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                .lcy_chg1;
        pkg_detb_rtl_teller_rec.acy_lcy_rate := p_ifdriaft.v_iftb_ria_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
        pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
        pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
        pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
        pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
        pkg_detb_rtl_teller_rec.waiver       := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                .chg1_waiver;
        pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
      END IF;
      -- 2
      IF k = 2 THEN
        pkg_detb_rtl_teller_rec.chg_gl_1  := l_arc_maint.cod_chg_gl1;
        pkg_detb_rtl_teller_rec.chg_ccy_1 := l_arc_maint.cod_chg_ccy1;
        pkg_detb_rtl_teller_rec.chg_amt_1 := p_ifdriaft.v_iftb_ria_out_charge(k)
                                             .chg2_amt;
      
        depks_rtl_teller.pkg_arc_row.cod_chg_amt1 := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                     .chg2_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT1' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt1);
        depks_rtl_teller.pkg_arc_row.cod_chg_type1 := l_arc_maint.cod_chg_type1;
      
        IF l_arc_maint.cod_chg_ccy1 <> l_cust_ac.ccy THEN
          IF NOT cypkss.fn_amt1_to_amt2(global.current_branch,
                                        l_arc_maint.cod_chg_ccy1,
                                        l_cust_ac.ccy,
                                        l_prod.rate_type_preferred,
                                        l_prod.rate_code_preferred,
                                        p_ifdriaft.v_iftb_ria_out_charge(k)
                                        .chg2_amt,
                                        'Y',
                                        pkg_detb_rtl_teller_rec.chg_in_acy_1,
                                        pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1,
                                        p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_1       := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                        .chg2_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1 := 1;
        END IF;
      
        pkg_detb_rtl_teller_rec.chg_in_lcy_1   := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                  .lcy_chg2;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_1 := p_ifdriaft.v_iftb_ria_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_1  := l_arc_maint.cod_chg_netting1;
        pkg_detb_rtl_teller_rec.txn_code_1     := l_arc_maint.cod_chg_txn_code1;
        pkg_detb_rtl_teller_rec.mis_head_2     := l_arc_maint.cod_mis_head1;
        pkg_detb_rtl_teller_rec.chg_desc1      := l_arc_maint.cod_chg_desc1;
        pkg_detb_rtl_teller_rec.chg_type1      := l_arc_maint.cod_chg_type1;
        pkg_detb_rtl_teller_rec.waiver1        := p_ifdriaft.v_iftb_ria_out_charge(k)
                                                  .chg2_waiver;
        pkg_detb_rtl_teller_rec.their_chgs1    := l_arc_maint.cod_their_chgs1;
      END IF;
    
    END LOOP;
  
    dbg('Calling depks_rtl_teller.fn_save');
  
    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      PR_LOG_ERROR('IFDCCPFT', 'FLEXCUBE', p_err_code, p_err_params);
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN FALSE;
  END FN_POST_ACC_ENTRY;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdriaft         IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
    l_serial_no  VARCHAR2(16);
    l_trn_ref_no iftb_rft_master.trn_ref_no%TYPE;
  
    l_formatted_msg CLOB;
    L_COUNT         NUMBER;
    L_EXCH_RATE     ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG     NUMBER;
    L_TXN_AMT       IFTB_RIA_MASTER.TXN_AMOUNT%TYPE;
    L_DEBIT_AMT     IFTB_RIA_MASTER.DR_AMOUNT%TYPE;
    L_CREDIT_AMT    IFTB_RIA_MASTER.CR_AMOUNT%TYPE;
  
    TYPE TYPE_RIA_ENQ_FLDS IS TABLE OF IFTB_RIA_ADDL_FIELDS%ROWTYPE;
    L_RIA_ENQ_FLDS TYPE_RIA_ENQ_FLDS;
  
    L_STTB_CORAL_RIA_WS_LOG STTB_CORAL_RIA_WS_LOG%ROWTYPE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    dbg('p_Action_Code' || p_action_code);
  
    IF p_Action_Code IN ('PICKUP')  OR p_Action_Code = cspks_req_global.p_new THEN --Txn Amount Input Changes after first pickup in case no aler to click pickup once again
    
      DBG('I am in PICKUP');
      
      --nullify all values
      IF p_Action_Code IN ('PICKUP') THEN
      SELECT * BULK COLLECT INTO p_ifdriaft.v_iftb_ria_addl_fields FROM IFTB_RIA_ADDL_FIELDS
      WHERE 1 = 2;
      END IF;
      
      --DELETE FROM 
    
      IF p_ifdriaft.v_iftb_ria_master.TXN_CCY IS NULL THEN
      
        dbg('Transaction Currency can not be null');
      
        p_err_code := 'IF-RIA-002';
      
        pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
      
        RETURN FALSE;
      
      END IF;
    
      IF p_ifdriaft.v_iftb_ria_master.TXN_AMOUNT IS NULL THEN
      
        dbg('Debit Amount Should Not Be Null');
      
        p_err_code := 'IF-RIA-004';
      
        pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
      
        RETURN FALSE;
      
      END IF;
    
      --check if paying correspondent id is null
      /*IF p_ifdriaft.v_iftb_ria_master.DELIVERY_METHOD = 'CASH_PIKCUP' THEN
        IF p_ifdriaft.v_iftb_ria_master.PAYIN_CORR_ID IS NULL THEN
        
          dbg('Paying Correspondent ID Should not be null for Cash Pickup mode');
        
          p_err_code := 'IF-RIA-001';
        
          pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
        
          RETURN FALSE;
        
        END IF;
      
      ELS*/
      IF p_ifdriaft.v_iftb_ria_master.DELIVERY_METHOD = 'BANK_DEPOSIT' THEN
      
        IF p_ifdriaft.v_iftb_ria_master.BANK_ID IS NULL THEN
        
          dbg('Beneficiary BIC Code Should Not Be Null for delivery method: Bank Deposit');
        
          p_err_code := 'IF-RIA-005';
        
          pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      IF p_ifdriaft.v_iftb_ria_master.trn_ref_no IS NULL THEN
        IF NOT trpkss.fn_get_product_refno(GLOBAL.current_branch,
                                           'RIAO',
                                           global.application_date,
                                           l_serial_no,
                                           l_trn_ref_no,
                                           p_err_code) THEN
          dbg('Failed in generation Transaction Ref No');
          RETURN FALSE;
        ELSE
          dbg('l_trn_ref_no=' || l_trn_ref_no);
          p_ifdriaft.v_iftb_ria_master.trn_ref_no := l_trn_ref_no;
        
        END IF;
      END IF;
    
      --Currency Conversion
      IF p_ifdriaft.v_iftb_ria_master.TXN_CCY <>
         p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY THEN
      
        --Get Exchange Rate
        /*IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                 p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY,
                                 p_ifdriaft.v_iftb_ria_master.TXN_CCY,
                                 --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 --'STANDARD', --Commercial Exchange Rate Changes Commented
                                 'COMM', --Commercial Exchange Rate Changes Added
                                 --'S', --l_prod.rate_code_preferred,
                                 
                                 CASE WHEN p_ifdriaft.v_iftb_ria_master.TXN_CCY =
                                 'USD' AND p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY =
                                 'KHR' THEN 'B' ELSE 'S' --l_prod.rate_code_preferred,
                                 END,
                                 
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        END IF;*/
        
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                 p_ifdriaft.v_iftb_ria_master.TXN_CCY,
                                 p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY,
                                 
                                 --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 --'STANDARD', --Commercial Exchange Rate Changes Commented
                                 'COMM', --Commercial Exchange Rate Changes Added
                                 --'S', --l_prod.rate_code_preferred,
                                 
                                 CASE WHEN p_ifdriaft.v_iftb_ria_master.TXN_CCY =
                                 'USD' AND p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY =
                                 'KHR' THEN 'B' ELSE 'S' --l_prod.rate_code_preferred,
                                 END,
                                 
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        END IF;
      
      ELSE
        L_EXCH_RATE := 1;
      
      END IF;
    
      DBG('L_EXCH_RATE=' || L_EXCH_RATE);
    
      p_ifdriaft.v_iftb_ria_master.EXCH_RATE := L_EXCH_RATE;
    
      DBG('p_ifdriaft.v_iftb_ria_master.EXCH_RATE=' ||
          p_ifdriaft.v_iftb_ria_master.EXCH_RATE);
    
      --Using above rate..convert /*khr to usd amount*/  ...usd to khr amount 
      --this is between txn ccy and debit acc ccy
      /*IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY,
                                    p_ifdriaft.v_iftb_ria_master.TXN_CCY,
                                    p_ifdriaft.v_iftb_ria_master.DR_AMOUNT,
                                    L_EXCH_RATE,
                                    'Y',
                                    L_TXN_AMT,
                                    P_ERR_PARAMS) THEN
        DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
      END IF;*/
      
      IF NOT cypkss.FN_AMT1_TO_AMT2(
                                    p_ifdriaft.v_iftb_ria_master.TXN_CCY,
                                    p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY,
                                    p_ifdriaft.v_iftb_ria_master.TXN_AMOUNT,
                                    L_EXCH_RATE,
                                    'Y',
                                    L_TXN_AMT,
                                    P_ERR_PARAMS) THEN
        DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
      END IF;
    
      dbg('FINAL L_TXN_AMT=' || L_TXN_AMT);
    
      --p_ifdriaft.v_iftb_ria_master.TXN_AMOUNT := L_TXN_AMT;
      
      p_ifdriaft.v_iftb_ria_master.DR_AMOUNT := L_TXN_AMT;
    
      p_ifdriaft.v_iftb_ria_master.sending_corr_id := global.current_branch;
      --get RIA Outgoing USD Account
      p_ifdriaft.v_iftb_ria_master.CR_ACC_NO  := FN_GET_PARAM_VAL('PGW_RIA_OUT_USD_ACCOUNT');
      p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY := FN_GET_PARAM_VAL('PGW_RIA_OUT_USD');
      p_ifdriaft.v_iftb_ria_master.CR_AMOUNT  := p_ifdriaft.v_iftb_ria_master.TXN_AMOUNT;
      
      p_ifdriaft.v_iftb_ria_master.PAYMNT_DATE  := GLOBAL.application_date;
    
      /*--check if debit currency not equal to credit acc currency
      IF p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY <>
         p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY AND
         p_ifdriaft.v_iftb_ria_master.TXN_CCY <>
         p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY AND
         p_ifdriaft.v_iftb_ria_master.TXN_CCY = 'KHR' AND
         p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY = 'USD' THEN
      
        --Get Exchange Rate
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                 p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY,
                                 p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 --'STANDARD', --Commercial Exchange Rate Changes Commented
                                 'COMM', --Commercial Exchange Rate Changes Added
                                 CASE WHEN p_ifdriaft.v_iftb_ria_master.TXN_CCY =
                                 'KHR' AND p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY =
                                 'USD' THEN 'B' ELSE 'S' --l_prod.rate_code_preferred,
                                 END,
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        END IF;
      
      ELSE
        L_EXCH_RATE := 1;
      
      END IF;
      
      p_ifdriaft.v_iftb_ria_master.EXCH_RATE := L_EXCH_RATE;
      
      --Using above rate..convert \*khr to usd amount*\  ...usd to khr amount
      --this is between debit acc ccy and credit acc ccy
      
      IF p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY <>
         p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY AND
         p_ifdriaft.v_iftb_ria_master.TXN_CCY <>
         p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY THEN
        IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY,
                                      p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY,
                                      p_ifdriaft.v_iftb_ria_master.DR_AMOUNT,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_CREDIT_AMT,
                                      P_ERR_PARAMS) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
        END IF;
      END IF;
      
      dbg('FINAL L_CREDIT_AMT=' || L_CREDIT_AMT);*/
    
      IF L_CREDIT_AMT = 0 THEN
      
        P_ERR_CODE := 'IF-RIA-003';
      
        Pr_Log_Error(p_Function_id, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      
        RETURN FALSE;
      
      END IF;
    
      /*IF p_ifdriaft.v_iftb_ria_master.DR_ACC_CCY <>
         p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY AND
         p_ifdriaft.v_iftb_ria_master.TXN_CCY <>
         p_ifdriaft.v_iftb_ria_master.CR_ACC_CCY THEN
        p_ifdriaft.v_iftb_ria_master.CR_AMOUNT := L_CREDIT_AMT;
      
      ELSE
      
        p_ifdriaft.v_iftb_ria_master.CR_AMOUNT := p_ifdriaft.v_iftb_ria_master.TXN_AMOUNT;
      
      END IF;*/
    
      IF p_action_code = 'PICKUP'  OR p_Action_Code = cspks_req_global.p_new THEN
        --'INVOKERIA' THEN
      
        DBG('p_action_code=' || p_action_code);
      
        --to check if cashpickup open payment available or not
        IF p_ifdriaft.v_iftb_ria_master.DELIVERY_METHOD = 'CASH_PIKCUP' THEN
        
          IF NOT
              IFPKS_RIA_AGENT_BANK_UTLS.FN_CHECK_OPEN_PAYMENT(p_ifdriaft.v_iftb_ria_master.BEN_COUNTRY,
                                                              p_Err_Code) THEN
          
            DBG('OPEN PAYMENT IS NOT AVAILABLE FOR CASH PICKUP AND HENCE CORRESPODENT LOCATION ID IS MANDATORY');
          
            IF P_IFDRIAFT.V_IFTB_RIA_MASTER.PAYIN_CORR_ID IS NULL THEN
            
              DBG('PAYING CORRESPONDENT ID SHOULD NOT BE NULL FOR CASH PICKUP MODE AND OPEN PAYMENT IS NOT AVIALABLE');
            
              P_ERR_CODE := 'IF-RIA-001';
            
              PR_LOG_ERROR('IFDRIAFT', 'FLEXCUBE', P_ERR_CODE, NULL);
            
              RETURN FALSE;
            
            END IF;
          
          ELSE
          
            DBG('OPEN PAYMENT IS AVAILABLE FOR CASH PICKUP AND HENCE CORRESPONDENT LOCATION ID IS NOT MANDATORY');
          
            IF p_ifdriaft.v_iftb_ria_master.PAYIN_CORR_ID IS NULL THEN
            
              DBG('PAYING CORRESPONENT ID IS SETTING TO 0 AS IT IS NULL AND OPEN PAYMENT IS AVAILABLE');
            
              p_ifdriaft.v_iftb_ria_master.PAYIN_CORR_ID := '0';
            
              --p_err_code := 'IF-RIA-001';
            
              -- pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
            
              --RETURN FALSE;
            
            END IF;
          
          END IF;
        END IF;
      
        --Get RIA Account Enquiry   
      
        L_FORMATTED_MSG := FN_GET_FMT_RIA_ENQ(p_ifdriaft);
      
        DBG('AFTER REPLACEMENT OF RIA ENQUIRY JSON=' || L_FORMATTED_MSG);
      
        DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
      
        DBG('CALLING RIA ENQUIRY WEBSERVICE');
      
        IF NOT FN_MSG_UPLOAD(p_ifdriaft,
                             'I',
                             L_FORMATTED_MSG,
                             'Account Enquiry Call',
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
        
          DBG('FAILED IN RIA ENQUIRY CALL');
        
          RETURN FALSE;
        
        ELSE
        
          DBG('SUCCESS IN RIA ENQUIRY CALL');
        
          IF NOT fn_enrich_product(p_ifdriaft, p_err_code, p_err_params) THEN
            dbg('Failed in Fn_Enrich_Product');
            RETURN FALSE;
          END IF;
        
        END IF;
      
      END IF;
    END IF;
    
      
    --Save Transaction
    IF p_action_code = cspks_req_global.p_new THEN
      
    --3k validation
    IF NOT FN_CHECK_TXNLIMIT_PER_DAY(p_ifdriaft) THEN
      dbg('TXN LIMIT IS ALREADY OVER 3K ON THIS CASA ACCOUNT');
      RETURN FALSE;
    END IF;
   
    
      IF p_ifdriaft.v_iftb_ria_master.delivery_method = 'BANK_DEPOSIT' THEN
      
        IF p_ifdriaft.v_iftb_ria_master.BANK_ACCOUNT_NO IS NULL THEN
        
          dbg('Beneficiary Account No Should Not Be Null for delivery method: Bank Deposit');
        
          p_err_code := 'IF-RIA-008';
        
          pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
        
          --RETURN FALSE;
        
        END IF;
      
        IF p_ifdriaft.v_iftb_ria_master.BANK_ACCOUNT_TYPE IS NULL THEN
        
          dbg('Beneficiary Bank Account Type Should Not Be Null for delivery method: Bank Deposit');
        
          p_err_code := 'IF-RIA-010';
        
          pr_log_error('IFDRIAFT', 'FLEXCUBE', p_err_code, NULL);
        
          --RETURN FALSE;
        
        END IF;
      
      END IF;
    
      --Check if multi record values are null
    
      DBG('p_ifdriaft.v_iftb_ria_addl_fields.COUNT=' ||
          p_ifdriaft.v_iftb_ria_addl_fields.COUNT);
    
      IF p_ifdriaft.v_iftb_ria_addl_fields.COUNT > 0 THEN
      
        FOR G IN p_ifdriaft.v_iftb_ria_addl_fields.FIRST .. p_ifdriaft.v_iftb_ria_addl_fields.LAST LOOP
        
          DBG('p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_NAME=' || p_ifdriaft.v_iftb_ria_addl_fields(G)
              .FIELD_NAME);
          DBG('p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE=' || p_ifdriaft.v_iftb_ria_addl_fields(G)
              .FIELD_VALUE);
        
          IF p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_VALUE IS NULL THEN
          
            P_ERR_CODE := 'IF-RIA-003';
          
            /* Pr_Log_Error(p_Function_id,
            P_SOURCE,
            P_ERR_CODE,
            p_ifdriaft.v_iftb_ria_addl_fields(G).FIELD_NAME);*/
          
            RETURN FALSE;
          
          END IF;
        
        END LOOP;
      
      END IF;
    
      IF NOT FN_POST_ACC_ENTRY(p_ifdriaft) THEN
        --p_ifdccpft.v_cstbs_ui_columns.char_field2) THEN
      
        DBG('FAILED IN CREDITING TO GL');
        RETURN FALSE;
      ELSE
        DBG('SUCCESS IN CREDITING TO GL');
        RETURN TRUE;
      END IF;
    END IF;
    
  
  
    --Delete Transaction
    IF p_action_code = cspks_req_global.p_delete THEN
      IF NOT depks_rtl_teller.fn_delete(p_ifdriaft.v_iftb_ria_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in FN_DELETE');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Auth Transaction
    IF p_action_code = cspks_req_global.p_auth THEN
    
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM sttb_coral_ria_ws_log
         WHERE FC_REF_NO = p_ifdriaft.v_iftb_ria_master.trn_ref_no
           AND ACTION = 'DOSCAN_AUTH'
           AND SCAN_ID IS NOT NULL;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      DBG('L_COUNT=' || L_COUNT);
    
      IF L_COUNT = 0 THEN
        IF NOT FN_AML_VALIDATION(p_ifdriaft) THEN
          RETURN FALSE;
        END IF;
      END IF;
    
      --Get AML Status
      BEGIN
        SELECT *
          INTO L_STTB_CORAL_RIA_WS_LOG
          FROM STTB_CORAL_RIA_WS_LOG
         WHERE FC_REF_NO = p_ifdriaft.v_iftb_ria_master.trn_ref_no
           AND UNIQUE_REFERENCE_NO =
               (SELECT MAX(UNIQUE_REFERENCE_NO)
                  FROM STTB_CORAL_RIA_WS_LOG
                 WHERE FC_REF_NO = p_ifdriaft.v_iftb_ria_master.trn_ref_no
                   AND REQ_TYPE = 'ONLINE_SCAN'
                   AND ACTION = 'DOSCAN_AUTH');
        --AND STATUS NOT IN ('PENDING');
      EXCEPTION
        WHEN OTHERS THEN
          L_STTB_CORAL_RIA_WS_LOG := NULL;
      END;
    
      DBG('L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO=' ||
          L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO);
      DBG('L_STTB_CORAL_RIA_WS_LOG.SCAN_ID=' ||
          L_STTB_CORAL_RIA_WS_LOG.SCAN_ID);
    
      IF NOT IFPKS_SANCTION_UTILS.FN_GET_AML_STATUS_RIA_OUT(L_STTB_CORAL_RIA_WS_LOG.SCAN_ID,
                                                            L_STTB_CORAL_RIA_WS_LOG.CUSTOMER_NO,
                                                            L_STTB_CORAL_RIA_WS_LOG.FC_REF_NO,
                                                            p_Err_Code,
                                                            p_Err_Params) THEN
        RETURN FALSE;
      END IF;
    
      DBG('p_ifdriaft.v_iftb_ria_master.MAKER_ID=' ||
          p_ifdriaft.v_iftb_ria_master.MAKER_ID);
    
      DBG('p_ifdriaft.v_iftb_ria_master.CHECKER_ID=' ||
          p_ifdriaft.v_iftb_ria_master.CHECKER_ID);
    
      DBG('GLOBAL.USER_ID' || GLOBAL.USER_ID);
    
      --Maker Can not authorize
      IF p_ifdriaft.v_iftb_ria_master.MAKER_ID = GLOBAL.USER_ID THEN
        pr_log_error(p_function_id, p_source, 'CF-AUT-002', NULL);
        RETURN FALSE;
      END IF;
    
      dbg(' Message generation success, going to upload now');
    
      --Get RIA CONFIRM PAYMENT    
      DBG('p_ifdriaft.v_iftb_ria_master.DELIVERY_METHOD=' ||
          p_ifdriaft.v_iftb_ria_master.DELIVERY_METHOD);
      IF p_ifdriaft.v_iftb_ria_master.DELIVERY_METHOD = 'CASH_PIKCUP' THEN
        L_FORMATTED_MSG := FN_GET_FMT_RIA_PAYMENT_CASHPIC(p_ifdriaft);
      ELSIF p_ifdriaft.v_iftb_ria_master.DELIVERY_METHOD = 'BANK_DEPOSIT' THEN
        L_FORMATTED_MSG := FN_GET_FMT_RIA_PAYMENT(p_ifdriaft);
      END IF;
    
      DBG('AFTER REPLACEMENT OF RIA PAYMENT JSON=' || L_FORMATTED_MSG);
    
      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
    
      DBG('CALLING RIA PAYMENT WEBSERVICE');
    
      IF NOT FN_MSG_UPLOAD(p_ifdriaft,
                           'C',
                           L_FORMATTED_MSG,
                           'Payment Confirmation Call',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      
        DBG('FAILED IN RIA PAYMENT CALL');
      
        RETURN FALSE;
      
      ELSE
      
        DBG('SUCCESS IN RIA PAYMENT CALL');
      
        --Check if already authorised
      
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM IFTB_RIA_MASTER
           WHERE TRN_REF_NO = p_ifdriaft.v_iftb_ria_master.trn_ref_no
                -- AND AUTH_STAT = 'A'
             AND ONCE_AUTH = 'Y';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;
      
        IF L_COUNT > 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'ST-VALS-007',
                       'Transaction No:' ||
                       p_ifdriaft.v_iftb_ria_master.trn_ref_no);
          RETURN FALSE;
        END IF;
      
        --AUTH TRANSACTION
        DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
        IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.current_branch,
                                                    p_ifdriaft.v_iftb_ria_master.trn_ref_no,
                                                    GLOBAL.USER_ID,
                                                    GLOBAL.LCY,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
          DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
          PR_LOG_ERROR('IFDRIAFT', 'FLEXCUBE', p_err_code, p_err_params);
          RETURN FALSE;
        ELSE
          --generate SVXP File
          dbg('done with authorization');
        END IF;
      
      END IF;
    
      dbg('fn_msg_upload successful');
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdriaft_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdriaft         IN ifpks_ifdriaft_Main.ty_ifdriaft,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdriaft_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdriaft         IN ifpks_ifdriaft_Main.ty_ifdriaft,
                                       p_Prev_ifdriaft    IN OUT ifpks_ifdriaft_Main.ty_ifdriaft,
                                       p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.ty_ifdriaft,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    
    TYPE TYPE_ria_enq_fld_len IS TABLE OF test_xml_data_ria_enq_fld_len1%ROWTYPE;
    L_TYPE_ria_enq_fld_len TYPE_ria_enq_fld_len;
    
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
    
     IF p_action_code = cspks_req_global.p_new THEN
      
    DBG('INSIDE SAVING TXN');
      
    --length validation
    BEGIN
 SELECT xt.* BULK COLLECT INTO L_TYPE_ria_enq_fld_len 
                  FROM test_xml_data_ria_enq_temp x, 
                       XMLTABLE('root/data/requiredField' PASSING x.payload 
                        COLUMNS FieldName VARCHAR2(255) PATH 'FieldName',
                                MinLength VARCHAR2(255) PATH 'MinLength',
                                MaxLength VARCHAR2(255) PATH 'MaxLength') xt  WHERE TRN_REF_NO = p_ifdriaft.v_iftb_ria_master.trn_ref_no;
 END;
 
 BEGIN
  FOR G IN p_Wrk_ifdriaft.v_iftb_ria_addl_fields.first .. p_Wrk_ifdriaft.v_iftb_ria_addl_fields.LAST

   LOOP
  
  FOR I IN L_TYPE_ria_enq_fld_len.FIRST .. L_TYPE_ria_enq_fld_len.LAST LOOP
    
  IF L_TYPE_ria_enq_fld_len(I).FIELD_NAME = 'BankAccountNo' THEN
    
  IF LENGTH(p_Wrk_ifdriaft.v_iftb_ria_master.bank_account_no) > L_TYPE_ria_enq_fld_len(I).MAX_LENGTH AND L_TYPE_ria_enq_fld_len(I).MAX_LENGTH <> 0  THEN
   
    p_err_code := 'IF-RIA-015';
      
      p_err_params := L_TYPE_ria_enq_fld_len(I).FIELD_NAME || '~' || L_TYPE_ria_enq_fld_len(I).MAX_LENGTH;
    
      --OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');
      
      --Pr_Log_Error('IFDRIAFT', 'FLEXCUBE', p_err_code, L_STATUS_MSG);
    
      RETURN FALSE;
   
   END IF;
   
   IF LENGTH(p_Wrk_ifdriaft.v_iftb_ria_master.bank_account_no) < L_TYPE_ria_enq_fld_len(I).MIN_LENGTH AND L_TYPE_ria_enq_fld_len(I).MIN_LENGTH <> 0 THEN
  
   p_err_code := 'IF-RIA-016';
      
      p_err_params := L_TYPE_ria_enq_fld_len(I).FIELD_NAME || '~' || L_TYPE_ria_enq_fld_len(I).MIN_LENGTH || '~' || L_TYPE_ria_enq_fld_len(I).MAX_LENGTH;
    
      --OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');
      
      --Pr_Log_Error('IFDRIAFT', 'FLEXCUBE', p_err_code, L_STATUS_MSG);
    
      RETURN FALSE;
   
   END IF;
    
  END IF;
  
  
  IF p_Wrk_ifdriaft.v_iftb_ria_addl_fields(G)
   .FIELD_NAME = L_TYPE_ria_enq_fld_len(I).FIELD_NAME THEN
   
  DBG('L_TYPE_ria_enq_fld_len(I).FIELD_NAME='||L_TYPE_ria_enq_fld_len(I).FIELD_NAME);
  DBG('L_TYPE_ria_enq_fld_len(I).MAX_LENGTH='||L_TYPE_ria_enq_fld_len(I).MAX_LENGTH);
  DBG('L_TYPE_ria_enq_fld_len(I).MIN_LENGTH='||L_TYPE_ria_enq_fld_len(I).MIN_LENGTH);
  DBG('DYNAMIC FIELD NAME='||p_Wrk_ifdriaft.v_iftb_ria_addl_fields(G)
   .FIELD_NAME);
  DBG('LENGTH OF DYNAMIC FIELD NAME='||LENGTH(p_Wrk_ifdriaft.v_iftb_ria_addl_fields(G)
   .FIELD_VALUE));
   
   IF LENGTH(p_Wrk_ifdriaft.v_iftb_ria_addl_fields(G)
   .FIELD_VALUE) > L_TYPE_ria_enq_fld_len(I).MAX_LENGTH AND L_TYPE_ria_enq_fld_len(I).MAX_LENGTH <> 0 THEN
   
    p_err_code := 'IF-RIA-015';
      
      p_err_params := p_Wrk_ifdriaft.v_iftb_ria_addl_fields(G)
   .FIELD_NAME || '~' || L_TYPE_ria_enq_fld_len(I).MAX_LENGTH;
    
      --OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');
      
      --Pr_Log_Error('IFDRIAFT', 'FLEXCUBE', p_err_code, L_STATUS_MSG);
    
      RETURN FALSE;
   
   END IF;
   
   IF LENGTH(p_Wrk_ifdriaft.v_iftb_ria_addl_fields(G)
   .FIELD_VALUE) < L_TYPE_ria_enq_fld_len(I).MIN_LENGTH AND L_TYPE_ria_enq_fld_len(I).MIN_LENGTH <> 0 THEN
   
    p_err_code := 'IF-RIA-016';
      
      p_err_params := p_Wrk_ifdriaft.v_iftb_ria_addl_fields(G)
   .FIELD_NAME || '~' || L_TYPE_ria_enq_fld_len(I).MIN_LENGTH || '~' || L_TYPE_ria_enq_fld_len(I).MAX_LENGTH;
    
      --OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');
      
      --Pr_Log_Error('IFDRIAFT', 'FLEXCUBE', p_err_code, L_STATUS_MSG);
    
      RETURN FALSE;
   
   END IF;
   
   
   END IF;
  
  END LOOP;
  
  
   
  END LOOP;
  END;
  END IF;
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdriaft_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdriaft         IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                                        p_Prev_ifdriaft    IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                        p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdriaft_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdriaft         IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                            p_Prev_ifdriaft    IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                            p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    IF p_Action_Code = 'AUTH' THEN
    
      DBG('P_IFDRIAFT.v_iftb_ria_master.RIA_REFERENCE_NO=' ||
          P_IFDRIAFT.v_iftb_ria_master.RIA_REFERENCE_NO);
      DBG('P_IFDRIAFT.v_iftb_ria_master.ORDER_NO=' ||
          P_IFDRIAFT.v_iftb_ria_master.ORDER_NO);
      DBG('P_IFDRIAFT.v_iftb_ria_master.RIA_ORDER_NO=' ||
          P_IFDRIAFT.v_iftb_ria_master.RIA_ORDER_NO);
      DBG('P_IFDRIAFT.v_iftb_ria_master.RIA_PIN=' ||
          P_IFDRIAFT.v_iftb_ria_master.RIA_PIN);
      DBG('P_IFDRIAFT.v_iftb_ria_master.RIA_PAY_STATUS=' ||
          P_IFDRIAFT.v_iftb_ria_master.RIA_PAY_STATUS);
    
      UPDATE IFTB_RIA_MASTER
         SET RIA_PAY_STATUS   = P_IFDRIAFT.v_iftb_ria_master.RIA_PAY_STATUS,
             RIA_REFERENCE_NO = P_IFDRIAFT.v_iftb_ria_master.RIA_REFERENCE_NO,
             ORDER_NO         = P_IFDRIAFT.v_iftb_ria_master.ORDER_NO,
             RIA_ORDER_NO     = P_IFDRIAFT.v_iftb_ria_master.RIA_ORDER_NO,
             RIA_PIN          = P_IFDRIAFT.v_iftb_ria_master.RIA_PIN
       WHERE TRN_REF_NO = P_IFDRIAFT.v_iftb_ria_master.TRN_REF_NO;
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdriaft_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdriaft         IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                             p_prev_ifdriaft    IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                             p_wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdriaft_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdriaft         IN ifpks_ifdriaft_Main.Ty_ifdriaft,
                        p_Wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.Ty_ifdriaft,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    DBG('P_IFDRIAFT.v_iftb_ria_master.RIA_PIN=' ||
        P_IFDRIAFT.v_iftb_ria_master.RIA_PIN);
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdriaft_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdriaft         IN ifpks_ifdriaft_Main.ty_ifdriaft,
                         p_wrk_ifdriaft     IN OUT ifpks_ifdriaft_Main.ty_ifdriaft,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdriaft_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdriaft_custom;
