-- Create sequence 
create sequence TRSQ_RIA_SEQID
minvalue 1
maxvalue 999999999
start with 26
increment by 1
nocache
cycle;
/
-- Create table
create table IFTB_RIA_MASTER
(
  trn_ref_no       VARCHAR2(16) not null,
  txn_ccy          VARCHAR2(3),
  txn_amount       NUMBER(22,3),
  dr_acc_no        VARCHAR2(20),
  dr_acc_ccy       VARCHAR2(3),
  dr_amount        NUMBER(22,3),
  cr_acc_no        VARCHAR2(20),
  cr_acc_ccy       VARCHAR2(3),
  cr_amount        NUMBER(22,3),
  paymnt_date      DATE,
  exch_rate        NUMBER(24,12),
  narrative        VARCHAR2(250),
  record_stat      CHAR(1),
  auth_stat        CHAR(1),
  mod_no           NUMBER(4),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  once_auth        CHAR(1),
  txn_unique_no    VARCHAR2(105),
  payin_corr_id    VARCHAR2(25),
  sending_corr_id  VARCHAR2(25),
  delivery_method  VARCHAR2(25),
  ben_country      VARCHAR2(2),
  ben_cnt_ccy      VARCHAR2(3),
  ben_firstname    VARCHAR2(105),
  ben_lastname     VARCHAR2(105),
  ben_city         VARCHAR2(255),
  ben_state        VARCHAR2(255),
  ria_reference_no VARCHAR2(105),
  order_no         VARCHAR2(105),
  ria_order_no     VARCHAR2(105),
  ria_pin          VARCHAR2(105),
  ria_pay_status   VARCHAR2(255)
)
/
alter table IFTB_RIA_MASTER add primary key (TRN_REF_NO)
/
-- Create table
create table IFTB_RIA_ADDL_FIELDS
(
  trn_ref_no    VARCHAR2(16) not null,
  field_name    VARCHAR2(25) not null,
  field_value   VARCHAR2(255),
  txn_unique_no VARCHAR2(25) not null
)
/
alter table IFTB_RIA_ADDL_FIELDS add primary key (TRN_REF_NO, TXN_UNIQUE_NO, FIELD_NAME)
/
-- Create table
create table IFTB_RIA_WS_OUT_LOG
(
  seq_no        VARCHAR2(105) not null,
  trn_ref_no    VARCHAR2(16),
  invoke_date   DATE,
  req_type      VARCHAR2(25),
  req_msg       CLOB,
  res_msg       CLOB,
  txn_unique_no VARCHAR2(105),
  status        CHAR(1),
  addl_info     VARCHAR2(105)
)
/
alter table IFTB_RIA_WS_OUT_LOG add primary key (SEQ_NO)
/