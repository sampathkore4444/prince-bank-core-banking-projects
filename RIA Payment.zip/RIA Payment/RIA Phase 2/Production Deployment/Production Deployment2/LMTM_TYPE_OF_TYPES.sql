insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('RIA_OUT_ACC_TYPE', 'RIA Outgoing Payment Bank Account Types', 'SAMPATH2', 'SAMPATH2', to_date('03-04-2021 02:00:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-04-2021 02:00:34', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('RIA_TRF_PURPOSE', 'RIA OUTGOING TRANSFER OF PURPOSE', 'SAMPATH2', 'SAMPATH2', to_date('03-04-2021 14:16:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-04-2021 14:16:14', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('RIA_OUT_ACC_TYPE', 'RIA Outgoing Payment Bank Account Types', 'SAMPATH2', 'SAMPATH2', to_date('03-04-2021 02:00:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-04-2021 02:00:34', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
