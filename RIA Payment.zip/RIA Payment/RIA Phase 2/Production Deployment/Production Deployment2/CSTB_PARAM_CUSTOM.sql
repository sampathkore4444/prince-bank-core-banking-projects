insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_AUTH_PWD', 'qwer!@#$', 'Y');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_AUTH_UID', 'prince', 'Y');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_IN_ENQ_URL', 'http://integration-uat.princeplc.com.kh/prnc-app/ria/api/v1/inb/cash-out-inquiry', 'Y');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_OUT_ENQ_URL', 'http://integration-uat.princeplc.com.kh/prnc-app/ria/api/v1/obnd/order-inquiry', 'Y');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_OUT_KHR', 'KHR', 'N');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_OUT_USD', 'USD', 'N');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_OUT_USD_ACCOUNT', '000021058', 'Y');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_PAYCONFIRM_IN_URL', 'http://integration-uat.princeplc.com.kh/prnc-app/ria/api/v1/inb/cash-out-confirm', 'Y');

insert into CSTB_PARAM_CUSTOM (PARAM_NAME, PARAM_VAL, MODIFY_FIELD)
values ('PGW_RIA_PAYCONFIRM_OUT_URL', 'http://integration-uat.princeplc.com.kh/prnc-app/ria/api/v1/obnd/pay-order', 'Y');

COMMIT;
