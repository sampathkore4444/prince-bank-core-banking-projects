insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'AMOUNT_TO_RECEIVE_RIAA', 32, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BANK_ACCOUNT_TYPE_RIAA', 10, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BANK_ID_RIAA', 6, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BANK_ROUTING_CODE_RIAA', 11, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_ACCOUNT_NO_RIAA', 7, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_ADDRESS_RIAA', 18, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_CELL_NO_RIAA', 27, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_CITY_RIAA', 8, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_COUNTRY_RIAA', 2, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_FIRST_NAME_RIAA', 4, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_ID_NO_RIAA', 14, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_ID_TYPE_RIAA', 13, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_LAST_NAME_RIAA', 5, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_PHONE_RIAA', 16, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BEN_STATE_RIAA', 9, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'BIC_SWIFT_RIAA', 15, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'CUSTOMER_ADDRESS_RIAA', 22, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'CUSTOMER_BIRTH_CITY_RIAA', 23, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'CUSTOMER_BIRTH_COUNTRY_RIAA', 24, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'CUSTOMER_OCCUPATION_RIAA', 21, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'CUSTOMER_STATE_RIAA', 25, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'CUSTOMER_ZIP_CODE_RIAA', 19, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'CUST_BEN_RELATIONSHIP_RIAA', 20, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'EXCHANGE_RATE_RIAA', 31, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'PICKUP_AGENT_NAME_RIAA', 35, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'PURPOSE_OF_TRF_RIAA', 12, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'RECEIVING_CURRENCY_RIAA', 33, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'RECEIVING_OPTION_RIAA', 30, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'RIA_FEE_RIAA', 36, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'RIA_PIN_RIAA', 28, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'RIA_REF_NO_RIAA', 34, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'SENDER_COUNTRY_RIAA', 29, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'SENDER_NAME_RIAA', 3, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'TXN_UNIQUE_NO_RIAA', 1, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'UNITARY_BANK_ACC_NO_RIAA', 26, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAA', 'VALUE_TYPE_RIAA', 17, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'COUNTRY_FROM_RIAP', 7, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'RIA_ORDER_DATE_RIAP', 11, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'RIA_ORDER_NO_RIAP', 2, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'RIA_PIN_RIAP', 4, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'RIA_REFERENCE_NO_RIAP', 1, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'SENDER_DOB_RIAP', 8, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'SENDER_FIRST_NAME_RIAP', 5, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'SENDER_LAST_NAME_RIAP', 6, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'SENDER_NATIONALITY_RIAP', 9, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'TXN_REMARKS_RIAP', 10, 'A');

insert into cstm_product_udf_fields_map (PRODUCT_CODE, FIELD_NAME, FIELD_NUM, AUTH_STAT)
values ('RIAP', 'TXN_UNIQUE_NO_RIAP', 3, 'A');

COMMIT;
