insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_TRF_PURPOSE', 'Capital Transfer', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_TRF_PURPOSE', 'Income(Wages and Salaries)', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_TRF_PURPOSE', 'Investment', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_TRF_PURPOSE', 'Payment for goods', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_TRF_PURPOSE', 'Payment for services', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_TRF_PURPOSE', 'Personal or Family Support', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_OUT_ACC_TYPE', 'Checking', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_OUT_ACC_TYPE', 'Credit', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_OUT_ACC_TYPE', 'Loan', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('RIA_OUT_ACC_TYPE', 'Savings', null);


COMMIT;
