CREATE OR REPLACE PACKAGE BODY Rtpks_Dedquery_Kernel AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'rtpks_dedquery_Kernel ==>' || P_MSG;
    DEBUG.PR_DEBUG('RT', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');
  END PR_SKIP_HANDLER;
  FUNCTION FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                        P_DEDQUERY         IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Build_Type_Structure..');
  
    DBG('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Build_Type_Structure ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_BUILD_TYPE_STRUCTURE;

  FUNCTION FN_PRE_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CHILD_FUNCTION   IN VARCHAR2,
                                  P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                  P_DEDQUERY         IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    DBG('In Fn_Pre_Check_Mandatory..');
  
    DBG('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    DBG('In Fn_Post_Check_Mandatory..');
  
    DBG('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CHILD_FUNCTION   IN VARCHAR2,
                                       P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                       P_PREV_DEDQUERY    IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                       P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Default_And_Validate..');
  
    DBG('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

  FUNCTION FN_POST_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                        P_PREV_DEDQUERY    IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                        P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Default_And_Validate..');
  
    DBG('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DEFAULT_AND_VALIDATE;

  FUNCTION FN_PRE_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_DEDQUERY         IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Pre_Resolve_Ref_Numbers..');
  
    DBG('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_RESOLVE_REF_NUMBERS;
  FUNCTION FN_POST_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_DEDQUERY         IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Post_Resolve_Ref_Numbers..');
  
    DBG('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of rtpks_dedquery_Main.Fn_Post_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_RESOLVE_REF_NUMBERS;
  FUNCTION FN_PRE_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                  P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Product_Default..');
  
    DBG('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PRODUCT_DEFAULT;

  FUNCTION FN_POST_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                   P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Product_Default..');
  
    DBG('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PRODUCT_DEFAULT;

  FUNCTION FN_PRE_UNLOCK(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN OUT VARCHAR2,
                         P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Unlock..');
  
    DBG('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UNLOCK;

  FUNCTION FN_POST_UNLOCK(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN OUT VARCHAR2,
                          P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Unlock');
  
    DBG('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UNLOCK;

  FUNCTION FN_PRE_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                P_PREV_DEDQUERY    IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Subsys_Pickup..');
  
    DBG('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_SUBSYS_PICKUP;

  FUNCTION FN_POST_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                 P_PREV_DEDQUERY    IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                 P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Subsys_Pickup..');
  
    DBG('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_SUBSYS_PICKUP;

  FUNCTION FN_PRE_ENRICH(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                         P_PREV_DEDQUERY    IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                         P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Enrich..');
  
    DBG('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_ENRICH;

  FUNCTION FN_POST_ENRICH(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                          P_PREV_DEDQUERY    IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                          P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Enrich..');
  
    DBG('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_ENRICH;

  FUNCTION FN_PRE_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_CHILD_FUNCTION   IN VARCHAR2,
                            P_MULTI_TRIP_ID    IN VARCHAR2,
                            P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                            P_PREV_DEDQUERY    IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                            P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Upload_Db..');
  
    DBG('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UPLOAD_DB;

  FUNCTION FN_POST_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_MULTI_TRIP_ID    IN VARCHAR2,
                             P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                             P_PREV_DEDQUERY    IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                             P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Upload_Db..');
  
    DBG('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UPLOAD_DB;

  FUNCTION FN_PRE_PROCESS(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_CHILD_FUNCTION   IN VARCHAR2,
                          P_MULTI_TRIP_ID    IN VARCHAR2,
                          P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                          P_PREV_DEDQUERY    IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                          P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Process..');
  
    DBG('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PROCESS;

  FUNCTION FN_POST_PROCESS(P_SOURCE           IN VARCHAR2,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_FUNCTION_ID      IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_CHILD_FUNCTION   IN VARCHAR2,
                           P_MULTI_TRIP_ID    IN VARCHAR2,
                           P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                           P_PREV_DEDQUERY    IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                           P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Process..');
  
    DBG('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PROCESS;

  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CHILD_FUNCTION   IN VARCHAR2,
                        P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                        P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                        P_QRYDATA_REQD     IN VARCHAR2,
                        P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                        P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Query..');
  
    DBG('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Pre_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;

  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CHILD_FUNCTION   IN VARCHAR2,
                         P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                         P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                         P_QRYDATA_REQD     IN VARCHAR2,
                         P_DEDQUERY         IN RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                         P_WRK_DEDQUERY     IN OUT RTPKS_DEDQUERY_MAIN.TY_DEDQUERY,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
    CURSOR C_RTL_TELLER(FCCREF VARCHAR2) IS
      SELECT * FROM DETB_RTL_TELLER WHERE TRN_REF_NO = FCCREF;
  
    CURSOR C_ARC_SETTLE(XREF VARCHAR2) IS
      SELECT * FROM CSTBS_ARC_SETTLE WHERE XREF = XREF;
  
    L_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
  
    L_PROD      CSTM_PRODUCT.PRODUCT_CODE%TYPE;
    L_PROD_DESC CSTM_PRODUCT.PRODUCT_DESCRIPTION%TYPE;
    L_MODULE    CSTM_PRODUCT.MODULE%TYPE;
  
    L_DEBIT_BAL STTMS_CUST_ACCOUNT.ACY_CURR_BALANCE%TYPE;
    L_CEDIT_BAL STTMS_CUST_ACCOUNT.ACY_CURR_BALANCE%TYPE;
  
    L_BRANCH_NAME STTM_BRANCH.BRANCH_NAME%TYPE;
  
    L_TXN_TYPE      DETB_RTL_TELLER.DR_ACC%TYPE;
    L_TRN_CODE      STTM_TRN_CODE.TRN_CODE%TYPE;
    L_TRN_CODE_DESC STTM_TRN_CODE.TRN_DESC%TYPE;
  
    L_ACC_TYPE_OFS STTBS_ACCOUNT.AC_OR_GL%TYPE;
    L_ACC_TYPE_TXN STTBS_ACCOUNT.AC_OR_GL%TYPE;
  
    L_TXNBRNDESC       STTM_BRANCH.BRANCH_NAME%TYPE;
    L_OFSBRNDESC       STTM_BRANCH.BRANCH_NAME%TYPE;
    L_OFSTRNCDDESC     STTM_TRN_CODE.TRN_DESC%TYPE;
    L_TXNACCDESC       STTB_ACCOUNT.AC_GL_DESC%TYPE;
    L_OFSACDESC        STTB_ACCOUNT.AC_GL_DESC%TYPE;
    L_SENDER_NAME_RIAP VARCHAR2(255); --RIA Phase2 Changes for Mobile Banking Changes
  
  BEGIN
    DBG('In Fn_Post_Query');
    BEGIN
      DBG('Fccref = ' || P_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.FCCREF);
      SELECT *
        INTO L_RTL_TELLER
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.FCCREF;
    
      DBG('l_Rtl_Teller.Product_Code:::: ' || L_RTL_TELLER.PRODUCT_CODE);
      DBG('l_Rtl_Teller.Branch_Code ::::: ' || L_RTL_TELLER.BRANCH_CODE);
      DBG('l_Rtl_Teller.Txn_Acc ::::: ' || L_RTL_TELLER.TXN_ACC);
      DBG('l_Rtl_Teller.Ofs_Acc ::::: ' || L_RTL_TELLER.OFS_ACC);
      BEGIN
        SELECT MODULE, PRODUCT_DESCRIPTION
          INTO L_MODULE, L_PROD_DESC
          FROM CSTM_PRODUCT
         WHERE PRODUCT_CODE = L_RTL_TELLER.PRODUCT_CODE;
      
        SELECT BRANCH_NAME
          INTO L_BRANCH_NAME
          FROM STTM_BRANCH
         WHERE BRANCH_CODE = L_RTL_TELLER.BRANCH_CODE;
      
        SELECT DR_ACC, TXN_TRN_CODE
          INTO L_TXN_TYPE, L_TRN_CODE
          FROM DETB_RTL_TELLER
         WHERE TRN_REF_NO = P_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.FCCREF;
      
        DBG('l_txn_type:::::: ' || L_TXN_TYPE);
        DBG('l_trn_code:::::: ' || L_TRN_CODE);
        SELECT TRN_DESC
          INTO L_TRN_CODE_DESC
          FROM STTM_TRN_CODE
         WHERE TRN_CODE = L_TRN_CODE;
        DBG('l_trn_code_desc :::::: ' || L_TRN_CODE_DESC);
      
        DBG('25052249###Selecting description fields..');
        SELECT BRANCH_NAME
          INTO L_TXNBRNDESC
          FROM STTM_BRANCH
         WHERE BRANCH_CODE = L_RTL_TELLER.TXN_BRANCH;
        DBG('l_txnbrndesc--> ' || L_TXNBRNDESC);
      
        SELECT BRANCH_NAME
          INTO L_OFSBRNDESC
          FROM STTM_BRANCH
         WHERE BRANCH_CODE = L_RTL_TELLER.OFS_BRANCH;
        DBG('l_ofsbrndesc--> ' || L_OFSBRNDESC);
      
        SELECT TRN_DESC
          INTO L_OFSTRNCDDESC
          FROM STTM_TRN_CODE
         WHERE TRN_CODE = L_RTL_TELLER.OFS_TRN_CODE;
        DBG('l_ofstrncddesc--> ' || L_OFSTRNCDDESC);
      
        SELECT AC_GL_DESC
          INTO L_TXNACCDESC
          FROM STTB_ACCOUNT
         WHERE AC_GL_NO = L_RTL_TELLER.TXN_ACC;
        DBG('l_txnaccdesc--> ' || L_TXNACCDESC);
      
        SELECT AC_GL_DESC
          INTO L_OFSACDESC
          FROM STTB_ACCOUNT
         WHERE AC_GL_NO = L_RTL_TELLER.OFS_ACC;
        DBG('l_ofsacdesc--> ' || L_OFSACDESC);
      
        BEGIN
          SELECT AC_OR_GL
            INTO L_ACC_TYPE_TXN
          
            FROM STTBS_ACCOUNT
           WHERE AC_GL_NO = L_RTL_TELLER.TXN_ACC
                
             AND BRANCH_CODE = L_RTL_TELLER.TXN_BRANCH;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_ACC_TYPE_TXN := 'G';
            DBG('Account details not found with the follwing pararmeters  Hence setting type as GL' ||
                L_RTL_TELLER.TXN_ACC || 'Branch COde ' ||
                L_RTL_TELLER.TXN_BRANCH);
        END;
      
        DBG('l_acc_type_txn for Transaction Account :::: ' ||
            L_ACC_TYPE_TXN);
      
        BEGIN
          SELECT AC_OR_GL
            INTO L_ACC_TYPE_OFS
          
            FROM STTBS_ACCOUNT
           WHERE AC_GL_NO = L_RTL_TELLER.OFS_ACC
                
             AND BRANCH_CODE = L_RTL_TELLER.OFS_BRANCH;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_ACC_TYPE_OFS := 'G';
            DBG(' Offset Account details not found with the follwing pararmeters  Hence setting type as GL' ||
                L_RTL_TELLER.OFS_ACC || 'Branch Code ' ||
                L_RTL_TELLER.OFS_BRANCH);
        END;
      
        DBG('l_acc_type_ofs for Offset Account :::: ' || L_ACC_TYPE_OFS);
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Data does not exist with line tracking ::::: ' ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        WHEN OTHERS THEN
          DBG('In OTHERS of fn_post_query with line tracking::::: ' ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      END;
    
      IF L_TXN_TYPE = 'TXN' THEN
      
        IF L_ACC_TYPE_TXN = 'A' THEN
          DBG('Came here FOR TRANSACTION ACCOUNT..........');
          BEGIN
            SELECT ACY_CURR_BALANCE
              INTO L_DEBIT_BAL
            
              FROM STTMS_CUST_ACCOUNT
             WHERE CUST_AC_NO = L_RTL_TELLER.TXN_ACC
                  
               AND BRANCH_CODE = L_RTL_TELLER.TXN_BRANCH;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Transaction Account details not found with the follwing pararmeters  in sttm_cust_account ' ||
                  L_RTL_TELLER.TXN_ACC || 'Branch Code ' ||
                  L_RTL_TELLER.TXN_BRANCH);
          END;
        
        ELSE
          DBG('TRANSACTION ACCOUNT IS GL');
        END IF;
      
      ELSE
        IF L_ACC_TYPE_OFS = 'A' THEN
          DBG('Came here FOR OFFSET ACCOUNT..........');
          BEGIN
            SELECT ACY_CURR_BALANCE
              INTO L_DEBIT_BAL
            
              FROM STTMS_CUST_ACCOUNT
             WHERE CUST_AC_NO = L_RTL_TELLER.OFS_ACC
                  
               AND BRANCH_CODE = L_RTL_TELLER.OFS_BRANCH;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
            
              DBG(' Offset Account details not found with the follwing pararmeters  in sttb_cust_account' ||
                  L_RTL_TELLER.OFS_ACC || 'Branch Code ' ||
                  L_RTL_TELLER.OFS_BRANCH);
          END;
        
          DBG('Debit account balance is :::: ' || L_DEBIT_BAL ||
              ' when debit account is ::: ' || L_RTL_TELLER.OFS_ACC);
        ELSE
          DBG('OFFSET ACCOUNT IS GL for debit balance');
        END IF;
      END IF;
    
      IF L_TXN_TYPE = 'TXN' THEN
      
        IF L_ACC_TYPE_OFS = 'A' THEN
          DBG('CAME HERE FOR OFFSET ACCOUNT >>>>>>>');
          BEGIN
            SELECT ACY_CURR_BALANCE
              INTO L_CEDIT_BAL
            
              FROM STTMS_CUST_ACCOUNT
             WHERE CUST_AC_NO = L_RTL_TELLER.OFS_ACC
                  
               AND BRANCH_CODE = L_RTL_TELLER.OFS_BRANCH;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
            
              DBG(' Offset Account details not found with the follwing pararmeters  in sttb_cust_account' ||
                  L_RTL_TELLER.OFS_ACC || 'Branch Code ' ||
                  L_RTL_TELLER.OFS_BRANCH);
          END;
        
          DBG('Credit account balance is :::: ' || L_CEDIT_BAL ||
              ' when Credit account is ::: ' || L_RTL_TELLER.OFS_ACC);
        ELSE
          DBG('OFFSET ACCOUNT IS GL');
        END IF;
      
      ELSE
        IF L_ACC_TYPE_TXN = 'A' THEN
          DBG('CAME HERE FOR TRANSACTION ACCOUNT >>>>>>>');
          BEGIN
            SELECT ACY_CURR_BALANCE
              INTO L_CEDIT_BAL
            
              FROM STTMS_CUST_ACCOUNT
             WHERE CUST_AC_NO = L_RTL_TELLER.TXN_ACC
                  
               AND BRANCH_CODE = L_RTL_TELLER.TXN_BRANCH;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Transaction Account details not found with the follwing pararmeters  in sttm_cust_account ' ||
                  L_RTL_TELLER.TXN_ACC || 'Branch Code ' ||
                  L_RTL_TELLER.TXN_BRANCH);
          END;
        
          DBG('Credit account balance is :::: ' || L_CEDIT_BAL ||
              ' when Credit account is ::: ' || L_RTL_TELLER.TXN_ACC);
        ELSE
          DBG('Offset account is GL');
        END IF;
      END IF;
    
      IF L_RTL_TELLER.TRN_REF_NO IS NOT NULL THEN
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.XREF         := L_RTL_TELLER.XREF;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.FCCREF       := L_RTL_TELLER.TRN_REF_NO;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.PRD          := L_RTL_TELLER.PRODUCT_CODE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.BATCHNO      := L_RTL_TELLER.BRANCH_CODE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNACC       := L_RTL_TELLER.TXN_ACC;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNCCY       := L_RTL_TELLER.TXN_CCY;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNAMT       := L_RTL_TELLER.TXN_AMOUNT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNBRN       := L_RTL_TELLER.TXN_BRANCH;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.OFFSETACC    := L_RTL_TELLER.OFS_ACC;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.OFFSETCCY    := L_RTL_TELLER.OFS_CCY;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.OFFSETAMT    := L_RTL_TELLER.OFS_AMOUNT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.XRATE        := L_RTL_TELLER.EXCH_RATE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.LCYAMT       := L_RTL_TELLER.LCY_AMOUNT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNDATE      := L_RTL_TELLER.TRN_DT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.VALDATE      := L_RTL_TELLER.VALUE_DT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.RELCUST      := L_RTL_TELLER.REL_CUSTOMER;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CHRACC       := L_RTL_TELLER.CHARGE_ACCOUNT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CHGGL        := L_RTL_TELLER.CHG_GL;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CHGCCY       := L_RTL_TELLER.CHG_CCY;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CHGAMT       := L_RTL_TELLER.CHG_AMT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TCYTOTCHGAMT := L_RTL_TELLER.CHG_IN_ACY;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.NETTINGIND   := L_RTL_TELLER.NETTING_IND;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNCODE      := L_RTL_TELLER.TXN_CODE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.REMACCOUNT   := L_RTL_TELLER.REM_ACC;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.REMBANK      := L_RTL_TELLER.REM_BANK;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.REMBRANCH    := L_RTL_TELLER.REM_BRANCH;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.ROUTINGNO    := L_RTL_TELLER.ROUTING_NO;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.ENDPOINT     := L_RTL_TELLER.END_POINT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.SERIALNO     := L_RTL_TELLER.SERIAL_NO;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.MISHEAD      := L_RTL_TELLER.MIS_HEAD;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.ROUTECODE    := L_RTL_TELLER.ROUTE_CODE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CONTSTAT     := L_RTL_TELLER.RECORD_STAT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.AUTHSTAT     := L_RTL_TELLER.AUTH_STAT;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.MAKERID      := L_RTL_TELLER.MAKER_ID;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.MAKERDT      := L_RTL_TELLER.MAKER_DT_STAMP;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CHECKERID    := L_RTL_TELLER.CHECKER_ID;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CHECKERDT    := L_RTL_TELLER.CHECKER_DT_STAMP;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.MODNO        := L_RTL_TELLER.MOD_NO;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNTANKED    := L_RTL_TELLER.TXN_TANKED;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.OFFSETBRN    := L_RTL_TELLER.OFS_BRANCH;
      
        DBG('The txncode for txn leg is:' || L_RTL_TELLER.TXN_TRN_CODE ||
            'The txncode for ofs leg is:' || L_RTL_TELLER.OFS_TRN_CODE);
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNTRN    := L_RTL_TELLER.TXN_TRN_CODE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.OFFSETTRN := L_RTL_TELLER.OFS_TRN_CODE;
      
        DBG('The local currency exchange rate is:' ||
            L_RTL_TELLER.LCY_EXCH_RATE);
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.LCYXRATE := L_RTL_TELLER.LCY_EXCH_RATE;
      
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.SRCCODE := L_RTL_TELLER.SCODE;
        
        --RIA Phase2 Changes for Mobile Banking Changes Starts
        IF L_RTL_TELLER.PRODUCT_CODE = 'RIAP' THEN
          
        
          BEGIN
          
            SELECT A.FIELD_VAL_5 || ' ' || A.FIELD_VAL_6
              INTO L_SENDER_NAME_RIAP
              FROM CSTM_CONTRACT_USERDEF_FIELDS A
             WHERE A.CONTRACT_REF_NO = L_RTL_TELLER.TRN_REF_NO;
          
          EXCEPTION
          
            WHEN OTHERS THEN
              L_SENDER_NAME_RIAP := NULL;
          END;
        
          P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.SDBREFNO := L_SENDER_NAME_RIAP;
        
        ELSE
        --RIA Phase2 Changes for Mobile Banking Changes Ends
          P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.SDBREFNO := L_RTL_TELLER.SDB_REF_NO;
        END IF; --RIA Phase2 Changes for Mobile Banking Changes added End IF
      
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TRNNAR    := L_RTL_TELLER.NARRATIVE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.NARRATIVE := L_RTL_TELLER.NARRATIVE;
      
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.MODULE   := L_MODULE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.BRNDESC  := L_BRANCH_NAME;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.PRODDESC := L_PROD_DESC;
      
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.DBTACCBAL := L_DEBIT_BAL;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CRDACCBAL := L_CEDIT_BAL;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.VIRACCNO  := L_RTL_TELLER.VIR_ACC_NO;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TRNCDDESC := L_TRN_CODE_DESC;
      
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNBRNDESC   := L_TXNBRNDESC;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.OFSBRNDESC   := L_OFSBRNDESC;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.OFSTRNCDDESC := L_OFSTRNCDDESC;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNACDESC    := L_TXNACCDESC;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.OFSACDESC    := L_OFSACDESC;
      
        DBG('DEBIT ACCOUNT DETAILS' || L_RTL_TELLER.TXN_ACC);
        DBG('CREDIT ACCOUNT DETAILS' || L_RTL_TELLER.OFS_ACC);
      
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.TXNDR     := L_RTL_TELLER.DR_INSTRUMENT_CODE;
        P_WRK_DEDQUERY.V_RTVWS_TRANSACTION_DETAILS.CHEQISSDT := L_RTL_TELLER.CHEQUE_ISSUE_DATE;
      
        IF L_RTL_TELLER.CHG_AMT >= 0 THEN
          DBG('Charge No 1');
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).CHGCOMP := L_RTL_TELLER.CHG_DESC;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).WAIVER := L_RTL_TELLER.WAIVER;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).CHGAMT := L_RTL_TELLER.CHG_AMT;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).CHGCCY := L_RTL_TELLER.CHG_CCY;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).TYPE := L_RTL_TELLER.CHG_TYPE;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).LCYCHG := L_RTL_TELLER.CHG_IN_LCY;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).XRATE := L_RTL_TELLER.LCY_CHG_EXCH_RATE;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).CHGGL := L_RTL_TELLER.CHG_GL;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).THEIRACC := L_RTL_TELLER.THEIR_ACC;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).NETTINGIND := L_RTL_TELLER.NETTING_IND;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).TXNCODE := L_RTL_TELLER.TXN_CODE;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).MISHEAD := L_RTL_TELLER.MIS_HEAD_1;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(1).FCCREF := L_RTL_TELLER.TRN_REF_NO;
        END IF;
      
        IF L_RTL_TELLER.CHG_AMT_1 >= 0 THEN
          DBG('Charge No 2');
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).CHGCOMP := L_RTL_TELLER.CHG_DESC1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).WAIVER := L_RTL_TELLER.WAIVER1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).CHGAMT := L_RTL_TELLER.CHG_AMT_1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).CHGCCY := L_RTL_TELLER.CHG_CCY_1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).TYPE := L_RTL_TELLER.CHG_TYPE1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).LCYCHG := L_RTL_TELLER.CHG_IN_LCY_1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).XRATE := L_RTL_TELLER.LCY_CHG_EXCH_RATE1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).CHGGL := L_RTL_TELLER.CHG_GL_1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).THEIRACC := L_RTL_TELLER.THEIR_ACC1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).NETTINGIND := L_RTL_TELLER.NETTING_IND_1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).TXNCODE := L_RTL_TELLER.TXN_CODE_1;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).MISHEAD := L_RTL_TELLER.MIS_HEAD_2;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(2).FCCREF := L_RTL_TELLER.TRN_REF_NO;
        END IF;
      
        IF L_RTL_TELLER.CHG_AMT_2 >= 0 THEN
          DBG('Charge No 3');
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).CHGCOMP := L_RTL_TELLER.CHG_DESC2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).WAIVER := L_RTL_TELLER.WAIVER2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).CHGAMT := L_RTL_TELLER.CHG_AMT_2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).CHGCCY := L_RTL_TELLER.CHG_CCY_2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).TYPE := L_RTL_TELLER.CHG_TYPE2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).LCYCHG := L_RTL_TELLER.CHG_IN_LCY_2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).XRATE := L_RTL_TELLER.LCY_CHG_EXCH_RATE2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).CHGGL := L_RTL_TELLER.CHG_GL_2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).THEIRACC := L_RTL_TELLER.THEIR_ACC2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).NETTINGIND := L_RTL_TELLER.NETTING_IND_2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).TXNCODE := L_RTL_TELLER.TXN_CODE_2;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).MISHEAD := L_RTL_TELLER.MIS_HEAD_3;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(3).FCCREF := L_RTL_TELLER.TRN_REF_NO;
        END IF;
      
        IF L_RTL_TELLER.CHG_AMT_3 >= 0 THEN
          DBG('Charge No 4');
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).CHGCOMP := L_RTL_TELLER.CHG_DESC3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).WAIVER := L_RTL_TELLER.WAIVER3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).CHGAMT := L_RTL_TELLER.CHG_AMT_3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).CHGCCY := L_RTL_TELLER.CHG_CCY_3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).TYPE := L_RTL_TELLER.CHG_TYPE3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).LCYCHG := L_RTL_TELLER.CHG_IN_LCY_3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).XRATE := L_RTL_TELLER.LCY_CHG_EXCH_RATE3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).CHGGL := L_RTL_TELLER.CHG_GL_3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).THEIRACC := L_RTL_TELLER.THEIR_ACC3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).NETTINGIND := L_RTL_TELLER.NETTING_IND_3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).TXNCODE := L_RTL_TELLER.TXN_CODE_3;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).MISHEAD := L_RTL_TELLER.MIS_HEAD_4;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(4).FCCREF := L_RTL_TELLER.TRN_REF_NO;
        END IF;
      
        IF L_RTL_TELLER.CHG_AMT_4 >= 0 THEN
          DBG('Charge No 5');
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).CHGCOMP := L_RTL_TELLER.CHG_DESC4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).WAIVER := L_RTL_TELLER.WAIVER4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).CHGAMT := L_RTL_TELLER.CHG_AMT_4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).CHGCCY := L_RTL_TELLER.CHG_CCY_4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).TYPE := L_RTL_TELLER.CHG_TYPE4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).LCYCHG := L_RTL_TELLER.CHG_IN_LCY_4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).XRATE := L_RTL_TELLER.LCY_CHG_EXCH_RATE4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).CHGGL := L_RTL_TELLER.CHG_GL_4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).THEIRACC := L_RTL_TELLER.THEIR_ACC4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).NETTINGIND := L_RTL_TELLER.NETTING_IND_4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).TXNCODE := L_RTL_TELLER.TXN_CODE_4;
        
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).MISHEAD := L_RTL_TELLER.MIS_HEAD_5;
          P_WRK_DEDQUERY.V_WBVWS_CHARGE_DETAILS(5).FCCREF := L_RTL_TELLER.TRN_REF_NO;
        END IF;
      
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed in Selecting The Master Recotrd..');
        DBG('Record Does not Exist..');
        P_ERR_CODE   := 'ST-VALS-002';
        P_ERR_PARAMS := '';
        RETURN FALSE;
    END;
    DBG('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of rtpks_dedquery_Kernel.Fn_Post_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

END RTPKS_DEDQUERY_KERNEL;
