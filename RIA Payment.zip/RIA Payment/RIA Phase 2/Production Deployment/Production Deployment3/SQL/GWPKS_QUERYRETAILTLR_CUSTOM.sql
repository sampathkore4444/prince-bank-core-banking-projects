CREATE OR REPLACE PACKAGE BODY GWPKS_QUERYRETAILTLR_CUSTOM AS
  /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Change Tag        : PRF_CUSTOM_05_03072018
   **    Changes By        : Aniket
   **    Changes on        : 03-JUL-2018
   **    Description       : Changes related to teller advices specific to Prince Finance

         Modified By           : Kore Sampath Kumar
         Modified On           : 12-July-2019
         Modified Reason       : LOCH transaction and offset Amount to display with negative sign for reversal Changes
         Search String         : LOCH transaction and offset Amount to display with negative sign for reversal Changes

        Modified By         : Kore Sampath Kumar
        Modified Description : Prince Bank AML Changes

        Changed By         : Kore Sampath Kumar
        Change Description : Prince Bank Credit Card Payment by Cash GL Changes

    Modified By         : Kore Sampath Kumar
        Modified Description : Cheque Withdrawal Reverse

    Changed By         : Kore Sampath Kumar
  Change Description : AML Participant Enhancements Changes

  **    Changed By        : Kore Sampath Kumar
       **    Changed on        : 15-July-2020
       **    Description       : NBC RFT Changes
       **    Change Tag        : NBC RFT Changes

   ** Modified By         : Kore Sampath Kumar
   ** Modified On         : 15-Nov-2021
   ** Modified Reason     : AIA Payment
   ** Search String       : AIA Payment



    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'gwpks_queryretailtlr_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('RT', L_MSG);
  END DBG;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  
  --RIA Phase2 Changes Starts
  FUNCTION FN_UPDATE_UDF_VAL(P_CIF        IN VARCHAR2,
                             P_FIELD_NAME IN VARCHAR2,
                             P_VAL        IN VARCHAR2) RETURN BOOLEAN IS
  
    L_SQL       VARCHAR2(200);
    L_NUM       NUMBER;
    L_FIELD_VAL VARCHAR2(2000) := NULL;
  BEGIN
    DBG('Entered IN FN_UPDATE_UDF_VAL');
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_PRODUCT_UDF_FIELDS_MAP
    --CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE PRODUCT_CODE = 'RIAA'
       AND FIELD_NAME = P_FIELD_NAME;
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'UPDATE CSTM_PRODUCT_UDF_FIELDS_MAP SET field_val_' || L_NUM ||
             ' = ' || CHR(39) || P_VAL || CHR(39) ||
             '  WHERE PRODUCT_CODE =' || CHR(39) || 'RIAA' || CHR(39) ||
             ' and rec_key=' || CHR(39) || P_CIF || '~''';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL;
  
    DBG('done');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_UPDATE_UDF_VAL' || SQLERRM);
      RETURN FALSE;
  END FN_UPDATE_UDF_VAL;
  --RIA Payment Confirmation for Digital Ends

  FUNCTION FN_GET_AMLCHECK_PERDAY_RIA_OUT( --P_CUST_NO      IN VARCHAR2,
                                          --P_SENDER_NAME  IN VARCHAR2,
                                          P_BEN_NAME IN VARCHAR2,
                                          --P_SEN_HIGH_CNT IN VARCHAR2,
                                          P_BEN_HIGH_CNT IN VARCHAR2)
    RETURN BOOLEAN AS
    L_NAMEHIT_COUNT    NUMBER := 0;
    L_COUNTRYHIT_COUNT NUMBER := 0;
    L_HIT_COUNT        NUMBER := 0;
  BEGIN
    DBG('START OF FN_GET_AMLCHECK_PERDAY_RIA_OUT');
  
    /* --Check for Name hit on the same day
    BEGIN
      SELECT COUNT(1)
        INTO L_NAMEHIT_COUNT
        FROM STTB_CORAL_RIA_WS_LOG
       WHERE STATUS = 'HIT'
         AND BEN_NAME = P_BEN_NAME
            
         AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
             TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
    EXCEPTION
      WHEN OTHERS THEN
        L_NAMEHIT_COUNT := 0;
    END;
    
    --Check for Name and country hit on the same day
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNTRYHIT_COUNT
        FROM STTB_CORAL_RIA_WS_LOG
       WHERE STATUS = 'HIT'
         AND BEN_NAME = P_BEN_NAME
         AND BEN_HIGH_CNT = P_BEN_HIGH_CNT
         AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
             TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNTRYHIT_COUNT := 0;
    END;*/
  
    DBG('BRANCH DATE=' || GLOBAL.application_date);
    DBG('BRANCH DATE=' || TO_DATE(GLOBAL.application_date, 'DD-MM-YY'));
    DBG('BRANCH CODE=' || GLOBAL.current_branch);
  
    BEGIN
      SELECT COUNT(1)
        INTO L_HIT_COUNT
        FROM STTB_CORAL_RIA_WS_LOG
       WHERE STATUS = 'HIT'
         AND UPPER(TRIM(REGEXP_REPLACE(BEN_NAME, '\s{2,}', ' '))) =
             UPPER(TRIM(REGEXP_REPLACE(P_BEN_NAME, '\s{2,}', ' ')))
            --AND UPPER(BEN_NAME) = UPPER(P_BEN_NAME)
         AND UPPER(BEN_HIGH_CNT) = UPPER(P_BEN_HIGH_CNT)
         AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
            -- AND '20-AUG-21' =
             TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
    EXCEPTION
      WHEN OTHERS THEN
        L_HIT_COUNT := 0;
    END;
  
    IF L_HIT_COUNT <> 0 /*L_NAMEHIT_COUNT <> 0 OR L_COUNTRYHIT_COUNT <> 0*/
     THEN
      --PR_LOG_ERROR('IFDRIAPA', 'FLEXCUBE', 'IF-MTA-025', null);
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AMLCHECK_PERDAY_RIA_OUT');
      DBG('ERROR CODE IN FN_GET_AMLCHECK_PERDAY_RIA_OUT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AMLCHECK_PERDAY_RIA_OUT=' || SQLERRM);
      RETURN FALSE;
  END FN_GET_AMLCHECK_PERDAY_RIA_OUT;

  FUNCTION FN_GET_AMLCHECK_PERDAY_RIA_IN( --P_CUST_NO      IN VARCHAR2,
                                         P_SENDER_NAME  IN VARCHAR2,
                                         P_BEN_NAME     IN VARCHAR2,
                                         P_SEN_HIGH_CNT IN VARCHAR2,
                                         P_BEN_HIGH_CNT IN VARCHAR2,
                                         P_PRODUCT_CODE IN VARCHAR2)
    RETURN BOOLEAN AS
    L_NAMEHIT_COUNT_SENDER    NUMBER := 0;
    L_COUNTRYHIT_COUNT_SENDER NUMBER := 0;
    L_NAMEHIT_COUNT_BEN       NUMBER := 0;
    L_COUNTRYHIT_COUNT_BEN    NUMBER := 0;
    L_HIT_COUNT               NUMBER := 0;
  BEGIN
    DBG('START OF FN_GET_AMLCHECK_PERDAY_RIA_IN=' || P_PRODUCT_CODE);
  
    IF P_PRODUCT_CODE IN ('RIAI', 'RIAP') THEN
    
      DBG('P_SENDER_NAME=' || P_SENDER_NAME);
      DBG('P_SEN_HIGH_CNT=' || P_SEN_HIGH_CNT);
    
      --Check for Name hit on the same day for sender
      /*   BEGIN
        SELECT COUNT(1)
          INTO L_NAMEHIT_COUNT_SENDER
          FROM STTB_CORAL_RIA_WS_LOG
         WHERE STATUS = 'HIT'
           AND UPPER(TRIM(REGEXP_REPLACE(SENDER_NAME, '\s{2,}', ' '))) =
               UPPER(TRIM(REGEXP_REPLACE(P_SENDER_NAME, '\s{2,}', ' ')))
              --AND UPPER(SENDER_NAME) = UPPER(P_SENDER_NAME)
              
           AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
               TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
      EXCEPTION
        WHEN OTHERS THEN
          L_NAMEHIT_COUNT_SENDER := 0;
      END;*/
    
      --Check for Name and country hit on the same day for sender
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNTRYHIT_COUNT_SENDER
          FROM STTB_CORAL_RIA_WS_LOG
         WHERE STATUS = 'HIT'
           AND UPPER(TRIM(REGEXP_REPLACE(SENDER_NAME, '\s{2,}', ' '))) =
               UPPER(TRIM(REGEXP_REPLACE(P_SENDER_NAME, '\s{2,}', ' ')))
              --AND UPPER(SENDER_NAME) = UPPER(P_SENDER_NAME)
           AND UPPER(SENDER_HIGH_CNT) = UPPER(P_SEN_HIGH_CNT)
           AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
               TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNTRYHIT_COUNT_SENDER := 0;
      END;
    
    END IF;
  
    IF P_PRODUCT_CODE IN ('RIAB') THEN
      --Check for Name hit on the same day for sender
      BEGIN
        SELECT COUNT(1)
          INTO L_NAMEHIT_COUNT_SENDER
          FROM STTB_CORAL_RIA_WS_LOG
         WHERE STATUS = 'HIT'
           AND UPPER(TRIM(REGEXP_REPLACE(SENDER_NAME, '\s{2,}', ' '))) =
               UPPER(TRIM(REGEXP_REPLACE(P_SENDER_NAME, '\s{2,}', ' ')))
              --AND UPPER(SENDER_NAME) = UPPER(P_SENDER_NAME)
              
           AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
               TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
      EXCEPTION
        WHEN OTHERS THEN
          L_NAMEHIT_COUNT_SENDER := 0;
      END;
    
      --Check for Name and country hit on the same day for sender
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNTRYHIT_COUNT_SENDER
          FROM STTB_CORAL_RIA_WS_LOG
         WHERE STATUS = 'HIT'
           AND UPPER(TRIM(REGEXP_REPLACE(SENDER_NAME, '\s{2,}', ' '))) =
               UPPER(TRIM(REGEXP_REPLACE(P_SENDER_NAME, '\s{2,}', ' ')))
              --AND UPPER(SENDER_NAME) = UPPER(P_SENDER_NAME)
           AND UPPER(SENDER_HIGH_CNT) = UPPER(P_SEN_HIGH_CNT)
           AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
               TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNTRYHIT_COUNT_SENDER := 0;
      END;
    
      --Check for Name hit on the same day for beneficiary
      BEGIN
        SELECT COUNT(1)
          INTO L_NAMEHIT_COUNT_BEN
          FROM STTB_CORAL_RIA_WS_LOG
         WHERE STATUS = 'HIT'
           AND UPPER(TRIM(REGEXP_REPLACE(BEN_NAME, '\s{2,}', ' '))) =
               UPPER(TRIM(REGEXP_REPLACE(P_BEN_NAME, '\s{2,}', ' ')))
              -- AND UPPER(BEN_NAME) = UPPER(P_BEN_NAME)
              
           AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
               TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
      EXCEPTION
        WHEN OTHERS THEN
          L_NAMEHIT_COUNT_BEN := 0;
      END;
    
      --Check for Name and country hit on the same day for beneficiary
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNTRYHIT_COUNT_BEN
          FROM STTB_CORAL_RIA_WS_LOG
         WHERE STATUS = 'HIT'
           AND UPPER(TRIM(REGEXP_REPLACE(BEN_NAME, '\s{2,}', ' '))) =
               UPPER(TRIM(REGEXP_REPLACE(P_BEN_NAME, '\s{2,}', ' ')))
              --  UPPER(BEN_NAME) = UPPER(P_BEN_NAME)
           AND UPPER(BEN_HIGH_CNT) = UPPER(P_BEN_HIGH_CNT)
           AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
               TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNTRYHIT_COUNT_BEN := 0;
      END;
    
    END IF;
  
    /* BEGIN
      SELECT COUNT(1)
        INTO L_HIT_COUNT
        FROM STTB_CORAL_RIA_WS_LOG
       WHERE STATUS = 'HIT'
         AND BEN_NAME = P_BEN_NAME
         AND BEN_HIGH_CNT = P_BEN_HIGH_CNT
         AND TO_DATE(INVOKE_DATE, 'DD-MM-YY') =
             TO_DATE(GLOBAL.application_date, 'DD-MM-YY');
    EXCEPTION
      WHEN OTHERS THEN
        L_HIT_COUNT := 0;
    END;*/
  
    IF P_PRODUCT_CODE IN ('RIAI', 'RIAP') THEN
      IF /*L_NAMEHIT_COUNT_SENDER <> 0 OR*/
       L_COUNTRYHIT_COUNT_SENDER <> 0 THEN
        --PR_LOG_ERROR('IFDRIAPA', 'FLEXCUBE', 'IF-MTA-025', null);
        RETURN FALSE;
      END IF;
    
    ELSE
      IF L_NAMEHIT_COUNT_SENDER <> 0 OR L_COUNTRYHIT_COUNT_SENDER <> 0 OR
         L_NAMEHIT_COUNT_BEN <> 0 OR L_COUNTRYHIT_COUNT_BEN <> 0 THEN
        --PR_LOG_ERROR('IFDRIAPA', 'FLEXCUBE', 'IF-MTA-025', null);
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AMLCHECK_PERDAY_RIA_IN');
      DBG('ERROR CODE IN FN_GET_AMLCHECK_PERDAY_RIA_IN=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AMLCHECK_PERDAY_RIA_IN=' || SQLERRM);
      RETURN FALSE;
  END FN_GET_AMLCHECK_PERDAY_RIA_IN;
  
  --RIA Phase2 Changes Ends

  --RIA incoming Payment Starts
  FUNCTION FN_GET_RISK_LEVEL_CNT(P_COUNTRY_CODE IN VARCHAR2) RETURN NUMBER IS
    L_VALUE NUMBER;
  BEGIN
    SELECT DECODE(CODE, 'P', 5, 'V', 4, 'H', 3, 'M', '2', 'L', 1, 5)
      INTO L_VALUE
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = 'RISK_LEVEL_CNT'
       AND VALUE = P_COUNTRY_CODE;

    RETURN L_VALUE;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_VALUE;
  END FN_GET_RISK_LEVEL_CNT;

  --RIA incoming Payment Ends

  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN
    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('IF',
                     '[ERROR] ' || 'gwpks_queryretailtlr_custom :' || P_DBG);
    ELSE
      DEBUG.PR_DEBUG('IF',
                     '[DEBUG] ' || 'gwpks_queryretailtlr_custom :' || P_DBG);
    END IF;
  END DBG;

  --NBC RFT Changes Starts
  PROCEDURE PR_INSERT_RFT_MOBILE_BANING(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS

    L_CSTMS_CON_USERDEF_FIELDS CSTMS_CONTRACT_USERDEF_FIELDS%ROWTYPE;
    --PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    DBG('START OF PR_INSERT_RFT_MOBILE_BANING');

    DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
    DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
        P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);

    DBG('Depks_rtl_teller.pkg_rtl_teller_rec.xref=' ||
        Depks_rtl_teller.pkg_rtl_teller_rec.xref);

    BEGIN
      select *
        INTO L_CSTMS_CON_USERDEF_FIELDS
        from CSTMS_CONTRACT_USERDEF_FIELDS
       where contract_ref_no = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        L_CSTMS_CON_USERDEF_FIELDS := NULL;
    END;

    DBG('L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_1=' ||
        L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_1);
    DBG('L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_2=' ||
        L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_2);
    DBG('L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_3=' ||
        L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_3);
    DBG('L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_4=' ||
        L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_4);
    DBG('L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_5=' ||
        L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_5);
    DBG('L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_6=' ||
        L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_6);

    /*INSERT INTO IFTB_RFT_PASSCODE_MB
    VALUES
      (Depks_rtl_teller.pkg_rtl_teller_rec.xref,
       P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_1,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_2,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_3,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_4,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_5,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_6,
       P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_DT);*/

    INSERT INTO IFTB_RFT_MASTER_MOB
      (BRANCH_CODE,
       MSG_FLOW,
       TRN_REF_NO,
       PRODUCT_CODE,
       TRANSFER_DATE,
       TXN_CCY,
       TXN_AMT,
       REM_ACC,
       REM_NAME,
       REM_PHONE,
       BEN_NAME,
       BEN_PHONE,
       TXN_UNQ_NO,
       PASS_CODE,
       MAKER_ID,
       MAKER_DT_STAMP,
       CHECKER_ID,
       CHECKER_DT_STAMP,
       AUTH_STAT,
       RECORD_STAT,
       ONCE_AUTH,
       MOD_NO)
    VALUES
      (P_TY_RTUPLD.ty_upld_rtl_teller.branch_code,
       'O',
       P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO,
       P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE,
       P_TY_RTUPLD.ty_upld_rtl_teller.TRN_DT,
       P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
       P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT,
       P_TY_RTUPLD.ty_upld_rtl_teller.OFS_ACC,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_1,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_2,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_3,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_4,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_5,
       L_CSTMS_CON_USERDEF_FIELDS.FIELD_VAL_6,
       GLOBAL.USER_ID,
       FN_SYSDATE,
       GLOBAL.USER_ID,
       FN_SYSDATE,
       'A',
       'O',
       'Y',
       1);

    --COMMIT;

    DBG('END OF PR_INSERT_RFT_MOBILE_BANING');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE IN PR_INSERT_RFT_MOBILE_BANING=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_RFT_MOBILE_BANING=' || SQLERRM);

  END PR_INSERT_RFT_MOBILE_BANING;
  --NBC RFT Changes Ends

  --AML Participant Enhancements Changes Starts
  PROCEDURE PR_INSERT_PARTICIPANT_INFO(P_FUNC_ID   IN VARCHAR2,
                                       P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS

    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    DBG('P_FUNC_ID=' || P_FUNC_ID);
    DBG('INSIDE PR_INSERT_PARTICIPANT_INFO STARTS');

    IF P_FUNC_ID = '1001' THEN

      INSERT INTO IFTB_AML_PARTICIPANT_INFO_1001
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34);

    END IF;

    IF P_FUNC_ID = '1401' THEN

      INSERT INTO IFTB_AML_PARTICIPANT_INFO_1401
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35);

    END IF;

    IF P_FUNC_ID = '1013' THEN

      INSERT INTO IFTB_AML_PARTICIPANT_INFO_1013
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD36,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD37);

    END IF;

    IF P_FUNC_ID = '8203' THEN

      INSERT INTO IFTB_AML_PARTICIPANT_INFO_8203
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35,
         P_TY_RTUPLD.ty_upld_rtl_teller.REL_CUSTOMER,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD1,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD6
         );

    END IF;

    IF P_FUNC_ID = '8004' THEN

      INSERT INTO IFTB_AML_PARTICIPANT_INFO_8004
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35,
         P_TY_RTUPLD.ty_upld_rtl_teller.REL_CUSTOMER,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD1,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD6);

    END IF;

    COMMIT;
    DBG('INSIDE PR_INSERT_PARTICIPANT_INFO ENDS');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR IN PR_INSERT_PARTICIPANT_INFO');
      DBG('ERROR CODE IN PR_INSERT_PARTICIPANT_INFO=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_PARTICIPANT_INFO=' || SQLERRM);
  END PR_INSERT_PARTICIPANT_INFO;
  --AML Participant Enhancements Changes Ends

  --Cheque Withdrawal Reverse Starts
  PROCEDURE PR_INSERT_CHEQUE_WITHDRAWAL(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS

    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    DBG('P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT='||P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT);



    INSERT INTO IFTB_CHEQUE_WITHDRAWAL_CUSTOM
    VALUES
      (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
       P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD36,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD37,
     P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40 --AML Participant Enhancements Changes
     );

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR IN PR_INSERT_CHEQUE_WITHDRAWAL');
      DBG('ERROR CODE IN PR_INSERT_CHEQUE_WITHDRAWAL=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_CHEQUE_WITHDRAWAL=' || SQLERRM);
  END PR_INSERT_CHEQUE_WITHDRAWAL;
  --Cheque Withdrawal Reverse Ends

  --Prince Bank Credit Card Payment by Cash GL Changes Starts
  PROCEDURE PR_INSERT_CASH_BY_GL(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS

    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    DBG('P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT='||P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT);

    INSERT INTO IFTB_CREDIT_CARD_PYMNT_BY_CASH
    VALUES
      (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
       P_TY_RTUPLD.ty_upld_rtl_teller.TXN_ACC,
       P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
       P_TY_RTUPLD.ty_upld_rtl_teller.OFS_CCY,
       P_TY_RTUPLD.ty_upld_rtl_teller.OFS_AMOUNT,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD9,
       P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT,
       P_TY_RTUPLD.ty_upld_rtl_teller.NARRATIVE,
       'O',
       'A',
       1,
       GWPKS_UTIL.G_MAKERID,
       GLOBAL.application_date,
       P_TY_RTUPLD.ty_upld_rtl_teller.CHECKER_ID,
       GLOBAL.APPLICATION_DATE,
       'Y',
       P_TY_RTUPLD.ty_upld_rtl_teller.EXCH_RATE,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD4,
       GLOBAL.application_date,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD7,
       SUBSTR(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3,1,4)||'XXXXXXXX'||SUBSTR(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3,13),
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD5);

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR IN PR_INSERT_CASH_BY_GL');
      DBG('ERROR CODE IN PR_INSERT_CASH_BY_GL=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_CASH_BY_GL=' || SQLERRM);
  END PR_INSERT_CASH_BY_GL;

  --NBC RFT changes Starts
  PROCEDURE PR_INSERT_RFT_PASSCODE_INFO(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS

    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;

  BEGIN

    DBG('INSIDE PR_INSERT_RFT_PASSCODE_INFO STARTS');

    INSERT INTO IFTB_RFT_PASSCODE_INFO
    VALUES
      (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD41,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43,
       P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD25,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46);

    COMMIT;

    DBG('INSIDE PR_INSERT_RFT_PASSCODE_INFO ENDS');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR IN PR_INSERT_RFT_PASSCODE_INFO');
      DBG('ERROR CODE IN PR_INSERT_RFT_PASSCODE_INFO=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_RFT_PASSCODE_INFO=' || SQLERRM);
  END PR_INSERT_RFT_PASSCODE_INFO;
  --NBC RFT changes Ends

  FUNCTION FN_GET_TERMINAL_MERCHANT_ID(P_BRANCH IN STTM_BRANCH.BRANCH_CODE%TYPE)
    RETURN LMTM_TYPE_VALUES%ROWTYPE IS
    L_LMTM_TYPE_VALUES LMTM_TYPE_VALUES%ROWTYPE;
  BEGIN

    SELECT *
      INTO L_LMTM_TYPE_VALUES
      FROM LMTM_TYPE_VALUES
     WHERE TYPE = 'CC_PYMNT_SVXP'
       AND CODE LIKE P_BRANCH || '%';

    RETURN L_LMTM_TYPE_VALUES;

  EXCEPTION
    WHEN OTHERS THEN

      RETURN L_LMTM_TYPE_VALUES;

  END FN_GET_TERMINAL_MERCHANT_ID;

  FUNCTION FN_GET_SVXP_TEMPLATE RETURN CLOB IS

    L_CLOB CLOB;

  BEGIN
    DBG('START OF FN_GET_SVXP_TEMPLATE');

    L_CLOB := '<clearing xmlns="http://bpc.ru/sv/SVXP/clearing">
  <file_type>FLTP1700</file_type>
  <operation>
    <oper_type>OPTP0028</oper_type>
    <msg_type>MSGTPRES</msg_type>
    <sttl_type>STTT0000</sttl_type>
    <oper_date>$L_DATE</oper_date>
    <oper_amount>
      <amount_value>$L_AMOUNT</amount_value>
      <currency>$L_ISO_CCY_CODE</currency>
    </oper_amount>
    <status>OPST0100</status>
    <is_reversal>0</is_reversal>
    <originator_refnum>$L_REFERENCE_NO</originator_refnum>
    <terminal_number>$TERMINAL_NUMBER</terminal_number>
    <merchant_number>$MERCHANT_NUMBER</merchant_number>
    <issuer>
      <client_id_type>CITPACCT</client_id_type>
      <client_id_value>$L_CREDIT_CARD_AC_NO</client_id_value>
      <inst_id>1001</inst_id>
      <network_id>1001</network_id>
    </issuer>
    <acquirer>
            <inst_id>1001</inst_id>
    </acquirer>
    <note>
      <note_type>NTTPUSER </note_type>
      <note_content language="LANGENG">
        <note_header>Payment from CBS</note_header>
        <note_text>Customer did payment from cbs</note_text>
      </note_content>
    </note>
  </operation>
</clearing>';

    RETURN L_CLOB;

    DBG('END OF FN_GET_SVXP_TEMPLATE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_SVXP_TEMPLATE');
      DBG('ERROR CODE IN FN_GET_SVXP_TEMPLATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_SVXP_TEMPLATE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN FN_GET_SVXP_TEMPLATE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

  END FN_GET_SVXP_TEMPLATE;

  PROCEDURE PR_WRITE_CLOB_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                  P_IN_FILE_NAME IN VARCHAR2,
                                  P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);

    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);

      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);

      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;

    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_CLOB_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_CLOB_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_CLOB_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_CLOB_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_CLOB_TO_FILE;

  PROCEDURE PR_GEN_CCPAYMNT_SVXP_FILE(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
    L_RESP_CODE     VARCHAR2(10);
    L_TERMINAL_MERCHANT_NUM LMTM_TYPE_VALUES%ROWTYPE;
  BEGIN

    --GLOBAL.pr_init('001', 'SYSTEM');
    DBG('START OF PR_GEN_CCPAYMNT_SVXP_FILE');

    L_RESP_TEMPLATE := FN_GET_SVXP_TEMPLATE;

    L_FILE_NAME := 'SVXP_OUT_PMNT_' ||
                   P_TY_RTUPLD.ty_upld_rtl_teller.trn_ref_no || '_' ||
                   GLOBAL.APPLICATION_DATE;

    L_TERMINAL_MERCHANT_NUM := FN_GET_TERMINAL_MERCHANT_ID(GLOBAL.current_branch);

    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,'$TERMINAL_NUMBER',L_TERMINAL_MERCHANT_NUM.CODE);

    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,'$MERCHANT_NUMBER',L_TERMINAL_MERCHANT_NUM.VALUE);

    /*TO_CHAR(P_TY_RETAIL_TELLER.TIME_RECEIVED,
    CSPKS_REQ_GLOBAL.G_DATE_TIME_FORMAT)*/
    DBG('P_TY_RTUPLD.ty_upld_rtl_teller.time_received=' ||
        P_TY_RTUPLD.ty_upld_rtl_teller.time_received);

    P_TY_RTUPLD.ty_upld_rtl_teller.TIME_RECEIVED := CSFNS_TIMESTAMP;

    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_DATE',
                               SUBSTR(TO_CHAR(P_TY_RTUPLD.ty_upld_rtl_teller.TIME_RECEIVED,
                                              Cspks_Req_Global.G_DATE_TIME_FORMAT),
                                      1,
                                      10) || 'T' ||
                               SUBSTR(TO_CHAR(P_TY_RTUPLD.ty_upld_rtl_teller.TIME_RECEIVED,
                                              Cspks_Req_Global.G_DATE_TIME_FORMAT),
                                      12));
    --TO_DATE(GLOBAL.application_date,Cspks_Req_Global.g_Date_Format));
    --SUBSTR(p_ifdcccas.v_credit_card_pymnt_by_cash.checker_dt_stamp,1,10)||'T'||SUBSTR(p_ifdcccas.v_credit_card_pymnt_by_cash.checker_dt_stamp,12));
    --p_ifdcccas.v_credit_card_pymnt_by_cash.payment_date);

    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_AMOUNT',
                               P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT * 100);

    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_ISO_CCY_CODE', '840');

    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_REFERENCE_NO',
                               P_TY_RTUPLD.ty_upld_rtl_teller.trn_ref_no);

    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_CREDIT_CARD_AC_NO',
                               P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4);

    L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;

    DBG('L_RESP_CLOB=' || L_RESP_CLOB);

    --L_RESP_TEMPLATE := NULL;

    --END LOOP;

    DBG('DONE WITH GENERATING CLOB RESPONSE');

    --Write to output file
    DBG('START OF WRITING CLOB TO AN XML FILE');
    PR_WRITE_CLOB_TO_FILE('CREDIT_CARD_PAYMENT_CASH',
                          REPLACE(L_FILE_NAME, 'REQ', 'RES') || '.XML',
                          L_RESP_CLOB);

    --Write to Archive Path
    DBG('START OF WRITING CLOB TO AN XML FILE FOR ARCHIVE PATH');
    PR_WRITE_CLOB_TO_FILE('CREDIT_CARD_PAYMENT_CASH_AR',
                          REPLACE(L_FILE_NAME, 'REQ', 'RES') || '.XML',
                          L_RESP_CLOB);

    DBG('END OF WRITING CLOB TO AN XML FILE');

    DBG('END OF PR_GEN_CCPAYMNT_SVXP_FILE');

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GEN_CCPAYMNT_SVXP_FILE');
      DBG('ERROR CODE IN PR_GEN_CCPAYMNT_SVXP_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GEN_CCPAYMNT_SVXP_FILE=' || SQLERRM);
  END PR_GEN_CCPAYMNT_SVXP_FILE;
  --Prince Bank Credit Card Payment by Cash GL Changes ends

  FUNCTION FN_BUILD_RTDETAILS(P_SOURCE         IN VARCHAR2,
                              P_PARENT_RES     IN VARCHAR2,
                              P_REFERENCE_NO   IN VARCHAR2,
                              P_TY_RTUPLD      IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                              P_PARENT         IN OUT VARCHAR2,
                              P_KEY            IN OUT VARCHAR2,
                              P_DATA           IN OUT VARCHAR2,
                              P_FORMAT         IN OUT VARCHAR2,
                              P_NODE           IN OUT VARCHAR2,
                              P_FN_CALL_ID     IN NUMBER,
                              P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS




    --LOCH transaction and offset Amount to display with negative sign for reversal Changes starts
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    --LOCH transaction and offset Amount to display with negative sign for reversal Changes ends
    --Prince Bank AML Changes Starts
    L_WALKIN_CUSTOMER VARCHAR2(100);
    --Prince Bank AML Changes Ends
  BEGIN
    IF P_FN_CALL_ID = 1 THEN

      DBG('IF', 'Inside fn_build_rtdetails ...');

      DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);

      DBG('GWPKS_UTIL.PKG_FUNC=' || GWPKS_UTIL.PKG_FUNC);

     --Prince Bank Credit Card Payment by Cash GL Changes starts
      IF GWPKS_UTIL.PKG_FUNC IN ('CCCG') THEN

        P_KEY := 'CHAR_FIELD3' || '~' || 'CHAR_FIELD4' || '~' ||
                 'CHAR_FIELD5' || '~' || 'CHAR_FIELD6' || '~' ||
                 'CHAR_FIELD7' || '~' || 'CHAR_FIELD8' || '~' ||
                 'CHAR_FIELD9' || '~' || P_KEY;

        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field7 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field8 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field9 || '~' ||
                  P_DATA;

      END IF;
      --Prince Bank Credit Card Payment by Cash GL Changes ends

      --LOCH transaction and offset Amount to display with negative sign for reversal Changes starts
      IF GWPKS_UTIL.PKG_FUNC IN ('LOCH') THEN
        IF GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN

          dbg('DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.xref=' ||
              DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.xref);
          dbg('DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.trn_ref_no=' ||
              DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.trn_ref_no);
          dbg('P_TY_RTUPLD.ty_upld_rtl_teller.xref=' ||
              P_TY_RTUPLD.ty_upld_rtl_teller.xref);
          DBG('P_REFERENCE_NO=' || P_REFERENCE_NO);

          --Get details
          BEGIN
            SELECT *
              INTO L_DETB_RTL_TELLER
              FROM DETB_RTL_TELLER
             WHERE TRN_REF_NO = P_REFERENCE_NO;
          EXCEPTION
            WHEN OTHERS THEN
              L_DETB_RTL_TELLER := NULL;
          END;

          P_KEY  := 'PRINTXNAMT' || '~' || 'PRINOFFSAMT' || '~' || P_KEY;
          P_DATA := '-' ||
                    TRIM(CSFNS_FORMAT_AMT(L_DETB_RTL_TELLER.TXN_CCY,
                                          L_DETB_RTL_TELLER.TXN_AMOUNT)) || '~' || '-' ||
                    TRIM(CSFNS_FORMAT_AMT(L_DETB_RTL_TELLER.OFS_CCY,
                                          L_DETB_RTL_TELLER.OFS_AMOUNT)) || '~' ||
                    P_DATA;

        ELSE

          P_KEY  := 'PRINTXNAMT' || '~' || 'PRINOFFSAMT' || '~' || P_KEY;
          P_DATA := TRIM(CSFNS_FORMAT_AMT(DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_CCY,
                                          DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT)) || '~' ||
                    TRIM(CSFNS_FORMAT_AMT(DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.OFS_CCY,
                                          DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.OFS_AMOUNT)) || '~' ||
                    P_DATA;

        END IF;

        DBG('MODIFIED P_KEY=' || P_KEY);
        DBG('MODIFIED P_DATA=' || P_DATA);

      END IF;
      --LOCH transaction and offset Amount to display with negative sign for reversal Changes ends

      --Prince Bank AML Changes Starts
      IF GWPKS_UTIL.PKG_FUNC IN ('1001', '1401', '1013') THEN

        IF GWPKS_UTIL.PKG_FUNC IN ('1013') THEN
          P_KEY := 'CHAR_FIELD40' || '~' || 'CHAR_FIELD31' || '~' ||
                   'CHAR_FIELD32' || '~' || 'CHAR_FIELD33' || '~' || --AML Participant Enhancements Changes
                   'CHAR_FIELD34' || '~' || 'CHAR_FIELD36' || '~' ||
                   'CHAR_FIELD37' || '~' || P_KEY;

          P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field40 || '~' || --AML Participant Enhancements Changes
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field33 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field36 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field37 || '~' ||
                    P_DATA;
        ELSIF GWPKS_UTIL.PKG_FUNC IN ('1001') THEN
          P_KEY := 'CHAR_FIELD40' || '~' || 'CHAR_FIELD31' || '~' || --AML Participant Enhancements Changes
                   'CHAR_FIELD32' || '~' || 'CHAR_FIELD33' || '~' ||
                   'CHAR_FIELD34' || '~' || P_KEY;

          P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field40 || '~' || --AML Participant Enhancements Changes
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field33 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                    P_DATA;
        ELSE
          P_KEY := 'CHAR_FIELD40' || '~' || 'CHAR_FIELD31' || '~' || --AML Participant Enhancements Changes
                   'CHAR_FIELD32' || '~' || 'CHAR_FIELD33' || '~' ||
                   'CHAR_FIELD34' || '~' || 'CHAR_FIELD35' || '~' || P_KEY;

          P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field40 || '~' || --AML Participant Enhancements Changes
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field33 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35 || '~' ||
                    P_DATA;
        END IF;
      END IF;

      IF GWPKS_UTIL.PKG_FUNC IN ('8203', '8004') THEN

        P_KEY := 'RELCUST' || '~' || 'CHAR_FIELD34' || '~' ||
                 'CHAR_FIELD35' || '~' || P_KEY;

        SELECT DECODE(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER,
                      global_frc.g_tbl_sttm_branch_rec.walkin_customer,
                      NULL,
                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER)
          INTO L_WALKIN_CUSTOMER
          FROM DUAL;

      DBG('L_WALKIN_CUSTOMER=' || L_WALKIN_CUSTOMER);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER);
        DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34=' ||
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34);
        DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35=' ||
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35);

        P_DATA := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER || '~' || --AML Participant Enhancements Changes
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35 || '~' ||
                  P_DATA;

      END IF;

      --Prince Bank AML Changes Ends

    --NBC RFT changes Starts
      IF GWPKS_UTIL.PKG_FUNC IN ('RFTM') THEN

        P_KEY := 'CHAR_FIELD41' || '~' || 'CHAR_FIELD42' || '~' ||
                 'CHAR_FIELD43' || '~' || 'NUM_FIELD25' || '~' ||
                 'CHAR_FIELD44' || '~' || 'CHAR_FIELD47' || '~' ||
                 'CHAR_FIELD45' || '~' || 'CHAR_FIELD46' || '~' || P_KEY;

        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field41 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field42 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field43 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.num_field25 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field44 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field45 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field46 || '~' ||
                  P_DATA;

      END IF;

      --NBC RFT Changes Ends

    --AIA Payment Starts
      IF GWPKS_UTIL.PKG_FUNC IN ('AIAC') THEN

        P_KEY := 'CHAR_FIELD3' || '~' || 'CHAR_FIELD4' || '~' ||
                 'CHAR_FIELD5' || '~' || 'CHAR_FIELD6' || '~' ||
                 'CHAR_FIELD7' || '~' || 'CHAR_FIELD8' || '~' ||
                 'CHAR_FIELD9' || '~' || 'CHAR_FIELD10' || '~' ||
                 'CHAR_FIELD11' || '~' || P_KEY;

        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD4 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD5 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD6 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD7 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD8 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD9 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD10 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD11 || '~' ||
                  P_DATA;

      END IF;
      --AIA Payment Ends
	  
	  --RIA Phase2 Changes Starts
	  IF GWPKS_UTIL.PKG_FUNC IN ('RIAC') THEN
      
        /*P_KEY := 'RIA_PIN' || '~' || 'RIA_AMOUNT' || '~' || 'TXN_UNIQUE_NO' || '~' ||
                 'RIA_REFERENCE_NO' || '~' || 'ORDER_NO' || '~' ||
                 'CURRENCY' || '~' || 'ORDER_DATE' || '~' || 'TXN_REMARKS' || '~' ||
                 'REFERENCE_NO' || '~' || 'COMM_CURRENCY' || '~' ||
                 'COMM_AMOUNT' || '~' || 'UNIQUE_ID_NAME' || '~' ||
                 'UNIQUE_ID_VALUE' || '~' || 'UID_EXPIRY_DATE' || '~' ||
                 'UID_ISSUED_COUNTRY' || '~' || 'PRINCE_CUSTOMER' || '~' ||
                 'BENEF_NAME' || '~' || 'BENEF_ADDRESS' || '~' ||
                 'BENEF_CITY' || '~' || 'SENDER_COUNTRY' || '~' || P_KEY;
        
        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field70 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD71 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD72 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD73 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD74 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD75 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD76 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD77 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD78 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD79 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD80 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD81 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD82 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD84 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD86 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD87 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88 || '~' ||
                  P_DATA;*/
      
        P_KEY := 'RIA_PIN' || '~' || 'RIA_AMOUNT' || '~' || 'TXN_UNIQUE_NO' || '~' ||
                 'RIA_REFERENCE_NO' || '~' || 'ORDER_NO' || '~' ||
                 'CURRENCY' || '~' || 'ORDER_DATE' || '~' || 'TXN_REMARKS' || '~' ||
                 'REFERENCE_NO' || '~' || 'COMM_CURRENCY' || '~' ||
                 'COMM_AMOUNT' || '~' || 'UNIQUE_ID_NAME' || '~' ||
                 'UNIQUE_ID_VALUE' || '~' || 'UID_EXPIRY_DATE' || '~' ||
                 'UID_ISSUED_COUNTRY' || '~' || 'PRINCE_CUSTOMER' || '~' ||
                 'BENEF_NAME' || '~' || 'SENDER_FIRST_NAME' || '~' ||
                 'SENDER_LAST_NAME' || '~' || 'SENDER_COUNTRY' || '~' ||
                 'SENDER_NATIONALITY' || '~' || 'BENEF_BIRTH_COUNTRY' || '~' ||
                 'BENEF_NATIONALITY' || '~' || 'BENEF_ADDR_CODE' || '~' ||
                 'BENEF_PROVINCE' || '~' || 'BENEF_DISTRICT' || '~' ||
                 'BENEF_VILLAGE_COMM' || '~' || 'BENEF_ADDR_4' || '~' ||
                 'BENEF_ADDR_COUNTRY' || '~' || 'BENEF_OCCUPATION' || '~' ||
                 P_KEY;
      
        DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89=' ||
            P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89);
      
        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field70 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.num_field11 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD71 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD72 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD73 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD74 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD75 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD76 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD77 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD78 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD79 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD80 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD81 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD82 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD83 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD84 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD85 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD98 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD99 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD88 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD100 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD89 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD90 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD91 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD92 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD93 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD94 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD95 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD96 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD97 || '~' ||
                  P_DATA;
      
      END IF;
	  --RIA Phase2 Changes Ends

    END IF;



    DBG('IF', 'Returning Successfully from fn_build_rtdetails..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of gwpks_queryretailtlr_custom.fn_build_rtdetails ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_BUILD_RTDETAILS;

  FUNCTION FN_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                            P_PARENT_RES     IN VARCHAR2,
                            P_FCCREF         IN VARCHAR2,
                            P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                            P_XREF           IN VARCHAR2,
                            P_PARENT         IN OUT VARCHAR2,
                            P_TAG            IN OUT VARCHAR2,
                            P_DATA           IN OUT VARCHAR2,
                            P_FORMAT         IN OUT VARCHAR2,
                            P_FN_CALL_ID     IN NUMBER,
                            P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside CUSTOM function fn_build_fsreply..');

    DBG('**',
        'Returning successfully from the CUSTOM function fn_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of CUSTOM fn_build_fsreply..');
      RETURN FALSE;
  END FN_BUILD_FSREPLY;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_REPLY_FTDETAILS_PRE(P_TY_RTUPLD IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                  P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                                  P_DATA      IN OUT VARCHAR2,
                                  P_KEY       IN OUT VARCHAR2,
                                  P_PARENT    IN OUT VARCHAR2,
                                  P_FORMAT    IN OUT VARCHAR2,
                                  P_NODE      IN OUT VARCHAR2,
                                  P_CNT_LVL   IN OUT VARCHAR2,
                                  P_ERR_CODE  IN OUT VARCHAR2,
                                  P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_reply_ftdetails_Pre');

    DBG('Returning success from fn_reply_ftdetails_Pre');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of gwpks_queryretailtlr_custom.fn_reply_ftdetails_Pre..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
  END FN_REPLY_FTDETAILS_PRE;

  FUNCTION FN_REPLY_FTDETAILS_POST(P_TY_RTUPLD IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                   P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                                   P_DATA      IN OUT VARCHAR2,
                                   P_KEY       IN OUT VARCHAR2,
                                   P_PARENT    IN OUT VARCHAR2,
                                   P_FORMAT    IN OUT VARCHAR2,
                                   P_NODE      IN OUT VARCHAR2,
                                   P_CNT_LVL   IN OUT VARCHAR2,
                                   P_ERR_CODE  IN OUT VARCHAR2,
                                   P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_reply_ftdetails_Post');

    DBG('Returning success from fn_reply_ftdetails_Post');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_queryretailtlr_custom.fn_reply_ftdetails_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_REPLY_FTDETAILS_POST;

  FUNCTION FN_REPLY_CHGDETS(P_SOURCE         IN VARCHAR2,
                            P_FCCREF         IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                            P_DATA           IN OUT VARCHAR2,
                            P_KEY            IN OUT VARCHAR2,
                            P_PARENT         IN OUT VARCHAR2,
                            P_FORMAT         IN OUT VARCHAR2,
                            P_NODE           IN OUT VARCHAR2,
                            P_CNT_LVL        IN OUT VARCHAR2,
                            P_TS_LIST        IN OUT VARCHAR2,
                            P_TS_LIST1       IN OUT VARCHAR2,
                            P_TS_VALUE       IN OUT VARCHAR2,
                            P_TS_VALUE1      IN OUT VARCHAR2,
                            P_COUNT          IN INTEGER,
                            P_FN_CALL_ID     IN OUT NUMBER,
                            P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN
    DBG('Inside Custom function fn_reply_chgdets ...');

    DBG('Returning success from Custom function Fn_reply_chgdets');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of fn_reply_chgdets..');
      RETURN FALSE;

  END FN_REPLY_CHGDETS;

  FUNCTION FN_PRE_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                                P_PARENT_RES     IN VARCHAR2,
                                P_FCCREF         IN VARCHAR2,
                                P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                P_XREF           IN VARCHAR2,
                                P_PARENT         IN OUT VARCHAR2,
                                P_TAG            IN OUT VARCHAR2,
                                P_DATA           IN OUT VARCHAR2,
                                P_FORMAT         IN OUT VARCHAR2,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAM      IN OUT VARCHAR2,
                                P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                P_FN_CALL_ID     IN NUMBER) RETURN BOOLEAN IS

  --AIA Payment Confirmation Starts for Digital
    L_INSURANCE_CODE VARCHAR2(105);
    L_POLICY_NO      VARCHAR2(105);
    L_TRAN_UNIQE_NO  VARCHAR2(105);
    L_FORMATTED_MSG  CLOB;
  --AIA Payment Confirmation Ends for Digital

  --RIA incoming Payment starts
    L_TAG                VARCHAR2(32767);
    L_DATA               VARCHAR2(32767);
    L_SENDER_NATIONALITY VARCHAR2(32767);
    L_BEN_NATIONALITY    VARCHAR2(32767);
    L_COUNTRY_FROM       VARCHAR2(32767);
    L_COUNTRY_TO         VARCHAR2(32767);
    L_REG_ADDR_COUNTRY   VARCHAR2(32767);
    L_CUST_TYPE          STTM_CUSTOMER.CUSTOMER_TYPE%TYPE;
  L_TYPE_RIA       VARCHAR2(105);
    L_SENDER_FIRST_NAME  VARCHAR2(32767);
    L_SENDER_LAST_NAME   VARCHAR2(32767);
    L_BEN_NAME           VARCHAR2(32767);
    P_HIT_STATUS         VARCHAR2(100);
    P_SCAN_ID            VARCHAR2(100);

    L_RATE_CODE      CSTM_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_RATE_TYPE      CSTM_PRODUCT.RATE_TYPE_PREFERRED%TYPE;
    L_X_RATE_DERIVED CYTM_RATES.MID_RATE%TYPE;
    L_RATE_FLAG      NUMBER;
    l_txn_amt        DETB_RTL_TELLER.TXN_AMOUNT%TYPE;
    L_AMOUNT         STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_AMOUNT1        STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_CUST_NO        STTM_CUSTOMER.CUSTOMER_NO%TYPE;

    L_CUSTOMER       STTM_CUSTOMER%ROWTYPE;
    TYPE TYPE_RISK_SCORE IS VARRAY(5) OF INTEGER;
    L_RISK_SCORE   TYPE_RISK_SCORE;
    L_MAX_INDEX    NUMBER;
    L_MAX_VALUE    NUMBER;
    L_HIGH_SEN_CNT STTM_CUSTOMER.NATIONALITY%TYPE;
    L_HIGH_BEN_CNT STTM_CUSTOMER.NATIONALITY%TYPE;

    P_WHO_HIT            CHAR(1);
    --RIA incoming Payment ends
	
	 --RIA Phase2 Changes Outgoing Payment Starts
    L_BEN_FIRST_NAME VARCHAR2(1000);
    L_BEN_LAST_NAME  VARCHAR2(1000);
    L_SENDER_COUNTRY STTM_COUNTRY.COUNTRY_CODE%TYPE;
    --RIA Phase2 Changes outgoing Payment Ends
	
	--MTA Payment Confirmation Starts
    L_REMIT_TYPE           VARCHAR2(100);
    L_PAY_MODE             VARCHAR2(100);
    L_REMIT_REASON_PURPOSE VARCHAR2(100);
    L_SENDER_NAME          VARCHAR2(100);
    L_SENDER_DOB           VARCHAR2(100);
    L_SENDER_UID           VARCHAR2(100);
    L_SENDER_UVAL          VARCHAR2(100);
    L_SENDER_OCC           VARCHAR2(100);
    L_SENDER_MOB           VARCHAR2(100);
    L_SENDER_EMAIL         VARCHAR2(100);
    L_SENDER_ADDR          VARCHAR2(100);
    L_BEN_BIC              VARCHAR2(100);
    L_BEN_BANK_NAME        VARCHAR2(100);
    L_BEN_BANK_BRANCH      VARCHAR2(100);
    L_BEN_BRANCH_NAME      VARCHAR2(100);
    L_BEN_COUNTRY          VARCHAR2(100);
    L_BEN_COUNTRY_NAME     VARCHAR2(100);
    L_MTA_BEN_NATIONALITY  VARCHAR2(100);
    L_CASHPICKUP_LOC       VARCHAR2(100);
    L_BEN_ADDR             VARCHAR2(100);
    L_BEN_PHONE            VARCHAR2(100);
    L_BEN_EMAIL            VARCHAR2(100);
  
    L_BEN_STATE                VARCHAR2(100);
    L_BEN_CITY                 VARCHAR2(100);
    L_BEN_POSTCODE             VARCHAR2(100);
    L_DOC_REF_NO               VARCHAR2(100);
    L_COMPANY_TYPE             VARCHAR2(100);
    L_STREET_NAME              VARCHAR2(100);
    L_STREET_TYPE              VARCHAR2(100);
    L_STREET_NO                VARCHAR2(100);
    L_REMARKS                  VARCHAR2(100);
    L_COUNTRY_OF_BUSINESS      VARCHAR2(100);
    L_PAYOUT_GRP_CODE          VARCHAR2(100);
    L_REQUEST_IDENTIFIER       VARCHAR2(100);
    L_REQUEST_IDENTIFIER_VALUE VARCHAR2(100);
    L_REQUESTOR_NAME           VARCHAR2(100);
    L_BEN_ACCOUNT              VARCHAR2(100);
    L_SENDER_CITY              VARCHAR2(100);
    L_MTA_SENDER_FIRST_NAME    VARCHAR2(100);
    L_SENDER_POSTCODE          VARCHAR2(100);
    L_SENDER_STATE             VARCHAR2(100);
    --MTA Payment Confirmation Ends
	
	
	--RIA Phase2 Changes Outgoing Payment Confirmation Starts for digital
    L_TXN_UNIQUE_NO_RIAA  VARCHAR2(255);
    L_BEN_COUNTRY_RIAA    VARCHAR2(255);
    L_BEN_FIRST_NAME_RIAA VARCHAR2(255);
    L_BEN_LAST_NAME_RIAA  VARCHAR2(255);
    L_BANK_ID_RIAA        VARCHAR2(255);
    L_BEN_CITY_RIAA       VARCHAR2(255);
    L_BEN_STATE_RIAA      VARCHAR2(255);
  
    L_CUST_FIRST_NAME STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_CUST_LAST_NAME  STTM_CUST_PERSONAL.LAST_NAME%TYPE;
  
    L_CUST_ADDRESS        STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_CITY           STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_CUST_DOB            VARCHAR2(100);
    L_CUST_OCCUPATION     STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_CUST_ID_TYPE        STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_CUST_ID_NO          STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_CUST_ID_EXPIRY_DATE VARCHAR2(100);
  
    L_ADDRESS_LINE1    STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDRESS_LINE2    STTM_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDRESS_LINE3    STTM_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS_LINE4    STTM_CUSTOMER.ADDRESS_LINE4%TYPE;
    L_UNIQUE_ID_NAME   STTM_CUSTOMER.UNIQUE_ID_NAME%TYPE;
    L_UNIQUE_ID_VALUE  STTM_CUSTOMER.UNIQUE_ID_VALUE%TYPE;
    L_FIRST_NAME       STTM_CUST_PERSONAL.FIRST_NAME%TYPE;
    L_LAST_NAME        STTM_CUST_PERSONAL.LAST_NAME%TYPE;
    L_DOB              STTM_CUST_PERSONAL.DATE_OF_BIRTH%TYPE;
    L_OCCUPATION       STTM_CUSTOMER_CUSTOM.OCCUPATION%TYPE;
    L_UNIQUE_ID_EXP_DT STTM_CUSTOMER_CUSTOM.UNIQUE_ID_EXP_DT%TYPE;
  
    L_DELIVERY_METHOD_RIAA       IFTB_RIA_MASTER.DELIVERY_METHOD%TYPE;
    L_BEN_BANK_ID_RIAA           IFTB_RIA_MASTER.BANK_ID%TYPE;
    L_BEN_ACCOUNT_NO_RIAA        IFTB_RIA_MASTER.BANK_ACCOUNT_NO%TYPE;
    L_BANK_ACCOUNT_TYPE_RIAA     IFTB_RIA_MASTER.BANK_ACCOUNT_TYPE%TYPE;
    L_BANK_ROUTING_CODE_RIAA     VARCHAR2(255);
    L_PURPOSE_OF_TRF_RIAA        VARCHAR2(255);
    L_BEN_ID_TYPE_RIAA           VARCHAR2(255);
    L_BIC_SWIFT_RIAA             VARCHAR2(255);
    L_BEN_PHONE_RIAA             VARCHAR2(255);
    L_VALUE_TYPE_RIAA            VARCHAR2(255);
    L_BEN_ADDRESS_RIAA           VARCHAR2(255);
    L_CUST_BEN_RELATIONSHIP_RIAA VARCHAR2(255);
    L_UNITARY_BANK_ACC_NO_RIAA   VARCHAR2(255);
    L_BEN_CELL_NO_RIAA           VARCHAR2(255);
    L_BEN_ID_NO_RIAA             VARCHAR2(255);
  
    --P_RIA_PIN                IFTB_RIA_MASTER.RIA_PIN%TYPE;
  
    --RIA Phase2 Changes Outgoing Payment Confirmation Ends for digital
  
    --RIA Phase2 Changes Withdrawal Remittance Confirmation Starts for Digital
    L_RIA_REFERENCE_NO_RIAP VARCHAR2(105);
    L_RIA_ORDER_NO_RIAP     VARCHAR2(105);
    L_RIA_ORDER_DATE_RIAP   VARCHAR2(105);
    L_TXN_UNIQUE_NO_RIAP    VARCHAR2(105);
    L_RIA_PIN_RIAP          VARCHAR2(105);
    --RIA Phase2 Changes Withdrawal Remittance Confirmation Ends for Digital

  BEGIN
    DBG('Inside the function Gwpks_Queryretailtlr_Custom.fn_pre_build_fsreply..');

  --AIA Payment Confirmation Starts for Digital
    IF P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE IN ('AIAA') THEN
      IF P_TY_RTUPLD.TBL_UDFDETAILS.COUNT > 0 THEN
        FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
          DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X)
              .FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL);

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'INSURANCE_CODE_AIA' THEN

            L_INSURANCE_CODE := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'POLICY_NUMBER_AIA' THEN

            L_POLICY_NO := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'TRAN_UNIQUE_NO_AIA' THEN

            L_TRAN_UNIQE_NO := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;



        END LOOP;



        DBG('L_INSURANCE_CODE=' || L_INSURANCE_CODE);
        DBG('L_POLICY_NO=' || L_POLICY_NO);
        DBG('L_TRAN_UNIQE_NO=' || L_TRAN_UNIQE_NO);


        --call AIA for payment confirmation
    --Get AIA CONFIRM PAYMENT
          L_FORMATTED_MSG := IFPKS_AIA_SI_UTILS.FN_GET_FMT_AIA_PAYMENT(L_TRAN_UNIQE_NO,
                                                                       L_POLICY_NO,
                                                                       P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                                                       P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);

          DBG('AFTER REPLACEMENT OF AIA PAYMENT JSON=' || L_FORMATTED_MSG);

          DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);

          DBG('CALLING AIA PAYMENT WEBSERVICE');

          IF NOT IFPKS_AIA_SI_UTILS.FN_MSG_UPLOAD(depks_rtl_teller.g_trn_ref_no,
                                                  L_POLICY_NO,
                                                  'C',
                                                  L_FORMATTED_MSG,
                                                  'Payment Confirmation Call for AIAA - Digital',
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM) THEN

            DBG('FAILED IN AIA PAYMENT CALL');
            PR_LOG_ERROR('DEDRTPRM','API1','IF-AIA-004', null);
            RETURN FALSE;

          ELSE

            DBG('SUCCESS IN AIA PAYMENT CALL');

          END IF;


        END IF;
      END IF;



    --AIA Payment Confirmation Ends for Digital

  --RIA Incoming Payment starts

    IF P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE IN ('RIAI', 'RIAB') THEN
      IF P_TY_RTUPLD.TBL_UDFDETAILS.COUNT > 0 THEN
        FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
          DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X)
              .FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL);

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'SENDER_NATIONALITY_RIA' THEN

            L_SENDER_NATIONALITY := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'BEN_NATIONALITY_RIA' THEN

            L_BEN_NATIONALITY := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'SENDER_FIRST_NAME_RIA' THEN

            L_SENDER_FIRST_NAME := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'SENDER_LAST_NAME_RIA' THEN

            L_SENDER_LAST_NAME := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'COUNTRY_FROM_RIA' THEN

            L_COUNTRY_FROM := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'COUNTRY_TO_RIA' THEN

            L_COUNTRY_TO := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'BEN_ACC_NAME_RIA' THEN

            L_BEN_NAME := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'REG_ADDR_COUNTRY_RIA' THEN

            L_REG_ADDR_COUNTRY := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

      IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'TYPE_RIA' THEN

            L_TYPE_RIA := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;

          END IF;

        END LOOP;

        --Get Customer Type
        BEGIN

          SELECT *
            INTO L_CUSTOMER
            FROM STTM_CUSTOMER
           WHERE CUSTOMER_NO IN
                 (SELECT CUST_NO
                    FROM STTM_CUST_ACCOUNT
                   WHERE CUST_AC_NO = P_TY_RTUPLD.ty_upld_rtl_teller.ofs_acc);

        EXCEPTION
          WHEN OTHERS THEN
            L_CUSTOMER := NULL;
        END;

        DBG('L_CUST_TYPE=' || L_CUSTOMER.CUSTOMER_TYPE);
        DBG('L_SENDER_NATIONALITY=' || L_SENDER_NATIONALITY);
        DBG('L_COUNTRY_FROM=' || L_COUNTRY_FROM);
        DBG('L_COUNTRY_TO=' || L_COUNTRY_TO);
        DBG('L_SENDER_FIRST_NAME=' || L_SENDER_FIRST_NAME);
        DBG('L_SENDER_LAST_NAME=' || L_SENDER_LAST_NAME);


        --New AML Validation Starts


        --Sender Highest Country
        IF L_SENDER_NATIONALITY <> 'N/A' THEN

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_SENDER_NATIONALITY),
                                          FN_GET_RISK_LEVEL_CNT(L_COUNTRY_FROM));
        ELSE

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_COUNTRY_FROM));

        END IF;

        IF L_RISK_SCORE.COUNT > 1 THEN
        L_MAX_INDEX := 1;
        L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

        FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

          IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
            L_MAX_VALUE := L_RISK_SCORE(G);
            L_MAX_INDEX := G;
          END IF;
        END LOOP;

        IF L_MAX_INDEX = 1 THEN
          L_HIGH_SEN_CNT := L_SENDER_NATIONALITY;
        ELSE
          --ELSIF L_MAX_INDEX = 2 THEN
          L_HIGH_SEN_CNT := L_COUNTRY_FROM;

        END IF;
        ELSE
          L_HIGH_SEN_CNT := L_COUNTRY_FROM;
        END IF;

        --Beneficiary Highest Country
        IF L_SENDER_NATIONALITY <> 'N/A' THEN

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_BEN_NATIONALITY),
                                          FN_GET_RISK_LEVEL_CNT(L_COUNTRY_TO));
        ELSE

          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_COUNTRY_TO));

        END IF;

        IF L_RISK_SCORE.COUNT > 1 THEN
        L_MAX_INDEX := 1;
        L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);

        FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP

          IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
            L_MAX_VALUE := L_RISK_SCORE(G);
            L_MAX_INDEX := G;
          END IF;
        END LOOP;

        IF L_MAX_INDEX = 1 THEN
          L_HIGH_BEN_CNT := L_BEN_NATIONALITY;
        ELSE
          --ELSIF L_MAX_INDEX = 2 THEN
          L_HIGH_BEN_CNT := L_COUNTRY_TO;

        END IF;
        ELSE
          L_HIGH_BEN_CNT := L_COUNTRY_TO;
        END IF;

        --Call AML for both Sender and Beneficiary for individual
    IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA(L_HIGH_SEN_CNT,
                                                       L_HIGH_BEN_CNT,
                                                       L_CUSTOMER.CUSTOMER_NO,
                                                       CASE
                                                       L_TYPE_RIA WHEN 'Individual' THEN
                                                       L_SENDER_FIRST_NAME || ' ' ||
                                                       L_SENDER_LAST_NAME WHEN 'Corporate' THEN
                                                       L_SENDER_FIRST_NAME END,
                                                       L_BEN_NAME,
                                                       'DOSCAN_AUTH',
                                                       P_FCCREF,
                                                       P_HIT_STATUS,
                                                       P_WHO_HIT,
                                                       P_SCAN_ID,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM) THEN

      DBG('P_HIT_STATUS=' || P_HIT_STATUS);

      DBG('P_WHO_HIT=' || P_WHO_HIT);

      PR_LOG_ERROR('IFDRIAPA',
                   'FLEXCUBE',
                   'IF-MTA-018',
                   P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN 'For Sender' WHEN 'R' THEN
                   'For Beneficiary' WHEN 'B' THEN
                   'For Both Sender and Beneficiary' END);
      RETURN FALSE;

    ELSE
      RETURN TRUE;
    END IF;

        --New AML Validation Ends

        --call AML
        /*IF L_CUST_TYPE = 'I' THEN

          DBG('CALLING AML WITH SENDER DETAILS');
          --Call AML for Sender
          IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP('INDIVIDUAL',
                                                         L_SENDER_NATIONALITY,
                                                         L_COUNTRY_FROM,
                                                         L_COUNTRY_TO,
                                                         '0000002',
                                                         L_SENDER_FIRST_NAME || ' ' ||
                                                         L_SENDER_LAST_NAME,
                                                         'AUTOAUTH',
                                                         P_HIT_STATUS,
                                                         P_SCAN_ID,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAM) THEN

            --update udf aml status

            DBG('P_HIT_STATUS=' || P_HIT_STATUS);
            PR_LOG_ERROR('DEDRTPRM',
                         'API1',
                         'ST-PRIN-023',
                         P_SCAN_ID || ' For Sender');
            RETURN FALSE;

          ELSE

            --Call AML for Beneficiary
            DBG('CALLING AML WITH BENEFICIARY DETAILS');
            IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP('INDIVIDUAL',
                                                           L_BEN_NATIONALITY,
                                                           L_COUNTRY_FROM,
                                                           L_COUNTRY_TO,
                                                           '0000002',
                                                           L_BEN_NAME,
                                                           'AUTOAUTH',
                                                           P_HIT_STATUS,
                                                           P_SCAN_ID,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN

              PR_LOG_ERROR('DEDRTPRM',
                           'API1',
                           'ST-PRIN-023',
                           P_SCAN_ID || ' For Beneficiary');
              RETURN FALSE;

            ELSE

              RETURN TRUE;

            END IF;

            RETURN TRUE;

          END IF;

        ELSE

          --This is for corporate sender

          IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP('CORPORATE',
                                                         L_REG_ADDR_COUNTRY,
                                                         L_COUNTRY_FROM,
                                                         L_COUNTRY_TO,
                                                         '0000002',
                                                         L_SENDER_FIRST_NAME || ' ' ||
                                                         L_SENDER_LAST_NAME,
                                                         'AUTOAUTH',
                                                         P_HIT_STATUS,
                                                         P_SCAN_ID,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAM) THEN

            PR_LOG_ERROR('DEDRTPRM',
                         'API1',
                         'ST-PRIN-023',
                         P_SCAN_ID || ' For Corporate');

            RETURN FALSE;

          ELSE

            --This is for corporate beneficiary --Call AML for Beneficiary
            DBG('CALLING AML WITH BENEFICIARY DETAILS');
            IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP('CORPORATE',
                                                           L_REG_ADDR_COUNTRY,
                                                           L_COUNTRY_FROM,
                                                           L_COUNTRY_TO,
                                                           '0000002',
                                                           L_BEN_NAME,
                                                           'AUTOAUTH',
                                                           P_HIT_STATUS,
                                                           P_SCAN_ID,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN

              PR_LOG_ERROR('DEDRTPRM',
                           'API1',
                           'ST-PRIN-023',
                           P_SCAN_ID || ' For Beneficiary');
              RETURN FALSE;

            ELSE

              RETURN TRUE;

            END IF;

            RETURN TRUE;

          END IF;

        END IF;*/
      END IF;

    END IF;
    --RIA Incoming Payment Ends
	
	--RIA Phse2 Changes Starts
	--RIA Outgoing Payment Starts
	IF P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE IN ('RIAA', '') THEN
    
      IF P_TY_RTUPLD.TBL_UDFDETAILS.COUNT > 0 THEN
      
        FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
          DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X)
              .FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL);
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'BEN_FIRST_NAME_RIAA' THEN
          
            L_BEN_FIRST_NAME := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'BEN_LAST_NAME_RIAA' THEN
          
            L_BEN_LAST_NAME := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'BEN_COUNTRY_RIAA' THEN
          
            L_BEN_COUNTRY := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'SENDER_NAME_RIAA' THEN
          
            L_SENDER_NAME := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'SENDER_COUNTRY_RIAA' THEN
          
            L_SENDER_COUNTRY := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
        END LOOP;
      
        DBG('P_TY_RTUPLD.ty_upld_rtl_teller.ofs_acc=' ||
            P_TY_RTUPLD.ty_upld_rtl_teller.ofs_acc);
      
        --Get Customer Type
        BEGIN
        
          SELECT *
            INTO L_CUSTOMER
            FROM STTM_CUSTOMER
           WHERE CUSTOMER_NO IN
                 (SELECT CUST_NO
                    FROM STTM_CUST_ACCOUNT
                   WHERE CUST_AC_NO = P_TY_RTUPLD.ty_upld_rtl_teller.ofs_acc);
        
        EXCEPTION
          WHEN OTHERS THEN
            L_CUSTOMER := NULL;
        END;
      
        DBG('L_CUST_TYPE=' || L_CUSTOMER.CUSTOMER_TYPE);
        DBG('L_BEN_FIRST_NAME=' || L_BEN_FIRST_NAME);
        DBG('L_BEN_LAST_NAME=' || L_BEN_LAST_NAME);
        DBG('L_BEN_COUNTRY=' || L_BEN_COUNTRY);
        DBG('L_SENDER_NAME=' || L_SENDER_NAME);
        DBG('L_SENDER_COUNTRY=' || L_SENDER_COUNTRY);
      
        L_SENDER_COUNTRY := 'KH';
      
        --New AML Validation Starts
      
        --Sender Highest Country    
      
        IF L_SENDER_COUNTRY <> 'N/A' THEN
        
          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_SENDER_COUNTRY));
        
        END IF;
      
        L_HIGH_SEN_CNT := L_SENDER_COUNTRY; --only one country in case of sender
      
        --Beneficiary Highest Country  
        IF L_BEN_COUNTRY <> 'N/A' THEN
        
          L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_BEN_COUNTRY));
        
        END IF;
      
        L_HIGH_BEN_CNT := L_BEN_COUNTRY;
      
        IF NOT FN_GET_AMLCHECK_PERDAY_RIA_OUT( --L_CUSTOMER.CUSTOMER_NO,
                                              --L_SENDER_NAME,
                                              L_BEN_FIRST_NAME || ' ' ||
                                              L_BEN_LAST_NAME,
                                              --L_HIGH_SEN_CNT,
                                              L_HIGH_BEN_CNT) THEN
        
          PR_LOG_ERROR('IFDRIAPA', 'FLEXCUBE', 'IF-RIA-029', null);
          RETURN FALSE;
        
        END IF;
      
        --Call AML for both Sender and Beneficiary for individual
        /*IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA(L_HIGH_SEN_CNT,
        L_HIGH_BEN_CNT,
        L_CUSTOMER.CUSTOMER_NO,
        --L_SENDER_FIRST_NAME || ' ' ||
        --L_SENDER_LAST_NAME,
        L_SENDER_NAME,
        --L_BEN_NAME,
        L_BEN_FIRST_NAME || ' ' ||
        L_BEN_LAST_NAME,
        'DOSCAN_AUTH',
        P_FCCREF,
        P_HIT_STATUS,
        P_WHO_HIT,
        P_SCAN_ID,
        P_ERR_CODE,
        P_ERR_PARAM) THEN*/
      
        IF NOT
            IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_OUT_NEW( --L_HIGH_SEN_CNT,
                                                                L_HIGH_BEN_CNT,
                                                                L_CUSTOMER.CUSTOMER_NO,
                                                                -- CASE
                                                                -- L_CUSTOMER.CUSTOMER_TYPE WHEN 'I' THEN
                                                                --  L_SENDER_FIRST_NAME || ' ' ||
                                                                -- L_SENDER_LAST_NAME WHEN 'C' THEN
                                                                --L_SENDER_FIRST_NAME END,
                                                                L_BEN_FIRST_NAME || ' ' ||
                                                                L_BEN_LAST_NAME,
                                                                'DOSCAN_AUTH',
                                                                P_FCCREF,
                                                                P_HIT_STATUS,
                                                                P_WHO_HIT,
                                                                P_SCAN_ID,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAM) THEN
          DBG('P_HIT_STATUS=' || P_HIT_STATUS);
        
          DBG('P_WHO_HIT=' || P_WHO_HIT);
        
          PR_LOG_ERROR('IFDRIAPA',
                       'FLEXCUBE',
                       'IF-MTA-018',
                       P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                       'For Sender' WHEN 'R' THEN 'For Beneficiary' WHEN 'B' THEN
                       'For Both Sender and Beneficiary' END);
          RETURN FALSE;
        
        ELSE
          --RETURN TRUE;
        
          --RIA Outgoing Payment Confirmation Starts for Digital
        
          IF P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE IN ('RIAA') THEN
          
            IF P_TY_RTUPLD.TBL_UDFDETAILS.COUNT > 0 THEN
            
              FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
              
                DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X)
                    .FIELD_VAL);
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'RECEIVING_OPTION_RIAA' THEN
                
                  L_DELIVERY_METHOD_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                            .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'TXN_UNIQUE_NO_RIAA' THEN
                
                  L_TXN_UNIQUE_NO_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                          .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_COUNTRY_RIAA' THEN
                
                  L_BEN_COUNTRY_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                        .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_FIRST_NAME_RIAA' THEN
                
                  L_BEN_FIRST_NAME_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                           .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_LAST_NAME_RIAA' THEN
                
                  L_BEN_LAST_NAME_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                          .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_CITY_RIAA' THEN
                
                  L_BEN_CITY_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_STATE_RIAA' THEN
                
                  L_BEN_STATE_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                      .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'BANK_ID_RIAA' THEN
                
                  L_BANK_ID_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_ID_NO_RIAA' THEN
                  -- 'BANK_ID_RIAA' THEN --'BEN_BANK_ID_RIAA' THEN
                
                  L_BEN_ID_NO_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                      .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_ACCOUNT_NO_RIAA' THEN
                
                  L_BEN_ACCOUNT_NO_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                           .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BANK_ACCOUNT_TYPE_RIAA' THEN
                
                  L_BANK_ACCOUNT_TYPE_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                              .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BANK_ROUTING_CODE_RIAA' THEN
                
                  L_BANK_ROUTING_CODE_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                              .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'PURPOSE_OF_TRF_RIAA' THEN
                
                  L_PURPOSE_OF_TRF_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                           .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_ID_TYPE_RIAA' THEN
                
                  L_BEN_ID_TYPE_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                        .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BIC_SWIFT_RIAA' THEN
                
                  L_BIC_SWIFT_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                      .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_PHONE_RIAA' THEN
                
                  L_BEN_PHONE_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                      .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'VALUE_TYPE_RIAA' THEN
                
                  L_VALUE_TYPE_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                       .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_ADDRESS_RIAA' THEN
                
                  L_BEN_ADDRESS_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                        .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'CUST_BEN_RELATIONSHIP_RIAA' THEN
                
                  L_CUST_BEN_RELATIONSHIP_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                                  .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'UNITARY_BANK_ACC_NO_RIAA' THEN
                
                  L_UNITARY_BANK_ACC_NO_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                                .FIELD_VAL;
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'BEN_CELL_NO_RIAA' THEN
                
                  L_BEN_CELL_NO_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                        .FIELD_VAL;
                
                END IF;
              
              END LOOP;
            
              DBG('L_DELIVERY_METHOD_RIAA=' || L_DELIVERY_METHOD_RIAA);
              DBG('L_TXN_UNIQUE_NO_RIAA=' || L_TXN_UNIQUE_NO_RIAA);
              DBG('L_BEN_COUNTRY_RIAA=' || L_BEN_COUNTRY_RIAA);
              DBG('L_BEN_FIRST_NAME_RIAA=' || L_BEN_FIRST_NAME_RIAA);
              DBG('L_BEN_LAST_NAME_RIAA=' || L_BEN_LAST_NAME_RIAA);
              DBG('L_BEN_CITY_RIAA=' || L_BEN_CITY_RIAA);
              DBG('L_BEN_STATE_RIAA=' || L_BEN_STATE_RIAA);
              DBG('L_BEN_BANK_ID_RIAA=' || L_BEN_BANK_ID_RIAA);
              DBG('L_BEN_ACCOUNT_NO_RIAA=' || L_BEN_ACCOUNT_NO_RIAA);
              DBG('L_BANK_ACCOUNT_TYPE_RIAA=' || L_BANK_ACCOUNT_TYPE_RIAA);
              DBG('L_BANK_ROUTING_CODE_RIAA=' || L_BANK_ROUTING_CODE_RIAA);
              DBG('L_BEN_ADDRESS_RIAA=' || L_BEN_ADDRESS_RIAA);
              DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
              DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT=' ||
                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT);
              DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC=' ||
                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
            
            END IF;
          
            --Get RIA CONFIRM PAYMENT
            IF L_DELIVERY_METHOD_RIAA = '1' THEN
            
              L_FORMATTED_MSG := IFPKS_IFDRIAFT_CUSTOM.FN_GET_FMT_RIA_PAY_CASHPIC_DIG(L_TXN_UNIQUE_NO_RIAA,
                                                                                      L_BEN_COUNTRY_RIAA,
                                                                                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                                                                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                                                                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC,
                                                                                      L_BEN_FIRST_NAME_RIAA,
                                                                                      L_BEN_LAST_NAME_RIAA,
                                                                                      L_BEN_CITY_RIAA,
                                                                                      L_BEN_STATE_RIAA);
            ELSIF L_DELIVERY_METHOD_RIAA = '2' THEN
            
              L_FORMATTED_MSG := IFPKS_IFDRIAFT_CUSTOM.FN_GET_FMT_RIA_PAYMENT_DIG(L_TXN_UNIQUE_NO_RIAA,
                                                                                  L_BEN_COUNTRY_RIAA,
                                                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY,
                                                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC,
                                                                                  L_BEN_FIRST_NAME_RIAA,
                                                                                  L_BEN_LAST_NAME_RIAA,
                                                                                  L_BANK_ID_RIAA,
                                                                                  L_BEN_ACCOUNT_NO_RIAA,
                                                                                  
                                                                                  L_BEN_CITY_RIAA,
                                                                                  L_BEN_STATE_RIAA,
                                                                                  
                                                                                  L_BANK_ACCOUNT_TYPE_RIAA,
                                                                                  L_BANK_ROUTING_CODE_RIAA,
                                                                                  
                                                                                  L_PURPOSE_OF_TRF_RIAA,
                                                                                  L_BEN_ID_TYPE_RIAA,
                                                                                  L_BEN_ID_NO_RIAA,
                                                                                  L_BIC_SWIFT_RIAA,
                                                                                  L_BEN_PHONE_RIAA,
                                                                                  L_VALUE_TYPE_RIAA,
                                                                                  L_BEN_ADDRESS_RIAA,
                                                                                  L_CUST_BEN_RELATIONSHIP_RIAA,
                                                                                  L_UNITARY_BANK_ACC_NO_RIAA,
                                                                                  L_BEN_CELL_NO_RIAA);
            
            END IF;
          
            DBG('AFTER REPLACEMENT OF RIA PAYMENT JSON=' ||
                L_FORMATTED_MSG);
          
            DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
          
            DBG('CALLING RIA PAYMENT WEBSERVICE');
          
            IF NOT IFPKS_IFDRIAFT_CUSTOM.FN_MSG_UPLOAD_DIG(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO,
                                                           'C',
                                                           L_FORMATTED_MSG,
                                                           'Payment Confirmation Call for RIA - Digital',
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM,
                                                           P_RIA_PIN) THEN
            
              DBG('FAILED IN RIA PAYMENT CALL');
              PR_LOG_ERROR('DEDRTPRM', 'API1', 'IF-RIA-000', P_ERR_PARAM);
              RETURN FALSE;
            
            ELSE
            
              DBG('SUCCESS IN RIA PAYMENT CALL');
            
              DBG('P_RIA_PIN=' || P_RIA_PIN);
            
              --update ria pin and other details
              FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
                DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X)
                    .FIELD_VAL);
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'RIA_PIN_RIAA' THEN
                
                  P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL := P_RIA_PIN;
                
                  DBG('P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL=' || P_TY_RTUPLD.TBL_UDFDETAILS(X)
                      .FIELD_VAL);
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'SENDER_COUNTRY_RIAA' THEN
                
                  P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL := 'KH';
                
                  P_SENDER_COUNTRY_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                           .FIELD_VAL;
                
                  DBG('P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL=' || P_TY_RTUPLD.TBL_UDFDETAILS(X)
                      .FIELD_VAL);
                
                END IF;
              
                IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
                 .FIELD_NAME = 'RECEIVING_OPTION_RIAA' THEN
                
                  L_DELIVERY_METHOD_RIAA := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                            .FIELD_VAL;
                
                  DBG('P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL=' || P_TY_RTUPLD.TBL_UDFDETAILS(X)
                      .FIELD_VAL);
                
                END IF;
              
                UPDATE CSTM_CONTRACT_USERDEF_FIELDS A
                   SET FIELD_VAL_28 = P_RIA_PIN,
                       FIELD_VAL_29 = P_SENDER_COUNTRY_RIAA,
                       FIELD_VAL_30 = L_DELIVERY_METHOD_RIAA
                 WHERE A.CONTRACT_REF_NO =
                       P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO;
              
              END LOOP;
            
            END IF;
          
          END IF;
        
          --RIA Outgoing Payment Confirmatoion Ends for Digital
        
        END IF;
      
      END IF;
    
    END IF;
  
    --RIA Outgoing Payment Ends
	
	
	--RIA Withdrawal Remittance Confirmation Starts for Digital
    IF P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE IN ('RIAP') THEN
    
      IF P_TY_RTUPLD.TBL_UDFDETAILS.COUNT > 0 THEN
      
        FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
        
          DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X)
              .FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL);
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'RIA_REFERENCE_NO_RIAP' THEN
          
            L_RIA_REFERENCE_NO_RIAP := P_TY_RTUPLD.TBL_UDFDETAILS(X)
                                       .FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'RIA_ORDER_NO_RIAP' THEN
          
            L_RIA_ORDER_NO_RIAP := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'RIA_ORDER_DATE_RIAP' THEN
          
            L_RIA_ORDER_DATE_RIAP := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'TXN_UNIQUE_NO_RIAP' THEN
          
            L_TXN_UNIQUE_NO_RIAP := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'RIA_PIN_RIAP' THEN
          
            L_RIA_PIN_RIAP := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'SENDER_FIRST_NAME_RIAP' THEN
          
            L_SENDER_FIRST_NAME := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'SENDER_LAST_NAME_RIAP' THEN
          
            L_SENDER_LAST_NAME := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'COUNTRY_FROM_RIAP' THEN
          
            L_COUNTRY_FROM := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
          IF P_TY_RTUPLD.TBL_UDFDETAILS(X)
           .FIELD_NAME = 'SENDER_NATIONALITY_RIAP' THEN
          
            L_SENDER_NATIONALITY := P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL;
          
          END IF;
        
        END LOOP;
      
        DBG('L_RIA_REFERENCE_NO_RIAP=' || L_RIA_REFERENCE_NO_RIAP);
        DBG('L_RIA_ORDER_NO_RIAP=' || L_RIA_ORDER_NO_RIAP);
        DBG('L_RIA_ORDER_DATE_RIAP=' || L_RIA_ORDER_DATE_RIAP);
        DBG('L_TXN_UNIQUE_NO_RIAP=' || L_TXN_UNIQUE_NO_RIAP);
        DBG('L_RIA_PIN_RIAP=' || L_RIA_PIN_RIAP);
      
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
      
      END IF;
    
      --Get Customer Type
      BEGIN
      
        SELECT *
          INTO L_CUSTOMER
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO IN
               (SELECT CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = P_TY_RTUPLD.ty_upld_rtl_teller.ofs_acc);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUSTOMER := NULL;
      END;
    
      DBG('L_CUST_TYPE=' || L_CUSTOMER.CUSTOMER_TYPE);
      DBG('L_SENDER_NATIONALITY=' || L_SENDER_NATIONALITY);
      DBG('L_COUNTRY_FROM=' || L_COUNTRY_FROM);
      DBG('L_COUNTRY_TO=' || L_COUNTRY_TO);
      DBG('L_SENDER_FIRST_NAME=' || L_SENDER_FIRST_NAME);
      DBG('L_SENDER_LAST_NAME=' || L_SENDER_LAST_NAME);
    
      --New AML Validation Starts
    
      --Sender Highest Country    
      IF L_SENDER_NATIONALITY <> 'N/A' THEN
      
        L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_SENDER_NATIONALITY),
                                        FN_GET_RISK_LEVEL_CNT(L_COUNTRY_FROM));
      ELSE
      
        L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_COUNTRY_FROM));
      
      END IF;
    
      IF L_RISK_SCORE.COUNT > 1 THEN
        L_MAX_INDEX := 1;
        L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);
      
        FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP
        
          IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
            L_MAX_VALUE := L_RISK_SCORE(G);
            L_MAX_INDEX := G;
          END IF;
        END LOOP;
      
        IF L_MAX_INDEX = 1 THEN
          L_HIGH_SEN_CNT := L_SENDER_NATIONALITY;
        ELSE
          --ELSIF L_MAX_INDEX = 2 THEN
          L_HIGH_SEN_CNT := L_COUNTRY_FROM;
        
        END IF;
      ELSE
        L_HIGH_SEN_CNT := L_COUNTRY_FROM;
      END IF;
    
      --Beneficiary Highest Country    
      /* IF L_SENDER_NATIONALITY <> 'N/A' THEN
      
        L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_BEN_NATIONALITY),
                                        FN_GET_RISK_LEVEL_CNT(L_COUNTRY_TO));
      ELSE
      
        L_RISK_SCORE := TYPE_RISK_SCORE(FN_GET_RISK_LEVEL_CNT(L_COUNTRY_TO));
      
      END IF;
      
      IF L_RISK_SCORE.COUNT > 1 THEN
        L_MAX_INDEX := 1;
        L_MAX_VALUE := L_RISK_SCORE(L_MAX_INDEX);
      
        FOR G IN 2 .. L_RISK_SCORE.COUNT LOOP
        
          IF L_RISK_SCORE(G) > L_MAX_VALUE THEN
            L_MAX_VALUE := L_RISK_SCORE(G);
            L_MAX_INDEX := G;
          END IF;
        END LOOP;
      
        IF L_MAX_INDEX = 1 THEN
          L_HIGH_BEN_CNT := L_BEN_NATIONALITY;
        ELSE
          --ELSIF L_MAX_INDEX = 2 THEN
          L_HIGH_BEN_CNT := L_COUNTRY_TO;
        
        END IF;
      ELSE
        L_HIGH_BEN_CNT := L_COUNTRY_TO;
      END IF;*/
    
      IF NOT
          FN_GET_AMLCHECK_PERDAY_RIA_IN( --L_CUSTOMER.CUSTOMER_NO,
                                        L_SENDER_FIRST_NAME || ' ' ||
                                        L_SENDER_LAST_NAME, --L_SENDER_NAME,
                                        /*L_BEN_FIRST_NAME || ' ' ||
                                                                                                                                                                                                                                                                                                                                  L_BEN_LAST_NAME*/
                                        null,
                                        L_HIGH_SEN_CNT,
                                        null, --L_HIGH_BEN_CNT,
                                        P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE) THEN
      
        PR_LOG_ERROR('IFDRIAPA', 'FLEXCUBE', 'IF-RIA-029', null);
        RETURN FALSE;
      
      END IF;
    
      /* --AML Check for NAME starts
      IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_INC(null, --L_HIGH_SEN_CNT,
                                                             null, --L_HIGH_BEN_CNT,
                                                             null, --L_CUSTOMER.CUSTOMER_NO,
                                                             
                                                             L_SENDER_FIRST_NAME || ' ' ||
                                                             L_SENDER_LAST_NAME,
                                                             NULL, --BEN NAME
                                                             'DOSCAN_AUTH',
                                                             P_FCCREF,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE,
                                                             P_HIT_STATUS,
                                                             P_WHO_HIT,
                                                             P_SCAN_ID,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
      
        DBG('P_HIT_STATUS=' || P_HIT_STATUS);
      
        DBG('P_WHO_HIT=' || P_WHO_HIT);
      
        --PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);
      
        PR_LOG_ERROR('IFDRIAPA',
                     'FLEXCUBE',
                     'IF-RIA-013',
                     P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                     ' For Sender' WHEN 'R' THEN ' For Beneficiary' WHEN 'B' THEN
                     ' For Both Sender and Beneficiary' END);
      
        RETURN FALSE;
        --Name screening ends
      
      ELSE
      
        --Country Screening Starts*/
    
      IF NOT IFPKS_SANCTION_UTILS.FN_RETURN_AML_RESP_RIA_INC(L_HIGH_SEN_CNT,
                                                             null, --ben country
                                                             null, --L_CUSTOMER.CUSTOMER_NO,
                                                             
                                                             L_SENDER_FIRST_NAME || ' ' ||
                                                             L_SENDER_LAST_NAME,
                                                             
                                                             null, --ben name
                                                             'DOSCAN_AUTH',
                                                             P_FCCREF,
                                                             P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE,
                                                             P_HIT_STATUS,
                                                             P_WHO_HIT,
                                                             P_SCAN_ID,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
      
        DBG('P_HIT_STATUS=' || P_HIT_STATUS);
      
        DBG('P_WHO_HIT=' || P_WHO_HIT);
      
        --PR_LOG_ERROR('IFDMTAPA', 'FLEXCUBE', 'IF-RIA-013', P_SCAN_ID);
      
        PR_LOG_ERROR('IFDRIAPA',
                     'FLEXCUBE',
                     'IF-RIA-013',
                     P_SCAN_ID || CASE P_WHO_HIT WHEN 'S' THEN
                     ' For Sender Country'/* WHEN 'R' THEN
                     ' For Beneficiary Country' WHEN 'B' THEN
                     ' For Both Sender and Beneficiary Countries'*/ END);
      
        RETURN FALSE;
      
      END IF; --Country Screening Ends
    
      --END IF;
      --AML Check for NAME ends
    
      --Get RIA CONFIRM PAYMENT
    
      L_FORMATTED_MSG := gwpks_createretailtlr_custom.FN_GET_FMT_RIA_PAYMENT_DIG(L_TXN_UNIQUE_NO_RIAP,
                                                                                 L_RIA_REFERENCE_NO_RIAP,
                                                                                 L_RIA_ORDER_NO_RIAP,
                                                                                 L_RIA_PIN_RIAP,
                                                                                 P_TY_RTUPLD);
    
      DBG('AFTER REPLACEMENT OF RIA PAYMENT JSON=' || L_FORMATTED_MSG);
    
      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
    
      DBG('CALLING RIA PAYMENT WEBSERVICE');
    
      IF NOT gwpks_createretailtlr_custom.FN_MSG_UPLOAD_RIA(P_TY_RTUPLD,
                                                            'C',
                                                            L_FORMATTED_MSG,
                                                            'RIA Payment Confirmation Call',
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
      
        DBG('FAILED IN RIA PAYMENT CALL');
      
        RETURN FALSE;
      
      ELSE
      
        DBG('SUCCESS IN RIA PAYMENT CALL');
      
      END IF;
    
    END IF;
  
    --RIA Withdrawal Remittance Confirmation Ends for Digital
	
	--RIA Phase2 Changes Ends

    DBG('Returning successfully from the function fn_pre_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_pre_build_fsreply..');
      RETURN FALSE;
  END FN_PRE_BUILD_FSREPLY;

  FUNCTION FN_POST_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                                 P_PARENT_RES     IN VARCHAR2,
                                 P_FCCREF         IN VARCHAR2,
                                 P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                 P_XREF           IN VARCHAR2,
                                 P_PARENT         IN OUT VARCHAR2,
                                 P_TAG            IN OUT VARCHAR2,
                                 P_DATA           IN OUT VARCHAR2,
                                 P_FORMAT         IN OUT VARCHAR2,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAM      IN OUT VARCHAR2,
                                 P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                 P_FN_CALL_ID     IN NUMBER) RETURN BOOLEAN IS
    --PRF_CUSTOM_05_03072018 changes starts
    L_TB_EMPTY_TBL     GWPKS_CREATERETAILTLR.TY_RECS_TBL;
    L_TB_NAME_VAL_PAIR GWPKS_CREATERETAILTLR.TY_RECS_TBL;

    L_TS_TAG_VALUES VARCHAR2(32767);
    L_TS_TAG_NAMES  VARCHAR2(32767);
    L_NODE_NAME     VARCHAR2(50);
    L_CURR_TAG      VARCHAR2(255);
    L_P_CNT         INTEGER;
    L_TAG           VARCHAR2(32767);
    L_DATA          VARCHAR2(32767);
    L_NAME          VARCHAR2(650);
    L_F_NAME        VARCHAR2(200);
    L_M_NAME        VARCHAR2(200);
    L_L_NAME        VARCHAR2(200);
    L_DEP_TYPE      VARCHAR2(50);
    L_BEN_NAME      VARCHAR2(500);
    L_AMT_WORDS     VARCHAR2(4000);
    L_RTL_TELLER    DETBS_RTL_TELLER%ROWTYPE;
    L_ADV_TOP       VARCHAR2(500);
    L_MOB_NO        VARCHAR2(50);

    --PRF_CUSTOM_05_03072018 changes ends

    --Prince Bank Credit Card Payment by Cash GL Changes
    L_DETB_RTL_TELLER    DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG     ACTB_DAILY_LOG%ROWTYPE;
    --Prince Bank Credit Card Payment by Cash GL Changes

    --Cheque Withdrawal Reverse Starts
  L_IFTB_CHEQUE_CUSTOM IFTB_CHEQUE_WITHDRAWAL_CUSTOM%ROWTYPE;
  --Cheque Withdrawal Reverse Ends

  --AML Participant Enhancements Starts
    L_IFTB_AML_PARTI_INFO_1401 IFTB_AML_PARTICIPANT_INFO_1401%ROWTYPE;
    L_IFTB_AML_PARTI_INFO_1001 IFTB_AML_PARTICIPANT_INFO_1001%ROWTYPE;
    L_IFTB_AML_PARTI_INFO_1013 IFTB_AML_PARTICIPANT_INFO_1013%ROWTYPE;
    L_IFTB_AML_PARTI_INFO_8203 IFTB_AML_PARTICIPANT_INFO_8203%ROWTYPE;
    L_IFTB_AML_PARTI_INFO_8004 IFTB_AML_PARTICIPANT_INFO_8004%ROWTYPE;
    --AML Participant Enhancements Ends

  --NBC RFT changes Starts
    L_IFTB_RFT_PASSCODE_INFO IFTB_RFT_PASSCODE_INFO%ROWTYPE;
    --NBC RFT changes Ends

  BEGIN
    DBG('Inside the function Gwpks_Queryretailtlr_Custom.fn_post_build_fsreply..');

    --PRF_CUSTOM_05_03072018 CHANGES STARTS
    DBG('PROD :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE);
    DBG('ANIKET WIL BE MODFYING THE TAGS HERE');

    L_TAG  := '';
    L_DATA := '';

    L_P_CNT := 1;

    L_NODE_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_PARENT,
                                               NULL,
                                               'N',
                                               L_P_CNT,
                                               '>'),
                       '??');

    WHILE L_NODE_NAME <> 'EOPL' LOOP
      DBG('Processing the node: ' || L_NODE_NAME);
      L_TB_NAME_VAL_PAIR := L_TB_EMPTY_TBL;
      L_TS_TAG_NAMES     := NVL(CSPKES_MISC.FN_GETPARAM(P_TAG,
                                                        P_TAG,
                                                        'N',
                                                        L_P_CNT,
                                                        '>'),
                                '??');

      IF L_TS_TAG_NAMES <> '??' THEN
        L_TAG := L_TAG || L_TS_TAG_NAMES;
      END IF;

      L_TS_TAG_VALUES := NVL(CSPKES_MISC.FN_GETPARAM(P_DATA,
                                                     P_DATA,
                                                     'N',
                                                     L_P_CNT,
                                                     '>'),
                             '??');

      IF L_TS_TAG_VALUES <> '??' THEN
        L_DATA := L_DATA || L_TS_TAG_VALUES;
      END IF;

      DBG('L_NODE_NAME :' || L_NODE_NAME);

      IF L_NODE_NAME = 'Blk-Transaction-Details' THEN
        DBG('before L_DATA :' || L_DATA);
        DBG('XREF :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF || '~' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);

        BEGIN
          SELECT *
            INTO L_RTL_TELLER
            FROM DETBS_RTL_TELLER
           WHERE XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED SELECTING FROM THE RTL TELLER ' || SQLERRM);
            BEGIN
              SELECT *
                INTO L_RTL_TELLER
                FROM DETBS_RTL_TELLER
               WHERE TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('FAILED AGAIN ' || SQLERRM);
                L_RTL_TELLER := NULL;
            END;
        END;

        DBG('TXN AMT :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT || '~' ||
            L_RTL_TELLER.TXN_AMOUNT);
        IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'TXN_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        ELSIF L_RTL_TELLER.TXN_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  L_RTL_TELLER.TXN_AMOUNT,
                                                  L_RTL_TELLER.TXN_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'TXN_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        END IF;

        DBG('OFS AMT :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT);
        IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'OFS_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        ELSIF L_RTL_TELLER.OFS_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  L_RTL_TELLER.OFS_AMOUNT,
                                                  L_RTL_TELLER.OFS_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'OFS_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        END IF;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                             L_RTL_TELLER.TXN_BRANCH)) LOOP
          L_TAG  := L_TAG || 'TXN_BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH,
                             L_RTL_TELLER.OFS_BRANCH)) LOOP
          L_TAG  := L_TAG || 'OFS_BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                             L_RTL_TELLER.BRANCH_CODE)) LOOP
          L_TAG  := L_TAG || 'BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE);
        FOR X IN (SELECT *
                    FROM CSTMS_PRODUCT
                   WHERE PRODUCT_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE,
                             L_RTL_TELLER.PRODUCT_CODE)) LOOP
          L_TAG     := L_TAG || 'PRODUCT_DESC~';
          L_DATA    := L_DATA || X.PRODUCT_DESCRIPTION || '~';
          L_ADV_TOP := X.PRODUCT_DESCRIPTION;
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
        FOR X IN (SELECT DECODE(ACCOUNT_TYPE,
                                'N',
                                'NOSTRO',
                                'S',
                                'SAVINGS',
                                'U',
                                'CHECKING',
                                'Y',
                                'TERM DEPOSIT',
                                '') AS AC_TYPE
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO = NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC,
                                          L_RTL_TELLER.TXN_ACC)
                     AND BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                             L_RTL_TELLER.TXN_BRANCH)) LOOP
          L_TAG  := L_TAG || 'TXN_AC_TYPE~';
          L_DATA := L_DATA || X.AC_TYPE || '~';
        END LOOP;

        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
        FOR X IN (SELECT DECODE(ACCOUNT_TYPE,
                                'N',
                                'NOSTRO',
                                'S',
                                'SAVINGS',
                                'U',
                                'CHECKING',
                                'Y',
                                'TERM DEPOSIT',
                                '') AS AC_TYPE
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO = NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC,
                                          L_RTL_TELLER.OFS_ACC)
                     AND BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH,
                             L_RTL_TELLER.OFS_BRANCH)) LOOP
          L_TAG  := L_TAG || 'OFS_AC_TYPE~';
          L_DATA := L_DATA || X.AC_TYPE || '~';
        END LOOP;

        IF P_TY_RTUPLD.TBL_UDFDETAILS.COUNT > 0 THEN
          FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
            DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X)
                .FIELD_VAL);
            IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'BENEFICIARY_NAME' THEN
              L_TAG  := L_TAG || 'UD_BENF_NAME~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            ELSIF P_TY_RTUPLD.TBL_UDFDETAILS(X)
             .FIELD_NAME = 'BENEFICIARY_ID_TYPE' THEN
              L_TAG  := L_TAG || 'UD_BENF_ID_TYPE~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            ELSIF P_TY_RTUPLD.TBL_UDFDETAILS(X)
             .FIELD_NAME = 'BENEFICIARY_ID_NO' THEN
              L_TAG  := L_TAG || 'UD_BENF_ID_NO~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            END IF;
          END LOOP;
        END IF;
      END IF;

      DBG('ACTION TYPE IS :' || GWPKS_UTIL.PKG_ACTTYPE);
      IF GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
        L_ADV_TOP := L_ADV_TOP || ' REVERSAL';
      END IF;

      L_TAG  := L_TAG || 'ADV_TOP~';
      L_DATA := L_DATA || L_ADV_TOP || '~';

      IF L_TS_TAG_NAMES <> '??' THEN
        L_TAG := L_TAG || '>';
      END IF;

      IF L_TS_TAG_VALUES <> '??' THEN
        L_DATA := L_DATA || '>';
      END IF;

      L_P_CNT     := L_P_CNT + 1;
      L_NODE_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_PARENT, L_P_CNT, '>'),
                         '??');
    END LOOP;
    DBG('P_TAG :' || P_TAG);
    DBG('L_TAG :' || L_TAG);
    DBG('P_DATA :' || P_DATA);
    DBG('L_DATA :' || L_DATA);
    P_TAG  := L_TAG;
    P_DATA := L_DATA;
    DBG('Completed the data preparation into PL/SQL collection');
    --PRF_CUSTOM_05_03072018 CHANGES ENDS

  --NBC RFT Changes Starts

    DBG('GWPKS_UTIL.PKG_FUNC=' || GWPKS_UTIL.PKG_FUNC);
    DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);
    DBG('P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE=' ||
        P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE);
    DBG('GLOBAL.BRANCH_CODE=' || GLOBAL.current_branch);
    DBG('P_TY_RTUPLD.ty_upld_rtl_teller.branch_code=' ||
        P_TY_RTUPLD.ty_upld_rtl_teller.branch_code);

    IF P_TY_RTUPLD.ty_upld_rtl_teller.SCODE <> 'FLEXCUBE' AND
       P_TY_RTUPLD.ty_upld_rtl_teller.PRODUCT_CODE = 'ERFM' THEN

      PR_INSERT_RFT_MOBILE_BANING(P_TY_RTUPLD);

    END IF;

    --NBC RFT Changes Ends


    --Prince Bank Credit Card Payment by Cash GL Changes starts

    IF GWPKS_UTIL.PKG_FUNC IN ('CCCG') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

      /*BEGIN
        SELECT *
          INTO L_FBTB_TXNLOG_MASTER
          FROM FBTB_TXNLOG_MASTER
          WHERE XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      EXCEPTION
        WHEN OTHERS THEN
          L_FBTB_TXNLOG_MASTER := NULL;
      END;*/

      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
          WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
          AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO
          AND A.PRODUCT_CODE IN ('CCCH','CCCV','CCCU');  --UPI Changes
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;

     /* BEGIN
        SELECT *
          INTO L_ACTB_DAILY_LOG
          FROM ACTB_DAILY_LOG
          WHERE EXTERNAL_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
          AND ROWNUM=1;
      EXCEPTION
        WHEN OTHERS THEN
          L_ACTB_DAILY_LOG := NULL;
      END;*/

      --IF L_FBTB_TXNLOG_MASTER.TXNSTATUS = 'IPR' THEN

      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID='||L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID='||L_DETB_RTL_TELLER.CHECKER_ID);
      --DBG('AUTH STAT1=' || L_ACTB_DAILY_LOG.AUTH_STAT);
      --DBG('CHEKER ID1='||L_ACTB_DAILY_LOG.AUTH_ID);

      -- IF L_FBTB_TXNLOG_MASTER.TXNSTATUS = 'IPR' THEN
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL
        AND L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN

         --insert into cash by gl master table
        PR_INSERT_CASH_BY_GL(P_TY_RTUPLD);
        --generate svxp file
        PR_GEN_CCPAYMNT_SVXP_FILE(P_TY_RTUPLD);

      END IF;

      --END IF;
    END IF;

  --Cheque Withdrawal Reverse Starts

     IF GWPKS_UTIL.PKG_FUNC IN ('1013') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN



      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
          WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
          AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO
          AND A.PRODUCT_CODE IN ('CQWL');
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;


      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID='||L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID='||L_DETB_RTL_TELLER.CHECKER_ID);



      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL
        AND L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN

        PR_INSERT_CHEQUE_WITHDRAWAL(P_TY_RTUPLD);

      END IF;

    END IF;


    IF GWPKS_UTIL.PKG_FUNC IN ('1013') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN



      BEGIN
        SELECT *
          INTO L_IFTB_CHEQUE_CUSTOM
          FROM IFTB_CHEQUE_WITHDRAWAL_CUSTOM A
          WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO
      AND A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      EXCEPTION
        WHEN OTHERS THEN
          L_IFTB_CHEQUE_CUSTOM := NULL;
      END;


      P_DATA := L_IFTB_CHEQUE_CUSTOM.char_field40 || '~' || --AML Participant Enhancements Changes
                L_IFTB_CHEQUE_CUSTOM.char_field31 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field32 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field33 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field34 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field36 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field37 || '~' ||

                SUBSTR(P_DATA, 8); --AML Participant Enhancements Changes
     END IF;

      --Cheque Withdrawal Reverse Ends

    --END IF;

    --Prince Bank Credit Card Payment by Cash GL Changes ends

  --AML Participant Enhancements Changes Starts
    IF GWPKS_UTIL.PKG_FUNC IN ('1001') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;

      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);

      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN

        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);

      END IF;

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('1001') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN

      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_1001
          FROM IFTB_AML_PARTICIPANT_INFO_1001 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      EXCEPTION
        WHEN OTHERS THEN
          L_IFTB_AML_PARTI_INFO_1001 := NULL;
      END;

      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);

      P_DATA := L_IFTB_AML_PARTI_INFO_1001.PARTICIPANT_NO || '~' ||
                L_IFTB_AML_PARTI_INFO_1001.SAME_AS_ACC_OWN || '~' ||
                L_IFTB_AML_PARTI_INFO_1001.PARTICIPANT_NAME || '~' ||
                L_IFTB_AML_PARTI_INFO_1001.MOBILE_NUMBER || '~' ||
                L_IFTB_AML_PARTI_INFO_1001.PURPOSE_OF_TXN || '~' ||

                SUBSTR(P_DATA, 6);

      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('1401') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;

      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);

      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN

        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);

      END IF;

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('1401') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN

      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);

      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_1401
          FROM IFTB_AML_PARTICIPANT_INFO_1401 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');

          L_IFTB_AML_PARTI_INFO_1401 := NULL;
      END;

      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);

      P_DATA := L_IFTB_AML_PARTI_INFO_1401.PARTICIPANT_NO || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.SAME_AS_ACC_OWN || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.PARTICIPANT_NAME || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.MOBILE_NUMBER || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.PURPOSE_OF_TXN || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.SOURCE_OF_FUNDS || '~' ||

                SUBSTR(P_DATA, 7);

      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('1013') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;

      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);

      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN

        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);

      END IF;

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('1013') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN

      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);

      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_1013
          FROM IFTB_AML_PARTICIPANT_INFO_1013 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');

          L_IFTB_AML_PARTI_INFO_1013 := NULL;
      END;

      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);

      P_DATA := L_IFTB_AML_PARTI_INFO_1013.PARTICIPANT_NO || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.SAME_AS_ACC_OWN || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.PARTICIPANT_NAME || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.MOBILE_NUMBER || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.PURPOSE_OF_TXN || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.UID_NAME || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.UID_VALUE || '~' ||

                SUBSTR(P_DATA, 8);

      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('8203') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;

      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);

      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN

        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);

      END IF;

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('8203') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN

      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);

      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_8203
          FROM IFTB_AML_PARTICIPANT_INFO_8203 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');

          L_IFTB_AML_PARTI_INFO_8203 := NULL;
      END;

      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);

      P_DATA := L_IFTB_AML_PARTI_INFO_8203.REL_CUSTOMER || '~' ||
                L_IFTB_AML_PARTI_INFO_8203.PURPOSE_OF_TXN || '~' ||
                L_IFTB_AML_PARTI_INFO_8203.SOURCE_OF_FUNDS || '~' ||

                SUBSTR(P_DATA, 4);

      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('8004') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;

      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);

      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN

        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);

      END IF;

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('8004') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN

      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);

      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_8004
          FROM IFTB_AML_PARTICIPANT_INFO_8004 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');

          L_IFTB_AML_PARTI_INFO_8004 := NULL;
      END;

      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);

      P_DATA := L_IFTB_AML_PARTI_INFO_8004.REL_CUSTOMER || '~' ||
                L_IFTB_AML_PARTI_INFO_8004.PURPOSE_OF_TXN || '~' ||
                L_IFTB_AML_PARTI_INFO_8004.SOURCE_OF_FUNDS || '~' ||

                SUBSTR(P_DATA, 4);

      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);

    END IF;
    --AML Participant Enhancements Changes Ends

  --NBC RFT changes Starts

    IF GWPKS_UTIL.PKG_FUNC IN ('RFTM') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN

      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;

      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);

      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN

        DBG('INSIDE IF CONDITION');

        --insert into RFT Passcode table
        PR_INSERT_RFT_PASSCODE_INFO(P_TY_RTUPLD);

      END IF;

    END IF;

    IF GWPKS_UTIL.PKG_FUNC IN ('RFTM') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN

      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);

      BEGIN
        SELECT *
          INTO L_IFTB_RFT_PASSCODE_INFO
          FROM IFTB_RFT_PASSCODE_INFO A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');

          L_IFTB_RFT_PASSCODE_INFO := NULL;
      END;

      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);

      /* P_DATA := L_IFTB_RFT_PASSCODE_INFO.PARTICIPANT_NO || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.SAME_AS_ACC_OWN || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.PARTICIPANT_NAME || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.MOBILE_NUMBER || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.PURPOSE_OF_TXN || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.SOURCE_OF_FUNDS || '~' ||

      SUBSTR(P_DATA, 7);*/

      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);

    END IF;

    --NBC RFT changes Ends

    DBG('Returning successfully from the function fn_post_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_post_build_fsreply..');
      RETURN FALSE;
  END FN_POST_BUILD_FSREPLY;

  FUNCTION FN_PRE_BUILD_RTDETL_DEDQUERY(P_SOURCE       IN VARCHAR2,
                                        P_PARENT_RES   IN VARCHAR2,
                                        P_REFERENCE_NO IN VARCHAR2,
                                        P_PARENT       IN OUT VARCHAR2,
                                        P_TAG          IN OUT VARCHAR2,
                                        P_DATA         IN OUT VARCHAR2,
                                        P_FORMAT       IN OUT VARCHAR2,
                                        P_ERR_CODE     IN OUT VARCHAR2,
                                        P_ERR_PARAM    IN OUT VARCHAR2)

   RETURN BOOLEAN IS
  BEGIN
    DBG('**',
        'Inside the function gwpks_queryretailtlr_custom.fn_pre_build_rtdetl_dedquery..');

    DBG('**',
        'Returning successfully from the function fn_pre_build_rtdetl_dedquery..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of fn_pre_build_rtdetl_dedquery..');
      RETURN FALSE;
  END FN_PRE_BUILD_RTDETL_DEDQUERY;

END GWPKS_QUERYRETAILTLR_CUSTOM;
