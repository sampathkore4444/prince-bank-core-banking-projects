CREATE OR REPLACE PACKAGE gwpks_queryretailtlr_custom AS
/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © © 2008 - 2015  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
  CHANGE HISTORY

  ** Changed By              : Ankit Tiwari
  ** Changed On              : 06/09/2013
  ** Change Description      : New function has been added for providing a hook.
  ** Search string           : 9NT1525_1201_IALIZZ_17421599

  ** Changed By              : Ankit
  ** Changed On              : 22/10/2014
  ** Change Description      : VNDFPT_12.0.3_17_OCT_2014_02_0000 (The declaration has given here for adding more function id's)
  ** Search string           : FCUBS_12.0.3_TPB_19856333

  ** Changed By              : Dekyi
  ** Changed On              : 28-Sept-2016
  ** Change Description      : 12.1_Hook request
  ** Search string           : Bug#23664551

  Modified By        : Saisudha Rathinavelu
  Modified On        : 03-Oct-2016
  Modified Reason    : Retro for hook change bug id 23482647.
  Search String      : 12.2_RETRO_Bug#23651628

    Modified By          : Piyush Sharma
    Modified On          : 18-Oct-2016
    Modified Description : Hook request in package gwpks_queryretailteller
    Search String        : INTERNAL_24909016_RETRO_FROM_24596829

	Modified By         : Dekyi
	Modified On         : 12-July-2017
	Modified Reason     : Hook provided. EHD ref: NED_12.0.1_13_JUN_2017_01_0000.Retro of Bug#26287701.
	Search String       : Bug#26384569
  ------------------------------------------------------------------------------------------------------
*/

--RIA Phase2 Changes Starts
  P_RIA_PIN             IFTB_RIA_MASTER.RIA_PIN%TYPE;
  P_SENDER_COUNTRY_RIAA STTM_COUNTRY.COUNTRY_CODE%TYPE;
--RIA Phase2 Changes Ends
-- 9NT1525_1201_IALIZZ_17421599 atarts
  FUNCTION fn_build_rtdetails(p_source         IN VARCHAR2,
                              p_parent_res     IN VARCHAR2,
                              p_reference_no   IN VARCHAR2,
                              p_ty_rtupld      IN depks_retailtellerupload.typ_retailtellerupld_rec,
                              p_parent         IN OUT VARCHAR2,
                              p_key            IN OUT VARCHAR2,
                              p_data           IN OUT VARCHAR2,
                              p_format         IN OUT VARCHAR2,
                              p_node           IN OUT VARCHAR2,
                              p_fn_call_id     IN NUMBER,
                              p_tb_custom_data IN OUT NOCOPY global.ty_tb_custom_data,
                              p_err_code       IN OUT VARCHAR2,
                              p_err_param      IN OUT VARCHAR2)
    RETURN BOOLEAN;
-- 9NT1525_1201_IALIZZ_17421599 ends
	--FCUBS_12.0.3_TPB_19856333 starts
	Function fn_build_fsreply(p_Source     In Varchar2
                             ,p_Parent_Res In Varchar2
                             ,p_Fccref     In Varchar2
                             ,p_ty_rtupld  IN OUT NOCOPY Depks_RetailTellerUpload.typ_retailTellerUpld_rec
                             ,p_Xref       In Varchar2
                             ,p_Parent     In Out Varchar2
                             ,p_Tag        In Out Varchar2
                             ,p_Data       In Out Varchar2
                             ,p_Format     In Out Varchar2
						     ,p_fn_call_id       IN  NUMBER
                             ,p_tb_custom_data IN OUT NOCOPY Global.ty_tb_custom_data
                             ,p_Err_Code   In Out Varchar2
                             ,p_Err_Param  In Out Varchar2)
    Return Boolean;
	--FCUBS_12.0.3_TPB_19856333 ends

  --Bug#23664551 Starts
 PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2);
 FUNCTION  fn_reply_ftdetails_pre (p_ty_rtupld  IN depks_retailtellerupload.typ_retailtellerupld_rec
                               ,p_fccref    IN detbs_rtl_teller.trn_ref_no%TYPE
                               ,p_data      IN OUT VARCHAR2
                               ,p_key       IN OUT VARCHAR2
                               ,p_parent    IN OUT VARCHAR2
                               ,p_format    IN OUT VARCHAR2
                               ,p_node      IN OUT VARCHAR2
                               ,p_cnt_lvl   IN OUT VARCHAR2
                               ,p_err_code  IN OUT VARCHAR2
                               ,p_err_param IN OUT VARCHAR2) RETURN BOOLEAN	;

 FUNCTION  fn_reply_ftdetails_post (p_ty_rtupld  IN depks_retailtellerupload.typ_retailtellerupld_rec
                               ,p_fccref    IN detbs_rtl_teller.trn_ref_no%TYPE
                               ,p_data      IN OUT VARCHAR2
                               ,p_key       IN OUT VARCHAR2
                               ,p_parent    IN OUT VARCHAR2
                               ,p_format    IN OUT VARCHAR2
                               ,p_node      IN OUT VARCHAR2
                               ,p_cnt_lvl   IN OUT VARCHAR2
                               ,p_err_code  IN OUT VARCHAR2
                               ,p_err_param IN OUT VARCHAR2) RETURN BOOLEAN	;
--Bug#23664551 Ends
--12.2_RETRO_Bug#23651628 Changes starts here
FUNCTION fn_reply_chgdets(p_source    IN VARCHAR2,
                              p_fccref    IN detbs_rtl_teller.trn_ref_no%TYPE,
                              p_data      IN OUT VARCHAR2,
                              p_key       IN OUT VARCHAR2,
                              p_parent    IN OUT VARCHAR2,
                              p_format    IN OUT VARCHAR2,
                              p_node      IN OUT VARCHAR2,
                              p_cnt_lvl   IN OUT VARCHAR2,
                              p_ts_list   IN OUT VARCHAR2,
                              p_ts_list1  IN OUT VARCHAR2,
                              p_ts_value  IN OUT VARCHAR2,
                              p_ts_value1 IN OUT VARCHAR2,
                              p_count     IN INTEGER,
						      P_fn_call_id IN OUT NUMBER,
							  p_tb_custom_data   IN OUT NOCOPY Global.ty_tb_custom_data,
                              p_err_code  IN OUT VARCHAR2,
                              p_err_param IN OUT VARCHAR2) RETURN BOOLEAN;
--12.2_RETRO_Bug#23651628 Changes ends here

--INTERNAL_24909016_RETRO_FROM_24596829
 FUNCTION fn_pre_build_fsreply(p_source     IN VARCHAR2
                             ,p_parent_res IN VARCHAR2
                             ,p_fccref     IN VARCHAR2
                             ,p_ty_rtupld  IN OUT NOCOPY Depks_RetailTellerUpload.typ_retailTellerUpld_rec
                             ,p_xref       IN VARCHAR2
                             ,p_parent     IN OUT VARCHAR2
                             ,p_tag        IN OUT VARCHAR2
                             ,p_data       IN OUT VARCHAR2
                             ,p_format     IN OUT VARCHAR2
                             ,p_err_code   IN OUT VARCHAR2
                             ,p_err_param  IN OUT VARCHAR2
							 ,p_Tb_Custom_Data IN OUT NOCOPY Global.Ty_Tb_Custom_Data
                             ,p_Fn_Call_ID      IN NUMBER)
    RETURN BOOLEAN ;

 FUNCTION fn_post_build_fsreply(p_source     IN VARCHAR2
                             ,p_parent_res IN VARCHAR2
                             ,p_fccref     IN VARCHAR2
                             ,p_ty_rtupld  IN OUT NOCOPY Depks_RetailTellerUpload.typ_retailTellerUpld_rec
                             ,p_xref       IN VARCHAR2
                             ,p_parent     IN OUT VARCHAR2
                             ,p_tag        IN OUT VARCHAR2
                             ,p_data       IN OUT VARCHAR2
                             ,p_format     IN OUT VARCHAR2
                             ,p_err_code   IN OUT VARCHAR2
                             ,p_err_param  IN OUT VARCHAR2
							 ,p_Tb_Custom_Data IN OUT NOCOPY Global.Ty_Tb_Custom_Data
                             ,p_Fn_Call_ID      IN NUMBER)
    RETURN BOOLEAN;
	--INTERNAL_24909016_RETRO_FROM_24596829
--Bug#26384569 starts
FUNCTION fn_pre_build_rtdetl_dedquery(p_source         IN VARCHAR2,
                                       p_parent_res   IN VARCHAR2,
                                       p_reference_no IN VARCHAR2,
                                       p_parent       IN OUT VARCHAR2,
                                       p_tag          IN OUT VARCHAR2,
                                       p_data         IN OUT VARCHAR2,
                                       p_format       IN OUT VARCHAR2,
                                       p_err_code     IN OUT VARCHAR2,
                                       p_err_param    IN OUT VARCHAR2)

   RETURN BOOLEAN;
--Bug#26384569 ends
END gwpks_queryretailtlr_custom;
