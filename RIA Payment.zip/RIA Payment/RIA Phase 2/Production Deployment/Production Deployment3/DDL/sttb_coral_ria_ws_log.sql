alter table STTB_CORAL_RIA_WS_LOG add (sender_name VARCHAR2(105),ben_name VARCHAR2(105),sender_high_cnt VARCHAR2(2),ben_high_cnt VARCHAR2(2))
/
