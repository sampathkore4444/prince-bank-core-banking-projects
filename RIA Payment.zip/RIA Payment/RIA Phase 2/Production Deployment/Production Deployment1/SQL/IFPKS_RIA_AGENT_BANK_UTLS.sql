CREATE OR REPLACE PACKAGE BODY IFPKS_RIA_AGENT_BANK_UTLS AS

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdriaft_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  PROCEDURE PR_INSERT_XML_DATA_DTLS(P_COUNTRY_CODE IN VARCHAR2,
                                    P_XML_TYPE     IN XMLTYPE) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    INSERT INTO test_xml_data VALUES (P_COUNTRY_CODE, P_XML_TYPE);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_XML_DATA_DTLS');
      DBG('ERROR CODE IN PR_INSERT_XML_DATA_DTLS=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_XML_DATA_DTLS=' || SQLERRM);
  END PR_INSERT_XML_DATA_DTLS;

  PROCEDURE PR_DELETE_XML_DATA_DTLS(P_COUNTRY_CODE IN VARCHAR2) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    DELETE FROM test_xml_data A WHERE A.COUNTRY_CODE = P_COUNTRY_CODE;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_DELETE_XML_DATA_DTLS');
      DBG('ERROR CODE IN PR_DELETE_XML_DATA_DTLS=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_DELETE_XML_DATA_DTLS=' || SQLERRM);
  END PR_DELETE_XML_DATA_DTLS;

  PROCEDURE PR_INSERT_BANK_LIST AS
  
    req     utl_http.req;
    res     utl_http.resp;
    url     varchar2(4000) := 'http://integration-uat.princeplc.com.kh/prnc-app/ria/api/v1/obnd/pre-store?countryCode=$COUNTRY_CODE';
    url1    varchar2(4000);
    name    varchar2(4000);
    buffer  varchar2(32767);
    buffer1 clob;
    buffer2 clob;
    content varchar2(4000) := '{}';
  
    TYPE TYPE_RIA_BANK_LIST IS TABLE OF IFTB_RIA_BANK_DTLS1%ROWTYPE;
    L_RIA_BANK_LIST TYPE_RIA_BANK_LIST;
  
    TYPE TYPE_RIA_AGENT_LIST IS TABLE OF IFTB_RIA_AGENT_DTLS1%ROWTYPE;
    L_RIA_AGENT_LIST TYPE_RIA_AGENT_LIST;
  
    CURSOR C1 IS
   /*   SELECT COUNTRY_CODE
        FROM STTM_COUNTRY
       WHERE RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
            --AND COUNTRY_CODE NOT IN (SELECT DISTINCT COUNTRY_CODE FROM IFTB_RIA_BANK_DTLS);
         AND COUNTRY_CODE = 'UK';*/
         
          SELECT DISTINCT COUNTRY_CODE
        FROM iftb_ria_country_currencies
       WHERE --RECORD_STAT = 'O'
      --   AND AUTH_STAT = 'A'
            --AND COUNTRY_CODE NOT IN (SELECT DISTINCT COUNTRY_CODE FROM IFTB_RIA_BANK_DTLS);
         --AND 
         COUNTRY_CODE = 'UK';
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
  BEGIN
  
    FOR G IN C1 LOOP
      BEGIN
        Debug.Pr_Debug('IF', 'COUNTRY CODE=' || G.COUNTRY_CODE);
      
        content := replace(content, chr(49824), ' ');
      
        url1 := replace(url, '$COUNTRY_CODE', G.COUNTRY_CODE);
      
        DBG('url1=' || url1);
      
        --req := utl_http.begin_request(url);
        req := utl_http.begin_request(url1, 'GET', ' HTTP/1.1');
        utl_http.set_authentication(req, 'prince', 'qwer!@#$', 'Basic');
        utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
        utl_http.set_header(req, 'content-type', 'application/json');
        utl_http.set_header(req, 'Content-Length', length(content));
      
        --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
      
        Debug.Pr_Debug('IF', 'content=' || content);
      
        utl_http.write_text(req, content);
      
        UTL_HTTP.WRITE_RAW(req, UTL_RAW.CAST_TO_RAW(content));
      
        res := utl_http.get_response(req);
      
        Debug.Pr_Debug('IF', 'status code=' || res.status_code);
      
        IF res.status_code = '200' THEN
          -- process the response from the HTTP call
          begin
            loop
              utl_http.read_line(res, buffer);
              --Debug.Pr_Debug('IF',buffer);
              buffer1 := buffer1 || buffer;
            end loop;
            utl_http.end_response(res);
          exception
            when utl_http.end_of_body then
              utl_http.end_response(res);
            
            WHEN utl_http.too_many_requests THEN
              utl_http.end_response(res);
            
            when others then
              Debug.Pr_Debug('IF', 'ERROR CODE=' || SQLCODE);
              Debug.Pr_Debug('IF', 'ERROR MESSAGE=' || SQLERRM);
          end;
        
          Debug.Pr_Debug('IF', 'buffer1=' || buffer1);
        
          buffer2 := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(buffer1);
          Debug.Pr_Debug('IF', 'buffer2=' || buffer2);
        
          --Get list of bank ids and names
          BEGIN
            WITH t(xml) AS
             (SELECT xmltype(buffer2) FROM DUAL)
            SELECT x.*
              BULK COLLECT
              INTO L_RIA_BANK_LIST
              FROM t,
                   xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                          "nq1"),
                            '/root/data/BankDeposit/Banks/Bank' passing
                            t.xml columns BANK_ID varchar2(50) PATH 'BankID',
                            BANK_NAME varchar2(50) PATH 'BankName') x;
          
          EXCEPTION
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('IF',
                             'ERROR CODE OF WITH CLAUSE OF BANK LIST=' ||
                             SQLCODE);
              DEBUG.PR_DEBUG('IF',
                             'ERROR MESSAGE OF WITH CLAUSE OF BANK LIST=' ||
                             SQLERRM);
          END;
          Debug.Pr_Debug('IF', 'COUNT=' || L_RIA_BANK_LIST.COUNT);
        
          --Parse Required Fields
          IF L_RIA_BANK_LIST.COUNT > 0 THEN
            BEGIN
              FOR K IN 1 .. L_RIA_BANK_LIST.COUNT LOOP
              
                Debug.Pr_Debug('IF',
                               'BANK_ID=' || L_RIA_BANK_LIST(K).BANK_ID || ' ' ||
                               'BANK_NAME=' || L_RIA_BANK_LIST(K).BANK_NAME);
              
                --INSERT INTO BANK LIST TABLE
              
                INSERT INTO IFTB_RIA_BANK_DTLS
                  (COUNTRY_CODE, BANK_ID, BANK_NAME)
                VALUES
                  (G.COUNTRY_CODE,
                   L_RIA_BANK_LIST(K).BANK_ID,
                   L_RIA_BANK_LIST(K).BANK_NAME);
              
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
                DBG('ERROR CODE=' || SQLCODE);
                DBG('ERROR MESSAGE=' || SQLERRM);
            END;
          
          END IF;
        
          --Get list of agent ids and names
          BEGIN
            WITH t(xml) AS
             (SELECT xmltype(buffer2) FROM DUAL)
            SELECT x.*
              BULK COLLECT
              INTO L_RIA_AGENT_LIST
              FROM t,
                   xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                          "nq1"),
                            '/root/data/OfficePickUp/OpenNetwork/Correspondents'
                            passing t.xml columns CORRESPONDENT_ID
                            varchar2(2000) PATH 'Name',
                            CORRESPONDENT_NAME varchar2(2000) PATH 'ID') x;
          EXCEPTION
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('IF',
                             'ERROR CODE OF WITH CLAUSE OF AGENT LIST=' ||
                             SQLCODE);
              DEBUG.PR_DEBUG('IF',
                             'ERROR MESSAGE OF WITH CLAUSE OF AGENT LIST=' ||
                             SQLERRM);
          END;
          --Debug.Pr_Debug('IF','COUNT='||L_RIA_AGENT_LIST.COUNT);
        
          --Parse Required Fields
          IF L_RIA_AGENT_LIST.COUNT > 0 THEN
            BEGIN
              FOR K IN 1 .. L_RIA_AGENT_LIST.COUNT LOOP
              
                Debug.Pr_Debug('IF',
                               'CORRESPONDENT_ID=' || L_RIA_AGENT_LIST(K)
                               .CORRESPONDENT_NAME || ' ' ||
                                'CORRESPONDENT_NAME=' || L_RIA_AGENT_LIST(K)
                               .CORRESPONDENT_ID);
              
                --INSERT INTO BANK LIST TABLE
              
                INSERT INTO IFTB_RIA_AGENT_DTLS
                  (COUNTRY_CODE, CORRESPONDENT_ID, CORRESPONDENT_NAME)
                VALUES
                  (G.COUNTRY_CODE,
                   L_RIA_AGENT_LIST(K).CORRESPONDENT_NAME,
                   L_RIA_AGENT_LIST(K).CORRESPONDENT_ID);
              
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
                DBG('ERROR CODE=' || SQLCODE);
                DBG('ERROR MESSAGE=' || SQLERRM);
            END;
          
          END IF;
        
          buffer1 := null;
          buffer2 := null;
        
        ELSE
          buffer1 := null;
          buffer2 := null;
          --CONTINUE;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          buffer1 := null;
          buffer2 := null;
          CONTINUE;
      END;
    
    END LOOP;
  
  END PR_INSERT_BANK_LIST;

  PROCEDURE PR_INSERT_BANK_LIST_OVD AS
  
    req     utl_http.req;
    res     utl_http.resp;
    url     varchar2(4000) := 'http://integration-uat.princeplc.com.kh/prnc-app/ria/api/v1/obnd/pre-store?countryCode=$COUNTRY_CODE';
    url1    varchar2(4000);
    name    varchar2(4000);
    buffer  varchar2(32767);
    buffer1 clob;
    buffer2 clob;
    content varchar2(4000) := '{}';
  
    TYPE TYPE_RIA_BANK_LIST IS TABLE OF IFTB_RIA_BANK_DTLS1%ROWTYPE;
    L_RIA_BANK_LIST TYPE_RIA_BANK_LIST;
  
    TYPE TYPE_RIA_AGENT_LIST IS TABLE OF IFTB_RIA_AGENT_DTLS1%ROWTYPE;
    L_RIA_AGENT_LIST TYPE_RIA_AGENT_LIST;
  
    TYPE TYPE_RIA_ONLY_CCY IS TABLE OF IFTB_RIA_ONLY_CCY%ROWTYPE;
    L_RIA_ONLY_CCY TYPE_RIA_ONLY_CCY;
  
    TYPE TYPE_IFTB_RIA_AGENT_CCY_DTLS1 IS TABLE OF IFTB_RIA_AGENT_CCY_DTLS1%ROWTYPE;
    L_IFTB_RIA_AGENT_CCY_DTLS1 TYPE_IFTB_RIA_AGENT_CCY_DTLS1;
  
    CURSOR C1 IS
    SELECT DISTINCT COUNTRY_CODE
        FROM iftb_ria_country_currencies
       WHERE --RECORD_STAT = 'O'
      --   AND AUTH_STAT = 'A'
            --AND COUNTRY_CODE NOT IN (SELECT DISTINCT COUNTRY_CODE FROM IFTB_RIA_BANK_DTLS);
         --AND 
         COUNTRY_CODE = 'UK';
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_GEN_SEQ_NO   VARCHAR2(100);
  
  BEGIN
  
    FOR G IN C1 LOOP
      BEGIN
        Debug.Pr_Debug('IF', 'COUNTRY CODE=' || G.COUNTRY_CODE);
      
        content := replace(content, chr(49824), ' ');
      
        url1 := replace(url, '$COUNTRY_CODE', G.COUNTRY_CODE);
      
        DBG('url1=' || url1);
      
        --req := utl_http.begin_request(url);
        req := utl_http.begin_request(url1, 'GET', ' HTTP/1.1');
        utl_http.set_authentication(req, 'prince', 'qwer!@#$', 'Basic');
        utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
        utl_http.set_header(req, 'content-type', 'application/json');
        utl_http.set_header(req, 'Content-Length', length(content));
      
        --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
      
        Debug.Pr_Debug('IF', 'content=' || content);
      
        utl_http.write_text(req, content);
      
        UTL_HTTP.WRITE_RAW(req, UTL_RAW.CAST_TO_RAW(content));
      
        res := utl_http.get_response(req);
      
        Debug.Pr_Debug('IF', 'status code=' || res.status_code);
      
        IF res.status_code = '200' THEN
          -- process the response from the HTTP call
          begin
            loop
              utl_http.read_line(res, buffer);
              --Debug.Pr_Debug('IF',buffer);
              buffer1 := buffer1 || buffer;
            end loop;
            utl_http.end_response(res);
          exception
            when utl_http.end_of_body then
              utl_http.end_response(res);
            
            WHEN utl_http.too_many_requests THEN
              utl_http.end_response(res);
            
            when others then
              Debug.Pr_Debug('IF', 'ERROR CODE=' || SQLCODE);
              Debug.Pr_Debug('IF', 'ERROR MESSAGE=' || SQLERRM);
          end;
        
          Debug.Pr_Debug('IF', 'buffer1=' || buffer1);
        
          buffer2 := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(buffer1);
          Debug.Pr_Debug('IF', 'buffer2=' || buffer2);
        
          --Get list of currencies
          BEGIN
            WITH t(xml) AS
             (SELECT xmltype(buffer2) FROM DUAL)
            SELECT x.*
              BULK COLLECT
              INTO L_RIA_ONLY_CCY
              FROM t,
                   xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                          "nq1"),
                            '/root/data/BankDeposit/Banks/Currency/Currency'
                            passing t.xml columns CURRENCY varchar2(50) PATH
                            'Code') x;
          
          EXCEPTION
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('IF',
                             'ERROR CODE OF WITH CLAUSE OF BANK LIST=' ||
                             SQLCODE);
              DEBUG.PR_DEBUG('IF',
                             'ERROR MESSAGE OF WITH CLAUSE OF BANK LIST=' ||
                             SQLERRM);
          END;
          Debug.Pr_Debug('IF', 'COUNT=' || L_RIA_ONLY_CCY.COUNT);
        
          --Parse Required Fields
          IF L_RIA_ONLY_CCY.COUNT > 0 THEN
            BEGIN
              FOR K IN 1 .. L_RIA_ONLY_CCY.COUNT LOOP
              
                Debug.Pr_Debug('IF',
                               'CURRENCY=' || L_RIA_ONLY_CCY(K).CURRENCY);
              
                --INSERT INTO BANK LIST TABLE
              
                INSERT INTO IFTB_RIA_CCY_DTLS
                  (COUNTRY_CODE, INDICATOR, CURRENCY)
                VALUES
                  (G.COUNTRY_CODE, 'D', L_RIA_ONLY_CCY(K).CURRENCY);
              
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
                DBG('ERROR CODE=' || SQLCODE);
                DBG('ERROR MESSAGE=' || SQLERRM);
            END;
          
          END IF;
        
          --insert into
        
          /*  insert into test_xml_data
          values
            (g.country_code, XMLTYPE.createXML(buffer2));*/
        
          PR_INSERT_XML_DATA_DTLS(g.country_code,
                                  XMLTYPE.createXML(buffer2));
        
          --Get list of agent ids and names
          BEGIN
            /*WITH t(xml) AS
             (SELECT xmltype(buffer2) FROM DUAL)
            SELECT x.*
              BULK COLLECT
              INTO L_IFTB_RIA_AGENT_CCY_DTLS1
              FROM t,
                   xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                          "nq1"),
                            '/root/data/OfficePickUp/OpenNetwork/Correspondents'
                            passing t.xml columns AGENT_ID varchar2(2000) PATH
                            'Name',
                            AGENT_NAME varchar2(2000) PATH 'ID',
                            CURRENCY varchar2(100) PATH '/Currency/Code') x;  */
          
            INSERT INTO IFTB_RIA_AGENT_CCY_DTLS
              (AGENT_NAME, AGENT_ID, CURRENCY)
              WITH agent_data AS
               (SELECT xt.*
                  FROM test_xml_data x,
                       XMLTABLE('root/data/OfficePickUp/OpenNetwork/Correspondents'
                                PASSING x.payload COLUMNS agent_name
                                VARCHAR2(255) PATH 'Name',
                                agent_id VARCHAR2(255) PATH 'ID',
                                Currencies XMLTYPE PATH 'Currency') xt),
              
              agent_ccy_data AS
               (SELECT agent_name, agent_id, xt2.*
                  FROM agent_data dd,
                       XMLTABLE('/Currency' PASSING dd.Currencies COLUMNS Code
                                VARCHAR2(4) PATH 'Code') xt2)
              SELECT * FROM agent_ccy_data;
          
          EXCEPTION
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('IF',
                             'ERROR CODE OF WITH CLAUSE OF AGENT LIST=' ||
                             SQLCODE);
              DEBUG.PR_DEBUG('IF',
                             'ERROR MESSAGE OF WITH CLAUSE OF AGENT LIST=' ||
                             SQLERRM);
          END;
          --Debug.Pr_Debug('IF','COUNT='||L_RIA_AGENT_LIST.COUNT);
        
          --Parse Required Fields
          /*IF L_IFTB_RIA_AGENT_CCY_DTLS1.COUNT > 0 THEN
            BEGIN
              FOR K IN 1 .. L_IFTB_RIA_AGENT_CCY_DTLS1.COUNT LOOP
              
                Debug.Pr_Debug('IF',
                               'AGENT_ID=' || L_IFTB_RIA_AGENT_CCY_DTLS1(K)
                               .AGENT_ID || ' ' || 'AGENT_NAME=' || L_IFTB_RIA_AGENT_CCY_DTLS1(K)
                               .AGENT_NAME || ' ' || 'CURRENCY=' || L_IFTB_RIA_AGENT_CCY_DTLS1(K)
                               .CURRENCY);
              
                --INSERT INTO BANK LIST TABLE
              
                INSERT INTO IFTB_RIA_AGENT_CCY_DTLS
                  (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
                VALUES
                  (G.COUNTRY_CODE,
                   'C',
                   L_IFTB_RIA_AGENT_CCY_DTLS1(K).AGENT_ID,
                   L_IFTB_RIA_AGENT_CCY_DTLS1(K).AGENT_NAME,
                   L_IFTB_RIA_AGENT_CCY_DTLS1(K).CURRENCY);
              
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
                DBG('ERROR CODE=' || SQLCODE);
                DBG('ERROR MESSAGE=' || SQLERRM);
            END;
          
          END IF;*/
        
          UPDATE IFTB_RIA_AGENT_CCY_DTLS A
             SET A.COUNTRY_CODE = G.COUNTRY_CODE, A.INDICATOR = 'C'
           where A.COUNTRY_CODE is null
             and A.Indicator is null;
        
          --IF SQL%ROWCOUNT > 1 THEN
        
          --DELETE FROM test_xml_data WHERE COUNTRY_CODE = G.COUNTRY_CODE;
        
          PR_DELETE_XML_DATA_DTLS(g.country_code);
        
          --END IF;
        
          buffer1 := null;
          buffer2 := null;
        
        ELSE
          buffer1 := null;
          buffer2 := null;
          --CONTINUE;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          buffer1 := null;
          buffer2 := null;
          CONTINUE;
      END;
    
    END LOOP;
  
  END PR_INSERT_BANK_LIST_OVD;

  FUNCTION FN_CHECK_OPEN_PAYMENT(P_COUNTRY_CODE IN VARCHAR2,
                                 P_ERR_CODE     IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  
    req     utl_http.req;
    res     utl_http.resp;
    url     varchar2(4000) := 'http://integration-uat.princeplc.com.kh/prnc-app/ria/api/v1/obnd/pre-store?countryCode=$COUNTRY_CODE';
    url1    varchar2(4000);
    name    varchar2(4000);
    buffer  varchar2(32767);
    buffer1 clob;
    buffer2 clob;
    content varchar2(4000) := '{}';
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_RESP_IN_XML             CLOB;
    P_DOCUMENT_XML            XMLTYPE;
    l_cashpickup_open_payment VARCHAR2(25);
  
  BEGIN
  
    Debug.Pr_Debug('IF', 'COUNTRY CODE=' || P_COUNTRY_CODE);
  
    content := replace(content, chr(49824), ' ');
  
    url1 := replace(url, '$COUNTRY_CODE', P_COUNTRY_CODE);
  
    DBG('url1=' || url1);
  
    --req := utl_http.begin_request(url);
    req := utl_http.begin_request(url1, 'GET', ' HTTP/1.1');
    utl_http.set_authentication(req, 'prince', 'qwer!@#$', 'Basic');
    utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(req, 'content-type', 'application/json');
    utl_http.set_header(req, 'Content-Length', length(content));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    Debug.Pr_Debug('IF', 'content=' || content);
  
    utl_http.write_text(req, content);
  
    UTL_HTTP.WRITE_RAW(req, UTL_RAW.CAST_TO_RAW(content));
  
    res := utl_http.get_response(req);
  
    Debug.Pr_Debug('IF', 'status code=' || res.status_code);
  
    IF res.status_code = '200' THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(res, buffer);
          --Debug.Pr_Debug('IF',buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(res);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(res);
        
        WHEN utl_http.too_many_requests THEN
          utl_http.end_response(res);
        
        when others then
          Debug.Pr_Debug('IF', 'ERROR CODE=' || SQLCODE);
          Debug.Pr_Debug('IF', 'ERROR MESSAGE=' || SQLERRM);
      end;
    
      Debug.Pr_Debug('IF', 'buffer1=' || buffer1);
    
      buffer2 := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(buffer1);
      Debug.Pr_Debug('IF', 'buffer2=' || buffer2);
    
      buffer2 := FN_CLOBREPLACE(buffer2, '&lt;', '<');
      DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || buffer2);
    
      buffer2 := FN_CLOBREPLACE(buffer2, '&gt;', '>');
      DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || buffer2);
    
      DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || buffer2);
    
      P_DOCUMENT_XML := XMLTYPE(buffer2);
    
      L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/code/text()')
                       .GETSTRINGVAL;
    
      L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/message/text()')
                      .GETSTRINGVAL;
    
      DBG('L_STATUS_CODE =' || L_STATUS_CODE);
      DBG('L_STATUS_MSG =' || L_STATUS_MSG);
    
      IF L_STATUS_CODE <> '000' THEN
      
        p_err_code := 'IF-RIA-000';
      
        OVPKSS.PR_APPENDTBL(p_err_code, L_STATUS_MSG || '~');
      
        RETURN FALSE;
      
      END IF;
    
      IF L_STATUS_CODE = '000' AND L_STATUS_MSG = 'success' THEN
      
        l_cashpickup_open_payment := P_DOCUMENT_XML.EXTRACT('/root/data/OfficePickUp/OpenPayment/Available/text()')
                                     
                                     .GETSTRINGVAL;
      
        DBG('l_cashpickup_open_payment =' || l_cashpickup_open_payment);
      
        IF l_cashpickup_open_payment = 'false' THEN
        
          RETURN FALSE;
        
        ELSE
        
          RETURN TRUE;
        
        END IF;
      
        RETURN FALSE;
      
      END IF;
    
      --buffer1 := null;
    
    END IF;
  
    RETURN FALSE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_CHECK_OPEN_PAYMENT');
      DBG('ERROR CODE IN FN_CHECK_OPEN_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_CHECK_OPEN_PAYMENT=' || SQLERRM);
      RETURN FALSE;
  END FN_CHECK_OPEN_PAYMENT;

END IFPKS_RIA_AGENT_BANK_UTLS;
