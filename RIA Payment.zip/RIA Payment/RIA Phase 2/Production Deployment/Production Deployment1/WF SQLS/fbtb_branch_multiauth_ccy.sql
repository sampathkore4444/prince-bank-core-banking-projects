insert into fbtb_branch_multiauth_ccy (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'RIAC', 'KHR');

insert into fbtb_branch_multiauth_ccy (BRANCH_CODE, FUNCTION_GROUP, CCY_CODE)
values ('ALL', 'RIAC', 'USD');

COMMIT;
