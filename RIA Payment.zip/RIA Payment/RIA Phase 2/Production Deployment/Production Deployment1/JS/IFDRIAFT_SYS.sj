/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2022, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : IFDRIAFT_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = 'N';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_MASTER":"TRN_REF_NO~TXN_CCY~TXN_AMOUNT~DR_ACC_NO~DR_ACC_CCY~DR_AMOUNT~CR_ACC_NO~CR_ACC_CCY~CR_AMOUNT~PAYMNT_DATE~EXCH_RATE~NARRATIVE~PAYIN_CORR_ID~SENDING_CORR_ID~DELIVERY_METHOD~BEN_COUNTRY~BEN_CNT_CCY~BEN_FIRSTNAME~BEN_LASTNAME~BEN_CITY~BEN_STATE~BANK_ID~BANK_ACCOUNT_NO~BANK_ACCOUNT_TYPE~DR_ACC_NAME~TXN_UNIQUE_NO~RIA_REFERENCE_NO~ORDER_NO~RIA_ORDER_NO~RIA_PIN~RIA_PAY_STATUS~TOT_CHG_AMT~NET_TXN_AMT~RIA_RECEIVING_AMT~RIA_EXCHANGE_RATE~PURPOSE_OF_TRANSFER~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH","BLK_CHILD":"FIELD_NAME~FIELD_VALUE","BLK_CHARGE":"TRN_REF_NO~CHG_SRNO~CHG1_DESC~CHG1_WAIVER~CHG1_AMT~CHG1_CCY~LCY_CHG1~FCY_CHG1~CHG1_GL~CHG2_DESC~CHG2_WAIVER~CHG2_AMT~CHG2_CCY~LCY_CHG2~FCY_CHG2~CHG2_GL~CHG3_DESC~CHG3_WAIVER~CHG3_AMT~CHG3_CCY~LCY_CHG3~FCY_CHG3~CHG3_GL~NETTING_REQ~XRATE~TXN_CODE~CHG1_TYPE~CHG1_IN_TXN~CHG1_IN_ACC~CHG2_TYPE~CHG2_IN_TXN~CHG2_IN_ACC~CHG3_TYPE~CHG3_IN_TXN~CHG3_IN_ACC~OTH_CCY~TXN_XRATE~ACC_XRATE"};

var multipleEntryPageSize = {"BLK_CHILD" :"15" };

var multipleEntrySVBlocks = "";

var tabMEBlks = {"CVS_MAIN__TAB_MAIN":"BLK_CHILD"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_MASTER">TRN_REF_NO~TXN_CCY~TXN_AMOUNT~DR_ACC_NO~DR_ACC_CCY~DR_AMOUNT~CR_ACC_NO~CR_ACC_CCY~CR_AMOUNT~PAYMNT_DATE~EXCH_RATE~NARRATIVE~PAYIN_CORR_ID~SENDING_CORR_ID~DELIVERY_METHOD~BEN_COUNTRY~BEN_CNT_CCY~BEN_FIRSTNAME~BEN_LASTNAME~BEN_CITY~BEN_STATE~BANK_ID~BANK_ACCOUNT_NO~BANK_ACCOUNT_TYPE~DR_ACC_NAME~TXN_UNIQUE_NO~RIA_REFERENCE_NO~ORDER_NO~RIA_ORDER_NO~RIA_PIN~RIA_PAY_STATUS~TOT_CHG_AMT~NET_TXN_AMT~RIA_RECEIVING_AMT~RIA_EXCHANGE_RATE~PURPOSE_OF_TRANSFER~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH</FN>'; 
msgxml += '      <FN PARENT="BLK_MASTER" RELATION_TYPE="N" TYPE="BLK_CHILD">FIELD_NAME~FIELD_VALUE</FN>'; 
msgxml += '      <FN PARENT="BLK_MASTER" RELATION_TYPE="N" TYPE="BLK_CHARGE">TRN_REF_NO~CHG_SRNO~CHG1_DESC~CHG1_WAIVER~CHG1_AMT~CHG1_CCY~LCY_CHG1~FCY_CHG1~CHG1_GL~CHG2_DESC~CHG2_WAIVER~CHG2_AMT~CHG2_CCY~LCY_CHG2~FCY_CHG2~CHG2_GL~CHG3_DESC~CHG3_WAIVER~CHG3_AMT~CHG3_CCY~LCY_CHG3~FCY_CHG3~CHG3_GL~NETTING_REQ~XRATE~TXN_CODE~CHG1_TYPE~CHG1_IN_TXN~CHG1_IN_ACC~CHG2_TYPE~CHG2_IN_TXN~CHG2_IN_ACC~CHG3_TYPE~CHG3_IN_TXN~CHG3_IN_ACC~OTH_CCY~TXN_XRATE~ACC_XRATE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR SUMMARY SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml_sum=""; 
msgxml_sum += '    <FLD>'; 
msgxml_sum += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_MASTER">AUTHSTAT~TXNSTAT~TRN_REF_NO~DR_ACC_NO~DR_ACC_CCY~PAYMNT_DATE~DELIVERY_METHOD~TXN_UNIQUE_NO~RIA_REFERENCE_NO~ORDER_NO~RIA_ORDER_NO~RIA_PIN</FN>'; 
msgxml_sum += '    </FLD>'; 

var detailFuncId = "IFDRIAFT";
var defaultWhereClause = "";
var defaultOrderByClause ="";
var multiBrnWhereClause ="";
var g_SummaryType ="S";
var g_SummaryBtnCount =0;
var g_SummaryBlock ="BLK_MASTER";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_MASTER" : "","BLK_CHILD" : "BLK_MASTER~N","BLK_CHARGE" : "BLK_MASTER~N"}; 

 var dataSrcLocationArray = new Array("BLK_MASTER","BLK_CHILD","BLK_CHARGE"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside IFDRIAFT.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside IFDRIAFT.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_MASTER__TRN_REF_NO";
pkFields[0] = "BLK_MASTER__TRN_REF_NO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_MASTER__DR_ACC_NO__LOV_DEBIT_ACC":["BLK_MASTER__DR_ACC_NO~BLK_MASTER__DR_ACC_NAME~BLK_MASTER__DR_ACC_CCY~","","N~N~N",""],"BLK_MASTER__PAYIN_CORR_ID__LOV_PAYIN_CORR_ID":["BLK_MASTER__PAYIN_CORR_ID~~~","BLK_MASTER__BEN_COUNTRY!","N~N~N","N"],"BLK_MASTER__BEN_COUNTRY__LOV_COUNTRY_CCY":["BLK_MASTER__BEN_COUNTRY~~","","N~N",""],"BLK_MASTER__BEN_CNT_CCY__LOV_BEN_CURRENCY":["BLK_MASTER__BEN_CNT_CCY~","BLK_MASTER__PAYIN_CORR_ID!~BLK_MASTER__BEN_COUNTRY!~BLK_MASTER__DELIVERY_METHOD!~BLK_MASTER__BEN_COUNTRY!~BLK_MASTER__DELIVERY_METHOD!~BLK_MASTER__BEN_COUNTRY!","N",""],"BLK_MASTER__BANK_ID__LOV_BANK_ID":["BLK_MASTER__BANK_ID~~","BLK_MASTER__BEN_COUNTRY!","N~N",""],"BLK_MASTER__BANK_ACCOUNT_TYPE__LOV_BANK_ACC_TYPES":["BLK_MASTER__BANK_ACCOUNT_TYPE~","","N",""],"BLK_MASTER__PURPOSE_OF_TRANSFER__LOV_RIA_PURPOSE_OF_TRF":["BLK_MASTER__PURPOSE_OF_TRANSFER~","","N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_CHILD");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array(); 

 var CallFormRelat=new Array(); 

 var CallRelatType= new Array(); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["IFDRIAFT"]="CUSTOM";
ArrPrntFunc["IFDRIAFT"]="";
ArrPrntOrigin["IFDRIAFT"]="";
ArrRoutingType["IFDRIAFT"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["IFDRIAFT"]="N";
ArrCustomModified["IFDRIAFT"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {};
var scrArgSource = {};
var scrArgVals = {};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------