function fnPostNew_CUSTOM() {
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = mainWin.Lcy;
	 document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	  document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; //12.0.2_17077363
    //document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'RIA Withdrawal'; 
	try{
	document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").getAttribute("DEFAULT"); 
	}catch(e){}

    if (dataObj.twoStepProcess == 'Y' && dataObj.firstStepDone == 'Y') {
        document.getElementById("BLK_TRANSACTION_DETAILS__PRD").value = 'CHW2';
    }
    return true;

}

function fnAssignTxnCcy(p_acc_ccy) {
    document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = p_acc_ccy.value;
    return true;
}

function fnAccCcy(event) {
    if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != "") {
        fnDisableElement(document.getElementsByName("TXNCCY")[0]);
    }
    return true;
}

function fnPostLoad_CUSTOM(e) {
	 document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	  document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; //12.0.2_17077363
    if (dataObj.twoStepProcess == 'Y' && dataObj.firstStepDone == 'Y') {
        document.getElementById("BLK_TRANSACTION_DETAILS__PRD").value = 'CHW2';
    }
    var txnAcc = mainWin.functionDef[functionId].txnAcc;
    var txnAccBlock = txnAcc.split("__")[0];
    var txnAccTag = txnAcc.split("__")[1];
    try {
        pickedUpAcc = getNodeText(selectSingleNode(dbDataDOM, "//" + txnAccBlock + '/' + txnAccTag));
        pickedUpCcy = getNodeText(selectSingleNode(dbDataDOM, "//" + 'BLK_TRANSACTION_DETAILS/OFFSETCCY'));
    }
    catch (e) {
    }
    return true;
}



function fnAmountF12_CUSTOM(addlArgs,e ) {  

try {
	var a = 'BLK_TRANSACTION_DETAILS__TXNCCY' ;
    var b = 'BLK_TRANSACTION_DETAILS__OFFSETCCY';
	var c = 'BLK_TRANSACTION_DETAILS__OFFSETAMT' ;
	var d = 'BLK_TRANSACTION_DETAILS__TXNAMT' ; 

				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}

function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;
	
    if (eventElement.name == 'UI_TXN_ACC' || eventElement.name == 'OFFSETCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').oldvalue = "";
  if(eventElement.name == 'UI_TXN_ACC'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'M'))

		{
			gViraccno = false;

			document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(eventElement.id).value;
		}

            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M') {
					gViraccno = true; 
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
       // }
    }
    }
      return true;
}


function fnDisableIfPrince(){

if (document.getElementById("BLK_TRANSACTION_DETAILS__PRINCE_CUSTOMER").checked == true){
		
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__UID_EXPIRY_DATE"));
                fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_NAME")); 
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_BIRTH_COUNTRY"));
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_NATIONALITY"));
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_ADDR_CODE"));
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_PROVINCE"));
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_DISTRICT"));
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_VILLAGE_COMM"));
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_ADDR_4"));
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_ADDR_COUNTRY"));
		fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__BENEF_OCCUPATION"));

	}


}

