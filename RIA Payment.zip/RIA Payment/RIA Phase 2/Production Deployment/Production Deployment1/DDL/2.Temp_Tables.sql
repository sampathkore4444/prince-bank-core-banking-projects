-- Create table
create table TEST_XML_DATA
(
  COUNTRY_CODE VARCHAR2(3),
  payload      XMLTYPE
)
/
alter table TEST_XML_DATA add primary key (COUNTRY_CODE)
/
-- Create table
create table TEST_XML_DATA_RIA_ENQ_TEMP
(
  trn_ref_no VARCHAR2(16) not null,
  payload    XMLTYPE
)
/
alter table TEST_XML_DATA_RIA_ENQ_TEMP add primary key (TRN_REF_NO)
/
-- Create table
create table TEST_XML_DATA_RIA_ENQ_FLD_LEN1
(
  field_name VARCHAR2(105),
  min_length NUMBER,
  max_length NUMBER
)
/