-- Create sequence 
create sequence FC_CORAL_RIA_WS_CALL_LOG_ID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle
/
-- Create sequence 
create sequence TRSQ_RIA_SEQID
minvalue 1
maxvalue 999999999
start with 1
increment by 1
nocache
cycle
/