prompt Importing table iftb_ria_ccy_dtls...
set feedback off
set define off
insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('AE', 'D', 'AED');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('AL', 'D', 'ALL');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('AR', 'D', 'ARS');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('AU', 'D', 'AUD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BA', 'D', 'BAM');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BD', 'D', 'BDT');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BE', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BF', 'D', 'XOF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BG', 'D', 'BGN');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BG', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BJ', 'D', 'XOF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BO', 'D', 'BOB');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BO', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BO', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('BR', 'D', 'BRL');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CA', 'D', 'CAD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CH', 'D', 'CHF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CH', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CI', 'D', 'XOF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CL', 'D', 'CLP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CM', 'D', 'XAF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CN', 'D', 'CNY');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CO', 'D', 'COP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CR', 'D', 'CRC');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CR', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('CY', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('DE', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('DO', 'D', 'DOP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('DO', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('EC', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('EC', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('EE', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('EG', 'D', 'EGP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('EG', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('EG', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ES', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ET', 'D', 'ETB');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('FI', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('FR', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GA', 'D', 'XAF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GD', 'D', 'XCD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GE', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GE', 'D', 'GEL');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GE', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GH', 'D', 'GHS');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GI', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GI', 'D', 'GBP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GM', 'D', 'GMD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GN', 'D', 'GNF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GR', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GT', 'D', 'GTQ');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GT', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GW', 'D', 'XOF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('GY', 'D', 'GYD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HK', 'D', 'HKD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HN', 'D', 'HNL');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HN', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HR', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HR', 'D', 'HRK');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HT', 'D', 'HTG');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HT', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HU', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('HU', 'D', 'HUF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ID', 'D', 'IDR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ID', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('IE', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('IL', 'D', 'ILS');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('IN', 'D', 'INR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('IS', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('IT', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('JM', 'D', 'JMD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('JO', 'D', 'JOD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('JP', 'D', 'JPY');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('KE', 'D', 'KES');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('KH', 'D', 'KHR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('KH', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('KM', 'D', 'KMF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('KR', 'D', 'KRW');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LA', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LK', 'D', 'AUD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LK', 'D', 'CAD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LK', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LK', 'D', 'GBP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LK', 'D', 'LKR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LK', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LR', 'D', 'LRD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LR', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LT', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LT', 'D', 'GBP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LT', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LU', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('LV', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MA', 'D', 'MAD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ML', 'D', 'XOF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MM', 'D', 'MMK');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MM', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MN', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MN', 'D', 'MNT');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MN', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MX', 'D', 'MXN');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MY', 'D', 'MYR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MY', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MZ', 'D', 'MZN');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('MZ', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NE', 'D', 'XOF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NG', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NI', 'D', 'GTQ');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NI', 'D', 'HNL');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NI', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NL', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NO', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NO', 'D', 'NOK');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NP', 'D', 'NPR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('NZ', 'D', 'NZD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PE', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PE', 'D', 'PEN');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PE', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PH', 'D', 'PHP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PH', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PK', 'D', 'PKR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PL', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PL', 'D', 'PLN');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PT', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PY', 'D', 'CLP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PY', 'D', 'PYG');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PY', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('PY', 'D', 'UYU');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('RO', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('RO', 'D', 'RON');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('RS', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('RS', 'D', 'RSD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('RU', 'D', 'RUB');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('RW', 'D', 'RWF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SE', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SE', 'D', 'SEK');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SG', 'D', 'SGD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SI', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SL', 'D', 'SLL');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SN', 'D', 'XOF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SR', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SR', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('SV', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TG', 'D', 'XOF');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TH', 'D', 'THB');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TN', 'D', 'TND');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TO', 'D', 'TOP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TR', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TR', 'D', 'TRY');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TR', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TT', 'D', 'TTD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TT', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('TZ', 'D', 'TZS');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UA', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UA', 'D', 'UAH');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UA', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UG', 'D', 'UGX');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UK', 'D', 'EUR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UK', 'D', 'GBP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('US', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UY', 'D', 'CLP');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UY', 'D', 'PYG');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UY', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('UY', 'D', 'UYU');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('VN', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('VN', 'D', 'VND');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('YE', 'D', 'SAR');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('YE', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('YE', 'D', 'YER');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ZM', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ZM', 'D', 'ZMW');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ZW', 'D', 'USD');

insert into iftb_ria_ccy_dtls (COUNTRY_CODE, INDICATOR, CURRENCY)
values ('ZW', 'D', 'ZWD');

prompt Done.
