prompt Importing table iftb_ria_bank_dtls...
set feedback off
set define off
insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40996602', 'AMERICAN EXPRESS BANK LTD', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('612401', 'ASOCIACION DE BANCOS DE LA ARGENTINA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('612501', 'ASOCIACION DE BANCOS DEL INTERIOR DE LA REPUBLICA ', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('704201', 'ASOCIACION DE BANCOS PUBLICOS Y PRIVADOS DE LA REP', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5639101', 'ASOCIACION DE LA BANCA ESPECIALIZADA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339711', 'BANCO BICA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61064802', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5651501', 'BANCO BRADESCO ARGENTINA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3576101', 'BANCO CENTRAL DE LA REPUBLICA ARGENTINA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138211', 'BANCO CIUDAD DE BUENOS AIRES', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4074001', 'BANCO CMF S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339811', 'BANCO COINAG', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2748001', 'BANCO COLUMBIA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5903201', 'BANCO COMAFI S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339911', 'BANCO COMERCIO', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('556701', 'BANCO CREDICOOP COOPERATIVO LIMITADO', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138311', 'BANCO DE CORDOBA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4350301', 'BANCO DE CORRIENTES S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4322701', 'BANCO DE FORMOSA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5912401', 'BANCO DE GALICIA Y BUENOS AIRES S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5358401', 'BANCO DE INVERSION Y COMERCIO EXTERIOR S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3574301', 'BANCO DE LA CIUDAD DE BUENOS AIRES', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217901', 'BANCO DE LA NACION ARGENTINA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4322801', 'BANCO DE LA PAMPA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3102501', 'BANCO DE LA PROVINCIA DE BUENOS AIRES', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2534801', 'BANCO DE LA PROVINCIA DE CORDOBA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32446202', 'BANCO DE LA REPUBLICA ORIENTAL DEL URUGUAY', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4350701', 'BANCO DE SAN JUAN, S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2535101', 'BANCO DE SANTA CRUZ S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5610301', 'BANCO DE SANTIAGO DEL ESTERO S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4428201', 'BANCO DE SERVICIOS Y TRANSACCIONES S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138511', 'BANCO DE TIERRA DEL FUEGO', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5612001', 'BANCO DE VALORES S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3575901', 'BANCO DEL CHUBUT S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5905101', 'BANCO DEL TUCUMAN S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('352711', 'BANCO DINO', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20330255', 'BANCO DINO', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1975901', 'BANCO FINANSUR S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138611', 'BANCO GALICIA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2803701', 'BANCO HIPOTECARIO S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138711', 'BANCO INDUSTRIAL', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20330355', 'BANCO INDUSTRIAL S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('288011', 'BANCO INTERFINANZAS S.A. ', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4078601', 'BANCO ITAU ARGENTINA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69049302', 'BANCO ITAU, S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2803401', 'BANCO JULIO S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4352201', 'BANCO MACRO S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4350601', 'BANCO MARIVA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5740701', 'BANCO MASVENTAS S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5901101', 'BANCO MERIDIAN S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2535201', 'BANCO MUNICIPAL DE ROSARIO', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('314111', 'BANCO NACION ARGENTINA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2491401', 'BANCO PATAGONIA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5896201', 'BANCO PIANO S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2492101', 'BANCO PROVINCIA DE TIERRA DEL FUEGO', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4349601', 'BANCO PROVINCIA DEL NEUQUEN S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2492501', 'BANCO REGIONAL DE CUYO, S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2803601', 'BANCO ROELA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4351901', 'BANCO SAENZ S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138811', 'BANCO SAN JUAN', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('230701', 'BANCO SANTANDER RIO S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138911', 'BANCO SANTIAGO DEL ESTERO', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5883801', 'BANCO SUPERVIELLE S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('340211', 'BANCO VOII S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('340311', 'BBVA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5901001', 'BBVA BANCO FRANCES, S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51747702', 'BNP PARIBAS', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('340011', 'BRUBANK', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('352611', 'BST', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20330455', 'BST', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16309902', 'CITIBANK, N.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3628301', 'DEUTSCHE BANK S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('340111', 'FINANDINO COMPANIA FINANCIERA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('340411', 'HSBC', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('315701', 'HSBC BANK ARGENTINA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('97911', 'ICBC', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49469502', 'INDUSTRIAL AND COMERCIAL BANK', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18052602', 'JPMORGAN CHASE BANK, NATIONAL ASSOCIATION', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4352301', 'NUEVO BANCO DE ENTRE RIOS S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4078701', 'NUEVO BANCO DE LA RIOJA S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4377901', 'NUEVO BANCO DE SANTA FE S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('505101', 'NUEVO BANCO DEL CHACO S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3009201', 'STANDARD BANK ARGENTINA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('287911', 'TRANSATLANTICA SA', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3610901', 'TRANSCAMBIO S.A.', 'AR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3149701', 'AB BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336801', 'AGRANI BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2729101', 'AL-ARAFAH ISLAMI BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123311', 'BANGLADESH BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5756701', 'BANGLADESH COMMERCE BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60211', 'BANGLADESH DEVELOPMENT BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337101', 'BANGLADESH KRISHI BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('443601', 'BANGLADESH SHILPA BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60711', 'BANK AL-FALAH LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2721501', 'BANK ASIA LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3149901', 'BASIC BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4482901', 'BRAC BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60811', 'CITIBANK NA', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('443701', 'CITY BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10811', 'COMMERCIAL BANK OF CEYLON', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2588801', 'DHAKA BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3733101', 'DUTCH-BANGLA BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1537001', 'EASTERN BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10911', 'EXIM BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('124011', 'FARMERS BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3733001', 'FIRST SECURITY ISLAMI BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11011', 'HABIB BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60411', 'HONGKONG & SHANGHAI BANKING CORP', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11111', 'HSBC', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336901', 'ICB ISLAMIC BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337201', 'IFIC BANK LTD.', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337301', 'ISLAMI BANK BANGLADESH LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2776201', 'JAMUNA BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5884501', 'JANATA BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123411', 'MEGHNA BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59711', 'MERCANTILE BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123511', 'MIDLAND BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123611', 'MODHUMOTI BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4445801', 'MUTUAL TRUST BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5890201', 'NATIONAL BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10711', 'NATIONAL BANK OF PAKISTAN', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3641801', 'NATIONAL CREDIT AND COMMERCE BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('124211', 'NRB BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123711', 'NRB COMMERCIAL BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123811', 'NRB GLOBAL BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3733201', 'ONE BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5711701', 'PREMIER BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2588701', 'PRIME BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('443901', 'PUBALI BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('88611', 'RAJSHAHI KRISHI UNAYAN BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5874901', 'RUPALI BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123911', 'SBAC BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5711801', 'SHAHJALAL ISLAMIC BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11211', 'Social Islami Bank', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('444001', 'SONALI BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4445901', 'SOUTHEAST BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4454001', 'STANDARD BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11311', 'STANDARD CHARTERED BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11411', 'STATE BANK OF INDIA', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2777501', 'TRUST BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('124111', 'UNION BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3150101', 'UNITED COMMERCIAL BANK LTD', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('508701', 'UTTARA BANK LIMITED', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60611', 'WOORI BANK', 'BD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335911', '	Banca OTP Albania sh.a', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3690401', 'AMERICAN BANK OF INVESTMENTA S.A', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('900001', 'BANK OF ALBANIA', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4868201', 'CREDIT BANK OF ALBANIA', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1976301', 'INTERNATIONAL COMMERCIAL BANK', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4371301', 'INTESA SANPAOLO BANK ALBANIA', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('22700402', 'NATIONAL BANK OF GREECE, S.A.', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5905401', 'PROCREDIT BANK ALBANIA', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('90611', 'Raiffeisen Bank sh.a', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1976201', 'TIRANA BANK S.A.', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4526701', 'UNION BANK', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5610501', 'UNITED BANK OF ALBANIA', 'AL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1977601', 'ADELAIDE BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5692401', 'AMP BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3574801', 'ARAB BANK AUSTRALIA LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5873601', 'AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3227801', 'AUSTRALIA POST', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('193511', 'AUSTRALIAN MILITARY BANK FORMELY AUSTRALIAN DEFENC', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2781401', 'AUSTRALIAN SETTLEMENTS LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1290101', 'AUSTRALIAN UNITY BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('193611', 'AUSWIDE BANK FORMERLY WIDE BAY BUILDING SOCIETY', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59254302', 'BANK OF AMERICA, NATIONAL ASSOCIATION', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2850001', 'BANK OF CHINA (AUSTRALIA) LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('193811', 'BANK OF MELBOURNE', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5905201', 'BANK OF QUEENSLAND LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('338411', 'BANK OF SYDNEY LTD', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('338511', 'BANKSA A DIVISION OF WESTPAC BANKING CORPORATION', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('338611', 'BANKWEST A DIVISION OF COMMONWEALTH BANK OF AUSTRA', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1971401', 'BENDIGO BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('194511', 'BEYOND BANK AUSTRALIA', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58653002', 'BNP PARIBAS', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16298602', 'CITIBANK, N.A.', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4851901', 'CITIGROUP GLOBAL MARKETS AUSTRALIA PTY LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('367401', 'COMMONWEALTH BANK OF AUSTRALIA', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1404001', 'COMMUNITY FIRST CREDIT UNION', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5051001', 'CREDIT UNION AUSTRALIA LTD', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1405001', 'CUSCAL LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('338711', 'HERITAGE BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4349301', 'HSBC BANK AUSTRALIA LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('195211', 'HUME BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1938301', 'CAISSE DESJARDINS DU CENTRE-SUD DE SHAWINIGAN', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('930301', 'CAISSE DESJARDINS DU COEUR DE LOTBINIERE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4718201', 'CAISSE DESJARDINS DU GRAND-COTEAU', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('782801', 'CAISSE DESJARDINS DU HAUT SHAWINIGAN', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4707701', 'CAISSE DESJARDINS DU HAUT-SAINT-LAURENT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('931401', 'CAISSE DESJARDINS DU LAC DES DEUX-MONTAGNES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1960101', 'CAISSE DESJARDINS DU LAC-MEMPHREMAGOG', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('923301', 'CAISSE DESJARDINS DU MARIGOT DE LAVAL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1959801', 'CAISSE DESJARDINS DU MONT-BELLEVUE DE SHERBROOKE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('795501', 'CAISSE DESJARDINS DU MONT-SAINT-BRUNO', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('780301', 'CAISSE DESJARDINS DU NORD DE LAVAL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1960001', 'CAISSE DESJARDINS DU NORD DE SHERBROOKE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('284411', 'ABN AMRO BANK ( CHILE )', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44041302', 'AMERICAN EXPRESS BANK LTD', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('283911', 'BANCO BANEFE SANTANDER', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5868601', 'BANCO BICE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('448901', 'BANCO BILBAO VIZCAYA ARGENTARIA CHILE S.A.', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('148511', 'BANCO BTG PACTUAL CHILE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('148611', 'BANCO CONSORCIO', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('185611', 'BANCO CREDICHILE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5889101', 'BANCO DE CHILE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5884801', 'BANCO DE CREDITO E INVERSIONES', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11902102', 'BANCO DE LA NACION ARGENTINA', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('284511', 'BANCO DEL DESARROLLO', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5880701', 'BANCO DEL ESTADO DE CHILE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('35140202', 'BANCO DO BRASIL S.A.', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('21411', 'BANCO EDWARDS', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('284011', 'BANCO EXTERIOR ( CHILE )', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('512801', 'BANCO FALABELLA', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('512701', 'BANCO INTERNACIONAL', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5909501', 'BANCO ITAU CHILE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4959101', 'BANCO PARIS', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5757801', 'BANCO PENTA', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2729601', 'BANCO RIPLEY', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5880801', 'BANCO SANTANDER-CHILE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5891201', 'BANCO SECURITY', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('284211', 'BANCO SUDAMERIS', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('283611', 'BANK OF AMERICA, NATIONAL ASSOCIATION, S.A', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('185711', 'BCI NOVA', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('284311', 'CHASE MANHATTAN BANK, N.A.', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('283711', 'CITIBANK', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5884701', 'CORPBANCA', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4442401', 'DEUTSCHE BANK (CHILE) S.A.', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('283411', 'DRESDNER BANQUE NATIONALE PARIS', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('284111', 'FRIST NATIONAL BANK OF BOSTON', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5732801', 'HSBC BANK CHILE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('148711', 'JP MORGAN CHASE BANK, N.A.', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5712001', 'RABOBANK CHILE', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('283511', 'REPUBLIC NATIONAL BANK OF NEW YORK', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5912501', 'SCOTIABANK SUD AMERICANO', 'CL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5128101', 'BANQUE ATLANTIQUE CAMEROUN', 'CM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('194011', 'BGFIBANK CAMEROUN S.A', 'CM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3270101', 'CREDIT COMMUNAUTAIRE D''AFRIQUE (C.C.A.)', 'CM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39711', 'FIRST TRUST SAVING AND LOANS', 'CM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13112502', 'UNITED BANK FOR AFRICA PLC', 'CM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('165411', 'Agricultural Bank of China Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5904701', 'AGRICULTURAL DEVELOPMENT BANK OF CHINA', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328511', 'Alashan Zuoqi Fangda Village Bank Co. Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328211', 'Anhui Dangtu Xinhua Village Bank Co. Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188011', 'Anhui Province Rural Credit Cooperative Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4529701', 'Bank of Anshan Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('319411', 'Bank of Baoding Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2721801', 'Bank of Beijing Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188111', 'Bank Of Cangzhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4484801', 'Bank Of Changsha', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('319511', 'Bank of Chaoyang Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('319611', 'Bank of Chengde Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('192011', 'Bank Of Chengdu Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5912701', 'Bank of China', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3796001', 'Bank of Chongqing Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5900801', 'Bank of Communications', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5747701', 'Bank Of Dalian', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188211', 'Bank Of Deyang (Great Wall Western China Bank)', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('192111', 'Bank Of Dongguan (Dongguan Commercial Bank)', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('323611', 'Bank of Fushun Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188311', 'Bank Of Fuxin Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('323711', 'Bank of Gansu Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5784701', 'Bank of Ganzhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31311', 'Bank of Guangzhou', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('323811', 'Bank of Guizhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4584001', 'Bank of Handan Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3793901', 'Bank of Hangzhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188411', 'Bank Of Hebei', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('323911', 'Bank of Hengshui Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188511', 'Bank Of Huludao', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324011', 'Bank of Huzhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3222601', 'Bank of Inner Mongolia Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324211', 'Bank of Jiangsu Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5905601', 'Bank of Jiangsu Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188611', 'Bank Of Jiaxing', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324311', 'Bank of Jilin Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331511', 'Bank of Jinhua Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188711', 'Bank Of Jining', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3796701', 'Bank Of Jinzhou Co ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('165611', 'Bank Of Kunlun', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2867501', 'Bank Of Langfang', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324511', 'Bank of Lanzhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324611', 'Bank of Liaoyang Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('188811', 'Bank Of Liuzhou', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2867701', 'Bank Of Luoyang', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5739501', 'Bank of Nanjing', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('192211', 'Bank Of Ningbo', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2792701', 'Bank Of Ningxia', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324711', 'Bank of Panjin', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324811', 'Bank of Pingdingshan Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3788201', 'Bank Of Qingdao', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5749401', 'Bank Of Qinghai', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324911', 'Bank of Qinhuangdao Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325011', 'Bank of Quanzhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4911501', 'Bank Of Rizhao', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5369801', 'Bank of Shanghai', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189011', 'Bank Of Shangrao', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189111', 'Bank Of Shaoxing', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325211', 'Bank of Shizuishan Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('191411', 'Bank of Taizhou Co., Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325311', 'Bank of Tangshan Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325411', 'Bank of Tianjin Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325511', 'Bank of Tibet', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325711', 'Bank of Urumqi Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325811', 'Bank of Weifang Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5747401', 'Bank of Wenzhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325911', 'Bank of Wuhai Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('326011', 'Bank of Xian Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189211', 'Bank of Xingtai Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5784201', 'Bank of Yingkou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('321211', 'Bank of Zaozhuang Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3211201', 'Bank of Zhangjiakou Co Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4530001', 'Bank of Zhengzhou Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5827101', 'Bank of Zigong Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('326111', 'Baofeng Yufeng Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3262301', 'Baoshang Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('326211', 'Bazhou Shunfeng Rural Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('326311', 'Beijing Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189311', 'Beijing Shunyi Yinzuo Rural Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('326511', 'BOC Fullerton Community Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189411', 'Chang'' An Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('326711', 'Changchun Chaoyang Herun Country Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('326811', 'Changchun Jingkai Rongfeng Rural Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('326911', 'Changchun Luyuan Rongtai Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327011', 'Changchun Nanguan Huimin Village Bank Co. Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327311', 'Changge Xuanyuan Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327111', 'Changle Lean County Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327811', 'Changzhi City Commercial bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327211', 'Chengdu Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3863901', 'China Bohai Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5875501', 'China Citic Bank Corporation Limited CNCB', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5890301', 'China Construction Bank Corporation ', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5359101', 'CHINA DEVELOPMENT BANK', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('512901', 'China Everbright Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5875601', 'China Guangfa Bank Co Ltd ', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5880901', 'China Merchants Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2806601', 'China Minsheng Banking Corporation Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('191911', 'China Resources Bank of Zhuhai Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5903401', 'China Zheshang Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327411', 'Chongqing Rural Commercial Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5835901', 'Chongqing Rural Commercial Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327511', 'Chongqing Three Gorges Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189511', 'Chongqing Yubei Yinzuo Rural Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327611', 'Citibank (China) Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('327911', 'Dah Sing Bank (China) Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328011', 'Dalian Development Zone Xinhui Rural Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328111', 'Dalian Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330511', 'Dawa Hengfeng Rural Bank Co. Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('323511', 'Dazhou City Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328311', 'DBS Bank (China) Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3863401', 'Dezhou Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2792601', 'Dongguan Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4530301', 'Dongying Bank Co Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328411', 'Dongying Laishang Village Bank Co. Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189611', 'Erdos Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190311', 'Evergrowing Bank Co Ltd  ', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3795801', 'EVERGROWING BANK CO., LTD', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328611', 'Fengnan Shunfeng Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3841501', 'IMB LTD', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3574601', 'ING BANK (AUSTRALIA) LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2491501', 'MACQUARIE BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4445601', 'MEMBERS EQUITY BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62136402', 'MIZUHO CORPORATE BANK, LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5902301', 'NATIONAL AUSTRALIA BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('195611', 'POLICE BANK', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4350401', 'ST. GEORGE BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3576001', 'SUNCORP-METWAY LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('338811', 'TEACHERS MUTUAL BANK LIMITED', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5871401', 'WESTPAC BANKING CORPORATION', 'AU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('275211', 'ABK BANK, DIVISIE VAN BANK J. VAN BREDA EN CO NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('275311', 'AXA BANK BELGIUM', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('444301', 'BANCA MONTE PASCHI BELGIO', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('275411', 'BANCONTACT-MISTERCASH SA/NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('275511', 'BANK DELEN NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3150501', 'BANK J. VAN BREDA AND CO NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('275611', 'BANQUE DEGROOF PETERCAM SA/NV (FORMERLY BANQUE DEG', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2787101', 'BANQUE DREZE', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1523401', 'BANQUE ENI S.A.', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('275711', 'BANQUE NAGELMACKERS S.A. - BANK NAGELMACKERS NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('275811', 'BELFIUS BANK SA/NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('275911', 'BEOBANK NV/SA', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276011', 'BNP PARIBAS FORTIS (FORTIS BANK SA/NV)', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276111', 'BPOST', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276211', 'BPOST BANK-BPOST BANQUE', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4848801', 'BRUGS LEENKREDIET BVBA', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337401', 'BYBLOS BANK EUROPE S.A.', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276311', 'CBC BANQUE S.A.', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('454901', 'CENTRALE KREDIETVERLENING', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276411', 'CPH BANQUE', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3690501', 'DIERICKX LEYS EN CIE EFFECTENBANK NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3151101', 'EUROPABANK N.V.', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276511', 'F. VAN LANSCHOT BANKIERS BELGIE N.V.', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276611', 'ING BELGIUM NV/SA (FORMERLY BANK BRUSSELS LAMBERT ', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4350801', 'KBC BANK NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4462301', 'KEYTRADE BANK SA/NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('345511', 'PREPAYMENTS SOLUTIONS EU SA', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('444401', 'PUILAETCO DEWAAY PRIVATE BANKERS', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('881301', 'RECORD BANK NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('444501', 'SANTANDER BENELUX SA', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276711', 'SAXO BANK BELGIQUE', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2803801', 'SG PRIVATE BANKING BELGIUM', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3151001', 'SHIZUOKA BANK (EUROPE) S.A.', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5857201', 'THE BANK OF NEW YORK MELLON SA/NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('323411', 'TRANSFERWISE EUROPE SA/NV', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('509501', 'UNITED TAIWAN BANK S.A.', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1976001', 'VAN DE PUT AND CO PRIVATE BANKERS', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('658101', 'VDK BANK', 'BE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5779201', 'BANQUE ATLANTIQUE DU BENIN', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109811', 'BANQUE SAHELO-SAHARIENNE POUR L''INVESTISSEMENT ET ', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('193011', 'BGFIBANK', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317811', 'CCEI Bank Benin', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20333455', 'CORIS INTERNATIONAL BANK', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('444901', 'ECOBANK BENIN SA', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('119811', 'LA POSTE DU BENIN', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5760801', 'NSIA BANQUE BENIN', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65511', 'ORABANK BENIN', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('283211', 'UNITED BANK FOR AFRICA BENIN', 'BJ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5875001', 'BANCO BISA S.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5877601', 'BANCO DE CREDITO DE BOLIVIA S.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('12313302', 'BANCO DE LA NACION ARGENTINA', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29157902', 'BANCO DO BRASIL S.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('666101', 'BANCO ECONOMICO, S.A. - SCZ', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('91211', 'Banco Fassil S.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5884301', 'BANCO GANADERO, S.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3270501', 'BANCO LOS ANDES PROCREDIT', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5875101', 'BANCO MERCANTIL SANTA CRUZ S.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337901', 'BANCO NACIONAL DE BOLIVIA S.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2014301', 'BANCO SOL( BANCO SOLIDARIO S.A.)', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('510001', 'BANCO UNION S.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45525902', 'CITIBANK, N.A.', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('22911', 'COOPERATIVA DE LA FAMILIA LTDA', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13111', 'PRODEM FFP', 'BO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20352255', 'CIBC FirstCaribbean International Bank (Barbados) ', 'GD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20352355', 'Grenada Co-operative Bank Ltd', 'GD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20352155', 'RBTT Bank Grenada Limited', 'GD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20352455', 'Republic Bank (Grenada) Ltd', 'GD');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4479501', 'Addiko Bank AD Banja Luka', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2579601', 'Addiko Bank AD Sarajevo', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5635101', 'Asa Banka DD Sarajevo', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2749201', 'BOSNA BANK INTERNATIONAL D.D. SARAJEVO', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3648401', 'CENTRALNA BANKA BOSNE I HERCEGOVINE', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40373302', 'EUROPEAN BANK FOR RECONSTRUCTION AND DEVELOPMENT', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1081201', 'HIPPO BANKA DD. ZENICA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2579501', 'INTESA SANPAOLO BANKA D.D. BOSNA I HERCEGOVINA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3926801', 'KOMERCIJALNA BANKA A.D. BANJA LUKA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5734901', 'KOMERCIJALNO  - INVESTICIONA BANKA D.D. V. KLADUSA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5706601', 'NLB RAZVOJNA BANKA, A.D. BANJA LUKA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4375401', 'NLB TUZLANSKA BANKA D.D., TUZLA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4471501', 'NOVA BANKA A.D. BANJA LUKA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5722801', 'PAVLOVIC INTERNATIONAL BANK A.D.', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3621501', 'PRIVREDNA BANKA D.D.', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3621701', 'PROCREDIT BANKA DD SARAJEVO', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4362601', 'RAIFFEISEN BANK D.D. BOSNIA I HERZEGOVINA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3650001', 'RAZVOJNA BANKA FEDERACIJE BIH', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5686901', 'Sberbank BH DD', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2610301', 'Sparkasse Bank DD Bih', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5706501', 'UNICREDIT BANK A.D. BANJA LUKA', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5906101', 'UNICREDIT BANK DD MOSTAR', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2579401', 'UNION BANKA D.D. SARAJEVO', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5653401', 'VAKUFSKA BANKA DD SARAJEVO', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4375601', 'ZIRAAT BANK BOSNIA D.D.', 'BA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4977001', 'BANQUE ATLANTIQUE BURKINA FASO', 'BF');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('445901', 'BANQUE COMMERCIALE DU BURKINA', 'BF');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3834801', 'BSIC BURKINA', 'BF');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5058401', 'CORIS BANK INTERNATIONAL', 'BF');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23032802', 'ECOBANK BURKINA FASO', 'BF');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109211', 'ORABANK BURKINA FASO', 'BF');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('314311', 'WENDKUNI BANK INTERNATIONAL', 'BF');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1686601', 'ABV INVESTICII EOOD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5127901', 'ADAMANT CAPITAL PARTNERS AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15745802', 'AGRICULTURAL BANK OF GREECE S.A.', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5372701', 'ALLIANZ BANK BULGARIA AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('949801', 'ALLIANZ BULGARIA HOLDING', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26856602', 'ALPHA BANK-BULGARIA BRANCH', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5617501', 'ASSOCIATION OF BANKS IN BULGARIA', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1399901', 'AVAL IN JSC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25102302', 'BANK LEUMI ROMANIA S.A.', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3578701', 'BANKSERVICE AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30688002', 'BAYERISCHE HYPO- UND VEREINSBANK AG', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('351911', 'BNP PARIBAS PERSONAL FINANCE S.A. BULGARIA BRANCH', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60291002', 'BNP PARIBAS S.A.-SOFIA BRANCH', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5047201', 'BULBROKERS AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3419601', 'BULEX INVEST PLC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4376501', 'BULGARIAN AMERICAN CREDIT BANK', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4376701', 'BULGARIAN DEVELOPMENT BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('900301', 'BULGARIAN NATIONAL BANK', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1053601', 'BULGARIAN STOCK EXCHANGE', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('802101', 'BULSTRAD INSURANCE & REINSURANCE PLC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25148202', 'CA IB INVESTMENTBANK AG', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4322901', 'CENTRAL COOPERATIVE BANK PLC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1168801', 'CENTRAL DEPOSITORY AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('802201', 'CHISTOTA SOFIA AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4079001', 'CIBANK JSC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16827402', 'CITIBANK EUROPE PLC, BULGARIA BRANCH', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4092501', 'COMMERCIAL BANK VICTORIA EAD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('703501', 'CORPORATE COMMERCIAL BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4376601', 'D COMMERCE BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44811', 'DSK BANK', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3412201', 'ELANA TRADING INC.', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1168901', 'EURO-FINANCE LTD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38411', 'EUROBANK BULGARIA AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('455001', 'EUROBANK EFG BULGARIA', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40372802', 'EUROPEAN BANK FOR RECONSTRUCTION AND DEVELOPMENT', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3273801', 'FINANCE ENGINEERING JSC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3012001', 'FINANCIAL BROKERAGE HOUSE', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1441901', 'FINANCIAL HOUSE INTERNET COMPANY POPULIARNA KASA', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2804301', 'FIRST INVESTMENT BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('362111', 'ICARD AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('94011', 'ING BANK N.V. SOFIA BRANCH', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1971901', 'INTERNATIONAL ASSET BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('351811', 'INVESTBANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('94111', 'ISBANK AG SOFIA BRANCH', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32897602', 'KBC SECURITIES NV', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2804401', 'MKB UNIONBANK A.D.', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1976601', 'MUNICIPAL BANK PLC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('24758602', 'NATIONAL BANK OF GREECE, S.A.', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2776401', 'NLB WEST-EAST BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4092601', 'PIRAEUS BANK BULGARIA AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3749701', 'PROCREDIT BANK (BULGARIA) EAD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2804201', 'RAIFFEISENBANK (BULGARIA) EAD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('8378702', 'RAIFFEISENBANK ZAO', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1583401', 'REGIONALA INVESTICIJU BANKA CLON BULGARIA', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10597902', 'SOCIETE GENERALE', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('510501', 'SOCIETE GENERALE EXPRESSBANK', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2164601', 'SOFSTROY AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1385801', 'STS FINANCE SC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5059701', 'SYNERGON ASSET MANAGEMENT JSC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('94211', 'T.C. ZIRAAT BANKASI - SOFIA BRANCH', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('94311', 'TBI BANK EAD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3152201', 'TEXIM BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1317801', 'TIC SAEDINENIE PLC', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4727401', 'TK HOLD AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2727501', 'TOKUDA BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55033102', 'UNICREDIT BULBANK', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('445801', 'UNITED BULGARIAN BANK AD', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('351711', 'VARENGOLD BANK AG', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4993501', 'VIKTRIS', 'BG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317611', ' BANCO C6 S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316711', ' BANCO VOTORANTIM S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('361411', 'ACESSO SOLUCOES PAGAMENTO SA', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('351011', 'B&T Associados Corretora De Cambio Ltda', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317311', 'BANCO AGIBANK S.A', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316211', 'BANCO ALFA S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('347611', 'BANCO ANDBANK SA', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5847501', 'BANCO AZTECA DO BRASIL S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('560901', 'BANCO BMG S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('338101', 'BANCO BRADESCO BBI S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5889001', 'BANCO BRADESCO S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('315911', 'BANCO BS2 S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316311', 'BANCO BTG PACTUAL S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4090801', 'BANCO CACIQUE S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4091301', 'BANCO CITIBANK S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5616001', 'BANCO COOPERATIVO DO BRASIL S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5616101', 'BANCO COOPERATIVO SICREDI S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317111', 'BANCO CRESOL', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('445101', 'BANCO DA AMAZONIA, S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4355101', 'BANCO DAYCOVAL S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('157911', 'BANCO DE PERNAMBUCO S.A. BANDE', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('347111', 'Banco Digio SA', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3102601', 'BANCO DO BRASIL S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5371401', 'BANCO DO ESTADO DE SERGIPE S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('158011', 'BANCO DO ESTADO DO CEARA S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('158111', 'BANCO DO ESTADO DO MARANHAO S.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('523801', 'BANCO DO ESTADO DO PARA SA', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('120911', 'BANCO DO ESTADO DO PIAUI S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4102701', 'BANCO DO ESTADO DO RIO GRANDE DO SUL, S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5875201', 'BANCO DO NORDESTE DO BRASIL, S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316611', 'BANCO INTERCAP S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('158211', 'BANCO INTERMEDIUM S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5889201', 'BANCO ITAU, S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316511', 'BANCO J.P. MORGAN S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3151501', 'BANCO MERCANTIL DO BRASIL, S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316011', 'BANCO MODAL S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('158511', 'BANCO ORIGINAL', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316411', 'BANCO ORIGINAL S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('347711', 'Banco Pan SA', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('361511', 'BANCO PANAMERICANO S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317411', 'BANCO RENNER', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160111', 'BANCO SAFRA S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5868401', 'BANCO SANTANDER (BRASIL) S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5887701', 'BANCO SOFISA S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317011', 'BANCO UNICRED', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('445701', 'BANESTES S.A. - BANCO DO ESTADO DO ESPIRITO SANTO', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('338001', 'BRB-BANCO DE BRASILIA S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('670601', 'CAIXA ECONOMICA FEDERAL', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317511', 'CCC NOROESTE BRASILEIRO LTDA', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('158311', 'CECRED', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('346711', 'CONFEDERACAO NACIONAL DAS COOPERATIVAS CENTRAIS DE', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('345811', 'CONFEDERACAO NACIONAL DAS COOPERATIVAS CENTRAIS UN', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('346211', 'Cooperativa Central de Credito Ailos', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316911', 'COOPERATIVA CENTRAL DE CREDITO URBANO CECRED', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('315411', 'CREDICOAMO', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('315611', 'CREDISIS CENTRAL DE COOPERAT', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('359311', 'Mercado Pago - conta do Mercado Livre', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('207211', 'NU PAGAMENTOS S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317211', 'NUBANK', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('315811', 'PAGSEGURO INTERNET S.A.', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('360111', 'STONE PAGAMENTOS S.A', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('158411', 'UNICRED DO BRASIL', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316811', 'UNICRED NORTE DO PARANA', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('315511', 'UNIPRIME CENTRAL', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('315711', 'UNIPRIME NORTE DO PARANA COOP', 'BR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('891701', '1ST CHOICE SAVINGS & CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('777701', '3M EMPLS (LONDON) CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4700801', 'ACADIAN CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4698701', 'ACADIE VIE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('184711', 'ACCU-RATE CORPORATION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4698401', 'ACE CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43770102', 'ACKER FINLEY INC.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3582501', 'ACUMEN CAPITAL PARTNERS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('926801', 'ADJALA CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4719101', 'ADVANCE SAVINGS CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1940701', 'ADVANTAGE CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('892701', 'AFFINITY CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4698101', 'AGASSIZ CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('501301', 'AGF TRUST COMPANY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2505001', 'AIM FUNDS MANAGEMENT INC.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1955301', 'AIR-TORONTO CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4701301', 'AIRLINE FINANCIAL CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4710501', 'ALDERGROVE CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4079301', 'ALL NATIONS TRUST COMPANY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('782501', 'ALL TRANS FINANCIAL SERVICES CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5771601', 'ALTERNA SAVINGS AND CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('893501', 'ALTONA CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1995101', 'AMARANTH CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('659801', 'AMEX BANK OF CANADA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1168501', 'AMI PARTNERS INC.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5723701', 'ANISHINABEK NATION CREDIT UNION INC.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4695901', 'APEX CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('916801', 'APPLE COMMUNITY CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2652801', 'AQUILON CAPITAL CORP', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4697901', 'ARBORG CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('773801', 'ARNSTEIN COMMUNITY CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('785101', 'ARROW CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('893401', 'ASSINIBOINE CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1993801', 'ATB FINANCIAL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4699201', 'AUSTIN CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1942901', 'AUTO WORKERS COMMUNITY CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51352602', 'AVIVA INVESTORS NORTH AMERICA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('784001', 'B2B TRUST', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2738202', 'BANCO ABN AMRO REAL S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('24553702', 'BANCO BANIF E COMERCIAL DOS ACORES S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17929602', 'BANCO BPI, S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45897802', 'BANCO COMERCIAL PORTUGUES S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68209902', 'BANCO ESPANOL DE CREDITO, S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32473702', 'BANCO ESPIRITO SANTO DOS ACORES S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67809202', 'BANCO ESPIRITO SANTO, S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16610702', 'BANCO NACIONAL DE COMERCIO EXTERIOR, S.N.C.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63352102', 'BANCO NACIONAL DE MEXICO, S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68962802', 'BANCO POPULAR ESPANOL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60738802', 'BANCO SANTANDER (BRASIL) S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69432902', 'BANCO SANTANDER (MEXICO), S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61171002', 'BANCO SANTANDER TOTTA S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55464902', 'BANK HAPOALIM B.M.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56283802', 'BANK LEUMI LE-ISRAEL B.M.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23072302', 'BANK MORGAN STANLEY AG', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61397402', 'BANK OF AMERICA, NATIONAL ASSOCIATION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339301', 'BANK OF CANADA (BANQUE DU CANADA)', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('511401', 'BANK OF CHINA (CANADA)', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36918902', 'BANK OF CYPRUS PUBLIC COMPANY LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('35009102', 'BANK OF IRELAND ASSET MANAGEMENT LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5889301', 'BANK OF MONTREAL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5904201', 'BANK OF NOVA SCOTIA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1977001', 'BANK OF NOVA SCOTIA TRUST COMPANY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('511501', 'BANK OF TOKYO-MITSUBISHI UFJ (CANADA)', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17757902', 'BANK OF VALLETTA PLC', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('7192502', 'BANK VONTOBEL AG', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2751501', 'BANK WEST', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49900002', 'BANQUE CENTRALE POPULAIRE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32166302', 'BARCLAYS BANK PLC', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39823502', 'BARCLAYS CAPITAL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1289501', 'BARCLAYS GLOBAL INVESTORS CANADA LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3016701', 'BARCLAYS MCCONNELL LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4695801', 'BATTLE RIVER CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1957201', 'BAY CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4718901', 'BAY ST. LAWRENCE CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61282502', 'BAYERISCHE LANDESBANK', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('776001', 'BAYSHORE CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('895501', 'BAYVIEW CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1211401', 'BBN JAMES CAPEL INC.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52879802', 'BBVA BANCOMER, S.A.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4832301', 'BEACON SECURITIES LTD.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('928901', 'BEAUBEAR CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4696401', 'BEAUMONT CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('894301', 'BEAUTIFUL PLAINS CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('772101', 'BELGIAN-ALLIANCE CREDIT UNION LTD.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1940101', 'BENGOUGH CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4700701', 'BERGENGREN CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4697401', 'BIGGAR AND DISTRICT CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4711701', 'BLACKVILLE CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1054001', 'BLC SECURITIES INC.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1581701', 'BLUECHIVE PROCESSING CORPORATION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2854901', 'BMO NESBITT BURNS, INC.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4328801', 'BMO TRUST COMPANY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1053101', 'BNP (CANADA) VALEURS MOBILIERES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('511001', 'BNP PARIBAS (CANADA)', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('33566002', 'BNY MELLON, NATIONAL ASSOCIATION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3920501', 'BNY TRUST COMPANY OF CANADA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4521501', 'BOURSE DE MONTREAL - THE MONTREAL EXCHANGE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1939401', 'BOW VALLEY CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4703601', 'BREWERS WAREHOUSING EMPL (KITCHENER) CREDIT UNION ', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1955201', 'BREWERS WAREHOUSING EMPLS (HAMILTON) CREDIT UNION ', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('892401', 'BROADVIEW CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4832401', 'BROCKHOUSE AND COOPER INC.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('774601', 'BROOK STREET CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('771401', 'BRUNO SAVINGS AND CREDIT UNION LIMITED', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63549702', 'BSI SA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('776501', 'BUDD AUTOMOTIVE EMPLS (KITCHENER) CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1956101', 'BUDUCHNIST CREDIT UNION LTD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('925001', 'BULKLEY VALLEY CREDIT UNION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4832501', 'BURGUNDY ASSET MANAGEMENT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('511101', 'BUSINESS DEVELOPMENT BANK OF CANADA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4700001', 'C.N.R. EMPLOYEES (LAKEHEAD TERMINAL) CREDIT UNION ', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5494901', 'CAISSE CENTRALE DESJARDINS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('918901', 'CAISSE D'' ECONOMIE DESJARDINS DE L''EDUCATION', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958201', 'CAISSE D'' ECONOMIE DESJARDINS DES EMPLOYES EN TELE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('919601', 'CAISSE D'' ECONOMIE DESJARDINS DES POMPIERS, DES CO', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4706301', 'CAISSE D'' ECONOMIE DESJARDINS EMPLOYEES DU SECTEUR', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('919201', 'CAISSE D'' ECONOMIE DESJARDINS LE CHAINON', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4705801', 'CAISSE D'' ECONOMIE DESJARDINS STRATHCONA-STRATHCON', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958401', 'CAISSE D'' ECONOMIE SOLIDAIRE DESJARDINS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958501', 'CAISSE D''ECONOMIE DES CANTONS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('919001', 'CAISSE D''ECONOMIE DES EMPLOYES DE LA C.I.P. LA TUQ', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4706401', 'CAISSE D''ECONOMIE DES EMPLOYES DE LA S.T.C.U.M.', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958101', 'CAISSE D''ECONOMIE DES LITUANIENS DE MONTREAL LITAS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('918801', 'CAISSE D''ECONOMIE DES PORTUGAIS DE MONTREAL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958301', 'CAISSE D''ECONOMIE DESJARDINS DE LA CULTURE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2034701', 'CAISSE D''ECONOMIE DESJARDINS DE LA VALLEE DE L''AMI', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1937001', 'CAISSE D''ECONOMIE DESJARDINS DE SEPT-ILES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4712801', 'CAISSE D''ECONOMIE DESJARDINS DES EMPLOYEES ET EMPL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('846901', 'CAISSE D''ECONOMIE DESJARDINS DES EMPLOYES D''ALCOA-', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4705901', 'CAISSE D''ECONOMIE DESJARDINS DES EMPLOYES DE VILLE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4713601', 'CAISSE D''ECONOMIE DESJARDINS DES TRAVAILLEURS ET T', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3835501', 'CAISSE D''ECONOMIE DESJARDINS DES TRAVAILLEURS UNIS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('919801', 'CAISSE D''ECONOMIE DESJARDINS DU PERSONNEL MUNICIPA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('778601', 'CAISSE D''ECONOMIE DESJARDINS DU RAIL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('919701', 'CAISSE D''ECONOMIE DESJARDINS HYDRO', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('846801', 'CAISSE D''ECONOMIE DESJARDINS LAURENTIDE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4705701', 'CAISSE D''ECONOMIE DESJARDINS MARIE-VICTORIN', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('919101', 'CAISSE D''ECONOMIE DEUX-MONTAGNES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4705601', 'CAISSE D''ECONOMIE EMPLOYEES ET EMPLOYES GAZ METROP', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1959001', 'CAISSE D''ECONOMIE EMPLOYES DE DOMGLAS INC', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4694901', 'CAISSE D''ECONOMIE HENRI-BOURASSA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('847001', 'CAISSE D''ECONOMIE HONORE-MERCIER', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4718601', 'CAISSE D''ECONOMIE LAURENTIENNE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958001', 'CAISSE D''ECONOMIE POLONAISE DU QUEBEC', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1936901', 'CAISSE D''ECONOMIE ST-LUC', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1201701', 'CAISSE DE DEPOT ET PLACEMENT DU QUEBEC', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4694601', 'CAISSE DES MUTUELLISTES EPARGNE ET CREDIT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4707901', 'CAISSE DESJARDINS ALLARD-SAINT-PAUL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('923601', 'CAISSE DESJARDINS ATWATER-CENTRE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4714501', 'CAISSE DESJARDINS CAP MARTIN DE CHARLEVOIX', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('847301', 'CAISSE DESJARDINS CHARLES-LEMOYNE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('923201', 'CAISSE DESJARDINS CITE-DU-NORD DE MONTREAL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1959701', 'CAISSE DESJARDINS D''AMOS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1995401', 'CAISSE DESJARDINS D''ARVIDA-KENOGAMI', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('794801', 'CAISSE DESJARDINS DE BEAUCE-CENTRE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('924001', 'CAISSE DESJARDINS DE BEAUPORT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4706001', 'CAISSE DESJARDINS DE BELOEIL - MONT-SAINT-HILAIRE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('927801', 'CAISSE DESJARDINS DE BIENVILLE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1989601', 'CAISSE DESJARDINS DE BOUCHERVILLE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('782001', 'CAISSE DESJARDINS DE BROUGHTON', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('921401', 'CAISSE DESJARDINS DE CHOMEDEY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4712101', 'CAISSE DESJARDINS DE CLERMONT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('785601', 'CAISSE DESJARDINS DE DOLBEAU-MISTASSINI', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('782301', 'CAISSE DESJARDINS DE DONNACONA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958901', 'CAISSE DESJARDINS DE DRUMMONDVILLE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('780801', 'CAISSE DESJARDINS DE FERME-NEUVE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4714901', 'CAISSE DESJARDINS DE FINANCEMENT LEVIS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958701', 'CAISSE DESJARDINS DE GRANBY-HAUTE-YAMASKA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('923701', 'CAISSE DESJARDINS DE HULL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1991901', 'CAISSE DESJARDINS DE JOLIETTE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('927601', 'CAISSE DESJARDINS DE JONQUIERE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2035101', 'CAISSE DESJARDINS DE KILDARE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('920601', 'CAISSE DESJARDINS DE L'' ARDOISE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('924201', 'CAISSE DESJARDINS DE L'' ERABLE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('930901', 'CAISSE DESJARDINS DE L'' ILE-D''ORLEANS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4706801', 'CAISSE DESJARDINS DE L'' ILE-DES-SOEURS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('920401', 'CAISSE DESJARDINS DE L''EST DE SHERBROOKE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('890401', 'CAISSE DESJARDINS DE L''ISLET', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4709901', 'CAISSE DESJARDINS DE L''OUEST DE LA MAURICIE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('781301', 'CAISSE DESJARDINS DE L''OUEST DE LA MONTEREGIE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4707201', 'CAISSE DESJARDINS DE L''OUEST DE LAVAL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4718101', 'CAISSE DESJARDINS DE L''OUEST DE PORTNEUF', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4715201', 'CAISSE DESJARDINS DE LA CHAUDIEERE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('794701', 'CAISSE DESJARDINS DE LA NOUVELLE-ACADIE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1959501', 'CAISSE DESJARDINS DE LA RIVE-NORD DU SAGUENAY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2031001', 'CAISSE DESJARDINS DE LA SEIGNEURIE DE RAMEZAY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('769101', 'CAISSE DESJARDINS DE LA VALLEE DE L''OR', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4695501', 'CAISSE DESJARDINS DE LA VALLEE-DES-FORTS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4696101', 'CAISSE DESJARDINS DE LA VALLEE-DU-SAINT-MAURICE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4709201', 'CAISSE DESJARDINS DE LIMOILOU', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('780901', 'CAISSE DESJARDINS DE LONGUEUIL', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4708901', 'CAISSE DESJARDINS DE LORIMIER', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1958801', 'CAISSE DESJARDINS DE MARIEVILLE-ROUGEMONT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('780101', 'CAISSE DESJARDINS DE MERCIER-ROSEMONT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('890601', 'CAISSE DESJARDINS DE MONT-LAURIER', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4719501', 'CAISSE DESJARDINS DE POHENEGAMOOK', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4695201', 'CAISSE DESJARDINS DE PONT-ROUGE - SAINT BASILE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('920701', 'CAISSE DESJARDINS DE RIMOUSKI', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4714801', 'CAISSE DESJARDINS DE ROUYN-NORANDA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('927201', 'CAISSE DESJARDINS DE ROYAL-ROUSSILLON', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2032701', 'CAISSE DESJARDINS DE SAINT-DONAT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('769701', 'CAISSE DESJARDINS DE SAINT-HUBERT', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('847501', 'CAISSE DESJARDINS DE SAINT-HYACINTHE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('847101', 'CAISSE DESJARDINS DE SAINT-LEONARD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1989901', 'CAISSE DESJARDINS DE SAINT-PIERRE-APOTRE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1937801', 'CAISSE DESJARDINS DE SAINTE-FOY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('921501', 'CAISSE DESJARDINS DE SAINTE-SCHOLASTIQUE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('792601', 'CAISSE DESJARDINS DE SALABERRY-DE-VALLEYFIELD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('781701', 'CAISSE DESJARDINS DE SILLERY - SAINT-LOUIS-DE-FRAN', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('792901', 'CAISSE DESJARDINS DE STANSTEAD', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('922901', 'CAISSE DESJARDINS DE TETREAULTVILLE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4720101', 'CAISSE DESJARDINS DE THETFORD MINES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('779801', 'CAISSE DESJARDINS DE TRACADIECHE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4695101', 'CAISSE DESJARDINS DE VAL-MASKA', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('922201', 'CAISSE DESJARDINS DE VARENNES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1937201', 'CAISSE DESJARDINS DE VAUDREUIL-SOULANGES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3855601', 'CAISSE DESJARDINS DE VIGER', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4720001', 'CAISSE DESJARDINS DE WENDAKE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('930601', 'CAISSE DESJARDINS DES BERGES DE ROUSSILLON', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4709701', 'CAISSE DESJARDINS DES CHUTES MONTMORENCY', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('769001', 'CAISSE DESJARDINS DES CINQ-CANTONS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('922101', 'CAISSE DESJARDINS DES GRANDES-SEIGNEURIES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4715001', 'CAISSE DESJARDINS DES HAUTS-CANTONS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4719601', 'CAISSE DESJARDINS DES HAUTS-RELIEFS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('920501', 'CAISSE DESJARDINS DES METAUX BLANCS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('795201', 'CAISSE DESJARDINS DES MOISSONS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5729201', 'CAISSE DESJARDINS DES MONTS ET RIVIERES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('779101', 'CAISSE DESJARDINS DES POLICIERS ET POLICIERES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('781901', 'CAISSE DESJARDINS DES RIVIERES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4719701', 'CAISSE DESJARDINS DES RIVIERES BOYER ET ETCHEMIN', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4695401', 'CAISSE DESJARDINS DES RIVIERES CHAUDIERE ET ETCHEM', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('932201', 'CAISSE DESJARDINS DES SEIGNEURIES DE BELLECHASSE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4718801', 'CAISSE DESJARDINS DES SOMMETS DE LA BEAUCE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1990001', 'CAISSE DESJARDINS DES SOURCES-LAC-SAINT-LOUIS', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1938601', 'CAISSE DESJARDINS DES TROIS-RIVIERES', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4716001', 'CAISSE DESJARDINS DU BIC', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4709501', 'CAISSE DESJARDINS DU CARREFOUR MINIER', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('931001', 'CAISSE DESJARDINS DU CENTRE DE LA NOUVELLE BEAUCE', 'CA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1793001', 'ASOCIACION BARAHONA DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5071701', 'ASOCIACION BONAO DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3506601', 'ASOCIACION CIBAO DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1793201', 'ASOCIACION COTUI DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5690101', 'ASOCIACION DE BANCO DE DESARROLLO, INC.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1556901', 'ASOCIACION DE BANCOS COMERCIALES DE LA REPUBLICA D', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1439201', 'ASOCIACION DOMINICANA DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5071801', 'ASOCIACION DUARTE DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5071901', 'ASOCIACION HIGUAMO DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1793501', 'ASOCIACION LA NACIONAL DE AHORROS Y PRESTAMOS PARA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5072101', 'ASOCIACION LA PREVISORA DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1439801', 'ASOCIACION LA VEGA REAL DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1439901', 'ASOCIACION MOCANA DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3507001', 'ASOCIACION NOROESTANA DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1793601', 'ASOCIACION NORTENA DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1440001', 'ASOCIACION PERAVIA DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1440101', 'ASOCIACION POPULAR DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1793701', 'ASOCIACION ROMANA DE AHORROS Y PRESTAMOS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('670901', 'BANCO AGRICOLA DE LA REPUBLICA DOMINICANA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2696401', 'BANCO ATLANTICO DE AHORRO Y CREDITO S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2696601', 'BANCO BDI S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5891501', 'BANCO BHD, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58897902', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4456901', 'BANCO CAPITAL DE AHORRO Y CREDITO, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5681201', 'BANCO CARIBE S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5895601', 'BANCO CENTRAL DE LA REPUBLICA DOMINICANA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3753901', 'BANCO CONFISA DE AHORRO Y CREDITO S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4879001', 'BANCO CONTINENTAL DE DESARROLLO,S.A', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5837501', 'BANCO DE AHORRO Y  CREDITO PROVIDENCIAL S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5690201', 'BANCO DE AHORRO Y CREDITO ADEMI S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3705601', 'BANCO DE AHORRO Y CREDITO ADOPEM', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3188401', 'BANCO DE AHORRO Y CREDITO ALTAS CUMBRES S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1793301', 'BANCO DE AHORRO Y CREDITO ATLAS, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3704901', 'BANCO DE AHORRO Y CREDITO BANCOTUI, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5072001', 'BANCO DE AHORRO Y CREDITO COFACI, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1439301', 'BANCO DE AHORRO Y CREDITO CONFISA, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3893901', 'BANCO DE AHORRO Y CREDITO DE LAS AMERICAS, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1439401', 'BANCO DE AHORRO Y CREDITO DEL CARIBE', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3188601', 'BANCO DE AHORRO Y CREDITO EMPIRE, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5069301', 'BANCO DE AHORRO Y CREDITO FEDERAL, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1985701', 'BANCO DE AHORRO Y CREDITO FIHOGAR', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3507101', 'BANCO DE AHORRO Y CREDITO GRUFICORP S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3949201', 'BANCO DE AHORRO Y CREDITO INMOBILIARIO, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4457001', 'BANCO DE AHORRO Y CREDITO MICRO, S.A', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3506701', 'BANCO DE AHORRO Y CREDITO PROVIDENCIAL, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3705101', 'BANCO DE AHORRO Y CREDITO PYME BHD, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3949101', 'BANCO DE AHORRO Y CREDITO RIO S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23811', 'BANCO DE CREDITO Y AHORRO UNION SA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2696301', 'BANCO DE DESARROLLO AGROPECUARIO SA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4550101', 'BANCO DE DESARROLLO IDECOSA, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5690401', 'BANCO DE DESARROLLO PERAVIA ,S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2732001', 'BANCO DE DESARROLLO UNIFICADO', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('543501', 'BANCO DOMINICANO DEL PROGRESO, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59015102', 'BANCO ESPANOL DE CREDITO, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3158301', 'BANCO MULTIPLE LEON S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3705001', 'BANCO MULTIPLE LOPEZ DE HARO S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3158401', 'BANCO NACIONAL DE FOMENTO DE LA VIVIENDA Y LA PROD', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2006501', 'BANCO PERAVIA DE AHORRO Y CREDITO', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5891601', 'BANCO POPULAR DOMINICANO, C. POR A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3423201', 'BANCO PROMERICA DE AHORRO Y CREDITO', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3508101', 'BANCO PROVIDENCIAL, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4422101', 'BANCO SANTA CRUZ, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('12860502', 'BANCO SANTANDER S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61675002', 'BANCO SANTANDER-CHILE', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5086101', 'BANCO UNION SA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1137001', 'BANCO VIMENCA S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65247602', 'BANK OF NOVA SCOTIA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69740202', 'BANK OF NOVA SCOTIA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5876001', 'Banreservas 10 digitos', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160411', 'Banreservas 15 digitos', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5069401', 'BELLBANK, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3422001', 'BONANZA BANCO DE AHORRO Y CREDITO', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34702802', 'CAJA DE AHORROS DEL MEDITERRANEO', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1505502', 'CAJASTUR - CAJA DE AHORROS DE ASTURIAS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2741101', 'CELVADOM -DEPOSITO CENTRALIZADO DE VALORES SA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17544002', 'CITIBANK, N.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17544102', 'CITIBANK, N.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17011', 'COOPERATIVA SAN JOSE INC', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3509401', 'CORPORACION DE CREDITO AMERICA, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5117501', 'CORPORACION DE CREDITO EL EFECTIVO', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5111501', 'CORPORACION DE CREDITO FIMOTORS', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1796701', 'CORPORACION DE CREDITO INVERSIONES MOCANAS, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5111601', 'CORPORACION DE CREDITO LA AMERICANA S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5073501', 'CORPORACION DE CREDITO LEASING CONFISA, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1796801', 'CORPORACION DE CREDITO MONUMENTAL, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1462501', 'CORPORACION DE CREDITO OFICORP, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3612101', 'CORPORACION DE CREDITO ORIENTAL', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5111401', 'CORPORACION DE CREDITO PREINDESA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5073601', 'CORPORACION DE CREDITO PRESTAMOS A LAS ORDENES, S.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1796901', 'CORPORACION DE CREDITO REIDO, C. POR A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1462601', 'CORPORACION DE CREDITO RONA, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5073701', 'CORPORACION DE CREDITO TOINSA, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2185401', 'GRUPO POPULAR, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26168502', 'JPMORGAN CHASE BANK, NATIONAL ASSOCIATION', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('46922102', 'JPMORGAN CHASE BANK, NATIONAL ASSOCIATION', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4550001', 'MOTOR CREDITO, S.A., BANCO DE AHORRO Y CREDITO', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2065001', 'OPTIMA CORPORACION DE CREDITO, S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5890401', 'REPUBLIC BANK (DR) S.A.', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4548201', 'SUPERINTENDENCIA DE BANCOS DE LA REPUBLICA DOMINIC', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1583801', 'TESORERIA DE LA SEGURIDAD SOCIAL', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55509402', 'THE BANK OF NOVA SCOTIA', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29323202', 'WACHOVIA BANK, NATIONAL ASSOCIATION', 'DO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54011', 'ASOC. MUTUALISTA  A Y C PICHINCHA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15011', 'ASOC. MUTUALISTA A Y C AZUAY', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14911', 'ASOC. MUTUALISTA A Y C IMBABURA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3158501', 'BANCO AMAZONAS S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4233601', 'BANCO BOLIVARIANO C.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4459701', 'BANCO CAPITAL S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339311', 'BANCO CENTRAL DE ECUADOR', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16811', 'BANCO COFIEC S.A', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('457801', 'BANCO COMERCIAL DE MANABI', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27511', 'BANCO COOPNACIONAL S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20350255', 'BANCO COOPNACIONAL S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('457901', 'BANCO DE DESARROLLO DEL ECUADOR', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5868801', 'BANCO DE GUAYAQUIL', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('457701', 'BANCO DE LOJA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('353501', 'BANCO DE MACHALA S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('353301', 'BANCO DEL AUSTRO, S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53511', 'BANCO DEL INSTITUTO ECUATORIANO DE SEGURIDAD SOCIA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('353401', 'BANCO DEL LITORAL S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4116701', 'BANCO DEL PACIFICO S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20350355', 'BANCO DEL PACIFICO S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5734801', 'BANCO DELBANK S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('353701', 'BANCO ECUATORIANO DE LA VIVIENDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3225101', 'BANCO FINCA S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4323501', 'BANCO GENERAL RUMINAHUI S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53711', 'BANCO PARA LA ASISTENCIA COMUNITARIA FINCA S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5912301', 'BANCO PICHINCHA C.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32851802', 'BANCO PROCREDIT', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53811', 'Banco Produbanco - Promerica', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20350055', 'BANCO SOLIDARIO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2005801', 'BANCO SUDAMERICANO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('489101', 'BANCO TERRITORIAL', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('900901', 'BANCO UNIVERSAL S.A. UNIBANCO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('301311', 'BANCO VISIONFUND ECUADOR S. A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53411', 'BANCO-D-MIRO S.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20349955', 'CACPECO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('285711', 'CCOP. DE A. Y C. SALASACA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45515102', 'CITIBANK, N.A.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('292811', 'COOP  DE A Y C CATAR LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('298511', 'COOP A Y C  1 DE JULIO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15311', 'COOP A Y C  CAMARA DE COMERCIO DE QUITO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('74211', 'COOP A Y C  EDUCADORES DEL TUNGURAHUA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('298011', 'COOP A Y C  LA FLORESTA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('294811', 'COOP A Y C  POLICIA NACIONAL LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20349655', 'COOP A Y C 11 DE JUNIO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71211', 'COOP A Y C 13 DE ABRIL LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13311', 'COOP A Y C 14 DE MARZO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('302011', 'COOP A Y C 14 DE MAYO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2733501', 'COOP A Y C 15 DE ABRIL LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189711', 'Foshan Shunde Rural Commercial Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328711', 'Fubon Bank (China) Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328811', 'Fudian Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('192311', 'Fujian Haixia Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189811', 'Fujian Rural Credit Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('328911', 'Gansu Provincial Rural Credit Cooperative Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189911', 'Guangdong Huaxing Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329011', 'Guangdong Nanhai Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190011', 'Guangdong Nanyue Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329111', 'Guangdong Provincial Rural Credit Cooperative Unio', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('165311', 'Guangdong Shunde Rural Commercial Bank Company Lim', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5784601', 'Guangxi Beibu Gulf Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329811', 'Guangxi Beibu Gulf Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329211', 'Guangxi Zhuang Autonomous Region Rural Credit Unio', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329311', 'Guangyang Shunfeng Rural Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190111', 'Guangzhou Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329411', 'Guian New Area Development Rural Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4530701', 'Guilin Bank
.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329511', 'Guilin Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329611', 'Guishang County Bank Of Guangyuan City', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2792501', 'Guiyang Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329711', 'Guizhou Province Rural Credit Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337911', 'Haikou United Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190211', 'Hainan Province Rural Credit Cooperative Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330011', 'Hami City Commercial bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330111', 'Hami Tianshan Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('319311', 'Hangzhou United Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4466201', 'Hankou Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5746901', 'Harbin Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330311', 'Heilongjiang Province Rural Credit Cooperative Uni', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330411', 'Henan Province Rural Credit Cooperative Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1976901', 'Hua Xia Bank Co Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330811', 'Huarong Xiangjiang Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330911', 'Hubei Bank Corporation Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190411', 'Hubei Rural Credit Cooperatives', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2793101', 'Huishang Bank Corporation Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331111', 'Hunan Rural Credit Cooperatives Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('325111', 'Hunan Sanxiang Bank Co., Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5903901', 'Industrial and Commercial Bank of China', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5903601', 'Industrial Bank Co. Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331211', 'Industrial Bank Of Korea (China) Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331311', 'Inner Mongolia Autonomous Region Rural Credit Unio', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331611', 'Jiangsu Changjiang Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4496201', 'Jiangsu Changshu Rural Commercial Bank CO Ltd
JIA', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332411', 'Jiangsu Jiangnan Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331711', 'Jiangsu Jiangyin Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331811', 'Jiangsu Kunshan Rural Commercial Bank Co Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4584401', 'Jiangsu Province Rural Credit Cooperative Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337311', 'Jiangsu Suning Bank Co. Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('191511', 'Jiangsu Suzhou Rural Commercial Bank Co Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337511', 'Jiangsu Taicang Rural Commercial Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4494501', 'Jiangsu Zhangjiagang Rural Commercial Bank Co. Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331911', 'Jiangxi Bank Co Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190511', 'Jiangxi Ganzhou Yinzuo Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332011', 'Jiangxi Rural Credit Cooperative Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('319711', 'Jiaozuo China Travel Bank Co Ltd (Bank of CTS.JZ)', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4529601', 'Jilin Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190611', 'Jilin Province Rural Credit Cooperative Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4573901', 'Jincheng Bank
JINCHENG CITY COMMERCIAL BANK CO., ', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331411', 'Jincheng Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190711', 'Jinshang Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332211', 'Jintang Huijin Rural Bank Co. Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332311', 'Jinzhai Huiyin Rural Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('321511', 'Jinzhong Yuci Rongxin Country Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330211', 'KEB Hana Bank (China) Company Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332511', 'Kenlilean Rural Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324411', 'Korla City Commercial Bank Co. Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5784801', 'Laishang Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4495501', 'Lanzhou Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332711', 'Laoting Shunfeng Rural Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332811', 'Leshan City Commercial Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332911', 'Liangshan Prefectural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333011', 'Liaoning Province Rural Credit Cooperative Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333211', 'Lingbao Rongfeng Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3863301', 'Linshang Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333411', 'Liyi Xintian Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190811', 'Longjiang Bank Corporation', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333511', 'Loufan Sanhe Rural Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333611', 'Luanping Shengyang Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('190911', 'Luohe City Commercial Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333711', 'Luzhou Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('329911', 'Meixian Hakka Village Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333811', 'Meizhou Merchants Bank Co., Ltd. ', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3798601', 'Mianyang City Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4494901', 'Nanchang Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334011', 'Nanyang Commercial Bank (China) Limited', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334111', 'Nanyang Country Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334211', 'Neijiang Xinglong Village Bank Co. Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334311', 'New Oriental Countryside Bank of Kaifeng', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334411', 'Ningbo Commerce Bank Corporation Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334511', 'Ningbo Donghai Bank Co., Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332111', 'Ningbo Yinzhou Rural Commercial Bank Co Ltd   (', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5906001', 'Ningbo Yinzhou Rural Cooperative Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('191011', 'Ningxia Huanghe Rural Commercial Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('321911', 'Ningxia Yellow River Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334611', 'Ningxia Yuanzhou Jinhui Village Bank Co., Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334711', 'Ordos Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334811', 'Otog Banner Huize Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3921301', 'Panzhihua City Commercial Bank Limited By Share Lt', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2721901', 'Ping An Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1348801', 'Postal Savings Bank of China Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('334911', 'Qian Xi Hua Du Country Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4493601', 'Qilu Bank  Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335011', 'Qingdao Huangdao Shunfeng Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335111', 'Qinghai Province Rural Credit Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335211', 'Qinglong Village Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335611', 'Qingyang Xifeng Ruixin County Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335311', 'Qingyun Lean Rural Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2777601', 'Qishang Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335411', 'Qujing City Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335511', 'Quwo Xintian Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('330711', 'Recuperando datos. Espere unos segundos e intente ', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('335811', 'Rural Credit Cooperative of Hebei', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4585301', 'Rural Credit Union Of Guangxi Zhuang Autonomous Re', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336111', 'Shaanxi Rural Credit Cooperatives Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('331011', 'Shandong Huimin Shunfeng Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('332611', 'Shandong Lanling Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333111', 'Shandong Lijin Shunfeng Village Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('333311', 'Shandong Linqu Jufeng Rural Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336011', 'Shandong Province Rural Credit Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5835401', 'Shandong Province Rural Credit Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1996801', 'Shanghai Pudong Development Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4975001', 'Shanghai Rural Commercial Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('337011', 'Shanghai Rural Commercial Bank Co Ltd ', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336211', 'Shanxi Province Rural Credit Union', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336311', 'Shanxi Yaodu Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336411', 'Shaoshan Everbright Village Bank Co Ltd   (Shao', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336511', 'Shengjing Bank Co. Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5895801', 'Shenzhen Development Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('191111', 'Shenzhen Futian Yinzuo Rural Bank', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('336611', 'Shenzhen Longgang Dingye Village Bank Co. Ltd.', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4494801', 'Shenzhen Rural Commercial Bank Co Ltd', 'CN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5910001', 'ACLEDA BANK PLC', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3621201', 'ADVANCED BANK OF ASIA LTD.', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20350755', 'AMK Microfinance Institution Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208511', 'Bank for Investment and Development of Cambodia Pl', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('685701', 'Bank of China (Hong Kong) Limited', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209611', 'Bank of India Phnom Penh Branch', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('207311', 'Booyoung Khmer Bank', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('207411', 'Bred Bank Cambodia Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('207611', 'Cambodia Asia Bank Ltd', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('207811', 'Cambodia Post Bank Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4323001', 'CAMBODIAN COMMERCIAL BANK LTD', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('207711', 'Cambodian Public Bank Ltd', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2004401', 'CANADIA BANK PLC', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('207911', 'Cathay United Bank Cambodia Co, Ltd', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('207511', 'CIMB Bank Cambodia Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56617902', 'FIRST COMMERCIAL BANK', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3621301', 'FOREIGN TRADE BANK OF CAMBODIA', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208211', 'Hong Leong Bank Cambodia PLC', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208411', 'ICBC Limited Phnom Penh Branch', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('316111', 'JTrust Royal bank', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209511', 'KASIKORN Bank', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208011', 'Kookmin Bank Cambodia Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62512902', 'KRUNG THAI BANK PUBLIC CO LIMITED', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209711', 'MB Bank Plc Phnom Penh Branch, Cambodia', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208311', 'Mega International Commercial Bank', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208111', 'Phillip Bank Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208711', 'Phnom Penh Commercial Bank', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20349255', 'PRINCE BANK PLC', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208611', 'RHB Indochina Bank Limited', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208811', 'Rural Development Bank', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('119411', 'SACOMBANK CAMBODIA Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209011', 'Saigon Hanoi Bank Cambodia Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('208911', 'Sathapana Bank Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209111', 'Shinhan Bank (Cambodia) Plc.', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209211', 'Taiwan Cooperative Bank', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209311', 'Union Commercial Bank Plc', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3767801', 'VATTANAC BANK LIMITED', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209411', 'Vietnam Bank for Agriculture and Rural Development', 'KH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135111', 'BANCAMIA', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3729301', 'BANCO AGRARIO DE COLOMBIA S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('341401', 'BANCO CAJA SOCIAL', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5871601', 'BANCO COLPATRIA RED MULTIBANCA COLPATRIA S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5712701', 'BANCO COMERCIAL AV VILLAS S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2718301', 'BANCO DAVIVIENDA S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5879601', 'BANCO DE BOGOTA S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5895401', 'BANCO DE OCCIDENTE', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('341301', 'BANCO GNB SUDAMERIS', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5875701', 'BANCO POPULAR S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('513301', 'BANCOLOMBIA S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1813601', 'BANCOOMEVA', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('99801', 'BBVA COLOMBIA', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3154901', 'CITIBANK COLOMBIA S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5713001', 'COOPERATIVA FINANCIERA DE ANTIOQUIA C.F.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('12331202', 'CORBANCA (ANTES SANTANDER)', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1246601', 'GIROS Y FINANZAS COMPANIA DE FINANCIAMIENTO COMERC', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11506002', 'HELM BANK', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3834201', 'HSBC COLOMBIA S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5080301', 'PAGOS INTERNACIONALES S.A.', 'CO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343155', 'ALDESA VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20342255', 'Asociacion Solidarista de Empleados del Banco Naci', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5891401', 'BANCO BAC SAN JOSE S.A.', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159111', 'BANCO BTC', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3614601', 'BANCO CATHAY DE COSTA RICA S.A.', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343855', 'BANCO CENTRAL', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('199311', 'BANCO CMB', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20344755', 'BANCO CMB COSTA RICA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5891301', 'BANCO CREDITO AGRICOLA DE CARTAGO', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5881101', 'BANCO DE COSTA RICA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3220101', 'BANCO GENERAL COSTA RICA S.A.', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20345155', 'BANCO HIPOTECARIO DE LA VIVIENDA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5877801', 'BANCO HSBC (COSTA RICA) S.A. Formerly BANCO DAVIVI', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2481801', 'BANCO IMPROSA S.A.', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20345755', 'BANCO INTERNACIONAL DE COSTA RICA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3155301', 'BANCO LAFISE, S.A.', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5895501', 'BANCO NACIONAL DE COSTA RICA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20345055', 'BANCO POPULAR DE DESARROLLO COMUNAL', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4320901', 'BANCO POPULAR Y DE DESARROLLO COMUNAL', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4367201', 'BANCO PROMERICA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159211', 'BANCO SCOTIABANK (ANTIGUO CITIBANK)', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343555', 'BCR VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20344055', 'BCT S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20342555', 'BCT VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343355', 'BN VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20349055', 'BOLSA NACIONAL DE VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160011', 'CAJA DE ANDE', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20344555', 'CATHAY DE COSTA RICA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20342655', 'CITI VALORES ACCIVAL S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159411', 'COOCIQUE', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346455', 'COOPE ANDE N 1 RL', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20345455', 'COOPE SAN MARCOS', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('12711', 'COOPEALIANZA R.L', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346655', 'COOPEAMISTAD R L', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159911', 'COOPEANDE', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348955', 'COOPEBANPO', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346255', 'COOPECAJA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346855', 'COOPECAR R L', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346955', 'COOPEGRECIA R L', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346055', 'COOPEGUANACASTE R L', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20347355', 'COOPEJUDICIAL', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20347255', 'COOPEMEDICOS R L', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346355', 'COOPEMEP', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159811', 'COOPENAE', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20347055', 'COOPERATIVA DE AHORRO Y CR EDITO ANTONIO VEGA GRAN', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346755', 'COOPERATIVA DE AHORRO Y CR EDITO REFACCIONARIO DEL', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346155', 'COOPERATIVA DE SERVICIOS PUBLICOS', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20346555', 'COOPESAN RAMON R L', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20347155', 'COOPEUNA R L', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348755', 'CREDIX WORLD S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343955', 'DAVIVIENDA COSTA RICA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20342955', 'DAVIVIENDA PUESTO DE BOLSA COSTA RICA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348455', 'EVERTEC COSTA RICA SOCIEDAD ANONIMA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20347455', 'FINANCIERA CAFSA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20347655', 'FINANCIERA COMECA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20347855', 'FINANCIERA CREDILAT S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159711', 'FINANCIERA DESYFIN', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20347555', 'FINANCIERA GENTE SOCIEDAD ANONIMA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159611', 'FINANCIERA GYT CONTINETAL', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348255', 'FONDO DE INVERSION CONCENTRADO CERRADO DE DEUDAS S', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348155', 'FONDO DE INVERSION DE INGRESO CERRADO MULTIFONDOS ', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348355', 'FONDO DE INVERSION NO DIVERSIFICADO CERRADO PRODUC', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348055', 'FONDO DE INVERSION SUMA NO DIVERSIFICADO', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20344955', 'FUSION BCR BCAC', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13011', 'GRUPO MUTUAL ALAJUELA LA VIVIENDA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20344355', 'IMPROSA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343655', 'IMPROSA VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348655', 'INNOVACION EN MEDIOS DE PAGOS ELECTRONICOS S A  IM', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20342855', 'INS VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20348555', 'INTERCLEAR CENTRAL DE VALORES S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20342355', 'INVERSIONES SAMA', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20344155', 'LAFISE S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20342455', 'MERCADO VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159311', 'Mucap', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20345955', 'MUTUAL CARTAGO', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343055', 'MUTUAL VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343455', 'POPULAR VALORES', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('159511', 'PRIVAL BANK', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20345255', 'PRIVAL BANK COSTA RICA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20343755', 'PRIVAL SECURITIES  PUESTO DE BOLSA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20344255', 'PROMERICA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20344455', 'SCOTIABANK DE COSTA RICA S A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('199411', 'THE BANK OF NOVA SCOTIA (COSTA RICA) S.A', 'CR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1382401', 'EXIM BANK COMORES LTD', 'KM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('139111', 'UNION DES MECKS', 'KM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('341501', 'BANQUE ATLANTIQUE DE COTE D''IVOIRE', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20329355', 'Banque d''Abidjan', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3782501', 'BANQUE DE L''HABITAT DE COTE D''IVOIRE', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('324111', 'BANQUE DE L''UNION -COTE D''IVOIRE', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('185411', 'BANQUE MALIENNE  DE SOLIDARITE', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39011', 'BANQUE NATIONALE D''INVESTISSEMENT', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3259101', 'CAISSE NATIONALE DES CAISSE EPARGNE', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('79611', 'CORIS BANK INTERNATIONAL', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3155501', 'Ecobank Cote D''Ivoire', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('170411', 'GUARANTY TRUST BANK COTE D''IVOIRE', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20330155', 'Mansa Bank', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('341601', 'NSIA Banque - Côte d''Ivoire', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('107311', 'ORABANK COTE D''IVOIRE', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13112402', 'UNITED BANK FOR AFRICA PLC', 'CI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3259601', 'ALFA CAPITAL HOLDINGS (CYPRUS) LIMITED', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36706602', 'ARAB JORDAN INVESTMENT BANK-OFFSHORE BANKING UNIT', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1401601', 'ASTROBANK PUBLIC COMPANY LIMITED', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1111702', 'BANK OF BEIRUT S.A.L.', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3156401', 'BANK OF CYPRUS PUBLIC COMPANY LIMITED', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3876202', 'BANKMED, S.A.L', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42266302', 'BANQUE SBA', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47477402', 'BBAC SAL', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('9491102', 'BEMO BANQUE EUROPEENNE POUR LE MOYEN-ORIENT SAL', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16564902', 'BLOM BANK SAL', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45667102', 'BYBLOS BANK SAL', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('514201', 'CENTRAL BANK OF CYPRUS', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41455602', 'CENTRAL COOPERATIVE BANK OF BULGARIA PLC', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('342401', 'CO-OPERATIVE CENTRAL BANK LTD', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36713602', 'CREDIT LIBANAIS SAL', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3944501', 'EUROBANK CYPRUS LIMITED', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27970102', 'FIRST INVESTMENT BANK', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3371401', 'HELLENIC BANK (INVESTMENTS) LIMITED', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5875801', 'HELLENIC BANK PUBLIC COMPANY LIMITED', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('558201', 'HOUSING FINANCE CORPORATION', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2022702', 'INTERCONTINENTAL BANK OF LEBANON S.A.L.', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45662702', 'JORDAN AHLI BANK', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51583002', 'JORDAN KUWAIT BANK', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3886202', 'LEBANON AND GULF BANK S.A.L.', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('869001', 'NATIONAL BANK OF GREECE (CYPRUS) LTD', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41432602', 'PRIVATBANK', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('541801', 'SOCIETE GENERALE CYPRUS LTD.', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('541701', 'THE CYPRUS DEVELOPMENT BANK PUBLIC COMPANY LIMITED', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3245002', 'TRASTA KOMERCBANKA CYPRUS BRANCH', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5127201', 'UNITED WORLD CAPITAL LIMITED', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3156701', 'USB BANK PLC', 'CY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236311', 'BANKA KOVANICA D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236411', 'BKS BANK AG, GLAVNA PODRUZNICA HRVATSKA', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236511', 'CROATIAN BANK FOR RECONSTRUCTION AND DEVELOPMENT/H', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236611', 'ERSTE AND STEIERMAERKISCHE BANK D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236711', 'ISTARSKA KREDITNA BANKA JOINT STOCK COMPANY', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236811', 'JADRANSKA BANKA D.D. SIBENIK', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236911', 'KARLOVACKA BANKA D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237011', 'KENTBANK D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237111', 'KREDITNA BANKA ZAGREB D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237211', 'OTP BANKA HRVATSKA D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237311', 'PARTNER BANKA D.D. ZAGREB', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237411', 'PODRAVSKA BANKA D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237511', 'PRIMORSKA BANKA D.D RIJEKA', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237611', 'PRIVREDNA BANKA ZAGREB D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2805001', 'RAIFFEISENBANK AUSTRIA D.D. ZAGREB', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237711', 'SAMOBORSKA BANKA D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237811', 'SLATINSKA BANKA DD', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('237911', 'SPLITSKA BANKA DD', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238011', 'TESLA STEDNA BANKA D.D.', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238111', 'ZAGREBACKA BANKA DD', 'HR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51990902', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58997702', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60950302', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61505402', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61505502', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68087602', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68087702', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45873702', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45887402', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17866202', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17866302', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17866502', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17915902', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17916202', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17280802', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17281002', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17281102', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17282202', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17312902', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17332002', 'BANCO BPI, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17334702', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17334802', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17334902', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17339102', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17339202', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17339302', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17339502', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17342002', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17342102', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17342202', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17347902', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17354502', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17354902', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17394702', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17394902', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17395002', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17395102', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17592902', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17930902', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17931002', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17931102', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17946702', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17965602', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17965702', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18015602', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18021902', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45897902', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45898002', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45898102', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45898202', 'BANCO COMERCIAL PORTUGUES S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2003701', '1822DIREKT GESELLSCHAFT DER FRANKFURTER SPARKASSE ', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3391001', '886 AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('677901', 'AACHENER BANK EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('632501', 'AACHENER BAUSPARKASSE AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('635301', 'AACHENER GRUNDVERMOGEN KAPITALANLAGEGESELLSCHAFT M', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3167001', 'AAREAL BANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1051701', 'AAREAL IMMOBILIEN KAPITALANLAGEGESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1671101', 'ABACUS GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17194402', 'ABC INTERNATIONAL BANK PLC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3240701', 'ABCFINANCE GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20429302', 'ABERDEEN ASSET MANAGERS LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4523101', 'ABK SYSTEME GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('550001', 'ABN AMRO BANK N.V. NIEDERLASSUNG DEUTSCHLAND', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('76502', 'ABSA BANK LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1754101', 'ABTSGMUNDER BANK - RAIFFEISEN - EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3238401', 'ACON ACTIENBANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('690701', 'ACTIVEST INVESTMENTGESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('803901', 'ADAM OPEL GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('734901', 'ADIG ALLGEMEINE DEUTSCHE INVESTMENT-GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3390601', 'ADOLF WURTH GMBH & CO. KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('746401', 'AGCO FINANCE GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15745602', 'AGRICULTURAL BANK OF GREECE S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15745702', 'AGRICULTURAL BANK OF GREECE S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15760802', 'AGRICULTURAL BANK OF GREECE S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44870302', 'AGRICULTURAL BANK OF GREECE S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44870402', 'AGRICULTURAL BANK OF GREECE S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3166801', 'AKA AUSFUHRKREDIT-GESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5828001', 'AKBANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69580202', 'AKBANK T.A.S.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1753801', 'AKF BANK GMBH & CO. KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('522401', 'AKTIVBANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5054901', 'ALEXANDER LUDICKE', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('551301', 'ALLGAUER VOLKSBANK EG KEMPTEN-SONTHOFEN', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('633501', 'ALLGEMEINE BEAMTEN KASSE KREDITBANK GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3626901', 'ALLIANZ AKTIENGESELLSCHAFT HOLDING', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4730001', 'ALLIANZ DRESDNER ASSET MANAGEMENT AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1015001', 'ALLIANZ DRESDNER ASSET MANAGEMENT INTERNATIONAL GM', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('632801', 'ALLIANZ DRESDNER BAUSPAR AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('645401', 'ALLIANZ GLOBAL INVESTORS - KAPITALANLAGEGESELLSCHA', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4830001', 'ALLIANZ LEBENSVERSICHERUNGS-AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5110601', 'ALLIANZ SE', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32229602', 'ALLIED BANKING CORPORATION', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32229702', 'ALLIED BANKING CORPORATION', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60939102', 'ALLIED IRISH BANKS P.L.C.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60939502', 'ALLIED IRISH BANKS P.L.C.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3856301', 'ALPHA WERTPAPIERHANDELS GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('651601', 'ALTE LEIPZIGER BAUSPAR AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4729901', 'ALTE LEIPZIGER HOLDING AKTIENGESELLSCHAFT', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('952401', 'ALTE LEIPZIGER LEBENSVERSICHERUNGSGESELLSCHAFT AUF', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('651501', 'ALTE LEIPZIGER TRUST INVESTMENT-GESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('735501', 'ALTONAER SPAR- UND BAUVEREIN EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4661201', 'AMB GENERALI ASSET MANAGERS KAPITALANLAGEGESELLSCH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('951801', 'AMB GENERALI HOLDINGS AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2652001', 'AMPEGAGERLING ASSET MANAGEMENT GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1598201', 'AMPEGAGERLING INVESTMENT GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3940701', 'ANB AMRO HYPOTHEKEN GROEP B.V. (DEUTSCHLAND)', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4193702', 'ANDORRA BANC AGRICOL REIG SA', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43395102', 'ANGLO IRISH BANK CORPORATION PLC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38691902', 'ANGLO-ROMANIAN BANK LTD', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('530901', 'ANTON HAFNER OHG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1521201', 'APO ASSET MANAGEMENT GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1599301', 'APO IMMOBILIEN- KAPITALANLAGEGESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2167301', 'ARAG ALLGEMEINE RECHTSSCHUTZ-VERSICHERUNGS-AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('615801', 'ARBEITGEBERVERBAND DES PRIVATEN BANKGEWERBES E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4852801', 'ARCHELON DEUTSCHLAND GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('517001', 'ARCHON CAPITAL BANK DEUTSCHLAND GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41618702', 'ARICONSEC INVESTMENT GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50498402', 'ASIAN DEVELOPMENT BANK', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2166901', 'ASSTEL LEBENSVERSICHERUNG AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('66268602', 'ATTIJARIWAFA BANK', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68549502', 'ATTIJARIWAFA BANK', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63962302', 'ATTIJARIWAFA BANK', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39675702', 'ATTIJARIWAFA BANK EUROPE', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5691101', 'AUGSBURGER AKTIENBANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('548401', 'AUGUSTA-BANK EG RVB', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4658801', 'AUMA KREDITBANK GMBH & CO. KG, BANK FUR FINANZIERU', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53464502', 'AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('804101', 'AUSTRIA BETEILIGUNGSGESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26532902', 'AUTOBANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1264901', 'AUTOEUROPA BANK', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1415601', 'AVIAREPS AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('8551702', 'AVIVA PLC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4321101', 'AXA BANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('731301', 'AXA INVESTMENT MANAGERS DEUTSCHLAND GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2167901', 'AXA KONZERN AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('802901', 'AXA LEBENSVERSICHERUNG AKTIENGESELLSCHAFT', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4729001', 'AXA VERSICHERUNG AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4491401', 'AXG INVESTMENTBANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('514301', 'B. METZLER SEEL. SOHN & CO. KGAA', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36441002', 'B.I.N. BANK JSB', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2854201', 'BAADER BANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4520901', 'BAADER SERVICE BANK GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4809902', 'BACHE COMMODITIES LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2005301', 'BAD WALDSEER BANK EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('575901', 'BADEN-WURTTEMBERGISCHE BANK - UNSELBSTANDIGE ANSTA', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4670401', 'BADEN-WURTTEMBERGISCHE INVESTMENTGESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4883201', 'BADEN-WURTTEMBERGISCHE WERTPAPIERBORSE STUTTGART', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('616701', 'BADISCHER GENOSSENSCHAFTSVERBAND E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1201101', 'BAECKER-DARLEHNSKASSE AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1748401', 'BAG BANKAKTIENGESELLSCHAFT', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34243402', 'BANCA CARIGE S.P.A. - CASSA DI RISPARMIO DI GENOVA', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49690402', 'BANCA D''ITALIA', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49698502', 'BANCA D''ITALIA', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14906202', 'BANCA MONTE DEI PASCHI DI SIENA S.P.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15414102', 'BANCA MONTE DEI PASCHI DI SIENA S.P.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60267402', 'BANCA NAZIONALE DEL LAVORO', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69412202', 'BANCA NAZIONALE DEL LAVORO', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31627902', 'BANCA POPOLARE DI VERONA S. GEMINIANO E S. PROSPER', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57809102', 'BANCA POPOLARE DI VICENZA-S.C.P.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('7466402', 'BANCO ABN AMRO REAL S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68094302', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17899302', 'BANCO BPI, S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17939202', 'BANCO COMERCIAL PORTUGUES S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17591402', 'BANCO COMERCIAL PORTUGUES S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45989702', 'BANCO COMERCIAL PORTUGUES S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41478002', 'BANCO COOPERATIVO ESPANOL, S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60847402', 'BANCO DE ORO-EPCI, INC.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57362602', 'BANCO DE SABADELL, S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29157702', 'BANCO DO BRASIL S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54826802', 'BANCO ESPANOL DE CREDITO, S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56516802', 'BANCO ESPIRITO SANTO, S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25932402', 'BANCO ITAU EUROPA S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69053202', 'BANCO ITAU, S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58452202', 'BANCO MERCANTIL, C.A., (BANCO UNIVERSAL)', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17759902', 'BANCO NACIONAL DE COMERCIO EXTERIOR, S.N.C.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38399002', 'BANCO PASTOR S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('66662802', 'BANCO POPULAR ESPANOL', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60327202', 'BANCO SANTANDER (BRASIL) S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32449602', 'BANCO SANTANDER S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32641802', 'BANCO SANTANDER S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('12351902', 'BANCO SANTANDER S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('12410802', 'BANCO SANTANDER S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54991102', 'BANCO SANTANDER TOTTA S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62506202', 'BANCO SANTANDER TOTTA S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62509802', 'BANCO SANTANDER TOTTA S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60653602', 'BANGKOK BANK PUBLIC COMPANY LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('575001', 'BANK 1 SAAR EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('375201', 'BANK COMPANIE NORD GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2792901', 'BANK DEUTSCHES KRAFTFAHRZEUGGEWERBE AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('652001', 'BANK FUR KIRCHE UND CARITAS EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('549001', 'BANK FUR SOZIALWIRTSCHAFT AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44594602', 'BANK FUR TIROL UND VORARLBERG AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2277102', 'BANK HANDLOWY W WARSZAWIE S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61324002', 'BANK HAPOALIM B.M.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53609602', 'BANK HAPOALIM B.M.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1599701', 'BANK IM BISTUM ESSEN EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('496901', 'BANK JULIUS BAR (DEUTSCHLAND) AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57653202', 'BANK LEUMI LE-ISRAEL B.M.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67038602', 'BANK LEUMI LE-ISRAEL B.M.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('8461002', 'BANK MORGAN STANLEY AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23072202', 'BANK MORGAN STANLEY AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2795801', 'BANK OF AMERICA N.A. MILITARY BANK OVERSEAS DIVISI', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61389402', 'BANK OF AMERICA, NATIONAL ASSOCIATION', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57776602', 'BANK OF CHINA LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67725302', 'BANK OF CHINA LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56715902', 'BANK OF COMMUNICATIONS CO., LTD', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69095302', 'BANK OF MONTREAL', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30701702', 'BANK OF SCOTLAND PLC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5839001', 'BANK SARASIN AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1714501', 'BANK SARASIN AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3168601', 'BANK SCHILLING & CO AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('7904002', 'BANK URALSIB', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20457302', 'BANK VONTOBEL OSTERREICH AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2919502', 'BANK VTB NORTH WEST', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4252802', 'BANK ZACHODNI WBK S.A.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5360101', 'BANKENFACHVERBAND E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1557301', 'BANKENVERBAND BADEN-WURTTEMBERG E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1557401', 'BANKENVERBAND BREMEN E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4648601', 'BANKENVERBAND HAMBURG E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1557501', 'BANKENVERBAND HESSEN E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1968901', 'BANKENVERBAND NIEDERSACHSEN E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1557601', 'BANKENVERBAND RHEINLAND-PFALZ', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('704701', 'BANKENVERBAND SAARLAND E.V', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('704801', 'BANKENVERBAND SCHLESWIG-HOLSTEIN E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4070101', 'BANKENVEREINIGUNG NORDRHEIN-WESTFALEN E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1473001', 'BANKHAUS AUGUST LENZ & CO AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('533301', 'BANKHAUS C.L. SEELIGER', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3164401', 'BANKHAUS CARL F. PLUMP & CO.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5369401', 'BANKHAUS DR. MASEL AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4663001', 'BANKHAUS E. MAYER AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3174001', 'BANKHAUS ELLWANGER & GEIGER KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('372901', 'BANKHAUS GEBR. MARTIN AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('516401', 'BANKHAUS HALLBAUM AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3174901', 'BANKHAUS J. FAISST OHG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5882001', 'BANKHAUS LAMPE KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('359001', 'BANKHAUS LOBBECKE AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('569201', 'BANKHAUS LUDWIG SPERRER KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('521701', 'BANKHAUS MAX FLESSA KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('359601', 'BANKHAUS NEELMEYER AKTIENGESELLSCHAFT', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('494301', 'BANKHAUS OSWALD KRUBER GMBH & CO. KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3171901', 'BANKHAUS W. FORTMANN & SOHNE KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4667701', 'BANKHAUS WERHAHN KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('373201', 'BANKHAUS WOLBERN & CO. (AG & CO. KG)', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('358801', 'BANKVEREIN BEBRA EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('380401', 'BANKVEREIN WERTHER AKTIENGESELLSCHAFT', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50279602', 'BANQUE CENTRALE POPULAIRE', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47572702', 'BANQUE CENTRALE POPULAIRE', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('9524102', 'BANQUE DE GESTION PRIVEE INDOSUEZ - BGPI', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31340602', 'BANQUE DE L''ECONOMIE DU COMMERCE ET DE LA MONETIQU', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42276602', 'BANQUE FEDERATIVE DU CREDIT MUTUEL', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38161602', 'BANQUE MAROCAINE DU COMMERCE EXTERIEUR', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2193002', 'BANQUE MAROCAINE DU COMMERCE EXTERIEUR', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29309302', 'BANQUE PSA FINANCE', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11508202', 'BARCLAYS BANK PLC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11050902', 'BARCLAYS BANK PLC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11050802', 'BARCLAYS BANK PLC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5046802', 'BARCLAYS CAPITAL', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('24837002', 'BARCLAYS GLOBAL INVESTORS LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5814801', 'BARCLAYS INDUSTRIE BANK GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4662401', 'BARCLAYS INDUSTRIE LEASING GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('953701', 'BARMENIA KRANKENVERSICHERUNG AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('646601', 'BAU- UND SPARVEREIN GEISLINGEN EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4663501', 'BAU- UND SPARVEREIN GOPPINGEN EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('733101', 'BAUGENOSSENSCHAFT ESSLINGEN EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('633901', 'BAUGENOSSENSCHAFT FREIE SCHOLLE EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1753301', 'BAUGENOSSENSCHAFT HALTINGEN-WEIL EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4667601', 'BAUGENOSSENSCHAFT MUNCHBERG EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('747201', 'BAUGENOSSENSCHAFT SPAR- UND BAUVEREIN 1895 MANNHEI', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4578401', 'BAUGENOSSENSCHAFT WIEDERAUFBAU EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('747101', 'BAUSPARKASSE MAINZ AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1752201', 'BAUSPARKASSE SCHWABISCH HALL AG, BAUSPARKASSE DER ', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('646301', 'BAUVEREIN BREISGAU EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('748601', 'BAUVEREIN SCHWEINFURT EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3537701', 'BAYER AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3786301', 'BAYERISCHE BEAMTEN LEBENSVERSICHERUNG AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1749601', 'BAYERISCHE BODENSEEBANK  - RAIFFEISEN - EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2474701', 'BAYERISCHE BORSE', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('650701', 'BAYERISCHE GARANTIEGESELLSCHAFT FUR MITTELSTANDISC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5396301', 'BAYERISCHE HYPO- UND VEREINSBANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5874101', 'BAYERISCHE LANDESBANK', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4472101', 'BAYERISCHE RAIFFEISEN-BETEILIGUNGS-AKTIENGESELLSCH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('704901', 'BAYERISCHER BANKENVERBAND E.V.', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('747501', 'BAYERN-INVEST KAPITALANLAGEGESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4578201', 'BAYERNINVEST KAPITALANLAGEGESELLSCHAFT MBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('730701', 'BBB BURGSCHAFTSBANK ZU BERLIN- BRANDENBURG GMBH', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4321301', 'BBBANK EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5830201', 'BCA BANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('648601', 'BEAMTEN-WOHNUNGS-VEREIN ZU HILDESHEIM EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3941801', 'BEAMTEN-WOHNUNGS-VEREIN ZU KOPENICK EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('21412602', 'BEAR STEARNS INTERNATIONAL LIMITED', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('7277702', 'BELARUSBANK OPEN  JOINT STOCK COMPANY', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37639002', 'BENCHMARK CAPITAL MANAGEMENT GMBH/BENCHMARK FINANC', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('730601', 'BENSBERGER BANK EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1599801', 'BERKHEIMER BANK EG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3607101', 'BERLIN-CHEMIE AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('516501', 'BERLIN-HANNOVERSCHE HYPOTHEKENBANK AG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4544001', 'BERLINER BANK AG & CO. KG', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('633701', 'BERLINER BAU- UND WOHNUNGSGENOSSENSCHAFT VON 1892 ', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('633401', 'BERLINER EFFEKTENBANK AG (NIEDERLASSUNG DER QUIRIN', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('697501', 'BERLINER SPARKASSE', 'DE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1582301', 'ECOBANK GABON SA', 'GA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54511', 'COOP A Y C 15 DE AGOSTO PILACOTO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71311', 'COOP A Y C 16 DE JUNIO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71411', 'COOP A Y C 20 DE FEBRERO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3766401', 'COOP A Y C 23 DE JULIO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71511', 'COOP A Y C 23 DE MAYO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4457901', 'COOP A Y C 29 DE OCTUBRE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54811', 'COOP A Y C 4 DE OCTUBRE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54911', 'COOP A Y C 9 DE OCTUBRE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('305911', 'COOP A Y C ABDON CALDERON LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13511', 'COOP A Y C ACCION RURAL LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71611', 'COOP A Y C ACCION TUNGURAHUA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55211', 'COOP A Y C ACCION Y DESARROLLO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55311', 'COOP A Y C AGRARIA MUSHUK KAWSAY LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71711', 'COOP A Y C AGRICOLA JUNIN LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55811', 'COOP A Y C ALFONSO JARAMILLO C.C.C', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55911', 'COOP A Y C ALIANZA DEL VALLE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56311', 'COOP A Y C ALIANZA MINAS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71811', 'COOP A Y C ALLI TARPUC LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56711', 'COOP A Y C AMAZONAS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57411', 'COOP A Y C AMBATO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57611', 'COOP A Y C ANDINA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109711', 'COOP A Y C ANTORCHA LTDA - DEPOSIT', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('295511', 'COOP A Y C ARMADA NACIONAL', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57711', 'COOP A Y C ARTESANOS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57811', 'COOP A Y C ATUNTAQUI LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('174611', 'COOP A Y C CAC-CICA (MIES)', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59211', 'COOP A Y C CACPE BIBLIAN', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13911', 'COOP A Y C CACPE CELICA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67811', 'COOP A Y C CACPE LOJA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14411', 'COOP A Y C CACPE MACARA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20349455', 'COOP A Y C CACPE PASTAZA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14611', 'COOP A Y C CACPE VILCABAMBA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14811', 'COOP A Y C CACPE ZAMORA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('304611', 'COOP A Y C CADECOG - GONZANAMA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4483401', 'COOP A Y C CAJA CENTRAL COOPERATIVA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58311', 'COOP A Y C CALCETA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('72111', 'COOP A Y C CAMARA DE COMERCIO CANTON BOLIVAR', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15211', 'COOP A Y C CAMARA DE COMERCIO DE AMBATO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('72211', 'COOP A Y C CAMARA DE COMERCIO DE PINDAL', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('72411', 'COOP A Y C CAMARA DE COMERCIO INDIGENA DE GUAMOTE ', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('307411', 'COOP A Y C CAMARA DE COMERCIO RIOBAMBA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('313911', 'COOP A Y C CAMARA DE COMERCIO SANTO DOMINGO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23211', 'COOP A Y C CARIMANGA LTDA - DEPOSITO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('72511', 'COOP A Y C CARROCEROS DE TUNGURAHUA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('172011', 'COOP A Y C CASAG LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('72611', 'COOP A Y C CHIBULEO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2733601', 'COOP A Y C CHONE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('183811', 'COOP A Y C CHUNCHI LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('171711', 'COOP A Y C COCA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('72911', 'COOP A Y C COL. FISC. EXPER. VICENTE ROCAFUERTE', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58811', 'COOP A Y C COMERCIO PORTOVIEJO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('73011', 'COOP A Y C CONSTRUCCION, COMERCIO Y PRODUCCION LTD', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('73211', 'COOP A Y C COOPINDIGENA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('73411', 'COOP A Y C CORPORACION CENTRO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2733701', 'COOP A Y C COTOCOLLAO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('73511', 'COOP A Y C CREA LTDA (MIES)', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('73611', 'COOP A Y C CREDIAMIGO LTDA LOJA (MIES)', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('179111', 'COOP A Y C CREDIL LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('309411', 'COOP A Y C CREDISOCIO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('313211', 'COOP A Y C CREDISUR LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20350155', 'COOP A Y C DE LA PEQUENA EMPRESA DE LOJA CACPE LOJ', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('73811', 'COOP A Y C DE LA PEQUENA EMPRESA DE PASTAZA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('171611', 'COOP A Y C DE LOS SERV. PUBL. DEL MIN. DE EDUCACIO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('73911', 'COOP A Y C DEL AZUAY', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('174411', 'COOP A Y C DEL EMIGRANTE ECUATORIANO Y SU FAMILIA ', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4458201', 'COOP A Y C DESARROLLO PUEBLOS', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25211', 'COOP A Y C DORADO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('295611', 'COOP A Y C ECUACREDITOS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('74011', 'COOP A Y C ECUAFUTURO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('74511', 'COOP A Y C EDUCADORES DE CHIMBORAZO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('179911', 'COOP A Y C EDUCADORES DE EL ORO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('304511', 'COOP A Y C EDUCADORES DE LOJA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('74711', 'COOP A Y C EDUCADORES DE ZAMORA CHINCHIPE', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('183911', 'COOP A Y C EDUCADORES TULCAN LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14311', 'COOP A Y C EL PANGUI LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3766801', 'COOP A Y C EL SAGRARIO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('74811', 'COOP A Y C EL TESORO PILLARENO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('74911', 'COOP A Y C EMPLEOS BANCARIOS DEL ORO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('80611', 'COOP A Y C ERCO LTD', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23511', 'COOP A Y C FAMILIA AUSTRAL', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('75411', 'COOP A Y C FERNANDO DAQUILEMA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('75511', 'COOP A Y C FINANCIERA INDIGENA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('75611', 'COOP A Y C FOCLA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('133311', 'COOP A Y C FUNDADESARROLLO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('302911', 'COOP A Y C FUTURO LAMANENSE', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('75711', 'COOP A Y C FUTURO Y PROGRESO DE GALAPAGOS', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('179411', 'COOP A Y C GONZANAMA (MIES)', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('183611', 'COOP A Y C GUAMOTE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('178111', 'COOP A Y C GUARANDA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('178311', 'COOP A Y C HUAYCO PUNGO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('172111', 'COOP A Y C INDIGENA ALFA Y OMEGA LTDA.ALFA Y OMEGA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('298611', 'COOP A Y C INDIGENA SAC LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('80711', 'COOP A Y C INTEGRAL', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59011', 'COOP A Y C JARDIN AZUAYO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4483601', 'COOP A Y C JESUS DEL GRAN PODER LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('75811', 'COOP A Y C JUAN PIO DE MORA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2776601', 'COOP A Y C JUVENTUD ECUATORIANA PROGRESISTA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('297611', 'COOP A Y C JUVENTUD UNIDA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('177311', 'COOP A Y C KISAPINCHA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15411', 'COOP A Y C KULLKI WASI', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4458501', 'COOP A Y C LA DOLOROSA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('184411', 'COOP A Y C LA FLORIDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('306211', 'COOP A Y C LA INMACULADA DE SAN PLACIDO LTDA.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('180311', 'COOP A Y C LA UNION LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('179011', 'COOP A Y C LOS CHASQUIS PASTOCALLE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('306411', 'COOP A Y C MAGISTERIO MANABITA LIMITADA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('81211', 'COOP A Y C MALCHINGUI LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('174811', 'COOP A Y C MAQUITA CUSHUN LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('170611', 'COOP A Y C MAQUITA CUSHUNCHIC LTDA.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('300311', 'COOP A Y C METROPOLIS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58911', 'COOP A Y C MINGA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('75911', 'COOP A Y C MULTIEMPRESARIAL L', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15511', 'COOP A Y C MUSHUC RUNA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('313311', 'COOP A Y C MUSHUK WASI LTDA ( MIES )', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('313411', 'COOP A Y C NUESTROS ABUELOS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('179811', 'COOP A Y C NUEVOS HORIZONTES EL ORO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15611', 'COOP A Y C OLMEDO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20349755', 'COOP A Y C OSCUS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5717101', 'COOP A Y C PABLO MU�?OZ VEGA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20350455', 'COOP A Y C PADRE JULIAN LORENTE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15711', 'COOP A Y C PADRE JULIAN LORENTE LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('184011', 'COOP A Y C PADRE VICENTE PONCE RUBIO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('177811', 'COOP A Y C PARA LA VIVIENDA ORDEN Y SEGURIDAD', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('76011', 'COOP A Y C PEDRO MONCAYO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('178411', 'COOP A Y C PIJAL', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('178711', 'COOP A Y C PILAHUIN', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('171811', 'COOP A Y C PILAHUIN TIO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('305311', 'COOP A Y C POPULAR Y SOLIDARIA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5717301', 'COOP A Y C PREVISION, AHORRO Y DESARROLLO COOPAD', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2733801', 'COOP A Y C PROGRESO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15811', 'COOP A Y C PUELLARO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('172411', 'COOP A Y C PUERTO FRANCISCO DE ORELLANA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55411', 'COOP A Y C PUJILI LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('179511', 'COOP A Y C QUILANGA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3766901', 'COOP A Y C RIOBAMBA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('311411', 'COOP A Y C RIOCHICO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55511', 'COOP A Y C SALINAS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('174111', 'COOP A Y C SAN BARTOLO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3767001', 'COOP A Y C SAN FRANCISCO DE ASIS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20349855', 'COOP A Y C SAN FRANCISCO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('76511', 'COOP A Y C SAN GABRIEL LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('305811', 'COOP A Y C SAN ISIDRO LTDA.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('76611', 'COOP A Y C SAN JUAN DE COTOGCHOA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55611', 'COOP A Y C SAN MARTIN DE TISALEO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16111', 'COOP A Y C SAN MIGUEL DE LOS BANCOS', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16311', 'COOP A Y C SAN MIGUEL DE PALLATANGA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16211', 'COOP A Y C SAN MIGUEL DE SIGCHOS', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('182711', 'COOP A Y C SAN PABLO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16411', 'COOP A Y C SAN PEDRO DE ANDAHUAYLAS', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16511', 'COOP A Y C SAN PEDRO DE TABOADA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55711', 'COOP A Y C SAN PEDRO LTDA.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2776701', 'COOP A Y C SANTA ANA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('76711', 'COOP A Y C SANTA ANITA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('296011', 'COOP A Y C SANTA ISABEL LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('297411', 'COOP A Y C SANTA LUCIA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('306611', 'COOP A Y C SANTA MARIA DE LA MANGA DEL CURA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3767101', 'COOP A Y C SANTA ROSA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56011', 'COOP A Y C SANTA ROSA DE PATUTAN LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('174711', 'COOP A Y C SERVIDORES MUNICIPALES DE CUENCA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56111', 'COOP A Y C SIERRA CENTRO LTDA.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56211', 'COOP A Y C SINCHI RUNA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56411', 'COOP A Y C SOL DE LOS ANDES LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('299911', 'COOP A Y C SOLIDARIDAD Y PROGRESO ORIENTAL', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56511', 'COOP A Y C SUMAC LLACTA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56611', 'COOP A Y C SUMAK SAMY LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4458801', 'COOP A Y C TULCAN', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('301811', 'COOP A Y C UNION EL EJIDO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56811', 'COOP A Y C UNION MERCEDARIA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56911', 'COOP A Y C UNION QUISAPINCHA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('178511', 'COOP A Y C UNIOTAVALO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57111', 'COOP A Y C VALLES DEL LIRIO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57211', 'COOP A Y C VENCEDORES DE TUNGURAHUA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55011', 'COOP A Y C VIRGEN DEL CISNE', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('302311', 'COOP A Y C VISION DE LOS ANDES VISANDES', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('163011', 'COOP CATAMAYO LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('285511', 'COOP DE A Y C  EL DISCAPACITADO  LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('291411', 'COOP DE A Y C CACEC LTDA (COTOPAXI)', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('286311', 'COOP DE A Y C FENIX', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('285811', 'COOP DE A Y C INTERCULT. TARPUK RUNA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('285911', 'COOP DE A Y C INTERCULTURAL TAWANTINSUYU LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('181411', 'COOP DE A Y C LA BENEFICA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('90811', 'COOP DE A Y C LAS LAGUNAS (MIESS)', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('79711', 'COOP DE A Y C LUCHA CAMPESINA LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('294111', 'COOP DE A Y C PARA EL PROGRESO MICROEMPRESARIAL CO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('292211', 'COOP DE A Y C SANTA ANA DE NAYON', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('292411', 'COOP DE A Y C TEXTIL 14 DE MARZO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('291711', 'COOP DE A. Y C. CAMARA DE COMERCIO JOYA DE LOS SAC', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('177011', 'COOP ESFUERZO UNIDO PARA EL DESARR. DEL CHILCO LA ', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('78011', 'COOP MUTUALISTA PICHINCHA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('78311', 'COOP SAN ANTONIO', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('122511', 'COOP SAN JOSE SJ', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20340555', 'COOP. AHORRO Y CREDITO OSCUS', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20340455', 'COOP. DE A Y C EDUCADORES DE PASTAZA LTDA.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('163211', 'COOP. DE A Y C INTI WASI LTD.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('290711', 'COOP. DE A Y C. ESPERANZA Y PROGRESO DEL VALLE', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('290611', 'COOP. DE A Y C. LUZ DEL VALLE', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('285611', 'COOP. DE A. Y C. BANOS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('290811', 'COOP. DE A. Y C. COOPARTAMOS LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('294311', 'COOP. DE A. Y C. DEL DISTRITO METROPOLITANO DE QUI', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('292611', 'COOP. DE A. Y C. ESPERANZA DEL FUTURO LTDA.', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('294011', 'COOP. DE A. Y C. GENERAL ANGEL FLORES LTDA', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4458401', 'COOP. DE A. Y C. GRAMEEN AMAZONAS', 'EC');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20353555', 'AGRICULTURAL BANK OF EGYPT', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50311', 'Ahli United Bank SAE', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50611', 'Al Baraka Bank of Egypt SAE', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50711', 'Al Watany Bank Of Egypt', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20331255', 'ALBARAKA BANK', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51011', 'Arab African International Bank', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51811', 'Arab Bank Plc', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51211', 'Arab Banking Corporation, Egypt - Abc Bank, Egypt', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51411', 'Arab International Bank', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50211', 'Bank Audi S.A.E.', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52111', 'Bank of Alexandria', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49011', 'Banque Du Caire S.A.E.', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('48611', 'Banque Misr', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49311', 'Barclays Bank-Egypt S.A.E.', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49511', 'Blom Bank Egypt Sae', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49711', 'BNP Paribas Le Caire', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51711', 'Citibank, N.A.', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49211', 'Commercial International Bank (Egypt) S.A.E.', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49611', 'Credit Agricole (Egypt)', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52011', 'Egyptian Arab Land Bank', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50911', 'Egyptian Gulf Bank', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51311', 'Export Development Bank of Egypt', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50411', 'Faisal Islamic Bank Of Egypt', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50011', 'Federal Arab Bank for Development and Investment', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50511', 'Housing And Development Bank', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51111', 'HSBC Bank Egypt SAE', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('48911', 'Industrial Development Bank Of Egypt', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52211', 'Mashreq Bank PSC', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49111', 'MISR Iran Development Bank', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50811', 'National Bank For Development', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51611', 'National Bank Of Abu Dhabi', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('48711', 'National Bank Of Egypt', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52311', 'National Bank of Greece', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52411', 'National Bank of Oman SAOG', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49911', 'National Societe Generale Bank Sae', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50111', 'Piraeus Bank Egypt', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20332055', 'QATAR NATIONAL BANK ALAHLI S.A.E', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49411', 'Societe Arabe Internationale De Banque (S.A.I.B.)', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49811', 'Suez Canal Bank', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51911', 'The Bank of Nova Scotia', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('48511', 'United Bank Limited', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16145202', 'United Bank Of Egypt', 'EG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4547201', 'Abank', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5885001', 'BANCO AGRICOLA S.A.', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('184811', 'BANCO ATLANTIDA EL SALVADOR S.A.', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20341355', 'BANCO AZUL', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3158901', 'BANCO CITIBANK DE EL SALVADOR, S.', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5633501', 'BANCO CREDOMATIC, S.A.', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('192911', 'BANCO DAVIVIENDA SALVADORENO S.A', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3159001', 'BANCO DE FOMENTO AGROPECUARIO', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('152411', 'BANCO INDUSTRIAL S.A.', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2815701', 'BANCO PROMERICA, S.A.', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2729501', 'BANCOVI R.L.', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20329155', 'FEDECACES', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('28511', 'FUNDASAL', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13211', 'REMESA SEGURA CUSCATLAN', 'SV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54468802', 'ALLIED IRISH BANKS P.L.C.', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('253911', 'AS INBANK', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1665701', 'AS LHV PANK', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1325101', 'AURORA ACCESS SECURITIES AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('7500802', 'BANK SNORAS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30688802', 'BAYERISCHE HYPO- UND VEREINSBANK AG', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3229301', 'BIGBANK AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('254011', 'COOP PANK', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('185811', 'CRESCO VAARTPABERITE AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42438402', 'DNB PANK', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('490301', 'EESTI KREDIIDIPANK', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('490401', 'EESTI PANK (BANK OF ESTONIA)', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('91311', 'ES CITADELE BANKA EESTI FILIAAL', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1557001', 'ESTONIAN BANKING ASSOCIATION', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('91911', 'ESTONIAN CREDIT BANK', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4970101', 'ESTONIAN CSD', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('254111', 'EVLI BANK LTD', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25197402', 'EVLI BANK PLC', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1325001', 'EVLI SECURITIES AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1689201', 'GILD FINANCIAL ADVISORY SERVICES AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3690601', 'MARFIN PANK EESTI AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34225902', 'NORDDEUTSCHE LANDESBANK GIROZENTRALE', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63337402', 'NORDEA BANK AB ESTONIA BRANCH', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68068502', 'NORDEA BANK DANMARK A/S', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34554402', 'NORDEA BANK NORGE ASA', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('254211', 'OP CORPORATE BANK PLC ESTONIAN BRANCH', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36382202', 'PAREX BANK', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57751902', 'POHJOLA BANK PLC ESTONIAN BRANCH', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3379902', 'PUBLIC JOINT STOCK COMPANY BALTIYSKIY BANK', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3159201', 'SEB PANK AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('745102', 'SIEMENS FINANCIAL SERVICES AKTIEBOLAG', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30558902', 'SVENSKA HANDELSBANKEN AB (PUBL)', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('24735102', 'SVENSKA HANDELSBANKEN AB ESTONIAN BRANCH', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4077201', 'TALLINN BUSINESS BANK LTD', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1014301', 'TALLINN STOCK EXCHANGE', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('33420302', 'UNICREDIT BANK AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('91411', 'VERSOBANK AS', 'EE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('107711', 'ABAY BANK SC', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('98611', 'ADDIS INTERNATIONAL BANK', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4479601', 'AWASH INTERNATIONAL BANK S.C.', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16911', 'BANK OF ABYSSINIA', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('78111', 'BERHAN INTERNATIONAL BANK', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('132711', 'BUNNA INTERNATIONAL BANK S.C.,', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('544301', 'COMMERCIAL BANK OF ETHIOPIA', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('106511', 'COOPERATIVE BANK OF OROMIA', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('132811', 'DASHEN BANK S.C', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('70411', 'DEBUB GLOBAL BANK S.C', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('106311', 'ENAT BANK S.C', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1632101', 'LION INTERNATIONAL BANK S.C.', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5714201', 'NIB INTERNATIONAL BANK S.C.', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1528901', 'OROMIA INTERNATIONAL BANK S.C.', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20330955', 'UNITED BANK OF ETHIOPIA', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3784601', 'WEGAGEN BANK', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20330855', 'ZEMEN BANK SC', 'ET');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('354601', 'AKTIA BANK PLC', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('259911', 'BANK OF ALAND PLC', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260011', 'BONUM BANK PLC', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260711', 'DANSKE KIINNITYSLUOTTOPANKKI OYJ', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260311', 'ELITE PRIVATE BANKING LTD', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('257511', 'ERIK SELIN BANKERS LTD', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2749101', 'EVLI BANK PLC', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260111', 'FOREX BANK AB, FILIAL I FINLAND', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('258511', 'LAMMIN SAASTOPANKKI', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1443501', 'NORDIC INVESTMENT BANK', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260211', 'NORDNET BANK AB SUOMEN SIVULIIKE', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('259011', 'OP CORPORATE BANK PLC', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260411', 'RESURS BANK AB SUOMEN SIVULIIKE', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('259211', 'S-BANK LTD', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260511', 'SEB KORT BANK AB, HELSINGIN SIVULIIKE', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260611', 'TF BANK AB, FILIAL FINLAND', 'FI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5012301', '123 VENTURE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2651301', '21 SOCIETE CENTRALE POUR L''INDUSTRIE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1637001', '2I2C ASSET MANAGEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5135201', '360 AM', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5011701', 'A PLUS FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1302101', 'A2 GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4088701', 'AAREAL BANK FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4990901', 'AAZ FINANCES SA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2659301', 'ABAXBOURSE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4828701', 'ABBEY NATIONAL FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25257102', 'ABBEY NATIONAL TREASURY SERVICES PLC (UK)', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1379701', 'ABC ARBITRAGE ASSET MANAGEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17194302', 'ABC INTERNATIONAL BANK PLC', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1147801', 'ABE CLEARING SAS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4985701', 'ABF ASSET MANAGEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1572501', 'ABF CAPITAL MANAGEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1076601', 'ABN AMRO COMMUNICATIONS INTERNATIONALES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4525901', 'ABN AMRO FIXED INCOME FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5780101', 'ABN AMRO FUTURES FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2472501', 'ACCEA FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5110001', 'ACE MANAGEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5006901', 'ACER FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5020201', 'ACROPOLE AM', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1351801', 'ACTIGEP', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4855801', 'ACTION CONTREPARTIE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3276101', 'ACTIS PATRIMOINE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1610901', 'ADEQUATION FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1325501', 'ADI ALTERNATIVE INVESTMENTS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1307201', 'ADREA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1611101', 'AESOPE GESTION DE PORTEFEUILLES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4991001', 'AFI EUROPE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3276201', 'AFI EUROPE IARD', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3276301', 'AFORGE GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4497101', 'AGCO FINANCE SNC', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2783901', 'AGEBANQUE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('547001', 'AGENCE FRANCAISE DE DEVELOPPEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1302301', 'AGF ALTERNATIVE ASSET MANAGEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2472601', 'AGF ASSET MANAGEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1307301', 'AGF CASH', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2180201', 'AGF FINANCEMENT 2', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3276401', 'AGF PRIVATE BANKING', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('996901', 'AGFA FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3276501', 'AGICAM', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4985801', 'AGILIS GESTION SA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1611201', 'AGIRA RETRAITE CADRES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4991101', 'AGIRA RETRAITE SALARIES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1629501', 'AGIRC', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1629601', 'AGLAE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1302401', 'AGPM ASSURANCES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5038101', 'AGREGATOR GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5132401', 'AGRICA EPARGNE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4745101', 'AGRIFIGEST-ALMA - SOCIETE FINANCIERE ET AGRICOLE D', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1572601', 'AIG VIE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4745501', 'AIPAL CREDIT SOCIETE ANONYME DE CREDIT IMMOBILIER ', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5023001', 'AIR FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5054801', 'AIRBUS SAS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5034201', 'AIVELYS ASSET MANAGEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('546701', 'AL KHALIJI FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('954401', 'ALCATEL LUCENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1316601', 'ALCIS SECURITIES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3297301', 'ALCYONE FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1483701', 'ALEXANDRE FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4470601', 'ALFABANQUE SA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2658601', 'ALFI GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4985901', 'ALICO', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5700901', 'ALLIANZ BANQUE S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60939402', 'ALLIED IRISH BANKS P.L.C.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1114001', 'ALMA FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1647001', 'ALOE PRIVATE EQUITY SAS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1113701', 'ALPHABOURSE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5750601', 'ALSABAIL - ALSACIENNE DE CREDIT BAIL IMMOBILIER', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4744601', 'ALSOLIA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1326001', 'ALSTOM HOLDINGS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1576501', 'ALSYON TECHNOLOGIES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1707401', 'ALTAVIA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3297401', 'ALTEIS MUTUELLES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5021201', 'ALTEN', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2797101', 'ALTER FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1113801', 'ALTERNATIVE AND DERIVATIVE INVESTMENTS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5110301', 'ALTERNATIVE LEADERS FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1629701', 'ALTIVIE ASSET MANAGEMENT GROUPE ALTIV', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1326101', 'ALTO INVEST', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4855201', 'ALTUS FINANCE GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1217601', 'ALTUS PATRIMOINE ET GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3507601', 'AM FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2168901', 'AMERICAN EXPRESS CARTE FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1634001', 'AMIRAL GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1581501', 'AMPLEGEST', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1865501', 'AMPLEO GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1637201', 'ANTARIUS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2782601', 'ANTEE S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4986101', 'ANTEIS EPARGNE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1630001', 'ANTENOR', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2177901', 'ANTIN-BAIL', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3271001', 'APAS BATIMENT TRAVAUX PUBLICS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5001901', 'APEI', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1302501', 'APICIL GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1628601', 'APOGE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1324701', 'APREP DIFFUSION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1324801', 'APRIL ASSURANCES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5001201', 'APRIL DEVELOPPEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5001301', 'APRIL SOLUTIONS ENTREPRISES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3421901', 'APTAR GROUP SAS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5689501', 'ARCA, BANQUE DU PAYS BASQUE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1628701', 'ARCALIS ACTIF GENERAL LA POSTE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1138301', 'ARCELOR TREASURY SNC', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1316701', 'ARFINCO', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1572801', 'ARGOVIE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3296201', 'ARIAL ASSURANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1637301', 'ARJIL', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4991401', 'ARKEON FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1572901', 'ARPEGE FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1628801', 'ARRCO', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1233701', 'ARROCHE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4742301', 'ARTESIA BAIL', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1581601', 'ASCOT FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5001501', 'ASF COMPTE PIVOT GROUPE ASF', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3271101', 'ASSET ALLOCATIONS ADVISORS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1302601', 'ASSOCIATION ADMINISTRATIVE AGRR', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('704601', 'ASSOCIATION FRANCAISE DES ETABLISSEMENTS DE CREDIT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4648501', 'ASSOCIATION FRANCAISE DES SOCIETES FINANCIERES (AS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1637101', 'ASSOCIATION NATIONALE D''ENTRAIDE ET DE PREVOYANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3296401', 'ASSOCIATION RENOUVEAU CARMF', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1302701', 'ASSURVAL', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5115601', 'ATHYMIS GESTION', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2659001', 'ATOS ORIGIN INFOGERANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3609901', 'ATOS WORLDLINE FINANCIAL MARKETS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1001501', 'ATRADIUS FACTORING', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54090402', 'ATTIJARIWAFA BANK', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54091202', 'ATTIJARIWAFA BANK', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59361002', 'ATTIJARIWAFA BANK', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63963302', 'ATTIJARIWAFA BANK', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63963502', 'ATTIJARIWAFA BANK', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5793901', 'ATTIJARIWAFA BANK EUROPE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1110801', 'AUBOYNEAU, LABOURET, OLLIVIER S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17727902', 'AUDI SARADAR PRIVATE BANK SAL', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5023301', 'AUREL', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4553801', 'AUREL MONEY MARKET', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4497201', 'AUREL NEXTSTAGE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5007001', 'AURIS GESTION PRIVEE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65966502', 'AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('954701', 'AUTOMOBILES PEUGEOT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4609701', 'AUTORITE DES MARCHES FINANCIERS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5001601', 'AUTOROUTES DU SUD DE LA FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5009801', 'AUXIA IMMOBILIER', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4741301', 'AUXICOMI', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5751901', 'AUXIFIP', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2182501', 'AUXIMURS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5009901', 'AVENIR FINANCE GESTION SA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4986201', 'AVENIR FINANCE INVESTISSEMENT MANAGERS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1573101', 'AVIP ASSURANCE VIE ET PREVOYANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1325201', 'AVIP LILLE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3270701', 'AVIVA COURTAGE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3270201', 'AVIVA DIRECT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3781501', 'AVIVA FRANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3270301', 'AVIVA GESTION D ACTIFS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5001701', 'AVIVA VIE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3296701', 'AWF', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2169301', 'AXA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2836801', 'AXA BANQUE FINANCEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3161201', 'AXA BANQUE S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4985201', 'AXA COURTAGE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('8797302', 'AXA EPARGNE ENTREPRISE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2651401', 'AXA FRANCE FINANCE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('812301', 'AXA FRANCE VIE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1628901', 'AXA INVESTMENT MANAGERS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4991501', 'AXA INVESTMENT MANAGERS IF', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3452001', 'AXA INVESTMENT MANAGERS PRIVATE EQUITY EUROPE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1301101', 'AXA MULTIMANAGER LIMITED', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1687201', 'AXIOM ALTERNATIVE INVESTMENTS', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1216801', 'AZUR - FINANCES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1629001', 'AZUR ASSURANCES IARD', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1636901', 'AZUR GMF MUTUELLES ASSURANCES ASSOCIEES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2182901', 'B*CAPITAL', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1365702', 'BACHE COMMODITIES LIMITED', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1611801', 'BACHE EQUITIES LIMITED', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1110901', 'BADENIA BAUSPARKASSE AG', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1075601', 'BAIL BANQUE POPULAIRE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1270301', 'BAIL ECONOMIE', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4499401', 'BAIL ENTREPRISES', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3018601', 'BAIL EQUIPEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2181201', 'BAIL IMMO NORD', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2472701', 'BAIL INVESTISSEMENT', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4499501', 'BAIL-ACTEA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3296801', 'BALZAC SHORT TERM', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34241602', 'BANCA CARIGE S.P.A. - CASSA DI RISPARMIO DI GENOVA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34243102', 'BANCA CARIGE S.P.A. - CASSA DI RISPARMIO DI GENOVA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49698602', 'BANCA D''ITALIA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49998802', 'BANCA D''ITALIA', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15414002', 'BANCA MONTE DEI PASCHI DI SIENA S.P.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56578302', 'BANCA NAZIONALE DEL LAVORO', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56578802', 'BANCA NAZIONALE DEL LAVORO', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('46153702', 'BANCA POPOLARE DI VERONA S. GEMINIANO E S. PROSPER', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60234202', 'BANCA POPOLARE DI VICENZA-S.C.P.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40216502', 'BANCA REGIONALE EUROPEA S.P.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54469602', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52991102', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52991202', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53141602', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53245902', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'FR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68311', 'CAPITAL LOCAL AREA BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('151211', 'CAPITAL SMALL FINANCE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('536201', 'CENTRAL BANK OF INDIA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45515402', 'CITI BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3698401', 'CITIZEN CREDIT COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3178701', 'CITY UNION BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('368811', 'Coastal Local Area Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63311', 'COMMONWEALTH BANK OF AUSTRALIA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('536701', 'CORPORATION BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63411', 'CREDIT AGRICOLE CORP AND INVESTMENT BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43234402', 'CREDIT SUISSE A.G', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('537301', 'CSB BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60498302', 'CTBC Bank Co.  Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59083302', 'DBS BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5624201', 'DCB BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('536301', 'DENA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('151311', 'DEOGIRI NAGARI SAHAKARI BANK LTD. AURANGABAD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68811', 'DEPOSIT INSURANCE AND CREDIT GUARANTEE CORPORATION', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29747702', 'DEUSTCHE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135411', 'DEVELOPMENT BANK OF SINGAPORE', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580801', 'DHANALAKSHMI BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('122311', 'DOHA BANK QSC', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2691401', 'DOMBIVLI NAGARI SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('151411', 'EQUITAS SMALL FINANCE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134511', 'EXPORT IMPORT BANK OF INDIA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5869301', 'FEDERAL BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('161711', 'FINO PAYMENTS BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31234002', 'FIRSTRAND BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65411', 'G P PARSIK BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65111', 'GADCHIROLI DISTRICT CENTRAL CO-OPERATIVE BANK LTD.', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('384101', 'GURGAON GRAMIN BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('151511', 'HIMACHAL PRADESH STATE COOPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52666302', 'HSBC BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580101', 'IDBI BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134411', 'IDFC BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('161811', 'IDUKKI DISTRICT CO OPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3178801', 'INDIAN BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5869401', 'INDIAN OVERSEAS BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('659101', 'INDUSIND BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('70011', 'INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4424801', 'JALGAON JANATA SAHAKARI BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580701', 'JAMMU AND KASHMIR BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109011', 'JANAKALYAN SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('108211', 'JANASEVA SAHAKARI BANK BORIVLI LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69011', 'JANASEVA SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('681101', 'JANATA SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('205611', 'JIO PAYMENTS BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26200002', 'JP MORGAN CHASE BANK N.A.', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63611', 'KALLAPPANNA AWADE ICHALKARANJI JANATA SAHAKARI BAN', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2725701', 'KALUPUR COMMERCIAL CO-OPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5855601', 'KALYAN JANATA SAHAKARI BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('108511', 'KAPOL COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69111', 'KAPOLE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('536801', 'KARNATAKA BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('350611', 'Karnataka gramin bank', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('78211', 'KARNATAKA VIKAS GRAMEENA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3178601', 'KARUR VYSYA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('151711', 'KEB HANA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('98011', 'KERALA GRAMIN BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('352011', 'Kookmin Bank', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4732801', 'KOTAK MAHINDRA BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('205711', 'KOZHIKODE DISTRICT COOPERATIAVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580601', 'LAXMI VILAS BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4453201', 'MAHANAGAR COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('151811', 'MAHARASHTRA GRAMIN BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3178201', 'MAHARASHTRA STATE COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65787902', 'MASHREQBANK PSC', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53311502', 'MIZUHO CORPORATE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('363411', 'Model Cooperative Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('108611', 'NAGAR URBAN CO OPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3237001', 'NAGPUR NAGARIK SAHAKARI BANK LTD.', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('70211', 'NATIONAL AUSTRALIA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135211', 'NATIONAL BANK OF ABU DHABI PJSC', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2691501', 'NEW INDIA CO-OPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5706801', 'NKGSB COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('384001', 'NORTH MALABAR GRAMIN BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3698801', 'NUTAN NAGARIK SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5882401', 'ORIENTAL BANK OF COMMERCE', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('161911', 'PAYTM PAYMENTS BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('105911', 'PRAGATHI KRISHNA GRAMIN BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('384601', 'PRATHAMA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63911', 'PRIME COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('151911', 'PT BANK MAYBANK INDONESIA TBK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5685101', 'PUNJAB AND MAHARSHTRA COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('537101', 'PUNJAB AND SIND BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('384701', 'PUNJAB NATIONAL BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69211', 'RABOBANK INTERNATIONAL (CCRB)', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('352111', 'Rajarshi Shahu Sahakari Bank Ltd  Pune', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('108711', 'RAJGURUNAGAR SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3698901', 'RAJKOT NAGARIK SAHAKARI BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('384501', 'RBL Bank Limited', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580301', 'RESERVE BANK OF INDIA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('108811', 'SAHEBRAO DESHMUKH COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135311', 'SAMARTH SAHAKARI BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('282811', 'Sant Sopankaka Sahakari Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('383901', 'SARASWAT COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64211', 'SBER BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134711', 'SHIKSHAK SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56937102', 'SHINHAN BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135511', 'SHIVALIK MERCANTILE CO OPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64411', 'SHRI CHHATRAPATI RAJASHRI SHAHU URBAN COOPERATIVE ', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31994502', 'SOCIETE GENERALE', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('70311', 'SOLAPUR JANATA SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('537401', 'SOUTH INDIAN BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10311802', 'STANDARD CHARTERED BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20331555', 'STATE BANK OF INDIA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50277402', 'STATE BANK OF MAURITIUS LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('364711', 'Suco Souharda Sahakari Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64611', 'SUMITOMO MITSUI BANKING CORPORATION', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134911', 'SURAT NATIONAL COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64511', 'SUTEX COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('536901', 'SYNDICATE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('384901', 'TAMILNAD MERCANTILE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2691801', 'THE A.P. MAHESH COOPERATIVE URBAN BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63211', 'THE AKOLA DISTRICT CENTRAL COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('655701', 'THE ANDHRA PRADESH STATE COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4446801', 'THE COSMOS CO OPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('108011', 'THE DELHI STATE COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('162211', 'THE GADCHIROLI DISTRICT CENTRAL COOPERATIVE BANK L', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4446701', 'THE GREATER BOMBAY COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5738201', 'THE GUJARAT STATE COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134811', 'THE HASTI COOP BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2728801', 'THE JALGAON PEOPELS COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('108911', 'THE KANGRA CENTRAL COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65211', 'THE KANGRA CO-OPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3747301', 'THE KARAD URBAN CO-OP BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('536001', 'THE KARANATAKA STATE COOPERATIVE APEX BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63711', 'THE KURMANCHAL NAGAR SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64011', 'THE MEHSANA URBAN COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63811', 'THE MUMBAI DISTRICT CENTRAL COOPERATIVE BANK LIMIT', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580201', 'THE MUNICIPAL CO-OPERATIVE BANK, LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('681001', 'THE NAINITAL BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64111', 'THE NASIK MERCHANTS COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('162311', 'THE NAVNIRMAN CO-OPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('368611', 'The Nawanagar Cooperative Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('152011', 'THE PANDHARPUR URBAN CO OP. BANK LTD. PANDHARPUR', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('368711', 'The Punjab State Cooperative Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3787701', 'THE RAJASTHAN STATE COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10074002', 'THE ROYAL BANK OF SCOTLAND N V', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64311', 'THE SEVA VIKAS CO-OPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('162411', 'THE SEVA VIKAS COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580401', 'THE SHAMRAO VITHAL COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('162511', 'THE SINDHUDURG DISTRICT CENTRAL COOP BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64711', 'THE SURAT DISTRICT COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3751501', 'THE SURATH PEOPLES COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5737601', 'THE TAMIL NADU STATE APEX COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65311', 'THE THANE BHARAT SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2774501', 'THE THANE DISTRICT CENTRAL COOPERATIVE BANK LIMITE', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('361811', 'The Udaipur Urban Co Operative Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64811', 'THE VARACHHA COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69411', 'THE VISHWESHWAR SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5739001', 'THE WEST BENGAL STATE COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134611', 'THE ZOROASTRIAN COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69311', 'TJSB SAHAKARI BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64911', 'TUMKUR GRAIN MERCHANTS COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19309702', 'UBS AG', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('536401', 'UCO BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('162711', 'UJJIVAN SMALL FINANCE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3178301', 'UNITED BANK OF INDIA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69811', 'UNITED OVERSEAS BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('162611', 'UTKARSH SMALL FINANCE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('206911', 'VASAI JANATA SAHAKARI BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65011', 'VASAI VIKAS SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5890801', 'VIJAYA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20333655', 'VPBank', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69511', 'WESTPAC BANKING CORPORATION', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69611', 'WOORI BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4498401', 'YES BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69911', 'ZILA SAHAKRI BANK LIMITED GHAZIABAD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236211', 'SPARISJOOUR MYRASYSLU', 'IS');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236111', 'SPARISJOOURINN I KEFLAVIK', 'IS');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5874601', 'BANK HAPOALIM B.M.', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5893301', 'BANK LEUMI LE-ISRAEL B.M.', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2580401', 'BANK MASSAD LTD', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2816501', 'BANK OF JERUSALEM LTD', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5871201', 'ISRAEL DISCOUNT BANK LIMITED', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('584301', 'MERCANTILE DISCOUNT BANK LIMITED', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5873501', 'MIZRAHI TEFAHOT BANK LTD', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5878701', 'THE FIRST INTERNATIONAL BANK OF ISRAEL LTD', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5869501', 'UNION BANK OF ISRAEL LTD', 'IL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2647501', 'A.B.P. SIM MILANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4949601', 'A.C. GIRARDI E C. SIM', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37122702', 'AAREAL BANK AG', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('807501', 'ABANELLA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('502401', 'ABAXBANK S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36060502', 'ABBEY NATIONAL PLC', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36060702', 'ABBEY NATIONAL PLC', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40187702', 'ABBEY NATIONAL PLC', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17194202', 'ABC INTERNATIONAL BANK PLC', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5846401', 'ABN AMRO ASSET MANAGEMENT ITALY SGR S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3569501', 'ACEAELECTRABEL TRADING SPA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('982801', 'ACQUASERVICE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('22044402', 'ADVICORP PUBLIC LIMITED COMPANY', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1985601', 'AEM TRADING SRL', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2171301', 'AGRICAR DIESEL', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4672801', 'AGRILEASING - BANCA PER IL LEASING DELLE BANCHE DI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('983901', 'ALBATROS INDUSTRIA CONCIARIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4734001', 'ALDEGHI LUIGI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('694201', 'ALETTI & C. BANCA DI INVESTIMENTO MOBILIARE S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3276601', 'ALETTI GESTIELLE ALTERNATIVE SGR S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5088201', 'ALITALIA-LINEE AEREE ITALIANE S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('983401', 'ALLEANZA ASSICURAZIONI S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('189502', 'ALLFUNDS BANK, S.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1536501', 'ALLIANZ BANK FINANCIAL ADVISORS S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1375501', 'ALLIANZ GLOBAL INVESTORS ITALIA SGR S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5025601', 'ALLIANZ GLOBAL INVESTORS ITALIA SGR S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('809001', 'ALLIANZ RAS S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('809401', 'ALLIANZ-LLOYD ADRIATICO S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32229502', 'ALLIED BANKING CORPORATION', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3582801', 'ALMO NATURE S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31011602', 'ALPENBANK AKTIENGESELLSCHAFT', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1985801', 'ALTO ADIGE BANCA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29208902', 'AMERICAN EXPRESS BANK LTD', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5004601', 'ANIMA SGRPA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3526001', 'AR ENTERPRISE S.R.L.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11838502', 'ARAB BANK PLC', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('12211502', 'ARAB BANK PLC', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29134202', 'ARAB BANKING CORPORATION B.S.C.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4785501', 'ARCA SGR S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2245001', 'ARCA SIM S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19154802', 'AS PRIVATBANK', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2171401', 'ASSICURAZIONI GENERALI S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1558001', 'ASSOCIAZIONE BANCARIA ITALIANA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1558201', 'ASSOCIAZIONE FRA LE CASSE DI RISPARMIO ITALIANE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5798801', 'ASSOCIAZIONE ITALIANA OPERATORI MERCATI DEI CAPITA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1558101', 'ASSOCIAZIONE NAZIONALE BANCHE PRIVATE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5019701', 'ASSOSIM', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1338301', 'ATLANTIA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('156311', 'ATTIJARIWAFA BANK EUROPE SEDE SECONDARIA ITALIANA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2170801', 'AUTOROMEA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('939101', 'AZIMUT SGR S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1854501', 'B.C.C. DEL GARDA - BANCA DI CREDITO COOPERATIVO CO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4903201', 'BAI SIM', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2842001', 'BANCA 24-7 S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4677501', 'BANCA ADIGE PO CREDITO COOPERATIVO LUSIA - SOCIETA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('710501', 'BANCA ADRIA - CREDITO COOPERATIVO DEL DELTA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1727901', 'BANCA AGCI S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('408601', 'BANCA AGRICOLA POPOLARE DI RAGUSA S.C.A.R.L.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5907601', 'BANCA AKROS S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2842101', 'BANCA ALBERTINI SYZ & C S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1831201', 'BANCA ALPI MARITTIME CREDITO COOPERATIVO CARRU', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('790501', 'BANCA ALTO VICENTINO CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5869701', 'BANCA ANTONVENETA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2842201', 'BANCA APUANA - CREDITO COOPERATIVO DI MASSA CARRAR', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('586701', 'BANCA APULIA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27959602', 'BANCA ARNER SA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1829401', 'BANCA ATESTINA DI CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5719101', 'BANCA BSI ITALIA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3181401', 'BANCA CAPASSO ANTONIO S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61011', 'BANCA CARIGE ITALIA SPA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4218401', 'BANCA CARIGE S.P.A. - CASSA DI RISPARMIO DI GENOVA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3299801', 'BANCA CARIM - CASSA DI RISPARMIO DI RIMINI S.P.A', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3182501', 'BANCA CARIME S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('681401', 'BANCA CASSA DI RISPARMIO DI SAVIGLIANO S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('789901', 'BANCA CENTRO EMILIA - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('585701', 'BANCA CESARE PONTI S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4632201', 'BANCA COOPERATIVA CATTOLICA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4464601', 'BANCA CRAS - CREDITO COOPERATIVO SOVICILLE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2753301', 'BANCA CREMASCA - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('789101', 'BANCA CREMONESE CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('714701', 'BANCA CRV CASSA DI RISPARMIO DI VIGNOLA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('713501', 'BANCA D''ITALIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3777301', 'BANCA DEI COLLI EUGANEI - CREDITO COOPERATIVO - LO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2747001', 'BANCA DEI DUE MARI DI CALABRIA - CREDITO COOPERATI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1831301', 'BANCA DEI SIBILLINI - CREDITO COOPERATIVO DI CASAV', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('832101', 'BANCA DEL CANAVESE - CREDITO COOPERATIVO DI VISCHE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1853801', 'BANCA DEL CENTROVENETO - CREDITO COOPERATIVO SCARL', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('787201', 'BANCA DEL CILENTO - CREDITO COOPERATIVO CILENTO CE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3371501', 'BANCA DEL COMPRENSORIO DEL CUOIO DI CASTELFRANCO D', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1854001', 'BANCA DEL CROTONESE - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('713401', 'BANCA DEL FUCINO S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2015801', 'BANCA DEL LAVORO E DEL PICCOLO RISPARMIO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3299001', 'BANCA DEL MONTE DI LUCCA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('705501', 'BANCA DEL MUGELLO - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('409501', 'BANCA DEL PIEMONTE S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3228001', 'BANCA DEL SUD S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('344411', 'Banca del Territorio Lombardo Credito Cooperativo ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4678901', 'BANCA DEL VALDARNO - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1856901', 'BANCA DELL''ADDA CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3871901', 'BANCA DELL''ADRIATICO S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3572701', 'BANCA DELL''ARTIGIANATO E DELL''INDUSTRIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('694701', 'BANCA DELL''ELBA CREDITO COOPERATIVO - SOCIETA COOP', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1856201', 'BANCA DELLA BERGAMASCA CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('539701', 'BANCA DELLA CAMPANIA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1536301', 'BANCA DELLA CIOCIARIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1853501', 'BANCA DELLA COSTA D''ARGENTO - CREDITO COOPERATIVO ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1854701', 'BANCA DELLA MARCA CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('708001', 'BANCA DELLA MAREMMA - CREDITO COOPERATIVO DI GROSS', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2842301', 'BANCA DELLA NUOVA TERRA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3261001', 'BANCA DELLA PROVINCIA DI MACERATA S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('786201', 'BANCA DELLA TUSCIA CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1829801', 'BANCA DELLA VALPOLICELLA CREDITO COOPERATIVO DI MA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('695001', 'BANCA DELLA VALSASSINA - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4635801', 'BANCA DELLE MARCHE S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4673701', 'BANCA DELLO JONIO - CREDITO COOPERATIVO - ALBIDONA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4679401', 'BANCA DI ANCONA - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1336501', 'BANCA DI ANDRIA DI CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('788301', 'BANCA DI ANGHIARI E STIA CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4675501', 'BANCA DI BEDIZZOLE TURANO VALVESTINO CREDITO COOPE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('584701', 'BANCA DI BERGAMO S.P.A.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1830501', 'BANCA DI BIENTINA CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('831601', 'BANCA DI BOLOGNA CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('788901', 'BANCA DI CAPRANICA CREDITO COOPERATIVO SOCIETA COO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4733401', 'BANCA DI CARAGLIO, DEL CUNEESE E DELLA RIVIERA DEI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('709801', 'BANCA DI CARNIA E GEMONESE - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4675901', 'BANCA DI CASCINA - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('707901', 'BANCA DI CAVOLA E SASSUOLO CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1827901', 'BANCA DI CESENA - CREDITO COOPERATIVO DI CESENA E ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('707101', 'BANCA DI CHIANCIANO TERME CREDITO COOPERATIVO VAL ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('540701', 'BANCA DI CIVIDALE SPA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('707501', 'BANCA DI COSENZA - CREDITO COOPERATIVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('361011', 'BANCA DI CREDITO CCOERATIVO DI MILANO SOCIETA COOR', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4610001', 'BANCA DI CREDITO COOPERATIVO - BANCA DI SIRACUSA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('710201', 'BANCA DI CREDITO COOPERATIVO - TARSIA (COSENZA)', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('706801', 'BANCA DI CREDITO COOPERATIVO ABRUZZESE - CAPPELLE ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1401101', 'BANCA DI CREDITO COOPERATIVO AGRIGENTINO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2746901', 'BANCA DI CREDITO COOPERATIVO AGROBRESCIANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1521501', 'BANCA DI CREDITO COOPERATIVO ANTONELLO DA MESSINA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5035501', 'BANCA DI CREDITO COOPERATIVO BANCA BRUTIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3770701', 'BANCA DI CREDITO COOPERATIVO CAMUNA (ESINE-BRESCIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1856701', 'BANCA DI CREDITO COOPERATIVO DEGLI ULIVI - TERRA D', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('708101', 'BANCA DI CREDITO COOPERATIVO DEI CASTELLI E DEGLI ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1831601', 'BANCA DI CREDITO COOPERATIVO DEI CASTELLI ROMANI  ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4673301', 'BANCA DI CREDITO COOPERATIVO DEI COMUNI CILENTANI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('706901', 'BANCA DI CREDITO COOPERATIVO DEL BASSO SEBINO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4674401', 'BANCA DI CREDITO COOPERATIVO DEL BELICE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4464801', 'BANCA DI CREDITO COOPERATIVO DEL CARSO - ZADRUZNA ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3770801', 'BANCA DI CREDITO COOPERATIVO DEL CHIANTI FIORENTIN', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4673201', 'BANCA DI CREDITO COOPERATIVO DEL CIRCEO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2747101', 'BANCA DI CREDITO COOPERATIVO DEL FRIULI CENTRALE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('694901', 'BANCA DI CREDITO COOPERATIVO DEL GARIGLIANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4674701', 'BANCA DI CREDITO COOPERATIVO DEL LAMETINO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3776801', 'BANCA DI CREDITO COOPERATIVO DEL METAURO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1829501', 'BANCA DI CREDITO COOPERATIVO DEL MOLISE-SAN MARTIN', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2171201', 'BANCA DI CREDITO COOPERATIVO DEL NISSENO DI SOMMAT', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1856101', 'BANCA DI CREDITO COOPERATIVO DEL POLESINE - ROVIGO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('787101', 'BANCA DI CREDITO COOPERATIVO DEL POLLINO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('791301', 'BANCA DI CREDITO COOPERATIVO DEL TUSCOLO - ROCCA P', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('812201', 'BANCA DI CREDITO COOPERATIVO DEL VELINO (COMUNE DI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('788601', 'BANCA DI CREDITO COOPERATIVO DEL VENEZIANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3832901', 'BANCA DI CREDITO COOPERATIVO DELL''ADRIATICO TERAMA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1830001', 'BANCA DI CREDITO COOPERATIVO DELL''ALTA BRIANZA - A', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('786001', 'BANCA DI CREDITO COOPERATIVO DELL''ALTA MURGIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2746801', 'BANCA DI CREDITO COOPERATIVO DELL''ALTA PADOVANA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1830101', 'BANCA DI CREDITO COOPERATIVO DELL''ALTO RENO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1830401', 'BANCA DI CREDITO COOPERATIVO DELL''ALTO TIRRENO DEL', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('788001', 'BANCA DI CREDITO COOPERATIVO DELLA BASSA FRIULANA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5801101', 'BANCA DI CREDITO COOPERATIVO DELLA CONTEA DI MODIC', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('950101', 'BANCA DI CREDITO COOPERATIVO DELLA MONTAGNA PISTOI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1831501', 'BANCA DI CREDITO COOPERATIVO DELLA ROMAGNA OCCIDEN', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('709701', 'BANCA DI CREDITO COOPERATIVO DELLA SIBARITIDE - SP', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('709601', 'BANCA DI CREDITO COOPERATIVO DELLA SILA PICCOLA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('831901', 'BANCA DI CREDITO COOPERATIVO DELLA VALLE DEL FITAL', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('787301', 'BANCA DI CREDITO COOPERATIVO DELLA VALLE DEL TRIGN', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4675601', 'BANCA DI CREDITO COOPERATIVO DELLA VALTROMPIA - BO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4464701', 'BANCA DI CREDITO COOPERATIVO DELLE PREALPI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1853601', 'BANCA DI CREDITO COOPERATIVO DI ALBA LANGHE E ROER', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4675301', 'BANCA DI CREDITO COOPERATIVO DI ALBEROBELLO E SAMM', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4727601', 'BANCA DI CREDITO COOPERATIVO DI ALTAVILLA SILENTIN', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1830201', 'BANCA DI CREDITO COOPERATIVO DI ALTOFONTE E CACCAM', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('705701', 'BANCA DI CREDITO COOPERATIVO DI ANAGNI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('705601', 'BANCA DI CREDITO COOPERATIVO DI AQUARA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('705801', 'BANCA DI CREDITO COOPERATIVO DI ARBOREA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4675401', 'BANCA DI CREDITO COOPERATIVO DI AVETRANA (TA)', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('706301', 'BANCA DI CREDITO COOPERATIVO DI BARBARANO ROMANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('753201', 'BANCA DI CREDITO COOPERATIVO DI BARI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('788401', 'BANCA DI CREDITO COOPERATIVO DI BARLASSINA (MI)', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4674601', 'BANCA DI CREDITO COOPERATIVO DI BASCIANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('788501', 'BANCA DI CREDITO COOPERATIVO DI BASILIANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4739401', 'BANCA DI CREDITO COOPERATIVO DI BELLEGRA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('705901', 'BANCA DI CREDITO COOPERATIVO DI BENE VAGIENNA (CUN', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4673801', 'BANCA DI CREDITO COOPERATIVO DI BORGHETTO LODIGIAN', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('790901', 'BANCA DI CREDITO COOPERATIVO DI BRESCIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1853701', 'BANCA DI CREDITO COOPERATIVO DI BUCCINO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('706401', 'BANCA DI CREDITO COOPERATIVO DI BUONABITACOLO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1830701', 'BANCA DI CREDITO COOPERATIVO DI BUSTO GAROLFO E BU', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4510101', 'BANCA DI CREDITO COOPERATIVO DI CAGLIARI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('707401', 'BANCA DI CREDITO COOPERATIVO DI CALCIO E DI COVO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4074101', 'BANCA DI CREDITO COOPERATIVO DI CAMBIANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1830901', 'BANCA DI CREDITO COOPERATIVO DI CAMPIGLIA DEI BERI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1854101', 'BANCA DI CREDITO COOPERATIVO DI CANOSA - LOCONIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('788801', 'BANCA DI CREDITO COOPERATIVO DI CAPACCIO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1831101', 'BANCA DI CREDITO COOPERATIVO DI CARATE BRIANZA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4675801', 'BANCA DI CREDITO COOPERATIVO DI CARAVAGGIO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('707001', 'BANCA DI CREDITO COOPERATIVO DI CARTURA (PADOVA)', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('585101', 'BANCA DI CREDITO COOPERATIVO DI CARUGATE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1857001', 'BANCA DI CREDITO COOPERATIVO DI CASALGRASSO E SANT', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('789201', 'BANCA DI CREDITO COOPERATIVO DI CASCIA DI REGGELLO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1831401', 'BANCA DI CREDITO COOPERATIVO DI CASSANO DELLE MURG', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4676001', 'BANCA DI CREDITO COOPERATIVO DI CASTAGNETO CARDUCC', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('789301', 'BANCA DI CREDITO COOPERATIVO DI CASTEL GOFFREDO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('789501', 'BANCA DI CREDITO COOPERATIVO DI CASTENASO (BOLOGNA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('789601', 'BANCA DI CREDITO COOPERATIVO DI CASTIGLIONE MESSER', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('787401', 'BANCA DI CREDITO COOPERATIVO DI CERNUSCO SUL NAVIG', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4676201', 'BANCA DI CREDITO COOPERATIVO DI CHERASCO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4676301', 'BANCA DI CREDITO COOPERATIVO DI CITTANOVA - SOC.CO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('789701', 'BANCA DI CREDITO COOPERATIVO DI CIVITANOVA MARCHE ', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('788701', 'BANCA DI CREDITO COOPERATIVO DI COLOBRARO E VALSIN', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('707301', 'BANCA DI CREDITO COOPERATIVO DI CONVERSANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4676401', 'BANCA DI CREDITO COOPERATIVO DI CORINALDO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1831801', 'BANCA DI CREDITO COOPERATIVO DI CREMENO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4676501', 'BANCA DI CREDITO COOPERATIVO DI CRETA - CREDITO CO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4680401', 'BANCA DI CREDITO COOPERATIVO DI DOBERDO E SAVOGNA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('791101', 'BANCA DI CREDITO COOPERATIVO DI DOVERA E POSTINO (', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('695901', 'BANCA DI CREDITO COOPERATIVO DI FALCONARA MARITTIM', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4676601', 'BANCA DI CREDITO COOPERATIVO DI FANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4676801', 'BANCA DI CREDITO COOPERATIVO DI FILOTTRANO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4676901', 'BANCA DI CREDITO COOPERATIVO DI FIUGGI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('790001', 'BANCA DI CREDITO COOPERATIVO DI FIUMICELLO ED AIEL', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('790101', 'BANCA DI CREDITO COOPERATIVO DI FLUMERI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4677101', 'BANCA DI CREDITO COOPERATIVO DI FORNACETTE', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('707801', 'BANCA DI CREDITO COOPERATIVO DI GAMBATESA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('790201', 'BANCA DI CREDITO COOPERATIVO DI GATTEO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('707601', 'BANCA DI CREDITO COOPERATIVO DI GAUDIANO DI LAVELL', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4677201', 'BANCA DI CREDITO COOPERATIVO DI GHISALBA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('790301', 'BANCA DI CREDITO COOPERATIVO DI GRADARA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1853901', 'BANCA DI CREDITO COOPERATIVO DI IMPRUNETA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('710801', 'BANCA DI CREDITO COOPERATIVO DI INZAGO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4677301', 'BANCA DI CREDITO COOPERATIVO DI LAURENZANA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('790401', 'BANCA DI CREDITO COOPERATIVO DI LESMO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4677401', 'BANCA DI CREDITO COOPERATIVO DI LEVERANO (LE)', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('694501', 'BANCA DI CREDITO COOPERATIVO DI MAIERATO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2806001', 'BANCA DI CREDITO COOPERATIVO DI MANZANO S.C.A.R.L.', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('790801', 'BANCA DI CREDITO COOPERATIVO DI MARCON - VENEZIA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1854401', 'BANCA DI CREDITO COOPERATIVO DI MASIANO (PISTOIA)', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3833001', 'BANCA DI CREDITO COOPERATIVO DI MASSAFRA', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('361111', 'BANCA DI CREDITO COOPERATIVO DI MILANO SOCIETA COO', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39511', 'ORABANK GABON', 'GA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('283311', 'UNITED BANK FOR AFRICA GABON', 'GA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5358901', 'BANK OF GEORGIA JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20350955', 'BASISBANK JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351155', 'CARTU BANK JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65611', 'CREDO BANK JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351655', 'HALYK BANK GEORGIA JSC 

JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351855', 'ISBANK GEORGIA JSC 



JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20350855', 'LIBERTY BANK JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351955', 'PASHA BANK GEORGIA JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351255', 'PROCREDIT BANK JSC

 JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351355', 'SILK ROAD BANK JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351455', 'TBC BANK JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351755', 'TERABANK JSC



JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351055', 'VTB BANK (GEORGIA) JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20351555', 'ZIRAAT BANK GEORGIA JSC', 'GE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1631701', 'ACCESS BANK GAMBIA', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4387601', 'ARAB-GAMBIA ISLAMIC BANK LIMITED', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31611', 'BAYBA FINANCIAL SERVICES', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5007101', 'BSIC GAMBIA LIMITED', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3392101', 'ECOBANK GAMBIA', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5722901', 'GUARANTY TRUST BANK (GAMBIA) LTD', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5370401', 'INTERNATIONAL BANK FOR COMMERCE (GAMBIA) LTD', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26011', 'MEGABANK GAMBIA LIMITED', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1548901', 'PRIME BANK GAMBIA LTD', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26811', 'RELIANCE FINANCIAL SERVICES', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109111', 'SKYE BANK GAMBIA', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('493901', 'STANDARD CHARTERED BANK GAMBIA LIMITED', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('548101', 'TRUST BANK LTD.', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27311', 'ZENITH BANK GAMBIA', 'GM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('176211', '	AKWAPIM RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('176311', '	AMANANO RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('176411', '	ANKOBRA WEST RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('176511', '	BANGMARIGU COMMUNITY BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('176711', '	CAPITAL RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175511', 'ABOKOBI AREA RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3605401', 'ACCESS BANK (GHANA) LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175911', 'ADA RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20356055', 'ADANSI RURAL BANK', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('533701', 'AGRICULTURAL DEVELOPMENT BANK', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('176011', 'AHAFO ANO PREMIER RURAL BANK', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('174911', 'AMANSIE WEST RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1197901', 'ARB APEX BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175011', 'ASAWINSO RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175111', 'ASOKORE RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('79011', 'BANK OF AFRICA(gh) Ltd', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1791001', 'BANK OF BARODA (GHANA) LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('577401', 'BARCLAYS BANK OF GHANA LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('176611', 'BOSOMTWE RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1687601', 'BSIC GHANA LTD', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1555801', 'CAL MERCHANT BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2767401', 'CONSOLIDATED BANK LTD (FORMER UNIBANK  LIMITED GHA', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4636101', 'ECOBANK GHANA LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20328955', 'FBN BANK (GHANA) LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3269201', 'FIDELITY BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2815501', 'FIRST ATLANTIC MERCHANT BANK LTD', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('79411', 'FIRST CAPITAL PLUS BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('344811', 'FIRST NATIONAL BANK GHANA LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('533801', 'GHANA COMMERCIAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('344711', 'GHL BANK LTD', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('133411', 'GLOBAL ACCESS SAVINGS AND LOANS COMPANY LTD', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1522401', 'GUARANTY TRUST BANK (GHANA) LTD', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4364101', 'HFC BANK (GHANA) LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5372901', 'INTERNATIONAL COMMERCIAL BANK', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175311', 'KAASEMAN RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175611', 'KUMAWUMAN RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175711', 'KWAMANMAN RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('176811', 'MEPE AREA RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('158811', 'MULTI CREDIT SAVINGS AND LOANS', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('533901', 'NATIONAL INVESTMENT BANK LTD', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175411', 'NYAKROM RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2015601', 'PRUDENTIAL BANK LTD', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('175811', 'SEFWIMAN RURAL BANK LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('577501', 'SG-SSB LTD', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2664801', 'STANBIC BANK GHANA LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10514802', 'STANDARD CHARTERED BANK', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('577601', 'STANDARD CHARTERED BANK GHANA LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('78911', 'THE ROYAL BANK ltd', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4521901', 'UNITED BANK FOR AFRICA (GHANA) LTD.', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3175401', 'UNIVERSAL MERCHANT BANK', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4524701', 'ZENITH BANK (GHANA) LIMITED', 'GH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('277711', 'BALTICA BANK (GIBRALTAR) LTD', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('277811', 'BANK J. SAFRA SARASIN (GIBRALTAR) LTD', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('277911', 'BANK JSS (GIBRALTAR) LTD', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5055001', 'CLOSE BROTHERS MARRACHE BANK LIMITED', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('278011', 'GIBRALTAR AND IBERIAN BANK LTD', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('278111', 'GIBRALTAR INTERNATIONAL BANK LIMITED', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('278211', 'JYSKE BANK (GIBRALTAR) LTD.', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1401801', 'LLOYDS BANK (GIBRALTAR) LIMITED', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('95011', 'NATWEST-GIBRALTAR', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('278311', 'SG KLEINWORT HAMBROS BANK (GIBRALTAR) LIMITED', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('278411', 'SPRINGFIELD BANK AND TRUST LTD', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3175701', 'TURICUM PRIVATE BANK LIMITED', 'GI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('374911', 'ECOBANK GUINEE S.A', 'GN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('168111', 'NSIA BANQUE GUINEE', 'GN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('78511', 'ORABANK GUINEA', 'GN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20330655', 'UNITED BANK FOR AFRICA- GUINEE', 'GN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5737401', 'AEGEAN BALTIC BANK S.A.', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('534301', 'ALPHA BANK AE', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('381401', 'ATTICA BANK SA', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268611', 'B AND N BANK GREEK BRANCH', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268511', 'BANK OF AMERICA, N.A. ATHENS', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2662601', 'BLACK SEA TRADE AND DEVELOPMENT BANK', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42130802', 'BMW AUSTRIA BANK GMBH', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65080302', 'BNP PARIBAS GRECE', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268711', 'CETELEM SA CETELEM BANK', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36068502', 'CITIBANK EUROPE PLC GREECE BRANCH', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16811902', 'CITIBANK N.A.', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('33861202', 'CREDICOM CONSUMER FINANCE BANK S.A.', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268811', 'DAIMLERCHRYSLER BANK POLSKA SA', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('567001', 'EUROBANK ERGASIAS S.A.', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40906202', 'FCE BANK PLC', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1256801', 'GMAC BANK GMBH', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34084802', 'HSBC FRANCE ATHENS BRANCH', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5693201', 'INVESTMENT BANK OF GREECE S.A.', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5396201', 'NATIONAL BANK OF GREECE S.A.', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268911', 'NATIONAL INVESTMENT BANK FOR INDUSTRIAL DEVELOPMEN', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('534201', 'PIRAEUS BANK SA', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('269011', 'PROCREDIT BANK (BULGARIA) EAD THESSALONIKI BRANCH', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27652702', 'SOCIETE GENERALE BANK AND TRUST (HELLAS)', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10618202', 'SOCIETE GENERALE GREECE', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('13431702', 'T.C. ZIRAAT BANKASI ATHENS CENTRAL BRANCH', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44462902', 'UNICREDIT BANK AG (HYPOVEREINSBANK) ATHENS', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('49852602', 'VOLKSWAGEN BANK GMBH', 'GR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5890601', 'BANCO AGROMERCANTIL DE GUATEMALA, S.A.', 'GT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3914301', 'BANCO AZTECA DE GUATEMALA, S.A.', 'GT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5869001', 'BANCO DE DESARROLLO RURAL, S.A. (BANRURAL)', 'GT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3175901', 'BANCO G & T  CONTINENTAL S.A.', 'GT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5882301', 'BANCO INDUSTRIAL S.A.', 'GT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29890402', 'BANCO PROMERICA, S.A.', 'GT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('312511', 'BANCO DA UNIAO - S.A', 'GW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('167111', 'BANQUE ATLANTIQUE GUINEA-BISSAU', 'GW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3310401', 'ECOBANK GUINEA BISSAU', 'GW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109311', 'ORABANK GUINEA-BISSAU', 'GW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69752102', 'BANK OF NOVA SCOTIA', 'GY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2728901', 'CITIZENS BANK GUYANA INCORPORATED', 'GY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5884001', 'DEMERARA BANK LIMITED', 'GY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('381901', 'GUYANA BANK FOR TRADE AND INDUSTRY LIMITED', 'GY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5679301', 'NEW BUILDING SOCIETY LTD.', 'GY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5906301', 'REPUBLIC BANK (GUYANA) LIMITED', 'GY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27084702', 'ALLAHABAD BANK', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5878501', 'BANK OF CHINA (HONG KONG) LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63427002', 'BANK OF CHINA LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56647902', 'BANK OF COMMUNICATIONS CO., LTD', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5890701', 'CHINA CONSTRUCTION BANK (ASIA) CORPORATION LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('578901', 'CHIYU BANKING CORPORATION LTD.', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5868301', 'CHONG HING BANK LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3797101', 'CITIBANK (HONG KONG) LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4475001', 'CITIC INTERNATIONAL FINANCIAL HOLDINGS LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('610301', 'DAH SING BANK, LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('382801', 'DBS BANK (HONG KONG) LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('579401', 'FUBON BANK (HONG KONG) LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5889801', 'HANG SENG BANK LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5896601', 'INDUSTRIAL AND COMMERCIAL BANK OF CHINA (ASIA) LIM', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('6601', 'NANYANG COMMERCIAL BANK, LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5876801', 'OCBC WING HANG BANK, LTD', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1219001', 'ONWARD SECURITIES CO', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('382701', 'PUBLIC BANK (HONG KONG) LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5908101', 'SHANGHAI COMMERCIAL BANK LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2793701', 'STANDARD CHARTERED BANK LTD', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5901701', 'THE BANK OF EAST ASIA, LIMITED', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5867801', 'THE HONGKONG AND SHANGHAI BANKING CORP LTD', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5868201', 'WING LUNG BANK, LTD', 'HK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5891901', 'BANCO ATLANTIDA, S.A.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4578901', 'BANCO AZTECA DE HONDURAS, S.A.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5878301', 'BANCO DAVIVIENDA HONDURAS SA.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('133711', 'BANCO DE DESARROLLO RURAL, S.A. (BANRURAL)', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('578801', 'BANCO DE HONDURAS, S.A.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3176301', 'BANCO DE LOS TRABAJADORES', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('578601', 'BANCO DE OCCIDENTE, S.A.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5900601', 'BANCO DEL PAIS, S.A.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5912101', 'BANCO FICOHSA', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5876701', 'BANCO FINANCIERA CENTROAMERICANA, S.A. (FICENSA)', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4321701', 'BANCO HONDURENO DEL CAFE, S.A.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2809901', 'BANCO LAFISE (HONDURAS), S.A.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4590401', 'BANCO POPULAR COVELO S.A.', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2826502', 'BANCO PROCREDIT', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2731801', 'BANCO PROMERICA SA', 'HN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('382201', 'BANQUE DE L''UNION HAITIENNE, S.A.', 'HT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20329855', 'Banque Populaire Haïtienne', 'HT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20329955', 'Capital Bank', 'HT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45515302', 'CITIBANK, N.A.', 'HT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5869101', 'SOGEBANK', 'HT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4484401', 'SOGEBEL', 'HT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4484301', 'UNIBANK', 'HT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934801', 'ABASAR ES  VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4852701', 'ABN AMRO HOARE GOVETT HUNGARY/RT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1610801', 'ACCESS INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1611001', 'AEGON HUNGARY INVESTMENT FUND MANAGEMENT COMPANY L', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1530401', 'AEGON MAGYARORSZAG BEFEKTETESI JEGY FORGALMAZO ZRT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4721501', 'AGRIA BELAPATFALVA TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1686901', 'AGRIBROKER KFT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1686801', 'AGRIMPEX KFT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1380001', 'AGROKONT ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('799201', 'ALBA TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4986001', 'ALLAMADOSSAG KEZELO KOZPONT RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4726301', 'ALLIANZ HUNGARIA BIZTOSITO RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4721601', 'ALSOJASZSAGI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4721701', 'ALSONEMEDI ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('535801', 'ALTALANOS ERTEKFORGALMI BANK RT-AEB RT (GENERAL BA', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('796801', 'ALTALANOS KOZLEKEDESI HITELSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934901', 'APATFALVI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036601', 'ASVANYRAROI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1576601', 'AXA MAGYARORORSZAG BEFEKTETESI ALAPKEZELO ZRT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('935001', 'BACSKA TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('947401', 'BAK ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('799301', 'BAKONYVIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('796501', 'BALATON-FELVIDEKI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036501', 'BALATONFOLDVAR ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('799401', 'BALMAZUJVAROS ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14925602', 'BANCA MONTE DEI PASCHI DI SIENA S.P.A.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57362702', 'BANCO DE SABADELL, S.A.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4379201', 'BANCO POPOLARE HUNGARY BANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('24085302', 'BANCO PRIMUS S.A.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39012502', 'BANK FUR TIROL UND VORARLBERG AG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('66104302', 'BANK HAPOALIM B.M.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5743401', 'BANK OF CHINA (HUNGARIA) HITELINTEZET RT.(BANK OF ', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63729102', 'BANK OF CHINA LIMITED', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4563101', 'BANK PLUS BANK ZARTKORUEN MUKODO RESZVENYTARSASAG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4843001', 'BANKAR BEFEKTETESI RT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40189102', 'BARCLAYS CAPITAL', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('796601', 'BATASZEK ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5109302', 'BAUSPARKASSE SCHWABISCH HALL AG, BAUSPARKASSE DER ', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('796701', 'BIATORBAGY ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934601', 'BIHARKERESZTES ES  VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('947301', 'BIHARNAGYBAJOM ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5034401', 'BIZTONSAG INVEST SECURITIES INC.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('35928802', 'BKS BANK AG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53882802', 'BNP PARIBAS', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('7085902', 'BNP PARIBAS SECURITIES SERVICES', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4725001', 'BOKOD ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('947601', 'BOLDVA ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934701', 'BOLY ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('796301', 'BOROTAI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3411901', 'BUDAPEST ALAPKEZELO ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1273101', 'BUDAPEST COMMODITY EXCHANGE', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('383401', 'BUDAPEST HITEL- ES FEJLESZTESI BANK NYRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3275801', 'BUDAPEST INVESTMENT MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1067301', 'BUDAPEST STOCK EXCHANGE', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('947501', 'BUKKALJA TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1610501', 'CA IB INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20163002', 'CA IB INVESTMENTBANK AG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('579701', 'CALYON BANK HUNGARY', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4721401', 'CEGLEDBERCELI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1610601', 'CIB INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3177801', 'CIB KOZEP-EUROPAI NEMZETOZI BANK RT. (CENTRAL-EURO', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40322002', 'CITIBANK EUROPE PLC', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1376001', 'CODEX ERTEKTAR ES ERTEKPAPIR ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1974701', 'COMMERZBANK (BUDAPEST) RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54918002', 'COMMERZBANK AKTIENGESELLSCHAFT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1224901', 'CONCORDE ERTEKPAPIR UGYNOKSEG RT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2731701', 'CREDIGEN BANK RT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('33861302', 'CREDIT INDUSTRIEL ET COMMERCIAL', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1091601', 'CREDIT SUISSE - BUDAPEST', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3274601', 'CREDIT SUISSE ASSET MANAGEMENT HUNGARY INVESTMENT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4725401', 'CSERHATVIDEKE KORZETI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4725101', 'DEL-BALATON TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934501', 'DEL-PEST MEGYEI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2161301', 'DEL-ZALAI EGYESULT TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42036102', 'DEUTSCHE BANK AKTIENGESELLSCHAFT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3729901', 'DEUTSCHE BANK RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('796401', 'DOBROKOZI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4725201', 'DOMOSZLO ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4725301', 'DRAVAMENTI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036301', 'DREGELYPALANK ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036401', 'DUNAFOLDVAR ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('947701', 'DUNAKANYAR TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934301', 'DUNAPATAJ ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42043902', 'DZ BANK AG DEUTSCHE ZENTRAL-GENOSSENSCHAFTSBANK', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('799501', 'ECSEG ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('798401', 'EGER ES KORNYEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936901', 'ELLA ELSO LAKASHITEL KERESKEDELMI BANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1286601', 'ELLA FIRST MORTGAGE COMMERCIAL BANK LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936501', 'ELSO KISALFOLD HITELSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934401', 'ENDROD ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1653701', 'EQUILOR INVESTMENT PLC.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159501', 'ERCSI ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159601', 'ERD ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936601', 'ERSEKVADKERT ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1038701', 'ERSTE BANK BEFEKESTI ZRT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5892201', 'ERSTE BANK HUNGARY ZRT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1306301', 'ERSTE INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('796201', 'ESZAK TOLNA MEGYEI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723701', 'ESZTERGOMI ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26536702', 'EUROHYPO AKTIENGESELLSCHAFT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1306401', 'EUROPA INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36069702', 'EUROPEAN BANK FOR RECONSTRUCTION AND DEVELOPMENT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936301', 'FADD ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2161401', 'FAY ANDRAS TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('33377102', 'FCE BANK PLC', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159401', 'FEGYVERNEK ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723601', 'FEHERTO ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723501', 'FELSOZSOLCA ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4456601', 'FHB JELZALOGBANK NYRT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5799501', 'FHB KERESKEDELMI BANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39700702', 'FIO FINANCIAL GROUP', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936801', 'FOKUSZ TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('798501', 'FORRAS TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('798301', 'FORRO ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57728502', 'FORTIS BANK SA/NV', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936701', 'FUNDAMENTA-LAKASKASSZA LAKAS-TAKAREKPENZTAR RT. (F', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3274301', 'FUTUREAL INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4721201', 'FUZESABONY ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936401', 'GADOROS ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3274401', 'GENERALI INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3007101', 'GIRO CREDIT INVESTMENT (BUDAPEST)LT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3405401', 'GLENCORE GRAIN HUNGARY KFT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2582101', 'GMAC HUNGARY FINANCIAL SERVICES LTD', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4948901', 'GOG SECURITIES LIMITED', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('937101', 'GYONGYOS-MATRA TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159101', 'GYULAI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4721301', 'HAJDUDOROG ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('798101', 'HAJDUSAGI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159201', 'HAJOS ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('937001', 'HALASZI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3392501', 'HAMILTON ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('456101', 'HANWHA BANK MAGYARORSZAG RT. (HANWHA BANK HUNGARY ', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('798601', 'HAROMKO TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723901', 'HARTAI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1382701', 'HATARIDOS TOZSDEIPAR KFT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4724001', 'HATVAN ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('798201', 'HEVIZ ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4725501', 'HODASZ-PORCSALMA TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936201', 'HOSSZUPALYI ES KORNY. TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1382801', 'HUNGARIA ORDER KFT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('705401', 'HUNGARIAN BANKING ASSOCIATION', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4492401', 'HUNGARIAN FINANCIAL SUPERVISORY AUTHORITY', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5035401', 'HUNGAROGRAIN ZRT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('8068902', 'HYPO-BANK BURGENLAND AKTIENGESELLSCHAFT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4968701', 'HYPO-SECURITIES HUNGARIA RT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723801', 'IBRANY ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1305501', 'IE INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1689601', 'IKR-BROKER TOZSDEUGYNOKI KFT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14784402', 'INVESTKREDIT BANK AG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036201', 'JASZAROKSZALLAS ES VIDEKE KORZ. TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159701', 'JASZFENYSZARU ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159001', 'JOGAZDA SZOVETKEZETI TAKAREKPENZTAR', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3273401', 'K AND H SECURITIES INVESTMENT FUND MANAGEMENT COMP', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934201', 'KABA ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('798701', 'KAPOLNASNYEK ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4486701', 'KARPATIA HITELSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25790902', 'KBC BANK DEUTSCHLAND AG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3374401', 'KBC EQUITAS ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1375601', 'KBC SECURITIES N.V. HUNGARIAN BRANCH OFFICE', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('901401', 'KDB BANK (MAGYARORSZAG) RT  (KDB BANK HUNGARY LTD)', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159801', 'KELER RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('502101', 'KERESKEDELMI ES HITELBANK RT. (Formerly K&H BANK Z', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('947801', 'KETHELY ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('937301', 'KEVERMES ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('947901', 'KIS-RABA MENTI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('937401', 'KISDUNAMENTI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('797801', 'KISKUNDOROZSMAI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160001', 'KISKUNFELEGYHAZI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('933901', 'KISZOMBOR ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936001', 'KOMADI ES VIDEKE KORZETI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('936101', 'KONDOROSI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934001', 'KORMEND ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723401', 'KORNYE ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('937201', 'KUNSZENTMARTON ES VID TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('797901', 'LAKITELEKI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58125702', 'LANDESBANK BADEN-WURTTEMBERG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('937501', 'LEBENY-KUNSZIGET ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4724101', 'LETAVERTES ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160201', 'LOVO ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159301', 'MAGNET BANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036101', 'MAGYAR ALLAMKINCSTAR', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4379101', 'MAGYAR CETELEM RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5636701', 'MAGYAR EXPORT-IMPORT BANK RT. (EXIM BANK LTD.)', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2052201', 'MAGYAR NEMZETI BANK (NATIONAL BANK OF HUNGARY)', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2161901', 'MAGYAR POSTA RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('535901', 'MAGYAR TAKAREKSZOVETKEZETI BANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4724901', 'MAGYARORSZAGI VOLKSBANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2159901', 'MECSEKKORNYEK HITELSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2037101', 'MECSEKVIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('579801', 'MERKANTIL BANK RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2161501', 'MEZOKERESZTES ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160301', 'MFB HUNGARIAN DEVELOPMENT BANK PRIVATE LIMITED COM', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5892101', 'MKB BANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3273701', 'MKB INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2037001', 'MOHACS ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723301', 'MONOR ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160101', 'MORAHALOM ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('799701', 'NADASD-ORSEG  EGYESULT TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('797701', 'NAGYATAD ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160401', 'NAGYBAJOM ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036801', 'NAGYECSED ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('934101', 'NAGYHALASZ ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4724201', 'NAGYKATA ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723001', 'NAGYMANYOK ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036901', 'NAGYREDE ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4721101', 'NAGYVAZSONYI KINIZSI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('797601', 'NEMESNADUDVAR ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4924001', 'NEW YORK BROKER BUDAPEST RT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1391001', 'NOMURA SECURITIES HUNGARY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5996402', 'NOVA LJUBLJANSKA BANKA D.D., LJUBLJANA', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4723101', 'NYIRBELTEKI KORZETI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2036001', 'NYIRSEGI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160501', 'NYUL ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23283902', 'OBERBANK AG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('799601', 'ORKENYI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18250902', 'OSTERREICHISCHE VOLKSBANKEN-AG', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5869201', 'OTP BANK PLC.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1574001', 'OTP INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5742601', 'OTP JELZALOGBANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4725601', 'OTP LAKASTAKAREKPENZTAR RT. (OTP BUILDING SOCIETY ', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4988001', 'OTP REAL ESTATE INVESTMENT FUND MANAGEMENT COMPANY', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('948101', 'OTTHON LAKAS-TAKAREKPENZTAR RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160601', 'PACSA ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160701', 'PANNON TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4720801', 'PANNONHALMA ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('935901', 'PARTISCUM XI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('798801', 'PECEL ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160801', 'PERESZTEG ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4720901', 'PILISMAROT-DOMOS TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('797501', 'PILISVOROSVAR ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4722701', 'PINCEHELY-OZORA ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3393401', 'PLANINVEST BROKER ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4722801', 'POCSAJ ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4724301', 'POLGARI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5636801', 'PORSCHE BANK HUNGARY RT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1257001', 'POSTABANK ERTEKPAPIR RT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4722901', 'POSTAI ELSZAMOLO KOZPONT', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3272601', 'PRUDENT-INVEST INVESTMENT FUND MANAGEMENT COMPANY', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1378701', 'QUAESTOR ERTEKPAPIR NYRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3272701', 'QUAESTOR INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4724401', 'RABAKOZI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2582201', 'RAIFFEISEN BANK ZRT.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4988301', 'RAIFFEISEN INVESTMENT FUND MANAGEMENT COMPANY LTD.', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('6828302', 'RAIFFEISENBANK ZAO', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('933801', 'RAJKA ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2160901', 'RAKAMAZ ES VIDEKE KORZETI TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3272801', 'REALSZISZTEMA INVESTMENT FUND MANAGEMENT COMPANY L', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('797301', 'REPCELAK ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('799801', 'RETKOZ TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4721001', 'RICSE ES VIDEKE TAKAREKSZOVETKEZET', 'HU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('583101', '(BANK SUMSEL) PT BANK PEMBANGUNAN DAERAH SUMATERA ', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('156411', 'ABN AMRO JAKARTA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36528702', 'AMERICAN EXPRESS BANK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65050802', 'BANGKOK BANK PUBLIC CO LTD', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('537701', 'BANK AKITA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('196811', 'BANK ANZ INDONESIA, PT.', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3179301', 'BANK BALI', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5896701', 'BANK BII MAYBANK INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('156611', 'BANK BINTANG MANUNGGAL PT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('157011', 'BANK DANPAC', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('582101', 'BANK DIPO', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4973401', 'BANK DKI SYARIAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2772601', 'BANK FINCONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2015701', 'BANK HAGAKITA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4479801', 'BANK HARMONI', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('157111', 'BANK HIMPUNAN SAUDARA 1906', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20341455', 'BANK INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('152911', 'BANK JABAR', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('153111', 'BANK JATENG', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('153211', 'BANK KALBAR', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5876901', 'BANK METRO EKSPRES', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385601', 'BANK MITRANIAGA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385401', 'BANK MNC INTERNATIONAL', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5867501', 'BANK NEGARA INDONESIA  - PT (PERSERO)', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('154111', 'BANK NTB', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('157311', 'BANK OF AMERICA NA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('56258202', 'BANK OF CHINA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197311', 'BANK PEMBANGUNAN DAERAH KALIMANTAN SELATAN', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581901', 'BANK PERSYARIKATAN INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('157411', 'BANK PIKKO', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3180401', 'BANK RIAU', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('537501', 'BANK SAUDARA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('154911', 'BANK SULSEL UUS', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('156711', 'BANK SULSELBAR', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('155411', 'BANK SUMUT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('33911', 'BANK SYARIAH BUKOPIN', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('164911', 'BANK SYARIAH VICTORIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('538101', 'BANK TABUNGAN NEGARA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('582501', 'BANK UOB BUANA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197511', 'BPD DIY', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197611', 'BPD JAWA BARAT DAN BANTEN, TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('120611', 'BPD KALIMANTAN TENGAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197811', 'BPD KALIMANTAN TIMUR', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197711', 'BPD NANGGROE ACEH DARUSSALAM', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198011', 'BPD PAPUA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('386101', 'BPD SULAWESI TENGGARA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198111', 'BPD SULAWESI UTARA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198211', 'BPD SULSELBAR', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198311', 'BPD SUMATERA UTARA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198411', 'BPD SUMUT SYARIAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1112001', 'CITIBANK, NA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('28447202', 'DEUTSCHE BANK AKTIENGESELLSCHAFT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198711', 'PT  BANK BTPN SYARIAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198811', 'PT  BANK RAKYAT INDONESIA AGRONIAGA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198911', 'PT  BANK SINAR HARAPAN BALI', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('199011', 'PT  BANK VICTORIA SYARIAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('199111', 'PT  BPD SUMATERA BARAT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('199211', 'PT  BPD SUMATERA SELATAN', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4329601', 'PT ANZ INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('156811', 'PT BANK AGRIS', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('537901', 'PT BANK AGRONIAGA TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('538601', 'PT BANK AMAR INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3179401', 'PT BANK ANDARA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('538701', 'PT BANK ANTARDAERAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2710101', 'PT BANK ARTHA GRAHA INTERNASIONAL TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5735201', 'PT BANK ARTOS INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('156911', 'PT BANK BCA SYARIAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581101', 'PT BANK BISNIS INTERNASIONAL', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1971301', 'PT BANK BNP PARIBAS INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('538001', 'PT BANK BUKOPIN', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385301', 'PT BANK BUMI ARTA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385501', 'PT BANK CAPITAL INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('231801', 'PT BANK CENTRAL ASIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3179601', 'PT BANK CENTURY TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4081301', 'PT BANK CHINATRUST INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5912201', 'PT BANK CIMB NIAGA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4466701', 'PT BANK COMMONWEALTH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('196911', 'PT BANK CTBC INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581201', 'PT BANK DANAMON INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('582201', 'PT BANK DBS INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581301', 'PT BANK EKONOMI RAHARJA TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5735301', 'PT BANK FAMA INTERNATIONAL', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581401', 'PT BANK GANESHA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3180101', 'PT BANK HAGA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197011', 'PT BANK HANA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2772401', 'PT BANK HARDA INTERNASIONAL', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('85911', 'PT BANK ICBC INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581501', 'PT BANK INA PERDANA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5735501', 'PT BANK INDEX SELINDO', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5735601', 'PT BANK JASA JAKARTA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1647501', 'PT BANK JATIM', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385201', 'PT BANK KEB HANA INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('157211', 'PT BANK KEB INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1474201', 'PT BANK KESAWAN TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34511', 'PT BANK KESEJAHTERAAN EKONOMI', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580901', 'PT BANK LAMPUNG', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5879701', 'PT BANK MANDIRI (PERSERO) TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('538801', 'PT BANK MASPION INDONESIA (MASPION BANK)', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581601', 'PT BANK MAYAPADA INTERNASIONAL, TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198511', 'PT BANK MAYBANK SYARIAH INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4480001', 'PT BANK MAYORA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5877001', 'PT BANK MEGA TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('583001', 'PT BANK MESTIKA DHARMA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385801', 'PT BANK MIZUHO INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('85411', 'PT BANK NOBU NATIONAL BANK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385101', 'PT BANK NUSANTARA PARAHYANGAN TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3179101', 'PT BANK OCBC NISP TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('154411', 'PT BANK PANIN', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197211', 'PT BANK PEMBANGUAN DAERAH NTB', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('198611', 'PT BANK PEMBANGUNAN DAERAH BALI', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3179201', 'PT BANK PEMBANGUNAN DAERAH BENGKULU', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('582601', 'PT BANK PEMBANGUNAN DAERAH JAMBI', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5735901', 'PT BANK PEMBANGUNAN DAERAH JAWA BARAT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('386401', 'PT BANK PEMBANGUNAN DAERAH KALIMANTAN TIMUR(BANK K', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('153511', 'PT BANK PEMBANGUNAN DAERAH KALSEL', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385001', 'PT BANK PEMBANGUNAN DAERAH MALUKU', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197411', 'PT BANK PEMBANGUNAN DAERAH NTT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('386201', 'PT BANK PEMBANGUNAN DAERAH NUSA TENGGARA BARAT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('154211', 'PT BANK PEMBANGUNAN DAERAH NUSA TENGGARA TIMUR', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('386001', 'PT BANK PEMBANGUNAN DAERAH PAPUA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('582901', 'PT BANK PEMBANGUNAN DAERAH SULAWESI UTARA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('538401', 'PT BANK PEMBANGUNAN DAERAH SUMATERA BARAT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2772501', 'PT BANK PEMBANGUNAN DAERAH YOGYAKARTA (BANK DIY)', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4196901', 'PT BANK PERMATA TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('83611', 'PT BANK PUNDI INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('86211', 'PT BANK RABOBANK INTERNATIONAL INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5908401', 'PT BANK RAKYAT INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581801', 'PT BANK ROYAL INDONESIA (ROYAL BANK)', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('85211', 'PT BANK SAHABAT SAMPOERNA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('538301', 'PT BANK SINARMAS', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('155011', 'PT BANK SULTENG', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3180701', 'PT BANK SWADESI TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3179001', 'PT Bank Syariah Aceh (Formely known as BPD Aceh)', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581001', 'PT BANK SYARIAH BRI  ', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3180001', 'PT BANK SYARIAH MANDIRI', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('385701', 'PT BANK SYARIAH MEGA INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('581701', 'PT BANK SYARIAH MUAMALAT INDONESIA, TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('84311', 'PT BANK TABUNGAN PENSIUNAN NASIONAL TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3179501', 'PT BANK UOB INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3785101', 'PT BANK VICTORIA INTERNATIONAL TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3180201', 'PT BANK WINDU KENTJANA INTERNATIONAL TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('538201', 'PT BANK WOORI INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197911', 'PT BPD SULAWESI TENGAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('35711', 'PT PANIN BANK SYARIAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('85011', 'PT. BANK DINAR INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('164611', 'PT. BANK JABAR BANTEN SYARIAH', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32511', 'PT. BANK MUTIARA, TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('164511', 'PT. Bank QNB Indonesia Tbk', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31811', 'PT. BANK RAYKAT INDONESIA (PERSERO), TBK', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('84911', 'PT. BANK SAHABAT PURBA DANARTA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('197111', 'PTBANK HSBC INDONESIA', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1196901', 'STANDARD CHARTERED IND., PT', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67893902', 'THE BANK OF TOKYO-MITSUBISHI UFJ, LTD', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60313802', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LTD.', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('164811', 'THE ROYAL BANK OF SCOTLAND Nv', 'ID');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('270711', 'AIB BANK', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1641601', 'AIB MORTGAGE BANK', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('553001', 'BANK OF IRELAND', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2879901', 'BANK OF IRELAND (TREASURY)', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2807201', 'BANK OF MONTREAL IRELAND PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5046902', 'BARCLAYS BANK IRELAND PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('270811', 'CITIBANK EUROPE PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('270911', 'DELL BANK INTERNATIONAL D.A.C.', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2769401', 'DEPFA ACS BANK DAC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2751201', 'DEPFA BANK PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('33950302', 'DUNBAR ASSETS IRELAND', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('271011', 'EAA COVERED BOND BANK PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5684201', 'EBS D.A.C.', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('271111', 'HEWLETT-PACKARD INTERNATIONAL BANK PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4093701', 'INTESA SANPAOLO BANK IRELAND PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('583501', 'J.P. MORGAN BANK (IRELAND) PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2016201', 'J.P. MORGAN BANK DUBLIN PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('583601', 'KBC BANK IRELAND PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3611201', 'KBC MORTGAGE BANK', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('271211', 'LEASEPLAN FINANCE N.V. (DUBLIN BRANCH)', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4093601', 'LGT BANK AG, DUBLIN BRANCH', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('271311', 'NATIONWIDE UK (IRELAND)', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('661101', 'PERMANENT TSB P.L.C.', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('702601', 'SCOTIABANK (IRELAND) DESIGNATED ACTIVITY COMPANY', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('271411', 'THE INVESTMENT BANK OF IRELAND LIMITED', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2888301', 'ULSTER BANK IRELAND DAC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5684301', 'UNICREDIT BANK IRELAND PLC', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('271511', 'WELLS FARGO BANK INTERNATIONAL UNLIMITED COMPANY', 'IE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20349155', 'ABHYUDAYA CO-OPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18398602', 'ABU DHABI COMMERCIAL BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3988701', 'AHMEDABAD MERCANTILE COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('161411', 'AIRTEL PAYMENTS BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('317711', 'Ajara Urban Co-operative Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('107811', 'AKOLA JANATA COMMERCIAL COOPERATIVE BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('580501', 'ALLAHABAD BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4567501', 'ALMORA URBAN CO-OPERATIVE BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('384301', 'ANDHRA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3178401', 'ANDHRA PRAGATHI GRAMEENA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5684801', 'APNA SAHAKARI BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('368511', 'Arvind Sahakari Bank Ltd', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('161611', 'AU SMALL FINANCE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68711', 'AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4647501', 'AXIS BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135011', 'BANDHAN BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52359502', 'BANK OF AMERICA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26534402', 'BANK OF BAHRAIN AND KUWAIT B.S.C.', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('367201', 'BANK OF BARODA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1523102', 'BANK OF CEYLON', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65273802', 'BANK OF NOVA SCOTIA', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67894202', 'BANK OF TOKYO MITSUBISHI LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('162111', 'BARAMATI CO OP BANK LTD', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11512302', 'BARCLAYS BANK PLC', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2691301', 'BASSEIN CATHOLIC COOPERATIVE BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2691901', 'BHARAT COOPERATIVE BANK MUMBAI LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('107911', 'BHARATIYA MAHILA BANK LIMITED', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65148302', 'BNP PARIBAS', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3178101', 'CANARA BANK', 'IN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('694601', 'BANCA DI CREDITO COOPERATIVO DI MONOPOLI', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('708201', 'BANCA DI CREDITO COOPERATIVO DI MONTECORVINO ROVEL', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('832401', 'BANCA DI CREDITO COOPERATIVO DI MONTEMAGGIORE BELS', 'IT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5877201', 'Bank Of Nova Scotia (Jamaica) Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41511', 'BJ Staff Co-opertive Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('360911', 'BPM Financial Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187711', 'Broadcast and Allied Services Co-op Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187811', 'Building Socities Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39911', 'C & WJ CO-OP CREDIT UNION LTD.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41611', 'C G Co-op Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187911', 'Church of the First Born Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62411', 'CIBC First Caribbean International Bank', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17544602', 'Citibank N.A. Jamaica', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62511', 'COK Sodality Co-op Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41811', 'Correctional Services Co-op Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41911', 'D&G Employees Co-op Credit Union Ltd', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62011', 'Development Bank of Jamaica Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('186711', 'Development Bank of Jamaica Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187611', 'EduCom  Co-operative Credit Union Limited Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42011', 'Ewarton Works Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5906901', 'First Global Bank Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62611', 'First Heritage Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('409801', 'First Regional Co-op Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('714801', 'FIRSTCARIBBEAN INTERNATIONAL BANK (JAMAICA) LIMITE', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187411', 'Gateway Co-operative Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42111', 'Grace CCU Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42211', 'ICD & Associates Employees Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42311', 'Insurance Employees Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('186311', 'Inter-American Development Bank', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42411', 'Jamaica Broilers Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42511', 'Jamaica Defence Force Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1988301', 'JAMAICA MONEY MARKET BROKERS', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('186511', 'Jamaica National Bank', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41111', 'Jamaica Police Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42711', 'Jamaica Special Constabulary Co-Op Credit Union Lt', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42611', 'Jamaica Teachers Association Co-op Credit Union Lt', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('349611', 'JDF Co-operative Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62711', 'JMMB Bank', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20332455', 'JN Bank Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187211', 'JN Financial Services', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187011', 'JN Fund Managers', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187111', 'JN Mortgage Centre', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42811', 'JPS & Partners Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40311', 'JPS Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62811', 'JTA Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42911', 'Kirkvine Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43011', 'Lascelles Employees & Partners Co-op Credit Union ', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20331155', 'Lasco Financial Services', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20332755', 'LASCO PAY CARD', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3815201', 'M F & G Trust & Finance Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('28111', 'MANCHESTER CO-OP CREDIT UNION LTD.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43111', 'Montego Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('349711', 'NAJ & Health Services Co-operative Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43311', 'NAJ Co-operative Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62911', 'National Commercial Bank Ja Ltd', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41411', 'National People''s Co-operative Bank', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('186211', 'National People''s Co-operative Bank of Jamaica Lim', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('186911', 'NCB Capital Markets', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('360811', 'NCB Capital Markets', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43211', 'NCB Empoyees Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43511', 'Nestle Jamaica Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43411', 'NWC Co-operative Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40411', 'Palisadoes Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2557401', 'PAN CARIBBEAN BANK LIMITED', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134111', 'Petroleum Industry Employees Co-op Credit Union Lt', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40511', 'Portland Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134211', 'Postal Co-op Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('349911', 'Public Sector Employees Co-operative Credit Union', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43811', 'PWD Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('350211', 'SAGICOR BANK DOMINICA', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('192511', 'Sagicor Bank Jamaica Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('192411', 'Sagicor Bank Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('187311', 'Scotia Building Society', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41311', 'Scotia Building Society', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('186811', 'Scotia Investments Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40611', 'St. Elizabeth Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20332555', 'The Bank of Nova Scotia Jamaica Limited', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40911', 'Trelawny Co-op Credit Union Ltd.', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63111', 'Victoria Mutual Building Society', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3605201', 'Victoria Mutual Wealth Management', 'JM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5706101', 'CAPITAL BANK OF JORDAN', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5870201', 'CENTRAL BANK OF JORDAN', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('6545202', 'EGYPTIAN ARAB LAND BANK', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('589601', 'JORDAN COMMERCIAL BANK', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('411301', 'JORDAN ISLAMIC BANK', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3302401', 'JORDAN KUWAIT BANK', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('48291802', 'RAFIDAIN BANK', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20332855', 'SAFWA ISLAMIC BANK', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('661301', 'SOCIETE GENERALE DE BANQUE - JORDANIE', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10312702', 'STANDARD CHARTERED BANK', 'JO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20337955', 'Japan Post Bank.', 'JP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20341955', 'Mizuho Bank,Ltd.', 'JP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20341855', 'Resona Bank,Ltd.,Osaka', 'JP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20342055', 'Shinsei Bank,Ltd.', 'JP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('717401', 'ABSA BANK', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3861701', 'BANK OF AFRICA KENYA LTD', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('456601', 'CFC STANBIC BANK LIMITED', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17546702', 'CITIBANK, N.A.', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('28911', 'COOPERATIVE  BANK', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1555401', 'CREDIT BANK LIMITED', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('589901', 'DIAMOND TRUST BANK KENYA LTD', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('878401', 'ECOBANK KENYA LIMITED', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2858001', 'EQUITY BANK LIMITED', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5015601', 'FAMILY BANK LIMITED', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1673101', 'FIRST COMMUNITY BANK LIMITED', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123011', 'GUARANTY TRUST BANK', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3622901', 'GUARDIAN BANK LTD', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1689001', 'GULF AFRICAN BANK LTD', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('122911', 'JAMII BORA BANK', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('717601', 'KENYA COMMERCIAL BANK LTD', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('717701', 'KENYA POST OFFICE SAVINGS BANK (POSTBANK)', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20337755', 'KENYA WOMEN MICROFINANCE BANK', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('456401', 'MIDDLE EAST BANK KENYA LTD', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3302901', 'NATIONAL BANK OF KENYA LIMITED', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29211', 'PARAMOUNT BANBK', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('456501', 'PRIME BANK LTD', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10455502', 'STANDARD CHARTERED BANK', 'KE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2052001', 'BUSAN BANK', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5472501', 'CITIBANK KOREA INC.', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3784401', 'JEJU BANK', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5867301', 'KEB HANA BANK (FORMERLY KOREA EXCHANGE BANK)', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5908801', 'KOOKMIN BANK', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1635601', 'KOREA POST', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5892401', 'NONGHYUP BANK (FORMERLY KNOWN AS NATIONAL AGRICULT', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5887101', 'SHINHAN BANK', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5868001', 'STANDARD CHARTERED BANK KOREA LIMITED', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5879001', 'SUHYUP BANK (ALSO KNOWN AS NATIONAL FEDERATION OF ', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2886201', 'THE DAEGU BANK, LTD', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('717801', 'THE JEONBUK BANK, LTD.', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5899101', 'THE KOREA DEVELOPMENT BANK', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('590101', 'THE KWANGJU BANK, LTD', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('717901', 'THE KYONGNAM BANK, LTD', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5872001', 'WOORI BANK', 'KR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209911', 'ACLEDA BANK (LAO) LTD', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('210011', 'AGRICULTURAL PROMOTION BANK', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280811', 'Anz Bank (Lao) Limited', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52601502', 'BANGKOK BANK PUBLIC COMPANY LIMITED', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('46263502', 'BANK OF AYUDHYA PUBLIC COMPANY LIMITED', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('279211', 'Bank Of China Limited', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3303001', 'BANK OF THE LAO PDR', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('279311', 'Banque Franco-Lao Ltd', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('279411', 'Banque Pour Le Commerce Exterieur Lao Public', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('279511', 'Canadia Bank Lao Co Ltd.', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('279611', 'First Commercial Bank Ltd', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2062501', 'Indochina Bank Ltd', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('279711', 'Industrial And Commercial Bank Of China Limited', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1528001', 'International Commercial Bank (Lao) Ltd', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('279811', 'Joint Development Bank', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55331402', 'Kasikornthai Bank Limited', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('279911', 'Lao China Bank Co., Ltd.', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280011', 'Lao Construction Bank', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5636901', 'Lao Development Bank', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5684601', 'Lao-Viet Bank', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280111', 'Maruhan Japan Bank Lao Co. Ltd', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280211', 'Maybank Lao', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1636301', 'Phongsavanh Bank Ltd', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42065302', 'Public Bank', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280311', 'Rhb Bank Lao Limited', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280411', 'Saigon Hanoi Commercial Joint Stock Bank', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60214302', 'SAIGON THUONG TIN COMMERCIAL JOINT STOCK BANK', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280511', 'Siam Commercial Bank Pcl', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280611', 'St Bank Co. Ltd', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('280711', 'Vietinbank Lao Limited', 'LA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4459901', 'ECOBANK LIBERIA LIMITED', 'LR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('118411', 'UNITED FINANCE LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137511', 'WESTERN DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4359301', 'WESTERN RURAL DEVELOPMENT BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115011', 'YETI DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114911', 'ZENITH FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('907701', 'ABN AMRO CRAIGS LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1033701', 'ABN AMRO EQUITIES NZ LTD.', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2070101', 'ACCIDENT COMPENSATION CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1325901', 'ALLIANCE GLOBAL LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44043602', 'AMERICAN EXPRESS BANK LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45737002', 'AMP BANK LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53011', 'ANZ BANK NEW ZEALAND LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1112601', 'ANZ MCCAUGHAN SECURITIES (NZ) LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('596001', 'ANZ NATIONAL BANK LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5894101', 'ASB BANK LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68318602', 'AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2780501', 'BALDWIN SMITH AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('367301', 'BANK OF NEW ZEALAND', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11051602', 'BARCLAYS BANK PLC', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11100502', 'BARCLAYS BANK PLC', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36061602', 'BARCLAYS CAPITAL', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2762501', 'BISHOP CAMPBELL AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2009301', 'BLUESTREAM CLEARINGHOUSE', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60667802', 'BNP PARIBAS', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23261802', 'BNP PARIBAS (AUSTRALIA) LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1520501', 'BROOK ASSET MANAGEMENT', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16291702', 'CITIBANK, N.A.', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17544902', 'CITIBANK, N.A.', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2643701', 'CITIGROUP GLOBAL MARKETS NEW ZEALAND LTD.', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4972401', 'CLAVELL EQUITIES', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2219001', 'COGENT INVESTMENT OPERATIONS', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15110302', 'COMMONWEALTH BANK OF AUSTRALIA', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('365711', 'COOPERATIVE BANK NEW ZEALAND', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2744301', 'COUNTY NATWEST SECURITIES (NEW ZEALAND)', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1363901', 'CUSTOM HOUSE (NZ) LTD.', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1609701', 'DAIMLERCHRYSLER FINANCIAL SERVICES NEW ZEALAND LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42037202', 'DEUTSCHE BANK AKTIENGESELLSCHAFT', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1265301', 'DEUTSCHE MORGAN GRENFELL AUCKLAND NEW ZEALAND', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1458901', 'DEUTSCHE MORGAN GRENFELL WELLINGTON', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4839401', 'DEUTSCHE SECURITIES NEW ZEALAND LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2219101', 'DIRECT BROKING LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1459201', 'DOYLE PATERSON BROWN', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('907801', 'EGDEN WIGNALL AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4777001', 'ESAM CUSHING AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1254701', 'FAY, RICHWHITE AND COMPANY LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1794301', 'FGBC LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('24486102', 'FINANCIAL SERVICES INSTITUTE OF AUSTRALIA', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('24486202', 'FINANCIAL SERVICES INSTITUTE OF AUSTRALIA', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4777101', 'FIRST NZ CAPITAL EQUITIES LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3315101', 'FIRST PACIFIC TRUST LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2219201', 'FORSYTH BARR LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1250101', 'GARLICK AND CO LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5074301', 'GENERAL EQUITY BUILDING SOCIETY', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4949701', 'GLENDINNING AND GLENDINNING', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1987701', 'GLOBALCLEAR LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4173302', 'GOLDMAN SACHS JBWERE PTY LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4173402', 'GOLDMAN SACHS JBWERE PTY LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4173502', 'GOLDMAN SACHS JBWERE PTY LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2900501', 'GREENSLADES LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1609401', 'GREG MITCHELL', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3315301', 'HAMPSHIRE SAVINGS AND LOAN LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1632801', 'HIFX LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2997701', 'JARDINE FLEMING NEW ZEALAND LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2756901', 'JOHN CHAPMAN', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18051702', 'JPMORGAN CHASE BANK, NATIONAL ASSOCIATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('46942802', 'JPMORGAN CHASE BANK, NATIONAL ASSOCIATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3730901', 'KIWIBANK', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69893502', 'KOOKMIN BANK', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1654101', 'LATITUDE FX LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2915301', 'LR SINGLETON AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19105402', 'MACQUARIE BANK LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20449602', 'MACQUARIE BANK LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('907901', 'MACQUARIE EQUITIES NEW ZEALAND LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1636001', 'MACQUARIE SECURITIES NEW ZEALAND LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5087601', 'MERCEDES-BENZ NEW ZEALAND LTD.', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2961401', 'MERRILL LYNCH (NEW ZEALAND) LTD.', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1395901', 'MUNRO HUBBARD AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2958701', 'NATIONAL NOMINEES LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4070201', 'NEW ZEALAND ASSOCIATION OF CREDIT UNIONS (NZACU)', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('721001', 'NEW ZEALAND BANKERS'' ASSOCIATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1056901', 'NEW ZEALAND CENTRAL SECURITIES DEPOSITORY (NZDCSD)', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1866501', 'NEW ZEALAND EXCHANGE LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('889201', 'NEW ZEALAND FUTURES AND OPTIONS EXCHANGE', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4775801', 'NEW ZEALAND STOCK EXCHANGE', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4884901', 'NEW ZEALAND STOCK EXCHANGE - AUCKLAND', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4925501', 'NIKE NEW ZEALAND LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4775901', 'NZIJ STOCKBROKERS LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4987801', 'OFFSHORE CAPITAL RESERVE FINANCE COMPANY LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3508901', 'OPT MOBILE LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2943501', 'ORD MINNETT GROUP LTD. WELLINGTON', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1633001', 'OVERSEAS CAPITAL LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2910701', 'R.M. STORY AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3728201', 'RABOBANK NEW ZEALAND LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23271602', 'RBS GROUP (AUSTRALIA) PTY LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31012402', 'RBS GROUP (AUSTRALIA) PTY LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1078301', 'REGAN AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('757101', 'RESERVE BANK OF NEW ZEALAND', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('889301', 'ROSS, SINCLAIR AND CO.', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3601901', 'SMARTSHARES LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1159001', 'SOMERSET SMITH PARTNERS', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5849101', 'SOUTHLAND BUILDING SOCIETY', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65254802', 'THE BANK OF TOKYO-MITSUBISHI UFJ, LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60293502', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60726202', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58683702', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51787402', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53886402', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1056301', 'TRAVELEX FINANCIAL SERVICES NZ LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('418701', 'TSB BANK LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1584001', 'ULTIMATE FINANCIAL SERVICES LP', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1633201', 'UMBS ONLINE LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3602601', 'UNIVERSAL GOLD FINANCE LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54363202', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54381402', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54382102', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51957602', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51957902', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58843802', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58843902', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58844102', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60780102', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60893202', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60905002', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60905302', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65540202', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68041302', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68047702', 'WESTPAC BANKING CORPORATION', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2882301', 'WESTPAC NEW ZEALAND LIMITED', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1132601', 'WESTPACTRUST SECURITIES NZ LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1134401', 'WINSTANLEY AND DICKSON', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4885901', 'WMG YOVICH AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3607001', 'WOLF ALLIANCE LTD', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2895501', 'YOUNG AND CO', 'NZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4977101', 'BANQUE ATLANTIQUE NIGER', 'NE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4501001', 'BANQUE SAHELO-SAHARIENNE POUR L'' INVESTISSEMENT ET', 'NE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20333355', 'CORIS BANK INTERNATIONAL SA', 'NE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5634801', 'ECOBANK NIGER', 'NE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('119511', 'ORABANK NIGER', 'NE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2696501', 'ACCESS BANK NIG LTD.', 'NG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44411', 'ECOBANK NIGERIA', 'NG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('419301', 'FIDELITY BANK PLC', 'NG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2696701', 'GUARANTY TRUST BANK LTD', 'NG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3705301', 'POLARIS BANK (FOMERLY SKYE BANK PLC)', 'NG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('232101', 'UNITED BANK FOR AFRICA PLC', 'NG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('757501', 'UNITY BANK', 'NG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('233411', 'ARENDAL OG OMEGNS SPAREKASSE', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('233511', 'BANK NORWEGIAN', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('233611', 'BANK2 ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('251111', 'BNBANK ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('233711', 'BNP PARIBAS S.A. NORWAY BRANCH', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('233811', 'CITIBANK EUROPE PLC NORWAY BRANCH', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('251211', 'DANSKE BANK A/S', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('251311', 'DNB BANK ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('233911', 'DNB MARKETS A BUSINESS UNIT OF DNB BANK ASA OSLO', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234011', 'DNB MARKETS CUSTODY A BUSINESS UNIT DNB BANK ASA O', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234111', 'DVB BANK SE', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234211', 'EASYBANK ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234311', 'GE MONEY BANK NUF', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234411', 'GJENSIDIGE BANK ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('251411', 'HANDELSBANKEN', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234511', 'J. P. MORGAN EUROPE LIMITED OSLO BRANCH', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234611', 'KLP BANKEN AS', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234711', 'LANDKREDITT BANK AS', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('252011', 'MYBANK ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234811', 'NAERINGSBANKEN ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('234911', 'NORDEA BANK AB (PUBL) FILIAL I NORGE', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235011', 'OBOS BANKEN AS', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235111', 'OPPDALSBANKEN', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('251611', 'PARETO BANK ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('251511', 'PRIVATBANKEN ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235211', 'SAFE DEPOSIT BANK OF NORWAY AS', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('251811', 'SANTANDER CONSUMER BANK AS', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235311', 'SBANKEN ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235411', 'SEB ENSKILDA AS', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235511', 'SEB PRIVATE BANKING', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('251911', 'SKANDINAVISKA ENSKILDA BANKEN', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235611', 'SPARESKILLINGSBANKEN KRISTIANSAND S', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235711', 'STOREBRAND BANK ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235811', 'TERRA KORTBANK AS', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('235911', 'VOSS VEKSEL- OG LANDMANDSBANK ASA', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('236011', 'YA BANK AS', 'NO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('77611', 'ALBARAKA BANK (PAKISTAN)LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('759001', 'ALLIED BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123111', 'ASKARI BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36511', 'BANK AL HABIB LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38711', 'BANK ALFALAH LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('77111', 'BANK OF KHYBER, THE', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38611', 'BANK OF PUNJAB, THE', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36211', 'BANKISLAMI PAKISTAN LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38511', 'BURJ BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('77211', 'DEUTSCHE BANK AG', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4969501', 'DUBAI ISLAMIC BANK PAKISTAN LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36411', 'FAYSAL BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('77011', 'FIRST WOMEN BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219001', 'HABIB BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2003901', 'HABIB METROPOLITAN BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('77511', 'HSBC BANK MIDDLE EAST LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('77311', 'HSBC BANK OMAN S.A.O.G. (FORMERLY OMAN INTERNATION', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('77711', 'INDUSTRIAL DEVELOPMENT BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1336801', 'JS BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4089001', 'KASB BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('420401', 'MCB BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('210111', 'MCB ISLAMIC BANK', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3769301', 'MEEZAN BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3103601', 'NATIONAL BANK OF PAKISTAN', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38011', 'NIB BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1529201', 'SAMBA BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36111', 'SILKBANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('77411', 'SINDH BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36611', 'SONERI BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36311', 'STANDARD CHARTERED BANK (PAKISTAN) LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1307701', 'SUMMIT BANK LTD', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('368501', 'UNITED BANK LIMITED', 'PK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4649301', 'ASOCIACION DE BANCOS DEL PERU (ASBANC)', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4454401', 'ASOCIACION DE CAJAS RURALES DE AHORRO Y CREDITO', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4605201', 'BANCO AZTECA DEL PERU S.A.', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('759601', 'BANCO CENTRAL DE RESERVA DEL PERU', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3328601', 'BANCO DE COMERCIO', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217801', 'BANCO DE CREDITO DEL PERU', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5880001', 'BANCO DE LA NACION', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3241701', 'BANCO FALABELLA S.A.', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('70511', 'BANCO GNV', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('661901', 'BANCO INTERAMERICANO DE FINANZAS S.A.', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5896001', 'BANCO PICHINCHA', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3241801', 'BANCO RIPLEY S.A.', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('141811', 'BANCO SANTANDER PERAS S.A.', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5892701', 'BBVA BANCO CONTINENTAL', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('70911', 'CAJA HUANCAYO', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('70711', 'CAJA MUNICIPAL DE AHORRO Y CREDITO AREQUIPA SA', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('70811', 'CAJA MUNICIPAL DE AHORRO Y CREDITO PIURA SAC', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4601701', 'CITIBANK DEL PERU S.A.', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71011', 'CMAC TRUJILLO SA', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('902601', 'CREDISCOTIA FINANCIERA S.A.', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1252401', 'FINANCIERA PERUANA', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4989701', 'HSBC BANK PERU SA', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5885901', 'INTERBANK', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('141911', 'MI BANCO', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2559801', 'MIBANCO BANCO DE LA MICROEMPRESA S.A. -MIBANCO-', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5881301', 'SCOTIABANK PERU', 'PE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('152311', ' ROBINSONS BANK CORPORATION -15 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('101111', '1ST MACRO BANK INC', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('598401', 'AL-AMANAH ISLAMIC INVESTMENT BANK OF THE PHILIPPIN', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('105701', 'ALLIED BANKING CORPORATION', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('682901', 'ALLIED SAVINGS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5907501', 'ASIA UNITED BANK CORPORATION', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68316402', 'AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED AU', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5870501', 'BANCO DE ORO-EPCI, INC.', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67835102', 'BANGKOK BANK PUBLIC COMPANY LIMITED', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('167411', 'BANK OF CHINA', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3328701', 'BANK OF COMMERCE', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5871701', 'BANK OF THE PHILIPPINE ISLANDS', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4857301', 'BANK ONE SAVINGS AND TRUST CORPORATION', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('349411', 'BPI FAMILY SAVINGS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('349511', 'CHINA BANK SAVINGS  INC', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('104911', 'CHINA BANKING CORPORATION', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1978001', 'CHINATRUST (PHILIPPINES) COMMERCIAL BANK CORPORATI', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1307001', 'Citibank Savings Inc. 10 Digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160711', 'Citibank Savings Inc. 16 Digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('167611', 'CITY SAVINGS BANK INC', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('167511', 'CITYSTATE SAVINGS BANK INC', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42036202', 'DEUTSCHE BANK AKTIENGESELLSCHAFT', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('152611', 'DEVELOPMENT BANK OF THE PHILIPPINES - 10 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('421001', 'DEVELOPMENT BANK OF THE PHILIPPINES - 13 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('350511', 'Dungganon bank INC', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1972401', 'EAST WEST BANKING CORPORATION', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('101211', 'EQUICOM SAVINGS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('107011', 'FIRST ALLIED BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2739401', 'FIRST CONSOLIDATED BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1463001', 'HSBC SAVINGS BANK (PHILIPINES) INC.', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5899401', 'LAND BANK OF THE PHILIPPINES', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1034501', 'MALAYAN BANK SAVINGS AND MORTGAGE BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160611', 'MAYBANK PHILIPPINES 11 Digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('759901', 'MAYBANK PHILIPPINES 12 Digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5873301', 'METROPOLITAN BANK & TRUST COMPANY', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('133111', 'ONE NETWORK BANK - 11 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('152511', 'ONE NETWORK BANK - 12 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('106611', 'Overseas Filipino Bank', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('106911', 'PEN BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('759801', 'PHILIPPINE BANK OF COMMUNICATIONS', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('105111', 'PHILIPPINE BUSINESS BANK INC', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4116001', 'PHILIPPINE NATIONAL BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('421201', 'PHILIPPINE SAVINGS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160511', 'Philippine Trust Company 10 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5880101', 'Philippine Trust Company 12 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160911', 'Philippine Veterans Bank 13 Digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4620301', 'Philippone Veterans Bank 10 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('421301', 'PLANTERS DEVELOPMENT BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('504901', 'PREMIERE DEVELOPMENT BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('350711', 'QUEZON CAPITAL RURAL BANK INCORPORATED', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('90211', 'RCBC SAVINGS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('105211', 'RCBC SAVINGS BANK INC - PHP', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160311', 'RIZAL COMMERCIAL BANKING CORPORATION', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5886001', 'RIZAL COMMERCIAL BANKING CORPORATION 10 - digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160211', 'RIZAL COMMERCIAL BANKING CORPORATION 16- digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3779501', 'ROBINSONS BANK CORPORATION - 12 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('102911', 'SECURITY BANK - SAVINGS', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5892901', 'SECURITY BANK CORPORATION', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10312102', 'STANDARD CHARTERED BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2066601', 'STERLING BANK OF ASIA INC.', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52669002', 'THE BANK OF TOKYO-MITSUBISHI UFJ, LTD', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65216602', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('167711', 'TONG YANG SAVINGS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('160811', 'UCPB - UNITED COCONUT PLANTERS BANK 10 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5880201', 'UCPB - UNITED COCONUT PLANTERS BANK 12 digits', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4619701', 'UCPB SAVINGS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5894201', 'UNION BANK OF THE PHILIPPINES', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('554901', 'UNITED OVERSEAS BANK PHILIPPINES', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('101411', 'UNIVERSITY SAVINGS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('107111', 'VETERANS BANK', 'PH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4680601', 'AIG BANK POLSKA SA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1808401', 'ALIOR BANK SA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('271611', 'ALIOR BANK SA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1439701', 'ALLIANZ BANK POLSKA S.A.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65634102', 'ALLIED IRISH BANKS P.L.C.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4685401', 'BALTYCKI BANK SPOLDZIELCZY DARLOWO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69414302', 'BANCA NAZIONALE DEL LAVORO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62275002', 'BANCO DE SABADELL, S.A.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25785902', 'BANCO ESPIRITO SANTO DE INVESTIMENTO, S.A.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67202', 'BANCO MAIS, S.A.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('421501', 'BANK BPH SA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5723501', 'BANK DNB NORD POLSKA S.A.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('760201', 'BANK GOSPODARKI ZYWNOSCIOWEJ SA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('421701', 'BANK GOSPODARSTWA KRAJOWEGO (BGK) NATIONAL ECONOMY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4116101', 'BANK HANDLOWY W WARSZAWIE S.A.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('598601', 'BANK MILLENNIUM SA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('497401', 'BANK OCHRONY SRODOWISKA S.A.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4466801', 'BANK OF TOKYO-MITSUBISHI (POLSKA) SA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4310401', 'BANK POCZTOWY S.A. (POSTAL BANK SA)', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5911001', 'BANK POLSKA KASA OPIEKI SA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('558701', 'BANK POLSKIEJ SPOLDZIELCZOSCI S.A .', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('833501', 'BANK ROZWOJU CUKROWNICTWA S.A.', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('763101', 'BANK SPOLDZIELCZY ''MAZOWSZE'' PLOCK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('835601', 'BANK SPOLDZIELCZY ''PALUKI'' ZNIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4691001', 'BANK SPOLDZIELCZY ADAMOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1894201', 'BANK SPOLDZIELCZY ALEKSANDROW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('743401', 'BANK SPOLDZIELCZY ANDRESPOL', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4681901', 'BANK SPOLDZIELCZY ANDRYCHOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('844301', 'BANK SPOLDZIELCZY AUGUSTOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('840201', 'BANK SPOLDZIELCZY BABOROW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1858201', 'BANK SPOLDZIELCZY BARCIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('764901', 'BANK SPOLDZIELCZY BARGLOW KOSCIELNY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4687601', 'BANK SPOLDZIELCZY BARTOSZYCE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1891101', 'BANK SPOLDZIELCZY BEDZIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('762501', 'BANK SPOLDZIELCZY BELCHATOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('765001', 'BANK SPOLDZIELCZY BIALA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('764401', 'BANK SPOLDZIELCZY BIALA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('833901', 'BANK SPOLDZIELCZY BIALA PODLASKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1898301', 'BANK SPOLDZIELCZY BIALA RAWSKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4690201', 'BANK SPOLDZIELCZY BIALOBRZEGI', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1892701', 'BANK SPOLDZIELCZY BIALOGARD', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4682501', 'BANK SPOLDZIELCZY BIALOPOLE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1895601', 'BANK SPOLDZIELCZY BIALOSLIWIE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4681401', 'BANK SPOLDZIELCZY BIALYSTOK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4686101', 'BANK SPOLDZIELCZY BIECZ', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('762901', 'BANK SPOLDZIELCZY BIELSK PODLASKI', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('736101', 'BANK SPOLDZIELCZY BIELSKO BIALA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('737701', 'BANK SPOLDZIELCZY BIEZUN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4693401', 'BANK SPOLDZIELCZY BILGORAJ', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('767501', 'BANK SPOLDZIELCZY BISZCZA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('843801', 'BANK SPOLDZIELCZY BLASZKI', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4690701', 'BANK SPOLDZIELCZY BLAZOWA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4687801', 'BANK SPOLDZIELCZY BRANICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('736001', 'BANK SPOLDZIELCZY BRANSK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('766101', 'BANK SPOLDZIELCZY BRODNICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4687701', 'BANK SPOLDZIELCZY BRZEG', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1899001', 'BANK SPOLDZIELCZY BRZESKO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('833601', 'BANK SPOLDZIELCZY BRZEZNICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('839601', 'BANK SPOLDZIELCZY BUKOWINA TATRZANSKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1892001', 'BANK SPOLDZIELCZY BUSKO ZDROJ', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('835201', 'BANK SPOLDZIELCZY BYDGOSZCZ', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('834901', 'BANK SPOLDZIELCZY BYSTRA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1891901', 'BANK SPOLDZIELCZY BYTOM', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('844201', 'BANK SPOLDZIELCZY BYTOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('835801', 'BANK SPOLDZIELCZY CHELM', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1899101', 'BANK SPOLDZIELCZY CHELMNO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5754701', 'BANK SPOLDZIELCZY CHLOPICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1892101', 'BANK SPOLDZIELCZY CHMIELNIK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1895801', 'BANK SPOLDZIELCZY CHODZIEZ', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('844401', 'BANK SPOLDZIELCZY CHOJNA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('835301', 'BANK SPOLDZIELCZY CHOJNICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4686201', 'BANK SPOLDZIELCZY CHOJNOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('744901', 'BANK SPOLDZIELCZY CHORZELE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4684501', 'BANK SPOLDZIELCZY CHRZANOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2833801', 'BANK SPOLDZIELCZY CHYNOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4682601', 'BANK SPOLDZIELCZY CIECHANOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1894101', 'BANK SPOLDZIELCZY CIECHANOWIEC', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('736201', 'BANK SPOLDZIELCZY CIESZYN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1858401', 'BANK SPOLDZIELCZY CYCOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('841301', 'BANK SPOLDZIELCZY CZARNKOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('839701', 'BANK SPOLDZIELCZY CZARNY DUNAJEC', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5755601', 'BANK SPOLDZIELCZY CZECHOWICE - DZIEDZICE - BESTWIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4682201', 'BANK SPOLDZIELCZY CZERSK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('764801', 'BANK SPOLDZIELCZY CZLUCHOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1894001', 'BANK SPOLDZIELCZY CZYZEW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4692501', 'BANK SPOLDZIELCZY DABROWA TARNOWSKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4684901', 'BANK SPOLDZIELCZY DALESZYCE GORNO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4692701', 'BANK SPOLDZIELCZY DEBICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4685701', 'BANK SPOLDZIELCZY DOBCZYCE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('843301', 'BANK SPOLDZIELCZY DOBRE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1895201', 'BANK SPOLDZIELCZY DOBRZEN WIELKI', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('836901', 'BANK SPOLDZIELCZY DOBRZYCA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4693501', 'BANK SPOLDZIELCZY DOLHOBYCZOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4684101', 'BANK SPOLDZIELCZY DREZDENKO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3812701', 'BANK SPOLDZIELCZY DUSZNIKI WLKP', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('841601', 'BANK SPOLDZIELCZY DYNOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1858601', 'BANK SPOLDZIELCZY DZIALDOWO Z S. W LIDZBARKU', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('739001', 'BANK SPOLDZIELCZY DZIERZGON', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4692901', 'BANK SPOLDZIELCZY DZIERZONIOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1898501', 'BANK SPOLDZIELCZY ELK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1935701', 'BANK SPOLDZIELCZY FRAMPOL', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4689501', 'BANK SPOLDZIELCZY GABIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1897701', 'BANK SPOLDZIELCZY GARWOLIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1858701', 'BANK SPOLDZIELCZY GASOCIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5754501', 'BANK SPOLDZIELCZY GILOWICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('737901', 'BANK SPOLDZIELCZY GLINOJECK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1891601', 'BANK SPOLDZIELCZY GLIWICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1893201', 'BANK SPOLDZIELCZY GLOGOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5754001', 'BANK SPOLDZIELCZY GLOGOW MALOPOLSKI', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4688201', 'BANK SPOLDZIELCZY GLOGOWEK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4690301', 'BANK SPOLDZIELCZY GLOWACZOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('839501', 'BANK SPOLDZIELCZY GLOWNO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('744501', 'BANK SPOLDZIELCZY GLUBCZYCE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('840501', 'BANK SPOLDZIELCZY GLUCHOLAZY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('739601', 'BANK SPOLDZIELCZY GNIEW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4689901', 'BANK SPOLDZIELCZY GNIEZNO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1895101', 'BANK SPOLDZIELCZY GOGOLIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('765501', 'BANK SPOLDZIELCZY GOLENIOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('845001', 'BANK SPOLDZIELCZY GOLUB DOBRZYN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1893401', 'BANK SPOLDZIELCZY GORA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3812801', 'BANK SPOLDZIELCZY GORA KALWARIA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4687001', 'BANK SPOLDZIELCZY GORLICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1891801', 'BANK SPOLDZIELCZY GORZYCE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4689401', 'BANK SPOLDZIELCZY GOSTYNIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4688301', 'BANK SPOLDZIELCZY GOWOROWO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4685301', 'BANK SPOLDZIELCZY GRABOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('845101', 'BANK SPOLDZIELCZY GREBOCIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4692301', 'BANK SPOLDZIELCZY GREBOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4687901', 'BANK SPOLDZIELCZY GRODKOW-LOSIOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4693901', 'BANK SPOLDZIELCZY GRODZISK MAZOWIECKI', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2833201', 'BANK SPOLDZIELCZY GRODZISKU WLKP', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4690401', 'BANK SPOLDZIELCZY GROJEC', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('737801', 'BANK SPOLDZIELCZY GRUDUSK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('743601', 'BANK SPOLDZIELCZY GRYBOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4692001', 'BANK SPOLDZIELCZY GRYFICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4692101', 'BANK SPOLDZIELCZY GRYFINO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('834101', 'BANK SPOLDZIELCZY HAJNOWKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4681001', 'BANK SPOLDZIELCZY HALINOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1895001', 'BANK SPOLDZIELCZY ILAWA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4689301', 'BANK SPOLDZIELCZY ILOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4693801', 'BANK SPOLDZIELCZY ILOWA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('841901', 'BANK SPOLDZIELCZY ILZA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('841801', 'BANK SPOLDZIELCZY IM. STEFCZYKA BELSK DUZY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('737001', 'BANK SPOLDZIELCZY INOWROCLAW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('766901', 'BANK SPOLDZIELCZY IZBICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1894501', 'BANK SPOLDZIELCZY JABLONKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1891001', 'BANK SPOLDZIELCZY JAROCIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1896801', 'BANK SPOLDZIELCZY JAROSLAW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4682001', 'BANK SPOLDZIELCZY JASIENICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5755001', 'BANK SPOLDZIELCZY JASIENIEC', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('842701', 'BANK SPOLDZIELCZY JASIONKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('762301', 'BANK SPOLDZIELCZY JASTROWIE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('837101', 'BANK SPOLDZIELCZY JASTRZEBIE ZDROJ', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('742101', 'BANK SPOLDZIELCZY JAWOR', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('740401', 'BANK SPOLDZIELCZY JAWORZNO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1892201', 'BANK SPOLDZIELCZY JEDRZEJOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('838901', 'BANK SPOLDZIELCZY JEDWABNE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('736301', 'BANK SPOLDZIELCZY JELESNIA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('744301', 'BANK SPOLDZIELCZY JONKOWO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4687101', 'BANK SPOLDZIELCZY JORDANOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2834001', 'BANK SPOLDZIELCZY JOZEFOW N/WISLA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('834201', 'BANK SPOLDZIELCZY JUCHNOWIEC GORNY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('742401', 'BANK SPOLDZIELCZY JUTROSIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4688401', 'BANK SPOLDZIELCZY KADZIDLO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('838201', 'BANK SPOLDZIELCZY KALISZ POMORSKI', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('843401', 'BANK SPOLDZIELCZY KALUSZYN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2833301', 'BANK SPOLDZIELCZY KALWARIA ZEBRZYDOWSKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4690801', 'BANK SPOLDZIELCZY KAMIEN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('836701', 'BANK SPOLDZIELCZY KAMIENNA GORA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4681101', 'BANK SPOLDZIELCZY KARCZEW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4684301', 'BANK SPOLDZIELCZY KATOWICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5755101', 'BANK SPOLDZIELCZY KATY WROCLAWSKIE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('742801', 'BANK SPOLDZIELCZY KAZIMIERZ DOLNY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4682301', 'BANK SPOLDZIELCZY KCYNIA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('834601', 'BANK SPOLDZIELCZY KETY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4685001', 'BANK SPOLDZIELCZY KIELCE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('762601', 'BANK SPOLDZIELCZY KLESZCZOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('835901', 'BANK SPOLDZIELCZY KLOBUCK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('838001', 'BANK SPOLDZIELCZY KLODAWA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4692801', 'BANK SPOLDZIELCZY KLODZKO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('738401', 'BANK SPOLDZIELCZY KLOMNICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4684601', 'BANK SPOLDZIELCZY KNUROW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('766701', 'BANK SPOLDZIELCZY KOBIERZYCE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('742701', 'BANK SPOLDZIELCZY KOCK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4686001', 'BANK SPOLDZIELCZY KOLACZYCE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1897501', 'BANK SPOLDZIELCZY KOLBUSZOWA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4686701', 'BANK SPOLDZIELCZY KOLNO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1859301', 'BANK SPOLDZIELCZY KONIECPOL', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('837601', 'BANK SPOLDZIELCZY KONIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4683301', 'BANK SPOLDZIELCZY KONOPISKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('741101', 'BANK SPOLDZIELCZY KONSKIE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('743001', 'BANK SPOLDZIELCZY KONSKOWOLA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('711301', 'BANK SPOLDZIELCZY KONSTANTYNOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('711401', 'BANK SPOLDZIELCZY KORNICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1896701', 'BANK SPOLDZIELCZY KORNIK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('736901', 'BANK SPOLDZIELCZY KORONOWO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5134101', 'Gt Bank Liberia', 'LR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('591201', 'INTERNATIONAL BANK (LIBERIA) LIMITED', 'LR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('413201', 'LIBERIAN BANK FOR DEVELOPMENT & INVESTMENT', 'LR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1792501', 'UNITED BANK FOR AFRICA (LIBERIA) LIMITED', 'LR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45311', 'AB CITADELE BANKAS', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('452301', 'AB DNB BANKAS', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('149111', 'AB SEB BANK', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('146011', 'LITHUANIA CENTRAL CREDIT UNION', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('149211', 'NORDEA BANK AB', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('361311', 'PAYSERA LT UAB', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('367711', 'REVOLUT PAYMENTS UAB', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45711', 'SEB BANK', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47011', 'SIAULIU BANKAS AB', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('368211', 'TRANSACTIVE SYSTEMS UAB', 'LT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('254611', 'AS BALTIJAS PRIVATBANKA', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('254711', 'AS BLUEORANGE BANK', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('255511', 'AS EXPOBANK (FORMERLY AS LTB BANK)', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('878501', 'AS MERIDIAN TRADE BANK', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('256311', 'BIGBANK AS LATVIA BRANCH', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57694202', 'DANSKE BANK A/S, LATVIJA BRANCH', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('254811', 'EVLI BANK LTD', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('255311', 'GLOBAL OVERSEAS BANK A.D.', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('659401', 'JSC CITADELE BANKA', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('255611', 'LUMINOR BANK AS LATVIA (FORMER NORDEA BANK AB LATV', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('256011', 'LUMINOR BANK AS, LATVIA (FORMER AS DNB BANKA)', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('255711', 'OP CORPORATE BANK PLC LATVIA BRANCH', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('256211', 'RIGENSIS BANK AS', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('255811', 'SC PAREX BANKA', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('878601', 'SEB BANKA', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('256111', 'SIGNET BANK AS', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('255411', 'SVENSKA HANDELSBANKEN AB LATVIAN BRANCH', 'LV');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263211', '3 CAPITAL TRADING (LUXEMBOURG) SARL', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3304501', 'ABN AMRO BANK LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5783001', 'ADVANZIA BANK S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263311', 'AGRICULTURAL BANK OF CHINA (LUXEMBOURG) BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263411', 'AGRICULTURAL BANK OF CHINA (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('878801', 'ARGENTABANK LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263511', 'BANCA MARCH, S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3691701', 'BANCA POPOLARE DELL''EMILIA ROMAGNA (EUROPE) INTERN', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('878901', 'BANCO BRADESCO EUROPA S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263611', 'BANCO BTG PACTUAL LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263711', 'BANCO BTG PACTUAL SA LUXEMBOURG BRA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263811', 'BANCO SAFRA S.A. LUXEMBOURG BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263911', 'BANK JULIUS BAER LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3304801', 'BANK OF CHINA (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57779102', 'BANK OF CHINA, LUXEMBOURG BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264011', 'BANK OF COMMUNICATIONS (LUXEMBOURG)', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264111', 'BANK OF COMMUNICATIONS CO., LTD. LUXEMBOURG BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264211', 'BANKINTER LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('414101', 'BANQUE BCP S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('452401', 'BANQUE CARNEGIE LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('516102', 'BANQUE DE COMMERCE ET DE PLACEMENTS S.A. SUCCURSAL', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5882701', 'BANQUE DE LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264311', 'BANQUE DE PATRIMOINES PRIVES', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('591601', 'BANQUE DEGROOF PETERCAM LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3378401', 'BANQUE ET CAISSE D''EPARGNE DE L''ETAT', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3304601', 'BANQUE HAPOALIM (LUXEMBOURG) S.A', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264411', 'BANQUE HAPOALIM (SUISSE) SA SUCCURSALE DE LUXEMBOU', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264511', 'BANQUE INTERNATIONALE A LUXEMBOURG SA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264611', 'BANQUE J. SAFRA SARASIN (LUXEMBOURG) SA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('591901', 'BANQUE LBLUX S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2716101', 'BANQUE PUILAETCO DEWAAY LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('656201', 'BANQUE TRANSATLANTIQUE (CM-CIC GROUP)', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264711', 'BEMO EUROPE BANQUE PRIVEE', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264811', 'BHW ALLGEMEINE BAUSPARKASSE AG, NIEDERLASSUNG LUXE', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('264911', 'BNP PARIBAS LEASING SOLUTIONS S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60715202', 'BNP PARIBAS, SUCCURSALE DE LUXEMBOURG', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2841801', 'CACEIS BANK, LUXEMBOURG BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62672202', 'CAIXA GERAL DE DEPOSITOS', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265011', 'CANDRIAM LUXEMBOURG', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265111', 'CATELLA BANK S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265211', 'CBP QUILVEST S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265311', 'CHINA CONSTRUCTION BANK (EUROPE) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265411', 'CHINA CONSTRUCTION BANK CORPORATION LUXEMBOURG BRA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265511', 'CHINA EVERBRIGHT BANK (EUROPE) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265611', 'CHINA EVERBRIGHT BANK COMPANY LIMITED, LUXEMBOURG ', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265711', 'CHINA MERCHANTS BANK CO., LIMITED LUXEMBOURG BRANC', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265811', 'CITCO BANK NEDERLAND NV, LUXEMBOURG BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('265911', 'CITIBANK EUROPE PLC LUXEMBOURG BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58064502', 'COMMERZBANK AG', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266011', 'COMMERZBANK FINANCE AND COVERED BOND S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('35554002', 'CONRAD HINRICH DONNER BANK, HAMBURG (ALLEMAGNE) SU', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('902101', 'CREDEM INTERNATIONAL (LUX) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3305101', 'CREDIT SUISSE (LUXEMBOURG) S.A., PRIVATE BANKING', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38490402', 'CREDIT SUISSE AG, LUXEMBOURG BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('413501', 'DANSKE BANK INTERNATIONAL S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5361001', 'DEKABANK DEUTSCHE GIROZENTRALE LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('9390302', 'DEKABANK DEUTSCHE GIROZENTRALE SUCCURSALE DE LUXEM', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266111', 'DELEN PRIVATE BANK LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266211', 'DEPFA PFANDBRIEF BANK INTERNATIONAL S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('28428002', 'DEUTSCHE BANK AG, FILIALE LUXEMBOURG', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('592001', 'DEUTSCHE BANK LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('452501', 'DEUTSCHE POSTBANK AG ZWEIGNIEDERLASSUNG LUXEMBURG ', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266311', 'DEWAAY LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('413601', 'DZ PRIVATBANK S.A., LUXEMBOURG', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4998201', 'E. OHMAN J:OR (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('879101', 'EAST-WEST UNITED BANK S.A', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266411', 'EAST-WEST UNITED BANK S.A', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5783101', 'EFG BANK LUXEMBOURG SA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('591501', 'EUROBANK PRIVATE BANK LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3692201', 'EUROPAEISCHE GENOSSENSCHAFTSBANK S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4375001', 'FIDEURAM BANK (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('557601', 'FORTUNA BANQUE S.C.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3727201', 'FREIE INTERNATIONALE SPARKASSE S.A', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266511', 'HAUCK AND AUFHAEUSER FUND PLATFORMS S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('592201', 'HAUCK UND AUFHAEUSER PRIVATBANKIERS AG, NIEDERLASS', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34066902', 'HSBC BANK PLC', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('592401', 'HSBC PRIVATE BANK (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3304701', 'HSBC Securities Services (Luxembourg) S A', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('35554202', 'HSH NORDBANK AG', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3305201', 'HSH NORDBANK SECURITIES S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63905002', 'IKB DEUTSCHE INDUSTRIEBANK AG (LUXEMBOURG)', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4309601', 'IKB INTERNATIONAL S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58137302', 'INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED, L', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266611', 'INDUSTRIAL AND COMMERCIAL BANK OF CHINA LTD., LUXE', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5892601', 'ING LUXEMBOURG S.A. (FORMERLY CREDIT EUROPEEN S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266711', 'INTESA SANPAOLO BANK LUXEMBOURG', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('719601', 'J.P. MORGAN BANK LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37125202', 'JOH. BERENBERG, GOSSLER AND CO.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3727301', 'JOHN DEERE BANK S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5399801', 'KBL EUROPEAN PRIVATE BANKERS S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30314702', 'LLOYDS TSB BANK PLC', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1059101', 'LOMBARD ODIER (EUROPE) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('754001', 'M.M. WARBURG U. CO LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3857801', 'MEDIOBANCA INTERNATIONAL (LUXEMBOURG) SA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266811', 'METROPOLITAN BANK ASSOCIATES S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('266911', 'MIRABAUD ET CIE (EUROPE) SA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('719501', 'MITSUBISHI UFJ INVESTOR SERVICES AND BANKING (LUXE', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('879401', 'MIZUHO TRUST AND BANKING (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('656001', 'NATIXIS BANK (FORMERLY NATIXIS PRIVATE BANKING INT', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5877301', 'NOMURA BANK (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('592301', 'NORD/LB LUXEMBOURG S.A. COVERED BOND BANK', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('753901', 'NORDEA BANK S.A. LUXEMBOURG (TRANSFER AGENCY)', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4864701', 'NORTHERN TRUST GLOBAL SERVICES LIMITED LUXEMBOURG ', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('413301', 'PICTET ET CIE (EUROPE) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267011', 'PRUDENTIAL-BACHE INTERNATIONAL BANK LTD.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267111', 'RAKUTEN EUROPE BANK S.A', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267211', 'RAKUTEN PAYMENTS SERVICES SA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4780401', 'RBC INVESTOR SERVICES BANK S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267311', 'RCB BANK LTD', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267411', 'RIVERBANK S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('656301', 'SKANDINAVISKA ENSKILDA BANKEN S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267511', 'SMBC NIKKO BANK (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1337801', 'SOCIETE GENERALE BANK AND TRUST (ACTING AS FIDUCIA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('592701', 'SOCIETE GENERALE BANK AND TRUST S.A', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267611', 'SOCIETE GENERALE BANK AND TRUST S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267711', 'SOCIETE GENERALE CAPITAL MARKET FINANCE S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('413901', 'STATE STREET BANK INTERNATIONAL GMBH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267811', 'STATE STREET BANK LUXEMBOURG S.A. (FORMERLY SANPAO', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('414001', 'SUMITOMO MITSUI TRUST BANK (LUXEMBOURG) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44407602', 'SVENSKA HANDELSBANKEN AB(PUBL)LUX', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('46779702', 'THE BANK OF NEW YORK MELLON (INTERNATIONAL) LTD, L', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('267911', 'THE BANK OF NEW YORK MELLON (LUXEMBOURG) SA, LUXEM', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268011', 'THE BANK OF NEW YORK MELLON SA/NV, LUXEMBOURG BRAN', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268111', 'THE ROYAL BANK OF SCOTLAND INTERNATIONAL, LUXEMBOU', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2814501', 'UBI BANCA INTERNATIONAL S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('753701', 'UBS EUROPE SE, LUXEMBOURG BRANCH', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2836401', 'UNICREDIT INTERNATIONAL BANK-LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268211', 'UNICREDIT LUXEMBOURG S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('719801', 'UNION BANCAIRE PRIVEE (EUROPE) S.A.', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268311', 'UNITED EUROPEAN BANK (LUXEMBOURG) S.A.(FORMERLY UN', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('268411', 'VP BANK (LUXEMBOURG) SA', 'LU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('90111', 'Banque Atlantique du Mali', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2583601', 'BANQUE INTERNATIONALE POUR LE COMMERCE ET L''INDUST', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('754601', 'BANQUE MALIENNE DE SOLIDARITE', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('78811', 'BSIC Mali', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109911', 'CORIS BANK MALI', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4381101', 'ECOBANK MALI', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('209811', 'LA BANQUE DE DEVELOPPEMENT DU MALI - SA', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109411', 'ORABANK MALI', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('203611', 'UNITED BANK FOR AFRICA MALI', 'ML');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('345311', 'Actinver Casa de Bolsa SA de CV', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5910601', 'BANAMEX', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('502701', 'BANCA AFIRME, S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5896901', 'BANCA MIFEL S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5906401', 'BANCO AHORRO FAMSA, S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4460101', 'BANCO AZTECA S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5905901', 'BANCO DEL AHORRO NACIONAL Y SERVICIOS FINANCIEROS,', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5900701', 'BANCO DEL BAJIO, S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5888301', 'BANCO INBURSA, S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1555001', 'BANCO INTERACCIONES, S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5906501', 'BANCO MULTIVA S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('416101', 'BANCO NACIONAL DE OBRAS Y SERVICIOS PUBLICOS, S.N.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3306801', 'BANCO NACIONAL DEL EJERCITO, FUERZA AEREA Y ARMADA', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4309801', 'BANCO REGIONAL DE MONTERREY, S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5871301', 'BANCOMER', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5826101', 'BANCOPPEL S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4602401', 'BANORTE/BANCRECER', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5888801', 'Bansi SA Institucion de Banca Multiple', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5889601', 'BM SCOTIABANK INVERLAT', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('345211', 'CIBANCO, S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3391801', 'CONSULTORIA INTERNACIONAL BANCO, S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('370111', 'HDI Seguros SA de CV', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5873901', 'HSBC MEXICO S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1444001', 'JP Morgan Casa de Bolsa SA de CV JP Morgan Grupo F', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3924701', 'PRUDENTIAL BANK S.A.', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5900101', 'SANTANDER/SERFIN', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('351211', 'Sistema de Transferencias y Pagos STP   S.A.   De ', 'MX');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('415401', 'AFFIN BANK BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('170911', 'AL RAJHI BANKING AND INVESTMENT CORPORATION (MALAY', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('415101', 'ALLIANCE BANK MALAYSIA BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5361801', 'AMBANK (M) BERHARD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('414801', 'BANK ISLAM MALAYSIA BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('185011', 'BANK KERJASAMA RAKYAT (M) BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4392201', 'BANK MUAMALAT MALAYSIA BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5897301', 'BANK OF AMERICA MALAYSIA BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('173211', 'BANK OF CHINA (MALAYSIA) BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('173311', 'BANK OF TOKYO-MITSUBISHI UFJ (MALAYSIA) BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('185111', 'BANK PERTANIAN MALAYSIA BERHAD-AGROBANK', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('754401', 'BANK SIMPANAN NASIONAL', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('173011', 'BNP PARIBAS MALAYSIA BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5873001', 'CIMB BANK BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3595001', 'CITIBANK BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5360801', 'DEUTSCHE BANK (MALAYSIA) BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('594001', 'HONG LEONG BANK BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4647001', 'HSBC BANK MALAYSIA BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20334055', 'INDUSTRIAL AND COMMERCIAL BANK OF CHINA (MALAYSIA)', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('46934802', 'JP MORGAN CHASE BANK BERHARD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('172811', 'KUWAIT FINANCE HOUSE (MALAYSIA) BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5889501', 'MAYBANK BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20334155', 'MBSB Bank Berhad', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('173611', 'MIZUHO BANK (MALAYSIA) BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('172911', 'OCBC BANK (MALAYSIA) BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('174011', 'PUBLIC BANK BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5877401', 'RHB BANK BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5355301', 'STANDARD CHARTERED BANK MALAYSIA BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('173811', 'SUMITOMO MITSUI BANKING CORPORATION MALAYSIA BERHA', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5625801', 'THE ROYAL BANK OF SCOTLAND BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5897201', 'UNITED OVERSEAS BANK (MALAYSIA) BERHAD', 'MY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('123211', 'AL BARID', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32422102', 'ARAB BANK PLC', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5879301', 'ATTIJARIWAFA BANK', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4378001', 'BANK AL-AMAL', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('755701', 'BANQUE CENTRALE POPULAIRE', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3307001', 'BANQUE MAROCAINE DU COMMERCE EXTERIEUR', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3324901', 'BANQUE MAROCAINE POUR LE COMMERCE ET L''INDUSTRIE-B', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('756101', 'CREDIT AGRICOLE DU MAROC S.A.', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('416501', 'CREDIT DU MAROC', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('755801', 'CREDIT IMMOBILIER ET HOTELIER', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('594501', 'SOCIETE GENERALE MAROCAINE DE BANQUES', 'MA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20331755', 'Arig Bank', 'MN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20331855', 'Bogd Bank', 'MN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3767701', 'CAPITRON BANK', 'MN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3619301', 'KHAN BANK', 'MN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2814001', 'TRADE AND DEVELOPMENT BANK OF MONGOLIA LLC', 'MN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339611', 'ECOBANK MZ', 'MZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4375801', 'I.C.B.  BANCO INTERNACIONAL DE COMERCIO, SARL', 'MZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20356155', 'United Bank For Africa Mozambique SA', 'MZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('118511', 'ASIA GREEN DEVELOPMENT BANK LIMITED', 'MM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('118611', 'AYEYARWADY BANK LIMITED', 'MM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('118711', 'CO-OPERATIVE BANK LIMITED (PUBLIC BANK)', 'MM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20337655', 'Kanbawza Bank Limited', 'MM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('133811', 'MYANMA ECONOMIC BANK', 'MM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('133211', 'MYANMAR CITIZENS BANK LTD', 'MM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('276811', 'Shwe (Rural And Urban Development) Bank Ltd', 'MM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('186011', 'UNITED AMARA BANK LIMITED', 'MM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('289011', 'BANCO AVANZ', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4310101', 'BANCO CITIBANK DE NICARAGUA, S.A.', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5899801', 'BANCO DE AMERICA CENTRAL NICARAGUA, S.A.', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5900401', 'BANCO DE FINANZAS, S.A.', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5888401', 'BANCO DE LA PRODUCCION', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26511', 'BANCO LAFISE BANCENTRO', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3854901', 'BANCO PROCREDIT', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('289111', 'FINANCIERA COMERCIAL HONDURENA S.A.', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('290411', 'Teledolar S.A.', 'NI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1385201', '2B TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1691201', '323 TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5372201', 'AAGUS FINANCIAL SERVICES GROUP N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5873701', 'ABN AMRO BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4501701', 'ABN AMRO BOUWFONDS NEDERLANDSE GEMEENTEN N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3924401', 'ABN AMRO GROENBANK B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4440201', 'ABN AMRO HOLDING N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4565801', 'ABN AMRO HYPOTHEKEN GROEP B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4777401', 'ABP INVESTMENTS', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2050901', 'ABR FINANCIAL B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1686701', 'ACCENT AIGU B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5020701', 'ACCENT GRAVE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1379901', 'ACCENT TONIQUE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1362401', 'ACCION N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4738401', 'ACHMEA BANK HOLDING NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4738101', 'ACHMEA HOLDING NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4091701', 'ACHMEA HYPOTHEEKBANK NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2850601', 'ACHMEA RETAIL BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5003201', 'ACONA BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1361801', 'ADVIESBUREAU VOOR VERMOGENS-BEHEER VAN GRAFHORST B', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1352001', 'ADVIESGROEP REYERSEN VAN BUUREN B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4738001', 'AEGEAN FINANCE STICHTING', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5372101', 'AEGON BANK NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1352101', 'AEGON FINANCIELE DIENSTEN B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1521601', 'AEGON GROUP TREASURY N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1646601', 'AEGON INVESTMENT MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2173501', 'AEGON NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1057301', 'AESPEN FUTURES BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1132801', 'AEX-AGRICULTURAL FUTURES EXCHANGE', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1352201', 'AFS BROKERS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1646401', 'AFS CAPITAL MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1646701', 'AFS CAPITAL MARKETS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5020501', 'AFS MONEYBROKERS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1691501', 'AGRIGENTO BASSA B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5763301', 'AKBANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5022901', 'ALL ENERGY TRADING BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1363501', 'ALL OPTIONS INTERNATIONAL BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1638801', 'ALLIANZ NEDERLAND ASSET MANAGEMENT BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3369501', 'ALPINVEST PARTNERS N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3395101', 'AMOPTIONS TRADING VIII B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1261301', 'AMRO SECURITIES', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3342501', 'AMSTEL CAPITAL MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5020401', 'AMSTEL FUNDS EN ASSET MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4777501', 'AMSTEL SECURITIES NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1352501', 'AMSTERDAM BROKERS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2899201', 'AMSTERDAM COMMODITY EXCHANGE', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2815201', 'AMSTERDAM TRADE BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5021301', 'AMSTERDAMS EFFECTENKANTOOR B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2899301', 'AMSTERDAMSE EFFECTENBEURS', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5825801', 'ANADOLUBANK NEDERLAND N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1368101', 'ANDROPAN ASSET MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5028601', 'ANTHOS ASSET MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3311801', 'ANTHOS BANK B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4777601', 'AOT SECURITIES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4643901', 'ASN Bank', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5021601', 'ASSET ENHANCEMENT GROUP B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5021501', 'ASTER-X CAPITAL MANAGEMENT B.V', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5021701', 'ATTICA VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1687101', 'AVERO BANCAIRE DIENSTEN N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1521301', 'AZL NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1653201', 'B.A. VAN DOORN EN COMP B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1362501', 'BAKKENIST EN EMMENS N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1382201', 'BANCO DO ESTADO DE SAO PAOLO S.A.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4426401', 'BANK INSINGER DE BEAUFORT N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('417601', 'BANK MENDES GANS N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('418501', 'BANK NEDERLANDSE GEMEENTEN N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('417701', 'BANK OF TOKYO-MITSUBISHI UFJ (HOLLAND) N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('418001', 'BANK TEN CATE & CIE N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2582401', 'BANK VOOR DE BOUWNIJVERHEID N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5882801', 'BANQUE ARTESIA NEDERLAND N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3395201', 'BARY SECURITIES N.V., DE', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('417801', 'BAX'' BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1362301', 'BEER EN VAN STAPELE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4960101', 'BELASTINGDIENST/CENTRALE BETALINGSADMINISTRATIE SE', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4737701', 'BELEGGINGSFONDS DE ZONNEWIJSER', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1647401', 'BENS INTERNATIONAL TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5022101', 'BERBEN''S EFFECTENKANTOOR B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5038301', 'BERGSHOEFF OPTIONS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3369801', 'BEUSMANS CAPITAL MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3369901', 'BEZEMER CLEMENTS SCHIPPER VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3860701', 'BFO FINANCE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4448801', 'BHF FINANCE (NETHERLANDS) B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5775501', 'BINCKBANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1362601', 'BLACKROCK (NETHERLANDS) B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1647701', 'BLUE SKY GROUP B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1647301', 'BNG CAPITAL MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4565201', 'BNP PARIBAS BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3918001', 'BNY MELLON ASSET SERVICING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3391401', 'BOER EN OLIJ EFFECTENHUIS', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3395301', 'BONDSSPAARBANK VOOR DE EEMSMOND N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1648101', 'BORGHOLS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1380401', 'BORIS TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1362801', 'BOUWFONDS REIM B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5022401', 'BOX CONSULTANTS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('203711', 'BUNQ B.V', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5022201', 'BUSTELBERG EFFECTENKANTOOR B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4870401', 'BZW NEDERLAND NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1375401', 'C.E. DE BRUIN VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1381301', 'CALIMERO TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3375701', 'CARDANO RISK MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1363001', 'CARDANO STRUCTURING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1380901', 'CEBULON OPTIONS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1400301', 'CEBULON VOF', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3395601', 'CENTERCROSS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1368401', 'CHARTERHOUSE VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5038501', 'CHO OPTION TRADERS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5001001', 'CIBA SPECIALTY CHEMICALS TREASURY SERVICE BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('417901', 'CITCO BANK NEDERLAND N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4509201', 'CMV BANK B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5038701', 'COLUMBUS GROUP B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1381201', 'CONSORTIUM HELVETICUM B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1652801', 'CORDARES VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3986901', 'CREDIT AGRICOLE CHEUVREUX NETHERLANDS', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('567201', 'CREDIT EUROPE BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4737901', 'CREDIT EUROPE GROUP N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1687801', 'CROSS OPTIONS INT. XI B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1688001', 'CURVALUE II B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1381401', 'CURVALUE III B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1440701', 'DAIMLER INTERNATIONAL FINANCE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1381601', 'DCM BROKERS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('418201', 'DE INDONESISCHE OVERZEESE BANK, N.V.(THE INDONESIA', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5818201', 'DE LAGE LANDEN INTERNATIONAL B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2799401', 'DE NEDERLANDSCHE BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5033501', 'DE VERMOGENSSPECIALIST B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1374401', 'DE VESTE VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1374501', 'DE VRIES EN CO B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1374601', 'DE VRIES EN WESTERMANN B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1670401', 'DE WAERDT VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5072601', 'DEEP BLUE CAPITAL B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1369101', 'DEGROOF VERMOGENSBEHEER N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1368801', 'DELTA LLOYD ASSET MANAGEMENT N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('595501', 'DELTA LLOYD BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3916301', 'DELTA LLOYD BANKENGROEP N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('811001', 'DELTA LLOYD LEVENSVERZEKERINGEN NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1057401', 'DELTA LLOYD NUTS OHRA ASSET MANAGEMENT', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('985501', 'DELTA LLOYD NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1265601', 'DELTA LLOYD RENTEFONDS', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2705501', 'DEMIR-HALK BANK (NEDERLAND) N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5032401', 'DENO VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('88511', 'DEUTSCHE BANK AG', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4467801', 'DEXIA BANK NEDERLAND N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1653101', 'DIJKSTRA BEAUMONT WEALTH MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1653401', 'DIMA VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('702701', 'DIREKTBANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1688201', 'DOMIX OPTIES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1382001', 'DOUCHKA B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4776701', 'DRESDNER VPV N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1376501', 'DSM PENSIONS SERVICES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4777701', 'DUTCH MINISTRY OF FINANCE', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3375901', 'DUTCH OPTIONS AND FUTURES INSTITUTE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('553401', 'DVB BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1634801', 'DVB BANK NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3404701', 'E.D.I. EQUITY DERIVATIVES INVESTMENTS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1688301', 'EDUTRADERS III B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3376201', 'EFFECTENKANTOOR NIEUWE UITLEG B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1688401', 'EFFECTIVE TRADERS AMSTERDAM B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1483801', 'ENDEX EUROPEAN ENERGY DERIVATIVES EXCHANGE N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4579001', 'EQUENS N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3000501', 'EQUENS NEDERLAND B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1653501', 'ERNST EN VAN DEN BROEK VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5029701', 'EUREFFECT ASSET MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4860001', 'EUREFFECT STOCKBROKERS AMSTERDAM', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4737601', 'EUREKO BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1369701', 'EURO AMERICAN PARTICIPATIONS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1560101', 'EURONEXT AMSTERDAM N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2173701', 'EURONEXT NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3392201', 'EUROPEAN MULTILATERAL CLEARING FACILITY N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('418601', 'F VAN LANSCHOT BANKIERS N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1252201', 'F.I.N.T.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4651401', 'FACTORS CHAIN INTERNATIONAL (FCI)', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1654001', 'FALCINVEST ASSET MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3009301', 'FASTNET NETHERLANDS', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5030101', 'FAXTOR SECURITIES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1688701', 'FENC NETHERLANDS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3574501', 'FGH BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1649601', 'FIERET EN VAN LYNDEN B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5026001', 'FIMAGRO B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3372601', 'FINALTRUST VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3372401', 'FINANCIELE ONDERNEMING SMIDSWATER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2898301', 'FINANCIELE TERMIJNMARKET AMSTERDAM', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3203501', 'FINATA BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5025801', 'FINLES VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1369901', 'FIRST CAPITAL ASSET MANAGERS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1688801', 'FIRST EURO SECURITIES AND DERIVATIVES TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1376801', 'FLORINT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4951801', 'FLOW TRADERS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3405001', 'FLUHALP TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2174201', 'FMO-NETHERLANDS DEVELOPMENT FINANCE COMPANY', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5828501', 'FOREIGN BANKERS'' ASSOCIATION (FBA)', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5039301', 'FORGER EQUITY TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1194501', 'FORTIS (GSLA) B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5691701', 'FORTIS ASR BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4310001', 'FORTIS BANK (NEDERLAND) N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5818001', 'FORTIS BANK GLOBAL CLEARING N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2851001', 'FORTIS BANK NEDERLAND (HOLDING) N.V', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5818101', 'FORTIS GROENBANK B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4091801', 'FORTIS HYPOTHEEK BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2174301', 'FORTIS NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2174001', 'FORTIS UTRECHT NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1575301', 'FORTIS VERZEKERINGEN NEDERLAND N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3405101', 'FORTOP B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5026201', 'FORZA VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1672401', 'FRANKE EN PARTNERS PENSIOEN-ADVIES EN VERMOGENSBEH', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('595701', 'FRIESLAND BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2219501', 'FRIESLAND BANK SECURITIES N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3405201', 'FUTURE SURFING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1971701', 'GARANTIBANK INTERNATIONAL NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1650501', 'GOOISCH EFFECTENHUIS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1650601', 'GORIS EN LADRU VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3372701', 'GROEIVERMOGEN N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5026501', 'GROENSTATE VERMOGENSADVIES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5137801', 'GRUENBERG INVESTMENTS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5026601', 'GVB CAPITAL MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3002701', 'H. WESSELIUS EN CO BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5026801', 'HANZEVAST CAPITAL N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1366501', 'HARMONY VERMOGENSBEHEER B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3405601', 'HARTWIG II B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('502901', 'HELABA FINANCE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3372901', 'HET HAAGS EFFEKTENKANTOOR B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1650801', 'HET HOLLANDSCH EFFECTENKANTOOR B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1057501', 'HEWLETT-PACKARD NEDERLAND B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1689301', 'HIERONYMUS OPTIONS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4738201', 'HOLDING BERCOOP GROEP NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4378301', 'HOLLAND BELEGGINGSGROEP B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('665801', 'HOLLANDSCHE BANK-UNIE N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5026901', 'HOMBURG PARTICIPATIES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5035301', 'HOPSTAKEN JOHANNESMA EN CO B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1689401', 'HOT TRADERS V.O.F.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5039801', 'IDE INTERNATIONAL DERIVATIVES ENTERPRISE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4526001', 'IMC OPTIONS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5027101', 'IMC SECURITIES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5048201', 'IMC TRADING B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1367001', 'IMS INSTITUTIONAL MANAGEMENT SERVICES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1651401', 'INDEPENDENT TRADING COMBINATION EFFECTEN B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1367301', 'INDUBEL VERMOGENSBEHEER NV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5027201', 'ING AM INTERFINANCE SEVICES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1367101', 'ING ASSET MANAGEMENT B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5910501', 'ING BANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2871801', 'ING DIRECT N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('985601', 'ING GROEP N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3373501', 'ING INVESTMENT MANAGEMENT NETHERLANDS N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3373601', 'ING PERSONAL FUND SERVICES B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2173201', 'ING TRUST (NEDERLAND) BV', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3373701', 'INMAXXA B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1366701', 'INSINGER DE BEAUFORT ASSET MANAGEMENT N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1651201', 'INSTITUUT VOOR BELEGGINGSSTRATEGIE B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5040001', 'INTAL B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5040101', 'INTER VALUE OPTIONS B.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5016101', 'INTERBANK N.V.', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1650901', 'INTERNATIONAL ASSETS ADVISORY CORPORATION EUROPE B', 'NL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3217401', 'ACE DEVELOPMENT BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5693401', 'AGRICULTURE DEVELOPMENT BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110211', 'ALPINE DEVELOPMENT BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110311', 'APEX DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135711', 'API FINANCE LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110411', 'ARANIKO DEVELOPMENT BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110511', 'ARUN FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4548901', 'BAGESHWARI DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110611', 'BAGMATI DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3391201', 'BANK OF ASIA NEPAL LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5617601', 'BANK OF KATHMANDU', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110711', 'BHARGAV BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4548701', 'BHRIKUTEE DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3942801', 'BIRATLAXMI DEV BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110811', 'BISHWA BIKASH BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135811', 'BRIGHT DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3942901', 'BUSINESS UNIVERSAL DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110911', 'CENTURY COMMERCIAL BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5795801', 'CHHIMEK BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3335701', 'CITIZENS BANK INTERNATIONAL LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111011', 'CITY DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111111', 'CIVIC DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111211', 'CIVIL BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3217501', 'CLEAN ENERGY DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135911', 'COMMERZ AND TRUST BANK NEPAL LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111311', 'COSMOS DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111411', 'COUNTRY DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137711', 'DEVA BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136011', 'DIYALO BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111511', 'EKATA BIKAS BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2804101', 'EVEREST BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4579901', 'EXCEL DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138111', 'FEWA BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111611', 'FEWA FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3217801', 'GANDAKI BIKASH BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111711', 'GARIMA BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111811', 'GAUMUKHI BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4580101', 'GAURI SHANKAR DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3293201', 'GLOBAL IME BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('111911', 'GRAND BANK NEPAL LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112011', 'GUHESWORI MERCHANT BANKING AND FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136111', 'GULMI BIKASH BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136211', 'H AND B DEVELOPMENT LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112111', 'HAMRO BIKAS BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1553501', 'HIMALAYAN BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112211', 'ICFC FINANCE LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('110111', 'IME CO-OPERATIVE SERVICE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3217701', 'INFRASTRUCTURE DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112311', 'INNOVATIVE DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112411', 'INTERNATIONAL DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112511', 'JANATA BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112611', 'JHIMRUK BIKAS BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112711', 'JYOTI BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112811', 'KABELI BIKAS BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('112911', 'KAILASH BIKAS BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113011', 'KALIKA MICROCREDIT DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113111', 'KALINCHOWK DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113211', 'KAMANA SEWA BIKAS BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113311', 'KANCHAN DEVELOPMENT BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113411', 'KANKAI BIKAS BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113511', 'KANKREBIHAR BIKASH BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3187301', 'KARNALI DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113611', 'KASKI FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3942501', 'KASTHAMANDAP DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136311', 'KHANDBARI DEVELOPMENT BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1585301', 'KIST BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5730601', 'KUMARI BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5743301', 'LAXMI BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2730701', 'LUMBINI BIKASH BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2766801', 'MACHHAPURCHHRE BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('118011', 'MAHAKALI BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('138011', 'MAHALAXMI BIKAS BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113711', 'MAHALAXMI FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3893201', 'MALIKA VIKASH BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136511', 'MANAKAMANA DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('113911', 'MANASLU BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114011', 'MANJUSHREE FINANCIAL INSTITUTION LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114111', 'MATRIBHUMI BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114211', 'MEGHA BANK NEPAL LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114311', 'METRO DEVELOPMENT BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114411', 'MISSION DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114511', 'MITERI DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114611', 'MITHILA LAGHUBITTA BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114711', 'MOUNT MAKALU DEVELOPMENT BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136611', 'MUKTINATH BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('594901', 'NABIL BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('114811', 'NARAYANI NATIONAL FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('120511', 'NDEP DEVELOPMENT BANK LTD.', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2804501', 'NEPAL BANGLADESH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('417001', 'NEPAL BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('118111', 'NEPAL COMMUNITY DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136711', 'NEPAL CONSUMER DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3773801', 'NEPAL CREDIT AND COMMERCE BANK(NCC)', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('118211', 'NEPAL EXPRESS FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3589501', 'NEPAL INDISTRIAL AND COMMERCE BANK(NIC)', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5713301', 'NEPAL INVESTMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116011', 'NIC Asia Bank Limited', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116111', 'NILGIRI VIKAS BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3508801', 'NMB BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137811', 'OM DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116211', 'OM FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('118311', 'PACIFIC DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3893301', 'PASCHIMANCHAL DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116411', 'PATHIBHARA BIKAS BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('161511', 'Pokhara Finance Limited', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116511', 'PRABHU BANK  LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4579501', 'PRIME COMMERCIAL BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136811', 'PROFESSIONAL BIKAS BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116611', 'Professional Diyalo Bikas Bank Ltd', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('136911', 'PUBLIC DEVELOPMENT BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116711', 'PURNIMA BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116811', 'RAPTIBHERI BIKAS BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137011', 'RARA DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('417101', 'RASTRIYA BANIJYA BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('116911', 'RELIABLE DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117011', 'RISING DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117111', 'ROYAL MERCHANT BANKING AND  FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117211', 'SAGARMATHA MERCHANT BANKING AND FINANCE CO LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117311', 'SAHARA BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3187201', 'SAHAYOGI BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117411', 'SALAPA BIKAS BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117511', 'SAMABRIDHI BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3187001', 'SANIMA BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117611', 'SAPTAKOSHI DEVELOPMENT BANK LIMITED -', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117711', 'SBI BANK', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137111', 'SETI FINANCE LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('117911', 'SHANGRI-LA DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115911', 'SHINE RESUNGA DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137211', 'SHUBHALAXMI FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5743901', 'SIDDHARTHA BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4543701', 'SIDDHARTHA DEVLOPMENT  BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115811', 'SINDHU BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137311', 'SOCIAL DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115711', 'SOCIETY DEVELOPMENT BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137411', 'SOORYA DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115611', 'SRIJANA FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('756401', 'STANDARD CHARTERED BANK NEPAL LTD.', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115511', 'SUBHECHHA BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1379001', 'SUNRISE BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115411', 'SUPREME DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115311', 'SYNERGY FINANCE LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115211', 'TINAU DEVELOPMENT BANK LIMITED', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('115111', 'TOURISM DEVELOPMENT BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3969801', 'TRIVENI BIKASH BANK LTD', 'NP');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5674201', 'CAIXA RURAL GALEGA, SOCIEDAD COOPERATIVA DE CREDIT', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('278511', 'Caixa Rural La Vall San Isidro Cooperativa De Cred', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4430901', 'CAIXA RURAL LES COVES DE VINROMA, S. COOP. DE CRED', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3687101', 'CAIXA RURAL SANT JOSEP DE VILAVELLA S. COOP. DE CR', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3686101', 'CAIXA RURAL VINAROS, S. COOP. DE CREDITO V.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17611', 'CAIXABANK, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17211', 'CAJA CANARIAS', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('683101', 'CAJA DE AHORRO PROVINCIAL DE GUADALAJARA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1533601', 'CAJA DE AHORROS DE CASTILLA-LA MANCHA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('500201', 'CAJA DE AHORROS DE LA INMACULADA DE ARAGON', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('555201', 'CAJA DE AHORROS DE LA RIOJA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('685101', 'CAJA DE AHORROS DE MURCIA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('602301', 'CAJA DE AHORROS DE ONTINYENT', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1476501', 'CAJA DE AHORROS DE SALAMANCA Y SORIA - CAJA DUERO', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4618901', 'CAJA DE AHORROS DE SANTANDER Y CANTABRIA - CAJA CA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3333001', 'CAJA DE AHORROS DE VALENCIA, CASTELLON Y ALICANTE ', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('558001', 'CAJA DE AHORROS DE VIGO, OURENSE E PONTEVEDRA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('500101', 'CAJA DE AHORROS DE VITORIA Y ALAVA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('601701', 'CAJA DE AHORROS DEL MEDITERRANEO', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4634901', 'CAJA DE AHORROS MUNICIPAL DE BURGOS', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('424701', 'CAJA DE AHORROS Y MONTE DE PIEDAD DE BALEARES SA N', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4636201', 'CAJA DE AHORROS Y MONTE DE PIEDAD DE NAVARRA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('24411', 'CAJA DE AHORROS Y MONTE DE PIEDAD DE ZARAGOZA, ARA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('664801', 'CAJA ESPANA DE INVERSIONES, CAJA DE AHORROS Y MONT', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3332901', 'CAJA LABORAL POPULAR SOCIEDAD COOPERATIVA DE CREDI', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5706301', 'CAJA RURAL ARAGONESA Y DE LOS PIRINEOS, S. COOP. D', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3686001', 'CAJA RURAL CASTELLON-S. ISIDRO, S. COOP. DE CREDIT', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4415401', 'CAJA RURAL DE ALBACETE, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5674601', 'CAJA RURAL DE ARAGON, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2667701', 'CAJA RURAL DE ASTURIAS, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4415201', 'CAJA RURAL DE BURGOS, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4415101', 'CAJA RURAL DE CASAS IBANEZ, S.COOP. DE CREDITO DE ', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5672801', 'CAJA RURAL DE GRANADA, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4414501', 'CAJA RURAL DE GUISSONA, SOCIEDAD COOPERATIVA DE CR', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3685101', 'CAJA RURAL DE JAEN, BARCELONA Y MADRID, SOCIEDAD C', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2667401', 'CAJA RURAL DE NAVARRA, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5673001', 'CAJA RURAL DE SEGOVIA, C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3686901', 'CAJA RURAL DE SORIA, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4415701', 'CAJA RURAL DE TENERIFE, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2668701', 'CAJA RURAL DE TERUEL, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2668801', 'CAJA RURAL DE TOLEDO, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('314811', 'CAJA RURAL DE UTRERA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5674501', 'CAJA RURAL DE ZAMORA, C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5714701', 'CAJA RURAL DEL MEDITERRANEO, RURALCAJA S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5673101', 'CAJA RURAL DEL SUR, S. COOP. DE CREDITO', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2800701', 'CAJAMAR CAJA RURAL', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('849201', 'CAJASTUR - CAJA DE AHORROS DE ASTURIAS', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('92011', 'CAJASUR BANCO SAU', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('602101', 'CITIBANK ESPANA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2792101', 'CORREOS Y TELEGRAFOS', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29748602', 'DEUTSCHE BANK AKTIENGESELLSCHAFT', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('848501', 'DEUTSCHE BANK, SOCIEDAD ANONIMA ESPANOLA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10058002', 'ESPIRITO SANTO BANK', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50197302', 'EUROPEAN INVESTMENT BANK', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67411', 'EVO BANCO SA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61293602', 'HSBC BANK PLC', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31511', 'IBERCAJA CAJA DE AHORRO DE ZARAGOZA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52956902', 'ING BELGIQUE S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4599701', 'ING REAL ESTATE (ESPANA)', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('848601', 'KUTXABANK, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('21316502', 'LLOYDS TSB BANK PLC', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('556601', 'MONTES DE PIEDAD Y CAJA DE AHORROS DE RONDA, CADIZ', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('315311', 'N26 BANK GMBH', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44011', 'NUEVO MICRO BANK S.A.U', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2814901', 'OPEN BANK SANTANDER CONSUMER, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('364111', 'ORANGE BANK SA SUCURSAL EN ESPA�?A', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4456001', 'POPULAR BANCA PRIVADA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('344611', 'PREPAID FINANCIAL SERVICES LIMITED', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('344511', 'PREPAID FINANCIAL SERVICES LIMITED, S.E.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5705301', 'SANTANDER CENTRAL HISPANO INVESTMENT S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2850901', 'SANTANDER INVESTMENT  S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10739902', 'SOCIETE GENERALE', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10439302', 'STANDARD CHARTERED BANK', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4353601', 'TARGOBANK, SA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('122611', 'TRIODOS BANK VN', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4387301', 'UBS BANK S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('46319102', 'UNICREDIT BANCA DI ROMA S.P.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3684401', 'UNO-E BANK S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('33016802', 'WESTLB AG', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30211', 'AMANA BANK Ltd', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61411', 'AXIS BANK LIMITED', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('849301', 'BANK OF CEYLON', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60911', 'CENTRAL BANK OF SRI LANKA', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36911', 'Citibank NA', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5881401', 'COMMERCIAL BANK OF CEYLON LIMITED', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20353055', 'Commercial Bank Plc', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37011', 'DEUTSCHE BANK AG', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37111', 'DFCC VARDHANA BANK LTD.', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('849501', 'HATTON NATIONAL BANK LIMITED', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4947401', 'HDFC BANK LTD - HOUSING DEVELOPMENT FIANCE CORPO', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59411', 'ICICI Bank Limited', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37311', 'MCB BANK LTD.', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37411', 'NATIONAL DEVELOPMENT BANK PLC', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37511', 'NATIONAL SAVINGS BANK', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2722101', 'NATIONS TRUST BANK LIMITED', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37611', 'PAN ASIA BANKING CORPORATION PLC', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37711', 'PEOPLES BANK', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37811', 'PUBLIC BANK BERHAD', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('849801', 'SAMPATH BANK LIMITED', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2732101', 'SANASA DEVELOPMENT BANK LTD.', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37911', 'SEYLAN BANK PLC', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10439902', 'STANDARD CHARTERED BANK', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52667302', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37509602', 'THE INDIAN BANK', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52796802', 'THE INDIAN OVERSEAS BANK', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59611', 'UNION BANK OF COLOMBO PLC', 'LK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260811', 'ALANDSBANKEN ABP (FINLAND),SVENSK FILIAL', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1437801', 'AVANZA BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('260911', 'AVANZA BANK HOLDING AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42437802', 'BANK2 BANKAKTIEBOLAG', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261011', 'BANKAKTIEBOLAGET AVANZA', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261111', 'BANQUE INVIK LUXEMBOURG FILIAL', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4504801', 'CARNEGIE INVESTMENT BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3375201', 'CERDO BANKPARTNER AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261211', 'EKOBANKEN MEDLEMSBANK', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4983001', 'FOREX BANK AKTIEBOLAG', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2540401', 'GE MONEY BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261311', 'HSB BANK AB (PUBL)', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261411', 'HYSCOBANX TRUST COMPANY KB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2746201', 'ICA BANKEN AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261511', 'IKANO BANKEN AB (PUBL)', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4504901', 'JAK MEDLEMSBANK', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3310801', 'KINADEN SPARKASSA EK FOR', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261611', 'LANDSHYPOTEK BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2540701', 'LANSFORSAKRINGAR BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25918102', 'LEHMAN BROTHERS INTERNATIONAL (EUROPE)', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261811', 'MARGINALEN BANK BANKAKTIEBOLAG', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3945501', 'MEDMERA BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('261911', 'MIND BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3945401', 'NORDAX FINANS AB (PUBL)', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1390501', 'NORDNET BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4485501', 'RESURS BANK AKTIEBOLAG', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262011', 'SALUSANSVAR BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262111', 'SBAB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262211', 'SKANDIABANKEN', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('351411', 'SKANDINAVISKA ENSKILIDA BANKEN AB (SEB)', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262311', 'STADSHYPOTEK BANK', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262411', 'SVEA BANK AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262511', 'TREVISE PRIVATE BANKING AB', 'SE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('905501', 'ABANKA D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3340001', 'ADDIKO BANK D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262611', 'ARGONOS, BORZNO POSREDNISKA HISA, D.O.O.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262711', 'BANKA INTESA SANPAOLO D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5832001', 'BANKA SPARKASSE D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31014802', 'BKS BANK AG, BANCNA PODRUZNICA', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262811', 'BROKERJET SPARKASSE-BORZNO POSREDNISKA DRUZBA, D.D', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3949501', 'DELAVSKA HRANILNICA D.D. LJUBLJANA', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1971201', 'DEZELNA BANKA SLOVENIJE D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('423801', 'GORENJSKA BANKA D.D., KRANJ', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5022801', 'HRANILNICA LON D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1517001', 'HRANILNICA VIPAVA D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1440301', 'ILIRIKA D.D. LJUBLJANA', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('848301', 'NOVA KREDITNA BANKA MARIBOR D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263111', 'NOVA LJUBLJANSKA BANKA D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('262911', 'SID-SLOVENE EXPORT AND DEVELOPMENT BANK INC., LJUB', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('263011', 'SID-SLOVENSKA IZVOZNA IN RAZVOJNA BANKA, D.D., LJU', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4327101', 'SKB BANKA, D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('503601', 'UNICREDIT BANKA SLOVENIJA D.D.', 'SI');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('89411', 'Cooperatieve Spaar-en Krediet Godo GA', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('88811', 'De Surinaamshe Bank NV - DSB', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('89311', 'Finabank NV', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('89011', 'Handels - Krediet-en Industrauebank NV - Hakrinban', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('89111', 'Landbouwbank NV', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('88911', 'RBC Royal Bank (Suriname) N.V.', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221511', 'DEUTSCHE BANK (SCHWEIZ) AG (FORMERLY DEUTSCHE ASSE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221611', 'DEUTSCHE BANK (SCHWEIZ) AG ZURICH - PRIVATE BANKIN', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221711', 'DEUTSCHE BANK (SUISSE) SA - PRIVATE BANKING -', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221811', 'DEUTSCHE BANK (SUISSE) SA FORMERLY RUED BLASS AND ', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221911', 'DEUTSCHE BANK (SVIZZERA) SA LUGANO - PRIVATE BANKI', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222011', 'DEUTSCHE BANK AG ZURICH BRANCH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222111', 'DUKASCOPY BANK SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242511', 'DZ PRIVATBANK (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246811', 'EDMOND DE ROTHSCHILD (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222211', 'EDMOND DE ROTHSCHILD (SUISSE) S.A. - SUCCURSALE DI', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242211', 'EFG BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242111', 'EFG BANK EUROPEAN FINANCIAL GROUP SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222311', 'EFG BANK SA LUGANO BRANCH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222411', 'ERSPARNISKASSE RUEEGGISBERG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222511', 'ERSPARNISKASSE SPEICHER', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222611', 'F. VAN LANSCHOT BANKIERS (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222711', 'FAB PRIVATE BANK (SUISSE) S.A. (FORMERLY NBAD PRIV', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246011', 'FALCON PRIVATE BANK LTD.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222811', 'FIDEURAM BANK (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242411', 'FRANKFURTER BANKGESELLSCHAFT (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('222911', 'FREIE GEMEINSCHAFTSBANK GENOSSENSCHAFT', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242611', 'GLARNER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223011', 'GLOBALANCE BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223111', 'GOLDMAN SACHS BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223511', 'GOLDMAN SACHS BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242711', 'GONET ET CIE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242911', 'GRAUBUENDNER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223611', 'GS BANQUE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223211', 'GS BANQUE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223311', 'GUTZWILLER E. ET CIE BANQUIERS', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223711', 'GUTZWILLER E. ET CIE BANQUIERS', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243011', 'HABIB BANK AG ZURICH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223811', 'HABIBSONS BANK LIMITED', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223411', 'HABIBSONS BANK LIMITED', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('223911', 'HABIBSONS BANK LIMITED LONDON ZURICH BRANCH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224011', 'HINDUJA BANK (SWITZERLAND) LTD', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243211', 'HSBC BANK PLC', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243311', 'HSBC BANK PLC', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240311', 'HSBC PRIVATE BANK (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243411', 'HYPO VORARLBERG BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241511', 'HYPOSWISS PRIVATE BANK GENEVE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224111', 'IG BANK S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243611', 'INCORE BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224211', 'INDUSTRIAL AND COMMERCIAL BANK OF CHINA LTD BEIJIN', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224311', 'ING BELGIUM BRUSSELS GENEVA BRANCH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224411', 'INTESA SANPAOLO PRIVATE BANK (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224511', 'INVESTEC BANK (SWITZERLAND) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224611', 'J.P. MORGAN (SUISSE) S.A', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224711', 'J.P. MORGAN (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241611', 'JPMORGAN CHASE BANK, N.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224811', 'LA COMPAGNIE BENJAMIN DE ROTHSCHILD SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('224911', 'LANDOLT ET CIE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225011', 'LES FILS DREYFUS ET CIE SA BANQUIERS', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225111', 'LF FINANCE (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225211', 'LGT BANK (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244511', 'LUZERNER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225311', 'M.M. WARBURG BANK (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225411', 'MAERKI BAUMANN UND CO. AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238611', 'MERCANTIL BANK (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225511', 'MERRILL LYNCH CAPITAL MARKETS AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('854101', 'MIGROS BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225611', 'MIRABAUD AND CIE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225711', 'MITSUBISHI UFJ WEALTH MANAGEMENT BANK (SWITZERLAND', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225811', 'MIZUHO BANK (SWITZERLAND) LTD.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('225911', 'MOURGUE D''ALGUE ET CIE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226011', 'NBK BANQUE PRIVEE (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226111', 'NEUE AARGAUER BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226211', 'NEUE HELVETISCHE BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244611', 'NIDWALDNER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226311', 'NOMURA BANK (SWITZERLAND) LTD.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226411', 'NORDEA BANK S.A. LUXEMBURG ZWEIGNIEDERLASSUNG  ZUR', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227511', 'NORDEA BANK S.A. LUXEMBURG ZWEIGNIEDERLASSUNG  ZUR', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227611', 'NOTENSTEIN LA ROCHE PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226511', 'NOTENSTEIN LA ROCHE PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244711', 'OBWALDNER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226611', 'PIGUET GALLAND ET CIE SA (EX BANQUE PIGUET ET CIE ', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227711', 'PIGUET GALLAND ET CIE SA (EX BANQUE PIGUET ET CIE ', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244911', 'PKB PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245111', 'PRIVATBANK BELLERIVE AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243511', 'PRIVATBANK IHAG ZUERICH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242811', 'PRIVATBANK VON GRAFFENRIED AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245211', 'PSA INTERNATIONAL S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245311', 'QNB BANQUE PRIVEE (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245411', 'RAHN+BODMER CO.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4619001', 'RAIFFEISEN SCHWEIZ GENOSSENSCHAFT', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227811', 'RBC INVESTOR SERVICES BANK S.A. ESCH-SUR-ALZETTE Z', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226711', 'RBC INVESTOR SERVICES BANK S.A. ESCH-SUR-ALZETTE Z', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226811', 'REGIOBANK SOLOTHURN AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227911', 'REGIOBANK SOLOTHURN AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228011', 'REICHMUTH AND CO', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('226911', 'REICHMUTH AND CO', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245511', 'ROTHSCHILD BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227011', 'SALLFORT PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228111', 'SALLFORT PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228211', 'SAXO BANK (SWITZERLAND) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245811', 'SCHAFFHAUSER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240011', 'SCHRODER AND CO BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227311', 'SCHWYZER KANTONALBANK (SKB)', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246611', 'SCOBAG PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227411', 'SIX SIS AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227111', 'SOCIETA BANCARIA TICINESE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245611', 'SOCIETE GENERALE PRIVATE BANKING (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245711', 'SOCIETE GENERALE, PARIS, ZURICH BRANCH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('227211', 'SPAR- UND LEIHKASSE BUCHEGGBERG AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228311', 'SPAR- UND LEIHKASSE FRUTIGEN', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228411', 'SPAR- UND LEIHKASSE LEUK UND UMGEBUNG GENOSSENSCHA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228511', 'SPAR- UND LEIHKASSE WYNIGEN', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228611', 'SPARKASSE BUNDESPERSONAL SKB EFV', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243911', 'ST.GALLER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228711', 'STATE STREET BANK INTERNATIONAL GMBH MUNICH  ZURIC', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3621601', 'SWISS POST POSTFINANCE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228811', 'SWISSQUOTE BANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('228911', 'TELLCO AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244011', 'THURGAUER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229011', 'TRAFINA PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229111', 'UBL (SWITZERLAND) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246911', 'UBS AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245911', 'UBS ASSET MANAGEMENT AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('247111', 'UBS GROUP AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229211', 'UBS SWITZERLAND AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229311', 'UFJ BANK (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229411', 'UNICREDIT BANK AG (HYPOVEREINSBANK)', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229511', 'UNION BANCAIRE PRIVEE GENEVA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229611', 'UNION BANCAIRE PRIVEE ZURICH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246111', 'UNITED MIZRAHI BANK (SWITZERLAND) LTD', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246311', 'URNER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246411', 'VALIANT BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229711', 'VALIANT BANK AG PRIVATE BANKING (FORMERLY VALIANT ', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229811', 'VP BANK (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('229911', 'VZ DEPOTBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('230011', 'WALMART BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('230111', 'ZAHRINGER PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246511', 'ZUERCHER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244111', 'ZUGER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1523801', 'BANQUE ATLANTIQUE TOGO', 'TG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26911', 'Banque Populaire Pour L''Epargne et le Credit', 'TG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('624301', 'BANQUE TOGOLAISE POUR LE COMMERCE ET L''INDUSTRIE (', 'TG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('184611', 'CORIS BANK INTERNATIONAL TOGO S.A', 'TG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3357301', 'ECOBANK-TOGO SA', 'TG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47811', 'ORABANK TOGO', 'TG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('430301', 'SOCIETE INTERAFRICAINE DE BANQUE', 'TG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('624601', 'UNION TOGOLAISE DE BANQUE', 'TG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20355555', 'ANZ BANK (THAI) PUBLIC COMPANY LIMITED', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5867401', 'BANGKOK BANK PUBLIC COMPANY LIMITED (Tanakan Krong', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('430101', 'BANK FOR AGRICULTURE AND AGRICULTURAL CO-OPERATIVE', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('66165302', 'BANK OF AMERICA, NATIONAL ASSOCIATION', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('430201', 'BANK OF AYUDHYA PUBLIC COMPANY LIMITED', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52613702', 'BNP PARIBAS', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3357201', 'CIMB THAI BANK PUBLIC COMPANY LIMITED (Tanakan CIM', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('16292302', 'CITIBANK, N.A.', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('79511', 'DEUTSCHE BANK AG', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54142802', 'INDIAN OVERSEAS BANK', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2784901', 'ISLAMIC BANK OF THAILAND', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5874201', 'KASIKORNBANK PUBLIC COMPANY LIMITED (Tanakan Ka Si', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4519901', 'KIATNAKIN BANK PUBLIC COMPANY LTD (Tanakan Kiat Na', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5872901', 'KRUNG THAI BANK PUBLIC CO LIMITED (Tanakan Krong T', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1502301', 'LAND AND HOUSES RETAIL BANK PUBLIC CO., LTD', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3874401', 'MEGA INTERNATIONAL COMMERCIAL BANK PUBLIC COMPANY ', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('71111', 'SIAM COMMERCIAL BANK PUBLIC COMPANY LIMITED (Tanak', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('624201', 'STANDARD CHARTERED BANK (THAI) PUBLIC COMPANY LTD', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64338202', 'SUMITOMO MITSUI BANKING CORPORATION', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1271601', 'THAI CREDIT RETAIL BANK CO., LTD.', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5888101', 'THANACHART BANK PUBLIC COMPANY LTD (Tanakan Ta Na ', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65261302', 'THE BANK OF TOKYO-MITSUBISHI UFJ, LTD', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('624101', 'THE GOVERNMENT SAVINGS BANK (Tanakan Aom Sin)', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67886902', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4520001', 'TISCO BANK PUBLIC COMPANY LTD (Tanakan TIS CO)', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5886301', 'TMB BANK PUBLIC COMPANY LIMITED', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5880501', 'UNITED OVERSEAS BANK (THAI) PUBLIC COMPANY LTD (Ta', 'TH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3357001', 'CRDB BANK LIMITED', 'TZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('133011', 'ECOBANK TANZANIE LIMITED', 'TZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20341555', 'EQUITY BANK TANZANIA LIMITED', 'TZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20355455', 'GUARANTY TRUST BANK (Tanzania) LTD', 'TZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3222001', 'INTERNATIONAL COMMERCIAL BANK (TANZANIA) LTD', 'TZ');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('625101', 'BANQUE DE L''HABITAT', 'TN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20355955', 'WIFAK BANK', 'TN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55233502', 'AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED', 'TO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5632401', 'MBF BANK LIMITED', 'TO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('97411', 'PACIFIC INTERNATIONAL COMMERCIAL BANK', 'TO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('855601', 'TONGA DEVELOPMENT BANK', 'TO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('430401', 'WESTPAC BANK OF TONGA', 'TO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('430901', 'ADABANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5902401', 'AKBANK T.A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2687501', 'AKTIF INVESTMENT BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4506001', 'ALBARAKA TURK KATILIM BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4838101', 'ALTERNATIF MENKUL KIYMETLER A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5886801', 'ANADOLUBANK AS', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('431001', 'ARAP TURK BANKASI A.S. (ARAB TURKISH BANK)', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('199911', 'BANK MELLAT TURKIYE A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('200611', 'BANK OF CHINA TURKEY A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3694101', 'BANKPOZITIF KREDI VE KALKINMA BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1533701', 'BIRLESIK FON BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1534401', 'BURGAN BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3813601', 'CITIBANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339411', 'DENIZBANK AS', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4634101', 'DEUTSCHE BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5681501', 'DILER YATIRIM BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('200011', 'FIBABANKA A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5639301', 'GSD BANK (GSD YATIRIM BANKASI A.S.)', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('625701', 'HSBC BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('200211', 'ICBC TURKEY BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('625501', 'ILLER BANKASI T.A.S', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('557101', 'ING BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45054702', 'INTESA SANPAOLO S.P.A.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2806401', 'ISTANBUL TAKAS VE SAKLAMA BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26202602', 'JPMORGAN CHASE BANK, NATIONAL ASSOCIATION', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5781901', 'KUVEYT TURK KATILIM BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('703301', 'MERRILL LYNCH YATIRIM BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('200311', 'MUFG BANK TURKEY A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5681601', 'NUROL YATIRIM BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('200711', 'ODEABANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('200411', 'PASHA YATIRIM BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3357901', 'QNB FINANSBANK A.S', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('200111', 'RABOBANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('625601', 'SEKERBANK, T.A.S. (SUGARBANK)', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11167902', 'SOCIETE GENERALE', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10514702', 'STANDARD CHARTERED BANK', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5881601', 'TURK EKONOMI BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('557001', 'TURKISH BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219501', 'TURKIYE CUMHURIYETI ZIRAAT BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5767801', 'TURKIYE FINANS KATILIM BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5887201', 'TURKIYE GARANTI BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3357801', 'TURKIYE HALK BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4091401', 'Turkiye Ihracat Kredi Bankasi - Turk Eximbank', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('856301', 'TURKIYE IS BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('856401', 'TURKIYE KALKINMA BANKASI A.S. (DEVELOPMENT BANK OF', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('856501', 'TURKIYE SINAI KALKINMA BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5493501', 'TURKIYE VAKIFLAR BANKASI T.A.O.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4327601', 'TURKLAND BANK A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('199811', 'VAKIF KATILIM BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2052701', 'YAPI VE KREDI BANKASI AS', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('200511', 'ZIRAAT KATILIM BANKASI A.S.', 'TR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('624801', 'FIRST CITIZENS BANK LIMITED', 'TT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2538801', 'FIRSTCARIBBEAN INTERNATIONAL BANK (TRINIDAD & TOBA', 'TT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20332255', 'JMMB Bank (T&T) Limited', 'TT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20332355', 'RBC Royal Bank (Trinidad & Tobago) Limited', 'TT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5894901', 'REPUBLIC BANK LIMITED', 'TT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5898301', 'SCOTIABANK TRINIDAD AND TOBAGO LIMITED', 'TT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20329555', 'ABC CAPITAL BANK LIMITED', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1444901', 'BANK OF AFRICA UGANDA LTD', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('657601', 'BANK OF BARODA (UGANDA) LIMITED', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20329755', 'BANK OF INDIA', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('431801', 'BANK OF UGANDA', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('626201', 'BARCLAYS BANK OF UGANDA LIMITED', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11440802', 'BARCLAYS BANK PLC', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20329655', 'BBANK OF BARODA', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2700201', 'CAIRO INTERNATIONAL BANK LTD', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4327701', 'CENTENARY BANK LTD', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5693501', 'CITIBANK (UGANDA) LTD', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1532901', 'DFCU BANK LTD.', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4311201', 'DIAMOND TRUST BANK OF UGANDA LIMITED', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('196511', 'GUARANTY TRUSTt BANK (Uganda) Ltd', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1401401', 'KCB BANK UGANDA LIMITED', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5355101', 'ORIENT BANK LIMITED', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('865801', 'STANBIC BANK (UGANDA) LTD', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('626301', 'STANDARD CHARTERED BANK UGANDA LIMITED', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('432001', 'TROPICAL AFRICAN BANK LTD.', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5054301', 'UNITED BANK FOR AFRICA (UGANDA) LTD', 'UG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('374611', '	COMMERCIAL BANK OF DUBAI PJSC', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5913401', 'ABU DHABI ISLAMIC BANK', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('311911', 'AHLI UNITED BANK LIMITED', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1714201', 'AJMAN BANK', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1438301', 'AL HILAL BANK', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('865501', 'ARAB EMIRATES INVESTMENT BANK PJSC', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('351111', 'BANK OF BARODA', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('311811', 'BANK OF SHARJAH', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3525501', 'CREDIT EUROPE BANK (DUBAI) LTD.', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4481101', 'Dubai Bank', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('311611', 'El Nilein Islamic Bank', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('312211', 'Global Investment Bank Limited', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('312011', 'Hinduja Bank', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('353411', 'HSBC Bank Middle East Limited', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('312111', 'InvestBank', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('312311', 'Islamic Finance House', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('365011', 'MASHREQBANK', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3338401', 'Noor Bank', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('311711', 'Rakbank', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('431701', 'SHARJAH ISLAMIC BANK', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('312411', 'TABARAK INVESTMENT CAPITAL LIMITED', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('865301', 'UNITED ARAB BANK', 'AE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20353955', 'ACCENT BANK JSC (A-BANK JSC)', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20355055', 'ALPARI BANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20353655', 'ASVIO BANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20353755', 'BANK PIVDENNYI  PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20353855', 'BANK VOSTOK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4611901', 'CB ACCORDBANK  PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354055', 'CB PRAVEX BANK JSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354155', 'CB ZEMELNY CAPITAL BANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20355355', 'COMMERCIAL BANK GLOBUS PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5627801', 'COMMERCIAL INDUSTRIAL BANK', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354255', 'CREDIT DNEPR PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54111', 'CRYSTALBANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5128901', 'EASTERN-UKRANIAN BANK GRANT JSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354355', 'FIRST UKRAINIAN INTERNATIONAL BANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20355155', 'IBOX BANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354455', 'INDUSTRIALBANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354555', 'INTERNATIONAL INVESTMENT BANK JSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354655', 'KREDOBANK  PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354755', 'MOTOR BANK OJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4311301', 'PRIVATBANK', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20355255', 'RADABANK JSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354855', 'STATE SAVINGS BANK OF UKRAINE JSC (OSCHADBANK)', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61111', 'TASCOMBANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20354955', 'TRUST CAPITAL BANK JSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20352955', 'UKRAINE - HUMANITARIAN ASSISTANCE', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4506301', 'UKRGAZBANK PJSC', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20352855', 'UNIVERSALBANK (MONO)', 'UA');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1542401', '1492 CAPITAL MANAGEMENT, LLC', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4043901', '167TH TFR FCU', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17711', 'BANK OF AMERICA', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20211', 'Bank Of The West', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5335901', 'BRANCH 825 N A L C CU', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18411', 'Branch Banking And Trust', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('21311', 'California Bank And Trust', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20411', 'Charles Schwab Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18011', 'Citibank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('7701', 'CITYWIDE BANKS', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('21011', 'Colonial Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19811', 'Comerica Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20011', 'Compass Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20511', 'E-Trade Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19711', 'Fifth Third', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20111', 'Goldman Sachs Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('91711', 'GREEN DOT BANK', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20711', 'Harris Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18711', 'HSBC', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19011', 'ING Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19111', 'Key Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19611', 'Manufacturers Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20311', 'Marshall And Ilsley Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19311', 'Morgan Stanley', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18611', 'PNC Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('21111', 'RBC Bank USA', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18811', 'RBS Citizens', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18511', 'Regions Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20911', 'State Street Bank And Trust', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18311', 'Suntrust', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18211', 'Suntrust Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20811', 'TD Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38811', 'Teleton USA 3200726792', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19211', 'The Bank Of New York Mellon', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19911', 'The Huntington National Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18911', 'The Royal Bank Of Scotland N.V.', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20611', 'UBS Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('834301', 'BANK SPOLDZIELCZY KORYCIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1893501', 'BANK SPOLDZIELCZY KOSCIAN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1859701', 'BANK SPOLDZIELCZY KOSCIERZYNA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5755501', 'BANK SPOLDZIELCZY KOSTRZYN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('738701', 'BANK SPOLDZIELCZY KOSZECIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1899301', 'BANK SPOLDZIELCZY KOWAL', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('766201', 'BANK SPOLDZIELCZY KOWALEWO POMORSKIE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('767701', 'BANK SPOLDZIELCZY KOZUCHOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('744701', 'BANK SPOLDZIELCZY KRAPKOWICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4686401', 'BANK SPOLDZIELCZY KRASNIK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('840901', 'BANK SPOLDZIELCZY KRASNOSIELC', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('737601', 'BANK SPOLDZIELCZY KRASNYSTAW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4683901', 'BANK SPOLDZIELCZY KROKOWA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4687201', 'BANK SPOLDZIELCZY KROSCIENKO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1896301', 'BANK SPOLDZIELCZY KROSNIEWICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('767601', 'BANK SPOLDZIELCZY KROSNO ODRZANSKIE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1890801', 'BANK SPOLDZIELCZY KROTOSZYN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1858101', 'BANK SPOLDZIELCZY KRUSZWICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('738201', 'BANK SPOLDZIELCZY KRZEPICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1893001', 'BANK SPOLDZIELCZY KRZESZOWICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('843001', 'BANK SPOLDZIELCZY KRZYWDA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('741001', 'BANK SPOLDZIELCZY KRZYZANOWICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4693601', 'BANK SPOLDZIELCZY KSIEZPOL', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4686501', 'BANK SPOLDZIELCZY KUROW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1896201', 'BANK SPOLDZIELCZY KUTNO ''WSPOLNA PRACA''', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('743701', 'BANK SPOLDZIELCZY LACKO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1897401', 'BANK SPOLDZIELCZY LANCUT', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4681601', 'BANK SPOLDZIELCZY LAPY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('766301', 'BANK SPOLDZIELCZY LASIN', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('764301', 'BANK SPOLDZIELCZY LASKARZEW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('845901', 'BANK SPOLDZIELCZY LASZCZOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('740301', 'BANK SPOLDZIELCZY LAZY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4691801', 'BANK SPOLDZIELCZY LEBA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('838601', 'BANK SPOLDZIELCZY LECZNA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('833801', 'BANK SPOLDZIELCZY LEGIONOWO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1893301', 'BANK SPOLDZIELCZY LEGNICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('840701', 'BANK SPOLDZIELCZY LESNICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1858501', 'BANK SPOLDZIELCZY LESNIOWICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('711201', 'BANK SPOLDZIELCZY LESZNOWOLA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4690901', 'BANK SPOLDZIELCZY LEZAJSK', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('839801', 'BANK SPOLDZIELCZY LIMANOWA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4500901', 'BANK SPOLDZIELCZY LIPINKI', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('762401', 'BANK SPOLDZIELCZY LIPKA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4693101', 'BANK SPOLDZIELCZY LIPNO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('842001', 'BANK SPOLDZIELCZY LIPSKO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('841201', 'BANK SPOLDZIELCZY LOBZENICA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('843701', 'BANK SPOLDZIELCZY LOCHOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1857601', 'BANK SPOLDZIELCZY LOMAZY', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4686801', 'BANK SPOLDZIELCZY LOMZA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('741201', 'BANK SPOLDZIELCZY LOPUSZNO', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4681201', 'BANK SPOLDZIELCZY LOSICE', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1894801', 'BANK SPOLDZIELCZY LOSOSINA DOLNA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4690101', 'BANK SPOLDZIELCZY LUBACZOW', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('744101', 'BANK SPOLDZIELCZY LUBAWA', 'PL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('340711', 'BANCO BASA S.A', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('340811', 'BANCO BILBAO VIZCAYA ARGENTARIA PARAGUAY S.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('341211', 'BANCO CONTINENTAL SAECA', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('341611', 'BANCO DE LA NACION ARGENTINA', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('341711', 'BANCO DO BRASIL S.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5715501', 'BANCO FAMILIAR S.A.E.C.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('342011', 'BANCO GNB PARAGUAY S.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('342211', 'BANCO ITAU PARAGUAY S.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('342311', 'BANCO NACIONAL DE FOMENTO', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('342511', 'BANCO PARA LA COMERCIALIZACION Y LA PRODUCCION S.A', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('342711', 'BANCO REGIONAL S.A.E.C.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('342811', 'Banco RIO S.A.E.C.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('343211', 'CITIBANK N.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('343311', 'CRISOL Y ENCARNACIN FINANCIERA S.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('343411', 'FINANCIERA EL COMERCIO S.A.E.C.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('343611', 'FINANCIERA PARAGUAYO JAPONESA SAECA', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('343711', 'FINLANTINA S.A DE FINANZAS', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('343911', 'GRUPO INTERNACIONAL DE FINANZAS S.A .C.A. (INTERFI', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('344111', 'SUDAMERIS BANK S.A.E.C.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('344311', 'VISION BANCO S.A.E.C.A.', 'PY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2712901', 'A.C.V. - AGENCIA DE CAMBIOS DE VILAMOURA, LDA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2713101', 'A.F. - INVESTIMENTOS SGPS, SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3723901', 'A.F. - INVESTIMENTOS, FUNDOS IMOBILIARIOS, SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1646501', 'ACTIVOBANK7', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5697301', 'AGENCIA DE CAMBIOS - J.R. PEIXE REI & COMPANHIA LI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3724001', 'AGENCIA DE CAMBIOS CENTRAL, LDA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2713201', 'AGENCIA DE CAMBIOS CUNHA, LDA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4437401', 'AGENCIA DE CAMBIOS, A.S., SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5697201', 'ALJARDI SGPS, LDA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3724101', 'ALVES RIBEIRO - INVESTIMENTOS FINANCEIROS, SGPS, S', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30479002', 'ANGLO IRISH BANK CORPORATION PLC', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43395202', 'ANGLO IRISH BANK CORPORATION PLC', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2713301', 'ARGENTARIA VALORES - SOCIEDADE FINANCEIRA DE CORRE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1497301', 'ARGENTARIA VOLARE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3307701', 'AS ''PARITATE BANKA'' - SUCURSAL EM PORTUGAL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('8997802', 'AS PRIVATBANK', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3724201', 'ASCOR - DEALER, SOCIEDADE FINANCEIRA DE CORRETAGEM', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1559101', 'ASSOCIACAO PORTUGUESA DE BANCOS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5020801', 'ATRIUM INVESTIMENTOS-SOCIEDADE FINANCEIRA DE CORRE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4437101', 'B.I.G. FUNDOS - SOCIEDADE GESTORA DE FUNDOS DE INV', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15284402', 'BANCA MONTE DEI PASCHI DI SIENA S.P.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1672001', 'BANCAJA PORTUGAL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2758302', 'BANCO ABN AMRO REAL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('422101', 'BANCO ACTIVOBANK (PORTUGAL) AS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('22596002', 'BANCO AFRICANO DE INVESTIMENTOS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('350811', 'Banco Atlantico - Europa SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2735301', 'BANCO BAI EUROPA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2056801', 'BANCO BANIF E COMERCIAL DOS ACORES S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1728001', 'BANCO BIC PORTUGUES, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4325301', 'BANCO BILBAO VIZCAYA ARGENTARIA PORTUGAL, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52108802', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52112902', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53215202', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53237902', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53238002', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53238102', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54809602', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61066702', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61068202', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61068302', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61908802', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61916702', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61919702', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65798302', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68201302', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('422001', 'BANCO BPI, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('93402', 'BANCO CETELEM ARGENTINA S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31136602', 'BANCO CETELEM ARGENTINA S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1097701', 'BANCO CETELEM SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('422201', 'BANCO COMERCIAL PORTUGUES S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4599001', 'BANCO CREDIBOM, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('152811', 'BANCO CTT SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3088302', 'BANCO DE COMERCIO E INDUSTRIA SARL- BCI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5632901', 'BANCO DE INVESTIMENTO GLOBAL SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('662001', 'BANCO DE INVESTIMENTO IMOBILIARIO SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('760601', 'BANCO DE PORTUGAL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('35337002', 'BANCO DO BRASIL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('35337102', 'BANCO DO BRASIL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41713102', 'BANCO DO BRASIL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41713302', 'BANCO DO BRASIL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('41713402', 'BANCO DO BRASIL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29161302', 'BANCO DO BRASIL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4091901', 'BANCO EFISA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65811202', 'BANCO ESPANOL DE CREDITO, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('497501', 'BANCO ESPIRITO SANTO DE INVESTIMENTO, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3768301', 'BANCO ESPIRITO SANTO DOS ACORES S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('662101', 'BANCO FINANTIA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2815301', 'BANCO INVEST S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('504101', 'BANCO ITAU EUROPA S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69049202', 'BANCO ITAU, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5022701', 'BANCO L.J. CARREGOSA, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2577301', 'BANCO MADESANT - SOCIEDADE UNIPESSOAL, SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3694301', 'BANCO MAIS, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2800601', 'BANCO MILLENNIUM BCP INVESTIMENTO, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68961502', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68961602', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68969102', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68969202', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64395902', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('66695202', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62115702', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62124102', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55214902', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57006102', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53274002', 'BANCO POPULAR ESPANOL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4325401', 'BANCO POPULAR PORTUGAL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2712701', 'BANCO PORTUGUES DE GESTAO, SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('598901', 'BANCO PORTUGUES DE INVESTIMENTO, S.A.-BPI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5797501', 'BANCO PRIMUS S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5370701', 'BANCO PRIVADO PORTUGUES SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3624101', 'BANCO RURAL EUROPA S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60330002', 'BANCO SANTANDER (BRASIL) S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5372501', 'BANCO SANTANDER CONSUMER PORTUGAL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32641702', 'BANCO SANTANDER S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5872801', 'BANCO SANTANDER TOTTA S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('66332902', 'BANCO SANTANDER-CHILE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4443801', 'BANIF BANCO DE INVESTIMENTO, SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('811501', 'BANIF SGPS SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('421901', 'BANIF-BANCO INTERNACIONAL DO FUNCHAL S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('152111', 'BANKINTER SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45811802', 'BANQUE ACCORD', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('25759302', 'BANQUE CENTRALE DE COMPENSATION', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('23103002', 'BANQUE ESPIRITO SANTO ET DE LA VENETIE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44751602', 'BANQUE ESPIRITO SANTO ET DE LA VENETIE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('6806202', 'BANQUE PRIVEE EDMOND DE ROTHSCHILD EUROPE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1452502', 'BANQUE PRIVEE EDMOND DE ROTHSCHILD EUROPE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39797202', 'BANQUE PRIVEE ESPIRITO SANTO SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29309402', 'BANQUE PSA FINANCE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11508802', 'BARCLAYS BANK PLC', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39823902', 'BARCLAYS CAPITAL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1629101', 'BARCLAYS WEALTH MANAGERS PORTUGAL-SGFIM, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44468902', 'BAYERISCHE HYPO- UND VEREINSBANK AG', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4602501', 'BBVA, INSTITUICAO FINANCEIRA DE CREDITO, SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1458301', 'BES INVESTIMENTOS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4438501', 'BEST - BANCO ELECTRONICO DE SERVICO TOTAL SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4871601', 'BIE - BANK AND TRUST LTD', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37445102', 'BMW BANK GMBH', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47461602', 'BMW BANK GMBH', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47461702', 'BMW BANK GMBH', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47461802', 'BMW BANK GMBH', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60121202', 'BNP PARIBAS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67849602', 'BNP PARIBAS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65080102', 'BNP PARIBAS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14709402', 'BNP PARIBAS LEASE GROUP SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('8550102', 'BNP PARIBAS PERSONAL FINANCE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4376302', 'BNP PARIBAS PERSONAL FINANCE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1799602', 'BNP PARIBAS PERSONAL FINANCE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1799702', 'BNP PARIBAS PERSONAL FINANCE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47028902', 'BNP PARIBAS SECURITIES SERVICES', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20721102', 'BNP PARIBAS WEALTH MANAGEMENT', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2899401', 'BOLSA DE DERIVADOS DO PORTO', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3295201', 'BPI GESTAO DE ACTIVOS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5633001', 'BPN - BANCO PORTUGUES DE NEGOCIOS SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3723601', 'BPN IMOFUNDOS - SOCIEDADE GESTORA DE FUNDOS DE INV', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('497601', 'BSN - BANCO SANTANDER DE NEGOCIOS PORTUGAL, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('760501', 'CAIXA - BANCO DE INVESTIMENTO, S.A.', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('598801', 'CAIXA CENTRAL DE CREDITO AGRICOLA MUTUO, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688401', 'CAIXA DE CREDITO AGICOLA MUTUO DE OLIVEIRA DO HOSP', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672401', 'CAIXA DE CREDITO AGRICOLA  MUTUO DE ALCACER DO SAL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671001', 'CAIXA DE CREDITO AGRICOLA MUTUO BEIRA CENTRO, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5676001', 'CAIXA DE CREDITO AGRICOLA MUTUO DA AREA METROPOLIT', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688501', 'CAIXA DE CREDITO AGRICOLA MUTUO DA BAIRRADA E AGUI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671601', 'CAIXA DE CREDITO AGRICOLA MUTUO DA BATALHA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671101', 'CAIXA DE CREDITO AGRICOLA MUTUO DA BEIRA BAIXA SUL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417001', 'CAIXA DE CREDITO AGRICOLA MUTUO DA CHAMUSCA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689301', 'CAIXA DE CREDITO AGRICOLA MUTUO DA COSTA VERDE, CR', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688601', 'CAIXA DE CREDITO AGRICOLA MUTUO DA GUARDA E CELORI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5676401', 'CAIXA DE CREDITO AGRICOLA MUTUO DA REGIAO DE BRAGA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5676901', 'CAIXA DE CREDITO AGRICOLA MUTUO DA REGIAO DO FUNDA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670601', 'CAIXA DE CREDITO AGRICOLA MUTUO DA TERRA QUENTE, C', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671301', 'CAIXA DE CREDITO AGRICOLA MUTUO DA ZONA DO PINHAL,', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688301', 'CAIXA DE CREDITO AGRICOLA MUTUO DAS SERRAS DE ANSI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689601', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ALBERGARIA E SE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3690001', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ALBUFEIRA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677001', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ALCANHOES, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677101', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ALCOBACA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677301', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ALENQUER, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677501', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ALJUSTREL E ALM', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670001', 'CAIXA DE CREDITO AGRICOLA MUTUO DE AMARES, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672501', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ANADIA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417501', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ARMAMAR E MOIME', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5675801', 'CAIXA DE CREDITO AGRICOLA MUTUO DE AROUCA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417701', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ARRUDA DOS VINH', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671501', 'CAIXA DE CREDITO AGRICOLA MUTUO DE AZAMBUJA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417101', 'CAIXA DE CREDITO AGRICOLA MUTUO DE BARCELOS, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672701', 'CAIXA DE CREDITO AGRICOLA MUTUO DE BEJA E MERTOLA,', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417801', 'CAIXA DE CREDITO AGRICOLA MUTUO DE BENAVENTE, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2669901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE BOMBARRAL, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418701', 'CAIXA DE CREDITO AGRICOLA MUTUO DE BORBA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418001', 'CAIXA DE CREDITO AGRICOLA MUTUO DE CADAVAL, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671701', 'CAIXA DE CREDITO AGRICOLA MUTUO DE CALDAS DA RAINH', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689701', 'CAIXA DE CREDITO AGRICOLA MUTUO DE CAMPO MAIOR, CR', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670801', 'CAIXA DE CREDITO AGRICOLA MUTUO DE CANTANHEDE E MI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5676801', 'CAIXA DE CREDITO AGRICOLA MUTUO DE COIMBRA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE CORUCHE, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418801', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ELVAS, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418501', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ENTRE TEJO E SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688201', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ESTARREJA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677601', 'CAIXA DE CREDITO AGRICOLA MUTUO DE ESTREMOZ, MONFO', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE EVORA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417201', 'CAIXA DE CREDITO AGRICOLA MUTUO DE FAFE, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4419001', 'CAIXA DE CREDITO AGRICOLA MUTUO DE FERREIRA DO ALE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE FORNOS DE ALGOD', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670101', 'CAIXA DE CREDITO AGRICOLA MUTUO DE GUIMARAES, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418201', 'CAIXA DE CREDITO AGRICOLA MUTUO DE LAFOES, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3687901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE LAMEGO E CASTRO', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672001', 'CAIXA DE CREDITO AGRICOLA MUTUO DE LEIRIA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671801', 'CAIXA DE CREDITO AGRICOLA MUTUO DE LOURES, SINTRA ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689001', 'CAIXA DE CREDITO AGRICOLA MUTUO DE LOURINHA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689201', 'CAIXA DE CREDITO AGRICOLA MUTUO DE MAFRA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688101', 'CAIXA DE CREDITO AGRICOLA MUTUO DE MOGADOURO E VIM', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689801', 'CAIXA DE CREDITO AGRICOLA MUTUO DE MORAVIS, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417601', 'CAIXA DE CREDITO AGRICOLA MUTUO DE OLIVEIRA DE AZE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689101', 'CAIXA DE CREDITO AGRICOLA MUTUO DE OLIVEIRA DO BAI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3687701', 'CAIXA DE CREDITO AGRICOLA MUTUO DE PAREDES, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672101', 'CAIXA DE CREDITO AGRICOLA MUTUO DE PERNES, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671401', 'CAIXA DE CREDITO AGRICOLA MUTUO DE POMBAL, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689401', 'CAIXA DE CREDITO AGRICOLA MUTUO DE PORTO DE MOS, C', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417401', 'CAIXA DE CREDITO AGRICOLA MUTUO DE POVOA DE VARZIM', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5676501', 'CAIXA DE CREDITO AGRICOLA MUTUO DE S. JOAO DA PESQ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677401', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SALVATERRA DE M', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670201', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SANTO TIRSO, CR', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2673001', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SAO BARTOLOMEU ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677701', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SAO TEOTONIO, C', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672601', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SATAO E VILA NO', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688801', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SEIA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2673101', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SILVES, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418301', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SOBRAL DE MONTE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4419201', 'CAIXA DE CREDITO AGRICOLA MUTUO DE SOUSEL, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677201', 'CAIXA DE CREDITO AGRICOLA MUTUO DE TAROUCA, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5676601', 'CAIXA DE CREDITO AGRICOLA MUTUO DE TERRAS DE MIRAN', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688701', 'CAIXA DE CREDITO AGRICOLA MUTUO DE TERRAS DE VIRIA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3687601', 'CAIXA DE CREDITO AGRICOLA MUTUO DE TERRAS DO SOUSA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418401', 'CAIXA DE CREDITO AGRICOLA MUTUO DE TORRES VEDRAS, ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689501', 'CAIXA DE CREDITO AGRICOLA MUTUO DE TRAMAGAL, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE VAGOS, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE VALE DE CAMBRA,', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672301', 'CAIXA DE CREDITO AGRICOLA MUTUO DE VILA FRANCA DE ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5675901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE VILA NOVA DE FA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2671201', 'CAIXA DE CREDITO AGRICOLA MUTUO DE VILA NOVA DE TA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3687501', 'CAIXA DE CREDITO AGRICOLA MUTUO DE VILA VERDE E DE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672901', 'CAIXA DE CREDITO AGRICOLA MUTUO DE VILA VICOSA, CR', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4419401', 'CAIXA DE CREDITO AGRICOLA MUTUO DO ALGARVE, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3688001', 'CAIXA DE CREDITO AGRICOLA MUTUO DO ALTO CORGO, TAM', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5676201', 'CAIXA DE CREDITO AGRICOLA MUTUO DO ALTO DOURO, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3689901', 'CAIXA DE CREDITO AGRICOLA MUTUO DO ALTO GUADIANA, ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4417301', 'CAIXA DE CREDITO AGRICOLA MUTUO DO ALTO MINHO, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670701', 'CAIXA DE CREDITO AGRICOLA MUTUO DO BAIXO MONDEGO, ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672201', 'CAIXA DE CREDITO AGRICOLA MUTUO DO BAIXO VOUGA, CR', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418101', 'CAIXA DE CREDITO AGRICOLA MUTUO DO CARTAXO, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4419101', 'CAIXA DE CREDITO AGRICOLA MUTUO DO GUADIANA INTERI', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5676101', 'CAIXA DE CREDITO AGRICOLA MUTUO DO MINHO, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2672801', 'CAIXA DE CREDITO AGRICOLA MUTUO DO NORDESTE ALENTE', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4419301', 'CAIXA DE CREDITO AGRICOLA MUTUO DO NORTE ALENTEJAN', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3731501', 'CAIXA DE CREDITO AGRICOLA MUTUO DO RIBATEJO NORTE ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4418601', 'CAIXA DE CREDITO AGRICOLA MUTUO DO RIBATEJO SUL, C', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677801', 'CAIXA DE CREDITO AGRICOLA MUTUO DO SOTAVENTO ALGAR', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4460901', 'CAIXA DE CREDITO AGRICOLA MUTUO DO VALE DO DAO, CR', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3768501', 'CAIXA DE CREDITO AGRICOLA MUTUO DO VALE DO DOURO, ', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670301', 'CAIXA DE CREDITO AGRICOLA MUTUO DO VALE DO SOUSA E', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2670501', 'CAIXA DE CREDITO AGRICOLA MUTUO DO VALE DO TAVORA,', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5677901', 'CAIXA DE CREDITO AGRICOLA MUTUO DOS ACORES, CRL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5632801', 'CAIXA ECONOMICA DA ASSOCIACAO DE SOCORROS MUTUOS D', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2669801', 'CAIXA ECONOMICA DA MISERICORDIA DE ANGRA DO HEROIS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2577101', 'CAIXA ECONOMICA DO PORTO', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3329001', 'CAIXA ECONOMICA MONTEPIO GERAL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2577201', 'CAIXA ECONOMICA SOCIAL', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5898001', 'CAIXA GERAL DE DEPOSITOS', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3295301', 'CAIXAGEST TECNICAS DE GESTAO DE FUNDOS, SA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4568902', 'CAJA DE AHORROS DE GALICIA - CAIXA GALICIA', 'PT');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('88111', 'Stiching Surinaamse Volkscredietbank', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('89211', 'Surichnage Bank NV', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('89511', 'Surinaamse Postspaarbank', 'SR');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243711', 'AARGAUISCHE KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('214911', 'ABANCA CORPORACION BANCARIA S.A BETANZOS SUCCURSAL', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215011', 'ACREVIS BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215111', 'AEK BANK 1826 GENOSSENSCHAFT', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215211', 'ALPHA RHEINTAL BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215311', 'ALTERNATIVE BANK SCHWEIZ AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215411', 'AP ANLAGE UND PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238411', 'APPENZELLER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238511', 'ARAB BANK (SWITZERLAND) LTD', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215511', 'ARBUTHNOT BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246211', 'AXION SWISS BANK SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215611', 'BALOISE BANK SOBA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215711', 'BANCA ALETTI E C. (SUISSE) SA (BANCO POPOLARE GROU', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215811', 'BANCA ARNER S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239211', 'BANCA CREDINVEST SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('215911', 'BANCA DEL CERESIO SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216011', 'BANCA DEL SEMPIONE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241011', 'BANCA DELLO STATO DEL CANTONE TICINO', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216111', 'BANCA POPOLARE DI SONDRIO (SUISSE)', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216211', 'BANCA ZARATTINI AND CO SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216311', 'BANCO ITAU (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216411', 'BANCO SANTANDER (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239611', 'BANK AM BELLEVUE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241711', 'BANK CIC (SWITZERLAND) LTD.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('367811', 'BANK CLER AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242011', 'BANK EEK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('242311', 'BANK EKI GENOSSENSCHAFT', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239911', 'BANK FOR INTERNATIONAL SETTLEMENTS', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216511', 'BANK FUER TIROL UND VORARLBERG AG INNSBRUCK ZWEIGN', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216611', 'BANK GANTRISCH GENOSSENSCHAFT', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('245011', 'BANK HAPOALIM (SWITZERLAND) LTD', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216711', 'BANK IN NIEDERUZWIL', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240111', 'BANK J. SAFRA SARASIN LTD', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216811', 'BANK JULIUS BAER AND CO.LTD.  ZURICH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244211', 'BANK LEUMI LE ISRAEL', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244311', 'BANK LINTH LLB AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('216911', 'BANK MORGAN STANLEY AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217011', 'BANK OF AMERICA MERRILL LYNCH INTERNATIONAL LIMITE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241211', 'BANK SPARHAFEN ZUERICH AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217111', 'BANK THALWIL GENOSSENSCHAFT', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217211', 'BANK VON ROLL AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217311', 'BANK VONTOBEL AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241311', 'BANK ZWEIPLUS AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217411', 'BANKHAUS JUNGHOLZ', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217511', 'BANKMED (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238211', 'BANQUE ALGERIENNE DU COMMERCE EXTERIEUR S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217611', 'BANQUE AUDI (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240511', 'BANQUE BONHOTE ET CIE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239511', 'BANQUE CANTONALE DE FRIBOURG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238911', 'BANQUE CANTONALE DE GENEVE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239011', 'BANQUE CANTONALE DU JURA SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239411', 'BANQUE CANTONALE DU VALAIS', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239111', 'BANQUE CANTONALE NEUCHATELOISE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239311', 'BANQUE CANTONALE VAUDOISE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217711', 'BANQUE CRAMER ET CIE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217811', 'BANQUE DE COMMERCE ET DE PLACEMENTS S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('217911', 'BANQUE DEGROOF PETERCAM (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218011', 'BANQUE DU LEMAN SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218111', 'BANQUE ERIC STURDZA S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240811', 'BANQUE HAVILLAND (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243111', 'BANQUE HERITAGE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218211', 'BANQUE HOTTINGER ET CIE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218311', 'BANQUE HUNZIKER S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218411', 'BANQUE INTERCOMMERCIALE DE GESTION', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239811', 'BANQUE INTERNATIONALE A LUXEMBOURG (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218511', 'BANQUE INTERNATIONALE DE COMMERCE - BRED', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244411', 'BANQUE LOMBARD ODIER ET CIE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218611', 'BANQUE MORVAL', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218711', 'BANQUE PARIS BERTRAND STURDZA SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218811', 'BANQUE PICCIOTTO SETTON AND ASSOCIES', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('244811', 'BANQUE PICTET ET CIE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218911', 'BANQUE PRIVEE BCP (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240711', 'BANQUE PROFIL DE GESTION S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('353511', 'BANQUE RAIFFEISEN SION ET REGION SOCIETE COOPERATI', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219011', 'BANQUE SYZ ET CO SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219111', 'BANQUE SYZ SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219211', 'BANQUE THALER S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219311', 'BANQUE VONTOBEL GENEVE SA.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219411', 'BANTLEON BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219511', 'BARCLAYS BANK (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240411', 'BASELLANDSCHAFTLICHE KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240211', 'BASLER KANTONALBANK', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238711', 'BAUMANN ET CIE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219611', 'BBO BANK BRIENZ OBERHASLI AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238811', 'BBVA (SUIZA) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219711', 'BERENBERG BANK (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('243811', 'BERNER KANTONALBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219811', 'BEZIRKS-SPARKASSE DIELSDORF GENOSSENSCHAFT', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('239711', 'BHF BANK (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219911', 'BIPIELLE BANK (SUISSE) (IN LIQUIDATION)', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220011', 'BLOM BANK (SWITZERLAND) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240911', 'BNP PARIBAS (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('240611', 'BORDIER ET CIE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241111', 'BSI AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220111', 'BURGERGEMEINDE BERN  DC BANK DEPOSITO-CASSA DER ST', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220211', 'BZ BANK AKTIENGESELLSCHAFT', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220311', 'C.I.M. BANQUE', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('238311', 'CA INDOSUEZ (SWITZERLAND) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220411', 'CACEIS BANK SWITZERLAND BRANCH', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220511', 'CBH COMPAGNIE BANCAIRE HELVETIQUE SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220611', 'CEMBRA MONEY BANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220711', 'CHINA CONSTRUCTION BANK CORPORATION BEIJINH  SWISS', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220811', 'CITIBANK (SWITZERLAND) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241811', 'CITIBANK N.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('220911', 'CLIENTIS AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('246711', 'COMMERZBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241411', 'CORNER BANCA S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('241911', 'COUTTS AND CO LTD', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221011', 'CREDIT AGRICOLE NEXT BANK (SUISSE) SA', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221111', 'CREDIT EUROPE BANK (SUISSE) S.A.', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221211', 'CREDIT SUISSE (SCHWEIZ) AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221311', 'CREDIT SUISSE (SCHWEIZ) AG (MULTIBANK ARS AND EFT ', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('247011', 'CREDIT SUISSE AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('221411', 'DEKA(SWISS) PRIVATBANK AG', 'CH');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('210211', 'ALIOR BANK VARSOVIA SUCURSALA BUCURESTI', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4618201', 'ALPHA BANK ROMANIA SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('656701', 'BANC POST S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('142211', 'BANCA CENTRALA COOPERATISTA CREDITCOOP', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5685701', 'BANCA COMERCIALA CARPATICA SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('98111', 'BANCA COMERCIALA FEROVIARA S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3329301', 'BANCA COMERCIALA ROMANA S.A. (ROMANIAN COMMERCIAL ', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('210311', 'BANCA DE EXPORT IMPORT A ROMANIEI', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('142111', 'BANCA MILLENNIUM SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('142411', 'BANCA ROMANA DE CREDITE SI INVESTITII', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4425501', 'BANCA ROMANEASCA S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('503201', 'BANCA TRANSILVANIA S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2692501', 'BANK LEUMI ROMANIA S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51472202', 'BANK OF CYPRUS PCL NICOSIA, ROMANIAN BRANCH', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('142511', 'BCR BANCA PT. LOCUINTE SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43100502', 'BLOM BANK FRANCE S.A. ROMANIA BRANCH', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63389602', 'BNP PARIBAS FORTIS SA/NV BRUXELLES BUCHAREST BRANC', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('96111', 'BRD - GROUPE SOCIETE GENERALE SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3329401', 'CEC BANK-S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40322302', 'CITIBANK EUROPE PLC, DUBLIN-SUCURSALA ROMANIA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('98211', 'CREDIT AGRICOLE BANK ROMANIA S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('902701', 'CREDIT EUROPE BANK (ROMANIA) S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4618301', 'EXIMBANK OF ROMANIA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30411', 'GARANTI BANK S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('345011', 'Garanti Bank SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2692701', 'IDEA BANK SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3418701', 'ING BANK N.V., BUCHAREST BRANCH', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3699501', 'INTESA SANPAOLO ROMANIA S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('137611', 'LIBRA INTERNET BANK SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4425601', 'MARFIN BANK (ROMANIA) S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5903701', 'OTP BANK ROMANIA S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3699401', 'PATRIA BANK SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2692401', 'PIRAEUS BANK ROMANIA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1257101', 'PORSCHE BANK ROMANIA SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4475601', 'PROCREDIT BANK S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('142311', 'RAIFFEISEN BANCA PENTRU LOCUINTE SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3699701', 'RAIFFEISEN BANK S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('142611', 'TBI BANK EAD SOFIA - SUCURSALA BUCURESTI', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4089601', 'THE ROYAL BANK OF SCOTLAND PLC EDINBURGH, ROMANIA ', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1553101', 'UNICREDIT BANK SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37177702', 'VENETO BANCA SCPA ITALIA MONTEBELLUNA SUCURSALA BU', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('345111', 'Vista Bank (Romania) SA', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3699801', 'VOLKSBANK ROMANIA S.A.', 'RO');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5642301', 'AK BARS BANK', 'RU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('457001', 'ALFA-BANK', 'RU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3329601', 'MOSCOW INDUSTRIAL BANK', 'RU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20341755', 'Sberbank', 'RU');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('281211', 'ADDIKO BANK AD BEOGRAD', 'RS');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3773401', 'RAIFFEISENBANK A.D., BEOGRAD', 'RS');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4440701', 'ECOBANK RWANDA', 'RW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20333055', 'EQUITY BANK RWANDA', 'RW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20341155', 'I&M BANK (RWANDA) PLC', 'RW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1988401', 'KCB RWANDA SA', 'RW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27411', 'Urwego Opportunity Bank', 'RW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3211101', 'ACCESS BANK (SIERRA LEONE) LTD.', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('361711', 'ACCESS BANK (SL) LIMITED', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20333755', 'BNB TRANSFER FOREIGN EXCHANGE LTD', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20352555', 'ECOBANK SIERRA LEONE', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2728601', 'FIRST INTERNATIONAL BANK (SIERRA LEONE) LIMITED', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4452901', 'GUARANTY TRUST BANK (SIERRA LEONE) LIMITED', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20332655', 'SIERRA LEONE COMMERCIAL BANK', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3973001', 'SKYE BANK (SL) LTD', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4074601', 'UNION TRUST BANK (SIERRA LEONE) LIMITED', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4599801', 'UNITED BANK FOR AFRICA (SL) LTD', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2061801', 'ZENITH BANK (SIERRA LEONE) LIMITED', 'SL');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('148411', 'BANK OF AFRICA SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1292901', 'BANQUE ATLANTIQUE SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('761601', 'BANQUE DE L''HABITAT DU SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5772801', 'BANQUE DES INSTITUTIONS MUTUALISTES D''AFRIQUE DE L', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('761801', 'BANQUE ISLAMIQUE DU SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('105311', 'BANQUE NATIONALE DE DEVELOPPEMENT ECONOMIQUE', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5003401', 'BANQUE REGIONALE DE MARCHES', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2837501', 'BANQUE SAHELO-SAHARIENNE POUR L''INVESTISSEMENT ET ', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('134011', 'BCI', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20333955', 'BGFIBANK SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('600401', 'CAISSE NATIONALE DE CREDIT AGRICOLE DU SENEGAL (CN', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3330601', 'COMPAGNIE BANCAIRE DE L''AFRIQUE OCCIDENTALE (CBAO)', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339511', 'CORIS BANK INTERNATIONAL SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2770401', 'ECOBANK SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3267101', 'FBN SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20333855', 'LA BANQUE OUTARDE', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('109511', 'ORABANK SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('163411', 'POSTEFINANCES', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('600501', 'SOCIETE GENERALE DE BANQUES AU SENEGAL(SGBS)', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26211', 'UM PAMECAS', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3631701', 'UNITED BANK FOR AFRICA SENEGAL', 'SN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('601901', 'ABANCA CB, SA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5074501', 'ABENGOA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5705401', 'ADMINISTRACION DE BANCOS LATINOAMERICANOS SANTANDE', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('44042402', 'AMERICAN EXPRESS BANK LTD', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('848801', 'ARESBANK S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('290311', 'ARQUIA BANK', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5899001', 'BANCA MARCH S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64862202', 'BANCA NAZIONALE DEL LAVORO', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('619601', 'BANCA PUEYO S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17311', 'BANCAJA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5612601', 'BANCO ALCALA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4633601', 'BANCO ALICANTINO DE COMERCIO S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5475601', 'BANCO BANIF S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5872501', 'BANCO BILBAO VIZCAYA ARGENTARIA, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('683201', 'BANCO CAIXA GERAL', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4588701', 'BANCO CAMINOS, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4353501', 'BANCO CETELEM S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4327201', 'BANCO COOPERATIVO ESPANOL, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('619501', 'BANCO DE ANDALUCIA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('424201', 'BANCO DE CREDITO LOCAL DE ESPANA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5372001', 'BANCO DE DEPOSITOS, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5886101', 'BANCO DE ESPANA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('703401', 'BANCO DE FINANZAS E INVERSIONES S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65319002', 'BANCO DE GUAYAQUIL', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('423901', 'BANCO DE LA PEQUENA Y MEDIANA EMPRESA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('848901', 'BANCO DE MADRID S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5904401', 'BANCO DE SABADELL, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('425001', 'BANCO DE VALENCIA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2536401', 'BANCO DEPOSITARIO BBVA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5872601', 'BANCO ESPANOL DE CREDITO, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3332701', 'BANCO GALLEGO S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('424801', 'BANCO GUIPUZCOANO, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4327301', 'BANCO HALIFAX HISPANIA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3332601', 'BANCO INDUSTRIAL DE BILBAO', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5714501', 'BANCO INVERSIS S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('374511', 'BANCO LIBERBANK', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31011', 'Banco Mare Nostrum S.A', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2015001', 'BANCO OCCIDENTAL S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3332801', 'BANCO PASTOR S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31411', 'Banco Pichincha Espana, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5887301', 'BANCO POPULAR ESPANOL', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('31497802', 'BANCO PRIMUS S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57925602', 'BANCO SANTANDER (MEXICO), S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32962102', 'BANCO SANTANDER RIO S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218101', 'BANCO SANTANDER S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('6817602', 'BANCO UNIVERSAL, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('424001', 'BANCO URQUIJO SABADELL BANCA PRIVADA, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5714401', 'BANCOPOPULAR-E S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('22811', 'BANKIA, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5883301', 'BANKINTER, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11051702', 'BARCLAYS BANK PLC', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('849001', 'BARCLAYS BANK S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30685702', 'BAYERISCHE HYPO- UND VEREINSBANK AG', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4387201', 'BBVA BANCO DE FINANCIACION S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58816102', 'BBVA BANCOMER, S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('368111', 'BMCE BANK INTERNATIONAL S.A.
 BMCE BANK INTERNATI', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('849101', 'BNP PARIBAS ESPANA S.A.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('374711', 'C.R. DE ALBACETE, CIUDAD REAL Y CUENCA, S.C.C.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4633701', 'CAIXA D''ESTALVIS COMARCAL DE MANLLEU', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('601801', 'CAIXA D''ESTALVIS DE CATALUNYA (CAJA DE AHORROS DE ', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1476301', 'CAIXA D''ESTALVIS DE GIRONA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('424601', 'CAIXA D''ESTALVIS DE MANRESA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('685001', 'CAIXA D''ESTALVIS DE POLLENSA - COLONYA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('657301', 'CAIXA D''ESTALVIS DE SABADELL', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('556901', 'CAIXA D''ESTALVIS DE TARRAGONA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('424901', 'CAIXA D''ESTALVIS DE TERRASSA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1533501', 'CAIXA D''ESTALVIS DEL PENEDES', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('602201', 'CAIXA D''ESTALVIS LAIETANA', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('318211', 'CAIXA DE CREDIT DELS ENGINYERS-CC. INGENIEROS, S.C', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64841102', 'CAIXA GERAL DE DEPOSITOS', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4430001', 'CAIXA POPULAR-CAIXA RURAL, S. COOP. DE CREDITO V.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5675201', 'CAIXA RURAL ALBALAT DELS SORELLS, COOPERATIVA DE C', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3686401', 'CAIXA RURAL ALTEA, C.C.V.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3686301', 'CAIXA RURAL BENICARLO, S. COOP. DE CREDIT V.', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2668201', 'CAIXA RURAL D''ALGEMESI, S. COOP. V. DE CREDIT', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3686201', 'CAIXA RURAL DE BALEARS, S. COOP. DE CREDITO', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2668101', 'CAIXA RURAL DE CALLOSA D''EN SARRIA, COOPERATIVA DE', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4431001', 'CAIXA RURAL DE L''ALCUDIA, SOCIEDAD COOPERATIVA VAL', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5674101', 'CAIXA RURAL DE TURIS, COOPERATIVA DE CREDITO VALEN', 'ES');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('318011', '	Post Office Savings Bank (Singapore)', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52233402', 'AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57776502', 'BANK OF CHINA LIMITED', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67847902', 'BNP PARIBAS', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53371502', 'CIMB BANK BERHAD', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5829401', 'CITIBANK SINGAPORE LIMITED', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5873101', 'DBS BANK LTD', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('42027002', 'DEUTSCHE BANK AKTIENGESELLSCHAFT', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3331701', 'FAR EASTERN BANK LTD', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('365511', 'HL BANK SINGAPORE', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('20330755', 'HL BANK SINGAPORE', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27667602', 'HONG LEONG BANK BERHAD', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('165111', 'HSBC BANK (SINGAPORE) LIMITED', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('69101202', 'MALAYAN BANKING BERHAD', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('59793902', 'MIZUHO CORPORATE BANK, LIMITED', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('219301', 'OVERSEA-CHINESE BANKING CORPORATION LIMITED', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('32984602', 'PT BANK CENTRAL ASIA TBK', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55833402', 'RHB BANK BERHAD', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('165211', 'STANDARD CHARTERED BANK (SINGAPORE) LIMITED', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62060202', 'SUMITOMO MITSUI BANKING CORPORATION', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60731002', 'THE BANK OF TOKYO-MITSUBISHI UFJ, LTD', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5889701', 'UNITED OVERSEAS BANK LIMITED', 'SG');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2650501', '2CG LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1290501', '3I INVESTMENTS PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4017401', '3I NORDIC PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3008601', 'A S FOSTER LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51675902', 'AAREAL BANK AG', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36835002', 'AB BANK LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4827401', 'ABBEY LIFE ASSURANCE CO LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4827501', 'ABBEY NATIONAL ASSET MANAGERS LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2471501', 'ABBEY NATIONAL PEP AND ISA MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('454201', 'ABBEY NATIONAL TREASURY SERVICES PLC (UK)', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('996401', 'ABBEY NATIONAL UNIT TRUST MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4827601', 'ABBEY UNIT TRUST MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4876201', 'ABBOT INVESTMENT MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4523001', 'ABC CLEARING LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('432101', 'ABC INTERNATIONAL BANK PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1129201', 'ABERDEEN ASSET MANAGEMENT FUNDS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4859701', 'ABERDEEN ASSET MANAGEMENT INVESTMENT SERVICES LIMI', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3256501', 'ABERDEEN ASSET MANAGEMENT LIFE AND PENSIONS LIMITE', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2471601', 'ABERDEEN ASSET MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2764901', 'ABERDEEN PREFERRED INCOME TRUST PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4827701', 'ABERDEEN PRIVATE INVESTORS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1346101', 'ABERDEEN UNIT TRUST MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3632201', 'ABERFORTH UNIT TRUST MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2471701', 'ABERFORTH UTM', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('996501', 'ABG SUNDAL COLLIER LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4827801', 'ABINGWORTH MANAGEMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27787502', 'ABN AMRO ASSET MANAGEMENT FONDSMAEGLERSELSKAB A/S', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1255001', 'ABN AMRO CAPITAL (UK) LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1049701', 'ABN AMRO CORPORATE FINANCE LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2469801', 'ABN AMRO EQUITIES (UK) LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1146201', 'ABN AMRO FUTURES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826401', 'ABN AMRO HOARE GOVETT', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826501', 'ABN AMRO HOARE GOVETT CORPORATE FINANCE LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1237001', 'ABN AMRO HOARE GOVETT SECURITIES', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38218802', 'ABSA BANK LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1233201', 'ACG DEVELOPMENTS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1146301', 'ACM INVESTMENTS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2469901', 'ACTINVEST CORPORATION LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470001', 'ACTINVEST GROUP LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('626501', 'ADAM & COMPANY PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4845101', 'ADAM AND COMPANY INVESTMENT MANAGEMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2784201', 'ADAM SMITH LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2659601', 'ADAMS P T', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995801', 'ADD PARTNERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826601', 'ADELPHI CAPITAL LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3335101', 'ADG MARKET MAKING LLP', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470101', 'ADM INVESTOR SERVICES INTERNATIONAL LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826701', 'ADVANCE TRADING', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995901', 'ADVANCE TRADING (ARBITRAGE) LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470201', 'ADVANCE TRADING (OPTIONS) LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470301', 'ADVANCED MEDIA INVESTMENTS LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1049801', 'ADVENT INTERNATIONAL PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470401', 'ADVENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4845201', 'ADVICORP PUBLIC LIMITED COMPANY', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1146401', 'AEA INVESTORS (UK) LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470501', 'AEGIS CORPORATE STRATEGY LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1330201', 'AEGON ASSET MANAGEMENT UK PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826801', 'AEGON FUND MANAGEMENT UK LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2650601', 'AEQUILIBRIUM INVESTMENTS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826901', 'AERION FUND MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2784401', 'AFIM LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470601', 'AGI CORPORATE FINANCE LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('232201', 'AHLI UNITED BANK (UK) PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45435202', 'AIB CAPITAL MARKETS PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3358901', 'AIB GROUP (UK) PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4845301', 'AIG INVESTMENTS EUROPE LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1217201', 'AIG TRADING LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4328001', 'AIRDRIE SAVINGS BANK', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1496901', 'AITKEN CAMPBELL AND COMPANY LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2782801', 'AJG INVESTMENTS LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62884302', 'AKBANK T.A.S.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5136701', 'AKO CAPITAL LLP', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('34240602', 'AL WATANY BANK OF EGYPT', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3632001', 'ALADDIN CAPITAL MANAGEMENT UK LLP', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1049901', 'ALBANY VENTURE MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1235201', 'ALBEMARLE PRIVATE EQUITY LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2783101', 'ALBERDALE AND CO LP', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('996101', 'ALBION OIL LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1217401', 'ALBOURNE PARTNERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4855101', 'ALDER INVESTMENT MANAGEMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4845401', 'ALDERTON FINANCIAL SERVICES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4827001', 'ALEX BROWN AND SONS INVESTMENTS LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1687001', 'ALEXANDER DAVID SECURITIES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4523201', 'ALEXANDER SECURITIES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('38078102', 'ALFA CAPITAL HOLDINGS (CYPRUS) LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18760802', 'ALFA-BANK', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1048301', 'ALIE STREET SECURITIES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3609701', 'ALKEN ASSET MANAGEMENT LLP', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1572701', 'ALL IPO PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1146501', 'ALLCHURCHES INVESTMENT MANAGEMENT SERVICES', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4827101', 'ALLCO FINANCE (UK) LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5354501', 'ALLEN & OVERY', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2299002', 'ALLFUNDS BANK, S.A.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4071001', 'ALLIANCE & LEICESTER PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2650701', 'ALLIANCE AND LEICESTER SHARESAFE LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1129901', 'ALLIANCE AND LEICESTER UNIT TRUST MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470701', 'ALLIANCE CAPITAL LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470801', 'ALLIANCE CAPITAL WHITTINGDALE LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1249301', 'ALLIANCE FUND MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3594201', 'ALLIANCE TRUST SAVINGS LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5862901', 'ALLIANCEBERNSTEIN LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3337101', 'ALLIANZ GLOBAL INVESTORS (UK) LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50497302', 'ALLIED BANK OF PAKISTAN LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4069801', 'ALLIED BANK PHILIPPINES (UK) PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('11786602', 'ALLIED BANKING CORPORATION', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1445201', 'ALLIED IRISH BANK (GB)', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51988302', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51988402', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('51988502', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52988502', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52988702', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('52988802', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60937002', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65629402', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65634702', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65628502', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54467502', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58886302', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58887602', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58887702', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61152102', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61152302', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61152402', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61153602', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68085502', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68085602', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68085802', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68085302', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68085402', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54468902', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65629302', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60938602', 'ALLIED IRISH BANKS P.L.C.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2470901', 'ALLSOP AND CO INVESTMENTS LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1641701', 'ALMADIES INSURANCE SERVICES COMPANY LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1339401', 'ALMADIES UK BANK LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('996201', 'ALNISTA CAPITAL MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5130201', 'ALPARI (UK) LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2070301', 'ALPCAPITAL LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18549702', 'ALPHA BANK', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3359701', 'ALPHA BANK LONDON LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1113601', 'ALPHA BROKERS (METALS) LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1112201', 'ALPHA INVESTMENT MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1217301', 'ALTA ADVISERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4855001', 'ALTA BERKELEY ASSOCIATES LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4825301', 'ALTIUM CAPITAL LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4825401', 'ALTIUS ASSOCIATES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1307501', 'ALTUS INVESTMENT MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1866601', 'ALTUS LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4748001', 'AMADEUS CAPITAL PARTNERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4825501', 'AMALGAMATED METAL TRADING LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1112501', 'AMAS MATHESON ASSET MANAGEMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1145601', 'AMBAC CREDIT PRODUCTS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1145701', 'AMBRIAN PARTNERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3690301', 'AMC BANK LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995101', 'AMEREX FUTURES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995201', 'AMEREX PETROLEUM (UK) LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995301', 'AMERICAN EQUITIES OVERSEAS (UK) LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2784301', 'AMERICAN EXPRESS ASSET MANAGEMENT INTERNATIONAL', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('40998402', 'AMERICAN EXPRESS BANK LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('36529002', 'AMERICAN EXPRESS BANK LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29209502', 'AMERICAN EXPRESS BANK LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('29210402', 'AMERICAN EXPRESS BANK LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4825601', 'AMERICAN EXPRESS FINANCIAL SERVICES EUROPE LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4825701', 'AMIKON INVESTMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('39395502', 'AMP BANK LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4825801', 'AMSTEEL SECURITIES (FAR EAST) LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2469201', 'AMT FUTURES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2782501', 'ANCHORAGE CAPITAL PARTNERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5127801', 'ANDERSEN CHARNLEY INVESTMENT MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1145901', 'ANDERSON QUANTREND LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1525701', 'ANGLESEA FUNDING PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3369701', 'ANGLO AMERICAN CAPITAL PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1050001', 'ANGLO AND INTERNATIONAL CORPORATE FINANCE LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('653302', 'ANGLO IRISH BANK CORPORATION PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('653502', 'ANGLO IRISH BANK CORPORATION PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43395302', 'ANGLO IRISH BANK CORPORATION PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30478602', 'ANGLO IRISH BANK CORPORATION PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('30478802', 'ANGLO IRISH BANK CORPORATION PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37576802', 'ANGLO IRISH BANK CORPORATION PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('43394902', 'ANGLO IRISH BANK CORPORATION PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('653402', 'ANGLO IRISH BANK CORPORATION PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3359301', 'ANGLO-ROMANIAN BANK LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3359801', 'ANSBACHER & CO LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2658901', 'ANTEROS CAPITAL MARKETS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4825901', 'ANVIL PARTNERS LLP', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2794001', 'ANZ BANK (EUROPE) LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('37726402', 'ANZ NATIONAL BANK LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1111701', 'AON ADVISORS (UK) LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4855301', 'AON CAPITAL MARKETS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995401', 'APAX PARTNERS AND CO VENTURES LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1076401', 'APAX PARTNERS EUROPE MANAGERS LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1217801', 'APAX PARTNERS STRATEGIC INVESTORS LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('14385502', 'ARAB AFRICAN INTERNATIONAL BANK', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('50590202', 'ARAB NATIONAL BANK', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995501', 'ARBOR RESEARCH AND TRADING LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('668601', 'ARBUTHNOT LATHAM & CO LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5795201', 'ARBUTHNOT SECURITIES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1233301', 'ARBUTHNOT UNIT TRUST MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2781201', 'ARC PARTNERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1146001', 'ARCADIA PETROLEUM LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1111401', 'ARCANUM INVESTMENT MANAGEMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826001', 'ARCIS CAPITAL LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2782201', 'ARCUS INVESTMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826101', 'ARDEN PARTNERS PLC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2469301', 'ARGENTIA PENSION CONSULTANTS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3311901', 'ARGO TRADERS LLP', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1146101', 'ARGYLE INVESTMENT ADVISORS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995601', 'ARGYLL INVESTMENT MANAGEMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2782101', 'ARIEL (U.K.) LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4854201', 'ARK ASSET MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1523701', 'ARKIOS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('995701', 'ARLINGTON CAPITAL INVESTORS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('970601', 'ARLINGTON GROUP ASSET MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2784101', 'ARLINGTON PROPERTY INVESTMENT MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4912001', 'ARLINGTON PROPERTY UNIT TRUST MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2469401', 'ARM CORPORATE FINANCE LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826201', 'ARMAJARO SECURITIES LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1216201', 'ARNHOLD AND S BLEICHROEDER UK LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2469501', 'ARNOLD STANSBY AND CO.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1233801', 'AROS SECURITIES LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2781101', 'AROSMAIZELS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2065201', 'ARROWGRASS CAPITAL PARTNERS LLP', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5014901', 'ARTEMIS FUND MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4826301', 'ARTEMIS INVESTMENT MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2469601', 'ARTEMIS UNIT TRUST MANAGERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5131201', 'ARY FOREX LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2469701', 'ASAHI FINANCE (UK) LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2468101', 'ASAHI LIFE INVESTMENT EUROPE LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5009701', 'ASCENSION SECURITIES', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1145201', 'ASHCOURT ASSET MANAGEMENT LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2468201', 'ASHMORE CORPORATE FINANCE LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2468301', 'ASHMORE INVESTMENT MANAGEMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1234001', 'ASPECT CAPITAL LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2468401', 'ASPEN OIL (BROKING) LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1145301', 'ASSET ALLIANCE INTERNATIONAL LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1437601', 'ASSOCIATED FOREIGN EXCHANGE, LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1560401', 'ASSOCIATION FOR PAYMENT CLEARING SERVICES', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4070501', 'ASSOCIATION OF BRITISH CREDIT UNIONS LTD. (ABCUL)', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3218901', 'ASSOCIATION OF FOREIGN BANKS (AFB)', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4075101', 'ASSOCIATION OF INVESTMENT TRUST COMPANIES', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4824801', 'ASTAIRE AND PARTNERS LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1234501', 'ATC CLEARING SERVICES LTD.', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('994301', 'ATHANOR CAPITAL PARTNERS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('994401', 'ATLANTIC CAPITAL MANAGEMENT PARTNERS', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3018201', 'ATLANTIC-PACIFIC CAPITAL LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('994501', 'ATLANTIS INVESTMENT MANAGEMENT LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4824901', 'ATLAS CAPITAL LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3632101', 'ATLAS ONE FINANCIAL GROUP LTD', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4854601', 'ATTICA ALTERNATIVE INVESTMENTS LIMITED', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1145401', 'AUBREY G LANSTON AND CO INC', 'UK');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('19411', 'Union Bank Of California', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('18111', 'US BANK', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('21511', 'Wachovia Bank', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('17911', 'WELLS FARGO', 'US');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10511', 'ABN - AMRO', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('867401', 'BANCO BILBAO VIZCAYA ARGENTARIA URUGUAY S.A.', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('218001', 'BANCO DE LA REPUBLICA ORIENTAL DEL URUGUAY', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5881701', 'BANCO ITAU URUGUAY S.A.', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('867201', 'BANCO SANTANDER (URUGUAY) S.A.', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('867301', 'BANCO SURINVEST S.A.', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10611', 'CITIBANK', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3588601', 'CREDIT URUGUAY BANCO S.A.', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5895001', 'DISCOUNT BANK (LATIN AMERICA) S.A.', 'UY');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3895301', 'AN BINH COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4616701', 'ANZ BANK(VIETNAM) LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3248501', 'ANZ-VTRAC FINANCIAL LEASING COMPANY', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5883701', 'ASIA COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('47919402', 'ASIAN DEVELOPMENT BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60653702', 'BANGKOK BANK PUBLIC COMPANY LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('57776202', 'BANK OF CHINA', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('320111', 'BANK OF COMMUNICATIONS CO LTD', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('12943902', 'BANK OF INDIA', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64843102', 'BANK SINOPAC', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('320011', 'Bao Viet Joint Stock Commercial Bank', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3297001', 'BAO VIET SECURITIES COMPANY', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60667602', 'BNP PARIBAS', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('319911', 'CHINATRUST COMMERCIAL BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('45517302', 'CITIBANK N.A.', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('15709402', 'COMMONWEALTH BANK OF AUSTRALIA', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3248301', 'DAIABANK - GREAT ASIA COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('61196002', 'DBS BANK LTD', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('21834302', 'DEUTSCHE BANK PRIVAT-UND GESCHAFTSKUNDEN AG', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('702801', 'DONGA BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4016901', 'EVN FINANCE JOINT STOCK COMPANY', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54481702', 'FIRST COMMERCIAL BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3526301', 'FIRST COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('319811', 'GLOBAL PETRO COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5862001', 'HANDICO FINANCE COMPANY', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('163811', 'HOCHIMINH CITY DEVELOPMENT JOINT STOCK COMMERCIAL ', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339211', 'HONG LEONG BANK VIETNAM LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5851701', 'HSBC BANK (VIETNAM) LTD.', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67819002', 'HUA NAN COMMERCIAL BANK, LTD', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4311601', 'INDOVINA BANK LTD', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('320211', 'Industrial and Commercial Bank of China Limited', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60600302', 'INDUSTRIAL BANK OF KOREA', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5897001', 'Joint Stock Commercial Bank for Foreign Trade of V', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5895901', 'Joint Stock Commercial Bank for Investment and Dev', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('26214302', 'JPMORGAN CHASE BANK, NATIONAL ASSOCIATION', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339111', 'KEB Hana Bank', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3994401', 'KEXIM VIETNAM LEASING COMPANY (KVLC)', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3235901', 'KIEN LONG COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('63283302', 'KOOKMIN BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60648902', 'KOREA EXCHANGE BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3951001', 'LIEN VIET JOINT STOCK COMMERCIAL BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53555102', 'MALAYAN BANKING BERHAD', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60101102', 'MEGA INTERNATIONAL COMMERCIAL BANK CO., LTD.', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1115701', 'MILITARY COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('68980002', 'MIZUHO CORPORATE BANK, LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('703001', 'NAM A COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('320311', 'NATIONAL CITIZEN COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54678402', 'NATIXIS', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4926401', 'NORTH ASIA COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5847301', 'OCEAN COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('164011', 'ORIENT COMMERCIAL JOINT STOCK BANK (ORICOMBANK)', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('320411', 'OVERSEAS CHINESE BANKING COPERATION LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('338911', 'PETROLIMEX GROUP COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3248601', 'PRUDENTIAL VIETNAM FINANCE COMPANY LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('58514102', 'PT BANK CIMB NIAGA TBK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('503901', 'PUBLIC BANK VIETNAM LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1576101', 'PVCombank', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('53311', 'SACOMBANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1554001', 'SAIGON BANK FOR INDUSTRY AND TRADE', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4647101', 'SAIGON COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5041801', 'SAIGON HANOI COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5897101', 'SAIGON THUONG TIN COMMERCIAL JOINT STOCK BANK (SAC', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1865301', 'SAMSUNG VINA ELECTRONICS CO., LTD', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('55164102', 'SHINHAN BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4612701', 'SONG DA FINANCE JOINT STOCK COMPANY', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3021501', 'SOUTHEAST ASIA COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('567501', 'SOUTHERN COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('10513602', 'STANDARD CHARTERED BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3278601', 'STANDARD CHARTERED BANK (VIETNAM) LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5871001', 'STATE BANK OF VIETNAM', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('64339102', 'SUMITOMO MITSUI BANKING CORPORATION', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('67070902', 'TAIPEI FUBON COMMERCIAL BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60319802', 'THE BANK OF TOKYO-MITSUBISHI UFJ, LTD', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('65252202', 'THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMI', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('54090102', 'THE SHANGHAI COMMERCIAL & SAVINGS BANK, LTD', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('1589201', 'TIENPHONG COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('4017001', 'TOYOTA VIETNAM FINANCE COMPANY LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('62328102', 'UNITED OVERSEAS BANK LIMITED', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('163511', 'VIET CAPITAL COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('3236001', 'VIET NAM THUONG TIN COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5888501', 'VIETNAM BANK FOR AGRICULTURE AND RURAL DEVELOPMENT', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5888601', 'VIETNAM BANK FOR INDUSTRY AND TRADE (VIETINBANK)', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('164111', 'VIETNAM EXPORT- IMPORT COMMERCIAL JOINT-STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('164211', 'VIETNAM INTERNATIONAL COMMERCIAL JOINT STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('163611', 'VIETNAM MARITIME COMMERCIAL STOCK BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('163711', 'VIETNAM PROSPERITY JOINT STOCK COMMERCIAL BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('339011', 'VIETNAM PUBLIC JOINT STOCK COMMERCIAL BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('185911', 'VIETNAM TECHNOLOGICAL AND COMMERCIAL JOINT STOCK B', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('2710201', 'VINASIAM BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('60919202', 'WOORI BANK', 'VN');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('367611', 'ALKURAIMI ISLAMIC BANK', 'YE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('5371701', 'COOPERATIVE AND AGRICULTURAL CREDIT BANK', 'YE');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('27111', 'Ab Bank Zambia', 'ZM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('135611', 'Ecobank Zambia', 'ZM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('345411', 'UNITED BANK FOR AFRICA ZAMBIA', 'ZM');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('318811', 'FIRST CAPITAL BANK LTD', 'ZW');

insert into iftb_ria_bank_dtls (BANK_ID, BANK_NAME, COUNTRY_CODE)
values ('283111', 'ZB BANK LIMITED', 'ZW');

prompt Done.
