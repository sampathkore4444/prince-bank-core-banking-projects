prompt Importing table iftb_ria_agent_dtls...
set feedback off
set define off
insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1080511', 'Perucourier-Jet Peru-Jet Argentina', 'AR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('5924811', 'Argenper S.A.', 'AR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('19863611', 'Maguiexpress SA', 'AR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('46268611', 'Latin Express Financial Services Argentina S.A', 'AR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('69315411', 'Cobro Express Global S.A.', 'AR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('79432811', 'CartaSur SA', 'AR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('44922111', 'Any Bank Payout', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('364412', '** BRAC BANK **', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('12717211', 'Ab Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('50445411', 'Bank Asia Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7003514', 'Dutch Bangla Bank Ltd', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('45310811', 'Bangladesh Krishi Bank', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('39117611', 'Dhaka Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('8077014', 'Agrani Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7002214', 'Prime Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7308614', 'Uttara Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('16646811', 'Southeast Bank', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('23793311', 'Janata Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('44904711', 'Trust Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('50444911', 'Social Islami Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('52338011', 'Sonali Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('65780811', 'United Commercial Bank Ltd', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('75925711', 'One Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('79704611', 'Mercantile Bank Limited', 'BD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1065811', 'Bancomer', 'BO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4344411', 'Euroenvios', 'BO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('5924811', 'Argenper S.A.', 'BO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('12394611', 'Banco Ganadero', 'BO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('16963111', '1', 'BO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('18875411', 'Mabrend Hispano Transfer SRL (Boligiros S.R.L)', 'BO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('104588711', 'Banco Fassil (Sub-Agentes)', 'BO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6051614', 'Nova Banka', 'BA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6105414', 'Novabanka (Post Office)', 'BA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('91627511', 'Novabanka Bosnia Post Office', 'BA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('75049711', 'Anywhere Payout Bulgaria', 'BG');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('70153711', 'Bulgarian Post (Eurogiro - Inpay AS)', 'BG');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('22659411', 'Tokuda Bank AD', 'BG');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7781614', 'Easypay AD', 'BG');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('43736511', 'Sacombank (Cambodia) Plc (IME)', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('35171155', 'Wing', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('46658411', 'Advanced Bank of Asia Limited', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('90447411', 'Anywhere Payout Cambodia - USD', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('95990911', 'Sacombank (Cambodia) Plc', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('100548611', 'Prince Bank PLC', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('104767811', 'Chip Mong Commercial Bank Plc', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('105073911', 'LY Hour Pay Pro Plc', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('106043411', 'Cambodian Post (Eurogiro - Inpay AS)', 'KH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1066911', 'Banco W S.A (Pagos Internacionales S.A)', 'CO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4130111', 'Bancolombia S.A.', 'CO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4065111', 'Davivienda', 'CO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('82421211', 'Banco de Bogota S.A.', 'CO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('403212', 'Credomatic', 'CR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1034511', 'TeleDolar  S.A', 'CR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('43945611', 'Easypay - Phillgus', 'CR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('79650211', 'Anywhere Payout REPUBLIC OF CYPRUS (ROC) Only', 'CY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('79651311', 'Anywhere Payout NORTH CYPRUS ONLY', 'CY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7781614', 'Easypay AD', 'CY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('96327611', 'G.S. Cash Line LTD', 'CY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('10109', 'Caribe Express', 'DO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6843511', 'Banco BHD Leon S.A.', 'DO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('19268111', 'Banco Union', 'DO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('32717311', 'Banreservas', 'DO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('44622311', 'Asociacion La Nacional de A y P', 'DO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('53341611', 'Banco Popular Dominicano S.A.', 'DO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('34631811', 'Coop. A y C Juventud Ecuatoriana Progresista Ltda.', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('46283711', 'Cooperativa de Ahorro y Credito Fernando Daquilema Ltda', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('35424011', 'Cooperativa de Ahorro y Credito Jardin Azuayo', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4270211', 'Corporaciones Unidas Del Austro', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('5924811', 'Argenper S.A.', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('17509', 'Banco de Guayaquil', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('66095511', 'Banco de Loja S.A.', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1454212', 'Banco Pichincha', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('17071711', 'RTC', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('89093011', 'Transfer JEIS', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('93278311', 'Cooperativa De Ahorro Y Credito CREA', 'EC');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('19055611', 'Banco Atlantida El Salvador S.A', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('16309', 'Banco Agricola', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1456912', 'BANCOVI R.L.', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('403212', 'Credomatic', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('19323911', 'Las Americas Express International Courier S.A.', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('20569411', 'Paiz-Hiper Paiz (TNWK)', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1021511', 'Banco Cuscatlan El Salvador, S.A (TNWK)', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6091411', 'Banco Promerica S.A. El Salvador', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('10173811', 'Fedecaces', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('25688311', 'Super Selectos (TNWK)', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('92371211', 'Abank', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('100000111', 'Banco Azul (TNWK)', 'SV');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4194111', 'Banco Industrial S.A.', 'GT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('16009', 'Banrural S.A. - Guatemala (TNWK)', 'GT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('13609', 'Banco G & T Continental', 'GT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('17741411', 'Banco Azteca Guatemala S.A.', 'GT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('48632811', 'Farmacias Cruz Verde / Red Chapina', 'GT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('53069111', 'BAM-Banco Agromercantil (Rchapina)', 'GT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('77390311', 'Banco De Antigua - Red Chapina', 'GT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('77390411', 'Banco De Credito - Red Chapina', 'GT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1453712', 'Banco De Occidente', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6093311', 'Banco Promerica S.A. Honduras', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6970411', 'Banco Ficohsa', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('18651611', 'Banco Azteca Honduras S.A.', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('21553811', 'Banco Atlantida S.A', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('37036111', 'Banrural S.A - Honduras (TNWK)', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('54585411', 'CACIL de R.L.', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('73349911', 'Banco Lafise Honduras S.A.', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('88900711', 'Banco Del Pais, S.A', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('91600211', 'Banco Davivienda Honduras S.A.', 'HN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('84592911', 'Hungarian Post (Eurogiro - Inpay AS)', 'HU');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('99432611', 'Takarekbank Zrt.', 'HU');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('92291011', 'Anywhere Payout Indonesia - IDR', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('26635511', 'PT Bank Rakyat Indonesia', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('76776911', 'PT Pos Indonesia (Persero)', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('52643011', 'PT Bank Central Asia Tbk', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('25007111', 'PT Bank Negara Indonesia Tbk', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('659112', 'PT Bank CIMB Niaga', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('35172155', 'PT Post Indonesia (Persero)', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('76776311', 'PT Pegadaian (Persero)', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('100778311', 'PT. Reyhan Putra Mandiri', 'ID');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('43956511', 'IME Unidos Ltd.', 'JP');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('64579011', 'Unidos Ltd', 'JP');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6105414', 'Novabanka (Post Office)', 'LT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7925114', 'UAB Medicinos Bankas', 'LT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('36536211', 'Paysera', 'LT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('88936111', 'Lithuanian Post (Eurogiro - Inpay AS)', 'LT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('91492911', 'Anywhere Payout Lithuania EUR', 'LT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1065811', 'Bancomer', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('2567411', 'Empenos Del Sur S.A. De C.V. (Balsas)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4772511', 'Bansefi / Banco del Bienestar', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('19384511', 'Telecom', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('21269711', 'Elektra', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('29624911', 'Banorte (Uniteller) - Testing', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('33260811', 'Nueva Wal-Mart de Mexico, S. de R.L. de C.V', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('35989511', 'Aifco', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('41925711', 'Inpamex', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('41926711', 'Farmapronto (Inpamex)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('41926811', 'Chedraui (Inpamex)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('46286111', 'Farmacias Guadalajara', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('52749711', 'Farmacias Del Ahorro', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('55031811', 'Farmacias Isseg (Inpamex)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('60579311', 'Fundacion Donde (Tuuxt Taakin)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('66216711', 'Tiendas del Sol (Datransfer S.A. De C.V.)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('66273411', 'Woolworth (Datransfer S.A. De C.V.)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('74856311', 'Envios Tlachichilco', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('84453611', 'OXXO', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('95275011', 'BanCoppel S.A. (Appriza Pay Llc.)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('105377411', 'Chedraui (Appriza Pay LLC.)', 'MX');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6668514', 'CB Comertbank JSC', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('17124411', 'JSCB Moldindconbank', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('18068311', 'EuroCreditBank', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('34215611', 'FinComBank S.A.', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('60889411', 'AgroIndBank Moldova', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('71875611', 'Paynet Services LLC', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('73417011', 'BPAY LLC', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('84170411', 'Posta Moldovei', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('89078811', 'Anywhere Payout Moldova EUR USD', 'MD');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('63225811', 'Sendmn NBFI LLC', 'MN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('73240211', 'Public Credit NBFI LLC', 'MN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('87766311', 'Mongolian Post (Eurogiro - Inpay As)', 'MN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6410511', 'Banpro (Banco De La Produccion Nicaragua)', 'NI');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('21235611', 'Banco Lafise Bancentro', 'NI');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('53079111', 'Teledolar S.A.', 'NI');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6372914', 'JS Bank', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('14032411', 'Allied Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('20351911', 'Meezan Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('22282011', 'National Bank Of Pakistan', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('22803711', 'MCB Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('35529411', 'Soneri Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('36539411', 'Bank Of Punjab', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('43949111', 'IME National Bank of Pakistan (NBP)', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('43953511', 'IME MCB Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('48304311', 'Bankislami Pakistan Limited ', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('48547711', 'IME JS Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('49306411', 'Bank Of Punjab - PRI', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('49762811', 'Habib Metropolitan Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('50483311', 'A A Exchange Company Private Ltd', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('51899911', 'Dollar East Exchange Company Private Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('52994311', 'Royal International Exchange Company (Pvt) Ltd', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('61396811', 'Wall Street Exchange Company (Pvt) Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('66527711', 'H&H Exchange Company Private Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('68184811', 'Anywhere Payout Pakistan', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('72366411', 'Link International Exchange Company Pvt Ltd', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('72859111', 'The Bank Of Khyber', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('74816711', 'Askari Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('76816311', 'NBP Exchange Company Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('77174811', 'Ravi Exchange Company (Private) Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('77187411', 'Paragon Exchange (Private) Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('79297411', 'FairDeal Exchange Company Private Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('79364911', 'Muhammadi Exchange Company (Pvt)Ltd', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('80075011', 'United Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('88956611', 'Sindh Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('94108911', 'IME Soneri Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('101011611', 'IME  Askari Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('103790211', 'Faysal Bank Limited', 'PK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('5924811', 'Argenper S.A.', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('31042711', 'Banco Financiero del Peru', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('22992211', 'Banco Azteca Peru S.A.', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('17709', 'Banco de Credito del Peru', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('40216911', 'InkaFarma', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('35095511', 'Interbank Agente', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1080511', 'Perucourier-Jet Peru-Jet Argentina', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('290212', 'Peru Express S.A.', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4201711', 'Interbank', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('17186811', 'Scotiabank Peru SAA', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('96315811', 'Banco Azteca Peru S.A. (Directo)', 'PE');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('757912', 'Banco Familiar', 'PY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('37111611', 'Pronet S.A.', 'PY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('53099511', 'FE Cambios S.A', 'PY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('60065511', 'Maxicambios SA', 'PY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('62371211', 'UB S.A.', 'PY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('47165211', 'Realtransfer - Instituiçao De Pagamento, S.A.', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('51858311', 'Perola Da India Artigos De Papelaria LDA', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('53299611', 'Waldemar Vieira Neto', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('54103311', 'MD Abdul Hakim Minhaj', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('54960311', 'Rinjin Travel Tours, Lda', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('57057711', 'Tej Paul Singh', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('57516311', 'Elizabeth Escalante Unipessoal LDA', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('58797611', 'Waseem Ashraf', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('58798011', 'Waldemar Vieira Neto', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('59550511', 'MD Abdul Hakim Minhaj', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('60639211', 'Cultura do Tabaco-Tabacaria,Unipessoal,LDA', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('61339211', 'MD Shekh Farid', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('63245411', 'Piotr Coltuc', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('63921311', 'Lucdeia LDA', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('67252911', 'Uni eventos, unipessoal LDA', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('68863111', 'Asmita Kadel', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('71899811', 'Dalbir Singh', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('71946611', 'Raj Kumar Tamang', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('72303711', 'Jagpreet Singh', 'PT');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('86908911', 'CN Posta Romana S.A.', 'RO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('18328511', 'CEC Bank/Transfer Rapid', 'RO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('94006711', 'Speed Transfer Amanet', 'RO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('97613711', 'Payout Romania EUR RON', 'RO');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1043211', 'Qiwi Bank JSC (Contact System)', 'RU');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7884114', 'KoronaPay (CU Payment System)', 'RU');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('50058411', 'Unistream Commercial Bank JSC', 'RU');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('79690211', 'VTB Bank', 'RU');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('6246914', 'Commercial Bank of Ceylon PLC', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7955114', 'Bank Of Ceylon', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('8023614', 'Seylan Bank', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('14556811', 'Sampath Bank Limited', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('17062511', 'Hatton National Bank PLC', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('52983611', 'Cargills Bank Ltd & Cargilis Food Stores', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('53069011', 'Any Bank Payout', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('66474111', 'Pan Asia Banking Corporation PLC', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('72517611', 'National Savings Bank', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('83637511', 'MMBL Money Transfer Private Limited', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('91677411', 'People''s Bank', 'LK');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('33627511', 'Stichting Surinaamse Volkscredietbank', 'SR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('59884811', 'Southern Commercial Bank N.V.', 'SR');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1985314', 'Ria Geneve', 'CH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('5793914', 'Ria Lausanne', 'CH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('5794014', 'Ria Zürich', 'CH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7533314', 'Ria Basel', 'CH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('34113411', 'Ria Genève II', 'CH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('53471611', 'Ria Biel', 'CH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('60803811', 'Ria Lugano', 'CH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('68444311', 'RIA Renens', 'CH');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('92415711', 'Anywhere Payout Tunisia', 'TN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1740714', 'BH Bank ( Former Banque de L''Habitat)', 'TN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('106378511', 'Wifak Bank', 'TN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('84195911', 'Anywhere Payout Ukraine', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('73225211', 'Payout in UAH only - NovaPoshta', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('105316811', 'Save The Children', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('7924914', 'Credit Dnepr Bank PJSC', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('20195611', 'Universal Bank', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('20196311', 'Ukrgasbank JSB', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('20201211', 'Ukrainian Financial Group', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('20203111', 'Kredobank Ojsc', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('20203711', 'State Savings Bank Of Ukraine JSC', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('37583411', 'Privatbank', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('42658511', 'Bank Pivdennyi', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('42969711', 'JSC Pravex Bank', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('46551911', 'PJSC IBOX Bank', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('49376011', 'PJSC CB Globus', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('49411211', 'PJSC Bank Vostok', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('53517011', 'Accordbank CB PJSC', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('54247611', 'Ukr Post', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('56204511', 'Industrial Bank PJSC JSCB', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('74448711', 'JSC Unex Bank', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('75549111', 'JSC RWS Bank', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('75810511', 'Jsc First Ukrainian International Bank', 'UA');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('1065811', 'Bancomer', 'UY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4152011', 'More Money Transfers', 'UY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('5924811', 'Argenper S.A.', 'UY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('33899711', 'Varlix Servicios Fin.', 'UY');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('75909611', 'Aloqabank JSC', 'UZ');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('75953911', 'Qishloq Qurilish Bank JSCB', 'UZ');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('76988911', 'Microcreditbank JSCB', 'UZ');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('77169611', 'Uzbek Industrial and Construction Bank JSCB', 'UZ');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('81402111', 'Agrobank JSCB', 'UZ');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('82962811', 'JSCMB Ipoteka bank', 'UZ');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('101893311', 'Bank Orient Finans PJSC', 'UZ');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('73011411', 'Anywhere Payout VND', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('95470211', 'Anywhere Payout USD', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('48387311', 'Vietcombank (JSC Bank for Foreign Trade of Vietnam)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('4845411', 'VIB (Vietnam International Bank)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('17924111', 'DongA (Dong A Commercial Joint Stock Bank)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('22720311', 'SacomBank (Sacombank Remittance Express Company)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('49344011', 'HD Bank (Ho Chi Minh City Dev. JSC Bank)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('59153711', 'Sacombank Other Banks', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('81687311', 'Military Commercial Joint Stock Bank (Mb) Bank', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('81935311', 'Vietinbank', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('82014011', 'SCB (Sai Gon Joint Stock Commercial Bank)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('82036611', 'Exim Bank', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('86980611', 'ACB (Asia Commercial Joint Stock Bank)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('91933611', 'BIDV', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('92079011', 'SeABank (Southeast Asia Commercial Joint Stock Bank)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('92079111', 'Post and Telecommunication Finance Company (PTF)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('93675111', 'MSB(Vietnam Maritime Commercial Join Stock Bank)', 'VN');

insert into iftb_ria_agent_dtls (CORRESPONDENT_ID, CORRESPONDENT_NAME, COUNTRY_CODE)
values ('97474311', 'Vietnam Bank For Agriculture And Rural Development ', 'VN');

prompt Done.
