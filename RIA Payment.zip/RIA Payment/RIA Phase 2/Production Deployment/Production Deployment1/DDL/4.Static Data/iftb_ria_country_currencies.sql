prompt Importing table iftb_ria_country_currencies...
set feedback off
set define off
insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('KR', 'KRW', 'Korea Republic');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SG', 'SGD', 'Singapore');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AL', 'ALL', 'Albania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AL', 'EUR', 'Albania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AL', 'USD', 'Albania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AG', 'XCD', 'Antigua');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AR', 'ARS', 'Argentina');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AM', 'EUR', 'Armenia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AM', 'USD', 'Armenia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AU', 'AUD', 'Australia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BH', 'BHD', 'Bahrain');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BD', 'BDT', 'Bangladesh');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BY', 'EUR', 'Belarus');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BY', 'RUB', 'Belarus');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BY', 'USD', 'Belarus');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BE', 'EUR', 'Belgium');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BJ', 'XOF', 'Benin');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BO', 'BOB', 'Bolivia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BO', 'USD', 'Bolivia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BO', 'EUR', 'Bolivia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BA', 'BAM', 'Bosnia and Herzegovina');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BA', 'EUR', 'Bosnia and Herzegovina');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BR', 'BRL', 'Brazil');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BG', 'BGN', 'Bulgaria');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BG', 'EUR', 'Bulgaria');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BG', 'USD', 'Bulgaria');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BF', 'XOF', 'Burkina Faso');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('BI', 'BIF', 'Burundi');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('KH', 'USD', 'Cambodia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('KH', 'KHR', 'Cambodia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CM', 'XAF', 'Cameroon');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CA', 'CAD', 'Canada');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CA', 'USD', 'Canada');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CL', 'CLP', 'Chile');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CL', 'USD', 'Chile');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CN', 'CNY', 'China');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CO', 'COP', 'Colombia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('KM', 'KMF', 'Comoros');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CD', 'USD', 'Congo Democratic Republic');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CR', 'CRC', 'Costa Rica');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CR', 'USD', 'Costa Rica');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CI', 'XOF', 'Cote d''Ivoire');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HR', 'EUR', 'Croatia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HR', 'HRK', 'Croatia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CY', 'EUR', 'Cyprus');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CY', 'GBP', 'Cyprus');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CY', 'TRY', 'Cyprus');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CY', 'USD', 'Cyprus');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('DJ', 'DJF', 'Djibouti');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('DO', 'DOP', 'Dominican Republic');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('DO', 'USD', 'Dominican Republic');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('EC', 'USD', 'Ecuador');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('EG', 'EGP', 'Egypt');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('EG', 'EUR', 'Egypt');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('EG', 'USD', 'Egypt');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SV', 'USD', 'El Salvador');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('EE', 'EUR', 'Estonia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('ET', 'ETB', 'Ethiopia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('FI', 'EUR', 'Finland');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('FR', 'EUR', 'France');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GA', 'XAF', 'Gabon');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GM', 'GMD', 'Gambia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GE', 'EUR', 'Georgia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GE', 'USD', 'Georgia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GE', 'GEL', 'Georgia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('DE', 'EUR', 'Germany');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GH', 'GHS', 'Ghana');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GR', 'EUR', 'Greece');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GT', 'GTQ', 'Guatemala');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GN', 'GNF', 'Guinea');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GW', 'XOF', 'Guinea-Bissau');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('GY', 'GYD', 'Guyana');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HT', 'HTG', 'Haiti');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HT', 'USD', 'Haiti');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HN', 'HNL', 'Honduras');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HN', 'USD', 'Honduras');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HU', 'HUF', 'Hungary');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HU', 'EUR', 'Hungary');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('IN', 'INR', 'India');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('ID', 'IDR', 'Indonesia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('ID', 'USD', 'Indonesia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('IE', 'EUR', 'Ireland');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('IL', 'EUR', 'Israel');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('IL', 'USD', 'Israel');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('IL', 'ILS', 'Israel');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('IT', 'EUR', 'Italy');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('JM', 'JMD', 'Jamaica');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('JP', 'JPY', 'Japan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('JO', 'JOD', 'Jordan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('JO', 'USD', 'Jordan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('KZ', 'EUR', 'Kazakhstan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('KZ', 'RUB', 'Kazakhstan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('KZ', 'USD', 'Kazakhstan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('KE', 'KES', 'Kenya');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LA', 'USD', 'Laos');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LV', 'EUR', 'Latvia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LR', 'LRD', 'Liberia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LR', 'USD', 'Liberia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LR', 'LKR', 'Liberia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LT', 'EUR', 'Lithuania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LT', 'GBP', 'Lithuania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LT', 'USD', 'Lithuania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LU', 'EUR', 'Luxembourg');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MY', 'MYR', 'Malaysia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MY', 'USD', 'Malaysia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('ML', 'XOF', 'Mali');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MR', 'MRU', 'Mauritania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MX', 'MXN', 'Mexico');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MX', 'USD', 'Mexico');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MD', 'EUR', 'Moldova, Republic of');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MD', 'USD', 'Moldova, Republic of');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MD', 'MDL', 'Moldova, Republic of');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MN', 'EUR', 'Mongolia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MN', 'MNT', 'Mongolia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MN', 'USD', 'Mongolia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('ME', 'EUR', 'Montenegro');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MA', 'MAD', 'Morocco');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MZ', 'MZN', 'Mozambique');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MZ', 'USD', 'Mozambique');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MM', 'MMK', 'Myanmar');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('MM', 'USD', 'Myanmar');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('NP', 'NPR', 'Nepal');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('NL', 'EUR', 'Netherlands');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('NZ', 'NZD', 'New Zealand');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('NI', 'USD', 'Nicaragua');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('NE', 'XOF', 'Niger Republic of');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('NG', 'USD', 'Nigeria');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('NO', 'NOK', 'Norway');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('NO', 'EUR', 'Norway');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('OM', 'OMR', 'Oman');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PK', 'PKR', 'Pakistan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PY', 'PYG', 'Paraguay');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PY', 'USD', 'Paraguay');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PE', 'EUR', 'Peru');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PE', 'PEN', 'Peru');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PE', 'USD', 'Peru');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PH', 'PHP', 'Philippines');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PH', 'USD', 'Philippines');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PL', 'PLN', 'Poland');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PL', 'EUR', 'Poland');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PT', 'EUR', 'Portugal');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('PR', 'USD', 'Puerto Rico');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RO', 'EUR', 'Romania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RO', 'RON', 'Romania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RU', 'EUR', 'Russia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RU', 'RUB', 'Russia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RU', 'USD', 'Russia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RU', 'GBP', 'Russia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RW', 'RWF', 'Rwanda');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SN', 'XOF', 'Senegal');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RS', 'EUR', 'Serbia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('RS', 'RSD', 'Serbia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SL', 'SLL', 'Sierra Leone');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SI', 'EUR', 'Slovenia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('ES', 'EUR', 'Spain');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LK', 'EUR', 'Sri Lanka');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LK', 'GBP', 'Sri Lanka');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LK', 'LKR', 'Sri Lanka');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('LK', 'USD', 'Sri Lanka');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SR', 'EUR', 'Suriname');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SR', 'USD', 'Suriname');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SE', 'SEK', 'Sweden');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('SE', 'USD', 'Sweden');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('CH', 'CHF', 'Switzerland');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TJ', 'EUR', 'Tajikistan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TJ', 'USD', 'Tajikistan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TZ', 'TZS', 'Tanzania');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TH', 'THB', 'Thailand');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TG', 'XOF', 'Togo');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TO', 'TOP', 'Tonga');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TT', 'TTD', 'Trinidad');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TT', 'USD', 'Trinidad');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TN', 'TND', 'Tunisia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TR', 'EUR', 'Turkey');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TR', 'TRY', 'Turkey');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TR', 'USD', 'Turkey');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('TR', 'XOF', 'Turkey');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UG', 'UGX', 'Uganda');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UA', 'EUR', 'Ukraine');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UA', 'USD', 'Ukraine');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UA', 'UAH', 'Ukraine');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('AE', 'AED', 'United Arab Emirates');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UK', 'GBP', 'United Kingdom');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UK', 'GNF', 'United Kingdom');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UK', 'EUR', 'United Kingdom');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('US', 'USD', 'United States');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('US', 'XOF', 'United States');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UY', 'USD', 'Uruguay');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UY', 'UYU', 'Uruguay');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UZ', 'USD', 'Uzbekistan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('UZ', 'EUR', 'Uzbekistan');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('VN', 'VND', 'Vietnam');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('VN', 'USD', 'Vietnam');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('VN', 'AUD', 'Vietnam');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('VN', 'CAD', 'Vietnam');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('VN', 'EUR', 'Vietnam');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('VN', 'GBP', 'Vietnam');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('YE', 'SAR', 'Yemen');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('YE', 'USD', 'Yemen');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('YE', 'YER', 'Yemen');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('ZM', 'USD', 'Zambia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('ZM', 'ZMW', 'Zambia');

insert into iftb_ria_country_currencies (COUNTRY_CODE, CURRENCY, COUNTRY_NAME)
values ('HK', 'HKD', 'Hong Kong');

prompt Done.
