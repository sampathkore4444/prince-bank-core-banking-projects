prompt Importing table iftb_ria_agent_ccy_dtls...
set feedback off
set define off
insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BA', 'C', '6051614', 'Nova Banka', 'BAM');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BA', 'C', '6051614', 'Nova Banka', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('AR', 'C', '1080511', 'Perucourier-Jet Peru-Jet Argentina', 'ARS');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('AR', 'C', '5924811', 'Argenper S.A.', 'ARS');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BA', 'C', '6105414', 'Novabanka (Post Office)', 'BAM');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BA', 'C', '6105414', 'Novabanka (Post Office)', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BA', 'C', '91627511', 'Novabanka Bosnia Post Office', 'BAM');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BG', 'C', '75049711', 'Anywhere Payout Bulgaria', 'BGN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BG', 'C', '70153711', 'Bulgarian Post (Eurogiro - Inpay AS)', 'BGN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BG', 'C', '22659411', 'Tokuda Bank AD', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BG', 'C', '22659411', 'Tokuda Bank AD', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BG', 'C', '7781614', 'Easypay AD', 'BGN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BG', 'C', '7781614', 'Easypay AD', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '1065811', 'Bancomer', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('AR', 'C', '19863611', 'Maguiexpress SA', 'ARS');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('AR', 'C', '46268611', 'Latin Express Financial Services Argentina S.A', 'ARS');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('AR', 'C', '69315411', 'Cobro Express Global S.A.', 'ARS');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('AR', 'C', '79432811', 'CartaSur SA', 'ARS');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '44922111', 'Any Bank Payout', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '364412', '** BRAC BANK **', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '12717211', 'Ab Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '50445411', 'Bank Asia Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '7003514', 'Dutch Bangla Bank Ltd', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '45310811', 'Bangladesh Krishi Bank', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '39117611', 'Dhaka Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '8077014', 'Agrani Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '7002214', 'Prime Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '7308614', 'Uttara Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '16646811', 'Southeast Bank', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '23793311', 'Janata Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '44904711', 'Trust Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '50444911', 'Social Islami Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '52338011', 'Sonali Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '65780811', 'United Commercial Bank Ltd', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '75925711', 'One Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BD', 'C', '79704611', 'Mercantile Bank Limited', 'BDT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '4344411', 'Euroenvios', 'BOB');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '4344411', 'Euroenvios', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '5924811', 'Argenper S.A.', 'BOB');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '5924811', 'Argenper S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '12394611', 'Banco Ganadero', 'BOB');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '12394611', 'Banco Ganadero', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '16963111', '1', 'BOB');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '16963111', '1', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '16963111', '1', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '18875411', 'Mabrend Hispano Transfer SRL (Boligiros S.R.L)', 'BOB');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('BO', 'C', '104588711', 'Banco Fassil (Sub-Agentes)', 'BOB');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '43736511', 'Sacombank (Cambodia) Plc (IME)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '35171155', 'Wing', 'KHR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '35171155', 'Wing', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '46658411', 'Advanced Bank of Asia Limited', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '90447411', 'Anywhere Payout Cambodia - USD', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '95990911', 'Sacombank (Cambodia) Plc', 'KHR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '95990911', 'Sacombank (Cambodia) Plc', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '100548611', 'Prince Bank PLC', 'KHR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '100548611', 'Prince Bank PLC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '104767811', 'Chip Mong Commercial Bank Plc', 'KHR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '104767811', 'Chip Mong Commercial Bank Plc', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '105073911', 'LY Hour Pay Pro Plc', 'KHR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '105073911', 'LY Hour Pay Pro Plc', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('KH', 'C', '106043411', 'Cambodian Post (Eurogiro - Inpay AS)', 'KHR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CO', 'C', '1066911', 'Banco W S.A (Pagos Internacionales S.A)', 'COP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CO', 'C', '4130111', 'Bancolombia S.A.', 'COP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CO', 'C', '4065111', 'Davivienda', 'COP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CO', 'C', '82421211', 'Banco de Bogota S.A.', 'COP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CR', 'C', '403212', 'Credomatic', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CR', 'C', '1034511', 'TeleDolar  S.A', 'CRC');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CR', 'C', '1034511', 'TeleDolar  S.A', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CR', 'C', '43945611', 'Easypay - Phillgus', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '10109', 'Caribe Express', 'DOP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '10109', 'Caribe Express', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '6843511', 'Banco BHD Leon S.A.', 'DOP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '6843511', 'Banco BHD Leon S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '19268111', 'Banco Union', 'DOP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '19268111', 'Banco Union', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '32717311', 'Banreservas', 'DOP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '32717311', 'Banreservas', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '44622311', 'Asociacion La Nacional de A y P', 'DOP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '44622311', 'Asociacion La Nacional de A y P', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '53341611', 'Banco Popular Dominicano S.A.', 'DOP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('DO', 'C', '53341611', 'Banco Popular Dominicano S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('FJ', 'C', '84957011', 'Exchange World (Fiji) Pte Limited', 'FJD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('FJ', 'C', '85061811', 'Real Forex Proprietary (Fiji) Pte Limited', 'FJD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('FJ', 'C', '91229911', 'MH Money Express', 'FJD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('GT', 'C', '4194111', 'Banco Industrial S.A.', 'GTQ');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('GT', 'C', '16009', 'Banrural S.A. - Guatemala (TNWK)', 'GTQ');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('GT', 'C', '13609', 'Banco G & T Continental', 'GTQ');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('GT', 'C', '17741411', 'Banco Azteca Guatemala S.A.', 'GTQ');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('GT', 'C', '48632811', 'Farmacias Cruz Verde / Red Chapina', 'GTQ');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('GT', 'C', '53069111', 'BAM-Banco Agromercantil (Rchapina)', 'GTQ');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('GT', 'C', '77390311', 'Banco De Antigua - Red Chapina', 'GTQ');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('GT', 'C', '77390411', 'Banco De Credito - Red Chapina', 'GTQ');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '1453712', 'Banco De Occidente', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '6093311', 'Banco Promerica S.A. Honduras', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '6970411', 'Banco Ficohsa', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '18651611', 'Banco Azteca Honduras S.A.', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '21553811', 'Banco Atlantida S.A', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '37036111', 'Banrural S.A - Honduras (TNWK)', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '54585411', 'CACIL de R.L.', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '73349911', 'Banco Lafise Honduras S.A.', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '73349911', 'Banco Lafise Honduras S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '88900711', 'Banco Del Pais, S.A', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '91600211', 'Banco Davivienda Honduras S.A.', 'HNL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HN', 'C', '91600211', 'Banco Davivienda Honduras S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HU', 'C', '84592911', 'Hungarian Post (Eurogiro - Inpay AS)', 'HUF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HU', 'C', '99432611', 'Takarekbank Zrt.', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('HU', 'C', '99432611', 'Takarekbank Zrt.', 'HUF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '92291011', 'Anywhere Payout Indonesia - IDR', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '26635511', 'PT Bank Rakyat Indonesia', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '76776911', 'PT Pos Indonesia (Persero)', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '52643011', 'PT Bank Central Asia Tbk', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '52643011', 'PT Bank Central Asia Tbk', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '25007111', 'PT Bank Negara Indonesia Tbk', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '25007111', 'PT Bank Negara Indonesia Tbk', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '659112', 'PT Bank CIMB Niaga', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '35172155', 'PT Post Indonesia (Persero)', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '76776311', 'PT Pegadaian (Persero)', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('ID', 'C', '100778311', 'PT. Reyhan Putra Mandiri', 'IDR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('JM', 'C', '86063111', 'LASCO - Victoria Mutual and JMMB', 'JMD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('JP', 'C', '43956511', 'IME Unidos Ltd.', 'JPY');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('JP', 'C', '64579011', 'Unidos Ltd', 'JPY');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LA', 'C', '73376911', 'Saigon Thuong Tin Bank Lao Co. Ltd', 'LAK');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LA', 'C', '73376911', 'Saigon Thuong Tin Bank Lao Co. Ltd', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LB', 'C', '88164411', 'OTP SAL', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '6668514', 'CB Comertbank JSC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '6668514', 'CB Comertbank JSC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '17124411', 'JSCB Moldindconbank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '17124411', 'JSCB Moldindconbank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '18068311', 'EuroCreditBank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '18068311', 'EuroCreditBank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '34215611', 'FinComBank S.A.', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '34215611', 'FinComBank S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '60889411', 'AgroIndBank Moldova', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '60889411', 'AgroIndBank Moldova', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '71875611', 'Paynet Services LLC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '71875611', 'Paynet Services LLC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '73417011', 'BPAY LLC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '73417011', 'BPAY LLC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '84170411', 'Posta Moldovei', 'MDL');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '89078811', 'Anywhere Payout Moldova EUR USD', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MD', 'C', '89078811', 'Anywhere Payout Moldova EUR USD', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MN', 'C', '63225811', 'Sendmn NBFI LLC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MN', 'C', '63225811', 'Sendmn NBFI LLC', 'MNT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MN', 'C', '63225811', 'Sendmn NBFI LLC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MN', 'C', '73240211', 'Public Credit NBFI LLC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MN', 'C', '73240211', 'Public Credit NBFI LLC', 'MNT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MN', 'C', '73240211', 'Public Credit NBFI LLC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MN', 'C', '87766311', 'Mongolian Post (Eurogiro - Inpay As)', 'MNT');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '1065811', 'Bancomer', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '2567411', 'Empenos Del Sur S.A. De C.V. (Balsas)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '4772511', 'Bansefi / Banco del Bienestar', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '19384511', 'Telecom', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '21269711', 'Elektra', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '29624911', 'Banorte (Uniteller) - Testing', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '33260811', 'Nueva Wal-Mart de Mexico, S. de R.L. de C.V', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '35989511', 'Aifco', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '41925711', 'Inpamex', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '41926711', 'Farmapronto (Inpamex)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '41926811', 'Chedraui (Inpamex)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '41926811', 'Chedraui (Inpamex)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '46286111', 'Farmacias Guadalajara', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '52749711', 'Farmacias Del Ahorro', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '55031811', 'Farmacias Isseg (Inpamex)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '60579311', 'Fundacion Donde (Tuuxt Taakin)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '66216711', 'Tiendas del Sol (Datransfer S.A. De C.V.)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '66273411', 'Woolworth (Datransfer S.A. De C.V.)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '74856311', 'Envios Tlachichilco', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '84453611', 'OXXO', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '95275011', 'BanCoppel S.A. (Appriza Pay LLC)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('MX', 'C', '105377411', 'Chedraui  (Appriza Pay LLC)', 'MXN');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('NI', 'C', '6410511', 'Banpro (Banco De La Produccion Nicaragua)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('NI', 'C', '21235611', 'Banco Lafise Bancentro', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('NI', 'C', '53079111', 'Teledolar S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PA', 'C', '18651411', 'Banco Azteca Panama S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PA', 'C', '54352111', 'Master Money Transfer S.A', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '6372914', 'JS Bank', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '14032411', 'Allied Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '20351911', 'Meezan Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '22282011', 'National Bank Of Pakistan', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '22803711', 'MCB Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '35529411', 'Soneri Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '36539411', 'Bank Of Punjab', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '43949111', 'IME National Bank of Pakistan (NBP)', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '43953511', 'IME MCB Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '48304311', 'Bankislami Pakistan Limited ', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '48547711', 'IME JS Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '49306411', 'Bank Of Punjab - PRI', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '49762811', 'Habib Metropolitan Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '50483311', 'A A Exchange Company Private Ltd', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '51899911', 'Dollar East Exchange Company Private Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '52994311', 'Royal International Exchange Company (Pvt) Ltd', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '61396811', 'Wall Street Exchange Company (Pvt) Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '66527711', 'H&H Exchange Company Private Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '68184811', 'Anywhere Payout Pakistan', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '72366411', 'Link International Exchange Company Pvt Ltd', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '72859111', 'The Bank Of Khyber', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '74816711', 'Askari Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '76816311', 'NBP Exchange Company Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '77174811', 'Ravi Exchange Company (Private) Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '77187411', 'Paragon Exchange (Private) Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '79297411', 'FairDeal Exchange Company Private Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '79364911', 'Muhammadi Exchange Company (Pvt)Ltd', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '80075011', 'United Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '88956611', 'Sindh Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '94108911', 'IME Soneri Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '101011611', 'IME Askari Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PK', 'C', '103790211', 'Faysal Bank Limited', 'PKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '757912', 'Banco Familiar', 'PYG');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '757912', 'Banco Familiar', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '37111611', 'Pronet S.A.', 'PYG');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '53099511', 'FE Cambios S.A', 'PYG');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '53099511', 'FE Cambios S.A', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '60065511', 'Maxicambios SA', 'PYG');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '60065511', 'Maxicambios SA', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '62371211', 'UB S.A.', 'PYG');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PY', 'C', '62371211', 'UB S.A.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '47165211', 'Realtransfer - Instituiçao De Pagamento, S.A.', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '51858311', 'Perola Da India Artigos De Papelaria LDA', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '53299611', 'Waldemar Vieira Neto', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '54103311', 'MD Abdul Hakim Minhaj', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '54960311', 'Rinjin Travel Tours, Lda', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '57057711', 'Tej Paul Singh', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '57516311', 'Elizabeth Escalante Unipessoal LDA', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '58797611', 'Waseem Ashraf', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '58798011', 'Waldemar Vieira Neto', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '59550511', 'MD Abdul Hakim Minhaj', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '60639211', 'Cultura do Tabaco-Tabacaria,Unipessoal,LDA', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '61339211', 'MD Shekh Farid', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '63245411', 'Piotr Coltuc', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '63921311', 'Lucdeia LDA', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '67252911', 'Uni eventos, unipessoal LDA', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '68863111', 'Asmita Kadel', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '71899811', 'Dalbir Singh', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '71946611', 'Raj Kumar Tamang', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('PT', 'C', '72303711', 'Jagpreet Singh', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RO', 'C', '86908911', 'CN Posta Romana S.A.', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RO', 'C', '86908911', 'CN Posta Romana S.A.', 'RON');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RO', 'C', '18328511', 'CEC Bank/Transfer Rapid', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RO', 'C', '18328511', 'CEC Bank/Transfer Rapid', 'RON');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RO', 'C', '94006711', 'Speed Transfer Amanet', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RO', 'C', '94006711', 'Speed Transfer Amanet', 'RON');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RO', 'C', '97613711', 'Payout Romania EUR RON', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RO', 'C', '97613711', 'Payout Romania EUR RON', 'RON');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '1043211', 'Qiwi Bank JSC (Contact System)', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '1043211', 'Qiwi Bank JSC (Contact System)', 'RUB');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '1043211', 'Qiwi Bank JSC (Contact System)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '7884114', 'KoronaPay (CU Payment System)', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '7884114', 'KoronaPay (CU Payment System)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '50058411', 'Unistream Commercial Bank JSC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '50058411', 'Unistream Commercial Bank JSC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '79690211', 'VTB Bank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '79690211', 'VTB Bank', 'GBP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '79690211', 'VTB Bank', 'RUB');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('RU', 'C', '79690211', 'VTB Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '6246914', 'Commercial Bank of Ceylon PLC', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '7955114', 'Bank Of Ceylon', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '8023614', 'Seylan Bank', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '14556811', 'Sampath Bank Limited', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '17062511', 'Hatton National Bank PLC', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '52983611', 'Cargills Bank Ltd & Cargilis Food Stores', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '53069011', 'Any Bank Payout', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '66474111', 'Pan Asia Banking Corporation PLC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '66474111', 'Pan Asia Banking Corporation PLC', 'GBP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '66474111', 'Pan Asia Banking Corporation PLC', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '66474111', 'Pan Asia Banking Corporation PLC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '72517611', 'National Savings Bank', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '83637511', 'MMBL Money Transfer Private Limited', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('LK', 'C', '91677411', 'People''s Bank', 'LKR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CH', 'C', '1985314', 'Ria Geneve', 'CHF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CH', 'C', '5793914', 'Ria Lausanne', 'CHF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CH', 'C', '5794014', 'Ria Zürich', 'CHF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CH', 'C', '7533314', 'Ria Basel', 'CHF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CH', 'C', '34113411', 'Ria Genève II', 'CHF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CH', 'C', '53471611', 'Ria Biel', 'CHF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CH', 'C', '60803811', 'Ria Lugano', 'CHF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('CH', 'C', '68444311', 'RIA Renens', 'CHF');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('SR', 'C', '33627511', 'Stichting Surinaamse Volkscredietbank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('SR', 'C', '33627511', 'Stichting Surinaamse Volkscredietbank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('SR', 'C', '59884811', 'Southern Commercial Bank N.V.', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('SR', 'C', '59884811', 'Southern Commercial Bank N.V.', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('TN', 'C', '92415711', 'Anywhere Payout Tunisia', 'TND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('TN', 'C', '1740714', 'BH Bank ( Former Banque de L''Habitat)', 'TND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('TN', 'C', '106378511', 'Wifak Bank', 'TND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '84195911', 'Anywhere Payout Ukraine', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '84195911', 'Anywhere Payout Ukraine', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '73225211', 'Payout in UAH only - NovaPoshta', 'UAH');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '105316811', 'Save The Children', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '105316811', 'Save The Children', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '7924914', 'Credit Dnepr Bank PJSC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '7924914', 'Credit Dnepr Bank PJSC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20195611', 'Universal Bank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20195611', 'Universal Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20196311', 'Ukrgasbank JSB', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20196311', 'Ukrgasbank JSB', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20201211', 'Ukrainian Financial Group', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20201211', 'Ukrainian Financial Group', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20203111', 'Kredobank Ojsc', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20203111', 'Kredobank Ojsc', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20203711', 'State Savings Bank Of Ukraine JSC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20203711', 'State Savings Bank Of Ukraine JSC', 'UAH');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '20203711', 'State Savings Bank Of Ukraine JSC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '37583411', 'Privatbank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '37583411', 'Privatbank', 'UAH');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '37583411', 'Privatbank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '42658511', 'Bank Pivdennyi', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '42658511', 'Bank Pivdennyi', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '42969711', 'JSC Pravex Bank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '42969711', 'JSC Pravex Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '46551911', 'PJSC IBOX Bank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '46551911', 'PJSC IBOX Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '49376011', 'PJSC CB Globus', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '49376011', 'PJSC CB Globus', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '49411211', 'PJSC Bank Vostok', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '49411211', 'PJSC Bank Vostok', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '53517011', 'Accordbank CB PJSC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '53517011', 'Accordbank CB PJSC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '54247611', 'Ukr Post', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '54247611', 'Ukr Post', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '56204511', 'Industrial Bank PJSC JSCB', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '56204511', 'Industrial Bank PJSC JSCB', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '74448711', 'JSC Unex Bank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '74448711', 'JSC Unex Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '75549111', 'JSC RWS Bank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '75549111', 'JSC RWS Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '75810511', 'Jsc First Ukrainian International Bank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UA', 'C', '75810511', 'Jsc First Ukrainian International Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '75909611', 'Aloqabank JSC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '75953911', 'Qishloq Qurilish Bank JSCB', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '75953911', 'Qishloq Qurilish Bank JSCB', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '76988911', 'Microcreditbank JSCB', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '77169611', 'Uzbek Industrial and Construction Bank JSCB', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '77169611', 'Uzbek Industrial and Construction Bank JSCB', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '81402111', 'Agrobank JSCB', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '81402111', 'Agrobank JSCB', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '82962811', 'JSCMB Ipoteka bank', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '82962811', 'JSCMB Ipoteka bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '101893311', 'Bank Orient Finans PJSC', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('UZ', 'C', '101893311', 'Bank Orient Finans PJSC', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '73011411', 'Anywhere Payout VND', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '95470211', 'Anywhere Payout USD', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '48387311', 'Vietcombank (JSC Bank for Foreign Trade of Vietnam)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '48387311', 'Vietcombank (JSC Bank for Foreign Trade of Vietnam)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '4845411', 'VIB (Vietnam International Bank)', 'AUD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '4845411', 'VIB (Vietnam International Bank)', 'CAD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '4845411', 'VIB (Vietnam International Bank)', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '4845411', 'VIB (Vietnam International Bank)', 'GBP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '4845411', 'VIB (Vietnam International Bank)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '4845411', 'VIB (Vietnam International Bank)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '17924111', 'DongA (Dong A Commercial Joint Stock Bank)', 'AUD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '17924111', 'DongA (Dong A Commercial Joint Stock Bank)', 'CAD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '17924111', 'DongA (Dong A Commercial Joint Stock Bank)', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '17924111', 'DongA (Dong A Commercial Joint Stock Bank)', 'GBP');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '17924111', 'DongA (Dong A Commercial Joint Stock Bank)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '17924111', 'DongA (Dong A Commercial Joint Stock Bank)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '22720311', 'SacomBank (Sacombank Remittance Express Company)', 'EUR');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '22720311', 'SacomBank (Sacombank Remittance Express Company)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '22720311', 'SacomBank (Sacombank Remittance Express Company)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '49344011', 'HD Bank (Ho Chi Minh City Dev. JSC Bank)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '49344011', 'HD Bank (Ho Chi Minh City Dev. JSC Bank)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '59153711', 'Sacombank Other Banks', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '81687311', 'Military Commercial Joint Stock Bank (Mb) Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '81687311', 'Military Commercial Joint Stock Bank (Mb) Bank', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '81935311', 'Vietinbank', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '82014011', 'SCB (Sai Gon Joint Stock Commercial Bank)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '82014011', 'SCB (Sai Gon Joint Stock Commercial Bank)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '82036611', 'Exim Bank', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '82036611', 'Exim Bank', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '86980611', 'ACB (Asia Commercial Joint Stock Bank)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '86980611', 'ACB (Asia Commercial Joint Stock Bank)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '91933611', 'BIDV', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '91933611', 'BIDV', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '92079011', 'SeABank (Southeast Asia Commercial Joint Stock Bank)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '92079111', 'Post and Telecommunication Finance Company (PTF)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '93675111', 'MSB(Vietnam Maritime Commercial Join Stock Bank)', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '93675111', 'MSB(Vietnam Maritime Commercial Join Stock Bank)', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '97474311', 'Vietnam Bank For Agriculture And Rural Development ', 'USD');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VN', 'C', '97474311', 'Vietnam Bank For Agriculture And Rural Development ', 'VND');

insert into iftb_ria_agent_ccy_dtls (COUNTRY_CODE, INDICATOR, AGENT_ID, AGENT_NAME, CURRENCY)
values ('VI', 'C', '62228611', 'Sanchez Envios', 'USD');

prompt Done.
