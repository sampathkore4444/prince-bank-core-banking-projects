-- Create table
create table IFTB_RIA_ADDL_FIELDS
(
  trn_ref_no    VARCHAR2(16),
  field_name    VARCHAR2(255),
  field_value   VARCHAR2(255),
  txn_unique_no VARCHAR2(255)
)
/
alter table IFTB_RIA_ADDL_FIELDS add primary key (TRN_REF_NO, TXN_UNIQUE_NO, FIELD_NAME)
/
-- Create table
create table IFTB_RIA_AGENT_CCY_DTLS
(
  country_code VARCHAR2(100),
  indicator    CHAR(1),
  agent_id     VARCHAR2(100),
  agent_name   VARCHAR2(255),
  currency     VARCHAR2(100)
)
/
alter table IFTB_RIA_AGENT_CCY_DTLS add primary key (AGENT_ID, AGENT_NAME, CURRENCY)
/
-- Create table
create table IFTB_RIA_AGENT_CCY_DTLS1
(
  agent_id   VARCHAR2(100),
  agent_name VARCHAR2(255),
  currency   VARCHAR2(100)
)
/
-- Create table
create table IFTB_RIA_AGENT_DTLS
(
  correspondent_id   VARCHAR2(2000),
  correspondent_name VARCHAR2(2000),
  country_code       VARCHAR2(2)
)
/
alter table IFTB_RIA_AGENT_DTLS add primary key (CORRESPONDENT_ID, COUNTRY_CODE)
/
-- Create table
create table IFTB_RIA_AGENT_DTLS1
(
  correspondent_id   VARCHAR2(2000),
  correspondent_name VARCHAR2(2000)
)
/
-- Create table
create table IFTB_RIA_BANK_DTLS
(
  bank_id      VARCHAR2(2000),
  bank_name    VARCHAR2(2000),
  country_code VARCHAR2(2)
)
/
alter table IFTB_RIA_BANK_DTLS add primary key (BANK_ID, COUNTRY_CODE)
/
-- Create table
create table IFTB_RIA_BANK_DTLS1
(
  bank_id   VARCHAR2(2000),
  bank_name VARCHAR2(2000)
)
/
-- Create table
create table IFTB_RIA_CCY_DTLS
(
  country_code VARCHAR2(100),
  indicator    CHAR(1),
  currency     VARCHAR2(100)
)
/
alter table IFTB_RIA_CCY_DTLS add primary key (COUNTRY_CODE, INDICATOR, CURRENCY)
/
-- Create table
create table IFTB_RIA_COUNTRY_CURRENCIES
(
  country_code VARCHAR2(2),
  currency     VARCHAR2(3),
  country_name VARCHAR2(255)
)
/
alter table IFTB_RIA_COUNTRY_CURRENCIES add primary key (COUNTRY_CODE, CURRENCY)
/
-- Create table
create table IFTB_RIA_MASTER
(
  trn_ref_no          VARCHAR2(16),
  txn_ccy             VARCHAR2(3),
  txn_amount          NUMBER(22,3),
  dr_acc_no           VARCHAR2(20),
  dr_acc_ccy          VARCHAR2(3),
  dr_amount           NUMBER(22,3),
  cr_acc_no           VARCHAR2(20),
  cr_acc_ccy          VARCHAR2(3),
  cr_amount           NUMBER(22,3),
  paymnt_date         DATE,
  exch_rate           NUMBER(24,12),
  narrative           VARCHAR2(250),
  record_stat         CHAR(1),
  auth_stat           CHAR(1),
  mod_no              NUMBER(4),
  maker_id            VARCHAR2(12),
  maker_dt_stamp      DATE,
  checker_id          VARCHAR2(12),
  checker_dt_stamp    DATE,
  once_auth           CHAR(1),
  txn_unique_no       VARCHAR2(105),
  payin_corr_id       VARCHAR2(25),
  sending_corr_id     VARCHAR2(25),
  delivery_method     VARCHAR2(25),
  ben_country         VARCHAR2(2),
  ben_cnt_ccy         VARCHAR2(3),
  ben_firstname       VARCHAR2(105),
  ben_lastname        VARCHAR2(105),
  ben_city            VARCHAR2(255),
  ben_state           VARCHAR2(255),
  ria_reference_no    VARCHAR2(105),
  order_no            VARCHAR2(105),
  ria_order_no        VARCHAR2(105),
  ria_pin             VARCHAR2(105),
  ria_pay_status      VARCHAR2(255),
  bank_id             VARCHAR2(100),
  bank_account_no     VARCHAR2(105),
  bank_account_type   VARCHAR2(255),
  dr_acc_name         VARCHAR2(255),
  tot_chg_amt         NUMBER(22,3),
  net_txn_amt         NUMBER(22,3),
  ria_receiving_amt   NUMBER(22,3),
  ria_exchange_rate   NUMBER(24,12),
  purpose_of_transfer VARCHAR2(255)
)
/
alter table IFTB_RIA_MASTER add primary key (TRN_REF_NO)
/
-- Create table
create table IFTB_RIA_ONLY_CCY
(
  currency VARCHAR2(10)
)
/
-- Create table
create table IFTB_RIA_OUT_CHARGE
(
  trn_ref_no  VARCHAR2(20),
  chg_srno    NUMBER(1),
  chg1_desc   VARCHAR2(255),
  chg1_waiver VARCHAR2(1),
  chg1_amt    NUMBER(22,3),
  chg1_ccy    VARCHAR2(3),
  lcy_chg1    NUMBER(22,3),
  fcy_chg1    NUMBER(22,3),
  chg1_gl     VARCHAR2(20),
  chg2_desc   VARCHAR2(255),
  chg2_waiver VARCHAR2(1),
  chg2_amt    NUMBER(22,3),
  chg2_ccy    VARCHAR2(3),
  lcy_chg2    NUMBER(22,3),
  fcy_chg2    NUMBER(22,3),
  chg2_gl     VARCHAR2(20),
  chg3_desc   VARCHAR2(255),
  chg3_waiver VARCHAR2(1),
  chg3_amt    NUMBER(22,3),
  chg3_ccy    VARCHAR2(3),
  lcy_chg3    NUMBER(22,3),
  fcy_chg3    NUMBER(22,3),
  chg3_gl     VARCHAR2(20),
  netting_req CHAR(1),
  xrate       NUMBER(22,10),
  txn_code    VARCHAR2(3),
  chg1_type   VARCHAR2(1),
  chg1_in_txn NUMBER(22,3),
  chg1_in_acc NUMBER(22,3),
  chg2_type   VARCHAR2(1),
  chg2_in_txn NUMBER(22,3),
  chg2_in_acc NUMBER(22,3),
  chg3_type   VARCHAR2(1),
  chg3_in_txn NUMBER(22,3),
  chg3_in_acc NUMBER(22,3),
  oth_ccy     VARCHAR2(3),
  txn_xrate   NUMBER(22,10),
  acc_xrate   NUMBER(22,10)
)
/
alter table IFTB_RIA_OUT_CHARGE add primary key (TRN_REF_NO, CHG_SRNO)
/
-- Create table
create table IFTB_RIA_WS_OUT_LOG
(
  seq_no        VARCHAR2(105) not null,
  trn_ref_no    VARCHAR2(16),
  invoke_date   TIMESTAMP(6),
  req_type      VARCHAR2(25),
  req_msg       CLOB,
  res_msg       CLOB,
  txn_unique_no VARCHAR2(105),
  status        CHAR(1),
  addl_info     VARCHAR2(105)
)
/
alter table IFTB_RIA_WS_OUT_LOG add primary key (SEQ_NO)
/
-- Create table
create table IFTB_RIA_WS_IN_LOG
(
  seq_no        VARCHAR2(105) not null,
  trn_ref_no    VARCHAR2(16),
  invoke_date   TIMESTAMP(6),
  ria_pin       VARCHAR2(20),
  req_type      VARCHAR2(25),
  req_msg       CLOB,
  res_msg       CLOB,
  txn_unique_no VARCHAR2(105),
  status        CHAR(1),
  addl_info     VARCHAR2(105)
)
/
alter table IFTB_RIA_WS_IN_LOG add primary key (SEQ_NO)
/