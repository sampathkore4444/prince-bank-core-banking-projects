CREATE OR REPLACE PACKAGE BODY cypks_cydratee_kernel AS

  PRM_EX_RATE_COPY VARCHAR2(1);
  PRM_HO_ACTIVITY  SMTBS_MENU.HO_FUNCTION%TYPE;
  G_CNT            NUMBER;

  TYPE TY_G_RATE IS TABLE OF CYTM_RATES.RATE_TYPE%TYPE INDEX BY PLS_INTEGER;
  G_RATE_TYPE TY_G_RATE;

  PROCEDURE PR_CHECK_FOR_CHANGE(P_WRK_CYDRATEE  IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                P_PREV_CYDRATEE IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE);

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'cypks_cydratee_Kernel ==>' || P_MSG;
    DEBUG.PR_DEBUG('CY', L_MSG);
  END DBG;

  FUNCTION FN_GET_PREV_DATA(P_SOURCE        IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                            P_ACTION_CODE   IN VARCHAR2,
                            P_FUNCTION_ID   IN VARCHAR2,
                            P_CYDRATEE      IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                            P_PREV_CYDRATEE IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                            P_ERR_CODE      IN OUT VARCHAR2,
                            P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');
  END PR_SKIP_HANDLER;
  FUNCTION FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                        P_CYDRATEE         IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In Fn_Post_Build_type_structure..');

    DBG('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of cypks_cydratee_Kernel.Fn_Post_Build_type_structure ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_BUILD_TYPE_STRUCTURE;

  FUNCTION FN_RATE_SERIAL(P_ACTION_CODE VARCHAR2,
                          P_CCY1        IN VARCHAR2,
                          P_CCY2        IN VARCHAR2,
                          P_RATE_TYPE   IN VARCHAR2,
                          P_RATE_DATE   IN VARCHAR2) RETURN NUMBER IS
    L_MAX_SERIAL NUMBER(4) := 0;

  BEGIN
    DBG('Inside FN_RATE_SERIAL');
    DBG('Parameter Action code ' || P_ACTION_CODE);
    DBG('Currency 1 :' || P_CCY1);
    DBG('Currency2  :' || P_CCY2);
    DBG('Rate Date  :' || P_RATE_DATE);
    DBG('Rate type  :' || P_RATE_TYPE);
    DBG('l_max_serial  :' || L_MAX_SERIAL);

    SELECT MAX(RATE_SERIAL)
      INTO L_MAX_SERIAL
      FROM CYTM_RATES
     WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
       AND CCY1 = P_CCY1
       AND CCY2 = P_CCY2
       AND RATE_TYPE = P_RATE_TYPE
       AND RATE_DATE = P_RATE_DATE;

    DBG('Max Serial : ' || L_MAX_SERIAL);
    IF L_MAX_SERIAL > 0 THEN
      L_MAX_SERIAL := L_MAX_SERIAL + 1;
    ELSIF L_MAX_SERIAL = 0 OR L_MAX_SERIAL IS NULL THEN
      L_MAX_SERIAL := 1;
    END IF;
    DBG('AFTER FINAL l_max_serial  :  ' || L_MAX_SERIAL);
    RETURN L_MAX_SERIAL;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('Max Serial is not found so intialize ');
      L_MAX_SERIAL := 1;
      RETURN L_MAX_SERIAL;
  END FN_RATE_SERIAL;

  FUNCTION FN_CALCULATE(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                        P_ACTION      IN VARCHAR2,
                        P_CYTMS_RATES IN OUT CYTM_RATES%ROWTYPE,
                        P_ERR_CODE    IN OUT VARCHAR2,
                        P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN

   IS
    L_QUOTATION         CYTMS_CCY_PAIR_DEFN.QUOTATION%TYPE;
    L_SPREAD_DEFN       CYTMS_CCY_PAIR_DEFN.SPREAD_DEFN%TYPE;
    L_POINTS_MULTIPLIER CYTMS_CCY_PAIR_DEFN.POINTS_MULTIPLIER%TYPE;
    L_EFF_BUY_SPREAD    CYTMS_RATES.BUY_SPREAD%TYPE;
    L_EFF_SALE_SPREAD   CYTMS_RATES.SALE_SPREAD%TYPE;
  BEGIN
    DBG('In Fn_Calculate');
    BEGIN
      SELECT QUOTATION, SPREAD_DEFN, POINTS_MULTIPLIER
        INTO L_QUOTATION, L_SPREAD_DEFN, L_POINTS_MULTIPLIER
        FROM CYTMS_CCY_PAIR_DEFN
       WHERE CCY1 = P_CYTMS_RATES.CCY1
         AND CCY2 = P_CYTMS_RATES.CCY2;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Exception raised while getting the Spread and quotation Detials ');
        DBG(SQLERRM);
        RETURN FALSE;
    END;
    IF P_ACTION = 'R' THEN
      DBG('Calculating Rates...');
      IF L_SPREAD_DEFN = '.' THEN
        L_EFF_BUY_SPREAD  := P_CYTMS_RATES.BUY_SPREAD * L_POINTS_MULTIPLIER;
        L_EFF_SALE_SPREAD := P_CYTMS_RATES.SALE_SPREAD *
                             L_POINTS_MULTIPLIER;
      ELSIF L_SPREAD_DEFN = '%' THEN
        L_EFF_BUY_SPREAD  := (P_CYTMS_RATES.BUY_SPREAD *
                             P_CYTMS_RATES.MID_RATE) / 100;
        L_EFF_SALE_SPREAD := (P_CYTMS_RATES.SALE_SPREAD *
                             P_CYTMS_RATES.MID_RATE) / 100;
      END IF;
      IF L_QUOTATION = 'D' THEN
        P_CYTMS_RATES.BUY_RATE      := P_CYTMS_RATES.MID_RATE -
                                       L_EFF_BUY_SPREAD;
        P_CYTMS_RATES.SALE_RATE     := P_CYTMS_RATES.MID_RATE +
                                       L_EFF_SALE_SPREAD;
        P_CYTMS_RATES.INT_AUTH_STAT := 'U';
      ELSIF L_QUOTATION = 'I' THEN
        P_CYTMS_RATES.BUY_RATE      := P_CYTMS_RATES.MID_RATE +
                                       L_EFF_BUY_SPREAD;
        P_CYTMS_RATES.SALE_RATE     := P_CYTMS_RATES.MID_RATE -
                                       L_EFF_SALE_SPREAD;
        P_CYTMS_RATES.INT_AUTH_STAT := 'U';
      END IF;
      P_CYTMS_RATES.UNAUTH_MID_RATE    := P_CYTMS_RATES.MID_RATE;
      P_CYTMS_RATES.UNAUTH_BUY_SPREAD  := P_CYTMS_RATES.BUY_SPREAD;
      P_CYTMS_RATES.UNAUTH_SALE_SPREAD := P_CYTMS_RATES.SALE_SPREAD;
      P_CYTMS_RATES.UNAUTH_BUY_RATE    := P_CYTMS_RATES.BUY_RATE;
      P_CYTMS_RATES.UNAUTH_SALE_RATE   := P_CYTMS_RATES.SALE_RATE;
    ELSIF P_ACTION = 'S' THEN
      DBG('Calulating Spread...');
      IF (NVL(P_CYTMS_RATES.MID_RATE, 0) = 0) THEN
        P_CYTMS_RATES.MID_RATE := (P_CYTMS_RATES.SALE_RATE +
                                  P_CYTMS_RATES.BUY_RATE) / 2;
      END IF;
      IF L_QUOTATION = 'D' THEN
        L_EFF_BUY_SPREAD  := P_CYTMS_RATES.MID_RATE -
                             P_CYTMS_RATES.BUY_RATE;
        L_EFF_SALE_SPREAD := P_CYTMS_RATES.SALE_RATE -
                             P_CYTMS_RATES.MID_RATE;
      ELSIF L_QUOTATION = 'I' THEN
        L_EFF_BUY_SPREAD  := P_CYTMS_RATES.BUY_RATE -
                             P_CYTMS_RATES.MID_RATE;
        L_EFF_SALE_SPREAD := P_CYTMS_RATES.MID_RATE -
                             P_CYTMS_RATES.SALE_RATE;
      END IF;
      IF L_SPREAD_DEFN = '.' THEN
        P_CYTMS_RATES.BUY_SPREAD    := L_EFF_BUY_SPREAD /
                                       L_POINTS_MULTIPLIER;
        P_CYTMS_RATES.SALE_SPREAD   := L_EFF_SALE_SPREAD /
                                       L_POINTS_MULTIPLIER;
        P_CYTMS_RATES.INT_AUTH_STAT := 'U';
      ELSIF L_SPREAD_DEFN = '%' THEN
        P_CYTMS_RATES.BUY_SPREAD    := L_EFF_BUY_SPREAD * 100 /
                                       P_CYTMS_RATES.MID_RATE;
        P_CYTMS_RATES.SALE_SPREAD   := L_EFF_SALE_SPREAD * 100 /
                                       P_CYTMS_RATES.MID_RATE;
        P_CYTMS_RATES.INT_AUTH_STAT := 'U';
      END IF;
      P_CYTMS_RATES.UNAUTH_MID_RATE    := P_CYTMS_RATES.MID_RATE;
      P_CYTMS_RATES.UNAUTH_BUY_SPREAD  := P_CYTMS_RATES.BUY_SPREAD;
      P_CYTMS_RATES.UNAUTH_SALE_SPREAD := P_CYTMS_RATES.SALE_SPREAD;
      P_CYTMS_RATES.UNAUTH_BUY_RATE    := P_CYTMS_RATES.BUY_RATE;
      P_CYTMS_RATES.UNAUTH_SALE_RATE   := P_CYTMS_RATES.SALE_RATE;

    END IF;
    DBG('Returning Success from Fn_Calculate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of cypks_cydratee_kernel.Fn_Calculate..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_CALCULATE;

  FUNCTION FN_ENRICH_RATES(P_SOURCE           IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_PREV_CYDRATEE    IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                           P_WRK_CYDRATEE     IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN

   IS
    L_NEW_REC_WRK BOOLEAN := TRUE;
  BEGIN
    DBG('In Fn_Enrich_Rates');
    DBG('Count inside Fn_Enrich_Rates:' ||
        P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT);
    IF P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN
      FOR L_WRK_INDEX IN P_WRK_CYDRATEE.V_CYTMS_RATES.FIRST .. P_WRK_CYDRATEE.V_CYTMS_RATES.LAST LOOP

        DBG('Previous Count::' || P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT);
        IF P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT =
           P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT THEN

          DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Wrk_Index).rate_type::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .RATE_TYPE);
          DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Wrk_Index).unauth_mid_rate::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .UNAUTH_MID_RATE);
          DBG('p_prev_cydratee.v_Cytms_Rates(l_Wrk_Index).mid_rate::' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .MID_RATE);
          DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Wrk_Index).unauth_buy_spread::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .UNAUTH_BUY_SPREAD);
          DBG('p_prev_cydratee.v_Cytms_Rates(l_Wrk_Index).buy_spread::' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .BUY_SPREAD);
          DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Wrk_Index).unauth_sale_spread::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .UNAUTH_SALE_SPREAD);
          DBG('p_prev_cydratee.v_Cytms_Rates(l_Wrk_Index).sale_spread::' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .SALE_SPREAD);
          DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Wrk_Index).unauth_buy_rate::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .UNAUTH_BUY_RATE);
          DBG('p_prev_cydratee.v_Cytms_Rates(l_Wrk_Index).buy_rate::' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .BUY_RATE);
          DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Wrk_Index).unauth_sale_rate::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .UNAUTH_SALE_RATE);
          DBG('p_prev_cydratee.v_Cytms_Rates(l_Wrk_Index).sale_rate::' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
              .SALE_RATE);

          IF (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).MID_RATE, '0') <>
             NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).MID_RATE, '0')) OR
             (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).BUY_SPREAD, '0') <>
             NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).BUY_SPREAD,
                  '0')) OR
             (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).SALE_SPREAD,
                  '0') <>
             NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).SALE_SPREAD,
                  '0')) OR
             (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).BUY_RATE, '0') <>
             NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).BUY_RATE, '0')) OR
             (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).SALE_RATE, '0') <>
             NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).SALE_RATE, '0')) THEN

            DBG('Something has been changed,so updating the rate date');
            DBG('Changed Rate::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                .RATE_TYPE);
            P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).RATE_DATE := GLOBAL.APPLICATION_DATE;
            DBG('p_Wrk_cydratee.v_cytms_rates(l_Wrk_Index).Rate_Date = ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                .RATE_DATE);

          END IF;
        END IF;
        L_NEW_REC_WRK := TRUE;
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).MID_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                  .MID_RATE,
                                                                  0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).BUY_SPREAD := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                    .BUY_SPREAD,
                                                                    0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).SALE_SPREAD := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                     .SALE_SPREAD,
                                                                     0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).BUY_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                  .BUY_RATE,
                                                                  0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).SALE_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                   .SALE_RATE,
                                                                   0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).UNAUTH_MID_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                         .UNAUTH_MID_RATE,
                                                                         0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).UNAUTH_BUY_SPREAD := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                           .UNAUTH_BUY_SPREAD,
                                                                           0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).UNAUTH_SALE_SPREAD := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                            .UNAUTH_SALE_SPREAD,
                                                                            0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).UNAUTH_BUY_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                         .UNAUTH_BUY_RATE,
                                                                         0);
        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).UNAUTH_SALE_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                                                          .UNAUTH_SALE_RATE,
                                                                          0);

        DBG('Check Whether is Spread is Changed ..');

        DBG('Unath mid rate: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .UNAUTH_MID_RATE || ' Mid rate: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .MID_RATE);
        DBG('Unath buy sprd: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .UNAUTH_BUY_SPREAD || ' Buy sprd: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .BUY_SPREAD);
        DBG('Unath sale sprd: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .UNAUTH_SALE_SPREAD || ' sale sprd: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .SALE_SPREAD);
        DBG('Unath buy rate: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .UNAUTH_BUY_RATE || ' Buy rate: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .BUY_RATE);
        DBG('Unath sale rate: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .UNAUTH_SALE_RATE || ' Sale rate: ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
            .SALE_RATE);

        IF P_ACTION_CODE = 'DEFAULT' OR P_SOURCE <> 'FLEXCUBE' THEN
          DBG('p_Prev_cydratee.v_cytms_rates.COUNT' ||
              P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT);

          IF P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN

            DBG('MODIFICATION INCREMENT');

            FOR L_PREV_INDEX IN P_PREV_CYDRATEE.V_CYTMS_RATES.FIRST .. P_PREV_CYDRATEE.V_CYTMS_RATES.LAST LOOP
              DBG('prev::' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                  .RATE_TYPE);
              DBG('WORK::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                  .RATE_TYPE);
              IF (P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX).RATE_TYPE = P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                 .RATE_TYPE) THEN
                L_NEW_REC_WRK := FALSE;
                DBG('PREVIOUS' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                    .INT_AUTH_STAT);
                DBG('current' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                    .INT_AUTH_STAT);

                IF P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                 .INT_AUTH_STAT = 'U' THEN

                  IF P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)

                   .UNAUTH_MID_RATE <> P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                     .MID_RATE OR P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                     .UNAUTH_BUY_SPREAD <> P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                     .BUY_SPREAD OR P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                     .UNAUTH_SALE_SPREAD <> P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                     .SALE_SPREAD THEN

                    DBG('Spread is Got Changed..Calculate Rate');
                    IF NOT FN_CALCULATE(P_SOURCE,
                                        'R',
                                        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX),
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
                      DBG('Rate Calculation failed');
                      RETURN FALSE;
                    END IF;
                  END IF;
                ELSE
                  DBG('MODIFICATION POST AUTHORIZATION');

                  DBG('p_Prev_cydratee.v_cytms_rates(l_prev_Index).Buy_Rate>>' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                      .BUY_RATE);
                  DBG('p_Wrk_cydratee.v_cytms_rates(l_Wrk_Index).Buy_Rate>>' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                      .BUY_RATE);
                  DBG('p_Wrk_cydratee.v_cytms_rates(l_Wrk_Index).Sale_Rate>>' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                      .SALE_RATE);
                  DBG('p_Prev_cydratee.v_cytms_rates(l_prev_Index).Sale_Rate>>' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                      .SALE_RATE);
                  DBG('p_Prev_cydratee.v_cytms_rates(l_prev_Index).Mid_Rate>>' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                      .MID_RATE);
                  DBG('p_Wrk_cydratee.v_cytms_rates(l_Wrk_Index).Mid_Rate>>' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                      .MID_RATE);
                  DBG('p_Prev_cydratee.v_cytms_rates(l_prev_Index).Buy_Spread>>' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                      .BUY_SPREAD);
                  DBG('p_Wrk_cydratee.v_cytms_rates(l_Wrk_Index).Buy_Spread>>' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                      .BUY_SPREAD);
                  DBG('p_Prev_cydratee.v_cytms_rates(l_prev_Index).Sale_Spread>>' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                      .SALE_SPREAD);
                  DBG('p_Wrk_cydratee.v_cytms_rates(l_Wrk_Index).Sale_Spread>>' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                      .SALE_SPREAD);
                  DBG('l_Wrk_Index>>' || L_WRK_INDEX);
                  DBG('l_prev_Index>>' || L_PREV_INDEX);
                  IF NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                         .MID_RATE,
                         0) <>
                     NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).MID_RATE,
                         0) OR
                     NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                         .BUY_SPREAD,
                         0) <> NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                   .BUY_SPREAD,
                                   0) OR
                     NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                         .SALE_SPREAD,
                         0) <> NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                   .SALE_SPREAD,
                                   0) THEN
                    DBG('Spread is Got Changed..Calculate Rate');
                    IF NOT FN_CALCULATE(P_SOURCE,
                                        'R',
                                        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX),
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
                      DBG('Rate Calculation failed');
                      RETURN FALSE;
                    END IF;
                  ELSIF (NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                             .BUY_RATE,
                             0) <> P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                        .BUY_RATE AND NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                          .SALE_RATE,
                                          0) <> 0) OR
                        (NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_PREV_INDEX)
                             .SALE_RATE,
                             0) <> P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                        .SALE_RATE AND NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                                           .BUY_RATE,
                                           0) <> 0) THEN
                    DBG('Rate is Got Changed..Calculate Spread');
                    IF NOT FN_CALCULATE(P_SOURCE,
                                        'S',
                                        P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX),
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
                      DBG('Rate Calculation failed');
                      RETURN FALSE;
                    END IF;

                  END IF;

                END IF;

              END IF;

            END LOOP;
          END IF;
          IF L_NEW_REC_WRK THEN
            DBG('new additon');

            DBG('New Rate::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                .RATE_TYPE);
            P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).RATE_DATE := GLOBAL.APPLICATION_DATE;
            DBG('p_Wrk_cydratee.v_cytms_rates(l_Wrk_Index).Rate_Date = ' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
                .RATE_DATE);

            IF P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX).MID_RATE <> 0 OR P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
               .BUY_SPREAD <> 0 OR P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX)
               .SALE_SPREAD <> 0 THEN
              DBG('Spread is Got Changed..Calculate Rate');
              IF NOT FN_CALCULATE(P_SOURCE,
                                  'R',
                                  P_WRK_CYDRATEE.V_CYTMS_RATES(L_WRK_INDEX),
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
                DBG('Rate Calculation failed');
                RETURN FALSE;
              END IF;
            END IF;

          END IF;
        END IF;

      END LOOP;
    END IF;

    DBG('Returning Success from Fn_Enrich_Rates');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of cypks_fcj_cydrates_addon.Fn_Enrich_Rates ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_ENRICH_RATES;

  PROCEDURE PR_CHECK_FOR_CHANGE(P_WRK_CYDRATEE  IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                P_PREV_CYDRATEE IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE) IS
    L_WRK_COUNT  NUMBER;
    L_PREV_COUNT NUMBER;
    L_REC_FOUND  BOOLEAN;
    L_INDEX1     NUMBER;

  BEGIN
    DBG('fn_check_for_change begins');
    DBG('i am here1');
    L_WRK_COUNT  := P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT;
    L_PREV_COUNT := P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT;
    DBG('l_Wrk_Count' || L_WRK_COUNT);
    DBG('l_Prev_Count' || L_PREV_COUNT);

    IF L_WRK_COUNT > 0 THEN
      DBG('i am here2');

      IF L_PREV_COUNT = 0 THEN
        DBG('for first time rate save');
        FOR L_INDEX1 IN P_WRK_CYDRATEE.V_CYTMS_RATES.FIRST .. P_WRK_CYDRATEE.V_CYTMS_RATES.LAST LOOP
          DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Index1).Rate_TYPE' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
              .RATE_TYPE);
          P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_DATE := GLOBAL.APPLICATION_DATE;
          P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_SERIAL := 1;
        END LOOP;
      END IF;

      L_REC_FOUND := FALSE;
      DBG('p_prev_cydratee.v_Cytms_Rates_master.auth_stat' ||
          P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER.AUTH_STAT);
      DBG('l_Prev_Count' || L_PREV_COUNT);
      IF NVL(P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER.AUTH_STAT, '~') <> 'A' THEN
        IF L_PREV_COUNT > 0 THEN
          DBG('i am here3');
          FOR L_INDEX1 IN P_PREV_CYDRATEE.V_CYTMS_RATES.FIRST .. P_PREV_CYDRATEE.V_CYTMS_RATES.LAST LOOP
            DBG('p_prev_cydratee.v_Cytms_Rates.auth_stat' ||
                P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER.AUTH_STAT);
            IF (((NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).UNAUTH_MID_RATE,
                      '0') <> NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                     .UNAUTH_MID_RATE,
                                     '0')) OR
               (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                      .UNAUTH_BUY_SPREAD,
                      '0') <> NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                     .UNAUTH_BUY_SPREAD,
                                     '0')) OR
               (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                      .UNAUTH_SALE_SPREAD,
                      '0') <> NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                     .UNAUTH_SALE_SPREAD,
                                     '0')) OR
               (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).UNAUTH_BUY_RATE,
                      '0') <> NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                     .UNAUTH_BUY_RATE,
                                     '0')) OR
               (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                      .UNAUTH_SALE_RATE,
                      '0') <> NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                     .UNAUTH_SALE_RATE,
                                     '0')))) THEN
              DBG('Record Has been Found.Update Case..');
              L_REC_FOUND := TRUE;
              DBG('i am here 4');

              G_RATE_TYPE(L_INDEX1) := P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                       .RATE_TYPE;
              DBG('rate type G_RATE_TYPE(l_Index1)' ||
                  G_RATE_TYPE(L_INDEX1));

              IF P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
               .RATE_DATE <> GLOBAL.APPLICATION_DATE THEN
                DBG('i am if of for new');
                P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_DATE := GLOBAL.APPLICATION_DATE;
                P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_SERIAL := 1;

              ELSE
                DBG('serial incremented here');
                P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_SERIAL := P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                                                      .RATE_SERIAL + 1;
                DBG('serial here::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                    .RATE_SERIAL);
              END IF;

            END IF;
          END LOOP;

        END IF;
      ELSE
        IF L_PREV_COUNT > 0 THEN
          DBG('i am here3 or else');
          DBG('p_prev_cydratee.v_Cytms_Rates.count' ||
              P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT);
          FOR L_INDEX1 IN P_PREV_CYDRATEE.V_CYTMS_RATES.FIRST .. P_PREV_CYDRATEE.V_CYTMS_RATES.LAST LOOP
            DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Index1).rate_type' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .RATE_TYPE);
            DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Index1).unauth_mid_rate' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .UNAUTH_MID_RATE);
            DBG('p_prev_cydratee.v_Cytms_Rates(l_Index1).mid_rate' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .MID_RATE);
            DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Index1).unauth_buy_spread' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .UNAUTH_BUY_SPREAD);
            DBG('p_prev_cydratee.v_Cytms_Rates(l_Index1).buy_spread' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .BUY_SPREAD);
            DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Index1).unauth_sale_spread' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .UNAUTH_SALE_SPREAD);
            DBG('p_prev_cydratee.v_Cytms_Rates(l_Index1).sale_spread' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .SALE_SPREAD);
            DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Index1).unauth_buy_rate' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .UNAUTH_BUY_RATE);
            DBG('p_prev_cydratee.v_Cytms_Rates(l_Index1).buy_rate' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .BUY_RATE);
            DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Index1).unauth_sale_rate' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .UNAUTH_SALE_RATE);
            DBG('p_prev_cydratee.v_Cytms_Rates(l_Index1).sale_rate' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                .SALE_RATE);

            IF ((P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
               .UNAUTH_MID_RATE <> 0 OR P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
               .UNAUTH_BUY_SPREAD <> 0 OR P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
               .UNAUTH_SALE_SPREAD <> 0 OR P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
               .UNAUTH_BUY_RATE <> 0 OR P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
               .UNAUTH_SALE_RATE <> 0) AND
               ((NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).UNAUTH_MID_RATE,
                      '0') <>
               NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1).MID_RATE, '0')) OR
               (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                      .UNAUTH_BUY_SPREAD,
                      '0') <>
               NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1).BUY_SPREAD,
                      '0')) OR
               (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                      .UNAUTH_SALE_SPREAD,
                      '0') <>
               NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1).SALE_SPREAD,
                      '0')) OR
               (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).UNAUTH_BUY_RATE,
                      '0') <>
               NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1).BUY_RATE, '0')) OR
               (NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                      .UNAUTH_SALE_RATE,
                      '0') <>
               NVL(P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1).SALE_RATE,
                      '0')))) THEN

              DBG('else case if record is auth ');
              L_REC_FOUND := TRUE;
              DBG('i am here 4 of else');

              G_RATE_TYPE(L_INDEX1) := P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                       .RATE_TYPE;
              DBG('changed rate' || G_RATE_TYPE(L_INDEX1));

              IF P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
               .RATE_DATE <> GLOBAL.APPLICATION_DATE THEN
                DBG('rate serial:' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                    .RATE_SERIAL);
                DBG('rate date::' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                    .RATE_DATE);
                DBG('i am if of serial');
                P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_DATE := GLOBAL.APPLICATION_DATE;
                P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_SERIAL := 1;

              ELSE
                DBG('i am else of serial');
                DBG('serial can be ncremented here also');

                DBG('p_Wrk_cydratee.v_Cytms_Rates(l_Index1).Rate_date' || P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                    .RATE_DATE || 'after eod');
                IF P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_DATE <> P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                   .RATE_DATE THEN
                  DBG('p_prev_cydratee.v_Cytms_Rates(l_Index1).Rate_date' || P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                      .RATE_DATE);
                  P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_SERIAL := 1;
                ELSE
                  DBG('rate is being incremented');

                  P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1).RATE_SERIAL := P_WRK_CYDRATEE.V_CYTMS_RATES(L_INDEX1)
                                                                        .RATE_SERIAL + 1;

                END IF;

              END IF;

            END IF;
          END LOOP;
        END IF;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END;

  FUNCTION FN_PRE_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CHILD_FUNCTION   IN VARCHAR2,
                                  P_CYDRATEE         IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    DBG('In Fn_Pre_Check_Mandatory');
    P_CYDRATEE.V_CYTMS_RATES_MASTER.BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
    IF P_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN
      FOR I IN P_CYDRATEE.V_CYTMS_RATES.FIRST .. P_CYDRATEE.V_CYTMS_RATES.LAST LOOP
        P_CYDRATEE.V_CYTMS_RATES(I).BRANCH_CODE := P_CYDRATEE.V_CYTMS_RATES_MASTER.BRANCH_CODE;
      END LOOP;
    END IF;

    BEGIN
      SELECT PARAM_VAL
        INTO PRM_EX_RATE_COPY
        FROM CSTBS_PARAM
       WHERE PARAM_NAME = 'EX_RATE_COPY';
    EXCEPTION
      WHEN OTHERS THEN
        PRM_EX_RATE_COPY := 'N';
        DBG('NO DATE FOUND..');
    END;

    DBG('Calling Fn_Get_smtb_menu_Rec_Wrp for the function id...' ||
        'CYDRATEE');
    IF GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP('CYDRATEE',
                                                 P_ERR_CODE,
                                                 P_ERR_PARAMS) THEN
      PRM_HO_ACTIVITY := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.HO_FUNCTION;
      DBG('prm_ho_activity....' || PRM_HO_ACTIVITY);
    ELSE
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;
    DBG('Menu details derived...');

    DBG(GLOBAL.HEAD_OFFICE);
    DBG(GLOBAL.CURRENT_BRANCH);
    IF GLOBAL.HEAD_OFFICE <> GLOBAL.CURRENT_BRANCH THEN
      IF NVL(PRM_EX_RATE_COPY, 'N') = 'Y' AND
         NVL(PRM_HO_ACTIVITY, 'N') = 'Y' THEN
        DBG('Not Ho Maan');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of cypks_cydratee_Kernel.Fn_Pre_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_CYDRATEE         IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    DBG('In Fn_Post_Check_Mandatory..');

    DBG('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of cypks_cydratee_Kernel.Fn_Post_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CHILD_FUNCTION   IN VARCHAR2,
                                       P_CYDRATEE         IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                       P_PREV_CYDRATEE    IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                       P_WRK_CYDRATEE     IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_THRUCCY VARCHAR2(3);
    L_COUNT   NUMBER;
  BEGIN

    DBG('In Fn_Pre_Default_And_Validate..');
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

      IF P_CYDRATEE.V_CYTMS_RATES.COUNT = 0 THEN
        DEBUG.PR_DEBUG('**',
                       'At least one Currency rate  should be maintained');
        P_ERR_CODE   := 'CY-01';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      IF P_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN

        FOR I IN P_CYDRATEE.V_CYTMS_RATES.FIRST .. P_CYDRATEE.V_CYTMS_RATES.LAST LOOP
          IF P_CYDRATEE.V_CYTMS_RATES(I).RATE_TYPE IS NULL THEN
            DBG('Rate Type is null ');
            RETURN FALSE;
          END IF;

          SELECT COUNT(*)
            INTO L_COUNT
            FROM CYTMS_RATE_TYPE
           WHERE RECORD_STAT = 'O'
             AND ONCE_AUTH = 'Y'
             AND CCY_RATE_TYPE = P_CYDRATEE.V_CYTMS_RATES(I).RATE_TYPE;

          IF L_COUNT = 0 THEN
            P_ERR_CODE   := 'ST-VALS-011';
            P_ERR_PARAMS := P_CYDRATEE.V_CYTMS_RATES(I)
                            .RATE_TYPE || '~Rate Type';
            DBG('Lov Validation False   :' || P_CYDRATEE.V_CYTMS_RATES(I)
                .RATE_TYPE);
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          END IF;
          IF P_CYDRATEE.V_CYTMS_RATES(I).MID_RATE <= 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CY-9007', '');
          END IF;
          --sampath commented starts
         /* IF P_CYDRATEE.V_CYTMS_RATES(I).BUY_SPREAD < 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CY-9008', '');
          END IF;
          IF P_CYDRATEE.V_CYTMS_RATES(I).SALE_SPREAD < 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CY-9008', '');
          END IF;*/
         --sampath commented ends
        END LOOP;

        BEGIN
          SELECT THROUGH_CCY
            INTO L_THRUCCY
            FROM CYTBS_CCY_PAIR
           WHERE CCY1 = P_CYDRATEE.V_CYTMS_RATES(1).CCY1
             AND CCY2 = P_CYDRATEE.V_CYTMS_RATES(1).CCY2;
          IF L_THRUCCY IS NOT NULL THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'EU-EXH07', '');
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
      END IF;
    END IF;

    DBG('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of cypks_cydratee_Kernel.Fn_Pre_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

  FUNCTION FN_POST_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_CYDRATEE         IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                        P_PREV_CYDRATEE    IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                        P_WRK_CYDRATEE     IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_RATE_SERIAL NUMBER(4);
    L_COUNT       NUMBER;
    L_COUNT_FLG   NUMBER := 0;
    L_EXIST_FLAG  BOOLEAN := TRUE;

    L_QUOTATION CYTMS_CCY_PAIR_DEFN.QUOTATION%TYPE;
  BEGIN

    DBG('In Fn_Post_Default_And_Validate..');

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

      IF (P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT >
         P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT) THEN
        DBG('Previus record has more records');
        DBG('Rates cannot be deleted');
        L_EXIST_FLAG := FALSE;

      ELSE
        DBG('Check for any deletion');
        IF P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN

          FOR PREV IN P_PREV_CYDRATEE.V_CYTMS_RATES.FIRST .. P_PREV_CYDRATEE.V_CYTMS_RATES.LAST LOOP

            FOR CURR IN P_WRK_CYDRATEE.V_CYTMS_RATES.FIRST .. P_WRK_CYDRATEE.V_CYTMS_RATES.LAST LOOP

              IF (P_PREV_CYDRATEE.V_CYTMS_RATES(PREV)
                 .RATE_TYPE = P_WRK_CYDRATEE.V_CYTMS_RATES(CURR).RATE_TYPE) THEN
                L_EXIST_FLAG := TRUE;
                GOTO OUT_LOOP;

              ELSE
                L_EXIST_FLAG := FALSE;
                DBG('Not a match');

              END IF;

            END LOOP;
            <<OUT_LOOP>>
            DBG('Next iter');
          END LOOP;
        END IF;
      END IF;

    END IF;

    IF (NOT (L_EXIST_FLAG)) THEN
      DBG('rates  cannot be deleted');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CY-RTYP3', '');
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN

      IF P_CYDRATEE.V_CYTMS_RATES_MASTER.ONCE_AUTH = 'Y' THEN

        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-VALS-012',
                     '@' || P_CYDRATEE.V_CYTMS_RATES_MASTER.ONCE_AUTH || '~@' ||
                     'cytms_rates_master.once_auth');
      END IF;

    END IF;

    IF (P_ACTION_CODE = 'DEFAULT' AND
       P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT = 0) THEN
      IF NOT FN_GET_PREV_DATA(P_SOURCE,
                              P_ACTION_CODE,
                              P_FUNCTION_ID,
                              P_WRK_CYDRATEE,
                              P_PREV_CYDRATEE,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Get_Prev_Data..');
      END IF;

    ELSIF P_SOURCE <> 'FLEXCUBE' THEN
      IF P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT <> 0 THEN
        FOR L_INDEX IN P_PREV_CYDRATEE.V_CYTMS_RATES.FIRST .. P_PREV_CYDRATEE.V_CYTMS_RATES.LAST LOOP
          P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX).MID_RATE := '';
          P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX).BUY_RATE := '';
          P_PREV_CYDRATEE.V_CYTMS_RATES(L_INDEX).SALE_RATE := '';
        END LOOP;
      END IF;
    END IF;

    DBG('p_prev_cydratee.v_Cytms_Rates.Count::::::' ||
        P_PREV_CYDRATEE.V_CYTMS_RATES.COUNT);
    DBG('ccy.v_Cytms_Rates.Count::::::' || P_ACTION_CODE);
    IF NOT FN_ENRICH_RATES(P_SOURCE,
                           P_SOURCE_OPERATION,
                           P_ACTION_CODE,
                           P_PREV_CYDRATEE,
                           P_WRK_CYDRATEE,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      DBG('Failed in Enriching the Rates ');
    END IF;

    IF P_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN

      DBG('changes to be indentified once');
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
        PR_CHECK_FOR_CHANGE(P_WRK_CYDRATEE, P_PREV_CYDRATEE);
      END IF;

      FOR I IN P_CYDRATEE.V_CYTMS_RATES.FIRST .. P_CYDRATEE.V_CYTMS_RATES.LAST LOOP
        DBG('Action Code :' || P_ACTION_CODE);
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

          IF P_SOURCE <> 'FLEXCUBE' THEN
            IF INSTR('IE',
                     CYPKSS.FN_EURTYPE(P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1)) = 0 AND
               INSTR('IE',
                     CYPKSS.FN_EURTYPE(P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2)) = 0 THEN
              IF P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_TYPE IS NULL OR P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                 .MID_RATE IS NULL OR P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                 .BUY_RATE IS NULL OR P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                 .SALE_RATE IS NULL THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'SM-00089', '');
              END IF;
            ELSE

              IF INSTR('IE',
                       CYPKSS.FN_EURTYPE(P_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1)) = 0 AND
                 INSTR('IE',
                       CYPKSS.FN_EURTYPE(P_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2)) = 0 THEN
                IF P_CYDRATEE.V_CYTMS_RATES(I).RATE_TYPE IS NULL OR P_CYDRATEE.V_CYTMS_RATES(I)
                   .MID_RATE IS NULL OR P_CYDRATEE.V_CYTMS_RATES(I)
                   .BUY_RATE IS NULL OR P_CYDRATEE.V_CYTMS_RATES(I)
                   .SALE_RATE IS NULL THEN
                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'SM-00089', '');
                END IF;
              END IF;
            END IF;
          END IF;
          BEGIN

            IF P_ACTION_CODE NOT IN
               (CSPKS_REQ_GLOBAL.P_QUERY, CSPKS_REQ_GLOBAL.P_AUTH) THEN

              DBG(P_CYDRATEE.V_CYTMS_RATES(I).RATE_DATE);
              DBG(GLOBAL.APPLICATION_DATE);
              IF P_CYDRATEE.V_CYTMS_RATES(I)
               .RATE_DATE = GLOBAL.APPLICATION_DATE THEN
                SELECT COUNT(1)
                  INTO L_COUNT
                  FROM CYTMS_RATES
                 WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES(I).CCY1
                   AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES(I).CCY2
                   AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                   AND RATE_TYPE = P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                      .RATE_TYPE
                   AND RATE_DATE = P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                      .RATE_DATE;

                SELECT COUNT(*)
                  INTO G_CNT
                  FROM CYTMS_RATES
                 WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES(I).CCY1
                   AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES(I).CCY2
                   AND RATE_TYPE = P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                      .RATE_TYPE
                   AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

                DBG('g_cnt   :' || G_CNT || 'p_cydratee.v_Cytms_Rates(i)
                  .rate_serial' || P_CYDRATEE.V_CYTMS_RATES(I)
                    .RATE_SERIAL);

                IF G_RATE_TYPE.COUNT > 0 THEN
                  FOR I IN G_RATE_TYPE.FIRST .. G_RATE_TYPE.LAST LOOP
                    DBG('MODIFIED RECORDS' || G_RATE_TYPE(I));
                    IF P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                     .RATE_TYPE = G_RATE_TYPE(I) THEN
                      DBG('p_Wrk_cydratee.v_Cytms_Rates(i).rate_type' || P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                          .RATE_TYPE);

                      IF L_COUNT > 0 OR G_CNT = 0 THEN

                        SELECT COUNT(*)
                          INTO L_COUNT
                          FROM CYTMS_RATES
                         WHERE CCY1 = P_CYDRATEE.V_CYTMS_RATES(I).CCY1
                           AND CCY2 = P_CYDRATEE.V_CYTMS_RATES(I).CCY2
                           AND RATE_TYPE = P_CYDRATEE.V_CYTMS_RATES(I)
                              .RATE_TYPE
                           AND RATE_SERIAL = P_CYDRATEE.V_CYTMS_RATES(I)
                              .RATE_SERIAL;
                        IF L_COUNT > 0 OR G_CNT = 0 THEN

                          P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_SERIAL := FN_RATE_SERIAL(P_ACTION_CODE,
                                                                                        P_CYDRATEE.V_CYTMS_RATES(I).CCY1,
                                                                                        P_CYDRATEE.V_CYTMS_RATES(I).CCY2,
                                                                                        P_CYDRATEE.V_CYTMS_RATES(I)
                                                                                        .RATE_TYPE,
                                                                                        P_CYDRATEE.V_CYTMS_RATES(I)
                                                                                        .RATE_DATE);
                          DBG(P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_SERIAL);
                        END IF;

                        SELECT RATE_SERIAL
                          INTO L_RATE_SERIAL
                          FROM CYTBS_RATES_HISTORY
                         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                           AND CCY1 = P_CYDRATEE.V_CYTMS_RATES(I).CCY1
                           AND CCY2 = P_CYDRATEE.V_CYTMS_RATES(I).CCY2
                           AND RATE_TYPE = P_CYDRATEE.V_CYTMS_RATES(I)
                              .RATE_TYPE
                           AND RATE_DATE = P_CYDRATEE.V_CYTMS_RATES(I)
                              .RATE_DATE
                           AND RATE_SERIAL = P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                              .RATE_SERIAL;

                        DBG('L_RATE_SERIAL : ' || L_RATE_SERIAL);

                      END IF;
                    END IF;
                  END LOOP;

                END IF;
              END IF;
            END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
            WHEN OTHERS THEN
              DBG(' when others while saving rate_serial ' || SQLERRM ||
                  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
              RETURN FALSE;
          END;
          IF (P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_DATE IS NULL OR P_WRK_CYDRATEE.V_CYTMS_RATES(I)
             .RATE_SERIAL IS NULL) THEN
            P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_DATE := GLOBAL.APPLICATION_DATE;
            P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_SERIAL := 1;
          END IF;
        END IF;
      END LOOP;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
       P_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1 IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_COUNT
        FROM (SELECT CCY1
                FROM CYTMS_RATES_MASTER
               WHERE CCY1 = P_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
                 AND RECORD_STAT = 'O'
                 AND ONCE_AUTH = 'Y');

      IF L_COUNT <= 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-VALS-012',
                     '@' || P_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1 || '~@' ||
                     'CYTMS_RATES_MASTER.CCY1');
        RETURN FALSE;
      END IF;

    END IF;

    BEGIN
      SELECT QUOTATION
        INTO L_QUOTATION
        FROM CYTMS_CCY_PAIR_DEFN
       WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
         AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2;
      DBG('l_Quotation@@@ ' || L_QUOTATION);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Exception raised while getting the Spread and quotation Detials ');
        DBG(SQLERRM);
        RETURN FALSE;
    END;
    --sampath commented starts
    /*IF L_QUOTATION = 'D' THEN

      IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
        IF P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN
          FOR I IN P_WRK_CYDRATEE.V_CYTMS_RATES.FIRST .. P_WRK_CYDRATEE.V_CYTMS_RATES.LAST LOOP
            IF P_WRK_CYDRATEE.V_CYTMS_RATES(I)
             .BUY_RATE > P_WRK_CYDRATEE.V_CYTMS_RATES(I).MID_RATE THEN
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CY-9019', '');
            END IF;
            IF P_WRK_CYDRATEE.V_CYTMS_RATES(I)
             .SALE_RATE < P_WRK_CYDRATEE.V_CYTMS_RATES(I).MID_RATE THEN
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CY-9020', '');
            END IF;
          END LOOP;
        END IF;
      END IF;

    END IF;*/
    --sampath commented ends

    DBG('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of cypks_cydratee_Kernel.Fn_Post_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DEFAULT_AND_VALIDATE;

  FUNCTION FN_PRE_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_CHILD_FUNCTION   IN VARCHAR2,
                            P_POST_UPL_STAT    IN VARCHAR2,
                            P_MULTI_TRIP_ID    IN VARCHAR2,
                            P_CYDRATEE         IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                            P_PREV_CYDRATEE    IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                            P_WRK_CYDRATEE     IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT NUMBER;
    L_RCNT  NUMBER;

  BEGIN

    DBG('In Fn_Pre_Upload_Db..');

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.RECORD_STAT := P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER.RECORD_STAT;
      P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.ONCE_AUTH   := P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER.ONCE_AUTH;
      IF P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN
        FOR I IN P_WRK_CYDRATEE.V_CYTMS_RATES.FIRST .. P_WRK_CYDRATEE.V_CYTMS_RATES.LAST LOOP
          DBG(P_WRK_CYDRATEE.V_CYTMS_RATES(I).INT_AUTH_STAT);

          IF NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(I).INT_AUTH_STAT, 'U') = 'U' THEN

            SELECT COUNT(1)
              INTO L_COUNT
              FROM CYTMS_RATES
             WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES(I).CCY1
               AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES(I).CCY2
               AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
               AND RATE_TYPE = P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_TYPE;

            SELECT COUNT(*)
              INTO L_RCNT
              FROM CYTMS_RATES
             WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES(I).CCY1
               AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES(I).CCY2
               AND RATE_TYPE = P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_TYPE
               AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

            P_WRK_CYDRATEE.V_CYTMS_RATES(I).UNAUTH_MID_RATE := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                               .MID_RATE;
            P_WRK_CYDRATEE.V_CYTMS_RATES(I).UNAUTH_BUY_SPREAD := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                                 .BUY_SPREAD;
            P_WRK_CYDRATEE.V_CYTMS_RATES(I).UNAUTH_SALE_SPREAD := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                                  .SALE_SPREAD;
            P_WRK_CYDRATEE.V_CYTMS_RATES(I).UNAUTH_BUY_RATE := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                               .BUY_RATE;
            P_WRK_CYDRATEE.V_CYTMS_RATES(I).UNAUTH_SALE_RATE := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                                .SALE_RATE;

            P_WRK_CYDRATEE.V_CYTMS_RATES(I).UNAUTH_RATE_DATE := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                                .RATE_DATE;
            P_WRK_CYDRATEE.V_CYTMS_RATES(I).UNAUTH_RATE_SERIAL := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                                  .RATE_SERIAL;

            P_WRK_CYDRATEE.V_CYTMS_RATES(I).INT_AUTH_STAT := 'U';

            IF L_COUNT > 0 THEN

              P_WRK_CYDRATEE.V_CYTMS_RATES(I).MID_RATE := P_PREV_CYDRATEE.V_CYTMS_RATES(I)
                                                          .MID_RATE;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).BUY_SPREAD := P_PREV_CYDRATEE.V_CYTMS_RATES(I)
                                                            .BUY_SPREAD;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).SALE_SPREAD := P_PREV_CYDRATEE.V_CYTMS_RATES(I)
                                                             .SALE_SPREAD;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).BUY_RATE := P_PREV_CYDRATEE.V_CYTMS_RATES(I)
                                                          .BUY_RATE;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).SALE_RATE := P_PREV_CYDRATEE.V_CYTMS_RATES(I)
                                                           .SALE_RATE;

              P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_DATE := P_PREV_CYDRATEE.V_CYTMS_RATES(I)
                                                           .RATE_DATE;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_SERIAL := P_PREV_CYDRATEE.V_CYTMS_RATES(I)
                                                             .RATE_SERIAL;

            ELSE

              P_WRK_CYDRATEE.V_CYTMS_RATES(I).MID_RATE := NULL;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).BUY_SPREAD := NULL;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).SALE_SPREAD := NULL;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).BUY_RATE := NULL;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).SALE_RATE := NULL;

              P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_DATE := NULL;
              P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_SERIAL := NULL;

            END IF;
          END IF;
        END LOOP;
      END IF;
    END IF;
    DBG('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of cypks_cydratee_Kernel.Fn_Pre_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UPLOAD_DB;

  FUNCTION FN_POST_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_POST_UPL_STAT    IN VARCHAR2,
                             P_MULTI_TRIP_ID    IN VARCHAR2,
                             P_CYDRATEE         IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                             P_PREV_CYDRATEE    IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                             P_WRK_CYDRATEE     IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_EX_RATE_COPY VARCHAR2(1);
    L_HO_BRANCH    STTMS_CORE_BANK.HO_BRANCH%TYPE;
    L_REVAL_COUNT  NUMBER;

    CURSOR CR_RATES IS
      SELECT *
        FROM CYTMS_RATES
       WHERE BRANCH_CODE = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.BRANCH_CODE
         AND CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
         AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2;

    CURSOR CR_RATES_INTAUTH IS
      SELECT *
        FROM CYTMS_RATES
       WHERE BRANCH_CODE = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.BRANCH_CODE
         AND CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
         AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2;

    L_COPY_HO_RATES  CSTB_PARAM.PARAM_VAL%TYPE;
    L_USER_AUTO_AUTH SMTB_USER.USER_ID%TYPE;
  BEGIN

    DERIVERATES.T_CYTB_RATES_REVAL.DELETE;
    DBG('In fn_post_upload_db>>>>');
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      IF P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN
        DELETE FROM CYTMS_RATES
         WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
           AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2;
      END IF;
      DELETE FROM CYTMS_RATES_MASTER
       WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
         AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2;
    END IF;
    DBG('In fn_post_upload_db p_action_code >>>>' || P_ACTION_CODE || '  ' ||
        CSPKS_REQ_GLOBAL.P_AUTH);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_CLOSE) THEN
      BEGIN
        SELECT NVL(PARAM_VAL, 'N')
          INTO L_COPY_HO_RATES
          FROM CSTB_PARAM
         WHERE PARAM_NAME = 'COPY_HO_RATES';
        DBG('The Copy HO Rate param == ' || L_COPY_HO_RATES);
        IF L_COPY_HO_RATES = 'Y' THEN
          IF SMPKSS.FN_CHECK_AUTO_AUTH(GLOBAL.USER_ID,
                                       'CYDRATEE',
                                       GLOBAL.CURRENT_BRANCH) THEN
            L_USER_AUTO_AUTH := 'A';
          ELSE
            L_USER_AUTO_AUTH := 'U';
          END IF;
          UPDATE CYTM_RATES_MASTER
             SET RECORD_STAT = 'C', AUTH_STAT = L_USER_AUTO_AUTH
           WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
             AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2
             AND BRANCH_CODE <> GLOBAL.HEAD_OFFICE;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No param is maintained for COPY_HO_RATES');
        WHEN OTHERS THEN
          DBG('When other error in cypks_cydccypr_kernel.Fn_Post_Upload_Db error: ' ||
              SQLERRM);
      END;
    END IF;
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      DBG('In fn_post_upload_db auth_stat >>>>' ||
          P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.AUTH_STAT);

      DBG('going to update ' || P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT);

      FOR REC IN CR_RATES_INTAUTH LOOP

        IF REC.INT_AUTH_STAT = 'U' THEN
          UPDATE CYTMS_RATES
             SET MID_RATE           = UNAUTH_MID_RATE,
                 BUY_SPREAD         = UNAUTH_BUY_SPREAD,
                 SALE_SPREAD        = UNAUTH_SALE_SPREAD,
                 BUY_RATE           = UNAUTH_BUY_RATE,
                 SALE_RATE          = UNAUTH_SALE_RATE,
                 RATE_DATE          = UNAUTH_RATE_DATE,
                 RATE_SERIAL        = UNAUTH_RATE_SERIAL,
                 UNAUTH_RATE_DATE   = NULL,
                 UNAUTH_RATE_SERIAL = NULL,
                 UNAUTH_MID_RATE    = NULL,
                 UNAUTH_BUY_SPREAD  = NULL,
                 UNAUTH_SALE_SPREAD = NULL,
                 UNAUTH_BUY_RATE    = NULL,
                 UNAUTH_SALE_RATE   = NULL,
                 INT_AUTH_STAT      = 'A'
           WHERE CCY1 = REC.CCY1
             AND CCY2 = REC.CCY2
             AND BRANCH_CODE =
                 P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.BRANCH_CODE
             AND RATE_TYPE = REC.RATE_TYPE;

        END IF;
      END LOOP;

      BEGIN
        SELECT HO_BRANCH INTO L_HO_BRANCH FROM STTMS_CORE_BANK;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
      END;

      BEGIN
        SELECT PARAM_VAL
          INTO L_EX_RATE_COPY
          FROM CSTBS_PARAM
         WHERE PARAM_NAME = 'EX_RATE_COPY';
      EXCEPTION
        WHEN OTHERS THEN
          PRM_EX_RATE_COPY := 'N';
      END;

      DBG('calling drvrates for HO');

      BEGIN
        SELECT *
          INTO DERIVERATES.CYTMS_CCY_REC
          FROM CYTMS_CCY_PAIR_DEFN
         WHERE ((CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1 AND
               CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2));
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('CY', 'The currency pair is not maintained');
          NULL;
      END;
      BEGIN
        SELECT OFFSET_RECORD

          INTO DERIVERATES.L_OFFSET_REC
          FROM CYTBS_CCY_PAIR
         WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
           AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('CY',
                         P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1 || '->' ||
                         P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2 ||
                         ' is an Invalid Ccy Pairc ' || SQLERRM);
          NULL;
      END;
      BEGIN
        SELECT OFFSET_RECORD
          INTO DERIVERATES.L_OFFSET_REC2
          FROM CYTBS_CCY_PAIR

         WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2
           AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('CY',
                         P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1 || '->' ||
                         P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2 ||
                         ' is an Invalid Ccy Pairc ' || SQLERRM);
          NULL;
      END;
      SELECT NO_OF_UNITS
        INTO DERIVERATES.G_NO_OF_UNITS1
        FROM CYTBS_CCY_PAIR
       WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
         AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2;
      SELECT NO_OF_UNITS
        INTO DERIVERATES.G_NO_OF_UNITS2
        FROM CYTBS_CCY_PAIR
       WHERE CCY1 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2
         AND CCY2 = P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1;

      SELECT TODAY
        INTO DERIVERATES.L_TODAY
        FROM STTMS_DATES
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
      DEBUG.PR_DEBUG('CY', 'today cymisc' || DERIVERATES.L_TODAY);

      FOR CURREC IN CR_RATES LOOP
        BEGIN

          SELECT *
            INTO DERIVERATES.T_CCY_CACHE(GLOBAL.CURRENT_BRANCH ||
                                         CURREC.CCY1 || CURREC.CCY2 ||
                                         CURREC.RATE_TYPE)
            FROM CYTMS_RATES
           WHERE BRANCH_CODE = CURREC.BRANCH_CODE
             AND CCY1 = CURREC.CCY1
             AND CCY2 = CURREC.CCY2
             AND RATE_TYPE = CURREC.RATE_TYPE;
        EXCEPTION
          WHEN OTHERS THEN

            SELECT *
              INTO DERIVERATES.T_CCY_CACHE(GLOBAL.CURRENT_BRANCH ||
                                           CURREC.CCY2 || CURREC.CCY1 ||
                                           CURREC.RATE_TYPE)
              FROM CYTMS_RATES
             WHERE BRANCH_CODE = CURREC.BRANCH_CODE
               AND CCY1 = CURREC.CCY2
               AND CCY2 = CURREC.CCY1
               AND RATE_TYPE = CURREC.RATE_TYPE;
            DEBUG.PR_DEBUG('CY', 'caching2 ...');
        END;

        L_REVAL_COUNT := DERIVERATES.T_CYTB_RATES_REVAL.COUNT;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . BRANCH_CODE := CURREC.BRANCH_CODE;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . CCY1 := CURREC.CCY1;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . CCY2 := CURREC.CCY2;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . RATE_TYPE := CURREC.RATE_TYPE;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . MID_RATE := CURREC.MID_RATE;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . BUY_SPREAD := CURREC.BUY_SPREAD;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . SALE_SPREAD := CURREC.SALE_SPREAD;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . BUY_RATE := CURREC.BUY_RATE;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . SALE_RATE := CURREC.SALE_RATE;
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . STATUS := 'U';
        DERIVERATES.T_CYTB_RATES_REVAL(L_REVAL_COUNT + 1) . REVAL_DATE := GLOBAL.APPLICATION_DATE;

      END LOOP;

      DERIVERATES.DRVRATES(GLOBAL.CURRENT_BRANCH,
                           P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1,
                           P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2);
      DBG('l_Ex_Rate_Copy:>>>>>>>:' || L_EX_RATE_COPY);
      DBG('l_Ho_Branch::' || L_HO_BRANCH);

      IF NVL(L_EX_RATE_COPY, 'N') = 'Y' THEN

        IF NOT
            CYPKSS_MISC.FN_PROPAGATERATES(GLOBAL.CURRENT_BRANCH,
                                          P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1,
                                          P_WRK_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2) THEN
          DBG('Rate propagation failed');
          P_ERR_CODE   := 'CY-20001';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      END IF;

      FORALL I IN 1 .. DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY.COUNT
        INSERT INTO CYTB_DERIVED_RATES_HISTORY
          (BRANCH_CODE,
           CCY1,
           CCY2,
           RATE_TYPE,
           RATE_DT_STAMP,
           MID_RATE,
           BUY_RATE,
           SALE_RATE,
           MULT_FACTOR,
           POWER_FACTOR,
           RATE_FLAG,
           RATE_DATE,
           RATE_SERIAL)
        VALUES
          (DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).BRANCH_CODE,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).CCY1,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).CCY2,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).RATE_TYPE,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).RATE_DT_STAMP,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).MID_RATE,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).BUY_RATE,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).SALE_RATE,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).MULT_FACTOR,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).POWER_FACTOR,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).RATE_FLAG,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).RATE_DATE,
           DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY(I).RATE_SERIAL);

      FORALL J IN 1 .. DERIVERATES.T_CYTMS_DERIVED_RATES.COUNT
        INSERT INTO CYTM_DERIVED_RATES
          (BRANCH_CODE,
           CCY1,
           CCY2,
           RATE_TYPE,
           MID_RATE,
           BUY_SPREAD,
           SALE_SPREAD,
           BUY_RATE,
           SALE_RATE,
           MULT_FACTOR,
           POWER_FACTOR,
           RATE_FLAG,
           RATE_DATE,
           RATE_SERIAL)
        VALUES
          (DERIVERATES.T_CYTMS_DERIVED_RATES(J).BRANCH_CODE,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).CCY1,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).CCY2,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).RATE_TYPE,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).MID_RATE,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).BUY_SPREAD,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).SALE_SPREAD,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).BUY_RATE,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).SALE_RATE,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).MULT_FACTOR,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).POWER_FACTOR,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).RATE_FLAG,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).RATE_DATE,
           DERIVERATES.T_CYTMS_DERIVED_RATES(J).RATE_SERIAL);

      DERIVERATES.T_CYTMS_DERIVED_RATES.DELETE;
      DERIVERATES.T_CYTB_DERIVED_RATES_HISTORY.DELETE;

      FOR I IN 1 .. DERIVERATES.T_CYTB_RATES_REVAL.COUNT LOOP
        UPDATE CYTB_RATES_REVAL
           SET MID_RATE    = DERIVERATES.T_CYTB_RATES_REVAL(I).MID_RATE,
               BUY_SPREAD  = DERIVERATES.T_CYTB_RATES_REVAL(I).BUY_SPREAD,
               SALE_SPREAD = DERIVERATES.T_CYTB_RATES_REVAL(I).SALE_SPREAD,
               BUY_RATE    = DERIVERATES.T_CYTB_RATES_REVAL(I).BUY_RATE,
               SALE_RATE   = DERIVERATES.T_CYTB_RATES_REVAL(I).SALE_RATE,
               STATUS      = 'U',
               REVAL_DATE  = GLOBAL.APPLICATION_DATE
         WHERE BRANCH_CODE = DERIVERATES.T_CYTB_RATES_REVAL(I).BRANCH_CODE
           AND CCY1 = DERIVERATES.T_CYTB_RATES_REVAL(I).CCY1
           AND CCY2 = DERIVERATES.T_CYTB_RATES_REVAL(I).CCY2
           AND RATE_TYPE = DERIVERATES.T_CYTB_RATES_REVAL(I).RATE_TYPE;

        IF SQL%ROWCOUNT = 0 THEN
          INSERT INTO CYTB_RATES_REVAL
            (BRANCH_CODE,
             CCY1,
             CCY2,
             RATE_TYPE,
             MID_RATE,
             BUY_SPREAD,
             SALE_SPREAD,
             BUY_RATE,
             SALE_RATE,
             STATUS,
             REVAL_DATE)
          VALUES
            (DERIVERATES.T_CYTB_RATES_REVAL(I).BRANCH_CODE,
             DERIVERATES.T_CYTB_RATES_REVAL(I).CCY1,
             DERIVERATES.T_CYTB_RATES_REVAL(I).CCY2,
             DERIVERATES.T_CYTB_RATES_REVAL(I).RATE_TYPE,
             DERIVERATES.T_CYTB_RATES_REVAL(I).MID_RATE,
             DERIVERATES.T_CYTB_RATES_REVAL(I).BUY_SPREAD,
             DERIVERATES.T_CYTB_RATES_REVAL(I).SALE_SPREAD,
             DERIVERATES.T_CYTB_RATES_REVAL(I).BUY_RATE,
             DERIVERATES.T_CYTB_RATES_REVAL(I).SALE_RATE,
             'U',
             GLOBAL.APPLICATION_DATE);

        END IF;
      END LOOP;

    END IF;
    DBG('Returning Success from fn_post_upload_db>>>>>>>>>>');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of cypks_fcj_cydrates_addon.fn_post_upload_db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
      DBG('Returning Success From Fn_Post_Upload_Db..');
      RETURN TRUE;

  END FN_POST_UPLOAD_DB;

  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CHILD_FUNCTION   IN VARCHAR2,
                        P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                        P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                        P_QRYDATA_REQD     IN VARCHAR2,
                        P_CYDRATEE         IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                        P_WRK_CYDRATEE     IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    DBG('In Fn_Pre_Query..');

    DBG('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of cypks_cydratee_Kernel.Fn_Pre_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;

  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CHILD_FUNCTION   IN VARCHAR2,
                         P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                         P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                         P_QRYDATA_REQD     IN VARCHAR2,
                         P_CYDRATEE         IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                         P_WRK_CYDRATEE     IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    DBG('In Fn_Post_Query..');

    IF P_WRK_CYDRATEE.V_CYTMS_RATES.COUNT > 0 THEN
      FOR I IN P_WRK_CYDRATEE.V_CYTMS_RATES.FIRST .. P_WRK_CYDRATEE.V_CYTMS_RATES.LAST LOOP

        IF P_WRK_CYDRATEE.V_CYTMS_RATES(I)
         .INT_AUTH_STAT = 'U' AND
            P_ACTION_CODE IN
            (CSPKS_REQ_GLOBAL.P_AUTH, CSPKS_REQ_GLOBAL.P_QUERY) THEN
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).MID_RATE := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                      .UNAUTH_MID_RATE;
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).BUY_SPREAD := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                        .UNAUTH_BUY_SPREAD;
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).SALE_SPREAD := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                         .UNAUTH_SALE_SPREAD;
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).BUY_RATE := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                      .UNAUTH_BUY_RATE;
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).SALE_RATE := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                       .UNAUTH_SALE_RATE;

          P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_DATE := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                       .UNAUTH_RATE_DATE;
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_SERIAL := P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                         .UNAUTH_RATE_SERIAL;

        ELSE

          P_WRK_CYDRATEE.V_CYTMS_RATES(I).MID_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                          .MID_RATE,
                                                          P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                          .UNAUTH_MID_RATE);
          DBG('In Fn_Post_Query..' || P_WRK_CYDRATEE.V_CYTMS_RATES(I)
              .MID_RATE);
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).BUY_SPREAD := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                            .BUY_SPREAD,
                                                            P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                            .UNAUTH_BUY_SPREAD);
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).SALE_SPREAD := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                             .SALE_SPREAD,
                                                             P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                             .UNAUTH_SALE_SPREAD);
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).BUY_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                          .BUY_RATE,
                                                          P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                          .UNAUTH_BUY_RATE);
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).SALE_RATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                           .SALE_RATE,
                                                           P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                           .UNAUTH_SALE_RATE);

          P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_DATE := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                           .RATE_DATE,
                                                           P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                           .UNAUTH_RATE_DATE);
          P_WRK_CYDRATEE.V_CYTMS_RATES(I).RATE_SERIAL := NVL(P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                             .RATE_SERIAL,
                                                             P_WRK_CYDRATEE.V_CYTMS_RATES(I)
                                                             .UNAUTH_RATE_SERIAL);

        END IF;
      END LOOP;
    END IF;

    DBG('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of cypks_cydratee_Kernel.Fn_Post_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

  FUNCTION FN_GET_PREV_DATA(P_SOURCE        IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                            P_ACTION_CODE   IN VARCHAR2,
                            P_FUNCTION_ID   IN VARCHAR2,
                            P_CYDRATEE      IN CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                            P_PREV_CYDRATEE IN OUT CYPKS_CYDRATEE_MAIN.TY_CYDRATEE,
                            P_ERR_CODE      IN OUT VARCHAR2,
                            P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS

    RECORD_LOCKED EXCEPTION;
    L_REC_EXISTS BOOLEAN := TRUE;
    PRAGMA EXCEPTION_INIT(RECORD_LOCKED, -54);

    CURSOR C_V_CYTMS_RATES IS
      SELECT *
        FROM CYTM_RATES
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND BRANCH_CODE = P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER.BRANCH_CODE
         AND CCY1 = P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
         AND CCY2 = P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2;

  BEGIN
    DBG('In fn_get_prev_data..');

    DBG('Get the master record...');
    BEGIN
      SELECT *
        INTO P_PREV_CYDRATEE.V_CYTMS_RATES_MASTER
        FROM CYTM_RATES_MASTER
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND BRANCH_CODE = P_CYDRATEE.V_CYTMS_RATES_MASTER.BRANCH_CODE
         AND CCY1 = P_CYDRATEE.V_CYTMS_RATES_MASTER.CCY1
         AND CCY2 = P_CYDRATEE.V_CYTMS_RATES_MASTER.CCY2
         FOR UPDATE NOWAIT;

    EXCEPTION
      WHEN RECORD_LOCKED THEN
        DBG('Failed to Obtain the Lock..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-LOCK-001', NULL);
        RETURN FALSE;
      WHEN NO_DATA_FOUND THEN
        DBG('Failed in selecting the Previous master Recotrd');
        L_REC_EXISTS := FALSE;
    END;

    IF L_REC_EXISTS THEN
      DBG('Get the Detailed Records');

      DBG('Get the Record For :CYTMS_RATES');
      OPEN C_V_CYTMS_RATES;
      LOOP
        FETCH C_V_CYTMS_RATES BULK COLLECT
          INTO P_PREV_CYDRATEE.V_CYTMS_RATES;
        EXIT WHEN C_V_CYTMS_RATES%NOTFOUND;
      END LOOP;
      CLOSE C_V_CYTMS_RATES;
    END IF;

    DBG('Returning fn_get_prev_data');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of cypks_fcj_cydrates.Fn_Get_Prev_Data ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      IF C_V_CYTMS_RATES%ISOPEN THEN
        CLOSE C_V_CYTMS_RATES;
      END IF;
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_PREV_DATA;

END CYPKS_CYDRATEE_KERNEL;
/