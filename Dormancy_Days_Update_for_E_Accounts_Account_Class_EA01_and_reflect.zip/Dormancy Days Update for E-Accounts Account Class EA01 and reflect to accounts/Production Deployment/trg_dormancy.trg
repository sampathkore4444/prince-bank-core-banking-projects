CREATE OR REPLACE TRIGGER trg_dormancy
/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2001 - 2009  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/

after update on sttm_account_class
for each row
  WHEN (old.dormancy<>new.dormancy and new.auth_stat = 'U') 
 

--sampath starts
  DECLARE
  L_DAYS NUMBER;
--sampath ends
 
 begin
stpks_stdaccls_kernel.g_acc_class_dormancy := 'Y'; --9NT1606_12_2_RETRO_12_1_23664381 changes

--sampath starts
  IF :OLD.DORMANT_PARAM = 'M' AND :OLD.ACCOUNT_CLASS = 'EA01' THEN
  
    debug.pr_debug('AC', 'NEW DORMANCY=' || :NEW.DORMANCY);
    debug.pr_debug('AC', 'OLD DORMANCY=' || :OLD.DORMANCY);
  
    L_DAYS := TO_NUMBER(:NEW.DORMANCY) - TO_NUMBER(:OLD.DORMANCY);
  
    debug.pr_debug('AC', 'NEW DAYS TO BE ADDED=' || L_DAYS);
  
    IF L_DAYS > 0 THEN
      update sttms_cust_account
         set dormancy_days = :new.dormancy,
             
             dormancy_date = dormancy_date + L_DAYS
       where account_class = :new.account_class;
    
   
    
    END IF;
  
  ELSE
    --sampath ends
	
    update sttms_cust_account
    set dormancy_days=:new.dormancy,
        --9NT1525_11.1_RONBTR_14372225_12.0_RETRO_14568240 changes starts
        /*dormancy_date=greatest(nvl(date_last_cr_activity,ac_open_date),
                        nvl(date_last_dr_activity,ac_open_date))
                    +:new.dormancy+1*/
	dormancy_date = decode(dormant_param
			       ,'B'
			       ,greatest(nvl(date_last_cr_activity, ac_open_date)  ,nvl(date_last_dr_activity, ac_open_date))
			       ,'C'
			       ,nvl(date_last_cr_activity, ac_open_date)
			       ,'D'
			       ,nvl(date_last_dr_activity, ac_open_date)
			       ,dormancy_date) + :NEW.dormancy + 1
       --9NT1525_11.1_RONBTR_14372225_12.0_RETRO_14568240 ends
       where account_class=:new.account_class;
	   
END IF; --sampath added

stpks_stdaccls_kernel.g_acc_class_dormancy := 'N'; ----9NT1606_12_2_RETRO_12_1_23664381 changes

end;

