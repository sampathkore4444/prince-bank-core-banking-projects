/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2020, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1401_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~PRD~BRN~TXNBRN~TXNACC~TXNCCY~TXNAMT~OFFSETACC~OFFSETCCY~OFFSETAMT~XRATE~TXNDATE~RELCUST~NARRATIVE~FCCREF~LCYAMT~ACTAMT~TCYTOTCHGAMT~ACCTITLE1~FT~OFFSETBRN~OFFSETTRN~TXNTRN~MODULE~CUSTNAME~NEGOTRATE~NEGOTREFNO~BENFADDR1~BENFADDR2~BENFADDR3~BENFADDR4~TOKENNO~DENMAMT2~VIRACCNO~ACCTYPE~UI_TXN_ACC~AC_OR_GL~ADV_ACC~CHAR_FIELD31~CHAR_FIELD32~CHAR_FIELD33~CHAR_FIELD34~CHAR_FIELD35~CHAR_FIELD40"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~PRD~BRN~TXNBRN~TXNACC~TXNCCY~TXNAMT~OFFSETACC~OFFSETCCY~OFFSETAMT~XRATE~TXNDATE~RELCUST~NARRATIVE~FCCREF~LCYAMT~ACTAMT~TCYTOTCHGAMT~ACCTITLE1~FT~OFFSETBRN~OFFSETTRN~TXNTRN~MODULE~CUSTNAME~NEGOTRATE~NEGOTREFNO~BENFADDR1~BENFADDR2~BENFADDR3~BENFADDR4~TOKENNO~DENMAMT2~VIRACCNO~ACCTYPE~UI_TXN_ACC~AC_OR_GL~ADV_ACC~CHAR_FIELD31~CHAR_FIELD32~CHAR_FIELD33~CHAR_FIELD34~CHAR_FIELD35~CHAR_FIELD40</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1401.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1401.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__FCCREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__FCCREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__OFFSETCCY__LOV_OFFSETCCY":["BLK_TRANSACTION_DETAILS__OFFSETCCY~~","","N~N",""],"BLK_TRANSACTION_DETAILS__VIRACCNO__LOV_TXNACC":["BLK_TRANSACTION_DETAILS__VIRACCNO~BLK_TRANSACTION_DETAILS__TXNCCY~BLK_TRANSACTION_DETAILS__ACCTITLE1~BLK_TRANSACTION_DETAILS__TXNBRN~BLK_TRANSACTION_DETAILS__OFFSETCCY~BLK_TRANSACTION_DETAILS__ACCTYPE~","","N~N~N~N","N"],"BLK_TRANSACTION_DETAILS__UI_TXN_ACC__LOV_TXNACC":["BLK_TRANSACTION_DETAILS__UI_TXN_ACC~BLK_TRANSACTION_DETAILS__TXNCCY~BLK_TRANSACTION_DETAILS__ACCTITLE1~~BLK_TRANSACTION_DETAILS__TXNBRN~BLK_TRANSACTION_DETAILS__AC_OR_GL~","","N~N~N~N",""],"BLK_TRANSACTION_DETAILS__CHAR_FIELD34__LOV_PURPOSE_OF_TXN":["BLK_TRANSACTION_DETAILS__CHAR_FIELD34~","","N",""],"BLK_TRANSACTION_DETAILS__CHAR_FIELD35__LOV_SOURCE_OF_FUNDS":["BLK_TRANSACTION_DETAILS__CHAR_FIELD35~","","N",""],"BLK_TRANSACTION_DETAILS__CHAR_FIELD40__LOV_PARTICIPANT_NO":["BLK_TRANSACTION_DETAILS__CHAR_FIELD40~BLK_TRANSACTION_DETAILS__CHAR_FIELD32~~BLK_TRANSACTION_DETAILS__CHAR_FIELD33~","","N~N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_MAIN';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_BODY';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("DMCD~BLK_TRANSACTION_DETAILS","CHCD~BLK_TRANSACTION_DETAILS","MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","PDCD~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("","","","",""); 

 var CallRelatType= new Array("N","N","1","N","1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1401"]="KERNEL";
ArrPrntFunc["1401"]="";
ArrPrntOrigin["1401"]="";
ArrRoutingType["1401"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1401"]="N";
ArrCustomModified["1401"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CVS_MAIN":"TXNCCY","DMCD":"","CHCD":"","MDCD":"","UDCD":"","PDCD":""};
var scrArgSource = {"CVS_MAIN":"BLK_TRANSACTION_DETAILS__TXNACC","DMCD":"","CHCD":"","MDCD":"","UDCD":"","PDCD":""};
var scrArgVals = {"CVS_MAIN":"","DMCD":"","CHCD":"","MDCD":"","UDCD":"","PDCD":""};
var scrArgDest = {"CVS_MAIN":""};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","PDCD":""};
var dpndntOnSrvs = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","PDCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"2","DELETE":"2","CLOSE":"2","REOPEN":"2","REVERSE":"2","ROLLOVER":"2","CONFIRM":"2","LIQUIDATE":"2","SUMMARYQUERY":"2"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------