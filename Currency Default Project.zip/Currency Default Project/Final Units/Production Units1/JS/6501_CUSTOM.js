function fnPostLoad_CUSTOM() {
	
	if(dataObj.action != 'REMOTEAUTH' && dataObj.action != 'VIEW' && dataObj.action != 'REVERSE'){
   document.getElementById("BLK_CLEARING_DETAILS__INSTRCCY").value = null;
	}
	
    return true;
    	
}