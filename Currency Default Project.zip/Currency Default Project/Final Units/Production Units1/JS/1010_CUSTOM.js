function fnPostLoad_CUSTOM() {
   
   if(dataObj.action != 'REMOTEAUTH' && dataObj.action != 'VIEW' && dataObj.action != 'REVERSE'){
   document.getElementById("BLK_TRANSACTION_DETAILS__INSTRCCY").value = null;
   }
	
    return true;
    	
}