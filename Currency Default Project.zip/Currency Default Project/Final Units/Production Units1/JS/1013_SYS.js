/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2020, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1013_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"PRD~XREF~BRN~TXNBRN~TXNACC~TXNAMT~TXNCCY~OFFSETBRN~OFFSETACC~OFFSETCCY~OFFSETAMT~XRATE~LCYAMT~TXNDATE~VALDATE~RELCUST~NARRATIVE~OFFSETLCYAMT~BOOKDATE~DENMCCY1~DENMAMT1~DRINSTCD~ACTAMT~ACCTITLE1~TCYTOTCHGAMT~MODULE~TXNTRN~OFFSETTRN~FT~CUSTNAME~NEGOTRATE~NEGOTREFNO~REJECTFLAG~INSTRDATE~CHEQUE_ISSUE_DATE~REJECT_CODE~BENFADDR1~BENFADDR2~BENFADDR3~BENFADDR4~DENMAMT2~CHAR_FIELD31~CHAR_FIELD32~CHAR_FIELD33~CHAR_FIELD34~CHAR_FIELD36~CHAR_FIELD37~CHAR_FIELD40"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">PRD~XREF~BRN~TXNBRN~TXNACC~TXNAMT~TXNCCY~OFFSETBRN~OFFSETACC~OFFSETCCY~OFFSETAMT~XRATE~LCYAMT~TXNDATE~VALDATE~RELCUST~NARRATIVE~OFFSETLCYAMT~BOOKDATE~DENMCCY1~DENMAMT1~DRINSTCD~ACTAMT~ACCTITLE1~TCYTOTCHGAMT~MODULE~TXNTRN~OFFSETTRN~FT~CUSTNAME~NEGOTRATE~NEGOTREFNO~REJECTFLAG~INSTRDATE~CHEQUE_ISSUE_DATE~REJECT_CODE~BENFADDR1~BENFADDR2~BENFADDR3~BENFADDR4~DENMAMT2~CHAR_FIELD31~CHAR_FIELD32~CHAR_FIELD33~CHAR_FIELD34~CHAR_FIELD36~CHAR_FIELD37~CHAR_FIELD40</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1013.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1013.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__TXNACC__LOV_TXNACC":["BLK_TRANSACTION_DETAILS__TXNACC~BLK_TRANSACTION_DETAILS__ACCTITLE1~BLK_TRANSACTION_DETAILS__TXNCCY~BLK_TRANSACTION_DETAILS__TXNBRN~~","","N~N~N~N",""],"BLK_TRANSACTION_DETAILS__OFFSETCCY__LOV_CCY":["BLK_TRANSACTION_DETAILS__OFFSETCCY~~","","",""],"BLK_TRANSACTION_DETAILS__REJECT_CODE__LOV_REJECT_CODE":["BLK_TRANSACTION_DETAILS__REJECT_CODE~~","","N~N",""],"BLK_TRANSACTION_DETAILS__CHAR_FIELD34__LOV_PURPOSE_OF_TXN":["BLK_TRANSACTION_DETAILS__CHAR_FIELD34~","","N",""],"BLK_TRANSACTION_DETAILS__CHAR_FIELD36__LOV_UNIQUE_ID_NAME":["BLK_TRANSACTION_DETAILS__CHAR_FIELD36~","","N",""],"BLK_TRANSACTION_DETAILS__CHAR_FIELD40__LOV_PARTICIPANT_NO":["BLK_TRANSACTION_DETAILS__CHAR_FIELD40~BLK_TRANSACTION_DETAILS__CHAR_FIELD32~BLK_TRANSACTION_DETAILS__CHAR_FIELD33~BLK_TRANSACTION_DETAILS__CHAR_FIELD36~BLK_TRANSACTION_DETAILS__CHAR_FIELD37~","","N~N~N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_BODY';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","CHCD~BLK_TRANSACTION_DETAILS","DMCD~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("DETBS_RTL_TELLER.XREF=MIVWS_MIS_DETAILS.XREF","DETBS_RTL_TELLER.XREF=UDVWS_UDF_DETAILS.XREF","DETBS_RTL_TELLER.XREF=CSTBS_WBCHARGE_DETAILS.XREF","DETBS_RTL_TELLER.XREF=CSTBS_WBDENOM_MASTER.XREF"); 

 var CallRelatType= new Array("1","N","N","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1013"]="KERNEL";
ArrPrntFunc["1013"]="";
ArrPrntOrigin["1013"]="";
ArrRoutingType["1013"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1013"]="N";
ArrCustomModified["1013"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"MDCD":"","UDCD":"","CHCD":"","DMCD":""};
var scrArgSource = {"MDCD":"","UDCD":"","CHCD":"","DMCD":""};
var scrArgVals = {"MDCD":"","UDCD":"","CHCD":"","DMCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"MDCD":"","UDCD":"","CHCD":"","DMCD":""};
var dpndntOnSrvs = {"MDCD":"","UDCD":"","CHCD":"","DMCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------