function fnPostLoad_CUSTOM() {

   document.getElementById("BLK_TRANSACTION_DETAILS__INSTRCCY").value = null;
	
    return true;
    	
}