function fnPostLoad_CUSTOM() {
   document.getElementById("BLK_CLEARING_DETAILS__INSTRCCY").value = null;
	
    return true;
    	
}