function fnPostNew_CUSTOM() {
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value=null;
if (document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD31").checked) {
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD32"));
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD33"));
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD40"));
}
return true;
}

function fnDisableElements(event){
	if (document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD31").checked) {
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD32"));
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD33"));
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD40"));
}else{
	fnEnableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD32"));
fnEnableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD33"));
fnEnableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD40"));
}
	return true;
}