# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant
from scipy.stats import chi2_contingency

# Load loan dataset
df = pd.read_csv('loan.csv')

# Define target variable
target = 'default'

# Define categorical variables
cat_vars = ['home_ownership', 'purpose', 'term', 'grade', 'sub_grade']

# Define continuous variables # continuous variables are nothing but numeric variables
cont_vars = ['loan_amnt', 'int_rate', 'installment', 'annual_inc', 'dti', 'revol_util', 'inq_last_6mths', 'open_acc', 'pub_rec', 'total_acc']

# Convert target variable to binary
df[target] = np.where(df[target] == 'Yes', 1, 0)

# Define function to calculate WOE and IV
def calc_woe_iv(df, var, target):
    df = df[[var, target]]
    df.dropna(inplace=True)
    
    total_good = df[target].value_counts()[0]
    total_bad = df[target].value_counts()[1]
    
    groups = df.groupby(var).agg({target: ['count', 'sum']})
    groups.columns = ['total', 'bad']
    
    groups['good'] = groups['total'] - groups['bad']
    
    groups['pct_good'] = groups['good'] / total_good
    groups['pct_bad'] = groups['bad'] / total_bad
    
    groups['woe'] = np.log(groups['pct_good'] / groups['pct_bad'])
    
    groups['iv'] = (groups['pct_good'] - groups['pct_bad']) * groups['woe']
    iv = groups['iv'].sum()
    
    return groups, iv

# Calculate WOE and IV for categorical variables
cat_woe_iv = {}
for var in cat_vars:
    groups, iv = calc_woe_iv(df, var, target)
    cat_woe_iv[var] = {'groups': groups, 'iv': iv}
    
# Calculate WOE and IV for continuous variables
cont_woe_iv = {}
for var in cont_vars:
    df[var+'_bin'] = pd.cut(df[var], bins=10, duplicates='drop')
    groups, iv = calc_woe_iv(df, var+'_bin', target)
    cont_woe_iv[var] = {'groups': groups, 'iv': iv}
    df.drop(columns=[var+'_bin'], inplace=True)

# Calculate IV for all variables
var_iv = {}
for var in cat_vars + cont_vars:
    if var in cat_vars:
        iv = cat_woe_iv[var]['iv']
    else:
        iv = cont_woe_iv[var]['iv']
    var_iv[var] = iv

# Plot IV for all variables
plt.figure(figsize=(10,6))
sns.barplot(x=list(var_iv.keys()), y=list(var_iv.values()))
plt.xlabel('Variable')
plt.ylabel('IV')
plt.title('Information Value (IV) per variable')
plt.xticks(rotation=90)
plt.show()

# Select variables with IV > 0.02
selected_vars = [k for k, v in var_iv.items() if v > 0.02]

# Create dummy variables for categorical variables
for var in cat_vars:
    if var in selected_vars:
        dummies = pd.get_dummies(df[var], prefix=var, drop_first=True)
        df = pd.concat([df, dummies], axis=1)
        df.drop(columns=[var], inplace=True)

# Split data into train and test sets
X = df[selected_vars]
y = df[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Fit logistic regression model
lr = LogisticRegression()
lr.fit(X_train, y_train)

# Predict on test set and calculate accuracy and ROC AUC score
y_pred = lr.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("ROC AUC score:", roc_auc_score(y_test, y_pred))

# Check for multicollinearity
X_train = add_constant(X_train)
vif = pd.DataFrame([variance_inflation_factor(X_train.values, i) for i in range(X_train.shape[1])], index=X_train.columns)
vif = vif.iloc[1:]
vif.columns = ['VIF']
print(vif)

# Calculate scorecard points and coefficients
intercept = lr.intercept_[0]
coefficients = lr.coef_[0]
points = {}
for i, var in enumerate(selected_vars):
    woe_groups = cat_woe_iv[var]['groups'] if var in cat_vars else cont_woe_iv[var]['groups']
    woe_dict = dict(zip(woe_groups.index, woe_groups['woe']))
    if var in cat_vars:
        var_dummies = [col for col in X.columns if col.startswith(var)]
        for k, v in woe_dict.items():
            points[var+'_'+k] = round(coefficients[i] * v * len(df[df[var].isin([k])]) / df.shape[0], 2)
    else:
        var_bin = var+'_bin'
        for k, v in woe_dict.items():
            points[var_bin+'_'+k] = round(coefficients[i] * v * len(df[df[var_bin].isin([k])]) / df.shape[0], 2)

# Print scorecard
print("Scorecard Points:\n", points)
print("\nIntercept:", intercept)


# Calculate score for a sample borrower
sample = {'home_ownership': 'MORTGAGE', 'loan_amnt': 10000, 'annual_inc': 50000, 'int_rate': 10.99, 'dti': 10, 'inq_last_6mths': 2, 'revol_util': 50, 'total_acc': 10, 'open_acc': 5, 'pub_rec': 0, 'purpose': 'debt_consolidation', 'sub_grade': 'C1', 'term': ' 36 months', 'grade': 'C


# Calculate score for a sample borrower
score = intercept
for var in sample:
    if var in cat_vars:
        woe_groups = cat_woe_iv[var]['groups']
        woe_dict = dict(zip(woe_groups.index, woe_groups['woe']))
        if sample[var] in woe_dict:
            score += points[var+'_'+sample[var]]
    else:
        var_bin = var+'_bin'
        woe_groups = cont_woe_iv[var]['groups']
        woe_dict = dict(zip(woe_groups.index.astype(str), woe_groups['woe']))
        sample_bin = pd.cut([sample[var]], bins=woe_groups.index.astype(float))
        if sample_bin[0].left in woe_dict:
            score += points[var_bin+'_'+str(sample_bin[0].left)]
            
print("Score:", round(score, 2))


This code calculates the score for a sample borrower based on the credit scorecard points and coefficients calculated earlier. It first initializes the score with the intercept value, and then iterates through each variable in the sample borrower's data. For categorical variables, it looks up the WOE value for the borrower's value and adds the corresponding scorecard points to the score. For continuous variables, it first bins the borrower's value using the same bins as used in the WOE calculation, and then adds the corresponding scorecard points to the score.

Note that the scorecard points and coefficients as well as the score calculated for the sample borrower are just examples and would need to be updated based on your specific data and business needs.