insert into swtm_fcliteral_code (PROC_CODE_TYPE, FC_LITERAL, EXT_TXN_CODE, DESCRIPTION, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CHANNEL, ATM_SUPPORT, POS_SUPPORT, IVR_SUPPORT)
values ('29', 'PCT', null, null, 'O', 'A', 2, 'SYSTEM', to_date('03-04-2021 15:34:49', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:34:49', 'dd-mm-yyyy hh24:mi:ss'), 'Y', null, null, null, null);

COMMIT;
