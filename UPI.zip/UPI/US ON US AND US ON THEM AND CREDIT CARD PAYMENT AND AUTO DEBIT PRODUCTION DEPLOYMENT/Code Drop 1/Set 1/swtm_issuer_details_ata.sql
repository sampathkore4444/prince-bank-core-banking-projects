insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('62630117', 'UPI Credit Card - Classic', null, null, null, null, null, null, null, null, 'CREDITCARDU');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('62630116', 'UPI Credit Card - Diamond', null, null, null, null, null, null, null, null, 'CREDITCARDU');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('6229346', 'UPI Debit Card - Classic', null, null, null, null, null, null, null, null, 'PRINCE');

insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('6263011', 'UPI Credit Card - Classic', null, null, null, null, null, null, null, null, 'CREDITCARDU');

COMMIT;
