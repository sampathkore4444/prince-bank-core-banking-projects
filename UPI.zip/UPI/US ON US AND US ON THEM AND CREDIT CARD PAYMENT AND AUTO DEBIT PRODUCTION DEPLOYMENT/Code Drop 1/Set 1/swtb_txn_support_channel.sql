insert into swtb_txn_support_channel (FC_LITERAL, DESCRIPTION, ATM_SUPPORT, POS_SUPPORT, IVR_SUPPORT, CHANNEL)
values ('PCT', null, null, null, null, 'POS');

COMMIT;
