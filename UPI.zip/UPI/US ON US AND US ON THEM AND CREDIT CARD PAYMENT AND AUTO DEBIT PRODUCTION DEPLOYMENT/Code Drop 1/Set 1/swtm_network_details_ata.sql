insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('CREDITCARDU', '114100001', 'Credit Card Network UPI', 'SYSTEM', to_date('14-01-2020 14:35:07', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('14-01-2020 14:35:07', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 2);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPI', '114100001', 'UPI Card Network', 'SYSTEM', to_date('14-01-2020 12:53:18', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('14-01-2020 12:53:18', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPICPY', '114100001', 'PCT - UPI Card Network Cash Payment', 'SYSTEM', to_date('03-04-2021 15:43:04', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:43:04', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPIGPAY', '114100001', 'PCT - UPI Card Network General Payment', 'SYSTEM', to_date('03-04-2021 15:43:04', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:43:04', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('CCPAYUPI', '114100001', 'Credit Card Payment Network for UPI', 'SYSTEM', to_date('06-01-2020 16:14:12', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-01-2020 16:14:12', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPIDSB', '114100001', 'PCT - UPI Card Network Fund Disbursement', 'SYSTEM', to_date('03-04-2021 15:42:44', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:42:44', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPIDFT', '114100001', 'PCT - UPI Card Network Domestic FT', 'SYSTEM', to_date('03-04-2021 15:43:04', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:43:04', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPIMS', '114100001', 'PCT - UPI Card Network Merchant Settlement', 'SYSTEM', to_date('03-04-2021 14:33:27', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 14:33:27', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 2);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPICR', '114100001', 'PCT - UPI Card Network Cash Rebate', 'SYSTEM', to_date('03-04-2021 15:42:18', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:42:18', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPIOTR', '114100001', 'PCT - UPI Card Network Online Tax Refund', 'SYSTEM', to_date('03-04-2021 15:42:44', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:42:44', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

COMMIT;
