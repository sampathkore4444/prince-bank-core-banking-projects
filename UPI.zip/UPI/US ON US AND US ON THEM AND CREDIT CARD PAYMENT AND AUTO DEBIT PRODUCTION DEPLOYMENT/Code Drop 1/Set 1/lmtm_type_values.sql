insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('FCLITERAL', 'PRIMARY CREDIT TRANSACTIONS', 'PCT');

COMMIT;
