insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('BEQ', 'R', 'BLR2', 'O', 'A', 1, 'SYSTEM', to_date('14-01-2020 11:43:25', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('14-01-2020 11:43:25', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'ATM');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('CAB', 'R', 'CAB2', 'O', 'A', 1, 'SYSTEM', to_date('14-01-2020 11:45:18', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('14-01-2020 11:45:18', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('CAW', 'R', 'CWR2', 'O', 'A', 1, 'SYSTEM', to_date('14-01-2020 11:43:57', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('14-01-2020 11:43:57', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'ATM');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('CCP', 'O', 'CCPU', 'O', 'A', 1, 'SYSTEM', to_date('03-04-2021 17:19:07', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 17:19:07', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'CCPAYUPI', 'ALL', 'ATM');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('NPA', 'R', 'NPR2', 'O', 'A', 1, 'SYSTEM', to_date('14-01-2020 11:44:39', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('14-01-2020 11:44:39', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('PCT', 'R', 'PCT7', 'O', 'A', 1, 'SYSTEM', to_date('03-04-2021 14:42:15', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 14:42:15', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPIDSB', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('PCT', 'R', 'PCT3', 'O', 'A', 1, 'SYSTEM', to_date('03-04-2021 15:45:25', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:45:25', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPIOTR', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('CCP', 'O', 'CCPU', 'O', 'A', 1, 'SYSTEM', to_date('03-04-2021 17:20:18', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 17:20:18', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'CCPAYUPI', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('PCT', 'R', 'PCT6', 'O', 'A', 1, 'SYSTEM', to_date('03-04-2021 14:38:40', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 14:38:40', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPIMS', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('PCT', 'R', 'PCT5', 'O', 'A', 2, 'SYSTEM', to_date('03-04-2021 14:20:33', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 14:20:33', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPICPY', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('PCT', 'R', 'PCT2', 'O', 'A', 1, 'SYSTEM', to_date('03-04-2021 15:44:09', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:44:09', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPICR', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('PCT', 'R', 'PCT4', 'O', 'A', 1, 'SYSTEM', to_date('03-04-2021 15:45:56', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:45:56', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPIDFT', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('PCT', 'R', 'PCT1', 'O', 'A', 1, 'SYSTEM', to_date('03-04-2021 15:36:57', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('03-04-2021 15:36:57', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPIGPAY', 'ALL', 'POS');

COMMIT;
