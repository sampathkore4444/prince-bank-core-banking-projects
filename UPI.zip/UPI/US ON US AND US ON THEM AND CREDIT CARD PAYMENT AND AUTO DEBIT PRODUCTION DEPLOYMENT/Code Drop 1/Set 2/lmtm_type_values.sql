insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('CREDIT_CARD_ACCS', '389220013', 'UCCP');

COMMIT;
