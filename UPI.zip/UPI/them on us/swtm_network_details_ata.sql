insert into swtm_network_details_ata (NETWORK_ID, ACCOUNT_NO, DESCRIPTION, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ACCOUNT_BRANCH, MOD_NO)
values ('UPI', '114100001', 'UPI Card Network', 'SAMPATH2', to_date('14-01-2020 12:53:18', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:53:18', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', null, 1);

COMMIT;
