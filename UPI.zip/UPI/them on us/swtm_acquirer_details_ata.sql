insert into swtm_acquirer_details_ata (ACQ_BIN, ACQ_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('44120116', 'UPI', null, null, null, null, null, null, null, null, 'PRINCE');

COMMIT;
