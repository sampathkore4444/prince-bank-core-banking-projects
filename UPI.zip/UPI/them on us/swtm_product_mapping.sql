insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('CAW', 'F', 'ACWU', 'O', 'A', 1, 'SAMPATH2', to_date('14-01-2020 12:54:13', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:54:13', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'ATM');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('BEQ', 'F', 'BLQU', 'O', 'A', 1, 'SAMPATH2', to_date('14-01-2020 12:55:20', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:55:20', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'ATM');

COMMIT;
