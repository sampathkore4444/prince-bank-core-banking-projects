insert into swtm_issuer_details_ata (ISS_BIN, ISS_DESC, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, NETWORK_ID)
values ('62293465', 'UPI Debit Classic', null, null, null, null, null, null, null, null, 'UPI');

COMMIT;
