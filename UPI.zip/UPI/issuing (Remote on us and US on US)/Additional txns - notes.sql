General Payment -   PCT1
Cash Rebate		-   PCT2
Online Tax Refund - PCT3
Domestic P2P	  - PCT4
MoneyExpress	  - PCT5 