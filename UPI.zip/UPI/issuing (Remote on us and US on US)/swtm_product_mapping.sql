insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('BEQ', 'R', 'BLR2', 'O', 'A', 1, 'SAMPATH2', to_date('14-01-2020 11:43:25', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:43:25', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'ATM');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('CAW', 'R', 'CWR2', 'O', 'A', 1, 'SAMPATH2', to_date('14-01-2020 11:43:57', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:43:57', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'ATM');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('NPA', 'R', 'NPR2', 'O', 'A', 1, 'SAMPATH2', to_date('14-01-2020 11:44:39', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:44:39', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('CAB', 'R', 'CAB2', 'O', 'A', 1, 'SAMPATH2', to_date('14-01-2020 11:45:18', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:45:18', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'UPI', 'ALL', 'POS');

COMMIT;
