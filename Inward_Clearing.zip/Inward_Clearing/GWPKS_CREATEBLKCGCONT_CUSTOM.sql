CREATE OR REPLACE PACKAGE BODY gwpks_createblkcgcont_custom IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('CG', 'gwpks_createblkcgcont_custom : ' || P_MSG);
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END DBG;

  FUNCTION FN_DDCONTRACT_RES_FULL(P_SOURCE         IN VARCHAR2,
                                  P_FCCREF         IN VARCHAR2,
                                  P_XREF           IN VARCHAR2,
                                  P_NODE           IN VARCHAR2,
                                  P_DATA           IN OUT VARCHAR2,
                                  P_KEY            IN OUT VARCHAR2,
                                  P_PARENT         IN OUT VARCHAR2,
                                  P_FORMAT         IN OUT VARCHAR2,
                                  P_UPL_CONT_REC   IN CSVW_BC_DD_MASTER%ROWTYPE,
                                  P_BC_DD_DET      IN GWPKS_CREATEBLKCGCONTRACT.TY_BC_DD_UPLD_REC,
                                  P_ERRS           IN OUT VARCHAR2,
                                  P_PRMS           IN OUT VARCHAR2,
                                  P_CALL_FN_ID     IN OUT NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    
     --sampath starts
    l_count    NUMBER;
    l_err_code ertb_msgs.err_code%type;
    l_type     ertb_msgs.type%type;
    --sampath ends
    
  BEGIN
    DBG('In  fn_ddcontract_res_full..of gwpks_createblkcgcont_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);
        
        --sampath starts
  
    IF P_ERRS IS NOT NULL THEN
      dbg('coming inside with errors:' || P_ERRS);
      l_count := REGEXP_COUNT(P_ERRS, ';');
      IF l_count > 0 THEN
        FOR i IN REVERSE 1 .. l_count LOOP
          l_err_code := Cspkes_Misc.Fn_Getparam(P_ERRS, i, ';');
          dbg('l_err_code is ' || l_err_code);
          l_type := ovpks.Fn_Gettype(l_err_code);
          dbg('l_type is ' || l_type);
          IF l_type = 'E' THEN
            P_ERRS := l_err_code;
            dbg('Final error code is @@ ' || P_ERRS);
            EXIT;
          END IF;
        END LOOP;
      END IF;
    END IF;
  
    dbg('The error code to get the response map is ' || P_ERRS);
  
    IF P_ERRS = 'AC-PRINDORM' THEN
      DBG('INSIDE IF');
      OVPKS.PR_APPENDTBL('AC-PRINDORM', P_PRMS);
      RETURN FALSE;
    END IF;
  
    IF P_ERRS = 'AC-VAC07' THEN
      DBG('INSIDE IF');
      OVPKS.PR_APPENDTBL('AC-VAC07', P_PRMS);
      RETURN FALSE;
    END IF;
  
    IF P_ERRS = 'AC-VAC04' THEN
      DBG('INSIDE IF');
      OVPKS.PR_APPENDTBL('AC-VAC04', P_PRMS);
      RETURN FALSE;
    END IF;
  
    IF P_ERRS = 'CA-PRINCHQ1' THEN
      DBG('INSIDE IF');
      OVPKS.PR_APPENDTBL('CA-PRINCHQ1', P_PRMS);
      RETURN FALSE;
    END IF;
  
    IF P_ERRS = 'CA-PRINCHQ2' THEN
      DBG('INSIDE IF');
      OVPKS.PR_APPENDTBL('CA-PRINCHQ2', P_PRMS);
      RETURN FALSE;
    END IF;
  
    IF P_ERRS = 'CA-PRINCHQ3' THEN
      DBG('INSIDE IF');
      OVPKS.PR_APPENDTBL('CA-PRINCHQ3', P_PRMS);
      RETURN FALSE;
    END IF;
  
    IF SUBSTR(P_ERRS, 1, INSTR(P_ERRS, ';', 1)) = 'AC-PRINDORM' THEN
      DBG('INSIDE IF');
      OVPKS.PR_APPENDTBL('AC-PRINDORM', P_PRMS);
      RETURN FALSE;
    END IF;
    --sampath ends
  
    DBG('In  Retruning Successfully from gwpks_createblkcgcont_custom.fn_ddcontract_res_full');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_createblkcgcont_custom.fn_ddcontract_res_full..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_DDCONTRACT_RES_FULL;

  FUNCTION FN_TS_TO_TYPE(PRECTYPE         IN VARCHAR2,
                         PKEY             IN VARCHAR2,
                         PDATA            IN VARCHAR2,
                         P_UPL_CONT_REC   IN OUT CSVW_BC_DD_MASTER%ROWTYPE,
                         P_UPL_MIS_DET    IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                         P_UPL_UDF_DET    IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                         P_UPL_CHG_DET    IN OUT DDPKS_UPLOAD_CONTRACT_CREATE.TYP_TBLCHGDETS,
                         P_BC_DD_DET      IN OUT GWPKS_CREATEBLKCGCONTRACT.TY_BC_DD_UPLD_REC,
                         P_ERR_CODE       IN OUT VARCHAR2,
                         P_ERR_PARAM      IN OUT VARCHAR2,
                         P_CALL_FN_ID     IN OUT NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In  fn_ts_to_type..of gwpks_createblkcgcont_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);
  
    DBG('In  Retruning Successfully from gwpks_createblkcgcont_custom.fn_ts_to_type');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_createblkcgcont_custom.fn_ts_to_type..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_TS_TO_TYPE;

END GWPKS_CREATEBLKCGCONT_CUSTOM;
