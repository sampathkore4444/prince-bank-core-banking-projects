CREATE OR REPLACE PACKAGE BODY cgpks_inward_clg_new_custom AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'Cgpks_Inward_clg_New_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('CG', L_MSG);
  END DBG;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;
  
  --sampath starts
    PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                           p_Source      VARCHAR2,
                           p_Err_Code    VARCHAR2,
                           p_Err_Params  VARCHAR2) IS
    BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                   p_Function_Id,
                                   p_Err_Code,
                                   p_Err_Params);
    END Pr_Log_Error;
    --sampath ends

  FUNCTION FN_PRE_VALIDATE_UPLOAD(P_CLG_REC  IN CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                                  P_ERR_CODE IN OUT VARCHAR2,
                                  P_ERR_MESG IN OUT VARCHAR2,
                                  P_ERR_TBL  IN OUT OVPKS.TBL_ERROR)
    RETURN BOOLEAN IS
    
    --sampath starts
      L_STTB_ACCOUNT    STTB_ACCOUNT%ROWTYPE;
      L_STATUS          VARCHAR2(100);
      L_COUNT           NUMBER;
      L_ACCOUNT_BALANCE STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
      L_ERROR_CODE      VARCHAR2(100);
      L_ERROR_MSG       ERTB_MSGS.MESSAGE%TYPE;
      L_STTM_DATES STTM_DATES%ROWTYPE;
       CHK_REC_COUNT   NUMBER;
      credit_limit_exceed EXCEPTION;
    PRAGMA exception_init(credit_limit_exceed, -20111);
      --sampath ends
      
  BEGIN
    DBG('Inside Cgpks_Inward_clg_New_custom.Fn_Pre_validate_upload');
    
     DBG('ACTION CODE='||GWPKS_UTIL.pkg_actType);
    DBG('ACTION CODE='||GWPKS_UTIL.PKG_FUNC);
    DBG('P_CLG_REC.REM_ACCOUNT='||P_CLG_REC.REM_ACCOUNT);
    
    --sampath starts
      IF GWPKS_UTIL.pkg_actType = 'SAVEAUTOAUTH' AND P_CLG_REC.REM_ACCOUNT IS NOT NULL THEN
      
        BEGIN
          SELECT *
            INTO L_STTB_ACCOUNT
            FROM STTB_ACCOUNT
           WHERE AC_GL_NO = P_CLG_REC.REM_ACCOUNT;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_STTB_ACCOUNT := NULL;
            DBG('FAILED IN GETTING ACCOUNT DETAILS');
        END;
      
        DBG('L_STTB_ACCOUNT.AC_STAT_DORMANT=' ||
            L_STTB_ACCOUNT.AC_STAT_DORMANT);
        DBG('L_STTB_ACCOUNT.AC_STAT_FROZEN=' ||
            L_STTB_ACCOUNT.AC_STAT_FROZEN);
        DBG('L_STTB_ACCOUNT.AC_STAT_NO_DR=' ||
            L_STTB_ACCOUNT.AC_STAT_NO_DR);
      
        --Dormant
        IF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
          DBG('INSIDE DORMANCY');
          P_ERR_CODE := 'AC-PRINDORM';
          P_ERR_MESG := P_CLG_REC.REM_ACCOUNT;
         OVPKS.PR_APPENDTBL('AC-PRINDORM', P_CLG_REC.REM_ACCOUNT);
         
         --PR_LOG_ERROR('5555', 'FLEXCUBE', 'AC-PRINDORM', NULL);
         --raise_application_error(-20111,'Credit Limit Exceeded');
         --RETURN FALSE;
         --Pr_Log_Error('5555','FLEXCUBE','AC-PRINDORM','P_REC_CLG_UPLD.REMACCOUNT');
          --Pr_Log_Error('5555','FLEXCUBE','AC-VAC05','P_REC_CLG_UPLD.REMACCOUNT');
          RETURN FALSE;
        
        END IF;
      
        --Frozen
        IF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
          DBG('INSIDE FROZEN');
          P_ERR_CODE := 'AC-VAC04';
          P_ERR_MESG := P_CLG_REC.REM_ACCOUNT;
          OVPKS.PR_APPENDTBL('AC-VAC04', P_CLG_REC.REM_ACCOUNT);
          RETURN FALSE;
        END IF;
      
        --No Debit
        IF L_STTB_ACCOUNT.AC_STAT_NO_DR = 'Y' THEN
          DBG('INSIDE NO-DEBIT');
          P_ERR_CODE := 'AC-VAC07';
          P_ERR_MESG := P_CLG_REC.REM_ACCOUNT;
          OVPKS.PR_APPENDTBL('AC-VAC07', P_CLG_REC.REM_ACCOUNT);
          RETURN FALSE;
        END IF;
      
        DBG('   ' || P_CLG_REC.BRANCH_CODE);
        DBG('P_REC_CLG_UPLD.ACC_BRANCH=' || P_CLG_REC.ACC_BRANCH);
        DBG('P_REC_CLG_UPLD.BRANCH_CODE=' || P_CLG_REC.BRANCH_CODE);
        DBG('P_REC_CLG_UPLD.TXN_BRN=' || P_CLG_REC.TXN_BRANCH);
      
        DBG('P_REC_CLG_UPLD.REMACCOUNT=' || P_CLG_REC.REM_ACCOUNT);
        DBG('P_REC_CLG_UPLD.INSTRNO=' || P_CLG_REC.INSTRUMENT_NO_1);
      
        DBG('P_REC_CLG_UPLD.INSTRAMT=' || P_CLG_REC.INSTRUMENT_AMT);
      
        --Check Balance of an account
        BEGIN
          IF NOT ACPKSS_MISC.FN_GETAVLBAL(P_CLG_REC.ACC_BRANCH,
                                          P_CLG_REC.REM_ACCOUNT,
                                          L_ACCOUNT_BALANCE,
                                          'Y') THEN
            DBG('Unable to fetch Transaction account Amount');
          ELSE
            DBG('BALANCE OF AN ACCOUNT=' || L_ACCOUNT_BALANCE);
          END IF;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('The error occured at line:' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          
            DBG('Failure in fetching the Available balance fr the transaction account');
        END;
      
        IF L_ACCOUNT_BALANCE < P_CLG_REC.INSTRUMENT_AMT THEN
        
          IFPKSS_FIN_OVD.PR_REGISTER_OVD('CA-PRINCHQ4',
                                         P_CLG_REC.ACC_CCY,
                                         ABS(L_ACCOUNT_BALANCE));
        
          L_ERROR_CODE := L_ERROR_CODE || 'CA-PRINCHQ4;';
          L_ERROR_MSG  := L_ERROR_MSG || P_CLG_REC.REM_ACCOUNT || '~' ||
                          RTRIM(LTRIM(CSFNS_FORMAT_AMT(P_CLG_REC.ACC_CCY,
                                                       L_ACCOUNT_BALANCE))) || '~' ||
                          RTRIM(LTRIM(CSFNS_FORMAT_AMT(P_CLG_REC.ACC_CCY,
                                                       L_ACCOUNT_BALANCE))) || '~' || ';';
          DBG('L_ERROR_MSG=' || L_ERROR_MSG);
        
          --OVPKSS.PR_APPENDTBL('CA-PRINCHQ4',L_ERROR_MSG);
          PR_LOG_ERROR('5555', 'FLEXCUBE', 'CA-PRINCHQ4', NULL);
          
          --RETURN FALSE;
        
          --PR_LOG_ERROR('5555', 'FLEXCUBE', 'CA-PRINCHQ4', P_REC_CLG_UPLD.REMACCOUNT);
        
          --RETURN FALSE;
        END IF;
      
        --Check Delivery Status
        BEGIN
          SELECT B.REQUEST_STATUS
            INTO L_STATUS
            FROM CATM_CHECK_DETAILS A, CATM_CHECK_BOOK B
           WHERE A.BRANCH = B.BRANCH
             AND A.ACCOUNT = B.ACCOUNT
             AND A.CHECK_BOOK_NO = B.FIRST_CHECK_NO
             AND A.BRANCH = P_CLG_REC.ACC_BRANCH
             AND A.ACCOUNT = P_CLG_REC.REM_ACCOUNT
             AND A.CHECK_NO = P_CLG_REC.INSTRUMENT_NO_1;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error while geting the check book status' || SQLERRM ||
                SQLCODE);
        END;
      
        IF NVL(L_STATUS, 'Nothing') <> ('Delivered') THEN
          OVPKSS.PR_APPENDTBL('CA-PRINCHQ0', P_CLG_REC.INSTRUMENT_NO_1);
          RETURN FALSE;
        END IF;
      
        --Check Status
        BEGIN
        
          SELECT STATUS
            INTO L_STATUS
            FROM CATMS_CHECK_DETAILS
           WHERE MOD_NO = (
                           
                           SELECT MAX(MOD_NO)
                             FROM CATMS_CHECK_DETAILS
                            WHERE CHECK_NO = P_CLG_REC.INSTRUMENT_NO_1
                              AND BRANCH = P_CLG_REC.ACC_BRANCH
                              AND ACCOUNT = P_CLG_REC.REM_ACCOUNT)
             AND CHECK_NO = P_CLG_REC.INSTRUMENT_NO_1
             AND BRANCH = P_CLG_REC.ACC_BRANCH
             AND ACCOUNT = P_CLG_REC.REM_ACCOUNT;
        
        EXCEPTION
          WHEN OTHERS THEN
          
            OVPKS.PR_APPENDTBL('IF-DAT037', NULL);
            DBG('should return false');
            --RETURN FALSE;
        END;
      
        --Used Check
        IF L_STATUS = 'U' THEN
          P_ERR_CODE := 'CA-PRINCHQ1';
          P_ERR_MESG := P_CLG_REC.INSTRUMENT_NO_1;
          OVPKS.PR_APPENDTBL('CA-PRINCHQ1', P_CLG_REC.INSTRUMENT_NO_1);
          --RETURN FALSE;
        END IF;
      
        --Stop Payment Check
		BEGIN
         L_STTM_DATES := GLOBALS_FRC.FN_GET_BRN_DATE_FRC(P_CLG_REC.ACC_BRANCH);

      DBG('l_branch_date is - ' || L_STTM_DATES.TODAY);
            SELECT COUNT(*)
              INTO CHK_REC_COUNT
              FROM CATMS_STOP_PAYMENTS
             WHERE BRANCH = P_CLG_REC.ACC_BRANCH
               AND STOP_PAYMENT_TYPE = 'C'
               AND NOT (RECORD_STAT = 'C' AND AUTH_STAT = 'A')
               AND

                   (P_CLG_REC.INSTRUMENT_NO_1 BETWEEN START_CHECK_NO AND END_CHECK_NO)
               AND

                   L_STTM_DATES.TODAY BETWEEN EFFECTIVE_DATE AND
                   NVL(EXPIRY_DATE, L_STTM_DATES.TODAY)

               AND ACCOUNT = P_CLG_REC.REM_ACCOUNT;
        
        EXCEPTION
		WHEN OTHERS THEN
		CHK_REC_COUNT := 0;
		END;
		
		DBG('CHK_REC_COUNT='||CHK_REC_COUNT);
		
        IF CHK_REC_COUNT >0 /*L_STATUS = 'S'*/ THEN
          P_ERR_CODE := 'CA-PRINCHQ2';
          P_ERR_MESG := P_CLG_REC.INSTRUMENT_NO_1;
          OVPKS.PR_APPENDTBL('CA-PRINCHQ2', P_CLG_REC.INSTRUMENT_NO_1);
          --RETURN FALSE;
        END IF;
      
        --Cancelled Check
        IF L_STATUS = 'C' THEN
          P_ERR_CODE := 'CA-PRINCHQ3';
          P_ERR_MESG := P_CLG_REC.INSTRUMENT_NO_1;
          OVPKS.PR_APPENDTBL('CA-PRINCHQ3', P_CLG_REC.INSTRUMENT_NO_1);
          --RETURN FALSE;
        END IF;
      
      END IF;
    
    --sampath ends

    DBG('Returning sucess Cgpks_Inward_clg_New_custom.Fn_Pre_validate_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Cgpks_Inward_clg_New_custom.Fn_Pre_validate_upload..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_VALIDATE_UPLOAD;

  FUNCTION FN_POST_VALIDATE_UPLOAD(P_CLG_REC  IN CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                                   P_ERR_CODE IN OUT VARCHAR2,
                                   P_ERR_MESG IN OUT VARCHAR2,
                                   P_ERR_TBL  IN OUT OVPKS.TBL_ERROR)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Cgpks_Inward_clg_New_custom.Fn_Post_validate_upload');

    DBG('Returning sucess Cgpks_Inward_clg_New_custom.Fn_Post_validate_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Cgpks_Inward_clg_New_custom.Fn_Post_validate_upload..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_VALIDATE_UPLOAD;

  FUNCTION FN_PRE_AUTO_REJECT(P_ENTRY_REC         IN OUT CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                              P_CHARGE_APPLICABLE IN CSTB_CLG_REJ_REASON.UPDATE_CHQ_RET_IN_CUSTAC%TYPE,
                              P_CHARGE_PROD       IN CSTB_CLG_REJ_REASON.CHARGE_PROD_IW%TYPE,
                              P_UPD_RETN_TO_ACC   IN CSTB_CLG_REJ_REASON.UPDATE_CHQ_RET_IN_CUSTAC%TYPE,
                              P_ERR_CODE          IN OUT VARCHAR2,
                              P_ERR_MESG          IN OUT VARCHAR2,
                              P_ACCOUNT_VALID     IN BOOLEAN DEFAULT TRUE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Cgpks_Inward_clg_New_custom.fn_pre_auto_reject');

    DBG('Returning sucess Cgpks_Inward_clg_New_custom.fn_pre_auto_reject');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Cgpks_Inward_clg_New_custom.fn_pre_auto_reject..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_AUTO_REJECT;

  FUNCTION FN_POST_AUTO_REJECT(P_ENTRY_REC         IN OUT CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                               P_CHARGE_APPLICABLE IN CSTB_CLG_REJ_REASON.UPDATE_CHQ_RET_IN_CUSTAC%TYPE,
                               P_CHARGE_PROD       IN CSTB_CLG_REJ_REASON.CHARGE_PROD_IW%TYPE,
                               P_UPD_RETN_TO_ACC   IN CSTB_CLG_REJ_REASON.UPDATE_CHQ_RET_IN_CUSTAC%TYPE,
                               P_ERR_CODE          IN OUT VARCHAR2,
                               P_ERR_MESG          IN OUT VARCHAR2,
                               P_ACCOUNT_VALID     IN BOOLEAN DEFAULT TRUE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Cgpks_Inward_clg_New_custom.fn_post_auto_reject');

    DBG('Returning sucess Cgpks_Inward_clg_New_custom.fn_post_auto_reject');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Cgpks_Inward_clg_New_custom.fn_post_auto_reject..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_AUTO_REJECT;

  FUNCTION FN_PRE_CHG_PROC(PBRANCH          IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                           P_ENTRY_REC      IN OUT CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                           P_CHG_ROW        IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                           P_ERR_CODE       IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                           P_ERRPARAM       IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                           P_ACC_HAND       IN OUT ACPKS.TBL_ACHOFF,
                           P_FN_CALL_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)

   RETURN BOOLEAN IS
  BEGIN
    DBG('inside cgpks_inward_clg_new_custom.FN_pre_CHG_PROC..');
    DBG('cgpks_inward_clg_new_custom.FN_pre_CHG_PROC Process completed successfully');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in cgpks_inward_clg_new_custom.FN_pre_CHG_PROC' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PRE_CHG_PROC;

  FUNCTION FN_POST_CHG_PROC(PBRANCH          IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                            P_ENTRY_REC      IN OUT CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                            P_CHG_ROW        IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                            P_ERR_CODE       IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                            P_ERRPARAM       IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                            P_ACC_HAND       IN OUT ACPKS.TBL_ACHOFF,
                            P_FN_CALL_ID     IN OUT NUMBER,
                            P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)

   RETURN BOOLEAN IS
  BEGIN
    DBG('inside cgpks_inward_clg_new_custom.FN_post_CHG_PROC..');
    DBG('cgpks_inward_clg_new_custom.FN_CHG_PROC Process completed successfully');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in cgpks_inward_clg_new_custom.FN_post_CHG_PROC' ||
          SQLERRM);
      RETURN FALSE;
  END FN_POST_CHG_PROC;

  FUNCTION FN_PROCESS_A_RECORD(P_CLG_REC        IN OUT CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                               P_FN_CALL_ID     IN OUT NUMBER,
                               P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_ERR_MESG       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Calling cgpks_inward_clg_new_custom.fn_process_a_record');

    DBG('cgpks_inward_clg_new_custom.fn_process_a_record Process completed successfully');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in cgpks_inward_clg_new_custom.fn_process_a_record' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PROCESS_A_RECORD;

  FUNCTION FN_PRE_PASS_IC_ACCT_ENTRIES(PBRANCH     IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                                       P_ENTRY_REC IN OUT CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                                       P_CHG_ROW   IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                                       P_ERR_CODE  IN OUT VARCHAR2,
                                       P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Cgpks_Inward_clg_New_custom.fn_pre_pass_ic_acct_entries');

    DBG('Returning sucess Cgpks_Inward_clg_New_custom.fn_pre_pass_ic_acct_entries');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Cgpks_Inward_clg_New_custom.fn_pre_pass_ic_acct_entries..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_PASS_IC_ACCT_ENTRIES;

  FUNCTION FN_POST_PASS_IC_ACCT_ENTRIES(PBRANCH     IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                                        P_ENTRY_REC IN OUT CSTBS_IW_CLEARING_MASTER%ROWTYPE,
                                        P_CHG_ROW   IN OUT IFTMS_ARC_MAINT%ROWTYPE,
                                        P_ERR_CODE  IN OUT VARCHAR2,
                                        P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Cgpks_Inward_clg_New_custom.fn_post_pass_ic_acct_entries');

    DBG('Returning sucess Cgpks_Inward_clg_New_custom.fn_post_pass_ic_acct_entries');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of Cgpks_Inward_clg_New_custom.fn_post_pass_ic_acct_entries..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_PASS_IC_ACCT_ENTRIES;

END CGPKS_INWARD_CLG_NEW_CUSTOM;
