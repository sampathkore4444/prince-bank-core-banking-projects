CREATE OR REPLACE PACKAGE BODY gwpks_enrichblkcgcont_custom IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('CG', 'gwpks_enrichblkcgcont_custom : ' || P_MSG);
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END DBG;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;
  
   --sampath starts
    PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                           p_Source      VARCHAR2,
                           p_Err_Code    VARCHAR2,
                           p_Err_Params  VARCHAR2) IS
    BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                   p_Function_Id,
                                   p_Err_Code,
                                   p_Err_Params);
    END Pr_Log_Error;
    --sampath ends
    

  FUNCTION FN_INSERT_BULK_CLEARING_UPLOAD(P_REC_CLG_UPD_REC IN IFTBS_CLEARING_UPLOAD%ROWTYPE,
                                          P_CALL_FN_ID      IN OUT NUMBER,
                                          P_TB_CUSTOM_DATA  IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In  fn_insert_bulk_clearing_upload..of gwpks_enrichblkcgcont_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);

    DBG('In  Returning Successfully from gwpks_enrichblkcgcont_custom.fn_insert_bulk_clearing_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_enrichblkcgcont_custom.fn_insert_bulk_clearing_upload..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_INSERT_BULK_CLEARING_UPLOAD;

  FUNCTION FN_BUILD_CLEARING_DETAILS(P_SOURCE         IN VARCHAR2,
                                     P_FCCREF         IN OUT VARCHAR2,
                                     P_CLG_UPLD_REC   IN OUT CGPKSS_UPLOAD_CG_CREATE.TY_CLG_UPLD_REC,
                                     P_XREF           IN VARCHAR2,
                                     P_PARENT_RES     IN VARCHAR2,
                                     P_PARENT         IN OUT VARCHAR2,
                                     P_KEY            IN OUT VARCHAR2,
                                     P_DATA           IN OUT VARCHAR2,
                                     P_KEY_CLOB       IN OUT NOCOPY CLOB,
                                     P_DATA_CLOB      IN OUT NOCOPY CLOB,
                                     P_FORMAT         IN OUT VARCHAR2,
                                     P_CNT_LVL        IN OUT NUMBER,
                                     P_CONSOLIDATED   IN OUT VARCHAR2,
                                     P_ERR_CODE       IN OUT VARCHAR2,
                                     P_ERR_PARAM      IN OUT VARCHAR2,
                                     P_ISOUTCLOB      IN OUT VARCHAR2,
                                     P_CALL_FN_ID     IN OUT NUMBER,
                                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)

   RETURN BOOLEAN IS
  BEGIN

    DBG('In  fn_build_clearing_details..of gwpks_enrichblkcgcont_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);

    DBG('In  Returning Successfully from gwpks_enrichblkcgcont_custom.fn_build_clearing_details');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_enrichblkcgcont_custom.fn_build_clearing_details..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_BUILD_CLEARING_DETAILS;

  FUNCTION FN_DDCONTRACT_RES_FULL(P_SOURCE         IN VARCHAR2,
                                  P_FCCREF         IN VARCHAR2,
                                  P_XREF           IN VARCHAR2,
                                  P_NODE           IN VARCHAR2,
                                  P_DATA           IN OUT VARCHAR2,
                                  P_KEY            IN OUT VARCHAR2,
                                  P_PARENT         IN OUT VARCHAR2,
                                  P_FORMAT         IN OUT VARCHAR2,
                                  P_UPL_CONT_REC   IN CSVW_BC_DD_MASTER%ROWTYPE,
                                  P_BC_DD_DET      IN GWPKS_ENRICHBLKCGCONTRACT.TY_BC_DD_UPLD_REC,
                                  P_ERRS           IN OUT VARCHAR2,
                                  P_PRMS           IN OUT VARCHAR2,
                                  P_CALL_FN_ID     IN OUT NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In  fn_ddcontract_res_full..of gwpks_enrichblkcgcont_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);

    DBG('In  Retruning Successfully from gwpks_enrichblkcgcont_custom.fn_ddcontract_res_full');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_enrichblkcgcont_custom.fn_ddcontract_res_full..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_DDCONTRACT_RES_FULL;

  FUNCTION FN_BUILD_ADDROW(P_SOURCE         IN VARCHAR2,
                           P_DATA           IN OUT VARCHAR2,
                           P_KEY            IN OUT CLOB,
                           P_PARENT         IN OUT VARCHAR2,
                           P_FORMAT         IN OUT VARCHAR2,
                           P_LVL2_CNT       IN OUT NUMBER,
                           P_UPL_CONT_REC   IN CSVW_BC_DD_MASTER%ROWTYPE,
                           P_BC_DD_DET      IN GWPKS_ENRICHBLKCGCONTRACT.TY_BC_DD_UPLD_REC,
                           P_ERRS           IN OUT VARCHAR2,
                           P_PRMS           IN OUT VARCHAR2,
                           P_CALL_FN_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In  fn_build_addrow..of gwpks_enrichblkcgcont_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);

    DBG('In  Retruning Successfully from gwpks_enrichblkcgcont_custom.fn_build_addrow');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_enrichblkcgcont_custom.fn_build_addrow..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_BUILD_ADDROW;

  FUNCTION FN_BUILD_ADDROW_5521(P_CLG_UPLD_REC   IN CGPKSS_UPLOAD_CG_CREATE.TY_CLG_UPLD_REC,
                                P_DATA           IN OUT VARCHAR2,
                                P_KEY            IN OUT VARCHAR2,
                                P_PARENT         IN OUT VARCHAR2,
                                P_FORMAT         IN OUT VARCHAR2,
                                P_CNT_LVL        IN OUT NUMBER,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAM      IN OUT VARCHAR2,
                                P_CALL_FN_ID     IN OUT NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)

   RETURN BOOLEAN IS
  BEGIN
    DBG('In  fn_build_addrow_5521..of gwpks_enrichblkcgcont_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);

    DBG('In  Retruning Successfully from gwpks_enrichblkcgcont_custom.fn_build_addrow_5521');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_enrichblkcgcont_custom.fn_build_addrow_5521..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_BUILD_ADDROW_5521;

  FUNCTION FN_TS_TO_TYPE(PRECTYPE         IN VARCHAR2,
                         PKEY             IN VARCHAR2,
                         PDATA            IN VARCHAR2,
                         P_UPL_CONT_REC   IN OUT CSVW_BC_DD_MASTER%ROWTYPE,
                         P_UPL_MIS_DET    IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                         P_UPL_UDF_DET    IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                         P_UPL_CHG_DET    IN OUT DDPKS_UPLOAD_CONTRACT_CREATE.TYP_TBLCHGDETS,
                         P_BC_DD_DET      IN OUT GWPKS_ENRICHBLKCGCONTRACT.TY_BC_DD_UPLD_REC,
                         P_ERR_CODE       IN OUT VARCHAR2,
                         P_ERR_PARAM      IN OUT VARCHAR2,
                         P_CALL_FN_ID     IN OUT NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In  fn_ts_to_type..of gwpks_enrichblkcgcont_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);

    DBG('In  Retruning Successfully from gwpks_enrichblkcgcont_custom.fn_ts_to_type');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_enrichblkcgcont_custom.fn_ts_to_type..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_TS_TO_TYPE;

  FUNCTION FN_PRE_CHECK_MANDATORY_CG_REC(P_REC_CLG_UPLD IN IFTBS_CLEARING_UPLOAD%ROWTYPE)
    RETURN BOOLEAN IS
    
    --sampath starts
      L_STTB_ACCOUNT    STTB_ACCOUNT%ROWTYPE;
      L_STATUS          VARCHAR2(100);
      L_COUNT           NUMBER;
      L_ACCOUNT_BALANCE STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
      L_ERROR_CODE      VARCHAR2(100);
      L_ERROR_MSG       ERTB_MSGS.MESSAGE%TYPE;
       L_STTM_DATES STTM_DATES%ROWTYPE;
       CHK_REC_COUNT   NUMBER;
      --sampath ends
      
  BEGIN
    DBG('Inside gwpks_enrichblkcgcont_cluster.fn_Pre_check_mandatory_cg_rec');
    
      DBG('gwpks_EnrichBlkcgcontract.G_OPERATION_CODE=' ||
          gwpks_EnrichBlkcgcontract.G_OPERATION_CODE);
    
      --sampath starts
      IF gwpks_EnrichBlkcgcontract.G_OPERATION_CODE =
         'EnrichBlkTransaction' AND P_REC_CLG_UPLD.REMACCOUNT IS NOT NULL THEN
      
        BEGIN
          SELECT *
            INTO L_STTB_ACCOUNT
            FROM STTB_ACCOUNT
           WHERE AC_GL_NO = P_REC_CLG_UPLD.REMACCOUNT;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_STTB_ACCOUNT := NULL;
            DBG('FAILED IN GETTING ACCOUNT DETAILS');
        END;
      
        DBG('L_STTB_ACCOUNT.AC_STAT_DORMANT=' ||
            L_STTB_ACCOUNT.AC_STAT_DORMANT);
        DBG('L_STTB_ACCOUNT.AC_STAT_FROZEN=' ||
            L_STTB_ACCOUNT.AC_STAT_FROZEN);
        DBG('L_STTB_ACCOUNT.AC_STAT_NO_DR=' ||
            L_STTB_ACCOUNT.AC_STAT_NO_DR);
      
        --Dormant
        IF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
          DBG('INSIDE DORMANCY');
         OVPKS.PR_APPENDTBL('AC-PRINDORM', P_REC_CLG_UPLD.REMACCOUNT);
          --Pr_Log_Error('5555','FLEXCUBE','AC-VAC05','P_REC_CLG_UPLD.REMACCOUNT');
          --RETURN FALSE;
        
        END IF;
      
        --Frozen
        IF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
          OVPKS.PR_APPENDTBL('AC-VAC04', P_REC_CLG_UPLD.REMACCOUNT);
          --RETURN FALSE;
        END IF;
      
        --No Debit
        IF L_STTB_ACCOUNT.AC_STAT_NO_DR = 'Y' THEN
          OVPKS.PR_APPENDTBL('AC-VAC07', P_REC_CLG_UPLD.REMACCOUNT);
          --RETURN FALSE;
        END IF;
      
        DBG('P_REC_CLG_UPLD.REMBRANCH=' || P_REC_CLG_UPLD.REMBRANCH);
        DBG('P_REC_CLG_UPLD.ACC_BRANCH=' || P_REC_CLG_UPLD.ACC_BRANCH);
        DBG('P_REC_CLG_UPLD.BRANCH_CODE=' || P_REC_CLG_UPLD.BRANCH_CODE);
        DBG('P_REC_CLG_UPLD.TXN_BRN=' || P_REC_CLG_UPLD.TXN_BRN);
      
        DBG('P_REC_CLG_UPLD.REMACCOUNT=' || P_REC_CLG_UPLD.REMACCOUNT);
        DBG('P_REC_CLG_UPLD.INSTRNO=' || P_REC_CLG_UPLD.INSTRNO);
      
        DBG('P_REC_CLG_UPLD.INSTRAMT=' || P_REC_CLG_UPLD.INSTRAMT);
      
        --Check Balance of an account
        BEGIN
          IF NOT ACPKSS_MISC.FN_GETAVLBAL(P_REC_CLG_UPLD.TXN_BRN,
                                          P_REC_CLG_UPLD.REMACCOUNT,
                                          L_ACCOUNT_BALANCE,
                                          'Y') THEN
            DBG('Unable to fetch Transaction account Amount');
          ELSE
            DBG('BALANCE OF AN ACCOUNT=' || L_ACCOUNT_BALANCE);
          END IF;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('The error occured at line:' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          
            DBG('Failure in fetching the Available balance fr the transaction account');
        END;
      
        IF L_ACCOUNT_BALANCE < P_REC_CLG_UPLD.INSTRAMT THEN
        
          IFPKSS_FIN_OVD.PR_REGISTER_OVD('CA-PRINCHQ4',
                                         P_REC_CLG_UPLD.TXNCCY,
                                         ABS(L_ACCOUNT_BALANCE));
        
          L_ERROR_CODE := L_ERROR_CODE || 'CA-PRINCHQ4;';
          L_ERROR_MSG  := L_ERROR_MSG || P_REC_CLG_UPLD.REMACCOUNT || '~' ||
                          RTRIM(LTRIM(CSFNS_FORMAT_AMT(P_REC_CLG_UPLD.TXNCCY,
                                                       L_ACCOUNT_BALANCE))) || '~' ||
                          RTRIM(LTRIM(CSFNS_FORMAT_AMT(P_REC_CLG_UPLD.TXNCCY,
                                                       L_ACCOUNT_BALANCE))) || '~' || ';';
          DBG('L_ERROR_MSG=' || L_ERROR_MSG);
        
          --OVPKSS.PR_APPENDTBL('CA-PRINCHQ4',L_ERROR_MSG);
          PR_LOG_ERROR('5555', 'FLEXCUBE', 'CA-PRINCHQ4', NULL);
          
          --RETURN FALSE;
        
          --PR_LOG_ERROR('5555', 'FLEXCUBE', 'CA-PRINCHQ4', P_REC_CLG_UPLD.REMACCOUNT);
        
          --RETURN FALSE;
        END IF;
      
        --Check Delivery Status
        BEGIN
          SELECT B.REQUEST_STATUS
            INTO L_STATUS
            FROM CATM_CHECK_DETAILS A, CATM_CHECK_BOOK B
           WHERE A.BRANCH = B.BRANCH
             AND A.ACCOUNT = B.ACCOUNT
             AND A.CHECK_BOOK_NO = B.FIRST_CHECK_NO
             AND A.BRANCH = P_REC_CLG_UPLD.TXN_BRN
             AND A.ACCOUNT = P_REC_CLG_UPLD.REMACCOUNT
             AND A.CHECK_NO = P_REC_CLG_UPLD.INSTRNO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error while geting the check book status' || SQLERRM ||
                SQLCODE);
        END;
      
        IF NVL(L_STATUS, 'Nothing') <> ('Delivered') THEN
          OVPKSS.PR_APPENDTBL('CA-PRINCHQ0', P_REC_CLG_UPLD.INSTRNO);
          RETURN FALSE;
        END IF;
      
        --Check Status
        BEGIN
        
          SELECT STATUS
            INTO L_STATUS
            FROM CATMS_CHECK_DETAILS
           WHERE MOD_NO = (
                           
                           SELECT MAX(MOD_NO)
                             FROM CATMS_CHECK_DETAILS
                            WHERE CHECK_NO = P_REC_CLG_UPLD.INSTRNO
                              AND BRANCH = P_REC_CLG_UPLD.TXN_BRN
                              AND ACCOUNT = P_REC_CLG_UPLD.REMACCOUNT)
             AND CHECK_NO = P_REC_CLG_UPLD.INSTRNO
             AND BRANCH = P_REC_CLG_UPLD.TXN_BRN
             AND ACCOUNT = P_REC_CLG_UPLD.REMACCOUNT;
        
        EXCEPTION
          WHEN OTHERS THEN
          
            OVPKS.PR_APPENDTBL('IF-DAT037', NULL);
            DBG('should return false');
            --RETURN FALSE;
        END;
      
        --Used Check
        IF L_STATUS = 'U' THEN
          OVPKS.PR_APPENDTBL('CA-PRINCHQ1', P_REC_CLG_UPLD.INSTRNO);
          --RETURN FALSE;
        END IF;
      
        --Stop Payment Check
        BEGIN
         L_STTM_DATES := GLOBALS_FRC.FN_GET_BRN_DATE_FRC(P_REC_CLG_UPLD.TXN_BRN);

      DBG('l_branch_date is - ' || L_STTM_DATES.TODAY);
      
            SELECT COUNT(*)
              INTO CHK_REC_COUNT
              FROM CATMS_STOP_PAYMENTS
             WHERE BRANCH = P_REC_CLG_UPLD.TXN_BRN
               AND STOP_PAYMENT_TYPE = 'C'
               AND NOT (RECORD_STAT = 'C' AND AUTH_STAT = 'A')
               AND

                   (P_REC_CLG_UPLD.INSTRNO BETWEEN START_CHECK_NO AND END_CHECK_NO)
               AND

                   L_STTM_DATES.TODAY BETWEEN EFFECTIVE_DATE AND
                   NVL(EXPIRY_DATE, L_STTM_DATES.TODAY)

               AND ACCOUNT = P_REC_CLG_UPLD.REMACCOUNT;
         
      EXCEPTION
        WHEN OTHERS THEN
          CHK_REC_COUNT := 0;
      END;
      
         DBG('CHK_REC_COUNT='||CHK_REC_COUNT);
             
         IF CHK_REC_COUNT >0 /*L_STATUS = 'S'*/ THEN
          OVPKS.PR_APPENDTBL('CA-PRINCHQ2', P_REC_CLG_UPLD.INSTRNO);
          RETURN FALSE;
        END IF;
      
        --Cancelled Check
        IF L_STATUS = 'C' THEN
          OVPKS.PR_APPENDTBL('CA-PRINCHQ3', P_REC_CLG_UPLD.INSTRNO);
          --RETURN FALSE;
        END IF;
      
      END IF;
    
      --sampath ends

    DBG('Returning true from gwpks_enrichblkcgcont_cluster.fn_Pre_check_mandatory_cg_rec');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_enrichblkcgcont_cluster.fn_Pre_check_mandatory_cg_rec..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY_CG_REC;

  FUNCTION FN_POST_CHECK_MANDATORY_CG_REC(P_REC_CLG_UPLD IN IFTBS_CLEARING_UPLOAD%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside gwpks_enrichblkcgcont_custom.fn_Post_check_mandatory_cg_rec');

    DBG('Returning true from gwpks_enrichblkcgcont_custom.fn_Post_check_mandatory_cg_rec');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_enrichblkcgcont_custom.fn_Post_check_mandatory_cg_rec..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY_CG_REC;

  FUNCTION FN_VALIDATE_RECORD(P_REMBRANCH      IN STTB_ACCOUNT.BRANCH_CODE%TYPE,
                              P_REMACCOUNT     IN STTB_ACCOUNT.AC_GL_NO%TYPE,
                              P_INSTRNO        IN CATM_CHECK_DETAILS.CHECK_NO%TYPE,
                              P_INSTRAMT       IN CATM_CHECK_DETAILS.AMOUNT%TYPE,
                              P_ERR_CODE       OUT VARCHAR2,
                              P_ERR_PARAM      OUT VARCHAR2,
                              P_CALL_FN_ID     IN OUT NUMBER,
                              P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS

    L_ERR_CODE        VARCHAR2(100);
    L_ERR_PARAMS      VARCHAR2(200);
    L_STTB_ACCOUNT    STTBS_ACCOUNT%ROWTYPE;
    L_COUNT           NUMBER;
    L_COUNT1          NUMBER;
    L_CLEARING_UPLOAD IFTB_BULK_CLEARING_UPLOAD %ROWTYPE;
    L_STATUS          IFTB_BULK_CLEARING_UPLOAD.STATUS%TYPE;
    L_ACC_GL_STATUS   STTB_ACCOUNT.AC_GL_REC_STATUS%TYPE;

  BEGIN
    DBG('In  fn_validate_endpoint.');

    DBG('validations done sucessfully thanx  !!!! ');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  VALIDATING THE RECORD...');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('ED-UPLOTH', 'fn_validate_endpoint~' || SQLCODE);
      RETURN FALSE;

  END FN_VALIDATE_RECORD;

  FUNCTION FN_UPLOAD(P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                     P_TY_CLG_REC     IN OUT CGPKSS_UPLOAD_CG_CREATE.TY_CLG_UPLD_REC,
                     P_OVERRIDE_FLAG  OUT CHAR,
                     P_AUTH_STAT      OUT CHAR,
                     P_ERR_TBL        IN OUT OVPKS.TBL_ERROR,
                     P_CALL_FN_ID     IN OUT NUMBER,
                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS

  BEGIN
    DBG('In  fn_upload...custom');
    DBG('In  Retruning Successfully from gwpks_enrichblkcgcont_custom.Fn_Upload');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of FN_UPLOAD...');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_UPLOAD;

  PROCEDURE PR_PROCESS_MSG_CG_INSTR(P_IS_IN_MSG_CLOB  IN VARCHAR2,
                                    P_REC_MSG_HEADER  IN GWPKS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                                    P_IS_OUT_MSG_CLOB IN OUT VARCHAR2,
                                    P_INSTR_REC       IN OUT GWPKS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                                    P_FLAG            OUT NUMBER,
                                    P_ERR_CODE        IN OUT VARCHAR2,
                                    P_ERR_PARAM       IN OUT VARCHAR2,
                                    P_CALL_FN_ID      IN OUT NUMBER,
                                    P_TB_CUSTOM_DATA  IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Inside Custom pr_process_msg_cg_instr ...');

    DBG('Returning Successfully from Custom pr_process_msg_cg_instr..');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of gwpks_enrichblkcgcont_custom.pr_process_msg_cg_instr ..');
      DBG(SQLERRM);
      RETURN;
  END PR_PROCESS_MSG_CG_INSTR;

END GWPKS_ENRICHBLKCGCONT_CUSTOM;
