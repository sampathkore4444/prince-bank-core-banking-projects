/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2020, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : CGDIWCGD_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_CGVWS_INWARD_CLG_UPLOAD":"STATUS~CURRENCY~ENDPOINT~TXNDATE~REMBRANCH~REMACCOUNT~ACC_CCY~PROD~INSTRNO~INSTRAMT~BENACCOUNT~AUTH_STAT~SCODE~ENTRYNO~INSTRTYPE~DIRECTION~USER_ID~REJ_REASON_CODE~XREF~BATCH_NO~FCCREF1","BLK_CGVWS_INWARD_CLG_UPLD":"SCODE1~XREF1~ENTRY_NO1~STATUS1~REJ_REASON_CODE~FORCE_POSTING~REJ_ADV_REQD~PROD~REMACCOUNT~REMBRANCH~BENACCOUNT~INSTRNO~INSTRCCY~INSTRAMT~ROUTINGNO~ACC_CCY~TXNDATE~ENDPOINT~TXN_BRN~REMBANK~INSTRDATE~VALDATEBNK~VALDATECUST~FCCREF~MAKER_ID~MAKER_DT_STAMP~CHECKER_DT_STAMP~CHECKER_ID~ERROR_CODES~ERROR_PARAMS~REMARKS~BEN_CUST~ERR_MSG~INSTR_TYPE~DIRECTION~CUSTNAME~AUTH_STAT~WAIVE~BENROUTINGNO~ALTCHECK~CHAR_FIELD21~PRESNBNKCHG~CHQRETNAMT"};

var multipleEntryPageSize = {"BLK_CGVWS_INWARD_CLG_UPLD" : "30 "};

var multipleEntrySVBlocks = "BLK_CGVWS_INWARD_CLG_UPLD";

var tabMEBlks = {"CVS_MAIN__TAB_MAIN":"BLK_CGVWS_INWARD_CLG_UPLD"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_CGVWS_INWARD_CLG_UPLOAD">STATUS~CURRENCY~ENDPOINT~TXNDATE~REMBRANCH~REMACCOUNT~ACC_CCY~PROD~INSTRNO~INSTRAMT~BENACCOUNT~AUTH_STAT~SCODE~ENTRYNO~INSTRTYPE~DIRECTION~USER_ID~REJ_REASON_CODE~XREF~BATCH_NO~FCCREF1</FN>'; 
msgxml += '      <FN PARENT="BLK_CGVWS_INWARD_CLG_UPLOAD" RELATION_TYPE="N" TYPE="BLK_CGVWS_INWARD_CLG_UPLD">SCODE1~XREF1~ENTRY_NO1~STATUS1~REJ_REASON_CODE~FORCE_POSTING~REJ_ADV_REQD~PROD~REMACCOUNT~REMBRANCH~BENACCOUNT~INSTRNO~INSTRCCY~INSTRAMT~ROUTINGNO~ACC_CCY~TXNDATE~ENDPOINT~TXN_BRN~REMBANK~INSTRDATE~VALDATEBNK~VALDATECUST~FCCREF~MAKER_ID~MAKER_DT_STAMP~CHECKER_DT_STAMP~CHECKER_ID~ERROR_CODES~ERROR_PARAMS~REMARKS~BEN_CUST~ERR_MSG~INSTR_TYPE~DIRECTION~CUSTNAME~AUTH_STAT~WAIVE~BENROUTINGNO~ALTCHECK~CHAR_FIELD21~PRESNBNKCHG~CHQRETNAMT</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_CGVWS_INWARD_CLG_UPLOAD" : "","BLK_CGVWS_INWARD_CLG_UPLD" : "BLK_CGVWS_INWARD_CLG_UPLOAD~N"}; 

 var dataSrcLocationArray = new Array("BLK_CGVWS_INWARD_CLG_UPLOAD","BLK_CGVWS_INWARD_CLG_UPLD"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside CGDIWCGD.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside CGDIWCGD.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_CGVWS_INWARD_CLG_UPLOAD__SCODE";
pkFields[0] = "BLK_CGVWS_INWARD_CLG_UPLOAD__SCODE";
queryFields[1] = "BLK_CGVWS_INWARD_CLG_UPLOAD__XREF";
pkFields[1] = "BLK_CGVWS_INWARD_CLG_UPLOAD__XREF";
queryFields[2] = "BLK_CGVWS_INWARD_CLG_UPLOAD__FCCREF1";
pkFields[2] = "BLK_CGVWS_INWARD_CLG_UPLOAD__FCCREF1";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_CGVWS_INWARD_CLG_UPLOAD":["STATUS"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
//***** Fields Amendable while Query *****
var queryAmendArr = {"BLK_CGVWS_INWARD_CLG_UPLOAD":["ACC_CCY","AUTH_STAT","BATCH_NO","BENACCOUNT","CURRENCY","DIRECTION","ENDPOINT","FCCREF1","INSTRAMT","INSTRNO","PROD","REJ_REASON_CODE","REMACCOUNT","REMBRANCH","STATUS","TXNDATEI","USER_ID","XREF"]};
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_CGVWS_INWARD_CLG_UPLOAD__CURRENCY__LOV_CCY":["BLK_CGVWS_INWARD_CLG_UPLOAD__CURRENCY~~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__ENDPOINT__LOV_ENDPOINT":["BLK_CGVWS_INWARD_CLG_UPLOAD__ENDPOINT~~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__REMBRANCH__LOV_REM_BRN":["BLK_CGVWS_INWARD_CLG_UPLOAD__REMBRANCH~~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__REMACCOUNT__LOV_REM_ACC_NO":["BLK_CGVWS_INWARD_CLG_UPLOAD__REMACCOUNT~~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__ACC_CCY__LOV_CCY":["BLK_CGVWS_INWARD_CLG_UPLOAD__ACC_CCY~~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__PROD__LOV_PROD":["BLK_CGVWS_INWARD_CLG_UPLOAD__PROD~~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__BENACCOUNT__LOV_BEN_ACC_NO":["BLK_CGVWS_INWARD_CLG_UPLOAD__BENACCOUNT~","","N","N"],"BLK_CGVWS_INWARD_CLG_UPLOAD__USER_ID__LOV_USERID":["BLK_CGVWS_INWARD_CLG_UPLOAD__USER_ID~","","N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__REJ_REASON_CODE__LOV_REJ_REASON":["BLK_CGVWS_INWARD_CLG_UPLOAD__REJ_REASON_CODE~~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__XREF__LOV_EXT_REF_NO":["BLK_CGVWS_INWARD_CLG_UPLOAD__XREF~","","N",""],"BLK_CGVWS_INWARD_CLG_UPLOAD__BATCH_NO__LOV_BATCH_NO":["BLK_CGVWS_INWARD_CLG_UPLOAD__BATCH_NO~","","N",""],"BLK_CGVWS_INWARD_CLG_UPLD__REJ_REASON_CODE__LOV_REJ_REASON":["BLK_CGVWS_INWARD_CLG_UPLD__REJ_REASON_CODE~~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLD__REMACCOUNT__LOV_REM_ACC_NO":["BLK_CGVWS_INWARD_CLG_UPLD__REMACCOUNT~BLK_CGVWS_INWARD_CLG_UPLD__REMBRANCH~","","N~N",""],"BLK_CGVWS_INWARD_CLG_UPLD__BENACCOUNT__LOV_BEN_ACC_NO":["BLK_CGVWS_INWARD_CLG_UPLD__BENACCOUNT~","","N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_CGVWS_INWARD_CLG_UPLD");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array(); 

 var CallFormRelat=new Array(); 

 var CallRelatType= new Array(); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["CGDIWCGD"]="KERNEL";
ArrPrntFunc["CGDIWCGD"]="";
ArrPrntOrigin["CGDIWCGD"]="";
ArrRoutingType["CGDIWCGD"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["CGDIWCGD"]="N";
ArrCustomModified["CGDIWCGD"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {};
var scrArgSource = {};
var scrArgVals = {};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"2"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------