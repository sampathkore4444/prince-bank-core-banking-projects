CREATE OR REPLACE PACKAGE BODY cgpks_cgdiwcgd_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : cgpks_cgdiwcgd_main.sql
     **
     ** Module     : CLEARING
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Original_Action    VARCHAR2(100);
   g_Action_Code    VARCHAR2(100);
   g_Addl_Info       Cspks_Req_Global.Ty_Addl_Info;
   g_Ui_Name            VARCHAR2(50) := 'CGDIWCGD';
   g_Req_Key                 VARCHAR2(32767);
   g_cgdiwcgd         cgpks_cgdiwcgd_Main.Ty_cgdiwcgd;
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Kernel    BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'cgpks_cgdiwcgd_Main ==>'||p_Msg;
         Debug.Pr_Debug('CG' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'CGDIWCGD';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      cgpks_cgdiwcgd_Kernel.Pr_Skip_Handler (P_Stage);
      cgpks_cgdiwcgd_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Kernel IS
   BEGIN
      g_Skip_Kernel := TRUE;
   END Pr_Set_Skip_Kernel;
   PROCEDURE Pr_Set_Activate_Kernel IS
   BEGIN
      g_Skip_Kernel := FALSE;
   END Pr_Set_Activate_Kernel;
   FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type = Cspks_Req_Global.p_Kernel THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Kernel;
      END IF;
   END  Fn_Skip_Kernel;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION  Fn_Get_Original_Action RETURN VARCHAR2 IS
   BEGIN
      RETURN G_Original_Action;
   END  Fn_Get_Original_Action;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_cgdiwcgd       IN   OUT cgpks_cgdiwcgd_Main.ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_3    NUMBER;
      l_Bnd_Cntr_3    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_CGVWS_INWARD_CLG_UPLOAD' THEN
            p_cgdiwcgd.v_cgvws_inward_clg_upload.STATUS := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.CURRENCY := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.ENDPOINT := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_cgdiwcgd.v_cgvws_inward_clg_upload.TXNDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_cgdiwcgd.v_cgvws_inward_clg_upload.TXNDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.REMBRANCH := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.REMACCOUNT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.ACC_CCY := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.PROD := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTRNO := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTRAMT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.BENACCOUNT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.AUTH_STAT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.SCODE := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.ENTRY_NO := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTR_TYPE := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.MAKER_ID := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.REJ_REASON_CODE := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.XREF := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.BATCH_NO := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upload.FCCREF1 := Cspks_Req_Global.Fn_GetVal;
         ELSIF  l_Node = 'BLK_CGVWS_INWARD_CLG_UPLD' THEN
            l_Dsn_Rec_Cnt_2 :=  p_cgdiwcgd.v_cgvws_inward_clg_upld.count +1 ;
            l_Dsn_Rec_Cnt_3 :=  p_cgdiwcgd.v_cstb_ui_columns.count +1 ;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).SCODE1 := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).XREF1 := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ENTRY_NO1 := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).STATUS1 := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REJ_REASON_CODE := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).FORCE_POSTING := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REJ_ADV_REQD := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).PROD := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REMACCOUNT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REMBRANCH := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).BENACCOUNT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRNO := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRCCY := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRAMT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ROUTINGNO := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ACC_CCY := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).TXNDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).TXNDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ENDPOINT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).TXN_BRN := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REMBANK := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).VALDATEBNK := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).VALDATEBNK := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).VALDATECUST := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).VALDATECUST := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).FCCREF := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).MAKER_ID := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CHECKER_ID := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ERROR_CODES := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ERROR_PARAMS := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REMARKS := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).BEN_CUST := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ERR_MSG := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTR_TYPE := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).DIRECTION := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CUSTNAME := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).AUTH_STAT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).WAIVE_REJECT_CHG := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).BENROUTINGNO := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).CHAR_FIELD20 := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).CHAR_FIELD21 := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).PRESENT_BANK_CHG := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CHEQUE_RETN_AMT := Cspks_Req_Global.Fn_GetVal;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).scode1 :=p_cgdiwcgd.v_cgvws_inward_clg_upload.scode;
            p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).char_field21 :=p_cgdiwcgd.v_cgvws_inward_clg_upload.xref;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_cgdiwcgd.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_cgdiwcgd       IN   OUT cgpks_cgdiwcgd_Main.ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_3    NUMBER;
      l_Bnd_Cntr_3    NUMBER;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_CGVWS_INWARD_CLG_UPLOAD','Cgvw-Clearing-Upload-Full','Cgvw-Clearing-Upload-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key IN( 'STATS','STATUS')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.STATUS := l_Val;
               ELSIF l_Key IN( 'CURR','CURRENCY')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.CURRENCY := l_Val;
               ELSIF l_Key = 'ENDPOINT' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.ENDPOINT := l_Val;
               ELSIF l_Key IN( 'TRANS_DATE','TXNDATE')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_cgdiwcgd.v_cgvws_inward_clg_upload.TXNDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_cgdiwcgd.v_cgvws_inward_clg_upload.TXNDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key IN( 'REMBRANCH_F','REMBRANCH')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.REMBRANCH := l_Val;
               ELSIF l_Key IN( 'REMITTER','REMACCOUNT')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.REMACCOUNT := l_Val;
               ELSIF l_Key IN( 'REMACCCCY','ACC_CCY')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.ACC_CCY := l_Val;
               ELSIF l_Key = 'PROD' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.PROD := l_Val;
               ELSIF l_Key IN( 'INSTRUMENT_NO','INSTRNO')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTRNO := l_Val;
               ELSIF l_Key IN( 'AMOUNT','INSTRAMT')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTRAMT := l_Val;
               ELSIF l_Key = 'BENACCOUNT' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.BENACCOUNT := l_Val;
               ELSIF l_Key IN( 'AUTHSTATUS','AUTH_STAT')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.AUTH_STAT := l_Val;
               ELSIF l_Key IN( 'SOURCE','SCODE')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.SCODE := l_Val;
               ELSIF l_Key = 'ENTRYNO' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.ENTRY_NO := l_Val;
               ELSIF l_Key IN( 'INSTRUMENT_TYPE','INSTRTYPE')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTR_TYPE := l_Val;
               ELSIF l_Key = 'DIRECTION' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION := l_Val;
               ELSIF l_Key = 'USER_ID' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.MAKER_ID := l_Val;
               ELSIF l_Key = 'REJ_REASON_CODE' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.REJ_REASON_CODE := l_Val;
               ELSIF l_Key = 'XREF' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.XREF := l_Val;
               ELSIF l_Key = 'BATCH_NO' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.BATCH_NO := l_Val;
               ELSIF l_Key = 'FCCREF1' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.FCCREF1 := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         ELSIF  l_Node IN ( 'BLK_CGVWS_INWARD_CLG_UPLD','Cgvw-Clearing-Upld') THEN
            l_Dsn_Rec_Cnt_2 :=  p_cgdiwcgd.v_cgvws_inward_clg_upld.count +1 ;
            l_Dsn_Rec_Cnt_3 :=  p_cgdiwcgd.v_cstb_ui_columns.count +1 ;
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key IN( 'SOURCE_CODE','SCODE1')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).SCODE1 := l_Val;
               ELSIF l_Key IN( 'XREF','XREF1')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).XREF1 := l_Val;
               ELSIF l_Key IN( 'ENTRYNO','ENTRY_NO1')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ENTRY_NO1 := l_Val;
               ELSIF l_Key IN( 'STATS','STATUS1')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).STATUS1 := l_Val;
               ELSIF l_Key = 'REJ_REASON_CODE' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REJ_REASON_CODE := l_Val;
               ELSIF l_Key = 'FORCE_POSTING' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).FORCE_POSTING := l_Val;
               ELSIF l_Key = 'REJ_ADV_REQD' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REJ_ADV_REQD := l_Val;
               ELSIF l_Key = 'PROD' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).PROD := l_Val;
               ELSIF l_Key IN( 'REM_ACC_NO','REMACCOUNT')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REMACCOUNT := l_Val;
               ELSIF l_Key IN( 'REMBRANCH_F','REMBRANCH')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REMBRANCH := l_Val;
               ELSIF l_Key = 'BENACCOUNT' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).BENACCOUNT := l_Val;
               ELSIF l_Key IN( 'INSTNO','INSTRNO')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRNO := l_Val;
               ELSIF l_Key = 'INSTRCCY' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRCCY := l_Val;
               ELSIF l_Key = 'INSTRAMT' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRAMT := l_Val;
               ELSIF l_Key IN( 'ROUTING_NO','ROUTINGNO')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ROUTINGNO := l_Val;
               ELSIF l_Key IN( 'CCY_CD','ACC_CCY')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ACC_CCY := l_Val;
               ELSIF l_Key IN( 'LIQUIDATION_DATE','TXNDATE')  THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).TXNDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).TXNDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'ENDPOINT' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ENDPOINT := l_Val;
               ELSIF l_Key = 'TXN_BRN' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).TXN_BRN := l_Val;
               ELSIF l_Key IN( 'REM_BANK','REMBANK')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REMBANK := l_Val;
               ELSIF l_Key = 'INSTRDATE' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTRDATE := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'VALDATEBNK' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).VALDATEBNK := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).VALDATEBNK := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'VALDATECUST' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).VALDATECUST := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).VALDATECUST := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'FCCREF' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).FCCREF := l_Val;
               ELSIF l_Key = 'MAKER_ID' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).MAKER_ID := l_Val;
               ELSIF l_Key = 'MAKER_DT_STAMP' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).MAKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'CHECKER_DT_STAMP' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CHECKER_DT_STAMP := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'CHECKER_ID' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CHECKER_ID := l_Val;
               ELSIF l_Key IN( 'ERROR_CODE','ERROR_CODES')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ERROR_CODES := l_Val;
               ELSIF l_Key = 'ERROR_PARAMS' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ERROR_PARAMS := l_Val;
               ELSIF l_Key IN( 'REMRKS','REMARKS')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).REMARKS := l_Val;
               ELSIF l_Key IN( 'BENCUST','BEN_CUST')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).BEN_CUST := l_Val;
               ELSIF l_Key IN( 'UPLOAD_STAT','ERR_MSG')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ERR_MSG := l_Val;
               ELSIF l_Key IN( 'INSTRUMENT_TYPE','INSTR_TYPE')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).INSTR_TYPE := l_Val;
               ELSIF l_Key = 'DIRECTION' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).DIRECTION := l_Val;
               ELSIF l_Key = 'CUSTNAME' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CUSTNAME := l_Val;
               ELSIF l_Key IN( 'AUTHSTATUS','AUTH_STAT')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).AUTH_STAT := l_Val;
               ELSIF l_Key IN( 'WAIVE_REJ_CHG','WAIVE')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).WAIVE_REJECT_CHG := l_Val;
               ELSIF l_Key = 'BENROUTINGNO' THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).BENROUTINGNO := l_Val;
               ELSIF l_Key = 'ALTCHECK' THEN
                  p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).CHAR_FIELD20 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD21' THEN
                  p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).CHAR_FIELD21 := l_Val;
               ELSIF l_Key IN( 'PRESN_BNK_CHG_AMT','PRESNBNKCHG')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).PRESENT_BANK_CHG := l_Val;
               ELSIF l_Key IN( 'CHQ_RETN_AMT','CHQRETNAMT')  THEN
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).CHEQUE_RETN_AMT := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).scode1 :=p_cgdiwcgd.v_cgvws_inward_clg_upload.scode;
            p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).char_field21 :=p_cgdiwcgd.v_cgvws_inward_clg_upload.xref;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_cgdiwcgd.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_cgdiwcgd          IN cgpks_cgdiwcgd_Main.ty_cgdiwcgd,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_3    NUMBER;
      l_Bnd_Cntr_3    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_1_Lvl_Counter := 0;
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_CGVWS_INWARD_CLG_UPLOAD',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','STATUS',p_cgdiwcgd.v_cgvws_inward_clg_upload.status);
      Cspks_Req_Global.Pr_Write('V','CURRENCY',p_cgdiwcgd.v_cgvws_inward_clg_upload.currency);
      Cspks_Req_Global.Pr_Write('V','ENDPOINT',p_cgdiwcgd.v_cgvws_inward_clg_upload.endpoint);
      IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate) <>
            p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate THEN
         l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','TXNDATE',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','REMBRANCH',p_cgdiwcgd.v_cgvws_inward_clg_upload.rembranch);
      Cspks_Req_Global.Pr_Write('V','REMACCOUNT',p_cgdiwcgd.v_cgvws_inward_clg_upload.remaccount);
      Cspks_Req_Global.Pr_Write('V','ACC_CCY',p_cgdiwcgd.v_cgvws_inward_clg_upload.acc_ccy);
      Cspks_Req_Global.Pr_Write('V','PROD',p_cgdiwcgd.v_cgvws_inward_clg_upload.prod);
      Cspks_Req_Global.Pr_Write('V','INSTRNO',p_cgdiwcgd.v_cgvws_inward_clg_upload.instrno);
      Cspks_Req_Global.Pr_Write('V','INSTRAMT',p_cgdiwcgd.v_cgvws_inward_clg_upload.instramt);
      Cspks_Req_Global.Pr_Write('V','BENACCOUNT',p_cgdiwcgd.v_cgvws_inward_clg_upload.benaccount);
      Cspks_Req_Global.Pr_Write('V','AUTH_STAT',p_cgdiwcgd.v_cgvws_inward_clg_upload.auth_stat);
      Cspks_Req_Global.Pr_Write('V','SCODE',p_cgdiwcgd.v_cgvws_inward_clg_upload.scode);
      Cspks_Req_Global.Pr_Write('V','ENTRYNO',p_cgdiwcgd.v_cgvws_inward_clg_upload.entry_no);
      Cspks_Req_Global.Pr_Write('V','INSTRTYPE',p_cgdiwcgd.v_cgvws_inward_clg_upload.instr_type);
      Cspks_Req_Global.Pr_Write('V','DIRECTION',p_cgdiwcgd.v_cgvws_inward_clg_upload.direction);
      Cspks_Req_Global.Pr_Write('V','USER_ID',p_cgdiwcgd.v_cgvws_inward_clg_upload.maker_id);
      Cspks_Req_Global.Pr_Write('V','REJ_REASON_CODE',p_cgdiwcgd.v_cgvws_inward_clg_upload.rej_reason_code);
      Cspks_Req_Global.Pr_Write('V','XREF',p_cgdiwcgd.v_cgvws_inward_clg_upload.xref);
      Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_cgdiwcgd.v_cgvws_inward_clg_upload.batch_no);
      Cspks_Req_Global.Pr_Write('V','FCCREF1',p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1);

      --Dbg('Building Childs Of :BLK_CGVWS_INWARD_CLG_UPLOAD..');
      l_Dsn_Rec_Cnt_2 := 0;
      IF p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT > 0 THEN
         FOR i_2 IN  1..p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT LOOP
            l_Dsn_Rec_Cnt_2 := i_2;
            l_Dsn_Rec_Cnt_3 := 0;
            IF p_cgdiwcgd.v_cstb_ui_columns.COUNT > 0 THEN
               FOR i_3 IN  1..p_cgdiwcgd.v_cstb_ui_columns.COUNT LOOP
                  IF NVL(p_cgdiwcgd.v_cstb_ui_columns(i_3).char_field21,'@') = NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.xref,'@') THEN
                     l_Dsn_Rec_Cnt_3 := i_3;
                     EXIT;
                  END IF;
               END LOOP;
            END IF;
            l_Master_Childs  :=  l_Master_Childs +1;
            l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','BLK_CGVWS_INWARD_CLG_UPLD',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','SCODE1',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).scode1);
            Cspks_Req_Global.Pr_Write('V','XREF1',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).xref1);
            Cspks_Req_Global.Pr_Write('V','ENTRY_NO1',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).entry_no1);
            Cspks_Req_Global.Pr_Write('V','STATUS1',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).status1);
            Cspks_Req_Global.Pr_Write('V','REJ_REASON_CODE',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).rej_reason_code);
            Cspks_Req_Global.Pr_Write('V','FORCE_POSTING',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).force_posting);
            Cspks_Req_Global.Pr_Write('V','REJ_ADV_REQD',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).rej_adv_reqd);
            Cspks_Req_Global.Pr_Write('V','PROD',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).prod);
            Cspks_Req_Global.Pr_Write('V','REMACCOUNT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).remaccount);
            Cspks_Req_Global.Pr_Write('V','REMBRANCH',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).rembranch);
            Cspks_Req_Global.Pr_Write('V','BENACCOUNT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).benaccount);
            Cspks_Req_Global.Pr_Write('V','INSTRNO',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrno);
            Cspks_Req_Global.Pr_Write('V','INSTRCCY',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrccy);
            Cspks_Req_Global.Pr_Write('V','INSTRAMT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instramt);
            Cspks_Req_Global.Pr_Write('V','ROUTINGNO',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).routingno);
            Cspks_Req_Global.Pr_Write('V','ACC_CCY',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).acc_ccy);
            IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txndate) <>
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txndate THEN
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txndate,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txndate,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','TXNDATE',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','ENDPOINT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).endpoint);
            Cspks_Req_Global.Pr_Write('V','TXN_BRN',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txn_brn);
            Cspks_Req_Global.Pr_Write('V','REMBANK',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).rembank);
            IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrdate) <>
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrdate THEN
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrdate,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrdate,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','INSTRDATE',l_Date_Val);
            IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatebnk) <>
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatebnk THEN
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatebnk,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatebnk,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','VALDATEBNK',l_Date_Val);
            IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatecust) <>
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatecust THEN
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatecust,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatecust,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','VALDATECUST',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','FCCREF',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).fccref);
            Cspks_Req_Global.Pr_Write('V','MAKER_ID',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_id);
            IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_dt_stamp) <>
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','MAKER_DT_STAMP',l_Date_Val);
            IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_dt_stamp) <>
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_dt_stamp THEN
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','CHECKER_DT_STAMP',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','CHECKER_ID',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_id);
            Cspks_Req_Global.Pr_Write('V','ERROR_CODES',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).error_codes);
            Cspks_Req_Global.Pr_Write('V','ERROR_PARAMS',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).error_params);
            Cspks_Req_Global.Pr_Write('V','REMARKS',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).remarks);
            Cspks_Req_Global.Pr_Write('V','BEN_CUST',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ben_cust);
            Cspks_Req_Global.Pr_Write('V','ERR_MSG',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).err_msg);
            Cspks_Req_Global.Pr_Write('V','INSTR_TYPE',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instr_type);
            Cspks_Req_Global.Pr_Write('V','DIRECTION',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).direction);
            Cspks_Req_Global.Pr_Write('V','CUSTNAME',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).custname);
            Cspks_Req_Global.Pr_Write('V','AUTH_STAT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).auth_stat);
            Cspks_Req_Global.Pr_Write('V','WAIVE',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).waive_reject_chg);
            Cspks_Req_Global.Pr_Write('V','BENROUTINGNO',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).benroutingno);
            IF l_Dsn_rec_cnt_3 > 0 THEN
               Cspks_Req_Global.Pr_Write('V','ALTCHECK',p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).char_field20);
               Cspks_Req_Global.Pr_Write('V','CHAR_FIELD21',p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).char_field21);
            ELSE
               Cspks_Req_Global.Pr_Write('V','ALTCHECK',NULL);
               Cspks_Req_Global.Pr_Write('V','CHAR_FIELD21',NULL);
            END IF;
            Cspks_Req_Global.Pr_Write('V','PRESNBNKCHG',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).present_bank_chg);
            Cspks_Req_Global.Pr_Write('V','CHQRETNAMT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).cheque_retn_amt);
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_cgdiwcgd          IN cgpks_cgdiwcgd_Main.ty_cgdiwcgd,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_2_Lvl_Counter   NUMBER := 0;
      l_Dsn_Rec_Cnt_2    NUMBER;
      l_Bnd_Cntr_2    NUMBER;
      l_Dsn_Rec_Cnt_3    NUMBER;
      l_Bnd_Cntr_3    NUMBER;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF (  p_cgdiwcgd.v_cgvws_inward_clg_upload.scode IS NOT NULL 
         AND  p_cgdiwcgd.v_cgvws_inward_clg_upload.xref IS NOT NULL 
         AND  p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1 IS NOT NULL 
          )
          THEN
            l_1_Lvl_Counter := 0;
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Cgvw-Clearing-Upload-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','STATS',p_cgdiwcgd.v_cgvws_inward_clg_upload.status);
            Cspks_Req_Global.Pr_Write('V','CURR',p_cgdiwcgd.v_cgvws_inward_clg_upload.currency);
            Cspks_Req_Global.Pr_Write('V','ENDPOINT',p_cgdiwcgd.v_cgvws_inward_clg_upload.endpoint);
            IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate) <>
                  p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate THEN
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','TRANS_DATE',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','REMBRANCH_F',p_cgdiwcgd.v_cgvws_inward_clg_upload.rembranch);
            Cspks_Req_Global.Pr_Write('V','REMITTER',p_cgdiwcgd.v_cgvws_inward_clg_upload.remaccount);
            Cspks_Req_Global.Pr_Write('V','REMACCCCY',p_cgdiwcgd.v_cgvws_inward_clg_upload.acc_ccy);
            Cspks_Req_Global.Pr_Write('V','PROD',p_cgdiwcgd.v_cgvws_inward_clg_upload.prod);
            Cspks_Req_Global.Pr_Write('V','INSTRUMENT_NO',p_cgdiwcgd.v_cgvws_inward_clg_upload.instrno);
            Cspks_Req_Global.Pr_Write('V','AMOUNT',p_cgdiwcgd.v_cgvws_inward_clg_upload.instramt);
            Cspks_Req_Global.Pr_Write('V','BENACCOUNT',p_cgdiwcgd.v_cgvws_inward_clg_upload.benaccount);
            Cspks_Req_Global.Pr_Write('V','AUTHSTATUS',p_cgdiwcgd.v_cgvws_inward_clg_upload.auth_stat);
            Cspks_Req_Global.Pr_Write('V','SOURCE',p_cgdiwcgd.v_cgvws_inward_clg_upload.scode);
            Cspks_Req_Global.Pr_Write('V','ENTRYNO',p_cgdiwcgd.v_cgvws_inward_clg_upload.entry_no);
            Cspks_Req_Global.Pr_Write('V','INSTRUMENT_TYPE',p_cgdiwcgd.v_cgvws_inward_clg_upload.instr_type);
            Cspks_Req_Global.Pr_Write('V','DIRECTION',p_cgdiwcgd.v_cgvws_inward_clg_upload.direction);
            Cspks_Req_Global.Pr_Write('V','USER_ID',p_cgdiwcgd.v_cgvws_inward_clg_upload.maker_id);
            Cspks_Req_Global.Pr_Write('V','REJ_REASON_CODE',p_cgdiwcgd.v_cgvws_inward_clg_upload.rej_reason_code);
            Cspks_Req_Global.Pr_Write('V','XREF',p_cgdiwcgd.v_cgvws_inward_clg_upload.xref);
            Cspks_Req_Global.Pr_Write('V','BATCH_NO',p_cgdiwcgd.v_cgvws_inward_clg_upload.batch_no);
            Cspks_Req_Global.Pr_Write('V','FCCREF1',p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1);

            --Dbg('Building Childs Of :BLK_CGVWS_INWARD_CLG_UPLOAD..');
            l_Dsn_Rec_Cnt_2 := 0;
            IF p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT > 0 THEN
               FOR i_2 IN  1..p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT LOOP
                  l_Dsn_Rec_Cnt_2 := i_2;
                  l_Dsn_Rec_Cnt_3 := 0;
                  IF p_cgdiwcgd.v_cstb_ui_columns.COUNT > 0 THEN
                     FOR i_3 IN  1..p_cgdiwcgd.v_cstb_ui_columns.COUNT LOOP
                        IF NVL(p_cgdiwcgd.v_cstb_ui_columns(i_3).char_field21,'@') = NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.xref,'@') THEN
                           l_Dsn_Rec_Cnt_3 := i_3;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  l_Master_Childs  :=  l_Master_Childs +1;
                  l_1_Lvl_Counter   := l_1_Lvl_Counter +1;
                  l_Level_Format      := l_0_Lvl_Counter||'.'||l_1_Lvl_Counter;
                  Cspks_Req_Global.Pr_Write('P','Cgvw-Clearing-Upld',l_Level_Format);
                  Cspks_Req_Global.Pr_Write('V','SOURCE_CODE',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).scode1);
                  Cspks_Req_Global.Pr_Write('V','XREF',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).xref1);
                  Cspks_Req_Global.Pr_Write('V','ENTRYNO',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).entry_no1);
                  Cspks_Req_Global.Pr_Write('V','STATS',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).status1);
                  Cspks_Req_Global.Pr_Write('V','REJ_REASON_CODE',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).rej_reason_code);
                  Cspks_Req_Global.Pr_Write('V','FORCE_POSTING',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).force_posting);
                  Cspks_Req_Global.Pr_Write('V','REJ_ADV_REQD',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).rej_adv_reqd);
                  Cspks_Req_Global.Pr_Write('V','PROD',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).prod);
                  Cspks_Req_Global.Pr_Write('V','REM_ACC_NO',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).remaccount);
                  Cspks_Req_Global.Pr_Write('V','REMBRANCH_F',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).rembranch);
                  Cspks_Req_Global.Pr_Write('V','BENACCOUNT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).benaccount);
                  Cspks_Req_Global.Pr_Write('V','INSTNO',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrno);
                  Cspks_Req_Global.Pr_Write('V','INSTRCCY',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrccy);
                  Cspks_Req_Global.Pr_Write('V','INSTRAMT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instramt);
                  Cspks_Req_Global.Pr_Write('V','ROUTING_NO',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).routingno);
                  Cspks_Req_Global.Pr_Write('V','CCY_CD',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).acc_ccy);
                  IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txndate) <>
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txndate THEN
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txndate,Cspks_Req_Global.g_Ws_Date_Time_Format);
                  ELSE
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txndate,Cspks_Req_Global.g_Ws_Date_Format);
                  END IF;
                  Cspks_Req_Global.Pr_Write('V','LIQUIDATION_DATE',l_Date_Val);
                  Cspks_Req_Global.Pr_Write('V','ENDPOINT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).endpoint);
                  Cspks_Req_Global.Pr_Write('V','TXN_BRN',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).txn_brn);
                  Cspks_Req_Global.Pr_Write('V','REM_BANK',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).rembank);
                  IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrdate) <>
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrdate THEN
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrdate,Cspks_Req_Global.g_Ws_Date_Time_Format);
                  ELSE
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instrdate,Cspks_Req_Global.g_Ws_Date_Format);
                  END IF;
                  Cspks_Req_Global.Pr_Write('V','INSTRDATE',l_Date_Val);
                  IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatebnk) <>
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatebnk THEN
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatebnk,Cspks_Req_Global.g_Ws_Date_Time_Format);
                  ELSE
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatebnk,Cspks_Req_Global.g_Ws_Date_Format);
                  END IF;
                  Cspks_Req_Global.Pr_Write('V','VALDATEBNK',l_Date_Val);
                  IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatecust) <>
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatecust THEN
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatecust,Cspks_Req_Global.g_Ws_Date_Time_Format);
                  ELSE
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).valdatecust,Cspks_Req_Global.g_Ws_Date_Format);
                  END IF;
                  Cspks_Req_Global.Pr_Write('V','VALDATECUST',l_Date_Val);
                  Cspks_Req_Global.Pr_Write('V','FCCREF',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).fccref);
                  Cspks_Req_Global.Pr_Write('V','MAKER_ID',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_id);
                  IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_dt_stamp) <>
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_dt_stamp THEN
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
                  ELSE
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).maker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
                  END IF;
                  Cspks_Req_Global.Pr_Write('V','MAKER_DT_STAMP',l_Date_Val);
                  IF trunc(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_dt_stamp) <>
                        p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_dt_stamp THEN
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Time_Format);
                  ELSE
                     l_Date_Val :=  TO_CHAR( p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_dt_stamp,Cspks_Req_Global.g_Ws_Date_Format);
                  END IF;
                  Cspks_Req_Global.Pr_Write('V','CHECKER_DT_STAMP',l_Date_Val);
                  Cspks_Req_Global.Pr_Write('V','CHECKER_ID',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).checker_id);
                  Cspks_Req_Global.Pr_Write('V','ERROR_CODE',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).error_codes);
                  Cspks_Req_Global.Pr_Write('V','ERROR_PARAMS',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).error_params);
                  Cspks_Req_Global.Pr_Write('V','REMRKS',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).remarks);
                  Cspks_Req_Global.Pr_Write('V','BENCUST',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).ben_cust);
                  Cspks_Req_Global.Pr_Write('V','UPLOAD_STAT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).err_msg);
                  Cspks_Req_Global.Pr_Write('V','INSTRUMENT_TYPE',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).instr_type);
                  Cspks_Req_Global.Pr_Write('V','DIRECTION',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).direction);
                  Cspks_Req_Global.Pr_Write('V','CUSTNAME',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).custname);
                  Cspks_Req_Global.Pr_Write('V','AUTHSTATUS',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).auth_stat);
                  Cspks_Req_Global.Pr_Write('V','WAIVE_REJ_CHG',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).waive_reject_chg);
                  Cspks_Req_Global.Pr_Write('V','BENROUTINGNO',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).benroutingno);
                  IF l_Dsn_rec_cnt_3 > 0 THEN
                     Cspks_Req_Global.Pr_Write('V','ALTCHECK',p_cgdiwcgd.v_cstb_ui_columns(l_Dsn_Rec_Cnt_3).char_field20);
                  ELSE
                     Cspks_Req_Global.Pr_Write('V','ALTCHECK',NULL);
                  END IF;
                  Cspks_Req_Global.Pr_Write('V','PRESN_BNK_CHG_AMT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).present_bank_chg);
                  Cspks_Req_Global.Pr_Write('V','CHQ_RETN_AMT',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Dsn_Rec_Cnt_2).cheque_retn_amt);
               END LOOP;
            END IF;
         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Cgvw-Clearing-Upload-PK','1');
         l_Key_Cols := 'SOURCE~'||'XREF~'||'FCCREF1~';
         l_Key_Vals := p_cgdiwcgd.v_cgvws_inward_clg_upload.scode||'~'||p_cgdiwcgd.v_cgvws_inward_clg_upload.xref||'~'||p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_cgdiwcgd IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.SCODE';
      IF p_cgdiwcgd.v_cgvws_inward_clg_upload.scode IS Null THEN
         Dbg('Field scode is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.XREF';
      IF p_cgdiwcgd.v_cgvws_inward_clg_upload.xref IS Null THEN
         Dbg('Field xref is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.FCCREF1';
      IF p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1 IS Null THEN
         Dbg('Field fccref1 is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'CGVWS_INWARD_CLG_UPLOAD';

         l_Blk := 'CGVWS_INWARD_CLG_UPLD';
         l_Count := p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
         IF l_Count > 0 THEN
            FOR l_index IN 1 .. p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT LOOP
               l_Fld := 'CGVWS_INWARD_CLG_UPLD.XREF1';
               IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Index).xref1 IS Null THEN
                  Dbg('Primary Key Column xref1 Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
               l_Fld := 'CGVWS_INWARD_CLG_UPLD.FCCREF';
               IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_Index).fccref IS Null THEN
                  Dbg('Primary Key Column fccref Cannot Be Null');
                  l_Key := Null;
                  Pr_Log_Error(p_Source,'ST-MAND-003','@'||l_Fld||'~@'||l_Blk||'~'||l_index );
               END IF;
            END LOOP;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.ty_cgdiwcgd,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      IF p_cgdiwcgd.v_cgvws_inward_clg_upload.STATUS IS NOT NULL THEN
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.STATUS NOT IN ('OVER','UNPR','SUCC','REJR','ERRR') THEN
            dbg('Invalid Value For The Field  :STATUS:'||p_cgdiwcgd.v_cgvws_inward_clg_upload.STATUS);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_cgdiwcgd.v_cgvws_inward_clg_upload.STATUS||'~@CGVWS_INWARD_CLG_UPLOAD.STATUS~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      IF p_cgdiwcgd.v_cgvws_inward_clg_upload.AUTH_STAT IS NOT NULL THEN
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.AUTH_STAT NOT IN ('A','U') THEN
            dbg('Invalid Value For The Field  :AUTH_STAT:'||p_cgdiwcgd.v_cgvws_inward_clg_upload.AUTH_STAT);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_cgdiwcgd.v_cgvws_inward_clg_upload.AUTH_STAT||'~@CGVWS_INWARD_CLG_UPLOAD.AUTH_STAT~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      IF p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTR_TYPE IS NOT NULL THEN
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTR_TYPE NOT IN ('CHQ','DD','BC') THEN
            dbg('Invalid Value For The Field  :INSTR_TYPE:'||p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTR_TYPE);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_cgdiwcgd.v_cgvws_inward_clg_upload.INSTR_TYPE||'~@CGVWS_INWARD_CLG_UPLOAD.INSTR_TYPE~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      IF p_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION IS NOT NULL THEN
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION NOT IN ('I') THEN
            dbg('Invalid Value For The Field  :DIRECTION:'||p_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION||'~@CGVWS_INWARD_CLG_UPLOAD.DIRECTION~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      l_Count      := p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_Count LOOP
            l_Key := NULL;
            IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).STATUS1 IS NOT NULL THEN
               IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).STATUS1 NOT IN ('OVER','UNPR','SUCC','REJR','ERRR') THEN
                  dbg('Invalid Value For The Field  :STATUS1:'||p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).STATUS1);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).STATUS1||'~@CGVWS_INWARD_CLG_UPLD.STATUS1'||'~'||l_Key||'~@CGVWS_INWARD_CLG_UPLD') ;
               END IF;
            END IF;
            IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).FORCE_POSTING IS NOT NULL THEN
               IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).FORCE_POSTING NOT IN ('Y','N') THEN
                  dbg('Invalid Value For The Field  :FORCE_POSTING:'||p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).FORCE_POSTING);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).FORCE_POSTING||'~@CGVWS_INWARD_CLG_UPLD.FORCE_POSTING'||'~'||l_Key||'~@CGVWS_INWARD_CLG_UPLD') ;
               END IF;
            END IF;
            IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).REJ_ADV_REQD IS NOT NULL THEN
               IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).REJ_ADV_REQD NOT IN ('Y','N') THEN
                  dbg('Invalid Value For The Field  :REJ_ADV_REQD:'||p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).REJ_ADV_REQD);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).REJ_ADV_REQD||'~@CGVWS_INWARD_CLG_UPLD.REJ_ADV_REQD'||'~'||l_Key||'~@CGVWS_INWARD_CLG_UPLD') ;
               END IF;
            END IF;
            IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).AUTH_STAT IS NOT NULL THEN
               IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).AUTH_STAT NOT IN ('A','U') THEN
                  dbg('Invalid Value For The Field  :AUTH_STAT:'||p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).AUTH_STAT);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).AUTH_STAT||'~@CGVWS_INWARD_CLG_UPLD.AUTH_STAT'||'~'||l_Key||'~@CGVWS_INWARD_CLG_UPLD') ;
               END IF;
            END IF;
            IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).WAIVE_REJECT_CHG IS NOT NULL THEN
               IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).WAIVE_REJECT_CHG NOT IN ('Y','N') THEN
                  dbg('Invalid Value For The Field  :WAIVE_REJECT_CHG:'||p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).WAIVE_REJECT_CHG);
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                  Pr_Log_Error(p_Source,'ST-VALS-013',p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).WAIVE_REJECT_CHG||'~@CGVWS_INWARD_CLG_UPLD.WAIVE_REJECT_CHG'||'~'||l_Key||'~@CGVWS_INWARD_CLG_UPLD') ;
               END IF;
            END IF;
         END LOOP;
      END IF;
      Dbg('Duplicate Records Check For :v_cgvws_inward_clg_upld..');
      l_Count      := p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
      IF l_Count > 0 THEN
         FOR l_index  IN 1 .. l_count LOOP
            l_key := NULL;
            IF l_index < l_Count THEN
               FOR l_index1 IN l_index+1 .. l_Count LOOP
                  IF (NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).scode1,'@')=  NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).scode1,'@')) AND (NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1,'@')=  NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).xref1,'@')) AND (NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref,'@')=  NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).fccref,'@')) THEN
                     Dbg('Duplicare Record Found for :'||l_Key);
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.SCODE1')||'-'||
                     p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).scode1||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                     p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                     p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                     Pr_Log_Error(p_Source,'ST-VALS-009','@CGVWS_INWARD_CLG_UPLD~'||l_Key);
                  END IF;
               END LOOP;
            END IF;
         END LOOP;
      END IF;
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_cgdiwcgd     IN  OUT cgpks_cgdiwcgd_Main.ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      IF p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION IS NULL THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION := 'I';
      END IF;
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Merge_Amendables        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Prev_cgdiwcgd IN cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Wrk_cgdiwcgd IN OUT cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Wrk_Count      NUMBER := 0 ;
      l_Deleted_Recs   NUMBER := 0;
      l_Modified_Flds  VARCHAR2(32000):= NULL;
      l_Key            VARCHAR2(5000):= NULL;
      l_Mod_Fld        VARCHAR2(100):= NULL;
      i                NUMBER := 1;
      l_Rec_Found      BOOLEAN := FALSE;
      l_Rec_Modified   BOOLEAN := FALSE;
      l_Rec_Sent       BOOLEAN := FALSE;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Pk_Or_Full     VARCHAR2(5) :='FULL';
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Mod_No         NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Amendable_Nodes Cspks_Req_Global.Ty_Amend_Nodes;
      l_Amendable_Fields Cspks_Req_Global.Ty_Amend_Fields;
      N_v_cgvws_inward_clg_upld       cgpks_cgdiwcgd_Main.Ty_Tb_v_cgvws_inward_clg_upld;

      FUNCTION Fn_Amendable(p_Item IN VARCHAR2) RETURN BOOLEAN IS
      BEGIN
         IF l_Amendable_Fields.EXISTS(p_Item) THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END Fn_Amendable;
   BEGIN

      Dbg('In Fn_Sys_Merge_Amendables');

      Dbg('Calling Cspks_Req_Utils.Fn_Get_Amendable_Details..');
      IF NOT Cspks_Req_Utils.Fn_Get_Amendable_Details(p_source ,
         p_Source_Operation,
         l_Amendable_Nodes,
         l_Amendable_Fields,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      l_Blk := 'CGVWS_INWARD_CLG_UPLOAD';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.STATUS';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.STATUS') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.status := p_cgdiwcgd.v_cgvws_inward_clg_upload.status;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.status IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.status,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.status,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.CURRENCY';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.CURRENCY') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.currency := p_cgdiwcgd.v_cgvws_inward_clg_upload.currency;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.currency IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.currency,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.currency,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.ENDPOINT';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.ENDPOINT') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.endpoint := p_cgdiwcgd.v_cgvws_inward_clg_upload.endpoint;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.endpoint IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.endpoint,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.endpoint,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.TXNDATE';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.TXNDATE') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.txndate := p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.txndate,global.min_date) <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.txndate,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.REMBRANCH';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.REMBRANCH') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.rembranch := p_cgdiwcgd.v_cgvws_inward_clg_upload.rembranch;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.rembranch IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.rembranch,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.rembranch,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.REMACCOUNT';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.REMACCOUNT') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.remaccount := p_cgdiwcgd.v_cgvws_inward_clg_upload.remaccount;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.remaccount IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.remaccount,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.remaccount,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.ACC_CCY';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.ACC_CCY') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.acc_ccy := p_cgdiwcgd.v_cgvws_inward_clg_upload.acc_ccy;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.acc_ccy IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.acc_ccy,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.acc_ccy,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.PROD';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.PROD') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.prod := p_cgdiwcgd.v_cgvws_inward_clg_upload.prod;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.prod IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.prod,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.prod,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.INSTRNO';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.INSTRNO') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.instrno := p_cgdiwcgd.v_cgvws_inward_clg_upload.instrno;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.instrno IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.instrno,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.instrno,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.INSTRAMT';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.INSTRAMT') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.instramt := p_cgdiwcgd.v_cgvws_inward_clg_upload.instramt;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.instramt IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.instramt,-1) <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.instramt,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.BENACCOUNT';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.BENACCOUNT') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.benaccount := p_cgdiwcgd.v_cgvws_inward_clg_upload.benaccount;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.benaccount IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.benaccount,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.benaccount,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.AUTH_STAT';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.AUTH_STAT') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.auth_stat := p_cgdiwcgd.v_cgvws_inward_clg_upload.auth_stat;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.auth_stat IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.auth_stat,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.auth_stat,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.ENTRY_NO';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.ENTRY_NO') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.entry_no := p_cgdiwcgd.v_cgvws_inward_clg_upload.entry_no;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.entry_no IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.entry_no,-1) <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.entry_no,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.INSTR_TYPE';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.INSTR_TYPE') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.instr_type := p_cgdiwcgd.v_cgvws_inward_clg_upload.instr_type;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.instr_type IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.instr_type,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.instr_type,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.DIRECTION';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.DIRECTION') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.direction := p_cgdiwcgd.v_cgvws_inward_clg_upload.direction;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.direction IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.direction,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.direction,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.MAKER_ID';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.MAKER_ID') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.maker_id := p_cgdiwcgd.v_cgvws_inward_clg_upload.maker_id;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.maker_id IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.maker_id,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.maker_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.REJ_REASON_CODE';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.REJ_REASON_CODE') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.rej_reason_code := p_cgdiwcgd.v_cgvws_inward_clg_upload.rej_reason_code;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.rej_reason_code IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.rej_reason_code,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.rej_reason_code,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CGVWS_INWARD_CLG_UPLOAD.BATCH_NO';
      IF Fn_Amendable('CGVWS_INWARD_CLG_UPLOAD.BATCH_NO') THEN
         p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.batch_no := p_cgdiwcgd.v_cgvws_inward_clg_upload.batch_no;
      ELSE
         IF p_cgdiwcgd.v_cgvws_inward_clg_upload.batch_no IS NOT NULL THEN
            IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.batch_no,'@') <>
               NVL(p_cgdiwcgd.v_cgvws_inward_clg_upload.batch_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;

      l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
      IF  l_Rec_Modified THEN
         IF l_Modified_Flds IS NOT NULL THEN
            i :=  1;
            l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
            WHILE l_Mod_Fld <> 'EOPL' LOOP
               Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
               i := i +1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
            END LOOP;
         END IF;
      END IF;
      l_Blk := 'CGVWS_INWARD_CLG_UPLD';
      l_Count      := p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
      l_Wrk_Count  := p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
      IF l_Count > 0 THEN
         FOR l_index IN 1..l_Count  LOOP
            l_Rec_Found := FALSE;
            l_Rec_Modified := FALSE;
            l_Modified_Flds := NULL;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1,'@')=  NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).xref1,'@')) AND (NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref,'@')=  NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).fccref,'@')) THEN
                     Dbg('Record Found..');
                     l_Rec_Found := TRUE;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.ENTRY_NO1';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.ENTRY_NO1') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).entry_no1 := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).entry_no1;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).entry_no1 IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).entry_no1,-1) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).entry_no1,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.STATUS1';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.STATUS1') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).status1 := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).status1;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).status1 IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).status1,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).status1,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.REJ_REASON_CODE';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.REJ_REASON_CODE') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).rej_reason_code := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rej_reason_code;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rej_reason_code IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).rej_reason_code,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rej_reason_code,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.FORCE_POSTING';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.FORCE_POSTING') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).force_posting := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).force_posting;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).force_posting IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).force_posting,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).force_posting,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.REJ_ADV_REQD';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.REJ_ADV_REQD') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).rej_adv_reqd := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rej_adv_reqd;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rej_adv_reqd IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).rej_adv_reqd,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rej_adv_reqd,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.PROD';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.PROD') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).prod := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).prod;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).prod IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).prod,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).prod,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.REMACCOUNT';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.REMACCOUNT') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).remaccount := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).remaccount;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).remaccount IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).remaccount,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).remaccount,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.REMBRANCH';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.REMBRANCH') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).rembranch := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rembranch;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rembranch IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).rembranch,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rembranch,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.BENACCOUNT';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.BENACCOUNT') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).benaccount := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).benaccount;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).benaccount IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).benaccount,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).benaccount,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.INSTRNO';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.INSTRNO') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instrno := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrno;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrno IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instrno,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrno,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.INSTRCCY';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.INSTRCCY') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instrccy := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrccy;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrccy IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instrccy,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.INSTRAMT';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.INSTRAMT') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instramt := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instramt;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instramt IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instramt,-1) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instramt,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.ROUTINGNO';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.ROUTINGNO') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).routingno := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).routingno;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).routingno IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).routingno,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).routingno,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.ACC_CCY';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.ACC_CCY') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).acc_ccy := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).acc_ccy;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).acc_ccy IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).acc_ccy,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).acc_ccy,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.TXNDATE';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.TXNDATE') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).txndate := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).txndate;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).txndate IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).txndate,global.min_date) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).txndate,global.min_date)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.ENDPOINT';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.ENDPOINT') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).endpoint := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).endpoint;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).endpoint IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).endpoint,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).endpoint,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.TXN_BRN';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.TXN_BRN') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).txn_brn := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).txn_brn;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).txn_brn IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).txn_brn,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).txn_brn,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.REMBANK';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.REMBANK') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).rembank := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rembank;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rembank IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).rembank,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).rembank,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.INSTRDATE';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.INSTRDATE') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instrdate := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrdate;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrdate IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instrdate,global.min_date) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instrdate,global.min_date)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.VALDATEBNK';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.VALDATEBNK') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).valdatebnk := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).valdatebnk;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).valdatebnk IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).valdatebnk,global.min_date) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).valdatebnk,global.min_date)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.VALDATECUST';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.VALDATECUST') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).valdatecust := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).valdatecust;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).valdatecust IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).valdatecust,global.min_date) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).valdatecust,global.min_date)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.MAKER_ID';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.MAKER_ID') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).maker_id := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).maker_id;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).maker_id IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).maker_id,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).maker_id,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.MAKER_DT_STAMP';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.MAKER_DT_STAMP') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).maker_dt_stamp := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).maker_dt_stamp;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).maker_dt_stamp IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).maker_dt_stamp,global.min_date) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).maker_dt_stamp,global.min_date)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.CHECKER_DT_STAMP';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.CHECKER_DT_STAMP') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).checker_dt_stamp := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).checker_dt_stamp;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).checker_dt_stamp IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).checker_dt_stamp,global.min_date) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).checker_dt_stamp,global.min_date)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.CHECKER_ID';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.CHECKER_ID') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).checker_id := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).checker_id;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).checker_id IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).checker_id,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).checker_id,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.ERROR_CODES';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.ERROR_CODES') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).error_codes := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).error_codes;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).error_codes IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).error_codes,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).error_codes,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.ERROR_PARAMS';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.ERROR_PARAMS') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).error_params := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).error_params;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).error_params IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).error_params,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).error_params,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.REMARKS';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.REMARKS') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).remarks := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).remarks;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).remarks IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).remarks,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).remarks,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.BEN_CUST';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.BEN_CUST') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).ben_cust := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).ben_cust;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).ben_cust IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).ben_cust,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).ben_cust,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.ERR_MSG';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.ERR_MSG') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).err_msg := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).err_msg;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).err_msg IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).err_msg,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).err_msg,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.INSTR_TYPE';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.INSTR_TYPE') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instr_type := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instr_type;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instr_type IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).instr_type,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).instr_type,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.DIRECTION';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.DIRECTION') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).direction := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).direction;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).direction IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).direction,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).direction,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.CUSTNAME';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.CUSTNAME') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).custname := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).custname;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).custname IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).custname,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).custname,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.AUTH_STAT';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.AUTH_STAT') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).auth_stat := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).auth_stat;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).auth_stat IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).auth_stat,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).auth_stat,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.WAIVE_REJECT_CHG';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.WAIVE_REJECT_CHG') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).waive_reject_chg := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).waive_reject_chg;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).waive_reject_chg IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).waive_reject_chg,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).waive_reject_chg,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.BENROUTINGNO';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.BENROUTINGNO') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).benroutingno := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).benroutingno;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).benroutingno IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).benroutingno,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).benroutingno,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.SMALL_ACC_NO';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.SMALL_ACC_NO') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).small_acc_no := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).small_acc_no;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).small_acc_no IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).small_acc_no,-1) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).small_acc_no,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.PRESENT_BANK_CHG';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.PRESENT_BANK_CHG') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).present_bank_chg := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).present_bank_chg;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).present_bank_chg IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).present_bank_chg,-1) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).present_bank_chg,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.CHEQUE_RETN_AMT';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.CHEQUE_RETN_AMT') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).cheque_retn_amt := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).cheque_retn_amt;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).cheque_retn_amt IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).cheque_retn_amt,-1) <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).cheque_retn_amt,-1)  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;
                     l_fld := 'CGVWS_INWARD_CLG_UPLD.BATCH_NO';
                     IF Fn_Amendable('CGVWS_INWARD_CLG_UPLD.BATCH_NO') THEN
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).batch_no := p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).batch_no;
                     ELSE
                        IF p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).batch_no IS NOT NULL THEN
                           IF NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).batch_no,'@') <>
                              NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).batch_no,'@')  THEN
                              l_Modified_flds := l_Modified_Flds ||'~'||l_Fld;
                              l_Rec_Modified  := TRUE;
                           END IF;
                        END IF;
                     END IF;

                     l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
                     IF  l_Rec_modified THEN
                        IF l_Modified_Flds IS NOT NULL THEN
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                           p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                           Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                           p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                           i :=  1;
                           l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           WHILE l_mod_fld <> 'EOPL' LOOP
                              Pr_Log_Error(p_Source,'ST-AMND-003','@'||l_Mod_Fld||'~@'||l_Blk||'~'||l_Key );
                              i := i +1;
                              l_Mod_Fld := Cspkes_Misc.Fn_GetParam(l_Modified_Flds,i,'~');
                           END LOOP;
                        END IF;
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT +1 ) :=  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index);
               IF l_Amendable_Nodes.EXISTS('CGVWS_INWARD_CLG_UPLD') THEN
                  IF l_Amendable_Nodes('CGVWS_INWARD_CLG_UPLD').New_Allowed = 'N' THEN
                     Dbg('New Record Cannot Be Added..');
                     l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                     p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                     Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                     p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                     Pr_Log_Error(p_source,'ST-AMND-004',l_key||'~@'||l_blk);
                  END IF;
               ELSE
                  Dbg('New Record Cannot Be Added..');
                  l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1||':'||
                  Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                  p_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref;
                  Pr_Log_Error(p_Source,'ST-AMND-004',l_key||'~@'||l_blk);
               END IF;
            END IF;
         END LOOP;
      END IF;

      IF l_Amendable_Nodes.EXISTS('CGVWS_INWARD_CLG_UPLD') THEN
         IF l_Amendable_Nodes('CGVWS_INWARD_CLG_UPLD').All_Records = 'Y' THEN
            Dbg('Logic For Deleting Some Records From Work Record  if Not sent..');
            l_Wrk_Count := p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
            l_Count     := p_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
            IF l_Wrk_Count > 0 THEN
               FOR l_index1 IN 1..l_Wrk_count  LOOP
                  l_Rec_Found := FALSE;
                  IF l_Count > 0 THEN
                     FOR l_index IN 1..l_Count  LOOP
                        IF (NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).xref1,'@')=  NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld  (l_index).xref1,'@')) AND (NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).fccref,'@')=  NVL(p_cgdiwcgd.v_cgvws_inward_clg_upld  (l_index).fccref,'@')) THEN
                           Dbg('Record Found..');
                           l_Rec_Found := TRUE;
                           EXIT;
                        END IF;
                     END LOOP;
                  END IF;
                  IF l_Rec_Found THEN
                     Dbg('Adding  a Record...');
                     N_v_cgvws_inward_clg_upld(N_v_cgvws_inward_clg_upld.COUNT +1 ) :=  p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_Index1);
                  ELSE
                     l_Deleted_Recs := l_Deleted_Recs +1;
                     IF l_Amendable_Nodes.EXISTS('CGVWS_INWARD_CLG_UPLD') THEN
                        IF l_Amendable_Nodes('CGVWS_INWARD_CLG_UPLD').Delete_Allowed = 'N' THEN
                           Dbg('Record Cannot Be Deleted..');
                           l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                           p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).xref1||':'||
                           Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                           p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).fccref;
                           Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                        END IF;
                     ELSE
                        Dbg('Record Cannot Be Deleted..');
                        l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.XREF1')||'-'||
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).xref1||':'||
                        Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLD.FCCREF')||'-'||
                        p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1).fccref;
                        Pr_Log_Error(p_Source,'ST-AMND-006',l_Key||'~@'||l_Blk);
                     END IF;
                  END IF;
               END LOOP;
            END IF;
            p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld:= N_v_cgvws_inward_clg_upld;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Merge_Amendables..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Merge_Amendables..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Merge_Amendables;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_cgdiwcgd IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER  := 0;
      l_Dsn_Rec_Cnt_3 NUMBER := 0;
      l_Bnd_Cntr_3    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      l_Blk := 'CGVWS_INWARD_CLG_UPLOAD';
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.CURRENCY';
      IF p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.CURRENCY IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT CCY_CODE, CCY_NAME FROM CYTMS_CCY_DEFN WHERE AUTH_STAT = 'A' AND RECORD_STAT = 'O' ORDER BY CCY_CODE) WHERE CCY_CODE = P_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.CURRENCY;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :CURRENCY:'||p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.CURRENCY);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.CURRENCY||'~@CGVWS_INWARD_CLG_UPLOAD.CURRENCY~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.ENDPOINT';
      IF p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ENDPOINT IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT ALL STTM_END_POINT.END_POINT, STTM_END_POINT.END_POINT_DESCRIPTION FROM STTM_END_POINT WHERE AUTH_STAT='A' AND RECORD_STAT='O' ORDER BY END_POINT) WHERE END_POINT = P_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ENDPOINT;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :ENDPOINT:'||p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ENDPOINT);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ENDPOINT||'~@CGVWS_INWARD_CLG_UPLOAD.ENDPOINT~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.REMBRANCH';
      IF p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMBRANCH IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT BRANCH_CODE, BRANCH_NAME FROM STTM_BRANCH WHERE AUTH_STAT = 'A' AND RECORD_STAT ='O' ORDER BY BRANCH_CODE) WHERE BRANCH_CODE = P_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMBRANCH;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :REMBRANCH:'||p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMBRANCH);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMBRANCH||'~@CGVWS_INWARD_CLG_UPLOAD.REMBRANCH~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.REMACCOUNT';
      IF p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMACCOUNT IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT DISTINCT(REM_ACCOUNT), ACC_BRANCH FROM CSTBS_IW_CLEARING_MASTER ORDER BY ACC_BRANCH) WHERE REM_ACCOUNT = P_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMACCOUNT;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :REMACCOUNT:'||p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMACCOUNT);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMACCOUNT||'~@CGVWS_INWARD_CLG_UPLOAD.REMACCOUNT~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.ACC_CCY';
      IF p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ACC_CCY IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT CCY_CODE, CCY_NAME FROM CYTMS_CCY_DEFN WHERE AUTH_STAT = 'A' AND RECORD_STAT = 'O' ORDER BY CCY_CODE) WHERE CCY_CODE = P_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ACC_CCY;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :ACC_CCY:'||p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ACC_CCY);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ACC_CCY||'~@CGVWS_INWARD_CLG_UPLOAD.ACC_CCY~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.PROD';
      IF p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.PROD IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT PRODUCT_CODE, PRODUCT_DESCRIPTION FROM CSTM_PRODUCT WHERE MODULE = 'CG' AND RECORD_STAT = 'O' AND AUTH_STAT = 'A' ORDER BY PRODUCT_CODE) WHERE PRODUCT_CODE = P_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.PROD;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :PROD:'||p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.PROD);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.PROD||'~@CGVWS_INWARD_CLG_UPLOAD.PROD~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.MAKER_ID';
      IF p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.MAKER_ID IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT DISTINCT(MAKER_ID) FROM CSTBS_IW_CLEARING_MASTER) WHERE MAKER_ID = P_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.MAKER_ID;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :MAKER_ID:'||p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.MAKER_ID);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.MAKER_ID||'~@CGVWS_INWARD_CLG_UPLOAD.MAKER_ID~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      l_Fld := 'CGVWS_INWARD_CLG_UPLOAD.XREF';
      IF p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.XREF IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT DISTINCT XREF FROM CSTBS_IW_CLEARING_MASTER WHERE TXN_BRANCH = GLOBAL.CURRENT_BRANCH) WHERE XREF = P_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.XREF;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :XREF:'||p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.XREF);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.XREF||'~@CGVWS_INWARD_CLG_UPLOAD.XREF~@CGVWS_INWARD_CLG_UPLOAD') ;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Prev_cgdiwcgd IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Wrk_cgdiwcgd IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_cgdiwcgd  IN   OUT cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      Cursor c_v_cstb_ui_columns IS
      SELECT *
      FROM   CSTB_UI_COLUMNS
      WHERE char_field21 = p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.xref
      ;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Querying Query Data Sources..');
      Dbg('Get the Record For :CSTB_UI_COLUMNS');
      OPEN c_v_cstb_ui_columns;
      LOOP
         FETCH c_v_cstb_ui_columns
         BULK COLLECT INTO p_Wrk_cgdiwcgd.v_cstb_ui_columns;
          EXIT WHEN c_v_cstb_ui_columns%NOTFOUND;
      END LOOP;
      CLOSE c_v_cstb_ui_columns;
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Sys_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_cgdiwcgd         IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Wrk_cgdiwcgd  IN   OUT cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Wrk_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists        BOOLEAN := TRUE;
      RECORD_LOCKED    EXCEPTION;
      PRAGMA EXCEPTION_INIT( RECORD_LOCKED, -54 );
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      Cursor c_v_cgvws_inward_clg_upld IS
      SELECT *
      FROM   CGVW_INWARD_CLG_UPLD
      WHERE scode1 = p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.scode
      ;
   BEGIN
      Dbg('In Fn_Sys_Query..');
      IF p_QryData_Reqd = 'Q' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_cgdiwcgd,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      ELSE
         l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLOAD.SCODE')||'-'||
         p_cgdiwcgd.v_cgvws_inward_clg_upload.scode||':'||
         Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLOAD.XREF')||'-'||
         p_cgdiwcgd.v_cgvws_inward_clg_upload.xref||':'||
         Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CGVWS_INWARD_CLG_UPLOAD.FCCREF1')||'-'||
         p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1;
         Dbg('Get The Master Record...');
         IF NVL(p_With_Lock,'N') = 'Y' THEN
            BEGIN
               SELECT *
               INTO   p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload
               FROM  CGVW_INWARD_CLG_UPLOAD
               WHERE scode = p_cgdiwcgd.v_cgvws_inward_clg_upload.scode
                AND xref = p_cgdiwcgd.v_cgvws_inward_clg_upload.xref
                AND fccref1 = p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1
                FOR UPDATE NOWAIT;
            EXCEPTION
               WHEN RECORD_LOCKED THEN
                  Dbg('Failed to Obtain the Lock..');
                  Pr_Log_Error(p_Source,'ST-LOCK-001',NULL);
                  RETURN FALSE;
               WHEN No_Data_Found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  l_Rec_Exists := FALSE;
            END;

         ELSE
            BEGIN
               SELECT *
               INTO   p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload
               FROM  CGVW_INWARD_CLG_UPLOAD
               WHERE scode = p_cgdiwcgd.v_cgvws_inward_clg_upload.scode
                AND xref = p_cgdiwcgd.v_cgvws_inward_clg_upload.xref
                AND fccref1 = p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1
               ;
            EXCEPTION
               WHEN no_data_found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  p_Err_Code    := 'ST-VALS-002';
                  p_Err_Params  := l_Key;
                  RETURN FALSE;
            END;

         END IF;
         IF p_Full_Data = 'Y' AND l_Rec_Exists THEN
            Dbg('Get the Record For :CGVWS_INWARD_CLG_UPLOAD');
            BEGIN
               SELECT *
               INTO p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload
               FROM   CGVW_INWARD_CLG_UPLOAD
               WHERE scode = p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.scode
                AND xref = p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.xref
                AND fccref1 = p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :CGVWS_INWARD_CLG_UPLOAD');
            END;
            Dbg('Get the Record For :CGVWS_INWARD_CLG_UPLD');
            OPEN c_v_cgvws_inward_clg_upld;
            LOOP
               FETCH c_v_cgvws_inward_clg_upld
               BULK COLLECT INTO p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld;
                EXIT WHEN c_v_cgvws_inward_clg_upld%NOTFOUND;
            END LOOP;
            CLOSE c_v_cgvws_inward_clg_upld;

         END IF;
         IF p_QryData_Reqd = 'Y' THEN
            Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
            IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Wrk_cgdiwcgd,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
               RETURN FALSE;
            END IF;
         END IF;

      END IF;
      Dbg('Returning Success From Fn_Sys_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         IF  c_v_cgvws_inward_clg_upld%ISOPEN THEN
            CLOSE c_v_cgvws_inward_clg_upld;
         END IF;
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query;
   FUNCTION Fn_Sys_Upload_Db         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Prev_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Wrk_cgdiwcgd      IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Count             NUMBER:= 0;
      l_Ins_Count         NUMBER:= 0;
      l_Upd_Count         NUMBER:= 0;
      l_Del_Count         NUMBER:= 0;
      l_Wrk_Count         NUMBER:= 0;
      l_Prev_Count        NUMBER:= 0;
      l_Rec_Found         BOOLEAN:= FALSE;
      l_Row_Id            ROWID;
      l_Key               VARCHAR2(5000):= NULL;
      l_Auth_Stat         VARCHAR2(1) := 'A';
      l_Base_Data_From_Fc VARCHAR2(1):= 'Y';
      I_v_cgvws_inward_clg_upld       cgpks_cgdiwcgd_Main.Ty_Tb_v_cgvws_inward_clg_upld;
      U_v_cgvws_inward_clg_upld       cgpks_cgdiwcgd_Main.Ty_Tb_v_cgvws_inward_clg_upld;
      D_v_cgvws_inward_clg_upld       cgpks_cgdiwcgd_Main.Ty_Tb_v_cgvws_inward_clg_upld;
   BEGIN
      Dbg('In Fn_Sys_Upload_Db..');
      IF p_Action_Code = Cspks_Req_Global.p_new THEN

         Dbg('Inserting Into CGVWS_INWARD_CLG_UPLOAD..');
         BEGIN
            IF  p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.scode IS NOT NULL AND  p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.xref IS NOT NULL AND  p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1 IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  CGVW_INWARD_CLG_UPLOAD
               VALUES p_wrk_cgdiwcgd.v_cgvws_inward_clg_upload;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoCGVWS_INWARD_CLG_UPLOAD..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@CGVWS_INWARD_CLG_UPLOAD';
               RETURN FALSE;
         END;

         Dbg('Inserting Into CGVWS_INWARD_CLG_UPLD..');
         BEGIN
            l_Count      := p_wrk_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
            FORALL l_index IN  1..l_count
            INSERT INTO CGVW_INWARD_CLG_UPLD
            VALUES p_wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index);
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoCGVWS_INWARD_CLG_UPLD..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@CGVWS_INWARD_CLG_UPLD';
               RETURN FALSE;
         END;
      ELSIF p_Action_Code = Cspks_Req_Global.p_modify THEN

         Dbg('Updating Single Record Node :  CGVWS_INWARD_CLG_UPLOAD..');
         BEGIN
            UPDATE CGVW_INWARD_CLG_UPLOAD
            SET
            STATUS = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.STATUS,
            CURRENCY = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.CURRENCY,
         ENDPOINT = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ENDPOINT,
         TXNDATE = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.TXNDATE,
         REMBRANCH = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMBRANCH,
         REMACCOUNT = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REMACCOUNT,
         ACC_CCY = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ACC_CCY,
         PROD = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.PROD,
         INSTRNO = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.INSTRNO,
         INSTRAMT = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.INSTRAMT,
         BENACCOUNT = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.BENACCOUNT,
         AUTH_STAT = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.AUTH_STAT,
         ENTRY_NO = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.ENTRY_NO,
         INSTR_TYPE = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.INSTR_TYPE,
         DIRECTION = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.DIRECTION,
         MAKER_ID = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.MAKER_ID,
         REJ_REASON_CODE = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.REJ_REASON_CODE,
         BATCH_NO = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.BATCH_NO
WHERE scode = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.scode
 AND xref = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.xref
 AND fccref1 = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1
;
      EXCEPTION
         WHEN OTHERS THEN
            Dbg('Failed in Insert Into CGVWS_INWARD_CLG_UPLOAD..');
            Dbg(SQLERRM);
            p_Err_Code    := 'ST-UPLD-001';
            p_Err_Params  := '@CGVWS_INWARD_CLG_UPLOAD';
            RETURN FALSE;
      END;


      Dbg('Preapring Insert and Update Types for  CGVWS_INWARD_CLG_UPLD..');
      l_Wrk_Count  := p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
      l_Prev_Count := p_Prev_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
      IF l_Wrk_Count > 0 THEN
         FOR l_index IN 1 .. l_Wrk_Count LOOP
            l_Rec_Found    := FALSE;
            IF l_Prev_Count >  0 THEN
               FOR l_index1 IN 1..l_Prev_Count  LOOP
                  IF (NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1,'@')=  NVL(p_Prev_cgdiwcgd.v_cgvws_inward_clg_upld  (l_index1).xref1,'@')) AND (NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref,'@')=  NVL(p_Prev_cgdiwcgd.v_cgvws_inward_clg_upld  (l_index1).fccref,'@')) THEN
                     Dbg('Record Has Been Found.Update Case..');
                     l_rec_found := TRUE;
                     EXIT;
                  END IF;
               END LOOP;
            END IF;
            IF l_rec_found THEN
               Dbg('Record is Modified...');
               U_v_cgvws_inward_clg_upld(U_v_cgvws_inward_clg_upld.COUNT +1 ) :=  p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index);
            ELSE
               Dbg('Record is Added...');
               I_v_cgvws_inward_clg_upld(I_v_cgvws_inward_clg_upld.COUNT +1 ) :=  p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index);
            END IF;
         END LOOP;
      END IF;

      Dbg('Preapring Delete Types for  CGVWS_INWARD_CLG_UPLD..');
      l_Wrk_Count  := p_wrk_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
      l_Prev_Count := p_prev_cgdiwcgd.v_cgvws_inward_clg_upld.COUNT;
      IF l_Prev_Count > 0 THEN
         FOR l_index1 IN 1 .. l_Prev_Count LOOP
            l_Rec_Found    := FALSE;
            IF l_Wrk_Count >  0 THEN
               FOR l_index IN 1..l_Wrk_Count  LOOP
                  IF (NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).xref1,'@')=  NVL(p_Prev_cgdiwcgd.v_cgvws_inward_clg_upld  (l_index1).xref1,'@')) AND (NVL(p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upld(l_index).fccref,'@')=  NVL(p_Prev_cgdiwcgd.v_cgvws_inward_clg_upld  (l_index1).fccref,'@')) THEN
                     Dbg('Record Has Been Found.Update Case..');
                     l_Rec_Found := TRUE;
                     EXIT;
                  END IF;
               END LOOP;
            END IF;
            IF NOT l_Rec_Found THEN
               Dbg('Record is Deleted...');
               D_v_cgvws_inward_clg_upld(D_v_cgvws_inward_clg_upld.COUNT +1 ) :=  p_Prev_cgdiwcgd.v_cgvws_inward_clg_upld(l_index1);
            END IF;
         END LOOP;
      END IF;
      l_Del_Count  := D_v_cgvws_inward_clg_upld.COUNT;
      Dbg('Records Deleted  :'||l_Del_Count);
      IF l_Del_Count > 0 THEN
         FOR l_index IN 1 .. l_del_count LOOP
            Dbg('Deleting Record...');
            DELETE CGVW_INWARD_CLG_UPLD
            WHERE scode1 = D_v_cgvws_inward_clg_upld(l_index).scode1
             AND xref1 = D_v_cgvws_inward_clg_upld(l_index).xref1
             AND fccref = D_v_cgvws_inward_clg_upld(l_index).fccref
            ;
         END LOOP;
      END IF;
      l_Ins_Count  := I_v_cgvws_inward_clg_upld.COUNT;
      Dbg('New Records Added  :'||l_ins_count);
      BEGIN
         l_Count      := I_v_cgvws_inward_clg_upld.COUNT;
         FORALL l_Index IN  1..l_count
         INSERT INTO CGVW_INWARD_CLG_UPLD
         VALUES I_v_cgvws_inward_clg_upld(l_index);
      EXCEPTION
         WHEN OTHERS THEN
            Dbg('Failed in Insert IntoCGVWS_INWARD_CLG_UPLD..');
            Dbg(SQLERRM);
            p_Err_Code    := 'ST-UPLD-001';
            p_Err_Params  := '@CGVWS_INWARD_CLG_UPLD';
            RETURN FALSE;
      END;
      l_Upd_Count  := U_v_cgvws_inward_clg_upld.COUNT;
      Dbg('Records Modified  :'||l_Upd_Count);
      IF l_Upd_Count > 0 THEN
         FOR l_index IN 1 .. l_Upd_Count LOOP
            Dbg('Updating The  Record...');
            BEGIN
               UPDATE CGVW_INWARD_CLG_UPLD
               SET
               ENTRY_NO1 = U_v_cgvws_inward_clg_upld(l_index).ENTRY_NO1,
               STATUS1 = U_v_cgvws_inward_clg_upld(l_index).STATUS1,
               REJ_REASON_CODE = U_v_cgvws_inward_clg_upld(l_index).REJ_REASON_CODE,
               FORCE_POSTING = U_v_cgvws_inward_clg_upld(l_index).FORCE_POSTING,
               REJ_ADV_REQD = U_v_cgvws_inward_clg_upld(l_index).REJ_ADV_REQD,
               PROD = U_v_cgvws_inward_clg_upld(l_index).PROD,
               REMACCOUNT = U_v_cgvws_inward_clg_upld(l_index).REMACCOUNT,
               REMBRANCH = U_v_cgvws_inward_clg_upld(l_index).REMBRANCH,
               BENACCOUNT = U_v_cgvws_inward_clg_upld(l_index).BENACCOUNT,
               INSTRNO = U_v_cgvws_inward_clg_upld(l_index).INSTRNO,
               INSTRCCY = U_v_cgvws_inward_clg_upld(l_index).INSTRCCY,
               INSTRAMT = U_v_cgvws_inward_clg_upld(l_index).INSTRAMT,
               ROUTINGNO = U_v_cgvws_inward_clg_upld(l_index).ROUTINGNO,
               ACC_CCY = U_v_cgvws_inward_clg_upld(l_index).ACC_CCY,
               TXNDATE = U_v_cgvws_inward_clg_upld(l_index).TXNDATE,
            ENDPOINT = U_v_cgvws_inward_clg_upld(l_index).ENDPOINT,
            TXN_BRN = U_v_cgvws_inward_clg_upld(l_index).TXN_BRN,
            REMBANK = U_v_cgvws_inward_clg_upld(l_index).REMBANK,
            INSTRDATE = U_v_cgvws_inward_clg_upld(l_index).INSTRDATE,
            VALDATEBNK = U_v_cgvws_inward_clg_upld(l_index).VALDATEBNK,
            VALDATECUST = U_v_cgvws_inward_clg_upld(l_index).VALDATECUST,
            MAKER_ID = U_v_cgvws_inward_clg_upld(l_index).MAKER_ID,
            MAKER_DT_STAMP = U_v_cgvws_inward_clg_upld(l_index).MAKER_DT_STAMP,
            CHECKER_DT_STAMP = U_v_cgvws_inward_clg_upld(l_index).CHECKER_DT_STAMP,
            CHECKER_ID = U_v_cgvws_inward_clg_upld(l_index).CHECKER_ID,
            ERROR_CODES = U_v_cgvws_inward_clg_upld(l_index).ERROR_CODES,
            ERROR_PARAMS = U_v_cgvws_inward_clg_upld(l_index).ERROR_PARAMS,
            REMARKS = U_v_cgvws_inward_clg_upld(l_index).REMARKS,
            BEN_CUST = U_v_cgvws_inward_clg_upld(l_index).BEN_CUST,
            ERR_MSG = U_v_cgvws_inward_clg_upld(l_index).ERR_MSG,
            INSTR_TYPE = U_v_cgvws_inward_clg_upld(l_index).INSTR_TYPE,
            DIRECTION = U_v_cgvws_inward_clg_upld(l_index).DIRECTION,
            CUSTNAME = U_v_cgvws_inward_clg_upld(l_index).CUSTNAME,
            AUTH_STAT = U_v_cgvws_inward_clg_upld(l_index).AUTH_STAT,
            WAIVE_REJECT_CHG = U_v_cgvws_inward_clg_upld(l_index).WAIVE_REJECT_CHG,
            BENROUTINGNO = U_v_cgvws_inward_clg_upld(l_index).BENROUTINGNO,
            SMALL_ACC_NO = U_v_cgvws_inward_clg_upld(l_index).SMALL_ACC_NO,
            PRESENT_BANK_CHG = U_v_cgvws_inward_clg_upld(l_index).PRESENT_BANK_CHG,
            CHEQUE_RETN_AMT = U_v_cgvws_inward_clg_upld(l_index).CHEQUE_RETN_AMT,
            BATCH_NO = U_v_cgvws_inward_clg_upld(l_index).BATCH_NO
WHERE scode1 = U_v_cgvws_inward_clg_upld(l_index).scode1
 AND xref1 = U_v_cgvws_inward_clg_upld(l_index).xref1
 AND fccref = U_v_cgvws_inward_clg_upld(l_index).fccref
;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Updating CGVWS_INWARD_CLG_UPLD..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@CGVWS_INWARD_CLG_UPLD';
               RETURN FALSE;
         END;
      END LOOP;
   END IF;
ELSIF p_Action_Code = Cspks_Req_Global.p_delete THEN
   Dbg('Action Code '||p_Action_Code);
   Dbg('Deleting The Data..');

   
   DELETE CGVW_INWARD_CLG_UPLD
   WHERE scode1 = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.scode
   ;

   DELETE CGVW_INWARD_CLG_UPLOAD WHERE scode = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.scode
    AND xref = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.xref
    AND fccref1 = p_Wrk_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1
   ;



END IF;

Dbg('Returning Success From Fn_Sys_Upload_Db');
RETURN TRUE;
EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of Fn_Sys_Upload_Db ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_params  := NULL;
   RETURN FALSE;
END Fn_Sys_Upload_Db;
FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
p_cgdiwcgd       IN   OUT cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN IS

l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

BEGIN

Dbg('In Fn_Build_Ws_Type..');

IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
   IF NOT Fn_Sys_Build_Fc_Type(p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Addl_Info ,
      p_CGDIWCGD,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in Fn_Sys_Build_Fc_Type..');
      RETURN FALSE;
   END IF;
ELSE
   IF NOT Fn_Sys_Build_Ws_Type(p_source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Addl_Info ,
      p_CGDIWCGD,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in Fn_Sys_Build_Ws_Type..');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('POSTTYPE');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Build_Type_Structure(p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      l_Child_Function,
      p_Addl_Info ,
      p_CGDIWCGD,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Build_Type_Structure..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Build_Type_Structure(p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      l_Child_Function,
      p_Addl_Info ,
      p_CGDIWCGD,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Build_Type_Structure..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Build_Type..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Build_Type ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Build_Type;
FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                        p_source_operation  IN     VARCHAR2,
                        p_Function_id       IN     VARCHAR2,
                        p_action_code       IN     VARCHAR2,
p_exchange_pattern   IN  VARCHAR2,
p_cgdiwcgd          IN cgpks_cgdiwcgd_Main.ty_cgdiwcgd,
p_err_code        IN OUT VARCHAR2,
p_err_params      IN OUT VARCHAR2)
RETURN BOOLEAN   IS

l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

BEGIN

dbg('In Fn_Build_Ts_List..');

IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
   IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
      p_source_operation,
      p_Function_id,
      p_action_code,
      p_cgdiwcgd,
      p_err_code,
      p_err_params)  THEN
      dbg('Failed in Fn_Sys_Build_Fc_Ts');
      RETURN FALSE;
   END IF;
ELSE
   IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
      p_source_operation,
      p_Function_id,
      p_action_code,
      p_exchange_pattern,
      p_cgdiwcgd,
      p_err_code,
      p_err_params)  THEN
      dbg('Failed in Fn_Sys_Build_Ws_Ts');
      RETURN FALSE;
   END IF;
END IF;

dbg('Returning from Fn_Build_Ts_List');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   debug.pr_debug('**','In when others of cgpks_cgdiwcgd_Main.Fn_Build_Ts_List ..');
   debug.pr_debug('**',SQLERRM);
   p_err_code    := 'ST-OTHR-001';
   p_err_params  := NULL;
   RETURN FALSE;
END Fn_Build_Ts_List;
FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cgdiwcgd       IN  OUT cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Key_Cols        VARCHAR2(32767);
l_Key_Vals        VARCHAR2(32767);
l_Func_Type       VARCHAR2(32767);
BEGIN

Dbg('In Fn_Get_Key_Information..');
l_Key_Cols := 'SCODE~'||'XREF~'||'FCCREF1~';
l_Key_Vals := p_cgdiwcgd.v_cgvws_inward_clg_upload.scode||'~'||p_cgdiwcgd.v_cgvws_inward_clg_upload.xref||'~'||p_cgdiwcgd.v_cgvws_inward_clg_upload.fccref1||'~';
Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
   p_Source_Operation,
   p_Function_Id,
   p_Action_Code ,
   'TRANSACTION',
   'CGVWS_INWARD_CLG_UPLOAD',
   'BLK_CGVWS_INWARD_CLG_UPLOAD',
   'Cgvw-Clearing-Upload',
   l_Key_Cols,
   l_Key_Vals,
   p_cgdiwcgd.Addl_Info,
   p_Err_Code,
   p_Err_Params) THEN
   Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
   RETURN FALSE;
END IF;
IF p_cgdiwcgd.Addl_Info.EXISTS('RECORD_KEY') THEN
   G_Req_Key :=  p_cgdiwcgd.Addl_Info('RECORD_KEY');
END IF;
Dbg('Returning Succsess From Fn_Get_Key_Information..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Get_Key_Information..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Get_Key_Information;
FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
p_cgdiwcgd IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code       IN  OUT VARCHAR2,
p_Err_Params     IN  OUT VARCHAR2)
  RETURN BOOLEAN IS

l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

BEGIN

Dbg('In Fn_Check_Mandatory..');

Pr_Skip_Handler('PREMAND');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Check_Mandatory (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Pk_Or_Full,
      p_Function_Id  ,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in  cgpks_cgdiwcgd_Custom.Fn_Pre_Check_Mandatory..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Check_Mandatory (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Pk_Or_Full,
      p_Function_Id  ,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in  cgpks_cgdiwcgd_Kernel.Fn_Pre_Check_Mandatory..');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('POSTMAND');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Check_Mandatory (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_Pk_Or_Full,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Check_Mandatory..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Check_Mandatory (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_Pk_Or_Full,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Check_Mandatory..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Check_Mandatory..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Check_Mandatory ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Check_Mandatory;
FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
p_QryData_Reqd       IN  VARCHAR2,
p_cgdiwcgd         IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Wrk_cgdiwcgd  IN   OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN IS

l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
l_Key_Tags       VARCHAR2(32767);
l_Key_Vals       VARCHAR2(32767);

BEGIN

Dbg('In Fn_Query..');

Pr_Skip_Handler('PREQRY');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_pre_Query (p_Source,
      p_Source_Operation,
      p_Function_id,
      p_action_code,
      p_Function_Id  ,
      p_Full_Data  ,
      p_with_lock,
      p_QryData_Reqd,
      p_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code  ,
      p_Err_Params ) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Pre_Query..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_pre_Query (p_Source,
      p_Source_Operation,
      p_Function_id,
      p_action_code,
      p_Function_Id  ,
      p_Full_Data  ,
      p_with_lock,
      p_QryData_Reqd,
      p_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code  ,
      p_Err_Params ) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Pre_Query..');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('SYSDESC');
IF p_QryData_Reqd = 'Y' THEN
   Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
   IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Wrk_cgdiwcgd,
      p_Err_Code  ,
      p_Err_Params ) THEN
      Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
      RETURN FALSE;
   END IF;
END IF;

Pr_Skip_Handler('POSTQRY');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Query (p_Source,
      p_Source_Operation,
      p_Function_id,
      p_Action_Code,
      p_Function_Id  ,
      p_Full_Data  ,
      p_with_lock ,
      p_QryData_Reqd,
      p_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code  ,
      p_Err_Params ) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Query..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Query (p_Source,
      p_Source_Operation,
      p_Function_id,
      p_Action_Code,
      p_Function_Id  ,
      p_Full_Data  ,
      p_with_lock ,
      p_QryData_Reqd,
      p_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code  ,
      p_Err_Params ) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Query..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Query..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of Fn_Query ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Query;
FUNCTION Fn_Resolve_Ref_Numbers         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cgdiwcgd     IN OUT cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS

BEGIN

Dbg('In Fn_Resolve_Ref_Numbers..');

Pr_Skip_Handler('PREMAND');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Resolve_Ref_Numbers (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Pre_Resolve_Ref_Numbers..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Resolve_Ref_Numbers (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Pre_Resolve_Ref_Numbers..');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('POSTMAND');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Resolve_Ref_Numbers (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Resolve_Ref_Numbers..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Resolve_Ref_Numbers (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Resolve_Ref_Numbers..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Resolve_Ref_Numbers..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of Fn_Resolve_Ref_Numbers ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Resolve_Ref_Numbers;
FUNCTION Fn_Product_Default         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Wrk_cgdiwcgd      IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'CGDIWCGD';
l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
l_Row_Id            ROWID;
l_Key  VARCHAR2(32767);
l_Key_Id  VARCHAR2(32767);
l_Fld  VARCHAR2(32767);


BEGIN

Dbg('In Fn_Product_Default..');

Pr_Skip_Handler('PREPRDDFLT');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Product_Default (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Pre_Product_Default..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Product_Default (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Pre_Product_Default..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
IF NOT Fn_Sys_Query_Desc_Fields(p_Source,
   p_Source_Operation,
   p_Function_Id,
   Cspks_Req_Global.p_prddflt,
   p_Wrk_cgdiwcgd,
   p_Err_Code,
   p_Err_Params) THEN
   Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
   RETURN FALSE;
END IF;
Pr_Skip_Handler('POSTPRDDFLT');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Product_Default (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Product_Default..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Product_Default (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Product_Default..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Product_Default..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Product_Default ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Product_Default;
FUNCTION Fn_Unlock         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
p_Action_Code       IN  OUT  VARCHAR2,
p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'CGDIWCGD';


BEGIN

Dbg('In Fn_Unlock..');

Pr_Skip_Handler('PREUNLOCK');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Unlock (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code ,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Pre_Unlock..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Unlock (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code ,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Pre_Unlock..');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('POSTUNLOCK');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Unlock (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code ,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Unlock..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Unlock (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code ,
      p_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Unlock..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Unlock..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Unlock ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Unlock;
FUNCTION Fn_Subsys_Pickup         (p_Source            IN VARCHAR2,
p_Source_Operation  IN     VARCHAR2,
p_Function_Id       IN     VARCHAR2,
p_Action_Code       IN     VARCHAR2,
p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Prev_cgdiwcgd IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Wrk_cgdiwcgd      IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'CGDIWCGD';


BEGIN

Dbg('In Fn_Subsys_Pickup..');

Pr_Skip_Handler('PRESUBSYSPKP');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Subsys_Pickup (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Pre_Subsys_Pickup..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Subsys_Pickup (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Pre_Subsys_Pickup..');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('POSTSUBSYSPKP');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Subsys_Pickup (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_prev_cgdiwcgd,
      p_wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Subsys_Pickup ..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Subsys_Pickup (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_prev_cgdiwcgd,
      p_wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Subsys_Pickup ..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Subsys_Pickup..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Subsys_Pickup ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Subsys_Pickup;
FUNCTION Fn_Enrich         (p_Source            IN VARCHAR2,
p_Source_Operation  IN     VARCHAR2,
p_Function_Id       IN     VARCHAR2,
p_Action_Code       IN     VARCHAR2,
p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Prev_cgdiwcgd IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Wrk_cgdiwcgd      IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'CGDIWCGD';


BEGIN

Dbg('In Fn_Enrich..');

Pr_Skip_Handler('PREENRICH');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Enrich (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom. Fn_Pre_Enrich..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Enrich (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel. Fn_Pre_Enrich..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Calling in Fn_Sys_Query_Desc_Field..');
IF NOT Fn_Sys_Query_Desc_Fields(p_Source,
   p_Source_Operation,
   p_Function_Id,
   p_Action_Code,
   p_Wrk_cgdiwcgd,
   p_Err_Code,
   p_Err_Params) THEN
   Dbg('Failed in Fn_Sys_Query_Desc_Field..');
   RETURN FALSE;
END IF;
Pr_Skip_Handler('POSTENRICH');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Enrich (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Enrich..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Enrich (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Enrich..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning  Success From Fn_Enrich..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others Of cgpks_cgdiwcgd_Main.Fn_Enrich ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Enrich;
FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_id       IN     VARCHAR2,
                        p_action_code       IN OUT    VARCHAR2,
p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Prev_cgdiwcgd IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Wrk_cgdiwcgd IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
l_Source_Operation       VARCHAR2(100) := p_source_Operation;
l_Full_Data    VARCHAR2(1) := 'N';
l_With_Lock    VARCHAR2(1) := 'Y';
l_Qrydata_Reqd    VARCHAR2(1) := 'N';
l_Pk_Or_Full      VARCHAR2(10) := 'FULL';


BEGIN

Dbg('In Fn_Default_And_Validate..');

l_Full_data   := 'Y';
Dbg('Calling  Fn_Query..');
IF NOT Fn_Query(p_Source,
   p_Source_Operation,
   p_Function_id,
   p_Action_Code,
   l_Full_data,
   l_With_Lock,
   l_Qrydata_Reqd,
   p_cgdiwcgd,
   p_Prev_cgdiwcgd,
   p_Err_Code,
   p_Err_Params) THEN
   Dbg('Failed in Fn_Query..');
   RETURN FALSE;
END IF;
Pr_Skip_Handler('PREDFLT');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Default_And_Validate (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Pre_Default_And_Validate');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Default_And_Validate (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Pre_Default_And_Validate');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('POSTDFLT');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Default_And_Validate (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in  cgpks_cgdiwcgd_Kernel.Fn_Post_Default_And_Validate..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Default_And_Validate (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in  cgpks_cgdiwcgd_Custom.Fn_Post_Default_And_Validate..');
      RETURN FALSE;
   END IF;
END IF;
IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
   Dbg('Calling  Fn_Check_Mandatory..');
   IF NOT Fn_Check_Mandatory(p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      l_Pk_Or_Full,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in Fn_Check_Mandatory..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Check_Mandatory..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_default_and_validate ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Default_And_Validate;
FUNCTION Fn_Upload_Db  (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Multi_Trip_Id    IN  VARCHAR2,
p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Prev_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Wrk_cgdiwcgd      IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
l_Row_Id            ROWID;
l_Key  VARCHAR2(32767);
l_Key_Id  VARCHAR2(32767);
l_Fld  VARCHAR2(32767);


BEGIN

Dbg('In Fn_Upload_Db..');

Pr_Skip_Handler('PREUPLD');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Upload_Db (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_Multi_Trip_Id,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Pre_Upload_Db..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Upload_Db (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_Multi_Trip_Id,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Pre_Upload_Db..');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('POSTUPLD');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Upload_Db (p_Source,
      p_Source_Operation,
      p_Function_id,
      p_action_code,
      p_Function_Id  ,
      p_Multi_Trip_Id,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Upload_Db..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Upload_Db (p_Source,
      p_Source_Operation,
      p_Function_id,
      p_action_code,
      p_Function_Id  ,
      p_Multi_Trip_Id,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Upload_Db..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success  From Fn_Upload_Db..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Upload_Db ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Upload_Db;
FUNCTION Fn_Process         (p_Source            IN VARCHAR2,
p_Source_Operation  IN     VARCHAR2,
p_Function_Id       IN     VARCHAR2,
p_Action_Code       IN     VARCHAR2,
p_Multi_Trip_Id    IN  VARCHAR2,
p_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Prev_cgdiwcgd     IN  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Wrk_cgdiwcgd      IN OUT  cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Calling_Function Smtb_Menu.Function_Id%TYPE := 'CGDIWCGD';
l_Source_Operation       VARCHAR2(100) := p_Source_Operation;


BEGIN

Dbg('In Fn_Process..');

Pr_Skip_Handler('PREPROCESS');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Pre_Process (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_multi_trip_id,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in  cgpks_cgdiwcgd_Custom.Fn_Pre_Process..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Pre_Process (p_Source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_multi_trip_id,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in  cgpks_cgdiwcgd_Kernel.Fn_Pre_Process..');
      RETURN FALSE;
   END IF;
END IF;
Pr_Skip_Handler('POSTPROCESS');
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_kernel  THEN
   IF NOT cgpks_cgdiwcgd_Kernel.Fn_Post_Process (p_source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_Multi_Trip_Id,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Kernel.Fn_Post_Process..');
      RETURN FALSE;
   END IF;
END IF;
IF NOT cgpks_cgdiwcgd_Main.Fn_Skip_custom  THEN
   IF NOT cgpks_cgdiwcgd_Custom.Fn_Post_Process (p_source,
      p_Source_Operation,
      p_Function_Id,
      p_Action_Code,
      p_Function_Id  ,
      p_Multi_Trip_Id,
      p_cgdiwcgd,
      p_Prev_cgdiwcgd,
      p_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in cgpks_cgdiwcgd_Custom.Fn_Post_Process..');
      RETURN FALSE;
   END IF;
END IF;
Dbg('Returning Success From Fn_Process..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of cgpks_cgdiwcgd_Main.Fn_Process ..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Process;
FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN IS

E_Failure_Exception     EXCEPTION;

BEGIN

Dbg('In Fn_Rebuild_Ts_List..');
IF NOT  Fn_Build_Ts_List(p_Source,
   p_Source_Operation,
   p_Function_Id,
   p_Action_Code,
   p_Exchange_Pattern,
   g_cgdiwcgd,
   p_Err_Code,
   p_Err_Params)  THEN
   Dbg('Failed in Fn_Build_Ts_List..');
   p_Status      := 'F';
   RETURN FALSE;
END IF;
Dbg('Returning Success From Fn_Rebuild_Ts_List..');
RETURN TRUE;

EXCEPTION
WHEN E_Failure_Exception THEN
   Dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List..');
   p_Status        := 'F';
   Dbg('Errors     :'||p_Err_Code);
   Dbg('Parameters :'||p_Err_Params);
   RETURN TRUE;
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of Fn_Rebuild_Ts_List..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Status      := 'F';
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := Null;
   RETURN FALSE;
END Fn_Rebuild_Ts_List;

FUNCTION Fn_Get_Node_Data (
p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN   IS
l_Cntr NUMBER := 0;
BEGIN

Dbg('In Fn_Get_Node_Data..');
l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
p_Node_Data(l_Cntr).Node_Name := 'BLK_CGVWS_INWARD_CLG_UPLOAD';
p_Node_Data(l_Cntr).Xsd_Node := 'Cgvw-Clearing-Upload';
p_Node_Data(l_Cntr).Node_Parent := '';
p_Node_Data(l_Cntr).Node_Relation_Type := '1';
p_Node_Data(l_Cntr).Query_Node := '0';
p_Node_Data(l_Cntr).Node_Fields := 'STATUS~CURRENCY~ENDPOINT~TXNDATE~REMBRANCH~REMACCOUNT~ACC_CCY~PROD~INSTRNO~INSTRAMT~BENACCOUNT~AUTH_STAT~SCODE~ENTRYNO~INSTRTYPE~DIRECTION~USER_ID~REJ_REASON_CODE~XREF~BATCH_NO~FCCREF1~';
p_Node_Data(l_Cntr).Node_Tags := 'STATS~CURR~ENDPOINT~TRANS_DATE~REMBRANCH_F~REMITTER~REMACCCCY~PROD~INSTRUMENT_NO~AMOUNT~BENACCOUNT~AUTHSTATUS~SOURCE~ENTRYNO~INSTRUMENT_TYPE~DIRECTION~USER_ID~REJ_REASON_CODE~XREF~BATCH_NO~FCCREF1~';

l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
p_Node_Data(l_Cntr).Node_Name := 'BLK_CGVWS_INWARD_CLG_UPLD';
p_Node_Data(l_Cntr).Xsd_Node := 'Cgvw-Clearing-Upld';
p_Node_Data(l_Cntr).Node_Parent := 'BLK_CGVWS_INWARD_CLG_UPLOAD';
p_Node_Data(l_Cntr).Node_Relation_Type := 'N';
p_Node_Data(l_Cntr).Query_Node := '0';
p_Node_Data(l_Cntr).Node_Fields := 'SCODE1~XREF1~ENTRY_NO1~STATUS1~REJ_REASON_CODE~FORCE_POSTING~REJ_ADV_REQD~PROD~REMACCOUNT~REMBRANCH~BENACCOUNT~INSTRNO~INSTRCCY~INSTRAMT~ROUTINGNO~ACC_CCY~TXNDATE~ENDPOINT~TXN_BRN~REMBANK~INSTRDATE~VA';
p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'LDATEBNK~VALDATECUST~FCCREF~MAKER_ID~MAKER_DT_STAMP~CHECKER_DT_STAMP~CHECKER_ID~ERROR_CODES~ERROR_PARAMS~REMARKS~BEN_CUST~ERR_MSG~INSTR_TYPE~DIRECTION~CUSTNAME~AUTH_STAT~WAIVE~BENROUTINGNO~ALTCHECK~CH';
p_Node_Data(l_Cntr).Node_Fields := p_Node_Data(l_Cntr).Node_Fields||'AR_FIELD21~PRESNBNKCHG~CHQRETNAMT~';
p_Node_Data(l_Cntr).Node_Tags := 'SOURCE_CODE~XREF~ENTRYNO~STATS~REJ_REASON_CODE~FORCE_POSTING~REJ_ADV_REQD~PROD~REM_ACC_NO~REMBRANCH_F~BENACCOUNT~INSTNO~INSTRCCY~INSTRAMT~ROUTING_NO~CCY_CD~LIQUIDATION_DATE~ENDPOINT~TXN_BRN~REM_BANK~I';
p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'NSTRDATE~VALDATEBNK~VALDATECUST~FCCREF~MAKER_ID~MAKER_DT_STAMP~CHECKER_DT_STAMP~CHECKER_ID~ERROR_CODE~ERROR_PARAMS~REMRKS~BENCUST~UPLOAD_STAT~INSTRUMENT_TYPE~DIRECTION~CUSTNAME~AUTHSTATUS~WAIVE_REJ_CH';
p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'G~BENROUTINGNO~ALTCHECK~CHAR_FIELD21~PRESN_BNK_CHG_AMT~CHQ_RETN_AMT~';

Dbg('Returning From Fn_Get_Node_Data.. ');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others Of cgpks_cgdiwcgd_Main.Fn_Get_Node_Data..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := NULL;
   RETURN FALSE;
END Fn_Get_Node_Data;
FUNCTION Fn_Main       (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_cgdiwcgd          IN OUT cgpks_cgdiwcgd_Main.Ty_cgdiwcgd,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN IS

E_Failure_Exception     EXCEPTION;
E_Override_Exception    EXCEPTION;
E_Hold_Exception        EXCEPTION;
l_Post_Upl_Stat    VARCHAR2(1) :='A';
l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
l_action_code           VARCHAR2(100) := p_Action_Code;
l_Wrk_cgdiwcgd     cgpks_cgdiwcgd_Main.Ty_cgdiwcgd;
l_Prev_cgdiwcgd    cgpks_cgdiwcgd_Main.Ty_cgdiwcgd;
l_Dmy_cgdiwcgd    cgpks_cgdiwcgd_Main.Ty_cgdiwcgd;
l_Pk_Or_Full    VARCHAR2(5) :='PK';
l_Full_Data    VARCHAR2(1) := 'Y';
l_With_Lock    VARCHAR2(1) := 'N';
l_Qrydata_Reqd    VARCHAR2(1) := 'Y';
l_Count         NUMBER;
l_Rollback_Reqd    VARCHAR2(1) := 'N';
l_Prev_Auth_Stat        VARCHAR2(1) :='U';

BEGIN

Dbg('In Fn_Main');

SAVEPOINT Sp_Main_Cgdiwcgd;
p_Status := 'S';
g_Addl_Info.DELETE;
g_cgdiwcgd := p_cgdiwcgd;
g_Original_Action := p_Action_Code ;
g_Action_Code :=  p_Action_Code ;

Dbg('Calling  Fn_Resolve_Ref_Numbers..');
IF NOT Fn_Resolve_Ref_Numbers(p_Source,
   p_Source_Operation,
   p_Function_Id,
   p_Action_Code,
   p_cgdiwcgd,
   p_Err_Code,
   p_Err_Params)  THEN
   Dbg('Failed in Fn_Resolve_Ref_Numbers..');
   Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
   RAISE E_Failure_Exception;
END IF;

Dbg('Calling in Fn_Unlock..');
IF NOT Fn_Unlock(p_Source,
   p_Source_Operation,
   p_Function_Id,
   l_Action_Code,
   p_cgdiwcgd,
   p_Err_Code,
   p_Err_Params)  THEN
   Dbg('Failed in Fn_Unlock..');
   Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
   RAISE E_Failure_Exception;
END IF;

Dbg('Calling  Fn_Check_Mandatory..');
IF NOT Fn_Check_Mandatory(p_Source,
   p_Source_Operation,
   p_Function_Id,
   l_Action_Code,
   l_Pk_Or_Full,
   p_cgdiwcgd,
   p_Err_Code,
   p_Err_Params)  THEN
   Dbg('Failed in Fn_Check_Mandatory..');
   Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
   RAISE E_Failure_Exception;
END IF;

Dbg('Calling  Fn_Get_Key_Information..');
IF NOT  Fn_Get_Key_Information(p_Source,
   p_Source_Operation,
   p_Function_Id,
   p_Action_Code,
   p_cgdiwcgd,
   p_Err_Code,
   p_Err_Params)  THEN
   Dbg('Failed in Fn_Get_Key_Information..');
   RAISE e_Failure_Exception;
END IF;
IF p_Action_Code  = Cspks_Req_Global.p_Query THEN
   Dbg('Calling Fn_Query..');
   IF NOT Fn_Query(p_Source,
      p_Source_Operation,
      p_Function_Id,
      l_Action_Code,
      l_Full_data,
      l_With_Lock,
      l_Qrydata_Reqd,
      p_cgdiwcgd,
      l_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in Fn_Query..');
      Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
      RAISE E_Failure_Exception;
   END IF;
ELSIF p_Action_code  = Cspks_Req_Global.p_Prddflt THEN
   Dbg('Calling  Fn_Product_Default..');
   Dbg('Failed in Fn_Product_Default..');
   IF NOT Fn_Product_Default (p_Source,
      p_Source_Operation,
      p_Function_Id,
      l_Action_Code,
      p_cgdiwcgd,
      l_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in Fn_Product_Default..');
      Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
      RAISE E_Failure_Exception;
   END IF;

ELSIF SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_SubsysPickup))  = Cspks_Req_Global.p_SubsysPickup THEN
   Dbg('Calling  Fn_Subsys_Pickup..');
   IF NOT Fn_Subsys_Pickup (p_Source,
      p_Source_Operation,
      p_Function_Id,
      l_Action_Code,
      p_cgdiwcgd,
      l_Prev_cgdiwcgd,
      l_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in Fn_Subsys_Pickup..');
      Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
      RAISE E_Failure_Exception;
   END IF;

ELSIF SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  = Cspks_Req_Global.p_Enrich THEN
   Dbg('Calling  Fn_Enrich..');
   IF NOT Fn_Enrich (p_Source,
      p_Source_Operation,
      p_Function_Id,
      l_Action_Code,
      p_cgdiwcgd,
      l_Prev_cgdiwcgd,
      l_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in Fn_Enrich..');
      Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
      RAISE E_Failure_Exception;
   END IF;

ELSE
   IF NOT Fn_Default_And_Validate (p_Source,
      p_Source_Operation,
      p_Function_Id,
      l_Action_Code,
      p_cgdiwcgd,
      l_Prev_cgdiwcgd,
      l_Wrk_cgdiwcgd,
      p_Err_Code,
      p_Err_Params) THEN
      Dbg('Failed in Fn_Default_And_Validate..');
      Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
      RAISE E_Failure_Exception;
   END IF;

   -- Get Resultant Error Type
   g_autoauth := 'U';
   l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
   IF l_Resultant_Error_Type <> 'E' THEN
      Dbg('Calling  Fn_Upload_Db..');
      IF NOT Fn_Upload_Db (p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_Multi_Trip_Id,
         p_cgdiwcgd,
         l_Prev_cgdiwcgd,
         l_Wrk_cgdiwcgd,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Upload_Db..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;
      Dbg('Calling  Fn_Process..');
      IF NOT Fn_Process (p_Source,
         p_Source_Operation,
         p_Function_Id,
         l_Action_Code,
         p_Multi_Trip_Id,
         p_cgdiwcgd,
         l_Prev_cgdiwcgd,
         l_Wrk_cgdiwcgd,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Process..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;
      IF  l_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Reverse,Cspks_Req_Global.p_Rollover,Cspks_Req_Global.p_Confirm,Cspks_Req_Global.p_Liquidate ) THEN
         l_Prev_Auth_Stat := 'A';
         --Get Upload Status
         Dbg('Calling Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
         IF NOT Cspks_Req_Utils.Fn_Get_Auto_Auth_Status (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Prev_Auth_Stat,
            p_Multi_Trip_Id,
            P_Request_No,
            l_Post_Upl_Stat,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         IF l_Post_Upl_Stat = 'A'THEN
            Dbg('Calling Fn_Process With Auth as Action Code..');
            IF NOT Fn_Process (p_Source,
               p_Source_Operation,
               p_Function_Id,
               Cspks_Req_Global.p_Auth,
               p_Multi_Trip_Id,
               l_Wrk_cgdiwcgd,
               l_Prev_cgdiwcgd,
               l_Wrk_cgdiwcgd,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Process..');
               Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
         END IF;
      END IF;
   END IF;
END IF;
--Get Upload Status
Dbg('Calling Cspks_Req_Utils.Fn_Get_Upload_Status..');
IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
   p_Source_Operation,
   p_Function_Id,
   l_Action_Code,
   p_Multi_Trip_Id,
   P_Request_No,
   l_Post_Upl_Stat,
   p_Err_Code,
   p_Err_Params) THEN
   Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
   Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
   RAISE E_Failure_Exception;
END IF;

IF l_Post_Upl_Stat IN('A','U') THEN
   p_status := 'S';
   IF p_Action_code  <> Cspks_Req_Global.p_Prddflt AND
      SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  <> Cspks_Req_Global.p_Enrich THEN
      Dbg('Calling  Fn_Query..');
      IF NOT Fn_Query(p_source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Full_Data,
         l_With_Lock,
         l_Qrydata_Reqd,
         p_cgdiwcgd,
         l_Wrk_cgdiwcgd,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Query..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;
   END IF;
ELSIF l_Post_Upl_Stat ='O' THEN
   Dbg('New/First time Overides..');
   p_Status := 'O';
   RAISE E_Override_Exception;
ELSIF l_Post_Upl_Stat = 'H'    THEN
   Dbg('Keeping on Hold..');
   RAISE E_Hold_Exception;
ELSE
   Dbg('Not Feasible to Upload The Data...');
   RAISE E_Failure_Exception;
END IF;
IF p_Action_Code  = Cspks_Req_Global.p_Prddflt OR
   p_Action_Code  = Cspks_Req_Global.p_Copy OR
   SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_Enrich))  = Cspks_Req_Global.p_Enrich OR
   SUBSTR(p_Action_Code,1,Length(Cspks_Req_Global.p_SubsysPickup))  = Cspks_Req_Global.p_SubsysPickup THEN
   ROLLBACK TO Sp_Main_Cgdiwcgd;
END IF;

p_cgdiwcgd := l_Wrk_cgdiwcgd;
g_cgdiwcgd := l_Wrk_cgdiwcgd;
Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
Dbg('Errors     :'||p_Err_Code);
Dbg('Parameters :'||p_Err_Params);

Dbg('Returning Success From Fn_Main..');
RETURN TRUE;

EXCEPTION
WHEN E_Failure_Exception THEN
   Dbg('From E_Failure_Exception of Fn_Main');
   p_Status        := 'F';
   l_Post_Upl_Stat := 'F';
   Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
   Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
   Dbg('Errors     :'||p_Err_Code);
   Dbg('Parameters :'||p_Err_Params);
   RETURN TRUE;

WHEN E_Override_Exception THEN
   Dbg('From E_Override_Exception of Fn_Main..');
   p_Status        := 'O';
   l_Post_Upl_Stat := 'O';
   IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
      Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
      p_Err_Code    := 'ST-OTHR-001';
      p_Err_Params  := Null;
      RETURN FALSE;
   END IF;
   Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
   Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
   Dbg('Errors     :'||p_Err_Code);
   Dbg('Parameters :'||p_Err_Params);
   RETURN TRUE;

WHEN E_Hold_Exception THEN
   Dbg('From E_Hold_Exception of Fn_Main..');
   l_Post_Upl_Stat := 'H';
   Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
   Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
   ROLLBACK TO Sp_Main_Cgdiwcgd;
   IF NOT  Fn_main(p_Source,
      p_Source_operation,
      p_Function_Id,
      Cspks_Req_Global.p_Hold,
      p_Multi_Trip_Id,
      p_Request_No,
      p_cgdiwcgd,
      p_Status,
      p_Err_Code,
      p_Err_Params)  THEN
      Dbg('Failed in Fn_main..');
      RETURN FALSE;
   END IF;

   RETURN TRUE;

WHEN OTHERS THEN
   Debug.Pr_debug('**','In When Others of Fn_Main ..');
   Debug.Pr_debug('**',SQLERRM);
   p_Status      := 'F';
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := Null;
   RETURN FALSE;
END Fn_Main;

FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Multi_Trip_Id     IN     VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN IS
l_cgdiwcgd     cgpks_cgdiwcgd_Main.ty_cgdiwcgd;

BEGIN

Dbg('In Fn_Process_Request ..');
IF NOT  Fn_Build_Type(p_Source,
   p_Source_Operation,
   p_Function_id,
   p_Action_Code,
   p_Addl_Info,
   l_cgdiwcgd,
   p_Err_Code,
   p_Err_Params)  THEN
   Dbg('Failed in Fn_Build_Type..');
   p_Status      := 'F';
   RETURN FALSE;
END IF;
IF NOT  Fn_Main(p_Source,
   p_Source_Operation,
   p_Function_Id,
   p_Action_Code,
   p_Multi_Trip_Id,
   p_Request_No,
   l_cgdiwcgd,
   p_Status,
   p_Err_Code,
   p_Err_Params)  THEN
   Dbg('Failed in Fn_main..');
   RETURN FALSE;
END IF;

p_Addl_Info := l_cgdiwcgd.Addl_Info;
Cspks_Req_Global.Pr_Reset;
Dbg('Calling  Fn_Build_Ts_List..');
IF NOT  Fn_Build_Ts_List(p_Source,
   p_Source_Operation,
   p_Function_Id,
   p_Action_Code,
   p_Exchange_Pattern,
   l_cgdiwcgd,
   p_Err_Code,
   p_Err_Params)  THEN
   Dbg('Failed in Fn_Build_Ts_List..');
   p_Status      := 'F';
   RETURN FALSE;
END IF;
Cspks_Req_Global.Pr_Close_Ts;
Dbg('Returning Success From Fn_Process_Request ..');
RETURN TRUE;

EXCEPTION
WHEN OTHERS THEN
   Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
   Debug.Pr_Debug('**',SQLERRM);
   p_Status      := 'F';
   p_Err_Code    := 'ST-OTHR-001';
   p_Err_Params  := Null;
   RETURN FALSE;
END Fn_Process_Request;

END cgpks_cgdiwcgd_main;
/