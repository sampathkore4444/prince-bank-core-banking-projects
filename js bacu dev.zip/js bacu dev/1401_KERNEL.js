/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2004 - 2014  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*

** Modified By         : Sriraam S
** Modified On         : 19-Aug-2014
** Modified Reason     : 'event' handling as srcName supported in IE and evet.target supported in nonIE
** Search String       : FCUBS_1203_INTERNAL_19459483

** Modified By  	   : Ankit T
** Modified On   	   : 25-Aug-2014
** Modified Reason     : src.element was not working in Firefox.
** Search String       : FCUBS_12.0.3_TUN_19489533

**  Last Modified By   : Mohit Ojha
**  Last modified on   : 07-Apr-2017
**  Reason             : MCY/VA changes
**  Search String      : FCUBS12.4MCY/VA changes
-----------------------------------------------------------------------------------------
*/
//12.0.2_Single_Step_process starts
function fnPostNew_KERNEL() {
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = mainWin.Lcy;
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	 document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; //12.0.2_17077363
    document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Cash Deposit';
    return true;

}

// 1203_ITR1_18388624 starts 
function fnPreSave_KERNEL() {
try
  {
	if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != document.getElementById("BLK_TRANSACTION_DETAILS__VIRACCNO").value){
		gViraccno = true;		
     }
  else {
  			gViraccno = false;
	   }
  }
catch (e)
{
}
return true ;
}
// 1203_ITR1_18388624 ends

function fnAssignTxnCcy(p_acc_ccy) {
    document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = p_acc_ccy.value;
    return true;
}

function fnAccCcy(event) {
    if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != "") {
        fnDisableElement(document.getElementsByName("TXNCCY")[0]);
    }
    return true;
}
/*
function fnSetHotKeyBranch_KERNEL() {
   //if (window.event.srcElement.name == "TXNACC") {//FCUBS_12.0.3_TUN_19489533
	if (window.getEventSourceElement(event).name == "TXNACC") {//FCUBS_12.0.3_TUN_19489533
        hotKeyBrn = document.getElementsByName('TXNBRN')[0].value;
    }
    //if (window.event.srcElement.name == "OFFSETACC") {//FCUBS_12.0.3_TUN_19489533
	if (window.getEventSourceElement(event).name == "OFFSETACC") {//FCUBS_12.0.3_TUN_19489533
        hotKeyBrn = document.getElementsByName('OFFSETBRN')[0].value;
    }
    return true;
}
*/
function fnPostLoad_KERNEL(e) {
	document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; //12.0.2_17077363
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
    var txnAcc = mainWin.functionDef[functionId].txnAcc;
    var txnAccBlock = txnAcc.split("__")[0];
    var txnAccTag = txnAcc.split("__")[1];
    try {
        pickedUpAcc = getNodeText(selectSingleNode(dbDataDOM, "//" + txnAccBlock + '/' + txnAccTag));
        pickedUpCcy = getNodeText(selectSingleNode(dbDataDOM, "//" + 'BLK_TRANSACTION_DETAILS/OFFSETCCY'));
    }
    catch (e) {
    }
    return true;
}
//12.0.2_Single_Step_process ends

//9NT1620_1203_INTERNAL_18272320  starts

function fnPreProcessFields_KERNEL(e){

        appendData();
    if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) == 'V')
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue ="";

return true;
}

/*
function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
    if (eventElement.name == 'VIRACCNO' || eventElement.name == 'OFFSETCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').oldvalue = "";
  if(eventElement.name == 'VIRACCNO'  && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) != 'V')
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(eventElement.id).value;
		}	// 1203_ITR1_18388624
        if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/VIRACCNO")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) == 'V') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    }
      return true;
}
//9NT1620_1203_INTERNAL_18272320 ends 
*/


//FCUBS12.4MCY/VA changes starts
function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
    if (eventElement.name == 'UI_TXN_ACC' || eventElement.name == 'OFFSETCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').oldvalue = "";
  if(eventElement.name == 'UI_TXN_ACC'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'V' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'M'))
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(eventElement.id).value;
		}	// 1203_ITR1_18388624
		 appendData();
   // if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
       // }
    }
    }
      return true;
}
//FCUBS12.4MCY/VA changes ends