/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2017, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1300_1_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_CUST_ACCOUNT":"XREF~BRN~ACC~TXNCCY~INSISUBANK~INSNO~INSBENFNAME~INSULTBF1~INSULTBF2~INSULTBF3~CLSSN~CLSMOD~OFFBRN~OFFACC~INSPAYBRN~INSTAUS~INSEXPDT~INSULTBF4~INSOTHDETAIL1~INSOTHDETAIL2~INSOTHDETAIL3~INSOTHDETAIL4~INSOTHDETAIL5~INSOTHDETAIL6~INSOTHDTLTYP1~INSOTHDTLTYP2~INSOTHDTLTYP3~INSOTHDTLTYP4~INSOTHDTLTYP5~INSOTHDTLTYP6~OFFCCY~ACTAMT~EFFDT~ACCTITLE1~ATMBRN~REFNO~DELIVERY_MODE~ACCADDR~NARRATIVE~USEACCADDR~INSTNO~WAIVE"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_CUST_ACCOUNT">XREF~BRN~ACC~TXNCCY~INSISUBANK~INSNO~INSBENFNAME~INSULTBF1~INSULTBF2~INSULTBF3~CLSSN~CLSMOD~OFFBRN~OFFACC~INSPAYBRN~INSTAUS~INSEXPDT~INSULTBF4~INSOTHDETAIL1~INSOTHDETAIL2~INSOTHDETAIL3~INSOTHDETAIL4~INSOTHDETAIL5~INSOTHDETAIL6~INSOTHDTLTYP1~INSOTHDTLTYP2~INSOTHDTLTYP3~INSOTHDTLTYP4~INSOTHDTLTYP5~INSOTHDTLTYP6~OFFCCY~ACTAMT~EFFDT~ACCTITLE1~ATMBRN~REFNO~DELIVERY_MODE~ACCADDR~NARRATIVE~USEACCADDR~INSTNO~WAIVE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_CUST_ACCOUNT" : ""}; 

 var dataSrcLocationArray = new Array("BLK_CUST_ACCOUNT"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1300_1.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1300_1.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_CUST_ACCOUNT__BRN";
pkFields[0] = "BLK_CUST_ACCOUNT__BRN";
queryFields[1] = "BLK_CUST_ACCOUNT__ACC";
pkFields[1] = "BLK_CUST_ACCOUNT__ACC";
queryFields[2] = "BLK_CUST_ACCOUNT__CLSSN";
pkFields[2] = "BLK_CUST_ACCOUNT__CLSSN";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_CUST_ACCOUNT__INSISUBANK__LOV__BLK_CUST_ACCOUNT__INSISUBANK__1":["BLK_CUST_ACCOUNT__INSISUBANK~BLK_CUST_ACCOUNT__INSOTHDETAIL2~","","N~N",""],"BLK_CUST_ACCOUNT__INSPAYBRN__LOV_PAY_BRN_CODE":["BLK_CUST_ACCOUNT__INSPAYBRN~BLK_CUST_ACCOUNT__INSOTHDETAIL1~","BLK_CUST_ACCOUNT__INSISUBANK!VARCHAR2","N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_ALL';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CMIS~BLK_CUST_ACCOUNT","CUDF~BLK_CUST_ACCOUNT","CCCD~BLK_CUST_ACCOUNT"); 

 var CallFormRelat=new Array("","","STTBS_CUST_AC_CLOSURE.XREF = STTMS_ACCLSR_PAYOUT_DTL.EXT_REF_NO"); 

 var CallRelatType= new Array("1","N","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1300_1"]="KERNEL";
ArrPrntFunc["1300_1"]="1300_2";
ArrPrntOrigin["1300_1"]="KERNEL";
ArrRoutingType["1300_1"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1300_1"]="N";
ArrCustomModified["1300_1"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CMIS":"","CUDF":"","CCCD":""};
var scrArgSource = {"CMIS":"","CUDF":"","CCCD":""};
var scrArgVals = {"CMIS":"","CUDF":"","CCCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CMIS":"","CUDF":"","CCCD":""};
var dpndntOnSrvs = {"CMIS":"","CUDF":"","CCCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------