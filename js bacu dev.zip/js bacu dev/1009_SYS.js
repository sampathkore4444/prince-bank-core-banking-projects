/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1009_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~INSTRTYPE~ISSBRN~INSTRSTAT~PAYBANK~INSTRCCY~INSTRAMT~EXCHRATE~ACCCY~NARRATIVE~RELCUST~ACNO~TXNDATE~TCYTOTCHGAMT~BATCHNO~ACTAMT~ACBRN~ISSUER_CODE~CUSTNAME~TXNBRN","BLK_CHEQUE_DETAILS":"BENFNAME~BENFADDR1~BENFADDR2~BENFADDR3~BENFADDR4"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

 var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~INSTRTYPE~ISSBRN~INSTRSTAT~PAYBANK~INSTRCCY~INSTRAMT~EXCHRATE~ACCCY~NARRATIVE~RELCUST~ACNO~TXNDATE~TCYTOTCHGAMT~BATCHNO~ACTAMT~ACBRN~ISSUER_CODE~CUSTNAME~TXNBRN</FN>'; 
msgxml += '      <FN PARENT="BLK_TRANSACTION_DETAILS" RELATION_TYPE="1" TYPE="BLK_CHEQUE_DETAILS">BENFNAME~BENFADDR1~BENFADDR2~BENFADDR3~BENFADDR4</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_CHEQUE_DETAILS" : "BLK_TRANSACTION_DETAILS~1"}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_CHEQUE_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1009.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1009.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_TRANSACTION_DETAILS":["ACCCY","ACNO","ACTAMT","BATCHNO","EXCHRATE","INSTRAMT","INSTRCCY","INSTRSTAT","INSTRTYPE","ISSBRN","NARRATIVE","PAYBANK","RELCUST","TCYTOTCHGAMT","TXNDATE","XREF"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__ACCCY__LOV_CURRENCY":["BLK_TRANSACTION_DETAILS__ACCCY~~","","",""],"BLK_TRANSACTION_DETAILS__ACNO__LOV_ACCOUNT_CCY":["BLK_TRANSACTION_DETAILS__ACNO~BLK_TRANSACTION_DETAILS__ACCCY~BLK_TRANSACTION_DETAILS__CUSTNAME~","BLK_TRANSACTION_DETAILS__ACBRN!VARCHAR2","",""],"BLK_TRANSACTION_DETAILS__ACBRN__LOV_BRANCH":["BLK_TRANSACTION_DETAILS__ACBRN~~","","",""],"BLK_TRANSACTION_DETAILS__ISSUER_CODE__LOV_ISSUERCODE":["BLK_TRANSACTION_DETAILS__ISSUER_CODE~~","","N~N",""]};
var offlineLovInfoFlds = {"BLK_TRANSACTION_DETAILS__INSTRCCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__INSTRCCY~",""]};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CHCD~BLK_TRANSACTION_DETAILS","MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","TCCD~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("ISTMS_INSTR_TXN.XREF=CSTBS_WBCHARGE_DETAILS.XREF","ISTMS_INSTR_TXN.XREF=MIVWS_MIS_DETAILS.XREF","ISTMS_INSTR_TXN.XREF=UDVWS_UDF_DETAILS.XREF","ISTMS_INSTR_TXN.XREF=CSTBS_WBDENOM_DETAILS.XREF"); 

 var CallRelatType= new Array("N","1","N","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1009"]="KERNEL";
ArrPrntFunc["1009"]="";
ArrPrntOrigin["1009"]="";
ArrRoutingType["1009"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1009"]="N";
ArrCustomModified["1009"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CHCD":"","MDCD":"","UDCD":"","TCCD":""};
var scrArgSource = {"CHCD":"","MDCD":"","UDCD":"","TCCD":""};
var scrArgVals = {"CHCD":"","MDCD":"","UDCD":"","TCCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CHCD":"","MDCD":"","UDCD":"","TCCD":""};
var dpndntOnSrvs = {"CHCD":"","MDCD":"","UDCD":"","TCCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"","NEW":"","MODIFY":"","AUTHORIZE":"","DELETE":"","CLOSE":"","REOPEN":"","REVERSE":"","ROLLOVER":"","CONFIRM":"","LIQUIDATE":"","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------