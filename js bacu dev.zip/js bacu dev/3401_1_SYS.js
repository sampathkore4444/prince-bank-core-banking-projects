/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 3401_1_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~PRD~BRN~TRNREFNO~TXNACC~TXNCCY~TXNAMT~TXNBRN~TXNTRN~OFFSETACC~OFFSETCCY~OFFSETAMT~OFFSETBRN~OFFSETTRN~XRATE~LCYAMT~TXNDATE~VALUE_DT~RELCUST~NARRATIVE~MODULE~ACTAMT~TCYTOTCHGAMT~ACCTITLE1~CUSTNAME","BLK_SAFEDEPOSIT_DETAILS":"FCCREF~ESN~CNTAMT~CIFID~CUST~CNTCCY~CURPMNT~TOTPMNT~DUEDT~NXTDUEDT~SETLCCY~SETLACC~SETLBRN~VALDT"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

 var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~PRD~BRN~TRNREFNO~TXNACC~TXNCCY~TXNAMT~TXNBRN~TXNTRN~OFFSETACC~OFFSETCCY~OFFSETAMT~OFFSETBRN~OFFSETTRN~XRATE~LCYAMT~TXNDATE~VALUE_DT~RELCUST~NARRATIVE~MODULE~ACTAMT~TCYTOTCHGAMT~ACCTITLE1~CUSTNAME</FN>'; 
msgxml += '      <FN PARENT="BLK_TRANSACTION_DETAILS" RELATION_TYPE="1" TYPE="BLK_SAFEDEPOSIT_DETAILS">FCCREF~ESN~CNTAMT~CIFID~CUST~CNTCCY~CURPMNT~TOTPMNT~DUEDT~NXTDUEDT~SETLCCY~SETLACC~SETLBRN~VALDT</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_SAFEDEPOSIT_DETAILS" : "BLK_TRANSACTION_DETAILS~1"}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_SAFEDEPOSIT_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 3401_1.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 3401_1.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__TRNREFNO";
pkFields[0] = "BLK_TRANSACTION_DETAILS__TRNREFNO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__TXNACC__LOV_TXNACC":["BLK_TRANSACTION_DETAILS__TXNACC~~~","BLK_TRANSACTION_DETAILS__BRN!VARCHAR2","N~N~N",""],"BLK_TRANSACTION_DETAILS__TXNBRN__LOV_TXNBRN":["BLK_TRANSACTION_DETAILS__TXNBRN~~","","N~N",""],"BLK_TRANSACTION_DETAILS__OFFSETACC__LOV_TXNACC":["~~~","__!","N~N~N",""],"BLK_TRANSACTION_DETAILS__OFFSETCCY__LOV_OFFSETCCY":["BLK_TRANSACTION_DETAILS__OFFSETCCY~~","","N~N",""],"BLK_SAFEDEPOSIT_DETAILS__SETLCCY__LOV_CURRENCY":["BLK_SAFEDEPOSIT_DETAILS__SETLCCY~~","","",""],"BLK_SAFEDEPOSIT_DETAILS__SETLACC__LOV_TXNACC":["BLK_SAFEDEPOSIT_DETAILS__SETLACC~BLK_SAFEDEPOSIT_DETAILS__SETLCCY~~","BLK_SAFEDEPOSIT_DETAILS__SETLBRN!VARCHAR2","N~N~N",""],"BLK_SAFEDEPOSIT_DETAILS__SETLBRN__LOV_TXNBRN":["BLK_SAFEDEPOSIT_DETAILS__SETLBRN~~","","N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_ALL';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CDNM~BLK_TRANSACTION_DETAILS","CMIS~BLK_TRANSACTION_DETAILS","CUDF~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("","",""); 

 var CallRelatType= new Array("N","1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["3401_1"]="KERNEL";
ArrPrntFunc["3401_1"]="3401_2";
ArrPrntOrigin["3401_1"]="KERNEL";
ArrRoutingType["3401_1"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["3401_1"]="N";
ArrCustomModified["3401_1"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CDNM":"","CMIS":"","CUDF":""};
var scrArgSource = {"CDNM":"","CMIS":"","CUDF":""};
var scrArgVals = {"CDNM":"","CMIS":"","CUDF":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CDNM":"","CMIS":"","CUDF":""};
var dpndntOnSrvs = {"CDNM":"","CMIS":"","CUDF":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------