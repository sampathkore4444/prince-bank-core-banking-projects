/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2017, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6512_2_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"SCODE~TXNDATE1~ENDPOINT1~CONSOLIDATED~TXNCCY1~STATUS~BATCHTOTAMT~XREF~BENACCOUNT1~CUSTID1~ACCTITLE1~XRATE1~ACTAMT1~CUSTNAME~BATCHNO~TRANBRN~TRANDT","BLK_CLEARING_DETAILS":"ROUTINGNO~ENTRYNO~REMARKS~PRODUCT~FCCREF~REMACCOUNT~BENACCOUNT~INSTRAMT~INSTRNO~STATUS~REMBRANCH~ENDPOINT~INSTRCCY~TXNDATE~TXNCCY~XREF~INSTRDATE~CUSTID~XRATE~ACCTITLE~LATECLG~DIRECTION~PROJECTNAME~UNITPAYMENT~UNITID~DEPOSITSLIPNO~CHEQUE_ISSUE_DATE~INSTRTYPE~UI_INSTR_TYPE"};

var multipleEntryPageSize = {"BLK_CLEARING_DETAILS" :"15" };

var multipleEntrySVBlocks = "";

var tabMEBlks = {"CVS_MAIN__TAB_CHEQUES":"BLK_CLEARING_DETAILS"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">SCODE~TXNDATE1~ENDPOINT1~CONSOLIDATED~TXNCCY1~STATUS~BATCHTOTAMT~XREF~BENACCOUNT1~CUSTID1~ACCTITLE1~XRATE1~ACTAMT1~CUSTNAME~BATCHNO~TRANBRN~TRANDT</FN>'; 
msgxml += '      <FN PARENT="BLK_TRANSACTION_DETAILS" RELATION_TYPE="N" TYPE="BLK_CLEARING_DETAILS">ROUTINGNO~ENTRYNO~REMARKS~PRODUCT~FCCREF~REMACCOUNT~BENACCOUNT~INSTRAMT~INSTRNO~STATUS~REMBRANCH~ENDPOINT~INSTRCCY~TXNDATE~TXNCCY~XREF~INSTRDATE~CUSTID~XRATE~ACCTITLE~LATECLG~DIRECTION~PROJECTNAME~UNITPAYMENT~UNITID~DEPOSITSLIPNO~CHEQUE_ISSUE_DATE~INSTRTYPE~UI_INSTR_TYPE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_CLEARING_DETAILS" : "BLK_TRANSACTION_DETAILS~N"}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_CLEARING_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 6512_2.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 6512_2.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__TXNDATE1";
pkFields[0] = "BLK_TRANSACTION_DETAILS__TXNDATE1";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_CHEQUES';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_CLEARING_DETAILS");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CMIS~BLK_TRANSACTION_DETAILS","CUDF~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("",""); 

 var CallRelatType= new Array("1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["6512_2"]="KERNEL";
ArrPrntFunc["6512_2"]="";
ArrPrntOrigin["6512_2"]="";
ArrRoutingType["6512_2"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["6512_2"]="N";
ArrCustomModified["6512_2"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CMIS":"","CUDF":""};
var scrArgSource = {"CMIS":"","CUDF":""};
var scrArgVals = {"CMIS":"","CUDF":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CMIS":"","CUDF":""};
var dpndntOnSrvs = {"CMIS":"","CUDF":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------