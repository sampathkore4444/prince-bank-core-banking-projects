/*------------------------------------------------------------------------------------------
** File Name    : 8206_KERNEL.js
**
** Module       : RT
**
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2014  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
	Modified By      : Teja
    Modified On      : 10-Sep-2014  
    Modified Reason  : Currency Becoming Null when Launched From Queues
    Search String    : 9NT1620_1203_TPB_19577679
-----------------------------------------------------------------------------------------
*/

//12.0.3_Single_Step_process starts
function fnPreNew_KERNEL() {
	return true;
}
function fnPostNew_KERNEL() {
    debugs("In fnPostNew", "A");
	//9NT1620_1203_TPB_19577679 Added Starts
	 try{
    tempDOM =  fnGetDataXMLFromFCJXML(dataDOM, 1);
   document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value =  getNodeText(selectSingleNode(tempDOM,"//BLK_TRANSACTION_DETAILS/TXNCCY"));
   }
   catch (e){
       }
    fnDenmBasedTrack();
	
	//9NT1620_1203_TPB_19577679 Added ENds
    return true;

}
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
//PNTFLX01006_FCUBS_12.0.3_Denom_Wise_Variance <Start>
var exchRateBasedOnDenomList;
var exchRateBasedOnDenom;
var denmBasedTrackReqd;

function fnDenmBasedTrack() {

    exchRateBasedOnDenomList = mainWin.denomBasedTracking;
    exchRateBasedOnDenom = exchRateBasedOnDenomList.split(',');
    denmBasedTrackReqd = false;
    for (i = 0;i < exchRateBasedOnDenom.length;i++) {
        if (functionId == exchRateBasedOnDenom[i]){
            denmBasedTrackReqd = true;        
            document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = true;
            }
        }
}

function fnDenomVarianceCheckbox(){

if (denmBasedTrackReqd == false && document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked == true) {
        mask();
        showBranchAlerts(fnBuildAlertXML('WF-2196', 'E'), 'E');
        alertAction = "UNMASK";
        document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = false;
        return false;
    }
//    document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = false;
  return true ; //12.0.3_18471955
}
//PNTFLX01006_FCUBS_12.0.3_Denom_Wise_Variance <End>
function fnPostLoad_KERNEL(e) {
        debugs("In fnPostload", "A");
		//9NT1620_1203_TPB_19577679 Commentin Starts
      //  document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value='';
        //fnDenmBasedTrack() ;	
		//9NT1620_1203_TPB_19577679 Commentin Ends
    return true;
}
//12.0.3_Single_Step_process ends
function fnPreLoad_CVS_DMCD_KERNEL() {
    
    if (document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked) {
        if (!fnValidate())
            return false;
        if (selectNodes(dbDataDOM, "//" + gDenomBlockName).length == 0)
            fnPopulateDenom();
    }
    try {
        if (document.getElementById(mainWin.functionDef[functionId].ofsAmtField)) {
            if (document.getElementById(mainWin.functionDef[functionId].ofsAmtField).value == "") {
                var dispAmt = 0.00;
                document.getElementById(mainWin.functionDef[functionId].ofsAmtField).value = dispAmt;
                var mb3Amount = new MB3Amount(dispAmt, true, document.getElementById(mainWin.functionDef[functionId].ofsCcyField).value);
                document.getElementById(mainWin.functionDef[functionId].ofsAmtField + "I").value = mb3Amount.getDisplayAmount();
            }
        }
    }
    catch (e) {
    }
    return true;
}

function fxDenomInputValidation() {
    var valFailed = false;
    var totalAmt = document.getElementById(mainWin.functionDef[functionId].ofsAmtField).value;
    var cashAmt = null;
    if (selectSingleNode(dbDataDOM, "//" + gDenomSEBlockName + '/CASHAMT'))
        cashAmt = getNodeText(selectSingleNode(dbDataDOM, "//" + gDenomSEBlockName + '/CASHAMT'));
    else 
        cashAmt = 0.00;
    var exchRateBasedOnDenomList = mainWin.denomBasedTracking;
    var exchRateBasedOnDenom = exchRateBasedOnDenomList.split(',');
    for (i = 0;i < exchRateBasedOnDenom.length;i++) {
        if (functionId == exchRateBasedOnDenom[i]) {
            if (Number(cashAmt) != Number(totalAmt) && document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked == true) {
                mask();
                showBranchAlerts(fnBuildAlertXML('WF-2194', 'E'), 'E');
                alertAction = "UNMASK";
                valFailed = true;
            }
        }
    }

    //fnPopulateDenom() ;
    if (valFailed)
        return false;
    fnRecalc();
    return true;
    //9NT1620_FCUBS_12.0.3_Denom_Wise_Variance end
}



//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_TRANSACTION_DETAILS__TXNCCY' ;
    var b = 'BLK_TRANSACTION_DETAILS__OFFSETCCY';
	var c = 'BLK_TRANSACTION_DETAILS__OFFSETAMT' ;
	var d = 'BLK_TRANSACTION_DETAILS__TXNAMT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_213176251
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends