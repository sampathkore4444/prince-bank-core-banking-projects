/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2011  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1350_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 



    Changed By         :  Kundan Verma
    Description        :  Changed language code while searching from ertb_msgs
    Search String      :  FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
	
**  Last Modified By   : Ankit Tiwari
**  Last modified on   : 09-May-2013
**  Reason             : To hide the existing charge Tab.
** Search String 	   : 9NT1587_12.0.2_Acc_Closure_charges

**  Last Modified By   : Vipan Kumar
**  Last modified on   : 26-JUL-2017
**  Reason             : 1350- Can't close other branch CASA account.g_txnBranch has been assigned as Value of branch code for 1350 screen
						As in case of multi branch access g_txnBranch has value of selected branch.	
** Search String 	   : 9NT1606_12_4_RETRO_12_2_26525007
---------------------------------------------------------------
****************************************************************************************************************************/


function fnPostLoad_KERNEL() {
	document.getElementById("TAB_CHARGE").style.display="none";//9NT1587_12.0.2_Acc_Closure_charges	
	debug(dlgArg.mainWin, "In fnPostLoad", "A");  
	fnSaveAll = fnACWMMDenomval;
	return true;
}


function fnShowDefultValues() {
	
    var meblkName = "BLK_CUSTACC_PAYOUT";
	var tableObject;
	var rowList;
	var cashflg;
	var denomAmt = 0.0;
   
    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

	fnComputeAmount();

	if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {  			
			cashflg = rowList[rowIndex].cells[1].getElementsByTagName("SELECT")[0].value;
			if (cashflg == 'C')
			{
			 denomAmt = getCalcAmount(rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value);
			}            

		   }		
		}  

	 document.getElementById("BLK_CUST_ACCOUNT__DENOMAMT").value =  denomAmt;
	 return true;
}

function fnComputeAmount(){

    var meblkName = "BLK_CUSTACC_PAYOUT";
    var tableObject;
    var rowList;
    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

    var totalcompamt=0;       
    var rowamount = 0;
	var compamt = 0;
	var percentage;
	var totalPercentage = 0.00;
	var acamt = document.getElementById("BLK_CUST_ACCOUNT__ACC_AMT").value;

    if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {
			if (rowIndex == (rowList.length-1))
			{
				percentage = 100.00 -  floatingPointMultiplication(totalPercentage,1);
				compamt =   floatingPointMultiplication(acamt,1) - floatingPointMultiplication(totalcompamt,1);  
				totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(compamt,1);
			}
		   else {
          
		    percentage = rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value;
			rowamount = rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value;
		   if((rowamount != "" || rowamount != null) & 	(percentage == "" || percentage == null))
			   {
				 totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(rowamount,1);
				 compamt = 	rowamount;
				 totalPercentage = floatingPointMultiplication(totalPercentage,1)  + floatingPointMultiplication(percentage,1) ;
			   }
           	else{
            totalPercentage = floatingPointMultiplication(totalPercentage,1) +  floatingPointMultiplication(percentage,1) ;
			compamt = (floatingPointMultiplication(percentage,acamt))/ 100.00;
           	totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(compamt,1);
		   }

		}
		if (isNaN(parseInt(compamt))) {
		  compamt = "";
        }
		rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value = compamt;
		} 	

	}
}
function fnPreLoad_CVS_CUSTACW_PO_KERNEL(screenArgs)
{
screenArgs['CCY']        = document.getElementById("BLK_CUST_ACCOUNT__CCY").value;
	//screenArgs['BRN']        = document.getElementById("BLK_CUST_ACCOUNT__BRN_CODE").value;
screenArgs['BRN_CODE']        = document.getElementById("BLK_CUST_ACCOUNT__BRN_CODE").value;
	//screenArgs['ACC']        = document.getElementById("BLK_CUST_ACCOUNT__AC_NO").value;
screenArgs['AC_NO']        = document.getElementById("BLK_CUST_ACCOUNT__AC_NO").value;
	//screenArgs['CCY']        = document.getElementById("BLK_CUST_ACCOUNT__CCY").value;
	screenArgs['CUSTNO']     = document.getElementById("BLK_CUST_ACCOUNT__CUST_ID").value;
	//screenArgs['ACCLS']      = document.getElementById("BLK_CUST_ACCOUNT__ACCLS").value;
	//screenArgs['MATDT']      = document.getElementById("BLK_TDDETAILS__MATDT").value;
	screenArgs['REQ']        = fcjResponseDOM;

// FCUBS11.2 Start
 var meblkName = "BLK_CUSTACC_PAYOUT";
     var tableObject;
     var rowList;
	var bccnt = 0;
       var pdcnt = 0;
	var fccnt = 0;
    try
    { 
        tableObject = document.getElementById(meblkName);
	    rowList = tableObject.tBodies[0].rows.length;
    } catch(e)
    {}
	
	for (var rowIndex = 0; rowIndex < rowList; rowIndex++)
        {
		if (document.getElementsByName("PAYOUTTYPE")[rowIndex].value == 'B')
		{
		bccnt = bccnt+1;
		}
		else if (document.getElementsByName("PAYOUTTYPE")[rowIndex].value == 'P')
		{
		pdcnt = pdcnt+1;
		}
		else if (document.getElementsByName("PAYOUTTYPE")[rowIndex].value == 'F')
		{
		fccnt = fccnt+1;
		}
		}
		if (bccnt > 1 )
		{
		  
		  
		  showErrorAlerts('BRN-VAL-003');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
		  
		  
		  //alert('In multi mode term deposit payout,type Banker Cheque Cannot be choosen more than once');
          return false;		  
		}
		else if (pdcnt > 1)
		{
		
		showErrorAlerts('BRN-VAL-004');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
		
		
		//alert('In multi mode term deposit payout,type Payments Cannot be choosen more than once');
		return false;
		}
	   else if (fccnt > 1)
		{
		
		
		showErrorAlerts('BRN-VAL-005');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
		
		
		
		//alert('In multi mode term deposit payout,type Fund Transfers Cannot be choosen more than once');
		return false;
		}

// FCUBS11.2 End


    return true;
}
function fnFunctionDefultValues()
{
try {
 if (document.getElementById('BLK_CUST_ACCOUNT__BRN_CODE').value == '') 
	  //9NT1606_12_4_RETRO_12_2_26525007  starts	 
	  // document.getElementById('BLK_CUST_ACCOUNT__BRN_CODE').value = mainWin.CurrentBranch;
      document.getElementById('BLK_CUST_ACCOUNT__BRN_CODE').value = g_txnBranch; 
	  //9NT1606_12_4_RETRO_12_2_26525007  ends
} catch(e) {}
}

//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_CUST_ACCOUNT__CCY' ;
    var b = 'BLK_CUST_ACCOUNT__CCY';
	var c = 'BLK_CUST_ACCOUNT__ACC_AMT' ;
	var d = 'BLK_CUST_ACCOUNT__ACC_AMT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
		//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_21317625
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends