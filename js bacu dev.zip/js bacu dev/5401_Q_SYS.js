/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 5401_Q_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~PRD~BRN~TXNBRN~TXNACC~TXNCCY~TXNAMT~OFFSETACC~OFFSETCCY~OFFSETAMT~XRATE~TXNDATE~RELCUST~NARRATIVE~FCCREF~LCYAMT~ACTAMT~TCYTOTCHGAMT~ACCTITLE1~FT~OFFSETBRN~OFFSETTRN~TXNTRN~MODULE~CUSTNAME~AMOUNT_DISBURSED~AMOUNT_FINANCED","BLK_BALANCES":"ACCOUNT_NUMBER~BRANCH_CODE~OUTSTANDING~COMP_CCY~COMPONENT_NAME"};

var multipleEntryPageSize = {"BLK_BALANCES" :"15" };

var multipleEntrySVBlocks = "";

 var tabMEBlks = {"CVS_MAIN__TAB_ALL":"BLK_BALANCES"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~PRD~BRN~TXNBRN~TXNACC~TXNCCY~TXNAMT~OFFSETACC~OFFSETCCY~OFFSETAMT~XRATE~TXNDATE~RELCUST~NARRATIVE~FCCREF~LCYAMT~ACTAMT~TCYTOTCHGAMT~ACCTITLE1~FT~OFFSETBRN~OFFSETTRN~TXNTRN~MODULE~CUSTNAME~AMOUNT_DISBURSED~AMOUNT_FINANCED</FN>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="N" TYPE="BLK_BALANCES">ACCOUNT_NUMBER~BRANCH_CODE~OUTSTANDING~COMP_CCY~COMPONENT_NAME</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_BALANCES" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_BALANCES"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 5401_Q.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 5401_Q.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__FCCREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__FCCREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__TXNACC__LOV_TXNACC":["BLK_TRANSACTION_DETAILS__TXNACC~~~","BLK_TRANSACTION_DETAILS__TXNBRN!VARCHAR2","N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_MAIN';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_ALL';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_BALANCES");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CDNM~BLK_TRANSACTION_DETAILS","CCHG~BLK_TRANSACTION_DETAILS","CMIS~BLK_TRANSACTION_DETAILS","CUDF~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("","","",""); 

 var CallRelatType= new Array("N","N","1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["5401_Q"]="KERNEL";
ArrPrntFunc["5401_Q"]="5401_2";
ArrPrntOrigin["5401_Q"]="KERNEL";
ArrRoutingType["5401_Q"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["5401_Q"]="N";
ArrCustomModified["5401_Q"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CDNM":"","CCHG":"","CMIS":"","CUDF":""};
var scrArgSource = {"CDNM":"","CCHG":"","CMIS":"","CUDF":""};
var scrArgVals = {"CDNM":"","CCHG":"","CMIS":"","CUDF":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CDNM":"","CCHG":"","CMIS":"","CUDF":""};
var dpndntOnSrvs = {"CDNM":"","CCHG":"","CMIS":"","CUDF":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"","NEW":"","MODIFY":"","AUTHORIZE":"","DELETE":"","CLOSE":"","REOPEN":"","REVERSE":"","ROLLOVER":"","CONFIRM":"","LIQUIDATE":"","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------