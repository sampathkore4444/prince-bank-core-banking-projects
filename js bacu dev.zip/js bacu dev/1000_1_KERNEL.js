/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.

**  Last Modified By   :  Teja
**  Last modified on   :  JUL-14-2014
**  Search String      : 9NT1620_1203_RETRO_19205733  
**  Reason             : Skippping Amount negative or zero for 1000 Screen

** Modified By         : Sriraam S
** Modified On         : 28-Oct-2014
** Modified Reason     : Offset branch if sent from ARC, to make use of that instead of current branch
** Search String       : FCUBS_1203_TPB_19895431
------------------------------------------------------------------------------------------
*/

zeroAndNegativeVal=false; //9NT1620_1203_RETRO_19205733
function fnShowDefultValues() {
try{ //FCUBS_1203_TPB_19895431 added
  	document.getElementsByName("TXNCCY")[0].value = document.getElementsByName("OFFSETCCY")[0].value;
	if(document.getElementsByName('OFFSETBRN')[0].value == null || 
        document.getElementsByName('OFFSETBRN')[0].value == '' ||  document.getElementsByName('OFFSETBRN')[0].value == '*.*')
		//FCUBS_1203_TPB_19895431 added If condition
	document.getElementsByName('OFFSETBRN')[0].value= mainWin.CurrentBranch;
	document.getElementsByName('BRN')[0].value= mainWin.CurrentBranch;
}
catch(e){} //FCUBS_1203_TPB_19895431 added
}

