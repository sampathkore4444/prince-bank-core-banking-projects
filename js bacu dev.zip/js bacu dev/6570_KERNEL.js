/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright �  vercon_start_year - vercon_end_year  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6570_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/


function fnPreSave() {
try{
document.getElementById('BLK_CLEARING_REJECT_DETAILS__INSTRAMT') = null;
}catch(e){}
}

function fnPostLoad_KERNEL()
{
 document.getElementById('BLK_CLEARING_REJECT_DETAILS__BTN_QUERY').style = "hidden";
}

function fnRemarksDefault(event) {
var index=getRowIndex(event)-1;
if (dataObj.action != "REMOTEAUTH") {
var narr_def =  document.getElementById("BLK_CLEARING_REJECT_DETAILS__REMARKS").getAttribute('DEFAULT');
	var chq_num = document.getElementById("BLK_CLEARING_REJECT_DETAILS__INSTRNO").value;
	var rej_rsn = document.getElementById("BLK_CLEARING_REJECT_DETAILS__REJECTREASON").value;
	var narr_val = "";
	narr_split = narr_def.split('-');
	if(chq_num == "") chq_num =  ( narr_split[1] );
	if(rej_rsn == "") rej_rsn =  (narr_split[2]);
	narr_val = narr_split[0] +"-" +chq_num +"-"+rej_rsn;
	 document.getElementById("BLK_CLEARING_REJECT_DETAILS__REMARKS").value = narr_val;
	}
	return true;
}

function fnShowDefultValues() {
	try{
	document.getElementsByName('REMACCOUNT')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_REJECT_DETAILS" + "/" + "REMACCOUNT"));
	document.getElementsByName('BENACCOUNT')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_REJECT_DETAILS" + "/" + "BENACCOUNT"));
	}catch(e) {	}
	
}