/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1317_2_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : Gokulnath.M
**  Last modified on   : 19-Apr-2012
**  Full Version       : FCUBS12.0.0
**  Reason             : Redemption mode disabled changes
**  Search String : 9NT1501 ITR1 sfr 13970179

	Modified By              : Sriraam S
    Modified On              : 20-Jun-2013
    Modified Reason          : To show the Cash amount in the front end after calculating w.r.to Percentage of redemption amount and build td payout details, base 
							   bug#16713430
    Search String            : 9NT1587_1202_INTERNAL_16999937
****************************************************************************************************************************/

function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");  
	fnSaveAll = fnTdredmDenomval;
	//9NT1501 ITR1 sfr 13970179
	if(document.getElementsByName("REDEMPTION_MODE")[0].value == 'N')	{
		fnEnableElement(document.getElementsByName("WAVE_PENALTY")[0]);
		fnEnableElement(document.getElementsByName("WAIVE_INTEREST")[0]);
	}
	else {
		fnDisableElement(document.getElementsByName("WAVE_PENALTY")[0]);
		fnDisableElement(document.getElementsByName("WAIVE_INTEREST")[0]);
	}
	return true;
}

function fnShowDefultValues() {
	
     var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
	 var tableObject;
	 var rowList;
	var cashflg;
	var denomAmt = 0.0;
	var percentageEntered; //9NT1587_1202_INTERNAL_16999937 Added

    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

	 if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {  			
			cashflg = rowList[rowIndex].cells[1].getElementsByTagName("SELECT")[0].value;
			if (cashflg == 'C')
			{
			//9NT1587_1202_INTERNAL_16999937 Starts
			//denomAmt = getCalcAmount(rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value);
			 percentageEntered = rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value;
			 if(percentageEntered == null || (percentageEntered != null && (percentageEntered.replace(/\s+/g, ' ')).length == 0)){
			 document.getElementById("BLK_TD_REDEMPTION__DENOMAMT").value  = rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value;		
			}     
			break;
		    //9NT1587_1202_INTERNAL_16999937 Ends
			}            

		   }		
		}  

	 //document.getElementById("BLK_TD_REDEMPTION__DENOMAMT").value =  denomAmt; //9NT1587_1202_INTERNAL_16999937 Commented
	// document.getElementById("BLK_TDDETAILS__DENOMAMT").value =  denomAmt;
	 return true;
}

function fnInTab_TAB_DENOM_KERNEL()  
{ 
	
	fnSetDenomCcy();
	appendData('TBLPageTAB_DENOM');
	return true;
}
