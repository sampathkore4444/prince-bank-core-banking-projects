/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2014  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software System and is copyrighted by 
**  Oracle Financial Services Software Limited.
**  
**  All rights reserved.  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle Financial Services Software Limited.
**  
**  Oracle Corporation
**  World Headquarters
**  500 Oracle Parkway
**  Redwood Shores, CA 94065
**  U.S.A.
**  
**  Copyright � 2011 - 2012 by Oracle Financial Services Software limited. All rights reserved.
**  Oracle Financial Services Software Limited.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 5521_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   :  RavikumarG
**  Last modified on   :  13-Dec-2010
**  Full Version       :  9NT1428, Kernel 11,2, ITR2
**  Reason             :  SFR Number: 355: Retrival of total number of rows based on the dbDataDOM object is done
**  Search String      :  FC11.2, ITR#2, SFR#355
** Last Modified By   :  Ediga GANGADHAR
**  Last modified on   :  24-APRIL-2013
**  Reason             :  Capture the additionl information Drawee a/c no and Cheque number into Remarks
**  Search String      :   9NT1587_16712454_Narrative

** Last Modified By   :  Ediga GANGADHAR
**  Last modified on   :  24-APRIL-2013
**  Reason             : Due to mis place of '*' fnPreSave_KERNEL() is commneted.
**  Search String      :  FC12.0.2 IUT BUG NO#126

**  Last Modified By   :  Sarina
**  Last modified on   : 12-JUN-2013
**  Reason             : fnHandleError call commented as it is not reqd for addrows 
		         and because of it presave_kernel was not getting hit. Instead 
		         fnSetScrData is used to paint response on screen
**  Search String      : FC12.0.2 IUT BUG NO 149

**  Last Modified By   :  Vishalakshi N
**  Last modified on   :  13-Dec-2013  
**  Reason             :  To Calculate total of all amounts entered for multiple rows.
**  Search String      :  9NT1606_17947564_RETRO

**  Last Modified By   :  Vishalakshi N
**  Last modified on   :  31-Oct-2014
**  Reason             :  Amount field issue in Chrome.
**  Search String      :  INTERNAL_RETRO_19929816

Modified By      : Vijay Masti
Modified On      : 21-Nov-2016
Modified Reason  : Total Amount will be calculated even if we do not click on the button Outstanding amount
Retro for SFR    : 22734185
Search String    : RETRO_SFR_23658117
****************************************************************************************************************************/

//var fcjRequestDOM;
//var fcjResponseDOM;
var gaccno="";	 /**Account Desc Related Changes*/
//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */

/**Account Desc Related Changes Start*/
function getMsXmlDom(){ 
	var tempDom;
	try{
//As part of cross browser compatibility, ActiveXObject creation removed
	}catch(e){
//As part of cross browser compatibility, ActiveXObject creation removed
	}

	return tempDom;
}
/**Account Desc Related Changes End*/
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	var v_plus_button = document.getElementById("cmdAddRow_BLK_CLEARING_DETAILS");
	v_plus_button.disabled = "disabled";
	v_plus_button.style.display = "none";
	/*try{
	   var clearing_rows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows;
	 document.getElementsByName('ENDPOINT1')[0].value=clearing_rows[0].cells[12].getElementsByTagName("INPUT")[0].value;
	 document.getElementsByName('TXNCCY1')[0].value=clearing_rows[0].cells[15].getElementsByTagName("INPUT")[0].value ;
	 }catch(e) { }	*/
	return true;
}


function fnAddRowsWithDefault() {
	//fnAddRows1_JS(); return;

	//var l_brn=document.getElementById('BLK_TRANSACTION_DETAILS__BRN').value;
	var l_rowCnt =document.getElementById('BLK_TRANSACTION_DETAILS__ROWSTA').value;

	if (!l_rowCnt) {
		
		showErrorAlerts('BRN-VAL-007');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
		
		//alert("Enter the Number of Entries To be Added");
		return false;
	}

	tempAction = dataObj.action;
	fnAddRows0();
	dataObj.action	= tempAction;
	//document.getElementById('BLK_TRANSACTION_DETAILS__BRN').value=l_brn;
}

function fnAddRows0() {

	window.focus();
	appendData();
	dataObj.action = 'ADDNEWROWS';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
	var v_xml_string = getXMLString(fcjResponseDOM);
	if (fcjResponseDOM && v_xml_string.length > 0) {
		dataObj = new dataObject(v_xml_string);
		//FC12.0.2 IUT BUG NO 149 starts
		fnSetScrData(fcjResponseDOM);
		//var returnValue = fnHandleError();
		//FC12.0.2 IUT BUG NO 149 ends
	} else {
		alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
		return;
	}
	//9NT1587_16712454_Narrative starts
	var totRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
	for(var i=0; i< totRows; i++){
		document.getElementsByName("REMARKS")[i].value = document.getElementsByName("REMARKS")[i].getAttribute('DEFAULT');
		}
		//9NT1587_16712454_Narrative ends
}


function fnAddRows1_JS() {

	var l_rowCnt =document.getElementById('BLK_TRANSACTION_DETAILS__ROWSTA').value;
	for(i = 0; i < l_rowCnt; i++) {
		fnAddRow("BLK_CLEARING_DETAILS");
		
		
	}
}

function fnPostDeleteRow_BLK_CLEARING_DETAILS_KERNEL() {

	appendData(document.getElementById("TBLPageTAB_CHEQUES"));
	var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));
	for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENTRYNO"), new String(l_Cnt + 1));
	}

	var pageNo = Number(document.getElementById("CurrPage__BLK_CLEARING_DETAILS").innerHTML) - 1;
    var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
	var entryNo;
    for(var i=0; i< totalRows; i++){
		entryNo = new String(pageNo * PAGE_SIZE + i + 1);
		document.getElementsByName("ENTRYNOI")[i].value = entryNo;
		document.getElementsByName("ENTRYNO")[i].value = entryNo;
    }
    return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {
     return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}
//9NT1587_16712454_Narrative starts
function fnRemarksDefault(event) {
var index=getRowIndex(event)-1;
if (dataObj.action != "REMOTEAUTH") {
var narr_def =  document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[index].cells[17].getElementsByTagName("INPUT")[0].getAttribute('DEFAULT');
	var chq_num = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[index].cells[4].getElementsByTagName("INPUT")[0].value;
	var drwe_acc = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[index].cells[9].getElementsByTagName("INPUT")[0].value;
	var narr_val = "";
	narr_split = narr_def.split('-');
	if(chq_num == "") chq_num =  (narr_split[2]);
	if(drwe_acc == "") drwe_acc =  (narr_split[4] );
	narr_val = narr_split[0] +"-" +narr_split[1]+"-"+chq_num +"-"+narr_split[3] + "-"+drwe_acc;
	 document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[index].cells[17].getElementsByTagName("INPUT")[0].value = narr_val;
	}
	return true;
}//9NT1587_16712454_Narrative ends
/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
*/ //FC12.0.2 IUT BUG NO#126
function fnPreSave_KERNEL() {
		
	var isValid = true;
	//FC11.2, ITR#2, SFR#355 Starts
	var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));
	for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENTRYNO"), new String(l_Cnt + 1));
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "TXNCCY"), document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value);
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "INSTRCCY"), document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value);
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "TXNDATE"), document.getElementById("BLK_TRANSACTION_DETAILS__TXNDATE1").value);
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENDPOINT"), document.getElementById("BLK_TRANSACTION_DETAILS__ENDPOINT1").value);
	} 	

    var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
    for(var i=0; i< totalRows; i++){
		document.getElementsByName("TXNCCY")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value;
	    document.getElementsByName("INSTRCCY")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value;
	    document.getElementsByName("TXNDATE")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNDATE1").value;
	    document.getElementsByName("ENDPOINT")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__ENDPOINT1").value;
    }
	//FC11.2, ITR#2, SFR#355 Ends
	appendTabData(document.getElementById('TBLPageTAB_CHEQUES'));

	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	//RETRO_SFR_23658117 starts
	try {
		var totalAmt = 0;
		var l_Cnt = 0;
		appendData(document.getElementById("TBLPageTAB_MAIN"));
        var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS')); 
		if(clgNodes) {
			for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
				var l_Node = clgNodes[l_Cnt];
				var amt = getNodeText(selectSingleNode(l_Node, "INSTRAMT")); 
				if (amt && !isNaN(amt))
					totalAmt = addlargefloatsigned(totalAmt,amt);
			}
		}
		document.getElementById('BLK_TRANSACTION_DETAILS__BHATCHTOTAMTI').value = totalAmt;
		document.getElementById('BLK_TRANSACTION_DETAILS__BHATCHTOTAMT').value = totalAmt;
	} catch (ex) {
	}
	//RETRO_SFR_23658117 ends
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

		return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	
	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}

 function fnDefultBrnValues() {
   //alert('in setDefaultValues ');
	try{
	   var clearing_rows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows;
	 document.getElementsByName('ENDPOINT1')[0].value=clearing_rows[0].cells[12].getElementsByTagName("INPUT")[0].value;
	 document.getElementsByName('TXNCCY1')[0].value=clearing_rows[0].cells[15].getElementsByTagName("INPUT")[0].value ;
	 }catch(e) { }
 }
 /**Account Desc Related Changes Start*/
  function fnPostAddRow_BLK_CLEARING_DETAILS_KERNEL() {
 /*   newRow.cells[3].firstChild.value=dlgArg.mainWin.frames['Global'].CurrentBranch;
    	return true;  */
// start FCUBS 11.1 new code added.
appendData(document.getElementById("TBLPageAll"));
var l_LimitdetNode =  document.getElementById("BLK_CLEARING_DETAILS").tBodies[0];
var len =l_LimitdetNode.rows.length;
 if (l_LimitdetNode.rows.length > 0)
     {
	l_LimitdetNode.rows[len-1].cells[3].getElementsByTagName("INPUT")[0].value = mainWin.CurrentBranch; 
   }  
// End FCUBS 11.1 new code added.
 
 }
 function fnFetchAccDesc(){
	tempaction=dataObj.action;
        //gaccno--9NT1587_16712454_Narrative
	var currentrow = getRowIndex(evnt)-1;
	var accno  = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[currentrow].cells[4].getElementsByTagName("INPUT")[0].value;
	var accbrn = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[currentrow].cells[3].getElementsByTagName("INPUT")[0].value;
        if ((accno!="")&&(accbrn!="")&&(gaccno!=accno))
        {
	window.focus();   
	if (typeof(l_HeaderTabId) != 'undefined' && l_HeaderTabId != "") 
		appendData(document.getElementById("TBLPage" + l_HeaderTabId));
	var userLanguageCode = mainWin.frames("Global").LangCode;
	var tempDataDom = mainWin=loadXMLDoc(mainWin.UIXmlPath + "/" + userLanguageCode + "/" + dataObj.uiXml);
	var tabIds = selectNodes(tempDataDom,"//PAGE/@ID");
	if (document.getElementById("TBLPageAll")) 
		appendData(document.getElementById("TBLPageAll"));
	for (var i = 0; i < tabIds.length; i++) 
		appendData(document.getElementById("TBLPage" + tabIds[i].text));
	dataObj.action = "ACCDEC";
	fcjRequestDOM = buildUBSXml();
	var newADDL = selectSingleNode(fcjRequestDOM,"//ADDL");
	if (newADDL == undefined || newADDL == null) 
		newADDL = fcjRequestDOM.createElement("ADDL");
	var newParam = fcjRequestDOM.createElement("ACCNO");
	var newName = fcjRequestDOM.createElement("NAME");
	var newValue = fcjRequestDOM.createElement("VALUE");
	newName.appendChild(fcjRequestDOM.createTextNode("ATTRNAME"));
	newValue.appendChild(fcjRequestDOM.createTextNode(accno));
	newParam.appendChild(newName);
	newParam.appendChild(newValue);
	newADDL.appendChild(newParam);


	newParam = fcjRequestDOM.createElement("ACCBRN");
	newName = fcjRequestDOM.createElement("NAME");
	newValue = fcjRequestDOM.createElement("VALUE");
	newName.appendChild(fcjRequestDOM.createTextNode("ATTRVALUE"));
	newValue.appendChild(fcjRequestDOM.createTextNode(accbrn));
	newParam.appendChild(newName);
	newParam.appendChild(newValue);
	newADDL.appendChild(newParam);

	newParam = fcjRequestDOM.createElement("ACCDESC");
	newName = fcjRequestDOM.createElement("NAME");
	newValue = fcjRequestDOM.createElement("VALUE");
	newName.appendChild(fcjRequestDOM.createTextNode("ATTRNAME"));
	newValue.appendChild(fcjRequestDOM.createTextNode("NA"));
	newParam.appendChild(newName);
	newParam.appendChild(newValue);
	newADDL.appendChild(newParam);

	if (selectSingleNode(fcjRequestDOM,"//ADDL") == undefined) 
selectSingleNode(		fcjRequestDOM,"//FCUBS_HEADER").appendChild(newADDL);
setNodeText(selectSingleNode(fcjRequestDOM,"//ACTION"), dataObj.action);
setNodeText(selectSingleNode(fcjRequestDOM,"//SOURCE"), 'FLEXBRANCH');
setNodeText(selectSingleNode(fcjRequestDOM,"//MODULEID"), 'WB');
setNodeText(selectSingleNode(fcjRequestDOM,"//MULTITRIPID"), dataObj.multitripid);

	fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=WORKFLOW&actionType=accdesc&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
	var txnXMLDOM =getMsXmlDom();
	txnXMLDOM=loadXMLDoc(getXMLString(fcjResponseDOM));
	var accdesc =getNodeText( selectSingleNode(txnXMLDOM,"//ACCDESC/VALUE"));
	document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[currentrow].cells[5].getElementsByTagName("INPUT")[0].value = accdesc;
        gaccno= accno;
        }
	dataObj.action=tempaction;
	return true;
 
}
 function fnFetchAccDescUtil(){
	var currentrow = getRowIndex(evnt)-1;
        gaccno=document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[currentrow].cells[4].getElementsByTagName("INPUT")[0].value;
	return true;

} 

 /**Account Desc Related Changes End*/
//9NT1606_17947564_RETRO starts
 function fnCalculateTotAmt() {
	try {
		var totalAmt = 0;
		var l_Cnt = 0;
		appendData(document.getElementById("TBLPageTAB_MAIN"));
		var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));
		if(clgNodes) {
			for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
				var l_Node = clgNodes[l_Cnt];
				var amt = getNodeText(selectSingleNode(l_Node, "INSTRAMT"));
				if (amt && !isNaN(amt))
					totalAmt = parseFloat(totalAmt) + parseFloat(amt);
			}
		}
		//INTERNAL_RETRO_19929816 starts
		/*document.getElementsByName('BHATCHTOTAMTI')[0].value = totalAmt;
		document.getElementsByName('BLK_TRANSACTION_DETAILS__BHATCHTOTAMT')[0].value = totalAmt; */
		document.getElementById("BLK_TRANSACTION_DETAILS__BHATCHTOTAMTI").value = totalAmt;
		document.getElementById("BLK_TRANSACTION_DETAILS__BHATCHTOTAMT").value = totalAmt;
		//INTERNAL_RETRO_19929816 ends
	} catch (ex) {
	}
}
//9NT1606_17947564_RETRO ends