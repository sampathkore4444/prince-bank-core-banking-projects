/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
    Modified by        : TEJA
  Modified reason	 : The code has beed added to default narrative to screen name
  Modified Date		 : 03-NOV-2014
  Search String		 : 9NT1620_1203_RETRO_19940289 
---------------------------------------------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
//9NT1620_1203_RETRO_19940289  STARTS
 try {
          document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").getAttribute("DEFAULT");
    }
    catch (e) {
    }

//9NT1620_1203_RETRO_19940289  ENDS
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	debugs("In fnPreSave", "A");	
	var isValid = true;
	if(!fnValidate())
        return false;

	debugs("In fnPreSave", "A");	
	return isValid;	
	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}



function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}



function fnPreAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_MIS_KERNEL() {
    return true;
}
function fnInTab_TAB_MIS_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_MIS_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}


function fnPreAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_UDF_KERNEL() {
    return true;
}
function fnInTab_TAB_UDF_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_UDF_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}



function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnInTab_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL() {
    return true;
}
