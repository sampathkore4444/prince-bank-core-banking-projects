/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2018, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1406_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~PRD~BRN~ACCTXN~CHRACC~TXNACC~ACCCY~TXNCCY~TXNAMT~TXNBRN~OFFSETACC~OFFSETCCY~OFFSETAMT~OFFSETBRN~COMM_MODE~MOBILE_NUMBER~EMAIL_ID~NARRATIVE~BENFADDR1~BENFADDR2~BENFADDR3~RELCUST~CHG_AMT~XRATE~LCYAMT~TRNDATE~FCCREF~ACCTITLE1~CUSTNAME~TCYTOTCHGAMT~ACTAMT~COUNTRYFT~NEGOTRATE~NEGOTREFNO~AC_OR_GL~UI_TXN_ACC"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~PRD~BRN~ACCTXN~CHRACC~TXNACC~ACCCY~TXNCCY~TXNAMT~TXNBRN~OFFSETACC~OFFSETCCY~OFFSETAMT~OFFSETBRN~COMM_MODE~MOBILE_NUMBER~EMAIL_ID~NARRATIVE~BENFADDR1~BENFADDR2~BENFADDR3~RELCUST~CHG_AMT~XRATE~LCYAMT~TRNDATE~FCCREF~ACCTITLE1~CUSTNAME~TCYTOTCHGAMT~ACTAMT~COUNTRYFT~NEGOTRATE~NEGOTREFNO~AC_OR_GL~UI_TXN_ACC</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1406.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1406.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__FCCREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__FCCREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__ACCTXN__LOV_TXNACC":["BLK_TRANSACTION_DETAILS__ACCTXN~BLK_TRANSACTION_DETAILS__ACCCY~BLK_TRANSACTION_DETAILS__ACCTITLE1~BLK_TRANSACTION_DETAILS__TXNBRN~","","N~N~N~N",""],"BLK_TRANSACTION_DETAILS__CHRACC__LOV_TXNACC":["BLK_TRANSACTION_DETAILS__CHRACC~BLK_TRANSACTION_DETAILS__ACCCY~BLK_TRANSACTION_DETAILS__ACCTITLE1~BLK_TRANSACTION_DETAILS__TXNBRN~","","N~N~N~N",""],"BLK_TRANSACTION_DETAILS__TXNCCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__TXNCCY~~","","",""],"BLK_TRANSACTION_DETAILS__OFFSETCCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__OFFSETCCY~~","","",""],"BLK_TRANSACTION_DETAILS__COUNTRYFT__LOV_COUNTRY":["BLK_TRANSACTION_DETAILS__COUNTRYFT~~","","N~N",""],"BLK_TRANSACTION_DETAILS__UI_TXN_ACC__LOV_TXNACC":["BLK_TRANSACTION_DETAILS__UI_TXN_ACC~BLK_TRANSACTION_DETAILS__ACCCY~BLK_TRANSACTION_DETAILS__ACCTITLE1~BLK_TRANSACTION_DETAILS__TXNBRN~BLK_TRANSACTION_DETAILS__OFFSETCCY~BLK_TRANSACTION_DETAILS__AC_OR_GL~","","N~N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_BODY';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("DMCD~BLK_TRANSACTION_DETAILS","CHCD~BLK_TRANSACTION_DETAILS","MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","FTCD~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("DETBS_RTL_TELLER.XREF=CSTBS_WBDENOM_MASTER.XREF","DETBS_RTL_TELLER.XREF=CSTBS_WBCHARGE_DETAILS.XREF","DETBS_RTL_TELLER.XREF=MIVWS_MIS_DETAILS.XREF","DETBS_RTL_TELLER.XREF=UDVWS_UDF_DETAILS.XREF",""); 

 var CallRelatType= new Array("N","N","1","N","1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1406"]="KERNEL";
ArrPrntFunc["1406"]="";
ArrPrntOrigin["1406"]="";
ArrRoutingType["1406"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1406"]="N";
ArrCustomModified["1406"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CVS_MAIN":"TXNCCY","DMCD":"","CHCD":"","MDCD":"","UDCD":"","FTCD":""};
var scrArgSource = {"CVS_MAIN":"BLK_TRANSACTION_DETAILS__TXNACC","DMCD":"","CHCD":"","MDCD":"","UDCD":"","FTCD":""};
var scrArgVals = {"CVS_MAIN":"","DMCD":"","CHCD":"","MDCD":"","UDCD":"","FTCD":""};
var scrArgDest = {"CVS_MAIN":""};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","FTCD":""};
var dpndntOnSrvs = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","FTCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"2"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------