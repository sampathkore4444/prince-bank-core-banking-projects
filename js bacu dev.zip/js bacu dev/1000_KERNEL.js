/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.

**  Last Modified By   :  Teja
**  Last modified on   :  JUL-14-2014
**  Search String      : 9NT1620_1203_RETRO_19205733  
**  Reason             : Skippping Amount negative or zero for 1000 Screen

** Modified By         : Sriraam S
** Modified On         : 28-Oct-2014
** Modified Reason     : Offset branch if sent from ARC, to make use of that instead of current branch
** Search String       : FCUBS_1203_TPB_19895431

** Modified By         : Mohit Ojha
** Modified On         : 07-Apr-2017
** Modified Reason     : MCY/VA changes
** Search String       : FCUBS12.4MCY/VA changes

** Modified By         : Mohit Ojha
** Modified On         : 07-Apr-2017
** Modified Reason     : TRANSACTION ACCOUNT NOT ENTERED ERROR ON PICK UP
** Search String       : Bug#25852184 
**
** Modified By         : Shayam Sundar Ragunathan
** Modified On         : 14-Nov-2017
** Modified Reason     : Changes done to retain transaction currency when GL account is select as 
						 transaction account.
						 Assigned user entered ccy value when currency defaulted from account is null.
** Search String       : 9NT1606_12_4_RETRO_12_2_26913086

** Modified By         : Himanshu Chowdhary
** Modified On         : 07-Feb-2018
** Modified Reason     : Code added to default the Transaction currency on screen launch.
** Search String       : 124_NRSP_27499850

** Modified By         : Mantinder Kaur
** Modified On         : 20-Mar-2018
** Modified Reason     : The offset account not getting defaulted on query if the same is mainained in arc for the product.
						Fix provided to set the offset account as offset account maintained in the arc maintenance on click of query.
** Search String       : FCUBS_124_SAIGON_27705440

** Modified By         : Mantinder Kaur
** Modified On         : 08-May-2019
** Modified Reason     : Amount based signatory not working for 1000 screen.There was no code available to support the amount based signatory for 1000 screen.
						Handling given to show the amount based signatory on F12 for the transaction leg.
** Search String       : FCUBS_124_SAIGON_27960518
------------------------------------------------------------------------------------------
*/

zeroAndNegativeVal=false; //9NT1620_1203_RETRO_19205733
function fnShowDefultValues() {
try{ //FCUBS_1203_TPB_19895431 added
  	document.getElementsByName("TXNCCY")[0].value = document.getElementsByName("OFFSETCCY")[0].value;  //9NT1606_12_4_RETRO_12_2_26913086 commented    //124_NRSP_27499850 uncommented
	//document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value; //9NT1606_12_4_RETRO_12_2_26913086   // 124_NRSP_27499850 commented 
	if(document.getElementsByName('OFFSETBRN')[0].value == null || 
        document.getElementsByName('OFFSETBRN')[0].value == '' ||  document.getElementsByName('OFFSETBRN')[0].value == '*.*')
		//FCUBS_1203_TPB_19895431 added If condition
	document.getElementsByName('OFFSETBRN')[0].value= mainWin.CurrentBranch;
	document.getElementsByName('BRN')[0].value= mainWin.CurrentBranch;
}
catch(e){} //FCUBS_1203_TPB_19895431 added
}
//124_NRSP_27499850 starts
function fnPostLoad_KERNEL(e) {
	try {
        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = mainWin.Lcy;
    }
    catch (e) {
    }
    return true;
}
//124_NRSP_27499850 ends
//FCUBS_124_SAIGON_27705440 starts
//function fnPreQueryKernel() {  
function fnPreQuery_KERNEL() {
//FCUBS_124_SAIGON_27705440 ends
document.getElementsByName("OFFSETCCY")[0].value=document.getElementsByName("TXNCCY")[0].value;
document.getElementsByName("OFFSETCCY")[0].value==null;
return true ;
}
//FCUBS_124_SAIGON_27705440 starts
//function fnPostQueryKernel() { 
function fnPostQuery_KERNEL() {
//FCUBS_124_SAIGON_27705440 ends
 document.getElementsByName('BRN')[0].value= mainWin.CurrentBranch;
//FCUBS_124_SAIGON_27705440 starts
document.getElementById("BLK_TRANSACTION_DETAILS__UI_TXN_ACC").value=document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value 
document.getElementById("BLK_TRANSACTION_DETAILS__UI_OFS_ACC").value=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value
if(document.getElementsByName('OFFSETBRN')[0].value == null || document.getElementsByName('OFFSETBRN')[0].value == '' ||  document.getElementsByName('OFFSETBRN')[0].value == '*.*')
document.getElementsByName('OFFSETBRN')[0].value= mainWin.CurrentBranch;
//FCUBS_124_SAIGON_27705440 ends
return true ;
}
//FCUBS12.4MCY/VA changes starts
function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH' || dataObj.action == 'RESOLVEVIRTUALACC' || dataObj.action == 'BRNQUERY'){     //Bug#25852184
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
			
    if (eventElement.name == 'UI_TXN_ACC' || eventElement.name == 'TXNCCY') {
      appendData();  
	//Bug#25852184
	if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE")) == 'M')                
					{
                     document.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY').value = document.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY').oldvalue  ;
					 appendData();
                    }
	//Bug#25852184		
		
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY")) == "" && ((getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE"))) == 'V'|| (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE")) == 'M' )))
  document.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY').oldvalue = "";
  if(eventElement.name == 'UI_TXN_ACC'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE")) != 'V' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE")) != 'M'))
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(eventElement.id).value;
		}	// 1203_ITR1_18388624
        if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE")) == 'M') {
					
					
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    }
      return true;
}

function fnResolveVirAcc1(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH' || dataObj.action == 'RESOLVEVIRTUALACC' || dataObj.action =='BRNQUERY'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
    if (eventElement.name == 'UI_OFS_ACC' || eventElement.name == 'OFFSETCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) == "" && ((getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE"))) == 'V'|| (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC_TYPE")) == 'M' )))
  document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMT').oldvalue = "";
  if(eventElement.name == 'UI_OFS_ACC'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_OFS_ACC_TYPE")) != 'V' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_OFS_ACC_TYPE")) != 'M'))
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value = document.getElementById(eventElement.id).value;
		}	// 1203_ITR1_18388624
        if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_OFS_ACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_OFS_ACC_TYPE")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_OFS_ACC_TYPE")) == 'M') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    }
      return true;
}
//FCUBS12.4MCY/VA changes ends
//124_NRSP_27499850 starts commenting
/* //9NT1606_12_4_RETRO_12_2_26913086 starts
function fnonchangeTxnacc() {
	
	if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value == "") {
		document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").oldvalue;
    }
} */
//9NT1606_12_4_RETRO_12_2_26913086 ends
//124_NRSP_27499850 comment ends
//FCUBS_124_SAIGON_27960518 starts
function fnAmountF12_KERNEL(addlArgs,e ) {

try {

	   addlArgs['LOV_AMT'] = null ;
	  if(getEventSourceElement(e).name == "UI_TXN_ACC"){
	var a = 'BLK_TRANSACTION_DETAILS__TXNCCY' ;
    var b = 'BLK_TRANSACTION_DETAILS__TXNCCY';
	var c = 'BLK_TRANSACTION_DETAILS__TXNAMT' ;
	var d = 'BLK_TRANSACTION_DETAILS__TXNAMT' ; 

				if(!f12Validation(a, b, c, d , addlArgs ,e ))
		return false ;
	  }else {	
	    var srcElement = getEventSourceElement(e);
        if (document.getElementById(srcElement.id).value == "") {
            mask();
            showBranchAlerts(fnBuildAlertXML('WF-0001', 'E'), 'E');
            return false;
        }
	}
	}catch(e){}
	return true; 

}
//FCUBS_124_SAIGON_27960518 ends