/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1317_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : SUHAS REKHU
**  Last modified on   : 23-NOV-2010
**  Full Version       : 
**  Reason             : 9NT1428 -ITR1-SFR#1038  ,POPULATE THE AC_NO


    Changed By         :  Kundan Verma
    Description        :  Changed language code while searching from ertb_msgs
    Search String      :  FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
	
    Changed  By           : Gokulnath M
    Changed  On           : 16-Apr-2012
    Modified Reason       : Default Maturity value reassigned
    Search String          : 9NT1501 ITR1 sfr 13960491	
    
    Changed  By           : Reddy Prasad
    Changed  On           : 24-Jul-2013
    Modified Reason       : 1317 - PAYOUT TO TD IS NOT FETCHING ACCOUNT NUMBER IN OPERA
    Search String          : 9NT1587 12.0.2 ITR1 17181267
    Changed  By           : Sriraam S
    Changed  On           : 14-May-2014
    Modified Reason       : Reset Payout Redemption amount on change of Payout Percentage , Total Redemption amount (for Partial Redemption), 
																																Waive Interest
    Search String         : 9NT1587_1203_INTERNAL_18912683
****************************************************************************************************************************/
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");  
	//fnSaveAll = fnTdredmDenomval;
	//appendData();
	return true;
}

//9NT1587_1203_INTERNAL_18912683 starts
function fnResetRedemAmt(){
    var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
    var tableObject;
    var rowList;
    var percentageEntered;
     try
        {
            tableObject = document.getElementById(meblkName);
            rowList = tableObject.tBodies[0].rows;
            if(rowList != null && rowList.length > 0){
                percentageEntered = rowList[0].cells[2].getElementsByTagName("INPUT")[0].value;
                if(percentageEntered != null && (percentageEntered.replace(/\s+/g, ' ')).length > 0){
                    if(!(document.getElementsByName("REDMAMT")[0].disabled)){
                            for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
                             {
                                 document.getElementsByName("REDMAMT")[rowIndex].value  = "";               
                             }
                        }
                }
            }
         }
         catch(e)
	    {}
}
//Will be trigerred onChange of Percentage in Input stage
//Sample value of Id is --> "BLK_TDREDMPAYOUT_DETAILS__PERCENTAGEI" for 1st row, "BLK_TDREDMPAYOUT_DETAILS__PERCENTAGEI6" for 7th row
function fnRedemAmtReset(event){
    var rowIndex = event.srcElement.id.substring(event.srcElement.id.length-1,event.srcElement.id.length);
    if (isNaN(rowIndex)){
      document.getElementsByName("REDMAMT")[0].value  = "";
    }
    else{
		for (var index = 0; index <=rowIndex; index++) 
        document.getElementsByName("REDMAMT")[index].value  = ""; 
    } 
}
//9NT1587_1203_INTERNAL_18912683 Ends
function fnPreLoad_CVS_TDPAYOUT_KERNEL(screenArgs)
{
  //9NT1587 12.0.2 ITR1 17181267  Starts
	var ua = navigator.userAgent.toLowerCase(); 	
	if((ua.indexOf("opera") != -1)) {
		dbDataDOM = loadXMLDoc(getXMLString(dbDataDOM));
	}
	//9NT1587 12.0.2 ITR1 17181267  Ends  
	screenArgs['BRN']        = document.getElementById("BLK_TD_REDEMPTION__BRN_CODE").value;
	screenArgs['ACC']        = document.getElementById("BLK_TD_REDEMPTION__AC_NO").value;//17187519_TD Changes. Uncommented this line
	screenArgs['CCY']        = document.getElementById("BLK_TD_REDEMPTION__CCY").value;
	screenArgs['CUSTNO']     = document.getElementById("BLK_TD_REDEMPTION__CUST_ID").value;
	//screenArgs['ACCLS']      = document.getElementById("BLK_TD_REDEMPTION__ACCLS").value;
	//screenArgs['MATDT']      = document.getElementById("BLK_TDDETAILS__MATDT").value;
	screenArgs['REQ']        = fcjResponseDOM;
	var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
	    var tableObject;
	    var rowList;
		var ddcnt = 0;
		var bccnt = 0;
		var instrtype = "";
	    try
	    {
	        tableObject = document.getElementById(meblkName);
		    rowList = tableObject.tBodies[0].rows.length;
	    } catch(e)
	    {}
		
		for (var rowIndex = 0; rowIndex < rowList; rowIndex++)
	        {
			if (document.getElementsByName("PAYOUTTYPE")[rowIndex].value == 'D')
			{
			ddcnt = ddcnt+1;
			}
			else if (document.getElementsByName("PAYOUTTYPE")[rowIndex].value == 'B')
			{
			bccnt = bccnt+1;
			}
			}
		
			if (ddcnt >= 1 & bccnt >= 1)
			{
			  
			  showErrorAlerts('BRN-VAL-001');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			  
			  
			  //alert('In multi mode term deposit payout,a combination of Bankers Cheque and Demand Draft cannot be choosen');
	          return false;		  
			}
			else if (ddcnt > 1)
			{
			
			showErrorAlerts('BRN-VAL-002');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			//alert('In multi mode term deposit payout,type Demand Draft Cannot be choosen more than once');
			return false;
			}
		   else if (bccnt > 1)
			{
			
			showErrorAlerts('BRN-VAL-003');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			
			//alert('In multi mode term deposit payout,type Bankers Cheque Cannot be choosen more than once');
			return false;
			}
			else if (ddcnt == 1)
			{
			    instrtype = 'DDA';
			}
			else if (bccnt == 1)
			{
			    instrtype = 'BCA';
			}
			
			screenArgs['INSTRTYPE']  = instrtype;
		

    return true;
}

function fnShowDefultValues() {
	
     var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
	 var tableObject;
	 var rowList;
	var cashflg;
	var denomAmt = 0.0;
   
    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

	  fnComputeAmount();

	 if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {  			
			cashflg = rowList[rowIndex].cells[1].getElementsByTagName("SELECT")[0].value;
			if (cashflg == 'C')
			{
			 denomAmt = getCalcAmount(rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value);
			}            

		   }		
		}  

	 document.getElementById("BLK_TD_REDEMPTION__DENOMAMT").value =  denomAmt;
	// document.getElementById("BLK_TDDETAILS__DENOMAMT").value =  denomAmt;
	 return true;
}

function fnComputeAmount(){
	var matinst = document.getElementById("BLK_TD_REDEMPTION__DEF_MATR_INST").value;
	var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
    var tableObject;
    var rowList;
    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

    var totalcompamt=0;       
    var rowamount = 0;
	var compamt = 0;
	var percentage;
	var totalPercentage = 0.00;
	var tdamt = document.getElementById("BLK_TD_REDEMPTION__REDEMPTION_AMT").value;

    if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {
			if (rowIndex == (rowList.length-1))
			{
				percentage = 100.00 -  floatingPointMultiplication(totalPercentage,1);
				compamt =   floatingPointMultiplication(tdamt,1) - floatingPointMultiplication(totalcompamt,1);  
				totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(compamt,1);
			}
		   else {
          
		    percentage = rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value;
			rowamount = rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value;
		   if((rowamount != "" || rowamount != null) && 	(percentage == "" || percentage == null))
			   {
				 totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(rowamount,1);
				 compamt = 	rowamount;
				 totalPercentage = floatingPointMultiplication(totalPercentage,1)  + floatingPointMultiplication(percentage,1) ;
			   }
           	else{
            totalPercentage = floatingPointMultiplication(totalPercentage,1) +  floatingPointMultiplication(percentage,1) ;
			compamt = (floatingPointMultiplication(percentage,tdamt))/ 100.00;
           	totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(compamt,1);
		   }

		}
		if (isNaN(parseInt(compamt))) {
		  compamt = "";
        }
		rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value = compamt;
		} 	

	} 
	document.getElementById("BLK_TD_REDEMPTION__DEF_MATR_INST").value = matinst; 
return true;	
}

function fncompute()
{
    tempaction = dataObj.action;  
	var matinst = document.getElementById("BLK_TD_REDEMPTION__DEF_MATR_INST").checked; //9NT1501 ITR1 sfr 13960491
 dataObj.action = 'ENRICH';	
 fnResetRedemAmt(); //9NT1587_1203_INTERNAL_18912683 added
    appendData();
    dataObj.action = 'COMPUTE';
    fcjRequestDOM = buildUBSXml();
    addBranchParam(fcjRequestDOM);
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=compute&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
    if (fcjResponseDOM && getXMLString(fcjResponseDOM).length > 0) 
    {
	    enableForm();
        dataObj = new dataObject(getXMLString(fcjResponseDOM));
        var returnValue = fnHandleError();
    } else {
	     enableForm();
        alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
        return;
    }
	dataObj.action = tempaction;
	enableForm();
	//9NT1501 ITR1 sfr 13960491
	if (matinst) {
	document.getElementById("BLK_TD_REDEMPTION__DEF_MATR_INST").checked = true; 
	}
	fnDisableElement(document.getElementById('BLK_TD_REDEMPTION__DEF_MATR_INST'));
	document.getElementById("BLK_TD_REDEMPTION__BTN_COMPUTE").focus();
	//return true; 
    //var returnVal = displayResponse(messageNode);	
return true;
}	
//achelal changes starts
function fnAccCCy(e)
{
	if (document.getElementById("BLK_TD_REDEMPTION__AC_NO").value != "") {
		fnDisableElement(document.getElementsByName("CCY")[0]);
	}
 return true;
}
function fnChangeRedemMode(event)
{
if(document.getElementsByName("REDEMPTION_MODE")[0].value == 'N')
{
document.getElementsByName("REDEMPTION_AMTI")[0].value = document.getElementsByName("ACCOUNT_BALANCE")[0].value;
document.getElementsByName("REDEMPTION_AMTI")[0].value = document.getElementsByName("ACCOUNT_BALANCE")[0].value;
fnDisableElement(document.getElementsByName("REDEMPTION_AMT")[0]);
document.getElementsByName("REDEMPTION_AMTI")[0].focus();
}
else
{
document.getElementsByName("REDEMPTION_AMTI")[0].value = "";
document.getElementsByName("REDEMPTION_AMTI")[0].value = "";
fnEnableElement(document.getElementsByName("REDEMPTION_AMT")[0]);
document.getElementsByName("REDEMPTION_AMTI")[0].focus();
}
 return true;
}
function fndefault()
{
if(document.getElementById('BLK_TD_REDEMPTION__DEF_MATR_INST').checked=true)
{
    tempaction = dataObj.action;  
 dataObj.action = 'ENRICH';	
    appendData();
    dataObj.action = 'DEFAULT_PAYOUT';
    fcjRequestDOM = buildUBSXml();
    addBranchParam(fcjRequestDOM);
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=default&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
    if (fcjResponseDOM && getXMLString(fcjResponseDOM).length > 0) 
    {
	    enableForm();
        dataObj = new dataObject(getXMLString(fcjResponseDOM));
        var returnValue = fnHandleError();
    } else {
	     enableForm();
        alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
        return;
    }
	dataObj.action = tempaction;
	enableForm();
	document.getElementById('BLK_TD_REDEMPTION__DEF_MATR_INST').checked=true;
	fnDisableElement(document.getElementById('BLK_TD_REDEMPTION__DEF_MATR_INST'));
	document.getElementById('BLK_TD_REDEMPTION__WAIVE_INTEREST').focus();
	}
return true;
}	
//achelal changes ends


//12.0.2 TD Enhancement-Denominated Deposit <Satrt>
var result_flag = "";
//17059489_12.0.2 TD Change <Start>
function fnPostNew_KERNEL(e) {
    document.getElementsByName("cmdAddRow_" + 'BLK_DENOM_DEPOSIT')[0].style.display = "none";
    document.getElementsByName("cmdDelRow_" + 'BLK_DENOM_DEPOSIT')[0].style.display = "none";
    return true;
}

function fnSelectAllCertif(event) {
    
    if (!document.getElementsByName("SELECT_ALL")[0].checked) {
        //17153583_12.0.2 TD Changes <Start>		
        for (i = 1;i <= selectNodes(dbDataDOM, "//BLK_DENOM_DEPOSIT").length;i++)
            setNodeText(selectSingleNode(dbDataDOM, "//BLK_DENOM_DEPOSIT[@ID=" + i + "]/BLOCK_OR_REDEM"), 'N');
        //17153583_12.0.2 TD Changes <End>
        var totalRows = document.getElementById('BLK_DENOM_DEPOSIT').tBodies[0].rows.length;
        for (var i = 0;i < totalRows;i++)
            document.getElementsByName("BLOCK_OR_REDEM")[i].checked = false;
    }
    else {
        //17153583_12.0.2 TD Changes <Start>
        for (i = 1;i <= selectNodes(dbDataDOM, "//BLK_DENOM_DEPOSIT").length;i++)
            setNodeText(selectSingleNode(dbDataDOM, "//BLK_DENOM_DEPOSIT[@ID=" + i + "]/BLOCK_OR_REDEM"), 'R');
        //17153583_12.0.2 TD Changes <End>
        var totalRows = document.getElementById('BLK_DENOM_DEPOSIT').tBodies[0].rows.length;
        for (var i = 0;i < totalRows;i++)
            document.getElementsByName("BLOCK_OR_REDEM")[i].checked = true;
    }
    return true;
}
//17153583_12.0.2 TD Changes <Start>
function fnUnSelectAllCertif(event) {
    
    var rowindex = getRowIndex(event);
    if (!document.getElementsByName("BLOCK_OR_REDEM")[rowindex - 1].checked)
        document.getElementsByName("SELECT_ALL")[0].checked = false;
    return true;
}
//17153583_12.0.2 TD Changes <End>

function fnPopulateRedmnAmt(event) {
    //alert('test fnPopulateRedmnAmt');
    fnHitBackend('DENOMTOTAL');
    if (result_flag == "true")
        return true;
    if (result_flag == "false")
        return true;
}

function fnHitBackend(action) {
    if (action == "" || action == 'undefine')
        return;
    appendData();
    result_flag = "";
    var prevAction = dataObj.action;
    dataObj.action = action;
    fcjRequestDOM = buildUBSXml();
    addBranchParam(fcjRequestDOM);
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);

    if (fcjResponseDOM && getXMLString(fcjResponseDOM).length > 0) {
        dataObj = new dataObject(getXMLString(fcjResponseDOM));
        var returnValue = fnHandleError();
        if (returnValue == "SUCCESS")
            result_flag = "true";
    }
    else {
        alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
        fnEnableElement(document.getElementsByName("BTN_FETCH")[0]);
        fnEnableElement(document.getElementsByName("ACC")[0]);
        result_flag = "false";
        return false;
    }
    dataObj.action = prevAction;
    result_flag = "true";
    return true;
}
//12.0.2 TD Enhancement-Denominated Deposit <End>

//17184023_12.0.2 TD Changes <Start>
function fnPostReturnValToParent_LOV_AC_NO_KERNEL(){
    appendData();
    var g_prev_gAction = gAction;
    var g_prev_dataObjAction = dataObj.action;//17247445_12.0.2 TD Changes
    dataObj.action = "POPDENOM";
    var l_processMsg = showProcessMsg;
    showProcessMsg = false;
    fcjRequestDOM = buildBrnUBSXml();//buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    var orgDom = loadXMLDoc(getXMLString(dbDataDOM));
    if (!fnProcessResponse()) {
        //if (!fnProcessBrnResponse()) {
        gAction = g_prev_gAction;
        dataObj.action = g_prev_dataObjAction;//17247445_12.0.2 TD Changes
        dbDataDOM = loadXMLDoc(getXMLString(orgDom));
        return false;
    }
    showProcessMsg = l_processMsg;
    gAction = g_prev_gAction;
    dataObj.action = g_prev_dataObjAction;//17247445_12.0.2 TD Changes
    return true;
}
//17184023_12.0.2 TD Changes <End>
