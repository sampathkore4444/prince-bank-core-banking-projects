/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2014  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
           : Suhas Rekhu
Changed  On            : 04-March-2012
Modified Reason        : 9NT1501 usability changes
Search String          : 9NT1501 usability changes

Changed  By            : Gokulnath M
Changed  On            : 15-March-2012
Modified Reason        : 9NT1501 PRE-ITR SFR#72
Search String          : 9NT1501 PRE-ITR SFR#72

Last Modified By   :  Prabhakaran J
Last modified on   : 10-May-2012
Full Version       : FCUBS 12.0.0
Reason             : Focus changed to txn amount on exchange rate calculation
Search String : 9NT1501 ITR2 sfr 14005445

Last Modified By   :  Reddy Prasad
Last modified on   : 19-July-2013
Full Version       : FCUBS 12.0.2
Reason             : Exchange rate calculation
Search String      : FCUBS.12.0.2_ITR1_17065793

Last Modified By   :  Reddy Prasad
Last modified on   : 01-Aug-2013
Full Version       : FCUBS 12.0.2
Reason             : ON ENTERING TO ACCOUNT NUMBER SYSTEM FLICKERS 
Search String      : FCUBS.12.0.2_ITR1_17239135

	Last Modified By   :  Sanath
**  Last modified on   :  11-Jul-2013
**  Search String      :  FCUBS_12.0.1_RETRO_17420349
**  Reason             : The Branch code field should be previous sibling of Account number in the screen.

Last Modified By   : Ankit T
Last modified on   : 25-Aug-2014
Reason             : src.element was not working in Firefox.
Search String      : FCUBS_12.0.3_TUN_19489533

Last Modified By   :  Ankush Raizada
**  Last modified on   :  29-Oct-2014
**  Reason             : Fix has been provided to correct the value date
**  Search String      : 12.0.3_CREDIT_AGRICOLE_EGYPT_RETRO_19902643

----------------------------------------------------
------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
//9NT1501 usability changes STARTS
var hisC1='###';
var hisC2='$$$';
var hisAmount=0;
//9NT1501 usability changes	ENDS
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	fnDisableElement(document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY')); //9NT1620_1203_INTERNAL_18272320
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {
//9NT1501 usability changes starts
//document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value='Fund Transfer from <From Account Number > to <To Account Number>';
document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value='Fund Transfer from -From Account Number- to -To Account Number- '; //9NT1501 PRE-ITR SFR#72
document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value=g_txnBranch;
document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value=mainWin.Lcy;
document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value=mainWin.Lcy; 
document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETBRN").value=g_txnBranch;
//9NT1501 usability changes ends  
return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	//12.0.3_CREDIT_AGRICOLE_EGYPT_RETRO_19902643 starts
 if(document.getElementsByName('VALDATE')[0]) document.getElementsByName('VALDATE')[0].value = '';
 //12.0.3_CREDIT_AGRICOLE_EGYPT_RETRO_19902643 ends

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
// 1203_ITR1_18388624 starts 
	try
  {
	if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != document.getElementById("BLK_TRANSACTION_DETAILS__VIRACCNO").value){
		gViraccno = true;		
     }
  else {
  			gViraccno = false;
	   }
  }
catch (e)
{
}
// 1203_ITR1_18388624 ends 
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
//12.0.3_CREDIT_AGRICOLE_EGYPT_RETRO_19902643 starts
 if(document.getElementsByName('VALDATE')[0]) document.getElementsByName('VALDATE')[0].value = '';
 //12.0.3_CREDIT_AGRICOLE_EGYPT_RETRO_19902643 ends
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}//FCUBS.12.0.2_ITR1_17065793 <start>
function fnPostProcessFields_KERNEL (){    
    dataObj.stepNo = dataObj.stepNo + 1;	
}//FCUBS.12.0.2_ITR1_17065793 <end>

//9NT1501 usability changes  starts
function fnTxnAcc(event) {
	//FCUBS.12.0.2_ITR1_17239135 Starts
	/*try {disp_auto_lov('1006','BLK_TRANSACTION_DETAILS','TXNACC','From Account Number','LOV_AC_NO','','','', event);} catch(e) {}*/
	//FCUBS.12.0.2_ITR1_17239135 Ends
	if (!isAutoLOVOpened) {
		document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getEventSourceElement(event).value;
	}
fnAccCcy(event);
//fnComputeXrate(event) --FCUBS.12.0.2_ITR1_17065793
	return true;
}

function fnOffsetAcc(event) {
	// FCUBS.12.0.2_ITR1_17239135 Starts
	/*try {disp_auto_lov('1006','BLK_TRANSACTION_DETAILS','OFFSETACC','To Account Number','LOV_AC_NO','','','', event);} catch(e) {}*/
	// FCUBS.12.0.2_ITR1_17239135 Ends
	if (!isAutoLOVOpened) {
		document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value = getEventSourceElement(event).value;
	}
fnOffsetAccCcy(event);
//fnComputeXrate(event) --FCUBS.12.0.2_ITR1_17065793
	return ;
}


function fnAccCcy(event) {
	if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != "") {
		//document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Fund Transfer from ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' to ' + document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value+'';
		document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Fund Transfer from - ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' - to - ' + document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value+''; //9NT1501 PRE-ITR SFR#72
	}
	return true;
}
function fnOffsetAccCcy(event) {
	//if (document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value != "") { //12.0.3_18542322 
	if (document.getElementById("BLK_TRANSACTION_DETAILS__VIRACCNO").value != "") { //12.0.3_18542322 
		//document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Fund Transfer from ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' to ' + document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value+'';
	/*	document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Fund Transfer from - ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' - to - ' + document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value+''; //9NT1501 PRE-ITR SFR#72  *///12.0.3_18542322 
		document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Fund Transfer from - ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' - to - ' + document.getElementById("BLK_TRANSACTION_DETAILS__VIRACCNO").value+''; //12.0.3_18542322 
	}
	return true;
}


function fnComputeXrate(event){
if (hisC1!=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value || hisC2!=document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value || hisAmount!=document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").value) {
if (document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value !="" && document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value !="" && document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").value != "")
 {

if(document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value==document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value) {
	document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMTI").value;
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").focus();
}
else
    {
	document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=0;
	var tempAction = dataObj.action;
	appendData();
	dataObj.action = 'CALCEXCHAMT';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	local_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
		try {	
		if(local_fcjResponseDOM) {		
		var msgStatus   =getNodeText( selectSingleNode(local_fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') {
		showErrorAlerts('CL-COMM-04')	;
		self.close();
		}
		else{
		document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=getNodeText(selectSingleNode(fnGetDataXMLFromFCJXML(local_fcjResponseDOM, 1), "//BLK_TRANSACTION_DETAILS/OFFSETAMT"));	
	    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").focus();
		}
		}
	}catch(e){
	showErrorAlerts('GW-REOPR-01')	;
	}

	dataObj.action	= tempAction;


	}
	document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMTI").focus();	 //9NT1501 ITR2 sfr 14005445
	hisC1=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	hisC2=document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value;
	hisAmount=document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").value;
 }
 }
	return true;
}
//9NT1501 usability changes  ends

//FCUBS_12.0.1_RETRO_17420349 starts
function fnSetHotKeyBranch_KERNEL() {
	
	//if(window.event.srcElement.name =="TXNACC"){ //FCUBS_12.0.3_TUN_19489533
	if(window.getEventSourceElement(event).name =="TXNACC"){//FCUBS_12.0.3_TUN_19489533
	hotKeyBrn = document.getElementsByName('TXNBRN')[0].value;
	}
	//if(window.event.srcElement.name =="OFFSETACC"){//FCUBS_12.0.3_TUN_19489533
	if(window.getEventSourceElement(event).name =="OFFSETACC"){//FCUBS_12.0.3_TUN_19489533
	hotKeyBrn = document.getElementsByName('OFFSETBRN')[0].value;
	}
    return true;
}
//FCUBS_12.0.1_RETRO_17420349 ends

//FCUBS_12 0 3_WB_Virtual Accounts starts

function fnPreProcessFields_KERNEL(e){
        appendData();
    if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) == 'V')
        fnEnableElement(document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY'));
    else 
        fnDisableElement(document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY'));
return true;
}

function fnResolveVirAcc(event) {
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
    //if (event.srcElement.name == 'VIRACCNO' || event.srcElement.name == 'OFFSETCCY') {//FCUBS_12.0.3_TUN_19489533
	if (getEventSourceElement(event).name == 'VIRACCNO' || getEventSourceElement(event).name == 'OFFSETCCY') {//FCUBS_12.0.3_TUN_19489533
        appendData();
        
        //if (document.getElementById(event.srcElement.id)!= undefined && document.getElementById(event.srcElement.id).oldvalue != document.getElementById(event.srcElement.id).value) {//FCUBS_12.0.3_TUN_19489533
		if (document.getElementById(getEventSourceElement(event).id)!= undefined && document.getElementById(getEventSourceElement(event).id).oldvalue != document.getElementById(getEventSourceElement(event).id).value) {//FCUBS_12.0.3_TUN_19489533
        //if(event.srcElement.name == 'VIRACCNO'  && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) != 'V')//FCUBS_12.0.3_TUN_19489533
		if(getEventSourceElement(event).name == 'VIRACCNO'  && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) != 'V')//FCUBS_12.0.3_TUN_19489533
		// 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			//document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value = document.getElementById(event.srcElement.id).value;//FCUBS_12.0.3_TUN_19489533
			 document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value = document.getElementById(getEventSourceElement(event).id).value;//FCUBS_12.0.3_TUN_19489533
		}	// 1203_ITR1_18388624
 
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/VIRACCNO")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) == 'V') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    tempDOM = fnGetDataXMLFromFCJXML(tempDOM, 1);// Ankit added
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                                            
                            var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            
                            if (msgStatus == 'FAILURE') {
                              dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                        temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
   }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) == 'V')
        fnEnableElement(document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY'));
    else 
        fnDisableElement(document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY'));
        
    }    
    return true;
}
//FCUBS_12 0 3_WB_Virtual Accounts  ends
