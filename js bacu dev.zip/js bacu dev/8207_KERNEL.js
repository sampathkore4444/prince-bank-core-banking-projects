/*------------------------------------------------------------------------------------------
** File Name    : 8207_KERNEL.js
**
** Module       : RT
** 
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2014  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
** Modified By  	   : Ankit T
** Modified On   	   : 25-Aug-2014
** Modified Reason     : src.element was not working in Firefox.
** Search String       : FCUBS_12.0.3_TUN_19489533

	Modified By      : Teja
    Modified On      : 10-Sep-2014  
    Modified Reason  : Currency Becoming Null when Launched From Queues
    Search String    : 9NT1620_1203_TPB_19577679
-----------------------------------------------------------------------------------------
*/

//12.0.3_Single_Step_process starts
function fnPreNew_KERNEL() {
	return true;
}
function fnPostNew_KERNEL() {
    debugs("In fnPostNew", "A");
	//9NT1620_1203_TPB_19577679 Added Starts
	 try{
    tempDOM =  fnGetDataXMLFromFCJXML(dataDOM, 1);
   document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value =  getNodeText(selectSingleNode(tempDOM,"//BLK_TRANSACTION_DETAILS/TXNCCY"));
   }
   catch (e){
       }
    fnDenmBasedTrack();
	
	//9NT1620_1203_TPB_19577679 Added ENds
    return true;

}
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
// 1203_ITR1_18388624 starts 
function fnPreSave_KERNEL() {
try
  {
  if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != document.getElementById("BLK_TRANSACTION_DETAILS__VIRACCNO").value){
			gViraccno = true;		
     }
  else {
  			gViraccno = false;
	   }
  }
catch (e)
{
}
return true ;
}
// 1203_ITR1_18388624 ends

//PNTFLX01006_FCUBS_12.0.3_Denom_Wise_Variance <Start>
var exchRateBasedOnDenomList;
var exchRateBasedOnDenom;
var denmBasedTrackReqd;

function fnDenmBasedTrack() {
    exchRateBasedOnDenomList = mainWin.denomBasedTracking;
    exchRateBasedOnDenom = exchRateBasedOnDenomList.split(',');
    denmBasedTrackReqd = false;
    for (i = 0;i < exchRateBasedOnDenom.length;i++) {
        if (functionId == exchRateBasedOnDenom[i]){
            denmBasedTrackReqd = true;        
            document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = true;
            }
        }
}

function fnDenomVarianceCheckbox(){
if (denmBasedTrackReqd == false && document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked == true) {
        mask();
        showBranchAlerts(fnBuildAlertXML('WF-2196', 'E'), 'E');
        alertAction = "UNMASK";
        document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = false;
        return false;
    }
//    document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = false;
  return true ; //12.0.3_18471955
}
//PNTFLX01006_FCUBS_12.0.3_Denom_Wise_Variance <End>

function fnPostLoad_KERNEL(e) {
        debugs("In fnPostload", "A");
        //9NT1620_1203_TPB_19577679 Commentin Starts
      //  document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value='';
        //fnDenmBasedTrack() ;	
		//9NT1620_1203_TPB_19577679 Commentin Ends
	    return true;
}
//12.0.3_Single_Step_process ends
//9NT1620_1203_INTERNAL_18272320  starts
function fnPreProcessFields_KERNEL(e){

        appendData();
return true;
}


function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
    //if (event.srcElement.name == 'VIRACCNO' || event.srcElement.name == 'OFFSETCCY') {//FCUBS_12.0.3_TUN_19489533
	if (getEventSourceElement(event).name == 'VIRACCNO' || getEventSourceElement(event).name == 'OFFSETCCY') {//FCUBS_12.0.3_TUN_19489533
        appendData();
        //if (document.getElementById(event.srcElement.id)!= undefined && document.getElementById(event.srcElement.id).oldvalue != document.getElementById(event.srcElement.id).value) {//FCUBS_12.0.3_TUN_19489533
		if (document.getElementById(getEventSourceElement(event).id)!= undefined && document.getElementById(getEventSourceElement(event).id).oldvalue != document.getElementById(getEventSourceElement(event).id).value) {//FCUBS_12.0.3_TUN_19489533
        //if(event.srcElement.name == 'VIRACCNO'  && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) != 'V')//FCUBS_12.0.3_TUN_19489533
		if(getEventSourceElement(event).name == 'VIRACCNO'  && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) != 'V')//FCUBS_12.0.3_TUN_19489533		
		// 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			//document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(event.srcElement.id).value;//FCUBS_12.0.3_TUN_19489533
			document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(getEventSourceElement(event).id).value;//FCUBS_12.0.3_TUN_19489533
		}	// 1203_ITR1_18388624
             if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/VIRACCNO")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) == 'V') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    tempDOM = fnGetDataXMLFromFCJXML(tempDOM, 1);
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                      
                            var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            
                            if (msgStatus == 'FAILURE') {
                             dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                        temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     
                    }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                   dataObj.stepNo = dataObj.stepNo + 1;
                   dataObj.action = tempAction;

                }
            }
        }
    }
    }
    return true;
}
//9NT1620_1203_INTERNAL_18272320  ends


//9NT1620_1203_INTERNAL_18325754 starts 
function fxDenomInputValidation() {

	var cashAmt = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMT").value;
	var exchRateBasedOnDenomList = mainWin.denomBasedTracking;
	var exchRateBasedOnDenom = exchRateBasedOnDenomList.split(',');
	for (i = 0; i < exchRateBasedOnDenom.length; i++) {
	if (functionId == exchRateBasedOnDenom[i]) {
		if (Number(cashAmt) != Number(gCashNumNewFlow) && document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked == true) {
			mask();
			showBranchAlerts(fnBuildAlertXML('WF-2194', 'E'), 'E');
			alertAction = "UNMASK";
			return false;
		}
	  }
    }
    fnRecalc();
    return true;
}
function fnPreLoad_CVS_DMCD_KERNEL() {

    if (document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked) {
        if (!fnValidate())
            return false;
        if (selectNodes(dbDataDOM, "//" + gDenomBlockName).length == 0)
            fnPopulateDenom();
    }
    try {
        if (document.getElementById(mainWin.functionDef[functionId].ofsAmtField)) {
            if (document.getElementById(mainWin.functionDef[functionId].ofsAmtField).value == "") {
                var dispAmt = 0.00;
                document.getElementById(mainWin.functionDef[functionId].ofsAmtField).value = dispAmt;
                var mb3Amount = new MB3Amount(dispAmt, true, document.getElementById(mainWin.functionDef[functionId].ofsCcyField).value);
                document.getElementById(mainWin.functionDef[functionId].ofsAmtField + "I").value = mb3Amount.getDisplayAmount();
            }
        }
    }
    catch (e) {
    }
    return true;
}


//9NT1620_1203_INTERNAL_18325754 ends