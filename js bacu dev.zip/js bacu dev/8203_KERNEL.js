/*----------------------------------------------------------------------------------------------------
**
** File Name    : 8203_KERNEL.js
**
** Module       : FCJWeb
**
** This source is part of the FLEXCUBE Corporate - Corporate Banking
** Software System and is copyrighted by Oracle Financial Services Software Limited.

** All rights reserved.  No part of this work may be reproduced,
** stored in a retrieval system, adopted or transmitted in any form
** or by any means, electronic, mechanical, photographic, graphic,
** optic recording or otherwise, translated in any language or
** computer language, without the prior written permission  from Oracle Financial Services Software Limited.

** Oracle Financial Services Software Limited.,
** 10-11, SDF I, SEEPZ, Andheri (East),
** MUMBAI - 400 096.
** INDIA.

Copyright � 2004- 2014 by Oracle Financial Services Software Limited.
----------------------------------------------------------------------------------------------------
** Modified By         : Shayam Sundar Ragunathan
** Modified On         : 21-Feb-2017
** Modified Reason     : 8203 denom varience coming checked on launch from wf even though unchecked doing txn
** Search String       : 9NT1606_12_3_RETRO_12_0_3_25399895

** Modified By         : Shayam Sundar Ragunathan
** Modified On         : 21-Feb-2017
** Modified Reason     : FX SALE IS NOT VALIDATING THE DENOMINATION TOTAL AGAINST WITH CASH AMOUNT 
** Search String       : 9NT1606_12_3_RETRO_12_1_25436210 
*/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	//document.getElementById("BLK_TRANSACTION_DETAILS__BRN").value = mainWin.CurrentBranch;
	//appendData(document.getElementById('TBLPage' + strCurrentTabID));
	document.getElementsByName('BRN')[0].value = mainWin.CurrentBranch;
	appendData(document.getElementById("TBLPage"+strCurrentTabId));
        //fnDenmBasedTrack() ; //9NT1620_1203_INTERNAL_18325754 //9NT1606_12_3_RETRO_12_0_3_25399895 commented
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    fnDenmBasedTrack() ;//9NT1606_12_3_RETRO_12_0_3_25399895
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	debugs("In fnPreSave", "A");	
	var isValid = true;
	document.getElementsByName('BRN')[0].value= mainWin.CurrentBranch;
	appendData(document.getElementById("TBLPage"+strCurrentTabId));
/*	if(!fnValidate())
        return false;

	debugs("In fnPreSave", "A");	*/
	//9NT1606_12_3_RETRO_12_1_25436210 starts
	if(getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/DENOM_VARIANCE")) == 'Y'){
		if (Number(getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACTAMT")))>0)
	 {	
	 isValid=true;
	 }
	 else{
		 isValid=false;
		  showBranchAlerts(fnBuildAlertXML('WF-2191', 'E'), 'E');
	 }
	
}
//9NT1606_12_3_RETRO_12_1_25436210 ends
	return isValid;	
	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}



function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}



function fnPreAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_MIS_KERNEL() {
    return true;
}
function fnInTab_TAB_MIS_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_MIS_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}


function fnPreAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_UDF_KERNEL() {
    return true;
}
function fnInTab_TAB_UDF_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_UDF_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}



function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnInTab_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL() {
    return true;
}
//PNTFLX01006_FCUBS_12.0.3_Denom_Wise_Variance <Start>
var exchRateBasedOnDenomList;
var exchRateBasedOnDenom;
var denmBasedTrackReqd;

function fnDenmBasedTrack() {

    exchRateBasedOnDenomList = mainWin.denomBasedTracking;
    exchRateBasedOnDenom = exchRateBasedOnDenomList.split(',');
    denmBasedTrackReqd = false;
    for (i = 0;i < exchRateBasedOnDenom.length;i++) {
        if (functionId == exchRateBasedOnDenom[i]){
            denmBasedTrackReqd = true;        
            document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = true;
            }
        }
}

function fnDenomVarianceCheckbox(){

if (denmBasedTrackReqd == false && document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked == true) {
        mask();
        showBranchAlerts(fnBuildAlertXML('WF-2196', 'E'), 'E');
        alertAction = "UNMASK";
        document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = false;
        return false;
    }
  //  document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked = false; //12.0.3_18471955
  return true ; //12.0.3_18471955
}
//PNTFLX01006_FCUBS_12.0.3_Denom_Wise_Variance <End>

//9NT1620_1203_INTERNAL_18325754 STARTS
function fnPreLoad_CVS_DMCF_KERNEL() {
    
    if (document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked) {
        if (!fnValidate())
            return false;
        if (selectNodes(dbDataDOM, "//" + gFXDenomBlockName).length == 0)
            fnPopulateDenom();
    }
    try {
        if (document.getElementById(mainWin.functionDef[functionId].ofsAmtField)) {
            if (document.getElementById(mainWin.functionDef[functionId].ofsAmtField).value == "") {
                var dispAmt = 0.00;
                document.getElementById(mainWin.functionDef[functionId].ofsAmtField).value = dispAmt;
                var mb3Amount = new MB3Amount(dispAmt, true, document.getElementById(mainWin.functionDef[functionId].ofsCcyField).value);
                document.getElementById(mainWin.functionDef[functionId].ofsAmtField + "I").value = mb3Amount.getDisplayAmount();
            }
        }
    }
    catch (e) {
    }
    return true;
}

function fxDenomInputValidation() {
    var valFailed = false;
    var totalAmt = document.getElementById(mainWin.functionDef[functionId].txnAmtField).value;
    var cashAmt = null;
    if (selectSingleNode(dbDataDOM, "//" + gFXDenomSEBlockName + '/CASHAMT'))
        cashAmt = getNodeText(selectSingleNode(dbDataDOM, "//" + gFXDenomSEBlockName + '/CASHAMT'));
    else 
        cashAmt = 0.00;
    var exchRateBasedOnDenomList = mainWin.denomBasedTracking;
    var exchRateBasedOnDenom = exchRateBasedOnDenomList.split(',');
    for (i = 0;i < exchRateBasedOnDenom.length;i++) {
        if (functionId == exchRateBasedOnDenom[i]) {
            if (Number(cashAmt) != Number(totalAmt) && document.getElementById("BLK_TRANSACTION_DETAILS__DENOM_VARIANCE").checked == true) {
                mask();
                showBranchAlerts(fnBuildAlertXML('WF-2194', 'E'), 'E');
                alertAction = "UNMASK";
                valFailed = true;
            }
        }
    }

    if (valFailed)
        return false;
    fnRecalc();
    return true;

}
//9NT1620_1203_INTERNAL_18325754 ENDS
//12.0.3_18525406 starts
function fnPickupReqdFIDspecific(e) {
    var srcElement = getEventSourceElement(event);
    if (srcElement.id == 'BLK_TRANSACTION_DETAILS__TXNCCY' || srcElement.id == 'BLK_TRANSACTION_DETAILS__OFFSETCCY') {
        if (document.getElementsByName("TXNACC").length > 0) {
            document.getElementsByName("TXNACC")[0].value = "";
            fireHTMLEvent(document.getElementsByName("TXNACC")[0], "onpropertychange");
        }
        if (document.getElementsByName("OFFSETACC").length > 0) {
            document.getElementsByName("OFFSETACC")[0].value = "";
            fireHTMLEvent(document.getElementsByName("OFFSETACC")[0], "onpropertychange");
        }
    }
    return true;
}
//12.0.3_18525406 ends

