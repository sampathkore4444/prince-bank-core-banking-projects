/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright �  vercon_start_year - vercon_end_year  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6560_Q_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
** Last Modified By   :  Ediga GANGADHAR
**  Last modified on   :  24-APRIL-2013
**  Reason             :  Capture the additionl information Drawee a/c no and Cheque number into Remarks
**  Search String      :   9NT1587_16712454_Narrative

** Last Modified By   :  Sneha Sindhia
**  Last modified on   :  16-AUG-2013
**  Reason             :  Transaction Limit Validation to be skipped for 6560 screen
**  Search String      :   9NT1587_17302963

Changed By			: Sindhu Ramakrishna
Changed on			: 29-May-2015
Change Description	: FCUBS-12.1 Customer Landing Changes
Search String		: 12.1_Customer_Landing_Changes
****************************************************************************************************************************/

//9NT1587_17302963 starts
function fnPreSave() {
try{
document.getElementById('BLK_CLEARING_REJECT_DETAILS__INSTRAMT') = null;
}catch(e){}
}
//9NT1587_17302963 ends
// 9NT1587_16712454_Narrative starts
function fnRemarksDefault(event) {
var index=getRowIndex(event)-1;
if (dataObj.action != "REMOTEAUTH") {
var narr_def =  document.getElementById("BLK_CLEARING_REJECT_DETAILS__REMARKS").getAttribute('DEFAULT');
	var chq_num = document.getElementById("BLK_CLEARING_REJECT_DETAILS__INSTRNO").value;
	var rej_rsn = document.getElementById("BLK_CLEARING_REJECT_DETAILS__REJECTREASON").value;
	var narr_val = "";
	narr_split = narr_def.split('-');
	if(chq_num == "") chq_num =  ( narr_split[1] );
	if(rej_rsn == "") rej_rsn =  (narr_split[2]);
	narr_val = narr_split[0] +"-" +chq_num +"-"+rej_rsn;
	 document.getElementById("BLK_CLEARING_REJECT_DETAILS__REMARKS").value = narr_val;
	}
	return true;
}
//9NT1587_16712454_Narrative ends

//12.1_Customer_Landing_Changes starts
function fnPostLoad_KERNEL() {
try{
	 if((typeof(mainWin.gCustInfo["AccntNo"])!= 'undefined' && mainWin.gCustInfo["AccntNo"]!='' && mainWin.gCustInfo["FunctionId"]=='STDCUDEM') )
	{
	document.getElementById("BLK_CLEARING_REJECT_DETAILS__REMACCOUNT").value = mainWin.gCustInfo["AccntNo"];
	}
	}
	catch(e){}
	debugs("In fnPostLoad", "B");
	return true;
}
//12.1_Customer_Landing_Changes ends

