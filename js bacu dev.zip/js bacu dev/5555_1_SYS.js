/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2017, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 5555_1_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_BC_DD_MASTER":"XREF~CHAR_FIELD2~ENDPOINT1~ROWSTBA~TXNCCY~TOTAMT~CGTYPE~BRNCD~ACORGLNO~ROUTINGNO~UI_INSTRUMENT_TYPE~BATCHNO~ACCOUNTDESCRIPTION","BLK_BC_DD_DETAILS":"ENTRNUM~CLGTYP~TXNCCY~INSTRNUM~ISSBNK~INSTRAMT~INSTRTYP~ACGLNO~BRNCD~ROUTINGNO~INSTRSTAT~NARRATIVE~STATUS~DRAWEE_ACCOUNT~INSTRDT~PNEUMONICCODE~ENDPOINT~PROJECTNAME~UNITPAYMENT~UNITID~DEPOSITSLIPNO~BENROUTINGNO~UI_ACCTITLE~CHEQUE_ISSUE_DATE"};

var multipleEntryPageSize = {"BLK_BC_DD_DETAILS" :"15" };

var multipleEntrySVBlocks = "";

var tabMEBlks = {"CVS_MAIN__TAB_MAIN":"BLK_BC_DD_DETAILS"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_BC_DD_MASTER">XREF~CHAR_FIELD2~ENDPOINT1~ROWSTBA~TXNCCY~TOTAMT~CGTYPE~BRNCD~ACORGLNO~ROUTINGNO~UI_INSTRUMENT_TYPE~BATCHNO~ACCOUNTDESCRIPTION</FN>'; 
msgxml += '      <FN PARENT="BLK_BC_DD_MASTER" RELATION_TYPE="N" TYPE="BLK_BC_DD_DETAILS">ENTRNUM~CLGTYP~TXNCCY~INSTRNUM~ISSBNK~INSTRAMT~INSTRTYP~ACGLNO~BRNCD~ROUTINGNO~INSTRSTAT~NARRATIVE~STATUS~DRAWEE_ACCOUNT~INSTRDT~PNEUMONICCODE~ENDPOINT~PROJECTNAME~UNITPAYMENT~UNITID~DEPOSITSLIPNO~BENROUTINGNO~UI_ACCTITLE~CHEQUE_ISSUE_DATE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_BC_DD_MASTER" : "","BLK_BC_DD_DETAILS" : "BLK_BC_DD_MASTER~N"}; 

 var dataSrcLocationArray = new Array("BLK_BC_DD_MASTER","BLK_BC_DD_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 5555_1.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 5555_1.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_BC_DD_MASTER__XREF";
pkFields[0] = "BLK_BC_DD_MASTER__XREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_BC_DD_MASTER__ENDPOINT1__LOV_ENDPOINT":["BLK_BC_DD_MASTER__ENDPOINT1~~","","N~N",""],"BLK_BC_DD_MASTER__TXNCCY__LOV_TXNCCY":["BLK_BC_DD_MASTER__TXNCCY~~","","N~N",""],"BLK_BC_DD_MASTER__CGTYPE__LOV_CGTYPE":["BLK_BC_DD_MASTER__CGTYPE~~","","N~N",""],"BLK_BC_DD_MASTER__BRNCD__LOV_ISSBNK":["BLK_BC_DD_MASTER__BRNCD~~","","N~N",""],"BLK_BC_DD_MASTER__ACORGLNO__LOV_ACORGL":["BLK_BC_DD_MASTER__ACORGLNO~~BLK_BC_DD_MASTER__ACCOUNTDESCRIPTION~","BLK_BC_DD_MASTER__BRNCD!~BLK_BC_DD_MASTER__UI_INSTRUMENT_TYPE!~BLK_BC_DD_MASTER__UI_INSTRUMENT_TYPE!","N~N~N",""],"BLK_BC_DD_MASTER__ROUTINGNO__LOV_ROUTINGNO":["BLK_BC_DD_MASTER__ROUTINGNO~~~","","N~N~N",""],"BLK_BC_DD_DETAILS__CLGTYP__LOV_CGTYPE":["BLK_BC_DD_DETAILS__CLGTYP~BLK_BC_DD_DETAILS__UI_ACCTITLE~","","N~N",""],"BLK_BC_DD_DETAILS__TXNCCY__LOV_TXNCCY":["BLK_BC_DD_DETAILS__TXNCCY~~","","N~N",""],"BLK_BC_DD_DETAILS__INSTRNUM__LOV_INSTRNO":["BLK_BC_DD_DETAILS__INSTRNUM~~","BLK_BC_DD_DETAILS__INSTRTYP!VARCHAR2~BLK_BC_DD_DETAILS__ISSBNK!VARCHAR2~BLK_BC_DD_DETAILS__ACGLNO!VARCHAR2~BLK_BC_DD_DETAILS__INSTRTYP!VARCHAR2~BLK_BC_DD_DETAILS__ISSBNK!VARCHAR2","N~N",""],"BLK_BC_DD_DETAILS__ISSBNK__LOV_ISSBNK":["BLK_BC_DD_DETAILS__ISSBNK~~","","N~N",""],"BLK_BC_DD_DETAILS__ACGLNO__LOV_ACGLNO":["BLK_BC_DD_DETAILS__ACGLNO~~BLK_BC_DD_DETAILS__UI_ACCTITLE~","BLK_BC_DD_DETAILS__ISSBNK!~BLK_BC_DD_DETAILS__INSTRTYP!~BLK_BC_DD_DETAILS__INSTRTYP!","N~N~N",""],"BLK_BC_DD_DETAILS__ROUTINGNO__LOV_ROUTINGNO":["BLK_BC_DD_DETAILS__ROUTINGNO~~~","","N~N~N",""],"BLK_BC_DD_DETAILS__ENDPOINT__LOV_ENDPOINT":["BLK_BC_DD_DETAILS__ENDPOINT~~","","N~N",""],"BLK_BC_DD_DETAILS__PROJECTNAME__LOV_PROJECT_NAME":["BLK_BC_DD_DETAILS__PROJECTNAME~~","","N~N",""],"BLK_BC_DD_DETAILS__UNITID__LOV_UNITID":["BLK_BC_DD_DETAILS__UNITID~~","BLK_BC_DD_DETAILS__PROJECTNAME!VARCHAR2","N~N",""],"BLK_BC_DD_DETAILS__BENROUTINGNO__LOV_BEN_ROUTING_NO":["BLK_BC_DD_DETAILS__BENROUTINGNO~~~","","N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_BC_DD_DETAILS");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array(); 

 var CallFormRelat=new Array(); 

 var CallRelatType= new Array(); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["5555_1"]="KERNEL";
ArrPrntFunc["5555_1"]="5555_2";
ArrPrntOrigin["5555_1"]="KERNEL";
ArrRoutingType["5555_1"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["5555_1"]="N";
ArrCustomModified["5555_1"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {};
var scrArgSource = {};
var scrArgVals = {};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------