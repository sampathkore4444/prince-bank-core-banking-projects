/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2009  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
racle Financial Services Software Limited.
----------------------------------------------------------------------------------------------------
*/


/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */	
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */	 
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}     

function fnInTab_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_BLK_DENOMINATION_DETAILS_KERNEL(){
try {
		eval('fnShowDefultccy();');  
    }catch(e){
   } 
	return true;
}
function fnInTab_TAB_DENOM_KERNEL()  { 
	
	fnReversalInOut(); 
	return true;
}
