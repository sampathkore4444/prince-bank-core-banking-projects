/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2014 , Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software System and is copyrighted by 
**  Oracle Financial Services Software Limited.
**  
**  All rights reserved.  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle Financial Services Software Limited.
**  
**  Oracle Corporation
**  World Headquarters
**  500 Oracle Parkway
**  Redwood Shores, CA 94065
**  U.S.A.
**  
**  Copyright � 2011 - 2012 by Oracle Financial Services Software Limited.
**  Oracle Financial Services Software Limited.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6512_2_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
**
**Changed By         :  SwathyR
**Description         :  To disable add and delete row button in enrich stage
**Search String     :  FCUBS 11.3.1 - Usability Item VOL1 changes
**
**Changed By   :   Hamsa Shwetha V
**Changed On   :  25 July 2014
**Change Description :  Proper assignments made to paint values in enrich stage
**Search String  :   INTERNAL_19293382
****************************************************************************************************************************/
//FCUBS 11.3.1 - Usability Item VOL1 changes starts
function fnPostLoad_KERNEL() {
	// No more [+,-] button.
	var v_minus_button = document.getElementById("cmdDelRow_BLK_CLEARING_DETAILS");
          var v_plus_button = document.getElementById("cmdAddRow_BLK_CLEARING_DETAILS");
          v_minus_button.disabled = "disabled";
	v_plus_button.disabled = "disabled";
          v_minus_button.style.display = "none";
	v_plus_button.style.display = "none";
	return true;
}
//FCUBS 11.3.1 - Usability Item VOL1 changes ends
function fnPreSave_KERNEL() {
		
	var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
		for(var i=0; i< totalRows; i++){
			//document.getElementById("BENACCOUNT").value =document.getElementById("BLK_TRANSACTION_DETAILS__BENACCOUNT1").value;
			document.getElementsByName("BENACCOUNT1").value =document.getElementById("BLK_TRANSACTION_DETAILS__BENACCOUNT1").value;
			document.getElementById("TXNDATE").value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNDATE1").value;
			document.getElementById("XRATE").value =document.getElementById("BLK_TRANSACTION_DETAILS__XRATE1").value;
		    document.getElementById("CUSTID").value =document.getElementById("BLK_TRANSACTION_DETAILS__CUSTID1").value;
		    document.getElementById("ACCTITLE").value =document.getElementById("BLK_TRANSACTION_DETAILS__ACCTITLE1").value;				
			document.getElementById("TXNCCY").value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value;	 			
	}
			appendTabData(document.getElementById('TBLPageTAB_CHEQUES'));  	
	
	return true;	
}

function fnShowDefultValues() {
	
	try{

        //INTERNAL_19293382 commented starts 
	   /* var clearing_rows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows;
    document.getElementsByName('BENACCOUNT1')[0].value=clearing_rows[0].cells[16].getElementsByTagName("INPUT")[0].value;
	document.getElementsByName('TXNCCY1')[0].value=clearing_rows[0].cells[21].getElementsByTagName("INPUT")[0].value ;
	document.getElementsByName('CUSTID1')[0].value=clearing_rows[0].cells[23].getElementsByTagName("INPUT")[0].value  ;
	document.getElementsByName('ACCTITLE1')[0].value=clearing_rows[0].cells[25].getElementsByTagName("INPUT")[0].value ;
	document.getElementsByName('XRATE1')[0].value=clearing_rows[0].cells[24].getElementsByTagName("INPUT")[0].value	 ; */
        //INTERNAL_19293382 commented ends
	
	//INTERNAL_19293382 starts 
	document.getElementsByName('BENACCOUNT1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "BENACCOUNT1"));
	document.getElementsByName('TXNCCY1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "TXNCCY1"));
	document.getElementsByName('CUSTID1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "CUSTID1"));
	document.getElementsByName('ACCTITLE1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "ACCTITLE1"));
	document.getElementsByName('XRATE1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "XRATE1"));
	//INTERNAL_19293382 ends
	//document.getElementsByName('ACTAMT1')[0].value=clearing_rows[0].cells[5].getElementsByTagName("INPUT")[0].value  ;
	}catch(e) {	}

}
