/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2011  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1411_Q_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/
/*function fnPostLoad_KERNEL()
	{
	debugs("In fnPreLoad", "A");
    fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO")); 
	}
 function enableLov() {
    if(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG").checked == false){ 
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO")); 
	document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO").value="";
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__ORIGINAL_REF_NO")); 
	return;
	}
    if(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG").checked == true){
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__ORIGINAL_REF_NO")); 
	document.getElementById("BLK_INTRA_BRANCH__ORIGINAL_REF_NO").value=""; 
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO")); 
	return;
	}
	
}*/
