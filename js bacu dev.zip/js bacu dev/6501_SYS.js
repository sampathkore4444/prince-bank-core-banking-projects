/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2018, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6501_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~STATUS~SCODE","BLK_CLEARING_DETAILS":"PRODUCT~INSTRNO~VALDATE~ROUTINGNO~SPLCHQ~ROUTBRNCOD~ROUTBNKNAM~ROUTSECTDISC~REMACCOUNT~INSTRDATE~LATECLG~REGCC~ROUTBNKCOD~ROUTSECTCOD~INSTRCCY~ROUTBRNNAM~TCYTOTCHGAMT~BENACCOUNT~INSTRAMT~XRATE~REMARKS~CUSTID~ACCCY~BENBRANCH~ACCTITLE~ACTAMT~DIRECTION~CUSTNAME~TXNDATE~NEGOTREFNO~NEGOTRATE~INSTRUMENT_TYPE~CHEQUE_ISSUE_DATE"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~STATUS~SCODE</FN>'; 
msgxml += '      <FN PARENT="BLK_TRANSACTION_DETAILS" RELATION_TYPE="1" TYPE="BLK_CLEARING_DETAILS">PRODUCT~INSTRNO~VALDATE~ROUTINGNO~SPLCHQ~ROUTBRNCOD~ROUTBNKNAM~ROUTSECTDISC~REMACCOUNT~INSTRDATE~LATECLG~REGCC~ROUTBNKCOD~ROUTSECTCOD~INSTRCCY~ROUTBRNNAM~TCYTOTCHGAMT~BENACCOUNT~INSTRAMT~XRATE~REMARKS~CUSTID~ACCCY~BENBRANCH~ACCTITLE~ACTAMT~DIRECTION~CUSTNAME~TXNDATE~NEGOTREFNO~NEGOTRATE~INSTRUMENT_TYPE~CHEQUE_ISSUE_DATE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_CLEARING_DETAILS" : "BLK_TRANSACTION_DETAILS~1"}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_CLEARING_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 6501.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 6501.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_CLEARING_DETAILS__PRODUCT__LOV__BLK_CLEARING_DETAILS__PRODUCT__1":["BLK_CLEARING_DETAILS__PRODUCT~~","","N~N",""],"BLK_CLEARING_DETAILS__ROUTINGNO__LOV__BLK_CLEARING_DETAILS__ROUTINGNO__1":["BLK_CLEARING_DETAILS__ROUTINGNO~~~","","N~N~N",""],"BLK_CLEARING_DETAILS__INSTRCCY__LOV_CURRENCY_LOCAL":["BLK_CLEARING_DETAILS__INSTRCCY~~","","",""],"BLK_CLEARING_DETAILS__BENACCOUNT__LOV_ACCOUNT_NUMBER":["BLK_CLEARING_DETAILS__BENACCOUNT~BLK_CLEARING_DETAILS__ACCCY~BLK_CLEARING_DETAILS__ACCTITLE~BLK_CLEARING_DETAILS__BENBRANCH~","","N~N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("MDCD~BLK_TRANSACTION_DETAILS","CHCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","PDCD~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("CSTBS_CLEARING_MASTER.XREF=MIVW_MIS_DETAILS.XREF","CSTBS_CLEARING_MASTER.XREF=CSTB_WBCHARGE_DETAILS.XREF","CSTBS_CLEARING_MASTER.XREF=UDVW_UDF_DETAILS.XREF","CSTBS_CLEARING_MASTER.XREF=DETBS_RTL_TELLER.XREF"); 

 var CallRelatType= new Array("1","N","N","1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["6501"]="KERNEL";
ArrPrntFunc["6501"]="";
ArrPrntOrigin["6501"]="";
ArrRoutingType["6501"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["6501"]="N";
ArrCustomModified["6501"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"MDCD":"","CHCD":"","UDCD":"","PDCD":""};
var scrArgSource = {"MDCD":"","CHCD":"","UDCD":"","PDCD":""};
var scrArgVals = {"MDCD":"","CHCD":"","UDCD":"","PDCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"MDCD":"","CHCD":"","UDCD":"","PDCD":""};
var dpndntOnSrvs = {"MDCD":"","CHCD":"","UDCD":"","PDCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"2"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------