/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2017, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6514_1_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"SCODE~TXNDATE1~ENDPOINT1~CONSOLIDATED~TXNCCY1~STATUS~BATCHTOTAMT~XREF~BENACCOUNT1~CUSTID1~ACCTITLE1~XRATE1~ACTAMT1~UI_INSTRUMENT_TYPE~NO_OF_ENTRIES~UI_PRODUCT~UI_ROUTINGNO~UI_INSTR_CCY~TOTALAMT~BATCHNO","BLK_CLEARING_DETAILS":"ROUTINGNO~ENTRYNO~REMARKS~PRODUCT~FCCREF~REMACCOUNT~INSTRCCY~BENACCOUNT~INSTRAMT~INSTRNO~STATUS~REMBRANCH~ENDPOINT~TXNDATE~TXNCCY~XREF~INSTRDATE~CUSTID~XRATE~ACCTITLE~LATECLG~DIRECTION~PROJECTNAME~UNITPAYMENT~UNITID~DEPOSITSLIPNO~INSTRUMENT_TYPE~CHEQUE_ISS_DATE"};

var multipleEntryPageSize = {"BLK_CLEARING_DETAILS" :"15" };

var multipleEntrySVBlocks = "";

var tabMEBlks = {"CVS_MAIN__TAB_CHEQUES":"BLK_CLEARING_DETAILS"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">SCODE~TXNDATE1~ENDPOINT1~CONSOLIDATED~TXNCCY1~STATUS~BATCHTOTAMT~XREF~BENACCOUNT1~CUSTID1~ACCTITLE1~XRATE1~ACTAMT1~UI_INSTRUMENT_TYPE~NO_OF_ENTRIES~UI_PRODUCT~UI_ROUTINGNO~UI_INSTR_CCY~TOTALAMT~BATCHNO</FN>'; 
msgxml += '      <FN PARENT="BLK_TRANSACTION_DETAILS" RELATION_TYPE="N" TYPE="BLK_CLEARING_DETAILS">ROUTINGNO~ENTRYNO~REMARKS~PRODUCT~FCCREF~REMACCOUNT~INSTRCCY~BENACCOUNT~INSTRAMT~INSTRNO~STATUS~REMBRANCH~ENDPOINT~TXNDATE~TXNCCY~XREF~INSTRDATE~CUSTID~XRATE~ACCTITLE~LATECLG~DIRECTION~PROJECTNAME~UNITPAYMENT~UNITID~DEPOSITSLIPNO~INSTRUMENT_TYPE~CHEQUE_ISS_DATE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_CLEARING_DETAILS" : "BLK_TRANSACTION_DETAILS~N"}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_CLEARING_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 6514_1.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 6514_1.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__TXNDATE1";
pkFields[0] = "BLK_TRANSACTION_DETAILS__TXNDATE1";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__BENACCOUNT1__LOV__BLK_TRANSACTION_DETAILS__BENACCOUNT1__1":["BLK_TRANSACTION_DETAILS__BENACCOUNT1~~BLK_TRANSACTION_DETAILS__ACCTITLE1~","","N~N~N",""],"BLK_TRANSACTION_DETAILS__BRN__LOV_BRN":["BLK_TRANSACTION_DETAILS__BRN~~","","N~N","N"],"BLK_TRANSACTION_DETAILS__UI_PRODUCT__LOV__BLK_CLEARING_DETAILS__PRODUCT__2":["BLK_TRANSACTION_DETAILS__UI_PRODUCT~~","","N~N",""],"BLK_TRANSACTION_DETAILS__UI_ROUTINGNO__LOV__BLK_CLEARING_DETAILS__ROUTINGNO__1":["BLK_TRANSACTION_DETAILS__UI_ROUTINGNO~~~","","N~N~N","N"],"BLK_CLEARING_DETAILS__ROUTINGNO__LOV__BLK_CLEARING_DETAILS__ROUTINGNO__1":["BLK_CLEARING_DETAILS__ROUTINGNO~~~","","N~N~N",""],"BLK_CLEARING_DETAILS__PRODUCT__LOV__BLK_CLEARING_DETAILS__PRODUCT__2":["BLK_CLEARING_DETAILS__PRODUCT~~","","N~N",""],"BLK_CLEARING_DETAILS__BENACCOUNT__LOV__BLK_TRANSACTION_DETAILS__BENACCOUNT1__1":["BLK_CLEARING_DETAILS__BENACCOUNT~BLK_CLEARING_DETAILS__REMBRANCH~BLK_CLEARING_DETAILS__ACCTITLE~","","N~N~N",""],"BLK_CLEARING_DETAILS__PROJECTNAME__LOV_PROJECT_NAME":["BLK_CLEARING_DETAILS__PROJECTNAME~~","","N~N",""],"BLK_CLEARING_DETAILS__UNITID__LOV_UNITID":["BLK_CLEARING_DETAILS__UNITID~~","BLK_CLEARING_DETAILS__PROJECTNAME!VARCHAR2","N~N",""]};
var offlineLovInfoFlds = {"BLK_TRANSACTION_DETAILS__TXNCCY1__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__TXNCCY1~",""],"BLK_TRANSACTION_DETAILS__UI_INSTR_CCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__UI_INSTR_CCY~",""],"BLK_CLEARING_DETAILS__INSTRCCY__LOV_CURRENCY_LOCAL":["BLK_CLEARING_DETAILS__INSTRCCY~",""],"BLK_CLEARING_DETAILS__TXNCCY__LOV_CURRENCY_LOCAL":["BLK_CLEARING_DETAILS__TXNCCY~",""]};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_CHEQUES';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_CLEARING_DETAILS");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CMIS~BLK_TRANSACTION_DETAILS","CUDF~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("",""); 

 var CallRelatType= new Array("1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["6514_1"]="KERNEL";
ArrPrntFunc["6514_1"]="6514_2";
ArrPrntOrigin["6514_1"]="KERNEL";
ArrRoutingType["6514_1"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["6514_1"]="N";
ArrCustomModified["6514_1"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CMIS":"","CUDF":""};
var scrArgSource = {"CMIS":"","CUDF":""};
var scrArgVals = {"CMIS":"","CUDF":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CMIS":"","CUDF":""};
var dpndntOnSrvs = {"CMIS":"","CUDF":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------