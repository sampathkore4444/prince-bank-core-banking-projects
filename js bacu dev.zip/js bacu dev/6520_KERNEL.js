/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2009  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/***************************************************************************************************************************
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6520_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
** Last Modified By   :  Ediga GANGADHAR
**  Last modified on   :  24-APRIL-2013
**  Reason             :  Capture the additionl information Drawee a/c no and Cheque number into Remarks
**  Search String      :   9NT1587_16712454_Narrative
****************************************************************************************************************************/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";
/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */

function fnPostNew_KERNEL() {
 //document.getElementsByName("BLK_CLEARING_DETAILS__VALDATE")[0].value=dlgArg.mainWin.frames['Global'].AppDate; //fcubs 10.5 itr2 changes to default the value of value date
  document.getElementById("BLK_CLEARING_DETAILS__TXNDATE").value=mainWin.currBranchDate;
  enableForm();                                                                                            //fcubs 10.5 itr2 changes to default the value of value date
    
    return true;
    	
}

//9NT1587_16712454_Narrative starts
function fnRemarksDefault(event) {
var index=getRowIndex(event)-1;
if (dataObj.action != "REMOTEAUTH") {
var narr_def =  document.getElementById("BLK_CLEARING_DETAILS__REMARKS").getAttribute('DEFAULT');
	var chq_num = document.getElementById("BLK_CLEARING_DETAILS__INSTRNO").value;
	var drwe_acc = document.getElementById("BLK_CLEARING_DETAILS__REMACCOUNT").value;
	var narr_val = "";
	narr_split = narr_def.split('-');
	if(chq_num == "") chq_num =  ( narr_split[2] );
	if(drwe_acc == "") drwe_acc =  (narr_split[4] );
	narr_val = narr_split[0] +"-" +narr_split[1]+"-"+chq_num +"-"+narr_split[3] + "-"+drwe_acc;
	 document.getElementById("BLK_CLEARING_DETAILS__REMARKS").value = narr_val;
	}
	return true;
}
// 9NT1587_16712454_Narrative ends



