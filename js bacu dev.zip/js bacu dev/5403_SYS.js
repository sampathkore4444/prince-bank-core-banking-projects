/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2017, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 5403_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~PRD~BRN~VALDATE~FNACCREF~RELCUST~CUSTNAME~TXNCCY~TXNAMT~OFFSETCCY~NARRATIVE~XRATE~OFFSETAMT~TCYTOTCHGAMT~ACTAMT~HJPAYBLE~HJREF"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~PRD~BRN~VALDATE~FNACCREF~RELCUST~CUSTNAME~TXNCCY~TXNAMT~OFFSETCCY~NARRATIVE~XRATE~OFFSETAMT~TCYTOTCHGAMT~ACTAMT~HJPAYBLE~HJREF</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 5403.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 5403.js, in "BlockName__FieldName" format
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__FNACCREF__LOV_FN_ACC":["BLK_TRANSACTION_DETAILS__FNACCREF~BLK_TRANSACTION_DETAILS__RELCUST~BLK_TRANSACTION_DETAILS__CUSTNAME~BLK_TRANSACTION_DETAILS__TXNCCY~BLK_TRANSACTION_DETAILS__OFFSETCCY~BLK_TRANSACTION_DETAILS__HJPAYBLE~BLK_TRANSACTION_DETAILS__TXNAMT~BLK_TRANSACTION_DETAILS__OFFSETAMT~BLK_TRANSACTION_DETAILS__XRATE~","","N~N~N~N~N~N~N~N~N",""],"BLK_TRANSACTION_DETAILS__TXNCCY__LOV_CCY":["BLK_TRANSACTION_DETAILS__TXNCCY~~","","",""],"BLK_TRANSACTION_DETAILS__OFFSETCCY__LOV_CCY":["BLK_TRANSACTION_DETAILS__OFFSETCCY~~","","",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("DMCD~BLK_TRANSACTION_DETAILS","CHCD~BLK_TRANSACTION_DETAILS","MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","DPMT~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("DETBS_RTL_TELLER.XREF=CSTBS_WBDENOM_MASTER.XREF","DETBS_RTL_TELLER.XREF=CSTBS_WBCHARGE_DETAILS.XREF","DETBS_RTL_TELLER.XREF=MIVWS_MIS_DETAILS.XREF","DETBS_RTL_TELLER.XREF=UDVWS_UDF_DETAILS.XREF","DETBS_RTL_TELLER.TRN_REF_NO = CSTB_UI_COLUMNS.CHAR_FIELD1"); 

 var CallRelatType= new Array("N","N","1","N","1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["5403"]="KERNEL";
ArrPrntFunc["5403"]="";
ArrPrntOrigin["5403"]="";
ArrRoutingType["5403"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["5403"]="N";
ArrCustomModified["5403"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DPMT":""};
var scrArgSource = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DPMT":""};
var scrArgVals = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DPMT":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DPMT":""};
var dpndntOnSrvs = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DPMT":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"2"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------