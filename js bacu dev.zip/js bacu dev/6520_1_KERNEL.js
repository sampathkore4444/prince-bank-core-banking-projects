/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2009  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/***************************************************************************************************************************
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6520_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
** Last Modified By   :  Ediga GANGADHAR
**  Last modified on   :  24-APRIL-2013
**  Reason             :  Capture the additionl information Drawee a/c no and Cheque number into Remarks
**  Search String      :   9NT1587_16712454_Narrative
****************************************************************************************************************************/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";
/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {
 //document.getElementsByName("BLK_CLEARING_DETAILS__VALDATE")[0].value=dlgArg.mainWin.frames['Global'].AppDate; //fcubs 10.5 itr2 changes to default the value of value date
  document.getElementById("BLK_CLEARING_DETAILS__TXNDATE").value=mainWin.currBranchDate;
  enableForm();                                                                                            //fcubs 10.5 itr2 changes to default the value of value date
    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

		return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	
	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
//9NT1587_16712454_Narrative starts
function fnRemarksDefault(event) {
var index=getRowIndex(event)-1;
if (dataObj.action != "REMOTEAUTH") {
var narr_def =  document.getElementById("BLK_CLEARING_DETAILS__REMARKS").getAttribute('DEFAULT');
	var chq_num = document.getElementById("BLK_CLEARING_DETAILS__INSTRNO").value;
	var drwe_acc = document.getElementById("BLK_CLEARING_DETAILS__REMACCOUNT").value;
	var narr_val = "";
	narr_split = narr_def.split('-');
	if(chq_num == "") chq_num =  ( narr_split[2] );
	if(drwe_acc == "") drwe_acc =  (narr_split[4] );
	narr_val = narr_split[0] +"-" +narr_split[1]+"-"+chq_num +"-"+narr_split[3] + "-"+drwe_acc;
	 document.getElementById("BLK_CLEARING_DETAILS__REMARKS").value = narr_val;
	}
	return true;
}
// 9NT1587_16712454_Narrative ends
