/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2009  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
	   /*----------------------------------------------------------------------------------------------------
**
** File Name    : 7031_KERNEL.js
**
** Module       : FCJWeb
**
**  This source is part of the FLEXCUBE Software System and is copyrighted by 
**  Oracle Financial Services Software Limited.
**  
**  All rights reserved.  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle Financial Services Software Limited.
**  
**  Oracle Corporation
**  World Headquarters
**  500 Oracle Parkway
**  Redwood Shores, CA 94065
**  U.S.A.
**  
**  Copyright � 2008- 2009 by Oracle Financial Services Software Limited.
**  Oracle Financial Services Software Limited.

**  CHANGE LOG
**  Last Modified By   : V.Rakesh Kumar
**  Last modified on   : 23-Aug-2011
**  Full Version       : 9NT1462-11.4 kernel Changes
**  Reason             : 9NT1462-11.4 kernel Changes
**Search String     :9NT1462-11.4 kernel- Passbook Management

**  Last Modified By   : V.Rakesh Kumar
**  Last modified on   : 22-November-2011
**  Reason             : 9NT1462 : ITR1 SFR#13391423 - Status description was not defaulted. so replaced the "return true".
**Search String     : 9NT1462 : ITR1 SFR#13391423

**  Last Modified By   : Shobhitk
**  Last modified on   : 12-feb-2011
**  Reason             : 12.0.1 NLS changes
**Search String     :16316025

	** Modified By 	  	  : Sriraam S
	** Modified On        : 17-Jul-2014
	** Modified Reason    : Populate button not working in Chrome
	** Search String      : 9NT1525_1203_INTERNAL_19237132
----------------------------------------------------------------------------------------------------
*/

var fcjRequestDOM;
var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
 
 function fnPreUnlock_KERNEL()
{
	
	//alert('fnPreUnloack_KERNEL  '+ dbDataDOM.selectSingleNode('//BLK_STTBS_SWEEP_DETAILS/MATURITY_DATE').text);
	
    return true;
}
function fnPostUnlock_KERNEL()
{
	
	//alert('fnPostUnloack_KERNEL  '+ dbDataDOM.selectSingleNode('//BLK_STTBS_SWEEP_DETAILS/MATURITY_DATE').text);
	
    return true;
}
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	document.getElementById('BRN').value = mainWin.CurrentBranch ;
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

     return true;
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	debugs("In fnPreSave", "A");	
	var isValid = true;
	if(!fnValidate())
        return false;

	debugs("In fnPreSave", "A");	
	return isValid;	
	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {

	gAction='SAVEAUTOAUTH';//9NT1462-11.4 kernel- Passbook Management
	return true;
	
	}

/*
function fnPreLoad_CVS_MAIN_KERNEL(screenArgs){
screenArgs['ACC'] = document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__ACC").value
screenArgs['BRN'] = document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__BRN").value
screenArgs['PASSBOOKNO'] = document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKNO ").value
return true ;
}
*/
//9NT1462-11.4 kernel- Passbook Management Starts

function fn_Populate(){

g_prev_gAction=gAction ;
gAction = 'NEW';

appendData(document.getElementById('TBLPageALL'));
var custid = document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__CUSTID").value ;
var passbk_number = document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKNO").value ;
var issue_date = document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__ISSUEDATE").value ;
gAction = 'EXECUTEQUERY';
//fcjRequestDOM = buildUBSXml(); //9NT1525_1203_INTERNAL_19237132 commented
fcjRequestDOM = buildBrnUBSXml(); //9NT1525_1203_INTERNAL_19237132 added
addBranchParam(fcjRequestDOM);
//fcjRequestDOM.selectSingleNode("//ACTION").text	= "POPULATE"; //9NT1525_1203_INTERNAL_19237132 commented
setNodeText(selectSingleNode(fcjRequestDOM, "//ACTION"), "POPULATE"); //9NT1525_1203_INTERNAL_19237132 added
gAction = 'POPULATE' ; 
fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
if(fcjResponseDOM)
  {
    var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
    var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
    var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);

    if (msgStatus == 'SUCCESS') 
    {
      setDataXML(getXMLString(pureXMLDOM));
      showData(dbStrRootTableName, 1);
	  
	  document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__ACC").value = dbDataDOM.selectSingleNode("//ACCOUNT").text ;
  document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__BRN").value = dbDataDOM.selectSingleNode("//BRANCH").text ;
  document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKNO").value = passbk_number;
  document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__ISSUEDATE").value = document.getElementById("BLK_MULTIPLE").tBodies[0].rows[0].cells[4].getElementsByTagName("INPUT")[0].value;
  //document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKNO").value = dbDataDOM.selectSingleNode("//PASSBOOK_NUMBER").text ;
  document.getElementById("BLK_PASSBOOK_STATUS_CHANGE__CUSTID").value = custid ;
    }
    else if (msgStatus == 'FAILURE')
    {
      
	   //alert('No Records to Populate.');
	  showErrorAlerts('BRN-VAL-013');	//	16316025
	  //gAction = g_prev_gAction; //9NT1462 : ITR1 SFR#13391423
	  //var returnVal = displayResponse(messageNode);
    }
	gAction = g_prev_gAction;

  }
  fnDefaultStatusDesc();
  return true; //9NT1462 : ITR1 SFR#13391423
}
function fnDefaultStatusDesc(){
	var tableObject = document.getElementById("BLK_MULTIPLE");
	var totRows = tableObject.tBodies[0].rows;
	for(var i=0;i<totRows.length;i++){
		var curRow = totRows[i];
	curRow.cells[6].getElementsByTagName("INPUT")[0].value = curRow.cells[5].getElementsByTagName("INPUT")[0].value;
	}

}
function fnPostNavigate_BLK_MULTIPLE_KERNEL()  { 
	
	fnDefaultStatusDesc();
		
	return true;

}
//9NT1462-11.4 kernel- Passbook Management Ends
