/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2019, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 8004_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~PRD~XRATE~NARRATIVE~BRN~TXNBRN~TXNDATE~FCCREF~MODULE~TXNCCY~TXNAMT~OFFSETCCY~OFFSETAMT~RELCUST~TRANCOUNT~BENFNAME~BENFADDR1~BENFADDR2~BENFADDR3~OTHERDETLS1~FT~TCYTOTCHGAMT~TXNACC~TXNTRN~OFFSETACC~OFFSETBRN~OFFSETTRN~LCYAMT~ACTAMT~ACCTITLE1~DENMAMT2~DENOM_VARIANCE~NEGOTRATE~NEGOTREFNO~CHAR_FIELD34~CHAR_FIELD35"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~PRD~XRATE~NARRATIVE~BRN~TXNBRN~TXNDATE~FCCREF~MODULE~TXNCCY~TXNAMT~OFFSETCCY~OFFSETAMT~RELCUST~TRANCOUNT~BENFNAME~BENFADDR1~BENFADDR2~BENFADDR3~OTHERDETLS1~FT~TCYTOTCHGAMT~TXNACC~TXNTRN~OFFSETACC~OFFSETBRN~OFFSETTRN~LCYAMT~ACTAMT~ACCTITLE1~DENMAMT2~DENOM_VARIANCE~NEGOTRATE~NEGOTREFNO~CHAR_FIELD34~CHAR_FIELD35</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 8004.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 8004.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__FCCREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__FCCREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__TXNCCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__TXNCCY~~","","",""],"BLK_TRANSACTION_DETAILS__OFFSETCCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__OFFSETCCY~~","","",""],"BLK_TRANSACTION_DETAILS__RELCUST__LOV_CUST_ID":["BLK_TRANSACTION_DETAILS__RELCUST~BLK_TRANSACTION_DETAILS__BENFNAME~BLK_TRANSACTION_DETAILS__BENFADDR1~BLK_TRANSACTION_DETAILS__BENFADDR2~BLK_TRANSACTION_DETAILS__BENFADDR3~BLK_TRANSACTION_DETAILS__OTHERDETLS1~","","N~N~N~N~N~N",""],"BLK_TRANSACTION_DETAILS__CHAR_FIELD34__LOV_PURPOSE_OF_TXN":["BLK_TRANSACTION_DETAILS__CHAR_FIELD34~","","N",""],"BLK_TRANSACTION_DETAILS__CHAR_FIELD35__LOV_SOURCE_OF_FUNDS":["BLK_TRANSACTION_DETAILS__CHAR_FIELD35~","","N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_MAIN';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_BODY';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("DMCD~BLK_TRANSACTION_DETAILS","CHCD~BLK_TRANSACTION_DETAILS","MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","DMCF~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("DETBS_RTL_TELLER.XREF=CSTBS_WBDENOM_MASTER.XREF","DETBS_RTL_TELLER.XREF=CSTBS_WBCHARGE_DETAILS.XREF","DETBS_RTL_TELLER.XREF=MIVWS_MIS_DETAILS.XREF","DETBS_RTL_TELLER.XREF=UDVWS_UDF_DETAILS.XREF","DETBS_RTL_TELLER.XREF=CSTBS_WBDENOM_MASTER.XREF"); 

 var CallRelatType= new Array("N","N","1","N","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["8004"]="KERNEL";
ArrPrntFunc["8004"]="";
ArrPrntOrigin["8004"]="";
ArrRoutingType["8004"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["8004"]="N";
ArrCustomModified["8004"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DMCF":""};
var scrArgSource = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DMCF":""};
var scrArgVals = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DMCF":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DMCF":""};
var dpndntOnSrvs = {"DMCD":"","CHCD":"","MDCD":"","UDCD":"","DMCF":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------