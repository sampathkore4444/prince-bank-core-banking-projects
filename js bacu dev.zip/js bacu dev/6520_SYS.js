/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2017, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6520_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~STATUS~SCODE~BATCHTOTAMT","BLK_CLEARING_DETAILS":"PRODUCT~INSTRNO~VALDATE~ROUTINGNO~SPLCHQ~ROUTBRNCOD~ROUTBNKNAM~ROUTSECTDISC~REMACCOUNT~INSTRDATE~LATECLG~REGCC~ROUTBNKCOD~INSTRCCY~ROUTSECTCOD~ROUTBRNNAM~ACCCY~TCYTOTCHGAMT~BENACCOUNT~ACCCYAMT~INSTRAMT~XRATE~BENCCY~REMARKS~ACCTITLE~DIRECTION~TXNDATE~NEGOTREFNO~NEGOTRATE~INSTRTYPE~CHEQUE_ISSUE_DATE"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~STATUS~SCODE~BATCHTOTAMT</FN>'; 
msgxml += '      <FN PARENT="BLK_TRANSACTION_DETAILS" RELATION_TYPE="1" TYPE="BLK_CLEARING_DETAILS">PRODUCT~INSTRNO~VALDATE~ROUTINGNO~SPLCHQ~ROUTBRNCOD~ROUTBNKNAM~ROUTSECTDISC~REMACCOUNT~INSTRDATE~LATECLG~REGCC~ROUTBNKCOD~INSTRCCY~ROUTSECTCOD~ROUTBRNNAM~ACCCY~TCYTOTCHGAMT~BENACCOUNT~ACCCYAMT~INSTRAMT~XRATE~BENCCY~REMARKS~ACCTITLE~DIRECTION~TXNDATE~NEGOTREFNO~NEGOTRATE~INSTRTYPE~CHEQUE_ISSUE_DATE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_CLEARING_DETAILS" : "BLK_TRANSACTION_DETAILS~1"}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_CLEARING_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 6520.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 6520.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_CLEARING_DETAILS__PRODUCT__LOV_PRODUCT":["BLK_CLEARING_DETAILS__PRODUCT~~","","N~N",""],"BLK_CLEARING_DETAILS__ROUTINGNO__LOV__BLK_CLEARING_DETAILS__ROUTINGNO__1":["BLK_CLEARING_DETAILS__ROUTINGNO~BLK_CLEARING_DETAILS__ROUTBRNCOD~BLK_CLEARING_DETAILS__ROUTBNKCOD~","","N~N~N",""],"BLK_CLEARING_DETAILS__BENACCOUNT__LOV__BLK_CLEARING_DETAILS__BENACCOUNT__3":["BLK_CLEARING_DETAILS__BENACCOUNT~BLK_CLEARING_DETAILS__ACCTITLE~","","N~N",""]};
var offlineLovInfoFlds = {"BLK_CLEARING_DETAILS__INSTRCCY__LOV_CURRENCY_LOCAL":["BLK_CLEARING_DETAILS__INSTRCCY~",""],"BLK_CLEARING_DETAILS__BENCCY__LOV_CURRENCY_LOCAL":["BLK_CLEARING_DETAILS__BENCCY~",""]};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CHCD~BLK_TRANSACTION_DETAILS","MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("CSTBS_CLEARING_MASTER.XREF=CSTB_WBCHARGE_DETAILS.XREF","CSTBS_CLEARING_MASTER.XREF=MIVW_MIS_DETAILS.XREF","CSTBS_CLEARING_MASTER.XREF=UDVW_UDF_DETAILS.XREF"); 

 var CallRelatType= new Array("N","1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["6520"]="KERNEL";
ArrPrntFunc["6520"]="";
ArrPrntOrigin["6520"]="";
ArrRoutingType["6520"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["6520"]="N";
ArrCustomModified["6520"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CHCD":"","MDCD":"","UDCD":""};
var scrArgSource = {"CHCD":"","MDCD":"","UDCD":""};
var scrArgVals = {"CHCD":"","MDCD":"","UDCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CHCD":"","MDCD":"","UDCD":""};
var dpndntOnSrvs = {"CHCD":"","MDCD":"","UDCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------