/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  Last Modified By   :  Achelal
**  Last modified on   :  15-Feb-2012
**  Search String       :  9nt1501 usability changes
**  Reason             :  9nt1501 usability changes

**  Last Modified By   :  Prabhakaran J
**  Last modified on   : 10-May-2012
**  Full Version       : FCUBS 12.0.0
**  Reason             :  Focus changed to txn amount on exchange rate calculation
**  Search String : 9NT1501 ITR2 sfr 14005445

**  Last Modified By   : Mohit Ojha
**  Last modified on   : 07-Apr-2017
**  Reason             : MCY/VA changes
**  Search String      : FCUBS12.4MCY/VA changes
----------------------------------------------------------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;
var hisC1='###';
var hisC2='$$$';
var hisAmount=0;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

//document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value=mainWin.Lcy;
	document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value='Miscellaneous Customer Debit';
    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
	 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	debugs( "In fnPreSave", "A");	
	var isValid = true;
	if(!fnValidate())
        return false;

	debugs("In fnPreSave", "A");	
	return isValid;	
	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_MIS_KERNEL() {
    return true;
}
function fnInTab_TAB_MIS_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_MIS_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}

function fnPreAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_UDF_KERNEL() {
    return true;
}
function fnInTab_TAB_UDF_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_UDF_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}


function fnFunctionDefultValues() {
    try
    {
        if (document.all.OFFSETBRN.value == '') document.all.OFFSETBRN.value = mainWin.CurrentBranch;
    } 
	catch(e)    {}
}

//9nt1501 usability changes ends

//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_TRANSACTION_DETAILS__TXNCCY' ;
    var b = 'BLK_TRANSACTION_DETAILS__TXNCCY';
	var c = 'BLK_TRANSACTION_DETAILS__TXNAMT' ;
	var d = 'BLK_TRANSACTION_DETAILS__TXNAMT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_21317625
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//FCUBS12.4MCY/VA changes starts
function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
    if (eventElement.name == 'UI_TXN_ACC' || eventElement.name == 'OFFSETCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').oldvalue = "";
  if(eventElement.name == 'UI_TXN_ACC'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'M'))
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(eventElement.id).value;
		}	// 1203_ITR1_18388624
        if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
								document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = '';    //Bug#25817723 added
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    }
      return true;
}
//FCUBS12.4MCY/VA changes ends
/*
function fnResolveVirAcc1(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
    if (eventElement.name == 'OFFSETACC' || eventElement.name == 'OFFSETCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMT').oldvalue = "";
  if(eventElement.name == 'OFFSETACC'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'M'))
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value = document.getElementById(eventElement.id).value;
		}	// 1203_ITR1_18388624
        if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    }
      return true;
}*/
//12.1_SV_changes  ends