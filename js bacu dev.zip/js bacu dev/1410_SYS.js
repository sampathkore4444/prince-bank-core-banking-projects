/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2018, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1410_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_INTRA_BRANCH":"REFERENCE_NO~FROM_BRANCH~FROM_BRANCH_NAME~FROM_VAULT_TIL~TO_BRANCH~TO_BRANCH_NAME~TO_VAULT_TIL~TXNCCY~TXNAMT~DESCRIPTION~XREF~REQUEST_STAT~ADV_REQ_FLAG~ADV_REQ_REF_NO~ORIGINAL_REF_NO~ADVANCE_AMOUNT~DENMAMT2~SCREENTYPE"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_INTRA_BRANCH">REFERENCE_NO~FROM_BRANCH~FROM_BRANCH_NAME~FROM_VAULT_TIL~TO_BRANCH~TO_BRANCH_NAME~TO_VAULT_TIL~TXNCCY~TXNAMT~DESCRIPTION~XREF~REQUEST_STAT~ADV_REQ_FLAG~ADV_REQ_REF_NO~ORIGINAL_REF_NO~ADVANCE_AMOUNT~DENMAMT2~SCREENTYPE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_INTRA_BRANCH" : ""}; 

 var dataSrcLocationArray = new Array("BLK_INTRA_BRANCH"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1410.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1410.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_INTRA_BRANCH__REFERENCE_NO";
pkFields[0] = "BLK_INTRA_BRANCH__REFERENCE_NO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_INTRA_BRANCH__TO_BRANCH__LOV_BRANCH_V":["BLK_INTRA_BRANCH__TO_BRANCH~BLK_INTRA_BRANCH__TO_BRANCH_NAME~BLK_INTRA_BRANCH__TO_VAULT_TIL~~","","N~N~N~N",""],"BLK_INTRA_BRANCH__TXNCCY__LOV_CURRENCY":["BLK_INTRA_BRANCH__TXNCCY~~","","",""],"BLK_INTRA_BRANCH__ADV_REQ_REF_NO__LOV_ADVANCE_REQ":["BLK_INTRA_BRANCH__ADV_REQ_REF_NO~BLK_INTRA_BRANCH__DESCRIPTION~~~~~~~BLK_INTRA_BRANCH__REQUEST_STAT~BLK_INTRA_BRANCH__ADV_REQ_FLAG~","","N~N~N~N~N~N","N"]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_BODY';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("DMCD~BLK_INTRA_BRANCH"); 

 var CallFormRelat=new Array("RTTBS_INTRA_BANK_MASTER.REFERENCE_NO=CSTBS_WBDENOM_MASTER.XREF"); 

 var CallRelatType= new Array("N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1410"]="KERNEL";
ArrPrntFunc["1410"]="";
ArrPrntOrigin["1410"]="";
ArrRoutingType["1410"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1410"]="N";
ArrCustomModified["1410"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"DMCD":""};
var scrArgSource = {"DMCD":""};
var scrArgVals = {"DMCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"DMCD":""};
var dpndntOnSrvs = {"DMCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------