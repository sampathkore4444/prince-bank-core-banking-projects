/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2013  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/***************************************************************************************************************************
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6514_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
**
**Changed By         :  Kundan Verma
**Description        :  Changed language code while searching from ertb_msgs
**Search String      :  FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
**
**Changed By         :  SwathyR
**Description         :  To default application date as cheque date
**Search String     :  FCUBS 11.3.1 - Usability Item VOL1 changes

Changed By         :  Prashant Yadav
Description        :  return true added on postload
Search String      :  16437671

** Last Modified By   :  Ediga GANGADHAR
**  Last modified on   :  24-APRIL-2013
**  Reason             :  Capture the additionl information Drawee a/c no and Cheque number into Remarks
**  Search String      :   9NT1587_16712454_Narrative

**  Last Modified By   :  Sarina
**  Last modified on   : 12-JUN-2013
**  Reason             : fnHandleError call commented as it is not reqd for addrows 
		         and because of it presave_kernel was not getting hit. Instead 
		         fnSetScrData is used to paint response on screen
**  Search String      : FC12.0.2 IUT BUG NO 149

**  Last Modified By   :  Sarina
**  Last modified on   : 25-JUL-2013
**  Reason             : Total Amount is not being printed on screen in Mozilla
**  Search String      : 9NT1587_FCUBS12.0.2_BUG_NO_17218652 

**  Last Modified By   :  Sneha Sindhia
**  Last modified on   : 27-AUG-2013
**  Reason             : Total Amount will be calculated even if we do not click on the button Outstanding amount
**  Search String      : 12.0.2_ITR2_17358518  

**Last Modified By  :  Deeksha Pai 
**Modified On  : 05-Dec-2013
**Reason  :  code added to make F11 and F12 keys work for other branches
**Search String  : INTERNAL_16860758
****************************************************************************************************************************/
var PAGE_SIZE = 15;
function fnPostLoad_KERNEL() {
	// No more [+] button.
	var v_plus_button = document.getElementById("cmdAddRow_BLK_CLEARING_DETAILS");
	v_plus_button.disabled = "disabled";
	v_plus_button.style.display = "none";
	//FCUBS 11.3.1 - Usability Item VOL1 changes starts
	var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
	for(var i=0; i< totalRows; i++) {
document.getElementsByName('INSTRDATE')[i].value = mainWin.AppDate;
}
return true;//16437671  added
//FCUBS 11.3.1 - Usability Item VOL1 changes ends
}

function fnPreSave_KERNEL() {
	appendTabData(document.getElementById('TBLPageTAB_CHEQUES'));
//12.0.2_ITR2_17358518 starts
	try {

		var totalAmt = 0;

		var l_Cnt = 0;

		appendData(document.getElementById("TBLPageTAB_MAIN"));

		var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));

		if(clgNodes) {

			for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {

				var l_Node = clgNodes[l_Cnt];

				var amt = getNodeText(selectSingleNode(l_Node, "INSTRAMT"));

				if (amt && !isNaN(amt))

					totalAmt = parseFloat(totalAmt) + parseFloat(amt);

			}

		}

		document.getElementsByName('TOTALAMT')[0].value = totalAmt;//Retained(Not commenting) for 9NT1587_FCUBS12.0.2_BUG_NO_17218652 as otherwise Amounttag will go null in Extbranch.js fnproceed
		document.getElementById('BLK_TRANSACTION_DETAILS__TOTALAMTI').value = totalAmt;//9NT1587_FCUBS12.0.2_BUG_NO_17218652

	} catch (ex) {

	}
	//12.0.2_ITR2_17358518 ends
	return true;
}

/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */	 
function fnDefultBrnValues() {
}

function fnAddRowsWithDefault() {
	//fnAddRows1_JS(); return;

	var l_brn=document.getElementById('BLK_TRANSACTION_DETAILS__BRN').value;
	var l_rowCnt =document.getElementById('BLK_TRANSACTION_DETAILS__NO_OF_ENTRIES').value;

	if (!l_rowCnt) {
		
		showErrorAlerts('BRN-VAL-007');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
		
		//alert("Enter the Number of Entries To be Added");
		return false;
	}

	tempAction = dataObj.action;
	fnAddRows0();
	dataObj.action	= tempAction;
	document.getElementById('BLK_TRANSACTION_DETAILS__BRN').value=l_brn;
}

function fnAddRows0() {

	window.focus();
	appendData();
	dataObj.action = 'ADDNEWROWS';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);

	var v_xml_string = getXMLString(fcjResponseDOM);
	if (fcjResponseDOM && v_xml_string.length > 0) {
		dataObj = new dataObject(v_xml_string);
		//FC12.0.2 IUT BUG NO 149 starts
		//var returnValue = fnHandleError();
		fnSetScrData(fcjResponseDOM);
		//FC12.0.2 IUT BUG NO 149 ends
	} else {
		alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
		return;
	}
	//9NT1587_16712454_Narrative STARTS 
	var totRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
	for(var i=0; i< totRows; i++){
		document.getElementsByName("REMARKS")[i].value = document.getElementsByName("REMARKS")[i].getAttribute('DEFAULT');
		}
		//9NT1587_16712454_Narrative ENDS
}


function fnAddRows1_JS() {

	var l_rowCnt =document.getElementById('BLK_TRANSACTION_DETAILS__NO_OF_ENTRIES').value;
	for(i = 0; i < l_rowCnt; i++) {
		fnAddRow("BLK_CLEARING_DETAILS");
	}
}

function fnPostDeleteRow_BLK_CLEARING_DETAILS_KERNEL() {

	appendData(document.getElementById("TBLPageTAB_CHEQUES"));
	var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));
	for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENTRYNO"), new String(l_Cnt + 1));
	}

	var pageNo = Number(document.getElementById("CurrPage__BLK_CLEARING_DETAILS").innerHTML) - 1;
    var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
	var entryNo;
    for(var i=0; i< totalRows; i++){
		entryNo = new String(pageNo * PAGE_SIZE + i + 1);
		document.getElementsByName("ENTRYNOI")[i].value = entryNo;
		document.getElementsByName("ENTRYNO")[i].value = entryNo;
    }
    return true;
}


function fnCalculateTotAmt() {

	try {

		var totalAmt = 0;

		var l_Cnt = 0;

		appendData(document.getElementById("TBLPageTAB_MAIN"));

		var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));

		if(clgNodes) {

			for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {

				var l_Node = clgNodes[l_Cnt];

				var amt = getNodeText(selectSingleNode(l_Node, "INSTRAMT"));

				if (amt && !isNaN(amt))

					totalAmt = parseFloat(totalAmt) + parseFloat(amt);

			}

		}

		document.getElementsByName('TOTALAMT')[0].value = totalAmt;//Retained(Not commenting) for 9NT1587_FCUBS12.0.2_BUG_NO_17218652 as otherwise Amounttag will go null in Extbranch.js fnproceed
		document.getElementById('BLK_TRANSACTION_DETAILS__TOTALAMTI').value = totalAmt;//9NT1587_FCUBS12.0.2_BUG_NO_17218652

	} catch (ex) {

	}

}
////9NT1587_16712454_Narrative  STARTS
function fnRemarksDefault(event) {
var index=getRowIndex(event)-1;
if (dataObj.action != "REMOTEAUTH") {
var narr_def =  document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[index].cells[17].getElementsByTagName("INPUT")[0].getAttribute('DEFAULT');
	var chq_num = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[index].cells[5].getElementsByTagName("INPUT")[0].value;
	var drwe_acc = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[index].cells[19].getElementsByTagName("INPUT")[0].value;
	var narr_val = "";
	narr_split = narr_def.split('-');
	if(chq_num == "") chq_num =  (narr_split[2] );
	if(drwe_acc == "") drwe_acc =  ( narr_split[4] );
	narr_val = narr_split[0] +"-" +narr_split[1]+"-"+chq_num +"-"+narr_split[3] + "-"+drwe_acc;
	 document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows[index].cells[17].getElementsByTagName("INPUT")[0].value = narr_val;
	}
	return true;
}
////9NT1587_16712454_Narrative  ENDS
//INTERNAL_16860758 starts
function fnSetHotKeyBranch_KERNEL()
{
try{
hotKeyBrn=document.getElementById("BLK_TRANSACTION_DETAILS__BRN").value;
}catch(e){}
return true;
}
//INTERNAL_16860758 ends


function fnShowDefultValues() {
	
	try{
	
	//INTERNAL_19293382 starts 
	document.getElementsByName('BENACCOUNT1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "BENACCOUNT"));
	document.getElementsByName('TXNCCY1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "TXNCCY"));
	document.getElementsByName('CUSTID1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "CUSTID"));
	document.getElementsByName('ACCTITLE1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "ACCTITLE"));
	document.getElementsByName('XRATE1')[0].value=getNodeText(selectSingleNode(dbDataDOM, "//" + "BLK_CLEARING_DETAILS" + "/" + "XRATE"));
	//INTERNAL_19293382 ends
	
	}catch(e) {	}
	
}