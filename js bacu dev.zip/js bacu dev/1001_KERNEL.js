/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------

** Modified By         : Mohit Ojha
** Modified On         : 07-Apr-2017
** Modified Reason     : MCY/VA changes
** Search String       : FCUBS12.4MCY/VA changes
------------------------------------------------------------------------------------------
*/
//12.0.2_Single_Step_process starts
function fnPostNew_KERNEL() {
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = mainWin.Lcy;
	 document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	  document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; //12.0.2_17077363
    document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Cash Withdrawal';
    if (dataObj.twoStepProcess == 'Y' && dataObj.firstStepDone == 'Y') {
        document.getElementById("BLK_TRANSACTION_DETAILS__PRD").value = 'CHW2';
    }
    return true;

}

function fnAssignTxnCcy(p_acc_ccy) {
    document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = p_acc_ccy.value;
    return true;
}

function fnAccCcy(event) {
    if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != "") {
        fnDisableElement(document.getElementsByName("TXNCCY")[0]);
    }
    return true;
}
/*
function fnSetHotKeyBranch_KERNEL() {

    if (window.event.srcElement.name == "TXNACC") {
        hotKeyBrn = document.getElementsByName('TXNBRN')[0].value;
    }
    if (window.event.srcElement.name == "OFFSETACC") {
        hotKeyBrn = document.getElementsByName('OFFSETBRN')[0].value;
    }
    return true;
}
*/
function fnPostLoad_KERNEL(e) {
	 document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	  document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; //12.0.2_17077363
    if (dataObj.twoStepProcess == 'Y' && dataObj.firstStepDone == 'Y') {
        document.getElementById("BLK_TRANSACTION_DETAILS__PRD").value = 'CHW2';
    }
    var txnAcc = mainWin.functionDef[functionId].txnAcc;
    var txnAccBlock = txnAcc.split("__")[0];
    var txnAccTag = txnAcc.split("__")[1];
    try {
        pickedUpAcc = getNodeText(selectSingleNode(dbDataDOM, "//" + txnAccBlock + '/' + txnAccTag));
        pickedUpCcy = getNodeText(selectSingleNode(dbDataDOM, "//" + 'BLK_TRANSACTION_DETAILS/OFFSETCCY'));
    }
    catch (e) {
    }
    return true;
}

//12.0.2_Single_Step_process ends


//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_TRANSACTION_DETAILS__TXNCCY' ;
    var b = 'BLK_TRANSACTION_DETAILS__OFFSETCCY';
	var c = 'BLK_TRANSACTION_DETAILS__OFFSETAMT' ;
	var d = 'BLK_TRANSACTION_DETAILS__TXNAMT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
 		//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_213176251
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends
//FCUBS12.4MCY/VA changes starts
function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
    if (eventElement.name == 'UI_TXN_ACC' || eventElement.name == 'OFFSETCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').oldvalue = "";
  if(eventElement.name == 'UI_TXN_ACC'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'M'))
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(eventElement.id).value;
		}	// 1203_ITR1_18388624
   // if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
       // }
    }
    }
      return true;
}
//FCUBS12.4MCY/VA changes ends