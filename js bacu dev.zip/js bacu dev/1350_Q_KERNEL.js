/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2011  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1350_Q_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 

    Changed By         :  Kundan Verma
    Description        :  Changed language code while searching from ertb_msgs
    Search String      :  FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
****************************************************************************************************************************/


/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
//fnFunctionDefultValues();
debugs("In fnPreLoad aa", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}


var MASKACC = ".nnnnnnnnnnnnnnn";
/*
 * Called to perform MASK ENHANCEMENT CHANGES - fnPreFormat() Action event and
 * this function has to return a success/failure flag to fnPreFormat function.
 * Specific to the functionid.
 */
  function fnPreFormat_KERNEL(obj){

		
		var l_acc_new1='';
		var x = obj.value.length;
		//alert(MASKACC);
		//alert('STR ->'+MASKACC.length);
		//var pmask = MASKACC;
		var l_acc_no=obj.value ;
		var myArr = new Array();
		var pmask = new String();
		pmask=MASKACC;
		var myArracc = new Array();
		var pacc = new String();
		var check = -1;
		check=l_acc_no.indexOf(".");
		
		if(check==-1)
		{
			//document.getElementById("BLK_CLEARING_DETAILS__BENBRANCH").value=document.getElementById("BLK_CLEARING_DETAILS__BENACCOUNT").value.substring(0,3);
			return true;
		}
		
		pacc=l_acc_no;
		var l_acc_new;
		myArrmask = pmask.split(".");
		myArracc = pacc.split(".");

		if (myArracc[0] != "")
		{
			
			showErrorAlerts('BRN-VAL-006');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			
			//alert('Invalid mask');
			return false;
		}

		var s=0;
		var r=0;
		
		for(var k=0;k<myArrmask.length;k++)
		{    
			s=s+1;

		}
		
		for(var l=0;l<myArracc.length;l++) 
		{
			r=r+1;
		}
		//alert('value of s is'+s);
		//alert('value of r is'+r);
		if(s!=r)
		{
			
			showErrorAlerts('BRN-VAL-006');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			
			//alert('Invalid mask');
			return false;
		}

		for(var i=0;i<myArrmask.length;i++)
		{    

			for(var j=0;j<myArracc.length;j++) 
			{
				if(i==j)
				{
					while(myArracc[j].length < myArrmask[i].length) 
					{
						myArracc[j] = "0" + myArracc[j];
					}
				}
			}	
		
		}
		
		var l_acc_new1='';

		for(var k=0;k<myArracc.length;k++)
		{
			l_acc_new1=l_acc_new1 + myArracc[k];
		}
	
		obj.value=l_acc_new1;
			//document.getElementById("BLK_CLEARING_DETAILS__BENBRANCH").value=document.getElementById("BLK_CLEARING_DETAILS__BENACCOUNT").value.substring(0,3);
	return true;	

}




function fnFunctionDefultValues()
{
try {   
	 document.getElementById('BLK_CUST_ACCOUNT__BRN_CODE').value = g_txnBranch; //dlgArg.mainWin.frames['Global'].CurrentBranch;
} catch(e) {}
}
