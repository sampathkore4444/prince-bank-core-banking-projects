/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2006 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.

** Modified By         : Vrishti Ghosh
** Modified On         : 30-Mar-2017
** Modified Reason     : Till id has been added to pass the bind variable in the query.
** Search String       : RETRO_12_3_25399514 
------------------------------------------------------------------------------------------
*/
/*
------------------------------------------------------------------------
*/
function fnPreSave_KERNEL() {
			   
	var totalRows = document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows.length;
	try{
	  for(var i=0; i< totalRows; i++){
       document.getElementById("ISSCODE")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSUER_CODE").value;
	   document.getElementById("ISSBRN")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSBRN").value;
	   document.getElementsByName("INOUTIND")[i].value = 'O';	    
	  }
	}catch(e){}
	try{
		for(var i=0; i< totalRows; i++){
			document.getElementsByName("ENDNO")[i].value = Number(document.getElementsByName("STARTNO")[i].value) +
															Number(document.getElementsByName("TCCOUNT")[i].value)-1;
		}
	}catch(e){}
 appendTabData(document.getElementById('TBLPageTAB_TCDENOM'));
		return true;	
}
function fnPostAddRow_BLK_TCDENOMINATION_DETAILS_KERNEL()
{

	 var len = document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows.length;

	 for(var i = 0;i < len; i++)
	  {
		if(document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[0].getElementsByTagName("INPUT")[0]){
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[14].getElementsByTagName("INPUT")[0].value = dataObj.tillid;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[3].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__INSTRCCY").value;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[11].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSUER_CODE").value;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[12].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSBRN").value;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[10].getElementsByTagName("INPUT")[0].value = 'OUT';
			document.getElementsByName("TILL_ID")[i].value =  dataObj.tillid; //RETRO_12_3_25399514 
		}	
	  }
	return true;
}
