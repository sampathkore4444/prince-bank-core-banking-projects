/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1010_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : Kiran Chandrappa
**  Last modified on   : 29-05-2013
**  Reason             : To capture the Beneficiary name into narrative field
**  Search String      : 9NT1587_12.0.2.0.0_Narrative_Changes

**  Last Modified By   : Geetanjali
**  Last modified on   : 03-Apr-2017
**  Reason             : MCY/VA changes
**  Search String      : FCUBS12.4MCY/VA changes 

**  Last Modified By   : Geetanjali
**  Last modified on   : 25-Apr-2017
**  Reason             : 500 ERROR ON TAB OUT FOR FOR NON REAL ACCOUNT VAM 
**  Search String      : bug#25940475 
****************************************************************************************************************************/
//OFAC Black List Check FC 11.1 Starts 
var defaultVal = ""; //9NT1587_12.0.2.0.0_Narrative_Changes
function fnPreLoad_CVS_OFACM_KERNEL(screenArgs){
	
	screenArgs['REQXML']='';//Prepare the request xml in the format of OFAC accepeted Requested xml and pass as
	// screen argument to CSCOFACM

return true;
}
//OFAC Black List Check FC 11.1 Ends 

//9NT1587_12.0.2.0.0_Narrative_Changes Starts
function fnonchangebenf() {
    document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = defaultVal + document.getElementById("BLK_CHEQUE_DETAILS__BENFNAME").value;
}

function fnPreNew_KERNEL() {
try{
defaultVal = document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").getAttribute("DEFAULT")
}
catch(e){}
return true;
}

function fnPreLoad_KERNEL() {
try{
defaultVal = document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").getAttribute("DEFAULT")
}
catch(e){}
return true;
}
//9NT1587_12.0.2.0.0_Narrative_Changes Ends


//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_TRANSACTION_DETAILS__ACCCY' ;
    var b = 'BLK_TRANSACTION_DETAILS__INSTRCCY';
	var c = 'BLK_TRANSACTION_DETAILS__INSTRAMT' ;
	var d = 'BLK_TRANSACTION_DETAILS__ACYAMOUNT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
 		//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_213176251
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends
function fnPostLoad_KERNEL() {

	debugs("In fnPostLoad", "A");
	document.getElementById("BLK_TRANSACTION_DETAILS__MULCHGCY").value = mainWin.Lcy;
	return true;
}

//FCUBS12.4MCY/VA changes starts
function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
    if (eventElement.name == 'UI_AC_NO' || eventElement.name == 'INSTRCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/INSTRCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/INSTRCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__INSTRCCY').oldvalue = "";
  if(eventElement.name == 'UI_AC_NO'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'M'))
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__ACNO").value = document.getElementById(eventElement.id).value;
		}	// 1203_ITR1_18388624
        if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/INSTRCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_AC_NO")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
							//	document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = '';    //Bug#25817723 added bug#25940475 
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                        document.getElementById("BLK_TRANSACTION_DETAILS__ACBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/ACBRN"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__ACCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/ACCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__ACNO").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/ACNO"));
						
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    }
      return true;
}
function fnResolveVirAcc1(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
                var eventElement = event.srcElement || event.target;
    if (eventElement.name == 'UI_CHARGE_ACCOUNT' || eventElement.name == 'INSTRCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/INSTRCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/INSTRCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL_TY")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__INSTRCCY').oldvalue = "";
  if(eventElement.name == 'UI_CHARGE_ACCOUNT'  && (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL_TY")) != 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL_TY")) != 'M'))
 
                                {
                                                gViraccno = false;
                                                document.getElementById("BLK_TRANSACTION_DETAILS__CHGACC").value = document.getElementById(eventElement.id).value;
                                }              
        if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/INSTRCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_CHARGE_ACCOUNT")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL_TY")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL_TY")) == 'M') {
                    gViraccno = true; 
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);
                        document.getElementById("BLK_TRANSACTION_DETAILS__ACBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/ACBRN"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__ACCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/ACCCY"));
                        document.getElementById("BLK_TRANSACTION_DETAILS__CHGACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/ACNO"));
                                                                                                
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    }
      return true;
}
//FCUBS12.4MCY/VA changes ends