/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2018, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 8301_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~NARRATIVE~PAYBANK~INSTRTYPE~INSTRCCY~INSTRAMT~EXCHRATE~TXNDATE~ACCCY~ACTAMT~TCYTOTCHGAMT~INSTRSTAT~INSTRNO~INSTRDATE~MANUAL_INPUT~DELIVERY_MODE~DELIVERY_ADD1~DELIVERY_ADD2~DELIVERY_ADD3~DELIVERY_ADD4~DENMAMT2~BANKNAME","BLK_CHEQUE_DETAILS":"PAYBRN~OTHERDETLS1~CHQNO~BENFNAME~BENFADDR1~BENFADDR2~BENFADDR3~OTHERDETLS2~OTHERDETLS3~OTHERDETLS4~OTHERDETLS5~OTHERDETLS6~OTHERDETLSTYPE1~OTHERDETLSTYPE2~OTHERDETLSTYPE3~OTHERDETLSTYPE4~OTHERDETLSTYPE5~OTHERDETLSTYPE6~PAYBRNAME"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~NARRATIVE~PAYBANK~INSTRTYPE~INSTRCCY~INSTRAMT~EXCHRATE~TXNDATE~ACCCY~ACTAMT~TCYTOTCHGAMT~INSTRSTAT~INSTRNO~INSTRDATE~MANUAL_INPUT~DELIVERY_MODE~DELIVERY_ADD1~DELIVERY_ADD2~DELIVERY_ADD3~DELIVERY_ADD4~DENMAMT2~BANKNAME</FN>'; 
msgxml += '      <FN PARENT="BLK_TRANSACTION_DETAILS" RELATION_TYPE="1" TYPE="BLK_CHEQUE_DETAILS">PAYBRN~OTHERDETLS1~CHQNO~BENFNAME~BENFADDR1~BENFADDR2~BENFADDR3~OTHERDETLS2~OTHERDETLS3~OTHERDETLS4~OTHERDETLS5~OTHERDETLS6~OTHERDETLSTYPE1~OTHERDETLSTYPE2~OTHERDETLSTYPE3~OTHERDETLSTYPE4~OTHERDETLSTYPE5~OTHERDETLSTYPE6~PAYBRNAME</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_CHEQUE_DETAILS" : "BLK_TRANSACTION_DETAILS~1"}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_CHEQUE_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 8301.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 8301.js, in "BlockName__FieldName" format
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__PAYBANK__LOV__BLK_TRANSACTION_DETAILS__PAYBANK__3":["BLK_TRANSACTION_DETAILS__PAYBANK~BLK_TRANSACTION_DETAILS__BANKNAME~","BLK_TRANSACTION_DETAILS__INSTRTYPE!","N~N",""],"BLK_TRANSACTION_DETAILS__INSTRCCY__LOV_CCY":["BLK_TRANSACTION_DETAILS__INSTRCCY~~","","",""],"BLK_TRANSACTION_DETAILS__ACCCY__LOV_CCY":["BLK_TRANSACTION_DETAILS__ACCCY~~","","",""],"BLK_CHEQUE_DETAILS__PAYBRN__LOV__BLK_CHEQUE_DETAILS__PAYBRN__4":["BLK_CHEQUE_DETAILS__PAYBRN~BLK_CHEQUE_DETAILS__PAYBRNAME~","BLK_TRANSACTION_DETAILS__INSTRTYPE!~BLK_TRANSACTION_DETAILS__PAYBANK!~BLK_TRANSACTION_DETAILS__INSTRCCY!~BLK_TRANSACTION_DETAILS__PAYBANK!~BLK_TRANSACTION_DETAILS__INSTRTYPE!~BLK_TRANSACTION_DETAILS__INSTRCCY!","N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CHCD~BLK_TRANSACTION_DETAILS","MDCD~BLK_TRANSACTION_DETAILS","UDCD~BLK_TRANSACTION_DETAILS","DMCD~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("ISTMS_INSTR_TXN.XREF=CSTBS_WBCHARGE_DETAILS.XREF","ISTMS_INSTR_TXN.XREF=MIVWS_MIS_DETAILS.XREF","ISTMS_INSTR_TXN.XREF=UDVWS_UDF_DETAILS.XREF","ISTMS_INSTR_TXN.XREF=CSTBS_WBDENOM_MASTER.XREF"); 

 var CallRelatType= new Array("N","1","N","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["8301"]="KERNEL";
ArrPrntFunc["8301"]="";
ArrPrntOrigin["8301"]="";
ArrRoutingType["8301"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["8301"]="N";
ArrCustomModified["8301"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
var scrArgSource = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
var scrArgVals = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
var dpndntOnSrvs = {"CHCD":"","MDCD":"","UDCD":"","DMCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------