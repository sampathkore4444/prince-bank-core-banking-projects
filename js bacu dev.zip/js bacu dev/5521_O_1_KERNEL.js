/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/***************************************************************************************************************************
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 5521_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */


function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	var v_plus_button = document.getElementById("cmdAddRow_BLK_CLEARING_DETAILS");
	v_plus_button.disabled = "disabled";
	v_plus_button.style.display = "none";

	/*try{
	   var clearing_rows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows;
	 document.getElementsByName('ENDPOINT1')[0].value=clearing_rows[0].cells[12].getElementsByTagName("INPUT")[0].value;
	 document.getElementsByName('TXNCCY1')[0].value=clearing_rows[0].cells[15].getElementsByTagName("INPUT")[0].value ;
	 }catch(e) { }*/
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
//9NT1466_FCUBS_11.3.1_DeCentralised_and_Offline_Branch STARTS
function fnAddRowsWithDefault() {
	fnAddRows1_JS(); 
	//var l_brn=document.getElementById('BLK_TRANSACTION_DETAILS__BRN').value;
	var l_rowCnt =document.getElementById('BLK_TRANSACTION_DETAILS__ROWSTA').value;

	if (!l_rowCnt) {
		
		showErrorAlerts('BRN-VAL-007');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
		
		//alert("Enter the Number of Entries To be Added");
		return false;
	}
	return;
	/*tempAction = dataObj.action;
	fnAddRows0();
	dataObj.action	= tempAction;*/
	//document.getElementById('BLK_TRANSACTION_DETAILS__BRN').value=l_brn;
}

function fnAddRows0() {

	window.focus();
	appendData();
	dataObj.action = 'ADDNEWROWS';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);

	var v_xml_string = getXMLString(fcjResponseDOM);
	if (fcjResponseDOM && v_xml_string.length > 0) {
		dataObj = new dataObject(v_xml_string);
		var returnValue = fnHandleError();
	} else {
		alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
		return;
	}
}


function fnAddRows1_JS() {

	var l_rowCnt =document.getElementById('BLK_TRANSACTION_DETAILS__ROWSTA').value;
	for(i = 0; i < l_rowCnt; i++) {
	
		fnAddRow("BLK_CLEARING_DETAILS");
		//ankit starts
		//document.getElementsByName("BLK_CLEARING_DETAILS__ENTRYNO")[i].value = 1;
	//ankit ends
	}
	fnPostAddRow_BLK_CLEARING_DETAILS_KERNEL();
	
}
function fnPostAddRow_BLK_CLEARING_DETAILS_KERNEL() {

	appendData(document.getElementById("TBLPageTAB_CHEQUES"));
	var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));
	//clgNodes.length = 1;
	for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENTRYNO"), new String(l_Cnt + 1));
	}

	var pageNo = Number(document.getElementById("CurrPage__BLK_CLEARING_DETAILS").innerHTML) - 1;
    var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
	var entryNo;
    for(var i=0; i< totalRows; i++){
		entryNo = new String(pageNo + i + 1);
		document.getElementsByName("ENTRYNOI")[i].value = entryNo;
		document.getElementsByName("ENTRYNO")[i].value = entryNo;
		document.getElementsByName("PRODUCT")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__UI_PRODUCT").value;
		document.getElementsByName("ENDPOINT")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__ENDPOINT1").value;
		document.getElementsByName("TXNCCY")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value;
		document.getElementsByName("INSTRCCY")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value;
    }
    return true;
}
function fnPostDeleteRow_BLK_CLEARING_DETAILS_KERNEL() {

	appendData(document.getElementById("TBLPageTAB_CHEQUES"));
	var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));
	for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENTRYNO"), new String(l_Cnt + 1));
	}

	var pageNo = Number(document.getElementById("CurrPage__BLK_CLEARING_DETAILS").innerHTML) - 1;
    var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
	var entryNo;
    for(var i=0; i< totalRows; i++){
		entryNo = new String(pageNo * PAGE_SIZE + i + 1);
		document.getElementsByName("ENTRYNOI")[i].value = entryNo;
		document.getElementsByName("ENTRYNO")[i].value = entryNo;
    }
    return true;
}
//9NT1466_FCUBS_11.3.1_DeCentralised_and_Offline_Branch ENDS
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	//Copy from Other Blocks
    //alert('Am here in Presave');
   // alert('totalRows' + totalRows);
	//alert('rowindex' + rowindex);
//ankit starts
	var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_CLEARING_DETAILS'));
	for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENTRYNO"), new String(l_Cnt + 1));
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "TXNCCY"), document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value);
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "INSTRCCY"), document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value);
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "TXNDATE"), document.getElementById("BLK_TRANSACTION_DETAILS__TXNDATE1").value);
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENDPOINT"), document.getElementById("BLK_TRANSACTION_DETAILS__ENDPOINT1").value);
	}
//ankit ends
    var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
	//alert('totalRows' + totalRows);
    for(var i=0; i< totalRows; i++){
		//alert('INSTRUMENT CCY1'+document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value);
		document.getElementById("TXNCCY")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value;
	    document.getElementById("INSTRCCY")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value;
	    document.getElementById("TXNDATE")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNDATE1").value;
	    document.getElementById("ENDPOINT")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__ENDPOINT1").value;
    }
	appendTabData(document.getElementById('TBLPageTAB_CHEQUES'));

	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

		return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	
	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}

 function fnFunctionDefultValues() {
   //alert('in setDefaultValues ');
	try{
	   var clearing_rows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows;
	 document.getElementsByName('ENDPOINT1')[0].value=clearing_rows[0].cells[12].getElementsByTagName("INPUT")[0].value;
	 document.getElementsByName('TXNCCY1')[0].value=clearing_rows[0].cells[15].getElementsByTagName("INPUT")[0].value ;
	 }catch(e) { }
 }
