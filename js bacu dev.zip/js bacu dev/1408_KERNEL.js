/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2014  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  Last Modified By   :  Achelal
**  Last modified on   :  15-Feb-2012
**  Search String       :  9nt1501 usability changes
**  Reason             :  9nt1501 usability changes

**  Last Modified By   :  Achelal
**  Last modified on   :  15-Feb-2012
**  Search String      : 9nt1501 itr2 sfr#14046733
**  Reason             :  9nt1501 itr2 usability change sfr#14046733
	
**  Last Modified By   :  Sanath
**  Last modified on   :  28-Feb-2012
**  Search String      : FCUBS_12.0.1_RETRO_16414767
**  Reason             :  UDF TYPE 

** Last Modified By    : Ankit T
** Last modified on    : 25-Aug-2014
** Reason              : src.element was not working in Firefox.
** Search String       : FCUBS_12.0.3_TUN_19489533

**  Last Modified By   : Mohit Ojha
**  Last modified on   : 07-Apr-2017
**  Reason             : MCY/VA changes
**  Search String      : FCUBS12.4MCY/VA changes

**  Last Modified By   : Vishalakshi N
**  Last modified on   : 10-Jan-2018
**  Reason             : Fix given to enable or disable transaction currency field based on account number type.
						Transaction currency will be enabled for virtual accounts and same will be disabled for normal customer accounts type.
						GL currency will enabled for all account types.
**  Search String      : FCUBS124_UNICREDIT_BULBANK_27360072
----------------------------------------------------------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;
var hisC1='###';
var hisC2='$$$';
var hisAmount=0;
//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

//9nt1501 itr2 sfr#14046733 change
//document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value=mainWin.Lcy;
	document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value='Miscellaneous Customer Credit';
    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	debugs("In fnPreSave", "A");	
	var isValid = true;
	if(!fnValidate())
        return false;
	
	debugs("In fnPreSave", "A");	
// 1203_ITR1_18388624 starts 
	try
  {
	if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != document.getElementById("BLK_TRANSACTION_DETAILS__VIRACCNO").value){
		gViraccno = true;		
     }
  else {
  			gViraccno = false;
	   }
  }
catch (e)
{
}
// 1203_ITR1_18388624 ends 
	
	return isValid;	
	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}



function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}



function fnPreAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_MIS_KERNEL() {
    return true;
}
function fnInTab_TAB_MIS_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_MIS_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}


function fnPreAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_UDF_KERNEL() {
    return true;
}
//FCUBS_12.0.1_RETRO_16414767
/*function fnInTab_TAB_UDF_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}*/
//FCUBS_12.0.1_RETRO_16414767
function fnOutTab_TAB_UDF_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}


function fnFunctionDefultValues() {
    try
    {
        if (document.getElementsByName("OFFSETBRN")[0].value == '') document.getElementsByName("OFFSETBRN")[0].value = mainWin.CurrentBranch;
    } 
	catch(e)    {}
	
	return true;
}

//9nt1501 usability changes starts
function fnCalcExchAmt(event)
{
if (hisC1!=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value || hisC2!=document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value || hisAmount!=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMT").value) {
if (document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value !="" && document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value !="" && document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").value != "")
 {

if(document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value==document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value) {
	document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMTI").value;
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").focus();
}
else
    {
	document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=0;
	var tempAction = dataObj.action;
	appendData();
	dataObj.action = 'CALCEXCHAMT';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	local_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
		try {	
		if(local_fcjResponseDOM) {		
		var msgStatus   =getNodeText( selectSingleNode(local_fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') {
		showErrorAlerts('CL-COMM-04');
		self.close();
		}
		else{
		document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=getNodeText(selectSingleNode(fnGetDataXMLFromFCJXML(local_fcjResponseDOM, 1), "//BLK_TRANSACTION_DETAILS/TXNAMT"));	
	    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").focus();
		}
		}
	}catch(e){
	showErrorAlerts('GW-REOPR-01')	;
	}

	dataObj.action	= tempAction;


	}	
	hisC1=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	hisC2=document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value;
	hisAmount=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMT").value;
	document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMTI").focus();
	document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").focus();
 }
 }
	return true;
	}
//9nt1501 usability changes ends

//9NT1620_1203_INTERNAL_18272320  starts

function fnPreProcessFields_KERNEL(e){
        appendData();
return true;
}
//9NT1620_1203_INTERNAL_18272320  ends
//FCUBS12.4MCY/VA changes starts
function fnResolveVirAcc(event) {
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM;
   // if (event.srcElement.name == 'VIRACCNO' || event.srcElement.name == 'TXNCCY') {//FCUBS_12.0.3_TUN_19489533
	if (getEventSourceElement(event).name == 'UI_TXN_ACC' || getEventSourceElement(event).name == 'OFFSETCCY') {//FCUBS_12.0.3_TUN_19489533
        appendData();
        //if (document.getElementById(event.srcElement.id) != undefined && document.getElementById(event.srcElement.id).oldvalue != document.getElementById(event.srcElement.id).value) {//FCUBS_12.0.3_TUN_19489533
		if (document.getElementById(getEventSourceElement(event).id) != undefined && document.getElementById(getEventSourceElement(event).id).oldvalue != document.getElementById(getEventSourceElement(event).id).value) {//FCUBS_12.0.3_TUN_19489533
        //if(event.srcElement.name == 'VIRACCNO'  && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/ACCTYPE")) != 'V')//FCUBS_12.0.3_TUN_19489533
		if(getEventSourceElement(event).name == 'UI_TXN_ACC'  && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) != 'V')//FCUBS_12.0.3_TUN_19489533
		// 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			//document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(event.srcElement.id).value;//FCUBS_12.0.3_TUN_19489533
			document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById(getEventSourceElement(event).id).value;//FCUBS_12.0.3_TUN_19489533
		}	// 1203_ITR1_18388624
             if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/OFFSETCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    tempDOM = fnGetDataXMLFromFCJXML(tempDOM, 1);
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
      
                      
                            var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
								document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = '';    //Bug#25817723 added
                            }
                            else {
                                temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
                                document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));
                                document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"));
                                document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));

                            }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
	//FCUBS124_UNICREDIT_BULBANK_27360072 starts
   /*if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M')
        fnEnableElement(document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY'));
    else 
        fnDisableElement(document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY'));
        
        
    }*/
	if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M')
        fnEnableElement(document.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY'));
    else 
        fnDisableElement(document.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY'));
     
    }
	//FCUBS124_UNICREDIT_BULBANK_27360072 ends
    return true;
}
//FCUBS12.4MCY/VA changes ends
