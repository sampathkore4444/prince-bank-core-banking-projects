/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2011  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1411_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/
  function fnPostLoad_KERNEL()
	{

disableForm();
	document.getElementById("BLK_DENOMINATION_SE__DENOMTOTALI").style.visibility="hidden";
    document.getElementById("BLK_DENOMINATION_SE__CDCCY").style.visibility="hidden";
	document.getElementById("BLK_DENOMINATION_SE__DENOMTOTALI").previousSibling.style.visibility="hidden";
	document.getElementById("BLK_DENOMINATION_SE__CDCCY").previousSibling.style.visibility="hidden";
	document.getElementById("BLK_DENOMINATION_SE__PREFDNM").style.visibility="hidden";
    document.getElementById("BLK_DENOMINATION_SE__DEFAULT").style.visibility="hidden";
    document.getElementById("BLK_DENOMINATION_SE__CLEAR").style.visibility="hidden";
	document.getElementById("BLK_DENOMINATION_SE__PREFDNM").previousSibling.style.visibility="hidden";
	document.getElementById("BLK_DENOMINATION_SE__CASHAMTI").style.visibility="hidden"; //9NT1525_1203_IGHSPBL_19206879 added
	document.getElementById("BLK_DENOMINATION_SE__CASHAMTI").previousSibling.style.visibility="hidden"; //9NT1525_1203_IGHSPBL_19206879 added
    //document.getElementById("BLK_DENOMINATION_SE__DEFAULT")
    //document.getElementById("BLK_DENOMINATION_SE__CLEAR")
	
	return true;
	}
	
