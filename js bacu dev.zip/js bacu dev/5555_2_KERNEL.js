/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 5555_2_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
**Changed By         :  SwathyR
**Description         :  To disable add and delete row button in enrich stage
**Search String     :  FCUBS 11.3.1 - Usability Item VOL1 changes

**Changed By        :  Deeksha
**Description       :  Assignment of total amt 
**Search String     :  9NT1606_18798863_19077390 

**Changed By        :  Deeksha
**Description       :  Assignment of total amt 
**Search String     :  9NT1606_18670377_19077938 
****************************************************************************************************************************/

function fnCalculateTotAmt() {
	try {
		var totalAmt = 0;
		var l_Cnt = 0;
		appendData(document.getElementById("TBLPageTAB_MAIN"));
		var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_BC_DD_DETAILS'));
		if(clgNodes) {
			for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
				var l_Node = clgNodes[l_Cnt];
				var amt = getNodeText(selectSingleNode(l_Node, "INSTRAMT"));
				if (amt && !isNaN(amt))
					totalAmt = parseFloat(totalAmt) + parseFloat(amt);
			}
		}
		document.getElementsByName('TOTAMTI')[0].value = totalAmt;
		//document.getElementsByName('TOTAMT')[0].value = totalAmt;
		document.getElementById('BLK_BC_DD_MASTER__TOTAMT').value = totalAmt;//9NT1606_18670377_19077938
	} catch (ex) {
	}
}

//FCUBS 11.3.1 - Usability Item VOL1 changes starts
function fnPostLoad_KERNEL() {
	// No more [+,-] button.
	var v_minus_button = document.getElementById("cmdDelRow_BLK_BC_DD_DETAILS");
          var v_plus_button = document.getElementById("cmdAddRow_BLK_BC_DD_DETAILS");
          v_minus_button.disabled = "disabled";
	v_plus_button.disabled = "disabled";
          v_minus_button.style.display = "none";
	v_plus_button.style.display = "none";
	//FCUBS 11.3.1 - Usability Item VOL1 changes ends
	fnCalculateTotAmt();
	return true;
}

//9NT1606_18798863_19077390 starts
function fnPreSave_KERNEL() {	
 fnCalculateTotAmt();
 return true;
}
//9NT1606_18798863_19077390 ends
