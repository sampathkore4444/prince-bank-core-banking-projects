/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2014 - 2015  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : Ankit
**  Date of creation   : 
**  File Name          : 1410_KERNEL.js
**  Purpose            : Released as part of FDD_FCUBS 12.1.RT_InterBrnCshPickupReq
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : TEJA
**  Last modified on   : 10-07-2015
**  Search Tag         : FCUBS121_ITR_21362250
**  Reason             : Validation for 1410
****************************************************************************************************************************/

function fnPostLoad_KERNEL() {
    if (document.getElementById("BLK_INTRA_BRANCH__FROM_BRANCH").value ==""){
		document.getElementsByName("FROM_BRANCH")[0].value = mainWin.CurrentBranch;
		document.getElementsByName("FROM_BRANCH_NAME")[0].value = mainWin.CurrentBranchName;
		document.getElementsByName("FROM_VAULT_TIL")[0].value = dataObj.tillid;
		}
	return;
}
//FCUBS121_ITR_21362250
function fnPreSave_KERNEL() {
		
	if(document.getElementsByName("FROM_VAULT_TIL")[0].value!=dataObj.tillid)
	{
	
	
    //var alertResp = fnBuildAlertXML('RT-INTR-01~RT-INTR-02', 'E', '', document.getElementsByName("FROM_VAULT_TIL")[0].value+"~"+document.getElementsByName("FROM_VAULT_TIL")[0].value); //12.1_ITR1_21604148
	var alertResp = fnBuildAlertXML('RT-INTR-01~RT-INTR-02', 'E', '', dataObj.tillid+"~"+dataObj.tillid); //12.1_ITR1_21604148
    mask();
    showBranchAlerts(alertResp, 'E');
	 
	  alertAction = "UNMASK";
      return false;
	}
	return true;
}
//FCUBS121_ITR_21362250 ENDS