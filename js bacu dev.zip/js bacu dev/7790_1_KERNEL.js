/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*----------------------------------------------------------------------------------------------------
**
** File Name    : 7790_1_KERNEL.js
**
** Module       : FCJWeb
**
**  This source is part of the FLEXCUBE Software System and is copyrighted by 
**  Oracle Financial Services Software Limited.
**  
**  All rights reserved.  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle Financial Services Software Limited.
**  
**  Oracle Corporation
**  World Headquarters
**  500 Oracle Parkway
**  Redwood Shores, CA 94065
**  U.S.A.
**  
**  Copyright � 2008- 2010 by Oracle Financial Services Software Limited.
**  Oracle Financial Services Software Limited.

** Modified By         : Sriraam S
** Modified On         : 09-Jan-2013
** Modified Reason     : On change of TxnAmount / Exchange Rate during Enrich Stage, Recalculate click mandated in RT Screens
** Search String       : 9NT1525_120_16066792
----------------------------------------------------------------------------------------------------
*/
/*disable the toolbar on launch*/
function fnPostNew_KERNEL() {
    mainWin.disableAllButtons();
    return true;    	
}
/*disable the toolbar on focus*/
//9NT1525_120_16066792 starts
//function fnPostFocus_KERNEL()
function fnPostFocusWB_KERNEL(){
//9NT1525_120_16066792 ends
	mainWin.disableAllButtons();
    return true;
}
