/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1000_Q_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"BRN~XREF~PRD~TXNBRN~TXNACC~TXNCCY~TXNAMT~OFFSETCCY~OFFSETAMT~XRATE~LCYAMT~TXNDATE~VALDATE~RELCUST~NARRATIVE~AUTHSTAT~ESN~EVNTCD~MODULE~TXNTRN~OFFSETBRN~OFFSETACC~OFFSETTRN~REMACCOUNT~REMBANK~REMBRANCH~ROUTINGNO~ENDPOINT~SERIALNO~ROUTECODE~DRINSTCD~CRINSTCD~REPREASON~TRACKREVERSE~MAKERID~MAKERSTAMP~CHECKERID~CHECKERSTAMP~MODNO~RECSTAT~SCODE~DRACC~FTPRBLM~THEIRCHGS~THEIRCHGS1~THEIRCHGS2~THEIRCHGS3~THEIRCHGS4~THEIRACC~THEIRACC1~THEIRACC2~THEIRACC3~THEIRACC4~TIMERECV~CHRACC~ACCTITLE1~ACCTITLE2~ACTAMT~BATCHNO~TCYTOTCHGAMT~TXNDRCR~BOOKDATE~TRANCOUNT~DENMAMT1~DENMAMT2~DENMCCY1~DENMCCY2~TCYCHGAMT~TCYCHGAMT1~TCYCHGAMT2~TCYCHGAMT3~TCYCHGAMT4~LCYCHGAMT~LCYCHGAMT1~LCYCHGAMT2~LCYCHGAMT3~LCYCHGAMT4~CHGACYXRATE~CHGACYXRATE1~CHGACYXRATE2~CHGACYXRATE3~CHGACYXRATE4~CHGLCYXRATE~CHGLCYXRATE1~CHGLCYXRATE2~CHGLCYXRATE3~CHGLCYXRATE4~FT~CALCHG~OFFSETLCYAMT~COUNTRY~TOTIL~CCYCODE~LCYTOTCHGAMT~UTLBNF1~UTLBNF2~UTLBNF3~UTLBNF4~UTLBNF5~AWI1~AWI2~AWI3~AWI4~AWI5"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

 var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">BRN~XREF~PRD~TXNBRN~TXNACC~TXNCCY~TXNAMT~OFFSETCCY~OFFSETAMT~XRATE~LCYAMT~TXNDATE~VALDATE~RELCUST~NARRATIVE~AUTHSTAT~ESN~EVNTCD~MODULE~TXNTRN~OFFSETBRN~OFFSETACC~OFFSETTRN~REMACCOUNT~REMBANK~REMBRANCH~ROUTINGNO~ENDPOINT~SERIALNO~ROUTECODE~DRINSTCD~CRINSTCD~REPREASON~TRACKREVERSE~MAKERID~MAKERSTAMP~CHECKERID~CHECKERSTAMP~MODNO~RECSTAT~SCODE~DRACC~FTPRBLM~THEIRCHGS~THEIRCHGS1~THEIRCHGS2~THEIRCHGS3~THEIRCHGS4~THEIRACC~THEIRACC1~THEIRACC2~THEIRACC3~THEIRACC4~TIMERECV~CHRACC~ACCTITLE1~ACCTITLE2~ACTAMT~BATCHNO~TCYTOTCHGAMT~TXNDRCR~BOOKDATE~TRANCOUNT~DENMAMT1~DENMAMT2~DENMCCY1~DENMCCY2~TCYCHGAMT~TCYCHGAMT1~TCYCHGAMT2~TCYCHGAMT3~TCYCHGAMT4~LCYCHGAMT~LCYCHGAMT1~LCYCHGAMT2~LCYCHGAMT3~LCYCHGAMT4~CHGACYXRATE~CHGACYXRATE1~CHGACYXRATE2~CHGACYXRATE3~CHGACYXRATE4~CHGLCYXRATE~CHGLCYXRATE1~CHGLCYXRATE2~CHGLCYXRATE3~CHGLCYXRATE4~FT~CALCHG~OFFSETLCYAMT~COUNTRY~TOTIL~CCYCODE~LCYTOTCHGAMT~UTLBNF1~UTLBNF2~UTLBNF3~UTLBNF4~UTLBNF5~AWI1~AWI2~AWI3~AWI4~AWI5</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1000_Q.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1000_Q.js, in "BlockName__FieldName" format
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_TRANSACTION_DETAILS":["ACCTITLE1","ACCTITLE2","ACTAMT","AUTHSTAT","AWI1","AWI2","AWI3","AWI4","AWI5","BATCHNO","BOOKDATEI","BRN","CALCHG","CCYCODE","CHECKERID","CHECKERSTAMP","CHGACYXRATE","CHGACYXRATE1","CHGACYXRATE2","CHGACYXRATE3","CHGACYXRATE4","CHGLCYXRATE","CHGLCYXRATE1","CHGLCYXRATE2","CHGLCYXRATE3","CHGLCYXRATE4","CHRACC","COUNTRY","CRINSTCD","DENMAMT1","DENMAMT2","DENMCCY1","DENMCCY2","DRACC","DRINSTCD","ENDPOINT","ESN","EVNTCD","FT","FTPRBLM","LCYAMT","LCYCHGAMT","LCYCHGAMT1","LCYCHGAMT2","LCYCHGAMT3","LCYCHGAMT4","LCYTOTCHGAMT","MAKERID","MAKERSTAMP","MODNO","MODULE","NARRATIVE","OFFSETACC","OFFSETAMT","OFFSETBRN","OFFSETCCY","OFFSETLCYAMT","OFFSETTRN","PRD","RECSTAT","RELCUST","REMACCOUNT","REMBANK","REMBRANCH","REPREASON","ROUTECODE","ROUTINGNO","SCODE","SERIALNO","TCYCHGAMT","TCYCHGAMT1","TCYCHGAMT2","TCYCHGAMT3","TCYCHGAMT4","TCYTOTCHGAMT","THEIRACC","THEIRACC1","THEIRACC2","THEIRACC3","THEIRACC4","THEIRCHGS","THEIRCHGS1","THEIRCHGS2","THEIRCHGS3","THEIRCHGS4","TIMERECV","TOTIL","TRACKREVERSE","TRANCOUNT","TXNACC","TXNAMT","TXNBRN","TXNCCY","TXNDATEI","TXNDRCR","TXNTRN","UTLBNF1","UTLBNF2","UTLBNF3","UTLBNF4","UTLBNF5","VALDATEI","XRATE","XREF"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TRANSACTION_DETAILS__PRD__LOV_PRODUCT":["BLK_TRANSACTION_DETAILS__PRD~~","","N~N",""]};
var offlineLovInfoFlds = {"BLK_TRANSACTION_DETAILS__OFFSETCCY__LOV_CURRENCY_LOCAL":["BLK_TRANSACTION_DETAILS__OFFSETCCY~",""]};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_MAIN';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'All';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CCHG~BLK_TRANSACTION_DETAILS","CMIS~BLK_TRANSACTION_DETAILS","CUDF~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("","",""); 

 var CallRelatType= new Array("N","1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1000_Q"]="KERNEL";
ArrPrntFunc["1000_Q"]="1000_2";
ArrPrntOrigin["1000_Q"]="KERNEL";
ArrRoutingType["1000_Q"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1000_Q"]="N";
ArrCustomModified["1000_Q"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {};
var scrArgSource = {};
var scrArgVals = {};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"","NEW":"","MODIFY":"","AUTHORIZE":"","DELETE":"","CLOSE":"","REOPEN":"","REVERSE":"","ROLLOVER":"","CONFIRM":"","LIQUIDATE":"","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------