/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2006 - 2009  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
--------------------------------------------------------------------------------
*/ 

function fnPostLoad_KERNEL() {
     document.getElementById("BLK_CHEQUE_DETAILS__PAYBRN").value = ""; 
    return true;
    	
}

function fnPostNew_KERNEL() {

     document.getElementById("BLK_TRANSACTION_DETAILS__ISSBRN").value = mainWin.CurrentBranch; 
    return true;
    	
}

