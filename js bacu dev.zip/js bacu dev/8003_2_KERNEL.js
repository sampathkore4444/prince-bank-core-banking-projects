/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
--------------------------------------------------------------------------------
*/

function fnPreSave_KERNEL() {
		  
	var totalRows = document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows.length;
	try{
	  for(var i=0; i< totalRows; i++){
       document.getElementById("ISSCODE")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSUER_CODE").value;
	   document.getElementById("ISSBRN")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSBRN").value;
	  //document.getElementsByName("INOUTIND")[i].value = 'P';
	   //document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[10].getElementsByTagName("INPUT")[0].value = 'P';	//9NT1466_FCUBS_11.3.1_DeCentralised_and_Offline_Branch
	  }	         
	}catch(e){}
	try{
		for(var i=0; i< totalRows; i++){
			document.getElementsByName("ENDNO")[i].value = Number(document.getElementsByName("STARTNO")[i].value) +
															Number(document.getElementsByName("TCCOUNT")[i].value)-1;
	}
	}catch(e){}
       appendTabData(document.getElementById('TBLPageTAB_TCDENOM'));
	return true;	
}

function fnPostAddRow_BLK_TCDENOMINATION_DETAILS_KERNEL()
{
  var len = document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows.length;

	 for(var i = 0;i < len; i++)
	  {
		if(document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[0].getElementsByTagName("INPUT")[0]){
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[3].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__INSTRCCY").value;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[11].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSUER_CODE").value;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[12].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSBRN").value;
			//document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[10].getElementsByTagName("INPUT")[0].value = 'OUT';
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[10].getElementsByTagName("INPUT")[0].value = 'P';	//9NT1466_FCUBS_11.3.1_DeCentralised_and_Offline_Branch
		}	
	  }
	return true;        
}
