/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2017, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1350_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_CUST_ACCOUNT":"CHARGES~DENOMAMT~TXNDATE~BRN_CODE~AC_NO~CUST_ID~ACC_DESC~CCY~ACC_AMT~XREF~FCCREF~TXN_AMT","BLK_CUSTACC_PAYOUT":"BRN~ACC~CCY~PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~OFFSET_CCY~PERCENTAGE~NARRATIVE~REF_NO~SEQNO~PAYOUTAMT~INSTNO~WAIVE"};

var multipleEntryPageSize = {"BLK_CUSTACC_PAYOUT" :"15" };

var multipleEntrySVBlocks = "";

var tabMEBlks = {"CVS_MAIN__TAB_PAYOUT":"BLK_CUSTACC_PAYOUT"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_CUST_ACCOUNT">CHARGES~DENOMAMT~TXNDATE~BRN_CODE~AC_NO~CUST_ID~ACC_DESC~CCY~ACC_AMT~XREF~FCCREF~TXN_AMT</FN>'; 
msgxml += '      <FN PARENT="BLK_CUST_ACCOUNT" RELATION_TYPE="N" TYPE="BLK_CUSTACC_PAYOUT">BRN~ACC~CCY~PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~OFFSET_CCY~PERCENTAGE~NARRATIVE~REF_NO~SEQNO~PAYOUTAMT~INSTNO~WAIVE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_CUST_ACCOUNT" : "","BLK_CUSTACC_PAYOUT" : "BLK_CUST_ACCOUNT~N"}; 

 var dataSrcLocationArray = new Array("BLK_CUST_ACCOUNT","BLK_CUSTACC_PAYOUT"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1350.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1350.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_CUST_ACCOUNT__BRN_CODE";
pkFields[0] = "BLK_CUST_ACCOUNT__BRN_CODE";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_CUST_ACCOUNT__AC_NO__LOV_CUSTACC":["BLK_CUST_ACCOUNT__AC_NO~BLK_CUST_ACCOUNT__ACC_DESC~","BLK_CUST_ACCOUNT__BRN_CODE!","N~N",""],"BLK_CUSTACC_PAYOUT__OFFSET_ACC__LOV_OFFSETACC":["BLK_CUSTACC_PAYOUT__OFFSET_ACC~~BLK_CUSTACC_PAYOUT__OFFSET_BRN~","","N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_PAYOUT';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_CUSTACC_PAYOUT");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("MDCD~BLK_CUST_ACCOUNT","UDCD~BLK_CUST_ACCOUNT","DMCD~BLK_CUST_ACCOUNT","CACP~BLK_CUST_ACCOUNT","CCCD~BLK_CUST_ACCOUNT"); 

 var CallFormRelat=new Array("CSTBS_UI_COLUMNS.CHAR_FIELD1=MIVW_MIS_DETAILS.XREF","CSTBS_UI_COLUMNS.CHAR_FIELD1=UDVW_UDF_DETAILS.XREF","CSTBS_UI_COLUMNS.CHAR_FIELD1=CSTB_WBDENOM_MASTER.XREF","CSTBS_UI_COLUMNS.CHAR_FIELD1 = STTMS_CUST_ACCOUNT.BRANCH_CODE AND CSTBS_UI_COLUMNS.CHAR_FIELD2 = STTMS_CUST_ACCOUNT.CUST_AC_NO","CSTBS_UI_COLUMNS.CHAR_FIELD6 = STTMS_ACCLSR_PAYOUT_DTL.EXT_REF_NO"); 

 var CallRelatType= new Array("1","N","N","1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1350"]="KERNEL";
ArrPrntFunc["1350"]="1350_2";
ArrPrntOrigin["1350"]="KERNEL";
ArrRoutingType["1350"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1350"]="N";
ArrCustomModified["1350"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"MDCD":"","UDCD":"","DMCD":"","CACP":"","CCCD":""};
var scrArgSource = {"MDCD":"","UDCD":"","DMCD":"","CACP":"","CCCD":""};
var scrArgVals = {"MDCD":"","UDCD":"","DMCD":"","CACP":"","CCCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"MDCD":"","UDCD":"","DMCD":"","CACP":"","CCCD":""};
var dpndntOnSrvs = {"MDCD":"","UDCD":"","DMCD":"","CACP":"","CCCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------