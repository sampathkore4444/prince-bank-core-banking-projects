/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
function fnPostNew_KERNEL() {

   document.getElementById("BLK_TRANSACTION_DETAILS__ISSBRN").value = mainWin.CurrentBranch;
    return true;
    	
}


//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_TRANSACTION_DETAILS__ACCCY' ;
    var b = 'BLK_TRANSACTION_DETAILS__INSTRCCY';
	var c = 'BLK_TRANSACTION_DETAILS__INSTRAMT' ;
	var d = 'BLK_TRANSACTION_DETAILS__ACYAMOUNT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
			//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_21317625
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends

//12.11_ITR_21543860 STARTS
function fnPreSave_KERNEL() {
	
	var totalRows = document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows.length;
	try{
	  for(var i=0; i< totalRows; i++){
       document.getElementById("ISSCODE")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSUER_CODE").value;
	   document.getElementById("ISSBRN")[i].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSBRN").value;
	   document.getElementsByName("INOUTIND")[i].value = 'O';
	      }
	}catch(e){}
	try{
		for(var i=0; i< totalRows; i++){
			document.getElementsByName("ENDNO")[i].value = Number(document.getElementsByName("STARTNO")[i].value) +
															Number(document.getElementsByName("TCCOUNT")[i].value)-1;
		}
	}catch(e){}
	  appendTabData(document.getElementById('TBLPageTAB_TCDENOM'));
	return true;	
}
function fnPostAddRow_BLK_TCDENOMINATION_DETAILS_KERNEL()
{
	
 var len = document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows.length;

	 for(var i = 0;i < len; i++)
	  {
		if(document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[0].getElementsByTagName("INPUT")[0]){
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[14].getElementsByTagName("INPUT")[0].value = dataObj.tillid;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[3].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__INSTRCCY").value;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[11].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSUER_CODE").value;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[12].getElementsByTagName("INPUT")[0].value = document.getElementById("BLK_TRANSACTION_DETAILS__ISSBRN").value;
			document.getElementById("BLK_TCDENOMINATION_DETAILS").tBodies[0].rows[i].cells[10].getElementsByTagName("INPUT")[0].value = 'OUT';
		}	
	  }
	return true;
}

//12.1_ITR_21543860 ENDS