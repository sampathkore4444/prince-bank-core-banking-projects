/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 3401_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/


function fnShowDefultValues(){
document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = document.getElementById("BLK_SAFEDEPOSIT_DETAILS__SETLACC").value;
document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = document.getElementById("BLK_SAFEDEPOSIT_DETAILS__SETLCCY").value;
document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").value = document.getElementById("BLK_SAFEDEPOSIT_DETAILS__CNTAMT").value;

	return true;
}

function fnPostLoad_KERNEL() {
	gDenomCcy = document.getElementById("BLK_SAFEDEPOSIT_DETAILS__SETLCCY").value;
	fnSetDenomCcy();
	debugs("In fnPostLoad", "A");
	return true;
}
