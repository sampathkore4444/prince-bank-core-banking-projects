/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1311_2_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TD_REDEMPTION":"CUST_ID~CCY~REDEMPTION_AMT~GL_TXN_CCY~GL_TXN_AMT~AC_NO~ACC_DESC~REDEMPTION_MODE~WAVE_PENALTY~GL_EXCH_RATE~XREF~BRN_CODE~ACTION_FLAG~REDEMPTION_BY~FCCREF~TXNDATE~CHARGES~ACC_AMT~TENOR_DD~NEXT_MAT_DATE~TENOR_YY~TENOR_MM~BANK_CD~BANK_TXN_CCY~BANK_EXCH_RATE~BANK_TXN_AMT~BENEF_NAME~PASSPORT_NO~ADDR1~ADDR2~BANK_NARRATIVE~SAVINGS_BRN_CODE~SAVINGS_TXN_CCY~SAVINGS_ACC_NO~SAVINGS_TXN_AMT~SAVINGS_NARRATIVE~CHQ_DATE~ONCE_AUTH~RECORD_STAT~AUTH_STAT~GL_NO~GL_NARRATIVE~MOD_NO~ADDR3~MICR_NO~PAYBRN~LCYTOTCHGAMT~EFFDT"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

 var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TD_REDEMPTION">CUST_ID~CCY~REDEMPTION_AMT~GL_TXN_CCY~GL_TXN_AMT~AC_NO~ACC_DESC~REDEMPTION_MODE~WAVE_PENALTY~GL_EXCH_RATE~XREF~BRN_CODE~ACTION_FLAG~REDEMPTION_BY~FCCREF~TXNDATE~CHARGES~ACC_AMT~TENOR_DD~NEXT_MAT_DATE~TENOR_YY~TENOR_MM~BANK_CD~BANK_TXN_CCY~BANK_EXCH_RATE~BANK_TXN_AMT~BENEF_NAME~PASSPORT_NO~ADDR1~ADDR2~BANK_NARRATIVE~SAVINGS_BRN_CODE~SAVINGS_TXN_CCY~SAVINGS_ACC_NO~SAVINGS_TXN_AMT~SAVINGS_NARRATIVE~CHQ_DATE~ONCE_AUTH~RECORD_STAT~AUTH_STAT~GL_NO~GL_NARRATIVE~MOD_NO~ADDR3~MICR_NO~PAYBRN~LCYTOTCHGAMT~EFFDT</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TD_REDEMPTION" : ""}; 

 var dataSrcLocationArray = new Array("BLK_TD_REDEMPTION"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1311_2.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1311_2.js, in "BlockName__FieldName" format
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TD_REDEMPTION__BANK_TXN_CCY__LOV__BLK_TD_REDEMPTION__BANK_TXN_CCY__1":["BLK_TD_REDEMPTION__BANK_TXN_CCY~","","N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_CHARGE';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CCHG~BLK_TD_REDEMPTION","CMIS~BLK_TD_REDEMPTION","CUDF~BLK_TD_REDEMPTION"); 

 var CallFormRelat=new Array("","",""); 

 var CallRelatType= new Array("N","1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1311_2"]="KERNEL";
ArrPrntFunc["1311_2"]="";
ArrPrntOrigin["1311_2"]="";
ArrRoutingType["1311_2"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1311_2"]="N";
ArrCustomModified["1311_2"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {};
var scrArgSource = {};
var scrArgVals = {};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
callformTabArray['CVS_MAIN__TAB_CHARGE'] = 'CCHG';
callformTabArray['CVS_MAIN__TAB_MIS'] = 'CMIS';
callformTabArray['CVS_MAIN__TAB_UDF'] = 'CUDF';
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"","NEW":"","MODIFY":"","AUTHORIZE":"","DELETE":"","CLOSE":"","REOPEN":"","REVERSE":"","ROLLOVER":"","CONFIRM":"","LIQUIDATE":"","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------