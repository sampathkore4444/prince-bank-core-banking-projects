/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1350_2_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : Ankit Tiwari
**  Last modified on   : 09-May-2013
**  Reason             : To hide the existing charge Tab.
**  Search String 	   : 9NT1587_12.0.2_Acc_Closure_charges

**  Last Modified By   : Ankit Tiwari
**  Last modified on   : 11-July-2013
**  Reason             : The code is added to set the currecny in denomination tab.
**  Search String 	   : 9NT1587_12.0.2_17083253 (Reference bug#14471617)

**  Last Modified By   : Ankit Tiwari
**  Last modified on   : 02-Aug-2013
**  Reason             : The code has been commented as this is handled in back end.
**  Search String 	   : 9NT1587_12.0.2_17254799
****************************************************************************************************************************/
//----------------------
function fnPostLoad_KERNEL() {
	document.getElementById("TAB_CHARGE").style.display="none";//9NT1587_12.0.2_Acc_Closure_charges
	debug(dlgArg.mainWin, "In fnPostLoad", "A");  
	ShowTabData();//FCUBS V UM_10.3.IN.3.0.0.0:sfr#111
	fnSaveAll = fnACWMMDenomval;
	return true;
}


function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
// 9NT1587_12.0.2_17083253  starts
/*
function fnInTab_TAB_DENOM_KERNEL()  {

	showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
*/
function fnInTab_TAB_DENOM_KERNEL()  { 
	fnSetDenomCcy();
	return true;
}
// 9NT1587_12.0.2_17083253 ends
function fnOutTab_TAB_DENOM_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}

function fnShowDefultValues() {
	
     var meblkName = "BLK_CUSTACC_PAYOUT";
     var tableObject;
     var rowList;
     var cashflg;
     var denomAmt = 0.0;

    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

	if (rowList != undefined && rowList.length != 0)
		{
        	for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        		{  			
			cashflg = rowList[rowIndex].cells[1].getElementsByTagName("SELECT")[0].value;
			if (cashflg == 'C')
				{
			 	denomAmt = getCalcAmount(rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value);
				gCashFlag = true; //9NT1374 sfr486 Changes for Cash Validation
				}            

		   	}		
		}  

	// document.getElementById("BLK_CUST_ACCOUNT__DENOMAMT").value =  denomAmt; -- 9NT1587_12.0.2_17254799
	 return true;
}

