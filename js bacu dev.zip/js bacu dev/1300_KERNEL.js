/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2009  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*----------------------------------------------------------------------------------------------------
Modified By : sandeep sambidi
Date Modified: 5-Aug-2013
Search String: 9NT1587_12.0.2_17265484
----------------------------------------------------------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";
  var defaultVal = ""; //9NT1587_12.0.2_17070675
 //9NT1587_12.0.2_17070675 STARTS
function fnonchangebenf() {
	defaultVal = document.getElementById("BLK_CUST_ACCOUNT__NARRATIVE").getAttribute("DEFAULT") //9NT1587_12.0.2_17265484
    document.getElementById("BLK_CUST_ACCOUNT__NARRATIVE").value = defaultVal + document.getElementById("BLK_CUST_ACCOUNT__INSBENFNAME").value;
}
//9NT1587_12.0.2_17070675 ENDS
/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	try{
	defaultVal = document.getElementById("BLK_CUST_ACCOUNT__NARRATIVE").getAttribute("DEFAULT")  //9NT1587_12.0.2_17070675
	}
catch(e){}
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	try{
	defaultVal = document.getElementById("BLK_CUST_ACCOUNT__NARRATIVE").getAttribute("DEFAULT") //9NT1587_12.0.2_17070675
	}
catch(e){}
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}


//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_CUST_ACCOUNT__TXNCCY' ;
    var b = 'BLK_CUST_ACCOUNT__TXNCCY';
	var c = 'BLK_CUST_ACCOUNT__ACTAMT' ;
	var d = 'BLK_CUST_ACCOUNT__ACTAMT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_21317625
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends