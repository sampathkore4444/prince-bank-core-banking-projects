/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1317_2_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TD_REDEMPTION":"BRN_CODE~AC_NO~CCY~CUST_ID~ACC_DESC~ACC_AMT~ACTION_FLAG~TENOR_DD~TENOR_MM~TENOR_YY~NEXT_MAT_DATE~REDEMPTION_MODE~REDEMPTION_AMT~WAVE_PENALTY~XREF~FCCREF~TXNDATE~CHARGES~DENOMAMT~WAIVE_INTEREST~BRANCH_CODE~PRINCIPAL_AMOUNT~INTEREST_RATE~MATURITY_AMOUNT~DEF_MATR_INST~INTEREST_AMOUNT~TAX_AMOUNT~TOT_PAYOUT~ACCOUNT_BALANCE~DENMAMT2~AMT_REDMN~CERTIFICATE_REDMN","BLK_TDREDMPAYOUT_DETAILS":"BRN~ACC~CCY~PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~OFFSET_CCY~PERCENTAGE~REDMAMT~REF_NO~SEQNO~NARRATIVE~WAIVE~INSTNO","BLK_DENOM_DEPOSIT":"CUST_AC_NO1~BRANCH_CODE1~CERTIFICATE_NO~REFERENCE_NO~CERTIFICATE_AMOUNT~BLOCK_OR_REDEM~CERTIFICATE_STATUS"};

var multipleEntryPageSize = {"BLK_TDREDMPAYOUT_DETAILS" :"15" ,"BLK_DENOM_DEPOSIT" :"15" };

var multipleEntrySVBlocks = "";

 var tabMEBlks = {"CVS_MAIN__TAB_PAYOUT":"BLK_TDREDMPAYOUT_DETAILS","CVS_MAIN__TAB_DENOM_DEP":"BLK_DENOM_DEPOSIT"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TD_REDEMPTION">BRN_CODE~AC_NO~CCY~CUST_ID~ACC_DESC~ACC_AMT~ACTION_FLAG~TENOR_DD~TENOR_MM~TENOR_YY~NEXT_MAT_DATE~REDEMPTION_MODE~REDEMPTION_AMT~WAVE_PENALTY~XREF~FCCREF~TXNDATE~CHARGES~DENOMAMT~WAIVE_INTEREST~BRANCH_CODE~PRINCIPAL_AMOUNT~INTEREST_RATE~MATURITY_AMOUNT~DEF_MATR_INST~INTEREST_AMOUNT~TAX_AMOUNT~TOT_PAYOUT~ACCOUNT_BALANCE~DENMAMT2~AMT_REDMN~CERTIFICATE_REDMN</FN>'; 
msgxml += '      <FN PARENT="BLK_TD_REDEMPTION" RELATION_TYPE="N" TYPE="BLK_TDREDMPAYOUT_DETAILS">BRN~ACC~CCY~PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~OFFSET_CCY~PERCENTAGE~REDMAMT~REF_NO~SEQNO~NARRATIVE~WAIVE~INSTNO</FN>'; 
msgxml += '      <FN PARENT="BLK_TD_REDEMPTION" RELATION_TYPE="N" TYPE="BLK_DENOM_DEPOSIT">CUST_AC_NO1~BRANCH_CODE1~CERTIFICATE_NO~REFERENCE_NO~CERTIFICATE_AMOUNT~BLOCK_OR_REDEM~CERTIFICATE_STATUS</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TD_REDEMPTION" : "","BLK_TDREDMPAYOUT_DETAILS" : "BLK_TD_REDEMPTION~N","BLK_DENOM_DEPOSIT" : "BLK_TD_REDEMPTION~N"}; 

 var dataSrcLocationArray = new Array("BLK_TD_REDEMPTION","BLK_TDREDMPAYOUT_DETAILS","BLK_DENOM_DEPOSIT"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1317_2.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1317_2.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TD_REDEMPTION__BRN_CODE";
pkFields[0] = "BLK_TD_REDEMPTION__BRN_CODE";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_PAYOUT';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_TDREDMPAYOUT_DETAILS","BLK_DENOM_DEPOSIT");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CMIS~BLK_TD_REDEMPTION","CUDF~BLK_TD_REDEMPTION","CDNM~BLK_TD_REDEMPTION","CTDR~BLK_TD_REDEMPTION","CCCD~BLK_TD_REDEMPTION"); 

 var CallFormRelat=new Array("","","","CSTBS_UI_COLUMNS.CHAR_FIELD1 = STTMS_CUST_ACCOUNT.BRANCH_CODE AND CSTBS_UI_COLUMNS.CHAR_FIELD2 = STTMS_CUST_ACCOUNT.CUST_AC_NO","CSTBS_UI_COLUMNS.CHAR_FIELD1 = STTMS_CUST_ACCOUNT.BRANCH_CODE AND CSTBS_UI_COLUMNS.CHAR_FIELD2 = STTMS_CUST_ACCOUNT.CUST_AC_NO"); 

 var CallRelatType= new Array("1","N","N","1","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1317_2"]="KERNEL";
ArrPrntFunc["1317_2"]="";
ArrPrntOrigin["1317_2"]="";
ArrRoutingType["1317_2"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1317_2"]="N";
ArrCustomModified["1317_2"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CMIS":"","CUDF":"","CDNM":"","CTDR":"","CCCD":""};
var scrArgSource = {"CMIS":"","CUDF":"","CDNM":"","CTDR":"","CCCD":""};
var scrArgVals = {"CMIS":"","CUDF":"","CDNM":"","CTDR":"","CCCD":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CMIS":"","CUDF":"","CDNM":"","CTDR":"","CCCD":""};
var dpndntOnSrvs = {"CMIS":"","CUDF":"","CDNM":"","CTDR":"","CCCD":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
callformTabArray['CVS_MAIN__TAB_MIS'] = 'CMIS';
callformTabArray['CVS_MAIN__TAB_UDF'] = 'CUDF';
callformTabArray['CVS_MAIN__TAB_DENOM'] = 'CDNM';
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------