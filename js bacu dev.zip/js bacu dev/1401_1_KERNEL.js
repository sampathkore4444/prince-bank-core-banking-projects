/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  Last Moddified By   :  Achelal
**  Last modified on   :  15-Feb-2012
**  Search String       :  9nt1501 usability changes
**  Reason             :  9nt1501 usability changes
**  Last Modified By   :  Prabhakaran J
**  Last modified on   : 10-May-2012
**  Full Version       : FCUBS 12.0.0
**  Reason             :  Focus changed to offset amount on exchange rate calculation
**  Search String : 9NT1501 ITR2 sfr 14005445

**  Last Modified By   :  Sanath
**  Last modified on   :  12-Dec-2012
**  Search String      :  FCUBS_12.0_STORYBOARD_15928835
**  Reason             : The Branch code field should be previous sibling of Account number in the 
screen.

----------------------------------------------------------------------------------------------------
*/	

var hisC1='###';
var hisC2='$$$';
var hisAmount=0;

function fnPostNew_KERNEL() {
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value=mainWin.Lcy;
	document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value='Cash Deposit';
    //document.getElementsByName('NARRATIVE')[0].value = 'Cash Deposit';//EBB542
    return true;
    	
}

function fnAssignTxnCcy(p_acc_ccy){//EBB201 11.2 IT1 SFR#1311
	document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value=p_acc_ccy.value;
	return true;
}
function fnAccCcy(event) {
	if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != "") {
		fnDisableElement(document.getElementsByName("TXNCCY")[0]);
	}
	return true;
}
//FCUBS_12.0_STORYBOARD_15928835 starts
function fnSetHotKeyBranch_KERNEL() {
	
	if(window.event.srcElement.name =="TXNACC"){
	hotKeyBrn = document.getElementsByName('TXNBRN')[0].value;
	}
	if(window.event.srcElement.name =="OFFSETACC"){
	hotKeyBrn = document.getElementsByName('OFFSETBRN')[0].value;
	}
    return true;
}
//FCUBS_12.0_STORYBOARD_15928835 ends
//9nt1501 usability changes starts
function fnCalcExchAmt(event)
{

if (hisC1!=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value || hisC2!=document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value || hisAmount!=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMT").value) {
if (document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value !="" && document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value !="" && document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMT").value != "")
 {

if(document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value==document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value) {
	document.getElementById('BLK_TRANSACTION_DETAILS__ACTAMTI').value=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").value;
	document.getElementById("BLK_TRANSACTION_DETAILS__ACTAMTI").focus();
}
else
    {
	document.getElementById('BLK_TRANSACTION_DETAILS__ACTAMTI').value=0;
	var tempAction = dataObj.action;
	appendData();
	dataObj.action = 'CALCEXCHAMT';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	local_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
		try {	
		if(local_fcjResponseDOM) {		
		var msgStatus   =getNodeText( selectSingleNode(local_fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') {
		showErrorAlerts('CL-COMM-04');
		self.close();
		}
		else{
		document.getElementById('BLK_TRANSACTION_DETAILS__ACTAMTI').value=getNodeText(selectSingleNode(fnGetDataXMLFromFCJXML(local_fcjResponseDOM, 1), "//BLK_TRANSACTION_DETAILS/TXNAMT"));	
	    document.getElementById("BLK_TRANSACTION_DETAILS__ACTAMTI").focus();
		}
		}
	}catch(e){
	showErrorAlerts('GW-REOPR-01')	;
	}

	dataObj.action	= tempAction;


	}
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").focus();	 //9NT1501 ITR2 sfr 14005445
	hisC1=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	hisC2=document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value;
	hisAmount=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMT").value;
 }
 }
	return true;
}
//9nt1501 usability changes ends
