/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1317_Q_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TD_REDEMPTION":"BRN_CODE~AC_NO~CUST_ID~ACC_DESC~ACC_AMT~ACTION_FLAG~TENOR_DD~TENOR_MM~TENOR_YY~NEXT_MAT_DATE~REDEMPTION_MODE~REDEMPTION_AMT~WAVE_PENALTY~CCY~XREF~FCCREF~TXNDATE~CHARGES~DENOMAMT","BLK_TDREDMPAYOUT_DETAILS":"BRN~ACC~CCY~PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~OFFSET_CCY~PERCENTAGE~REDMAMT~REF_NO~SEQNO~NARRATIVE"};

var multipleEntryPageSize = {"BLK_TDPAYOUT_DETAILS__REDM" :"15" };

var multipleEntrySVBlocks = "";

 var tabMEBlks = {"CVS_MAIN__":"BLK_TDPAYOUT_DETAILS__REDM"};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TD_REDEMPTION">BRN_CODE~AC_NO~CUST_ID~ACC_DESC~ACC_AMT~ACTION_FLAG~TENOR_DD~TENOR_MM~TENOR_YY~NEXT_MAT_DATE~REDEMPTION_MODE~REDEMPTION_AMT~WAVE_PENALTY~CCY~XREF~FCCREF~TXNDATE~CHARGES~DENOMAMT</FN>'; 
msgxml += '      <FN PARENT="BLK_TD_REDEMPTION" RELATION_TYPE="1" TYPE="BLK_TDREDMPAYOUT_DETAILS">BRN~ACC~CCY~PAYOUTTYPE~OFFSET_BRN~OFFSET_ACC~OFFSET_CCY~PERCENTAGE~REDMAMT~REF_NO~SEQNO~NARRATIVE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TD_REDEMPTION" : "","BLK_TDREDMPAYOUT_DETAILS" : "BLK_TD_REDEMPTION~1"}; 

 var dataSrcLocationArray = new Array("BLK_TD_REDEMPTION","BLK_TDREDMPAYOUT_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 1317_Q.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 1317_Q.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TD_REDEMPTION__BRN_CODE";
pkFields[0] = "BLK_TD_REDEMPTION__BRN_CODE";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_TD_REDEMPTION__AC_NO__LOV_ACC":["BLK_TD_REDEMPTION__AC_NO~BLK_TD_REDEMPTION__ACC_DESC~","BLK_TD_REDEMPTION__BRN_CODE!VARCHAR2","N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_ALL';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array("BLK_TDPAYOUT_DETAILS__REDM");
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CCHG~BLK_TD_REDEMPTION","CMIS~BLK_TD_REDEMPTION","CUDF~BLK_TD_REDEMPTION","CDNM~BLK_TD_REDEMPTION","CTDR~BLK_TDREDMPAYOUT_DETAILS"); 

 var CallFormRelat=new Array("","","","",""); 

 var CallRelatType= new Array("N","1","N","N","1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["1317_Q"]="KERNEL";
ArrPrntFunc["1317_Q"]="1317_2";
ArrPrntOrigin["1317_Q"]="KERNEL";
ArrRoutingType["1317_Q"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["1317_Q"]="N";
ArrCustomModified["1317_Q"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CCHG":"","CMIS":"","CUDF":"","CDNM":"","CTDR":""};
var scrArgSource = {"CCHG":"","CMIS":"","CUDF":"","CDNM":"","CTDR":""};
var scrArgVals = {"CCHG":"","CMIS":"","CUDF":"","CDNM":"","CTDR":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CCHG":"","CMIS":"","CUDF":"","CDNM":"","CTDR":""};
var dpndntOnSrvs = {"CCHG":"","CMIS":"","CUDF":"","CDNM":"","CTDR":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"","NEW":"","MODIFY":"","AUTHORIZE":"","DELETE":"","CLOSE":"","REOPEN":"","REVERSE":"","ROLLOVER":"","CONFIRM":"","LIQUIDATE":"","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------