/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1461_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
-----------------------------------------------------------------------------------------
*/

function fnPostNew_KERNEL() {
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = mainWin.Lcy;
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	 document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; 
    document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Advance By Cash';
    return true;

}

function fnPreSave_KERNEL() {

return true ;
}


function fnAssignTxnCcy(p_acc_ccy) {
    document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = p_acc_ccy.value;
    return true;
}

function fnAccCcy(event) {
    if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != "") {
        fnDisableElement(document.getElementsByName("TXNCCY")[0]);
    }
    return true;
}
/*
function fnSetHotKeyBranch_KERNEL() {
  
	if (window.getEventSourceElement(event).name == "TXNACC") {
        hotKeyBrn = document.getElementsByName('TXNBRN')[0].value;
    }
    
	if (window.getEventSourceElement(event).name == "OFFSETACC") {
        hotKeyBrn = document.getElementsByName('OFFSETBRN')[0].value;
    }
    return true;
}
*/
function fnPostLoad_KERNEL(e) {
	document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; 
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
    var txnAcc = mainWin.functionDef[functionId].txnAcc;
    var txnAccBlock = txnAcc.split("__")[0];
    var txnAccTag = txnAcc.split("__")[1];
    try {
        pickedUpAcc = getNodeText(selectSingleNode(dbDataDOM, "//" + txnAccBlock + '/' + txnAccTag));
        pickedUpCcy = getNodeText(selectSingleNode(dbDataDOM, "//" + 'BLK_TRANSACTION_DETAILS/OFFSETCCY'));
    }
    catch (e) {
    }
	//IF (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value ==""{
	//if (dataObj.pickupClicked == "Y" && mainWin.functionDef[functionId].newFlow == 'Y'){
	//(document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value="";
	
	//}
	//}
    return true;
}
