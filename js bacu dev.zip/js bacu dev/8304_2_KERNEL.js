/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 8304_2_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : Nirmala N
**  Last modified on   : 25-08-2011
**  Full Version       : 
**  Reason             : 9NT1466 IUT SFR 219
****************************************************************************************************************************/

function fnPostLoad_KERNEL() {

	debugs("In fnPostLoad", "A");
      document.getElementById("BLK_CHARGE_DETAILS").disabled=true;
	document.getElementById("BLK_MIS_DETAILS").disabled=true;
	document.getElementById("BLK_UDF_DETAILS").disabled=true;	
	return true;
}
