/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2018, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 7031_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_PASSBOOK_STATUS_CHANGE":"XREF~SERIALNO~BRN~ACC~PASSBOOKNO~STATUS~STATUSCHGDATE~REASON~ISSUEDATE~PASSBOOKTYPE~USERID~CUSTID~REFERENCE_NO"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_PASSBOOK_STATUS_CHANGE">XREF~SERIALNO~BRN~ACC~PASSBOOKNO~STATUS~STATUSCHGDATE~REASON~ISSUEDATE~PASSBOOKTYPE~USERID~CUSTID~REFERENCE_NO</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_PASSBOOK_STATUS_CHANGE" : ""}; 

 var dataSrcLocationArray = new Array("BLK_PASSBOOK_STATUS_CHANGE"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 7031.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 7031.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_PASSBOOK_STATUS_CHANGE__REFERENCE_NO";
pkFields[0] = "BLK_PASSBOOK_STATUS_CHANGE__REFERENCE_NO";
queryFields[1] = "BLK_PASSBOOK_STATUS_CHANGE__SERIALNO";
pkFields[1] = "BLK_PASSBOOK_STATUS_CHANGE__SERIALNO";
queryFields[2] = "BLK_PASSBOOK_STATUS_CHANGE__BRN";
pkFields[2] = "BLK_PASSBOOK_STATUS_CHANGE__BRN";
queryFields[3] = "BLK_PASSBOOK_STATUS_CHANGE__ACC";
pkFields[3] = "BLK_PASSBOOK_STATUS_CHANGE__ACC";
queryFields[4] = "BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKNO";
pkFields[4] = "BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKNO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_PASSBOOK_STATUS_CHANGE__BRN__LOV_BRANCH":["BLK_PASSBOOK_STATUS_CHANGE__BRN~~","","",""],"BLK_PASSBOOK_STATUS_CHANGE__ACC__LOV_ACC_NO":["BLK_PASSBOOK_STATUS_CHANGE__ACC~BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKNO~BLK_PASSBOOK_STATUS_CHANGE__ISSUEDATE~BLK_PASSBOOK_STATUS_CHANGE__CUSTID~BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKTYPE~BLK_PASSBOOK_STATUS_CHANGE__STATUS~","BLK_PASSBOOK_STATUS_CHANGE__BRN!VARCHAR2","N~N~N~N~N~N",""],"BLK_PASSBOOK_STATUS_CHANGE__STATUS__LOV_STATUS":["BLK_PASSBOOK_STATUS_CHANGE__STATUS~BLK_PASSBOOK_STATUS_CHANGE__STATUS~","","N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("STCPBHIS~BLK_PASSBOOK_STATUS_CHANGE"); 

 var CallFormRelat=new Array("CATMS_PASSBOOK_LOG.ACCOUNT = CATMS_PASSBOOK_LOG__A.ACCOUNT AND CATMS_PASSBOOK_LOG.PASSBOOK_NUMBER = CATMS_PASSBOOK_LOG__A.PASSBOOK_NUMBER AND CATMS_PASSBOOK_LOG.BRANCH = CATMS_PASSBOOK_LOG__A.BRANCH"); 

 var CallRelatType= new Array("1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["7031"]="KERNEL";
ArrPrntFunc["7031"]="";
ArrPrntOrigin["7031"]="";
ArrRoutingType["7031"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["7031"]="N";
ArrCustomModified["7031"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"STCPBHIS":"ACCOUNT~PASSBOOK_NUMBER~BRANCH"};
var scrArgSource = {"STCPBHIS":"BLK_PASSBOOK_STATUS_CHANGE__ACC~BLK_PASSBOOK_STATUS_CHANGE__PASSBOOKNO~BLK_PASSBOOK_STATUS_CHANGE__BRN"};
var scrArgVals = {"STCPBHIS":"~~"};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"STCPBHIS":""};
var dpndntOnSrvs = {"STCPBHIS":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
callformTabArray["CVS_MAIN__TAB_MAIN"] = "STCPBHIS";
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------