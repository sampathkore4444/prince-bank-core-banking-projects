/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
           : Suhas Rekhu
Changed  On            : 04-March-2012
Modified Reason        : 9NT1501 usability changes
Search String          : 9NT1501 usability changes

Changed  By            : Suhas Rekhu
Changed  On            : 04-March-2012
Modified Reason        : 9NT1501 PRE-ITR SFR#80
Search String          : 9NT1501 PRE-ITR SFR#80

Changed  By            : Gokulnath M
Changed  On            : 15-March-2012
Modified Reason        : 9NT1501 PRE-ITR SFR#72
Search String          : 9NT1501 PRE-ITR SFR#72

Last Modified By   :  Prabhakaran J
Last modified on   : 10-May-2012
Full Version       : FCUBS 12.0.0
Reason             :  Focus changed to txn amount on exchange rate calculation
Search String : 9NT1501 ITR2 sfr 14005445

Last Modified By   : Mantinder Kaur
Last modified on   : 03-June-2014
Reason                 : UDF field displayed as lov even if it is a text field.
Search String      : FCUBS_12.0.3_TJSSPCAP_19052298

Modified By   	   : Nitish Priyaranjan
Modified on        : 01-Aug-2014
Reason             : Assignment of narrative is not required for reversal as values are already available.
Search String      : FCUBS_12.0.3_COMMONWEALTH_BANK_OF_AUSTRALIA_19522298

Modified By   	   : Ankit
Modified on        : 21-Oct-2014
Reason             : The code has been moved to postNewkernel
Search String      : FCUBS_12.0.3_CBA_19830171
----------------------------------------------------------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
 
// 9NT1501 PRE-ITR SFR#80 usability changes STARTS
var hisC1='###';
var hisC2='$$$';
var hisAmount=0;
// 9NT1501 PRE-ITR SFR#80 usability changes	ENDS

function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() { 
	debugs("In fnPostLoad", "A");
//FCUBS_12.0.3_CBA_19830171	starts
/*	
//9NT1501 usability changes starts
if (dataObj.action != 'REVERSE') {  //FCUBS_12.0.3_COMMONWEALTH_BANK_OF_AUSTRALIA_19522298
document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value='Miscellaneous GL Transfer from <From GL Account> to <To GL Account>'; //9NT1501 PRE-ITR SFR#72
} //FCUBS_12.0.3_COMMONWEALTH_BANK_OF_AUSTRALIA_19522298
document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value=mainWin.Lcy;
document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value=mainWin.Lcy; 
*/
//FCUBS_12.0.3_CBA_19830171 ends
//9NT1501 usability changes ends
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {    
//FCUBS_12.0.3_CBA_19830171 starts
document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value='Miscellaneous GL Transfer from <From GL Account> to <To GL Account>';
document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value=mainWin.Lcy;
document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value=mainWin.Lcy;
//FCUBS_12.0.3_CBA_19830171 ends
    return true;    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	debugs( "In fnPreSave", "A");	
	var isValid = true;
	if(!fnValidate())
        return false;

	debugs("In fnPreSave", "A");	
	return isValid;	
	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}
function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnPreAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_MIS_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_MIS_KERNEL() {
    return true;
}
function fnInTab_TAB_MIS_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_MIS_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}

function fnPreAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_UDF_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_UDF_KERNEL() {
    return true;
}
//FCUBS_12.0.3_TJSSPCAP_19052298
/*function fnInTab_TAB_UDF_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}*/
//FCUBS_12.0.3_TJSSPCAP_19052298
function fnOutTab_TAB_UDF_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}

function fnFunctionDefultValues() {
    try
    {
        if (document.all.OFFSETBRN.value == '') document.all.OFFSETBRN.value = mainWin.CurrentBranch;
    } 
	catch(e)    {}








}
//9NT1501 usability changes starts

function fnOffsetAcc(event) {
	try {disp_auto_lov('1005','BLK_TRANSACTION_DETAILS','OFFSETACC','To GL Account Number','LOV_TO_GL_ACC','','','', event);} catch(e) {}
	if (!isAutoLOVOpened) {
		document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value = getEventSourceElement(event).value;
	}
fnOffsetAcc1(event);
	return true;
}


function fnAcc(event) {
	try {disp_auto_lov('1005','BLK_TRANSACTION_DETAILS','TXNACC','From GL Account Number','LOV_FROM_GL_ACC','','','', event);} catch(e) {}
	if (!isAutoLOVOpened) {
		document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value = getEventSourceElement(event).value;
	}
fnAcc1(event);
	return true;
}



function fnAcc1(event) {
	if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != "") {
		//document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Miscellaneous GL Transfer from ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' to ' + document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value+'';
		document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Miscellaneous GL Transfer from - ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' - to - ' + document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value+''; //9NT1501 PRE-ITR SFR#72
	}
	return true;
}
function fnOffsetAcc1(event) {
	if (document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value != "") {
		//document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Miscellaneous GL Transfer from ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' to ' + document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value+'';
		document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'Miscellaneous GL Transfer from - ' + document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value+' - to - ' + document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETACC").value+''; //9NT1501 PRE-ITR SFR#72
	}
	return true;
}

function fnComputeXrate1(event){



	try {disp_auto_lov('1005','BLK_TRANSACTION_DETAILS','TXNCCY','From GL Currency','LOV_ACCCCY','','','', event);} catch(e) {}
	if (!isAutoLOVOpened) {
		document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value = getEventSourceElement(event).value;
	}
	fnComputeXrate(event);
return ;	
}

function fnComputeXrate2(event){



	try {disp_auto_lov('1005','BLK_TRANSACTION_DETAILS','OFFSETCCY','To GL Currency','LOV_ACCCCY','','','', event);} catch(e) {}
	if (!isAutoLOVOpened) {
		document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = getEventSourceElement(event).value;
	}
	fnComputeXrate(event);
return ;	
}

function fnComputeXrate(event){
if (hisC1!=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value || hisC2!=document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value || hisAmount!=document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").value) {
if (document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value !="" && document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value !="" && document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").value != "")
 {


if(document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value==document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value) {
	document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMTI").value;
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").focus();
}

else
    {
	document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=0;
	var tempAction = dataObj.action;
	appendData();
	dataObj.action = 'CALCEXCHAMT';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	local_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
		try {	
		if(local_fcjResponseDOM) {		
		var msgStatus   =getNodeText( selectSingleNode(local_fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') {
		showErrorAlerts('CL-COMM-04')	;
		self.close();
		}
		else{
		document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETAMTI').value=getNodeText(selectSingleNode(fnGetDataXMLFromFCJXML(local_fcjResponseDOM, 1), "//BLK_TRANSACTION_DETAILS/OFFSETAMT"));	
	    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETAMTI").focus();
		}
		}
	}catch(e){
	showErrorAlerts('GW-REOPR-01')	;
	}

	dataObj.action	= tempAction;


	}
	document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMTI").focus();	 //9NT1501 ITR2 sfr 14005445
	hisC1=document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	hisC2=document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value;
	hisAmount=document.getElementById("BLK_TRANSACTION_DETAILS__TXNAMT").value;
 }
 }
	return true;
}
//9NT1501 usability changes ends
