/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*----------------------------------------------------------------------------------------------------
**
** File Name    : 8307_1_KERNEL.js
**
** Module       : FCJWeb
**
** This source is part of the FLEXCUBE Corporate - Corporate Banking
** Software System and is copyrighted by Oracle Financial Services Software Limited.

** All rights reserved.  No part of this work may be reproduced,
** stored in a retrieval system, adopted or transmitted in any form
** or by any means, electronic, mechanical, photographic, graphic,
** optic recording or otherwise, translated in any language or
** computer language, without the prior written permission  from Oracle Financial 
** Services Software Limited.


**  Oracle Corporation
**  World Headquarters
**  500 Oracle Parkway
**  Redwood Shores, CA 94065
**  U.S.A.
**  
**  Copyright � 2011- 2012 by Oracle Financial Services Software Limited.
**  Oracle Financial Services Software Limited.

** Modified By         : Priyanka vijai
** Modified On         : 13-March-2017
** Modified Reason     : Transaction currency changing to local on remote
** Search String       : 12.3_SUPPORT_RETRO_25401156
**
** Modified By         : Shayam Sundar Ragunathan
** Modified On         : 03-Aug-2017
** Modified Reason     : The issue was occuring due the issuance chrges getting picked up during querying the instrument details. 
                         Fix given to nullify the charges and the related amounts,so that on pickup the correct values get picked up.
** Search String       : 9NT1606_12_4_RETRO_12_1_26384652 
**
** Modified By         : Shayam Sundar Ragunathan
** Modified On         : 23-Oct-2017
** Modified Reason     : Issue : Transaction currency was set to null after click on Query in 8307 screen.
						 Fix   : Now it will default from BC currency ,later if user wants to change then it can be changed. 
** Search String       : 9NT1606_12_4_RETRO_12_2_27009235
----------------------------------------------------------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	//9NT1587_12.0.2_17201918 Starts
	try{
		if (dataObj.action != 'REMOTEAUTH')//12.3_SUPPORT_RETRO_25401156
		 document.getElementById("BLK_TRANSACTION_DETAILS__ACCCY").value = mainWin.BranchLcy;
	 }catch(e) {}
	 //9NT1587_12.0.2_17201918 Ends
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	document.getElementById("BLK_TRANSACTION_DETAILS__ACNO").value="";
	document.getElementById("BLK_TRANSACTION_DETAILS__ACBRN").value="";
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostQuery_KERNEL(){

try{
  		 document.getElementById("BLK_TRANSACTION_DETAILS__INSTRTYPE").value="BCW";
		 document.getElementById("BLK_TRANSACTION_DETAILS__TXNDATE").value = mainWin.currBranchDate;
		 document.getElementById("BLK_TRANSACTION_DETAILS__LIQDDATE").value = mainWin.currBranchDate;
		 //9NT1466_FCUBS_11.3.1_DeCentralised_and_Offline_Branch STARTS
		 //document.getElementsByName('ISSBRN')[0].value = mainWin.CurrentBranch;//9NT1606_12_3_RETRO_12_1_25398932 commented
		 document.getElementsByName('ACNO')[0].value = '';
		 document.getElementsByName('ACCCY')[0].value = '';
		 document.getElementById("BLK_TRANSACTION_DETAILS__EXCHRATE").value="";
		 //9NT1466_FCUBS_11.3.1_DeCentralised_and_Offline_Branch ENDS
		//9NT1606_12_4_RETRO_12_2_27009235 start 
		if(document.getElementById("BLK_TRANSACTION_DETAILS__ACCCY").value==""){
		document.getElementById("BLK_TRANSACTION_DETAILS__ACCCY").value = mainWin.BranchLcy;
		}
		//9NT1606_12_4_RETRO_12_2_27009235 end
		//9NT1606_12_4_RETRO_12_1_26384652 STARTS
				document.getElementsByName('TCYTOTCHGAMT')[0].value ='';
				fireHTMLEvent(document.getElementsByName('TCYTOTCHGAMT')[0], "onpropertychange");
				document.getElementsByName('ACTAMT')[0].value ='';
				fireHTMLEvent(document.getElementsByName('ACTAMT')[0], "onpropertychange");				
                var chargeNode = selectNodes(dbDataDOM, "//BLK_CHARGE_DETAILS");
                for (var i = 0;i < chargeNode.length;i++) {
                    chargeNode[i].parentNode.removeChild(chargeNode[i]);
                }
        //9NT1606_12_4_RETRO_12_1_26384652 ENDS			 		 
		 }
		 catch(e) { 
	 }
 return true ;   
}
