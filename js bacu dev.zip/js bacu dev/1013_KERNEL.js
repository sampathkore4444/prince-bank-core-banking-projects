/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2014  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
           : Suhas Rekhu
Changed  On            : 04-March-2012
Modified Reason        : 9NT1501 usability changes
Search String          : 9NT1501 usability changes

**  Last Modified By   :  Gokulnath.M
**  Last modified on   : 11-Apr-2012
**  Full Version       : FCUBS 12.0.0
**  Reason             :  Focus changed to offset amount on exchange rate calculation
**  Search String : 9NT1501 ITR1 sfr 13929475

** Changed  By            : Sriraam S
** Changed  On            : 16-Dec-2013
** Modified Reason        : Defaulted Cheque date to be Current Branch Date
** Search String          : 9NT1587_1202_INTERNAL_17941929

** Changed  By            : Sriraam S
** Changed  On            : 27-Feb-2014
** Modified Reason        : Flickering of Account field and screen prevented
** Search String          : 9NT1587_1203_IEGPCAE_18317875

** Changed  By            : Vipan Kumar
** Changed  On            : 7-July-2017
** Modified Reason        : Defaulted Cheque date to be Current Branch Date
** Search String          : 9NT1606_12_4_RETRO_12_3_26474223 
**
**  Modified By          : Shayam Sundar Ragunathan
**  Modified On          : 26-Jul-2017
**  Modified Reason      : Issue:narrative value geting changed due to onblur event.
				           Fix:Given to set the narrativedef value in the addl param and defaul the narrative according to the value.
**  Search String        : 9NT1606_12_4_RETRO_12_2_26230765

**  Modified By          : Mantinder Kaur
**  Modified On          : 26-Jul-2017
**  Modified Reason      : Issue:The cheque issue date not getting shown in user date format.
				           Fix: fireHTMLEvent added of cheque issue date so that it gets formatted based on user date format.
**  Search String        : FCUBS_124_SAIGON_27966427
----------------------------------------------------------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";
//9NT1501 usability changes starts
var hisC1='###';
var hisC2='$$$';
var hisAmount=0;
//9NT1501 usability changes ends

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

//9NT1501 usability changes
	//document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY").value=mainWin.Lcy;
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value=mainWin.Lcy;
//9NT1501 usability changes ends
     document.getElementsByName('NARRATIVE')[0].value = 'Cheque Withdrawal';//EBB542
	 document.getElementById("BLK_TRANSACTION_DETAILS__CHEQUE_ISSUE_DATE").value=mainWin.currBranchDate; //9NT1587_1202_INTERNAL_17941929 Added
	 //FCUBS_124_SAIGON_27966427 starts
	// document.getElementById("BLK_TRANSACTION_DETAILS__CHEQUE_ISSUE_DATEI").value= mainWin.currBranchDate;  //9NT1606_12_4_RETRO_12_3_26474223
	 fireHTMLEvent(document.getElementsByName('CHEQUE_ISSUE_DATE')[0], "onpropertychange");
	 //FCUBS_124_SAIGON_27966427 ends
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}


/*
function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
*/
//9NT1501 usability changes starts

//9NT1501 usability changes ends


//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_TRANSACTION_DETAILS__TXNCCY' ;
    var b = 'BLK_TRANSACTION_DETAILS__OFFSETCCY';
	var c = 'BLK_TRANSACTION_DETAILS__OFFSETAMT' ;
	var d = 'BLK_TRANSACTION_DETAILS__TXNAMT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
		//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_21317625
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends

//9NT1606_12_4_RETRO_12_2_26230765 starts
function fnchngenarrative(event){

try{
dataObj.narrativedef ="Y";
}catch(e){}
return true;	
}
//9NT1606_12_4_RETRO_12_2_26230765 ends