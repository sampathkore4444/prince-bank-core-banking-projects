/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2013  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 5555_1_CUSTOM.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 


Changed By         :  Kundan Verma
Description        :  Changed language code while searching from ertb_msgs
Search String      :  FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes

Changed By         :  Vinodkumar Subramaniam
Description        :  Account description vanishing after clicking addrow button. Code added for the same to display the acc desc.
Search String      :  11.4 ITR2 SFR#13531630 VINOD CHANGES
** Last Modified By   :  Ediga GANGADHAR
**  Last modified on   :  24-APRIL-2013
**  Reason             :  Capture the additionl information Drawee a/c no and Cheque number into Remarks
**  Search String      :   9NT1587_16712454_Narrative

    Modified By           : Prashant Yadav
    Modified On           : 24-05-2013
    Modified Reason       : chnages for f11 and f12 functionality
	Search String         : PMPKRASK_16860758 
	
	Modified By           : Gangadhar Ediga
    Modified On           : 01-06-2013
    Modified Reason       : due to js error '{' is added.
	Search String         : FCUBS1202IUT_INTERNEL_109
	
**  Last Modified By   :  Sarina
**  Last modified on   : 12-JUN-2013
**  Reason             : fnHandleError call commented as it is not reqd for addrows 
		         and because of it presave_kernel was not getting hit. Instead 
		         fnSetScrData is used to paint response on screen
**  Search String      : FC12.0.2 IUT BUG NO 149
	
	Modified By           : Vishalakshi N
        Modified On           : 22-08-2013
        Modified Reason       : The function fnSetHotKeyBranch() has been renamed to fnSetHotKeyBranch_KERNEL().
	Search String         : BDTNRB_17320161	
	
**Changed By        :  Deeksha
**Description       :  Assignment of total amt 
**Search String     :  9NT1606_18798863_19077390 

**Changed By        :  Deeksha
**Description       :  Assignment of total amt 
**Search String     :  9NT1606_18387423_19078153  
      Changed By          : Priyanka vijai
      Changed On          : 23-Dec-2016
      Changed Description : New flow override handling
      Search String       : 12.2_SUPPORT_RETRO_24373019 
****************************************************************************************************************************/
var PAGE_SIZE = 15;

function fnPostNew_KERNEL()
{
   document.getElementById("BLK_BC_DD_MASTER__TXNCCY").value = dlgArg.mainWin.frames["Global"].Lcy;  
 return true;
}

function fnPostLoad_KERNEL() {
 document.getElementById("cmdAddRow_BLK_BC_DD_DETAILS").style.visibility = "hidden";
 return true;
}
function fnAddRowsWithDefault()
{
    var numRows = parseInt(document.getElementById("BLK_BC_DD_MASTER__ROWSTBA").value); 
	var l_LastIndex = selectNodes(dbDataDOM,getXPathQuery('BLK_BC_DD_DETAILS')).length;
	var tableObj = document.getElementById("BLK_BC_DD_DETAILS");
	var numerRows = tableObj.tBodies[0].rows.length;

	if (document.getElementById("BLK_BC_DD_MASTER__ROWSTBA").value== '')
	{
		
		showErrorAlerts('BRN-VAL-009');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
		
		
		//alert(' Enter the number of rows to be added! ');
		
		return false;
	}
	
	if(document.getElementById("BLK_BC_DD_MASTER__CGTYPE").value !='')
	{
		if(document.getElementById("BLK_BC_DD_MASTER__CGTYPE").value=="BCLG")
		{
			if(document.getElementById("BLK_BC_DD_MASTER__UI_INSTRUMENT_TYPE").value != 'BCG')
			{
			showErrorAlerts('BRN-VAL-010');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			
			
			//alert(' Instrument Type and the Clearing Type are not same! ');
			return false;
			}
		}
		else if(document.getElementById("BLK_BC_DD_MASTER__CGTYPE").value=="DDLG")
		{
			if(document.getElementById("BLK_BC_DD_MASTER__UI_INSTRUMENT_TYPE").value != 'DDG')
			{
			
			showErrorAlerts('BRN-VAL-010');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			//alert(' Instrument Type and the Clearing Type are not same! ');
			return false;
			}	
		} 
		else 
		{
			if(document.getElementById("BLK_BC_DD_MASTER__UI_INSTRUMENT_TYPE").value != 'CHQ')
			{
			
			showErrorAlerts('BRN-VAL-010');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			//alert(' Instrument Type and the Clearing Type are not same! ');
			return false;
			}
		}
	}
	

 
	window.focus();
	appendData();
	var l_accdesc = document.getElementById("BLK_BC_DD_MASTER__ACCOUNTDESCRIPTION").value; //11.4 ITR2 SFR#13531630 VINOD CHANGES Added
       tempAction = dataObj.action; //FCUBS11.2 SFR830 ITR1
	dataObj.action = 'ADDNEWROWS';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
	var v_xml_string = getXMLString(fcjResponseDOM);
	if (fcjResponseDOM && v_xml_string.length > 0) {
		dataObj = new dataObject(v_xml_string);
		//FC12.0.2 IUT BUG NO 149 starts
		//var returnValue = fnHandleError();
		fnSetScrData(fcjResponseDOM);
		//FC12.0.2 IUT BUG NO 149 ends
	} else {
		alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
		//return; //FCUBS11.2 SFR830 ITR1
	}
	dataObj.action = tempAction; //FCUBS11.2 SFR830 ITR1
	document.getElementById("BLK_BC_DD_MASTER__ACCOUNTDESCRIPTION").value = l_accdesc; //11.4 ITR2 SFR#13531630 VINOD CHANGES Added
	//9NT1587_16712454_Narrative starts
	var totRows = document.getElementById("BLK_BC_DD_DETAILS").tBodies[0].rows.length;
	for(var i=0; i< totRows; i++){
		document.getElementsByName("NARRATIVE")[i].value =document.getElementsByName("NARRATIVE")[i].getAttribute('DEFAULT');
		}
	// 9NT1587_16712454_Narrative ends
}

function fnPostDeleteRow_BLK_BC_DD_DETAILS_KERNEL() {
	appendData(document.getElementById("TBLPageTAB_MAIN"));
	var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_BC_DD_DETAILS'));
	for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
		setNodeText(selectSingleNode(clgNodes[l_Cnt], "ENTRNUM"), new String(l_Cnt + 1));
	}

	var pageNo = Number(document.getElementById("CurrPage__BLK_BC_DD_DETAILS").innerHTML) - 1;
	var totalRows = document.getElementById("BLK_BC_DD_DETAILS").tBodies[0].rows.length;
	var entryNo;
	for(var i=0; i< totalRows; i++){
		entryNo = new String(pageNo * PAGE_SIZE + i + 1);
		document.getElementsByName("ENTRNUM")[i].value = entryNo;
	}
	return true;
}

function fn_instrchange(evnt)
{
 //Add code to handle change of Instrument type
 var currRowIndex;
 currRowIndex=getRowIndex(evnt)-1;
if(currRowIndex==-1)
{
	return true;
}
fnClearRowData(currRowIndex);
var instrType=document.getElementsByName("INSTRTYP")[currRowIndex].value;
fnDefaultRowData(currRowIndex,instrType);
return true;
}

function fnClearRowData(currRowIndex)
{
try
{
	var rowLen = document.getElementById("BLK_BC_DD_DETAILS").tBodies[0].rows.length;
	if(currRowIndex<0 || currRowIndex>=rowLen)
	return true;

document.getElementsByName("BLK_BC_DD_DETAILS__INSTRNUM")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__ISSBNK")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__INSTRAMT")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__TXNCCY")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__ACGLNO")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__BRNCD")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__ROUTINGNO")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__INSTRSTAT")[currRowIndex].value ="LIQD";
document.getElementsByName("BLK_BC_DD_DETAILS__NARRATIVE")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__STATUS")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__DRAWEE_ACCOUNT")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__INSTRDT")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__ACDESC")[currRowIndex].value ='';
document.getElementsByName("BLK_BC_DD_DETAILS__ENDPOINT")[currRowIndex].value ='';
}
catch(e)
{
}
return true;
}

function fnDefaultRowData(rowIndex,instrType)
{
try
{
	var rowLen = document.getElementById("BLK_BC_DD_DETAILS").tBodies[0].rows.length;
	if(rowIndex<0 || rowIndex>rowLen)
	return true;

	if(instrType=="BCG")
	{
	document.getElementsByName("CLGTYP")[rowIndex].value = 'BCLG';
	}
	else if(instrType=="DDG")
	{
	document.getElementsByName("CLGTYP")[rowIndex].value = 'DDLG';
	} 
	else if(instrType=="CHQ")
	{
	document.getElementsByName("CLGTYP")[rowIndex].value = 'CGIN';
	}
	document.getElementsByName("ISSBNK")[rowIndex].value = dlgArg.mainWin.frames["Global"].CurrentBranch;
 	document.getElementsByName("INSTRDT")[rowIndex].value = dlgArg.mainWin.frames["Global"].AppDate;
	//document.getElementsByName("BLK_BC_DD_DETAILS__TXNCCY")[rowIndex].value = document.getElementById("BLK_BC_DD_MASTER__TXNCCY").value;
}catch(e)
{}
	return true;
}

function fnCalculateTotAmt() {
	try {
		var totalAmt = 0;
		var l_Cnt = 0;
		appendData(document.getElementById("TBLPageTAB_MAIN"));
		var clgNodes = selectNodes(dbDataDOM, getXPathQuery('BLK_BC_DD_DETAILS'));
		if(clgNodes) {
			for(l_Cnt = 0 ; l_Cnt < clgNodes.length; l_Cnt++ ) {
				var l_Node = clgNodes[l_Cnt];
				var amt = getNodeText(selectSingleNode(l_Node, "INSTRAMT"));
				if (amt && !isNaN(amt))
					totalAmt = parseFloat(totalAmt) + parseFloat(amt);
			}
		}
		document.getElementsByName('TOTAMTI')[0].value = totalAmt;
		//document.getElementsByName('TOTAMT')[0].value = totalAmt;//9NT1606_18387423_19078153
	    document.getElementById('BLK_BC_DD_MASTER__TOTAMT').value = totalAmt;//9NT1606_18387423_19078153
	} catch (ex) {
	}
}

function fn_addrowsnum(){
var l_rowCnt =document.getElementsByName('ROWSTBA')[0].value;


if (l_rowCnt == ""){
    
	showErrorAlerts('BRN-VAL-011');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
	
	
	//alert('Enter the No of Records To be Added..');
     return false;
}
tempaction = dataObj.action;
//fnEnrich();			
fnAddRowsWithDefault();
dataObj.action	= tempaction; 
fnDisableElement(document.getElementsByName("BTN_ROWS")[0]);
}

// 9NT1587_16712454_Narrative starts
function fnRemarksDefault(event) {
try{//12.2_SUPPORT_RETRO_24373019 
var index=getRowIndex(event)-1;
if (dataObj.action != "REMOTEAUTH") {
var narr_def =  document.getElementById("BLK_BC_DD_DETAILS").tBodies[0].rows[index].cells[9].getElementsByTagName("INPUT")[0].getAttribute('DEFAULT');
	var chq_num = document.getElementById("BLK_BC_DD_DETAILS").tBodies[0].rows[index].cells[4].getElementsByTagName("INPUT")[0].value;
	var drwe_acc = document.getElementById("BLK_BC_DD_DETAILS").tBodies[0].rows[index].cells[15].getElementsByTagName("INPUT")[0].value;
	var narr_val = "";
	narr_split = narr_def.split('-');
	if(chq_num == "") chq_num =  ( narr_split[2] );
	if(drwe_acc == "") drwe_acc =  (narr_split[4] );
	narr_val = narr_split[0] +"-" +narr_split[1]+"-"+chq_num +"-"+narr_split[3] + "-"+drwe_acc;
	 document.getElementById("BLK_BC_DD_DETAILS").tBodies[0].rows[index].cells[9].getElementsByTagName("INPUT")[0].value = narr_val;
	}
}catch(e){}//12.2_SUPPORT_RETRO_24373019 
	return true;
}
// 9NT1587_16712454_Narrative ends
//PMPKRASK_16860758  START
//BDTNRB_17320161 Starts
//function fnSetHotKeyBranch()
function fnSetHotKeyBranch_KERNEL()
//BDTNRB_17320161 Ends
{
try{

hotKeyBrn=document.getElementById("BLK_BC_DD_MASTER__BRNCD").value;
}catch(e){}
//FCUBS1202IUT_INTERNEL_109 STARTS
return true;
}
//FCUBS1202IUT_INTERNEL_109 ENDS
//PMPKRASK_16860758  END
//9NT1606_18798863_19077390  starts
function fnPreSave_KERNEL() {	
document.getElementById("BLK_BC_DD_MASTER__ACORGLNO").value;
fnCalculateTotAmt();
 return true;
}
//9NT1606_18798863_19077390  ends

//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_BC_DD_MASTER__TXNCCY1';
    var b = 'BLK_BC_DD_MASTER__TXNCCY1';
	var c = 'BLK_BC_DD_MASTER__TOTAMT';
	var d = 'BLK_BC_DD_MASTER__TOTAMT'; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_213176251
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends