/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 8305_2_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_TRANSACTION_DETAILS":"XREF~NARRATIVE~PAYBANK~INSTRTYPE~INSTRCCY~INSTRAMT~EXCHRATE~TXNDATE~ACCCY~TCYTOTCHGAMT~ACTAMT~INSTRSTAT~INSTRNO~INSTRDATE~MANUAL_INPUT~BNKNAME~BANKNAME~DENMAMT2~DELIVERY_MODE~DELIVERY_ADD1~DELIVERY_ADD2~DELIVERY_ADD3~DELIVERY_ADD4","BLK_CHEQUE_DETAILS":"PAYBRN~CHQNO~BENFNAME~OTHERDETLS1~BENFADDR1~BENFADDR2~BENFADDR3~OTHERDETLS2~OTHERDETLS3~OTHERDETLS4~OTHERDETLS5~OTHERDETLS6~OTHERDETLSTYPE1~OTHERDETLSTYPE2~OTHERDETLSTYPE3~OTHERDETLSTYPE4~OTHERDETLSTYPE5~OTHERDETLSTYPE6~PAYBRNAME"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

 var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_TRANSACTION_DETAILS">XREF~NARRATIVE~PAYBANK~INSTRTYPE~INSTRCCY~INSTRAMT~EXCHRATE~TXNDATE~ACCCY~TCYTOTCHGAMT~ACTAMT~INSTRSTAT~INSTRNO~INSTRDATE~MANUAL_INPUT~BNKNAME~BANKNAME~DENMAMT2~DELIVERY_MODE~DELIVERY_ADD1~DELIVERY_ADD2~DELIVERY_ADD3~DELIVERY_ADD4</FN>'; 
msgxml += '      <FN PARENT="BLK_TRANSACTION_DETAILS" RELATION_TYPE="1" TYPE="BLK_CHEQUE_DETAILS">PAYBRN~CHQNO~BENFNAME~OTHERDETLS1~BENFADDR1~BENFADDR2~BENFADDR3~OTHERDETLS2~OTHERDETLS3~OTHERDETLS4~OTHERDETLS5~OTHERDETLS6~OTHERDETLSTYPE1~OTHERDETLSTYPE2~OTHERDETLSTYPE3~OTHERDETLSTYPE4~OTHERDETLSTYPE5~OTHERDETLSTYPE6~PAYBRNAME</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_TRANSACTION_DETAILS" : "","BLK_CHEQUE_DETAILS" : "BLK_TRANSACTION_DETAILS~1"}; 

 var dataSrcLocationArray = new Array("BLK_TRANSACTION_DETAILS","BLK_CHEQUE_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 8305_2.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 8305_2.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
pkFields[0] = "BLK_TRANSACTION_DETAILS__XREF";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_CHEQUE_DETAILS":["BENFADDR1","BENFADDR2","BENFADDR3","BENFNAME","CHQNO","OTHERDETLS1","PAYBRN"],"BLK_TRANSACTION_DETAILS":["ACCCY","ACTAMT","EXCHRATE","INSTRAMT","INSTRCCY","INSTRTYPE","NARRATIVE","PAYBANK","TCYTOTCHGAMT","TXNDATEI","XREF"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_DENOM';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CMIS~BLK_TRANSACTION_DETAILS","CCHG~BLK_TRANSACTION_DETAILS","CDNM~BLK_TRANSACTION_DETAILS","CUDF~BLK_TRANSACTION_DETAILS"); 

 var CallFormRelat=new Array("","","",""); 

 var CallRelatType= new Array("1","N","N","N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["8305_2"]="KERNEL";
ArrPrntFunc["8305_2"]="";
ArrPrntOrigin["8305_2"]="";
ArrRoutingType["8305_2"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["8305_2"]="N";
ArrCustomModified["8305_2"]="N";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {};
var scrArgSource = {};
var scrArgVals = {};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {};
var dpndntOnSrvs = {};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
callformTabArray['CVS_MAIN__TAB_MIS'] = 'CMIS';
callformTabArray['CVS_MAIN__TAB_CHARGE'] = 'CCHG';
callformTabArray['CVS_MAIN__TAB_DENOM'] = 'CDNM';
callformTabArray['CVS_MAIN__TAB_UDF'] = 'CUDF';
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"","DELETE":"","CLOSE":"","REOPEN":"","REVERSE":"","ROLLOVER":"","CONFIRM":"","LIQUIDATE":"","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------