/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2010  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 8306_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : Kiran Chandrappa
**  Last modified on   : 03-06-2013
**  Reason             : To capture the Beneficiary name into narrative field
**  Search String      : 9NT1587_12.0.2.0.0_Narrative_Changes
****************************************************************************************************************************/

var defaultVal = ""; //9NT1587_12.0.2.0.0_Narrative_Changes
//OFAC Black List Check FC 11.1 Starts 
function fnPreLoad_CVS_OFACM_KERNEL(screenArgs){
	
	screenArgs['REQXML']='';//Prepare the request xml in the format of OFAC accepeted Requested xml and pass as
	// screen argument to CSCOFACM

return true;
}
//OFAC Black List Check FC 11.1 Ends 
//9NT1587_12.0.2.0.0_Narrative_Changes Starts
function fnonchangebenf() {
    document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = defaultVal + document.getElementById("BLK_CHEQUE_DETAILS__BENFNAME").value;
}

function fnPreNew_KERNEL() {
try{
defaultVal = document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").getAttribute("DEFAULT")
}
catch(e){}
return true;
}

function fnPreLoad_KERNEL() {
try{
defaultVal = document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").getAttribute("DEFAULT")
}
catch(e){}
return true;
}
//9NT1587_12.0.2.0.0_Narrative_Changes Ends
