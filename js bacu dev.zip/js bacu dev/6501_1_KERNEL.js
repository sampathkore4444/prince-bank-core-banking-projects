/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2015  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6501_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   :  Rajesh
**  Last modified on   :  18-Jul-2011
**  Search String       :  Instrument Type 9NT1466
**  Reason             :  Instrument Type Added

**  Last Modified By   :  Achelal
**  Last modified on   :  15-Feb-2012
**  Search String       :  9nt1501 usability changes
**  Reason             :  9nt1501 usability changes

Changed  By            : Gokulnath M
Changed  On            : 15-March-2012
Modified Reason        : 9NT1501 PRE-ITR SFR#72
Search String          : 9NT1501 PRE-ITR SFR#72

Changed  By            : Gokulnath M
Changed  On            : 02-April-2012
Modified Reason        : 9NT1501 sfr 13913140
Search String          : 9NT1501 sfr 13913140

Last Modified By   :  Prabhakaran J
Last modified on   : 10-May-2012
Full Version       : FCUBS 12.0.0
Reason             :  Focus changed to instrument amount on exchange rate calculation
Search String : 9NT1501 ITR2 sfr 14005445

Changed  By            : Prashant Y
Changed  On            : 03-March-2013
Modified Reason        : Changes done to do exchange rate calc on onblur
Search String          : SCRNVB_16428487 
** Last Modified By   :  Ediga GANGADHAR
**  Last modified on   :  24-APRIL-2013
**  Reason             :  Capture the additionl information Drawee a/c no and Cheque number into Remarks
**  Search String      :   9NT1587_16712454_Narrative

Changed By			: Sindhu Ramakrishna
Changed on			: 19-May-2015
Change Description	: FCUBS-12.1 Customer Landing Changes
Search String		: 12.1_Customer_Landing_Changes
*/
//var fcjRequestDOM;
//var fcjResponseDOM;
//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
 
 var hisC1='###';
var hisC2='$$$';
var hisAmount=0;
 
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {
  //document.getElementsByName("BLK_CLEARING_DETAILS__VALDATE")[0].value=dlgArg.mainWin.frames['Global'].AppDate;
  //document.getElementById("BLK_CLEARING_DETAILS__TXNDATE").value=mainWin.currBranchDate;
  //SCRNVB_16428487 start
  addEvent(document.getElementsByName("INSTRAMTI")[0], "onblur", "validateInputAmount('INSTRAMT', 'INSTRCCY', event);fnValidateRange(this);fnCalcExchAmt(event);");
  //SCRNVB_16428487 end
 // document.getElementById("BLK_CLEARING_DETAILS__REMARKS").value='Cheque Deposit - Cheque no - Cheque Number - Drawer Account Number - Account Number -'; commented by 9NT1587_16712454_Narrative
   document.getElementById("BLK_CLEARING_DETAILS__BENBRANCH").value=mainWin.CurrentBranch;
  //enableForm();
//12.1_Customer_Landing_Changes starts
	try{
	 if((typeof(mainWin.gCustInfo["AccntNo"])!= 'undefined' && mainWin.gCustInfo["AccntNo"]!='' && mainWin.gCustInfo["FunctionId"]=='STDCUDEM') )
	{
	document.getElementById("BLK_CLEARING_DETAILS__BENACCOUNT").value = mainWin.gCustInfo["AccntNo"];
	fnCreateOnchangeEvent(document.getElementById("BLK_CLEARING_DETAILS__BENACCOUNT"));
	}
	}
	catch(e){}
//12.1_Customer_Landing_Changes ends
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	//Instrument Type 9NT1466 Starts
	var instr = document.getElementById('BLK_TRANSACTION_DETAILS__UI_INSTRUMENT_TYPE').value;
    document.getElementById('BLK_CLEARING_DETAILS__INSTRUMENT_TYPE').value = instr;
	
    //Instrument Type 9NT1466 Ends
	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

		return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	
	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnAccCcy(event) {
	if (document.getElementById("BLK_CLEARING_DETAILS__BENACCOUNT").value != "") {
		fnDisableElement(document.getElementsByName("ACCCY")[0]);
	}
	return true;
}
	// 9NT1587_16712454_Narrative starts 
/*function fnChequeNo(event) {
	if (document.getElementById("BLK_CLEARING_DETAILS__INSTRNO").value != "") {
		document.getElementById("BLK_CLEARING_DETAILS__REMARKS").value = 'Cheque Deposit - Cheque Number - '+ document.getElementById("BLK_CLEARING_DETAILS__INSTRNO").value+ ' - Drawer Account Number - '+document.getElementById("BLK_CLEARING_DETAILS__REMACCOUNT").value+'' ;
	}
	return true;
}
function fnDrawerAcc(event) {
	if (document.getElementById("BLK_CLEARING_DETAILS__REMACCOUNT").value != "") {
		document.getElementById("BLK_CLEARING_DETAILS__REMARKS").value = 'Cheque Deposit - Cheque Number - '+ document.getElementById("BLK_CLEARING_DETAILS__INSTRNO").value + ' - Drawer Account Number - '+document.getElementById("BLK_CLEARING_DETAILS__REMACCOUNT").value+'';
	}
	return true;
}*/
function fnRemarksDefault(event) {
var index=getRowIndex(event)-1;
if (dataObj.action != "REMOTEAUTH") {
var narr_def =  document.getElementById("BLK_CLEARING_DETAILS__REMARKS").getAttribute('DEFAULT');
	var chq_num = document.getElementById("BLK_CLEARING_DETAILS__INSTRNO").value;
	var drwe_acc = document.getElementById("BLK_CLEARING_DETAILS__REMACCOUNT").value;
	var narr_val = "";
	narr_split = narr_def.split('-');
	if(chq_num == "") chq_num =  ( narr_split[2] );
	if(drwe_acc == "") drwe_acc =  (narr_split[4]);
	narr_val = narr_split[0] +"-" +narr_split[1]+"-" +chq_num +"-"+narr_split[3] + "-"+drwe_acc;
	  document.getElementById("BLK_CLEARING_DETAILS__REMARKS").value = narr_val;
	}
	return true;
}
	// 9NT1587_16712454_Narrative ends
//9nt1501 usability changes starts
function fnCalcExchAmt(event)//SCRNVB_16428487 added event
{

if (hisC1!=document.getElementById("BLK_CLEARING_DETAILS__INSTRCCY").value || hisC2!=document.getElementById("BLK_CLEARING_DETAILS__ACCCY").value || hisAmount!=document.getElementById("BLK_CLEARING_DETAILS__INSTRAMT").value) {
if (document.getElementById("BLK_CLEARING_DETAILS__INSTRCCY").value !="" && document.getElementById("BLK_CLEARING_DETAILS__ACCCY").value !="" && document.getElementById("BLK_CLEARING_DETAILS__INSTRAMT").value != "")
 {

if(document.getElementById("BLK_CLEARING_DETAILS__INSTRCCY").value==document.getElementById("BLK_CLEARING_DETAILS__ACCCY").value) {
	document.getElementById('BLK_CLEARING_DETAILS__ACTAMTI').value=document.getElementById("BLK_CLEARING_DETAILS__INSTRAMT").value;
	document.getElementById("BLK_CLEARING_DETAILS__ACTAMTI").focus();
}
else
    {
	document.getElementById('BLK_CLEARING_DETAILS__ACTAMTI').value=0;
	var tempAction = dataObj.action;
	appendData();
	dataObj.action = 'CALCEXCHAMT';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	local_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
		try {	
		if(local_fcjResponseDOM) {		
		var msgStatus   =getNodeText( selectSingleNode(local_fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') {
		showErrorAlerts('CL-COMM-04');
		self.close();
		}
		else{
		document.getElementById('BLK_CLEARING_DETAILS__ACTAMTI').value=getNodeText(selectSingleNode(fnGetDataXMLFromFCJXML(local_fcjResponseDOM, 1), "//BLK_CLEARING_DETAILS[2]/TXNAMT"));	
	    document.getElementById("BLK_CLEARING_DETAILS__ACTAMTI").focus();
		}
		}
	}catch(e){
	showErrorAlerts('GW-REOPR-01')	;
	}

	dataObj.action	= tempAction;


	}
	document.getElementById("BLK_CLEARING_DETAILS__INSTRAMTI").focus();	 //9NT1501 ITR2 sfr 14005445
	hisC1=document.getElementById("BLK_CLEARING_DETAILS__INSTRCCY").value;
	hisC2=document.getElementById("BLK_CLEARING_DETAILS__ACCCY").value;
	hisAmount=document.getElementById("BLK_CLEARING_DETAILS__INSTRAMT").value;
 }
 }
	return true;
/*if (document.getElementById("BLK_CLEARING_DETAILS__INSTRAMTI").value != "") {
  
	tempAction = dataObj.action;
		window.focus();
	appendData();
	dataObj.action = 'CALCEXCHAMT';
	var userLanguageCode = mainWin.LangCode;
	fcjRequestDOM = buildUBSXml();
	addBranchParam(fcjRequestDOM);
	local_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
	document.getElementById('BLK_CLEARING_DETAILS__ACTAMTI').value=getNodeText(selectSingleNode(fnGetDataXMLFromFCJXML(local_fcjResponseDOM, 1),"//BLK_CLEARING_DETAILS[2]/TXNAMT"));
	dataObj.action	= tempAction;
	}
	return true;*/ //9NT1501 sfr 13913140
}
function fnAccCcy(event) {
	if (document.getElementById("BLK_CLEARING_DETAILS__BENACCOUNT").value != "") {
		fnDisableElement(document.getElementsByName("ACCCY")[0]);
	}
	return true;
}
//9nt1501 usability changes ends
