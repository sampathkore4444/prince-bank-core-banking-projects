/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2004 - 2015  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  Last Modified By   : Mohit Ojha
**  Last modified on   : 07-Apr-2017
**  Reason             : MCY/VA changes
**  Search String      : FCUBS12.4MCY/VA changes

** Modified By         : Mohit Ojha
** Modified On         : 26-APR-2017
** Modified Reason     : 1406 : GETTING "ACCOUNT CURRENCY DOES NOT MATCH WITH ENTRY CURRENCY" ON SAVE
** Search String       : Bug#25942865

** Modified By         : Yogendra Moganti
** Modified On         : 26-Dec-2017
** Modified Reason     : Bug 27293598 - F10, F11 AND F12 ARE NOT WORKING IF THE ACCOUNT BELONGS TO DIFFERENT BRANCH 
** Search String       : Bug_27293598

** Modified By           : Gaurav Singh
** Modified On           : 18-Jan-2017
** Modified Reason       : ISSUE WITH F10, F11 AND F12 FUNCTIONALITY
** Search String         : Bug_27391596

-----------------------------------------------------------------------------------------
*/

function fnPostNew_KERNEL() {
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = mainWin.Lcy;
	document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
	 document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; 
    document.getElementById("BLK_TRANSACTION_DETAILS__NARRATIVE").value = 'International Cash Transfer';
    return true;

}

function fnPreSave_KERNEL() {

return true ;
}


function fnAssignTxnCcy(p_acc_ccy) {
    document.getElementById('BLK_TRANSACTION_DETAILS__OFFSETCCY').value = p_acc_ccy.value;
    return true;
}

function fnAccCcy(event) {
    if (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value != "") {
        fnDisableElement(document.getElementsByName("TXNCCY")[0]);
    }
    return true;
}

/*
function fnSetHotKeyBranch_KERNEL() {
  
	if (window.getEventSourceElement(event).name == "TXNACC") {
        hotKeyBrn = document.getElementsByName('TXNBRN')[0].value;
    }
    
	if (window.getEventSourceElement(event).name == "OFFSETACC") {
        hotKeyBrn = document.getElementsByName('OFFSETBRN')[0].value;
    }
    return true;
}
*/
function fnPostLoad_KERNEL(e) {
	document.getElementById(mainWin.functionDef[functionId].xRate).oldvalue = document.getElementById(mainWin.functionDef[functionId].xRate).value; 
    document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").oldvalue = document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value;
    var txnAcc = mainWin.functionDef[functionId].txnAcc;
    var txnAccBlock = txnAcc.split("__")[0];
    var txnAccTag = txnAcc.split("__")[1];
    try {
        pickedUpAcc = getNodeText(selectSingleNode(dbDataDOM, "//" + txnAccBlock + '/' + txnAccTag));
        pickedUpCcy = getNodeText(selectSingleNode(dbDataDOM, "//" + 'BLK_TRANSACTION_DETAILS/OFFSETCCY'));
    }
    catch (e) {
    }
	//IF (document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value ==""{
	//if (dataObj.pickupClicked == "Y" && mainWin.functionDef[functionId].newFlow == 'Y'){
	//(document.getElementById("BLK_TRANSACTION_DETAILS__TXNACC").value="";
	
	//}
	//}
    return true;
}
//FCUBS12.4MCY/VA changes starts
function fnResolveVirAcc(event) {
    
    if(dataObj.action == 'INPUT' || dataObj.action == 'ENRICH'){
    var tempDOM ;
	var eventElement = event.srcElement || event.target;//FCUBS_1203_INTERNAL_19459483 added
	//srcElement is only available in IE. In all other browsers it is target
	//Hence, replacing all eventElement with eventElement
    if (eventElement.name == 'UI_TXN_ACC' || eventElement.name == 'TXNCCY') {
        appendData();
        if( getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY"))!= undefined && 
getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY")) == "" && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V')
  document.getElementById('BLK_TRANSACTION_DETAILS__TXNCCY').oldvalue = "";
  if(eventElement.name == 'UI_TXN_ACC'  && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'A' )
  // 1203_ITR1_18388624 starts
		{
			gViraccno = false;
			// 1203_ITR1_18388624 ends
			document.getElementById("BLK_TRANSACTION_DETAILS__CHRACC").value = document.getElementById(eventElement.id).value;
			document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = document.getElementById("BLK_TRANSACTION_DETAILS__ACCCY").value ; 
		}	// 1203_ITR1_18388624
        if (document.getElementById(eventElement.id)!= undefined && document.getElementById(eventElement.id).oldvalue != document.getElementById(eventElement.id).value) {
            if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY")) != '' && getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/UI_TXN_ACC")) != '') {
                if (getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'V' || getNodeText(selectSingleNode(dbDataDOM, "//BLK_TRANSACTION_DETAILS/AC_OR_GL")) == 'M') {
					gViraccno = true; // 1203_ITR1_18388624
                    var tempAction = dataObj.action;
                    dataObj.action = 'RESOLVEVIRTUALACC';
                    fcjRequestDOM = buildUBSXml();
                    addBranchParam(fcjRequestDOM);
                    tempDOM = fcjRequestDOM ;
                    temp_fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
                    try {
                        if (temp_fcjResponseDOM) {
                        
                           var msgStatus = getNodeText(selectSingleNode(temp_fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
                            if (msgStatus == 'FAILURE') {
                                dispErrorNodeForVirAcc(event);
                                self.close();
								document.getElementById("BLK_TRANSACTION_DETAILS__CHRACC").value = '';    //Bug#25817723 added
                            }
                            else {
                            
                         temp_fcjResponseDOM = fnGetDataXMLFromFCJXML(temp_fcjResponseDOM, 1);// Ankit added
						 document.getElementById("BLK_TRANSACTION_DETAILS__OFFSETCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY")); //Bug#25942865
                         document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/BRNCODE"));                       
                         document.getElementById("BLK_TRANSACTION_DETAILS__CHRACC").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNACC"));
						 document.getElementById("BLK_TRANSACTION_DETAILS__ACCCY").value = getNodeText(selectSingleNode(temp_fcjResponseDOM, "//BLK_TRANSACTION_DETAILS/TXNCCY")); 
                     }
                        }
                    }
                    catch (e) {
                        showErrorAlerts('GW-REOPR-01');
                    }
                    
                    dataObj.stepNo = dataObj.stepNo + 1;
                    dataObj.action = tempAction;

                }
            }
        }
    }
    }
      return true;
}
//FCUBS12.4MCY/VA changes ends
//Bug_27391596 comment starts
/*
//Bug_27293598 - start
function fnSetHotKeyBranch_KERNEL(e)
{
	var event=window.event||e;
	var srcElement=getEventSourceElement(event);
	var srcID=srcElement.id;
	if (srcID =='BLK_TRANSACTION_DETAILS__UI_TXN_ACC')
	hotKeyBrn = document.getElementById("BLK_TRANSACTION_DETAILS__TXNBRN").value;
	return true;
}
//Bug_27293598 end
*/
//Bug_27391596 comment ends