/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2011 - 2014  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*----------------------------------------------------------------------------------------------------
**
** File Name    : 8308_1_KERNEL.js
**
** Module       : FCJWeb
**
** This source is part of the FLEXCUBE Corporate - Corporate Banking
** Software System and is copyrighted by Oracle Financial Services Software Limited.

** All rights reserved.  No part of this work may be reproduced,
** stored in a retrieval system, adopted or transmitted in any form
** or by any means, electronic, mechanical, photographic, graphic,
** optic recording or otherwise, translated in any language or
** computer language, without the prior written permission  from Oracle Financial 
** Services Software Limited.


**  Oracle Corporation
**  World Headquarters
**  500 Oracle Parkway
**  Redwood Shores, CA 94065
**  U.S.A.
**  
**  Copyright � 2011- 2012 by Oracle Financial Services Software Limited.
**  Oracle Financial Services Software Limited.

	Modified By           : Sriraam S
	Modified On           : 06-Feb-2014
	Modified Reason       : INSTRBRN AND ACBRN values madified, Base Bug#18096285
	Search String         : 9NT1587_1203_INTERNAL_18191871	
	

	Modified By           : Sriraam S
	Modified On           : 06-Feb-2014
	Modified Reason       : The Defaulting of ACNO value to Null is done only when action is INPUT
	Search String         : 9NT1525_1203_INTERNAL_18194553
	
	Modified By           : Teja 
	Modified On           : 03-Aug-2014
	Modified Reason       : Exchange Rate to be sent null from Input to Enrich
	Search String         : 9NT1620_1203_RETRO_19350327
	
	** Modified By         : TEJA
	** Modified On         : 23-Sep-2014
	** Modified Reason     : Fix provided to nullify GL Amount.
	** Search String       : 9NT1620_1203_RETRO_19664241
**
** Modified By         : Shayam Sundar Ragunathan
** Modified On         : 03-Aug-2017
** Modified Reason     : The issue was occuring due the issuance chrges getting picked up during querying the instrument details. 
                         Fix given to nullify the charges and the related amounts,so that on pickup the correct values get picked up.
** Search String       : 9NT1606_12_4_RETRO_12_1_26384652 
----------------------------------------------------------------------------------------------------
*/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
//FCUBS 11.3.1 - IUT- SFR#809 - starts
if(dataObj.action == 'INPUT' ) { //9NT1525_1203_INTERNAL_18194553 added
	document.getElementsByName("ACNO")[0].value = '';
	document.getElementsByName("ACCTITLE")[0].value = '';
	document.getElementById("BLK_TRANSACTION_DETAILS__ACTAMT").value = "";  //9NT1620_1203_RETRO_19664241
//FCUBS 11.3.1 - IUT- SFR#809 - end
} //9NT1525_1203_INTERNAL_18194553 added
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

	 showTabData(document.getElementById("TBLPage" + strCurrentTabId));
	return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	appendData(document.getElementById('TBLPage' + strCurrentTabID));

	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}


function fnPostQuery_KERNEL(){
try{
  		 document.getElementById("BLK_TRANSACTION_DETAILS__TXNDATE").value = mainWin.currBranchDate;
		 document.getElementById("BLK_TRANSACTION_DETAILS__LIQDDATE").value = mainWin.currBranchDate;
		 //9NT1466_FCUBS_11.3.1_DeCentralised_and_Offline_Branch STARTS
		 document.getElementsByName('INSTRTYPE')[0].value ='BCG';
		 document.getElementsByName('ACNO')[0].value = '';
		 document.getElementsByName('ACCTITLE')[0].value = '';
		 //document.getElementsByName('ISSBRN')[0].value = mainWin.CurrentBranch; //9NT1525_1203_INTERNAL_18194553 Commented
		 document.getElementsByName('ACCCY')[0].value = '';
		 document.getElementsByName('ACBRN')[0].value = mainWin.CurrentBranch; //9NT1525_1203_INTERNAL_18194553 Added
		 //9NT1466_FCUBS_11.3.1_DeCentralised_and_Offline_Branch ENDS
        document.getElementsByName('EXCHRATE')[0].value = ''; //9NT1620_1203_RETRO_19350327 added
		document.getElementById("BLK_TRANSACTION_DETAILS__ACTAMT").value = "";  //9NT1620_1203_RETRO_19664241
				//9NT1606_12_4_RETRO_12_1_26384652 STARTS
				document.getElementsByName('TCYTOTCHGAMT')[0].value ='';
				fireHTMLEvent(document.getElementsByName('TCYTOTCHGAMT')[0], "onpropertychange");
				document.getElementsByName('ACTAMT')[0].value ='';
				fireHTMLEvent(document.getElementsByName('ACTAMT')[0], "onpropertychange");			
                var chargeNode = selectNodes(dbDataDOM, "//BLK_CHARGE_DETAILS");
                for (var i = 0;i < chargeNode.length;i++) {
                    chargeNode[i].parentNode.removeChild(chargeNode[i]);
                }
            //9NT1606_12_4_RETRO_12_1_26384652 ENDS	
		 }
		 catch(e) { 
	 }
 return true ;   
}