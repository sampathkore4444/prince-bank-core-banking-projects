/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2009  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/

zeroAndNegativeVal=false; //12.1_ITR2_21837854 
//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event

try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	 addlArgs['LOV_AMT'] = null;
	if(getEventSourceElement(e).name == 'ACC') {
	//BLK_CUST_ACCOUNT__ACC
	var a = 'BLK_CUST_ACCOUNT__TXNCCY' ;
    var b = 'BLK_CUST_ACCOUNT__TXNCCY';
	var c = 'BLK_CUST_ACCOUNT__ACTAMT' ;
	var d = 'BLK_CUST_ACCOUNT__ACTAMT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
		//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_21317625
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}
	}catch(e){}

	return true; 

}
//12.1_SV_changes  ends