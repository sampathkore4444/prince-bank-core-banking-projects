/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2012  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1317_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : SUHAS REKHU
**  Last modified on   : 23-NOV-2010
**  Full Version       : 
**  Reason             : 9NT1428 -ITR1-SFR#1038  ,POPULATE THE AC_NO


    Changed By         :  Kundan Verma
    Description        :  Changed language code while searching from ertb_msgs
    Search String      :  FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
	
    Changed  By           : Gokulnath M
    Changed  On           : 16-Apr-2012
    Modified Reason       : Default Maturity value reassigned
    Search String          : 9NT1501 ITR1 sfr 13960491	
    
    Changed  By           : Reddy Prasad
    Changed  On           : 24-Jul-2013
    Modified Reason       : 1317 - PAYOUT TO TD IS NOT FETCHING ACCOUNT NUMBER IN OPERA
    Search String          : 9NT1587 12.0.2 ITR1 17181267
    Changed  By           : Sriraam S
    Changed  On           : 14-May-2014
    Modified Reason       : Reset Payout Redemption amount on change of Payout Percentage , Total Redemption amount (for Partial Redemption), 
																																Waive Interest
    Search String         : 9NT1587_1203_INTERNAL_18912683
	
	Changed  By           : Ankit
    Changed  On           : 19-Jun-2015
    Modified Reason       : The java call has been routed to EnrichHandler.
    Search String         : 12.1_IQA_21270478
	
	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!IMPORTANT !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!SHOW DEFAULT VALUES NOT ADDED YET
	
**  Changed  By           : Shayam Sundar Ragunathan
**  Changed  On           : 10-Feb-2017
**  Modified Reason       : Branch code defaulted to the transaction branch on screen launch.
**  Search String         : 9NT1606_12_3_RETRO_12_1_25402459 
**
**  Changed  By           : Shayam Sundar Ragunathan
**  Changed  On           : 10-Feb-2017
**  Modified Reason       : Resetting the payout account and branch is cash mode is changed to cash after selecting it as account.
**  Search String         : 9NT1606_12_3_RETRO_12_0_3_25400290
**
**  Changed  By           : Shayam Sundar Ragunathan
**  Changed  On           : 14-Jul-2017
**  Modified Reason       : Pickup mandatory for 1317
**  Search String         : 9NT1606_12_4_RETRO_12_2_26440914
**
**  Changed  By           : Shayam Sundar Ragunathan
**  Changed  On           : 28-Aug-2017
**  Modified Reason       : Changes done to throw override when charges are amended or waived.
							firstpickup variable was not set to Y, due to this charge values were not
							inserted into fbtb_ovd table. Hence, charge amendment validation was not happening on save.
**  Search String         : 9NT1606_12_4_RETRO_12_2_26709601

**  Changed  By           : Mantinder Kaur
**  Changed  On           : 16-Apr-2018
**  Modified Reason       : After pickup if the user visits the denominated deposit tab,payout details tab is getting enabled.
							Fix provided to disable the tabs after pickup is done once.
**  Search String         : FCUBS_124_SAIGON_27859153 


**  Modified By			: Himanshu Chowdhary
**  Modified On			: 02-May-2018
**  Modified Reason     : System was not allowing user to Compute without entering the Payout details. Modified the condition to skip the payout detail validation on compute. 
						  Also, Pickup made mandatory to calculate cash amounts to correctly update the till balances.
**  Search String       : FCUBS_124_SAIGON_27953095
****************************************************************************************************************************/

//FCUBS_121_INTERNAL_21796906 starts
function fnDisableTDTabs(dependDataObj){
try{
		if(tdSaveClicked && !disableTDTabs){ //If save clicked and Pickup not yet clicked / fields are yet to be disabled
			tdSaveClicked = false;
			return;
			}
		//After Pickup || if tabs already disabled || launched from workflow after Hold || Save
		if(!dependDataObj || disableTDTabs || (dataObj != null && (dataObj.stage == "50" || (dataObj.oldTxnStat != null && dataObj.oldStageStat != null && dataObj.oldTxnStat.length >= 3 && dataObj.oldStageStat.length >= 3)))){
				disableTDTabs = true;
				disableForm();
				fnEnableElement(document.getElementById("BTN_OK"));
				fnEnableElement(document.getElementById("BTN_EXIT_IMG"));
			}
	}catch(e){}	
}
//FCUBS_121_INTERNAL_21796906 ends
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");  
	document.getElementById('BLK_TD_REDEMPTION__BRN_CODE').value = g_txnBranch;	//9NT1606_12_3_RETRO_12_0_1_25402459
	fnSaveAll = fnTdredmDenomval;
	//9NT1501 ITR1 sfr 13970179
	if(document.getElementsByName("REDEMPTION_MODE")[0].value == 'N')	{
		fnEnableElement(document.getElementsByName("WAVE_PENALTY")[0]);
		fnEnableElement(document.getElementsByName("WAIVE_INTEREST")[0]);
	}
	else {
		fnDisableElement(document.getElementsByName("WAVE_PENALTY")[0]);
		fnDisableElement(document.getElementsByName("WAIVE_INTEREST")[0]);
	}
	fnDisableTDTabs(true); //FCUBS_121_INTERNAL_21796906 starts
	return true;
}

//9NT1606_12_3_RETRO_12_0_3_25400290 starts
function fnResetAcc(event){
if (document.getElementById("BLK_TDREDMPAYOUT_DETAILS__PAYOUTTYPE").value=='C'){

	document.getElementById("BLK_TDREDMPAYOUT_DETAILS__OFFSET_ACC").value ="";
	document.getElementById("BLK_TDREDMPAYOUT_DETAILS__OFFSET_BRN").value ="";	
}
}
//9NT1606_12_3_RETRO_12_0_3_25400290 ends
//9NT1587_1203_INTERNAL_18912683 starts
function fnResetRedemAmt(){
    var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
    var tableObject;
    var rowList;
    var percentageEntered;
     try
        {
            tableObject = document.getElementById(meblkName);
            rowList = tableObject.tBodies[0].rows;
            if(rowList != null && rowList.length > 0){
                percentageEntered = rowList[0].cells[2].getElementsByTagName("INPUT")[0].value;
                if(percentageEntered != null && (percentageEntered.replace(/\s+/g, ' ')).length > 0){
                    if(!(document.getElementsByName("REDMAMT")[0].disabled)){
                            for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
                             {
                                 document.getElementsByName("REDMAMT")[rowIndex].value  = "";               
                             }
                        }
                }
            }
         }
         catch(e)
	    {}
}
//Will be trigerred onChange of Percentage in Input stage
//Sample value of Id is --> "BLK_TDREDMPAYOUT_DETAILS__PERCENTAGEI" for 1st row, "BLK_TDREDMPAYOUT_DETAILS__PERCENTAGEI6" for 7th row
function fnRedemAmtReset(event){
    var rowIndex = event.srcElement.id.substring(event.srcElement.id.length-1,event.srcElement.id.length);
    if (isNaN(rowIndex)){
      document.getElementsByName("REDMAMT")[0].value  = "";
    }
    else{
		for (var index = 0; index <=rowIndex; index++) 
        document.getElementsByName("REDMAMT")[index].value  = ""; 
    } 
}
//9NT1587_1203_INTERNAL_18912683 Ends
function fnPreLoad_CVS_TDPAYOUT_KERNEL(screenArgs)
{
  //9NT1587 12.0.2 ITR1 17181267  Starts
	var ua = navigator.userAgent.toLowerCase(); 	
	if((ua.indexOf("opera") != -1)) {
		dbDataDOM = loadXMLDoc(getXMLString(dbDataDOM));
	}
	//9NT1587 12.0.2 ITR1 17181267  Ends  
	screenArgs['BRN']        = document.getElementById("BLK_TD_REDEMPTION__BRN_CODE").value;
	screenArgs['ACC']        = document.getElementById("BLK_TD_REDEMPTION__AC_NO").value;//17187519_TD Changes. Uncommented this line
	screenArgs['CCY']        = document.getElementById("BLK_TD_REDEMPTION__CCY").value;
	screenArgs['CUSTNO']     = document.getElementById("BLK_TD_REDEMPTION__CUST_ID").value;
	//screenArgs['ACCLS']      = document.getElementById("BLK_TD_REDEMPTION__ACCLS").value;
	//screenArgs['MATDT']      = document.getElementById("BLK_TDDETAILS__MATDT").value;
	screenArgs['REQ']        = fcjResponseDOM;
	var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
	    var tableObject;
	    var rowList;
		var ddcnt = 0;
		var bccnt = 0;
		var instrtype = "";
	    try
	    {
	        tableObject = document.getElementById(meblkName);
		    rowList = tableObject.tBodies[0].rows.length;
	    } catch(e)
	    {}
		
		for (var rowIndex = 0; rowIndex < rowList; rowIndex++)
	        {
			if (document.getElementsByName("PAYOUTTYPE")[rowIndex].value == 'D')
			{
			ddcnt = ddcnt+1;
			}
			else if (document.getElementsByName("PAYOUTTYPE")[rowIndex].value == 'B')
			{
			bccnt = bccnt+1;
			}
			}
		
			if (ddcnt >= 1 & bccnt >= 1)
			{
			  
			  showErrorAlerts('BRN-VAL-001');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			  
			  
			  //alert('In multi mode term deposit payout,a combination of Bankers Cheque and Demand Draft cannot be choosen');
	          return false;		  
			}
			else if (ddcnt > 1)
			{
			
			showErrorAlerts('BRN-VAL-002');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			//alert('In multi mode term deposit payout,type Demand Draft Cannot be choosen more than once');
			return false;
			}
		   else if (bccnt > 1)
			{
			
			showErrorAlerts('BRN-VAL-003');  // FC_UBS_V.UM_11.3.0.0.0.0.0 NLS Changes
			
			
			//alert('In multi mode term deposit payout,type Bankers Cheque Cannot be choosen more than once');
			return false;
			}
			else if (ddcnt == 1)
			{
			    instrtype = 'DDA';
			}
			else if (bccnt == 1)
			{
			    instrtype = 'BCA';
			}
			
			screenArgs['INSTRTYPE']  = instrtype;
		

    return true;
}

/*function fnShowDefultValues() {
	
     var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
	 var tableObject;
	 var rowList;
	var cashflg;
	var denomAmt = 0.0;
   
    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

	  fnComputeAmount();

	 if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {  			
			cashflg = rowList[rowIndex].cells[1].getElementsByTagName("SELECT")[0].value;
			if (cashflg == 'C')
			{
			 denomAmt = getCalcAmount(rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value);
			}            

		   }		
		}  

	 document.getElementById("BLK_TD_REDEMPTION__DENOMAMT").value =  denomAmt;
	// document.getElementById("BLK_TDDETAILS__DENOMAMT").value =  denomAmt;
	 return true;
}
*/

function fnShowDefultValues() {
	
     var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
	 var tableObject;
	 var rowList;
	var cashflg;
	var denomAmt = 0.0;
	var percentageEntered; //9NT1587_1202_INTERNAL_16999937 Added

    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

	 if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {  			
			cashflg = rowList[rowIndex].cells[1].getElementsByTagName("SELECT")[0].value;
			if (cashflg == 'C')
			{
			//9NT1587_1202_INTERNAL_16999937 Starts
			//denomAmt = getCalcAmount(rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value);
			 percentageEntered = rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value;
			 if(percentageEntered == null || (percentageEntered != null && (percentageEntered.replace(/\s+/g, ' ')).length == 0)){
			 document.getElementById("BLK_TD_REDEMPTION__DENOMAMT").value  = rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value;		
			}     
			break;
		    //9NT1587_1202_INTERNAL_16999937 Ends
			}            

		   }		
		}  

	 //document.getElementById("BLK_TD_REDEMPTION__DENOMAMT").value =  denomAmt; //9NT1587_1202_INTERNAL_16999937 Commented
	// document.getElementById("BLK_TDDETAILS__DENOMAMT").value =  denomAmt;
	 return true;
}
function fnComputeAmount(){
	var matinst = document.getElementById("BLK_TD_REDEMPTION__DEF_MATR_INST").value;
	var meblkName = "BLK_TDREDMPAYOUT_DETAILS";
    var tableObject;
    var rowList;
    try
    {
        tableObject = document.getElementById(meblkName);
        rowList = tableObject.tBodies[0].rows;
    } catch(e)
    {}

    var totalcompamt=0;       
    var rowamount = 0;
	var compamt = 0;
	var percentage;
	var totalPercentage = 0.00;
	var tdamt = document.getElementById("BLK_TD_REDEMPTION__REDEMPTION_AMT").value;

    if (rowList != undefined && rowList.length != 0)
    {
        for (var rowIndex = 0; rowIndex < rowList.length; rowIndex++)
        {
			if (rowIndex == (rowList.length-1))
			{
				percentage = 100.00 -  floatingPointMultiplication(totalPercentage,1);
				compamt =   floatingPointMultiplication(tdamt,1) - floatingPointMultiplication(totalcompamt,1);  
				totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(compamt,1);
			}
		   else {
          
		    percentage = rowList[rowIndex].cells[2].getElementsByTagName("INPUT")[0].value;
			rowamount = rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value;
		   if((rowamount != "" || rowamount != null) && 	(percentage == "" || percentage == null))
			   {
				 totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(rowamount,1);
				 compamt = 	rowamount;
				 totalPercentage = floatingPointMultiplication(totalPercentage,1)  + floatingPointMultiplication(percentage,1) ;
			   }
           	else{
            totalPercentage = floatingPointMultiplication(totalPercentage,1) +  floatingPointMultiplication(percentage,1) ;
			compamt = (floatingPointMultiplication(percentage,tdamt))/ 100.00;
           	totalcompamt = floatingPointMultiplication(totalcompamt,1) + floatingPointMultiplication(compamt,1);
		   }

		}
		if (isNaN(parseInt(compamt))) {
		  compamt = "";
        }
		rowList[rowIndex].cells[3].getElementsByTagName("INPUT")[0].value = compamt;
		} 	

	} 
	document.getElementById("BLK_TD_REDEMPTION__DEF_MATR_INST").value = matinst; 
return true;	
}

function fncompute()
{
    tempaction = dataObj.action;  
	var matinst = document.getElementById("BLK_TD_REDEMPTION__DEF_MATR_INST").checked; //9NT1501 ITR1 sfr 13960491
 dataObj.action = 'ENRICH';	
 fnResetRedemAmt(); //9NT1587_1203_INTERNAL_18912683 added
    appendData();
    dataObj.action = 'COMPUTE';
    fcjRequestDOM = buildUBSXml();
    addBranchParam(fcjRequestDOM);
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=compute&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
    if (fcjResponseDOM && getXMLString(fcjResponseDOM).length > 0) 
    {
	    enableForm();
        dataObj = new dataObject(getXMLString(fcjResponseDOM));
        var returnValue = fnHandleError();
    } else {
	     enableForm();
        alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
        return;
    }
	dataObj.action = tempaction;
	dataObj.firstPickup ="Y"; //FCUBS_124_SAIGON_27953095
	enableForm();
	//9NT1501 ITR1 sfr 13960491
	if (matinst) {
	document.getElementById("BLK_TD_REDEMPTION__DEF_MATR_INST").checked = true; 
	}
	fnDisableElement(document.getElementById('BLK_TD_REDEMPTION__DEF_MATR_INST'));
	document.getElementById("BLK_TD_REDEMPTION__BTN_COMPUTE").focus();
	//return true; 
    //var returnVal = displayResponse(messageNode);	
return true;
}	
//achelal changes starts
/* //Commented as CCY is read-only field in RAD.
function fnAccCCy(e)
{
	if (document.getElementById("BLK_TD_REDEMPTION__AC_NO").value != "") {
		fnDisableElement(document.getElementsByName("CCY")[0]);
	}
 return true;
}
*/
function fnPopCertDet(){ //Function is given for populating the Denom certification details on tab out of Account field.
debugs("In fnPopCertDet", "A");  
fnPostReturnValToParent_LOV_AC_NO_KERNEL();
}
function fnChangeRedemMode(event)
{
if(document.getElementsByName("REDEMPTION_MODE")[0].value == 'N')
{
document.getElementsByName("REDEMPTION_AMTI")[0].value = document.getElementsByName("ACCOUNT_BALANCE")[0].value;
document.getElementsByName("REDEMPTION_AMTI")[0].value = document.getElementsByName("ACCOUNT_BALANCE")[0].value;
fnDisableElement(document.getElementsByName("REDEMPTION_AMT")[0]);
document.getElementsByName("REDEMPTION_AMTI")[0].focus();
}
else
{
document.getElementsByName("REDEMPTION_AMTI")[0].value = "";
document.getElementsByName("REDEMPTION_AMTI")[0].value = "";
fnEnableElement(document.getElementsByName("REDEMPTION_AMT")[0]);
document.getElementsByName("REDEMPTION_AMTI")[0].focus();
}
 return true;
}
function fndefault()
{
if(document.getElementById('BLK_TD_REDEMPTION__DEF_MATR_INST').checked=true)
{
    tempaction = dataObj.action;  
 dataObj.action = 'ENRICH';	
    appendData();
    dataObj.action = 'DEFAULT_PAYOUT';
    fcjRequestDOM = buildUBSXml();
    addBranchParam(fcjRequestDOM);
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=default&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);
    if (fcjResponseDOM && getXMLString(fcjResponseDOM).length > 0) 
    {
	    enableForm();
        dataObj = new dataObject(getXMLString(fcjResponseDOM));
        var returnValue = fnHandleError();
    } else {
	     enableForm();
        alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
        return;
    }
	dataObj.action = tempaction;
	enableForm();
	document.getElementById('BLK_TD_REDEMPTION__DEF_MATR_INST').checked=true;
	fnDisableElement(document.getElementById('BLK_TD_REDEMPTION__DEF_MATR_INST'));
	document.getElementById('BLK_TD_REDEMPTION__WAIVE_INTEREST').focus();
	}
return true;
}	
//achelal changes ends


//12.0.2 TD Enhancement-Denominated Deposit <Satrt>
var result_flag = "";
//17059489_12.0.2 TD Change <Start>
function fnPostNew_KERNEL(e) {
    document.getElementsByName("cmdAddRow_" + 'BLK_DENOM_DEPOSIT')[0].style.display = "none";
    document.getElementsByName("cmdDelRow_" + 'BLK_DENOM_DEPOSIT')[0].style.display = "none";
    return true;
}

function fnSelectAllCertif(event) {
    if (!document.getElementsByName("SELECT_ALL")[0].checked) {
        //17153583_12.0.2 TD Changes <Start>		
        for (i = 1;i <= selectNodes(dbDataDOM, "//BLK_DENOM_DEPOSIT").length;i++)
            setNodeText(selectSingleNode(dbDataDOM, "//BLK_DENOM_DEPOSIT[@ID=" + i + "]/BLOCK_OR_REDEM"), 'N');
        //17153583_12.0.2 TD Changes <End>
        var totalRows = document.getElementById('BLK_DENOM_DEPOSIT').tBodies[0].rows.length;
        for (var i = 0;i < totalRows;i++)
            document.getElementsByName("BLOCK_OR_REDEM")[i].checked = false;
    }
    else {
        //17153583_12.0.2 TD Changes <Start>
        for (i = 1;i <= selectNodes(dbDataDOM, "//BLK_DENOM_DEPOSIT").length;i++)
            setNodeText(selectSingleNode(dbDataDOM, "//BLK_DENOM_DEPOSIT[@ID=" + i + "]/BLOCK_OR_REDEM"), 'R');
        //17153583_12.0.2 TD Changes <End>
        var totalRows = document.getElementById('BLK_DENOM_DEPOSIT').tBodies[0].rows.length;
        for (var i = 0;i < totalRows;i++)
            document.getElementsByName("BLOCK_OR_REDEM")[i].checked = true;
    }
    return true;
}
//17153583_12.0.2 TD Changes <Start>
function fnUnSelectAllCertif(event) {

    var rowindex = getRowIndex(event);
    if (!document.getElementsByName("BLOCK_OR_REDEM")[rowindex - 1].checked)
        document.getElementsByName("SELECT_ALL")[0].checked = false;
    return true;
}
//17153583_12.0.2 TD Changes <End>

//FCUBS_121_INTERNAL_21796906 starts
function fnTdRedeemEnrich(){
	dataObj.firstPickup = "Y";  //9NT1606_12_4_RETRO_12_2_26709601
fnEnrich();
	if(handleErrMsgStatus == "SUCCESS")
		fnDisableTDTabs(false);
	else
	fnDisableTDTabs(true); 
}
//FCUBS_121_INTERNAL_21796906 ends

function fnPopulateRedmnAmt(event) {
    //alert('test fnPopulateRedmnAmt');
    fnHitBackend('DENOMTOTAL');
	//FCUBS_121_INTERNAL_21796906 starts
	if(handleErrMsgStatus == "SUCCESS")
		fnDisableTDTabs(false);
	else
	fnDisableTDTabs(true); 
	//FCUBS_121_INTERNAL_21796906 ends
    if (result_flag == "true")
        return true;
    if (result_flag == "false")
        return true;
}

function fnHitBackend(action) {
    if (action == "" || action == 'undefine')
        return;
    appendData();
    result_flag = "";
    var prevAction = dataObj.action;
    dataObj.action = action;
    fcjRequestDOM = buildUBSXml();
    addBranchParam(fcjRequestDOM);
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL + "?msgType=ENRICH&actionType=enrich&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);

    if (fcjResponseDOM && getXMLString(fcjResponseDOM).length > 0) {
        dataObj = new dataObject(getXMLString(fcjResponseDOM));
        var returnValue = fnHandleError();
        if (returnValue == "SUCCESS")
            result_flag = "true";
		dataObj.pickupClicked = "N";//9NT1606_12_4_RETRO_12_2_26440914
    }
    else {
        alert(parent.getItemDesc("LBL_PROCESS_FAIL"));
        fnEnableElement(document.getElementsByName("BTN_FETCH")[0]);
        fnEnableElement(document.getElementsByName("ACC")[0]);
        result_flag = "false";
        return false;
    }
    dataObj.action = prevAction;
    result_flag = "true";
    return true;
}
//12.0.2 TD Enhancement-Denominated Deposit <End>

//17184023_12.0.2 TD Changes <Start>
function fnPostReturnValToParent_LOV_AC_NO_KERNEL(){
    appendData();
    var g_prev_gAction = gAction;
    var g_prev_dataObjAction = dataObj.action;//17247445_12.0.2 TD Changes
    dataObj.action = "POPDENOM";
    var l_processMsg = showProcessMsg;
    showProcessMsg = false;
    fcjRequestDOM = buildBrnUBSXml();//buildUBSXml();
    //fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId); //12.1_IQA_21270478
	fcjResponseDOM = fnPost(fcjRequestDOM, serverURL + "?msgType=ENRICH&actionType=popdenom&funcid=" + functionId + "&XREF=" + dataObj.xref, functionId);//12.1_IQA_21270478
    var orgDom = loadXMLDoc(getXMLString(dbDataDOM));
    if (!fnProcessResponse()) {
        //if (!fnProcessBrnResponse()) {
        gAction = g_prev_gAction;
        dataObj.action = g_prev_dataObjAction;//17247445_12.0.2 TD Changes
        dbDataDOM = loadXMLDoc(getXMLString(orgDom));
        return false;
    }
    showProcessMsg = l_processMsg;
    gAction = g_prev_gAction;
    dataObj.action = g_prev_dataObjAction;//17247445_12.0.2 TD Changes
    return true;
}
//17184023_12.0.2 TD Changes <End>

//12.1_SV_changes starts
function fnAmountF12_KERNEL(addlArgs,e ) {  //12.1_IQA_21317625 added event
try {
	//a = account ccy :: b = transaction ccy :: c = transaction amount d :: account amt without charges
	var a = 'BLK_TD_REDEMPTION__CCY' ;
    var b = 'BLK_TD_REDEMPTION__CCY';
	var c = 'BLK_TD_REDEMPTION__REDEMPTION_AMT' ;
	var d = 'BLK_TD_REDEMPTION__REDEMPTION_AMT' ; 
		//if(!f12Validation(a, b, c, d))//12.1_IQA_21238670
		//		if(!f12Validation(a, b, c, d , addlArgs )) //12.1_IQA_21238670  // 12.1_IQA_21317625
				if(!f12Validation(a, b, c, d , addlArgs ,e )) //12.1_IQA_21317625
		return false ;
	}catch(e){}
	return true; 

}
//12.1_SV_changes  ends
//FCUBS_124_SAIGON_27859153 starts
function fnInTab_TAB_DENOM_DEP_KERNEL(){
	if (dataObj.firstPickup =="N"){
	fnDisableTDTabs(strCurrentTabId,true);
	}
return true;
} 

function fnInTab_TAB_PAYOUT_KERNEL(){
	if (dataObj.firstPickup =="N"){
	fnDisableTDTabs(strCurrentTabId,true);
	} 
return true;
} 
//FCUBS_124_SAIGON_27859153 ends