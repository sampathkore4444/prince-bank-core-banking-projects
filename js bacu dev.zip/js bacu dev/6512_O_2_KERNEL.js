/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2009  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/***************************************************************************************************************************
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 6512_2_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//var fcjRequestDOM;
//var fcjResponseDOM;

//var gErrCodes = "";

/*
 * Called to perform some neccessary operation before the fnLoad() Window event
 * Specific to the functionid
 */
function fnPreLoad_KERNEL() {
	debugs("In fnPreLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Window event
 * Specific to the functionid
 */
function fnPostLoad_KERNEL() {
	debugs("In fnPostLoad", "A");
	return true;
}
/*
 * Called to perform some neccessary operation before the fnNew() Action event
 * Specific to the functionid
 */
function fnPreNew_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnNew() Action event
 * Specific to the functionid 
 */
function fnPostNew_KERNEL() {

    
    return true;
    	
}
/*
 * Called to perform some neccessary operation before the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPreUnlock_KERNEL() {
	var unlock = true;
	return true;
}
/*
 * Called to perform some neccessary operation after the fnUlock() Action event
 * Specific to the functionid 
 */
function fnPostUnlock_KERNEL() {
	debugs("In fnPostUnlock", "A");
        return true;
}
/*
 * Called to perform some neccessary operation before the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPreAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnAuthorize() Action event
 * Specific to the functionid 
 */
function fnPostAuthorize_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPreCopy_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnCopy() Action event
 * Specific to the functionid 
 */
function fnPostCopy_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation before the fnClose() Window event
 * Specific to the functionid 
 */
function fnPreClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnClose() Window event
 * Specific to the functionid 
 */
function fnPostClose_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPreReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnReOpen() Window event
 * Specific to the functionid 
 */
function fnPostReOpen_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPreDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnDelete() Action event
 * Specific to the functionid 
 */
function fnPostDelete_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPreEnterQuery_KERNEL() {
       
	return true;
}
/*
 * Called to perform some neccessary operation after the fnEnterQuery() Action event
 * Specific to the functionid 
 */
function fnPostEnterQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation before the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPreExecuteQuery_KERNEL() {
	return true;
}
/*
 * Called to perform some neccessary operation after the fnExecuteQuery() Action event
 * Specific to the functionid 
 */
function fnPostExecuteQuery_KERNEL() {
	return true;
}

/*
 * Called to perform some neccessary operation before the fnSave() Action event and
 * this function has to return a success/failure flag to fnSave function.
 * Specific to the functionid.
 */
function fnPreSave_KERNEL() {
		
	var isValid = true;
		//Copy from Other Blocks
		//alert('Am here in Presave');

		var totalRows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows.length;
		//alert('totalRows' + totalRows);
		//alert('rowindex' + rowindex);
		for(var i=0; i< totalRows; i++){
			//alert('iNSTRUMENT CCY1'+document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value);
			document.getElementById("BENACCOUNT")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__BENACCOUNT1").value;
			document.getElementById("TXNDATE")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNDATE1").value;
			document.getElementById("XRATE")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__XRATE1").value;
		    document.getElementById("CUSTID")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__CUSTID1").value;
		    document.getElementById("ACCTITLE")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__ACCTITLE1").value;
			//document.getElementsByName("INSTRCCY")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__INSTRCCY1").value;
			document.getElementById("TXNCCY")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__TXNCCY1").value;
			//document.getElementsByName("ACTAMT")[i].value =document.getElementById("BLK_TRANSACTION_DETAILS__ACTAMT1").value;
	        //alert('BENACCOUNT'+ document.getElementsByName("BENACCOUNT")[i].value);
			//alert('BENACCOUNT1'+ document.getElementsByName("BENACCOUNT1")[i].value);
	}
appendTabData(document.getElementById('TBLPageTAB_CHEQUES'));
	// Do Mandatory validations
	

	// Do basic datatype validations
	

	// Get all the Messages from Previuos Validate and now
	// display all
	if (!isValid) {
		//Call Functions in Util
		var msg = buildMessage(gErrCodes);
		alertMessage(msg);
		return false;
	}
	
	return true;	
}
/*
 * Called to perform some neccessary operation after the fnSave() Action event
 * Specific to the functionid 
 */
function fnPostSave_KERNEL() {
	return true;
}
function fnPreLoad_Summary(){
   
}
function fnPostSave() {	//CHANDRA
	return true;
}

function fnPreAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_CHARGE_KERNEL() {
    return true;
}

function fnPreAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostAddRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPreDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}

function fnPostDeleteRow_TAB_DENOM_KERNEL() {
    return true;
}
function fnInTab_TAB_DENOM_KERNEL()  {

		return true;
}
function fnOutTab_TAB_DENOM_KERNEL(){

	
	return true;
}

function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}
function fnInTab_TAB_CHARGE_KERNEL() {
    return true;
}

 function fnShowDefultValues()
{
		
	try{
	   var clearing_rows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows;
	 	
    document.getElementsByName('BENACCOUNT1')[0].value=clearing_rows[0].cells[11].getElementsByTagName("INPUT")[0].value;
	document.getElementsByName('TXNCCY1')[0].value=clearing_rows[0].cells[16].getElementsByTagName("INPUT")[0].value ;
	document.getElementsByName('CUSTID1')[0].value=clearing_rows[0].cells[18].getElementsByTagName("INPUT")[0].value  ;
	document.getElementsByName('ACCTITLE1')[0].value=clearing_rows[0].cells[20].getElementsByTagName("INPUT")[0].value ;
	document.getElementsByName('XRATE1')[0].value=clearing_rows[0].cells[19].getElementsByTagName("INPUT")[0].value	 ;
	//document.getElementsByName('ACTAMT1')[0].value=clearing_rows[0].cells[5].getElementsByTagName("INPUT")[0].value  ;
	}catch(e) {	}

}
function fnFunctionDefultValues() {
	try{
	   var clearing_rows = document.getElementById("BLK_CLEARING_DETAILS").tBodies[0].rows;
	 	
    document.getElementsByName('BENACCOUNT1')[0].value=clearing_rows[0].cells[11].getElementsByTagName("INPUT")[0].value;
	document.getElementsByName('TXNCCY1')[0].value=clearing_rows[0].cells[16].getElementsByTagName("INPUT")[0].value ;
	document.getElementsByName('CUSTID1')[0].value=clearing_rows[0].cells[18].getElementsByTagName("INPUT")[0].value  ;
	document.getElementsByName('ACCTITLE1')[0].value=clearing_rows[0].cells[20].getElementsByTagName("INPUT")[0].value ;
	document.getElementsByName('XRATE1')[0].value=clearing_rows[0].cells[19].getElementsByTagName("INPUT")[0].value	 ;
	//document.getElementsByName('ACTAMT1')[0].value=clearing_rows[0].cells[5].getElementsByTagName("INPUT")[0].value  ;
	}catch(e) {	}

}
