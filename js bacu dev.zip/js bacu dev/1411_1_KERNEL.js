/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2011  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1411_1_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/
function fnPostLoad_KERNEL()
	{
	//document.getElementById("BLK_DENOMINATION_SE__CDCCY").value=document.getElementById("BLK_INTRA_BRANCH__TXNCCY").value;
	//disableForm();
	}

  
  /*function fnPostLoad_KERNEL()
	{
    fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO")); 
	}

	
 function enableLov() {
    if(document.getElementById("BLK_INTRA_BRANCH__ADVANCE_REG_SEND").checked == true)
	{
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO"));
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__FROM_BRANCH")); 
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__FROM_VAULT_TIL")); 
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__TO_BRANCH")); 
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__TO_VAULT_TIL")); 
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__TXNAMT")); 
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__TXNCCY")); 
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__DESCRIPTION")); 
	fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG"));
	document.getElementById("BLK_INTRA_BRANCH__FROM_BRANCH").value="";	
	document.getElementById("BLK_INTRA_BRANCH__FROM_VAULT_TIL").value="";	
	document.getElementById("BLK_INTRA_BRANCH__TO_BRANCH").value="";	
	document.getElementById("BLK_INTRA_BRANCH__TO_VAULT_TIL").value="";	
	document.getElementById("BLK_INTRA_BRANCH__TXNAMT").value="";	
	document.getElementById("BLK_INTRA_BRANCH__TXNCCY").value="";	
	document.getElementById("BLK_INTRA_BRANCH__DESCRIPTION").value="";	
    document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG").value="";	
	return;
	}
   if(document.getElementById("BLK_INTRA_BRANCH__ADVANCE_REG_SEND").checked == false){
    fnDisableElement(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO"));
	document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO").value="";	
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__FROM_BRANCH")); 
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__FROM_VAULT_TIL")); 
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__TO_BRANCH")); 
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__TO_VAULT_TIL")); 
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__TXNAMT")); 
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__TXNCCY")); 
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__DESCRIPTION")); 
	fnEnableElement(document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG"));
	return;
	}
	
}*/
