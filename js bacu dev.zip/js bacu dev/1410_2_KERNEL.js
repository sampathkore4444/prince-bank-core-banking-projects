/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2011  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 1410_2_KERNEL.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : Suhas Rekhu
**  Last modified on   : 11-Oct-2011
**  Full Version       : 9nt1466 itr1 sfr#13081012
**  Reason             : 9nt1466 itr1 sfr#13081012
** Modified By         : Mantinder Kaur
** Modified On         : 19-May-2014
** Modified Reason     : For advance request inter branch cash transfer is giving error. 
** Search String       : 9NT1620_1203_18935398

** Modified By         : Sriraam S
** Modified On         : 23-Sep-2014
** Modified Reason     : Advance Amount field values and UI alignment changes
** Search String       : FCUBS_1203_GCB_19675739
****************************************************************************************************************************/

function fnPostLoad_KERNEL() {
//9nt1466 itr1 sfr#13081012 starts
	//document.getElementById("BLK_DENOMINATION_SE__DENOMTOTALI").style.visibility="hidden";
      // document.getElementById("BLK_DENOMINATION_SE__CDCCY").style.visibility="hidden";
	//document.getElementById("BLK_DENOMINATION_SE__DENOMTOTALI").previousSibling.style.visibility="hidden";
	//document.getElementById("BLK_DENOMINATION_SE__CDCCY").previousSibling.style.visibility="hidden";
	
//9nt1466 itr1 sfr#13081012 ends
	if (document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG").checked == true) 
	{
	if(document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNT").value =="" || document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNT").value == null){ //FCUBS_1203_GCB_19675739 added
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNT").value=document.getElementById("BLK_INTRA_BRANCH__TXNAMT").value;
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNTI").value=document.getElementById("BLK_INTRA_BRANCH__TXNAMTI").value;
	}//FCUBS_1203_GCB_19675739 added
	document.getElementById("BLK_INTRA_BRANCH__TXNAMT").value=0;
	document.getElementById("BLK_INTRA_BRANCH__TXNAMTI").value=0;
	document.getElementById("BLK_INTRA_BRANCH__TXNAMT").style.visibility="hidden";
	document.getElementById("BLK_INTRA_BRANCH__TXNAMT").previousSibling.style.visibility="hidden";
	document.getElementById("BLK_INTRA_BRANCH__TXNAMTI").style.visibility="hidden";
	document.getElementById("BLK_INTRA_BRANCH__TXNAMTI").previousSibling.style.visibility="hidden";
       document.getElementById("BLK_DENOMINATION_SE__PREFDNM").style.visibility="hidden";
       document.getElementById("BLK_DENOMINATION_SE__PREFDNM").previousSibling.style.visibility="hidden";
       document.getElementById("BLK_DENOMINATION_SE__DEFAULT").style.visibility="hidden";
	   zeroAndNegativeVal = false;//9NT1620_1203_18935398 
	//FCUBS_1203_GCB_19675739 starts
	document.getElementById("BLK_DENOMINATION_SE__CASHAMT").style.visibility="hidden";
	document.getElementById("BLK_DENOMINATION_SE__CASHAMT").previousSibling.style.visibility="hidden"; 
	document.getElementById("BLK_DENOMINATION_SE__CASHAMTI").style.visibility="hidden";
	document.getElementById("BLK_DENOMINATION_SE__CASHAMTI").previousSibling.style.visibility="hidden"; 
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNTI").style.visibility = "visible";
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNTI").previousSibling.style.visibility = "visible";
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNT").style.visibility = "visible";
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNT").previousSibling.style.visibility = "visible";
	//FCUBS_1203_GCB_19675739 ends
	}
	if (document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG").checked == false) 
	{
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNTI").style.visibility="hidden";
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNTI").previousSibling.style.visibility="hidden";
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNT").style.visibility="hidden";
	document.getElementById("BLK_INTRA_BRANCH__ADVANCE_AMOUNT").previousSibling.style.visibility="hidden";
	}
	if (document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_REF_NO").value!="")
	{
	document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG").checked=false;
	//document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG").style.visibility="hidden";
	//document.getElementById("BLK_INTRA_BRANCH__ADV_REQ_FLAG").nextSibling.style.visibility ="hidden";
	//FCUBS_12.0_SCRNVB_16327344 STARTS
	//return;
	return true;
	//FCUBS_12.0_SCRNVB_16327344 ENDS
	}
	
	//FCUBS_12.0_SCRNVB_16327344 starts
	//return;
	return true;
	//FCUBS_12.0_SCRNVB_16327344 ends
}

