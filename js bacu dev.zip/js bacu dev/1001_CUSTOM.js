function fnPostNew_CUSTOM() {
console.log("In fnPostNew_CUSTOM");
if (document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD31").checked) {
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD32"));
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD33"));
}
return true;
}

function fnDisableElements(event){
	console.log("In fnDisableElements");
	if (document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD31").checked) {
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD32"));
fnDisableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD33"));
document.getElementsByClassName('BTNimg')[0].style.visibility='hidden';
}else{
	fnEnableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD32"));
fnEnableElement(document.getElementById("BLK_TRANSACTION_DETAILS__CHAR_FIELD33"));
document.getElementsByClassName('BTNimg')[0].style.visibility='hidden';
}
	return true;
}