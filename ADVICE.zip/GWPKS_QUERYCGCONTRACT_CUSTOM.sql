CREATE OR REPLACE PACKAGE BODY GWPKS_QUERYCGCONTRACT_CUSTOM IS
  /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Change Tag        : PRF_CUSTOM_05_03072018
   **    Changes By        : Aniket
   **    Changes on        : 03-JUL-2018
   **    Description       : Changes related to Passbook printing specific to Prince Finance
   
   
   Modified By           : Kore Sampath Kumar
   Modified On           : 12-July-2019
   Modified Reason       : Cheque Reversal Instrument and Account Currency Amount to display with negative sign for reversal Changes
   Search String         : Cheque Reversal Instrument and Account Currency Amount to display with negative sign for reversal Changes
    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('CG', 'gwpks_querycgcontract_custom : ' || P_MSG);
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END DBG;

  FUNCTION FN_BUILD_CLEARING_DETAILS(P_SOURCE         IN VARCHAR2,
                                     P_FCCREF         IN OUT VARCHAR2,
                                     P_CLG_UPLD_REC   IN OUT CGPKSS_UPLOAD_CG_CREATE.TY_CLG_UPLD_REC,
                                     P_XREF           IN VARCHAR2,
                                     P_PARENT_RES     IN VARCHAR2,
                                     P_PARENT         IN OUT VARCHAR2,
                                     P_KEY            IN OUT VARCHAR2,
                                     P_DATA           IN OUT VARCHAR2,
                                     P_KEY_CLOB       IN OUT NOCOPY CLOB,
                                     P_DATA_CLOB      IN OUT NOCOPY CLOB,
                                     P_FORMAT         IN OUT VARCHAR2,
                                     P_CNT_LVL        IN OUT VARCHAR2,
                                     P_CONSOLIDATED   IN OUT VARCHAR2,
                                     P_ERR_CODE       IN OUT VARCHAR2,
                                     P_ERR_PARAM      IN OUT VARCHAR2,
                                     P_ISOUTCLOB      IN OUT VARCHAR2,
                                     P_CALL_FN_ID     IN OUT NUMBER,
                                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    --PRF_CUSTOM_05_03072018 changes starts
    P_DATA_TEMP VARCHAR2(32767);
    P_KEY_TEMP  VARCHAR2(32767);
    L_ADV_TOP   VARCHAR2(1000);
    L_PROD      VARCHAR2(10);
    L_TXN_BRN   VARCHAR2(4);
    L_P_CNT     NUMBER;
    L_TAG_NAME  VARCHAR2(4000);
    L_TAG_VALUE VARCHAR2(4000);
    
    L_INSTR_AMT VARCHAR2(100);
    L_ACCCY_AMT VARCHAR2(100);
    --PRF_CUSTOM_05_03072018 changes ends
  BEGIN

    DBG('In  fn_build_clearing_details..of gwpks_querycgcontract_custom for p_call_fn_id--> ' ||
        P_CALL_FN_ID);

    --PRF_CUSTOM_05_03072018 changes starts
    DBG('P_CALL_FN_ID :' || P_CALL_FN_ID);
    DBG('GWPKS_UTIL.pkg_func :' || GWPKS_UTIL.PKG_FUNC);
    
    
    IF P_CALL_FN_ID = '1' AND GWPKS_UTIL.PKG_FUNC IN ('6501', '6520') THEN
      P_DATA_TEMP := SUBSTR(P_TB_CUSTOM_DATA('p_data_temp'),
                            1,
                            LENGTH(P_TB_CUSTOM_DATA('p_data_temp')) - 1) || '~';
      P_KEY_TEMP  := SUBSTR(P_TB_CUSTOM_DATA('p_key_temp'),
                            1,
                            LENGTH(P_TB_CUSTOM_DATA('p_key_temp')) - 1);

      DBG('P_DATA_TEMP :' || P_DATA_TEMP);
      DBG('P_KEY_TEMP :' || P_KEY_TEMP);
      L_P_CNT    := 1;
      L_TAG_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_KEY_TEMP,
                                                NULL,
                                                'N',
                                                L_P_CNT,
                                                '~'),
                        '??');

      DBG('ABOUT TO LOOP');
      WHILE L_TAG_NAME <> 'EOPL' LOOP
        DBG('L_TAG_NAME :' || L_TAG_NAME);
        L_TAG_VALUE := NVL(CSPKES_MISC.FN_GETPARAM(P_DATA_TEMP,
                                                   L_P_CNT,
                                                   '~'),
                           '??');
        DBG('L_TAG_VALUE :' || L_TAG_VALUE);

        IF L_TAG_NAME = 'PRODUCT' THEN
          L_PROD := L_TAG_VALUE;
        ELSIF L_TAG_NAME = 'TXNBRN' THEN
          L_TXN_BRN := L_TAG_VALUE;
        END IF;
        
        --Cheque Reversal Instrument and Account Currency Amount to display with negative sign for reversal Changes starts
         IF GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
           IF L_TAG_NAME = 'INSTRAMT' THEN
                  L_INSTR_AMT := '-'||L_TAG_VALUE;      
           END IF;
           IF L_TAG_NAME = 'ACCCYAMT' THEN
                  L_ACCCY_AMT := '-'||L_TAG_VALUE;      
           END IF;
          ELSE
            
          IF L_TAG_NAME = 'INSTRAMT' THEN
                  L_INSTR_AMT := L_TAG_VALUE;      
           END IF;
           IF L_TAG_NAME = 'ACCCYAMT' THEN
                  L_ACCCY_AMT := L_TAG_VALUE;      
           END IF;
            
         END IF;
         
         
        --Cheque Reversal Instrument and Account Currency Amount to display with negative sign for reversal Changes ends

        L_P_CNT    := L_P_CNT + 1;
        L_TAG_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_KEY_TEMP, L_P_CNT, '~'),
                          '??');
      END LOOP;
      
      --Cheque Reversal Instrument and Account Currency Amount to display with negative sign for reversal Changes starts
      --Instrument Amount and Account Currency Amount
      P_KEY_TEMP  := P_KEY_TEMP || 'PRININSTRAMT~'||'PRINACCYAMT~';
      P_DATA_TEMP := P_DATA_TEMP || L_INSTR_AMT || '~' || L_ACCCY_AMT || '~';
        --Cheque Reversal Instrument and Account Currency Amount to display with negative sign for reversal Changes ends

      DBG('Selecting :' || L_TXN_BRN);
      FOR X IN (SELECT * FROM STTMS_BRANCH WHERE BRANCH_CODE = L_TXN_BRN) LOOP
        P_KEY_TEMP  := P_KEY_TEMP || 'TXN_BRANCH_NAME~';
        P_DATA_TEMP := P_DATA_TEMP || X.BRANCH_NAME || '~';
      END LOOP;

      DBG('PRODUCT :' || L_PROD);
      FOR X IN (SELECT * FROM CSTMS_PRODUCT WHERE PRODUCT_CODE = L_PROD) LOOP
        P_KEY_TEMP  := P_KEY_TEMP || 'PRODUCT_DESC~';
        P_DATA_TEMP := P_DATA_TEMP || X.PRODUCT_DESCRIPTION || '~';
        L_ADV_TOP   := X.PRODUCT_DESCRIPTION;
      END LOOP;

      DBG('ACTION TYPE IS :' || GWPKS_UTIL.PKG_ACTTYPE);
      IF GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
        L_ADV_TOP := L_ADV_TOP || ' REVERSAL';
      END IF;

      P_KEY_TEMP  := P_KEY_TEMP || 'ADV_TOP~';
      P_DATA_TEMP := P_DATA_TEMP || L_ADV_TOP || '~';

      P_KEY_TEMP  := P_KEY_TEMP || '>';
      P_DATA_TEMP := P_DATA_TEMP || '>';

      P_TB_CUSTOM_DATA('p_data_temp') := P_DATA_TEMP;
      P_TB_CUSTOM_DATA('p_key_temp') := P_KEY_TEMP;
      DBG('P_DATA_TEMP :' || P_DATA_TEMP);
      DBG('P_KEY_TEMP :' || P_KEY_TEMP);
    END IF;
    --PRF_CUSTOM_05_03072018 changes ends
    DBG('In  Returning Successfully from gwpks_querycgcontract_custom.fn_build_clearing_details');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  gwpks_querycgcontract_custom.fn_build_clearing_details..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_BUILD_CLEARING_DETAILS;

END GWPKS_QUERYCGCONTRACT_CUSTOM;
/