CREATE OR REPLACE PACKAGE BODY ICPKS_TDDEP_CERT_CUSTOM AS
  /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Change Tag        : PRF_CUSTOM_05_03072018
   **    Changes By        : Aniket
   **    Changes on        : 03-JUL-2018
   **    Description       : Changes related to Passbook printing specific to Prince Finance

   Modified By           : Kore Sampath Kumar
   Modified On           : 03-July-2019
   Modified Reason       : Term Deposit Certificate Changes as per PRINCE
   Search String         : Term Deposit Certificate Changes as per PRINCE
   
   Modified By           : Kore Sampath Kumar
   Modified On           : 08-Sep-2019
   Modified Reason       : Term Deposit Certificate Interest Rate Changes as per PRINCE
   Search String         : Term Deposit Certificate Interest Rate Changes as per PRINCE

    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'icpks_tddep_cert_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('IC', L_MSG);
  END DBG;

  --PRF_CUSTOM_05_03072018 changes starts
  PROCEDURE PR_PUTITS(PDCN     MSTBS_ADV_INPUT.DCN%TYPE,
                      IN_LOOP  MSTBS_ADV_INPUT.LOOP_NO%TYPE,
                      IN_FIELD VARCHAR2,
                      IN_VALUE VARCHAR2) IS
  BEGIN
    DBG('b4 INSERT INTO MSTBS_AVD_INPUT');
    INSERT INTO MSTBS_ADV_INPUT
      (DCN, LOOP_NO, FIELD_TAG, VALUE, JUSTIFY)
    VALUES
      (PDCN, IN_LOOP, IN_FIELD, IN_VALUE, 'L');
    DBG('Inserted string is ' || PDCN || '~' || IN_FIELD || '~' ||
        TO_CHAR(IN_LOOP) || '~' || IN_VALUE || '~L');
  END;
  --PRF_CUSTOM_05_03072018 changes ends

  FUNCTION FN_TD_ROLL_ADV(PACC_NO          IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                          P_BRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                          P_FN_CALL_ID     IN NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_td_roll_adv');

    DBG('Returning from fn_td_roll_adv');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_td_roll_adv');
      RETURN FALSE;
  END FN_TD_ROLL_ADV;

  FUNCTION FN_TD_CERT_ADV_INPUT(P_REC            IN MSTBS_DLY_MSG_OUT%ROWTYPE,
                                P_FN_CALL_ID     IN NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    --PRF_CUSTOM_05_03072018 changes starts
    L_TD_DET  ICTMS_TD_DETAILS%ROWTYPE;
    L_COUNTER NUMBER;
    --PRF_CUSTOM_05_03072018 changes ends

    --Term Deposit Certificate Changes as per PRINCE starts
    L_ICTM_ACC     ICTM_ACC%ROWTYPE;
    L_ACC_PR       ICTBS_ACC_PR%ROWTYPE;
    L_PAYOUT_COUNT NUMBER := 0;
    L_ERR_CODE     ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM    ERTB_MSGS.MESSAGE%TYPE;
    L_RULE         ICTMS_PR_INT.RULE%TYPE;
    L_INT_AMOUNT   NUMBER;
    L_TAX_AMT        ICTBS_ENTRIES.AMT%TYPE;
    L_NET_INT_AFTER_TAX ICTBS_ENTRIES.AMT%TYPE;
    L_ICDREDMN        TDVWS_TD_REDEMPTION%ROWTYPE;
    L_TB_CALC_BRKUP   STPKS_STDTDTOP_UTILS.TY_TB_RED_BRKUP;
    L_REDEM_FULL_FLAG VARCHAR2(1);
    L_TOTAL_AMT    NUMBER(22, 2) := 0;
    --Term Deposit Certificate Changes as per PRINCE ends
  BEGIN
    DBG('Inside fn_td_cert_adv_input');

    --PRF_CUSTOM_05_03072018 changes starts
    IF P_FN_CALL_ID = '1' THEN
      DBG('IN TO DO SOME TAGS FOR CUSTOM');

      BEGIN
        SELECT *
          INTO L_TD_DET
          FROM ICTMS_TD_DETAILS
         WHERE ACC = P_REC.REFERENCE_NO
           AND BRN = P_REC.BRANCH;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('When others of select sttm_customer...>' || SQLERRM);
      END;

      PR_PUTITS(P_REC.DCN,
                1,
                '_ORGTDAMT_',
                TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY, L_TD_DET.TD_AMOUNT)));

      SELECT SUM(CNT)
        INTO L_COUNTER
        FROM (SELECT COUNT(*) CNT
                FROM ICTBS_TDREDEMPTION_MASTER
               WHERE ACC_NO = P_REC.REFERENCE_NO
                 AND BRANCH_CODE = P_REC.BRANCH
              UNION
              SELECT COUNT(*) CNT
                FROM ICTMS_TDREDMN_MASTER
               WHERE AC_NO = P_REC.REFERENCE_NO
                 AND BRANCH_CODE = P_REC.BRANCH);

      DELETE FROM MSTB_ADV_INPUT
       WHERE DCN = P_REC.DCN
         AND FIELD_TAG IN ('AMT', 'DEPAMTWORDS');
      IF L_COUNTER > 0 THEN
        PR_PUTITS(P_REC.DCN,
                  1,
                  'AMT',
                  TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY,
                                             (NVL(L_TD_DET.TD_AMOUNT, 0) +
                                             NVL(L_TD_DET.TOPUP_AMT, 0) -
                                             NVL(L_TD_DET.REDEM_AMT, 0)))));
        PR_PUTITS(P_REC.DCN,
                  1,
                  'DEPAMTWORDS',
                  CSPKE_MISC.FN_NUM2WORDS('ENG',
                                          (NVL(L_TD_DET.TD_AMOUNT, 0) +
                                          NVL(L_TD_DET.TOPUP_AMT, 0) -
                                          NVL(L_TD_DET.REDEM_AMT, 0)),
                                          P_REC.CCY));

      ELSE
        PR_PUTITS(P_REC.DCN,
                  1,
                  'AMT',
                  TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY,
                                             (NVL(L_TD_DET.TD_AMOUNT, 0) +
                                             NVL(L_TD_DET.TOPUP_AMT, 0)))));
        PR_PUTITS(P_REC.DCN,
                  1,
                  'DEPAMTWORDS',
                  CSPKE_MISC.FN_NUM2WORDS('ENG',
                                          (NVL(L_TD_DET.TD_AMOUNT, 0) +
                                          NVL(L_TD_DET.TOPUP_AMT, 0)),
                                          P_REC.CCY));

      END IF;
     --PRF_CUSTOM_05_03072018 changes ends

      --Term Deposit Certificate Changes as per PRINCE starts
	  
      --Term Deposit Certificate Interest Rate Changes as per PRINCE Starts
      PR_PUTITS(P_REC.DCN, 1, 'FDINTRATE', ICPKS_TD_INT_DTLS_UTLS.fn_get_int_rate(P_REC.REFERENCE_NO,P_REC.BRANCH));
      --Term Deposit Certificate Interest Rate Changes as per PRINCE Ends
	  
      DEBUG.PR_DEBUG('IC', 'Select from acc pr for running calc');
      SELECT *
        INTO L_ACC_PR
        FROM ICTBS_ACC_PR
       WHERE BRN = P_REC.BRANCH
         AND ACC = P_REC.REFERENCE_NO;

      BEGIN
        SELECT *
          INTO L_ICTM_ACC
          FROM ICTM_ACC
         WHERE BRN = L_ACC_PR.BRN
           AND ACC = L_ACC_PR.ACC;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC', 'Failed in Selecing from ICTM_ACC');
      END;

      BEGIN
        SELECT COUNT(*)
          INTO L_PAYOUT_COUNT
          FROM ICTM_TDPAYOUT_DETAILS
         WHERE BRN = L_ACC_PR.BRN
           AND ACC = L_ACC_PR.ACC
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC',
                         'Failed in Selecing from ictm_tdpayout_details');
      END;

      BEGIN
        SELECT RULE
          INTO L_RULE
          FROM ICTMS_PR_INT
         WHERE PRODUCT_CODE = L_ACC_PR.PROD;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC',
                         'Could not get the product rule code :' || SQLERRM);
      END;
      DEBUG.PR_DEBUG('IC', 'The product rule code got is--> ' || L_RULE);

      IF (L_ICTM_ACC.BOOK_ACC <> L_ICTM_ACC.ACC OR L_PAYOUT_COUNT > 0) THEN

        DEBUG.PR_DEBUG('IC', ' Acc pr found so calling calc ');

        DELETE ICTW_MEMO_BOOKING WHERE ACC = L_ACC_PR.ACC;

        IF NOT ICPKS_RESOLVE_MAINT.FN_RESOLVE_ACC(L_ACC_PR.BRN,
                                                  L_ACC_PR.ACC,
                                                  L_ERR_CODE,
                                                  L_ERR_PARAM) THEN
          DEBUG.PR_DEBUG('IC', 'Failed to resolve account');
        END IF;

        ICPKS_TEST.PR_ICALC(L_ACC_PR.BRN,
                            L_ACC_PR.ACC,
                            L_ACC_PR.PROD,

                            NULL,
                            NULL);

        SELECT SUM(DECODE(A.DRCR_IND, 'C', A.AMT, -A.AMT))
          INTO L_INT_AMOUNT
          FROM ICTW_MEMO_BOOKING A, ICTM_RULE_FRM B
         WHERE A.FRM_NO = B.FRM_NO
           AND A.BRN = L_ACC_PR.BRN
           AND A.ACC = L_ACC_PR.ACC
           AND A.PROD = L_ACC_PR.PROD
           AND A.IS_TAX != 'Y'
           AND B.RULE_ID = L_RULE
           AND B.BOOK_FLAG = 'B';

        DEBUG.PR_DEBUG('IC', ' The interest amount is ' || L_INT_AMOUNT);

        /*PR_PUTITS(P_REC.DCN,
                  1,
                  'INTAMT',
                  TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY, L_INT_AMOUNT)));*/

        SELECT NVL(SUM(AMT), 0)
          INTO L_TAX_AMT
          FROM ICTW_MEMO_BOOKING
         WHERE BRN = L_ACC_PR.BRN
           AND ACC = L_ACC_PR.ACC
           AND PROD = L_ACC_PR.PROD
           AND IS_TAX = 'Y';
        DEBUG.PR_DEBUG('IC', ' The tax amount is ' || L_TAX_AMT);

        L_NET_INT_AFTER_TAX := L_INT_AMOUNT - L_TAX_AMT;

        PR_PUTITS(P_REC.DCN,
                  1,
                  'NETINTAFTERTAX',
                  TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY, L_NET_INT_AFTER_TAX)));

      ELSE

        IF STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(L_ACC_PR.ACC,
                                                       L_ACC_PR.BRN) THEN
          STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('Y');

          ICPKSS_MAINT.PR_GET_FULL_REDEM(L_REDEM_FULL_FLAG);
          ICPKSS_MAINT.PR_SET_FULL_REDEM(NULL);

          L_ICDREDMN.BRN_CODE := L_ACC_PR.BRN;
          L_ICDREDMN.AC_NO    := L_ACC_PR.ACC;

          L_ICDREDMN.WAVE_PENALTY   := 'Y';
          L_ICDREDMN.REDEMPTION_AMT := 0;
          L_ICDREDMN.CCY            := L_ACC_PR.CCY;
          DEBUG.PR_DEBUG('IC',
                         'calling stpks_stdtdtop_utils.fn_matamt_comp to calculate Maturity Amount before Top-Up');
          IF NOT STPKS_STDTDTOP_UTILS.FN_MATAMT_COMP('FLEXCUBE',
                                                     'NEW',
                                                     L_ICDREDMN,
                                                     L_TB_CALC_BRKUP,
                                                     L_ERR_CODE,
                                                     L_ERR_PARAM) THEN
            DEBUG.PR_DEBUG('IC', 'failed after calling fn_matamt_comp');
            L_ERR_CODE  := 'ST-TDMAT-01';
            L_ERR_PARAM := NULL;
            RETURN FALSE;
          END IF;
          ICPKSS_MAINT.PR_SET_FULL_REDEM(L_REDEM_FULL_FLAG);
          STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('');

          L_INT_AMOUNT := STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST;
          L_TAX_AMT    := STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;
          DEBUG.PR_DEBUG('IC',
                         ' The interest amount is ' ||
                         STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST);
          DEBUG.PR_DEBUG('IC',
                         ' The tax amount is ' ||
                         STPKS_STDTDTOP_UTILS.G_TOTAL_TAX);

          L_NET_INT_AFTER_TAX := STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST -
                                 STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;

          PR_PUTITS(P_REC.DCN,
                    1,
                    'NETINTAFTERTAX',
                    TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY,
                                               L_NET_INT_AFTER_TAX)));

          STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST := 0;
          STPKS_STDTDTOP_UTILS.G_TOTAL_TAX      := 0;
        ELSE
        /*
          STPKS_STDCUSAC_UTILS_1.PR_CALC_MATURITY(L_ACC_PR.BRN,
                                                  L_ACC_PR.ACC,
                                                  L_ACC_PR.PROD,
                                                  L_TOTAL_AMT);*/

          L_INT_AMOUNT := STPKS_STDCUSAC_UTILS_1.G_TOTAL_INTEREST;
          L_TAX_AMT    := STPKS_STDCUSAC_UTILS_1.G_TOTAL_TAX;
          DEBUG.PR_DEBUG('IC',
                         ' The interest amount is ' ||
                         STPKS_STDCUSAC_UTILS_1.G_TOTAL_INTEREST);
          DEBUG.PR_DEBUG('IC',
                         ' The tax amount is ' ||
                         STPKS_STDCUSAC_UTILS_1.G_TOTAL_TAX);
          L_NET_INT_AFTER_TAX := STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST -
                                 STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;

          PR_PUTITS(P_REC.DCN,
                    1,
                    'NETINTAFTERTAX',
                    TRIM(CYPKS.CSFN_FORMAT_AMT(P_REC.CCY,
                                               L_NET_INT_AFTER_TAX)));
          STPKS_STDCUSAC_UTILS_1.G_TOTAL_INTEREST := 0;
          STPKS_STDCUSAC_UTILS_1.G_TOTAL_TAX      := 0;
        END IF;

      END IF;

      --Term Deposit Certificate Changes as per PRINCE ends


    END IF;


    DBG('Returning from fn_td_cert_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_td_cert_adv_input');
      RETURN FALSE;
  END FN_TD_CERT_ADV_INPUT;

  FUNCTION FN_TD_BATCH_HANDOFF(PACC_NO          IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                               PADHOC_OR_BATCH  IN CHAR,
                               P_FN_CALL_ID     NUMBER,
                               P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside icpks_tddep_cert_custom.fn_td_batch_handoff');

    DBG('Returning Success From icpks_tddep_cert_custom.fn_td_batch_handoff');
    RETURN TRUE;
  END FN_TD_BATCH_HANDOFF;

  FUNCTION FN_TD_REDEM_ADV_INPUT(P_REC            IN MSTBS_DLY_MSG_OUT%ROWTYPE,
                                 P_FN_CALL_ID     IN NUMBER,
                                 P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_td_redem_adv_input');

    DBG('Returning from fn_td_redem_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_td_redem_adv_input');
      RETURN FALSE;
  END FN_TD_REDEM_ADV_INPUT;

  FUNCTION FN_TD_REDEM_ADV(PACC_NO          IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_BRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                           P_REF_NO         IN ICTB_REDEM_ACC.REDEM_REF_NO%TYPE,
                           P_CALL_FN_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_td_redem_adv');
    DBG('Returning from fn_td_redem_adv');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_td_redem_adv');
      RETURN FALSE;
  END FN_TD_REDEM_ADV;
  FUNCTION FN_TD_TOPUP_ADV(PACC_NO          IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_BRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                           P_REF_NO         IN ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO%TYPE,
                           P_CALL_FN_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_td_topup_adv');
    DBG('Returning from fn_td_topup_adv');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_td_topup_adv');
      RETURN FALSE;
  END FN_TD_TOPUP_ADV;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_PRE_TD_TOPUP_ADV_INPUT(L_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_pre_td_topup_adv_input');
    DBG('Returning from fn_pre_td_topup_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_pre_td_topup_adv_input');
      RETURN FALSE;
  END FN_PRE_TD_TOPUP_ADV_INPUT;

  FUNCTION FN_POST_TD_TOPUP_ADV_INPUT(L_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_post_td_topup_adv_input');
    DBG('Returning from fn_post_td_topup_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_post_td_topup_adv_input');
      RETURN FALSE;
  END FN_POST_TD_TOPUP_ADV_INPUT;

  FUNCTION FN_PRE_IPTD_REDEM_ADV_INPUT(L_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_pre_iptd_redem_adv_input');
    DBG('Returning from fn_pre_iptd_redem_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_pre_iptd_redem_adv_input');
      RETURN FALSE;
  END FN_PRE_IPTD_REDEM_ADV_INPUT;

  FUNCTION FN_POST_IPTD_REDEM_ADV_INPUT(L_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_post_iptd_redem_adv_input');
    DBG('Returning from fn_post_iptd_redem_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_post_iptd_redem_adv_input');
      RETURN FALSE;
  END FN_POST_IPTD_REDEM_ADV_INPUT;

  FUNCTION FN_PRE_TD_SIMULATE_ADV_INPUT(L_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_pre_td_simulate_adv_input');
    DBG('Returning from fn_pre_td_simulate_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_pre_td_simulate_adv_input');
      RETURN FALSE;
  END FN_PRE_TD_SIMULATE_ADV_INPUT;

  FUNCTION FN_POST_TD_SIMULATE_ADV_INPUT(L_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_post_td_simulate_adv_input');
    DBG('Returning from fn_post_td_simulate_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_post_td_simulate_adv_input');
      RETURN FALSE;
  END FN_POST_TD_SIMULATE_ADV_INPUT;

  FUNCTION FN_PRE_TD_MATADJ_ADV_INPUT(D_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_pre_td_matadj_adv_input');
    DBG('Returning from fn_pre_td_matadj_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_pre_td_matadj_adv_input');
      RETURN FALSE;
  END FN_PRE_TD_MATADJ_ADV_INPUT;

  FUNCTION FN_POST_TD_MATADJ_ADV_INPUT(D_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_post_td_matadj_adv_input');
    DBG('Returning from fn_post_td_matadj_adv_input');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_post_td_matadj_adv_input');
      RETURN FALSE;
  END FN_POST_TD_MATADJ_ADV_INPUT;

END ICPKS_TDDEP_CERT_CUSTOM;
/