CREATE OR REPLACE PACKAGE BODY ICPKS_TD_INT_DTLS_UTLS IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'ICPKS_INT_DTLS_UTLS ==>' || P_MSG;
    DEBUG.PR_DEBUG('IC', L_MSG);
  END DBG;

  FUNCTION FN_GET_INT_RATE(P_ACC IN VARCHAR2, P_BRN IN VARCHAR2)
    RETURN NUMBER IS
    L_INT_RATE   NUMBER;
    L_RULE       NUMBER;
    L_RATE       ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    L_TENOR      NUMBER := 0;
    REC_ICTM_ACC ICTM_ACC%ROWTYPE;
  BEGIN
    DBG('In Fn_Get_Int_Rate');
  
    BEGIN
      SELECT *
        INTO REC_ICTM_ACC
        FROM ICTM_ACC
       WHERE ACC = P_ACC
         AND BRN = P_BRN;
    
      SELECT ABS(REC_ICTM_ACC.INT_START_DATE - REC_ICTM_ACC.MATURITY_DATE)
        INTO L_TENOR
        FROM DUAL;
    
      DBG('L_TENOR=' || L_TENOR);
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('unable to find the Ictm_Acc for ' || P_ACC || '~' || P_BRN);
        DBG('Setting int rate to 0');
        L_INT_RATE := 0;
        RETURN L_INT_RATE;
    END;
  
    DBG('l_Tenor =' || L_TENOR);
  
    IF L_TENOR > 0 THEN
      --L_RATE := FN_GET_RATE_CODE(P_ACC, P_BRN, L_TENOR); SAMPATH COMMENTED
    
      L_RATE := FN_GET_RATE_CODE_CUSTOM(P_ACC, P_BRN, L_TENOR);
      DBG('Got rate code as ' || L_RATE);
    
      BEGIN
        SELECT UDE_VALUE
          INTO L_INT_RATE
          FROM ICTM_ACC_UDEVALS A
         WHERE ACC = P_ACC
           AND BRN = P_BRN
           AND UDE_ID = L_RATE
           AND UDE_EFF_DT = (SELECT MAX(UDE_EFF_DT)
                               FROM ICTM_ACC_UDEVALS
                              WHERE ACC = A.ACC
                                AND BRN = A.BRN
                                AND UDE_ID = A.UDE_ID);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to get the value for ' || L_RATE);
          DBG('Setting int_rate to 0');
          L_INT_RATE := 0;
      END;
    
      RETURN L_INT_RATE;
    ELSE
      RETURN 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      L_INT_RATE := 0;
      RETURN L_INT_RATE;
  END FN_GET_INT_RATE;

  FUNCTION FN_GET_RATE_CODE_CUSTOM(P_ACC   IN VARCHAR2,
                                   P_BRN   IN VARCHAR2,
                                   P_TENOR IN VARCHAR2)
    RETURN ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE IS
  
    TYPE T IS TABLE OF ICTMS_PR_INT_UDEVALS%ROWTYPE;
    V T;
  
    L_CUST_ACC STTM_CUST_ACCOUNT%ROWTYPE;
  
    CURSOR C1(P_ACC_CLASS ICTMS_PR_INT_UDEVALS.ACLASS%TYPE,
              P_PROD      ICTMS_PR_INT_UDEVALS.PRODUCT_CODE%TYPE,
              P_CCY       ICTMS_PR_INT_UDEVALS.CCY_CODE%TYPE) IS
      SELECT *
        FROM ICTMS_PR_INT_UDEVALS A
       WHERE ACLASS = P_ACC_CLASS
         AND PRODUCT_CODE = P_PROD
         AND CCY_CODE = P_CCY
         AND UDE_EFF_DT = (SELECT MAX(UDE_EFF_DT)
                             FROM ICTMS_PR_INT_UDEVALS
                            WHERE ACLASS = A.ACLASS
                              AND PRODUCT_CODE = A.PRODUCT_CODE
                              AND CCY_CODE = A.CCY_CODE
                              AND UDE_ID = A.UDE_ID);
  
    L_SLAB1  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB2  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB3  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB4  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB5  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB6  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB7  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB8  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB9  ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB10 ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_SLAB11 ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_UDE_ID ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    L_PROD   VARCHAR2(4);
    L_RATE   VARCHAR2(24);
    L_RULE   VARCHAR2(10);
  BEGIN
  
    BEGIN
      SELECT PROD
        INTO L_PROD
        FROM ICTM_ACC_PR
       WHERE ACC = P_ACC
         AND BRN = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Unable to get product for ' || P_ACC ||
            ' in fn_get_rate_code , returning xxx');
        L_RATE := 'xxx';
        RETURN L_RATE;
    END;
  
    DBG('l_prod = ' || L_PROD);
  
    IF L_PROD <> 'xxx' THEN
      BEGIN
        SELECT RULE
          INTO L_RULE
          FROM ICTMS_PR_INT
         WHERE PRODUCT_CODE = L_PROD;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Unable to find the rule , returning xxx');
          L_RATE := 'xxx';
          RETURN L_RATE;
      END;
    END IF;
  
    DBG('l_rule = ' || L_RULE);
  
    --GET ACCOUNT INFORMATION
    BEGIN
      SELECT *
        INTO L_CUST_ACC
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_CUST_ACC := NULL;
    END;
  
    OPEN C1(L_CUST_ACC.ACCOUNT_CLASS, L_PROD, L_CUST_ACC.CCY);
  
    FETCH C1 BULK COLLECT
      INTO V;
    CLOSE C1;
  
    FOR G IN V.FIRST .. V.LAST LOOP
      IF V(G).UDE_ID = 'SLAB_1' THEN
        L_SLAB1 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_2' THEN
        L_SLAB2 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_3' THEN
        L_SLAB3 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_4' THEN
        L_SLAB4 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_5' THEN
        L_SLAB5 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_6' THEN
        L_SLAB6 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_7' THEN
        L_SLAB7 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_8' THEN
        L_SLAB8 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_9' THEN
        L_SLAB9 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_10' THEN
        L_SLAB10 := V(G).UDE_VALUE;
      ELSIF V(G).UDE_ID = 'SLAB_11' THEN
        L_SLAB11 := V(G).UDE_VALUE;
      END IF;
    END LOOP;
  
    IF P_TENOR >= L_SLAB1 AND P_TENOR <= L_SLAB2 THEN
      L_UDE_ID := 'INT_RATE_1M';
    ELSIF P_TENOR > L_SLAB2 AND P_TENOR <= L_SLAB3 THEN
      L_UDE_ID := 'INT_RATE_3M';
    ELSIF P_TENOR > L_SLAB3 AND P_TENOR <= L_SLAB4 THEN
      L_UDE_ID := 'INT_RATE_6M';
    ELSIF P_TENOR > L_SLAB4 AND P_TENOR <= L_SLAB5 THEN
      L_UDE_ID := 'INT_RATE_9M';
    ELSIF P_TENOR > L_SLAB5 AND P_TENOR <= L_SLAB6 THEN
      L_UDE_ID := 'INT_RATE_1Y';
    ELSIF P_TENOR > L_SLAB6 AND P_TENOR <= L_SLAB7 THEN
      L_UDE_ID := 'INT_RATE_2Y';
    ELSIF P_TENOR > L_SLAB7 AND P_TENOR <= L_SLAB8 THEN
      L_UDE_ID := 'INT_RATE_3Y';
    ELSIF P_TENOR > L_SLAB8 AND P_TENOR <= L_SLAB9 THEN
      L_UDE_ID := 'INT_RATE_4Y';
    ELSIF P_TENOR > L_SLAB9 THEN
      L_UDE_ID := 'INT_RATE_5Y';
    END IF;
  
    DBG('L_UDE_ID=' || L_UDE_ID);
  
    RETURN L_UDE_ID;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END FN_GET_RATE_CODE_CUSTOM;

END ICPKS_TD_INT_DTLS_UTLS;
/