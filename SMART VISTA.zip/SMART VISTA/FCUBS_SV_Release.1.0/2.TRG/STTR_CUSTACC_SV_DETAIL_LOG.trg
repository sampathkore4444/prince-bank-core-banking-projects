CREATE OR REPLACE TRIGGER STTR_CUSTACC_SV_DETAIL_LOG
  AFTER INSERT OR UPDATE ON STTM_CUST_ACCOUNT
  REFERENCING new AS new old AS old
  FOR EACH ROW
    WHEN ((((nvl(NEW.ATM_FACILITY,'N')='Y') and (nvl(NEW.ATM_FACILITY,'N')<>nvl(OLD.ATM_FACILITY,'N'))) OR
          ((nvl(NEW.ATM_FACILITY,'N')='N') and (nvl(NEW.ATM_FACILITY,'N')<>nvl(OLD.ATM_FACILITY,'N'))) OR
          (nvl(NEW.RECORD_STAT,'N')<>nvl(OLD.RECORD_STAT,'N'))) AND
          (nvl(NEW.ACCOUNT_TYPE,'A')='U' OR nvl(NEW.ACCOUNT_TYPE,'A')='S'))
DECLARE
  L_OPERATION VARCHAR2(10);
  L_SYS_DATE  DATE;
BEGIN

      debug.pr_debug('AC','came IN TO Trigger STTR_CUSTACC_SV_DETAIL_LOG ');
      IF INSERTING THEN
        IF(nvl(:NEW.ATM_FACILITY,'N')='Y') THEN
        L_OPERATION:='INSERT';
        END IF;
      ELSE
        IF((nvl(:NEW.ATM_FACILITY,'N')<>nvl(:OLD.ATM_FACILITY,'N')) OR
        (nvl(:NEW.RECORD_STAT,'N')<>nvl(:OLD.RECORD_STAT,'N') AND (nvl(:NEW.ATM_FACILITY,'N')='Y'))) THEN
        L_OPERATION:='UPDATE';
        END IF;
      END IF;
      debug.pr_debug('AC','L_OPERATION '||L_OPERATION);

      SELECT TODAY INTO L_SYS_DATE FROM STTM_DATES WHERE BRANCH_CODE IN (SELECT HO_BRANCH FROM STTM_BANK);
      IF L_OPERATION IS NOT NULL THEN
       INSERT INTO IFTB_SV_CDC_CUSTOM VALUES (sv_sequence.nextval, L_SYS_DATE, 'STTM_CUST_ACCOUNT', 'STTR_CUSTACC_SV_DETAIL_LOG',
                                          (:NEW.BRANCH_CODE||'~'||:NEW.CUST_AC_NO), L_OPERATION, SYSDATE,:NEW.ATM_FACILITY,:NEW.RECORD_STAT,'I',null);
      END IF;
      debug.pr_debug('AC','came out of Trigger STTR_CUSTACC_SV_DETAIL_LOG ');

EXCEPTION
  WHEN OTHERS THEN
    NULL;
    debug.pr_debug('AC','Error while inserting of sv table ' || SQLERRM);
  --RAISE_APPLICATION_ERROR(-20001, 'An error was encountered while updation of aml log- ' || SQLCODE || ' -ERROR- ' || SQLERRM);
END STTR_CUSTACC_SV_DETAIL_LOG;
/