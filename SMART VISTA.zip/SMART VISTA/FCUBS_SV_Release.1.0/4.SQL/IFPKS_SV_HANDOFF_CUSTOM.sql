CREATE OR REPLACE PACKAGE BODY IFPKS_SV_HANDOFF_CUSTOM IS

/*
        -----------------------------------------------------------------------------------------------------------------

        =================================================================================================================
        ****************************************    CHANGE HISTORY      *************************************************
        =================================================================================================================

            CREATED BY    : Techurate Dev Team
            CREATED ON    : 24-JAN-2018

            MODIFIED BY    : Techurate Dev Team
            MODIFIED ON    : 24-JAN-2018
            MODIFIED REASON: ADDED PIN CHANGE LITERAL 'PIN' FOR COLLECTING PIN CHANGE CHARGES
            SEARCH STRING  : TECH#20190124001


*/

  PROCEDURE DBG(LINE IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'IFPKS_SV_HANDOFF_CUSTOM-->' || LINE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed IN IFPKS_SV_HANDOFF_CUSTOM.DBG');
      DBG(SQLERRM);
  END;
  PROCEDURE PR_INIT_PROCESS IS
    L_SEQ       IFTB_SVCARD_CUSTDETAILS_CUSTOM.SEQ_NO%TYPE;
    L_FILE_NAME IFTB_SVCARD_CUSTDETAILS_CUSTOM.FULL_NAME%TYPE := NULL;
    CURSOR CUR_SV_DETAILS IS
      SELECT SEQ_NO
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE STATUS = 'G'
       ORDER BY SEQ_NO;
  BEGIN
    DBG('came inside pr_init_process');
    OPEN CUR_SV_DETAILS;
    LOOP
      FETCH CUR_SV_DETAILS
        INTO L_SEQ;
      IF CUR_SV_DETAILS%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('processing for ' || L_SEQ);
      IF NOT FN_GEN_SV_FILE(L_SEQ, L_FILE_NAME) THEN
        PR_UPDATE_STATUS(L_SEQ, 'E', NULL);
      ELSE
        PR_UPDATE_STATUS(L_SEQ, 'H', L_FILE_NAME);
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT pr_INIT_PROCESS ' || SQLERRM);
      PR_UPDATE_STATUS(L_SEQ, 'E', NULL);
  END PR_INIT_PROCESS;

  FUNCTION FN_GEN_SV_FILE(P_SEQ_NO    IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.SEQ_NO%TYPE,
                          P_FILE_NAME OUT IFTB_SVCARD_CUSTDETAILS_CUSTOM.FILE_NAME%TYPE)
    RETURN BOOLEAN IS
    L_XML_DATA     IFTB_SVCARD_CUSTDETAILS_CUSTOM.MESSAGE%TYPE;
    L_FILE_HANDLER UTL_FILE.FILE_TYPE;
    L_FILE_PATH    VARCHAR2(255);
    l_ARCHIVAL_PATH VARCHAR2(255); --- added for TECH#20190124001
    L_FILE_NAME    VARCHAR2(50);
    L_FILE_EXT     VARCHAR2(5);
    L_XML_TYPE     IFTB_SVCARD_CUSTDETAILS_CUSTOM.XML_TYPE%TYPE;
  BEGIN
    DBG('entered FN_GEN_SV_FILE');
    BEGIN
      FOR L_PARAM_DATA IN (SELECT PARAM_NAME, PARAM_VAL
                             FROM IFTM_SV_CONFIG_CUSTOM
                            WHERE PARAM_NAME IN
                                  ('FILE_PATH', 'FILE_EXT', 'FILE_NAME','ARCHIVAL_PATH')) LOOP
        IF L_PARAM_DATA.PARAM_NAME = 'FILE_PATH' THEN
          L_FILE_PATH := L_PARAM_DATA.PARAM_VAL;
        ELSIF L_PARAM_DATA.PARAM_NAME = 'FILE_EXT' THEN
          L_FILE_EXT := L_PARAM_DATA.PARAM_VAL;
        ELSIF L_PARAM_DATA.PARAM_NAME = 'FILE_NAME' THEN
          L_FILE_NAME := L_PARAM_DATA.PARAM_VAL;
          ----- TECH#20190124001 start
        ELSIF L_PARAM_DATA.PARAM_NAME = 'ARCHIVAL_PATH' THEN
          L_ARCHIVAL_PATH := L_PARAM_DATA.PARAM_VAL;
          ------ TECH#20190124001 end
        END IF;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to obtain param details for IFTM_SV_CONFIG_CUSTOM');
        RETURN FALSE;
    END;
    BEGIN
      SELECT XML_TYPE, MESSAGE
        INTO L_XML_TYPE, L_XML_DATA
        FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
       WHERE SEQ_NO = P_SEQ_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG( 'Failed to obtain xml_type,message details from IFTB_SVCARD_CUSTDETAILS_CUSTOM');
        RETURN FALSE;
    END;
    IF L_XML_TYPE <> 'SVXP' THEN
      L_FILE_NAME := L_FILE_NAME || '_' || L_XML_TYPE || '_' ||
                     TO_CHAR(SYSDATE, 'DDMMYY') ||
                     TO_CHAR(SYSDATE, 'HHMISS') || '_' || P_SEQ_NO ||
                     L_FILE_EXT;
    ELSE
      L_FILE_NAME := L_XML_TYPE || '_' || TO_CHAR(SYSDATE, 'DDMMYY') ||
                     TO_CHAR(SYSDATE, 'HHMISS') || '_' || P_SEQ_NO || '_RATE' ||
                     L_FILE_EXT;
    END IF;

    DBG('FILE Path >> ' || L_FILE_PATH);
    DBG('Archival Path >> ' || L_ARCHIVAL_PATH);
    DBG('FILE Name >> ' || L_FILE_NAME);
    BEGIN
      L_FILE_HANDLER := UTL_FILE.FOPEN(L_FILE_PATH, L_FILE_NAME, 'W', 32767);
      DBG('FILE Opened >> ' || L_FILE_NAME);

      PR_WRITE_TO_FILE(L_FILE_HANDLER, L_XML_DATA);

      P_FILE_NAME := L_FILE_NAME;
      ---- TECH#20190124001 starts
      DBG('archiving FILE >> ' || L_FILE_NAME);
      L_FILE_HANDLER := UTL_FILE.FOPEN(L_ARCHIVAL_PATH, L_FILE_NAME, 'W', 32767);

      PR_WRITE_TO_FILE(L_FILE_HANDLER, L_XML_DATA);
      ----- TECH#20190124001 ends
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG( 'Failed to open file : '||sqlerrm);
        RETURN FALSE;
    END;

  END FN_GEN_SV_FILE;

  PROCEDURE PR_WRITE_TO_FILE(P_FILE_HANDLER IN UTL_FILE.FILE_TYPE,
                             P_MESSAGE      IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.MESSAGE%TYPE) IS
  BEGIN
    UTL_FILE.PUT_LINE(P_FILE_HANDLER, P_MESSAGE);
    UTL_FILE.FCLOSE_ALL;
  END PR_WRITE_TO_FILE;

  PROCEDURE PR_UPDATE_STATUS(P_SEQ_NO   IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.SEQ_NO%TYPE,
                             P_STATUS   VARCHAR2,
                             P_FILENAME IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.FILE_NAME%TYPE) IS
  BEGIN
    UPDATE IFTB_SVCARD_CUSTDETAILS_CUSTOM
       SET STATUS = P_STATUS, FILE_NAME = P_FILENAME
     WHERE SEQ_NO = P_SEQ_NO;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed to update status : '||sqlerrm);
      RAISE;
  END;

END IFPKS_SV_HANDOFF_CUSTOM;
/