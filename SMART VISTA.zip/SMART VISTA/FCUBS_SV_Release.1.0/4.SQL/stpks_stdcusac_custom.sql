CREATE OR REPLACE PACKAGE BODY stpks_stdcusac_custom AS
                    /*-----------------------------------------------------------------------------------------------------
                    **
                    ** File Name  : stpks_stdcusac_custom.sql
                    **
                    ** Module     : Static Maintenance
                    **
                    ** This source is part of the Oracle FLEXCUBE Software Product.
                    ** Copyright (R) 2008,2019 , Oracle and/or its affiliates.  All rights reserved
                    **
                    **
                    ** No part of this work may be reproduced, stored in a retrieval system, adopted
                    ** or transmitted in any form or by any means, electronic, mechanical,
                    ** photographic, graphic, optic recording or otherwise, translated in any
                    ** language or computer language, without the prior written permission of
                    ** Oracle and/or its affiliates.
                    **
                    ** Oracle Financial Services Software Limited.
                    ** Oracle Park, Off Western Express Highway,
                    ** Goregaon (East),
                    ** Mumbai - 400 063, India
                    ** India
                    -------------------------------------------------------------------------------------------------------
                    CHANGE HISTORY

                    SFR Number         :
                    Changed By         :
                    Change Description :

                    -------------------------------------------------------------------------------------------------------
                    */


                  PROCEDURE Dbg(p_msg VARCHAR2)  IS
                     l_Msg     VARCHAR2(32767);
                  BEGIN
                     IF debug.pkg_debug_on <> 2 THEN
                        l_Msg := 'stpks_stdcusac_Custom ==>'||p_Msg;
                        Debug.Pr_Debug('ST' ,l_Msg);
                     END IF;
                  END Dbg;

                  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
                  BEGIN
                     Cspks_Req_Utils.Pr_Log_Error(p_Source,p_Function_Id,p_Err_Code,p_Err_Params);
                  END Pr_Log_Error;
                  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
                  BEGIN
                     Dbg('In Pr_Skip_Handler..');
                  END Pr_Skip_Handler;
                  FUNCTION fn_Post_build_type_structure (p_Source    IN     VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_Id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
                     p_stdcusac     IN  OUT stpks_stdcusac_Main.ty_stdcusac,
                     p_Err_Code          IN OUT VARCHAR2,
                     p_Err_Params        IN OUT VARCHAR2)
                  RETURN BOOLEAN
                     IS
                  BEGIN

                     Dbg('In Fn_Post_Build_type_structure..');

                     Dbg('Returning Success From Fn_Post_Build_Type_Structure');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When Others Of stpks_stdcusac_Custom.Fn_Post_Build_type_structure ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END Fn_Post_Build_Type_Structure;

                  FUNCTION Fn_Pre_Check_Mandatory(p_Source    IN  VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_stdcusac IN OUT  stpks_stdcusac_Main.Ty_stdcusac,
                     p_Err_Code       IN  OUT VARCHAR2,
                     p_Err_Params     IN  OUT VARCHAR2)
                  RETURN BOOLEAN

                     IS
                  BEGIN

                     Dbg('In Fn_Pre_Check_Mandatory');

                     Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When Others of stpks_stdcusac_Custom.Fn_Pre_Check_Mandatory ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END fn_pre_check_mandatory;

                  FUNCTION Fn_Post_Check_Mandatory(p_Source    IN  VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_Id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
                     p_stdcusac IN   stpks_stdcusac_Main.ty_stdcusac,
                     p_Err_Code       IN  OUT VARCHAR2,
                     p_Err_Params     IN  OUT VARCHAR2)
                  RETURN BOOLEAN

                     IS
                  BEGIN

                     Dbg('In Fn_Post_Check_Mandatory..');

                     Dbg('Returning Success From Fn_Post_Check_Mandatory..');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When Others of stpks_stdcusac_Custom.Fn_Post_Check_Mandatory ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END Fn_Post_Check_Mandatory;

                  FUNCTION Fn_Pre_Default_And_Validate (p_Source    IN  VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_Id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_stdcusac IN   stpks_stdcusac_Main.ty_stdcusac,
                     p_Prev_stdcusac IN OUT stpks_stdcusac_Main.ty_stdcusac,
                     p_Wrk_stdcusac IN OUT  stpks_stdcusac_Main.ty_stdcusac,
                     p_Err_Code       IN  OUT VARCHAR2,
                     p_Err_Params     IN  OUT VARCHAR2)
                  RETURN BOOLEAN
                     IS
                  BEGIN

                     Dbg('In Fn_Pre_Default_And_Validate..');

                     Dbg('Returning Success From fn_pre_default_and_validate..');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When Others of stpks_stdcusac_Custom.Fn_Pre_Default_And_Validate ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END Fn_Pre_Default_And_Validate;

                  FUNCTION Fn_Post_Default_And_Validate (p_Source    IN  VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_Id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_stdcusac IN   stpks_stdcusac_Main.Ty_stdcusac,
                     p_Prev_stdcusac IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                     p_Wrk_stdcusac IN OUT  stpks_stdcusac_Main.Ty_stdcusac,
                     p_Err_Code       IN  OUT VARCHAR2,
                     p_Err_Params     IN  OUT VARCHAR2)
                  RETURN BOOLEAN
                     IS
                  BEGIN

                     Dbg('In Fn_Post_Default_And_Validate..');

                     Dbg('Returning Success From Fn_Post_Default_And_Validate..');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When Others of stpks_stdcusac_Custom.Fn_Post_Default_And_Validate ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END Fn_Post_Default_And_Validate;

                  FUNCTION Fn_Pre_Upload_Db (p_Source    IN  VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_Id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_Post_Upl_Stat    IN  VARCHAR2,
                     p_Multi_Trip_Id    IN  VARCHAR2,
                     p_stdcusac IN stpks_stdcusac_Main.Ty_stdcusac,
                     p_Prev_stdcusac IN stpks_stdcusac_Main.Ty_stdcusac,
                     p_Wrk_stdcusac IN OUT  stpks_stdcusac_Main.Ty_stdcusac,
                     p_Err_Code       IN  OUT VARCHAR2,
                     p_Err_Params     IN  OUT VARCHAR2)
                  RETURN BOOLEAN
                     IS
    --AML Integrations Changes Starts
    L_FIELD_VAL_2 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_2%TYPE;
    --AML Integrations Changes Ends
                  BEGIN

                     Dbg('In Fn_Pre_Upload_Db..');

    --AML Integrations Changes Starts
    IF P_ACTION_CODE IN ('NEW') THEN

      BEGIN


        L_FIELD_VAL_2 := CSPKS_AML_INTEGRATION_CUSTOM.FN_UDF_VAL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,'AML_VALIDATED');


        IF L_FIELD_VAL_2 = 'No' THEN

          P_WRK_STDCUSAC.v_sttms_cust_account.ac_stat_frozen := 'Y';
          P_WRK_STDCUSAC.v_sttms_cust_account.ac_stat_no_dr  := 'Y';
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to SELECT UDF Value');
          DBG(SQLERRM);
      END;
    END IF;

    --AML Integrations Changes ends

                     Dbg('Returning Success From Fn_Pre_Upload_Db..');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When Others of stpks_stdcusac_Custom.Fn_Pre_Upload_Db ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END Fn_Pre_Upload_Db;

                  FUNCTION Fn_Post_Upload_Db (p_Source    IN  VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_Id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_Post_Upl_Stat    IN  VARCHAR2,
                     p_Multi_Trip_Id    IN  VARCHAR2,
                     p_stdcusac IN stpks_stdcusac_Main.Ty_stdcusac,
                     p_prev_stdcusac IN stpks_stdcusac_Main.Ty_stdcusac,
                     p_wrk_stdcusac IN OUT  stpks_stdcusac_Main.Ty_stdcusac,
                     p_Err_Code       IN  OUT VARCHAR2,
                     p_Err_Params     IN  OUT VARCHAR2)
    RETURN BOOLEAN IS
    ----SV UDF capture starts
    L_CARD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    L_PROD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE;
    ----SV UDF capture ends
                  BEGIN

                     Dbg('In Fn_Post_Upload_Db..');

    ----SV UDF capture starts
    DBG('In Fn_Post_Upload_Db.. pavan');
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
    
      if (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.atm_facility = 'Y' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE NOT IN
         ('Y', 'N')) then
      
        L_PROD_ID := ifpks_sv_cdc_custom.FN_GET_PROD_ID(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        L_CARD_ID := ifpks_sv_cdc_custom.FN_GET_CARD_ID(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      
        IF (L_PROD_ID IS null OR L_CARD_ID is null) THEN
          DEBUG.PR_DEBUG('**', 'CARD ID OR PRODUCT_ID ARE NULL');
          P_ERR_CODE   := 'ST-SV-001';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      end if;
    
    END IF;
  
    ----SV UDF capture ends
  
                     Dbg('Returning Success From Fn_Post_Upload_Db..');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When Others of stpks_stdcusac_Custom.Fn_Post_Upload_Db ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END Fn_Post_Upload_Db;

                  FUNCTION Fn_Pre_Query  ( p_Source    IN  VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_Id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
                     p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
                     p_QryData_Reqd IN  VARCHAR2 ,
                     p_stdcusac IN   stpks_stdcusac_Main.Ty_stdcusac,
                     p_Wrk_stdcusac IN OUT   stpks_stdcusac_Main.Ty_stdcusac,
                     p_Err_Code          IN OUT VARCHAR2,
                     p_Err_Params        IN OUT VARCHAR2)
                  RETURN BOOLEAN
                     IS
                  BEGIN

                     Dbg('In Fn_Pre_Query..');

                     Dbg('Returning Success From Fn_Pre_Query..');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When Others of stpks_stdcusac_Custom.Fn_Pre_Query ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END Fn_Pre_Query;

                  FUNCTION Fn_Post_Query  ( p_Source    IN  VARCHAR2,
                                             p_Source_Operation  IN     VARCHAR2,
                                             p_Function_Id       IN     VARCHAR2,
                                             p_Action_Code       IN     VARCHAR2,
                     p_Child_Function    IN  VARCHAR2,
                     p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
                     p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
                     p_QryData_Reqd IN  VARCHAR2 ,
                     p_stdcusac IN   stpks_stdcusac_Main.ty_stdcusac,
                     p_wrk_stdcusac IN OUT   stpks_stdcusac_Main.ty_stdcusac,
                     p_Err_Code          IN OUT VARCHAR2,
                     p_err_params        IN OUT VARCHAR2)
                  RETURN BOOLEAN
                     IS
                  BEGIN

                     Dbg('In Fn_Post_Query..');

                     Dbg('Returning Success From Fn_Post_Query..');
                     RETURN TRUE;
                  EXCEPTION
                     WHEN OTHERS THEN
                        Debug.Pr_Debug('**','In When others of stpks_stdcusac_Custom.Fn_Post_Query ..');
                        Debug.Pr_Debug('**',SQLERRM);
                        p_Err_Code    := 'ST-OTHR-001';
                        p_Err_Params  := NULL;
                        RETURN FALSE;
                  END Fn_Post_Query;


               END stpks_stdcusac_custom;

