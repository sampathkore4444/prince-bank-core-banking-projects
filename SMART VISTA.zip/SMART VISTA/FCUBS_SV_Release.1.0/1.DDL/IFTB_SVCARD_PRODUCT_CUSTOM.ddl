-- Create table
create table IFTB_SVCARD_PRODUCT_CUSTOM
(
  account_type  CHAR(1),
  account_ccy   VARCHAR2(3),
  acc_type_code VARCHAR2(10),
  product_id    VARCHAR2(10),
  product_name  VARCHAR2(105),
  card_type     VARCHAR2(5)
);
