-- Create table
create table IFTB_SVCARD_CUSTDETAILS_CUSTOM
(
  seq_no          NUMBER not null,
  xml_type        VARCHAR2(5),
  customer_no     VARCHAR2(9),
  full_name       VARCHAR2(105),
  address_line1   VARCHAR2(105),
  address_line3   VARCHAR2(105),
  address_line2   VARCHAR2(105),
  address_line4   VARCHAR2(105),
  country         VARCHAR2(3),
  nationality     VARCHAR2(3),
  unique_id_name  VARCHAR2(255),
  unique_id_value VARCHAR2(255),
  first_name      VARCHAR2(105),
  middle_name     VARCHAR2(105),
  last_name       VARCHAR2(105),
  date_of_birth   DATE,
  e_mail          VARCHAR2(255),
  resident_status CHAR(1),
  mobile_number   VARCHAR2(105),
  branch_code     VARCHAR2(3),
  cust_ac_no      VARCHAR2(20),
  atm_facility    CHAR(1),
  staff           VARCHAR2(1),
  card_id         VARCHAR2(15),
  prod_id         VARCHAR2(10),
  ccy             VARCHAR2(3),
  account_type    CHAR(1),
  message         CLOB,
  status          CHAR(1) default 'I',
  cy_branch_code  VARCHAR2(3),
  src_ccy         VARCHAR2(3),
  dest_ccy        VARCHAR2(3),
  rate_type       VARCHAR2(8),
  mid_rate        NUMBER(24,12),
  buy_rate        NUMBER(24,12),
  sale_rate       NUMBER(24,12),
  rate_date       DATE,
  rate_serial     NUMBER(4),
  file_name       VARCHAR2(105)
);

-- Create/Recreate indexes 
create index U01_IF_SV_DETAILS on IFTB_SVCARD_CUSTDETAILS_CUSTOM (XML_TYPE, CUST_AC_NO, CUSTOMER_NO);

-- Create/Recreate primary, unique and foreign key constraints 
alter table IFTB_SVCARD_CUSTDETAILS_CUSTOM
  add constraint PK_IF_SV_DETAILS primary key (SEQ_NO);
  
  
-- Create sequence 
create sequence SV_SEQUENCE
minvalue 1
maxvalue 9999999999
start with 10001004
increment by 1
cache 20
cycle;


----create trigger for sequence
CREATE OR REPLACE TRIGGER trig_IF_sv_details
  BEFORE INSERT ON IFTB_SVCARD_CUSTDETAILS_CUSTOM
  FOR EACH ROW
BEGIN
  SELECT sv_sequence.nextval
  INTO :new.seq_no
  FROM dual;
END;
/
