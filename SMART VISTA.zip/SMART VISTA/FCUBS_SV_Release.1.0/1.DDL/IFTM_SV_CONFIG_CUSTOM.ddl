-- Create table
create table IFTM_SV_CONFIG_CUSTOM
(
  param_name VARCHAR2(30) not null,
  param_val  VARCHAR2(255)
);
