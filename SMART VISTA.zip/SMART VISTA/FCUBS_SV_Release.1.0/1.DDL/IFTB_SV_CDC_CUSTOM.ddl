-- Create table
create table IFTB_SV_CDC_CUSTOM
(
  id           NUMBER,
  fcc_date     DATE,
  table_name   VARCHAR2(50),
  source       VARCHAR2(50),
  pkey_vals    VARCHAR2(100),
  operation    VARCHAR2(20),
  log_time     TIMESTAMP(6),
  atm_facility CHAR(1),
  record_stat  CHAR(1),
  status       CHAR(1) default 'I',
  err_param    VARCHAR2(256)
);
