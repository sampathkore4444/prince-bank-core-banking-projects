-- Create table
create table SWTM_NETWORK_DETAILS_CUSTOM
(
  network_id       VARCHAR2(20),
  debit_network    CHAR(1),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  record_stat      VARCHAR2(1),
  auth_stat        VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4)
);

alter table SWTM_NETWORK_DETAILS_CUSTOM
  add constraint PK_SWTM_NETWORK_CUSTOM unique (NETWORK_ID);

