CREATE OR REPLACE PACKAGE BODY GWPKS_EXT_SWITCHSERVICE AS

  /*
        -----------------------------------------------------------------------------------------------------------------
    
        =================================================================================================================
        ****************************************    CHANGE HISTORY      *************************************************
        =================================================================================================================
    
            MODIFIED BY    : Techurate Dev Team
            MODIFIED ON    : 12-NOV-2018
            MODIFIED REASON: ADDED PIN CHANGE LITERAL 'PIN' FOR COLLECTING PIN CHANGE CHARGES
            SEARCH STRING  : CHANGES FOR TECH#20181211001
            
            
            MODIFIED BY    : Techurate Dev Team
            MODIFIED ON    : 12-NOV-2018
            MODIFIED REASON: ADDED TO SKIP GET ADDITIONAL AMOUNTS FOR PREPAID/CREDITS CARDS.
            SEARCH STRING  : CHANGES FOR TECH#20181224002
            
            MODIFIED BY    : Techurate Dev Team
            MODIFIED ON    : 12-NOV-2018
            MODIFIED REASON: ADDED TO GET ISS/ACQ BINS AND SKIP CHECKING FOR CUSTOMER ACCOUNT IN CASE OF PREPAID/CREDITS CARDS 
            SEARCH STRING  : CHANGES FOR TECH#20181224003
            
            
            MODIFIED BY    : Techurate Dev Team
            MODIFIED ON    : 12-NOV-2018
            MODIFIED REASON: ADDED TO MAKE THE FIELD 102 (OR FIELD 103 IN CASE OF DEPOSIT) AS TRANSACTION ACCOUNT IN CASE OF PREPAID/CREDIT CARDS.
            SEARCH STRING  : CHANGES FOR TECH#20181224004
            
            MODIFIED BY    : Techurate Dev Team
            MODIFIED ON    : 10-JAN-2019
            MODIFIED REASON: ADDED ACCOUNT VERFICATION (ADT) AND TO SEND CUSTOMER NAME IN RESPONSE
            SEARCH STRING  : CHANGES FOR TECH#20190110001
            
            MODIFIED BY    : Techurate Dev Team
            MODIFIED ON    : 17-JAN-2019
            MODIFIED REASON: CUSTOMIZATION DONE FOR CARDLESS WITHDRAWAL
            SEARCH STRING  : CHANGES FOR TECH#20190117001
    
            MODIFIED BY    : Techurate Dev Team
            MODIFIED ON    : 24-JAN-2019
            MODIFIED REASON: HANDLED UNWANTED FIELD 90 POPULATION IN RESPONSE MESSAGE.
            SEARCH STRING  : CHANGES FOR TECH#20190124001

  */

  PROCEDURE DBG(X VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('SW', 'gwpks_ext_switchservice=>' || X);
  END DBG;

  FUNCTION FN_PRE_SWITCHTRANSACTION(P_REC_MSG_HEADER IN GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                                    P_INSTR_REC      IN OUT GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                                    P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                    P_ERR_CODE       IN OUT VARCHAR2,
                                    P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_pre_switchTransaction');
  
    DBG('End of fn_pre_switchTransaction');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_lqservice.fn_pre_switchTransaction');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      P_ERR_CODE  := 'GW-CL001';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_PRE_SWITCHTRANSACTION;

  FUNCTION FN_POST_SWITCHTRANSACTION(P_REC_MSG_HEADER IN GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                                     P_INSTR_REC      IN OUT GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                                     P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                     P_ERR_CODE       IN OUT VARCHAR2,
                                     P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_post_switchTransaction');
  
    DBG('End of fn_post_switchTransaction');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_lqservice.fn_post_switchTransaction');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      P_ERR_CODE  := 'GW-CL001';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_POST_SWITCHTRANSACTION;

  FUNCTION FN_NETWORKTRANSACTION(P_TY_ATM_TXN_REC  IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                 P_SWTB_SETTLEMENT IN OUT SWTB_SETTLEMENT%ROWTYPE,
                                 P_ERR_CODE        IN OUT VARCHAR2,
                                 P_ERR_PARAM       IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_networktransaction');
  
    DBG('End of fn_networktransaction');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_lqservice.fn_networktransaction');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      P_ERR_CODE  := 'GW-CL001';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_NETWORKTRANSACTION;

  FUNCTION FN_PRODUCT_DERIVE(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                             P_FN_CALL_ID     IN NUMBER,
                             P_ERRCODE        IN OUT VARCHAR2,
                             P_ERRPARAM       IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('gwpks_ext_switchservice.fn_product_derive : Coming inside Gwpks_CreateSWTransaction.fn_product_derive ');
  
    DBG('gwpks_ext_switchservice.fn_product_derive : ' ||
        P_TY_ATM_TXN_REC.PRODUCT_CODE);
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERRCODE := 'SW-PRD-03';
      DBG('fn_product_derive : Other exception ' || '~' || SQLERRM);
      RETURN FALSE;
  END FN_PRODUCT_DERIVE;

  FUNCTION FN_REASSIGN_FIELD(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                             P_ERR_CODE       IN OUT VARCHAR2,
                             P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN
    DBG('gwpks_ext_switchservice.fn_main : Coming Fn_MiniStat');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-NFN-01';
      RETURN FALSE;
  END FN_REASSIGN_FIELD;

  FUNCTION FN_INSERT_ADDLTXT(P_ADDL_INF       IN OUT CSTB_ADDL_TEXT.ADDL_TEXT%TYPE,
                             P_ERR_CODE       IN OUT VARCHAR2,
                             P_ERR_PARAM      IN OUT VARCHAR2,
                             P_TY_ATM_TXN_REC IN GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC DEFAULT NULL)
    RETURN BOOLEAN AS
  BEGIN
  
    DBG('gwpks_ext_switchservice.Fn_Insert_Addltxt : Coming Fn_Insert_Addltxt');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAiled in fn_insert_addltxt ' || SQLERRM);
      RETURN FALSE;
  END FN_INSERT_ADDLTXT;

  FUNCTION FN_MINI_STMT_DATA(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                             P_ERR_CODE       IN OUT VARCHAR2,
                             P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN
    DBG('gwpks_ext_switchservice.fn_main : Coming fn_mini_stmt_data');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-NFN-01';
      RETURN FALSE;
  END FN_MINI_STMT_DATA;

  FUNCTION FN_POST_UPDATE_RESP(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_ERR_PARAM      IN OUT VARCHAR2,
                               P_FN_CALL_ID     IN NUMBER DEFAULT 1)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of Fn_Post_Update_Resp');
    ---------------CHANGES START FOR TECH#20190117001
    IF P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO IS NOT NULL THEN
      IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 2) = '22' THEN
        DBG('Came inside finhandler');
        DBG('before pan '||P_TY_ATM_TXN_REC.PAN);
        DBG('PREAUTH '||P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO);
        DBG('P_TY_ATM_TXN_REC.RRN '||P_TY_ATM_TXN_REC.RRN);
         BEGIN
              SELECT PAN
                INTO P_TY_ATM_TXN_REC.PAN
                FROM SWTBS_TXN_LOG            
               WHERE PRE_AUTH_SEQ_NO = P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO
                 AND P_KEY = P_TY_ATM_TXN_REC.P_KEY
                 AND XREF= P_TY_ATM_TXN_REC.XREF
                 AND RRN = P_TY_ATM_TXN_REC.RRN;
         EXCEPTION
    
              WHEN NO_DATA_FOUND THEN
                P_ERR_CODE  := 'SW-PAN-02';
                P_ERR_PARAM := P_TY_ATM_TXN_REC.P_KEY;
                DBG(
                    'NO DATA FOUND - swtbs_txn_log ' || P_ERR_CODE || '~' ||
                    P_ERR_PARAM);
                RETURN FALSE;
         END;
      DBG('After pan'||P_TY_ATM_TXN_REC.PAN);
      end if; 
    end if;
    ------------------CHANGES END FOR TECH#20190117001  
    DBG('End of Fn_Post_Update_Resp');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.Fn_Post_Update_Resp');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      P_ERR_CODE  := 'GW-CL001';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_POST_UPDATE_RESP;

  FUNCTION FN_BLOCK_MAIN(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                         P_ERR_CODE       IN OUT VARCHAR2,
                         P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN
    DBG('Start of Fn_Block_Main');
    DBG('Printing Error Code' || P_ERR_CODE || '~' || P_ERR_PARAM);
  
    DBG('End of Fn_Block_Main');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in gw[pks_ext_switchservice.fn_block_main' || SQLERRM);
      RETURN FALSE;
  END FN_BLOCK_MAIN;

  FUNCTION FN_PROCESS_REQ(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                          P_ERR_CODE       IN OUT VARCHAR2,
                          P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN
    DBG('Start of Fn_Process_Req');
    -------CHANGES FOR TECH#20181211001 STARTS
    IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('PIN') THEN
      P_TY_ATM_TXN_REC.CHARGE_NON_FIN_TXN := 'Y';
      IF NOT SWPKSS_NONFINHANDLER.FN_MAIN(P_TY_ATM_TXN_REC,
                                          P_ERR_CODE,
                                          P_ERR_PARAM) THEN
      
        DBG('gwpks_switch_nonfin.fn_main');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        RETURN FALSE;
      END IF;
      IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) IN ('1', '2') THEN
      
        DBG('calling gwpks_switch_querybal.fn_main');
        IF NOT SWPKSS_QUERYBALANCE.FN_MAIN(P_TY_ATM_TXN_REC,
                                           P_ERR_CODE,
                                           P_ERR_PARAM) THEN
          DBG('Failed while calling gwpks_switch_querybal.fn_main' ||
              SQLCODE);
        
          RETURN FALSE;
        END IF;
      
      ELSIF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '4' THEN
      
        RETURN TRUE;
      END IF;
    END IF;
  
    -------CHANGES FOR TECH#20181211001 ENDS
    DBG('End of Fn_Process_Req');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.Fn_Process_Req');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      P_ERR_CODE  := 'GW-CL001';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_PROCESS_REQ;

  FUNCTION FN_PROCESS_SWRTTXN(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                              P_TY_RTUPLD      IN OUT NOCOPY DEPKSS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of Fn_Process_swrttxn');
    -------CHANGES FOR TECH#20181211001 STARTS
    IF P_TY_ATM_TXN_REC.FC_LITERAL IN ('PIN') THEN
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH := P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC    := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT := 0;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH := P_TY_ATM_TXN_REC.ACC_BRANCH_CODE;
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC    := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
    END IF;
    -------CHANGES FOR TECH#20181211001 ENDS
    DBG('End of Fn_Process_swrttxn');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.Fn_Process_swrttxn');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_PROCESS_SWRTTXN;

  FUNCTION FN_TXN_CONTROL(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                          P_ERR_CODE       IN OUT VARCHAR2,
                          P_ERR_PARAM      IN OUT VARCHAR2,
                          P_FN_CALL_ID     IN NUMBER DEFAULT 1)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_txn_control');

    DBG('End of fn_txn_control');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_txn_control');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_TXN_CONTROL;

  FUNCTION FN_GET_ADDAMT(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                         P_ERR_CODE       IN OUT VARCHAR2,
                         P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
    L_ISS_BIN NUMBER;
  BEGIN
    DBG('Start of fn_get_addamt');
    -------------------TECH#20181224002
    SELECT COUNT(1)
      INTO L_ISS_BIN
      FROM SWTM_ISSUER_DETAILS
     WHERE ISS_BIN = SUBSTR(P_TY_ATM_TXN_REC.PAN, 1, 6)
       AND NETWORK_ID NOT IN (SELECT NETWORK_ID FROM SWTMS_NETWORK_DETAILS_CUSTOM WHERE DEBIT_NETWORK='Y' and RECORD_STAT='O' AND AUTH_STAT='A');
    IF (L_ISS_BIN > 0 
      OR   (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,1,2) IN ('39')))----------TECH#20190110001
      THEN
      GLOBAL.PR_SET_SKIP_KERNEL;
    END IF;
    --------------------TECH#20181224002
    DBG('End of fn_get_addamt');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_get_addamt');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_GET_ADDAMT;

  FUNCTION FN_CARDACC_TO_FCCACC(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                AC_ONLY_FLG      IN VARCHAR2,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  
  BEGIN
    DBG('Start of fn_cardacc_to_fccacc');
  -----------------TECH#20190110001 STARTS
  IF (SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('39')) THEN
              DBG('fn_cardacc_to_fccacc : proc code is 39');
            
              IF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.POS_VOID = 'Y' THEN
                DBG('fn_cardacc_to_fccacc : If pos_void is Y');
                P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC := P_TY_ATM_TXN_REC.TO_ACC;
            BEGIN  
                SELECT BRANCH_CODE
                  INTO P_TY_ATM_TXN_REC.ACC_BRANCH_CODE
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_TY_ATM_TXN_REC.TO_ACC
                   AND AUTH_STAT = 'A'
                   AND AC_GL_REC_STATUS = 'O';
                   
                SELECT CUSTOMER_NAME1 INTO P_TY_ATM_TXN_REC.ACCEPT_ADDR
                FROM STTM_CUSTOMER WHERE CUSTOMER_NO IN(
                SELECT CUST_NO FROM STTM_CUST_ACCOUNT WHERE RECORD_STAT='O' AND CUST_AC_NO=P_TY_ATM_TXN_REC.TO_ACC);
                
           EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CODE  := 'SW-ADT-01';
              P_ERR_PARAM := P_TY_ATM_TXN_REC.TXN_ACC_NO_FCC;
              DBG('fn_cardacc_to_fccacc : No data found in sttm_cust_account ' ||
                  P_ERR_CODE || '~' || P_ERR_PARAM);
              RETURN FALSE;
           END;
          END IF;
      GLOBAL.PR_SET_SKIP_KERNEL;             
     END IF;
  -----------------TECH#20190110001 ENDS
    DBG('End of fn_cardacc_to_fccacc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_cardacc_to_fccacc');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_CARDACC_TO_FCCACC;

  FUNCTION FN_DERIVE_NORMAL(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  
    L_ISS_BIN   NUMBER;
    L_ACQ_MATCH NUMBER(1) := 0;
    L_ISS_MATCH NUMBER(1) := 0;
  
  BEGIN
    DBG('Start of fn_derive_normal');
    
    ------------------------TECH#20181224003
    SELECT COUNT(1)
      INTO L_ISS_BIN
      FROM SWTM_ISSUER_DETAILS
     WHERE ISS_BIN = SUBSTR(P_TY_ATM_TXN_REC.PAN, 1, 6)
       AND NETWORK_ID NOT IN (SELECT NETWORK_ID FROM SWTMS_NETWORK_DETAILS_CUSTOM WHERE DEBIT_NETWORK='Y' and RECORD_STAT='O' AND AUTH_STAT='A');
    IF L_ISS_BIN > 0 THEN
      DBG('proc_code_type --> ' ||
          SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2));
    
      IF NOT SWPKSS_UTILS.FN_GET_FC_CODE_REC_WRP(SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE,
                                                        1,
                                                        2),
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM) THEN
        P_ERR_CODE  := 'SW-LIT-01';
        P_ERR_PARAM := SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2);
        DBG('In fn_derive_normal ' || SQLERRM);
        RETURN FALSE;
      ELSE
        DBG('Inside Fn_Get_fc_code_Rec_Wrp...');
        P_TY_ATM_TXN_REC.FC_LITERAL := SWPKSS_UTILS.G_TBL_SWTM_FC_CODE.FC_LITERAL;
      END IF;
    
      IF P_TY_ATM_TXN_REC.PAN IS NOT NULL THEN
        IF NOT SWPKSS_UTILS.FN_GET_ISSUER_DTLS_REC_WRP(SUBSTR(P_TY_ATM_TXN_REC.PAN,
                                                              1,
                                                              6),
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM)
        
         THEN
        
          IF P_ERR_CODE = 'CS-FRC-001' THEN
            P_TY_ATM_TXN_REC.NETWORK_ID := 'ALL';
            L_ISS_MATCH                 := 0;
            P_ERR_CODE                  := NULL;
          ELSE
            P_TY_ATM_TXN_REC.NETWORK_ID := 'ALL';
            P_ERR_CODE                  := 'SW-ISS-01';
            P_ERR_PARAM                 := SUBSTR(P_TY_ATM_TXN_REC.PAN,
                                                  1,
                                                  6);
            DBG('Error occured while retreiving the issuer details...');
            RETURN FALSE;
          END IF;
        ELSE
          DBG('Inside Fn_Get_issuer_dtls_Rec_Wrp...');
          P_TY_ATM_TXN_REC.NETWORK_ID := SWPKSS_UTILS.G_TBL_SWTM_ISS_DTLS.NETWORK_ID;
          L_ISS_MATCH                 := 1;
        END IF;
      END IF;
    
      IF NOT SWPKSS_UTILS.FN_GET_ACQ_DTLS_REC_WRP(P_TY_ATM_TXN_REC.ACQ_INS_ID,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM) THEN
      
        L_ACQ_MATCH := 0;
      
      ELSE
        DBG('Inside Fn_Get_acq_dtls_Rec_Wrp...');
        L_ACQ_MATCH := 1;
      END IF;
      IF L_ISS_MATCH = 1 AND L_ACQ_MATCH = 1 THEN
        P_TY_ATM_TXN_REC.OFFUS_ONUS := 'O';
      ELSIF L_ISS_MATCH = 1 THEN
        P_TY_ATM_TXN_REC.OFFUS_ONUS := 'R';
      ELSE
        P_TY_ATM_TXN_REC.NETWORK_ID := SWPKSS_UTILS.G_TBL_SWTM_ACQ_DTLS.NETWORK_ID;
        P_TY_ATM_TXN_REC.OFFUS_ONUS := 'F';
      END IF;
      DBG('IDENTIFIER:: ' || P_TY_ATM_TXN_REC.OFFUS_ONUS);
      DBG('p_Ty_Atm_Txn_Rec.Network_Id --> ' ||
          P_TY_ATM_TXN_REC.NETWORK_ID);
      IF (P_TY_ATM_TXN_REC.OFFUS_ONUS <> 'R') THEN
        IF NOT SWPKSS_UTILS.FN_GET_SW_TERMID_REC_WRP(P_TY_ATM_TXN_REC.TERM_ID,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM) THEN
        
          RETURN FALSE;
        
        ELSE
          P_TY_ATM_TXN_REC.TXN_GL              := SWPKSS_UTILS.G_TBL_SW_TERMID_REC.CASH_GL;
          P_TY_ATM_TXN_REC.INTELLIGENT_DEPOSIT := SWPKSS_UTILS.G_TBL_SW_TERMID_REC.INTELLIGENT_DEPOSIT;
        END IF;
      END IF;
      GLOBAL.PR_SET_SKIP_KERNEL;
    END IF;
    ----------------------TECH#20181224003
    DBG('End of fn_derive_normal');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_derive_normal');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_DERIVE_NORMAL;

  FUNCTION FN_PROCESS_CONTROL(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_process_control');
  
    DBG('End of fn_process_control');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_process_control');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_PROCESS_CONTROL;

  FUNCTION FN_ISO_PRE_SWITCHTRANSACTION(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                        P_ERR_CODE       IN OUT VARCHAR2,
                                        P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of Fn_Iso_Pre_Switchtransaction');
  
    DBG('End of Fn_Iso_Pre_Switchtransaction');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_lqservice.fn_pre_switchTransaction');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      P_ERR_CODE  := 'GW-CL001';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_ISO_PRE_SWITCHTRANSACTION;

  FUNCTION FN_ISO_POST_SWITCHTRANSACTION(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                         P_ERR_CODE       IN OUT VARCHAR2,
                                         P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of Fn_Iso_Post_Switchtransaction');
    DBG('Printing Error Code' || P_ERR_CODE || '~' || P_ERR_PARAM);
    DBG('End of Fn_Iso_Post_Switchtransaction');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_lqservice.fn_post_switchTransaction');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      P_ERR_CODE  := 'GW-CL001';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_ISO_POST_SWITCHTRANSACTION;

  FUNCTION FN_POST_MINI_STMT_DATA(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('gwpks_ext_switchservice.fn_main : Coming Fn_Post_Mini_Stmt_Data');
  
    DBG('End of Fn_Post_Mini_Stmt_Data');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'SW-NFN-01';
      RETURN FALSE;
  END FN_POST_MINI_STMT_DATA;

  FUNCTION FN_FINHANDLER_MAIN(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_finhandler_main');
    ---------------CHANGES START FOR TECH#20190117001
  IF P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO IS NOT NULL THEN
      IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 2) = '22' THEN
        DBG('Came inside finhandler');
        DBG('before pan '||P_TY_ATM_TXN_REC.PAN);
        DBG('PREAUTH '||P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO);
        DBG('P_TY_ATM_TXN_REC.RRN '||P_TY_ATM_TXN_REC.RRN);
         BEGIN
              SELECT PAN
                INTO P_TY_ATM_TXN_REC.PAN
                FROM SWTBS_TXN_LOG            
               WHERE PRE_AUTH_SEQ_NO = P_TY_ATM_TXN_REC.PRE_AUTH_SEQ_NO
                 AND P_KEY <> P_TY_ATM_TXN_REC.P_KEY
                 AND RRN = P_TY_ATM_TXN_REC.RRN;
         EXCEPTION
    
              WHEN NO_DATA_FOUND THEN
                P_ERR_CODE  := 'SW-PAN-01';
                P_ERR_PARAM := P_TY_ATM_TXN_REC.P_KEY;
                DBG(
                    'NO DATA FOUND - swtbs_txn_log ' || P_ERR_CODE || '~' ||
                    P_ERR_PARAM);
                RETURN FALSE;
         END;
      DBG('After pan'||P_TY_ATM_TXN_REC.PAN);
      end if; 
    end if;
    ------------------CHANGES END FOR TECH#20190117001
    DBG('End of fn_finhandler_main');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_finhandler_main');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_FINHANDLER_MAIN;

  FUNCTION FN_POST_PROCESS_SWRTTXN(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                   P_TY_RTUPLD      IN OUT NOCOPY DEPKSS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                   P_ERR_CODE       IN OUT VARCHAR2,
                                   P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
    L_ISS_BIN NUMBER;
  BEGIN
    DBG('Start of Fn_Post_Process_swrttxn');
    ---------------------TECH#20181224004
    SELECT COUNT(1)
      INTO L_ISS_BIN
      FROM SWTM_ISSUER_DETAILS
     WHERE ISS_BIN = SUBSTR(P_TY_ATM_TXN_REC.PAN, 1, 6)
       AND NETWORK_ID NOT IN (SELECT NETWORK_ID FROM SWTMS_NETWORK_DETAILS_CUSTOM WHERE DEBIT_NETWORK='Y' and RECORD_STAT='O' AND AUTH_STAT='A');
    IF L_ISS_BIN > 0 THEN
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('HEAD_OFFICE_BRANCH_NAME'),
                                                       P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE);
      --P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC    := NVL(P_TY_ATM_TXN_REC.FROM_ACC,P_TY_ATM_TXN_REC.TO_ACC);
      BEGIN
        SELECT AC_GL_NO
          INTO P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC
          FROM STTB_ACCOUNT
         WHERE AC_GL_NO =
               NVL(P_TY_ATM_TXN_REC.FROM_ACC, P_TY_ATM_TXN_REC.TO_ACC)
           AND AUTH_STAT = 'A'
           AND AC_GL_REC_STATUS = 'O'
           AND AC_OR_GL = 'G'
           AND GL_STAT_DE_POST = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERR_CODE  := 'SW-CRD-01';
          P_ERR_PARAM := P_TY_ATM_TXN_REC.FROM_ACC || '~' ||
                         P_TY_ATM_TXN_REC.TO_ACC;
          DBG('fn_cardacc_to_fccacc : No data found in sttb_account ' ||
              P_ERR_CODE || '~' || P_ERR_PARAM);
          RETURN FALSE;
      END;
    
      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY := P_TY_ATM_TXN_REC.TXN_CCY_FCC;
      DBG('assigned txn acc/brn/ccy for prepaid/credit--' ||
          P_TY_ATM_TXN_REC.TXN_CCY_FCC || ' ~~ ' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
    
    END IF;
    ---------------------TECH#20181224004 
    DBG('End of Fn_Post_Process_swrttxn');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.Fn_Post_Process_swrttxn');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_POST_PROCESS_SWRTTXN;

  FUNCTION FN_CHKBOOK_MAIN(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_chkbook_main');
  
    DBG('End of fn_chkbook_main');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_chkbook_main');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_CHKBOOK_MAIN;

  FUNCTION FN_CHKBOOK_REVERSE(P_TY_ATM_TXN_REC IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_chkbook_reverse');
  
    DBG('End of fn_chkbook_reverse');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_chkbook_reverse');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_CHKBOOK_REVERSE;

  FUNCTION FN_MANDATORY_VALIDATE(P_TY_ATM_TXN_REC IN GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of fn_mandatory_validate');
    
    -----------------------------------TECH#20181224003 STARTS
    IF  SUBSTR(P_TY_ATM_TXN_REC.PROC_CODE, 1, 2) IN ('39') THEN 
    
    IF P_TY_ATM_TXN_REC.MSG_TYPE IS NULL THEN 
        DBG( 'Mandatory field is NULL : FIELD1 - msg_type ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD1 - Msg_Type';
        RETURN FALSE; 
      
      ELSIF P_TY_ATM_TXN_REC.PAN IS NULL THEN
      
        IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) <> '8' THEN
          IF NOT NVL(P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_ACC_FROM_SWITCH,
                     'N') = 'Y' THEN
            DBG( 'Mandatory field is NULL : FIELD2 - pan ');
            P_ERR_CODE  := 'SW-MND-01';
            P_ERR_PARAM := 'FIELD2 - PAN';
            RETURN FALSE;
          END IF;
        END IF;
      
      ELSIF P_TY_ATM_TXN_REC.PROC_CODE IS NULL THEN
      
        DBG( 'Mandatory field is NULL : FIELD3 - Proc_Code');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD3 - Proc_Code';
        RETURN FALSE;
      
      ELSIF P_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL AND
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION NOT IN ('1', '2')  THEN
      
        DBG( 'Mandatory field is NULL : FIELD7 - Trans_Dt_Time ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD7 - Trans_Dt_Time';
        RETURN FALSE;
      
      ELSIF P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ISO_VERSION IN ('1', '2') AND
            P_TY_ATM_TXN_REC.TRANS_DT_TIME IS NULL AND
            P_TY_ATM_TXN_REC.LOCAL_TXN_TIME IS NULL THEN
      
        DBG( 'Mandatory field is NULL : FIELD12 - LOCAL_TXN_TIME ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD12 - LOCAL_TXN_TIME';
        RETURN FALSE;
      
      ELSIF P_TY_ATM_TXN_REC.STAN IS NULL THEN
      
        DBG( 'Mandatory field is NULL : FIELD11 - stan ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD11 - stan';
        RETURN FALSE;
      
      ELSIF P_TY_ATM_TXN_REC.ACQ_INS_ID IS NULL THEN
      
        DBG( 'Mandatory field is NULL : FIELD32 - Acq_Ins_Id ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD32 - Acq_Ins_Id ';
        RETURN FALSE;
      
      ELSIF P_TY_ATM_TXN_REC.RRN IS NULL THEN
      
        DBG( 'Mandatory field is NULL : FIELD37 - rrn ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD37 - rrn ';
        RETURN FALSE;
      
      ELSIF P_TY_ATM_TXN_REC.TERM_ID IS NULL THEN
        DBG( 'Mandatory field is NULL : FIELD41 - term_id ');
        P_ERR_CODE  := 'SW-MND-01';
        P_ERR_PARAM := 'FIELD41 - term_id ';
        RETURN FALSE;
      ELSIF P_TY_ATM_TXN_REC.TO_ACC IS NULL AND
            P_TY_ATM_TXN_REC.SWITCH_PARAM_FLG.ONLY_PAN_FROM_SWITCH = 'N' THEN        
          DBG( 'Mandatory field is NULL : FIELD103 - to_acc ');
          P_ERR_CODE  := 'SW-MND-01';
          P_ERR_PARAM := 'FIELD103 - to_acc ';
          RETURN FALSE;
        END IF;
        
    GLOBAL.PR_SET_SKIP_KERNEL;
    END IF; 
    -----------------------------------TECH#20181224003 ENDS
  
    DBG('End of fn_mandatory_validate');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.fn_mandatory_validate');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_MANDATORY_VALIDATE;

  FUNCTION FN_UPDATE_LIMITS(P_TY_ATM_TXN_REC IN GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN AS
  BEGIN
    DBG('Start of Fn_Update_Limits');
  
    DBG('End of Fn_Update_Limits');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.Fn_Update_Limits');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_UPDATE_LIMITS;

  FUNCTION NON_FINHANDLER_MAIN(P_TY_ATM_TXN_REC IN GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                               P_ERR_CODE       IN OUT VARCHAR2,
                               P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of Non_finhandler_main');
  
    DBG('End of Non_finhandler_main');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_switchservice.Non_finhandler_main');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END NON_FINHANDLER_MAIN;

  FUNCTION FN_BUILD_ATM_REPLY_ISO(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                  P_ISO_OUT_MSG    IN OUT VARCHAR2,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start of fn_build_atm_reply_iso');
    ----------------CHANGES FOR TECH#20190124001 STARTS
    IF SUBSTR(P_TY_ATM_TXN_REC.MSG_TYPE, 2, 1) = '4' THEN
       DBG('field 90 '||P_TY_ATM_TXN_REC.ORG_DATA);
         P_TY_ATM_TXN_REC.ORG_DATA:=NULL;   
    END IF;
    ----------------CHANGES FOR TECH#20190124001 ENDS
    DBG('End of fn_build_atm_reply_iso');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('something is horrible out here::' || SQLERRM);
      RETURN FALSE;
  END FN_BUILD_ATM_REPLY_ISO;

  FUNCTION FN_CHECK_FOR_REVERSAL(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start of fn_check_for_reversal');
  
    DBG('End of fn_check_for_reversal');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('something is horrible out here::' || SQLERRM);
      RETURN FALSE;
  END FN_CHECK_FOR_REVERSAL;

  FUNCTION FN_PRE_CCY_TRANS(P_ISO_TXN_CCY IN OUT NOCOPY VARCHAR2,
                            P_TXN_CCY     OUT VARCHAR2,
                            P_CCY_MINOR   OUT NUMBER,
                            P_ERRCODE     IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function FN_PRE_CCY_TRANS...');
  
    DBG('Returning success from FN_PRE_CCY_TRANS...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of gwpks_ext_switchservice.FN_PRE_CCY_TRANS ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PRE_CCY_TRANS;

  PROCEDURE PR_PRE_MSG_HANDLER(P_BRANCH          IN OUT NOCOPY VARCHAR2,
                               P_USER_ID         IN OUT NOCOPY VARCHAR2,
                               P_SOURCE          IN OUT NOCOPY VARCHAR2,
                               P_CHANNEL         IN OUT NOCOPY VARCHAR2,
                               P_ISO_MESSAGE     IN OUT NOCOPY VARCHAR2,
                               P_ERR_CODE        IN OUT NOCOPY VARCHAR2,
                               P_ERR_PARAM       IN OUT NOCOPY VARCHAR2,
                               P_TB_CLUSTER_DATA IN OUT GLOBAL.TY_TB_CLUSTER_DATA,
                               P_FN_CALL_ID      IN OUT NUMBER) IS
  BEGIN
    DBG('Inside the procedure pr_pre_msg_handler...');
  
    DBG('Returning success from pr_pre_msg_handler...');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of gwpks_ext_switchservice.pr_pre_msg_handler ..' ||
          SQLERRM);
      RETURN;
  END PR_PRE_MSG_HANDLER;

  FUNCTION FN_PRE_AMT_CHG_DERIVE_NEW(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                     P_ERR_CODE       IN OUT NOCOPY VARCHAR2,
                                     P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of fn_pre_amt_chg_derive_new');
  
    DBG('End of fn_pre_amt_chg_derive_new');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpkss_ext_switchservice.fn_pre_amt_chg_derive_new');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_AMT_CHG_DERIVE_NEW;

  FUNCTION FN_PRE_CALC_CHGS(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                            P_ERR_CODE       IN OUT NOCOPY VARCHAR2,
                            P_ERR_PARAM      IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of fn_pre_calc_chgs');
  
    DBG('End of fn_pre_calc_chgs');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpkss_ext_switchservice.fn_pre_calc_chgs');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_CALC_CHGS;

  FUNCTION FN_MERCHANTTRANSACTION(P_TY_ATM_TXN_REC      IN OUT GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                  P_SWTB_MER_SETTLEMENT IN OUT SWTB_MER_SETTLEMENT%ROWTYPE,
                                  P_ERR_CODE            IN OUT VARCHAR2,
                                  P_ERR_PARAM           IN OUT VARCHAR2)
    RETURN BOOLEAN AS
  
  BEGIN
    DBG('Start of fn_merchanttransaction');
  
    DBG('End of fn_merchanttransaction');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gwpks_ext_lqservice.fn_merchanttransaction');
      DEBUG.PR_DEBUG('**', 'Oracle error: ' || SQLERRM);
      P_ERR_CODE  := 'GW-CL001';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_MERCHANTTRANSACTION;

  FUNCTION FN_PRE_GET_BALANCES(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                               P_ERRCODE        IN OUT VARCHAR2,
                               P_ERRPARAM       IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function Fn_Pre_Get_Balances...');
  
    DBG('Returning success from Fn_Pre_Get_Balances...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Gwpks_Ext_Switchservice.Fn_Pre_Get_Balances ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PRE_GET_BALANCES;

  FUNCTION FN_POST_GET_BALANCES(P_TY_ATM_TXN_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                                P_ERRCODE        IN OUT VARCHAR2,
                                P_ERRPARAM       IN OUT NOCOPY VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function Fn_Post_Get_Balances...');
  
    DBG('Returning success from Fn_Post_Get_Balances...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Gwpks_Ext_Switchservice.Fn_Post_Get_Balances ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_POST_GET_BALANCES;

  FUNCTION FN_PRE_BUILD_ATM_NOTIF_XML(P_TY_ATM_NOTIF_REC IN OUT NOCOPY GWPKS_CREATESWTRANSACTION.TY_ATM_NOTIF_REC,
                                      P_PARENTS_LIST     IN OUT VARCHAR2,
                                      P_PARENTS_FORMAT   IN OUT VARCHAR2,
                                      P_TS_TAG_NAMES     IN OUT VARCHAR2,
                                      P_TS_TAG_VALUES    IN OUT VARCHAR2,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of fn_pre_build_atm_notif_xml');
  
    DBG('End of fn_pre_build_atm_notif_xml');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of fn_pre_build_atm_notif_xml:' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_BUILD_ATM_NOTIF_XML;

  FUNCTION FN_POST_MAIN(P_TY_ATM_TXN_REC IN OUT GWPKSS_CREATESWTRANSACTION.TY_ATM_TXN_REC,
                        P_ERR_CODE       IN OUT VARCHAR2,
                        P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function fn_post_main...');
  
    DBG('Returning success from fn_post_main...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Gwpks_Ext_Switchservice.fn_post_main ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_POST_MAIN;

END GWPKS_EXT_SWITCHSERVICE;
/