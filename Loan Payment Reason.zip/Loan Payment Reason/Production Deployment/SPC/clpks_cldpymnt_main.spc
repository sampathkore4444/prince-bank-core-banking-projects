CREATE OR REPLACE PACKAGE  clpks_cldpymnt_main AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : clpks_cldpymnt_main.spc
  **
  ** Module     : CL
  ** 
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2022 , Oracle and/or its affiliates.  All rights reserved
  ** 
  ** 
  ** No part of this work may be reproduced, stored in a retrieval system, adopted 
  ** or transmitted in any form or by any means, electronic, mechanical, 
  ** photographic, graphic, optic recording or otherwise, translated in any 
  ** language or computer language, without the prior written permission of 
  ** Oracle and/or its affiliates. 
  ** 
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East), 
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :  
  Changed By         :  
  Change Description :  
  
  -------------------------------------------------------------------------------------------------------
  */
  
  
TYPE ty_tb_v_cltbs_liq_settlements IS TABLE OF cltb_liq_settlements%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_liq_comp_summary IS TABLE OF cltb_liq_comp_summary%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_liq_comp_settled IS TABLE OF cltb_liq_comp_settled%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_liq_penal_rates IS TABLE OF cltb_liq_penal_rates%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_event_check_list IS TABLE OF cltb_event_check_list%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_liq_settlements__rev IS TABLE OF cltb_liq_settlements%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_liq_comp_summary_total IS TABLE OF cltb_liq_comp_summary_total%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_ltbs_acc_coll_link_paydt IS TABLE OF cltb_acc_coll_link_paydt%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_clvws_account_udf_date IS TABLE OF clvw_account_udf_date%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_clvws_account_udf_num IS TABLE OF clvw_account_udf_num%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_clvws_account_udf_char IS TABLE OF clvw_account_udf_char%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_account_events_advices IS TABLE OF cltb_account_events_advices%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__account_advice_suppress IS TABLE OF cltb_account_advice_suppress%ROWTYPE INDEX BY BINARY_INTEGER;

TYPE ty_cldpymnt IS RECORD (
     v_cltbs_liq     cltb_liq%ROWTYPE,
     v_cltbs_account_master     cltb_account_master%ROWTYPE,
     v_cltbs_account_ude_values     cltb_account_ude_values%ROWTYPE,
     v_cltbs_liq_settlements    ty_tb_v_cltbs_liq_settlements,
     v_cltbs_liq_comp_summary    ty_tb_v_cltbs_liq_comp_summary,
     v_cltbs_liq_comp_settled    ty_tb_v_cltbs_liq_comp_settled,
     v_cltbs_liq_penal_rates    ty_tb_v_cltbs_liq_penal_rates,
     v_cltbs_event_check_list    ty_tb_v_cltbs_event_check_list,
     v_cltbs_event_remarks     cltb_event_remarks%ROWTYPE,
     v_account_event_userdef     cltb_account_event_userdef%ROWTYPE,
     v_cstbs_ui_columns__udf     cstb_ui_columns%ROWTYPE,
     v_cstbs_ui_columns__udfdesc     cstb_ui_columns%ROWTYPE,
     v_cstbs_ui_columns__udfval     cstb_ui_columns%ROWTYPE,
     v_liq_settlements__rev    ty_tb_v_liq_settlements__rev,
     v_cstbs_ui_columns__subsys     cstb_ui_columns%ROWTYPE,
     v_clvws_liq     clvw_liq%ROWTYPE,
     v_liq_comp_summary_total    ty_tb_v_liq_comp_summary_total,
     v_cstbs_ui_columns__liq     cstb_ui_columns%ROWTYPE,
     v_cltbs_acc_coll_link_paydt    ty_tb_ltbs_acc_coll_link_paydt,
     v_clvws_account_udf_date    ty_tb_v_clvws_account_udf_date,
     v_clvws_account_udf_num    ty_tb_v_clvws_account_udf_num,
     v_clvws_account_udf_char    ty_tb_v_clvws_account_udf_char,
     v_account_events_advices    ty_tb_v_account_events_advices,
     v_account_advice_suppress    ty_tb__account_advice_suppress,
     v_account_settl_details     cltb_account_settl_details%ROWTYPE,
     v_cltb_liq_custom     cltb_liq_custom%ROWTYPE,
                 Desc_Fields    Cspks_Req_Global.Ty_Tb_Xml_Data,
                 Addl_Info    Cspks_Req_Global.Ty_Addl_info );

PROCEDURE Pr_Set_Skip_Sys;
PROCEDURE Pr_Set_Activate_Sys;
FUNCTION  Fn_Skip_Sys RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Kernel;
PROCEDURE Pr_Set_Activate_Kernel;
FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Custom;
PROCEDURE Pr_Set_Activate_Custom;
FUNCTION  Fn_Skip_Custom RETURN BOOLEAN;
FUNCTION Fn_Get_Original_Action RETURN VARCHAR2;
g_autoauth VARCHAR2(1);

FUNCTION Fn_Process_Request(p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Multi_Trip_Id     IN  VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_Addl_Info      IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Main       (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN  VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_cldpymnt          IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Build_Ts_List (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Exchange_Pattern   IN  VARCHAR2,
p_cldpymnt          IN clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code        IN OUT VARCHAR2,
p_Err_Params      IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Resolve_Ref_Numbers (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldpymnt     IN  OUT clpks_cldpymnt_Main.ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Product_Default         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt      IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Subsys_Pickup         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Prev_cldpymnt IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt      IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Enrich         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Prev_cldpymnt IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt      IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Check_Mandatory (p_Source    IN  VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
p_cldpymnt IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code       IN  OUT VARCHAR2,
p_Err_Params     IN  OUT VARCHAR2)
  RETURN BOOLEAN;
FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN  OUT   VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Prev_cldpymnt IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Upload_Db         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Multi_Trip_Id    IN  VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Prev_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt      IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Process         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Multi_Trip_Id    IN  VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Prev_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt      IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
p_with_lock     IN  VARCHAR2 DEFAULT 'N',
p_QryData_Reqd       IN  VARCHAR2,
p_cldpymnt         IN  clpks_cldpymnt_Main.Ty_cldpymnt, 
p_Wrk_cldpymnt  IN   OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_addl_info       IN Cspks_Req_Global.Ty_Addl_Info,
p_cldpymnt       IN   OUT clpks_cldpymnt_Main.ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
p_cldpymnt       IN   OUT clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldpymnt          IN clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code        IN OUT VARCHAR2,
p_Err_Params      IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Exchange_Pattern IN       VARCHAR2,
p_cldpymnt          IN clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code        IN OUT VARCHAR2,
p_Err_Params      IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN     VARCHAR2,
p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
p_cldpymnt IN  clpks_cldpymnt_Main.ty_cldpymnt,
p_Err_Code       IN  OUT VARCHAR2,
p_Err_Params     IN  OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Basic_Vals        (p_Source    IN     VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Merge_Amendables        (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Prev_cldpymnt IN clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt IN OUT clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source    IN     VARCHAR2,
p_Wrk_cldpymnt IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Lov_Vals        (p_Source    IN     VARCHAR2,
p_Wrk_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Default_Vals        (p_Source    IN     VARCHAR2,
p_Wrk_cldpymnt     IN  OUT clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Default_and_Validate        (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Prev_cldpymnt IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Upload_Db         (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Prev_cldpymnt     IN  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Wrk_cldpymnt      IN OUT  clpks_cldpymnt_Main.Ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Query  ( p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
p_QryData_Reqd       IN  VARCHAR2,
p_cldpymnt         IN  clpks_cldpymnt_Main.ty_cldpymnt, 
p_Wrk_cldpymnt  IN   OUT clpks_cldpymnt_Main.ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Wrk_cldpymnt  IN   OUT clpks_cldpymnt_Main.ty_cldpymnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Get_Node_Data ( 
p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
END clpks_cldpymnt_main;
/
CREATE OR REPLACE SYNONYM clpkss_cldpymnt_main FOR clpks_cldpymnt_main
/