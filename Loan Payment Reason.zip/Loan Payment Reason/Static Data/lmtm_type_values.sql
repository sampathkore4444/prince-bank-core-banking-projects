insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('LOAN_REPAY_RES', 'Borrow from Relative', 'BFREL');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('LOAN_REPAY_RES', 'Income from Business', 'INCFB');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('LOAN_REPAY_RES', 'New loan pays existing loan (Add Loan, Restructure, Reschedule, Extend)', 'NLPOL');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('LOAN_REPAY_RES', 'Refinance to Other Bank (Bank intention to release)', 'R2OBI');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('LOAN_REPAY_RES', 'Refinance to Other Bank (Other bank hunting)', 'R2OBH');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('LOAN_REPAY_RES', 'Selling Property (Normal or NPL)', 'SELLP');

COMMIT;
