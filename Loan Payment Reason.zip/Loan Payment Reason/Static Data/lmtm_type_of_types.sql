insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('LOAN_REPAY_RES', 'Loan Repayment Reason', 'SAMPATH2', 'SAMPATH2', to_date('03-04-2021 08:43:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-04-2021 08:43:53', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
