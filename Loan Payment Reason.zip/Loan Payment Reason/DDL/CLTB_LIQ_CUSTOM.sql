-- Create table
create table CLTB_LIQ_CUSTOM
(
  account_number    VARCHAR2(35),
  branch_code       VARCHAR2(35),
  event_seq_no      NUMBER not null,
  loan_repay_reason VARCHAR2(255),
  refinance_to_bank VARCHAR2(105)
)
/
alter table CLTB_LIQ_CUSTOM add constraint PK_CLTB_LIQ_CUSTOM primary key (ACCOUNT_NUMBER, BRANCH_CODE, EVENT_SEQ_NO)
/