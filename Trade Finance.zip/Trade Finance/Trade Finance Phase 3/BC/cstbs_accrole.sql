insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLFA CONT', 'Cust. Liab. for Acceptances - Cont', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLFA REAL', 'Cust. Liab. for Acceptances - Real', 'A', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('COLL OFFSET', 'Offset for Bills Under Collection', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACCEPTANCE CONT', 'Bills Accepted - Contingent Asset', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACCEPTANCE REAL', 'Bills Accepted - Real Asset', 'L', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMAQR', 'ACCEPTANCE COMMISSION', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMEXP', 'ACCEPTANCE COMMISSION', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMIISNPL', 'ACCEPTANCE COMMISSION', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMINC', 'ACCEPTANCE COMMISSION', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMPAY', 'ACCEPTANCE COMMISSION', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMPIA', 'ACCEPTANCE COMMISSION', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMREC', 'ACCEPTANCE COMMISSION', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMRECNPL', 'ACCEPTANCE COMMISSION', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMRIA', 'ACCEPTANCE COMMISSION', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMUNRL', 'ACCEPTANCE COMMISSION', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTAQR', 'INTEREST ON ADVANCE', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTEXP', 'INTEREST ON ADVANCE', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTIISNPL', 'INTEREST ON ADVANCE', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTINC', 'INTEREST ON ADVANCE', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTPAY', 'INTEREST ON ADVANCE', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTPIA', 'INTEREST ON ADVANCE', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTREC', 'INTEREST ON ADVANCE', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTRECNPL', 'INTEREST ON ADVANCE', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTRIA', 'INTEREST ON ADVANCE', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTUNRL', 'INTEREST ON ADVANCE', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV UNDER LCS', 'Advances Under LC`s Issued', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGENT ACCOUNT', 'Broker Agent Account', 'X', 'BC', 'N', 'N', 'N');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASSETGLNPL', 'NPL Asset GL for Bills', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC CUSTOMER', 'Customer Accounts', 'X', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01AQR', 'BCINT01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01EXP', 'BCINT01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01IISNPL', 'BCINT01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01INC', 'BCINT01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01PAY', 'BCINT01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01PIA', 'BCINT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01REC', 'BCINT01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01RECNPL', 'BCINT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01RIA', 'BCINT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01UNRL', 'BCINT01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX1_EXP', 'tax expence role forBCTAX1', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX1_PAD', 'tax paid in adv role forBCTAX1', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX1_PAY', 'tax payable role forBCTAX1', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX3_EXP', 'tax expence role forBCTAX3', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX3_PAD', 'tax paid in adv role forBCTAX3', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX3_PAY', 'tax payable role forBCTAX3', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX_EXP', 'tax expence role forBCTAX', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX_PAD', 'tax paid in adv role forBCTAX', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX_PAY', 'tax payable role forBCTAX', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_UCNF', 'Unconfirmed Amount for Export Bills', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_UCNF_OFF', 'Unconfirmed Offset Amount for Export Bills', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILL COLLATERAL', 'Collateral Collected under Bills', 'L', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILL COLLOFFSET', 'Bills Collateral Collected Offset', 'A', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILL MARGIN', 'Margin amt collected on Disnt Bill', 'A', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLCOLLCONT', 'Coll collected bills contingent', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLCOLLCONTOFF', 'Coll collected bills cont offset', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLS DISCNTED', 'Bills Discounted', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLS NEGOTIATE', 'Outgoing Bills Negotiated', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLS PURCHASED', 'Outgoing Bills Purchased', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BPUR_INT01IISNPL', 'BPUR_INT01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BPUR_INT01RECNPL', 'BPUR_INT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BPUR_INT01UNRL', 'BPUR_INT01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BRIDGE GL', 'Bridge GL', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BROKPAY', 'Brokerage Payable', 'L', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMINTADJINC', 'Effective Int Par Income', 'I', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMINTADJREC', 'Effective Int Par Receivable', 'I', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMPREMEXP', 'Effective Int Premium Expense', 'I', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMPREMPIA', 'Effective Int Paid in Advance', 'I', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1AQP', 'EL_BC1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1AQR', 'EL_BC1', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1DOV', 'EL_BC1', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1EXP', 'EL_BC1', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1IINPL', 'EL_BC1', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1INC', 'EL_BC1', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1PAY', 'EL_BC1', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1PIA', 'EL_BC1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1PPD', 'EL_BC1', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1REC', 'EL_BC1', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1RENPL', 'EL_BC1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1RIA', 'EL_BC1', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2AQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2AQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2DOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2EXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2IINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2INC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2PAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2PIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2PPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2REC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2RENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2RIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCAQP', 'el_bc', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCAQR', 'el_bc', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCDOV', 'el_bc', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCEXP', 'el_bc', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCIINPL', 'el_bc', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCINC', 'el_bc', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCPAY', 'el_bc', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCPIA', 'el_bc', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCPPD', 'el_bc', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCREC', 'el_bc', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCRENPL', 'el_bc', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCRIA', 'el_bc', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORFAITING_NOSTRO', 'Forfaiting House Nostro', 'X', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIAQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIAQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIDOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIEXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIIINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIINC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINAQP', 'FORFAITING INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINAQR', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINDOV', 'FORFAITING INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINEXP', 'FORFAITING INT FOR DIS TO FOR', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINIINPL', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTININC', 'FORFAITING INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINPAY', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINPIA', 'FORFAITING INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINPPD', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINREC', 'FORFAITING INT FOR DIS TO FOR', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINRENPL', 'FORFAITING INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINRIA', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIPAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIPIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIPPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIREC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIRENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIRIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EB COLLECTIONS', 'Outgoing Bills Under Collection', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENAQR', 'penal interest on negotiation', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENEXP', 'penal interest on negotiation', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENIISNPL', 'penal interest on negotiation', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENINC', 'penal interest on negotiation', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENPAY', 'penal interest on negotiation', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENPIA', 'penal interest on negotiation', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENPPD', 'penal interest on negotiation', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENREC', 'penal interest on negotiation', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENRECNPL', 'penal interest on negotiation', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENRIA', 'penal interest on negotiation', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENUNRL', 'penal interest on negotiation', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INAQR', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INEXP', 'Discount Interest collected upfront', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INIISNPL', 'Discount Interest collected upfront', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_ININC', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INPAY', 'Discount Interest collected upfront', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INPIA', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INREC', 'Discount Interest collected upfront', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INRECNPL', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INRIA', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INUNRL', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INAQR', 'Negotiation int on export bills', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INEXP', 'Negotiation int on export bills', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INIISNPL', 'Negotiation int on export bills', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_ININC', 'Negotiation int on export bills', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INPAY', 'Negotiation int on export bills', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INPIA', 'Negotiation int on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INPPD', 'Negotiation int on export bills', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INREC', 'Negotiation int on export bills', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INRECNPL', 'Negotiation int on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INRIA', 'Negotiation int on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INUNRL', 'Negotiation int on export bills', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INAQR', 'Purchase Interest on export bills', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INEXP', 'Purchase Interest on export bills', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INIISNPL', 'Purchase Interest on export bills', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_ININC', 'Purchase Interest on export bills', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INPAY', 'Purchase Interest on export bills', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INPIA', 'Purchase Interest on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INREC', 'Purchase Interest on export bills', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INRECNPL', 'Purchase Interest on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INRIA', 'Purchase Interest on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INUNRL', 'Purchase Interest on export bills', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMDISCINC', 'Effc Int Based Disc Accrued Till Dt', 'I', 'BC', 'Y', 'N', 'N');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMDISCRIA', 'Effec Int Discount to be Accrued', 'L', 'BC', 'Y', 'N', 'N');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1PIA', 'INTBADV1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1PPD', 'INTBADV1', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1REC', 'INTBADV1', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1RECNPL', 'INTBADV1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1RIA', 'INTBADV1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1UNRL', 'INTBADV1', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01AQR', 'INTBDIS01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01EXP', 'INTBDIS01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01IISNPL', 'INTBDIS01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01INC', 'INTBDIS01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01PAY', 'INTBDIS01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01PIA', 'INTBDIS01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01REC', 'INTBDIS01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01RECNPL', 'INTBDIS01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01RIA', 'INTBDIS01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01UNRL', 'INTBDIS01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1AQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1AQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1DOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1EXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1IINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1INC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1PAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1PIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1PPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1REC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1RENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1RIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTERESTREF', 'Interest Refund', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1AQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1AQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1DOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1EXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1IINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1INC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1PAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1PIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1PPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1REC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1RENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1RIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01AQR', 'INT_BPUR01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01EXP', 'INT_BPUR01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01IISNPL', 'INT_BPUR01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01INC', 'INT_BPUR01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01PAY', 'INT_BPUR01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01PIA', 'INT_BPUR01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01PPD', 'INT_BPUR01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01REC', 'INT_BPUR01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01RECNPL', 'INT_BPUR01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01RIA', 'INT_BPUR01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01UNRL', 'INT_BPUR01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IB COLLECTIONS', 'Incoming Bills Under Collection', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INAQR', 'Interest on advance', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INEXP', 'Interest on advance', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INIISNPL', 'Interest on advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_ININC', 'Interest on advance', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INPAY', 'Interest on advance', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INPIA', 'Interest on advance', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INREC', 'Interest on advance', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INRECNPL', 'Interest on advance', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INRIA', 'Interest on advance', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INUNRL', 'Interest on advance', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INAQR', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INEXP', 'Discount Interest collected upfront', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INIISNPL', 'Discount Interest collected upfront', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_ININC', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INPAY', 'Discount Interest collected upfront', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INPIA', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INREC', 'Discount Interest collected upfront', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INRECNPL', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INRIA', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INUNRL', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01AQR', 'INT01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01EXP', 'INT01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01IISNPL', 'INT01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01INC', 'INT01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01PAY', 'INT01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01PIA', 'INT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01REC', 'INT01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01RECNPL', 'INT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01RIA', 'INT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01UNRL', 'INT01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02AQR', 'INT02', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02EXP', 'INT02', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02IISNPL', 'INT02', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02INC', 'INT02', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02PAY', 'INT02', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02PIA', 'INT02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02REC', 'INT02', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02RECNPL', 'INT02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02RIA', 'INT02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02UNRL', 'INT02', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786AQR', 'INT786', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786EXP', 'INT786', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786IISNPL', 'INT786', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786INC', 'INT786', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786PAY', 'INT786', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786PIA', 'INT786', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786PPD', 'INT786', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786REC', 'INT786', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786RECNPL', 'INT786', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786RIA', 'INT786', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786UNRL', 'INT786', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1AQR', 'INTBADV1', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1EXP', 'INTBADV1', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1IISNPL', 'INTBADV1', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1INC', 'INTBADV1', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1PAY', 'INTBADV1', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2AQP', 'MAIN INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2AQR', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2DOV', 'MAIN INT FOR DIS TO FOR CASE 2', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2EXP', 'MAIN INT FOR DIS TO FOR CASE 2', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2IINPL', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2INC', 'MAIN INT FOR DIS TO FOR CASE 2', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2PAY', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2PIA', 'MAIN INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2PPD', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2REC', 'MAIN INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2RENPL', 'MAIN INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2RIA', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTAQP', 'MAIN INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTAQR', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTDOV', 'MAIN INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTEXP', 'MAIN INT FOR DIS TO FOR', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTIINPL', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTINC', 'MAIN INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTPAY', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTPIA', 'MAIN INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTPPD', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTREC', 'MAIN INT FOR DIS TO FOR', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTRENPL', 'MAIN INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTRIA', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_EXP', 'tax expense role for KKL', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_PAD', 'tax paid in adv role for KKL', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_PAY', 'tax payable role for KKL', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_COLL_BRIDGE', 'LC Collat Bridge GL', 'L', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_EXP', 'tax expense role for MM_TAX', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_PAD', 'tax paid in adv role for MM_TAX', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_PAY', 'tax payable role for MM_TAX', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('NOSTRO ACCOUNT', 'Our Correspondent`s Nostro Account', 'X', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PROVNEXP', 'Provisioning expense', 'E', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PROVNLIAB', 'Provisioning Liablilty', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PURCH INTIISNPL', 'purchase interest', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PURCH INTRECNPL', 'purchase interest', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PURCH INTUNRL', 'purchase interest', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIAQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIAQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIDOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIEXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIIINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIINC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINAQP', 'REBT INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINAQR', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINDOV', 'REBT INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINEXP', 'REBT INT FOR DIS TO FOR', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINIINPL', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTININC', 'REBT INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINPAY', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINPIA', 'REBT INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINPPD', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINREC', 'REBT INT FOR DIS TO FOR', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINRENPL', 'REBT INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINRIA', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIPAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIPIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIPPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIREC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIRENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIRIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ROLL_BRIDGE_GL', 'Bridge GL for BC Rollover', 'A', 'BC', 'Y', 'N', 'N');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_EXP', 'tax expense role for RTEST1', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_PAD', 'tax paid in adv role for RTEST1', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_PAY', 'tax payable role for RTEST1', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_EXP', 'tax expense role for RTEST2', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_PAD', 'tax paid in adv role for RTEST2', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_PAY', 'tax payable role for RTEST2', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01AQP', 'VINCLBC01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01AQR', 'VINCLBC01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01DOV', 'VINCLBC01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01EXP', 'VINCLBC01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01IINPL', 'VINCLBC01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01INC', 'VINCLBC01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01PAY', 'VINCLBC01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01PIA', 'VINCLBC01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01PPD', 'VINCLBC01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01REC', 'VINCLBC01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01RENPL', 'VINCLBC01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01RIA', 'VINCLBC01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02AQP', 'VINCLBC02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02AQR', 'VINCLBC02', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02DOV', 'VINCLBC02', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02EXP', 'VINCLBC02', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02IINPL', 'VINCLBC02', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02INC', 'VINCLBC02', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02PAY', 'VINCLBC02', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02PIA', 'VINCLBC02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02PPD', 'VINCLBC02', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02REC', 'VINCLBC02', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02RENPL', 'VINCLBC02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02RIA', 'VINCLBC02', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTAQP', 'TRANS INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTAQR', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTDOV', 'TRANS INT FOR DIS TO FOR CASE 2', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTEXP', 'TRANS INT FOR DIS TO FOR CASE 2', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTIINPL', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTINC', 'TRANS INT FOR DIS TO FOR CASE 2', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTPAY', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTPIA', 'TRANS INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTPPD', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTREC', 'TRANS INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTRENPL', 'TRANS INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTRIA', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUAP_COM2RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUPP_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUPP_COM2RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1INC', 'LC Issuance Commission (Sight)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1EXP', 'LC Issuance Commission (Sight)', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PAY', 'LC Issuance Commission (Sight)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1REC', 'LC Issuance Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AILSN_COM1RECV', 'LC Issuance Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1RECV', 'LC Issuance Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1RIA', 'LC Issuance Commission (Sight)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PIA', 'LC Issuance Commission (Sight)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1AQR', 'LC Issuance Commission (Sight)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PPD', 'LC Issuance Commission (Sight)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1UNRL', 'LC Issuance Commission (Sight)', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1INC', 'LC Issuance Commission (Usance)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1EXP', 'LC Issuance Commission (Usance)', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PAY', 'LC Issuance Commission (Usance)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1REC', 'LC Issuance Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AILUN_COM1RECV', 'LC Issuance Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1RECV', 'LC Issuance Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1RIA', 'LC Issuance Commission (Usance)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PIA', 'LC Issuance Commission (Usance)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1AQR', 'LC Issuance Commission (Usance)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PPD', 'LC Issuance Commission (Usance)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1UNRL', 'LC Issuance Commission (Usance)', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2INC', 'LC Amendment Commission (Sight)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2EXP', 'LC Amendment Commission (Sight)', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PAY', 'LC Amendment Commission (Sight)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2REC', 'LC Amendment Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AILSN_COM2RECV', 'LC Amendment Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2RECV', 'LC Amendment Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2RIA', 'LC Amendment Commission (Sight)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PIA', 'LC Amendment Commission (Sight)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2AQR', 'LC Amendment Commission (Sight)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PPD', 'LC Amendment Commission (Sight)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2UNRL', 'LC Amendment Commission (Sight)', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2INC', 'LC Amendment Commission (Usance)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2EXP', 'LC Amendment Commission (Usance)', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PAY', 'LC Amendment Commission (Usance)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2REC', 'LC Amendment Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AILUN_COM2RECV', 'LC Amendment Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2RECV', 'LC Amendment Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2RIA', 'LC Amendment Commission (Usance)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PIA', 'LC Amendment Commission (Usance)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2AQR', 'LC Amendment Commission (Usance)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PPD', 'LC Amendment Commission (Usance)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2UNRL', 'LC Amendment Commission (Usance)', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_ININC', 'Discount Interest Under LC Income', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INEXP', 'Discount Interest Under LC Expense', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INPAY', 'Discount Interest Under LC Payable', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INREC', 'Discount Interest Under LC Receivable', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INRIA', 'Discount Interest Under LC Received in advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INPIA', 'Discount Interest Under LC', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INAQR', 'Discount Interest Under LC Acquired interest receivable', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INAQP', 'Discount Interest Under LC Acquired interest payable', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INRENPL', 'Discount Interest Under LC', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INIINPL', 'Discount Interest Under LC', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INPPD', 'Discount Interest Under LC Prepaid Interest', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INDOV', 'Discount Interest Under LC', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INNORMINC', 'Discount Interest Under LC', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCOPNCG_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCOPNCG_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCOPNCG_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCOPNCG_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCOUR_REC', 'BC Courier Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCOUR_INC', 'BC Courier Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCOUR_IFBR', 'BC Courier Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCOUR_RIA', 'BC Courier Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCSWIFT_REC', 'BC Swift Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCSWIFT_INC', 'BC Swift Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCSWIFT_IFBR', 'BC Swift Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCSWIFT_RIA', 'BC Swift Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCLIQCG_REC', 'BC Liquidation Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCLIQCG_INC', 'BC Liquidation Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCLIQCG_IFBR', 'BC Liquidation Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCLIQCG_RIA', 'BC Liquidation Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCLCG_REC', 'BC Closure Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCLCG_INC', 'BC Closure Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCLCG_IFBR', 'BC Closure Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCLCG_RIA', 'BC Closure Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUAP_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1INC', 'BG Issuance/Re-Issuance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1EXP', 'BG Issuance/Re-Issuance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PAY', 'BG Issuance/Re-Issuance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1REC', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUIR_COM1RECV', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1RECV', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1RIA', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PIA', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1AQR', 'BG Issuance/Re-Issuance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PPD', 'BG Issuance/Re-Issuance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1UNRL', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2INC', 'BG Issuance/Re-Issuance Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2EXP', 'BG Issuance/Re-Issuance Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PAY', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2REC', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUIR_COM2RECV', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2RECV', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2RIA', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PIA', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2AQR', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PPD', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2UNRL', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1INC', 'BG Standby Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1EXP', 'BG Standby Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PAY', 'BG Standby Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1REC', 'BG Standby Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_ASBLC_COM1RECV', 'BG Standby Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1RECV', 'BG Standby Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1RIA', 'BG Standby Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PIA', 'BG Standby Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1AQR', 'BG Standby Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PPD', 'BG Standby Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1UNRL', 'BG Standby Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2INC', 'BG Standby Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2EXP', 'BG Standby Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PAY', 'BG Standby Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2REC', 'BG Standby Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_ASBLC_COM2RECV', 'BG Standby Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2RECV', 'BG Standby Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2RIA', 'BG Standby Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PIA', 'BG Standby Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2AQR', 'BG Standby Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PPD', 'BG Standby Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2UNRL', 'BG Standby Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1INC', 'BG Shipping Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1EXP', 'BG Shipping Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PAY', 'BG Shipping Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1REC', 'BG Shipping Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_ASGLC_COM1RECV', 'BG Shipping Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1RECV', 'BG Shipping Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1RIA', 'BG Shipping Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PIA', 'BG Shipping Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1AQR', 'BG Shipping Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PPD', 'BG Shipping Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1UNRL', 'BG Shipping Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2INC', 'BG Shipping Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2EXP', 'BG Shipping Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PAY', 'BG Shipping Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2REC', 'BG Shipping Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_ASGLC_COM2RECV', 'BG Shipping Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2RECV', 'BG Shipping Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2RIA', 'BG Shipping Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PIA', 'BG Shipping Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2AQR', 'BG Shipping Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PPD', 'BG Shipping Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2UNRL', 'BG Shipping Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1INC', 'BG Counter Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1EXP', 'BG Counter Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PAY', 'BG Counter Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1REC', 'BG Counter Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUCG_COM1RECV', 'BG Counter Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1RECV', 'BG Counter Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1RIA', 'BG Counter Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PIA', 'BG Counter Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1AQR', 'BG Counter Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PPD', 'BG Counter Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1UNRL', 'BG Counter Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2INC', 'BG Counter Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2EXP', 'BG Counter Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PAY', 'BG Counter Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2REC', 'BG Counter Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUCG_COM2RECV', 'BG Counter Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2RECV', 'BG Counter Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2RIA', 'BG Counter Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PIA', 'BG Counter Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2AQR', 'BG Counter Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PPD', 'BG Counter Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2UNRL', 'BG Counter Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1INC', 'BG Bid Bond Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1EXP', 'BG Bid Bond Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PAY', 'BG Bid Bond Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1REC', 'BG Bid Bond Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUBB_COM1RECV', 'BG Bid Bond Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1RECV', 'BG Bid Bond Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1RIA', 'BG Bid Bond Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PIA', 'BG Bid Bond Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1AQR', 'BG Bid Bond Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PPD', 'BG Bid Bond Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1UNRL', 'BG Bid Bond Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2INC', 'BG Bid Bond Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2EXP', 'BG Bid Bond Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PAY', 'BG Bid Bond Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2REC', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUBB_COM2RECV', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2RECV', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2RIA', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PIA', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2AQR', 'BG Bid Bond Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PPD', 'BG Bid Bond Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2UNRL', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUPG_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2INC', 'BG Performance Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2EXP', 'BG Performance Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PAY', 'BG Performance Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2REC', 'BG Performance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUPG_COM2RECV', 'BG Performance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2RECV', 'BG Performance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2RIA', 'BG Performance Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PIA', 'BG Performance Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2AQR', 'BG Performance Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PPD', 'BG Performance Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2UNRL', 'BG Performance Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1INC', 'BG Payment/Money Retension Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1EXP', 'BG Payment/Money Retension Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PAY', 'BG Payment/Money Retension Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1REC', 'BG Payment/Money Retension Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGURG_COM1RECV', 'BG Payment/Money Retension Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1RECV', 'BG Payment/Money Retension Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1RIA', 'BG Payment/Money Retension Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PIA', 'BG Payment/Money Retension Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1AQR', 'BG Payment/Money Retension Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PPD', 'BG Payment/Money Retension Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1UNRL', 'BG Payment/Money Retension Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2INC', 'BG Payment/Money Retension Amendment  Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2EXP', 'BG Payment/Money Retension Amendment  Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PAY', 'BG Payment/Money Retension Amendment  Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2REC', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGURG_COM2RECV', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2RECV', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2RIA', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PIA', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2AQR', 'BG Payment/Money Retension Amendment  Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PPD', 'BG Payment/Money Retension Amendment  Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2UNRL', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_ININC', 'Discount Interest Clean Income', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INEXP', 'Discount Interest Clean Expense', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INPAY', 'Discount Interest Clean Payable', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INREC', 'Discount Interest Clean Receivable', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INRIA', 'Discount Interest Clean Received in advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INPIA', 'Discount Interest Clean', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INAQR', 'Discount Interest Clean Acquired interest receivable', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INAQP', 'Discount Interest Clean Acquired interest payable', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INRENPL', 'Discount Interest Clean', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INIINPL', 'Discount Interest Clean', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INPPD', 'Discount Interest Clean Prepaid Interest', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INDOV', 'Discount Interest Clean', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INNORMINC', 'Discount Interest Clean', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_ININC', 'Acceptance Interest Under LC Income', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INEXP', 'Acceptance Interest Under LC Expense', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INPAY', 'Acceptance Interest Under LC Payable', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INREC', 'Acceptance Interest Under LC Receivable', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INRIA', 'Acceptance Interest Under LC Received in advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INPIA', 'Acceptance Interest Under LC', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INAQR', 'Acceptance Interest Under LC Acquired interest receivable', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INAQP', 'Acceptance Interest Under LC Acquired interest payable', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INRENPL', 'Acceptance Interest Under LC', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INIINPL', 'Acceptance Interest Under LC', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INPPD', 'Acceptance Interest Under LC Prepaid Interest', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INDOV', 'Acceptance Interest Under LC', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INNORMINC', 'Acceptance Interest Under LC', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_ININC', 'Acceptance Interest Clean Income', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INEXP', 'Acceptance Interest Clean Expense', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INPAY', 'Acceptance Interest Clean Payable', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INREC', 'Acceptance Interest Clean Receivable', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INRIA', 'Acceptance Interest Clean Received in advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INPIA', 'Acceptance Interest Clean', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INAQR', 'Acceptance Interest Clean Acquired interest receivable', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INAQP', 'Acceptance Interest Clean Acquired interest payable', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INRENPL', 'Acceptance Interest Clean', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INIINPL', 'Acceptance Interest Clean', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INPPD', 'Acceptance Interest Clean Prepaid Interest', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INDOV', 'Acceptance Interest Clean', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INNORMINC', 'Acceptance Interest Clean', 'I', 'BC', 'Y', null, null);

COMMIT;
