prompt Importing table cftms_rule...
set feedback off
set define off
insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM1', 'BG Issuance Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM2', 'BG StandBy Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM3', 'BG Shipping Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM4', 'BG Counter Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM5', 'BG BidBond Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM6', 'BG Performance Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM7', 'BG Payment Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM8', 'BG Payment Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ABGCOM9', 'BG Advance Payment Commission');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ACP_INT1', 'Acceptance Interest Under LC');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ACP_INT2', 'Acceptance Interest Clean');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ALCCOM1', 'LC issuance Commission (Sight)');

insert into cftms_rule (RULE, DESCRIPTION)
values ('ALCCOM2', 'LC issuance Commission (Usance)');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BCCLCG', 'BC Closure Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BCCOUR', 'BC Courier Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BCLIQCG', 'BC Liquidation Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BCOPNCG', 'BC Opening Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BCSWIFT', 'BC Swift Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BGADVCHG', 'BG Advicing Charge');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BGCANCHG', 'BG Cancellation Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BGCLMCHG', 'Guarantee Claim Charge');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BGCOURIER', 'BG Courier Charge');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BGSWIFTAMN', 'SWIFT Charges for BG Amendment');

insert into cftms_rule (RULE, DESCRIPTION)
values ('BGSWIFTISS', 'SWIFT Charges for BG Issuance');

insert into cftms_rule (RULE, DESCRIPTION)
values ('DIS_INT1', 'Discount Interest Under LC');

insert into cftms_rule (RULE, DESCRIPTION)
values ('DIS_INT2', 'Discount Interest Clean');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCADVCHG', 'LC Advicing Charge');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCAMENDMEN', 'LC Amedment Charge');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCCANCHG', 'LC Cancellation Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCCNFMCHG', 'LC Confirming Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCCOURIER', 'LC Courier Charge');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCDOCCHG', 'LC Documentary Charges');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCISSUANCE', 'LC Issuance Charge');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCSWIFTAMN', 'SWIFT Charges for LC Amendment');

insert into cftms_rule (RULE, DESCRIPTION)
values ('LCSWIFTISS', 'SWIFT Charges for LC Issuance');

prompt Done.
