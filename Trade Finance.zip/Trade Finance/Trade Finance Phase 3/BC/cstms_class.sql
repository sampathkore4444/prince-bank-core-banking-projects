prompt Importing table cstms_class...
set feedback off
set define off
insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCCLCG', 'BC Closure Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 12:09:26', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 12:09:26', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCCOUR', 'BC Courier Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 12:06:42', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 12:06:42', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCLIQCG', 'BC Liquidation Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 12:08:41', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 12:08:41', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCOPNCG', 'BC Opening Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 12:05:27', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 12:05:27', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCSWIFT', 'BC Swift Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 12:07:23', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 12:07:23', 'dd-mm-yyyy hh24:mi:ss'), 1);

prompt Done.
