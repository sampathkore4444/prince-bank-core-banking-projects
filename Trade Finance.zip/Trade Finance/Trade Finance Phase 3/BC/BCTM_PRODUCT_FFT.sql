prompt Importing table BCTM_PRODUCT_FFT...
set feedback off
set define off
insert into BCTM_PRODUCT_FFT (PROD_CODE, FFT_CODE, ADV_CODE, FFT_SL_NO)
values ('IULL', 'SNDRRCVRINFO', 'REIM_PAY_ADV', null);

prompt Done.
