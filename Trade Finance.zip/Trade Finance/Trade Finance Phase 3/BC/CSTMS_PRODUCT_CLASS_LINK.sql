prompt Importing table CSTMS_PRODUCT_CLASS_LINK...
set feedback off
set define off
insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAPS', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAPS', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAPS', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAPS', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAPS', 'RH', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAUC', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAUC', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAUC', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAUC', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('EAUC', 'RH', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ECUC', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ECUC', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ECUC', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ECUC', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ECUC', 'RH', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESCC', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESCC', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESCC', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESCC', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESCC', 'RH', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESUC', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESUC', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESUC', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESUC', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ESUC', 'RH', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ICLC', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ICLC', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ICLC', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ICLC', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ICLC', 'RH', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ISND', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ISND', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ISND', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ISND', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('ISND', 'RH', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IULL', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IULL', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IULL', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IULL', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IULL', 'RH', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IUNL', 'AC', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IUNL', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IUNL', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IUNL', 'DA', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('IUNL', 'RH', null);

prompt Done.
