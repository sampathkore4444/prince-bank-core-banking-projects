prompt Importing table BCTM_DOCS_MASTER...
set feedback off
set define off
insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('UPLD_700_46', 'ENG', 'Export Document', 'Export Document', 'O', 'YRAROTH1', to_date('06-03-2019 15:19:07', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 15:19:07', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 1, 'N', 'N');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('OTHERDOC', 'ENG', 'OTHERDOC', 'Other Docs', 'O', 'YRAROTH1', to_date('06-03-2019 14:42:33', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 14:42:33', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 2, 'N', 'N');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('INVDOC', 'ENG', 'Invoice', 'Invoice Documents', 'V', 'YRAROTH1', to_date('06-03-2019 14:43:51', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 14:43:51', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 2, 'N', 'N');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('MARDOC', 'ENG', 'Sea Way', 'Sea Way Documents', 'T', 'YRAROTH1', to_date('06-03-2019 14:44:26', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 14:44:26', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 2, 'Y', 'Y');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('INSDOC', 'ENG', 'Insurance', 'Insurance Documents', 'I', 'YRAROTH1', to_date('06-03-2019 11:34:19', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 11:34:19', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 1, 'N', 'N');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('OTHDOC', 'ENG', 'Other', 'Other Document', 'O', 'YRAROTH1', to_date('06-03-2019 14:45:21', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 14:45:21', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 2, 'N', 'N');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('AIRDOC', 'ENG', 'Air Way', 'Air Way Documents', 'T', 'YRAROTH1', to_date('06-03-2019 14:45:53', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 14:45:53', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 2, 'N', 'N');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('BOL', 'ENG', 'Bill of Lading', 'Bill of Lading', 'T', 'YRAROTH1', to_date('06-03-2019 14:47:11', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 14:47:11', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 2, 'N', 'Y');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('AIR', 'ENG', 'Air way Bill Docs', 'Air way Bill Docs', 'T', 'YRAROTH1', to_date('06-03-2019 14:47:52', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 14:47:52', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 3, 'N', 'N');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('INVOICE', 'ENG', 'INVOICE', 'INVOICE Documents', 'T', 'YRAROTH1', to_date('06-03-2019 11:37:48', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 11:37:48', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 3, 'N', 'N');

insert into BCTM_DOCS_MASTER (DOC_CODE, LANG_CODE, DOC_SHORT_DESC, DOC_LONG_DESC, DOC_TYPE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, VALIDATE_SHIP_GUA, BILL_OF_LADING_DOC)
values ('PACKINGLIST', 'ENG', 'PACKINGLIST', 'PACKINGLIST', 'V', 'YRAROTH1', to_date('06-03-2019 11:38:16', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('06-03-2019 11:38:16', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', 'Y', 1, 'N', 'N');

prompt Done.
