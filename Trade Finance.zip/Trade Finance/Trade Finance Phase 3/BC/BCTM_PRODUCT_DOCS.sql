prompt Importing table BCTM_PRODUCT_DOCS...
set feedback off
set define off
insert into BCTM_PRODUCT_DOCS (PROD_CODE, DOC_CODE, DOC_SL_NO)
values ('IULL', 'AIR', null);

insert into BCTM_PRODUCT_DOCS (PROD_CODE, DOC_CODE, DOC_SL_NO)
values ('IULL', 'BOL', null);

prompt Done.
