prompt Importing table TATM_PRODUCT_SCHEME...
set feedback off
set define off
insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('GUCG', null, 'LC', null);

insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('GUIR', null, 'LC', null);

insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('GUAD', null, 'LC', null);

insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('SBLC', null, 'LC', null);

insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('ELNR', null, 'LC', null);

insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('ILUN', null, 'LC', null);

insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('ILSN', null, 'LC', null);

insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('ELCR', null, 'LC', null);

prompt Done.
