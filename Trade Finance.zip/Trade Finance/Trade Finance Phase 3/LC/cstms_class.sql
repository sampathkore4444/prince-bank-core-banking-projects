prompt Importing table cstms_class...
set feedback off
set define off
insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGADVCHG', 'BG Advicing charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 20:09:42', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 20:09:42', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGCANCHG', 'BG Cancellation Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 20:10:09', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 20:10:09', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGCLMCHG', 'Guarantee Claim Charge', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('07-03-2019 14:00:29', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('07-03-2019 14:00:30', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGCOURIER', 'BG Courier Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 20:10:44', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 20:10:44', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGSWIFTAMN', 'BG SWIFT Charge for Amendment', 'CH', null, null, null, 'O', 'A', 'Y', 'TANNLEANG1', to_date('08-04-2019 16:53:53', 'dd-mm-yyyy hh24:mi:ss'), 'TANNLEANG1', to_date('08-04-2019 16:53:53', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGSWIFTISS', 'BG SWIFT Charge for Issuance', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('06-03-2019 20:10:15', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('06-03-2019 20:10:15', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCADVCHG', 'LC Export Advicing charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 18:02:05', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 18:02:05', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCAMENDMEN', 'LC Amendment Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('06-03-2019 14:34:35', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('06-03-2019 14:34:35', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCCANCHG', 'LC Cancellation Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('06-03-2019 16:13:14', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('06-03-2019 16:13:14', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCCNFMCHG', 'LC Confirming Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 18:00:05', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 18:00:05', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCCOURIER', 'LC Courier Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 11:41:26', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 11:41:26', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCDOCCHG', 'LC Documentary Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('06-03-2019 16:12:39', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('06-03-2019 16:12:39', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCISSUANCE', 'LC Issuance Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 11:40:27', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 11:40:27', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCSWIFTAMN', 'LC SWIFT Charge for Amendment', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 11:39:30', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 11:39:30', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCSWIFTISS', 'LC SWIFT Charge for Issuance', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 11:42:22', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 11:42:22', 'dd-mm-yyyy hh24:mi:ss'), 1);

prompt Done.
