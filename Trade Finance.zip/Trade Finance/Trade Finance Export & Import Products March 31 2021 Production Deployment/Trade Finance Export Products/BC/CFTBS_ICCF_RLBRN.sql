insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCAMNDAMTD', 'Amendment of LC Amount - Decrease', 'D', 'HLEANG', to_date('14-01-2020 13:31:19', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 13:31:19', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCAMNDEXDT', 'Amendment of LC Expiry Date - Increase', 'D', 'HLEANG', to_date('14-01-2020 13:54:41', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 13:54:41', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('GUAPCO1', 'BG Advance Payment Commission', 'D', 'HLEANG', to_date('14-01-2020 18:03:35', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 18:03:35', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('GUBBCO5', 'BG BidBond Commission', 'D', 'HLEANG', to_date('14-01-2020 18:13:39', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 18:13:39', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCECORADCF', 'LC Courier Charge', 'D', 'SAMPATH1', to_date('14-01-2020 21:25:14', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 21:26:21', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCECORBANC', 'LC Export Courier Charges for Advice and Confirm', 'D', 'SAMPATH2', to_date('14-01-2020 21:35:35', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 21:35:35', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('TEST', 'TEST', 'D', 'SAMPATH2', to_date('14-01-2020 11:20:36', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:20:36', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 2, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCISETINIT', 'Import BC Under LC Settlement Charges during INIT(Final)', 'D', 'SAMPATH2', to_date('14-01-2020 17:15:44', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 17:15:44', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('TEST1', 'TEST', 'D', 'SAMPATH2', to_date('14-01-2020 18:48:21', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 18:48:21', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BGCLMCHG', 'Guarantee Claim Charge', 'D', 'SYSTEM', to_date('07-03-2019 13:56:27', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('07-03-2019 13:56:27', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM8', 'BG Payment Commission', 'D', 'SYSTEM', to_date('08-04-2019 14:06:14', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('08-04-2019 14:11:06', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM9', 'BG Advance Payment Commission', 'D', 'SYSTEM', to_date('08-04-2019 14:08:18', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('08-04-2019 14:11:12', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCOPNCG', 'BC Opening Charges', 'D', 'SAMPATH2', to_date('14-01-2020 23:25:34', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 23:25:34', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 2, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCCOUR', 'BC Courier Charges', 'D', 'SAMPATH2', to_date('14-01-2020 23:02:36', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 23:02:36', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 3, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCSWIFT', 'BC Swift Charges', 'D', 'SYSTEM', to_date('06-03-2019 11:56:19', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 11:56:19', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCLIQCG', 'BC Liquidation Charges', 'D', 'SYSTEM', to_date('06-03-2019 11:56:51', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 11:56:51', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCCLCG', 'BC Closure Charges', 'D', 'SYSTEM', to_date('06-03-2019 11:57:40', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 11:57:40', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BGADVCHG', 'BG Advicing Charge', 'D', 'SYSTEM', to_date('06-03-2019 19:57:18', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:57:18', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BGCANCHG', 'BG Cancellation Charges', 'D', 'SYSTEM', to_date('06-03-2019 19:57:38', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:57:38', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BGCOURIER', 'BG Courier Charge', 'D', 'SYSTEM', to_date('06-03-2019 19:57:59', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:57:59', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BGSWIFTISS', 'SWIFT Charges for BG Issuance', 'D', 'SYSTEM', to_date('06-03-2019 19:58:47', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:58:47', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BGSWIFTAMN', 'SWIFT Charges for BG Amendment', 'D', 'SYSTEM', to_date('06-03-2019 19:59:05', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:59:05', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ALCCOM1', 'LC issuance Commission (Sight)', 'D', 'SYSTEM', to_date('06-03-2019 10:28:11', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 10:28:12', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCSWIFTISS', 'SWIFT Charges for LC Issuance', 'D', 'SYSTEM', to_date('06-03-2019 10:48:53', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 10:48:53', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCISSUANCE', 'LC Issuance Charge', 'D', 'SYSTEM', to_date('06-03-2019 10:49:45', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 10:49:45', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCSWIFTAMN', 'SWIFT Charges for LC Amendment', 'D', 'SYSTEM', to_date('06-03-2019 10:50:58', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 10:50:58', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCCOURIER', 'LC Courier Charge', 'D', 'SYSTEM', to_date('06-03-2019 10:52:49', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 10:52:49', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ALCCOM2', 'LC issuance Commission (Usance)', 'D', 'SYSTEM', to_date('06-03-2019 11:11:17', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 11:11:17', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCCANCHG', 'LC Cancellation Charges', 'D', 'SYSTEM', to_date('06-03-2019 15:19:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 15:19:10', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCDOCCHG', 'LC Documentary Charges', 'D', 'SYSTEM', to_date('06-03-2019 15:19:46', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 15:19:46', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCADVCHG', 'Advising Charge', 'D', 'SYSTEM', to_date('06-03-2019 17:51:08', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 17:51:08', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCCNFMCHG', 'LC Confirming Charges', 'D', 'SYSTEM', to_date('06-03-2019 17:51:42', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 17:51:42', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM1', 'BG Issuance Commission', 'D', 'SYSTEM', to_date('06-03-2019 19:24:42', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:24:42', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM2', 'BG StandBy Commission', 'D', 'SYSTEM', to_date('06-03-2019 19:25:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:25:10', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM3', 'BG Shipping Commission', 'D', 'SYSTEM', to_date('06-03-2019 19:25:43', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:25:43', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM4', 'BG Counter Commission', 'D', 'SYSTEM', to_date('06-03-2019 19:25:57', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:25:57', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM5', 'BG BidBond Commission', 'D', 'SYSTEM', to_date('06-03-2019 19:26:09', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:26:09', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM6', 'BG Performance Commission', 'D', 'SYSTEM', to_date('06-03-2019 19:26:21', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:26:21', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM7', 'BG Payment Commission', 'D', 'SYSTEM', to_date('06-03-2019 19:26:35', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 19:26:35', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('DIS_INT1', 'Discount Interest Under LC', 'D', 'SYSTEM', to_date('06-03-2019 17:00:41', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 17:00:41', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('DIS_INT2', 'Discount Interest Clean', 'D', 'SYSTEM', to_date('06-03-2019 17:00:57', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 17:00:57', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ACP_INT1', 'Acceptance Interest Under LC', 'D', 'SYSTEM', to_date('06-03-2019 17:02:14', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 17:02:14', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ACP_INT2', 'Acceptance Interest Clean', 'D', 'SYSTEM', to_date('06-03-2019 17:02:34', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 17:02:34', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCAMENDMEN', 'Other BG Amendment', 'D', 'SYSTEM', to_date('06-03-2019 14:31:46', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-03-2019 14:31:46', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('ABGCOM10', 'Commission For Others', 'D', 'SAMPATH1', to_date('14-01-2020 16:55:40', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH1', to_date('14-01-2020 16:55:40', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCIDISLIQD', 'BC Import Discrepencies Charges during Liquidation', 'D', 'SAMPATH2', to_date('14-01-2020 11:50:40', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:50:40', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCEDOCBOOK', 'BC Export Documentation Examination Charges during BOOK Event', 'D', 'SAMPATH2', to_date('14-01-2020 14:02:54', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 14:02:55', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCISETLIQD', 'Import BC Under LC Settlement Charges during LIQD(Final)', 'D', 'SAMPATH2', to_date('14-01-2020 11:54:30', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:54:30', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCIREILIQD', 'Import BC Under LC Reimbursement Charges during LIQD(Final)', 'D', 'SAMPATH2', to_date('14-01-2020 11:56:06', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:56:06', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCIACCLIQD', 'BC IMPORT UNDER LC ACCEPTANCE CHARGE DURING LIQD(FINAL)', 'D', 'SAMPATH2', to_date('14-01-2020 11:57:28', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:57:29', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCCORRES', 'BC CORRESPONDENT CHARGE', 'D', 'HLEANG', to_date('14-01-2020 17:22:36', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 17:22:37', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCCORCG', 'BC Correspondent Charge', 'D', 'HLEANG', to_date('14-01-2020 17:38:29', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 17:38:29', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCAMNEXDTD', 'BG Amendment on Increase Expiry Date', 'D', 'HLEANG', to_date('14-01-2020 13:57:42', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 13:57:42', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCICABBISS', 'LC Import Cable Charges for Booking Issuance', 'D', 'SAMPATH2', to_date('14-01-2020 20:07:21', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 20:07:22', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCIDAMAMND', 'LC Import Decrease Amount for Amendment', 'D', 'SAMPATH2', to_date('14-01-2020 12:20:00', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:20:00', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCIDEXAMND', 'LC Import Decrease Expory Date for Amendment', 'D', 'SAMPATH2', to_date('14-01-2020 12:20:56', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:20:56', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCIIAMAMND', 'LC Import Increase Amount Commission for Amendment', 'D', 'SAMPATH2', to_date('14-01-2020 12:53:18', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:53:18', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCIIACAMND', 'LC Import Increase Amount Cable Fee Commission for Amendment', 'D', 'SAMPATH2', to_date('14-01-2020 13:04:18', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 13:04:18', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCIIEXAMND', 'LC Import Increase Expiry Date Commission for Amendment', 'D', 'SAMPATH2', to_date('14-01-2020 13:09:51', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 13:09:51', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCIIECAMND', 'LC Import Increase Expiry Date Cable Fee Commission for Amendment', 'D', 'SAMPATH2', to_date('14-01-2020 13:11:19', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 13:11:19', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCIACCBOOK', 'BC IMPORT UNDER LC ACCEPTANCE CHARGE USSANCE DURING BOOK', 'D', 'SAMPATH2', to_date('14-01-2020 16:54:12', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 16:54:12', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCIREIINIT', 'Import BC Under LC Reimbursement Charges during INIT(Final)', 'D', 'SAMPATH2', to_date('14-01-2020 16:58:16', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 16:58:16', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCADVAMND', 'Amendment Advising Charge', 'D', 'SAMPATH2', to_date('14-01-2020 10:59:17', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 10:59:17', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('OAMENDMENT', 'Other LC Amendment', 'D', 'HLEANG', to_date('14-01-2020 14:30:05', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 14:30:05', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('BCDOCUMENT', 'BC Document Examination Charges', 'D', 'HLEANG', to_date('14-01-2020 10:55:16', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 10:55:17', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

COMMIT;
