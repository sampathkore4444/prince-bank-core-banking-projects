insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'ACKB', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'ADIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'BACP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'BDIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'BOOK', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'INIT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'LDIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'LIQD', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'REFA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'REFP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'REVR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'STCH', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'TAFT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'TDIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'TPFT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUA', 'TRES', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'ADIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'BACP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'BDIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'BOOK', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'INIT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'LDIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'LIQD', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'REFA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'REFP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'REVR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'STCH', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'TAFT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EBUP', 'TPFT', null);

COMMIT;
