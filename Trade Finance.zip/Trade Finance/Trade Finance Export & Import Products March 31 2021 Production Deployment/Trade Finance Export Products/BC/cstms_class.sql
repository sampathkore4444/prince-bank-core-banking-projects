insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCCLCG', 'BC Closure Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 22:53:18', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 22:53:19', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCCORCG', 'BC Correspondent Charge', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('14-01-2020 10:51:36', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 10:51:36', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCCOUR', 'BC Courier Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('14-01-2020 11:54:07', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 11:54:07', 'dd-mm-yyyy hh24:mi:ss'), 4);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCDOCUMENT', 'BC Document Examination Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('14-01-2020 11:52:14', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 11:52:15', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCIACCBOOK', 'BC IMPORT UNDER LC ACCEPTANCE CHARGE USSANCE DURIN', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 19:52:17', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:52:17', 'dd-mm-yyyy hh24:mi:ss'), 3);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCIACCLIQD', 'BC IMPORT ACCEPTANCE FEE CLASS', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('14-01-2020 10:27:56', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 10:27:56', 'dd-mm-yyyy hh24:mi:ss'), 3);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCIDISLIQD', 'BC IMPORT DISCPREPENCIES CHARGES', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('14-01-2020 18:13:02', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 18:13:02', 'dd-mm-yyyy hh24:mi:ss'), 3);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCIREIINIT', 'Import BC Under LC Reimbursement Charges during INIT(Final)', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 17:01:06', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 17:01:06', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCIREILIQD', 'BC IMPORT REIMBURSEMENT Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 12:14:39', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:14:39', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCISETINIT', 'Import BC Under LC Settlement Charges during INIT(Final)', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 17:18:00', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 17:18:00', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCISETLIQD', 'BC IMPORT SETTLEMENT Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 12:14:26', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:14:26', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCLIQCG', 'BC Liquidation Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 22:53:45', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 22:53:45', 'dd-mm-yyyy hh24:mi:ss'), 3);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCOPNCG', 'BC Opening Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 11:24:00', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:24:00', 'dd-mm-yyyy hh24:mi:ss'), 3);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCSWIFT', 'BC Swift Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('14-01-2020 11:43:40', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 11:43:40', 'dd-mm-yyyy hh24:mi:ss'), 4);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'TEST', 'BC Courier Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 09:51:46', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 09:51:46', 'dd-mm-yyyy hh24:mi:ss'), 1);

COMMIT;
