insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CHG_CUST_ACC', 'Customer Accounts', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLAIM_CREDIT_ACCT', 'Claim Credit Account', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLAIM_DEBIT_ACCT', 'Claim Debit Account', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLAIM_SUSPENSE', 'Claim Suspense', 'A', 'LC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMM1AQR', 'comm on lc amendment(tiered amt)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMM1EXP', 'comm on lc amendment(tiered amt)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMM1INC', 'comm on lc amendment(tiered amt)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMM1PAY', 'comm on lc amendment(tiered amt)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMM1PIA', 'comm on lc amendment(tiered amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMM1REC', 'comm on lc amendment(tiered amt)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMM1RIA', 'comm on lc amendment(tiered amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMM1UNRL', 'comm on lc amendment(tiered amt)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMMAQR', 'commission on lc issue(tiered amt)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMMEXP', 'commission on lc issue(tiered amt)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMMINC', 'commission on lc issue(tiered amt)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMMPAY', 'commission on lc issue(tiered amt)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMMPIA', 'commission on lc issue(tiered amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMMREC', 'commission on lc issue(tiered amt)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMMRIA', 'commission on lc issue(tiered amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLC1_COMMUNRL', 'commission on lc issue(tiered amt)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLFA CONT', 'Cust. Liab. for Acceptances - Cont', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLFA REAL', 'Cust. Liab. for Acceptances - Real', 'A', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMAQR', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMEXP', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMINC', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMPAY', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMPIA', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMPPD', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMREC', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMRIA', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('CLLC_COMMUNRL', 'Commission on LC Issue ( SLAB AMOUNT- WITH TENOR)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('COLL OFFSET', 'Offset for Bills Under Collection', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('COL_CUST_ACC', 'Customer Accounts', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('COL_DEPOSIT_ACC', 'Customer Accounts', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('COMM_CUST_ACC', 'Customer Accounts', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACCEPTANCE CONT', 'Bills Accepted - Contingent Asset', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACCEPTANCE REAL', 'Bills Accepted - Real Asset', 'L', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMAQR', 'ACCEPTANCE COMMISSION', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMEXP', 'ACCEPTANCE COMMISSION', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMIISNPL', 'ACCEPTANCE COMMISSION', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMINC', 'ACCEPTANCE COMMISSION', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMPAY', 'ACCEPTANCE COMMISSION', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMPIA', 'ACCEPTANCE COMMISSION', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMREC', 'ACCEPTANCE COMMISSION', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMRECNPL', 'ACCEPTANCE COMMISSION', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMRIA', 'ACCEPTANCE COMMISSION', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ACPT COMMUNRL', 'ACCEPTANCE COMMISSION', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTAQR', 'INTEREST ON ADVANCE', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTEXP', 'INTEREST ON ADVANCE', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTIISNPL', 'INTEREST ON ADVANCE', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTINC', 'INTEREST ON ADVANCE', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTPAY', 'INTEREST ON ADVANCE', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTPIA', 'INTEREST ON ADVANCE', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTREC', 'INTEREST ON ADVANCE', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTRECNPL', 'INTEREST ON ADVANCE', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTRIA', 'INTEREST ON ADVANCE', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV INTUNRL', 'INTEREST ON ADVANCE', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ADV UNDER LCS', 'Advances Under LC`s Issued', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGENT ACCOUNT', 'Broker Agent Account', 'X', 'BC', 'N', 'N', 'N');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASSETGLNPL', 'NPL Asset GL for Bills', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AVAL_INT_ACC', 'Availment internal account', 'A', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AVL_CREDIT_ACCT', 'Availment Credit account', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AVL_DEBIT_ACCT', 'Availment Debit account', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC CUSTOMER', 'Customer Accounts', 'X', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01AQR', 'BCINT01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01EXP', 'BCINT01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01IISNPL', 'BCINT01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01INC', 'BCINT01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01PAY', 'BCINT01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01PIA', 'BCINT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01REC', 'BCINT01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01RECNPL', 'BCINT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01RIA', 'BCINT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCINT01UNRL', 'BCINT01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX1_EXP', 'tax expence role forBCTAX1', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX1_PAD', 'tax paid in adv role forBCTAX1', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX1_PAY', 'tax payable role forBCTAX1', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX3_EXP', 'tax expence role forBCTAX3', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX3_PAD', 'tax paid in adv role forBCTAX3', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX3_PAY', 'tax payable role forBCTAX3', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX_EXP', 'tax expence role forBCTAX', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX_PAD', 'tax paid in adv role forBCTAX', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCTAX_PAY', 'tax payable role forBCTAX', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_UCNF', 'Unconfirmed Amount for Export Bills', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_UCNF_OFF', 'Unconfirmed Offset Amount for Export Bills', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILL COLLATERAL', 'Collateral Collected under Bills', 'L', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILL COLLOFFSET', 'Bills Collateral Collected Offset', 'A', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILL MARGIN', 'Margin amt collected on Disnt Bill', 'A', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLCOLLCONT', 'Coll collected bills contingent', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLCOLLCONTOFF', 'Coll collected bills cont offset', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLS DISCNTED', 'Bills Discounted', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLS NEGOTIATE', 'Outgoing Bills Negotiated', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BILLS PURCHASED', 'Outgoing Bills Purchased', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BPUR_INT01IISNPL', 'BPUR_INT01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BPUR_INT01RECNPL', 'BPUR_INT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BPUR_INT01UNRL', 'BPUR_INT01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BRIDGE GL', 'Bridge GL', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BROKPAY', 'Brokerage Payable', 'L', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMINTADJINC', 'Effective Int Par Income', 'I', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMINTADJREC', 'Effective Int Par Receivable', 'I', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMPREMEXP', 'Effective Int Premium Expense', 'I', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMPREMPIA', 'Effective Int Paid in Advance', 'I', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMM1AQR', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMM1EXP', 'Commission on LC Amendment ( SLAB A', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMM1INC', 'Commission on LC Amendment ( SLAB A', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMM1PAY', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMM1PIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMM1REC', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMM1RIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMM1UNRL', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMMAQR', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMMEXP', 'Commission on LC Issue ( SLAB AMOUN', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMMINC', 'Commission on LC Issue ( SLAB AMOUN', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMMPAY', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMMPIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMMREC', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMMRIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIRE_COMMUNRL', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMM1AQR', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMM1EXP', 'Commission on LC Amendment ( SLAB A', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMM1INC', 'Commission on LC Amendment ( SLAB A', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMM1PAY', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMM1PIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMM1REC', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMM1RIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMM1UNRL', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMMAQR', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMMEXP', 'Commission on LC Issue ( SLAB AMOUN', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMMINC', 'Commission on LC Issue ( SLAB AMOUN', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMMPAY', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMMPIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMMREC', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMMRIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIN_COMMUNRL', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMM1AQR', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMM1EXP', 'Commission on LC Issue ( SLAB AMOUN', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMM1INC', 'Commission on LC Issue ( SLAB AMOUN', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMM1PAY', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMM1PIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMM1REC', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMM1RIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMM1UNRL', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMMAQR', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMMEXP', 'Commission on LC Issue ( SLAB AMOUN', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMMINC', 'Commission on LC Issue ( SLAB AMOUN', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMMPAY', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMMPIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMMREC', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMMRIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTFI_COMMUNRL', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMM1AQR', 'Commission on LC Amendment ( TEIRED', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMM1EXP', 'Commission on LC Amendment ( TEIRED', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMM1INC', 'Commission on LC Amendment ( TEIRED', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMM1PAY', 'Commission on LC Amendment ( TEIRED', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMM1PIA', 'Commission on LC Amendment ( TEIRED', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMM1REC', 'Commission on LC Amendment ( TEIRED', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMM1RIA', 'Commission on LC Amendment ( TEIRED', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMM1UNRL', 'Commission on LC Amendment ( TEIRED', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMMAQR', 'Commission on LC Issue ( TEIRED AMO', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMMEXP', 'Commission on LC Issue ( TEIRED AMO', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMMINC', 'Commission on LC Issue ( TEIRED AMO', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMMPAY', 'Commission on LC Issue ( TEIRED AMO', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMMPIA', 'Commission on LC Issue ( TEIRED AMO', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMMREC', 'Commission on LC Issue ( TEIRED AMO', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMMRIA', 'Commission on LC Issue ( TEIRED AMO', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GTNF_COMMUNRL', 'Commission on LC Issue ( TEIRED AMO', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMM1AQR', 'Commission on LC Amendment ( TIERED', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMM1EXP', 'Commission on LC Amendment ( TIERED', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMM1INC', 'Commission on LC Amendment ( TIERED', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMM1PAY', 'Commission on LC Amendment ( TIERED', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMM1PIA', 'Commission on LC Amendment ( TIERED', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMM1REC', 'Commission on LC Amendment ( TIERED', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMM1RIA', 'Commission on LC Amendment ( TIERED', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMM1UNRL', 'Commission on LC Amendment ( TIERED', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMMAQR', 'Commission on LC Issue ( TIERED AMO', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMMEXP', 'Commission on LC Issue ( TIERED AMO', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMMINC', 'Commission on LC Issue ( TIERED AMO', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMMPAY', 'Commission on LC Issue ( TIERED AMO', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMMPIA', 'Commission on LC Issue ( TIERED AMO', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMMREC', 'Commission on LC Issue ( TIERED AMO', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMMRIA', 'Commission on LC Issue ( TIERED AMO', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELIR_COMMUNRL', 'Commission on LC Issue ( TIERED AMO', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMM1AQR', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMM1EXP', 'Commission on LC Amendment ( SLAB A', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMM1INC', 'Commission on LC Amendment ( SLAB A', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMM1PAY', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMM1PIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMM1REC', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMM1RIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMM1UNRL', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMMAQR', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMMEXP', 'Commission on LC Issue ( SLAB AMOUN', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMMINC', 'Commission on LC Issue ( SLAB AMOUN', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMMPAY', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMMPIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMMREC', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMMRIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRE_COMMUNRL', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMM1AQR', 'Commiss on LC Amendment - sl am/tn', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMM1EXP', 'Commiss on LC Amendment - sl am/tn', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMM1INC', 'Commiss on LC Amendment - sl am/tn', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMM1PAY', 'Commiss on LC Amendment - sl am/tn', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMM1PIA', 'Commiss on LC Amendment - sl am/tn', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMM1REC', 'Commiss on LC Amendment - sl am/tn', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMM1RIA', 'Commiss on LC Amendment - sl am/tn', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMM1UNRL', 'Commiss on LC Amendment - sl am/tn', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMMAQR', 'Commission on LC Issue (Slab amt/t', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMMEXP', 'Commission on LC Issue (Slab amt/t', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMMINC', 'Commission on LC Issue (Slab amt/t', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMMPAY', 'Commission on LC Issue (Slab amt/t', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMMPIA', 'Commission on LC Issue (Slab amt/t', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMMREC', 'Commission on LC Issue (Slab amt/t', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMMRIA', 'Commission on LC Issue (Slab amt/t', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRN_COMMUNRL', 'Commission on LC Issue (Slab amt/t', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMM1AQR', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMM1EXP', 'Commission on LC Amendment ( SLAB A', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMM1INC', 'Commission on LC Amendment ( SLAB A', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMM1PAY', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMM1PIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMM1REC', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMM1RIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMM1UNRL', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMMAQR', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMMEXP', 'Commission on LC Issue ( SLAB AMOUN', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMMINC', 'Commission on LC Issue ( SLAB AMOUN', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMMPAY', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMMPIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMMREC', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMMRIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ELRR_COMMUNRL', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1AQP', 'EL_BC1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1AQR', 'EL_BC1', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1DOV', 'EL_BC1', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1EXP', 'EL_BC1', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1IINPL', 'EL_BC1', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1INC', 'EL_BC1', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1PAY', 'EL_BC1', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1PIA', 'EL_BC1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1PPD', 'EL_BC1', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1REC', 'EL_BC1', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1RENPL', 'EL_BC1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC1RIA', 'EL_BC1', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2AQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2AQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2DOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2EXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2IINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2INC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2PAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2PIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2PPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2REC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2RENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BC2RIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCAQP', 'el_bc', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCAQR', 'el_bc', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCDOV', 'el_bc', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCEXP', 'el_bc', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCIINPL', 'el_bc', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCINC', 'el_bc', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCPAY', 'el_bc', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCPIA', 'el_bc', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCPPD', 'el_bc', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCREC', 'el_bc', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCRENPL', 'el_bc', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EL_BCRIA', 'el_bc', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORFAITING_NOSTRO', 'Forfaiting House Nostro', 'X', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIAQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIAQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIDOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIEXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIIINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIINC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINAQP', 'FORFAITING INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINAQR', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINDOV', 'FORFAITING INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINEXP', 'FORFAITING INT FOR DIS TO FOR', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINIINPL', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTININC', 'FORFAITING INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINPAY', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINPIA', 'FORFAITING INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINPPD', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINREC', 'FORFAITING INT FOR DIS TO FOR', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINRENPL', 'FORFAITING INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTINRIA', 'FORFAITING INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIPAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIPIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIPPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIREC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIRENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('FORTIRIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EB COLLECTIONS', 'Outgoing Bills Under Collection', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENAQR', 'penal interest on negotiation', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENEXP', 'penal interest on negotiation', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENIISNPL', 'penal interest on negotiation', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENINC', 'penal interest on negotiation', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENPAY', 'penal interest on negotiation', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENPIA', 'penal interest on negotiation', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENPPD', 'penal interest on negotiation', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENREC', 'penal interest on negotiation', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENRECNPL', 'penal interest on negotiation', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENRIA', 'penal interest on negotiation', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCNEGPENUNRL', 'penal interest on negotiation', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INAQR', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INEXP', 'Discount Interest collected upfront', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INIISNPL', 'Discount Interest collected upfront', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_ININC', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INPAY', 'Discount Interest collected upfront', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INPIA', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INREC', 'Discount Interest collected upfront', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INRECNPL', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INRIA', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_DIS_INUNRL', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INAQR', 'Negotiation int on export bills', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INEXP', 'Negotiation int on export bills', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INIISNPL', 'Negotiation int on export bills', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_ININC', 'Negotiation int on export bills', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INPAY', 'Negotiation int on export bills', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INPIA', 'Negotiation int on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INPPD', 'Negotiation int on export bills', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INREC', 'Negotiation int on export bills', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INRECNPL', 'Negotiation int on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INRIA', 'Negotiation int on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_NEG_INUNRL', 'Negotiation int on export bills', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INAQR', 'Purchase Interest on export bills', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INEXP', 'Purchase Interest on export bills', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INIISNPL', 'Purchase Interest on export bills', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_ININC', 'Purchase Interest on export bills', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INPAY', 'Purchase Interest on export bills', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INPIA', 'Purchase Interest on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INREC', 'Purchase Interest on export bills', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INRECNPL', 'Purchase Interest on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INRIA', 'Purchase Interest on export bills', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBC_PUR_INUNRL', 'Purchase Interest on export bills', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMDISCINC', 'Effc Int Based Disc Accrued Till Dt', 'I', 'BC', 'Y', 'N', 'N');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EIMDISCRIA', 'Effec Int Discount to be Accrued', 'L', 'BC', 'Y', 'N', 'N');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1PIA', 'INTBADV1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1PPD', 'INTBADV1', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1REC', 'INTBADV1', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1RECNPL', 'INTBADV1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1RIA', 'INTBADV1', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1UNRL', 'INTBADV1', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01AQR', 'INTBDIS01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01EXP', 'INTBDIS01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01IISNPL', 'INTBDIS01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01INC', 'INTBDIS01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01PAY', 'INTBDIS01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01PIA', 'INTBDIS01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01REC', 'INTBDIS01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01RECNPL', 'INTBDIS01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01RIA', 'INTBDIS01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBDIS01UNRL', 'INTBDIS01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1AQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1AQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1DOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1EXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1IINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1INC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1PAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1PIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1PPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1REC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1RENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBPUR1RIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTERESTREF', 'Interest Refund', 'A', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1AQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1AQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1DOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1EXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1IINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1INC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1PAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1PIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1PPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1REC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1RENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTFCJ1RIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01AQR', 'INT_BPUR01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01EXP', 'INT_BPUR01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01IISNPL', 'INT_BPUR01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01INC', 'INT_BPUR01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01PAY', 'INT_BPUR01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01PIA', 'INT_BPUR01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01PPD', 'INT_BPUR01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01REC', 'INT_BPUR01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01RECNPL', 'INT_BPUR01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01RIA', 'INT_BPUR01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT_BPUR01UNRL', 'INT_BPUR01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IB COLLECTIONS', 'Incoming Bills Under Collection', 'C', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INAQR', 'Interest on advance', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INEXP', 'Interest on advance', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INIISNPL', 'Interest on advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_ININC', 'Interest on advance', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INPAY', 'Interest on advance', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INPIA', 'Interest on advance', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INREC', 'Interest on advance', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INRECNPL', 'Interest on advance', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INRIA', 'Interest on advance', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_ADV_INUNRL', 'Interest on advance', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INAQR', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INEXP', 'Discount Interest collected upfront', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INIISNPL', 'Discount Interest collected upfront', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_ININC', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INPAY', 'Discount Interest collected upfront', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INPIA', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INREC', 'Discount Interest collected upfront', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INRECNPL', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INRIA', 'Discount Interest collected upfront', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBC_DIS_INUNRL', 'Discount Interest collected upfront', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1AQR', 'commission on LC amendment(2%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1EXP', 'commission on LC amendment(2%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1INC', 'commission on LC amendment(2%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1PAY', 'commission on LC amendment(2%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1PIA', 'commission on LC amendment(2%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1PPD', 'commission on LC amendment(2%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1REC', 'commission on LC amendment(2%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1RIA', 'commission on LC amendment(2%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMF1UNRL', 'commission on LC amendment(2%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFAQR', 'Commisson on LC Issue(2%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFEXP', 'Commisson on LC Issue(2%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFINC', 'Commisson on LC Issue(2%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFPAY', 'Commisson on LC Issue(2%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFPIA', 'Commisson on LC Issue(2%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFPPD', 'Commisson on LC Issue(2%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFREC', 'Commisson on LC Issue(2%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFRIA', 'Commisson on LC Issue(2%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMFUNRL', 'Commisson on LC Issue(2%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1AQR', 'commission on LC amendment(slab amt', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1EXP', 'commission on LC amendment(slab amt', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1INC', 'commission on LC amendment(slab amt', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1PAY', 'commission on LC amendment(slab amt', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1PIA', 'commission on LC amendment(slab amt', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1PPD', 'commission on LC amendment(slab amt', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1REC', 'commission on LC amendment(slab amt', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1RIA', 'commission on LC amendment(slab amt', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMS1UNRL', 'commission on LC amendment(slab amt', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSAQR', 'commission on LC issue (slab amt)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSEXP', 'commission on LC issue (slab amt)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSINC', 'commission on LC issue (slab amt)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSPAY', 'commission on LC issue (slab amt)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSPIA', 'commission on LC issue (slab amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSPPD', 'commission on LC issue (slab amt)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSREC', 'commission on LC issue (slab amt)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSRIA', 'commission on LC issue (slab amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILCI_COMSUNRL', 'commission on LC issue (slab amt)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMM1AQR', 'Commission on LC Amendment (1.5%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMM1EXP', 'Commission on LC Amendment (1.5%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMM1INC', 'Commission on LC Amendment (1.5%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMM1PAY', 'Commission on LC Amendment (1.5%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMM1PIA', 'Commission on LC Amendment (1.5%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMM1REC', 'Commission on LC Amendment (1.5%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMM1RIA', 'Commission on LC Amendment (1.5%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMM1UNRL', 'Commission on LC Amendment (1.5%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMMAQR', 'Commission on LC Issue (1.5%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMMEXP', 'Commission on LC Issue (1.5%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMMINC', 'Commission on LC Issue (1.5%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMMPAY', 'Commission on LC Issue (1.5%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMMPIA', 'Commission on LC Issue (1.5%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMMREC', 'Commission on LC Issue (1.5%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMMRIA', 'Commission on LC Issue (1.5%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIN_COMMUNRL', 'Commission on LC Issue (1.5%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMM1AQR', 'commission on amendment(slab amt)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMM1EXP', 'commission on amendment(slab amt)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMM1INC', 'commission on amendment(slab amt)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMM1PAY', 'commission on amendment(slab amt)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMM1PIA', 'commission on amendment(slab amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMM1REC', 'commission on amendment(slab amt)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMM1RIA', 'commission on amendment(slab amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMM1UNRL', 'commission on amendment(slab amt)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMMAQR', 'commission on lc issue(slam amt)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMMEXP', 'commission on lc issue(slam amt)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMMINC', 'commission on lc issue(slam amt)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMMPAY', 'commission on lc issue(slam amt)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMMPIA', 'commission on lc issue(slam amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMMREC', 'commission on lc issue(slam amt)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMMRIA', 'commission on lc issue(slam amt)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILIR_COMMUNRL', 'commission on lc issue(slam amt)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMM1AQR', 'Commission on LC Amendment (2.50%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMM1EXP', 'Commission on LC Amendment (2.50%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMM1INC', 'Commission on LC Amendment (2.50%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMM1PAY', 'Commission on LC Amendment (2.50%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMM1PIA', 'Commission on LC Amendment (2.50%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMM1REC', 'Commission on LC Amendment (2.50%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMM1RIA', 'Commission on LC Amendment (2.50%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMM1UNRL', 'Commission on LC Amendment (2.50%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMMAQR', 'Commission on LC Issue (2.50%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMMEXP', 'Commission on LC Issue (2.50%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMMINC', 'Commission on LC Issue (2.50%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMMPAY', 'Commission on LC Issue (2.50%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMMPIA', 'Commission on LC Issue (2.50%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMMREC', 'Commission on LC Issue (2.50%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMMRIA', 'Commission on LC Issue (2.50%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRE_COMMUNRL', 'Commission on LC Issue (2.50%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMM1AQR', 'Commission on LC Amendment (1.5%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMM1EXP', 'Commission on LC Amendment (1.5%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMM1INC', 'Commission on LC Amendment (1.5%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMM1PAY', 'Commission on LC Amendment (1.5%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMM1PIA', 'Commission on LC Amendment (1.5%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMM1REC', 'Commission on LC Amendment (1.5%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMM1RIA', 'Commission on LC Amendment (1.5%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMM1UNRL', 'Commission on LC Amendment (1.5%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMAQR', 'Commission on LC Issue (1.5%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMEXP', 'Commission on LC Issue (1.5%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMINC', 'Commission on LC Issue (1.5%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMPAY', 'Commission on LC Issue (1.5%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMPIA', 'Commission on LC Issue (1.5%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMPPD', 'Commision on LC issue(1.5%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMREC', 'Commission on LC Issue (1.5%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMRIA', 'Commission on LC Issue (1.5%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRN_COMMUNRL', 'Commission on LC Issue (1.5%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMM1AQR', 'Commission on LC Amendment (2.00%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMM1EXP', 'Commission on LC Amendment (2.00%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMM1INC', 'Commission on LC Amendment (2.00%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMM1PAY', 'Commission on LC Amendment (2.00%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMM1PIA', 'Commission on LC Amendment (2.00%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMM1REC', 'Commission on LC Amendment (2.00%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMM1RIA', 'Commission on LC Amendment (2.00%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMM1UNRL', 'Commission on LC Amendment (2.00%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMAQR', 'Commission on LC Issue (2.00%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMEXP', 'Commission on LC Issue (2.00%)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMINC', 'Commission on LC Issue (2.00%)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMPAY', 'Commission on LC Issue (2.00%)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMPIA', 'Commission on LC Issue (2.00%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMPPD', 'Commission on LC Issue (2.00%)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMREC', 'Commission on LC Issue (2.00%)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMRIA', 'Commission on LC Issue (2.00%)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ILRR_COMMUNRL', 'Commission on LC Issue (2.00%)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01AQR', 'INT01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01EXP', 'INT01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01IISNPL', 'INT01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01INC', 'INT01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01PAY', 'INT01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01PIA', 'INT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01REC', 'INT01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01RECNPL', 'INT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01RIA', 'INT01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT01UNRL', 'INT01', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02AQR', 'INT02', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02EXP', 'INT02', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02IISNPL', 'INT02', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02INC', 'INT02', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02PAY', 'INT02', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02PIA', 'INT02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02REC', 'INT02', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02RECNPL', 'INT02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02RIA', 'INT02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT02UNRL', 'INT02', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786AQR', 'INT786', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786EXP', 'INT786', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786IISNPL', 'INT786', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786INC', 'INT786', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786PAY', 'INT786', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786PIA', 'INT786', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786PPD', 'INT786', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786REC', 'INT786', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786RECNPL', 'INT786', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786RIA', 'INT786', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INT786UNRL', 'INT786', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1AQR', 'INTBADV1', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1EXP', 'INTBADV1', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1IISNPL', 'INTBADV1', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1INC', 'INTBADV1', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('INTBADV1PAY', 'INTBADV1', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2AQP', 'MAIN INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2AQR', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2DOV', 'MAIN INT FOR DIS TO FOR CASE 2', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2EXP', 'MAIN INT FOR DIS TO FOR CASE 2', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2IINPL', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2INC', 'MAIN INT FOR DIS TO FOR CASE 2', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2PAY', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2PIA', 'MAIN INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2PPD', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2REC', 'MAIN INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2RENPL', 'MAIN INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININT2RIA', 'MAIN INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTAQP', 'MAIN INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTAQR', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTDOV', 'MAIN INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTEXP', 'MAIN INT FOR DIS TO FOR', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTIINPL', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTINC', 'MAIN INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTPAY', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTPIA', 'MAIN INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTPPD', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTREC', 'MAIN INT FOR DIS TO FOR', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTRENPL', 'MAIN INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MAININTRIA', 'MAIN INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_EXP', 'tax expense role for KKL', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_EXP', 'tax expense role for KKL', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_PAD', 'tax paid in adv role for KKL', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_PAD', 'tax paid in adv role for KKL', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_PAY', 'tax payable role for KKL', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('KKL_PAY', 'tax payable role for KKL', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1AQR', 'LC COMM1', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1EXP', 'LC COMM1', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1INC', 'LC COMM1', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1PAY', 'LC COMM1', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1PIA', 'LC COMM1', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1PPD', 'LC COMM1', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1REC', 'LC COMM1', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1RIA', 'LC COMM1', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC1UNRL', 'LC COMM1', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCOLL_INT_ACCT', 'LC Collateral Internal account', 'L', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX1_EXP', 'tax expence role forLCTAX1', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX1_PAD', 'tax paid in adv role forLCTAX1', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX1_PAY', 'tax payable role forLCTAX1', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX2_EXP', 'tax expence role forLCTAX2', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX2_PAD', 'tax paid in adv role forLCTAX2', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX2_PAY', 'tax payable role forLCTAX2', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX_EXP', 'tax expence role forLCTAX', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX_PAD', 'tax paid in adv role forLCTAX', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTAX_PAY', 'tax payable role forLCTAX', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTBAD_EXP', 'tax expence role forLCTBAD', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTBAD_PAD', 'tax paid in adv role forLCTBAD', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCTBAD_PAY', 'tax payable role forLCTBAD', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_CNF', 'Confirmation of LC', 'C', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_CNF_OFF', 'Confirmation of LC Offset', 'C', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_COLCONTOF', 'Coll collected LC cont offset', 'C', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_COLL_BRIDGE', 'LC Collat Bridge GL', 'L', 'BC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_COLL_BRIDGE', 'LC Collat Bridge GL', 'L', 'LC', 'Y', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_COLL_CONT', 'Coll collected LC contingent', 'C', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_OCU', 'Outstanding Credit Unutilised', 'D', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_OCU_OFFSET', 'Unutilised Credit Offset', 'C', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_REM_NU', 'Reimbursement Non Undertaking of LC', 'C', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_REM_NU_OFF', 'Reimbursement Non Undertaking of LC Offset', 'C', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATAQR', 'SSS', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATEXP', 'SSS', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATINC', 'SSS', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATPAY', 'SSS', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATPIA', 'SSS', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATPPD', 'SSS', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATREC', 'SSS', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATRIA', 'SSS', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LC_SATUNRL', 'SSS', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMM1AQR', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMM1EXP', 'Commission on LC Amendment ( SLAB A', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMM1INC', 'Commission on LC Amendment ( SLAB A', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMM1PAY', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMM1PIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMM1REC', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMM1RIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMM1UNRL', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMMAQR', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMMEXP', 'Commission on LC Issue ( SLAB AMOUN', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMMINC', 'Commission on LC Issue ( SLAB AMOUN', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMMPAY', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMMPIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMMREC', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMMRIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SBLC_COMMUNRL', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_EXP', 'tax expense role for MM_TAX', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_EXP', 'tax expense role for MM_TAX', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_PAD', 'tax paid in adv role for MM_TAX', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_PAD', 'tax paid in adv role for MM_TAX', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_PAY', 'tax payable role for MM_TAX', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('MM_TAX_PAY', 'tax payable role for MM_TAX', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('NOSTRO ACCOUNT', 'Our Correspondent`s Nostro Account', 'X', 'BC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PROVNEXP', 'Provisioning expense', 'E', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PROVNLIAB', 'Provisioning Liablilty', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PURCH INTIISNPL', 'purchase interest', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PURCH INTRECNPL', 'purchase interest', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('PURCH INTUNRL', 'purchase interest', 'I', 'BC', 'Y', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIAQP', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIAQR', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIDOV', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIEXP', null, 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIIINPL', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIINC', null, 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINAQP', 'REBT INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINAQR', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINDOV', 'REBT INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINEXP', 'REBT INT FOR DIS TO FOR', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINIINPL', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTININC', 'REBT INT FOR DIS TO FOR', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINPAY', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINPIA', 'REBT INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINPPD', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINREC', 'REBT INT FOR DIS TO FOR', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINRENPL', 'REBT INT FOR DIS TO FOR', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTINRIA', 'REBT INT FOR DIS TO FOR', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIPAY', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIPIA', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIPPD', null, 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIREC', null, 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIRENPL', null, 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('REBTIRIA', null, 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1AQR', 'LC COMMISSION1', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1EXP', 'LC COMMISSION1', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1INC', 'LC COMMISSION1', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1PAY', 'LC COMMISSION1', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1PIA', 'LC COMMISSION1', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1PPD', 'LC COMMISSION1', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1REC', 'LC COMMISSION1', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1RIA', 'LC COMMISSION1', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOM1UNRL', 'LC COMMISSION1', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2AQR', 'LC COMM2', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2EXP', 'LC COMM2', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2INC', 'LC COMM2', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2PAY', 'LC COMM2', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2PIA', 'LC COMM2', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2PPD', 'LC COMM2', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2REC', 'LC COMM2', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2RIA', 'LC COMM2', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RLCCOMM2UNRL', 'LC COMM2', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ROLL_BRIDGE_GL', 'Bridge GL for BC Rollover', 'A', 'BC', 'Y', 'N', 'N');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_EXP', 'tax expense role for RTEST1', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_EXP', 'tax expense role for RTEST1', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_PAD', 'tax paid in adv role for RTEST1', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_PAD', 'tax paid in adv role for RTEST1', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_PAY', 'tax payable role for RTEST1', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST1_PAY', 'tax payable role for RTEST1', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_EXP', 'tax expense role for RTEST2', 'E', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_EXP', 'tax expense role for RTEST2', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_PAD', 'tax paid in adv role for RTEST2', 'A', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_PAD', 'tax paid in adv role for RTEST2', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_PAY', 'tax payable role for RTEST2', 'L', 'BC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('RTEST2_PAY', 'tax payable role for RTEST2', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01AQP', 'VINCLBC01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01AQR', 'VINCLBC01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01DOV', 'VINCLBC01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01EXP', 'VINCLBC01', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01IINPL', 'VINCLBC01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01INC', 'VINCLBC01', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01PAY', 'VINCLBC01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01PIA', 'VINCLBC01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01PPD', 'VINCLBC01', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01REC', 'VINCLBC01', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01RENPL', 'VINCLBC01', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC01RIA', 'VINCLBC01', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02AQP', 'VINCLBC02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02AQR', 'VINCLBC02', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02DOV', 'VINCLBC02', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02EXP', 'VINCLBC02', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02IINPL', 'VINCLBC02', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02INC', 'VINCLBC02', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02PAY', 'VINCLBC02', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02PIA', 'VINCLBC02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02PPD', 'VINCLBC02', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02REC', 'VINCLBC02', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02RENPL', 'VINCLBC02', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('VINCLBC02RIA', 'VINCLBC02', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2EXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMM1AQR', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMM1EXP', 'Commission on LC Amendment ( SLAB A', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMM1INC', 'Commission on LC Amendment ( SLAB A', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMM1PAY', 'Commission on LC Amendment ( SLAB A', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMM1PIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMM1REC', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMM1RIA', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMM1UNRL', 'Commission on LC Amendment ( SLAB A', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMMAQR', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMMEXP', 'Commission on LC Issue ( SLAB AMOUN', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMMINC', 'Commission on LC Issue ( SLAB AMOUN', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMMPAY', 'Commission on LC Issue ( SLAB AMOUN', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMMPIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMMREC', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMMRIA', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('SGTE_COMMUNRL', 'Commission on LC Issue ( SLAB AMOUN', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TAX_CUST_ACC', 'Customer Accounts', 'X', 'LC', 'N', 'N', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST51_EXP', 'tax expense role for TEST51', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST51_PAD', 'tax paid in adv role for TEST51', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST51_PAY', 'tax payable role for TEST51', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST52_EXP', 'tax expense role for TEST52', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST52_PAD', 'tax paid in adv role for TEST52', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST52_PAY', 'tax payable role for TEST52', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST53_EXP', 'tax expense role for TEST53', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST53_PAD', 'tax paid in adv role for TEST53', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST53_PAY', 'tax payable role for TEST53', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST54_EXP', 'tax expense role for TEST54', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST54_PAD', 'tax paid in adv role for TEST54', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST54_PAY', 'tax payable role for TEST54', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST56_EXP', 'tax expense role for TEST56', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST56_PAD', 'tax paid in adv role for TEST56', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST56_PAY', 'tax payable role for TEST56', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST57_EXP', 'tax expense role for TEST57', 'E', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST57_PAD', 'tax paid in adv role for TEST57', 'A', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST57_PAY', 'tax payable role for TEST57', 'L', 'LC', null, null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTAQP', 'TRANS INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTAQR', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTDOV', 'TRANS INT FOR DIS TO FOR CASE 2', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTEXP', 'TRANS INT FOR DIS TO FOR CASE 2', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTIINPL', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTINC', 'TRANS INT FOR DIS TO FOR CASE 2', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTPAY', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTPIA', 'TRANS INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTPPD', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTREC', 'TRANS INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTRENPL', 'TRANS INT FOR DIS TO FOR CASE 2', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TRANSINTRIA', 'TRANS INT FOR DIS TO FOR CASE 2', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('UCHG', 'CHARGES', 'I', 'LC', 'N', 'Y', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('UCUST', 'CUSTOMER', 'X', 'LC', 'N', 'Y', null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10INC', 'Commission For Others', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10EXP', 'Commission For Others', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10PAY', 'Commission For Others', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10REC', 'Commission For Others', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10RECV', 'Commission For Others', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10RIA', 'Commission For Others', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10PIA', 'Commission For Others', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10AQR', 'Commission For Others', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10PPD', 'Commission For Others', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10UNRL', 'Commission For Others', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10INC', 'Commission For Others', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10EXP', 'Commission For Others', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10PAY', 'Commission For Others', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10REC', 'Commission For Others', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_GUBB_COM10RECV', 'Commission For Others', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10RECV', 'Commission For Others', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10RIA', 'Commission For Others', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10PIA', 'Commission For Others', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10AQR', 'Commission For Others', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10PPD', 'Commission For Others', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10UNRL', 'Commission For Others', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('GUBB_COM10NORMINC', 'Commission For Others', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCICABBISS_INC', 'LC Export Courier Charges Advice and Confirm', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCICABBISS_IFBR', 'LC Export Courier Charges Advice and Confirm', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCICABBISS_RIA', 'LC Export Courier Charges Advice and Confirm', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIDAMAMND_INC', 'Import LC Decrease Amount Amendment Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIDAMAMND_IFBR', 'Import LC Decrease Amount Amendment Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIDAMAMND_RIA', 'Import LC Decrease Amount Amendment Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIDEXAMND_INC', 'Import LC Decrease Expiry Date Amendment Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIDEXAMND_IFBR', 'Import LC Decrease Expiry Date Amendment Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIDEXAMND_RIA', 'Import LC Decrease Expiry Date Amendment Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDRIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDPIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDAQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDPPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDUNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDINC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDEXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDPAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDREC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_LCIIACAMNDRECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDRECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDRIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDPIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDAQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDPPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDUNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDNORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDEXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDPAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDREC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDRECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDRIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDPIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDAQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDEXDT_INC', null, 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDEXDT_IFBR', null, 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDEXDT_RIA', null, 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDPPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDUNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDINC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDEXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDPAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDREC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_LCIIEXAMNDRECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDRECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDRIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDPIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDAQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDPPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDUNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIEXAMNDNORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDEXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDPAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDREC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDRECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDRIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDPIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDAQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDPPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDUNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDINC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDEXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDPAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDREC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_LCIIECAMNDRECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDRECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDRIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDPIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDAQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDPPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDUNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIECAMNDNORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUAP_COM2RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUPP_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUPP_COM2RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1INC', 'LC Issuance Commission (Sight)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1EXP', 'LC Issuance Commission (Sight)', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PAY', 'LC Issuance Commission (Sight)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1REC', 'LC Issuance Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AILSN_COM1RECV', 'LC Issuance Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1RECV', 'LC Issuance Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1RIA', 'LC Issuance Commission (Sight)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PIA', 'LC Issuance Commission (Sight)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1AQR', 'LC Issuance Commission (Sight)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PPD', 'LC Issuance Commission (Sight)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1UNRL', 'LC Issuance Commission (Sight)', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1INC', 'LC Issuance Commission (Usance)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1EXP', 'LC Issuance Commission (Usance)', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNEXDTD_INC', 'Amendment of LC Expiry Date -  Decrease', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNEXDTD_IFBR', 'Amendment of LC Expiry Date -  Decrease', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNEXDTD_RIA', 'Amendment of LC Expiry Date -  Decrease', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDAMTD_INC', 'Amendment of LC Amount - Decrease', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDAMTD_IFBR', 'Amendment of LC Amount - Decrease', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDAMTD_RIA', 'Amendment of LC Amount - Decrease', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PAY', 'LC Issuance Commission (Usance)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1REC', 'LC Issuance Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AILUN_COM1RECV', 'LC Issuance Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1RECV', 'LC Issuance Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1RIA', 'LC Issuance Commission (Usance)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PIA', 'LC Issuance Commission (Usance)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1AQR', 'LC Issuance Commission (Usance)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PPD', 'LC Issuance Commission (Usance)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1UNRL', 'LC Issuance Commission (Usance)', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2INC', 'LC Amendment Commission (Sight)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2EXP', 'LC Amendment Commission (Sight)', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PAY', 'LC Amendment Commission (Sight)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2REC', 'LC Amendment Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AILSN_COM2RECV', 'LC Amendment Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2RECV', 'LC Amendment Commission (Sight)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2RIA', 'LC Amendment Commission (Sight)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PIA', 'LC Amendment Commission (Sight)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2AQR', 'LC Amendment Commission (Sight)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PPD', 'LC Amendment Commission (Sight)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2UNRL', 'LC Amendment Commission (Sight)', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2INC', 'LC Amendment Commission (Usance)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2EXP', 'LC Amendment Commission (Usance)', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PAY', 'LC Amendment Commission (Usance)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2REC', 'LC Amendment Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AILUN_COM2RECV', 'LC Amendment Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2RECV', 'LC Amendment Commission (Usance)', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2RIA', 'LC Amendment Commission (Usance)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PIA', 'LC Amendment Commission (Usance)', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2AQR', 'LC Amendment Commission (Usance)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PPD', 'LC Amendment Commission (Usance)', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2UNRL', 'LC Amendment Commission (Usance)', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_ININC', 'Discount Interest Under LC Income', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INEXP', 'Discount Interest Under LC Expense', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INPAY', 'Discount Interest Under LC Payable', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INREC', 'Discount Interest Under LC Receivable', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INRIA', 'Discount Interest Under LC Received in advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INPIA', 'Discount Interest Under LC', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INAQR', 'Discount Interest Under LC Acquired interest receivable', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INAQP', 'Discount Interest Under LC Acquired interest payable', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INRENPL', 'Discount Interest Under LC', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INIINPL', 'Discount Interest Under LC', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INPPD', 'Discount Interest Under LC Prepaid Interest', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INDOV', 'Discount Interest Under LC', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCLDIS_INNORMINC', 'Discount Interest Under LC', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCOPNCG_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCOPNCG_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCOPNCG_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCOPNCG_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCOUR_REC', 'BC Courier Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCOUR_INC', 'BC Courier Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCOUR_IFBR', 'BC Courier Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCOUR_RIA', 'BC Courier Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCSWIFT_REC', 'BC Swift Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCSWIFT_INC', 'BC Swift Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCSWIFT_IFBR', 'BC Swift Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCSWIFT_RIA', 'BC Swift Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCLIQCG_REC', 'BC Liquidation Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCLIQCG_INC', 'BC Liquidation Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCLIQCG_IFBR', 'BC Liquidation Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCLIQCG_RIA', 'BC Liquidation Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCLCG_REC', 'BC Closure Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCLCG_INC', 'BC Closure Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCLCG_IFBR', 'BC Closure Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCLCG_RIA', 'BC Closure Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUAP_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1INC', 'BG Issuance/Re-Issuance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1EXP', 'BG Issuance/Re-Issuance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PAY', 'BG Issuance/Re-Issuance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1REC', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUIR_COM1RECV', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1RECV', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1RIA', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PIA', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1AQR', 'BG Issuance/Re-Issuance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PPD', 'BG Issuance/Re-Issuance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1UNRL', 'BG Issuance/Re-Issuance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2EXP', 'BG Issuance/Re-Issuance Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PAY', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2REC', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUIR_COM2RECV', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2RECV', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2RIA', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PIA', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2AQR', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PPD', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2UNRL', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1INC', 'BG Standby Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1EXP', 'BG Standby Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PAY', 'BG Standby Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1REC', 'BG Standby Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_ASBLC_COM1RECV', 'BG Standby Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1RECV', 'BG Standby Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1RIA', 'BG Standby Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PIA', 'BG Standby Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1AQR', 'BG Standby Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PPD', 'BG Standby Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1UNRL', 'BG Standby Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2INC', 'BG Standby Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2EXP', 'BG Standby Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PAY', 'BG Standby Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2REC', 'BG Standby Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_ASBLC_COM2RECV', 'BG Standby Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2RECV', 'BG Standby Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2RIA', 'BG Standby Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PIA', 'BG Standby Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2AQR', 'BG Standby Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PPD', 'BG Standby Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2UNRL', 'BG Standby Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1INC', 'BG Shipping Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1EXP', 'BG Shipping Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PAY', 'BG Shipping Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1REC', 'BG Shipping Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_ASGLC_COM1RECV', 'BG Shipping Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1RECV', 'BG Shipping Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1RIA', 'BG Shipping Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PIA', 'BG Shipping Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1AQR', 'BG Shipping Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PPD', 'BG Shipping Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2INC', 'BG Issuance/Re-Issuance Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1UNRL', 'BG Shipping Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2INC', 'BG Shipping Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2EXP', 'BG Shipping Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PAY', 'BG Shipping Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2REC', 'BG Shipping Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_ASGLC_COM2RECV', 'BG Shipping Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2RECV', 'BG Shipping Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2RIA', 'BG Shipping Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PIA', 'BG Shipping Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2AQR', 'BG Shipping Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PPD', 'BG Shipping Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2UNRL', 'BG Shipping Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1INC', 'BG Counter Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1EXP', 'BG Counter Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PAY', 'BG Counter Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1REC', 'BG Counter Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUCG_COM1RECV', 'BG Counter Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1RECV', 'BG Counter Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1RIA', 'BG Counter Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PIA', 'BG Counter Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1AQR', 'BG Counter Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PPD', 'BG Counter Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1UNRL', 'BG Counter Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2INC', 'BG Counter Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2EXP', 'BG Counter Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2REC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2RECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2RIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2INC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2AQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2PPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2UNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM2NORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1INC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1EXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1REC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1RECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1RIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1AQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1PPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1UNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM1NORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2INC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2EXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2REC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2RECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2RIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2AQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2PPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2UNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPP_COM2NORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1INC', 'LC Issuance Commission (Sight)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1EXP', 'LC Issuance Commission (Sight)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PAY', 'LC Issuance Commission (Sight)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1REC', 'LC Issuance Commission (Sight)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1RECV', 'LC Issuance Commission (Sight)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1RIA', 'LC Issuance Commission (Sight)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PIA', 'LC Issuance Commission (Sight)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1AQR', 'LC Issuance Commission (Sight)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1PPD', 'LC Issuance Commission (Sight)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1UNRL', 'LC Issuance Commission (Sight)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM1NORMINC', 'LC Issuance Commission (Sight)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1INC', 'LC Issuance Commission (Usance)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1EXP', 'LC Issuance Commission (Usance)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PAY', 'LC Issuance Commission (Usance)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1REC', 'LC Issuance Commission (Usance)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1RECV', 'LC Issuance Commission (Usance)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1RIA', 'LC Issuance Commission (Usance)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PIA', 'LC Issuance Commission (Usance)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1AQR', 'LC Issuance Commission (Usance)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1PPD', 'LC Issuance Commission (Usance)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1UNRL', 'LC Issuance Commission (Usance)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM1NORMINC', 'LC Issuance Commission (Usance)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2INC', 'LC Amendment Commission (Sight)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2EXP', 'LC Amendment Commission (Sight)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PAY', 'LC Amendment Commission (Sight)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2REC', 'LC Amendment Commission (Sight)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2RECV', 'LC Amendment Commission (Sight)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2RIA', 'LC Amendment Commission (Sight)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PIA', 'LC Amendment Commission (Sight)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2AQR', 'LC Amendment Commission (Sight)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2PPD', 'LC Amendment Commission (Sight)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2UNRL', 'LC Amendment Commission (Sight)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILSN_COM2NORMINC', 'LC Amendment Commission (Sight)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2INC', 'LC Amendment Commission (Usance)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2EXP', 'LC Amendment Commission (Usance)', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PAY', 'LC Amendment Commission (Usance)', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2REC', 'LC Amendment Commission (Usance)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2RECV', 'LC Amendment Commission (Usance)', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2RIA', 'LC Amendment Commission (Usance)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PIA', 'LC Amendment Commission (Usance)', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2AQR', 'LC Amendment Commission (Usance)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2PPD', 'LC Amendment Commission (Usance)', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2UNRL', 'LC Amendment Commission (Usance)', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AILUN_COM2NORMINC', 'LC Amendment Commission (Usance)', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCSWIFTAMN_INC', 'LC SWIFT Charge for Amendment', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCSWIFTAMN_IFBR', 'LC SWIFT Charge for Amendment', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCSWIFTAMN_RIA', 'LC SWIFT Charge for Amendment', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSUANCE_INC', 'LC Issuance Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSUANCE_IFBR', 'LC Issuance Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSUANCE_RIA', 'LC Issuance Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCOURIER_INC', 'LC Courier Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCOURIER_IFBR', 'LC Courier Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCOURIER_RIA', 'LC Courier Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCSWIFTISS_INC', 'LC SWIFT Charge for Issuance', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCSWIFTISS_IFBR', 'LC SWIFT Charge for Issuance', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCSWIFTISS_RIA', 'LC SWIFT Charge for Issuance', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCDOCCHG_INC', 'LC Documentary Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCDOCCHG_IFBR', 'LC Documentary Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCDOCCHG_RIA', 'LC Documentary Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCANCHG_INC', 'LC Cancellation Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCANCHG_IFBR', 'LC Cancellation Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCANCHG_RIA', 'LC Cancellation Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCNFMCHG_INC', 'LC Export Confirming Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCNFMCHG_IFBR', 'LC Export Confirming Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCNFMCHG_RIA', 'LC Export Confirming Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVCHG_INC', 'LC Export Advicing charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVCHG_IFBR', 'LC Export Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVCHG_RIA', 'LC Export Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1EXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1REC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1RECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1RIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1AQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1PPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1UNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1NORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUAP_COM1INC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1INC', 'BG Issuance/Re-Issuance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1EXP', 'BG Issuance/Re-Issuance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PAY', 'BG Issuance/Re-Issuance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1REC', 'BG Issuance/Re-Issuance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1RECV', 'BG Issuance/Re-Issuance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1RIA', 'BG Issuance/Re-Issuance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PIA', 'BG Issuance/Re-Issuance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1AQR', 'BG Issuance/Re-Issuance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1PPD', 'BG Issuance/Re-Issuance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1UNRL', 'BG Issuance/Re-Issuance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM1NORMINC', 'BG Issuance/Re-Issuance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2INC', 'BG Issuance/Re-Issuance Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2EXP', 'BG Issuance/Re-Issuance Amendment Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PAY', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2REC', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2RECV', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2RIA', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PIA', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2PPD', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2UNRL', 'BG Issuance/Re-Issuance Amendment Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2NORMINC', 'BG Issuance/Re-Issuance Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1INC', 'BG Standby Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1EXP', 'BG Standby Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PAY', 'BG Standby Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1REC', 'BG Standby Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1RECV', 'BG Standby Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1RIA', 'BG Standby Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PIA', 'BG Standby Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1AQR', 'BG Standby Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1PPD', 'BG Standby Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1UNRL', 'BG Standby Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM1NORMINC', 'BG Standby Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2INC', 'BG Standby Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2EXP', 'BG Standby Amendment Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PAY', 'BG Standby Amendment Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2REC', 'BG Standby Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2RECV', 'BG Standby Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUIR_COM2AQR', 'BG Issuance/Re-Issuance Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2RIA', 'BG Standby Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PIA', 'BG Standby Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2AQR', 'BG Standby Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2PPD', 'BG Standby Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2UNRL', 'BG Standby Amendment Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASBLC_COM2NORMINC', 'BG Standby Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1INC', 'BG Shipping Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1EXP', 'BG Shipping Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PAY', 'BG Shipping Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1REC', 'BG Shipping Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1RECV', 'BG Shipping Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1RIA', 'BG Shipping Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PIA', 'BG Shipping Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1AQR', 'BG Shipping Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1PPD', 'BG Shipping Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1UNRL', 'BG Shipping Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM1NORMINC', 'BG Shipping Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2INC', 'BG Shipping Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2EXP', 'BG Shipping Amendment Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PAY', 'BG Shipping Amendment Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2REC', 'BG Shipping Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2RECV', 'BG Shipping Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2RIA', 'BG Shipping Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PIA', 'BG Shipping Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2AQR', 'BG Shipping Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2PPD', 'BG Shipping Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2UNRL', 'BG Shipping Amendment Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('ASGLC_COM2NORMINC', 'BG Shipping Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1INC', 'BG Counter Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1EXP', 'BG Counter Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PAY', 'BG Counter Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1REC', 'BG Counter Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1RECV', 'BG Counter Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1RIA', 'BG Counter Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PIA', 'BG Counter Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1AQR', 'BG Counter Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1PPD', 'BG Counter Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1UNRL', 'BG Counter Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM1NORMINC', 'BG Counter Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2INC', 'BG Counter Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2EXP', 'BG Counter Amendment Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PAY', 'BG Counter Amendment Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2REC', 'BG Counter Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2RECV', 'BG Counter Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2RIA', 'BG Counter Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PIA', 'BG Counter Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2AQR', 'BG Counter Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PPD', 'BG Counter Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2UNRL', 'BG Counter Amendment Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2NORMINC', 'BG Counter Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1INC', 'BG Bid Bond Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1EXP', 'BG Bid Bond Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PAY', 'BG Bid Bond Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1REC', 'BG Bid Bond Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1RECV', 'BG Bid Bond Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1RIA', 'BG Bid Bond Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PIA', 'BG Bid Bond Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1AQR', 'BG Bid Bond Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PPD', 'BG Bid Bond Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1UNRL', 'BG Bid Bond Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1NORMINC', 'BG Bid Bond Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2INC', 'BG Bid Bond Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2EXP', 'BG Bid Bond Amendment Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PAY', 'BG Bid Bond Amendment Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2REC', 'BG Bid Bond Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2RECV', 'BG Bid Bond Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2RIA', 'BG Bid Bond Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PIA', 'BG Bid Bond Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2AQR', 'BG Bid Bond Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PPD', 'BG Bid Bond Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2UNRL', 'BG Bid Bond Amendment Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2NORMINC', 'BG Bid Bond Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1INC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1EXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1REC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1RECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1RIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1AQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1UNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1NORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2INC', 'BG Performance Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2EXP', 'BG Performance Amendment Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PAY', 'BG Performance Amendment Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2REC', 'BG Performance Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2RECV', 'BG Performance Amendment Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2RIA', 'BG Performance Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PIA', 'BG Performance Amendment Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2AQR', 'BG Performance Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PPD', 'BG Performance Amendment Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2UNRL', 'BG Performance Amendment Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2NORMINC', 'BG Performance Amendment Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1INC', 'BG Payment/Money Retension Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1EXP', 'BG Payment/Money Retension Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PAY', 'BG Payment/Money Retension Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1REC', 'BG Payment/Money Retension Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1RECV', 'BG Payment/Money Retension Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1RIA', 'BG Payment/Money Retension Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PIA', 'BG Payment/Money Retension Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1AQR', 'BG Payment/Money Retension Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PPD', 'BG Payment/Money Retension Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1UNRL', 'BG Payment/Money Retension Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1NORMINC', 'BG Payment/Money Retension Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2INC', 'BG Payment/Money Retension Amendment  Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2EXP', 'BG Payment/Money Retension Amendment  Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PAY', 'BG Payment/Money Retension Amendment  Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2REC', 'BG Payment/Money Retension Amendment  Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2RECV', 'BG Payment/Money Retension Amendment  Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2RIA', 'BG Payment/Money Retension Amendment  Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PIA', 'BG Payment/Money Retension Amendment  Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2AQR', 'BG Payment/Money Retension Amendment  Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PPD', 'BG Payment/Money Retension Amendment  Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2UNRL', 'BG Payment/Money Retension Amendment  Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2NORMINC', 'BG Payment/Money Retension Amendment  Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGADVCHG_INC', 'BG Advicing charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGADVCHG_IFBR', 'BG Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGADVCHG_RIA', 'BG Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGSWIFTAMN_INC', 'BG SWIFT Charge for Amendment', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGSWIFTAMN_IFBR', 'BG SWIFT Charge for Amendment', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGSWIFTAMN_RIA', 'BG SWIFT Charge for Amendment', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCANCHG_INC', 'BG Cancellation Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCANCHG_IFBR', 'BG Cancellation Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCANCHG_RIA', 'BG Cancellation Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGSWIFTISS_INC', 'BG SWIFT Charge for Issuance', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGSWIFTISS_IFBR', 'BG SWIFT Charge for Issuance', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGSWIFTISS_RIA', 'BG SWIFT Charge for Issuance', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCOURIER_INC', 'BG Courier Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCOURIER_IFBR', 'BG Courier Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCOURIER_RIA', 'BG Courier Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMENDMEN_INC', 'LC Amendment Charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMENDMEN_IFBR', 'LC Amendment Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMENDMEN_RIA', 'LC Amendment Charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCLMCHG_INC', 'Guarantee Claim Charge', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCLMCHG_IFBR', 'Guarantee Claim Charge', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BGCLMCHG_RIA', 'Guarantee Claim Charge', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDEXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDPAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDREC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDRECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDUNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDNORMINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDINC', 'BG Performance Commission', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDEXP', 'BG Performance Commission', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDPAY', 'BG Performance Commission', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDREC', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDRIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDPIA', 'BG Performance Commission', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDAQR', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDPPD', 'BG Performance Commission', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDUNRL', 'BG Performance Commission', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDINC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDEXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDPAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDREC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_LCIIAMAMNDRECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDRECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDRIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDPIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDAQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIAMAMNDPPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCIIACAMNDRECV', 'BG Performance Commission', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCECORBANC_INC', 'LC Export Courier Charges Advice and Confirm', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCECORBANC_IFBR', 'LC Export Courier Charges Advice and Confirm', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCECORBANC_RIA', 'LC Export Courier Charges Advice and Confirm', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PAY', 'BG Counter Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2REC', 'BG Counter Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUCG_COM2RECV', 'BG Counter Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2RECV', 'BG Counter Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2RIA', 'BG Counter Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PIA', 'BG Counter Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2AQR', 'BG Counter Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2PPD', 'BG Counter Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUCG_COM2UNRL', 'BG Counter Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1INC', 'BG Bid Bond Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1EXP', 'BG Bid Bond Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PAY', 'BG Bid Bond Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1REC', 'BG Bid Bond Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUBB_COM1RECV', 'BG Bid Bond Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1RECV', 'BG Bid Bond Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1RIA', 'BG Bid Bond Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PIA', 'BG Bid Bond Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1AQR', 'BG Bid Bond Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1PPD', 'BG Bid Bond Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM1UNRL', 'BG Bid Bond Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2INC', 'BG Bid Bond Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2EXP', 'BG Bid Bond Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PAY', 'BG Bid Bond Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2REC', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUBB_COM2RECV', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2RECV', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2RIA', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PIA', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2AQR', 'BG Bid Bond Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2PPD', 'BG Bid Bond Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUBB_COM2UNRL', 'BG Bid Bond Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1INC', 'BG Performance Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1EXP', 'BG Performance Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PAY', 'BG Performance Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1REC', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUPG_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1RECV', 'BG Performance Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1RIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PIA', 'BG Performance Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1AQR', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1PPD', 'BG Performance Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM1UNRL', 'BG Performance Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2INC', 'BG Performance Amendment Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2EXP', 'BG Performance Amendment Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PAY', 'BG Performance Amendment Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2REC', 'BG Performance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGUPG_COM2RECV', 'BG Performance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2RECV', 'BG Performance Amendment Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2RIA', 'BG Performance Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PIA', 'BG Performance Amendment Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2AQR', 'BG Performance Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2PPD', 'BG Performance Amendment Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGUPG_COM2UNRL', 'BG Performance Amendment Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1INC', 'BG Payment/Money Retension Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1EXP', 'BG Payment/Money Retension Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PAY', 'BG Payment/Money Retension Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1REC', 'BG Payment/Money Retension Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGURG_COM1RECV', 'BG Payment/Money Retension Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1RECV', 'BG Payment/Money Retension Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1RIA', 'BG Payment/Money Retension Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PIA', 'BG Payment/Money Retension Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1AQR', 'BG Payment/Money Retension Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1PPD', 'BG Payment/Money Retension Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM1UNRL', 'BG Payment/Money Retension Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2INC', 'BG Payment/Money Retension Amendment  Commission', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2EXP', 'BG Payment/Money Retension Amendment  Commission', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PAY', 'BG Payment/Money Retension Amendment  Commission', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2REC', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_AGURG_COM2RECV', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2RECV', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2RIA', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PIA', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2AQR', 'BG Payment/Money Retension Amendment  Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2PPD', 'BG Payment/Money Retension Amendment  Commission', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('AGURG_COM2UNRL', 'BG Payment/Money Retension Amendment  Commission', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_ININC', 'Discount Interest Clean Income', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INEXP', 'Discount Interest Clean Expense', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INPAY', 'Discount Interest Clean Payable', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INREC', 'Discount Interest Clean Receivable', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INRIA', 'Discount Interest Clean Received in advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INPIA', 'Discount Interest Clean', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INAQR', 'Discount Interest Clean Acquired interest receivable', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INAQP', 'Discount Interest Clean Acquired interest payable', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INRENPL', 'Discount Interest Clean', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INIINPL', 'Discount Interest Clean', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INPPD', 'Discount Interest Clean Prepaid Interest', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INDOV', 'Discount Interest Clean', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('EBCCDIS_INNORMINC', 'Discount Interest Clean', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_ININC', 'Acceptance Interest Under LC Income', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INEXP', 'Acceptance Interest Under LC Expense', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INPAY', 'Acceptance Interest Under LC Payable', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INREC', 'Acceptance Interest Under LC Receivable', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INRIA', 'Acceptance Interest Under LC Received in advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INPIA', 'Acceptance Interest Under LC', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INAQR', 'Acceptance Interest Under LC Acquired interest receivable', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INAQP', 'Acceptance Interest Under LC Acquired interest payable', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INRENPL', 'Acceptance Interest Under LC', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INIINPL', 'Acceptance Interest Under LC', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INPPD', 'Acceptance Interest Under LC Prepaid Interest', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INDOV', 'Acceptance Interest Under LC', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCLACP_INNORMINC', 'Acceptance Interest Under LC', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_ININC', 'Acceptance Interest Clean Income', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INEXP', 'Acceptance Interest Clean Expense', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INPAY', 'Acceptance Interest Clean Payable', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INREC', 'Acceptance Interest Clean Receivable', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INRIA', 'Acceptance Interest Clean Received in advance', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INPIA', 'Acceptance Interest Clean', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INAQR', 'Acceptance Interest Clean Acquired interest receivable', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INAQP', 'Acceptance Interest Clean Acquired interest payable', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INRENPL', 'Acceptance Interest Clean', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INIINPL', 'Acceptance Interest Clean', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INPPD', 'Acceptance Interest Clean Prepaid Interest', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INDOV', 'Acceptance Interest Clean', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('IBCCACP_INNORMINC', 'Acceptance Interest Clean', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIREIINIT_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIREIINIT_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIREIINIT_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIREIINIT_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('OAMENDMENT_INC', 'Other LC Amendment', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('OAMENDMENT_IFBR', 'Other LC Amendment', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('OAMENDMENT_RIA', 'Other LC Amendment', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCDOCUMENT_REC', 'BC Document Examination Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCDOCUMENT_INC', 'BC Document Examination Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCDOCUMENT_IFBR', 'BC Document Examination Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCDOCUMENT_RIA', 'BC Document Examination Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCORCG_REC', 'BC Correspondent Charge', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCORCG_INC', 'BC Correspondent Charge', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCORCG_IFBR', 'BC Correspondent Charge', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCORCG_RIA', 'BC Correspondent Charge', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVAMND_INC', 'LC Export Advicing charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVAMND_IFBR', 'LC Export Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVAMND_RIA', 'LC Export Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST_REC', 'BC Courier Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST_INC', 'BC Courier Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST_IFBR', 'BC Courier Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('TEST_RIA', 'BC Courier Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCISETINIT_REC', 'Import BC Under LC Reimbursement Charges during INIT(Final)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCISETINIT_INC', 'Import BC Under LC Reimbursement Charges during INIT(Final)', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCISETINIT_IFBR', 'Import BC Under LC Reimbursement Charges during INIT(Final)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCISETINIT_RIA', 'Import BC Under LC Reimbursement Charges during INIT(Final)', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIACCBOOK_REC', 'BC IMPORT UNDER LC ACCEPTANCE CHARGE USSANCE DURIN', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIACCBOOK_INC', 'BC IMPORT UNDER LC ACCEPTANCE CHARGE USSANCE DURIN', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIACCBOOK_IFBR', 'BC IMPORT UNDER LC ACCEPTANCE CHARGE USSANCE DURIN', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIACCBOOK_RIA', 'BC IMPORT UNDER LC ACCEPTANCE CHARGE USSANCE DURIN', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIACCLIQD_REC', 'BC IMPORT ACCEPTANCE FEE CLASS', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIACCLIQD_INC', 'BC IMPORT ACCEPTANCE FEE CLASS', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIACCLIQD_IFBR', 'BC IMPORT ACCEPTANCE FEE CLASS', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIACCLIQD_RIA', 'BC IMPORT ACCEPTANCE FEE CLASS', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIDISLIQD_REC', 'BC IMPORT DISCPREPENCIES CHARGES', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIDISLIQD_INC', 'BC IMPORT DISCPREPENCIES CHARGES', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIDISLIQD_IFBR', 'BC IMPORT DISCPREPENCIES CHARGES', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIDISLIQD_RIA', 'BC IMPORT DISCPREPENCIES CHARGES', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCISETLIQD_REC', 'BC IMPORT SETTLEMENT Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCISETLIQD_INC', 'BC IMPORT SETTLEMENT Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCISETLIQD_IFBR', 'BC IMPORT SETTLEMENT Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCISETLIQD_RIA', 'BC IMPORT SETTLEMENT Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIREILIQD_REC', 'BC IMPORT REIMBURSEMENT Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIREILIQD_INC', 'BC IMPORT REIMBURSEMENT Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIREILIQD_IFBR', 'BC IMPORT REIMBURSEMENT Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCIREILIQD_RIA', 'BC IMPORT REIMBURSEMENT Charges', 'L', 'BC', 'Y', null, null);

COMMIT;
