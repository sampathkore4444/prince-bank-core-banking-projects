CREATE OR REPLACE PACKAGE BODY Lcpks_Lcdtronl_Utils IS

  G_CALLING_FUNCTION VARCHAR2(10);
  G_ACTION_CODE      VARCHAR2(20);

  REBCHANGED VARCHAR2(1) := 'N';
  ABKCHANGED VARCHAR2(1) := 'N';
  BENCHANGED VARCHAR2(1) := 'N';
  REBEXISTS  VARCHAR2(1) := 'N';

  G_SKIP_KERNEL  BOOLEAN := FALSE;
  G_SKIP_CLUSTER BOOLEAN := FALSE;
  G_SKIP_CUSTOM  BOOLEAN := FALSE;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
  END FN_SKIP_CUSTOM;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
  END FN_SKIP_CLUSTER;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);

  BEGIN
    L_MSG := 'Lcpks_Lcdtronl_Utils ==>' || P_MSG;
    DEBUG.PR_DEBUG('LC', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID VARCHAR2,
                         P_SOURCE      COTMS_SOURCE.SOURCE_CODE%TYPE,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  FUNCTION FN_VALIDATE_RELATED_REFNO(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                     P_FUNCTION_ID        IN VARCHAR2,
                                     P_ACTION_CODE        IN VARCHAR2,
                                     P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                     P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_ERR_CODE           IN OUT VARCHAR2,
                                     P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_DELETE(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_FUNCTION_ID  IN VARCHAR2,
                              P_WRK_LCDTRONL IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_ERR_CODE     IN OUT VARCHAR2,
                              P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_ANY_FIELD_MODIFIED(P_SOURCE           IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                 P_AMENDABLE_NODES  IN CSPKS_REQ_GLOBAL.TY_AMEND_NODES,
                                 P_AMENDABLE_FIELDS IN CSPKS_REQ_GLOBAL.TY_AMEND_FIELDS,
                                 P_PREV_LCDTRONL    IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_WRK_LCDTRONL     IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,

                                 P_ERR_CODE   IN OUT VARCHAR2,
                                 P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_DATETIME(L_FNDATE IN OUT DATE) RETURN BOOLEAN IS
  BEGIN
    BEGIN
      SELECT TO_DATE(TO_CHAR(GLOBAL.APPLICATION_DATE, 'DD-MON-YY') || ' ' ||
                     TO_CHAR(FN_SYSDATE, 'HH24:MI:SS'),
                     'DD-MON-YY HH24:MI:SS')
        INTO L_FNDATE
        FROM DUAL;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('In When others of  lcpks_upload_utils.fn_datetime..');
        DBG(SQLERRM);
        RETURN FALSE;

    END;

    RETURN TRUE;
    DBG('Returning true from Fn_Datetime');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  lcpks_upload_utils.fn_datetime..');
      DBG(SQLERRM);
      RETURN FALSE;

  END FN_DATETIME;

  FUNCTION FN_GET_SUBSYS_STAT(P_SOURCE     IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_SUBSYSTEM  IN VARCHAR2,
                              P_SUBSYSSTAT IN VARCHAR2) RETURN VARCHAR2 IS
    L_STAT VARCHAR2(1) := 'D';
    L_POS  NUMBER := 0;

  BEGIN
    DBG(' In Fn_get_SubSys_Stat..');
    L_POS := INSTR(P_SUBSYSSTAT, P_SUBSYSTEM);
    IF L_POS > 0 THEN
      DBG('Subsystem found..');
      L_STAT := SUBSTR(P_SUBSYSSTAT, L_POS + LENGTH(P_SUBSYSTEM) + 1, 1);
      DBG('l_Stat' || L_STAT);
    END IF;

    RETURN L_STAT;
  END;

  FUNCTION FN_UPD_SUBSYS_STAT(P_SUBSYSTEM  IN VARCHAR2,
                              P_STAT       IN VARCHAR2,
                              P_SUBSYSSTAT IN VARCHAR2) RETURN VARCHAR2 IS
    L_SUBSYSSTAT VARCHAR2(300) := P_SUBSYSSTAT;
    L_STAT       VARCHAR2(1) := 'D';
    L_POS        NUMBER := 0;

  BEGIN
    DBG(' In Fn_Upd_Subsys_Stat..');
    L_POS := INSTR(P_SUBSYSSTAT, P_SUBSYSTEM);
    IF P_SUBSYSTEM IS NOT NULL THEN
      IF L_POS > 0 THEN
        L_STAT := SUBSTR(P_SUBSYSSTAT, L_POS + LENGTH(P_SUBSYSTEM) + 1, 1);
        DBG('STST/POS:' || L_STAT || '/' || L_POS);
        L_SUBSYSSTAT := SUBSTR(P_SUBSYSSTAT,
                               1,
                               L_POS + LENGTH(P_SUBSYSTEM) - 1) || ':' ||
                        P_STAT ||
                        SUBSTR(P_SUBSYSSTAT,
                               L_POS + LENGTH(P_SUBSYSTEM) + 2);
      ELSE
        L_SUBSYSSTAT := RTRIM(L_SUBSYSSTAT, ';') || ';' || P_SUBSYSTEM || ':' ||
                        P_STAT || ';';

      END IF;

    END IF;

    DBG('l_Subsysstat' || L_SUBSYSSTAT);
    RETURN L_SUBSYSSTAT;
  END;

  FUNCTION FN_GET_PRODUCT_DETAILS(P_PRODUCT_CODE       CSTM_PRODUCT.PRODUCT_CODE%TYPE,
                                  P_PROD_REC           IN OUT CSTMS_PRODUCT%ROWTYPE,
                                  P_PRODUCT_DEFINITION IN OUT LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                  P_FUNCTION_ID        IN VARCHAR2,
                                  P_ERR_CODE           IN OUT VARCHAR2,
                                  P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_MODULE SMTB_MENU.MODULE%TYPE;

  BEGIN
    DBG('In Fn_Get_Product_Details..');

    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;

    END;

    BEGIN
      SELECT *
        INTO P_PROD_REC
        FROM CSTMS_PRODUCT
       WHERE PRODUCT_CODE = P_PRODUCT_CODE
         AND MODULE = L_MODULE
         AND RECORD_STAT = 'O'
         AND ONCE_AUTH = 'Y';

    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in Slecting From Cstms_Product.. ');
        P_ERR_CODE   := 'LC-VALS-001';
        P_ERR_PARAMS := P_PRODUCT_CODE;
        RETURN FALSE;

    END;

    BEGIN
      SELECT *
        INTO P_PRODUCT_DEFINITION
        FROM LCTMS_PRODUCT_DEFINITION
       WHERE PRODUCT_CODE = P_PRODUCT_CODE;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in Slecting From Lctms_Product_Definition.. ');
        P_ERR_CODE   := 'LC-VALS-001';
        P_ERR_PARAMS := P_PRODUCT_CODE;
        RETURN FALSE;

    END;

    DBG('Returning from Product Details ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When others of Fn_Get_Product_Details ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_GET_PRODUCT_DETAILS;

  FUNCTION FN_GENERATE_REF_NO(P_PRODUCT     IN CSTMS_PRODUCT.PRODUCT_CODE%TYPE,
                              P_REF_NO      IN OUT CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                              P_USER_REF_NO IN OUT CSTBS_CONTRACT.USER_REF_NO%TYPE,
                              P_ERR_CODE    IN OUT VARCHAR2,
                              P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_ERR_CODE    VARCHAR2(100);
    L_SERIAL      VARCHAR2(10);
    L_USER_REF_NO CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE;
    L_COUNT       NUMBER;

  BEGIN
    DBG('In Fn_Generate_Ref_No');

    IF NOT TRPKS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                      P_PRODUCT,
                                      GLOBAL.APPLICATION_DATE,
                                      L_SERIAL,
                                      P_REF_NO,
                                      L_ERR_CODE) THEN

      DBG('Failed in Trpkss.Fn_Get_Product_Refno :' || L_ERR_CODE);
      P_ERR_CODE   := L_ERR_CODE;
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('In Fn_Generate_Ref_No');
    SELECT COUNT(*)
      INTO L_COUNT
      FROM CSTMS_SEQUENCE_MASTER
     WHERE SEQUENCE_CODE = 'USERREFNO'
       AND AUTH_STAT = 'A'
       AND RECORD_STAT = 'O';

    IF L_COUNT = 1 THEN
      IF NOT CSPKS_SEQUENCE.FN_GEN_SEQUENCENO('USERREFNO',
                                              P_REF_NO,
                                              GLOBAL.APPLICATION_DATE,
                                              L_USER_REF_NO,
                                              L_ERR_CODE) THEN
        P_ERR_CODE   := L_ERR_CODE;
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      P_USER_REF_NO := L_USER_REF_NO;
    ELSE
      P_USER_REF_NO := P_REF_NO;
      DBG('p_User_Ref_No' || P_USER_REF_NO);

    END IF;

    DBG('Returing  true form the Fn_Generate_Ref_No');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of  Fn_Generate_Ref_No..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_GENERATE_REF_NO;

  FUNCTION FN_RESOLVE_REF_NO(P_SOURCE     IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_FCC_REF_NO IN OUT CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                             P_EXT_REF_NO IN OUT CSTBS_CONTRACT.EXTERNAL_REF_NO%TYPE,
                             P_USR_REF_NO IN OUT CSTBS_CONTRACT.USER_REF_NO%TYPE,
                             P_ERR_CODE   IN OUT VARCHAR2,
                             P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_EXT_REF_NO CSTBS_CONTRACT.EXTERNAL_REF_NO%TYPE;

    L_FCC_REF_NO CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE;
    L_USR_REF_NO CSTBS_CONTRACT.USER_REF_NO%TYPE;

    L_CONTRACT_SOURCE VARCHAR2(100);
    L_COUNT           NUMBER;

  BEGIN

    DBG('In Fn_Resolve_Ref_No:');

    SELECT COUNT(*)
      INTO L_COUNT
      FROM CSTB_CONTRACT
     WHERE (CONTRACT_REF_NO = NVL(P_FCC_REF_NO, ''))
        OR (USER_REF_NO = NVL(P_USR_REF_NO, ''))
        OR ((EXTERNAL_REF_NO = NVL(P_EXT_REF_NO, '')) AND SOURCE = P_SOURCE);

    DBG('l_Count' || L_COUNT);

    IF L_COUNT > 0 THEN

      IF P_FCC_REF_NO IS NOT NULL THEN
        DBG('FCC Reference Number has been Sent :' || P_FCC_REF_NO);
        L_FCC_REF_NO := P_FCC_REF_NO;

        BEGIN
          SELECT USER_REF_NO, EXTERNAL_REF_NO, SOURCE

            INTO L_USR_REF_NO, P_EXT_REF_NO, L_CONTRACT_SOURCE

            FROM CSTB_CONTRACT
           WHERE

           CONTRACT_REF_NO = P_FCC_REF_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Contract Not Found in Flexcube cng here.');

            P_ERR_CODE   := 'LD-C0402';
            P_ERR_PARAMS := L_USR_REF_NO;

            RETURN FALSE;

        END;

        IF P_USR_REF_NO IS NULL THEN
          P_USR_REF_NO := L_USR_REF_NO;
        END IF;

        L_EXT_REF_NO := P_EXT_REF_NO;

      ELSIF P_EXT_REF_NO IS NOT NULL THEN
        DBG('External  Reference Number has been Sent :' || P_EXT_REF_NO);
        L_EXT_REF_NO      := P_EXT_REF_NO;
        L_CONTRACT_SOURCE := P_SOURCE;
        BEGIN
          SELECT EXTERNAL_REF_NO, CONTRACT_REF_NO, SOURCE
            INTO P_EXT_REF_NO, P_FCC_REF_NO, L_CONTRACT_SOURCE

            FROM CSTB_CONTRACT
           WHERE

           EXTERNAL_REF_NO = P_EXT_REF_NO
           AND SOURCE = P_SOURCE;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Contract Not Found in Flexcube.');
            P_ERR_CODE   := 'LC-VALS-003';
            P_ERR_PARAMS := P_SOURCE || '~' || P_EXT_REF_NO || '~' ||
                            P_FCC_REF_NO || '~' || P_USR_REF_NO;
            RETURN FALSE;

        END;

        L_FCC_REF_NO := P_FCC_REF_NO;
        L_EXT_REF_NO := P_EXT_REF_NO;

      ELSIF P_USR_REF_NO IS NOT NULL THEN
        DBG('User Reference Number has been Sent :' || P_USR_REF_NO);
        L_USR_REF_NO := P_USR_REF_NO;
        BEGIN
          SELECT USER_REF_NO, CONTRACT_REF_NO, SOURCE
            INTO P_USR_REF_NO, P_FCC_REF_NO, L_CONTRACT_SOURCE

            FROM CSTB_CONTRACT
           WHERE

           USER_REF_NO = P_USR_REF_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Contract Not Found in Flexcube.');
            P_ERR_CODE   := 'LC-VALS-003';
            P_ERR_PARAMS := P_SOURCE || '~' || P_EXT_REF_NO || '~' ||
                            P_FCC_REF_NO || '~' || P_USR_REF_NO;
            RETURN FALSE;

        END;

        L_USR_REF_NO := P_USR_REF_NO;
        L_FCC_REF_NO := P_FCC_REF_NO;

      END IF;

      IF (NVL(P_FCC_REF_NO, L_FCC_REF_NO) <> L_FCC_REF_NO) OR
         (NVL(P_EXT_REF_NO, L_EXT_REF_NO) <> L_EXT_REF_NO) THEN
        DBG('Reference Numbers Sent do not Match..');
        P_ERR_CODE   := 'LC-VALS-004';
        P_ERR_PARAMS := P_SOURCE || '~' || P_EXT_REF_NO || '~' ||
                        P_FCC_REF_NO || '~' || P_USR_REF_NO;
        RETURN FALSE;
      END IF;

    END IF;

    DBG('Returning true from Fn_Resolve_Ref_No');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Resolve_Ref_No..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_RESOLVE_REF_NO;

  FUNCTION FN_PICK_LOAN_PREFERENCE(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_PREV_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_CURRENCY      BCTBS_CONTRACT_MASTER.BILL_CCY%TYPE := GLOBAL.LCY;
    L_PRODUCT       BCTMS_PRODUCT_MASTER.LOAN_PRODUCT%TYPE;
    L_BRIDGE_GL     BCTMS_PRODUCT_MASTER.BRIDGE_GL%TYPE;
    L_TENOR         CLTMS_PRODUCT.STD_TENOR%TYPE;
    L_UNITS         CLTMS_PRODUCT.TENOR_UNIT%TYPE;
    L_RATE_TYPE     CLTMS_PRODUCT.RATE_TYPE%TYPE := 'M';
    L_EXCHANGE_RATE NUMBER;
    L_RATE_CODE     CSTMS_PRODUCT.RATE_TYPE_PREFERRED%TYPE;
    L_ORG_EXCH_RATE NUMBER;

  BEGIN

    DBG('Inside the loan  preferences ....');
    BEGIN
      SELECT LOAN_PRODUCT, BRIDGE_GL
        INTO L_PRODUCT, L_BRIDGE_GL

        FROM LCTMS_PRODUCT_DEFINITION
       WHERE PRODUCT_CODE = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'BC-UP0399', NULL);
        RETURN FALSE;

    END;

    L_PRODUCT := TRIM(L_PRODUCT);
    IF L_PRODUCT IS NOT NULL THEN

      BEGIN
        SELECT STD_TENOR, TENOR_UNIT
          INTO L_TENOR, L_UNITS

          FROM CLTMS_PRODUCT
         WHERE PRODUCT_CODE = L_PRODUCT;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'BC-UP0396',
                       'loan product');
          RETURN FALSE;

      END;

      BEGIN
        SELECT NVL(RATE_CODE_PREF, 'M'), NVL(RATE_TYPE, 'STANDARD')
          INTO L_RATE_CODE, L_RATE_TYPE

          FROM CLTMS_PRODUCT
         WHERE PRODUCT_CODE = L_PRODUCT;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'BC-UP0396',
                       'loan product');
          RETURN FALSE;

      END;

      IF L_UNITS = 'Y' THEN

        L_TENOR := L_TENOR * 12;
        L_UNITS := 'M';
      END IF;

      P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.LOAN_VAL_DATE := GLOBAL.APPLICATION_DATE;
      IF L_UNITS = 'M' THEN
        P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.MATURITY_DATE := ADD_MONTHS(P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.LOAN_VAL_DATE,
                                                                                      L_TENOR);
      ELSE
        P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.MATURITY_DATE := P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.LOAN_VAL_DATE +
                                                                           L_TENOR;

      END IF;

      DBG('Loan Value Date' ||
          P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.LOAN_VAL_DATE);
      DBG('Maturity Date ' ||
          P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.MATURITY_DATE);

      BEGIN
        SELECT DECODE(L_RATE_CODE,
                      'M',
                      MID_RATE,
                      'B',
                      BUY_RATE,
                      'S',
                      SALE_RATE)
          INTO L_EXCHANGE_RATE
          FROM CYTMS_RATES
         WHERE CCY1 = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY
           AND CCY2 = GLOBAL.LCY
           AND RATE_TYPE = L_RATE_TYPE
           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN

          BEGIN
            SELECT DECODE(L_RATE_CODE,
                          'M',
                          MID_RATE,
                          'B',
                          BUY_RATE,
                          'S',
                          SALE_RATE)
              INTO L_EXCHANGE_RATE
              FROM CYTMS_RATES
             WHERE CCY1 = GLOBAL.LCY
               AND CCY2 =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY
               AND RATE_TYPE = L_RATE_TYPE
               AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_EXCHANGE_RATE := NULL;

          END;

      END;

      DBG('l_exchange_rate::' || L_EXCHANGE_RATE);
      L_ORG_EXCH_RATE := L_EXCHANGE_RATE;
      IF L_EXCHANGE_RATE IS NOT NULL THEN

        DBG('calling cypkss.fn_get_rp_rate..to get the customer specific rate');

        IF NOT COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH,
                                                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                                                   L_PRODUCT,
                                                   NULL,
                                                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                                   GLOBAL.LCY,
                                                   L_ORG_EXCH_RATE,
                                                   L_EXCHANGE_RATE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN

          DBG('failed to get RP exchange rate :' || P_ERR_CODE);
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, NULL);

          RETURN FALSE;
        END IF;

        DBG('Post RP Original rate1:' || L_ORG_EXCH_RATE);
        DBG('Post RP excahnge rate1:' || L_EXCHANGE_RATE);

      END IF;

      BEGIN
        DBG('p_wrk_bcdtronl.v_bctbs_contract_master.bcrefno ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);
        DBG('p_wrk_bcdtronl.v_bctbs_contract_master.event_seq_no ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        DBG('p_wrk_bcdtronl.v_bctbs_contract_master.bill_amt ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        DBG('p_wrk_bcdtronl.v_bctbs_contract_master.bill_ccy ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY);
        DBG('p_wrk_bcdtronl.v_bctbs_contract_master.customer_id ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
        DBG('l_product ' || L_PRODUCT);
        DBG('l_currency ' || L_CURRENCY);
        DBG('l_tenor ' || L_TENOR);
        DBG('l_units ' || L_UNITS);
        DBG('l_rate_code ' || L_RATE_CODE);
        DBG('l_exchange_rate ' || L_EXCHANGE_RATE);
        DBG('l_bridge_gl ' || L_BRIDGE_GL);
        DBG('l_rate_type ' || L_RATE_TYPE);

        INSERT INTO BCTMS_LOAN_PREFERENCE
          (BCREFNO,
           EVENT_SEQ_NO,

           BILL_CCY,
           COUNTERPARTY,
           PRODUCT,
           CURRENCY,
           TENOR,
           UNITS,
           RATE_CODE,
           ORG_EXCH_RATE,
           EXCHANGE_RATE,
           BRIDGE_GL,
           RATE_TYPE,
           LOAN_VAL_DATE,
           MATURITY_DATE)

        VALUES
          (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,

           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
           L_PRODUCT,
           L_CURRENCY,
           L_TENOR,
           L_UNITS,
           L_RATE_CODE,
           L_ORG_EXCH_RATE,
           L_EXCHANGE_RATE,
           L_BRIDGE_GL,
           L_RATE_TYPE,
           P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.LOAN_VAL_DATE,
           P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.MATURITY_DATE);

      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          DBG('Duplicate in bctms_loan_preference..Updating..');
          UPDATE BCTMS_LOAN_PREFERENCE
             SET BCREFNO      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                 EVENT_SEQ_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,

                 BILL_CCY       = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                 COUNTERPARTY   = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                 PRODUCT        = L_PRODUCT,
                 CURRENCY       = L_CURRENCY,
                 TENOR          = L_TENOR,
                 UNITS          = L_UNITS,
                 RATE_CODE      = L_RATE_CODE,
                 ORG_EXCH_RATE  = L_ORG_EXCH_RATE,
                 EXCHANGE_RATE  = L_EXCHANGE_RATE,
                 BRIDGE_GL      = L_BRIDGE_GL,
                 RATE_TYPE      = L_RATE_TYPE,
                 RATE_CODE_PREF = L_RATE_CODE,
                 LOAN_VAL_DATE  = P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.LOAN_VAL_DATE,
                 MATURITY_DATE  = P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.MATURITY_DATE
           WHERE BCREFNO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM BCTMS_LOAN_PREFERENCE
                   WHERE BCREFNO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

          DBG('Successfuly Updated in bctms_loan_preference');
        WHEN OTHERS THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'BC-UP0404',
                       'loan product');
          DBG('Failed in population to bctms_loan_preference');
          RETURN FALSE;

      END;

    END IF;

    DBG('Returing from fn_pick_loan_preference');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of Fn_Pick_Loan_Preference..');
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_PICK_LOAN_PREFERENCE;

  FUNCTION FN_PICK_LOAN_ICCF(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_PREV_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_LOAN_PRODUCT     OUT CFTMS_PRODUCT_ICCF.PRODUCT%TYPE,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    CURSOR CFCR_PRODUCT_ICCF(P_PRODUCT_CODE IN CFTMS_PRODUCT_ICCF.PRODUCT%TYPE) IS
      SELECT UDE_ID
        FROM CLTMS_PRODUCT_UDE
       WHERE PRODUCT_CODE = P_PRODUCT_CODE;

    L_PRODUCT BCTMS_PRODUCT_MASTER.LOAN_PRODUCT%TYPE;
    L_COUNT   NUMBER := 0;

    L_RATE_CODE  CLTMS_PRODUCT_UDE_VALUES.RATE_CODE%TYPE;
    L_CODE_USAGE CLTMS_PRODUCT_UDE_VALUES.CODE_USAGE%TYPE;
    L_UDE_VALUE  BCTMS_LOAN_ICCF.INT_RATE%TYPE;
    L_UDE_INDEX  BINARY_INTEGER := 0;

  BEGIN

    DBG('Inside pikcup loan iccf....');

    BEGIN
      SELECT LOAN_PRODUCT
        INTO L_PRODUCT
        FROM LCTMS_PRODUCT_DEFINITION
       WHERE PRODUCT_CODE = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'BC-UP0399', 'loan product');

    END;

    P_LOAN_PRODUCT := L_PRODUCT;
    FOR C1 IN CFCR_PRODUCT_ICCF(L_PRODUCT) LOOP

      BEGIN
        SELECT UDE_VALUE, RATE_CODE, CODE_USAGE
          INTO L_UDE_VALUE, L_RATE_CODE, L_CODE_USAGE
          FROM CLTMS_PRODUCT_UDE_VALUES
         WHERE UDE_ID = C1.UDE_ID
           AND PRODUCT_CODE = L_PRODUCT
           AND CCY_CODE = NVL(P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_PREFERENCE.CURRENCY,
                              GLOBAL.LCY);

      EXCEPTION
        WHEN OTHERS THEN
          L_UDE_VALUE := 0;
          DBG('Exception of cltms_product_ude_values' || SQLERRM);

      END;

      IF L_RATE_CODE IS NULL THEN
        L_CODE_USAGE := NULL;
      END IF;

      L_UDE_INDEX := L_UDE_INDEX + 1;
      P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF(L_UDE_INDEX).COMPONENT := C1.UDE_ID;
      P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF(L_UDE_INDEX).INT_RATE := NVL(P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF(L_UDE_INDEX)
                                                                               .INT_RATE,
                                                                               L_UDE_VALUE);
      P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF(L_UDE_INDEX).RATE_CODE := L_RATE_CODE;
      P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF(L_UDE_INDEX).USAGE := L_CODE_USAGE;

      INSERT INTO BCTMS_LOAN_ICCF
        (BCREFNO, EVENT_SEQ_NO, COMPONENT, RATE_CODE, INT_RATE, USAGE)
      VALUES
        (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
         P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF           (L_UDE_INDEX)
         .COMPONENT,
         P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF           (L_UDE_INDEX)
         .RATE_CODE,
         P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF           (L_UDE_INDEX)
         .INT_RATE,
         P_WRK_LCDTRONL.TY_BCCTRPRF.V_BCTM_LOAN_ICCF           (L_UDE_INDEX)
         .USAGE);

    END LOOP;

    DBG('Returing from fn_pick_loan_preference');

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of Fn_Pick_Loan_Iccf..');
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_PICK_LOAN_ICCF;

  FUNCTION FN_GET_EVENT_CODE(P_SOURCE           IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_EVENT_CODE       IN OUT VARCHAR2,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_PRD_TYP VARCHAR2(10);
    L_COUNT   NUMBER;

  BEGIN
    DBG('In Fn_Get_event_code..');

    P_EVENT_CODE := NULL;
    DBG('In Fn_Get_event_code..p_Action_Code: ' || P_ACTION_CODE);
    DBG('In Fn_Get_event_code..related_lc_ref: ' ||
        P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO);
    DBG('In Fn_Get_event_code..Char_Field91: ' ||
        P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91);
    IF P_ACTION_CODE = 'CLOSE' THEN

      IF P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91 IS NOT NULL THEN

        IF P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91 = 'CANC' AND
           P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL THEN
          DBG('Manual Cancellation of Shipping Guarantee linked with Letters of Credit is not allowed.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-503', '');
        END IF;

        IF GLOBAL.APPLICATION_DATE >
           P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE THEN
          IF P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91 = 'CANC' THEN
            DBG('Cancellation cannot be don after Closure date..');

            P_EVENT_CODE := 'CLOS';
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-781', '');

          ELSE
            P_EVENT_CODE := P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91;

          END IF;

        ELSE
          P_EVENT_CODE := P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91;

        END IF;

      ELSE
        P_EVENT_CODE := 'CLOS';

      END IF;

    ELSIF P_ACTION_CODE = 'REOPEN' THEN

      P_EVENT_CODE := 'ROPN';

    ELSIF P_ACTION_CODE IN ('NEW', 'SUBSYSPKP_NEW', 'HOLD') THEN
      IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
         ('OPN', 'ONC', 'RMB') THEN

        P_EVENT_CODE := 'BISS';
      ELSIF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ADV' THEN

        P_EVENT_CODE := 'BADV';

      ELSIF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'CNF' THEN

        P_EVENT_CODE := 'BCFM';

      ELSIF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD' THEN

        P_EVENT_CODE := 'BPRE';

      ELSIF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ANC' THEN

        P_EVENT_CODE := 'BANC';

      END IF;

    ELSIF P_ACTION_CODE IN ('MODIFY') THEN
      IF NVL(P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91, 'AMND') <> 'AMND' THEN

        BEGIN
          SELECT PRODUCT_TYPE
            INTO L_PRD_TYP
            FROM LCTM_PRODUCT_DEFINITION
           WHERE PRODUCT_CODE =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;

        EXCEPTION
          WHEN OTHERS THEN
            L_PRD_TYP := 'I';

        END;

        IF L_PRD_TYP = 'G' THEN

          SELECT COUNT(*)
            INTO L_COUNT
            FROM CSTBS_CONTRACT_EVENT_LOG
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_CODE = 'AMND';

          IF L_COUNT > 0 THEN
            DBG('Amendment has already happened and hence Re-issuance cannot be done');
            P_EVENT_CODE := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-782', '');

          ELSE
            P_EVENT_CODE := 'REIS';

          END IF;

        ELSE
          DBG('Reissuance can be done only for Guaranatees..');

          P_EVENT_CODE := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-783', '');
          P_EVENT_CODE := 'AMND';

        END IF;

      END IF;

      IF NVL(P_EVENT_CODE, '123') <> 'REIS' THEN

        IF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE THEN
          IF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'OPN' THEN
            P_EVENT_CODE := 'AOCF';
          ELSIF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE =
                'PAD' THEN
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE =
               'ADV' THEN
              P_EVENT_CODE := 'APAD';
            ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE =
                  'ANC' THEN
              P_EVENT_CODE := 'APAC';

            ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE =
                  'OPN' THEN
              P_EVENT_CODE := 'BISS';

            ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE =
                  'ONC' THEN
              P_EVENT_CODE := 'BISS';

            END IF;

          ELSIF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE =
                'ADV' THEN
            P_EVENT_CODE := 'AATC';

          END IF;

          DBG('p_prev_lcdtronl.v_lctbs_contract_master.operation_code..' ||
              P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
          DBG('p_wrk_lcdtronl.v_lctbs_contract_master.operation_code..' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
        ELSIF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE =
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE THEN
          DBG('p_prev_lcdtronl.v_lctbs_contract_master.USER_DEFINED_STATUS..' ||
              P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS);
          DBG('p_wrk_lcdtronl.v_lctbs_contract_master.USER_DEFINED_STATUS..' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS);

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN

            IF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS <>
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS THEN
              P_EVENT_CODE := 'STCH';
            ELSE
              IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE,
                     'N') = 'Y' THEN
                P_EVENT_CODE := 'PCLS';
              ELSE
                P_EVENT_CODE := 'AMND';

              END IF;

            END IF;

          ELSE
            DBG('set the event code as APRE here');
            P_EVENT_CODE := 'APRE';

          END IF;

        ELSE
          P_EVENT_CODE := 'AMND';

        END IF;

      END IF;

    ELSIF P_ACTION_CODE = 'ROLLOVER' THEN

      P_EVENT_CODE := 'REIN';

    ELSIF P_ACTION_CODE = 'REVERSE' THEN

      P_EVENT_CODE := 'REVR';

    END IF;

    DBG('Returning True From Fn_Get_event_code..');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Get_event_code..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_GET_EVENT_CODE;

  FUNCTION FN_SET_EVENT_AND_SEQ_NO(P_SOURCE           IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_VERSION_NO         NUMBER(4);
    L_EVENT_NO           NUMBER(4);
    L_OLD_VERSION_NO     NUMBER(4) := 0;
    L_OLD_EVENT_NO       NUMBER(4) := 0;
    L_AUTH_STAT          VARCHAR(1) := 'A';
    L_EVENT              VARCHAR(100);
    L_AMEND_NO           NUMBER(4) := 0;
    L_PRDCODE            VARCHAR2(4);
    L_COUTERPARTY        VARCHAR2(4);
    L_CONCCY             VARCHAR2(4);
    L_AMENDSTATUS        VARCHAR(1);
    L_AMEND_EVENT_SEQ_NO NUMBER(3);
    L_FIN_AMND_NO        NUMBER(3);
    L_FIN_FLAG           VARCHAR2(1) := 'N';
    L_FIN_NO             NUMBER(3);
    L_AMND_CNT           NUMBER := 0;
  BEGIN
    DBG('In function Fn_Set_Event_And_Seq_No....');

    BEGIN
      SELECT AMND_STATUS, AMND_SEQ_NO, FIN_AMND_NO
        INTO L_AMENDSTATUS, L_AMEND_EVENT_SEQ_NO, L_FIN_AMND_NO

        FROM LCTBS_AMND_VALS_MASTER
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND VERSION_NO =
             (SELECT MAX(VERSION_NO)
                FROM LCTBS_AMND_VALS_MASTER
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in amend vals master');

    END;

    BEGIN
      SELECT LATEST_VERSION_NO,
             LATEST_EVENT_SEQ_NO,
             AUTH_STATUS,
             PRODUCT_CODE,
             COUNTERPARTY,
             CONTRACT_CCY
        INTO L_OLD_VERSION_NO,
             L_OLD_EVENT_NO,
             L_AUTH_STAT,
             L_PRDCODE,
             L_COUTERPARTY,
             L_CONCCY
        FROM CSTBS_CONTRACT
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('Selecting the version no');

    END;

    DBG('l_Old_Version_No' || L_OLD_VERSION_NO);
    DBG('l_Old_Event_No' || L_OLD_EVENT_NO);
    IF NOT FN_GET_EVENT_CODE(P_SOURCE,
                             P_SOURCE_OPERATION,
                             P_FUNCTION_ID,
                             P_ACTION_CODE,
                             P_LCDTRONL,
                             P_PREV_LCDTRONL,
                             P_WRK_LCDTRONL,
                             L_EVENT,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Get_Event_Code..');
      RETURN FALSE;
    END IF;

    DBG('l_event is cmg as' || L_EVENT);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_HOLD) THEN

      L_VERSION_NO := 1;
      L_EVENT_NO   := 1;
      L_FIN_NO     := 0;
    ELSIF P_ACTION_CODE IN
          (CSPKS_REQ_GLOBAL.P_MODIFY, CSPKS_REQ_GLOBAL.P_ROLLOVER) THEN
      L_VERSION_NO := L_OLD_VERSION_NO;
      L_EVENT_NO   := L_OLD_EVENT_NO;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

        DBG('l_Event_No--->' || L_EVENT_NO);
        SELECT COUNT(*)
          INTO L_AMND_CNT
          FROM LCTB_AMND_VALS_MASTER
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND AMND_SEQ_NO = L_EVENT_NO
           AND NVL(BENEFICIARY_CONF_REQD, 'N') = 'N';

        DBG('l_amnd_cnt--->' || L_AMND_CNT);
        IF L_AMND_CNT > 0 THEN
          P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 := 'Y';
          G_INCR_AMND_NO                                 := TRUE;

        ELSE
          P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 := 'N';

        END IF;
        DBG('p_Wrk_Lcdtronl.v_Cstbs_Ui_Columns.Char_Field92-->' ||
            P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92);

        IF P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 = 'Y' AND
           L_EVENT IN ('AMND', 'AOCF', 'APRE') THEN

          IF P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 NOT IN
             ('LCDAMEND', 'LIDAMEND') THEN

            L_AMEND_NO := NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO + 1,
                              1);

          ELSE
            L_AMEND_NO := NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO,
                              0);
          END IF;

        ELSE
          L_AMEND_NO := NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO,
                            0);

        END IF;

        DBG('l_Fin_No' || L_FIN_NO);
        DBG('l_Fin_Amnd_No' || L_FIN_AMND_NO);

        DBG('p_Lcdtronl.v_Lctbs_Contract_Master.Fin_Flag' ||
            P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_FLAG);
        DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Fin_Flag' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_FLAG);

        IF P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 IN
           ('LCDAMEND', 'LIDAMEND') OR
           P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 = 'Y' THEN
          L_FIN_FLAG := 'Y';
        ELSE
          L_FIN_FLAG := 'N';

        END IF;

        IF L_FIN_FLAG = 'Y' THEN

          L_FIN_NO := NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_AMND_NO,
                          1);
        ELSE
          L_FIN_NO := NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_AMND_NO,
                          0);

        END IF;

      END IF;

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      L_VERSION_NO := L_OLD_VERSION_NO;
      L_EVENT_NO   := L_OLD_EVENT_NO;
      L_FIN_NO     := NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_AMND_NO,
                          0);
      DBG('l_Old_Version_No in ROPN' || L_OLD_VERSION_NO);
      DBG('l_Old_Event_No in ROPN' || L_OLD_EVENT_NO);
      DBG('l_fin_no in ROPN' || L_FIN_NO);

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      L_VERSION_NO := L_OLD_VERSION_NO;
      L_EVENT_NO   := L_OLD_EVENT_NO;
      DBG('l_Old_Version_No in Clos' || L_OLD_VERSION_NO);
      DBG('l_Old_Event_No in Clos' || L_OLD_EVENT_NO);

    ELSE
      L_VERSION_NO := L_OLD_VERSION_NO;
      L_EVENT_NO   := L_OLD_EVENT_NO + 1;
      L_FIN_NO     := NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_AMND_NO,
                          0);

    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_FLAG = 'Y' THEN
        L_FIN_FLAG := 'Y';
      END IF;

    END IF;

    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO   := L_VERSION_NO;
    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE     := L_EVENT;

    IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE IS NULL THEN
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE := L_PRDCODE;
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.COUNTERPARTY := L_COUTERPARTY;
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_CCY := L_CONCCY;
    END IF;

    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO      := L_VERSION_NO;
    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO    := L_EVENT_NO;
    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO    := L_AMEND_NO;
    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE      := L_EVENT;
    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_FLAG        := L_FIN_FLAG;
    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_AMND_NO     := L_FIN_NO;

    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE IS NULL THEN
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE := L_PRDCODE;
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE    := L_COUTERPARTY;
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY := L_CONCCY;
    END IF;

    P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.EVENT_SEQ_NO    := L_EVENT_NO;
    P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.EVENT_CODE      := L_EVENT;

    P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.VERSION_NO      := L_VERSION_NO;
    P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.EVENT_SEQ_NO    := L_EVENT_NO;
    P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.EVENT_CODE      := L_EVENT;

    P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.VERSION_NO      := L_VERSION_NO;
    P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.EVENT_SEQ_NO    := L_EVENT_NO;
    P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.EVENT_CODE      := L_EVENT;

    P_WRK_LCDTRONL.V_LCTBS_GOODS.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.V_LCTBS_GOODS.VERSION_NO      := L_VERSION_NO;
    P_WRK_LCDTRONL.V_LCTBS_GOODS.EVENT_SEQ_NO    := L_EVENT_NO;
    P_WRK_LCDTRONL.V_LCTBS_GOODS.EVENT_CODE      := L_EVENT;

    P_WRK_LCDTRONL.V_GOODS_DETAILS__MASTER.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.V_GOODS_DETAILS__MASTER.EVENT_SEQ_NO    := L_EVENT_NO;

    IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT LOOP
        P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I).VERSION_NO := L_VERSION_NO;
      END LOOP;
    END IF;

    P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.VERSION_NO      := L_VERSION_NO;
    P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.EVENT_SEQ_NO    := L_EVENT_NO;
    P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.EVENT_CODE      := L_EVENT;

    IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).VERSION_NO := L_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).EVENT_CODE := L_EVENT;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).VERSION_NO := L_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).EVENT_CODE := L_EVENT;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT LOOP
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(I).EVENT_SEQ_NO := L_EVENT_NO;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).VERSION_NO := L_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).EVENT_CODE := L_EVENT;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).VERSION_NO := L_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).EVENT_CODE := L_EVENT;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_FFTS(I) . CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_FFTS(I).VERSION_NO := L_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_FFTS(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL.V_LCTBS_FFTS(I).EVENT_CODE := L_EVENT;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).VERSION_NO := L_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).EVENT_CODE := L_EVENT;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).VERSION_NO := L_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).EVENT_CODE := L_EVENT;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT LOOP
        P_WRK_LCDTRONL. V_LCTBS_DRAFTS_DETAILS(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL. V_LCTBS_DRAFTS_DETAILS(I).EVENT_SEQ_NO := L_EVENT_NO;
      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT LOOP
        P_WRK_LCDTRONL. V_LCTBS_CONTRACT_LIMITS(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL. V_LCTBS_CONTRACT_LIMITS(I).EVENT_SEQ_NO := L_EVENT_NO;
        P_WRK_LCDTRONL. V_LCTBS_CONTRACT_LIMITS(I).EVENT_CODE := L_EVENT;
        P_WRK_LCDTRONL. V_LCTBS_CONTRACT_LIMITS(I).VERSION_NO := L_VERSION_NO;
        P_WRK_LCDTRONL. V_LCTBS_CONTRACT_LIMITS(I).LINKED_CCY := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
        P_WRK_LCDTRONL. V_LCTBS_CONTRACT_LIMITS(I).OPERATION := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE;
      END LOOP;

    END IF;

    IF P_SOURCE <> 'FLEXCUBE' THEN
      DBG('Assigning key values other than FLEXCUBE for Subsystems::');

      DBG('Assigning key values for CFCTRCOM::');
      IF P_WRK_LCDTRONL.TY_CFCTRCOM.V_CSTBS_CONTRACT__COM.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CFCTRCOM.V_CSTBS_CONTRACT__COM.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_CFCTRCOM.V_CSTBS_CONTRACT__COM.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CFCTRCOM.V_CSTBS_CONTRACT__COM.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_CFCTRCOM.V_CSTBS_CONTRACT__COM.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CFCTRCOM.V_CSTBS_CONTRACT__COM.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      DBG('Assigning key values for CFCTRCHG::');
      IF P_WRK_LCDTRONL.TY_CFCTRCHG.V_CSTBS_CONTRACT__CHG.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CFCTRCHG.V_CSTBS_CONTRACT__CHG.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_CFCTRCHG.V_CSTBS_CONTRACT__CHG.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CFCTRCHG.V_CSTBS_CONTRACT__CHG.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_CFCTRCHG.V_CSTBS_CONTRACT__CHG.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CFCTRCHG.V_CSTBS_CONTRACT__CHG.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      FOR I IN 1 .. P_WRK_LCDTRONL.TY_CFCTRCHG.V_CFTBS_CHARGE_APPLN.COUNT LOOP
        IF P_WRK_LCDTRONL.TY_CFCTRCHG.V_CFTBS_CHARGE_APPLN(I)
         .CREATION_ESN IS NULL THEN
          P_WRK_LCDTRONL.TY_CFCTRCHG.V_CFTBS_CHARGE_APPLN(I).CREATION_ESN := L_EVENT_NO;
        END IF;
      END LOOP;

      DBG('Assigning key values for ISCTRSTL::');
      IF P_WRK_LCDTRONL.TY_ISCTRSTL.V_CSTBS_CONTRACT__SETT.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_ISCTRSTL.V_CSTBS_CONTRACT__SETT.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_ISCTRSTL.V_CSTBS_CONTRACT__SETT.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_ISCTRSTL.V_CSTBS_CONTRACT__SETT.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_ISCTRSTL.V_CSTBS_CONTRACT__SETT.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_ISCTRSTL.V_CSTBS_CONTRACT__SETT.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      DBG('Assigning key values for LCCTRCLT::');
      IF P_WRK_LCDTRONL.TY_LCCTRCLT.V_CSTBS_CONTRACT__COLL.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_LCCTRCLT.V_CSTBS_CONTRACT__COLL.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_LCCTRCLT.V_CSTBS_CONTRACT__COLL.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_LCCTRCLT.V_CSTBS_CONTRACT__COLL.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_LCCTRCLT.V_CSTBS_CONTRACT__COLL.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_LCCTRCLT.V_CSTBS_CONTRACT__COLL.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      DBG('Assigning key values for TACTRTAX::');
      IF P_WRK_LCDTRONL.TY_TACTRTAX.V_CSTBS_CONTRACT__TAX.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_TACTRTAX.V_CSTBS_CONTRACT__TAX.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_TACTRTAX.V_CSTBS_CONTRACT__TAX.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_TACTRTAX.V_CSTBS_CONTRACT__TAX.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_TACTRTAX.V_CSTBS_CONTRACT__TAX.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_TACTRTAX.V_CSTBS_CONTRACT__TAX.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      DBG('Assigning key values for CSCTRLNK::');
      DBG('Before CSCTRLNK::p_Wrk_Lcdtronl.ty_csctrlnk.v_cstbs_contract__lnk.contract_ref_no: ' ||
          P_WRK_LCDTRONL.TY_CSCTRLNK.V_CSTBS_CONTRACT__LNK.CONTRACT_REF_NO);
      IF P_WRK_LCDTRONL.TY_CSCTRLNK.V_CSTBS_CONTRACT__LNK.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CSCTRLNK.V_CSTBS_CONTRACT__LNK.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_CSCTRLNK.V_CSTBS_CONTRACT__LNK.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CSCTRLNK.V_CSTBS_CONTRACT__LNK.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_CSCTRLNK.V_CSTBS_CONTRACT__LNK.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CSCTRLNK.V_CSTBS_CONTRACT__LNK.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      DBG('After CSCTRLNK::p_Wrk_Lcdtronl.ty_csctrlnk.v_cstbs_contract__lnk.contract_ref_no: ' ||
          P_WRK_LCDTRONL.TY_CSCTRLNK.V_CSTBS_CONTRACT__LNK.CONTRACT_REF_NO);
      IF P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.COUNT > 0 THEN
        FOR I IN P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.FIRST .. P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.LAST LOOP
          DBG('Before 1: CSCTRLNK::p_wrk_lcdtronl.ty_csctrlnk.v_ldtbs_contract_linkages(i).contract_ref_no: ' || P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES(I)
              .CONTRACT_REF_NO);
          P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
          DBG('After 1:  CSCTRLNK::p_wrk_lcdtronl.ty_csctrlnk.v_ldtbs_contract_linkages(i).contract_ref_no: ' || P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES(I)
              .CONTRACT_REF_NO);
        END LOOP;

      END IF;

      DBG('Checking key values for MICTRMIS::');
      IF P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.BRANCH_CODE IS NOT NULL AND
         P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.UNIT_REF_NO IS NOT NULL AND
         P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.UNIT_TYPE IS NOT NULL THEN
        DBG('Assigning key values for MICTRMIS::');
        DBG('Check MICTRMIS::' ||
            P_WRK_LCDTRONL.TY_MICTRMIS.V_CSTBS_CONTRACT__MIS.CONTRACT_REF_NO);
        DBG('Check MICTRMIS::' ||
            P_WRK_LCDTRONL.TY_MICTRMIS.V_CSTBS_CONTRACT__MIS.LATEST_EVENT_SEQ_NO);
        IF P_WRK_LCDTRONL.TY_MICTRMIS.V_CSTBS_CONTRACT__MIS.CONTRACT_REF_NO IS NULL THEN
          P_WRK_LCDTRONL.TY_MICTRMIS.V_CSTBS_CONTRACT__MIS.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        END IF;

        IF P_WRK_LCDTRONL.TY_MICTRMIS.V_CSTBS_CONTRACT__MIS.LATEST_EVENT_SEQ_NO IS NULL THEN
          P_WRK_LCDTRONL.TY_MICTRMIS.V_CSTBS_CONTRACT__MIS.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
        END IF;

        DBG('Check1 MICTRMIS::' ||
            P_WRK_LCDTRONL.TY_MICTRMIS.V_CSTBS_CONTRACT__MIS.CONTRACT_REF_NO);
        DBG('Check1 MICTRMIS::' ||
            P_WRK_LCDTRONL.TY_MICTRMIS.V_CSTBS_CONTRACT__MIS.LATEST_EVENT_SEQ_NO);
      END IF;

      DBG('Assigning key values for CSCTRSPT::');
      IF P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_CONTRACT__SPLIT.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_CONTRACT__SPLIT.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_CONTRACT__SPLIT.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_CONTRACT__SPLIT.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_CONTRACT__SPLIT.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_CONTRACT__SPLIT.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      DBG('Assigning key values for BCCTRPRF::');
      IF P_WRK_LCDTRONL.TY_BCCTRPRF.V_CSTBS_CONTRACT__CLPRF.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_BCCTRPRF.V_CSTBS_CONTRACT__CLPRF.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_BCCTRPRF.V_CSTBS_CONTRACT__CLPRF.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_BCCTRPRF.V_CSTBS_CONTRACT__CLPRF.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_BCCTRPRF.V_CSTBS_CONTRACT__CLPRF.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_BCCTRPRF.V_CSTBS_CONTRACT__CLPRF.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      DBG('Assigning key values for BCCBRDET::');
      IF P_WRK_LCDTRONL.TY_BCCBRDET.V_CSTBS_CONTRACT__BROK.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_BCCBRDET.V_CSTBS_CONTRACT__BROK.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_BCCBRDET.V_CSTBS_CONTRACT__BROK.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_BCCBRDET.V_CSTBS_CONTRACT__BROK.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_BCCBRDET.V_CSTBS_CONTRACT__BROK.LATEST_VERSION_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_BCCBRDET.V_CSTBS_CONTRACT__BROK.LATEST_VERSION_NO := L_VERSION_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_LCCILUTL.V_CSTBS_CONTRACT__LIC.CONTRACT_REF_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_LCCILUTL.V_CSTBS_CONTRACT__LIC.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      END IF;

      IF P_WRK_LCDTRONL.TY_LCCILUTL.V_CSTBS_CONTRACT__LIC.LATEST_EVENT_SEQ_NO IS NULL THEN
        P_WRK_LCDTRONL.TY_LCCILUTL.V_CSTBS_CONTRACT__LIC.LATEST_EVENT_SEQ_NO := L_EVENT_NO;
      END IF;

    END IF;

    DBG('Returning  From Fn_Set_Event_And_Seq_No..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others Of Fn_Create_Version..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_SET_EVENT_AND_SEQ_NO;

  FUNCTION FN_CALCULATE_AMTS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_FUNCTION_ID        IN VARCHAR2,
                             P_ACTION_CODE        IN VARCHAR2,
                             P_PREV_MASTER_REC    IN LCTBS_CONTRACT_MASTER%ROWTYPE,
                             P_PREV_AVAILMENT_REC IN LCTBS_AVAILMENTS%ROWTYPE,
                             P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                             P_MASTER_REC         IN OUT LCTBS_CONTRACT_MASTER%ROWTYPE,
                             P_AVAILMENT_REC      IN OUT LCTBS_AVAILMENTS%ROWTYPE,
                             P_ERR_CODE           IN OUT VARCHAR2,
                             P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    DELTA_MAX_LC_AMT     LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;
    DELTA_MAX_LIAB       LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT%TYPE;
    NEW_CURR_AVL         LCTBS_AVAILMENTS.CURRENT_AVAILABILITY%TYPE;
    NEW_OS_LIAB          LCTBS_AVAILMENTS.OS_LIABILITY%TYPE;
    OUT_NEW_OS_LIAB      LCTBS_AVAILMENTS.OS_LIABILITY%TYPE;
    LO_MX_LC             LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;
    LO_MX_LIA            LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT%TYPE;
    OUT_MX_LC            LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;
    OUT_MX_LIA           LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT%TYPE;
    L_LIAB_TOLERANCE     NUMBER;
    L_PREV_AVAILMENT_REC LCTBS_AVAILMENTS%ROWTYPE;

    LO_LIAB_TOL    NUMBER;
    OUT_LIAB_TOL   NUMBER;
    IN_MX_LIA_AMT  LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT%TYPE;
    OUT_MX_LIA_AMT LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT%TYPE;

    L_PREV_MASTER_REC    LCTBS_CONTRACT_MASTER%ROWTYPE;
    LO_PAR_CONF_PERCENT  LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT%TYPE;
    OUT_PAR_CONF_PERCENT LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT%TYPE;
    LO_PAR_CONF_AMT      LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT%TYPE;
    OUT_PAR_CONF_AMT     LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT%TYPE;
    LO_AVL_CONF_AMT      LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT%TYPE;
    OUT_AVL_CONF_AMT     LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT%TYPE;
    DELTA_LC_AMT         LCTBS_CONTRACT_MASTER.CONTRACT_AMT%TYPE;
    DELTA_LC_CONF_AMT    LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT%TYPE;
    DELTA_LC_CONF_PER    LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT%TYPE;

    L_NOTUNDERTAKING_AMT LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT%TYPE;

    ABS_DELTA_MAX_LC_AMT NUMBER := 0;
    DELTA_UNDR_AMT       NUMBER := 0;

    L_CONT_PCT   NUMBER := 0;
    L_ORG_ACTION VARCHAR2(30);

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    FUNCTION FN_NO_OF_REINSTATEMENTS RETURN NUMBER IS
      TEMP NUMBER;

      L_DAYS NUMBER;
    BEGIN
      IF P_PRODUCT_DEFINITION.REVOLVING = 'Y' THEN
        DBG('p_Product_Definition.Revolving---->' ||
            P_PRODUCT_DEFINITION.REVOLVING);

        IF P_MASTER_REC.REINSTATEMENT_TYPE = 'A' AND
           P_MASTER_REC.REVOLVES_IN = 'T' THEN

          IF P_MASTER_REC.UNITS = 'D' THEN

            L_DAYS := (P_MASTER_REC.EXPIRY_DATE - P_MASTER_REC.ISSUE_DATE);
            IF MOD(L_DAYS, P_MASTER_REC.FREQUENCY) = 0 THEN
              TEMP := TRUNC((P_MASTER_REC.EXPIRY_DATE -
                            P_MASTER_REC.ISSUE_DATE) /
                            P_MASTER_REC.FREQUENCY);
            ELSE

              TEMP := TRUNC((P_MASTER_REC.EXPIRY_DATE -
                            P_MASTER_REC.ISSUE_DATE) /
                            P_MASTER_REC.FREQUENCY) + 1;
            END IF;
          ELSIF P_MASTER_REC.UNITS = 'M' THEN

            IF MOD(MONTHS_BETWEEN(P_MASTER_REC.EXPIRY_DATE,
                                  P_MASTER_REC.ISSUE_DATE),
                   1) <> 0 THEN
              DBG('Returning TEMP by adding 1 to it');
              TEMP := TRUNC(MONTHS_BETWEEN(P_MASTER_REC.EXPIRY_DATE,
                                           P_MASTER_REC.ISSUE_DATE) /
                            P_MASTER_REC.FREQUENCY) + 1;
            ELSE
              DBG('Returning TEMP directly');
              TEMP := TRUNC(MONTHS_BETWEEN(P_MASTER_REC.EXPIRY_DATE,
                                           P_MASTER_REC.ISSUE_DATE) /
                            P_MASTER_REC.FREQUENCY);

            END IF;

          END IF;

          DBG('temp is =' || TO_CHAR(TEMP));
          RETURN TEMP;
        ELSE
          DBG('Returning 1');
          RETURN 1;

        END IF;

      ELSE
        DBG('Returning 1 from fn_no_of_reinstatements..');
        RETURN 1;

      END IF;

      RETURN NULL;
    END FN_NO_OF_REINSTATEMENTS;

  BEGIN
    DBG('In function  Fn_Calculate_Amts..');

    IF P_ACTION_CODE = 'MODIFY' THEN
      IF P_PREV_MASTER_REC.CONTRACT_REF_NO IS NULL THEN
        BEGIN
          SELECT *
            INTO L_PREV_MASTER_REC
            FROM LCTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO = P_MASTER_REC.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_CONTRACT_MASTER
                   WHERE CONTRACT_REF_NO = P_MASTER_REC.CONTRACT_REF_NO);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('When No data found of the avail rec');
          WHEN OTHERS THEN
            DBG('When othres of the p_availment_rec');

        END;

      ELSE
        L_PREV_MASTER_REC := P_PREV_MASTER_REC;

      END IF;

      IF P_PREV_AVAILMENT_REC.CONTRACT_REF_NO IS NULL THEN

        BEGIN
          SELECT *
            INTO L_PREV_AVAILMENT_REC
            FROM LCTBS_AVAILMENTS
           WHERE CONTRACT_REF_NO = P_MASTER_REC.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_AVAILMENTS
                   WHERE CONTRACT_REF_NO = P_MASTER_REC.CONTRACT_REF_NO);

        EXCEPTION

          WHEN NO_DATA_FOUND THEN
            DBG('When No data found of the avail rec');

          WHEN OTHERS THEN
            DBG('When othres of the p_availment_rec');

        END;

      ELSE
        L_PREV_AVAILMENT_REC := P_PREV_AVAILMENT_REC;

      END IF;

    END IF;

    LO_MX_LC := NVL(P_MASTER_REC.CONTRACT_AMT, 0) *
                (1 + NVL(P_MASTER_REC.POSITIVE_TOLERANCE, 0) / 100);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('lo_mx_lc') := LO_MX_LC;
      L_TB_CLUSTER_DATA('lo_mx_lc_rev') := LO_MX_LC;
      IF NOT LCPKS_LCDTRONL_UTILS_CLUSTER.FN_CALCULATE_AMTS(P_SOURCE,
                                                            P_FUNCTION_ID,
                                                            P_ACTION_CODE,
                                                            P_PREV_MASTER_REC,
                                                            P_PREV_AVAILMENT_REC,
                                                            P_PRODUCT_DEFINITION,
                                                            P_MASTER_REC,
                                                            P_AVAILMENT_REC,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in lcpks_lcdtronl_utils_cluster.Fn_Calculate_Amts' ||
                       SQLERRM);
        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('LC',
                       'Lcpks_Lcdtronl_Utils_cluster max lc value ' ||
                       L_TB_CLUSTER_DATA('lo_mx_lc_rev'));
        LO_MX_LC := TO_NUMBER(L_TB_CLUSTER_DATA('lo_mx_lc_rev'));

        DEBUG.PR_DEBUG('LC',
                       'Lcpks_Lcdtronl_Utils_cluster.Fn_Calculate_Amts ' ||
                       LO_MX_LC);
        DEBUG.PR_DEBUG('LC',
                       'lcpks_lcdtronl_utils_cluster.Fn_Calculate_Amts returned true');
      END IF;
    END IF;

    DBG(P_MASTER_REC.CONTRACT_CCY || ' - ' || LO_MX_LC);
    IF NOT
        CYPKSS.FN_AMT_ROUND(P_MASTER_REC.CONTRACT_CCY, LO_MX_LC, OUT_MX_LC) THEN
      DBG('Failed in Cypkss.Fn_Amt_Round');
      P_ERR_CODE   := 'LC-VALS-006';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    P_MASTER_REC.MAX_CONTRACT_AMT := OUT_MX_LC;
    DELTA_MAX_LC_AMT              := NVL(P_MASTER_REC.MAX_CONTRACT_AMT, 0) -
                                     NVL(L_PREV_MASTER_REC.MAX_CONTRACT_AMT,
                                         0);
    NEW_CURR_AVL                  := NVL(L_PREV_AVAILMENT_REC.CURRENT_AVAILABILITY,
                                         0) + DELTA_MAX_LC_AMT;

    IF NEW_CURR_AVL < 0 THEN
      DBG('Invalid Modification! Current availability, o/s liability cannot be negative');
      P_ERR_CODE   := 'LCCON-040';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('calculatin the Max liability amoubt');

    IF P_MASTER_REC.ISSUE_DATE IS NOT NULL AND
       P_MASTER_REC.EXPIRY_DATE IS NOT NULL AND
       P_MASTER_REC.OPERATION_CODE <> 'PAD' THEN
      IF NVL(P_MASTER_REC.MAX_LIABILITY_AMT, 0) = 0 OR
         (P_MASTER_REC.REINSTATEMENT_TYPE = 'A' AND

          P_MASTER_REC.REVOLVES_IN = 'T')

         OR (NVL(P_MASTER_REC.MAX_LIABILITY_AMT, 0) <> 0 AND

             P_ACTION_CODE IN ('MODIFY', 'REOPEN')) OR
         NVL(P_MASTER_REC.LIAB_TOLERANCE, 0) > 0 THEN

        LO_MX_LIA := FN_NO_OF_REINSTATEMENTS *
                     (NVL(P_MASTER_REC.MAX_CONTRACT_AMT, 0) +
                     (NVL(P_MASTER_REC.MAX_CONTRACT_AMT, 0) *
                     NVL(P_MASTER_REC.LIAB_TOLERANCE, 0) / 100));

        IF NOT CYPKSS.FN_AMT_ROUND(P_MASTER_REC.CONTRACT_CCY,
                                   LO_MX_LIA,
                                   OUT_MX_LIA) THEN
          DBG('Failed in Cypkss.Fn_Amt_Round');
          P_ERR_CODE   := 'LC-VALS-006';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

        P_MASTER_REC.MAX_LIABILITY_AMT := OUT_MX_LIA;

      END IF;

      DBG(' lo_mx_lia -->' || LO_MX_LIA);
      DBG(' fn_no_of_reinstatements ' || FN_NO_OF_REINSTATEMENTS);

      DBG('The Out_Mx_Lia' || OUT_MX_LIA);

      IF (P_MASTER_REC.MAX_LIABILITY_AMT > 0 AND P_ACTION_CODE = 'NEW') OR
         (NVL(L_PREV_MASTER_REC.MAX_LIABILITY_AMT, 0) <>
         NVL(P_MASTER_REC.MAX_LIABILITY_AMT, 0) AND
         P_ACTION_CODE = 'MODIFY') THEN
        DBG('p_Master_Rec.Max_Liability_Amt:: ' ||
            P_MASTER_REC.MAX_LIABILITY_AMT);
        DBG('p_Master_Rec.Max_Contract_AmT:: ' ||
            P_MASTER_REC.MAX_CONTRACT_AMT);

        IF P_MASTER_REC.MAX_LIABILITY_AMT <
           NVL(P_MASTER_REC.MAX_CONTRACT_AMT, 0) THEN
          DBG('Resetting Liability Amount/Tolerance...');
          P_MASTER_REC.MAX_LIABILITY_AMT := NVL(P_MASTER_REC.MAX_CONTRACT_AMT,
                                                0);
        END IF;

        DBG('calculate the l_Liab_Tolerance');

        DBG('liab_tolerance' || P_MASTER_REC.LIAB_TOLERANCE);
        IF NVL(P_MASTER_REC.LIAB_TOLERANCE, 0) = 0 THEN
          LO_LIAB_TOL := (((NVL(P_MASTER_REC.MAX_LIABILITY_AMT, 0) /
                         FN_NO_OF_REINSTATEMENTS) -
                         NVL(P_MASTER_REC.MAX_CONTRACT_AMT, 0)) /
                         NVL(P_MASTER_REC.MAX_CONTRACT_AMT, 0)) * 100;

          IF NOT CYPKSS.FN_AMT_ROUND(P_MASTER_REC.CONTRACT_CCY,
                                     LO_LIAB_TOL,
                                     OUT_LIAB_TOL) THEN
            DBG('failed in cypkss.fn_amt_round');
            P_ERR_CODE   := 'LC-VALS-006';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

          L_LIAB_TOLERANCE := NVL(OUT_LIAB_TOL, 0);

          DBG('l_Liab_Tolerance' || L_LIAB_TOLERANCE);

          IF L_LIAB_TOLERANCE < 0 THEN
            DBG('Incorrect Liability Amount');
            P_ERR_CODE   := 'LC-VALS-113';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          ELSIF L_LIAB_TOLERANCE > 999 THEN
            DBG('Calculate Liability Tolerance is greater than 999,Reduce the MAx liab amt');
            P_ERR_CODE   := 'LC-VALS-114';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          ELSIF L_LIAB_TOLERANCE > 0 THEN

            IF L_LIAB_TOLERANCE <> NVL(P_MASTER_REC.LIAB_TOLERANCE, 0) THEN
              DBG('Liability Tolerance is Re-Adjusted..');
              P_MASTER_REC.LIAB_TOLERANCE := L_LIAB_TOLERANCE;

            END IF;

            IN_MX_LIA_AMT := NVL(P_MASTER_REC.MAX_CONTRACT_AMT, 0) +
                             NVL(P_MASTER_REC.MAX_CONTRACT_AMT, 0) *
                             NVL(P_MASTER_REC.LIAB_TOLERANCE, 0) / 100;
            IF NOT CYPKSS.FN_AMT_ROUND(P_MASTER_REC.CONTRACT_CCY,
                                       IN_MX_LIA_AMT,
                                       OUT_MX_LIA_AMT) THEN
              DBG('failed in cypkss.fn_amt_round');
              P_ERR_CODE   := 'LC-VALS-006';
              P_ERR_PARAMS := NULL;
              RETURN FALSE;
            END IF;

            P_MASTER_REC.MAX_LIABILITY_AMT := OUT_MX_LIA_AMT;
            DBG('l_Liab_Tolerance' || L_LIAB_TOLERANCE);
            DBG('p_Master_Rec.Liab_Tolerance' ||
                P_MASTER_REC.LIAB_TOLERANCE);

          ELSE
            P_MASTER_REC.LIAB_TOLERANCE := NVL(L_LIAB_TOLERANCE, 0);

          END IF;

        END IF;

      ELSE
        DBG('The liability amt is same...' || OUT_MX_LIA);
        IF OUT_MX_LIA IS NOT NULL THEN
          P_MASTER_REC.MAX_LIABILITY_AMT := OUT_MX_LIA;
        END IF;

      END IF;

    ELSE
      L_ORG_ACTION := NVL(CSPKS_REQ_WRAPPER.G_ACTION_CODE, 'XXX');
      DBG('l_org_action>>>>>>>>>>>' || L_ORG_ACTION);
      IF P_MASTER_REC.OPERATION_CODE = 'PAD' AND
         L_ORG_ACTION IN ('NEW', 'MODIFY', 'REOPEN') THEN
        DBG('If issue date/expiry date is NULL maximum liability amount is set to 0,during Pre-advice operation');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-395', NULL);
        P_MASTER_REC.MAX_LIABILITY_AMT := NULL;
      END IF;

    END IF;

    P_MASTER_REC.LIAB_TOLERANCE := NVL(P_MASTER_REC.LIAB_TOLERANCE, 0);
    DBG('p_Master_Rec.Liab_Tolerance' || P_MASTER_REC.LIAB_TOLERANCE);
    IF NVL(P_MASTER_REC.LIAB_TOLERANCE, 0) > 0 THEN
      IF NOT P_MASTER_REC.LIAB_TOLERANCE BETWEEN 1 AND 100 THEN

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-116', '');

      END IF;

    END IF;

    DELTA_MAX_LIAB := NVL(P_MASTER_REC.MAX_LIABILITY_AMT, 0) -
                      NVL(L_PREV_MASTER_REC.MAX_LIABILITY_AMT, 0);
    NEW_OS_LIAB    := NVL(L_PREV_AVAILMENT_REC.OS_LIABILITY, 0) +
                      DELTA_MAX_LIAB;

    DBG('Calling Cypkss.Fn_Amt_Round - ' || P_MASTER_REC.CONTRACT_CCY ||
        ' - ' || NEW_OS_LIAB);
    IF NOT CYPKSS.FN_AMT_ROUND(P_MASTER_REC.CONTRACT_CCY,
                               NEW_OS_LIAB,
                               OUT_NEW_OS_LIAB) THEN
      DBG('Failed in Cypkss.Fn_Amt_Round');
      P_ERR_CODE   := 'LC-VALS-006';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    IF NVL(OUT_NEW_OS_LIAB, 0) < 0 THEN
      DBG('Invalid Modification! Current availability, o/s liability cannot be negative');
      P_ERR_CODE   := 'LCCON-040';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    P_AVAILMENT_REC.CURRENT_AVAILABILITY := NEW_CURR_AVL;
    P_AVAILMENT_REC.OS_LIABILITY         := OUT_NEW_OS_LIAB;
    P_MASTER_REC.OS_LC_AMOUNT            := OUT_NEW_OS_LIAB;

    DBG('confirm percent ' || P_MASTER_REC.CONFIRM_PERCENT);
    DBG('confirm amount ' || P_MASTER_REC.CONFIRM_AMOUNT);
    DBG('Outstanding Liability :' || OUT_NEW_OS_LIAB);
    DBG('Partial Confirmation Allow :' ||
        P_MASTER_REC.PARTIAL_CONFIRMATION_ALLOW);
    DBG('New Current Availability :' || NEW_CURR_AVL);

    IF NVL(P_MASTER_REC.PARTIAL_CONFIRMATION_ALLOW, 'N') = 'Y' THEN
      IF P_ACTION_CODE = 'NEW' THEN
        IF NVL(P_MASTER_REC.CONFIRM_PERCENT, 0) > 0 THEN
          LO_PAR_CONF_PERCENT := P_MASTER_REC.CONFIRM_PERCENT;

          LO_PAR_CONF_AMT := (P_MASTER_REC.CONFIRM_PERCENT * NEW_CURR_AVL) / 100;
        ELSIF NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0) > 0 THEN

          LO_PAR_CONF_PERCENT := 100 * (P_MASTER_REC.CONFIRM_AMOUNT /
                                 NEW_CURR_AVL);
          LO_PAR_CONF_AMT     := P_MASTER_REC.CONFIRM_AMOUNT;

        ELSE
          LO_PAR_CONF_AMT := 0;

        END IF;

        LO_AVL_CONF_AMT := NVL(LO_PAR_CONF_AMT, 0);

        DBG('confirm percent New : ' || LO_PAR_CONF_PERCENT);
        DBG('confirm amount New :' || LO_PAR_CONF_AMT);
        DBG('Available confirm amount New :' || LO_AVL_CONF_AMT);

      ELSIF P_ACTION_CODE = 'MODIFY' THEN
        DBG('p_Prev_Availment_Rec.Available_Confirmed_Amt--> ' ||
            P_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT);
        DBG('l_Prev_Availment_Rec.Available_Confirmed_Amt--> ' ||
            L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT);
        DBG('p_Availment_Rec.Available_Confirmed_Amt--> ' ||
            P_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT);
        DELTA_LC_CONF_AMT := NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0) -
                             NVL(L_PREV_MASTER_REC.CONFIRM_AMOUNT, 0);
        DELTA_LC_CONF_PER := NVL(P_MASTER_REC.CONFIRM_PERCENT, 0) -
                             NVL(L_PREV_MASTER_REC.CONFIRM_PERCENT, 0);

        DBG('Delta_Lc_conf_amt :' || DELTA_LC_CONF_AMT);
        DBG('Delta_Lc_conf_per :' || DELTA_LC_CONF_PER);
        DBG('Delta_Max_Liab :' || DELTA_MAX_LIAB);
        DBG('delta_max_lc_amt :' || DELTA_MAX_LC_AMT);

        IF NVL(DELTA_MAX_LC_AMT, 0) <> 0 AND NVL(DELTA_LC_CONF_PER, 0) = 0 THEN
          DBG('Contract amt is modified');

          IF NVL(P_MASTER_REC.CONFIRM_PERCENT, 0) = 0 AND
             NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0) <> 0 THEN

            LO_PAR_CONF_AMT     := P_MASTER_REC.CONFIRM_AMOUNT;
            LO_AVL_CONF_AMT     := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                       0) +
                                   ((DELTA_MAX_LC_AMT *
                                    L_PREV_MASTER_REC.CONFIRM_PERCENT) / 100);
            LO_PAR_CONF_PERCENT := 100 *
                                   (NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0) /
                                   P_MASTER_REC.MAX_CONTRACT_AMT);
            DBG('l_prev_availment_rec.available_confirmed_amt6: ' ||
                L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT);
            DBG('delta_max_lc_amt7: ' || DELTA_MAX_LC_AMT);
            DBG('l_prev_master_rec.confirm_percent  : ' ||
                L_PREV_MASTER_REC.CONFIRM_PERCENT);
          ELSIF NVL(P_MASTER_REC.CONFIRM_PERCENT, 0) > 0 AND
                NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0) = 0 THEN

            LO_PAR_CONF_PERCENT := P_MASTER_REC.CONFIRM_PERCENT;
            LO_PAR_CONF_AMT     := P_MASTER_REC.MAX_CONTRACT_AMT *
                                   P_MASTER_REC.CONFIRM_PERCENT / 100;
            LO_AVL_CONF_AMT     := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                       0) +
                                   ((DELTA_MAX_LC_AMT *
                                    L_PREV_MASTER_REC.CONFIRM_PERCENT) / 100);
            DBG('l_prev_availment_rec.available_confirmed_amt9: ' ||
                L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT);
            DBG('delta_max_lc_amt: ' || DELTA_MAX_LC_AMT);
            DBG('l_prev_master_rec.confirm_percent  : ' ||
                L_PREV_MASTER_REC.CONFIRM_PERCENT);

          ELSE

            LO_PAR_CONF_PERCENT := P_MASTER_REC.CONFIRM_PERCENT;
            LO_PAR_CONF_AMT     := P_MASTER_REC.MAX_CONTRACT_AMT *
                                   P_MASTER_REC.CONFIRM_PERCENT / 100;
            LO_AVL_CONF_AMT     := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                       0) +
                                   ((DELTA_MAX_LC_AMT *
                                    L_PREV_MASTER_REC.CONFIRM_PERCENT) / 100);
            DBG('lo_par_conf_percent1 : ' || LO_PAR_CONF_PERCENT);
            DBG(' lo_par_conf_amt 2 : ' || LO_PAR_CONF_AMT);
            DBG('lo_avl_conf_amt  3: ' || LO_AVL_CONF_AMT);
            DBG('l_prev_availment_rec.available_confirmed_amt: ' ||
                L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT);
            DBG('delta_max_lc_amt: ' || DELTA_MAX_LC_AMT);
            DBG('l_prev_master_rec.confirm_percent  3: ' ||
                L_PREV_MASTER_REC.CONFIRM_PERCENT);

          END IF;

        ELSIF NVL(DELTA_LC_CONF_PER, 0) <> 0 AND
              NVL(DELTA_MAX_LC_AMT, 0) = 0 THEN
          DBG('Both Contract Amount and percent have been modified');

          IF P_MASTER_REC.CONFIRM_PERCENT IS NOT NULL THEN

            LO_PAR_CONF_PERCENT := NVL(P_MASTER_REC.CONFIRM_PERCENT, 0);

            LO_PAR_CONF_AMT := NVL(L_PREV_MASTER_REC.CONFIRM_AMOUNT, 0) +
                               (DELTA_LC_CONF_PER *

                                LO_MX_LC) / 100;
            LO_AVL_CONF_AMT := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                   0) + (DELTA_LC_CONF_PER *

                                         LO_MX_LC) / 100;

          ELSE

            LO_PAR_CONF_AMT := NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0);

            LO_PAR_CONF_PERCENT := 100 * (NVL(P_MASTER_REC.CONFIRM_AMOUNT,
                                              0) / LO_MX_LC);

            LO_AVL_CONF_AMT := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                   0) + NVL(DELTA_LC_CONF_AMT, 0);

          END IF;

        ELSIF NVL(DELTA_LC_CONF_PER, 0) <> 0 AND
              NVL(DELTA_MAX_LC_AMT, 0) <> 0 THEN
          DBG('Confirm percent is modified');
          LO_PAR_CONF_PERCENT := NVL(P_MASTER_REC.CONFIRM_PERCENT, 0);

          LO_PAR_CONF_AMT := (LO_PAR_CONF_PERCENT * LO_MX_LC) / 100;
          LO_AVL_CONF_AMT := (LO_PAR_CONF_PERCENT * LO_MX_LC) / 100;

        ELSIF NVL(DELTA_LC_CONF_AMT, 0) <> 0 THEN
          DBG('Confirm amount is modified');

          LO_PAR_CONF_PERCENT := 100 * (NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0) /
                                 LO_MX_LC);

          LO_PAR_CONF_AMT := NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0);
          LO_AVL_CONF_AMT := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                 0) + NVL(DELTA_LC_CONF_AMT, 0);

        ELSIF NVL(P_MASTER_REC.CONFIRM_PERCENT, 0) = 0 THEN
          DBG('23740433 when confirm percentage is zero and when amount is deleted');
          LO_AVL_CONF_AMT := 0;

        ELSIF NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0) = 0 THEN
          DBG('23740433 when confirm amount is zero and when percentage is deleted');
          LO_PAR_CONF_PERCENT := 0;

        ELSE
          DBG('Among Contract amount,confirm amount or percent nothing is modified');
          LO_PAR_CONF_PERCENT := NVL(L_PREV_MASTER_REC.CONFIRM_PERCENT, 0);
          LO_PAR_CONF_AMT     := NVL(L_PREV_MASTER_REC.CONFIRM_AMOUNT, 0);
          LO_AVL_CONF_AMT     := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                     0);

        END IF;

        DBG('confirm percent modify : ' || LO_PAR_CONF_PERCENT);
        DBG('confirm amount modify :' || LO_PAR_CONF_AMT);
        DBG('Available_Confirmed_Amt modify : ' || LO_AVL_CONF_AMT);
      END IF;

    ELSE

      P_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT := NVL(P_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                                     0);
      IF P_ACTION_CODE = 'MODIFY' AND
         (NVL(DELTA_MAX_LC_AMT, 0) <> 0 OR NVL(DELTA_MAX_LC_AMT, 0) = 0) THEN
        DBG('Contract amt is modified');
        LO_PAR_CONF_PERCENT := NVL(L_PREV_MASTER_REC.CONFIRM_PERCENT, 0);
        LO_PAR_CONF_AMT     := NVL(L_PREV_MASTER_REC.CONFIRM_AMOUNT, 0) +
                               ((DELTA_MAX_LC_AMT *
                                L_PREV_MASTER_REC.CONFIRM_PERCENT) / 100);
        LO_AVL_CONF_AMT     := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                   0) +
                               ((DELTA_MAX_LC_AMT *
                                L_PREV_MASTER_REC.CONFIRM_PERCENT) / 100);
      END IF;

    END IF;

    LO_PAR_CONF_AMT     := NVL(LO_PAR_CONF_AMT, 0);
    LO_AVL_CONF_AMT     := NVL(LO_AVL_CONF_AMT, 0);
    LO_PAR_CONF_PERCENT := NVL(LO_PAR_CONF_PERCENT, 0);

    IF NOT CYPKSS.FN_AMT_ROUND(P_MASTER_REC.CONTRACT_CCY,
                               LO_PAR_CONF_AMT,
                               OUT_PAR_CONF_AMT) THEN
      DBG('failed in cypkss.fn_amt_round');
      P_ERR_CODE   := 'LC-VALS-006';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    IF NOT CYPKSS.FN_AMT_ROUND(P_MASTER_REC.CONTRACT_CCY,
                               LO_AVL_CONF_AMT,
                               OUT_AVL_CONF_AMT) THEN
      DBG('failed in cypkss.fn_amt_round');
      P_ERR_CODE   := 'LC-VALS-006';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    IF NOT CYPKSS.FN_AMT_ROUND(P_MASTER_REC.CONTRACT_CCY,
                               LO_PAR_CONF_PERCENT,
                               OUT_PAR_CONF_PERCENT) THEN
      DBG('failed in cypkss.fn_amt_round');
      P_ERR_CODE   := 'LC-VALS-006';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    P_MASTER_REC.CONFIRM_PERCENT            := OUT_PAR_CONF_PERCENT;
    P_MASTER_REC.CONFIRM_AMOUNT             := OUT_PAR_CONF_AMT;
    P_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT := OUT_AVL_CONF_AMT;
    P_AVAILMENT_REC.UNCNFIRM_AVAILED_AMT    := NVL(L_PREV_AVAILMENT_REC.UNCNFIRM_AVAILED_AMT,
                                                   0);

    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' THEN

      DBG('Lo_Mx_Lc' || LO_MX_LC);
      DBG('p_Master_Rec.Unconfirm_Amount' || P_MASTER_REC.UNCONFIRM_AMOUNT);
      DBG('Out_Mx_Lc' || OUT_MX_LC);
      DBG('Out_Par_Conf_Amt' || OUT_PAR_CONF_AMT);

      P_MASTER_REC.UNCONFIRM_AMOUNT := OUT_MX_LC - OUT_PAR_CONF_AMT;

      P_AVAILMENT_REC.AVAILABLE_UNCONFIRMED_AMT := NVL(P_AVAILMENT_REC.CURRENT_AVAILABILITY,
                                                       0) - NVL(P_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT,
                                                                0);

      IF (P_MASTER_REC.OPERATION_CODE IN ('CNF', 'ANC'))

         AND NVL(P_MASTER_REC.PARTIAL_CONFIRMATION_ALLOW, 'N') = 'N' THEN

        P_MASTER_REC.CONFIRM_PERCENT := 100;

        IF P_ACTION_CODE = 'NEW' THEN
          P_MASTER_REC.CONFIRM_AMOUNT := OUT_MX_LC;
        ELSIF P_ACTION_CODE = 'MODIFY'

         THEN
          P_MASTER_REC.CONFIRM_AMOUNT := P_AVAILMENT_REC.CURRENT_AVAILABILITY;

        END IF;

        P_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT   := P_AVAILMENT_REC.CURRENT_AVAILABILITY;
        P_MASTER_REC.UNCONFIRM_AMOUNT             := 0;
        P_AVAILMENT_REC.AVAILABLE_UNCONFIRMED_AMT := 0;
      END IF;

    ELSE
      P_MASTER_REC.UNCONFIRM_AMOUNT             := 0;
      P_AVAILMENT_REC.AVAILABLE_UNCONFIRMED_AMT := 0;

    END IF;

    DBG('confirm percent in the end : ' || P_MASTER_REC.CONFIRM_PERCENT);
    DBG('confirm amount in the end :' || P_MASTER_REC.CONFIRM_AMOUNT);
    DBG('Available_Confirmed_Amt in the end  : ' ||
        P_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT);
    DBG('Uncnfirm_Availed_Amt in the end : ' ||
        P_AVAILMENT_REC.UNCNFIRM_AVAILED_AMT);
    DBG('p_Availment_Rec.Os_Liability : ' || P_AVAILMENT_REC.OS_LIABILITY);

    IF (P_MASTER_REC.OPERATION_CODE NOT IN ('ANC', 'CNF'))

     THEN

      IF (NVL(P_MASTER_REC.CONFIRM_PERCENT, 0) <> 0 OR
         NVL(P_MASTER_REC.CONFIRM_AMOUNT, 0) <> 0) THEN
        DBG('confirmation percent and confirm Amount can only be entered for oper code anc or cnf');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-507', NULL);
      END IF;

      P_MASTER_REC.CONFIRM_PERCENT            := 0;
      P_MASTER_REC.CONFIRM_AMOUNT             := 0;
      P_AVAILMENT_REC.AVAILABLE_CONFIRMED_AMT := 0;
      P_AVAILMENT_REC.UNCNFIRM_AVAILED_AMT    := 0;

    END IF;

    DBG('Reimbursement Type : ' || P_PRODUCT_DEFINITION.REIMBURSEMENT);
    IF NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'Y' THEN
      DBG('Action : ' || P_ACTION_CODE);
      IF P_ACTION_CODE = 'NEW' THEN
        IF P_MASTER_REC.UNDERTAKING_AMOUNT IS NOT NULL THEN

          P_MASTER_REC.AVAILED_UNDERTAKING_AMOUNT       := 0;
          P_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT  := NVL(P_MASTER_REC.UNDERTAKING_AMOUNT,
                                                               0);
          P_AVAILMENT_REC.AVAILED_NOTUNDERTAKING_AMOUNT := 0;
        END IF;

        DBG(' Availed Undertaking Amount : ' ||
            P_MASTER_REC.AVAILED_UNDERTAKING_AMOUNT);
      ELSIF P_ACTION_CODE = 'MODIFY' THEN
        DBG('Current Undertaking Amount:: ' ||
            P_MASTER_REC.UNDERTAKING_AMOUNT);
        DBG('Previous Undertaking Amount:: ' ||
            L_PREV_MASTER_REC.UNDERTAKING_AMOUNT);
        DBG('Current Contract  Amount:: ' || P_MASTER_REC.MAX_CONTRACT_AMT);
        DBG('Previous Contract Amount:: ' ||
            L_PREV_MASTER_REC.MAX_CONTRACT_AMT);
        DBG('Current Os Amount:: ' || P_AVAILMENT_REC.OS_LIABILITY);
        DBG('Previous Available Undertaking Amount:: ' ||
            P_PREV_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT);
        DBG('Previous Available Undertaking Amount:: ' ||
            L_PREV_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT);
        DBG('delta_max_lc_amt:: ' || DELTA_MAX_LC_AMT);
        DELTA_UNDR_AMT := NVL(P_MASTER_REC.UNDERTAKING_AMOUNT, 0) -
                          NVL(L_PREV_MASTER_REC.UNDERTAKING_AMOUNT, 0);

        L_NOTUNDERTAKING_AMT := NVL(L_PREV_AVAILMENT_REC.CURRENT_AVAILABILITY,
                                    0) -

                                NVL(L_PREV_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT,
                                    0);
        DBG('Delta MAx liab :' || DELTA_MAX_LIAB);
        DBG('Delta_Undr_Amt :' || DELTA_UNDR_AMT);
        DBG('Not Undertaking Amt :' || L_NOTUNDERTAKING_AMT);

        ABS_DELTA_MAX_LC_AMT := ABS(DELTA_MAX_LC_AMT);
        DBG(' absolute Delta MAx lc Amt :' || ABS_DELTA_MAX_LC_AMT);

        IF NVL(DELTA_MAX_LC_AMT, 0) < 0 THEN
          IF ABS_DELTA_MAX_LC_AMT > L_NOTUNDERTAKING_AMT THEN
            P_MASTER_REC.UNDERTAKING_AMOUNT := NVL(L_PREV_MASTER_REC.UNDERTAKING_AMOUNT,
                                                   0) -
                                               (NVL(ABS_DELTA_MAX_LC_AMT, 0) -
                                                NVL(L_NOTUNDERTAKING_AMT, 0));

            P_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT,
                                                                0) -
                                                            (NVL(ABS_DELTA_MAX_LC_AMT,
                                                                 0) -
                                                             NVL(L_NOTUNDERTAKING_AMT,
                                                                 0));
          END IF;

        ELSIF NVL(DELTA_MAX_LC_AMT, 0) >= 0 OR
              ABS_DELTA_MAX_LC_AMT < L_NOTUNDERTAKING_AMT THEN
          P_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT,
                                                              0);

        END IF;

        IF DELTA_UNDR_AMT <> 0 THEN
          DBG('New Undertaking Amt :' || P_MASTER_REC.UNDERTAKING_AMOUNT);

          P_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT := NVL(L_PREV_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT,

                                                              0) +
                                                          DELTA_UNDR_AMT;
        END IF;

        DBG('Now Undertaking Amt :' || P_MASTER_REC.UNDERTAKING_AMOUNT);
        DBG('N0w available_undertaking_amount :' ||
            P_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT);
        P_MASTER_REC.AVAILED_UNDERTAKING_AMOUNT       := NVL(L_PREV_MASTER_REC.AVAILED_UNDERTAKING_AMOUNT,
                                                             0);
        P_AVAILMENT_REC.AVAILED_NOTUNDERTAKING_AMOUNT := NVL(L_PREV_AVAILMENT_REC.AVAILED_NOTUNDERTAKING_AMOUNT,
                                                             0);
        DBG('N0w prev availed_undertaking_amount sarina :' ||
            L_PREV_MASTER_REC.AVAILED_UNDERTAKING_AMOUNT);
        DBG('N0w availed_undertaking_amount sarina :' ||
            P_MASTER_REC.AVAILED_UNDERTAKING_AMOUNT);

      END IF;

    ELSE
      P_MASTER_REC.UNDERTAKING_AMOUNT               := 0;
      P_MASTER_REC.AVAILED_UNDERTAKING_AMOUNT       := 0;
      P_AVAILMENT_REC.AVAILABLE_UNDERTAKING_AMOUNT  := 0;
      P_AVAILMENT_REC.AVAILED_NOTUNDERTAKING_AMOUNT := 0;

    END IF;

    P_AVAILMENT_REC.CURRENT_AVAILABILITY := NEW_CURR_AVL;
    P_AVAILMENT_REC.OS_LIABILITY         := OUT_NEW_OS_LIAB;
    P_MASTER_REC.OS_LC_AMOUNT            := OUT_NEW_OS_LIAB;

    DBG('p_Availment_Rec.Current_Availability : ' ||
        P_AVAILMENT_REC.CURRENT_AVAILABILITY);
    DBG('p_Availment_Rec.Os_Liability  : ' || P_AVAILMENT_REC.OS_LIABILITY);
    DBG('p_Master_Rec.Os_Lc_Amount : ' || P_MASTER_REC.OS_LC_AMOUNT);

    DBG('Returning true from fn_calculate_amts');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in fn_calculate_amts ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_CALCULATE_AMTS;

  FUNCTION FN_UNLOCK(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                     P_FUNCTION_ID IN VARCHAR2,
                     P_ACTION_CODE IN OUT VARCHAR2,
                     P_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                     P_ERR_CODE    IN OUT VARCHAR2,
                     P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_FCC_REF            VARCHAR2(20);
    L_EXT_REF            VARCHAR2(20);
    L_USER_REF           CSTB_CONTRACT.USER_REF_NO%TYPE;
    L_SOURCE             VARCHAR2(20);
    L_LOG_REC            CSTB_CONTRACT_EVENT_LOG%ROWTYPE;
    L_CONT_REC           CSTB_CONTRACT%ROWTYPE;
    L_PRODUCT_DEFINITION LCTMS_PRODUCT_DEFINITION%ROWTYPE;
    L_COUNT              NUMBER := 0;
    L_NEW_REFNO          CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE;
    L_NEW_ESN            CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE;
    L_NEW_VERSION        CSTBS_CONTRACT.LATEST_VERSION_NO%TYPE;
    L_CUR_APP_DATETIME   DATE;
    L_CUR_APP_DATE       DATE := TO_CHAR(GLOBAL.APPLICATION_DATE,
                                         'DD-MON-YY');
    L_LCTBS_AVAILMENTS   LCTBS_AVAILMENTS%ROWTYPE;
    L_NEW_OS_LIAB        LCTBS_AVAILMENTS.OS_LIABILITY%TYPE;
    L_NEW_CURR_AVL       LCTBS_AVAILMENTS.CURRENT_AVAILABILITY%TYPE;
    L_NEW_REIN_DATE      LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE%TYPE;
    L_CONT_EXISTS        BOOLEAN := TRUE;
    L_AUTH_COUNT         NUMBER;
    L_VERNO              NUMBER;
    L_ESN                NUMBER;
    L_FIN_FLAG           LCTBS_CONTRACT_MASTER.FIN_FLAG%TYPE;
    L_BRANCH             CSTBS_CONTRACT.BRANCH%TYPE;
    L_MODULE             CSTBS_CONTRACT.MODULE_CODE%TYPE;
    L_PRODUCT_TYPE       CSTBS_CONTRACT.PRODUCT_TYPE%TYPE;

    L_BOOL             BOOLEAN;
    L_NEW_AVL_CNF_AMT  LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT%TYPE;
    L_NEW_REIM_UND_AMT LCTBS_AVAILMENTS.AVAILABLE_UNDERTAKING_AMOUNT%TYPE;
    L_RND_AVL_CNF_AMT  LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT%TYPE;
    L_RND_REIM_UND_AMT LCTBS_AVAILMENTS.AVAILABLE_UNDERTAKING_AMOUNT%TYPE;

    L_SOURCE1 CSTB_CONTRACT.SOURCE%TYPE;

    L_UPCOUNT         NUMBER;
    L_GUARANTEE_COUNT NUMBER;

    L_POLICY_NUMBER VARCHAR2(105);

    L_NEW_AVL_UNCNF_AMT LCTBS_AVAILMENTS.AVAILABLE_UNCONFIRMED_AMT%TYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    CURSOR C_DRAFTS IS
      SELECT *
        FROM LCTB_DRAFTS
       WHERE CONTRACT_REF_NO = P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM LCTB_DRAFTS
               WHERE CONTRACT_REF_NO =
                     P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

  BEGIN
    DBG('In Fn_Unlock..' || P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

    BEGIN
      DBG('Checking for module code');
      SELECT MODULE_CODE, PRODUCT_TYPE
        INTO L_MODULE, L_PRODUCT_TYPE

        FROM CSTBS_CONTRACT
       WHERE CONTRACT_REF_NO = P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found for module code');
        L_MODULE := NULL;
      WHEN OTHERS THEN
        DBG('Failed in selecting module...' || SQLERRM);

    END;

    DBG('Module = ' || L_MODULE);
    IF L_MODULE NOT IN ('LC', 'LI') THEN
      P_ERR_CODE   := 'LC-UP1012';
      P_ERR_PARAMS := L_MODULE;
      RETURN FALSE;
    END IF;

    IF P_SOURCE <> 'FLEXCUBE' THEN
      IF P_ACTION_CODE = 'DELETE' THEN

        BEGIN
          DBG('Contract Ref No:' ||
              P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
          SELECT BRANCH
            INTO L_BRANCH
            FROM CSTBS_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('**', 'Failed in Select of Cstb_Contract');
            DEBUG.PR_DEBUG('**', SQLERRM);
            P_ERR_CODE   := 'ST-OTHR-001';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

        END;

        IF L_BRANCH <> GLOBAL.CURRENT_BRANCH THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-090', '');
          RETURN FALSE;
        END IF;

      END IF;

    END IF;

    G_ACTION_CODE      := P_ACTION_CODE;
    G_CALLING_FUNCTION := P_FUNCTION_ID;

    IF SUBSTR(P_ACTION_CODE, 1, LENGTH(CSPKS_REQ_GLOBAL.P_ENRICH)) =
       CSPKS_REQ_GLOBAL.P_ENRICH THEN
      P_ACTION_CODE := SUBSTR(P_ACTION_CODE,
                              LENGTH(CSPKS_REQ_GLOBAL.P_ENRICH) + 2);

    ELSIF SUBSTR(P_ACTION_CODE, 1, LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) =
          CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP THEN
      P_ACTION_CODE := SUBSTR(P_ACTION_CODE,
                              LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP) + 2);

    END IF;

    L_FCC_REF  := P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    L_EXT_REF  := P_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO;
    L_USER_REF := P_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO;

    SELECT COUNT(*)
      INTO L_UPCOUNT
      FROM MSTBS_DLY_MSG_IN
     WHERE GENERATED_REF_NO IN
           (P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
            P_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO);

    DBG('l_upcount' || L_UPCOUNT);

    IF (SUBSTR(P_ACTION_CODE, 1, LENGTH(CSPKS_REQ_GLOBAL.P_ENRICH)) <>
       CSPKS_REQ_GLOBAL.P_ENRICH) AND
       P_ACTION_CODE NOT IN
       (CSPKS_REQ_GLOBAL.P_PRDDFLT, 'DEFAULTDOC', 'POPULATELIMIT') THEN
      DBG('l_Fcc_Ref' || L_FCC_REF);
      BEGIN
        SELECT *
          INTO L_CONT_REC
          FROM CSTB_CONTRACT
         WHERE CONTRACT_REF_NO = L_FCC_REF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('No Data Found in Cstbs_Contract For Reference :' ||
              L_FCC_REF);
          L_CONT_EXISTS := FALSE;

      END;

      IF L_CONT_EXISTS THEN
        BEGIN
          SELECT *
            INTO L_LOG_REC
            FROM CSTB_CONTRACT_EVENT_LOG
           WHERE CONTRACT_REF_NO = L_FCC_REF
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM CSTB_CONTRACT_EVENT_LOG
                   WHERE CONTRACT_REF_NO = L_FCC_REF);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('No Data Found in Cstbs_Contract_Event_Log For Reference :' ||
                L_FCC_REF);

        END;

        SELECT COUNT(*)
          INTO L_AUTH_COUNT
          FROM CSTB_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO = L_FCC_REF
           AND AUTH_STATUS = 'A';

      END IF;

      BEGIN
        SELECT FIN_FLAG
          INTO L_FIN_FLAG
          FROM LCTB_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO = L_FCC_REF
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTB_CONTRACT_MASTER
                 WHERE CONTRACT_REF_NO = L_FCC_REF);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed....');

      END;

      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_MODIFY, CSPKS_REQ_GLOBAL.P_DELETE) AND
         L_CONT_REC.AUTH_STATUS = 'U'

         AND L_LOG_REC.EVENT_CODE IN ('GCLM', 'GCAM', 'GCLR', 'GCLP')

       THEN
        SELECT COUNT(*)
          INTO L_GUARANTEE_COUNT
          FROM LCTBS_GUARANTEE_CLAIM
         WHERE CONTRACT_REF_NO =
               P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        IF L_GUARANTEE_COUNT > 0 THEN
          DEBUG.PR_DEBUG('**',
                         'Claims logged for this Guarantee contract.Cannot unlock/delete this contract');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-CLM-016', NULL);
          RETURN FALSE;
        END IF;

      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_ROLLOVER AND
         NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE, 'XXX') =
         'PAD' THEN
        DBG('Operation Code came as :' ||
            P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
        P_ERR_CODE   := 'LC-VALS-409';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
        IF L_CONT_EXISTS THEN
          IF NVL(L_CONT_REC.CONTRACT_STATUS, 'A') <> 'H' THEN
            IF L_CONT_REC.CONTRACT_REF_NO IS NOT NULL THEN
              DBG('Contract Already Exists..');
              P_ERR_CODE   := 'LC-VALS-078';
              P_ERR_PARAMS := NULL;
              RETURN FALSE;
            END IF;

            IF L_EXT_REF IS NOT NULL THEN
              SELECT COUNT(*)
                INTO L_COUNT
                FROM CSTB_CONTRACT
               WHERE SOURCE = P_SOURCE
                 AND EXTERNAL_REF_NO = L_EXT_REF;

              IF L_COUNT > 0 THEN
                DBG('Duplicate External Reference number');
                P_ERR_CODE   := 'LD-C0402';
                P_ERR_PARAMS := L_EXT_REF;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LD-C0402',
                             L_EXT_REF);
              END IF;

            END IF;

          END IF;

        END IF;

      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_HOLD THEN
        IF L_CONT_EXISTS THEN

          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            DEBUG.PR_DEBUG('IS',
                           'Calling lcpks_lcdtronl_utils_cluster.Fn_Unlock');

            L_FN_CALL_ID      := 1;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            IF NOT
                LCPKS_LCDTRONL_UTILS_CLUSTER.FN_UNLOCK(P_SOURCE,
                                                       P_FUNCTION_ID,
                                                       P_ACTION_CODE,
                                                       P_LCDTRONL,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
              DEBUG.PR_DEBUG('IS',
                             'Failed in lcpks_lcdtronl_utils_cluster.Fn_Unlock');
              RETURN FALSE;
            END IF;
          END IF;
          IF NOT GLOBAL.G_SKIP_KERNEL THEN

            IF L_CONT_REC.SOURCE <> 'FCAT' THEN

              IF NVL(L_LOG_REC.MAKER_ID, GLOBAL.USER_ID) <> GLOBAL.USER_ID AND
                 L_UPCOUNT = 0 THEN

                P_ERR_CODE   := 'LC-VALS-047';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;
              END IF;

            END IF;

          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;

          IF L_AUTH_COUNT > 0 THEN
            DBG('Contract is AUthorized and hence Cannot be Put on Hold..');

            P_ERR_CODE := 'LC-VALS-504';

            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

        END IF;

      ELSE
        IF L_CONT_REC.CONTRACT_REF_NO IS NULL THEN
          DBG('p_Action_Code' || P_ACTION_CODE);
          DBG('Contract Not Found..');
          P_ERR_CODE   := 'LC-VALS-107';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

          DBG('l_Cont_Rec.SOURCE :: ' || L_CONT_REC.SOURCE);
          IF L_CONT_REC.SOURCE <> 'FCAT' THEN

            IF NVL(L_CONT_REC.AUTH_STATUS, 'U') <> 'A' AND
               L_CONT_REC.CONTRACT_STATUS <> 'H' THEN

              IF NVL(L_LOG_REC.MAKER_ID, '*') <> GLOBAL.USER_ID AND
                 L_UPCOUNT = 0 THEN

                DBG('Only maker can modify the contract..');
                P_ERR_CODE   := 'LC-VALS-111';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;
              ELSE
                DBG('Maker and the user are the same hence can modify the rec');

              END IF;

            END IF;
          END IF;

          SELECT COUNT(*)
            INTO L_COUNT
            FROM LCTBS_AMND_VALS_MASTER
           WHERE CONTRACT_REF_NO = L_CONT_REC.CONTRACT_REF_NO

             AND AMND_STATUS = 'U'
             AND AMND_SEQ_NO IN
                 (SELECT EVENT_SEQ_NO
                    FROM CSTB_CONTRACT_EVENT_LOG
                   WHERE CONTRACT_REF_NO = L_CONT_REC.CONTRACT_REF_NO
                     AND AUTH_STATUS = 'U');

          IF L_COUNT <> 0 THEN

            P_ERR_CODE   := 'LCUPLD-112';
            P_ERR_PARAMS := NULL;

            RETURN FALSE;
          END IF;

          SELECT COUNT(*)
            INTO L_COUNT
            FROM CSTB_CONTRACT_EVENT_LOG
           WHERE CONTRACT_REF_NO = L_CONT_REC.CONTRACT_REF_NO
             AND AUTH_STATUS = 'U'
             AND EVENT_CODE IN ('BKSG', 'CASG');
          DBG('l_unauth_sg_count' || L_COUNT);
          IF L_COUNT <> 0 THEN
            P_ERR_CODE   := 'LC-AMND-011';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

        ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
          SELECT SOURCE
            INTO L_SOURCE1
            FROM CSTB_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

          DBG('l_Log_Rec.Maker_Id' || L_LOG_REC.MAKER_ID);
          IF NVL(L_LOG_REC.MAKER_ID, '*') <> GLOBAL.USER_ID AND
             L_SOURCE1 <> 'FCAT' THEN
            DBG('Only Maker Can Delete The Contract..');
            P_ERR_CODE   := 'LC-VALS-007';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

          IF NVL(L_CONT_REC.AUTH_STATUS, '*') <> 'U' THEN

            DBG('Transaction Is Not In Un Auth State..');
            P_ERR_CODE   := 'LC-VALS-008';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

          DBG('Calling Ldpkss_Link.fn_delete_LC_sg_linkage..event_code... ' ||
              P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE);
          IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL AND
             L_PRODUCT_TYPE = 'H' AND
             P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE = 'BISS' THEN
            DBG('Calling Ldpkss_Link.fn_delete_LC_sg_linkage..... ');
            IF NOT LDPKSS_LINK.FN_DELETE_LC_SG_LINKAGE(P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN

              DBG('Ldpkss_Link.fn_delete_LC_sg_linkage..');
              RETURN FALSE;
            END IF;

          END IF;

        ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE

              AND (P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 <> 'LCDAMEND' AND
              L_CONT_REC.CURR_EVENT_CODE = 'CANC')

         THEN
          IF L_CONT_REC.AUTH_STATUS <> 'A' THEN
            DBG('Contract is not in Authorized State..');
            P_ERR_CODE   := 'LCUPLD-204';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

          IF L_CONT_REC.CONTRACT_STATUS IN ('K', 'S') THEN

            DBG('Contract status is not in C or S..');
            P_ERR_CODE   := 'LCUPLD-205';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

        ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
          IF L_CONT_REC.AUTH_STATUS <> 'A' THEN
            DBG('Contract is not in Authorized State..');
            P_ERR_CODE   := 'LCUPLD-205';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

          IF L_CONT_REC.CONTRACT_STATUS NOT IN ('C', 'S') THEN

            DBG('Contract status is in C or S..');
            P_ERR_CODE   := 'LCUPLD-205';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

        ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_ROLLOVER THEN
          IF L_CONT_REC.AUTH_STATUS <> 'A' THEN
            DBG('Contract is not in Authorized State..');
            P_ERR_CODE   := 'LCUPLD-204';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

          IF L_CONT_REC.CONTRACT_STATUS <> 'A' THEN

            DBG('Contract is not in Authorized State..');
            P_ERR_CODE   := 'OT-EXR-001';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

        ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REVERSE THEN
          IF L_CONT_REC.AUTH_STATUS <> 'A' THEN
            DBG('Contract is not in Authorized State..');
            P_ERR_CODE   := 'LCUPLD-204';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

          IF L_CONT_REC.CONTRACT_STATUS NOT IN ('A') THEN

            DBG('Contract status is not in A..');
            P_ERR_CODE   := 'LCUPLD-213';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

        ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
          IF NVL(L_LOG_REC.MAKER_ID, '*') = GLOBAL.USER_ID THEN
            DBG(' Maker Cannot Authorize the Contract..');
            P_ERR_CODE   := 'LC-VALS-108';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

          IF NVL(L_CONT_REC.AUTH_STATUS, '*') = 'A' THEN

            DBG('Transaction Is Not In Un AUth State..');
            P_ERR_CODE   := 'LC-VALS-109';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

        END IF;

      END IF;

      IF L_CONT_EXISTS THEN

        DBG('p_Action_Code' || P_ACTION_CODE);
        IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY,
                             CSPKS_REQ_GLOBAL.P_HOLD,
                             CSPKS_REQ_GLOBAL.P_NEW) THEN
          L_FCC_REF  := P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          L_EXT_REF  := P_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO;
          L_USER_REF := P_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO;
          L_SOURCE   := NVL(P_LCDTRONL.V_CSTBS_CONTRACT.SOURCE, P_SOURCE);

          IF L_AUTH_COUNT = 0 THEN
            DBG('Not Authorized so far...');
            IF P_ACTION_CODE <> 'HOLD' THEN

              P_ACTION_CODE := 'NEW';
            END IF;

            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              DEBUG.PR_DEBUG('IS',
                             'Calling lcpks_lcdtronl_utils_cluster.Fn_Unlock');
              L_FN_CALL_ID      := 2;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              IF NOT
                  LCPKS_LCDTRONL_UTILS_CLUSTER.FN_UNLOCK(P_SOURCE,
                                                         P_FUNCTION_ID,
                                                         P_ACTION_CODE,
                                                         P_LCDTRONL,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA) THEN
                DEBUG.PR_DEBUG('IS',
                               'Failed in lcpks_lcdtronl_utils_cluster.Fn_Unlock');
                RETURN FALSE;
              END IF;
            END IF;
            IF NOT GLOBAL.G_SKIP_KERNEL THEN

              IF L_LOG_REC.MAKER_ID <> GLOBAL.USER_ID AND
                 P_LCDTRONL.V_CSTBS_CONTRACT.SOURCE <> 'FCAT' AND
                 L_UPCOUNT = 0 THEN
                P_ERR_CODE   := 'LC-VALS-047';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;
              ELSE

                IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL AND
                   L_PRODUCT_TYPE = 'H' AND
                   P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE = 'BISS' THEN
                  DBG('Calling Ldpkss_Link.fn_delete_LC_sg_linkage..... ');
                  IF NOT
                      LDPKSS_LINK.FN_DELETE_LC_SG_LINKAGE(P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN

                    DBG('Ldpkss_Link.fn_delete_LC_sg_linkage..');
                    RETURN FALSE;
                  END IF;

                END IF;

                DBG('entering draft details loop for open policy');
                FOR DRAFT IN C_DRAFTS LOOP
                  L_POLICY_NUMBER := DRAFT.INSURANCE_POLICY_NO;
                  IF L_POLICY_NUMBER IS NOT NULL THEN
                    IF NOT
                        LCPKSS_UPLOAD_UTILS.FN_UPDATE_POL_UTIL_AMT(L_POLICY_NUMBER,
                                                                   P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                                   'MINUS',
                                                                   P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                                                                   P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAMS) THEN
                      DEBUG.PR_DEBUG('LC',
                                     'Failed to update utilization amount');
                    END IF;

                  END IF;

                END LOOP;

                DBG('This For The Firsttime Unauth...');
                DBG('Callling Lcpkss_Server.Fn_Unlockcontract..');
                IF NOT LCPKS_SERVER.FN_UNLOCKCONTRACT(GLOBAL.USER_ID,
                                                      L_CONT_REC.CONTRACT_REF_NO,
                                                      L_CONT_REC.LATEST_VERSION_NO,
                                                      L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                      L_CONT_REC.CURR_EVENT_CODE,
                                                      L_CUR_APP_DATETIME,
                                                      TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                              'DD-MON-YY'),
                                                      L_CONT_REC.CONTRACT_STATUS,
                                                      L_CONT_REC.AUTH_STATUS,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS)

                 THEN
                  DBG('Failed in Lcpkss_Server.Fn_Unlockcontract');
                  RETURN FALSE;
                END IF;

                L_CONT_REC.CONTRACT_STATUS := 'A';
                L_CONT_REC.AUTH_STATUS     := 'U';

                DBG('In Calling Lcpkss_Delete.Fn_Deletecontract..');
                IF NOT LCPKS_DELETE.FN_DELETECONTRACT(GLOBAL.USER_ID,
                                                      L_CONT_REC.CONTRACT_REF_NO,
                                                      L_CONT_REC.LATEST_VERSION_NO,
                                                      L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                      L_CONT_REC.CURR_EVENT_CODE,
                                                      FN_MNTSTAMP,
                                                      GLOBAL.APPLICATION_DATE,
                                                      'Y',
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
                  DBG('Failed in Lcpkss_Delete.Fn_Deletecontract..');
                  RETURN FALSE;
                ELSE
                  DBG('Lmpkss_Collat.Fn_Revert_Collateral_Amendment');
                  IF NOT
                      LMPKSS_COLLAT.FN_REVERT_COLLATERAL_AMENDMENT(L_CONT_REC.COUNTERPARTY,
                                                                   L_CONT_REC.CONTRACT_REF_NO,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAMS) THEN

                    DBG('Failed in Lmpkss_Collat.Fn_Revert_Collateral_Amendment..');
                    RETURN FALSE;
                  END IF;

                END IF;

              END IF;

            ELSE
              GLOBAL.PR_RESET_SKIP_KERNEL;
            END IF;

          ELSE

            DBG('Authorized atleast once ... ');
            DBG('Now in the unauth state...');
            DBG('l_Log_Rec.Contract_Status :' || L_LOG_REC.CONTRACT_STATUS);
            DBG('l_Log_Rec.Auth_Status :' || L_LOG_REC.AUTH_STATUS);

            IF L_LOG_REC.AUTH_STATUS = 'U' THEN

              DBG(' p_Lcdtronl.v_Cstbs_Contract.SOURCE :: ' ||
                  P_LCDTRONL.V_CSTBS_CONTRACT.SOURCE);
              IF L_LOG_REC.MAKER_ID != GLOBAL.USER_ID AND L_UPCOUNT = 0 AND
                 P_LCDTRONL.V_CSTBS_CONTRACT.SOURCE <> 'FCAT' THEN

                P_ERR_CODE   := 'LCCON-037';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;
              ELSE
                DBG('Maker and the user are the same');
                DBG('Calling Lcpkss_Delete.Fn_Deletecontract..');
                DBG('l_Log_Rec.Event_Code' || L_LOG_REC.EVENT_CODE);
                DBG('fin_flag' || L_FIN_FLAG);
                DBG('Char_Field1' ||
                    P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1);

                DBG('l_log_rec.event_code-->' || L_LOG_REC.EVENT_CODE);
                IF L_LOG_REC.EVENT_CODE = 'AVAL' THEN
                  DEBUG.PR_DEBUG('**',
                                 'Contract is not authorised..please authorise');
                  P_ERR_CODE   := 'LC-AMND-008';
                  P_ERR_PARAMS := NULL;
                  RETURN FALSE;
                END IF;

                IF NOT LCPKSS_DELETE.FN_DELETECONTRACT(GLOBAL.USER_ID,
                                                       L_CONT_REC.CONTRACT_REF_NO,
                                                       L_CONT_REC.LATEST_VERSION_NO,
                                                       L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                       L_CONT_REC.CURR_EVENT_CODE,
                                                       L_CUR_APP_DATE,
                                                       TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                               'DD-MON-YY'),
                                                       'Y',
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN
                  DBG('Failed in Lcpkss_Delete.Fn_Deletecontract');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               P_ERR_CODE,
                               P_ERR_PARAMS);
                END IF;

              END IF;

              BEGIN
                SELECT *
                  INTO L_CONT_REC
                  FROM CSTB_CONTRACT
                 WHERE CONTRACT_REF_NO = L_FCC_REF;

              EXCEPTION
                WHEN OTHERS THEN
                  DBG('No Data Found in Cstbs_Contract For Reference :' ||
                      L_FCC_REF);

              END;

            END IF;

            IF L_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' THEN

              SELECT COUNT(*)
                INTO L_COUNT
                FROM CSTBS_CONTRACT_EVENT_LOG
               WHERE CONTRACT_REF_NO = L_CONT_REC.CONTRACT_REF_NO
                 AND EVENT_CODE = 'AMND';

              IF L_COUNT = 0 THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-REIS', NULL);
                DBG('Calling Fn_Reissue..');
                IF NOT LCPKSS_SERVER.FN_DUPLICATECONTRACT(L_CONT_REC.CONTRACT_REF_NO,
                                                          L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                          L_CONT_REC.LATEST_VERSION_NO,
                                                          'REIS',
                                                          L_NEW_REFNO,
                                                          L_NEW_ESN,
                                                          L_NEW_VERSION,
                                                          TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                                  'DD-MON-YY'),
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
                  DBG('Failed in Lcpkss_Delete.Fn_Duplicatecontract');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               P_ERR_CODE,
                               P_ERR_PARAMS);
                END IF;

                L_CONT_REC.CONTRACT_STATUS := 'A';
                L_CONT_REC.AUTH_STATUS     := 'U';
              ELSE
                DBG('prod type G and authorised');
                DBG('Calling Lcpkss_Server.Fn_Duplicatecontract..');
                IF P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 NOT IN
                   ('LCDAMEND', 'LIDAMEND') THEN
                  IF NOT LCPKSS_SERVER.FN_DUPLICATECONTRACT(L_CONT_REC.CONTRACT_REF_NO,
                                                            L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                            L_CONT_REC.LATEST_VERSION_NO,
                                                            'AMND',
                                                            L_NEW_REFNO,
                                                            L_NEW_ESN,
                                                            L_NEW_VERSION,
                                                            TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                                    'DD-MON-YY'),
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
                    DBG('Failed in Lcpkss_Server.Fn_Duplicatecontract');
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 P_SOURCE,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
                  END IF;

                END IF;

              END IF;

            ELSE
              DBG('not G and authorised once ');
              DBG('If its authorised once,then we to call the duplicate contract');
              DBG('Calling Lcpkss_Server.Fn_Duplicatecontract..');

              IF NOT LCPKSS_SERVER.FN_DUPLICATECONTRACT(L_CONT_REC.CONTRACT_REF_NO,
                                                        L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                        L_CONT_REC.LATEST_VERSION_NO,
                                                        'AMND',
                                                        L_NEW_REFNO,
                                                        L_NEW_ESN,
                                                        L_NEW_VERSION,
                                                        L_CUR_APP_DATE,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
                DBG('Failed in Lcpkss_Server.Fn_Duplicatecontract');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             P_ERR_CODE,
                             P_ERR_PARAMS);
              END IF;

            END IF;

          END IF;

        ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
          DBG('Calling Lcpkss_Server.Fn_Duplicatecontract..In Reopen');
          DBG('l_cont_rec.latest_version_no ' ||
              L_CONT_REC.LATEST_VERSION_NO);
          DBG('l_cont_rec.latest_event_seq_no ' ||
              L_CONT_REC.LATEST_EVENT_SEQ_NO);
          IF NOT LCPKSS_SERVER.FN_DUPLICATECONTRACT(L_CONT_REC.CONTRACT_REF_NO,
                                                    L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                    L_CONT_REC.LATEST_VERSION_NO,
                                                    'ROPN',
                                                    L_NEW_REFNO,
                                                    L_NEW_ESN,
                                                    L_NEW_VERSION,
                                                    L_CUR_APP_DATE,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
            DBG('Failed in Lcpkss_Server.Fn_Duplicatecontract');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          END IF;

          BEGIN
            DBG('Before updating master record' ||
                P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT ||
                P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
            UPDATE LCTB_CONTRACT_MASTER
               SET CONTRACT_AMT = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                   EXPIRY_DATE  = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE
             WHERE CONTRACT_REF_NO =
                   P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
               AND VERSION_NO =
                   (SELECT MAX(VERSION_NO)
                      FROM LCTB_CONTRACT_MASTER
                     WHERE CONTRACT_REF_NO =
                           P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed while updating master record' || SQLERRM);
              NULL;

          END;

        ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_ROLLOVER) THEN

          DBG('Calling Lcpkss_Server.Fn_Duplicatecontract for Roll Over..');
          IF NOT LCPKSS_SERVER.FN_DUPLICATECONTRACT(L_CONT_REC.CONTRACT_REF_NO,
                                                    L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                    L_CONT_REC.LATEST_VERSION_NO,
                                                    'REIN',
                                                    L_NEW_REFNO,
                                                    L_NEW_ESN,
                                                    L_NEW_VERSION,
                                                    L_CUR_APP_DATE,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
            DBG('Failed in Lcpkss_Server.Fn_Duplicatecontract');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

          END IF;

          BEGIN
            SELECT *
              INTO L_LCTBS_AVAILMENTS
              FROM LCTBS_AVAILMENTS
             WHERE CONTRACT_REF_NO =
                   P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
               AND EVENT_SEQ_NO =
                   (SELECT MAX(LATEST_EVENT_SEQ_NO)
                      FROM CSTBS_CONTRACT
                     WHERE CONTRACT_REF_NO =
                           P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Failed to fetch');

              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-105', NULL);
            WHEN OTHERS THEN
              DBG('Failed to fetch');

              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-105', NULL);

          END;

          IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE = 'A' THEN

            IF NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE, 'X') = 'C' THEN

              L_NEW_OS_LIAB := L_LCTBS_AVAILMENTS.OS_LIABILITY;

            ELSIF NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE, 'X') = 'N' THEN

              L_NEW_CURR_AVL := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT;
              L_NEW_OS_LIAB  := L_LCTBS_AVAILMENTS.OS_LIABILITY -
                                L_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;

            END IF;

          ELSIF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE = 'M' THEN
            IF NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE, 'X') = 'C' THEN

              L_NEW_CURR_AVL     := L_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY +
                                    P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT;
              L_NEW_OS_LIAB      := L_LCTBS_AVAILMENTS.OS_LIABILITY +
                                    P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT;
              L_NEW_AVL_CNF_AMT  := NVL(L_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT,
                                        0) + NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                                                 0);
              L_NEW_REIM_UND_AMT := NVL(L_LCTBS_AVAILMENTS.AVAILABLE_UNDERTAKING_AMOUNT,
                                        0) + NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                                                 0);

              L_NEW_AVL_UNCNF_AMT := NVL(L_LCTBS_AVAILMENTS.AVAILABLE_UNCONFIRMED_AMT,
                                         0) + NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNCONFIRM_AMOUNT,
                                                  0);

            ELSIF NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE, 'X') = 'N' THEN
              L_NEW_CURR_AVL     := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT;
              L_NEW_OS_LIAB      := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT;
              L_NEW_AVL_CNF_AMT  := NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                                        0);
              L_NEW_REIM_UND_AMT := NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                                        0);

              L_NEW_AVL_UNCNF_AMT := NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNCONFIRM_AMOUNT,
                                         0);

            END IF;

            L_BOOL := CYPKSS.FN_AMT_ROUND(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                          L_NEW_AVL_CNF_AMT,
                                          L_RND_AVL_CNF_AMT);
            IF L_BOOL = FALSE THEN
              DEBUG.PR_DEBUG('LC',
                             'Fn Unlock Failed To Round NewAvlCnfAmt ');
              RETURN FALSE;
            END IF;

            L_BOOL := CYPKSS.FN_AMT_ROUND(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                          L_NEW_REIM_UND_AMT,
                                          L_RND_REIM_UND_AMT);
            IF L_BOOL = FALSE THEN
              DEBUG.PR_DEBUG('LC',
                             'Fn Unlock Failed To Round NewAvlUndrAmt ');
              RETURN FALSE;
            END IF;

          END IF;

          IF NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS, 'X') = 'M' THEN
            L_NEW_REIN_DATE := ADD_MONTHS(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE,
                                          P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY);
          ELSIF NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS, 'X') = 'D' THEN
            L_NEW_REIN_DATE := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE +
                               P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY;

          END IF;

          UPDATE LCTBS_AVAILMENTS
             SET CURRENT_AVAILABILITY = NVL(L_NEW_CURR_AVL,
                                            CURRENT_AVAILABILITY),
                 OS_LIABILITY         = NVL(L_NEW_OS_LIAB, OS_LIABILITY),

                 AVAILABLE_CONFIRMED_AMT      = NVL(L_RND_AVL_CNF_AMT,
                                                    AVAILABLE_CONFIRMED_AMT),
                 AVAILABLE_UNDERTAKING_AMOUNT = NVL(L_RND_REIM_UND_AMT,
                                                    AVAILABLE_UNDERTAKING_AMOUNT)

                ,
                 AVAILABLE_UNCONFIRMED_AMT = NVL(L_NEW_AVL_UNCNF_AMT,
                                                 AVAILABLE_UNCONFIRMED_AMT)

           WHERE CONTRACT_REF_NO =
                 P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO = L_NEW_ESN;

          IF SQL%ROWCOUNT = 0 THEN
            DBG('failed to update');
          END IF;

          DBG('lctbs_contract_master' ||
              P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
          UPDATE LCTBS_CONTRACT_MASTER
             SET NEXT_REINSTATEMENT_DATE = L_NEW_REIN_DATE
           WHERE CONTRACT_REF_NO =
                 P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO = L_NEW_ESN;

          IF SQL%ROWCOUNT = 0 THEN
            DBG('failed to update');
          END IF;

        ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_CLOSE) THEN
          DBG('event_code_current' ||
              P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91);
          DBG('event_code_current22' ||
              P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE);
          DBG('l_cont_rec.latest_version_no ' ||
              L_CONT_REC.LATEST_VERSION_NO);
          DBG('l_cont_rec.latest_event_seq_no ' ||
              L_CONT_REC.LATEST_EVENT_SEQ_NO);

          IF NOT LCPKSS_SERVER.FN_DUPLICATECONTRACT(L_CONT_REC.CONTRACT_REF_NO,
                                                    L_CONT_REC.LATEST_EVENT_SEQ_NO,
                                                    L_CONT_REC.LATEST_VERSION_NO,
                                                    NVL(P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91,
                                                        'CLOS'),
                                                    L_NEW_REFNO,
                                                    L_NEW_ESN,
                                                    L_NEW_VERSION,
                                                    L_CUR_APP_DATE,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
            DBG('Failed in Lcpkss_Server.Fn_Duplicatecontract');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          END IF;

        END IF;

        BEGIN
          SELECT LATEST_VERSION_NO, LATEST_EVENT_SEQ_NO
            INTO L_VERNO, L_ESN

            FROM CSTBS_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Selecting the version no');

        END;

        DBG('l_verno' || L_VERNO);
        DBG('l_esn' || L_ESN);

      END IF;

    END IF;

    DBG('Returning True From Fn_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Fn_Unlock..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_UNLOCK;

  FUNCTION FN_FORM_MSG(P_ERR_CODE   IN VARCHAR2,
                       P_ERR_PARAMS IN VARCHAR2,
                       P_LANG_CODE  IN SMTBS_LANGUAGE.LANG_CODE%TYPE,
                       P_CONF       OUT VARCHAR2) RETURN VARCHAR2 IS

    I         INTEGER;
    L_TYPE    CHAR(1);
    L_CONF    CHAR(1);
    L_FORMULA ERTBS_MSGS.DERIVED_MSG%TYPE;
    L_MSG     ERTBS_MSGS.MESSAGE%TYPE;
    L_PARAM   VARCHAR2(32767);

  BEGIN
    DBG('Inside Fn_Form_Msg..' || P_ERR_CODE || '::' || P_ERR_PARAMS || '::' ||
        P_LANG_CODE || '::' || P_CONF);
    IF NOT OVPKSS.FN_GETMSGANDTYPE(P_ERR_CODE,
                                   P_LANG_CODE,
                                   L_MSG,
                                   L_TYPE,
                                   L_CONF,
                                   L_FORMULA) THEN
      L_MSG := 'Missing Error Code ' || P_ERR_CODE;
    ELSE
      I       := 1;
      L_PARAM := CSPKES_MISC.FN_GETPARAM(P_ERR_PARAMS, I, '~');
      WHILE (L_PARAM <> 'EOPL') LOOP

        L_MSG   := REPLACE(L_MSG, '$' || I, L_PARAM);
        I       := I + 1;
        L_PARAM := CSPKES_MISC.FN_GETPARAM(P_ERR_PARAMS, I, '~');
      END LOOP;

    END IF;

    DBG('Returning true from Fn_Form_Msg.. ');
    P_CONF := L_CONF;
    RETURN L_MSG;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of Ftpks_Fcj_FtdConon.Fn_Form_Msg');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN 'Missing Error Code ' || P_ERR_CODE;

  END FN_FORM_MSG;

  FUNCTION FN_PICKUP_ADVICES(P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_ACTION_CODE    IN VARCHAR2,
                             P_FUNCTION_ID    IN VARCHAR2,
                             P_PRODUCT        IN VARCHAR2,
                             P_FCC_REF        IN VARCHAR2,
                             P_EVENT_SEQ_NO   IN CSTB_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE,
                             P_LATEST_VERSION IN NUMBER,
                             P_EVENT          IN CSTB_CONTRACT.CURR_EVENT_CODE%TYPE,
                             P_COUNTERPARTY   IN VARCHAR2,
                             P_ERR_CODE       IN OUT VARCHAR2,
                             P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_CSTBS_CONTRACT_EVENT_ADVICE CSTBS_CONTRACT_EVENT_ADVICE%ROWTYPE;

    CURSOR C_EVENT_ADVICES IS
      SELECT *
        FROM CSTBS_CONTRACT_EVENT_ADVICE
       WHERE CONTRACT_REF_NO = P_FCC_REF
         AND EVENT_SEQ_NO = P_EVENT_SEQ_NO;

    L_PARTY     VARCHAR2(20);
    L_ADV_COUNT NUMBER;
    L_MODULE    SMTB_MENU.MODULE%TYPE;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN

    DBG('In Function Fn_Pickup_Advices...');

    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;

    END;

    DELETE CSTBS_CONTRACT_EVENT_ADVICE
     WHERE CONTRACT_REF_NO = P_FCC_REF
       AND EVENT_SEQ_NO = P_EVENT_SEQ_NO;

    BEGIN
      SELECT COUNT(*)
        INTO L_ADV_COUNT
        FROM CSTBS_CONTRACT_EVENT_ADVICE
       WHERE CONTRACT_REF_NO = P_FCC_REF
         AND EVENT_SEQ_NO = P_EVENT_SEQ_NO;

      INSERT INTO CSTBS_CONTRACT_EVENT_ADVICE
        (CONTRACT_REF_NO,
         EVENT_SEQ_NO,
         MSG_TYPE,
         SUPPRESS,
         PRIORITY,
         MODULE,
         ADDRESS_LINE1,
         ADDRESS_LINE2,
         ADDRESS_LINE3,
         ADDRESS_LINE4,
         PARTY_TYPE,
         MEDIUM,
         CHG_REQD)
        SELECT P_FCC_REF,
               P_EVENT_SEQ_NO,
               P.MSG_TYPE,
               P.SUPPRESS,
               P.PRIORITY,
               L_MODULE,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               NULL,
               NVL(P.CHG_REQD, 'N')
          FROM CSTMS_PRODUCT_EVENT_ADVICE P
         WHERE P.PRODUCT_CODE = P_PRODUCT
           AND P.EVENT_CODE = P_EVENT;

      SELECT COUNT(*)
        INTO L_ADV_COUNT
        FROM CSTBS_CONTRACT_EVENT_ADVICE
       WHERE CONTRACT_REF_NO = P_FCC_REF
         AND EVENT_SEQ_NO = P_EVENT_SEQ_NO;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in Populating event Advice..');
        DBG(SQLERRM);
        RETURN FALSE;

    END;

    IF P_EVENT = 'AVAL' THEN

      FOR REC IN C_EVENT_ADVICES LOOP
        IF REC.MSG_TYPE IN ('PAYMENT_MESSAGE', 'RECEIVE_NOTICE') THEN
          L_PARTY := NULL;
        ELSE
          L_PARTY := P_COUNTERPARTY;

        END IF;

        UPDATE CSTBS_CONTRACT_EVENT_ADVICE
           SET PARTY_TYPE = L_PARTY
         WHERE CONTRACT_REF_NO = P_FCC_REF
           AND MSG_TYPE = REC.MSG_TYPE
           AND EVENT_SEQ_NO = P_EVENT_SEQ_NO;

      END LOOP;

    ELSE

      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;
        IF NOT
            LCPKS_LCDTRONL_UTILS_CLUSTER.FN_PICKUP_ADVICES(P_SOURCE,
                                                           P_ACTION_CODE,
                                                           P_FUNCTION_ID,
                                                           P_PRODUCT,
                                                           P_FCC_REF,
                                                           P_EVENT_SEQ_NO,
                                                           P_LATEST_VERSION,
                                                           P_EVENT,
                                                           P_COUNTERPARTY,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA) THEN
          DEBUG.PR_DEBUG('LC',
                         'Call to lcpks_lcdtronl_utils_cluster.Fn_Pickup_Advices failed');
        END IF;
      END IF;

      IF NOT GLOBAL.G_SKIP_KERNEL THEN

        DBG('Calling Lcpkss_Mesg.Fn_Setadviceparties');
        IF NOT LCPKS_MESG.FN_SETADVICEPARTIES(P_FCC_REF,
                                              P_EVENT_SEQ_NO,
                                              P_EVENT,
                                              P_PRODUCT) THEN
          DBG('Failed in Lcpkss_Mesg.Fn_Setadviceparties.. ');
          RETURN FALSE;
        END IF;

      ELSE
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;

      SELECT COUNT(*)
        INTO L_ADV_COUNT
        FROM CSTBS_CONTRACT_EVENT_ADVICE
       WHERE CONTRACT_REF_NO = P_FCC_REF
         AND EVENT_SEQ_NO = P_EVENT_SEQ_NO;

    END IF;

    DBG('Calling Lcpkss_Common.Fn_Getdefaultffts');
    IF NOT LCPKSS_COMMON.FN_GETDEFAULTFFTS(P_FCC_REF,
                                           P_LATEST_VERSION,
                                           P_EVENT_SEQ_NO,
                                           P_EVENT,
                                           P_PRODUCT,
                                           P_SOURCE) THEN
      DBG('Failed in Lcpkss_Common.Fn_Getdefaultffts..');
      RETURN FALSE;
    END IF;

    SELECT COUNT(*)
      INTO L_ADV_COUNT
      FROM CSTBS_CONTRACT_EVENT_ADVICE
     WHERE CONTRACT_REF_NO = P_FCC_REF
       AND EVENT_SEQ_NO = P_EVENT_SEQ_NO;

    OPEN C_EVENT_ADVICES;
    LOOP
      FETCH C_EVENT_ADVICES
        INTO L_CSTBS_CONTRACT_EVENT_ADVICE;

      EXIT WHEN C_EVENT_ADVICES%NOTFOUND;

    END LOOP;

    DBG('Returning true from the Fn_Pickup_Advices');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When others of Fn_Pickup_Advices');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_PICKUP_ADVICES;

  FUNCTION FN_UPLOAD_ADVICES(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_FUNCTION_ID  IN VARCHAR2,
                             P_ACTION_CODE  IN VARCHAR2,
                             P_FCC_REF      IN VARCHAR2,
                             P_EVENT_SEQ_NO IN CSTB_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE,
                             P_ADVICES      IN LCPKS_LCDTRONL_MAIN.TY_TB_V_CONTRACT_EVENT_ADVICE,
                             P_ERR_CODE     IN OUT VARCHAR2,
                             P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS

    CURSOR C_EVENT_ADVICES IS
      SELECT *
        FROM CSTBS_CONTRACT_EVENT_ADVICE
       WHERE CONTRACT_REF_NO = P_FCC_REF
         AND EVENT_SEQ_NO = P_EVENT_SEQ_NO;

    L_PICKEDUP_ADVICES LCPKS_LCDTRONL_MAIN.TY_TB_V_CONTRACT_EVENT_ADVICE;
    L_PICKEDUP_COUNT   NUMBER := 0;
    L_MATCHED_REC      NUMBER := 0;
    L_COUNT            NUMBER := 0;
    L_MSG_FOUND        BOOLEAN := FALSE;
    L_TAB_DATA         NUMBER := 0;

  BEGIN
    DBG('In advices' || P_EVENT_SEQ_NO);
    OPEN C_EVENT_ADVICES;
    LOOP
      FETCH C_EVENT_ADVICES BULK COLLECT
        INTO L_PICKEDUP_ADVICES;
      EXIT WHEN C_EVENT_ADVICES%NOTFOUND;
    END LOOP;

    CLOSE C_EVENT_ADVICES;

    L_PICKEDUP_COUNT := L_PICKEDUP_ADVICES.COUNT;
    L_COUNT          := P_ADVICES.COUNT;
    DBG('l_Pickedup_Count' || L_PICKEDUP_COUNT);
    DBG('l_Count' || L_COUNT);
    IF L_COUNT > 0 THEN
      FOR I IN 1 .. L_COUNT LOOP

        L_MSG_FOUND := FALSE;
        IF L_PICKEDUP_COUNT > 0 THEN
          FOR J IN 1 .. L_PICKEDUP_COUNT LOOP
            IF P_ADVICES(I).MSG_TYPE = L_PICKEDUP_ADVICES(J).MSG_TYPE THEN
              L_MATCHED_REC := J;
              L_MSG_FOUND   := TRUE;

              IF P_ADVICES(I).PARTY_ID = L_PICKEDUP_ADVICES(J).PARTY_ID THEN
                L_TAB_DATA := 0;
              ELSE
                L_TAB_DATA := 1;

              END IF;

              EXIT;
            END IF;

          END LOOP;

        ELSE
          L_MSG_FOUND := FALSE;

        END IF;

        IF NOT L_MSG_FOUND THEN
          DBG('Invalid message..');

        ELSE
          UPDATE CSTB_CONTRACT_EVENT_ADVICE
             SET SUPPRESS = NVL(P_ADVICES         (I).SUPPRESS,
                                L_PICKEDUP_ADVICES(L_MATCHED_REC).SUPPRESS),
                 PRIORITY = NVL(P_ADVICES         (I).PRIORITY,
                                L_PICKEDUP_ADVICES(L_MATCHED_REC).PRIORITY),

                 MEDIUM = DECODE(L_TAB_DATA,
                                 1,
                                 L_PICKEDUP_ADVICES(L_MATCHED_REC).MEDIUM,
                                 P_ADVICES         (I).MEDIUM),

                 CHG_REQD = NVL(P_ADVICES         (I).CHG_REQD,
                                L_PICKEDUP_ADVICES(L_MATCHED_REC).CHG_REQD)
           WHERE CONTRACT_REF_NO = P_FCC_REF
             AND EVENT_SEQ_NO = P_EVENT_SEQ_NO
             AND MSG_TYPE = P_ADVICES(I).MSG_TYPE;

        END IF;

      END LOOP;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When others of Fn_Pickup_Advices');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_UPLOAD_ADVICES;

  FUNCTION FN_LOG_OVERRIDES(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                            P_ACTION_CODE  IN VARCHAR2,
                            P_WRK_LCDTRONL IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_FUNCTION_ID  IN VARCHAR2,
                            P_ERR_CODE     IN OUT VARCHAR2,
                            P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_ERROR_CODE      VARCHAR2(255);
    L_ERROR_PARAMETER VARCHAR2(255);
    L_OVD_SEQ_NO      NUMBER := 0;
    L_RUNNING_NO      NUMBER := 0;
    L_TYPE            VARCHAR2(1);
    L_COUNT           NUMBER := 0;
    L_DUP_COUNT       NUMBER;
    L_ESN             CSTB_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE;
    L_VERSION         CSTB_CONTRACT.LATEST_VERSION_NO%TYPE;
    L_OVD_STATUS      CSTBS_CONTRACT_OVD.OVD_STATUS%TYPE;
    L_CONFIRMED       ERTBS_MSGS.CONFIRMATION_REQD%TYPE;
    L_MSG             ERTBS_MSGS.MESSAGE%TYPE;
    L_E_MAIL_OVD      CSTB_PARAM.PARAM_VAL%TYPE;
    L_MODULE          SMTB_MENU.MODULE%TYPE;

    CURSOR OVD_CUR(C_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE,
                   C_LANG     ERTB_MSGS.LANGUAGE%TYPE) IS
      SELECT B.*
        FROM MSTMS_EMAIL_OVD_DETAIL B, MSTMS_EMAIL_OVD A

       WHERE B.OVERRIDE_CODE = C_ERR_CODE
         AND B.LANGUAGE = C_LANG
         AND A.OVERRIDE_CODE = B.OVERRIDE_CODE
         AND A.LANGUAGE = B.LANGUAGE
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O';

  BEGIN
    DBG('In Fn_Insert_Ovd..');

    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;

    END;

    DBG('Selecting Event Seq No ...');
    BEGIN
      SELECT LATEST_EVENT_SEQ_NO, LATEST_VERSION_NO
        INTO L_ESN, L_VERSION

        FROM CSTBS_CONTRACT
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in selection');

    END;

    DBG('p_Wrk_Lcdtronl.v_Cstbs_Contract.Contract_Ref_No' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
    L_ESN := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;

    L_VERSION := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO;

    BEGIN
      SELECT NVL(PARAM_VAL, 'N')
        INTO L_E_MAIL_OVD
        FROM CSTB_PARAM
       WHERE PARAM_NAME = 'E_MAIL_OVD';

    EXCEPTION
      WHEN OTHERS THEN
        L_E_MAIL_OVD := 'N';

    END;

    IF L_ESN IS NULL THEN
      BEGIN
        SELECT MAX(EVENT_SEQ_NO)
          INTO L_ESN
          FROM CSTB_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed While Fetching the Event Seq Number ...');
          DBG(SQLERRM);
          RETURN TRUE;

      END;

    END IF;

    L_COUNT := OVPKS.GL_TBLERROR.COUNT;
    DBG('Insert ovd' || L_COUNT);
    IF L_COUNT > 0 THEN
      FOR I IN OVPKS.GL_TBLERROR.FIRST .. OVPKS.GL_TBLERROR.LAST LOOP
        L_ERROR_CODE      := OVPKS.GL_TBLERROR(I).ERR_CODE;
        L_ERROR_PARAMETER := OVPKS.GL_TBLERROR(I).PARAMS;
        L_TYPE            := OVPKSS.FN_GETTYPE(TRIM(REPLACE(L_ERROR_CODE,
                                                            '~',
                                                            '')));
        IF L_TYPE = 'D' THEN
          L_OVD_STATUS := 'U';
        ELSE
          L_OVD_STATUS := NULL;

        END IF;

        BEGIN
          SELECT COUNT(*)
            INTO L_DUP_COUNT
            FROM CSTB_CONTRACT_OVD
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO = L_ESN

             AND MODULE = L_MODULE

             AND ERR_CODE = L_ERROR_CODE
             AND

                 NVL(LTRIM(RTRIM(PARAMETERS, '~'), '~'), '*') =
                 NVL(LTRIM(RTRIM(L_ERROR_PARAMETER, '~'), '~'), '*');

        EXCEPTION
          WHEN OTHERS THEN
            DBG('failed here...');

        END;

        IF L_TYPE IN ('O', 'A', 'D') AND L_DUP_COUNT = 0 THEN
          IF L_E_MAIL_OVD = 'Y' THEN
            BEGIN
              FOR CUR_DET IN OVD_CUR(L_ERROR_CODE, GLOBAL.LANG) LOOP

                L_RUNNING_NO := L_RUNNING_NO + 1;
                L_MSG        := LCPKS_LCDTRONL_UTILS.FN_FORM_MSG(L_ERROR_CODE,
                                                                 L_ERROR_PARAMETER,
                                                                 GLOBAL.LANG,
                                                                 L_CONFIRMED);
                DBG('Populating Mstbs_Dly_Msg_Out with Running_No:: ' ||
                    L_RUNNING_NO || ' and Message::' || L_MSG);
                INSERT INTO MSTBS_DLY_MSG_OUT
                  (DCN,
                   BRANCH,
                   RUNNING_NO,
                   REFERENCE_NO,
                   ESN,
                   MODULE,
                   MEDIA,
                   LANGUAGE,
                   ADDRESS1,
                   MESSAGE,
                   TOBE_EMAILED,
                   MSG_STATUS,
                   HOLD_STATUS,
                   AUTH_STAT,
                   ONCE_AUTH)
                VALUES
                  (NULL,
                   GLOBAL.CURRENT_BRANCH,
                   L_RUNNING_NO,
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                   L_ESN,
                   L_MODULE,
                   'MAIL',
                   GLOBAL.LANG,
                   CUR_DET.EMAIL_ADDRESS,
                   L_MSG,
                   'Y',
                   'G',
                   'N',
                   'A',
                   'Y');

              END LOOP;

            EXCEPTION
              WHEN OTHERS THEN
                DBG('Exception While populating the Mstbs_Dly_Msg_Out::' ||
                    SQLERRM);
                NULL;

            END;

          END IF;

          L_OVD_SEQ_NO := L_OVD_SEQ_NO + 1;
          DBG('Before inserting first ' || L_ERROR_CODE);
          BEGIN
            INSERT INTO CSTB_CONTRACT_OVD
              (CONTRACT_REF_NO,
               EVENT_SEQ_NO,
               OVD_SEQ_NO,
               MODULE,
               ERR_CODE,
               PARAMETERS,

               OVD_STATUS

              ,
               TXN_BRANCH,
               FUNCTION_ID,
               MAKER_ID

               )

            VALUES
              (P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
               L_ESN,
               L_OVD_SEQ_NO,
               L_MODULE,
               L_ERROR_CODE,
               L_ERROR_PARAMETER,
               L_OVD_STATUS

              ,
               GLOBAL.CURRENT_BRANCH,
               P_FUNCTION_ID,
               GLOBAL.USER_ID

               );

          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              DBG('Its cmg inside...');
              UPDATE CSTB_CONTRACT_OVD
                 SET MODULE     = L_MODULE,
                     ERR_CODE   = L_ERROR_CODE,
                     PARAMETERS = L_ERROR_PARAMETER
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                 AND EVENT_SEQ_NO = L_ESN
                 AND OVD_SEQ_NO = L_OVD_SEQ_NO;

            WHEN OTHERS THEN
              DBG('Others Exception While Populating the Cstb Contrat Ovd ...');
              DBG(SQLERRM);

          END;

          IF NOT
              SMPKS_FCJ_TXNLIMITCHK.FN_LOG_MULTIAUTH_OVD(P_CONTRACT_REF_NO => P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                         P_EVENT_SEQ_NO    => L_ESN) THEN
            DBG('#E#smpks_fcj_txnlimitchk.fn_log_multiauth_ovd' || SQLERRM);
            NULL;
          END IF;

        END IF;

        DBG('inserted the ovd' || L_ERROR_CODE);
      END LOOP;

    END IF;

    DBG('Returning from Fn_Log_Overrides');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Log_Overrides ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_LOG_OVERRIDES;

  FUNCTION FN_CHECK_MANDATORY(P_SOURCE      IN VARCHAR2,
                              P_FUNCTION_ID IN VARCHAR2,
                              P_ACTION_CODE IN VARCHAR2,
                              P_PK_OR_FULL  IN VARCHAR2 DEFAULT 'FULL',
                              P_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_ERR_CODE    IN OUT VARCHAR2,
                              P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_BLK VARCHAR2(50);
    L_FLD VARCHAR2(50);

    L_REG_TYPE      LCTBS_REG_MASTER.REG_TYPE%TYPE;
    L_PROD_TYPE     LCTM_PRODUCT_DEFINITION.PRODUCT_TYPE%TYPE;
    L_REIMBURSEMENT LCTM_PRODUCT_DEFINITION.REIMBURSEMENT%TYPE;

  BEGIN
    DBG('In  Chenck Mandatory...');

    IF P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_PRDDFLT, CSPKS_REQ_GLOBAL.P_NEW) THEN
      L_BLK := 'CSTBS_CONTRACT';
      L_FLD := 'CSTBS_CONTRACT.PRODUCT_CODE';
      IF P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE IS NULL THEN
        DBG('Field Product Code is null ......');
        P_ERR_CODE   := 'ST-MAND-001';
        P_ERR_PARAMS := '@' || L_FLD;
        RETURN FALSE;
      END IF;

    ELSIF SUBSTR(P_ACTION_CODE, 1, LENGTH(CSPKS_REQ_GLOBAL.P_ENRICH)) =
          CSPKS_REQ_GLOBAL.P_ENRICH THEN
      L_BLK := 'LCTBS_CONTRACT_MASTER';
      L_FLD := 'LCTBS_CONTRACT_MASTER.CONTRACT_CCY';
      IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY IS NULL THEN
        DBG('Mandatory column contract_ccy cannot be Null');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-MAND-005',
                     '@' || L_FLD || '~@' || L_BLK);
      END IF;

      L_FLD := 'LCTBS_CONTRACT_MASTER.CONTRACT_AMT';
      IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT IS NULL THEN
        DBG('Mandatory column contract_amt cannot be Null');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-MAND-005',
                     '@' || L_FLD || '~@' || L_BLK);
      END IF;

      L_FLD := 'LCTBS_CONTRACT_MASTER.OPERATION_CODE';
      IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IS NULL THEN
        DBG('Mandatory column operation_code cannot be Null');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-MAND-005',
                     '@' || L_FLD || '~@' || L_BLK);
      END IF;

      L_FLD := 'LCTBS_CONTRACT_MASTER.CIF_ID';
      IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID IS NULL THEN
        DBG('Mandatory column cif_id cannot be Null');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-MAND-005',
                     '@' || L_FLD || '~@' || L_BLK);
      END IF;

    END IF;

    IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO IS NOT NULL THEN
      BEGIN
        SELECT REG_TYPE
          INTO L_REG_TYPE
          FROM LCTBS_REG_MASTER
         WHERE ACKREFNO = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in selecting registeration details');
      END;

      DBG('Selecting product type....');
      BEGIN
        SELECT PRODUCT_TYPE, REIMBURSEMENT
          INTO L_PROD_TYPE, L_REIMBURSEMENT
          FROM LCTM_PRODUCT_DEFINITION
         WHERE PRODUCT_CODE = P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in selecting product type ' || SQLERRM);
          RETURN FALSE;
      END;
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_PRDDFLT THEN
        IF (NVL(L_REG_TYPE, 'XX') = 'LC' AND L_PROD_TYPE NOT IN ('I', 'S')) OR
           (NVL(L_REG_TYPE, 'XX') = 'BG' AND L_PROD_TYPE NOT IN ('G')) OR
           (NVL(L_REG_TYPE, 'XX') = 'SG' AND L_PROD_TYPE NOT IN ('H'))

         THEN
          DBG('Registration type and product code type are different');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-REG-03', NULL);
        END IF;

        IF (L_PROD_TYPE = 'I' AND NVL(L_REIMBURSEMENT, 'N') = 'Y') THEN
          DBG('Registration is not allowed for reimbursement product');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-REG-21', NULL);
        END IF;

        IF NVL(L_REG_TYPE, 'XX') = 'AM' THEN
          DBG('Invalid acknowledgement reference');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-REG-04', NULL);
        END IF;

        IF L_PROD_TYPE NOT IN ('I', 'G', 'H', 'S') THEN
          DBG('Acknowledgement reference number is applicable only for Import LC / SG / BG');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-REG-02', NULL);
        END IF;
      END IF;
    END IF;

    DBG('Returning from Fn_check_mandatory');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_check_mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_CHECK_MANDATORY;

  FUNCTION FN_VALIDATE_IMPORTLICENSE(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                     P_FUNCTION_ID  IN VARCHAR2,
                                     P_ACTION_CODE  IN VARCHAR2,
                                     P_PRODUCT_TYPE IN LCTMS_PRODUCT_DEFINITION.PRODUCT_TYPE%TYPE,
                                     P_WRK_LCDTRONL IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_ERR_CODE     IN OUT VARCHAR2,
                                     P_ERR_PARAMS   IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_GOODS_CLASS         BCTM_GOODS_MASTER.GOODS_CLASSIFICATION%TYPE;
    L_EFF_DATE            DATE;
    L_EXP_DATE            DATE;
    L_AMEND_CONFIRM_COUNT NUMBER := 0;
    L_AMNV_UTIL_CNT       NUMBER := 0;
    L_CONTRACT_AMT        LCTBS_CONTRACT_MASTER.CONTRACT_AMT%TYPE;
    L_UTIL_REC            BOOLEAN := FALSE;
    L_REIN_REC            BOOLEAN := TRUE;
    L_UTIL_CNT            NUMBER := 0;
    L_CNT                 NUMBER := 0;
    L_ORG_ACTION          VARCHAR2(50);

  BEGIN
    DBG('Inside Fn_Validate_ImportLicense');
    DBG('ActionCode' || P_ACTION_CODE || 'FunctionId' || P_FUNCTION_ID);

    IF P_FUNCTION_ID IN ('LCDTRONL') THEN
      L_ORG_ACTION := SUBSTR(LCPKS_LCDTRONL_MAIN.FN_GET_ORIGINAL_ACTION,
                             1,
                             LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP));
    ELSIF P_FUNCTION_ID IN ('LIDTRONL') THEN
      L_ORG_ACTION := SUBSTR(LIPKS_LIDTRONL_MAIN.FN_GET_ORIGINAL_ACTION,
                             1,
                             LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP));

    END IF;

    DBG('l_org_action ' || L_ORG_ACTION || 'p_Product_Type' ||
        P_PRODUCT_TYPE);
    IF L_ORG_ACTION <> CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP AND
       P_FUNCTION_ID IN ('LCDTRONL', 'LIDTRONL') THEN
      IF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE IS NOT NULL AND
         P_PRODUCT_TYPE = 'I' THEN
        SELECT GOODS_CLASSIFICATION
          INTO L_GOODS_CLASS
          FROM BCTM_GOODS_MASTER
         WHERE GOODS_CODE = P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE;

        IF L_GOODS_CLASS <> 'G' AND
           P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL.COUNT = 0 THEN
          DBG('Import license has to be maintained');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-UTL-024', NULL);
        END IF;

      END IF;

      DBG('p_Wrk_Lcdtronl.ty_lccilutl.v_lctbs_license_utl_detail.COUNT' ||
          P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL.COUNT);
      IF P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL.COUNT > 0 AND
         P_PRODUCT_TYPE <> 'I' THEN
        DBG('Import License Details are applicable only for Import LC');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-UTL-021', NULL);
      END IF;

      FOR I IN 1 .. P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL.COUNT LOOP
        SELECT LICENSE_EFFECTIVE_DATE, LICENSE_EXPIRY_DATE
          INTO L_EFF_DATE, L_EXP_DATE
          FROM LCTM_IMP_LICENSE_MASTER
         WHERE IMPORT_LICENSE_NO = P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL(I)
              .IMPORT_LICENSE_NO;

        DBG('l_Eff_Date' || L_EFF_DATE || 'l_Exp_Date' || L_EXP_DATE);

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE BETWEEN
           L_EFF_DATE AND L_EXP_DATE THEN
          DBG('Effective date of contract is between the effective and expiry date of import license provided');
        ELSE
          DBG('Effective date of contract is not in between the effective and expiry date of import license provided');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-UTL-022',
                       P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL(I)
                       .IMPORT_LICENSE_NO);

        END IF;

      END LOOP;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
         P_FUNCTION_ID IN ('LCDTRONL', 'LIDTRONL') THEN

        SELECT COUNT(*)
          INTO L_AMEND_CONFIRM_COUNT
          FROM (SELECT CONTRACT_REF_NO
                  FROM CSTBS_CONTRACT_EVENT_LOG
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                   AND EVENT_CODE = 'ACON'
                   AND AUTH_STATUS = 'U'
                UNION
                SELECT CONTRACT_REF_NO
                  FROM LCTB_AMND_VALS_MASTER
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                   AND AMND_SEQ_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);

        DBG('l_amend_confirm_count :: ' || L_AMEND_CONFIRM_COUNT);
        IF L_AMEND_CONFIRM_COUNT > 0 THEN
          DBG('Amendment Confirmation is on process');
          SELECT COUNT(*)
            INTO L_CNT
            FROM LCTB_LICENSE_UTL_MASTER
           WHERE UTIL_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

          IF L_CNT > 0 THEN
            SELECT CONTRACT_AMT
              INTO L_CONTRACT_AMT
              FROM LCTB_CONTRACT_MASTER
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
               AND VERSION_NO IN
                   (SELECT MAX(VERSION_NO)
                      FROM LCTB_CONTRACT_MASTER A
                     WHERE A.CONTRACT_REF_NO =
                           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                       AND A.EVENT_SEQ_NO <=
                           (SELECT MAX(B.EVENT_SEQ_NO)
                              FROM CSTB_CONTRACT_EVENT_LOG B
                             WHERE B.CONTRACT_REF_NO = A.CONTRACT_REF_NO
                               AND B.AUTH_STATUS = 'A'));

            DBG('l_Contract_Amt' || L_CONTRACT_AMT);
            DBG('p_wrk_lcdtronl.v_lctbs_contract_master.Contract_Amt' ||
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);

            IF L_CNT > 0 AND
               P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL.COUNT = 0 AND
               NVL(L_CONTRACT_AMT, 0) >
               NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT, 0) THEN
              DBG('Import License details are not attached,Procced ?');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-UTL-032', NULL);
            END IF;

            IF P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL.COUNT > 0 THEN
              FOR I IN 1 .. P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL.COUNT LOOP
                SELECT COUNT(*)
                  INTO L_UTIL_CNT
                  FROM LCTB_LICENSE_UTL_DETAIL
                 WHERE UTIL_REF_NO =
                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                   AND IMPORT_LICENSE_NO = P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL(I)
                      .IMPORT_LICENSE_NO
                   AND GOODS_CODE = P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL(I)
                      .GOODS_CODE;

                SELECT COUNT(*)
                  INTO L_AMNV_UTIL_CNT
                  FROM LCTB_LICENSE_UTL_DETAIL
                 WHERE UTIL_REF_NO =
                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                   AND CONTRACT_ESN IN
                       (SELECT MAX(EVENT_SEQ_NO)
                          FROM CSTBS_CONTRACT_EVENT_LOG
                         WHERE CONTRACT_REF_NO =
                               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                           AND EVENT_CODE = 'AMNV'
                           AND AUTH_STATUS = 'A');

                DBG('l_Util_Cnt' || L_UTIL_CNT || 'l_Amnv_Util_Cnt' ||
                    L_AMNV_UTIL_CNT);

                IF L_UTIL_CNT > 0 AND NVL(P_WRK_LCDTRONL.TY_LCCILUTL.V_CSTBS_UI_COLUMNS__MULTI(I)
                                          .NUM_FIELD2,
                                          0) = 0 AND
                   NVL(L_CONTRACT_AMT, 0) > NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                0) THEN
                  DBG('Reinstatement details not maintained for the import license no and goods code combination');
                  L_REIN_REC := FALSE;
                END IF;

                IF L_AMNV_UTIL_CNT > 0 AND
                   NVL(P_WRK_LCDTRONL.TY_LCCILUTL.V_CSTBS_UI_COLUMNS__MULTI(I)
                       .NUM_FIELD1,
                       0) > 0 THEN
                  DBG('Utilization is already marked as a part of amendment capture');
                  L_UTIL_REC := TRUE;
                END IF;

              END LOOP;

              IF NOT L_REIN_REC THEN
                DBG('Reinstatement details not maintained for the import license,Do you wish to proceed?');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-UTL-030', NULL);
              END IF;

              IF L_UTIL_REC THEN
                DBG('Utilization is already marked as a part of amendment capture,Do you wish to proceed?');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-UTL-031', NULL);
              END IF;

            END IF;

          END IF;

        END IF;

      END IF;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Validate_ImportLicense ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE_IMPORTLICENSE;

  FUNCTION FN_VALIDATE_GOODS_DETAILS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                     P_FUNCTION_ID        IN VARCHAR2,
                                     P_ACTION_CODE        IN VARCHAR2,
                                     P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                     P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_PREV_LCDTRONL      IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_WRK_LCDTRONL       IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_ERR_CODE           IN OUT VARCHAR2,
                                     P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_UNIT_CHG     NUMBER := 0;
    L_PRICE_CHG    NUMBER := 0;
    L_GOODS        VARCHAR2(12);
    L_UNITS        NUMBER := 0;
    L_PRICE        NUMBER := 0;
    L_ORIG_UNITS   NUMBER := 0;
    L_COUNT        NUMBER := 0;
    L_GOODS_EXIST1 NUMBER := 0;
    L_GOODS_EXIST2 NUMBER := 0;
    L_COUNT_TRFR   NUMBER := 0;
    L_COUNT_BILL   NUMBER := 0;

    CURSOR C_GOODS_BILL(P_LC_REF_NO LCTB_CONTRACT_MASTER.RELATED_LC_REF_NO%TYPE) IS
      SELECT GOODS_CODE
        FROM BCTB_CONTRACT_GOODS_DETAILS
       WHERE CONTRACT_REF_NO = P_LC_REF_NO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM BCTB_CONTRACT_GOODS_DETAILS
               WHERE CONTRACT_REF_NO = P_LC_REF_NO);

    CURSOR C_GOODS_TRFR(P_LC_REF_NO LCTB_TRANSFER_GOODS_DETAILS.CONTRACT_REF_NO%TYPE,
                        P_SL_NO     LCTB_TRANSFER_GOODS_DETAILS.SL_NO%TYPE) IS
      SELECT GOODS_CODE
        FROM LCTB_TRANSFER_GOODS_DETAILS
       WHERE CONTRACT_REF_NO = P_LC_REF_NO
         AND SL_NO = P_SL_NO;

  BEGIN
    DBG('Inside the function Fn_Validate_Goods_Details with action: ' ||
        P_ACTION_CODE);

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT LOOP
          IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
           .GOODS_CODE IS NOT NULL AND
              ((P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
               .NO_OF_UNITS IS NULL AND P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
               .PRICE_PER_UNIT IS NOT NULL) OR (P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
               .NO_OF_UNITS IS NOT NULL AND P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
               .PRICE_PER_UNIT IS NULL)) THEN
            L_COUNT := L_COUNT + 1;
          END IF;
        END LOOP;
        DBG(' count here: ' || L_COUNT);
        IF L_COUNT > 0 THEN
          DBG('Units/price per unit for the goods is provided partially');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-069', NULL);
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      FOR Y IN (SELECT DISTINCT (GOODS_CODE) L_GOODS,
                                SUM(NO_OF_UNITS) L_UNITS,
                                MAX(PRICE_PER_UNIT) L_PRICE
                  FROM LCTB_TRANSFER_GOODS_DETAILS
                 WHERE CONTRACT_REF_NO IN
                       (SELECT TO_LCREF
                          FROM LCTB_TRANSFER_DETAILS
                         WHERE FROM_LCREF =
                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO)
                 GROUP BY GOODS_CODE) LOOP
        DBG('y.l_goods:' || Y.L_GOODS || '~' || 'y.l_units:' || Y.L_UNITS || '~' ||
            'y.l_price:' || Y.L_PRICE);
        BEGIN
          SELECT NO_OF_UNITS, PRICE_PER_UNIT, GOODS_CODE
            INTO L_UNIT_CHG, L_PRICE_CHG, L_GOODS
            FROM TABLE(P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL) H
           WHERE H.CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND H.GOODS_CODE = Y.L_GOODS;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in querying p_wrk_lcdtronl.v_goods_details__detail:' ||
                SQLERRM);
            L_UNIT_CHG  := 0;
            L_PRICE_CHG := 0;
            L_GOODS     := NULL;
        END;

        DBG(L_UNIT_CHG || ' < ' || Y.L_UNITS);
        IF (L_UNIT_CHG < Y.L_UNITS) AND NVL(L_GOODS, 'X') = Y.L_GOODS THEN
          DBG('Amendment of Number of units to a lesser count is not allowed as transfer is already done with a greater value.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-569', NULL);
        END IF;

        DBG(L_PRICE_CHG || ' < ' || Y.L_PRICE);
        IF (L_PRICE_CHG < Y.L_PRICE) AND NVL(L_GOODS, 'X') = Y.L_GOODS THEN
          DBG('Amendment of Price per unit to a lesser count is not allowed as transfer is already done with a greater value.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-570', NULL);
        END IF;

      END LOOP;

      IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT > 0 THEN
        FOR X IN (SELECT TO_LCREF, SL_NO
                    FROM LCTBS_TRANSFER_DETAILS A
                   WHERE A.FROM_LCREF =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO) LOOP

          FOR EACH_REC IN C_GOODS_TRFR(X.TO_LCREF, X.SL_NO) LOOP
            L_COUNT_TRFR := L_COUNT_TRFR + 1;
            FOR I IN 1 .. P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT LOOP
              DBG('LC goods_code: ' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                  .GOODS_CODE || ' Trfr goods_code : ' ||
                  EACH_REC.GOODS_CODE);
              IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
               .GOODS_CODE = EACH_REC.GOODS_CODE THEN
                DBG('Goods matched with trfr goods');
                L_GOODS_EXIST1 := L_GOODS_EXIST1 + 1;
              END IF;
            END LOOP;
          END LOOP;
        END LOOP;
        DBG('l_Count_trfr: ' || L_COUNT_TRFR || ' l_Goods_Exist1: ' ||
            L_GOODS_EXIST1);
        IF L_COUNT_TRFR <> L_GOODS_EXIST1 THEN
          DBG('Amendment of goods is not allowed as transfer is done already for the removed goods.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-571', NULL);
        END IF;
      END IF;

      DBG('validation against bill');
      FOR W IN (SELECT DISTINCT (GOODS_CODE) L_GOODS,
                                SUM(NO_OF_UNITS) L_UNITS,
                                MAX(PRICE_PER_UNIT) L_PRICE
                  FROM BCTB_CONTRACT_GOODS_DETAILS
                 WHERE CONTRACT_REF_NO IN
                       (SELECT BCREFNO
                          FROM BCTB_CONTRACT_MASTER
                         WHERE OUR_LC_REF =
                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO)
                 GROUP BY GOODS_CODE) LOOP
        DBG('w.l_goods:' || W.L_GOODS || '~' || 'w.l_units:' || W.L_UNITS || '~' ||
            'w.l_price:' || W.L_PRICE);
        BEGIN
          SELECT NO_OF_UNITS, PRICE_PER_UNIT, GOODS_CODE
            INTO L_UNIT_CHG, L_PRICE_CHG, L_GOODS
            FROM TABLE(P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL) G
           WHERE G.CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND G.GOODS_CODE = W.L_GOODS;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in querying p_wrk_lcdtronl.v_goods_details__detail:' ||
                SQLERRM);
            L_UNIT_CHG  := 0;
            L_PRICE_CHG := 0;
            L_GOODS     := NULL;
        END;

        BEGIN
          SELECT NO_OF_UNITS
            INTO L_ORIG_UNITS
            FROM LCTB_GOODS_DETAILS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND GOODS_CODE = W.L_GOODS
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_GOODS_DETAILS
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in querying lctb_goods_details:' || SQLERRM);
        END;

        DBG(L_UNIT_CHG || ' < ' || W.L_UNITS);
        IF (L_UNIT_CHG < W.L_UNITS AND (L_UNIT_CHG <> L_ORIG_UNITS) AND
           NVL(L_GOODS, 'X') = W.L_GOODS) THEN
          DBG('Amendment of Number of units to a lesser count is not allowed as bill is already booked with a greater value.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-572', NULL);
        END IF;

        DBG(L_PRICE_CHG || ' < ' || W.L_PRICE);
        IF (L_PRICE_CHG < W.L_PRICE) AND NVL(L_GOODS, 'X') = W.L_GOODS THEN
          DBG('Amendment of Price per unit to a lesser count is not allowed as bill is already booked with a greater value.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-573', NULL);
        END IF;

      END LOOP;

      IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT > 0 THEN
        FOR Z IN (SELECT BCREFNO
                    FROM BCTBS_CONTRACT_MASTER A
                   WHERE A.OUR_LC_REF =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                     AND A.EVENT_SEQ_NO =
                         (SELECT MAX(EVENT_SEQ_NO)
                            FROM BCTBS_CONTRACT_MASTER
                           WHERE OUR_LC_REF =
                                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO)) LOOP

          FOR EACH_REC IN C_GOODS_BILL(Z.BCREFNO) LOOP
            L_COUNT_BILL := L_COUNT_BILL + 1;
            FOR I IN 1 .. P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT LOOP
              DBG('LC goods_code: ' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                  .GOODS_CODE || ' BC goods_code : ' || EACH_REC.GOODS_CODE);
              IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
               .GOODS_CODE = EACH_REC.GOODS_CODE THEN
                DBG('LC Goods matched with BC goods');
                L_GOODS_EXIST2 := L_GOODS_EXIST2 + 1;
              END IF;
            END LOOP;
          END LOOP;
        END LOOP;
        DBG('l_Count_bill: ' || L_COUNT_BILL || ' l_Goods_Exist2: ' ||
            L_GOODS_EXIST2);
        IF L_COUNT_BILL <> L_GOODS_EXIST2 THEN
          DBG('Amendment of goods is not allowed as bill is done already booked for the removed goods.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-574', NULL);
        END IF;
      END IF;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Validate_Goods_Details ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE_GOODS_DETAILS;

  FUNCTION FN_VALIDATE(P_SOURCE        IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                       P_FUNCTION_ID   IN VARCHAR2,
                       P_ACTION_CODE   IN VARCHAR2,
                       P_LCDTRONL      IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                       P_PREV_LCDTRONL IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                       P_WRK_LCDTRONL  IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                       P_ERR_CODE      IN OUT VARCHAR2,
                       P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_PRODUCT_DEFINITION LCTMS_PRODUCT_DEFINITION%ROWTYPE;
    L_PROD_REC           CSTM_PRODUCT%ROWTYPE;

    L_PRODUCT_TYPE    CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
    L_CREDIT_AVL_WITH LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH%TYPE;

    L_ACTION           VARCHAR2(12);
    L_BC_REF           LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO%TYPE;
    L_CONTRACT_STATUS  CSTBS_CONTRACT.CONTRACT_STATUS%TYPE;
    L_COUNT            NUMBER;
    L_EVENT_SEQ_NO     CSTBS_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE;
    L_EVENT_PCLS       NUMBER;
    L_OS_LIABILITY     LCTBS_AVAILMENTS.OS_LIABILITY%TYPE;
    L_AMENDABLE_NODES  CSPKS_REQ_GLOBAL.TY_AMEND_NODES;
    L_AMENDABLE_FIELDS CSPKS_REQ_GLOBAL.TY_AMEND_FIELDS;
    L_MODULE           SMTB_MENU.MODULE%TYPE;

    L_OLD_EXP_DT     LCTB_CONTRACT_MASTER.EXPIRY_DATE%TYPE;
    L_OLD_CLOSURE_DT LCTB_CONTRACT_MASTER.CLOSURE_DATE%TYPE;
    L_FROM_LCREF     LCTB_TRANSFER_DETAILS.FROM_LCREF%TYPE;
    L_CONT_STATUS    CSTBS_CONTRACT.CONTRACT_STATUS%TYPE;

    L_ADB_MEMBER      ISTMS_BIC_DIRECTORY.ADB_MEMBER%TYPE;
    L_GUARANTEE_COUNT NUMBER;

    L_LIQ_COUNT_LC NUMBER := 0;
    L_LIQ_COUNT_BC NUMBER := 0;
    L_LQ_COUNT     NUMBER := 0;

    L_UNCONFIRMED_AMND_COUNT NUMBER := 0;
    L_SWIFT2018_ENABLED      VARCHAR2(3);
  BEGIN

    DBG('In  Fn_Validate...');
    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;

    END;

    BEGIN
      DBG('Selecting Product Type');
      SELECT PRODUCT_TYPE
        INTO L_PRODUCT_TYPE

        FROM CSTMS_PRODUCT
       WHERE PRODUCT_CODE = SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                   4,
                                   4);

      DBG('Product Type------->' || L_PRODUCT_TYPE);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('NOT A VALID PRODUCT');
        RETURN FALSE;
      WHEN OTHERS THEN
        DBG('iniside when others of selecting product type-->' || SQLERRM);
        RETURN FALSE;

    END;

    IF L_PRODUCT_TYPE NOT IN ('G', 'R', 'H', 'A', 'S')

     THEN

      IF (L_PRODUCT_TYPE <> 'I' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD') THEN

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH IS NULL THEN
          DBG('Mandetory field Credit Available With is Null');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-MAND-009', '');
          RETURN FALSE;
        END IF;

      END IF;
    END IF;

    DBG('p_action_code-->' || P_ACTION_CODE);
    DBG('p_wrk_lcdtronl.v_lctbs_contract_master.urr_preference-->' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE);
    DBG('p_prev_lcdtronl.v_lctbs_contract_master.urr_preference-->' ||
        P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      DBG('p_wrk_lcdtronl.v_lctbs_contract_master.urr_preference-->' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE);
      DBG('p_prev_lcdtronl.v_lctbs_contract_master.urr_preference-->' ||
          P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE);

      BEGIN
        SELECT PARAM_VAL
          INTO L_SWIFT2018_ENABLED
          FROM CSTB_PARAM
         WHERE PARAM_NAME = 'SWIFTTRADE2018_ENABLED';
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('LC', 'Failed in selecting swift enabled param');
      END;

      DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Contract_Ref_No-->' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);
      IF L_PRODUCT_TYPE IN ('G', 'A') THEN
        SELECT COUNT(*)
          INTO L_GUARANTEE_COUNT
          FROM LCTB_GUARANTEE_CLAIM LGC
         WHERE LGC.CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND LGC.EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTB_GUARANTEE_CLAIM LGC1
                 WHERE LGC1.CONTRACT_REF_NO = LGC.CONTRACT_REF_NO
                   AND LGC1.CLAIM_SEQ_NO = LGC.CLAIM_SEQ_NO)
           AND CLAIM_STATUS IN ('L', 'I');
        DBG('l_Guarantee_count-->' || L_GUARANTEE_COUNT);
        IF L_GUARANTEE_COUNT > 0 THEN
          DEBUG.PR_DEBUG('**',
                         'Unprocessed Calims logged for this Guarantee contract');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-559', NULL);
        END IF;
      END IF;

    END IF;

    IF P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_CLOSE, CSPKS_REQ_GLOBAL.P_REVERSE) THEN

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN

        IF L_PRODUCT_TYPE IN ('G', 'A') THEN
          SELECT COUNT(*)
            INTO L_GUARANTEE_COUNT

            FROM LCTB_GUARANTEE_CLAIM LGC
           WHERE LGC.CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND LGC.EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTB_GUARANTEE_CLAIM LGC1
                   WHERE LGC1.CONTRACT_REF_NO = LGC.CONTRACT_REF_NO
                     AND LGC1.CLAIM_SEQ_NO = LGC.CLAIM_SEQ_NO)
             AND CLAIM_STATUS IN ('L', 'I');

          IF L_GUARANTEE_COUNT > 0 THEN
            DEBUG.PR_DEBUG('**',
                           'Calims logged for this Guarantee contract.. Proceed for Close/Reverse?');

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-CLM-012', NULL);

          END IF;

        END IF;

        L_ACTION := 'Close';

        SELECT COUNT(1)
          INTO L_LIQ_COUNT_LC
          FROM LCTBS_DEFERRED_INT_COM
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND STATUS <> 'L';

        SELECT COUNT(1)
          INTO L_LIQ_COUNT_BC
          FROM LCTB_DEFERRED_LIQ_BILL
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND STATUS <> 'L';

        SELECT COUNT(1)
          INTO L_LQ_COUNT
          FROM CSTBS_CHG_LIQ A
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND LATEST_EVENT_SEQ_NO =
               (SELECT MAX(LATEST_EVENT_SEQ_NO)
                  FROM CSTBS_CHG_LIQ B
                 WHERE B.LIQ_REF_NO = A.LIQ_REF_NO)
           AND LIQ_STATUS <> 'COL';

        DBG('l_liq_count_lc' || L_LIQ_COUNT_LC);
        DBG('l_liq_count_bc' || L_LIQ_COUNT_BC);
        DBG('l_lq_count' || L_LQ_COUNT);

        IF (L_LIQ_COUNT_LC > 0) OR (L_LIQ_COUNT_BC > 0) OR (L_LQ_COUNT > 0) THEN
          DEBUG.PR_DEBUG('LC', 'Deferred component exists');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-499', NULL);
        END IF;

      ELSE
        L_ACTION := 'Reverse';

      END IF;

      IF L_PRODUCT_TYPE = 'I' THEN

        DBG('Checking for SG liankges ');
        FOR I IN (SELECT CONTRACT_REF_NO
                    FROM LDTBS_CONTRACT_LINKAGES
                   WHERE LINKED_TO_REF =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                     AND LINKAGE_TYPE = 'L') LOOP

          SELECT CONTRACT_STATUS
            INTO L_CONTRACT_STATUS
            FROM CSTB_CONTRACT
           WHERE CONTRACT_REF_NO = I.CONTRACT_REF_NO;

          IF L_CONTRACT_STATUS = 'A' THEN

            DBG('Operation  not allowed because  of active shipping guarantee contract/s');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-331', L_ACTION);
            RETURN FALSE;
          END IF;

        END LOOP;

      ELSIF L_PRODUCT_TYPE = 'H' THEN

        DBG('Checking for Bill liankges ');

        DBG(' Check whether the shipping guarantee is linked to bill.');
        SELECT COUNT(1)
          INTO L_COUNT
          FROM LDTBS_CONTRACT_LINKAGES L
         WHERE L.LINKED_TO_REF =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND L.LINKAGE_TYPE = 'S'
           AND EXISTS (SELECT 1
                  FROM CSTBS_CONTRACT C
                 WHERE C.CONTRACT_REF_NO = L.CONTRACT_REF_NO
                   AND C.CONTRACT_STATUS = 'A');
        DBG(' l_count: ' || L_COUNT);
        IF L_COUNT > 0 THEN
          DBG(' Operation not allowed because  of shipping guarantee linked to bill.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-332', L_ACTION);
          RETURN FALSE;
        END IF;

      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REVERSE OR
         (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE = 'CANC') THEN
        DBG('to check if pcls got fired....');
        BEGIN
          SELECT NVL(MAX(EVENT_SEQ_NO), 0)
            INTO L_EVENT_SEQ_NO
            FROM CSTB_CONTRACT_EVENT_LOG
           WHERE EVENT_CODE = 'ROPN'
             AND CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_EVENT_SEQ_NO := 0;

        END;

        BEGIN
          SELECT 1
            INTO L_EVENT_PCLS
            FROM CSTB_CONTRACT_EVENT_LOG
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_CODE = 'PCLS'
             AND EVENT_SEQ_NO > L_EVENT_SEQ_NO;

          IF L_EVENT_PCLS IS NOT NULL THEN
            DBG('PCLS fired');

            DBG('If PCLS event is fired than only closure operation is allowed');
            P_ERR_CODE   := 'LCCON-345';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('PCLS not fired' || SQLERRM);

        END;
      END IF;

      SELECT COUNT(1)
        INTO L_UNCONFIRMED_AMND_COUNT
        FROM LCTBS_AMND_VALS_MASTER
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND AMND_SEQ_NO <
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO
         AND AMND_STATUS = 'U';

      IF L_UNCONFIRMED_AMND_COUNT > 0 THEN
        DBG('Previous unconfirmed amendments exist');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-AVK17', NULL);
      END IF;

    END IF;

    DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Get_Product_Details' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE);
    IF NOT FN_GET_PRODUCT_DETAILS(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                  L_PROD_REC,
                                  L_PRODUCT_DEFINITION,
                                  P_FUNCTION_ID,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Get_Product_Details ...');
      RETURN FALSE;
    END IF;

    IF P_SOURCE = 'FLEXCUBE' THEN
      DBG('p_Source' || P_SOURCE || 'going to check mfa limit');

      GLOBAL.PR_SET_MFA_LIMIT_CHECK_REQD(TRUE);
      GLOBAL.PR_SET_MODULE_ID(L_MODULE);

    END IF;

    IF P_ACTION_CODE NOT IN
       (CSPKS_REQ_GLOBAL.P_DELETE,
        CSPKS_REQ_GLOBAL.P_AUTH,
        CSPKS_REQ_GLOBAL.P_COPY,
        CSPKS_REQ_GLOBAL.P_CLOSE,
        CSPKS_REQ_GLOBAL.P_REOPEN,
        CSPKS_REQ_GLOBAL.P_REVERSE) THEN
      DBG('Calling Fn_Validate_Master..');
      IF NOT FN_VALIDATE_MASTER(P_SOURCE,
                                P_FUNCTION_ID,
                                P_ACTION_CODE,
                                L_PRODUCT_DEFINITION,
                                P_LCDTRONL,
                                P_PREV_LCDTRONL,
                                P_WRK_LCDTRONL,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN

        DBG('Failed in Fn_Validate_Mastermaster..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Calling Fn_Validate_Parties');
      IF NOT FN_VALIDATE_PARTIES(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ACTION_CODE,
                                 L_PRODUCT_DEFINITION,
                                 P_LCDTRONL,
                                 P_PREV_LCDTRONL,
                                 P_WRK_LCDTRONL,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN

        DBG('Failed in Fn_Validate_Parties');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Calling Fn_Validate_Ship_Docs');
      IF NOT FN_VALIDATE_SHIP_DOCS(P_SOURCE,
                                   P_FUNCTION_ID,
                                   P_ACTION_CODE,
                                   L_PRODUCT_DEFINITION,
                                   P_LCDTRONL,
                                   P_PREV_LCDTRONL,
                                   P_WRK_LCDTRONL,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN

        DBG('Failed in Fn_Validate_Ship_Docs');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Calling Fn_Validate_Goods_Details');
      IF NOT FN_VALIDATE_GOODS_DETAILS(P_SOURCE,
                                       P_FUNCTION_ID,
                                       P_ACTION_CODE,
                                       L_PRODUCT_DEFINITION,
                                       P_LCDTRONL,
                                       P_PREV_LCDTRONL,
                                       P_WRK_LCDTRONL,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN

        DBG('Failed in Fn_Validate_Goods_Details');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Calling Fn_Validate_ImportLicense..');
      IF NOT FN_VALIDATE_IMPORTLICENSE(P_SOURCE,
                                       P_FUNCTION_ID,
                                       P_ACTION_CODE,
                                       L_PRODUCT_TYPE,
                                       P_WRK_LCDTRONL,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN

        DBG('Failed in Fn_Validate_ImportLicense..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('calling Fn_Validate_Related_Refno');
      IF NOT FN_VALIDATE_RELATED_REFNO(P_SOURCE,
                                       P_FUNCTION_ID,
                                       P_ACTION_CODE,
                                       L_PRODUCT_DEFINITION,
                                       P_LCDTRONL,
                                       P_PREV_LCDTRONL,
                                       P_WRK_LCDTRONL,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN

        DBG('Failed in Fn_Validate_Related_Refno..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Callin Fn_validate_limits');
      IF NOT FN_VALIDATE_LIMITS(P_SOURCE,
                                P_FUNCTION_ID,
                                P_ACTION_CODE,
                                P_LCDTRONL,
                                P_PREV_LCDTRONL,
                                P_WRK_LCDTRONL,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN

        DBG('Failed in Fn_validate_limits..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Calling the swift validation');

      IF NOT FN_SWIFT_VALIDATIONS(P_SOURCE,
                                  P_FUNCTION_ID,
                                  P_ACTION_CODE,
                                  L_PRODUCT_DEFINITION,
                                  P_LCDTRONL,
                                  P_WRK_LCDTRONL,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
        DBG('Faile in Fn_Validate_Related_Refno..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT LOOP
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).REQUIRED, 'N') = 'Y' THEN
            IF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).TRACER_CODE IS NULL THEN
              DBG('The tracer code is mandatory');
              OVPKSS.PR_APPENDTBL('LS-CON-000', 'Tracer Code');
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).TRACER_PARTY IS NULL THEN
              OVPKSS.PR_APPENDTBL('LS-CON-000', 'Tracer Party Type');
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).MEDIUM IS NULL THEN
              DBG('The medium is mandatory');
              OVPKSS.PR_APPENDTBL('LS-CON-000', 'Medium');
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).MEDIUM = 'SWIFT' AND P_WRK_LCDTRONL.V_LCTBS_TRACERS(I)
               .TEMPLATE_ID IS NULL THEN
              DBG('The Template ID is mandatory');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-335', ' ');
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).MEDIUM <> 'SWIFT' AND P_WRK_LCDTRONL.V_LCTBS_TRACERS(I)
               .TEMPLATE_ID IS NOT NULL THEN
              DBG('The Template ID should be entered only for swift media');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-325', ' ');
              RETURN FALSE;
            END IF;

          END IF;

        END LOOP;

      END IF;

    END IF;

    DBG('calling Fn_Validate_Related_Refno for Reopen - p_action_code' ||
        P_ACTION_CODE);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      BEGIN
        DBG('New Expiry dt' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        DBG('New Closure dt' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE);
        DBG('Curr Versionno' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
        DBG('Curr Event seqno' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        DBG('Before selecting old expiry and closure dates ');
        SELECT EXPIRY_DATE, CLOSURE_DATE
          INTO L_OLD_EXP_DT, L_OLD_CLOSURE_DT

          FROM LCTBS_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO

           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTBS_CONTRACT_MASTER
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                   AND VERSION_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO - 1);

        DBG('App date is  ' || GLOBAL.APPLICATION_DATE);
        DBG('Old Expiry date is  ' || L_OLD_EXP_DT);
        DBG('Old Closure date is  ' || L_OLD_CLOSURE_DT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In others1');
          NULL;

      END;

      DBG('l_product_type: ' || L_PRODUCT_TYPE);
      IF L_PRODUCT_TYPE IN ('I', 'H') THEN

        DBG('calling Fn_Validate_Related_Refno for Reopen');
        IF NOT FN_VALIDATE_RELATED_REFNO(P_SOURCE,
                                         P_FUNCTION_ID,
                                         P_ACTION_CODE,
                                         L_PRODUCT_DEFINITION,
                                         P_LCDTRONL,
                                         P_PREV_LCDTRONL,
                                         P_WRK_LCDTRONL,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN

          DBG('Failed in Fn_Validate_Related_Refno..');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END IF;

      ELSIF L_PRODUCT_TYPE = 'E' THEN

        DBG('Inside Export');
        BEGIN
          SELECT FROM_LCREF
            INTO L_FROM_LCREF
            FROM LCTBS_TRANSFER_DETAILS
           WHERE TO_LCREF =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

          DBG('l_from_lcref ' || L_FROM_LCREF);

          SELECT CONTRACT_STATUS
            INTO L_CONT_STATUS
            FROM CSTB_CONTRACT
           WHERE CONTRACT_REF_NO = L_FROM_LCREF;

          DBG('Checking for parent-child linkage3 ' || P_ACTION_CODE ||
              L_CONT_STATUS);
          IF L_CONT_STATUS = 'S' THEN
            DBG('Parent LC has to be reopened first, then only child LC can be reopened');

            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-BKB-007',
                         '@' ||
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO || '~@' ||
                         L_FROM_LCREF || '~@' || L_FROM_LCREF);
          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('In when others - Its a parant LC');

        END;

        DBG('prod111' || L_PRODUCT_DEFINITION.PRODUCT_TYPE);
        DBG('prod reimbursenment' || L_PRODUCT_DEFINITION.REIMBURSEMENT);

        IF (L_PRODUCT_DEFINITION.PRODUCT_TYPE NOT IN ('S', 'H', 'G')) THEN
          IF (L_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'E') AND
             L_PRODUCT_DEFINITION.REIMBURSEMENT <> 'Y') THEN

            FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
               .PARTY_TYPE IN ('ISB', 'ABK') THEN
                BEGIN
                  SELECT ADB_MEMBER
                    INTO L_ADB_MEMBER
                    FROM ISTMS_BIC_DIRECTORY
                   WHERE BIC_CODE = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                        .CUST_ADDRESS_LIN1;

                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;

                END;

                IF NVL(L_ADB_MEMBER, 'X') = 'N' THEN
                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-512', NULL);
                END IF;

              END IF;

            END LOOP;

          END IF;

        END IF;

      END IF;

    END IF;

    DBG('Calling the Fn_Validate_Eventcode..');
    IF NOT FN_VALIDATE_EVENTCODE(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ACTION_CODE,
                                 P_LCDTRONL,
                                 P_PREV_LCDTRONL,
                                 P_WRK_LCDTRONL,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN

      DBG('Failed in Fn_Validate_Eventcode');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE = 'PCLS' THEN

      DBG('Came here under PCLS');
      IF NOT CSPKS_REQ_UTILS.FN_GET_AMENDABLE_DETAILS(P_SOURCE,
                                                      CSPKS_REQ_GLOBAL.P_MODIFY,
                                                      L_AMENDABLE_NODES,
                                                      L_AMENDABLE_FIELDS,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN

        DBG('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Calling fn_any_field_modified');
      IF NOT FN_ANY_FIELD_MODIFIED(P_SOURCE,
                                   L_AMENDABLE_NODES,
                                   L_AMENDABLE_FIELDS,
                                   P_PREV_LCDTRONL,
                                   P_WRK_LCDTRONL,

                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
        DBG('Some field modified');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

    END IF;

    DBG('p_action_code>>CHECK' || P_ACTION_CODE);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BACK_TO_BACK_LC, 'N') <>
         NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BACK_TO_BACK_LC, 'N') THEN
        DBG('back to back lc should not be modified');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-410', NULL);
      END IF;

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM, 'N') <>
         NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM, 'N') THEN
        DBG('may confirm should not be modified');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-411', NULL);
      END IF;

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') <>
         NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') THEN
        DBG('track_limit should not be modified');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-412', NULL);
      END IF;

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIMITS_TRACKING_TENOR_TYPE,
             'N') <>
         P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIMITS_TRACKING_TENOR_TYPE THEN
        DBG('limits_tracking_tenor_type should not be modified');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-413', NULL);
      END IF;

      DBG('p_wrk_lcdtronl.v_lctbs_shipment.partial_shipment-->' ||
          P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT);
      DBG('p_prev_lcdtronl.v_lctbs_shipment.partial_shipment-->' ||
          P_PREV_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT);
      DBG('p_wrk_lcdtronl.v_lctbs_shipment.trans_shipment-->' ||
          P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT);
      DBG('p_prev_lcdtronl.v_lctbs_shipment.trans_shipment-->' ||
          P_PREV_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT);

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT, 'B') <>
         NVL(P_PREV_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT, 'B') OR
         NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT, 'B') <>
         NVL(P_PREV_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT, 'B')

       THEN
        DBG('shipment detail not to be modified');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-414', NULL);
      END IF;

    END IF;

    DBG('Returning from Fn_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Check_Feasibility ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE;

  FUNCTION FN_NETWORK_VALIDATIONS(P_IN_STRING IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    IF INSTR(P_IN_STRING, '/', 1) = 1 THEN
      RETURN FALSE;
    ELSIF INSTR(P_IN_STRING, '/', -1) = LENGTH(P_IN_STRING) THEN

      RETURN FALSE;

    ELSIF INSTR(P_IN_STRING, '//') > 0 THEN
      RETURN FALSE;

    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('Fn_Network_Validations Failed with ' || SQLERRM);
      RETURN FALSE;

  END FN_NETWORK_VALIDATIONS;

  FUNCTION FN_ISB_BANK_REF(P_SOURCE     IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                           P_LCDTRONL   IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                           P_REF_NO     OUT VARCHAR2,
                           P_ERR_CODE   IN OUT VARCHAR2,
                           P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('In Fn_Isb_Bank_Ref..');
    P_REF_NO := NULL;
    IF P_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
      FOR I IN P_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
        IF P_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE = 'ISB' THEN
          P_REF_NO := P_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO;
        END IF;

      END LOOP;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in When others of Fn_Isb_Bank_Ref');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_ISB_BANK_REF;

  FUNCTION FN_VALIDATE_MASTER(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_FUNCTION_ID        IN VARCHAR2,
                              P_ACTION_CODE        IN VARCHAR2,
                              P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                              P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_ERR_CODE           IN OUT VARCHAR2,
                              P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT    NUMBER;
    L_HOLIDAY  VARCHAR2(1);
    L_FLD      VARCHAR2(100);
    L_WHNO     NUMBER;
    L_CHNO     NUMBER;
    L_UNIT     CHAR(1);
    L_TOTALAMT NUMBER := 0;
    I          NUMBER;
    L_TEMP     NUMBER;
    LO_MIN_AMT NUMBER;

    L_CHECK                     BOOLEAN := FALSE;
    L_REF_NO                    VARCHAR2(35);
    L_LINKAGE_REC               LMTM_POOL_COLLATERAL_LINKAGES%ROWTYPE;
    L_POLICY_COUNT              NUMBER;
    L_SUM_ASSURED_CCY           VARCHAR2(3);
    L_OPN_POLICY_COUNT          NUMBER := 0;
    L_INSURANCE_POLICY_NUMBER   VARCHAR2(150);
    L_POLICY_SUM_ASSURED_AMOUNT NUMBER;
    L_POLICY_UTILIZATION_AMOUNT NUMBER;
    L_POLICY_EXPIRY_DATE        DATE;
    L_PER_CONV_AMT              NUMBER;
    L_INSURER_CODE              VARCHAR2(9);
    L_CUSTOMER_ID               VARCHAR2(10);
    L_LINE_AVAILABLE_DATE       DATE;

    L_INIT_STAGE_BILL_AMT NUMBER := 0;

    L_EVENT_SEQ_NO CSTB_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE := 0;
    L_EVENT_PCLS   NUMBER;

    DELTA_MAX_LC_AMT  LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;
    DELTA_CONFIRM_AMT LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT%TYPE;
    L_UNCONF_AMT      LCTBS_AVAILMENTS.CURRENT_AVAILABILITY%TYPE;

    L_OS_LIABILITY        LCTBS_AVAILMENTS.OS_LIABILITY%TYPE;
    DELTA_UNDERTAKING_AMT LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT%TYPE;
    L_NOTUNDERTAKING_AMT  LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT%TYPE;

    L_OVD_SEQ                  NUMBER;
    L_CUSTOMER                 ISTM_NETTING_AGREEMENT.CUSTOMER_NO%TYPE;
    L_CUSTOMER_TYPE            STTM_CUSTOMER.CUSTOMER_TYPE%TYPE;
    L_ERR_MSG                  VARCHAR2(300);
    LOC_ERR_CODE               VARCHAR2(50);
    L_AMT                      BCTB_CONTRACT_MASTER.BILL_AMT%TYPE;
    L_CCY                      BCTB_CONTRACT_MASTER.BILL_CCY%TYPE;
    P_PROD_TXN_AUTH_LIMITS_REC CSTMS_PRODUCT_TXN_AUTH_LIM%ROWTYPE;
    L_AUTH_COUNT               NUMBER;

    L_MODULE              SMTB_MENU.MODULE%TYPE;
    L_MAX_CONTRACT_AMOUNT LCTBS_CONTRACT_MASTER.CONTRACT_AMT%TYPE;
    L_SUM                 NUMBER := 0;
    L_BOOL                BOOLEAN := TRUE;
    L_TOTALAMNT           NUMBER := 0;
    L_PROD_TYPE           CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
    L_FLAG                VARCHAR2(1) := 'N';
    L_REIMB               LCTMS_PRODUCT_DEFINITION.REIMBURSEMENT%TYPE;
    L_CUST_COUNT          NUMBER := 0;
    L_PARTIAL_CLOS_DAYS   LCTM_BRANCH_PARAMETERS.PARTIAL_CLOS_DYAFTR_EXP%TYPE;

    L_CONTRACT_AMT          LCTB_CONTRACT_MASTER.CONTRACT_AMT%TYPE;
    L_BENEFICIARY_CONF_REQD LCTB_CONTRACT_MASTER.BENEFICIARY_CONF_REQD%TYPE;
    L_AMEND_CONFIRM_COUNT   NUMBER := 0;
    L_POSITIVE_TOLERANCE    LCTB_CONTRACT_MASTER.POSITIVE_TOLERANCE%TYPE;
    L_NEGATIVE_TOLERANCE    LCTB_CONTRACT_MASTER.NEGATIVE_TOLERANCE%TYPE;
    L_EFFECTIVE_DATE        LCTB_CONTRACT_MASTER.EFFECTIVE_DATE%TYPE;
    L_TENOR                 LCTB_CONTRACT_MASTER.TENOR%TYPE;
    L_EXPIRY_DATE           LCTB_CONTRACT_MASTER.EXPIRY_DATE%TYPE;
    L_LIAB_TOLERANCE        LCTB_CONTRACT_MASTER.LIAB_TOLERANCE%TYPE;
    L_MAX_LIABILITY_AMT     LCTB_CONTRACT_MASTER.MAX_LIABILITY_AMT%TYPE;
    L_CLOSURE_DATE          LCTB_CONTRACT_MASTER.CLOSURE_DATE%TYPE;

    L_CONT_STAT       CSTBS_CONTRACT.CONTRACT_STATUS%TYPE;
    L_CURR_EVENT_CODE CSTB_CONTRACT.CURR_EVENT_CODE%TYPE;
    L_ADB_MEMBER      ISTMS_BIC_DIRECTORY.ADB_MEMBER%TYPE;

    L_DAY         VARCHAR2(2);
    L_MONTH       VARCHAR(3);
    L_YEAR        VARCHAR2(4);
    L_ERROR_PARAM VARCHAR2(255);

    L_DRAFTTOTLEN     NUMBER := 0;
    L_LEN_MULTIPLEFFT NUMBER := 0;
    L_DRAFT_AVL       BOOLEAN := FALSE;
    L_PRODUCT_ST_DATE CSTM_PRODUCT.PRODUCT_START_DATE%TYPE;
    L_PRODUCT_ET_DATE CSTM_PRODUCT.PRODUCT_END_DATE%TYPE;
    L_ADD_AMT_COV     LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED%TYPE;

    L_CY_AMT        LCTBS_CONTRACT_MASTER.CONTRACT_AMT%TYPE;
    L_CY_AMT_LENGTH NUMBER;

    L_FROZEN   STTMS_CUSTOMER.FROZEN%TYPE;
    L_DECEASED STTMS_CUSTOMER.DECEASED%TYPE;

    L_REF_AUTH_STAT CSTB_CONTRACT.AUTH_STATUS%TYPE;
    L_AMNV_COUNT    NUMBER := 0;
    L_DAYS          NUMBER;
    L_COUNT_EXTREF  NUMBER := 0;

    L_STAGE           LCTBS_REG_MASTER.STAGE%TYPE;
    L_REG_TYPE        LCTBS_REG_MASTER.REG_TYPE%TYPE;
    L_CONTRACT_REF_NO LCTBS_REG_MASTER.CONTRACT_REF_NO%TYPE;

    L_UNCONFIRMED_AMND_COUNT NUMBER := 0;
    L_TOT_BLOCKED_AMT        BCTB_LC_BLOCK_DETAILS.BLOCK_AMT%TYPE;
    L_DOC_COUNT              NUMBER := 0;
    L_SWIFT2019_ENABLED      VARCHAR2(1);
    L_USERREFNO_COUNT        NUMBER;
  BEGIN

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CUSTOM THEN
      DEBUG.PR_DEBUG('LC',
                     'Calling  Lcpks_Lcdtronl_Utils_custom.fn_pre_Validate_Master..');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CUSTOM.FN_PRE_VALIDATE_MASTER(P_SOURCE,
                                                             P_FUNCTION_ID,
                                                             P_ACTION_CODE,
                                                             P_PRODUCT_DEFINITION,
                                                             P_LCDTRONL,
                                                             P_PREV_LCDTRONL,
                                                             P_WRK_LCDTRONL,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in  Lcpks_Lcdtronl_Utils_custom.fn_pre_Validate_Master..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CLUSTER THEN
      DEBUG.PR_DEBUG('LC',
                     'Calling  Lcpks_Lcdtronl_Utils_Cluster.fn_pre_Validate_Master..');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CLUSTER.FN_PRE_VALIDATE_MASTER(P_SOURCE,
                                                              P_FUNCTION_ID,
                                                              P_ACTION_CODE,
                                                              P_PRODUCT_DEFINITION,
                                                              P_LCDTRONL,
                                                              P_PREV_LCDTRONL,
                                                              P_WRK_LCDTRONL,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in  Lcpks_Lcdtronl_Utils_Cluster.fn_pre_Validate_Master..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_KERNEL THEN
      DEBUG.PR_DEBUG('LC', 'inside Lcpks_Lcdtronl_Utils.Fn_Skip_Kernel..');

      L_FLD := 'LCTBS_CONTRACT_MASTER.EXT_REF_NO';
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO IS NOT NULL THEN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM CSTB_CONTRACT
         WHERE EXTERNAL_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO
           AND SOURCE = P_SOURCE
           AND CONTRACT_REF_NO <>
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        IF L_COUNT > 0 THEN
          DBG('Duplicate External Reference number');
          P_ERR_CODE   := 'LD-C0402';
          P_ERR_PARAMS := '@' || L_FLD;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LD-C0402', '@' || L_FLD);
        END IF;

      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
        BEGIN
          SELECT COUNT(*)
            INTO L_USERREFNO_COUNT
            FROM CSTB_CONTRACT
           WHERE SOURCE = P_SOURCE
             AND USER_REF_NO = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO
             AND CONTRACT_REF_NO <>
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            L_USERREFNO_COUNT := 0;
        END;

        IF L_USERREFNO_COUNT > 0 THEN
          DBG('Duplicate External Reference number');
          P_ERR_CODE   := 'LD-C0402';
          P_ERR_PARAMS := 'User Ref No ' ||
                          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;

      DBG('Selecting product type....');
      BEGIN
        SELECT PRODUCT_TYPE, PRODUCT_START_DATE, PRODUCT_END_DATE
          INTO L_PROD_TYPE, L_PRODUCT_ST_DATE, L_PRODUCT_ET_DATE
          FROM CSTM_PRODUCT
         WHERE PRODUCT_CODE = P_PRODUCT_DEFINITION.PRODUCT_CODE;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in selecting product type ' || SQLERRM);
          RETURN FALSE;

      END;

      DBG('Product Type = ' || L_PROD_TYPE);

      L_FLD := 'CSTBS_CONTRACT.USER_REF_NO';

      BEGIN
        SELECT PARAM_VAL
          INTO L_SWIFT2019_ENABLED
          FROM CSTB_PARAM
         WHERE PARAM_NAME = 'SWIFTTRADE2019_ENABLED';
      EXCEPTION
        WHEN OTHERS THEN
          L_SWIFT2019_ENABLED := 'N';
          DEBUG.PR_DEBUG('LC', 'Failed in selecting swift enabled param');
      END;
      DBG('l_swift2019_enabled-->' || L_SWIFT2019_ENABLED);

      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

        DBG('inside FN_VALIDATE_MASTer user_defined_status >>' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS);
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS <>
           'NORM' THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-366', NULL);
        END IF;

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
          SELECT CONTRACT_STATUS
            INTO L_CONT_STAT
            FROM CSTBS_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

          IF L_CONT_STAT <> 'A' AND
             P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS <>
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS THEN
            DBG('Status change allowed only for active contracts ..');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-367', NULL);
          END IF;

        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'E') THEN

        IF P_PRODUCT_DEFINITION.TENOR_CODE = 'S' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD NOT IN
           ('P', 'N') THEN
          DBG('this type of credit mode is not allowed for Sight LC type');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-PRD-103', NULL);
        END IF;

        IF P_PRODUCT_DEFINITION.TENOR_CODE = 'U' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD NOT IN
           ('D', 'M', 'N', 'A') THEN
          DBG('this type of credit mode is not allowed for Usance LC type');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-PRD-104', NULL);
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
          DBG('entering draft details loop');
          FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.LAST LOOP

            IF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_TENOR, 0) < 0 THEN
              DBG('Draft tenor field cannot be negative');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-PRD-115',
                           P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_SL_NO);
            END IF;

            IF P_PRODUCT_DEFINITION.TENOR_CODE = 'S' AND P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
              .DRAFT_TENOR > 0 THEN
              DBG('Draft tenor value is not needed for Sight LC type');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-PRD-112',
                           P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_SL_NO);
            END IF;

            IF P_PRODUCT_DEFINITION.TENOR_CODE = 'U' AND P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
              .DRAFT_TENOR IS NULL THEN
              DBG('Draft tenor is mandatory if the LC type is Usance in product level');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-PRD-105',
                           P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_SL_NO);
            END IF;

            IF P_PRODUCT_DEFINITION.TENOR_CODE = 'U' AND P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
              .DRAFT_TENOR IS NOT NULL AND
               P_PRODUCT_DEFINITION.DRAFT_MIN_TENOR IS NOT NULL THEN
              IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
               .DRAFT_TENOR < P_PRODUCT_DEFINITION.DRAFT_MIN_TENOR THEN
                DBG('Draft tenor entered is lesser than the minimum draft days provided in product level');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-PRD-106',
                             P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_SL_NO);
              END IF;

            END IF;

            IF P_PRODUCT_DEFINITION.TENOR_CODE = 'U' AND P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
              .DRAFT_TENOR IS NOT NULL AND
               P_PRODUCT_DEFINITION.DRAFT_MAX_TENOR IS NOT NULL THEN
              IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
               .DRAFT_TENOR > P_PRODUCT_DEFINITION.DRAFT_MAX_TENOR THEN
                DBG('Draft tenor entered is greater than the maximum draft days provided in product level');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-PRD-107',
                             P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_SL_NO);
              END IF;

            END IF;

          END LOOP;

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO IS NOT NULL THEN
        DBG('inside FN_VALIDATE_MASTER 1-->' ||
            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO);
        IF LENGTH(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO) > 16 THEN
          DBG('User Ref Number Length is More than 16 Cant be saved ');
          P_ERR_CODE   := 'LC-VALS-120';
          P_ERR_PARAMS := '@' || L_FLD;
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-VALS-120',
                       '@' || L_FLD);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO IS NOT NULL THEN
        DBG('Validating the p_Wrk_Lcdtronl.v_Cstbs_Contract.User_Ref_No');
        IF NOT
            FN_NETWORK_VALIDATIONS(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO) THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-REF-VAL',
                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO);

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO IS NOT NULL THEN
        DBG('Validating the p_WRK_lcdtronl.v_cstbs_contract.EXTERNAL_REF_NO');
        IF NOT
            FN_NETWORK_VALIDATIONS(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO) THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-REF-VAL',
                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO);

        END IF;

      END IF;

      IF P_FUNCTION_ID IN ('LCDAMEND', 'LIDAMEND') AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE <>
         P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE AND
         P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NOT NULL THEN
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE;
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL AND
         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'H' THEN

        BEGIN
          SELECT AUTH_STATUS
            INTO L_REF_AUTH_STAT
            FROM CSTB_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed to fetch the auth status of Related Ref no');

        END;

        IF NVL(L_REF_AUTH_STAT, 'X') <> 'A' THEN
          DBG('Unauthorized Related LC Reference number cannot be linked to a shipping guarantee');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-800', NULL);
        END IF;

        SELECT OS_LIABILITY
          INTO L_MAX_CONTRACT_AMOUNT
          FROM LCTBS_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTBS_AVAILMENTS
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO);

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT >
           L_MAX_CONTRACT_AMOUNT THEN
          DBG(' SG amount is greater then linked LC Outstanding amount.');
          P_ERR_CODE   := 'LC-VALS-336';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

      END IF;

      IF NOT SMPKS.FN_LIMITS_VALIDATE('I',
                                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                      GLOBAL.USER_ID,
                                      GLOBAL.CURRENT_BRANCH,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, NULL);

      END IF;

      DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
      BEGIN
        SELECT MODULE
          INTO L_MODULE
          FROM SMTB_MENU
         WHERE FUNCTION_ID = P_FUNCTION_ID;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('In when others while getting module..');
          P_ERR_CODE   := 'ST-OTHR-001';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;

      END;

      BEGIN
        SELECT 1
          INTO L_AUTH_COUNT
          FROM CSTBS_CONTRACT
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND AUTH_STATUS = 'A';

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_AUTH_COUNT := 0;
        WHEN OTHERS THEN
          DBG('In when others while getting l_auth_count.. - ' || SQLERRM);
          P_ERR_CODE   := 'ST-OTHR-001';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;

      END;

      IF NOT
          SMPKS_FCJ_TXNLIMITCHK.FN_VALIDATE_PRODUCT_TXN_LIMIT(P_BRANCH          => GLOBAL.CURRENT_BRANCH,
                                                              P_MODULE_ID       => L_MODULE,
                                                              P_PRODUCT_CODE    => SUBSTR(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                                                          4,
                                                                                          4),
                                                              P_CONTRACT_REF_NO => P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                              P_EVENT_SEQ_NO    => P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                                              P_CUSTOMER_NO     => P_WRK_LCDTRONL.V_CSTBS_CONTRACT.COUNTERPARTY,
                                                              P_TXN_AMT         => P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                              P_TXN_CCY         => P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                                              P_ERRORCODE       => P_ERR_CODE,
                                                              P_ERRORMSG        => L_ERR_MSG) THEN
        DBG('Return False from    smpks_fcj_txnlimitchk.fn_validate_product_txn_limit');
        RETURN FALSE;
      END IF;

      DBG('CHECKING IF pcls FIRED BEFORE OR NOT');

      SELECT MAX(EVENT_SEQ_NO)
        INTO L_EVENT_SEQ_NO
        FROM CSTB_CONTRACT_EVENT_LOG
       WHERE EVENT_CODE = 'ROPN'
         AND CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

      DBG('ROPN l_event_seq_no ' || L_EVENT_SEQ_NO);
      BEGIN
        SELECT 1
          INTO L_EVENT_PCLS
          FROM CSTB_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND EVENT_CODE = 'PCLS'
           AND EVENT_SEQ_NO > NVL(L_EVENT_SEQ_NO, 0);
        IF L_EVENT_PCLS IS NOT NULL THEN
          DBG('PCLS fired');
          IF P_ACTION_CODE NOT IN
             (CSPKS_SERVICE.P_CLOSE, CSPKS_REQ_GLOBAL.P_REOPEN) THEN
            DBG('If PCLS event is fired than only closure operation is allowed');
            P_ERR_CODE   := 'LCCON-345';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

        END IF;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('PCLS not fired' || SQLERRM);

      END;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE = 'PCLS' THEN
        DBG('Partial Closure Not os liab chk');
        SELECT OS_LIABILITY
          INTO L_OS_LIABILITY
          FROM LCTBS_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTBS_AVAILMENTS
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

        IF L_OS_LIABILITY = 0 THEN
          DBG('Partial Closure Not Allowed as outstanding liability is zero');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-343', '');
          RETURN FALSE;
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE = 'V' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE = 'C' THEN

        DBG('Cummulative option cannot be set When Reinstament type is VALUE');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-361', '');

      END IF;

      DBG('Partial Closure:: ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE);
      DBG('REVOLVES_IN:: ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN);

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN IS NOT NULL AND
         NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE, 'N') = 'Y' THEN
        DBG('Partial Closure not allowed for non revolving LCs.');
        P_ERR_CODE   := 'LC-VALS-342';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS IS NOT NULL THEN
        DBG('Enter into PAYMENT DETAILS..');

        IF NOT LCPKS_ADV_MISC.FN_CHECK_STRING_VALIDITY(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS,
                                                       35,
                                                       4) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-106', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD IN
         ('M', 'D') AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS IS NULL THEN
        DBG('Details is manadatory');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-MTD-01', NULL);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_BEN IS NOT NULL THEN
        DBG('Enter into CHARGES_FROM_BEN..' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_BEN);

        IF NOT LCPKS_ADV_MISC.FN_CHECK_STRING_VALIDITY(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_BEN,
                                                       35,
                                                       6) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-101', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED IS NOT NULL THEN
        DBG('Enter into ADDITIONAL_AMTS_COVERED..' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED);

        IF NOT LCPKS_ADV_MISC.FN_CHECK_STRING_VALIDITY(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED,
                                                       35,
                                                       4) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-102', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH IS NOT NULL THEN
        DBG('Enter into Credit Available With..');

        IF NOT LCPKS_ADV_MISC.FN_CHECK_STRING_VALIDITY(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH,
                                                       35,
                                                       4) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-103', NULL);
        END IF;

        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM ISTMS_BIC_DIRECTORY
           WHERE BIC_CODE =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH;

          IF L_COUNT = 0 THEN
            DBG('override for invalid BIC code');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-096', NULL);
          END IF;

        END;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_ISB IS NOT NULL THEN
        DBG('Enter into Charges_From_Isb..');
        IF NOT LCPKS_ADV_MISC.FN_CHECK_STRING_VALIDITY(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_ISB,
                                                       35,
                                                       6) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-108', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO IS NOT NULL THEN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM CSTB_CONTRACT
         WHERE USER_REF_NO = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO
           AND CONTRACT_REF_NO <>
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        IF L_COUNT > 0 THEN
          DBG('Duplicate User Ref Reference number');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LD-C0402', '@' || L_FLD);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
         ('OPN', 'ONC', 'PAD', 'ADV', 'CNF', 'ANC', 'RMB') THEN
        DBG('Invalid operation code' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
        P_ERR_CODE   := 'LCUPLD-067';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      IF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD' THEN
        DBG('Change of operation code to PAD not allowed');
        P_ERR_CODE   := 'LCUPLD-358';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      DBG('HER111------->>>>>>');
      DBG('p_wrk_lcdtronl.v_lctbs_contract_master.operation_code :' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
      DBG('p_prev_lcdtronl.v_lctbs_contract_master.operation_code ' ||
          P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
      DBG('p_wrk_lcdtronl.v_lctbs_contract_master.pre_adv_date ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE);
      DBG('p_prev_lcdtronl.v_lctbs_contract_master.pre_adv_date ' ||
          P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE);

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN
        IF NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE,
               'ZZZ') <> 'PAD' AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE IS NOT NULL AND
           P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE IS NULL THEN
          DBG('Pre Advice Date cannot be entered for operation other than Pre Advice');
          P_ERR_CODE   := 'LCUPLD-359';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE >
         GLOBAL.APPLICATION_DATE THEN
        DBG('Pre Advice Date cannot be greater than application date');
        P_ERR_CODE   := 'LCUPLD-360';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      IF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE IS NOT NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE <>
           P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE THEN
          DBG('Change of issue date is not allowed');
          P_ERR_CODE   := 'LCUPLD-361';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE = 'Y' THEN
        DBG('Partial Closure Not Allowed For Pre-Advice Contract');
        P_ERR_CODE   := 'LCUPLD-365';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ADV' AND
         NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM, 'N') IN
         ('Y', 'C') AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY = 'ABK' THEN
        DBG('Advising Bank cannot be the confirmation party when confirm option is selected');
        P_ERR_CODE   := 'LCUPLD-605';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
      --sampath commented starts
      /*IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
         NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM, 'N') = 'C' AND
         (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'I' OR
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ANC') THEN
        DBG('Confirm option is not applicable');
        P_ERR_CODE   := 'LCUPLD-606';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;*/
      --sampath commented ends

      DBG('req_confirm_party' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY);
      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'E') THEN
        IF ((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ONC' OR
           (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
           ('OPN') AND NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM,
                              'N') IN ('Y', 'C'))) AND
           P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'I') OR
           ((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
           ('ADV')

           AND NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM,
                     'N') IN ('Y', 'C'))

           AND P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E') THEN
           dbg('null');
           --sampath commented starts
          /*IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY IS NULL AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE <> 'ILSR' THEN --sampath
            DBG('Requested Confirmation Party cannot be NULL when May confirm flag is selected.');
            P_ERR_CODE   := 'LCUPLD-601';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;*/
          --sampath commented ends
        ELSE
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'CNF' THEN
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY IS NOT NULL THEN
              DBG('Requested Confirmation Party should be NULL when May confirm flag is not selected.');
              P_ERR_CODE   := 'LCUPLD-602';
              P_ERR_PARAMS := NULL;
              RETURN FALSE;
            END IF;
          END IF;
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE IS NOT NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE >
           GLOBAL.APPLICATION_DATE THEN
          DBG('Issue date is Greater than Application Date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-084', NULL);

        END IF;

        IF L_PRODUCT_ST_DATE IS NOT NULL THEN
          IF L_PRODUCT_ST_DATE >
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE THEN
            DBG('Issue Date cannot be less than Start date of the Product');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-750', NULL);
          END IF;

        END IF;

        IF L_PRODUCT_ET_DATE IS NOT NULL THEN
          IF L_PRODUCT_ET_DATE <
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE THEN
            DBG('Issue Date cannot be greater than End date of the Product');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-751', NULL);
          END IF;

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE IS NOT NULL THEN
        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
               GLOBAL.APPLICATION_DATE) <
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE AND
           L_PROD_TYPE <> 'G' THEN
          DBG('Effective date cannot be earlier than the Issue date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-230', NULL);
        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE != 'E' THEN

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
           ('OPN', 'ONC', 'RMB', 'PAD')

           OR (P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('G', 'H') AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE =
           'PAD')

         THEN
          DBG('Invalid combination of product code and operation code');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-088', NULL);
        END IF;

      ELSE
        IF P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE = 'Y' THEN

          IF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
             ('ADV') AND L_SWIFT2019_ENABLED = 'N') OR
             (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
             ('ADV', 'ANC') AND L_SWIFT2019_ENABLED = 'Y') THEN

            DBG('Invalid combination of product code and operation code');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-088', NULL);
          END IF;

        ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
              ('ADV', 'ANC', 'CNF', 'PAD') THEN
          DBG('Invalid combination of product code and operation code');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-088', NULL);

        END IF;

      END IF;

      DBG('Checking for May_confirm' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE || '~' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM);
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ONC' AND
         NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM, 'N') = 'Y' THEN

        DBG('May Confirm Should not be checked if the Operation code is Open and Confirm');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-252', NULL);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN ('RMB') AND
         NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'N' THEN

        DBG('Invalid combination of product code and operation code');
        OVPKS.PR_APPENDTBL('LCUPLD-088', NULL);
      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE != 'E' AND
         NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
             'N') = 'Y' THEN
        DBG('Partial confirmation flag is allowed only for export products');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-505', NULL);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
         ('ANC', 'CNF', 'ADV', 'PAD') AND
         NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
             'N') = 'Y' THEN
        DBG('Partial confirmation flag can only be checked when oper code is adv,anc,pad or cnf');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-505', NULL);
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW OR
         (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND ((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
         ('CNF', 'ANC'))

         AND P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
         ('ADV', 'PAD'))) THEN
        IF NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT, 0) > 0 AND
           NVL(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT, 0) > 0 THEN
          DBG('Both Confirm Amount And Confirm Percent is specified');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-215', NULL);
        END IF;

        IF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
           ('ANC', 'CNF'))

         THEN
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT, 0) > 100 OR
             NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT, 0) >
             NVL(P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY, 0) THEN

            DBG('Confirm Amt is greater than Current Availability and/or confirm percent is greater than 100');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-508', NULL);
          END IF;

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE IS NOT NULL THEN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM LCTBS_ALLOWED_PARTIES A, STTBS_VALUE_DESC B

         WHERE UPPER(B.ITEM_VALUE) = UPPER(A.PARTY_TYPE)
           AND UPPER(B.FUNCTION_ID) = UPPER('LCtronlL')
           AND UPPER(B.BLOCK_NAME) = 'LCTBS_PARTIES'
           AND UPPER(B.ITEM_NAME) = 'PARTY_TYPE'

           AND UPPER(B.LANGUAGE_CODE) = 'ENG'

           AND A.PRODUCT_TYPE = P_PRODUCT_DEFINITION.PRODUCT_TYPE
           AND A.OPERATION_CODE = 'CIF'
           AND A.PARTY_TYPE =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE;

        IF L_COUNT = 0 THEN
          DBG('Invalid Party Type');

        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'C', 'H', 'S', 'G') THEN

        IF P_PRODUCT_DEFINITION.CONFIRMATION_REQUIRED = 'Y' AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'OPN' THEN

          DBG('override for conformation');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-018', NULL);
        ELSIF P_PRODUCT_DEFINITION.CONFIRMATION_REQUIRED = 'N' AND
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ONC' THEN

          DBG('override for conformation');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-019', NULL);

        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' THEN

        IF P_PRODUCT_DEFINITION.CONFIRMATION_REQUIRED = 'Y' AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ADV' THEN

          DBG('override for conformation');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-018', NULL);

        ELSIF P_PRODUCT_DEFINITION.CONFIRMATION_REQUIRED = 'N' AND
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'ANC' THEN

          DBG('override for conformation');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-019', NULL);

        END IF;

      END IF;

      DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Revolves_In' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN);
      IF P_PRODUCT_DEFINITION.REVOLVING = 'Y' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN = 'T' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY IS NULL THEN
          DBG('The frequency is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-125', NULL);

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS IS NULL THEN
          DBG('The Units is null');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-126', NULL);
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS NOT IN ('D', 'M') THEN

          DBG('Invalid units');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-005', NULL);
        END IF;

      ELSIF P_PRODUCT_DEFINITION.REVOLVING = 'Y' AND
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN = 'V' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY IS NOT NULL THEN
          DBG('frequency is not required');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-006', NULL);
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS IS NOT NULL THEN
          DBG('units is not required');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-007', NULL);
        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.REVOLVING = 'N' THEN

        DBG('Checking for next_reinstatement_date to null ');
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN IS NULL AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS IS NULL AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY IS NULL THEN
          DBG('Initializing next_reinstatement_date to null ');
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE := NULL;
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE      := NULL;
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE              := NULL;
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN IS NOT NULL OR
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS IS NOT NULL OR
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY IS NOT NULL OR
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE IS NOT NULL THEN
          DBG('The product is non revolving type ');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-008', NULL);
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE      := NULL;
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE              := NULL;
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS                   := NULL;
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY               := NULL;
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE := NULL;
        ELSE
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE = 'A' OR
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE = 'C' THEN

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-008', NULL);
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE := NULL;
          END IF;

        END IF;

      ELSE

        DBG('Product is revolving');
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE IS NOT NULL THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE >
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE OR
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE <
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-112', NULL);
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE IS NOT NULL THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE NOT IN
             ('C', 'N') THEN
            DBG('Invalid value for cumulative');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-009', NULL);
          END IF;

        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.REVOLVING = 'Y' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN NOT IN
           ('T', 'V')

           OR P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN IS NULL

         THEN
          DBG('Invalid revolving');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-010', NULL);
        END IF;

        DBG('p_wrk_lcdtronl.v_lctbs_contract_master.revolves_in' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN);
        DBG('p_wrk_lcdtronl.v_lctbs_contract_master.cumulative' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE);
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN = 'V' AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE = 'C' THEN

          DBG('When Revolves in is value then cumulative flag should nt be checked');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-096', NULL);
        END IF;

      END IF;

      L_UNIT := UPPER(SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                             -1,
                             1));
      L_WHNO := SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                       1,
                       LENGTH(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR) - 1);
      L_CHNO := ABS(TRUNC(L_WHNO, 0));
      DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Tenor' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR);
      IF LENGTH(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR) = 1 AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR NOT IN
         ('1', '2', '3', '4', '5', '6', '7', '8', '9') THEN
        DBG('Invalid tenor1');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-317', NULL);
      END IF;

      IF LENGTH(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR) <> 1 THEN
        IF L_WHNO IS NULL OR L_CHNO = 0 THEN

          DBG('Invalid tenor2');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-317', NULL);
        END IF;

      END IF;

      IF L_UNIT NOT IN ('Y', 'M', 'D') THEN

        DBG('Invalid teno3');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-317', NULL);
      END IF;

      IF L_WHNO <> L_CHNO OR L_WHNO = 0 THEN
        DBG('Invalid tenor4');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-317', NULL);
      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E'

         AND NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'N' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE IS NULL THEN
          DBG('issue_date is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-133', 'Issue Date');
        ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE IS NULL THEN
          DBG('effective_date is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LCCON-133',
                       'Effective Date');

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH IS NULL THEN
          DBG('credit_avl_with is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-128', NULL);
        ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_TYPE IS NULL THEN
          DBG('the settlement_type is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-129', NULL);

        ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD IS NULL THEN
          DBG('the settlement_method is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-130', NULL);

        END IF;

      END IF;

      DBG('p_product_definition.product_type::' ||
          P_PRODUCT_DEFINITION.PRODUCT_TYPE);
      DBG('The product type is:' || P_PRODUCT_DEFINITION.REIMBURSEMENT);
      IF ((P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I') AND
         NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'Y') OR
         (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'R')) OR
         P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('H', 'G')

         OR ((P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
         NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y'))

       THEN
        NULL;
      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_PLACE IS NULL THEN
          DBG('expiry place is null');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-205', NULL);

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NULL THEN
        DBG('expiry date is null');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-310', NULL);

      END IF;

      IF L_PROD_TYPE IN ('I', 'E') AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD' THEN
        NULL;
      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE IS NULL THEN
          DBG('issue_date is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-133', 'Issue Date');
        ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE IS NULL THEN
          DBG('effective_date is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LCCON-133',
                       'Effective Date');

        END IF;

      END IF;

      IF L_PROD_TYPE IN ('I', 'C') THEN

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH IS NULL THEN

          IF L_PROD_TYPE = 'I' AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD' THEN
            NULL;
          ELSE

            DBG('credit_avl_with is NULL');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-128', NULL);

          END IF;
        ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_TYPE IS NULL THEN
          DBG('the settlement_type is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-129', NULL);

        ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD IS NULL THEN
          DBG('the settlement_method is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-130', NULL);

        END IF;

      END IF;

      DBG('The product type is:' || P_PRODUCT_DEFINITION.REIMBURSEMENT);
      IF NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') <> 'Y' THEN

        DBG('The product type is:' || P_PRODUCT_DEFINITION.REIMBURSEMENT);
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE IS NOT NULL OR
           NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT, 0) <> 0 THEN
          DBG('The undertaking expiry date is:' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE);
          DBG('The Undertaking Amount is:' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT);
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-324', NULL);
        END IF;

      ELSE
        DBG('checking the undertaking amount :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT);
        DBG('checking the max_contract_amt :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);
        IF P_ACTION_CODE = CSPKS_SERVICE.P_NEW THEN
          DBG('p_action_code :' || P_ACTION_CODE);
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                 0) >
             NVL(P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY, 0) THEN

            DBG('Undertaking Amount should not be greater than the Contract Amount');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-327', NULL);
          END IF;

        END IF;

        DBG('checking the undertaking Exp date :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE);
        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT, 0) = 0 AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE IS NOT NULL THEN
          DBG('Undertaking Exp date should not be entered when undertaking Amount is zero');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-328', NULL);
        END IF;

        DBG('checking the Issue date :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE);
        DBG('checking the Exp date :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        DBG('checking the undertaking Exp date :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE);
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE IS NOT NULL THEN
          DBG('Validation of Undertaking Exp date against Issue date and Expiry date');
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE <
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE OR
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE >
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
            DBG('Undertaking Expiry date cannot be earlier than Issue date and later than Expiry Date');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-329', NULL);
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NULL THEN
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE >
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE THEN
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-341', NULL);
            END IF;

          END IF;

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD IN
         ('D', 'M') AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS IS NULL THEN
        DBG('The payment_details is NULL');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-206', NULL);
      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'H' THEN

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL THEN

          SELECT COUNT(*)
            INTO L_COUNT
            FROM BCTBS_CONTRACT_MASTER
           WHERE (OUR_LC_REF =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO AND
                 LC_FLAG = 'Y')
              OR (THEIR_LC_REF =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO AND
                 OPERATION = 'COL');

          IF L_COUNT > 0 THEN
            DBG('LC linked to BC');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-212', NULL);
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NULL AND
           P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'H' THEN

          DBG('For this SG contract LC is not linked, proceed ? ');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-511', NULL);
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE IS NOT NULL THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE = 'Y' THEN
            DBG('not allowed under this product');

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-332', NULL);

          END IF;

        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'S' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_PLACE IS NULL THEN
          DBG('the expiry_place is null');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-207', NULL);
        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.GUARANTEE_TYPE IS NULL THEN
          DBG('the guarantee_type is null');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-208', NULL);
        END IF;

        IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                0) > 0 OR NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                               0) > 0) THEN

          DBG('tolerance limit not reqd');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-333', NULL);
        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE, 'N') = 'Y' AND
           L_SWIFT2019_ENABLED = 'N' THEN

          DBG('Transfereable is y');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-332', NULL);
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE IS NULL THEN
          DBG('Applicable rule cannot be null for guarantee type of products');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-360', NULL);
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO IS NOT NULL AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE IS NOT NULL AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE >
           GLOBAL.APPLICATION_DATE THEN
          DBG('Customer reference date cannot be future dated');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-902', NULL);
        END IF;

      END IF;

      DEBUG.PR_DEBUG('LC',
                     'Product Type is' || P_PRODUCT_DEFINITION.PRODUCT_TYPE);
      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
         (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
         NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') OR
         (L_SWIFT2019_ENABLED = 'Y' AND
         P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'S') THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_REQUEST IS NULL THEN
          DBG('Issue/Request is null');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-240', NULL);
        END IF;

      END IF;

      IF (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'H') OR
         (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' AND
         L_SWIFT2019_ENABLED = 'N') THEN

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE = 'Y' THEN

          DBG('transferable flag not reqd');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-332', NULL);
        END IF;

      END IF;

      IF ((P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('G', 'H')) OR
         (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
         P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE = 'Y')) THEN
        DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Settlement_Method' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD);
        DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Payment_Details' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS);

        IF ((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD IS NOT NULL) OR
           (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS IS NOT NULL)) THEN

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-334', NULL);
        END IF;

        IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                0) > 0 OR NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                               0) > 0)

         THEN
          DBG('positive_tolerance Not reqd');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-333', NULL);
        END IF;

      END IF;

      DEBUG.PR_DEBUG('LC',
                     'Product Type is' || P_PRODUCT_DEFINITION.PRODUCT_TYPE);
      DEBUG.PR_DEBUG('LC',
                     'Advice of gua is' ||
                     P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE);
      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('G', 'H', 'S') OR
         (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
         NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
        DBG('The field Guarantee can be entered');
      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_REQUEST IS NOT NULL THEN
          DBG('the issue request is not required');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-335', NULL);
        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('H', 'G') THEN

        IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM IS NOT NULL

         THEN
          DBG('the INCO is not required');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-013', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_REQUEST IS NOT NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_REQUEST NOT IN
           ('I', 'R') THEN
          DBG('Invalid issue_request type');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-014', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE IS NOT NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE NOT IN
           ('M', 'A') THEN
          DBG('Invalid closure type');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-015', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE = 'A' THEN
          DBG('closure flag not reqd');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-016', NULL);
        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE = 'A' THEN

          DBG('closure flag not reqd');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-430', NULL);

        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('G', 'S') OR
         (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
         NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
        DBG('The field guarantee_type can be entered/Null');
      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.GUARANTEE_TYPE IS NOT NULL THEN
          DBG('guarantee_type not reqd');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-017', NULL);
        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
         P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE = 'Y' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.GUARANTEE_TYPE IS NULL THEN
          DBG('the guarantee_type is null cmg here');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-208', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT < 0 THEN
        DBG('Contract amount should be greater than 0');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-019', NULL);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE IS NOT NULL THEN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM SMTBS_LANGUAGE
         WHERE LANG_CODE =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE;

        IF L_COUNT = 0 THEN
          DBG('Invalid language code');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-020', NULL);
        END IF;

      END IF;

      DBG('p_Product_Definition.Applicable_Rule' ||
          P_PRODUCT_DEFINITION.APPLICABLE_RULE);

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE = 'OTHR' THEN

        L_FLD := 'LCTBS_CONTRACT_MASTER.RULE_NARRATIVE';
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RULE_NARRATIVE IS NULL THEN
          DBG('rule_narrative is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'MS-SWIFT017',
                       '@' || L_FLD);
        ELSE
          IF NOT
              FN_NETWORK_VALIDATIONS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RULE_NARRATIVE) THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'MS-SWIFT016',
                         '@' || L_FLD);
          END IF;

        END IF;

      ELSE

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RULE_NARRATIVE IS NOT NULL THEN
          DBG('Rule_Narrative must be NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCPR-076', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NOT NULL THEN
        DBG('p_action_code' || P_ACTION_CODE);
        DBG('Expiry date' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        DBG('Application Date' || GLOBAL.APPLICATION_DATE);
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE <
           GLOBAL.APPLICATION_DATE THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,

                       'LC-VALS-110',
                       NULL);
        END IF;

        DBG('Prev date is  ' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE ||
            'and new date is ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE =
           P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
          DBG('There is no change in expiry date');
        ELSE
          DBG(' There is change in expiry date..Prev date is  ' ||
              P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE ||
              'and new date is ' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE <
             GLOBAL.APPLICATION_DATE THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,

                         'LC-VALS-110',
                         NULL);
          END IF;

        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
               GLOBAL.APPLICATION_DATE) >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
          DBG('The effective date cannot be greater than expiry date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-210', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NOT NULL THEN
        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
               GLOBAL.APPLICATION_DATE) >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE THEN
          DBG('effective date cannot be greater then closure date');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-211     ', NULL);

        END IF;

      END IF;

      IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
              GLOBAL.APPLICATION_DATE) +

         NVL(NVL(L_WHNO, P_PRODUCT_DEFINITION.STANDARD_TENOR), 1)) <

         (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
              GLOBAL.APPLICATION_DATE)) THEN
        DBG('The issue date cannot be greater than expiry_date');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-061', NULL);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NOT NULL THEN
        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
               GLOBAL.APPLICATION_DATE) >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE THEN
          DBG('The issue date cannot be greater than closure date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-062', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NOT NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE THEN
          DBG('The expiry date cannot be greater than closure date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-063', NULL);
        END IF;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
         (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
         NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_DATE >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
          DBG('Claim Date cannot be greater than Gurantee Expiry Date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-552', NULL);
        END IF;
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE <
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
          DBG('Claim Expiry Date cannot be less than Gurantee Expiry Date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-553', NULL);
        END IF;
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE THEN
          DBG('Claim Expiry Date cannot be greater than Closure Date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-554', NULL);
        END IF;
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_DATE >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE THEN
          DBG('Claim Date cannot be greater than Gurantee Expiry Date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-557', NULL);
        END IF;
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE <>
           (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE +
           P_PRODUCT_DEFINITION.CLAIM_DAYS) THEN
          DBG('Defaulted claim expiry date is changed');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-555', NULL);
        END IF;
      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_DATE IS NOT NULL OR
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE IS NOT NULL THEN
          DBG('Claim Date and Claim Expiry Date should be NULL for non-guarantee products');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-550', NULL);
        END IF;
        IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 OR
           P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT > 0 THEN
          FOR I IN P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.LAST LOOP
            IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_TYPE = 'C' THEN
              DBG('Claim Documents can be captired only for gurantee products');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-556', NULL);
            END IF;
          END LOOP;
        END IF;

      END IF;

      IF P_FUNCTION_ID IN ('LCDAMEND', 'LIDAMEND') AND
         (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE >
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE)

       THEN
        DBG('Expiry date is being reduced in LCDAMEND.. So assiging new value');
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE;
      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE IS NOT NULL THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE <
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE OR
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE >
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
            DBG('incorrect stop_date');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-216', NULL);
          END IF;

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT IS NOT NULL THEN
        IF NVL(P_PRODUCT_DEFINITION.REVOLVING, 'N') = 'Y' THEN
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE,
                 'M') = 'A' AND
             NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN, 'N') = 'T' THEN

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS = 'D' THEN

              L_DAYS := (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE);
              IF MOD(L_DAYS,
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY) = 0 THEN
                L_TEMP := TRUNC((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE) /
                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY);
              ELSE

                L_TEMP := TRUNC((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE) /
                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY) + 1;
              END IF;

            ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS = 'M' THEN

              IF MOD(MONTHS_BETWEEN(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE,
                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE),
                     1) <> 0 THEN
                DBG('Returning l_Temp by adding 1 to it');
                L_TEMP := TRUNC(MONTHS_BETWEEN(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE) /
                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY) + 1;
              ELSE
                DBG('Returning l_Temp directly');
                L_TEMP := TRUNC(MONTHS_BETWEEN(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE) /
                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY);

              END IF;

            END IF;

          END IF;

        ELSE
          L_TEMP := 1;

        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT, 0) /
           L_TEMP <
           NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT, 0) THEN
          LO_MIN_AMT := L_TEMP * NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                                     0);
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LCCON-065',
                       LTRIM(CSFNS_FORMAT_AMT(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                              LO_MIN_AMT)));

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE = 'A' AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN = 'T' THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NULL OR
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE IS NULL OR
             NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY, 0) = 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-067', NULL);
          END IF;

        END IF;

      END IF;
      DBG('Calling Fn_Validate_Partytyp');
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE IS NOT NULL THEN
        IF NOT FN_VALIDATE_PARTYTYP(P_SOURCE,
                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE,
                                    P_PRODUCT_DEFINITION.PRODUCT_TYPE,
                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
          DBG('Invalid cust_type');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LCUPLD-041',
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE);
        END IF;

        NULL;
      END IF;

      DBG('After Fn_Validate_Partytyp');
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM IS NOT NULL THEN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM LCTBS_INCO_TERMS
         WHERE INCO_TERM = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM;

        IF L_COUNT = 0 THEN
          DBG('Invalid inco_term');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-021', NULL);
        END IF;

      END IF;

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHG_CLM_SWIFT, 'N') = 'Y' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHGCLM_TEMPLATE_ID IS NULL THEN
          DBG('TEMPLATE ID SHOULD NOT BE NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-320', NULL);
        END IF;

      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHGCLM_TEMPLATE_ID IS NOT NULL THEN
          DBG('TEMPLATE ID SHOULD BE NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-321', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN

        IF NOT CEPKSS_DATE.FN_ISHOLIDAY('CCY',
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                        L_HOLIDAY) THEN
          DBG('Failed in cepkss_date.fn_isholiday');

          L_ERROR_PARAM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
          IF CEPKS_DATE.FN_SPLITDATE(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                     L_DAY,
                                     L_MONTH,
                                     L_YEAR) THEN
            L_ERROR_PARAM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY ||
                             ' and month' || L_MONTH || ',year' || L_YEAR;
          END IF;

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-HOL-01', L_ERROR_PARAM);

        END IF;

      END IF;
      IF L_HOLIDAY = 'H' THEN
        DBG('Issue date is a holiday');

        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'LC-CO012',
                     '@' ||
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE || '~' || '@' ||
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY);

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NOT NULL THEN
        IF NOT CEPKSS_DATE.FN_ISHOLIDAY('CCY',
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE,
                                        L_HOLIDAY) THEN
          DBG('Failed in cepkss_date.fn_isholiday');

          L_ERROR_PARAM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
          IF CEPKS_DATE.FN_SPLITDATE(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE,
                                     L_DAY,
                                     L_MONTH,
                                     L_YEAR) THEN
            L_ERROR_PARAM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY ||
                             ' and month' || L_MONTH || ',year' || L_YEAR;
          END IF;

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-HOL-01', L_ERROR_PARAM);

        END IF;

        IF L_HOLIDAY = 'H' THEN

          DBG('Expiry date is a holiday');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-CO003',
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NOT NULL THEN
        IF NOT CEPKSS_DATE.FN_ISHOLIDAY('CCY',
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE,
                                        L_HOLIDAY) THEN

          L_ERROR_PARAM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
          IF CEPKS_DATE.FN_SPLITDATE(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE,
                                     L_DAY,
                                     L_MONTH,
                                     L_YEAR) THEN
            L_ERROR_PARAM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY ||
                             ' and month' || L_MONTH || ',year' || L_YEAR;
          END IF;

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-HOL-01', L_ERROR_PARAM);

        END IF;

        IF L_HOLIDAY = 'H' THEN

          DBG('closure date is a holiday');

          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-CO004',
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE);

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE IS NOT NULL THEN
        IF NOT CEPKSS_DATE.FN_ISHOLIDAY('CCY',
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                        L_HOLIDAY) THEN
          L_ERROR_PARAM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
          IF CEPKS_DATE.FN_SPLITDATE(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                     L_DAY,
                                     L_MONTH,
                                     L_YEAR) THEN
            L_ERROR_PARAM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY ||
                             ' and month' || L_MONTH || ',year' || L_YEAR;
          END IF;

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-HOL-01', L_ERROR_PARAM);
        END IF;

        IF L_HOLIDAY = 'H' THEN

          DBG('Claim Expiry Date is a holiday');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-VALS-562',
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE);
        END IF;

      END IF;

      DBG(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE);
      DBG(P_PRODUCT_DEFINITION.MAXIMUM_TENOR);

      IF ((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE >
         P_PRODUCT_DEFINITION.MAXIMUM_TENOR)) THEN
        DBG('More than max tenor');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-085', NULL);
      END IF;

      IF ((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE <
         P_PRODUCT_DEFINITION.MINIMUM_TENOR)) THEN
        DBG('less than min tenor');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-086', NULL);
      END IF;

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') = 'N' THEN

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE IN ('I', 'G', 'S') OR
           (P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'E' AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
           ('ANC', 'CNF')) THEN
          DBG('override for limit track');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-402', NULL);

        ELSE

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-089', NULL);

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE = 'A' OR
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NOT NULL THEN
          DBG('closure date not reqd');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-089', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT IS NOT NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT NOT IN
           ('N', 'A', 'C', 'X') THEN
          DBG('Invalid tolerance_text');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-023', NULL);
        END IF;

      END IF;

      L_FLD := 'LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD';
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD NOT IN
         ('P', 'A', 'D', 'M', 'N') THEN
        DBG('Invalid value for p_Wrk_Lcdtronl.v_lctbs_contract_master.settlement_method');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LD-VALS-012', '@' || L_FLD);
      END IF;

      DBG('p_Wrk_Lcdtronl.v_Lctbs_Drafts.COUNT' ||
          P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.LAST LOOP

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_TENOR IS NULL THEN
            DBG('The Tenor is NULL');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-DRFT-06', NULL);

          ELSE
            L_DRAFT_AVL := TRUE;
            DBG('The Tenor is NOT NULL');
            DBG('length of the tenor code' ||
                LENGTH(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_TENOR));
            DBG('length of the tenor code' ||
                LENGTH(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).CREDIT_DAYS_FROM));

            L_DRAFTTOTLEN := L_DRAFTTOTLEN +
                             (NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                                         .DRAFT_TENOR),
                                  0) + NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                                                   .CREDIT_DAYS_FROM),
                                            0));

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE IS NOT NULL THEN
            BEGIN
              SELECT FROZEN, DECEASED
                INTO L_FROZEN, L_DECEASED
                FROM STTM_CUSTOMER
               WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE;

            EXCEPTION
              WHEN OTHERS THEN
                DBG('failed in selecting frozen/deceased in drafts');

            END;

            IF NVL(L_FROZEN, 'N') = 'Y' OR NVL(L_DECEASED, 'N') = 'Y' THEN
              DBG('drafts >>frozen/deceased customer not allowed');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-VALS-394',
                           P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE);
            END IF;

          END IF;

          FOR J IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.LAST LOOP
            IF I != J THEN
              IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
               .DRAFT_TENOR = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(J).DRAFT_TENOR THEN

                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-DRFT-08', NULL);

                EXIT;
              END IF;

            END IF;

          END LOOP;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).PCT_AMT = 'P' AND P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
             .DRAFT_AMT IS NOT NULL THEN
            DBG('Amount not reqd');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-024', NULL);
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).PCT_AMT = 'A' AND P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
             .DRAFT_PCT IS NOT NULL THEN
            DBG('Percentage not reqd');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-025', NULL);
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).PCT_AMT = 'P' THEN
            L_TOTALAMT := L_TOTALAMT +
                          NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_PCT, 0) *
                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT / 100;
          ELSE
            L_TOTALAMT := L_TOTALAMT +
                          NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_AMT, 0);

          END IF;

          L_TOTALAMNT := 0;
          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).PCT_AMT = 'P' THEN
            L_TOTALAMNT := L_TOTALAMNT +
                           NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_PCT,
                               0) *
                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT / 100;
          ELSE
            L_TOTALAMNT := L_TOTALAMNT +
                           NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_AMT,
                               0);

          END IF;

          L_SUM := 0;

          DBG('p_Function_Id' || P_FUNCTION_ID);
          DBG('p_Wrk_Lcdtronl.v_Lctbs_Drafts_Details.COUNT' ||
              P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT);
          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT > 0 AND
             P_FUNCTION_ID IN ('LCDTRONL', 'LIDTRONL') THEN

            FOR J IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.LAST LOOP

              DBG('p_Wrk_Lcdtronl.v_Lctbs_Drafts_Details(j).Amount' || P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J)
                  .AMOUNT);
              IF (P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J).AMOUNT IS NULL OR P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J)
                 .AMOUNT = 0) THEN
                DBG('inside iff');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-901', NULL);
              END IF;

              IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).CONTRACT_REF_NO = P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J)
                 .CONTRACT_REF_NO AND P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                 .EVENT_SEQ_NO = P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J)
                 .EVENT_SEQ_NO AND P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                 .DRAFT_SL_NO = P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J)
                 .DRAFT_SL_NO THEN
                DBG('Draft Details Amount--> ' || P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J)
                    .AMOUNT);

                L_SUM := L_SUM +
                         NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J).AMOUNT,
                             0);

                L_BOOL := TRUE;

              END IF;

            END LOOP;

            DBG('l_totalamnt--> ' || L_TOTALAMNT);
            DBG('l_sum--> ' || L_SUM);
            IF L_BOOL = TRUE THEN
              IF L_SUM <> L_TOTALAMNT THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-094', NULL);
              END IF;

            END IF;

          END IF;

          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM BCTM_INSURANCE_COMP
             WHERE INSURANCE_COMP_CODE = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                  .INSURANCE_COMP_CODE
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';

          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed over here');

          END;

          IF L_COUNT = 0 THEN
            DBG('Company code not maintained');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-INR001', NULL);
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_COMP_CODE IS NULL THEN
            DBG('no company code');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-DRFT-07', NULL);
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).COVER_DATE IS NOT NULL THEN
            IF (P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_EXPIRY_DATE < P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
               .COVER_DATE) THEN
              DBG('Expiry Date cannot be less than CoverDate');
              OVPKS.PR_APPENDTBL('LC-OPL-03', NULL);
            END IF;

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).OPEN_POLICY_FLAG = 'Y' THEN

            DBG('Open Policy Flag is true');
            L_OPN_POLICY_COUNT := L_OPN_POLICY_COUNT + 1;
            IF L_OPN_POLICY_COUNT > 1 THEN
              DBG('One Contract Cannot Be linked to more than one Open policy');
              OVPKS.PR_APPENDTBL('LC-INR004', NULL);
            END IF;

            DBG('Validating open policy Number');
            SELECT COUNT(*)
              INTO L_POLICY_COUNT
              FROM LCTBS_OPEN_POLICY
             WHERE OPEN_POLICY_CODE = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                  .INSURANCE_POLICY_NO
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';

            IF L_POLICY_COUNT = 0 THEN
              DBG('Open policy code not maintained');
              OVPKS.PR_APPENDTBL('LC-INR002', NULL);
              RETURN FALSE;
            END IF;

            DBG('Validating open policy insurer Code');
            L_INSURANCE_POLICY_NUMBER := P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                                         .INSURANCE_POLICY_NO;
            SELECT SUM_ASSURED_AMT,
                   UTILIZATION_AMT,
                   PER_CONV_AMT,
                   EXPIRY_DATE,
                   INSURER_CODE,
                   CIF_ID,
                   SUM_ASSURED_CCY
              INTO L_POLICY_SUM_ASSURED_AMOUNT,
                   L_POLICY_UTILIZATION_AMOUNT,
                   L_PER_CONV_AMT,
                   L_POLICY_EXPIRY_DATE,
                   L_INSURER_CODE,
                   L_CUSTOMER_ID,

                   L_SUM_ASSURED_CCY
              FROM LCTB_OPEN_POLICY
             WHERE OPEN_POLICY_CODE = L_INSURANCE_POLICY_NUMBER;

            IF (L_INSURER_CODE <> P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
               .INSURANCE_COMP_CODE) THEN
              DBG('Company code not correct for this open policy');
              OVPKS.PR_APPENDTBL('LC-INR003', NULL);
            END IF;

            IF ((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT *
               (1 + NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                          0) / 100)) >
               L_POLICY_SUM_ASSURED_AMOUNT - L_POLICY_UTILIZATION_AMOUNT) THEN
              IF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT >
                 L_POLICY_SUM_ASSURED_AMOUNT - L_POLICY_UTILIZATION_AMOUNT) THEN

                DBG('contract amount greater than available amount');
                OVPKS.PR_APPENDTBL('LC-INR005', NULL);
              ELSE
                DBG('LC contract amount Along with Tolerance greater than available amount');
                OVPKS.PR_APPENDTBL('LC-INR011', NULL);

              END IF;

            END IF;

            IF ((P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT *
               (1 + NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                          0) / 100)) > L_PER_CONV_AMT) THEN
              IF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT >
                 L_PER_CONV_AMT) THEN
                DBG('contract amount greater than per conveyance limit');
                OVPKS.PR_APPENDTBL('LC-INR006', NULL);
              ELSE
                DBG('Contract Amount Along with Tolerance greater than Per conveyance limit for the Open Policy.');
                OVPKS.PR_APPENDTBL('LC-INR012', NULL);

              END IF;

            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE >
               L_POLICY_EXPIRY_DATE THEN
              DBG('latest shipment date should be less than expiry date');
              OVPKS.PR_APPENDTBL('LC-INR007', NULL);
            END IF;

            IF L_SUM_ASSURED_CCY !=
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY THEN
              DBG('Fn_Validate_Master-->Contract currency and Open Policy currency should be same');
              OVPKS.PR_APPENDTBL('LC-INR014', NULL);
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID !=
               L_CUSTOMER_ID THEN
              DBG('LC Customer and Open Policy Cusomer Mismatch  ....');
              OVPKS.PR_APPENDTBL('LC-INR013', NULL);
            END IF;

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_EXPIRY_DATE IS NULL THEN
            DBG('The insurance expiry date is null');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-DRFT-04', NULL);
          ELSIF (P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                .INSURANCE_EXPIRY_DATE -
                 NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE,
                     P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                     .INSURANCE_EXPIRY_DATE - 31) < 30) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-DRFT-05', NULL);

          END IF;

          DBG('Checking for drafts');
          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE IS NOT NULL THEN
            DBG('drawee is not Null');
            FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT LOOP
              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(J)
               .PARTY_TYPE = 'APP' AND P_WRK_LCDTRONL.V_LCTBS_PARTIES(J)
                 .CIF_ID = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE THEN
                DBG('inside APP party');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-DRF-01',
                             P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_SL_NO);
              END IF;

            END LOOP;

          END IF;

        END LOOP;

        DBG('l_drafttotlen::' || L_DRAFTTOTLEN);

        IF L_DRAFTTOTLEN > 107

         THEN
          DBG('combined lenght of the tenor and credits day from exceeds the limit');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'BC-SWIFT04', NULL);
        END IF;

      ELSE
        L_TOTALAMT := 0;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIMITS_TRACKING_TENOR_TYPE = 'D' THEN
          DBG('draft tenor has to given when Max draft tenor is selected');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-396', '');
        END IF;

      END IF;

      IF NOT L_DRAFT_AVL AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIMITS_TRACKING_TENOR_TYPE = 'D' THEN
        DBG('draft tenor has to given when Max draft tenor is selected');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-396', '');
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD = 'A' AND
         P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN

        IF L_TOTALAMT !=
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT THEN
          DBG('Amount not matching');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LCCON-064',
                       (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY || ' ' ||
                       LTRIM(L_TOTALAMT, ' ') || '~' ||
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY || ' ' ||
                       LTRIM(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                              ' ') || '~'));
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT > 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.LAST LOOP

          SELECT COUNT(*)
            INTO L_COUNT
            FROM LCTMS_AMOUNT_NAME
           WHERE AMOUNT_NAME = P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I)
                .AMOUNT_NAME;

          IF L_COUNT = 0 THEN
            DBG('Invalid amount_name');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCUPLD-027',
                         P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I)
                         .AMOUNT_NAME);

          END IF;

          FOR J IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.LAST LOOP
            IF I != J THEN
              IF ((P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I).DRAFT_SL_NO = P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J)
                 .DRAFT_SL_NO) AND
                 (P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I).AMOUNT_NAME = P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(J)
                 .AMOUNT_NAME)) THEN
                DBG('Duplicate amount_name');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LCUPLD-028',
                             P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I)
                             .AMOUNT_NAME);
              END IF;

            END IF;

          END LOOP;

        END LOOP;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REIMBURSEMENT_TYPE IS NOT NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REIMBURSEMENT_TYPE NOT IN
           ('O', 'C') THEN
          DBG('Invalid value for reimbursement_type');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-029', NULL);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN = 'T' THEN

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY IS NOT NULL AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS IS NULL THEN
          DBG('Units cannot be null for a Frequency');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-DUAL004', NULL);
        END IF;

      END IF;

      DBG('Before Calling cspkss_tradelicense_eod.pr_cust_tradelicovd');
      DBG('Value of Customer Number is : ' ||
          P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
      CSPKSS_TRADELICENSE_EOD.PR_CUST_TRADELICOVD(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
      DBG('After Calling cspkss_tradelicense_eod.pr_cust_tradelicovd');

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'I' AND
         P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE = 'REB' THEN
            L_FLAG := 'Y';
            EXIT;
          END IF;

        END LOOP;

      END IF;

      IF L_FLAG = 'Y' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.URR_PREFERENCE IS NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-351', NULL);
      END IF;

      IF P_ACTION_CODE = CSPKS_SERVICE.P_MODIFY THEN

        IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE = 'REIS'

         THEN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM CSTMS_PRODUCT_EVENT
           WHERE PRODUCT_CODE =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE
             AND EVENT_CODE = 'REIS';

          IF L_COUNT = 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-500', NULL);
          END IF;

          SELECT COUNT(*)
            INTO L_COUNT
            FROM CSTMS_PRODUCT_EVENT_ADVICE
           WHERE PRODUCT_CODE =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE
             AND EVENT_CODE = 'REIS';

          IF L_COUNT = 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-501', NULL);
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID IS NOT NULL AND
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO IS NOT NULL THEN
          DBG('Calling Lmpkss_Collat.Fn_Allow_Amendment..');
          IF NOT LMPKSS_COLLAT.FN_ALLOW_AMENDMENT(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                                                  P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                  L_LINKAGE_REC,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN

            DBG('Failed Lmpkss_Collat.Fn_Allow_Amendment..');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS = 'H' THEN
          IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.TEMPLATE_STATUS = 'Y' THEN

            P_ERR_CODE   := 'LCCON-036';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

        END IF;

        DBG('Checking partial closure flag at the AMND event');

        SELECT PARTIAL_CLOS_DYAFTR_EXP
          INTO L_PARTIAL_CLOS_DAYS
          FROM LCTM_BRANCH_PARAMETERS
         WHERE BRANCH = GLOBAL.CURRENT_BRANCH;

        IF (P_PRODUCT_DEFINITION.PRODUCT_TYPE NOT IN ('I', 'E') OR
           (GLOBAL.APPLICATION_DATE > P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE +
           NVL(L_PARTIAL_CLOS_DAYS, 0)))

           AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE = 'Y' THEN

          DBG('Partial Closure flag not allowed after expiry Date or for non Import Product');
          P_ERR_CODE   := 'LCCON-999';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;

        END IF;

        DBG('Checking if LC is fully linked to BC in Initial stage');
        L_INIT_STAGE_BILL_AMT := 0;

        FOR I IN (SELECT BCMAST.BCREFNO, BCMAST.LC_AMT
                    FROM BCTB_CONTRACT_MASTER BCMAST, CSTBS_CONTRACT CONTREF
                   WHERE BCMAST.OUR_LC_REF =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                     AND CONTREF.CONTRACT_REF_NO = BCMAST.BCREFNO
                     AND CONTREF.CONTRACT_STATUS = 'A'
                     AND BCMAST.STAGE = 'INI'
                     AND BCMAST.BCREFNO NOT IN
                         (SELECT CONTRACT_REF_NO
                            FROM LDTB_CONTRACT_LINKAGES
                           WHERE LINKAGE_TYPE = 'S')
                     AND BCMAST.EVENT_SEQ_NO =
                         (SELECT MAX(EVENT_SEQ_NO)
                            FROM BCTBS_CONTRACT_MASTER
                           WHERE BCREFNO = BCMAST.BCREFNO)) LOOP

          DEBUG.PR_DEBUG('LC',
                         'BILL REF LINKED >>' || I.BCREFNO || 'Bill amt>>' ||
                         I.LC_AMT);
          L_INIT_STAGE_BILL_AMT := L_INIT_STAGE_BILL_AMT + I.LC_AMT;
        END LOOP;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT <=
           L_INIT_STAGE_BILL_AMT THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE = 'Y' THEN
            DBG('Partial Closure flag is not allowed for fully linked bill in initial stage');
            P_ERR_CODE   := 'LCCON-344';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

        END IF;

        DBG('Calling Fn_Isb_Bank_Ref..');
        IF NOT FN_ISB_BANK_REF(P_SOURCE,
                               P_WRK_LCDTRONL,
                               L_REF_NO,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
          DBG('Failed in Fn_Isb_Bank_Ref..');

          RETURN FALSE;
        END IF;

        DBG('Previous confirmed amt :' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT);
        DBG('new confirmed amt :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT);
        DBG('Previous contract amt :' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        DBG('new contract amt :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        DBG('OS Liability :' ||
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.OS_LIABILITY);
        DBG('Available Confirmed Amt :' ||
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT);
        DBG('partial confirm flag :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW);
        DBG('Prev Available_Confirmed_Amt :' ||
            P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT);

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
               'N') = 'Y' THEN

          DELTA_MAX_LC_AMT  := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                                   0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                                            0);
          DELTA_CONFIRM_AMT := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                                   0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                                            0);
          L_UNCONF_AMT      := NVL(P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY,
                                   0) - NVL(P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT,
                                            0);

          DBG('Delta Max LC Amt :' || DELTA_MAX_LC_AMT);
          DBG('Delta Confirmed Amt :' || DELTA_CONFIRM_AMT);
          DBG('UnConfirmed Amt :' || L_UNCONF_AMT);

          IF DELTA_MAX_LC_AMT = 0 THEN
            IF DELTA_CONFIRM_AMT > 0 THEN
              IF L_UNCONF_AMT = 0 THEN
                DBG('Confirm amount cannot be increased');
                P_ERR_CODE   := 'LC-VALS-203';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;
              ELSIF DELTA_CONFIRM_AMT > L_UNCONF_AMT THEN
                DBG('Confirm amount cannot be increased beyond unconfirmed portion');
                P_ERR_CODE   := 'LC-VALS-202';
                P_ERR_PARAMS := L_UNCONF_AMT;
                RETURN FALSE;

              END IF;

            ELSIF DELTA_CONFIRM_AMT < 0 THEN

              IF ABS(DELTA_CONFIRM_AMT) > NVL(P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT,
                                              0) THEN
                DBG('Confirm amount cannot be decreased below available confirmed amount');
                P_ERR_CODE   := 'LC-VALS-204';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;
              END IF;

            END IF;

          END IF;

        END IF;

        DBG('Previous undertaking amt :' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT);
        DBG('new undertaking amt :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT);
        DBG('Previous contract amt :' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        DBG('new contract amt :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        DBG('OS Liability :' ||
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.OS_LIABILITY);
        DBG('Available undertaking Amt :' ||
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_UNDERTAKING_AMOUNT);

        IF NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'Y' THEN
          DELTA_MAX_LC_AMT      := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                                       0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,

                                                0);
          DELTA_UNDERTAKING_AMT := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                                       0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                                                0);
          L_NOTUNDERTAKING_AMT  := NVL(P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY,
                                       0) - NVL(P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_UNDERTAKING_AMOUNT,
                                                0);

          DBG('Delta Max LC Amt :' || DELTA_MAX_LC_AMT);
          DBG('Delta Undertaking Amt :' || DELTA_UNDERTAKING_AMT);
          DBG('Not Undertaking Amt :' || L_NOTUNDERTAKING_AMT);
          IF DELTA_MAX_LC_AMT = 0 THEN
            IF DELTA_UNDERTAKING_AMT > 0 THEN
              IF DELTA_UNDERTAKING_AMT > L_NOTUNDERTAKING_AMT THEN
                DBG('Undertaking amount cannot be increased beyond notundertaking portion');
                P_ERR_CODE   := 'LC-VALS-209';
                P_ERR_PARAMS := L_NOTUNDERTAKING_AMT;
                RETURN FALSE;
              END IF;

            ELSIF DELTA_UNDERTAKING_AMT < 0 THEN

              IF ABS(DELTA_UNDERTAKING_AMT) >
                 NVL(P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_UNDERTAKING_AMOUNT,
                     0) THEN
                DBG('Undertaking amount cannot be decreased below available Undertaking amount');
                P_ERR_CODE   := 'LC-VALS-210';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;
              END IF;

            END IF;

          END IF;

        END IF;

      END IF;

      BEGIN
        SELECT NVL(REIMBURSEMENT, 'N')
          INTO L_REIMB
          FROM LCTMS_PRODUCT_DEFINITION
         WHERE PRODUCT_CODE = P_PRODUCT_DEFINITION.PRODUCT_CODE;

        IF L_REIMB = 'Y' THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO IS NULL THEN
            P_ERR_CODE   := 'LC-VALS-380';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          ELSE
            IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW) OR
               (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO <>
               P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO) THEN

              SELECT COUNT(1)
                INTO L_CUST_COUNT
                FROM LCTBS_CONTRACT_MASTER
               WHERE CUST_REF_NO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO;

              IF L_CUST_COUNT >= 1 THEN
                P_ERR_CODE   := 'LC-VALS-362';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;
              END IF;

            END IF;

          END IF;

        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('failed in selecting reimbursemtn flag from product: ' ||
              SQLERRM || ' product: ' || P_PRODUCT_DEFINITION.PRODUCT_CODE);

      END;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
        BEGIN
          SELECT COUNT(*)
            INTO L_AMEND_CONFIRM_COUNT
            FROM (SELECT CONTRACT_REF_NO
                    FROM CSTBS_CONTRACT_EVENT_LOG
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                     AND EVENT_CODE = 'ACON'
                     AND AUTH_STATUS = 'U'

                  UNION
                  SELECT CONTRACT_REF_NO
                    FROM LCTB_AMND_VALS_MASTER
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                     AND AMND_SEQ_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Not from Amendment Confirmation');
            L_AMEND_CONFIRM_COUNT := 0;

        END;

        DBG('l_amend_confirm_count :: ' || L_AMEND_CONFIRM_COUNT);
        DBG('p_function_id :: ' || P_FUNCTION_ID);

        IF L_AMEND_CONFIRM_COUNT = 0 THEN
          DBG('Going to fetch from contract master');
          SELECT CONTRACT_AMT,
                 BENEFICIARY_CONF_REQD,
                 POSITIVE_TOLERANCE,
                 NEGATIVE_TOLERANCE,
                 LIAB_TOLERANCE,
                 MAX_LIABILITY_AMT,
                 EFFECTIVE_DATE,
                 TENOR,
                 EXPIRY_DATE,
                 CLOSURE_DATE,
                 ADDITIONAL_AMTS_COVERED
            INTO L_CONTRACT_AMT,
                 L_BENEFICIARY_CONF_REQD,
                 L_POSITIVE_TOLERANCE,
                 L_NEGATIVE_TOLERANCE,
                 L_LIAB_TOLERANCE,
                 L_MAX_LIABILITY_AMT,
                 L_EFFECTIVE_DATE,
                 L_TENOR,
                 L_EXPIRY_DATE,
                 L_CLOSURE_DATE,
                 L_ADD_AMT_COV
            FROM LCTB_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND VERSION_NO IN
                 (SELECT MAX(VERSION_NO)
                    FROM LCTB_CONTRACT_MASTER A
                   WHERE A.CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                     AND A.EVENT_SEQ_NO <=
                         (SELECT MAX(B.EVENT_SEQ_NO)
                            FROM CSTB_CONTRACT_EVENT_LOG B
                           WHERE B.CONTRACT_REF_NO = A.CONTRACT_REF_NO
                             AND B.AUTH_STATUS = 'A'));

        ELSE

          DBG('Going to fetch from amendment master');
          SELECT BENEFICIARY_CONF_REQD
            INTO L_BENEFICIARY_CONF_REQD
            FROM LCTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND VERSION_NO = 1;

          SELECT CONTRACT_AMT,
                 POSITIVE_TOLERANCE,
                 NEGATIVE_TOLERANCE,

                 EXPIRY_DATE,
                 CLOSURE_DATE,
                 ADDITIONAL_AMTS_COVERED
            INTO L_CONTRACT_AMT,
                 L_POSITIVE_TOLERANCE,
                 L_NEGATIVE_TOLERANCE,

                 L_EXPIRY_DATE,
                 L_CLOSURE_DATE,
                 L_ADD_AMT_COV
            FROM LCTBS_AMND_VALS_MASTER A
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO

             AND (AMND_SEQ_NO =
                 (SELECT MAX(B.EVENT_SEQ_NO)
                     FROM CSTB_CONTRACT_EVENT_LOG B
                    WHERE B.CONTRACT_REF_NO = A.CONTRACT_REF_NO
                      AND B.AUTH_STATUS = 'U'
                      AND B.EVENT_CODE = 'ACON') OR
                 AMND_SEQ_NO =
                 (SELECT AMND_SEQ_NO
                     FROM LCTB_AMND_VALS_MASTER
                    WHERE CONTRACT_REF_NO =
                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                      AND AMND_SEQ_NO =
                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO));

        END IF;

        DBG('l_contract_amt ::::' || L_CONTRACT_AMT);
        DBG('p_wrk_lcdtronl.v_lctbs_contract_master.contract_amt ::::' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);

        IF L_BENEFICIARY_CONF_REQD = 'Y' AND
           P_FUNCTION_ID IN ('LCDTRONL', 'LIDTRONL') THEN

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' AND
             P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
             'PAD' THEN

            IF L_CONTRACT_AMT <>
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT THEN
              DBG('inside the contract amt fields');
              P_ERR_CODE   := 'LC-VALS-375';
              P_ERR_PARAMS := 'Contract Amount';
              RETURN FALSE;
            END IF;

            IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                   0) <> NVL(L_POSITIVE_TOLERANCE, 0) THEN
              P_ERR_CODE   := 'LC-VALS-375';
              P_ERR_PARAMS := 'Positive Tolerance';
              DBG('The Positive Tolerance cannot be changed..........');
              RETURN FALSE;
            END IF;

            IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                   0) <> NVL(L_NEGATIVE_TOLERANCE, 0) THEN
              P_ERR_CODE   := 'LC-VALS-375';
              P_ERR_PARAMS := 'Negative Tolerance';
              DBG('The Negative Tolerance cannot be changed..........');
              RETURN FALSE;
            END IF;

            IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE, 0) <>
               NVL(L_LIAB_TOLERANCE, 0) AND L_AMEND_CONFIRM_COUNT = 0 THEN
              P_ERR_CODE   := 'LC-VALS-375';
              P_ERR_PARAMS := 'Liability Tolerance';
              DBG('The Liability Tolerance cannot be changed..........');
              RETURN FALSE;
            END IF;

            IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT,
                   0) <> NVL(L_MAX_LIABILITY_AMT, 0) AND
               L_AMEND_CONFIRM_COUNT = 0 THEN
              P_ERR_CODE   := 'LC-VALS-375';
              P_ERR_PARAMS := 'Liability Amount';
              DBG('The Liability Amount cannot be changed..........');
              RETURN FALSE;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE <>
               L_EFFECTIVE_DATE AND L_AMEND_CONFIRM_COUNT = 0 THEN
              P_ERR_CODE   := 'LC-VALS-375';
              P_ERR_PARAMS := 'Effective Date';
              DBG('The Effective Date cannot be changed..........');
              RETURN FALSE;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR <> L_TENOR AND
               L_AMEND_CONFIRM_COUNT = 0 THEN
              P_ERR_CODE   := 'LC-VALS-375';
              P_ERR_PARAMS := 'Tenor';
              DBG('The Tenor cannot be changed..........');
              RETURN FALSE;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE <>
               L_EXPIRY_DATE THEN
              P_ERR_CODE   := 'LC-VALS-375';
              P_ERR_PARAMS := 'Expiry Date';
              DBG('The Expiry date cannot be changed..........');
              RETURN FALSE;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE <>
               L_CLOSURE_DATE THEN
              P_ERR_CODE := 'LC-VALS-375';

              P_ERR_PARAMS := 'Closure Date';

              DBG('The Expiry date cannot be changed..........');
              DBG('The Closure date cannot be changed..........');
              RETURN FALSE;
            END IF;

            DBG('additional amount' ||
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED);
            DBG('l_add' || L_ADD_AMT_COV);
            IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED,
                   'X') <> NVL(L_ADD_AMT_COV, 'X') THEN
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-403', NULL);
            END IF;

          END IF;
        END IF;

      END IF;

      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        SELECT CURR_EVENT_CODE
          INTO L_CURR_EVENT_CODE
          FROM CSTB_CONTRACT
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

        IF L_CURR_EVENT_CODE = 'AMNV' THEN
          DBG('Contract is in Initiation Of Amendment Confirmation');
          P_ERR_CODE   := 'LC-AVK17';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

      END IF;

      DBG('In Prod Type ' || P_PRODUCT_DEFINITION.PRODUCT_TYPE);
      DBG('In Reim ' || P_PRODUCT_DEFINITION.REIMBURSEMENT);
      IF (P_PRODUCT_DEFINITION.PRODUCT_TYPE NOT IN ('S', 'H', 'G')) THEN

        IF (P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'E') AND
           NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') <> 'Y') THEN

          FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .PARTY_TYPE IN ('ISB', 'ABK') THEN
              BEGIN
                SELECT ADB_MEMBER
                  INTO L_ADB_MEMBER
                  FROM ISTMS_BIC_DIRECTORY
                 WHERE BIC_CODE = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                      .CUST_ADDRESS_LIN1;

              EXCEPTION
                WHEN OTHERS THEN
                  NULL;

              END;

              IF NVL(L_ADB_MEMBER, 'X') = 'N' THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-512', NULL);
              END IF;

            END IF;

          END LOOP;

        END IF;

      END IF;

      IF (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G') OR
         (NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
        L_CY_AMT := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OS_LC_AMOUNT;
      ELSE
        L_CY_AMT := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT;

      END IF;

      DBG('Currency and Amount AFTER');
      DBG(L_CY_AMT);
      L_CY_AMT_LENGTH := LENGTH(CSFN_FORMAT_SWIFT_AMT(L_CY_AMT));
      DBG('Current Length: ' || L_CY_AMT_LENGTH);
      IF L_CY_AMT_LENGTH > 15 THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'LC-VALS-392',
                     L_CY_AMT_LENGTH);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID IS NOT NULL THEN
        BEGIN
          SELECT FROZEN, DECEASED
            INTO L_FROZEN, L_DECEASED
            FROM STTM_CUSTOMER
           WHERE CUSTOMER_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('failed in selecting frozen/deceased in drafts');

        END;

        IF NVL(L_FROZEN, 'N') = 'Y' OR NVL(L_DECEASED, 'N') = 'Y' THEN
          DBG('main party frozen/deceased customer not allowed');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-VALS-394',
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
        END IF;

      END IF;

      IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'RMB' THEN

        SELECT COUNT(*)
          INTO L_COUNT_EXTREF
          FROM LCTBS_CONTRACT_MASTER
         WHERE EXT_REF_NO = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO
           AND CONTRACT_REF_NO <>
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND OPERATION_CODE IN ('RMB', 'ONC', 'OPN', 'CNF');

      ELSIF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
            ('ADV', 'ANC', 'PAD') THEN

        SELECT COUNT(*)
          INTO L_COUNT_EXTREF
          FROM LCTBS_CONTRACT_MASTER
         WHERE EXT_REF_NO = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO
           AND CONTRACT_REF_NO <>
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND OPERATION_CODE <> 'RMB';

      ELSE

        SELECT COUNT(*)
          INTO L_COUNT_EXTREF
          FROM LCTBS_CONTRACT_MASTER
         WHERE EXT_REF_NO = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO
           AND CONTRACT_REF_NO <>
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
      END IF;

      IF L_COUNT_EXTREF > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-REF-001', NULL);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO IS NULL AND
         L_PROD_TYPE <> 'E' THEN
        IF P_ACTION_CODE = 'NEW' THEN
          DBG('Checking if any LC/BG/SG registration is available for new operation');

          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM LCTBS_REG_MASTER
             WHERE STAGE = 'R'
               AND REG_TYPE <> 'AM'
               AND REG_TYPE = DECODE(L_PROD_TYPE,
                                     'I',
                                     'LC',
                                     'G',
                                     'BG',
                                     'S',
                                     'LC',
                                     'H',
                                     'SG')
               AND MODULE_ID = L_MODULE
               AND CIF_ID = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID
               AND CONTRACT_AMT =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT
               AND CONTRACT_CCY =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY
               AND CUST_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO
               AND AUTH_STATUS = 'A';
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in selecting registeration details');
              L_COUNT := 0;
          END;
        ELSIF P_ACTION_CODE = 'MODIFY' THEN
          DBG('Checking if any LC/BG/SG registration is available for modify operation');
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM LCTBS_REG_MASTER
             WHERE STAGE = 'R'
               AND REG_TYPE = 'AM'
               AND MODULE_ID = L_MODULE
               AND CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
               AND AUTH_STATUS = 'A';
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in selecting registeration details');
              L_COUNT := 0;
          END;
        END IF;

        IF L_COUNT > 0 THEN
          DBG('Unprocessed registration is available. Want to proceed?');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-REG-01', NULL);
        END IF;
      ELSE
        BEGIN
          SELECT REG_TYPE
            INTO L_REG_TYPE
            FROM LCTBS_REG_MASTER
           WHERE ACKREFNO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in selecting registeration details');
        END;

        DBG('Ackrefno is not null');
        IF P_ACTION_CODE = 'MODIFY' THEN
          DBG('Checking if the ackrefnum used is for the currenct contract');
          BEGIN
            SELECT CONTRACT_REF_NO
              INTO L_CONTRACT_REF_NO
              FROM LCTBS_REG_MASTER
             WHERE ACKREFNO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('In others exception while selecting contract ref number from lctbs_contract_master');
          END;

          DBG('l_reg_type' || L_REG_TYPE);
          DBG('l_contract_ref_no' || L_CONTRACT_REF_NO);
          IF L_CONTRACT_REF_NO <>
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO OR
             L_REG_TYPE <> 'AM' THEN
            DBG('Invalid ack ref number');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-REG-04', NULL);
          END IF;
        END IF;
      END IF;

      DBG('p_wrk_lcdtronl.v_lctbs_availments.current_availability' ||
          P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY);
      BEGIN
        SELECT SUM(BLOCK_AMT)
          INTO L_TOT_BLOCKED_AMT
          FROM BCTB_LC_BLOCK_DETAILS
         WHERE LCREFNO = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND BCREFNO IN
               (SELECT BCREFNO FROM BCTB_CONTRACT_MASTER WHERE STAGE = 'FIN')
           AND BLOCK_STATUS = 'U';
      EXCEPTION
        WHEN OTHERS THEN
          L_TOT_BLOCKED_AMT := 0;
      END;
      DBG('l_tot_blocked_amt' || L_TOT_BLOCKED_AMT);
      IF NVL(L_TOT_BLOCKED_AMT, 0) >
         NVL(P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY, 0) THEN
        DBG('Available amount is less than blocked amount.cannot amend');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-126', NULL);
      END IF;

      DEBUG.PR_DEBUG('LC',
                     'about to exit lcpks_lcdtronl_utils.Fn_Skip_Kernel..');
    END IF;
    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CLUSTER THEN
      DEBUG.PR_DEBUG('LC',
                     'Calling  lcpks_lcdtronl_utils_cluster.fn_post_Validate_Master..');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CLUSTER.FN_POST_VALIDATE_MASTER(P_SOURCE,
                                                               P_FUNCTION_ID,
                                                               P_ACTION_CODE,
                                                               P_PRODUCT_DEFINITION,
                                                               P_LCDTRONL,
                                                               P_PREV_LCDTRONL,
                                                               P_WRK_LCDTRONL,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in  lcpks_lcdtronl_utils_cluster.fn_post_Validate_Master..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CUSTOM THEN
      DEBUG.PR_DEBUG('LC',
                     'Calling  lcpks_lcdtronl_utils_custom.fn_post_Validate_Master..');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CUSTOM.FN_POST_VALIDATE_MASTER(P_SOURCE,
                                                              P_FUNCTION_ID,
                                                              P_ACTION_CODE,
                                                              P_PRODUCT_DEFINITION,
                                                              P_LCDTRONL,
                                                              P_PREV_LCDTRONL,
                                                              P_WRK_LCDTRONL,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in  lcpks_lcdtronl_utils_custom.fn_post_Validate_Master..');
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Validate_Master ');
      DBG(SQLERRM);
      DBG('ERROR LINE NUMBER='||DBMS_UTILITY.format_error_backtrace);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE_MASTER;

  FUNCTION FN_VALIDATE_PARTYTYP(P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_PARTY_TYPE     IN LCTBS_PARTIES.PARTY_TYPE%TYPE,
                                P_PRODUCT_TYPE   IN LCTMS_PRODUCT_DEFINITION.PRODUCT_TYPE%TYPE,
                                P_OPERATION_CODE IN LCTBS_UPLOAD_MASTER.OPERATION_CODE%TYPE,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT NUMBER;
    L_NO    NUMBER := 0;
    L_TEMP  VARCHAR2(3);

  BEGIN
    DBG('Inside fn_validate_partytyp');

    BEGIN
      L_TEMP := SUBSTR(P_PARTY_TYPE, 2);
      DEBUG.PR_DEBUG('LC', 'temp value is' || L_TEMP);
      L_NO := TO_NUMBER(L_TEMP);
      DEBUG.PR_DEBUG('LC', 'value is' || L_NO);
    EXCEPTION
      WHEN OTHERS THEN
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM LCTBS_ALLOWED_PARTIES A, STTBS_VALUE_DESC B

           WHERE UPPER(B.ITEM_VALUE) = UPPER(A.PARTY_TYPE)
             AND UPPER(A.PARTY_TYPE) = P_PARTY_TYPE
             AND UPPER(B.BLOCK_NAME) = 'LCTBS_PARTIES'
             AND UPPER(B.ITEM_NAME) = 'PARTY_TYPE'

             AND UPPER(B.LANGUAGE_CODE) = 'ENG'

             AND A.PRODUCT_TYPE = P_PRODUCT_TYPE
             AND A.OPERATION_CODE = P_OPERATION_CODE;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed');

        END;

        IF L_COUNT = 0 THEN
          DBG('Invalid party_type');
          RETURN FALSE;
        END IF;

    END;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Query_Pk ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE_PARTYTYP;

  FUNCTION FN_VALIDATE_PARTIES(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                               P_FUNCTION_ID        IN VARCHAR2,
                               P_ACTION_CODE        IN VARCHAR2,
                               P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                               P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                               P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                               P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                               P_ERR_CODE           IN OUT VARCHAR2,
                               P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_PARTY_TYPE  LCTBS_PARTIES.PARTY_TYPE%TYPE;
    L_PARTY_TYPE1 LCTBS_PARTIES.PARTY_TYPE%TYPE;
    L_CUST_NAME   STTM_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_COUNT_1     NUMBER := 0;
    L_LANG_CODE   STTM_CUSTOMER.LANGUAGE%TYPE;
    L_CNTRY_CODE  STTM_CUSTOMER.COUNTRY%TYPE;
    L_ADDR_LINE1  STTM_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDR_LINE2  STTM_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDR_LINE3  STTM_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDR_LINE4  STTM_CUSTOMER.ADDRESS_LINE4%TYPE;
    E_COUNT       NUMBER := 0;
    I_COUNT       NUMBER := 0;
    L_COUNT       NUMBER := 0;
    L_FLAG        NUMBER := 0;
    FOUND         NUMBER := 0;

    L_ISB_COUNT        NUMBER := 0;
    L_COUNT1           NUMBER := 0;
    L_COUNT2           NUMBER := 0;
    L_COUNT3           NUMBER := 0;
    L_PREV_CIFID       LCTBS_PARTIES.CIF_ID%TYPE;
    L_WRK_CIFID        LCTBS_PARTIES.CIF_ID%TYPE;
    L_TEMPLATEID       LCTBS_PARTIES.TEMPLATE_ID%TYPE;
    L_OS_LIAB          LCTBS_AVAILMENTS.OS_LIABILITY%TYPE;
    L_LIAB_AMT         LCTBS_AVAILMENTS.LIABILITY_AMT%TYPE;
    L_MAX_CONTRACT_AMT LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;
    L_CONTRACT_MASTER  LCTBS_CONTRACT_MASTER%ROWTYPE;
    L_PRODUCT_DETAILS  LCTMS_PRODUCT_DEFINITION%ROWTYPE;
    L_CHECK            BOOLEAN := FALSE;
    L_CUST             STTM_CUSTOMER.CUSTOMER_NO%TYPE;

    L_CURR_AVLABILITY  LCTBS_AVAILMENTS.CURRENT_AVAILABILITY%TYPE;
    L_PARTY_TYPE_EXIST NUMBER := 0;
    L_WALKIN           STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_BLKLIST          NUMBER;

    L_FROZEN   STTMS_CUSTOMER.FROZEN%TYPE;
    L_DECEASED STTMS_CUSTOMER.DECEASED%TYPE;

    CURSOR C_PARTYTYPE(P_RELATED_LC_REF_NO LCTB_CONTRACT_MASTER.RELATED_LC_REF_NO%TYPE) IS
      SELECT PARTY_TYPE
        FROM LCTB_PARTIES
       WHERE CONTRACT_REF_NO = P_RELATED_LC_REF_NO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM LCTB_PARTIES
               WHERE CONTRACT_REF_NO = P_RELATED_LC_REF_NO);

    L_VALID_BIC   NUMBER := 0;
    L_REQCONF_CNT NUMBER := 0;
    L_COB_CNT     NUMBER := 0;
  BEGIN
    DBG('Inside the function fn_validate_parties');

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CUSTOM THEN
      DBG('Calling lcpks_lcdtronl_utils_custom.Fn_Pre_Linkage_Parties');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CUSTOM.FN_PRE_VALIDATE_PARTIES(P_SOURCE,
                                                              P_FUNCTION_ID,
                                                              P_ACTION_CODE,
                                                              P_PRODUCT_DEFINITION,
                                                              P_LCDTRONL,
                                                              P_PREV_LCDTRONL,
                                                              P_WRK_LCDTRONL,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CLUSTER THEN
      DBG('Calling lcpks_lcdtronl_utils_cluster.Fn_Pre_Linkage_Parties');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CLUSTER.FN_PRE_VALIDATE_PARTIES(P_SOURCE,
                                                               P_FUNCTION_ID,
                                                               P_ACTION_CODE,
                                                               P_PRODUCT_DEFINITION,
                                                               P_LCDTRONL,
                                                               P_PREV_LCDTRONL,
                                                               P_WRK_LCDTRONL,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_KERNEL THEN

      DBG('p_Lcdtronl.v_Lctbs_Parties.count' ||
          P_LCDTRONL.V_LCTBS_PARTIES.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT = 0 THEN
        DBG('Party Details are null');
        P_ERR_CODE   := 'LCUPLD-031';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE IS NOT NULL THEN
            L_PARTY_TYPE := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE;
            IF L_PARTY_TYPE =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE AND P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
              .CIF_ID = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID THEN
              FOUND := 1;
              EXIT;
            END IF;

          END IF;

        END LOOP;

      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
        DBG('It came here under modify action');
        BEGIN
          DBG('Selecting count in BC');
          SELECT COUNT(*)
            INTO L_COUNT1
            FROM BCTBS_CONTRACT_MASTER
           WHERE OUR_LC_REF =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found in BC');
            L_COUNT1 := 0;

        END;

        BEGIN
          DBG('Selecting count in availment');
          SELECT COUNT(*)
            INTO L_COUNT2
            FROM LCTBS_AVAILMENTS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_CODE = 'AVAL';

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found in availments');
            L_COUNT2 := 0;

        END;

        BEGIN
          DBG('Selecting count in transfers');
          SELECT COUNT(*)
            INTO L_COUNT3
            FROM LCTBS_TRANSFER_DETAILS
           WHERE FROM_LCREF =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found in transfers');
            L_COUNT3 := 0;

        END;

        BEGIN
          DBG('Selecting liability amount');
          SELECT OS_LIABILITY, LIABILITY_AMT, CURRENT_AVAILABILITY
            INTO L_OS_LIAB, L_LIAB_AMT, L_CURR_AVLABILITY

            FROM LCTBS_AVAILMENTS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_AVAILMENTS
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for liability amount');
            L_OS_LIAB         := 0;
            L_CURR_AVLABILITY := 0;

        END;

        DBG('OS_LIABILITY = ' || L_OS_LIAB);
        DBG('Liability Amount = ' || L_LIAB_AMT);
        DBG('Current Availability = ' || L_CURR_AVLABILITY);
        BEGIN
          DBG('Selecting contract record');
          SELECT *
            INTO L_CONTRACT_MASTER
            FROM LCTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('No data found for contract');
            RETURN FALSE;

        END;

        BEGIN
          DBG('Selecting product record');
          SELECT *
            INTO L_PRODUCT_DETAILS
            FROM LCTMS_PRODUCT_DEFINITION
           WHERE PRODUCT_CODE = P_PRODUCT_DEFINITION.PRODUCT_CODE;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('No data found for product');
            RETURN FALSE;

        END;

        DBG('Count = ' || L_COUNT1 || ' ~ ' || L_COUNT2 || ' ~ ' ||
            L_COUNT3);

        DBG('Count in parties tab = ' ||
            P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT);

        IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
          FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
            DBG('Party type = ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                .PARTY_TYPE);
            DBG('Party ID = ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID);
            DBG('Present ESN = ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                .EVENT_SEQ_NO);
            BEGIN
              SELECT CIF_ID
                INTO L_PREV_CIFID
                FROM LCTBS_PARTIES
               WHERE CONTRACT_REF_NO = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                    .CONTRACT_REF_NO
                 AND PARTY_TYPE = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                    .PARTY_TYPE
                 AND VERSION_NO =
                     (P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).VERSION_NO - 1);

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Came into no data found for old party id');
                L_PREV_CIFID := NULL;

            END;

            L_MAX_CONTRACT_AMT := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT;
            DBG('Max Contract Amount = ' || L_MAX_CONTRACT_AMT);

            L_WRK_CIFID := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID;

            DBG('l_prev_party = ' || L_PREV_CIFID);
            DBG('l_wrk_party = ' || L_WRK_CIFID);
            IF P_PRODUCT_DEFINITION.REVOLVING = 'N' THEN
              IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'E') THEN

                DBG('Enter into Import or Expoprt type....');
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .PARTY_TYPE IN ('ABK', 'REB', 'BEN') THEN
                  IF L_PREV_CIFID IS NOT NULL AND
                     L_PREV_CIFID <> L_WRK_CIFID THEN
                    DBG('Party id are different for ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                        .PARTY_TYPE);
                    IF L_COUNT1 = 0 AND L_COUNT2 = 0 AND L_COUNT3 = 0 THEN
                      DBG('PARTY NAME CHANGED FOR PARTY TYPES REB/ABK');
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   P_SOURCE,
                                   'LCUPLD-510',
                                   P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                   .PARTY_TYPE);
                      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'ABK' THEN
                        ABKCHANGED := 'Y';
                      ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'REB' THEN
                        REBCHANGED := 'Y';

                      ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'BEN' THEN
                        BENCHANGED := 'Y';

                      END IF;

                    ELSE
                      DBG('Party id can not be modified');
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   P_SOURCE,
                                   'LCUPLD-514',

                                   NULL);

                    END IF;

                  END IF;

                ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .PARTY_TYPE NOT IN ('ABK', 'REB', 'BEN') AND
                       L_PREV_CIFID <> L_WRK_CIFID THEN
                  DBG('Party id can not be modified...');

                  P_ERR_CODE   := 'LCUPLD-515';
                  P_ERR_PARAMS := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                  .PARTY_TYPE;
                  RETURN FALSE;

                END IF;

              ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('G', 'H') THEN

                DBG('Enter into guarentee product type....');
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .PARTY_TYPE IN ('ABK', 'BEN') THEN
                  IF L_PREV_CIFID IS NOT NULL AND
                     L_PREV_CIFID <> L_WRK_CIFID THEN
                    DBG('Party id are different for ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                        .PARTY_TYPE);
                    IF L_COUNT1 = 0 AND L_COUNT2 = 0 AND L_COUNT3 = 0 THEN
                      DBG('PARTY NAME CHANGED FOR PARTY TYPES BEN/ABK');
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   P_SOURCE,
                                   'LCUPLD-510',
                                   P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                   .PARTY_TYPE);
                      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'ABK' THEN
                        ABKCHANGED := 'Y';
                      ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'BEN' THEN
                        BENCHANGED := 'Y';

                      END IF;

                    ELSE
                      DBG('Party id can not be modified');
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   P_SOURCE,
                                   'LCUPLD-514',

                                   NULL);

                    END IF;

                  END IF;

                ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .PARTY_TYPE NOT IN ('ABK', 'BEN') AND
                       L_PREV_CIFID <> L_WRK_CIFID THEN
                  DBG('Party id can not be modified...');

                  P_ERR_CODE   := 'LCUPLD-515';
                  P_ERR_PARAMS := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                  .PARTY_TYPE;
                  RETURN FALSE;

                END IF;

              END IF;

            ELSIF P_PRODUCT_DEFINITION.REVOLVING = 'Y' THEN
              IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'E') THEN

                DBG('Enter into Revolving type of product');
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .PARTY_TYPE IN ('ABK', 'REB', 'BEN') THEN
                  IF L_PREV_CIFID IS NOT NULL AND
                     L_PREV_CIFID <> L_WRK_CIFID THEN
                    DBG('Party id are different for ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                        .PARTY_TYPE);
                    IF L_COUNT1 = 0 AND L_COUNT2 = 0 AND L_COUNT3 = 0 AND
                       L_MAX_CONTRACT_AMT = L_CURR_AVLABILITY THEN
                      DBG('PARTY NAME CHANGED FOR PARTY TYPES REB/ABK');
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   P_SOURCE,
                                   'LCUPLD-510',
                                   P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                   .PARTY_TYPE);
                      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'ABK' THEN
                        ABKCHANGED := 'Y';
                      ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'REB' THEN
                        REBCHANGED := 'Y';

                      ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'BEN' THEN
                        BENCHANGED := 'Y';

                      END IF;

                    ELSE

                      IF L_COUNT1 <> 0 OR L_COUNT2 <> 0 OR L_COUNT3 <> 0 THEN

                        DBG('Party id can not be modified');
                        PR_LOG_ERROR(P_FUNCTION_ID,
                                     P_SOURCE,
                                     'LCUPLD-514',

                                     NULL);

                      ELSIF L_MAX_CONTRACT_AMT <> L_CURR_AVLABILITY THEN
                        DBG('LC amount is not fully reinstated');
                        PR_LOG_ERROR(P_FUNCTION_ID,
                                     P_SOURCE,
                                     'LCUPLD-516',
                                     NULL);

                      END IF;

                    END IF;

                  END IF;

                ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .PARTY_TYPE NOT IN ('ABK', 'REB', 'BEN') AND
                       L_PREV_CIFID <> L_WRK_CIFID THEN
                  DBG('Party id can not be modified...');

                  P_ERR_CODE   := 'LCUPLD-515';
                  P_ERR_PARAMS := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                  .PARTY_TYPE;
                  RETURN FALSE;

                END IF;

              ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('G', 'H') THEN

                DBG('Enter into Revolving type of product for G and H');
                DBG('Max Contract Amount = ' || L_MAX_CONTRACT_AMT);
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .PARTY_TYPE IN ('ABK', 'BEN') THEN
                  IF L_PREV_CIFID IS NOT NULL AND
                     L_PREV_CIFID <> L_WRK_CIFID THEN
                    DBG('Party id are different for ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                        .PARTY_TYPE);
                    IF L_COUNT1 = 0 AND L_COUNT2 = 0 AND L_COUNT3 = 0 AND
                       L_MAX_CONTRACT_AMT = L_OS_LIAB THEN
                      DBG('PARTY NAME CHANGED FOR PARTY TYPES BEN/ABK');
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   P_SOURCE,
                                   'LCUPLD-510',
                                   P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                   .PARTY_TYPE);
                      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'ABK' THEN
                        ABKCHANGED := 'Y';
                      ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .PARTY_TYPE = 'BEN' THEN
                        BENCHANGED := 'Y';

                      END IF;

                    ELSE
                      DBG('Party id can not be modified');
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   P_SOURCE,
                                   'LCUPLD-514',

                                   NULL);

                    END IF;

                  END IF;

                ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .PARTY_TYPE NOT IN ('ABK', 'BEN') AND
                       L_PREV_CIFID <> L_WRK_CIFID THEN
                  DBG('Party id can not be modified...');

                  P_ERR_CODE   := 'LCUPLD-515';
                  P_ERR_PARAMS := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                  .PARTY_TYPE;
                  RETURN FALSE;

                END IF;

              END IF;

            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE = 'REB' THEN

              DBG('REB is present in the current parties');
              REBEXISTS := 'Y';
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .PARTY_TYPE = 'BEN' AND
                P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' THEN
              DBG('Enter into BEN party type');
              IF P_PREV_LCDTRONL.V_LCTBS_PARTIES(I)
               .CIF_ID <> P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID THEN
                DBG('Party id of BEN are different');
                DBG('Updating CIF ID in contract table');
                BEGIN
                  UPDATE LCTBS_CONTRACT_MASTER
                     SET CIF_ID = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                     AND EVENT_SEQ_NO =
                         (SELECT MAX(EVENT_SEQ_NO)
                            FROM LCTBS_CONTRACT_MASTER
                           WHERE CONTRACT_REF_NO =
                                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-511', NULL);
                EXCEPTION
                  WHEN OTHERS THEN
                    DEBUG.PR_DEBUG('LC',
                                   'Unable to update CIF ID in contract table ' ||
                                   SQLERRM);
                    RETURN FALSE;

                END;

                DEBUG.PR_DEBUG('LC',
                               'Present CIF ID' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                               .CIF_ID);
              END IF;

            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .PARTY_TYPE = 'REB' AND REBCHANGED = 'Y' AND
                P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'I' THEN
              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).TEMPLATE_ID IS NULL THEN
                DEBUG.PR_DEBUG('LC',
                               'Template ID can not be null when REB party has been changed.');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-512', NULL);
              END IF;

            END IF;

          END LOOP;
        END IF;
      END IF;

      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
         P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
          DEBUG.PR_DEBUG('LC',
                         'Party_Type' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                         .PARTY_TYPE);
          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE <> 'REB' AND P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .TEMPLATE_ID IS NOT NULL THEN
            DEBUG.PR_DEBUG('LC',
                           'Template ID must be null when party is other than REB.');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-513', NULL);
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY IS NOT NULL THEN
            DEBUG.PR_DEBUG('LC',
                           'req_confirm_party' ||
                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY);
            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .PARTY_TYPE = NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY,
                                 '*') THEN
              L_REQCONF_CNT := 1;
              DEBUG.PR_DEBUG('LC',
                             'req_confirm_party is maintained in parties');
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE = 'COB' AND
                NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY,
                    '*') <> 'COB' THEN
              DEBUG.PR_DEBUG('LC', 'COB is not req_confirm_party');
              L_COB_CNT := 1;
            END IF;
          END IF;

        END LOOP;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY IS NOT NULL THEN
          --sampath commented starts
          /*IF L_REQCONF_CNT = 0 THEN
            DEBUG.PR_DEBUG('LC',
                           'Requested Confirmation Party is not maintained in Parties..');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCUPLD-604',
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY);
          END IF;*/
          --sampath commented ends

          IF L_COB_CNT = 1 THEN
            DEBUG.PR_DEBUG('LC',
                           'Requested Confirmation Party cannot be other than Confirming bank when COB is maintained in Parties.');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-603', NULL);
          END IF;
        END IF;

      END IF;

      IF FOUND = 0 THEN
        DBG('The party details are incorrect');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-102', NULL);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE IS NOT NULL THEN
            IF NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                          .CUST_ADDRESS_LIN1),
                   0) > 35 OR NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                         .CUST_ADDRESS_LIN2),
                                  0) > 35 OR
               NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                          .CUST_ADDRESS_LIN3),
                   0) > 35 OR NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                         .CUST_ADDRESS_LIN4),
                                  0) > 35 OR
               NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_NAME), 0) > 35 THEN
              DBG('One of the address line contains more characters then define in swift standards..hence overide ');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LD-C0419',
                           '@' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                           .PARTY_TYPE);
            END IF;

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID IS NOT NULL THEN
            BEGIN
              SELECT FROZEN, DECEASED
                INTO L_FROZEN, L_DECEASED
                FROM STTM_CUSTOMER
               WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID;

            EXCEPTION
              WHEN OTHERS THEN
                DBG('failed in selecting frozen/deceased in drafts');

            END;

            IF NVL(L_FROZEN, 'N') = 'Y' OR NVL(L_DECEASED, 'N') = 'Y' THEN
              DBG('main party frozen/deceased customer not allowed');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-VALS-394',
                           P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID);
            END IF;

          END IF;

        END LOOP;

      END IF;

      DBG('p_wrk_lcdtronl.v_lctbs_parties.COUNT::' ||
          P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT);
      DBG('p_prev_lcdtronl.v_lctbs_parties.COUNT::' ||
          P_PREV_LCDTRONL.V_LCTBS_PARTIES.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 AND
         P_PREV_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
        FOR J IN P_PREV_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_PREV_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
          FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
            DBG('p_wrk_lcdtronl.v_lctbs_parties(i).party_type::' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                .PARTY_TYPE);
            DBG('p_Prev_lcdtronl.v_lctbs_parties(j).party_type::' || P_PREV_LCDTRONL.V_LCTBS_PARTIES(J)
                .PARTY_TYPE);
            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .PARTY_TYPE = P_PREV_LCDTRONL.V_LCTBS_PARTIES(J).PARTY_TYPE THEN
              L_COUNT := 1;
              EXIT;
            END IF;

          END LOOP;

          DBG('l_count:;' || L_COUNT);

          IF L_COUNT = 0 THEN
            DBG('New party type does not match with existing party type');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCUPLD-520',
                         P_PREV_LCDTRONL.V_LCTBS_PARTIES(J).PARTY_TYPE);
          END IF;

          L_COUNT := 0;
        END LOOP;

      END IF;

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'H' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
          FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP

            FOR EACH_REC IN C_PARTYTYPE(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO) LOOP
              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
               .PARTY_TYPE = EACH_REC.PARTY_TYPE THEN
                DBG('party type matched with related lc');
                L_PARTY_TYPE_EXIST := 1;
                EXIT;
              END IF;

            END LOOP;

            IF L_PARTY_TYPE_EXIST = 0 AND
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL THEN
              DBG('party type not matched with related lc');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-785', NULL);
              RETURN FALSE;

            END IF;

            L_PARTY_TYPE_EXIST := 0;
          END LOOP;

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN

        SELECT WALKIN_CUSTOMER
          INTO L_WALKIN
          FROM STTMS_BRANCH
         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

        FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
          L_PARTY_TYPE := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE;

          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID IS NULL AND P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .CUST_NAME IS NULL THEN
            DBG('Either CIF ID or Customer Name is mandatory for : ' || I);
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-CONT-002',
                         'Either Party Id or Customer Name');
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID IS NULL THEN
            DBG('CIF ID is NUll, Defaultng the same as WALK_IN');
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID := L_WALKIN;
          END IF;

          DBG('cust ref no' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
              .CUST_REF_NO);
          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO IS NOT NULL THEN
            IF LENGTH(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO) > 16 THEN
              DBG('cust ref no is more than 16 cahracters');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-401', NULL);
            END IF;

            IF NOT FN_NETWORK_VALIDATIONS(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                          .CUST_REF_NO) THEN
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-405', NULL);
            END IF;
          END IF;

          IF L_PARTY_TYPE =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE THEN
            IF ((P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
               .CUST_REF_NO <>
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO) OR
               (P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
               .CUST_REF_DATE <>
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE)) THEN
              DBG('Cannot enter the details');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LCUPLD-089',
                           L_PARTY_TYPE);
            END IF;

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID IS NOT NULL THEN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM STTMS_CUSTOMER
             WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';

            IF L_COUNT = 0 THEN
              DBG('Invalid customer id');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LCUPLD-033',
                           P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID);
            END IF;

            SELECT COUNT(*)
              INTO L_COUNT
              FROM STTMS_CUSTOMER CUST, STTMS_BRANCH BR

             WHERE CUST.CUSTOMER_NO = BR.WALKIN_CUSTOMER
               AND CUST.CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                  .CIF_ID
               AND CUST.RECORD_STAT = 'O'
               AND CUST.ONCE_AUTH = 'Y';

            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT > 0 THEN

              FOR J IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
                L_PARTY_TYPE1 := P_WRK_LCDTRONL.V_LCTBS_PARTIES(J)
                                 .PARTY_TYPE;
                IF L_PARTY_TYPE1 IS NOT NULL THEN
                  IF L_PARTY_TYPE1 != L_PARTY_TYPE AND
                     (L_PARTY_TYPE1 NOT IN ('ABK', 'REB') OR
                     L_PARTY_TYPE NOT IN ('ABK', 'REB')) THEN

                    IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                     .CIF_ID <> NVL(L_WALKIN, '@@@') OR P_WRK_LCDTRONL.V_LCTBS_PARTIES(J)
                       .CIF_ID <> NVL(L_WALKIN, '@@@') THEN

                      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                       .CIF_ID = P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).CIF_ID THEN
                        DBG('Cif id duplicated');
                        PR_LOG_ERROR(P_FUNCTION_ID,
                                     P_SOURCE,
                                     'LCUPLD-034',
                                     NULL);
                      END IF;

                    END IF;
                  END IF;

                END IF;

              END LOOP;

            END IF;

            IF L_COUNT > 0 THEN
              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).COUNTRY_CODE IS NOT NULL THEN
                SELECT COUNT(*)
                  INTO L_COUNT
                  FROM STTMS_COUNTRY
                 WHERE COUNTRY_CODE = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                      .COUNTRY_CODE
                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A';

                IF L_COUNT = 0 THEN
                  DBG('Invalid country code');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               'LCUPLD-035',
                               P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                               .COUNTRY_CODE);
                END IF;

              END IF;

              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).LANG_CODE IS NOT NULL THEN
                SELECT COUNT(*)
                  INTO L_COUNT
                  FROM SMTBS_LANGUAGE
                 WHERE LANG_CODE = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                      .LANG_CODE;

                IF L_COUNT = 0 THEN
                  DBG('Invalid language code');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               'LCUPLD-036',
                               P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).LANG_CODE);
                END IF;

              END IF;

            ELSE
              BEGIN
                DBG('fetching the customer details' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                    .CIF_ID);
                SELECT CUSTOMER_NAME1,
                       LANGUAGE,
                       COUNTRY,
                       ADDRESS_LINE1,
                       ADDRESS_LINE2,
                       ADDRESS_LINE3,
                       ADDRESS_LINE4
                  INTO L_CUST_NAME,
                       L_LANG_CODE,
                       L_CNTRY_CODE,
                       L_ADDR_LINE1,
                       L_ADDR_LINE2,
                       L_ADDR_LINE3,
                       L_ADDR_LINE4
                  FROM STTM_CUSTOMER
                 WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                      .CIF_ID;

              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('failed to select the cust name');
                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-037', NULL);

              END;

              L_COUNT_1 := 0;
              DBG('global.current_branch::' || GLOBAL.CURRENT_BRANCH);

              FOR EACH_REC IN (SELECT *

                                 FROM STTM_CUSTOMER
                                WHERE CUSTOMER_CATEGORY = 'WALKIN'
                                  AND LOCAL_BRANCH = GLOBAL.CURRENT_BRANCH
                                  AND AUTH_STAT = 'A'
                                  AND RECORD_STAT = 'O') LOOP
                DBG('26427858 walkin  customer ' || EACH_REC.CUSTOMER_NO);
                DBG('p_Wrk_Lcdtronl.v_Lctbs_Parties(i).CIF_ID ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                    .CIF_ID);
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .CIF_ID = EACH_REC.CUSTOMER_NO THEN
                  L_COUNT_1 := 0;
                  DBG('l_count : ' || L_COUNT_1);
                  EXIT;
                ELSE
                  L_COUNT_1 := L_COUNT_1 + 1;
                  DBG('l_count IN ELSE : ' || L_COUNT_1);
                END IF;
              END LOOP;
              DBG('L_COUNT FINAL  ' || L_COUNT_1);
              DBG('Got the final count::' || L_COUNT_1);

              DBG('Cif id ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID);
              DBG('p_Wrk_Lcdtronl.v_Lctbs_Parties(i).Country_Code' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                  .COUNTRY_CODE);
              DBG('l_Cntry_Code ' || L_CNTRY_CODE);

              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).COUNTRY_CODE IS NOT NULL THEN

                IF L_COUNT_1 <> 0 THEN
                  IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                   .COUNTRY_CODE != L_CNTRY_CODE THEN
                    DBG('Cannot change the country');
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 P_SOURCE,
                                 'LCUPLD-038',
                                 NULL);

                  ELSE
                    SELECT COUNT(*)
                      INTO L_BLKLIST
                      FROM STTM_COUNTRY
                     WHERE COUNTRY_CODE = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                          .COUNTRY_CODE
                       AND BLACKLISTED = 'Y';

                    IF L_BLKLIST > 0 AND P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                      .PARTY_TYPE = 'BEN' THEN
                      DBG('Beneficiary Country is Blacklisted');
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   P_SOURCE,
                                   'LCUPLD-518',
                                   NULL);
                    END IF;

                  END IF;
                END IF;

              END IF;

              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).LANG_CODE IS NOT NULL THEN
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .LANG_CODE != L_LANG_CODE THEN
                  DBG('Cannot change the language code');
                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-039', NULL);
                END IF;

              END IF;

              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_NAME IS NOT NULL THEN
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                 .CUST_NAME != L_CUST_NAME THEN
                  DBG('Cannot change the customer name');

                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               'LCUPLD-040',
                               P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE);

                END IF;

              END IF;

            END IF;

          END IF;
        END LOOP;

      END IF;

      DBG('p_Product_Definition.Product_Type' ||
          P_PRODUCT_DEFINITION.PRODUCT_TYPE);

      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN

        IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' THEN
          FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
            DBG('product type' || P_PRODUCT_DEFINITION.PRODUCT_TYPE);

            L_PARTY_TYPE := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE;
            DBG('p_Product_Definition.Product_Type' ||
                P_PRODUCT_DEFINITION.PRODUCT_TYPE);

            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE IS NOT NULL THEN
              DBG('CALLING Fn_Validate_Partytyp..');
              IF NOT FN_VALIDATE_PARTYTYP(P_SOURCE,
                                          L_PARTY_TYPE,
                                          P_PRODUCT_DEFINITION.PRODUCT_TYPE,
                                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS) THEN

                DBG('Invalid party type');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LCUPLD-041',
                             L_PARTY_TYPE);
              END IF;

              DBG('l_Party_Type' || L_PARTY_TYPE);
              IF L_PARTY_TYPE IN ('APP', 'BEN', 'ISB') THEN

                E_COUNT := E_COUNT + 1;
                DBG('The count of the party type is' || E_COUNT);
              END IF;

              IF L_PARTY_TYPE = 'ISB' AND
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE != 'ISB' THEN
                IF ((P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO IS NULL) OR
                   (P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_DATE IS NULL)) THEN

                  DBG('Their ref and Date is mandatory');
                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-090', NULL);
                END IF;

              END IF;

              DBG(' Party type ' || L_PARTY_TYPE);
              DBG(' Customer type ' ||
                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE);
              IF CSPKS_FEATURE.FN_INSTALLED('PARTY_CUST_TYPE',
                                            GLOBAL.CURRENT_BRANCH) THEN

                IF L_PARTY_TYPE = 'ISB' AND
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE = 'ISB' THEN
                  IF ((P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO IS NULL) OR
                     (P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                     .CUST_REF_DATE IS NULL)) THEN

                    DBG('Their ref and Date is mandatory');
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 P_SOURCE,
                                 'LCCON-090',
                                 NULL);
                  END IF;

                END IF;

              END IF;

            END IF;

          END LOOP;

          DBG('The count of the party type is' || E_COUNT);
          IF E_COUNT < 3 THEN
            DBG('the product type  is cmg here');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-013', NULL);
          END IF;

          DBG('cmg here');
        ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN
              ('I', 'C', 'S', 'H', 'G', 'R') THEN
          DBG('product type is not E');
          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
            FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
              L_PARTY_TYPE := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE;

              IF NOT FN_VALIDATE_PARTYTYP(P_SOURCE,
                                          L_PARTY_TYPE,
                                          P_PRODUCT_DEFINITION.PRODUCT_TYPE,
                                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS) THEN

                DBG('Invalid l_party_type');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LCUPLD-041',
                             L_PARTY_TYPE);
              END IF;

              IF L_PARTY_TYPE IN ('APP', 'BEN') THEN

                I_COUNT := I_COUNT + 1;
                DBG('The count of the party type is' || I_COUNT);
              END IF;

              IF L_PARTY_TYPE IN ('ISB') AND
                 NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'Y' THEN
                I_COUNT     := I_COUNT + 1;
                L_ISB_COUNT := L_ISB_COUNT + 1;
                DBG('ISB present so 1+count of the party type is' ||
                    I_COUNT);
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO IS NULL THEN
                  DBG('Their ref is mandatory');
                  OVPKS.PR_APPENDTBL('LC-REMB-008', NULL);
                END IF;

              END IF;

              IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('G', 'H') AND
                 L_PARTY_TYPE = 'APB' THEN
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO IS NULL OR P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                   .CUST_REF_DATE IS NULL THEN
                  DBG('Their ref is mandatory');
                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-215', NULL);
                END IF;

              END IF;

            END LOOP;

            IF NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') <> 'Y' THEN

              IF I_COUNT < 2 THEN
                DBG('Mandatory parties not entered');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-013', NULL);
              END IF;

            END IF;

            IF NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'Y' AND
               L_ISB_COUNT = 0 THEN
              DBG('Mandatory parties not entered - ISB');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-REMB-001', NULL);
              OVPKS.PR_APPENDTBL('LC-REMB-001', NULL);
            END IF;

            IF NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'Y'

               AND I_COUNT < 1 THEN

              DBG('Mandatory parties not entered - ISB');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-013', NULL);
            END IF;

          END IF;

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT > 0 THEN

        FOR I IN P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.LAST LOOP
          IF ((P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).PARTY_TYPE IS NULL) OR
             (P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).MEDIUM_TYPE IS NULL) OR
             (P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
             .MEDIUM_ADDRESS IS NULL)) THEN
            DBG('party type,media and address should be entered');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-069', NULL);
          END IF;

          IF ((P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
             .MEDIUM_TYPE != 'SWIFT') AND
             (P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).ACC_NO IS NOT NULL)) THEN
            DBG('account number is only for SWIFT medium type');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-042', NULL);
          END IF;

          IF ((P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
             .MEDIUM_TYPE = 'SWIFT') AND
             (NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                          .MEDIUM_ADDRESS),
                   0) != 8 AND NVL(LENGTH(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                                            .MEDIUM_ADDRESS),
                                     0) != 11)) THEN
            DBG('Invalid swift address');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCCON-077',
                         P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                         .MEDIUM_TYPE);
          END IF;

          IF (P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
             .MEDIUM_TYPE = 'SWIFT') THEN
            SELECT COUNT(1)
              INTO L_VALID_BIC
              FROM ISTM_BIC_DIRECTORY
             WHERE BIC_CODE = P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                  .MEDIUM_ADDRESS
               AND RECORD_STAT = 'O'
               AND ONCE_AUTH = 'Y';

            IF L_VALID_BIC = 0 THEN
              DBG('For walkin customer address shud be A valid bic');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'ST-VALS-011',
                           P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                           .MEDIUM_ADDRESS ||
                            '~@LCTBS_OTHER_ADDRESSES~@LCTBS_OTHER_ADDRESSES.ADDRESS');
            END IF;
          END IF;

          IF ((P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
             .MEDIUM_TYPE = 'TELEX') AND
             (TO_NUMBER(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                         .MEDIUM_ADDRESS) < 0)) THEN
            DBG('Invalid swift address');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCCON-077',
                         P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                         .MEDIUM_TYPE);
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
            FOR J IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
              L_PARTY_TYPE := P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).PARTY_TYPE;

              IF L_PARTY_TYPE IS NOT NULL THEN
                IF L_PARTY_TYPE = P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                  .PARTY_TYPE THEN

                  IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                   .CIF_ID IS NULL THEN
                    P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).CIF_ID := P_WRK_LCDTRONL.V_LCTBS_PARTIES(J)
                                                                        .CIF_ID;
                  END IF;

                  L_FLAG := 1;
                  EXIT;
                END IF;

              END IF;

            END LOOP;

          END IF;

          IF L_FLAG = 0 THEN
            DBG('the party type in other address should be there in party details');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCUPLD-043',
                         P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                         .PARTY_TYPE);
          ELSE
            L_FLAG := 0;

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT <> 0 THEN

            FOR J IN P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.LAST LOOP
              IF I != J THEN
                IF ((P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).PARTY_TYPE = P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(J)
                   .PARTY_TYPE) AND
                   (P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).MEDIUM_TYPE = P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(J)
                   .MEDIUM_TYPE)) THEN
                  DBG('Duplicate media type');
                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-044', NULL);
                END IF;

              END IF;

            END LOOP;

            SELECT COUNT(*)
              INTO L_COUNT
              FROM MSTMS_MEDIA
             WHERE MEDIA = P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                  .MEDIUM_TYPE
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';

            IF L_COUNT = 0 THEN
              DBG('Invalid medium type');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-045', NULL);
            END IF;

          END IF;

        END LOOP;

      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Validate_Parties ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE_PARTIES;

  FUNCTION FN_VALIDATE_SHIP_DOCS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                 P_FUNCTION_ID        IN VARCHAR2,
                                 P_ACTION_CODE        IN VARCHAR2,
                                 P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                 P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_PREV_LCDTRONL      IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_WRK_LCDTRONL       IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_ERR_CODE           IN OUT VARCHAR2,
                                 P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT             NUMBER;
    FOUND               NUMBER := 0;
    L_SHIPDOCS_ALLOWED  CHAR(1);
    L_SHIPDOCS_REQUIRED CHAR(1);
    L_INCO_DESCRIPTION  LCTBS_INCO_TERMS.INCO_DESCRIPTION%TYPE;

    L_PORT_DISCHARGE LCTBS_SHIPMENT.PORT_DISCHARGE%TYPE;
    L_PORT_LOADING   LCTBS_SHIPMENT.PORT_LOADING%TYPE;

    L_GOODS_DESCR LCTB_GOODS.GOODS_DESCR%TYPE;

    L_FROM_PLACE           LCTBS_SHIPMENT.FROM_PLACE%TYPE;
    L_TO_PLACE             LCTBS_SHIPMENT.TO_PLACE%TYPE;
    L_LATEST_SHIPMENT_DATE LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE%TYPE;
    L_SHIPMENT_PERIOD      LCTBS_SHIPMENT.SHIPMENT_PERIOD%TYPE;

  BEGIN
    DBG('Inside the function fn_validate_ship_docs');

    DBG('validate port of discharge');
    DBG('p_action_code : ' || P_ACTION_CODE);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY

       AND
       (P_FUNCTION_ID IN ('LCDTRONL', 'LIDTRONL') AND
       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD = 'Y')

     THEN
      BEGIN

        SELECT LS.PORT_DISCHARGE,
               LS.PORT_LOADING

              ,
               LS.FROM_PLACE,
               LS.TO_PLACE,
               LS.LATEST_SHIPMENT_DATE,
               LS.SHIPMENT_PERIOD

          INTO L_PORT_DISCHARGE,
               L_PORT_LOADING

              ,
               L_FROM_PLACE,
               L_TO_PLACE,
               L_LATEST_SHIPMENT_DATE,
               L_SHIPMENT_PERIOD

          FROM LCTBS_AMND_VALS_MASTER LS
         WHERE LS.CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND LS.AMND_SEQ_NO =
               (SELECT MAX(LS.AMND_SEQ_NO)
                  FROM LCTBS_AMND_VALS_MASTER LS
                 WHERE LS.CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Shipment details not found');
          BEGIN
            SELECT PORT_DISCHARGE,
                   PORT_LOADING

                  ,
                   FROM_PLACE,
                   TO_PLACE,
                   LATEST_SHIPMENT_DATE,
                   SHIPMENT_PERIOD

              INTO L_PORT_DISCHARGE,
                   L_PORT_LOADING

                  ,
                   L_FROM_PLACE,
                   L_TO_PLACE,
                   L_LATEST_SHIPMENT_DATE,
                   L_SHIPMENT_PERIOD

              FROM LCTBS_SHIPMENT
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
               AND EVENT_SEQ_NO =
                   (SELECT MAX(EVENT_SEQ_NO)
                      FROM LCTBS_SHIPMENT
                     WHERE CONTRACT_REF_NO =
                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Shipment details not found');

          END;

      END;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' AND
         P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_DISCHARGE, '*') <>
           NVL(L_PORT_DISCHARGE, '*') AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD = 'Y' THEN
          DBG('port of discharge cannot be modified');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-VALS-375',
                       'PORT OF DISCHARGE');

        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_LOADING, '*') <>
           NVL(L_PORT_LOADING, '*') AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD = 'Y' THEN
          DBG('port of loading cannot be modified');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-VALS-375',
                       'PORT OF LOADING');

        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.FROM_PLACE, '*') <>
           NVL(L_FROM_PLACE, '*') THEN
          DBG('from place cannot be modified');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-405', NULL);
        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TO_PLACE, '*') <>
           NVL(L_TO_PLACE, '*') THEN
          DBG('to place cannot be modified');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-406', NULL);

        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE,
               L_LATEST_SHIPMENT_DATE + 1) <>
           NVL(L_LATEST_SHIPMENT_DATE,
               P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE + 1) THEN
          DBG('latest shipment date cannot be modified');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-407', NULL);

        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_PERIOD, '*') <>
           NVL(L_SHIPMENT_PERIOD, '*') THEN
          DBG('shipment period cannot be modified');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-408', NULL);
        END IF;

      END IF;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN ('RMB') THEN
      IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 OR
         P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT > 0 THEN
        DBG('ship doc details are not allowed for this product');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-111', NULL);
        RETURN FALSE;
      END IF;

    END IF;

    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G'

       OR P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE = 'Y' THEN

      IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 OR
         P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT > 0 THEN

        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.LAST LOOP
          DBG('Doc Type' || P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_TYPE);
          IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_TYPE <> 'C' THEN

            DBG('Only claim type documents are allowed for this product');
            P_ERR_CODE := 'LC-VALS-558';

            P_ERR_PARAMS := NULL;
            RETURN FALSE;

          END IF;
        END LOOP;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.FROM_PLACE IS NOT NULL OR
         P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TO_PLACE IS NOT NULL OR
         NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT, 'N') = 'Y' OR
         NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT, 'N') = 'Y' OR
         P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE IS NOT NULL OR
         P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_PERIOD IS NOT NULL OR
         P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS IS NOT NULL OR
         P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS IS NOT NULL OR
         P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_DISCHARGE IS NOT NULL OR

         P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_LOADING IS NOT NULL THEN
        DBG('shipment detail not allowed for this product');
        P_ERR_CODE   := 'LCUPLD-111';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE IS NOT NULL OR
         P_WRK_LCDTRONL.V_LCTBS_GOODS.PRE_ADVICE_DESCR IS NOT NULL OR
         P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR IS NOT NULL THEN
        DBG('Goods detail not allowed for this product');
        P_ERR_CODE   := 'LCUPLD-111';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

    END IF;

    DBG('The advice of guarentee is ' ||
        P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE);
    DBG('p_product_definition.product_type-->' ||
        P_PRODUCT_DEFINITION.PRODUCT_TYPE);
    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
       NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'N' THEN
      DBG('inside  export');
      L_SHIPDOCS_ALLOWED  := 'T';
      L_SHIPDOCS_REQUIRED := 'T';

    ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'I' AND
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN ('RMB') THEN

      DBG('inside import');
      L_SHIPDOCS_ALLOWED  := 'F';
      L_SHIPDOCS_REQUIRED := 'F';

    ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'I' THEN

      DBG('inside to assign doc allowed');
      L_SHIPDOCS_ALLOWED  := 'T';
      L_SHIPDOCS_REQUIRED := 'T';

    ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'C' THEN

      DBG('inside to assign doc allowed for C');
      L_SHIPDOCS_ALLOWED  := 'T';
      L_SHIPDOCS_REQUIRED := 'F';

    ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'S' THEN

      DBG('inside to assign doc allowed for S');
      L_SHIPDOCS_ALLOWED  := 'T';
      L_SHIPDOCS_REQUIRED := 'F';

    ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' THEN

      DBG('inside to assign doc allowed for F');
      L_SHIPDOCS_ALLOWED := 'F';

      L_SHIPDOCS_REQUIRED := 'T';

    ELSIF ((P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G') OR
          (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
          NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y')) THEN
      DBG('inside to assign doc allowed for for G again');
      L_SHIPDOCS_ALLOWED := 'F';

      L_SHIPDOCS_REQUIRED := 'T';

    ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'H' THEN

      L_SHIPDOCS_ALLOWED  := 'F';
      L_SHIPDOCS_REQUIRED := 'T';

    ELSE
      L_SHIPDOCS_ALLOWED  := 'T';
      L_SHIPDOCS_REQUIRED := 'T';

    END IF;

    DBG('inside docs-->' || L_SHIPDOCS_REQUIRED || ' type-->' ||
        P_PRODUCT_DEFINITION.PRODUCT_TYPE);
    IF L_SHIPDOCS_REQUIRED = 'F' AND
       P_PRODUCT_DEFINITION.PRODUCT_TYPE != 'S' THEN
      IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 OR
         P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT > 0 THEN
        DBG('ship doc details not allowed for this product');
        P_ERR_CODE   := 'LCCON-059';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

    END IF;

    DBG('before if....');
    IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 THEN
      FOR I IN P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.LAST LOOP
        FOR J IN P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.LAST LOOP
          IF I != J THEN
            DBG('inside this if..');
            IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
             .DOC_CODE = P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(J).DOC_CODE THEN
              DBG('Duplicate doc codes');
              P_ERR_CODE   := 'LCUPLD-046';
              P_ERR_PARAMS := NULL;
              RETURN FALSE;
              EXIT;
            END IF;

          END IF;

        END LOOP;

        DBG('coming here....' || P_PRODUCT_DEFINITION.PRODUCT_TYPE);
        IF P_PRODUCT_DEFINITION.PRODUCT_TYPE != 'H' THEN
          IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_REFERENCE IS NOT NULL THEN
            DBG('Reference code is not allowed for this product');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-047', NULL);
          END IF;

        END IF;

        DBG('before this if...');
        IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
         .DOC_ORIGINAL IS NOT NULL AND P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
           .DOC_ORIGINAL NOT IN ('Y', 'N') THEN
          DBG('Invalid value for p_upl_tbl_doc(i).doc_original');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LD-VALS-012',
                       'original Required');
        END IF;

        DBG('before docs check...');
        IF NVL(P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_ORIGINAL, 'N') = 'N' THEN

          IF NVL(LTRIM(RTRIM(P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                             .NO_OF_ORIGINALS)),
                 '0') <> '0'

           THEN
            DBG('Not reqd');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCPR-094', NULL);
          END IF;

        END IF;

        DBG('before select...');
        SELECT COUNT(*)
          INTO L_COUNT
          FROM BCTMS_DOCS_MASTER
         WHERE DOC_CODE = P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE
           AND LANG_CODE =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE

           AND RECORD_STAT = 'O'
           AND ONCE_AUTH = 'Y';

        DBG('before l_count...' || L_COUNT);
        IF L_COUNT = 0 THEN
          DBG('Invalid document code');
          P_ERR_CODE   := 'LCUPLD-048';
          P_ERR_PARAMS := P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE;
          RETURN FALSE;
        END IF;

        DBG('after select...');
        IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_TYPE IS NOT NULL THEN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM BCTMS_DOCS_MASTER
           WHERE DOC_CODE = P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE
             AND DOC_TYPE = P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_TYPE
             AND LANG_CODE =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE;

          IF L_COUNT = 0 THEN
            DBG('Invalid document type');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCUPLD-049',
                         P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_TYPE);
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).NO_OF_ORIGINALS IS NOT NULL THEN
          IF NOT LCPKS_UTILS.FN_VALIDATE_ORGDOCS(P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                                                 .NO_OF_ORIGINALS,
                                                 P_ERR_CODE) THEN
            DBG('Lcpks_utils.fn_validate_orgdocs failed to validate');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, '');
          END IF;
        END IF;

      END LOOP;

    END IF;

    DBG('this if starts');
    IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT > 0 THEN
      FOR I IN P_WRK_LCDTRONL.V_LCTBS_CLAUSES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.LAST LOOP
        FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT LOOP
          IF I != J THEN
            DBG('inside for loop');
            IF ((P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
               .CLAUSE_CODE = P_WRK_LCDTRONL.V_LCTBS_CLAUSES(J).CLAUSE_CODE) AND
               (P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
               .DOC_CODE = P_WRK_LCDTRONL.V_LCTBS_CLAUSES(J).DOC_CODE)) THEN
              DBG('Duplicate clause code');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LCUPLD-050',
                           P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).CLAUSE_CODE);
              EXIT;
            END IF;

          END IF;

        END LOOP;

        DBG('doc count check...');
        IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT = 0 THEN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM LCTMS_PRODUCT_DOCUMENTS PD, BCTMS_DOCS_MASTER DM
           WHERE PD.PRODUCT_CODE =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE
             AND PD.DOCUMENT_CODE = DM.DOC_CODE
             AND DM.DOC_CODE = P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE
             AND DM.LANG_CODE =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE;

          IF L_COUNT = 0 THEN
            DBG('Invalid document code');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCUPLD-048',
                         P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE);
          END IF;

        ELSE
          FOR K IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT LOOP
            IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
             .DOC_CODE = P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(K).DOC_CODE THEN
              FOUND := 1;
              EXIT;
            END IF;

          END LOOP;

          IF FOUND = 0 THEN
            DBG('Invalid document code');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LCUPLD-048',
                         P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE);
          END IF;

        END IF;

        FOUND := 0;
        SELECT COUNT(*)
          INTO L_COUNT
          FROM LCTMS_CLAUSE_MASTER
         WHERE CLAUSE_TYPE =
               (SELECT DOC_TYPE
                  FROM BCTMS_DOCS_MASTER
                 WHERE DOC_CODE = P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE
                   AND LANG_CODE =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE)
           AND CLAUSE_CODE = P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).CLAUSE_CODE
           AND LANGUAGE_CODE =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE;

        IF L_COUNT = 0 THEN
          DBG('Invalid clause code');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-051', NULL);
        END IF;

      END LOOP;

    END IF;

    DBG('p_wrk_lcdtronl.v_lctbs_shipment.latest_shipment_date-->' ||
        P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE);
    IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE IS NOT NULL THEN
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NOT NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
          DBG('latest_shipment_date cannot be greater than expiry_date');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-056', NULL);

        END IF;

      END IF;

      DBG('l_shipdocs_required-->' || L_SHIPDOCS_REQUIRED);
      IF L_SHIPDOCS_REQUIRED = 'T' THEN

        DBG('Its cmg here...');
        IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE <
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE THEN
          DBG('latest_shipment_date cannot be less than issue_date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-057', NULL);
        END IF;

      END IF;

      DBG('p_wrk_lcdtronl.v_lctbs_contract_master.next_reinstatement_date-->' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE);
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE IS NOT NULL THEN

        IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE >
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE THEN
          DBG('latest_shipment_date cannot be greater than next_reinstatement_date');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-055', NULL);
        END IF;

      END IF;

    END IF;

    IF

     (P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE IS NOT NULL OR
     P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DAYS IS NOT NULL) AND
     P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_PERIOD IS NOT NULL THEN
      DBG('latest_shipment_date and shipment period both cannot be enterd');

      DBG('Both Shipment Date or Days and Shipment Period cannot be entered');

      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-SDV-04', NULL);

    END IF;

    DBG('before fn_chk_inco_doc_clause');
    IF NOT FN_CHK_INCO_DOC_CLAUSE(P_SOURCE,
                                  P_FUNCTION_ID,
                                  P_ACTION_CODE,
                                  P_PRODUCT_DEFINITION,
                                  P_PREV_LCDTRONL,
                                  P_WRK_LCDTRONL,
                                  P_PREV_LCDTRONL,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN

      DBG('failed in fn_chk_inco_doc_clause');
      RETURN FALSE;
    END IF;

    IF NVL(L_SHIPDOCS_REQUIRED, 'F') = 'T' THEN

      IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
         NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y' THEN
        DBG('Shipment details not required for bank guarantee products');
      ELSE

        IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE IS NULL AND
           P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_PERIOD IS NULL THEN
          DBG('The error message....');
          P_ERR_CODE   := 'LC-SDV-02';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    DBG('Action : ' || P_ACTION_CODE || 'Goods Code : ' ||
        P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE || 'Goods Desc :' ||
        P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
       P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE IS NULL AND
       P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR IS NOT NULL THEN
      DBG('Goods description is provided without goods code. Procced ?');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-601', NULL);
    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_COUNT
        FROM BCTMS_GOODS_MASTER
       WHERE GOODS_CODE = P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE
         AND LANGUAGE_CODE = GLOBAL.LANG
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';

      IF L_COUNT = 0 THEN
        DBG('Invalid goods_code');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'BC-UP0139',
                     P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE);
      END IF;

    END IF;

    DBG('checking expiry date');
    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'I' THEN

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION IS NOT NULL THEN
        DBG('Period For Presentation is not null' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION);
        IF FN_VALID_NUMS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION) THEN

          DBG('Period For Presentation Value is Number ');

          IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE IS NOT NULL THEN
            DBG('checking expiry date5');
            IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE +
               NVL(TO_NUMBER(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION),
                   0) > P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
              DBG('checking expiry date8');
              P_ERR_CODE   := 'LCCON-504';
              P_ERR_PARAMS := NULL;
              DBG('checking expiry date9');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-504', NULL);
            END IF;

            IF P_PRODUCT_DEFINITION.CALCULATED_DAYS = 'Y' THEN
              IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION IS NOT NULL THEN
                IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION <>
                   NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                       P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE,
                       0) THEN

                  DBG(' Expiry date, Latest shipment date and Period for presentation are in Sync. Do you want to continue?');
                  P_ERR_CODE   := 'LC-VALS-101';
                  P_ERR_PARAMS := NULL;
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               P_ERR_CODE,
                               P_ERR_PARAMS);
                END IF;

              END IF;

            END IF;

          END IF;

        END IF;
      END IF;
    ELSE
      DBG('PRODUCT IS OF EXPORT TYPE');

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR IS NULL THEN
      IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS IS NULL THEN
        L_GOODS_DESCR := P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS;
      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS IS NOT NULL THEN
          L_GOODS_DESCR := P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS ||
                           CSPKES_MISC.FN_GETCHR(10) ||
                           P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS;
        ELSE
          L_GOODS_DESCR := P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS;

        END IF;

      END IF;

    ELSE
      IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS IS NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS IS NOT NULL THEN
          L_GOODS_DESCR := P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR ||
                           CSPKES_MISC.FN_GETCHR(10) ||
                           P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS;
        ELSE
          L_GOODS_DESCR := P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR;

        END IF;

      ELSE
        IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS IS NOT NULL THEN
          L_GOODS_DESCR := P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR ||
                           CSPKES_MISC.FN_GETCHR(10) ||
                           P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS ||
                           CSPKES_MISC.FN_GETCHR(10) ||
                           P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS;
        ELSE
          L_GOODS_DESCR := P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR ||
                           CSPKES_MISC.FN_GETCHR(10) ||
                           P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS;

        END IF;

      END IF;

    END IF;

    DBG('FCUBS_12.4_Guarantee_ClaimSettlement changes testing here');
    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
       (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
       P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE = 'Y') THEN
      IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.LAST LOOP
          DBG('p_Wrk_Lcdtronl.v_Lctbs_Documents(i).doc_original->' || P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
              .DOC_ORIGINAL);
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_ORIGINAL, '#') <> 'N' OR P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
            .DOC_COPIES IS NOT NULL OR P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
            .NO_OF_ORIGINALS IS NOT NULL OR P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
            .DOC_REFERENCE IS NOT NULL THEN
            DBG('Document details other than document code and doc description is not applicable.Hence defaulting to NULL');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-560', NULL);
            P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_ORIGINAL := NULL;
            P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_COPIES := NULL;
            P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).NO_OF_ORIGINALS := NULL;
            P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_REFERENCE := NULL;
          END IF;
        END LOOP;
      END IF;
    END IF;

    DBG('calling lcpks_swift_mt700.fn_validate_len');
    IF NOT LCPKS_SWIFT_MT700.FN_VALIDATE_45_47(L_GOODS_DESCR) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-236', NULL);

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Validate_Ship_Docs ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE_SHIP_DOCS;

  FUNCTION FN_CHK_INCO_DOC_CLAUSE(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                  P_FUNCTION_ID        IN VARCHAR2,
                                  P_ACTION_CODE        IN VARCHAR2,
                                  P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                  P_LCDTRONL           IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_PREV_LCDTRONL      IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_WRK_LCDTRONL       IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_ERR_CODE           IN OUT VARCHAR2,
                                  P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_FOUND  CHAR(1) := 'N';
    L_FOUND1 CHAR(1) := 'N';

    CURSOR CURDOCS IS
      SELECT *
        FROM TFTMS_INCO_DOCS
       WHERE INCO_TERM = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';

    CURSOR CURCLAUSES(DOC LCTBS_DOCUMENTS.DOC_CODE%TYPE) IS
      SELECT *
        FROM TFTMS_INCO_DOCS_CLAUSES
       WHERE DOC_CODE = DOC
         AND INCO_TERM = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM;

  BEGIN
    IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 THEN
      FOR I IN CURDOCS LOOP

        FOR J IN P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.LAST LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(J).DOC_CODE = I.DOC_CODE THEN
            BEGIN
              L_FOUND := 'Y';
            END;

            EXIT;
          END IF;

        END LOOP;

        IF L_FOUND = 'N' THEN

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-INCO-02', I.DOC_CODE);
        ELSE
          IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT > 0 THEN

            FOR J IN CURCLAUSES(I.DOC_CODE) LOOP
              FOR K IN P_WRK_LCDTRONL.V_LCTBS_CLAUSES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.LAST LOOP
                IF ((P_WRK_LCDTRONL.V_LCTBS_CLAUSES(K)
                   .CLAUSE_CODE = J.CLAUSE_CODE) AND
                   (P_WRK_LCDTRONL.V_LCTBS_CLAUSES(K).DOC_CODE = I.DOC_CODE)) THEN
                  L_FOUND1 := 'Y';
                  EXIT;
                END IF;

              END LOOP;

              IF L_FOUND1 = 'N' THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-INCO-03',

                             J.CLAUSE_CODE || '~' || I.DOC_CODE);
              END IF;

              L_FOUND1 := 'N';
            END LOOP;

          END IF;

        END IF;

        L_FOUND := 'N';
      END LOOP;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Chk_Inco_Doc_Clause ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_CHK_INCO_DOC_CLAUSE;

  FUNCTION FN_VALID_NUMS(P_IN_STRING IN VARCHAR2) RETURN BOOLEAN IS
    L_CHAR_TO_CHK VARCHAR2(1);
    VALID_SET     VARCHAR2(10) := '0123456789';

  BEGIN
    FOR L_INX IN 1 .. NVL(LENGTH(P_IN_STRING), 0) LOOP

      L_CHAR_TO_CHK := SUBSTR(P_IN_STRING, L_INX, 1);
      IF INSTR(VALID_SET, L_CHAR_TO_CHK) = 0 THEN
        RETURN FALSE;
      END IF;

    END LOOP;

    RETURN TRUE;
  END;

  FUNCTION FN_VALID_CHARS(P_IN_STRING  IN VARCHAR2,
                          P_FIELD_TYPE IN VARCHAR2,
                          P_OUT_STRING OUT VARCHAR2) RETURN BOOLEAN IS

    X_TYPE_SET    VARCHAR2(100);
    Y_TYPE_SET    VARCHAR2(100);
    Z_TYPE_SET    VARCHAR2(100);
    VALID_SET     VARCHAR2(100);
    L_INX         NUMBER;
    L_CHAR_TO_CHK VARCHAR2(1);
    L_VALID       BOOLEAN := TRUE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    MAIN_CHARS VARCHAR2(32767);
    SUB_CHARS  VARCHAR2(32767);
    POS        INTEGER;
    L_SKIP     BOOLEAN;

    CURSOR ALL_CHARS IS
      SELECT *
        FROM MSTMS_SWIFT_CHAR
       WHERE MAIN_CHAR <> SUB_CHAR
         AND RECORD_STAT = 'O'
         AND ONCE_AUTH = 'Y';

  BEGIN

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          LCPKS_LCDTRONL_UTILS_CLUSTER.FN_VALID_CHARS(P_IN_STRING,
                                                      P_FIELD_TYPE,
                                                      P_OUT_STRING,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in lcpks_lcdtronl_utils_cluster.Fn_Valid_Chars' ||
                       SQLERRM);
        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('LC',
                       'lcpks_lcdtronl_utils_cluster.Fn_Valid_Chars returned true');
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      FOR RECS IN ALL_CHARS LOOP
        MAIN_CHARS := MAIN_CHARS || NVL(RECS.MAIN_CHAR, ' ');
        SUB_CHARS  := SUB_CHARS || NVL(RECS.SUB_CHAR, ' ');
      END LOOP;

      X_TYPE_SET := ' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz' ||
                    '0123456789/-?:().,''+' || CHR(10) || CHR(13);
      Y_TYPE_SET := ' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz' ||
                    '0123456789.,-()/=''+:?!"%&*<>';

      IF NVL(LCPKS_ADVICES.G_SWIFT2018_ENABLED, 'N') = 'Y' THEN
        Z_TYPE_SET := ' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz' ||
                      '0123456789.,-()/=''+:?!"%&*<>;{@#_' || CHR(10) ||
                      CHR(13);
      END IF;

      P_OUT_STRING := P_IN_STRING;

      IF P_FIELD_TYPE = 'X' THEN

        VALID_SET := X_TYPE_SET;
      ELSIF P_FIELD_TYPE = 'Y' THEN

        VALID_SET := Y_TYPE_SET;

      ELSIF P_FIELD_TYPE = 'Z' AND
            NVL(LCPKS_ADVICES.G_SWIFT2018_ENABLED, 'N') = 'Y' THEN
        DEBUG.PR_DEBUG('LC', 'Z Character Set-->' || P_IN_STRING);
        VALID_SET := Z_TYPE_SET;

      END IF;

      FOR L_INX IN 1 .. NVL(LENGTH(P_IN_STRING), 0) LOOP

        L_CHAR_TO_CHK := SUBSTR(P_IN_STRING, L_INX, 1);
        IF INSTR(VALID_SET, L_CHAR_TO_CHK) = 0 THEN

          L_SKIP := TRUE;
          IF MAIN_CHARS IS NOT NULL AND SUB_CHARS IS NOT NULL THEN
            POS := INSTR(MAIN_CHARS, L_CHAR_TO_CHK, 1);
            IF POS <> 0 THEN
              L_CHAR_TO_CHK := SUBSTR(SUB_CHARS, POS, 1);
              IF (INSTR(VALID_SET, L_CHAR_TO_CHK, 1) = 0) THEN
                DEBUG.PR_DEBUG('IS', 'Not maintained Char can be replaced');
              ELSE
                L_SKIP := FALSE;
              END IF;
            END IF;
          END IF;
          IF L_SKIP THEN

            L_VALID      := FALSE;
            P_OUT_STRING := SUBSTR(P_OUT_STRING, 1, L_INX - 1) || '#' ||
                            SUBSTR(P_OUT_STRING, L_INX + 1);
          END IF;
        END IF;

      END LOOP;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;

    END IF;

    RETURN L_VALID;

    RETURN NULL;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Valid_Chars ');
      DBG(SQLERRM);
      RETURN FALSE;

  END FN_VALID_CHARS;

  FUNCTION FN_SWIFT_VALIDATIONS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_FUNCTION_ID        IN VARCHAR2,
                                P_ACTION_CODE        IN VARCHAR2,
                                P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_ERR_CODE           IN OUT VARCHAR2,
                                P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_TEMP       VARCHAR2(32767);
    L_FFT_LENGTH NUMBER := 0;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_RET_VALUE  BOOLEAN := TRUE;
    L_PORTION1   VARCHAR2(32767);
    L_PORTION2   VARCHAR2(32767);
    L_TEMP_STR   VARCHAR2(32767);
    L_LINE_COUNT NUMBER(3) := 1;
    L_POPSTR     VARCHAR2(32767);

    L_CODE     VARCHAR2(1);
    L_FLD_TYPE VARCHAR2(1);
  BEGIN

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          LCPKS_LCDTRONL_UTILS_CLUSTER.FN_SWIFT_VALIDATIONS(P_SOURCE,
                                                            P_FUNCTION_ID,
                                                            P_ACTION_CODE,
                                                            P_PRODUCT_DEFINITION,
                                                            P_LCDTRONL,
                                                            P_WRK_LCDTRONL,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in lcpks_lcdtronl_utils_cluster.Fn_Swift_Validations' ||
                       SQLERRM);
        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('LC',
                       'lcpks_lcdtronl_utils_cluster.Fn_Swift_Validations returned true');
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_PLACE,

                            'X',

                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-01', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-02', NULL);
      END IF;

      IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                      P_FUNCTION_ID,
                                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS,
                                      4,
                                      35,
                                      'Payment Details',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

        DBG('Failed in  fn_swift_check_credit_avl_with');
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-03', NULL);
      END IF;

      IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                      P_FUNCTION_ID,
                                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH,
                                      4,
                                      35,
                                      'Credit avl with',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

        DBG('Failed in fn_swift_check_credit_avl_with');

      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-37', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-38', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-04', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_LOADING,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-06A', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_DISCHARGE,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-06B', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-07', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-08', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_PERIOD,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-SDV-01', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT_DETAILS,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-001', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT_DETAILS,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-002', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.FROM_PLACE,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'LC-ADV-36',
                     '@BLK_SHIPMENT_DETAILS. FROMPALCE');
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TO_PLACE,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'LC-ADV-36',
                     '@BLK_SHIPMENT_DETAILS. TOPLACE');
      END IF;

      IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                      P_FUNCTION_ID,
                                      P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_PERIOD,
                                      6,
                                      65,
                                      'Shipment Period',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

        DBG('Failed in fn_swift_check_credit_avl_with');
      END IF;
      DBG('p_Wrk_Lcdtronl.v_Lctbs_Goods.Goods_Descr Z Character Set-->' ||
          P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR);

      DBG('lcpks_advices.g_swift2018_enabled' ||
          LCPKS_ADVICES.G_SWIFT2018_ENABLED);
      IF NVL(LCPKS_ADVICES.G_SWIFT2018_ENABLED, 'N') = 'Y' THEN
        L_FLD_TYPE := 'Z';
      ELSE
        L_FLD_TYPE := 'X';
      END IF;

      IF NOT

          FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR,

                         L_FLD_TYPE,
                         L_TEMP) THEN

        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-09', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_GOODS.PRE_ADVICE_DESCR,

                            L_FLD_TYPE,

                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-10', NULL);
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.CONDITIONS_FOR_BEN,
                            'Z',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-40', NULL);
      END IF;
      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.CONDITIONS_FOR_RECVBANK,
                            'Z',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-41', NULL);
      END IF;

      BEGIN
        SELECT PARAM_VAL
          INTO L_CODE
          FROM CSTB_PARAM
         WHERE PARAM_NAME = 'SWIFTTRADE2019_ENABLED';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('failed in selecting param val');
      END;
      SELECT DECODE(L_CODE, 'Y', 'Z', 'N', 'X', 'X') INTO L_CODE FROM DUAL;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_BEN,

                            'Z',

                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-11', NULL);
      END IF;

      IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                      P_FUNCTION_ID,
                                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_BEN,
                                      6,
                                      35,
                                      'Charges From Beneficiary',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

        DBG('Failed in fn_swift_check_credit_avl_with');
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-12', NULL);
      END IF;

      IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                      P_FUNCTION_ID,
                                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED,
                                      4,
                                      35,
                                      'Additional Amounts Covered',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

        DBG('Failed in fn_swift_check_credit_avl_with');

      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRESENTATION_NARRATIVE,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-13', NULL);
      END IF;

      WHILE L_RET_VALUE = TRUE LOOP

        L_RET_VALUE := LCPKSS_ADV_MISC.FN_SEP_STRING(L_POPSTR,
                                                     L_PORTION1,
                                                     L_PORTION2,
                                                     35);

        IF L_PORTION1 IS NOT NULL THEN
          L_LINE_COUNT := L_LINE_COUNT + 1;
        END IF;

        DBG('l_line_count::' || L_LINE_COUNT);

        L_POPSTR := L_PORTION2;

        IF L_LINE_COUNT = 5 AND L_POPSTR IS NOT NULL THEN
          L_RET_VALUE := FALSE;
          DBG('override is raised');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-ADV-021',
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION);
        END IF;
      END LOOP;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_ISB,

                            L_FLD_TYPE,

                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-14', NULL);
      END IF;

      IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                      P_FUNCTION_ID,
                                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_ISB,
                                      6,
                                      35,
                                      'Charges From ISB',
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN

        DBG('Failed in fn_swift_check_credit_avl_with');
      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACCOUNT_FOR_ISB,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-15', NULL);
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.LAST LOOP
          DBG('credit_day' || P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
              .CREDIT_DAYS_FROM);
          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                                .CREDIT_DAYS_FROM,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations for credit days from');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-35', NULL);
          END IF;

        END LOOP;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP

          DBG('p_Wrk_Lcdtronl.v_Lctbs_Parties(i).Cust_Name' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
              .CUST_NAME);
          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_NAME,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-17',

                         P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE);

          END IF;

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                .CUST_ADDRESS_LIN1,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-17A',

                         P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE);

          END IF;

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                .CUST_ADDRESS_LIN2,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-17B',

                         P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE);

          END IF;

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                .CUST_ADDRESS_LIN3,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-17C',

                         P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE);

          END IF;

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                .CUST_ADDRESS_LIN4,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-17D',

                         P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE);

          END IF;

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-17E',

                         P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE);

          END IF;

        END LOOP;

      END IF;

      IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_LC_REF_NO,
                            'X',
                            L_TEMP) THEN
        DBG('Failed in swift validations');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'LC-ADV-44',
                     '@LCTBS_CONTRACT_MASTER.USER_LC_REF_NO');
      END IF;
      IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.LAST LOOP
          DBG('medium_address' || P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
              .MEDIUM_ADDRESS);
          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                                .MEDIUM_ADDRESS,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations for credit days from');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-43',
                         '@LCTBS_OTHER_ADDRESSES.MEDIUM_ADDRESS' || '~' || P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                         .PARTY_TYPE);
          END IF;
          DBG('acc_no' || P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).ACC_NO);
          IF NOT
              FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).ACC_NO,
                             'X',
                             L_TEMP) THEN
            DBG('Failed in swift validations for credit days from');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-43',
                         '@LCTBS_OTHER_ADDRESSES.ACC_NO' || '~' || P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                         .PARTY_TYPE);
          END IF;
        END LOOP;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.LAST LOOP
          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_DESCR,

                                L_FLD_TYPE,

                                L_TEMP) THEN
            DBG('Failed in swift validations');

            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-18',
                         P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE);

          END IF;

        END LOOP;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_CLAUSES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.LAST LOOP
          IF NOT
              FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).CLAUSE_DESCR,

                             L_FLD_TYPE,

                             L_TEMP) THEN
            DBG('Failed in swift validations');

            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-19',
                         P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE || '~' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
                         .CLAUSE_CODE);

          END IF;

        END LOOP;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_FFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_FFTS.LAST LOOP

          IF (SUBSTR(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_CODE, 1, 3) =
             '23X' AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG = 'Y') THEN
            IF NOT
                FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR,
                               'X',
                               L_TEMP) THEN
              DBG('Failed in swift validations');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-ADV-16',
                           P_WRK_LCDTRONL.V_LCTBS_FFTS(I).MESG_TYPE);
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).MESG_TYPE IN ('LC_AMND_INSTR') THEN
              IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_DESCR,
                                              12,
                                              65,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_CODE ||
                                               '- FFT ins Description',
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
                DBG('Failed in Fn_Swift_Dtag_Validation MT700-78 FFT ins Description');
              END IF;
            END IF;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
           .FFT_INS_CODE LIKE 'INSTRUCTION%' THEN
            IF NOT
                FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR,
                               'X',
                               L_TEMP) THEN
              DBG('Failed in swift validations - Z');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-ADV-16',
                           P_WRK_LCDTRONL.V_LCTBS_FFTS(I).MESG_TYPE);
            END IF;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
           .MESG_TYPE IN
                 ('GUARANTEE', 'GUA_AMD_INSTR', 'GUA_ACK_ADVICE') THEN
            IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR IS NOT NULL THEN
              IF NOT
                  FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR,
                                 'X',
                                 L_TEMP) THEN
                DBG('Failed in swift validations');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-ADV-16',
                             P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                             .MESG_TYPE || ' FFT ' || P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                             .FFT_INS_CODE);
              END IF;
            END IF;

          ELSIF REGEXP_LIKE(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_CODE,
                            '^SND2RECMT\d{3}$') OR P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
               .FFT_INS_CODE IN ('SND2RECINFO', 'CANC') THEN

            IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
             .FFT_INS_CODE IN ('SND2RECMT740',
                                 'SND2RECMT747',
                                 'SND2RECMT730',
                                 'SND2RECMT705',
                                 'SND2RECMT700',
                                 'SND2RECMT710',
                                 'SND2RECMT720',
                                 'SND2RECMT707') OR
                (NVL(LCPKS_ADVICES.G_SWIFT2019_ENABLED, 'N') = 'Y' AND P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                 .FFT_INS_CODE IN ('SND2RECMT768',
                                  'SND2RECMT786',
                                  'SND2RECMT765',
                                  'SND2RECMT787',
                                  'SND2RECMT760',
                                  'SND2RECMT767',
                                  'SND2RECMT768',
                                  'SND2RECMT769')) THEN
              DBG('1 It is ' || P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                  .FFT_INS_CODE || ' and g_swift2019_enabled : ' ||
                  LCPKS_ADVICES.G_SWIFT2019_ENABLED ||
                  ', so doing Z char check..');
              IF NOT
                  FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR,
                                 'Z',
                                 L_TEMP) THEN
                DBG('Failed in swift validations - Z');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-ADV-16',
                             P_WRK_LCDTRONL.V_LCTBS_FFTS(I).MESG_TYPE);
              END IF;
            ELSE
              DBG('2 It is ' || P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                  .FFT_INS_CODE || ' and g_swift2019_enabled : ' ||
                  LCPKS_ADVICES.G_SWIFT2019_ENABLED ||
                  ', so doing X char check..');
              IF NOT
                  FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR,
                                 'X',
                                 L_TEMP) THEN
                DBG('Failed in swift validations - X');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-ADV-16',
                             P_WRK_LCDTRONL.V_LCTBS_FFTS(I).MESG_TYPE);
              END IF;
            END IF;

            DBG('Length(p_Wrk_Lcdtronl.v_Lctbs_Ffts(i).Fft_Ins_Descr) : ' ||
                LENGTH(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR));
            IF LENGTH(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR) > 210 THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-SWIFT01',
                           P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_CODE);
            END IF;

          ELSE

            IF NOT
                FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR,

                               L_FLD_TYPE,

                               L_TEMP) THEN
              DBG('Failed in swift validations');

              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-ADV-16',
                           P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                           .MESG_TYPE || ' FFT ' || P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                           .FFT_INS_CODE);

            END IF;

            DBG('Checking length of tag 79 for MT799 and MT707');
            IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).MESG_TYPE = 'LC_AMND_INSTR' THEN
              L_FFT_LENGTH := L_FFT_LENGTH +
                              LENGTH(P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                     .FFT_INS_DESCR);
              IF L_FFT_LENGTH > 1750 THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-SWIFT01',
                             'NARRATIVE');
              END IF;

              DBG('LC_AMND_INSTR - Tag79: ' || L_FFT_LENGTH);
            END IF;
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).MESG_TYPE = 'ADV_THIRD_BANK' THEN
            IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
             .FFT_INS_CODE LIKE 'INSTRUCTION%' AND P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
               .FFT_INS_DESCR IS NOT NULL THEN
              IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_DESCR,
                                              12,
                                              65,
                                              'FFT ins Description',
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
                DBG('Failed in Fn_Swift_Dtag_Validation FFT ins Description');

              END IF;

            END IF;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).MESG_TYPE = 'LC_INSTRUMENT' THEN
            IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
             .FFT_INS_CODE LIKE 'INSTRUCTION%' AND P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
               .FFT_INS_DESCR IS NOT NULL THEN
              DBG('validation in MT700-78 FFT condition');
              IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_DESCR,
                                              12,
                                              65,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_CODE ||
                                               '- FFT ins Description',
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
                DBG('Failed in Fn_Swift_Dtag_Validation MT700-78 FFT ins Description');
              END IF;

            ELSIF REGEXP_LIKE(P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_CODE,
                              '^SND2RECMT\d{3}$') AND P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                 .FFT_INS_DESCR IS NOT NULL THEN
              DBG('validation in MT700-72 FFT condition');
              IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_DESCR,
                                              6,
                                              35,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_CODE ||
                                               '- FFT ins Description',
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
                DBG('Failed in Fn_Swift_Dtag_Validation MT700-72 FFT ins Description');
              END IF;

            ELSIF P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
             .FFT_INS_CODE LIKE '71DCHARGES%' AND P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                  .FFT_INS_DESCR IS NOT NULL THEN
              DBG('validation in MT700-71D FFT condition');
              IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_DESCR,
                                              6,
                                              35,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_CODE ||
                                               '- FFT ins Description',
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
                DBG('Failed in Fn_Swift_Dtag_Validation MT700-72 FFT ins Description');
              END IF;

            ELSE
              IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR IS NOT NULL THEN
                DBG('validation in MT700-47A FFT condition');
                IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                                .FFT_INS_DESCR,
                                                100,
                                                65,
                                                P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                                .FFT_INS_CODE ||
                                                 '- FFT ins Description',
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
                  DBG('Failed in Fn_Swift_Dtag_Validation MT700-47A FFT ins Description');
                END IF;

              END IF;

            END IF;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
           .MESG_TYPE = 'LC_ACK_ADVICE' AND
                 NVL(LCPKS_ADVICES.G_SWIFT2018_ENABLED, 'N') = 'Y' THEN
            IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_CODE = '79NARRATIVE' THEN
              IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR IS NOT NULL THEN
                DBG('validation in LC_ACK_ADVICE');
                IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                                .FFT_INS_DESCR,
                                                35,
                                                50,
                                                P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                                .FFT_INS_CODE ||
                                                 '- FFT ins Description',
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
                  DBG('Failed in Fn_Swift_Dtag_Validation MT700-47A FFT ins Description');
                END IF;
              END IF;
            END IF;

          ELSE

            DBG('#p_Wrk_Lcdtronl.v_Lctbs_Ffts(i).Mesg_Type  ' || P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                .MESG_TYPE);
            DBG('#p_Wrk_Lcdtronl.v_Lctbs_Ffts(i).Fft_Ins_Descr  ' || P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                .FFT_INS_DESCR);
            DBG('#p_Wrk_Lcdtronl.v_Lctbs_Ffts(i).Fft_Ins_Code  ' || P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                .FFT_INS_CODE);
            DBG('#p_Wrk_Lcdtronl.v_Lctbs_Ffts(i).Fft_Ins_Code  ' || P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                .FFT_INS_CODE);
            DBG('Included in the IF condition for message type like GUA_AMD_INSTR');

            IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
             .FFT_INS_DESCR IS NOT NULL AND P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
               .FFT_INS_CODE != 'SND2RECINFO' AND P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
               .FFT_INS_CODE NOT LIKE 'INSTRUCTION%' THEN
              DBG('#insdie if');
              IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_DESCR,
                                              150,
                                              65,
                                              P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                              .FFT_INS_CODE ||
                                               '- FFT ins Description',
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
                DBG('Failed in Fn_Swift_Dtag_Validation FFT ins Description2');
              END IF;
            ELSE
              DBG('#insdie else');

              IF P_WRK_LCDTRONL.V_LCTBS_FFTS(I).FFT_INS_DESCR IS NOT NULL THEN
                IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                                .FFT_INS_DESCR,
                                                6,
                                                35,

                                                P_WRK_LCDTRONL.V_LCTBS_FFTS(I)
                                                .FFT_INS_CODE ||
                                                 '- FFT ins Description',

                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
                  DBG('Failed in Fn_Swift_Dtag_Validation FFT ins Description2');
                END IF;

              END IF;
            END IF;
          END IF;
        END LOOP;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.LAST LOOP

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-36',
                         '@BLK_DRAFTS.DRAWEE');
          END IF;

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS1,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-003', NULL);
          END IF;

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS2,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-004', NULL);
          END IF;

          IF NOT FN_VALID_CHARS(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3,
                                'X',
                                L_TEMP) THEN
            DBG('Failed in swift validations111');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-005', NULL);
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).CREDIT_DAYS_FROM IS NOT NULL THEN
            IF NOT FN_SWIFT_DTAG_VALIDATION(P_SOURCE,
                                            P_FUNCTION_ID,
                                            P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                                            .CREDIT_DAYS_FROM,
                                            3,
                                            35,
                                            'Credit Days From',
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
              DBG('Failed in Fn_Swift_Dtag_Validation Credit Days From');
            END IF;

          END IF;

        END LOOP;

      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Swift_Validations ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_SWIFT_VALIDATIONS;

  FUNCTION FN_SWIFT_CHECK(P_SOURCE              IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                          P_SOURCE_OPERATION    IN VARCHAR2,
                          P_FUNCTION_ID         IN VARCHAR2,
                          P_ACTION_CODE         IN VARCHAR2,
                          P_CONTRACT_REF_NO     IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                          P_LATEST_EVENT_SEQ_NO IN CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE,
                          P_EVENT_SEQ_NO        IN LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE,
                          P_ERR_CODE            IN OUT VARCHAR2,
                          P_ERR_PARAMS          IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    IF NOT LCPKSS_ADVICE_CHECK.FN_SWIFT_CHECKS(P_CONTRACT_REF_NO,
                                               P_LATEST_EVENT_SEQ_NO,
                                               P_EVENT_SEQ_NO,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN

      DBG('Failed in lcpkss_advice_check');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Swift_Check ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_SWIFT_CHECK;

  FUNCTION FN_SWIFT_DTAG_VALIDATION(P_SOURCE              IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                    P_FUNCTION_ID         IN VARCHAR2,
                                    P_SWIFT_TAG           IN VARCHAR2,
                                    P_NO_OF_LINES         IN NUMBER,
                                    P_NO_OF_CHAR_PER_LINE IN NUMBER,
                                    P_FILED_NAME          IN VARCHAR2,
                                    P_ERR_CODE            IN OUT VARCHAR2,
                                    P_ERR_PARAMS          IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNTER     NUMBER := 1;
    L_LINE_STRING VARCHAR2(4000);

  BEGIN
    DBG('Inside fn_swift_Dtag_validation');

    WHILE NVL(CSPKES_MISC.FN_GETPARAM(P_SWIFT_TAG, L_COUNTER, CHR(10)),
              '??') <> 'EOPL' LOOP
      L_LINE_STRING := CSPKES_MISC.FN_GETPARAM(P_SWIFT_TAG,
                                               L_COUNTER,
                                               CHR(10));

      IF NVL(LENGTH(L_LINE_STRING), 0) > NVL(P_NO_OF_CHAR_PER_LINE, 0) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-021', P_FILED_NAME);

      END IF;

      L_COUNTER := L_COUNTER + 1;

    END LOOP;

    IF L_COUNTER > NVL(P_NO_OF_LINES, 0) + 1 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-021', P_FILED_NAME);

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Swift_Dtag_Validation ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_SWIFT_DTAG_VALIDATION;

  FUNCTION FN_DEFAULT_MASTER(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_SOURCE_OPERATION   IN VARCHAR2,
                             P_FUNCTION_ID        IN VARCHAR2,
                             P_ACTION_CODE        IN VARCHAR2,
                             P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                             P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_ERR_CODE           IN OUT VARCHAR2,
                             P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT        NUMBER;
    L_WHNO         NUMBER;
    L_UNIT         CHAR(1);
    I              NUMBER;
    L_EXPIRY_DATE  DATE;
    L_REF_NO       CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE;
    L_USER_REF_NO  CSTBS_CONTRACT.USER_REF_NO%TYPE;
    L_EVENT_SEQ_NO CSTB_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE;
    L_VERSION_NO   CSTB_CONTRACT.LATEST_VERSION_NO%TYPE;
    L_MODULE       SMTB_MENU.MODULE%TYPE;
    L_CONTRACT_AMT LCTBS_CONTRACT_MASTER.CONTRACT_AMT%TYPE;

    L_ADDRESS3 STTMS_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS4 STTMS_CUSTOMER.ADDRESS_LINE4%TYPE;

    L_REG_TYPE         LCTBS_REG_MASTER.REG_TYPE%TYPE;
    L_LCTBS_REG_MASTER LCTBS_REG_MASTER%ROWTYPE;
    CURSOR C_PARTIES(C_ACKREFNO LCTBS_REG_MASTER.ACKREFNO%TYPE) IS
      SELECT * FROM LCTBS_REG_PARTIES WHERE ACKREFNO = C_ACKREFNO;
    J NUMBER := 1;

  BEGIN
    DBG('In Default master ' || P_ACTION_CODE);

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CUSTOM THEN
      DEBUG.PR_DEBUG('LC',
                     'Calling  Lcpks_Lcdtronl_Utils_custom.Fn_Pre_Default_Master..');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CUSTOM.FN_PRE_DEFAULT_MASTER(P_SOURCE,
                                                            P_SOURCE_OPERATION,
                                                            P_FUNCTION_ID,
                                                            P_ACTION_CODE,
                                                            P_PRODUCT_DEFINITION,
                                                            P_LCDTRONL,
                                                            P_PREV_LCDTRONL,
                                                            P_WRK_LCDTRONL,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in  Lcpks_Lcdtronl_Utils_custom.Fn_Pre_Default_Master..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CLUSTER THEN
      DEBUG.PR_DEBUG('LC',
                     'Calling  Lcpks_Lcdtronl_Utils_Cluster.Fn_Pre_Default_Master..');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CLUSTER.FN_PRE_DEFAULT_MASTER(P_SOURCE,
                                                             P_SOURCE_OPERATION,
                                                             P_FUNCTION_ID,
                                                             P_ACTION_CODE,
                                                             P_PRODUCT_DEFINITION,
                                                             P_LCDTRONL,
                                                             P_PREV_LCDTRONL,
                                                             P_WRK_LCDTRONL,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in  Lcpks_Lcdtronl_Utils_Cluster.Fn_Pre_Default_Master..');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_KERNEL THEN

      DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
      BEGIN
        SELECT MODULE
          INTO L_MODULE
          FROM SMTB_MENU
         WHERE FUNCTION_ID = P_FUNCTION_ID;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('In when others while getting module..');
          RETURN FALSE;

      END;

      IF P_ACTION_CODE IN
         ('PRDDFLT', CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_HOLD) THEN

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO IS NULL THEN
          DBG('Calling Lcpks_Fcj_Lcdtronl_Utils.Fn_Generate_Ref_No..');
          IF NOT FN_GENERATE_REF_NO(P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                    L_REF_NO,
                                    L_USER_REF_NO,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN

            DBG('Failed in Lcpks_Fcj_Lcdtronl_Utils.Fn_Generate_Ref_No..');
            RETURN FALSE;
          END IF;

          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO := L_REF_NO;
        END IF;

        DBG('p_Wrk_Lcdtronl.v_Cstbs_Contract.User_Ref_No  -->' ||
            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO);
        DBG('p_Source  -->' || P_SOURCE);
        IF P_SOURCE <> 'FLEXCUBE' THEN

          IF L_MODULE = 'LC' THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD := 'Y';
          END IF;

          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_LC_REF_NO;
        END IF;

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO IS NULL THEN
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO := NVL(L_USER_REF_NO,
                                                             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
        END IF;

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO IS NULL THEN
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        END IF;

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.SOURCE IS NULL THEN
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.SOURCE := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.SOURCE;
        END IF;

        L_EVENT_SEQ_NO                                      := 1;
        L_VERSION_NO                                        := 1;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO     := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.BOOK_DATE           := GLOBAL.APPLICATION_DATE;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO := L_VERSION_NO;
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO   := L_EVENT_SEQ_NO;
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.SERIAL_NO           := 1;
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.BRANCH              := GLOBAL.CURRENT_BRANCH;
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS     := 'A';

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_HOLD AND P_SOURCE = 'FCAT' THEN

          P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT;
          P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.OS_LIABILITY         := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT;
        END IF;

        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTH_STATUS := 'U';

        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.TEMPLATE_STATUS := 'N';
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.MODULE_CODE     := L_MODULE;
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.COUNTERPARTY    := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID;

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_DEFINED_STATUS IS NULL THEN
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_DEFINED_STATUS := 'NORM';
        END IF;

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_HOLD THEN
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS          := 'H';
          P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.CONTRACT_STATUS := 'H';
        END IF;

        DBG('Defaulting Contract master..');
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO      := L_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO    := L_EVENT_SEQ_NO;

        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO,
                                                                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO);

        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.DEAL_SOURCE := 'N';

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_LC_REF_NO IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_LC_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO;
        END IF;

        IF NOT
            FN_NETWORK_VALIDATIONS(NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_LC_REF_NO,
                                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO)) THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LC-REFNO01',
                       'Customer Reference Number');
          RETURN FALSE;
        END IF;

        IF P_ACTION_CODE = 'PRDDFLT' AND
           P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO IS NOT NULL THEN

          BEGIN
            SELECT REG_TYPE
              INTO L_REG_TYPE
              FROM LCTBS_REG_MASTER
             WHERE ACKREFNO = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in selecting registeration details');
          END;

          IF L_REG_TYPE IN ('LC', 'SG', 'BG') THEN

            DBG('In Fn_Default of registeration details...');
            BEGIN
              SELECT *
                INTO L_LCTBS_REG_MASTER
                FROM LCTBS_REG_MASTER
               WHERE ACKREFNO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in selecting registeration details');
            END;

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY       := L_LCTBS_REG_MASTER.CONTRACT_CCY;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT       := L_LCTBS_REG_MASTER.CONTRACT_AMT;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID             := L_LCTBS_REG_MASTER.CIF_ID;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_NAME          := L_LCTBS_REG_MASTER.CUST_NAME;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE := L_LCTBS_REG_MASTER.POSITIVE_TOLERANCE;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE := L_LCTBS_REG_MASTER.NEGATIVE_TOLERANCE;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT   := L_LCTBS_REG_MASTER.MAX_CONTRACT_AMT;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO        := L_LCTBS_REG_MASTER.CUST_REF_NO;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE      := L_LCTBS_REG_MASTER.CUST_REF_DATE;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE          := L_LCTBS_REG_MASTER.PARTY_TYPE;

            DBG('selecting the party details for the ack ref no ' ||
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO);
            FOR I IN C_PARTIES(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO) LOOP
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).PARTY_TYPE := I.PARTY_TYPE;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).CIF_ID := I.PARTY_ID;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).CUST_NAME := I.PARTY_NAME;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).CUST_REF_NO := I.PARTY_REFNO;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).COUNTRY_CODE := I.PARTY_COUNTRY_CODE;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).LANG_CODE := I.PARTY_LANGUAGE;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).CUST_ADDRESS_LIN1 := I.PARTY_ADDR1;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).CUST_ADDRESS_LIN2 := I.PARTY_ADDR2;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).CUST_ADDRESS_LIN3 := I.PARTY_ADDR3;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).CUST_ADDRESS_LIN4 := I.PARTY_ADDR4;
              J := J + 1;
            END LOOP;
          END IF;
        END IF;

        IF P_ACTION_CODE <> 'PRDDFLT' THEN

          DBG('in fn default p_wrk_lcdtronl.v_lctbs_contract_master.issue_date ------>>> ' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE);
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE IS NULL AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN
            P_ERR_CODE   := 'LCUPLD-362';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE := GLOBAL.APPLICATION_DATE;
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE IS NULL AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN
            P_ERR_CODE   := 'LCUPLD-363';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE;
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE IS NULL AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD' THEN
            P_ERR_CODE   := 'LCUPLD-364';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE := GLOBAL.APPLICATION_DATE;
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NULL AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN

            DBG('Expiry is Null..');
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR IS NOT NULL THEN
              L_UNIT := UPPER(SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                                     -1,
                                     1));

              BEGIN
                L_WHNO := SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                                 1,
                                 LENGTH(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR) - 1);
              EXCEPTION
                WHEN OTHERS THEN
                  P_ERR_CODE   := 'LC-VALS-201';
                  P_ERR_PARAMS := NULL;
                  RETURN FALSE;

              END;

              DBG('l_Unit' || L_UNIT);
              DBG('l_Whno' || L_WHNO);

              IF L_UNIT NOT IN ('D', 'M', 'Y') THEN

                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR ||
                                                                L_UNIT;
              END IF;

              DBG(' p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Tenor ' ||
                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR);

              IF L_UNIT = 'M' THEN
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := ADD_MONTHS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
                                                                                 L_WHNO);
              ELSIF L_UNIT = 'Y' THEN
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := ADD_MONTHS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
                                                                                 L_WHNO * 12);

              ELSIF L_UNIT = 'D' THEN

                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE +
                                                                      L_WHNO;

              END IF;

            ELSE

              IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR IS NULL AND
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
                 'PAD'

               THEN
                IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR IS NULL THEN
                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE +
                                                                        NVL(P_PRODUCT_DEFINITION.STANDARD_TENOR,
                                                                            1);

                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR := NVL(P_PRODUCT_DEFINITION.STANDARD_TENOR,
                                                                      1) || 'D';

                ELSE
                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE +
                                                                        REPLACE(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                                                                                'D',
                                                                                '');

                END IF;

              END IF;

            END IF;

            IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
               (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
               NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
              IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE IS NULL AND
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
                 'PAD' THEN
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE +
                                                                            NVL(P_PRODUCT_DEFINITION.CLAIM_DAYS,
                                                                                0);
              END IF;
            END IF;

          ELSE
            DBG('Expiry is not Null..');

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
               'PAD' THEN

              IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
                 (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
                 NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
                IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE IS NULL AND
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
                   'PAD' THEN
                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE +
                                                                              NVL(P_PRODUCT_DEFINITION.CLAIM_DAYS,
                                                                                  0);
                END IF;
              END IF;

              DBG('p_product_definition.closure_day iss : ' ||
                  P_PRODUCT_DEFINITION.CLOSURE_DAYS);

              IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NULL

                 OR (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE <>
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE)

               THEN

                IF P_PRODUCT_DEFINITION.CLOSURE_DAYS IS NOT NULL THEN

                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE) +

                                                                         P_PRODUCT_DEFINITION.CLOSURE_DAYS;
                  DBG('After changing the tenor the closure date iss : ' ||
                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE);
                ELSE
                  DBG('its cmg here');

                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE) + 30;

                  DBG('Now the closure date iss : ' ||
                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE);

                END IF;

              END IF;

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE;
              DBG('After changing tenor the Stop Date iss : ' ||
                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE);

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR := (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE) || 'D';
            END IF;

          END IF;

          DBG('Claim Date' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_DATE);
          DBG('Claim Expiry Date' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE);
          DBG('Expiry Date' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
          DBG('Stop Date' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE);

        END IF;

        DBG('Setting user defined status as NORMAL');
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS     := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS,
                                                                              'NORM');
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_DEFINED_STATUS            := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS,
                                                                              'NORM');
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_DERIVED_STATUS := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_DERIVED_STATUS,
                                                                              'NORM');

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' AND
           P_ACTION_CODE <> 'PRDDFLT' THEN

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE;
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NULL THEN
            IF P_PRODUCT_DEFINITION.CLOSURE_DAYS IS NOT NULL THEN

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE) +

                                                                     P_PRODUCT_DEFINITION.CLOSURE_DAYS;
            ELSE
              DBG('its cmg here');

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := TO_DATE(NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE)) + 30;

            END IF;

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NULL THEN
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE IS NULL THEN
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE := 'M';
            END IF;

          END IF;

        END IF;
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN = 'T' THEN

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS = 'M' THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE := ADD_MONTHS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                                                                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY);
          ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS = 'D' THEN

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE +
                                                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY;

          END IF;

        ELSE
          DEBUG.PR_DEBUG('LC',
                         'VALUE' ||
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE);
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE := NULL;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ALLOW_PREPAY IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ALLOW_PREPAY := NVL(P_PRODUCT_DEFINITION.ALLOW_PREPAY,
                                                                     'N');
        END IF;

        DBG('Before check partial confirmation allow  :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW);
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW := NVL(P_PRODUCT_DEFINITION.PARTIAL_CONFIRMATION_ALLOW,
                                                                                   'N');
        END IF;

        DBG(' After check partial confirmation allow  :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW);

        DBG('p_Product_Definition.Revolving=====>' ||
            P_PRODUCT_DEFINITION.REVOLVING);

        IF NVL(P_PRODUCT_DEFINITION.REVOLVING, 'N') = 'Y' THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE,
                                                                     'N');
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE,
                                                                             'M');
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN,
                                                                      'T');
          END IF;

        ELSIF NVL(P_PRODUCT_DEFINITION.REVOLVING, 'N') = 'N' THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE = 'N' THEN

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE := NULL;
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE = 'M' THEN

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE := NULL;
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE IS NULL THEN
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := P_PRODUCT_DEFINITION.PRODUCT_TYPE;
        END IF;

        IF P_ACTION_CODE = 'PRDDFLT' THEN

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE := P_PRODUCT_DEFINITION.TOLERANCE_POSITIVE;
          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE := P_PRODUCT_DEFINITION.TOLERANCE_NEGATIVE;
          END IF;

        END IF;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT * (1 +
                                                                   NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                                                                                                                              0) / 100);

        DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Max_Contract_Amt::' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT IS NOT NULL THEN

          IF NOT
              CYPKSS.FN_AMT_ROUND(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT) THEN
            DBG('Failed in Cypkss.Fn_Amt_Round');
            P_ERR_CODE   := 'LC-VALS-006';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;
        END IF;
        DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Max_Contract_Amt::' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE := P_PRODUCT_DEFINITION.APPLICABLE_RULE;
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHG_CLM_SWIFT IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHG_CLM_SWIFT := NVL(P_PRODUCT_DEFINITION.CHG_CLM_SWIFT,
                                                                      'N');
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RULE_NARRATIVE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RULE_NARRATIVE := P_PRODUCT_DEFINITION.RULE_NARRATIVE;
        END IF;

        IF P_PRODUCT_DEFINITION.PRODUCT_TYPE NOT IN ('H', 'G') THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM := P_PRODUCT_DEFINITION.INCO_TERM;
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.URR_PREFERENCE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.URR_PREFERENCE := P_PRODUCT_DEFINITION.URR_PREFERENCE;
        END IF;

        DBG('CHECKING THE STATUS CONTROL FLAG :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STATUS_CONTROL_FLAG);
        DBG('CHECKING THE STATUS CONTROL FLAG :' ||
            P_PRODUCT_DEFINITION.STATUS_CONTROL_FLAG);
        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STATUS_CONTROL_FLAG,
               'M') = 'M' THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STATUS_CONTROL_FLAG := NVL(P_PRODUCT_DEFINITION.STATUS_CONTROL_FLAG,
                                                                            'M');
          DBG('CHECKING THE STATUS CONTROL FLAG :' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STATUS_CONTROL_FLAG);
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE := GLOBAL.LANG;
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE := 'M';
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE := 'N';
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY := GLOBAL.LCY;
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_TYPE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_TYPE := 'S';
        END IF;

        IF (P_PRODUCT_DEFINITION.PRODUCT_TYPE NOT IN ('G', 'H')) AND
           (NOT (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
            NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y')) THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD := 'P';
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE := 'M';
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO := 0;
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCLUDE_TO_DATE IS NULL THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCLUDE_TO_DATE := NVL(P_PRODUCT_DEFINITION.INCLUDE_TO_DATE,
                                                                        'Y');
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_NAME IS NULL THEN
          BEGIN
            SELECT CUSTOMER_NAME1
              INTO P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_NAME
              FROM STTMS_CUSTOMER
             WHERE CUSTOMER_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Failed in  Selecting the Customer Name ');

          END;

        END IF;

        DBG('Cust Type Before Default' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE);
        DBG('Prd Type Default' || P_PRODUCT_DEFINITION.PRODUCT_TYPE);

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE IS NULL THEN
          IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE := 'BEN';

          ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'G', 'H', 'C') THEN

            IF P_PRODUCT_DEFINITION.REIMBURSEMENT = 'Y' THEN

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE := 'ISB';
            ELSE

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE := 'APP';

            END IF;

          ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'S' THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE := 'APP';

          END IF;

        END IF;

        IF P_PRODUCT_DEFINITION.ADVANCE_BY_LOAN = 'C' THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.COLLAT_LOAN_ALLOWED := 'N';
        ELSE

          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.COLLAT_LOAN_ALLOWED := NVL(P_PRODUCT_DEFINITION.ADVANCE_BY_LOAN,
                                                                            'N');
        END IF;
        DBG(' collat_loan_allowed>> ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.COLLAT_LOAN_ALLOWED);
        DBG('Cust Type After Default' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE);

        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO    := 0;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCLUDE_TO_DATE := NVL(P_PRODUCT_DEFINITION.INCLUDE_TO_DATE,
                                                                      'Y');
        IF P_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('E', 'I') THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT := 'N';
          END IF;

        END IF;

        IF P_ACTION_CODE = 'PRDDFLT' THEN

          IF L_MODULE = 'LC' THEN
            DBG('Before Beneficiary_Conf_Reqd is from Product default1-->' ||
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD);
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD := 'Y';
            DBG('After Beneficiary_Conf_Reqd is set1-->' ||
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD);
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
          FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT LOOP

            P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
            P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).EVENT_SEQ_NO := 1;
            P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).VERSION_NO := 1;
            P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).EVENT_CODE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE;

            IF ((P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS1 IS NULL) AND
               (P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS2 IS NULL) AND
               (P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3 IS NULL)) THEN

              SELECT COUNT(*)
                INTO L_COUNT
                FROM ISTMS_BIC_DIRECTORY
               WHERE BANK_NAME = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A';

              IF L_COUNT > 0 THEN

                SELECT BANK_NAME,
                       BANK_ADDRESS1,
                       BANK_ADDRESS2,
                       BANK_ADDRESS3
                  INTO P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE,
                       P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS1,
                       P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS2,
                       P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3

                  FROM ISTMS_BIC_DIRECTORY
                 WHERE BIC_CODE = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE
                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A';

              ELSE
                BEGIN
                  SELECT CUSTOMER_NAME1,
                         ADDRESS_LINE1,
                         ADDRESS_LINE2,

                         ADDRESS_LINE3,
                         ADDRESS_LINE4

                    INTO P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE,
                         P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS1,
                         P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS2,

                         L_ADDRESS3,
                         L_ADDRESS4

                    FROM STTMS_CUSTOMER
                   WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                        .DRAWEE
                     AND RECORD_STAT = 'O'
                     AND AUTH_STAT = 'A';

                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DBG('Invalid customer');

                END;

                IF L_ADDRESS4 IS NOT NULL THEN
                  IF LENGTH(L_ADDRESS3 || ' ' || L_ADDRESS4) <= 35 THEN
                    P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3 := L_ADDRESS3 || ' ' ||
                                                                 L_ADDRESS4;
                  ELSE
                    P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3 := L_ADDRESS3;
                  END IF;
                ELSE
                  P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3 := L_ADDRESS3;
                END IF;

              END IF;

            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
             .INSURANCE_COMP_CODE IS NOT NULL THEN

              IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_CO IS NULL THEN
                BEGIN
                  SELECT INSURANCE_COMP_NAME
                    INTO P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_CO
                    FROM BCTMS_INSURANCE_COMP
                   WHERE INSURANCE_COMP_CODE = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                        .INSURANCE_COMP_CODE;

                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('Failed in Selecting the Insurance Company Name..');
                    P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_CO := 'XXXXXXXXX';

                END;

              END IF;

            END IF;

          END LOOP;

        END IF;

        IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' THEN
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OS_LC_AMOUNT := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                                     0);

        ELSE
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OS_LC_AMOUNT := NULL;

        END IF;

        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_HOLD) THEN

          IF NOT FN_CALCULATE_AMTS(P_SOURCE,
                                   P_FUNCTION_ID,
                                   P_ACTION_CODE,
                                   P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER,
                                   P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS,
                                   P_PRODUCT_DEFINITION,
                                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER,
                                   P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
            DBG('Failed in Fn_Calculate_Amts');
            RETURN FALSE;
          END IF;

        END IF;

        IF NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'Y' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
           ('RMB') THEN
          DBG('Invalid combination of product code and operation code');
          OVPKS.PR_APPENDTBL('LCUPLD-088', NULL);
        END IF;

        DBG('p_wrk_lcdtronl.v_lctbs_contract_master.Tolerance_Text ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT);
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT IN
           ('A', 'X') THEN
          DBG('p_wrk_lcdtronl.v_lctbs_contract_master.Positive_Tolerance ' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE);
          DBG('p_wrk_lcdtronl.v_lctbs_contract_master.Negative_Tolerance ' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE);
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                 0) > 10 OR NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                                0) > 10 THEN
            DBG('Positive/negative Tolerance is greater than 10 when Tolerance text is About/ Approximately');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-340', NULL);
          END IF;

        END IF;

        DBG('Opr:: ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
        DBG('PCA:: ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW);
        IF P_ACTION_CODE = 'NEW' THEN
          IF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
             ('CNF', 'ANC'))

             AND NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
                     'N') = 'Y' THEN
            IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT,
                   0) = 0 AND
               NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT, 0) = 0 THEN
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-330', '');
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT    := 100;
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT     := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;
              P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNCONFIRM_AMOUNT     := 0;
              P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_UNCONFIRMED_AMT := 0;

            END IF;

          ELSIF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
                ('CNF', 'ANC'))

                AND NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
                        'N') = 'N' THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT    := 100;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT     := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNCONFIRM_AMOUNT     := 0;
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_UNCONFIRMED_AMT := 0;

          END IF;

          IF NVL(P_PRODUCT_DEFINITION.REIMBURSEMENT, 'N') = 'Y' AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT IS NULL THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-333', '');
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT         := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AVAILED_UNDERTAKING_AMOUNT := 0;
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_UNDERTAKING_AMOUNT    := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                                                                                     0);
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILED_NOTUNDERTAKING_AMOUNT   := 0;
          END IF;

        END IF;

        DBG('confirm amt :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT);
        DBG('confirm percent :' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT);

      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

        DBG('Came into Modify action');

        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE IS NULL AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN
          P_ERR_CODE   := 'LCUPLD-362';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE := GLOBAL.APPLICATION_DATE;
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE IS NULL AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN
          P_ERR_CODE   := 'LCUPLD-363';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE;
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NULL AND
           P_SOURCE_OPERATION <> 'LCDTRONL_FIN_MODIFY'

         THEN

          DBG('Expiry is Null..');

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR IS NOT NULL AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE IS NOT NULL THEN

            L_UNIT := UPPER(SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                                   -1,
                                   1));

            BEGIN
              L_WHNO := SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                               1,
                               LENGTH(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR) - 1);
            EXCEPTION
              WHEN OTHERS THEN
                P_ERR_CODE   := 'LC-VALS-201';
                P_ERR_PARAMS := NULL;
                RETURN FALSE;

            END;

            DBG('l_Unit' || L_UNIT);
            DBG('l_Whno' || L_WHNO);

            IF L_UNIT NOT IN ('D', 'M', 'Y') THEN

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR ||
                                                              L_UNIT;
            END IF;

            DBG(' p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Tenor ' ||
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR);

            IF L_UNIT = 'M' THEN
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := ADD_MONTHS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
                                                                               L_WHNO);
            ELSIF L_UNIT = 'Y' THEN
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := ADD_MONTHS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
                                                                               L_WHNO * 12);

            ELSIF L_UNIT = 'D' THEN

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE +
                                                                    L_WHNO;

            END IF;

            IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
               (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
               NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
              IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE IS NULL AND
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
                 'PAD' THEN
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE +
                                                                            NVL(P_PRODUCT_DEFINITION.CLAIM_DAYS,
                                                                                0);
              END IF;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NULL THEN
              DBG('Expiry Date-->' ||
                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE;
              DBG('Stop Date-->' ||
                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE);
              DBG('Closure Days-->' || P_PRODUCT_DEFINITION.CLOSURE_DAYS);
              IF P_PRODUCT_DEFINITION.CLOSURE_DAYS IS NOT NULL THEN

                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE) +
                                                                       P_PRODUCT_DEFINITION.CLOSURE_DAYS;
              ELSE
                DBG('its cmg here');

                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := TO_DATE(NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE)) + 30;

              END IF;

            END IF;
            DBG('Closure Date-->' ||
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE);

          ELSE

            IF P_PRODUCT_DEFINITION.STANDARD_TENOR <> 0 AND
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE IS NOT NULL THEN

              IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR IS NULL THEN

                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE +
                                                                      NVL(P_PRODUCT_DEFINITION.STANDARD_TENOR,
                                                                          1);
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR       := P_PRODUCT_DEFINITION.STANDARD_TENOR || 'D';
              ELSE
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE +
                                                                      REPLACE(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                                                                              'D',
                                                                              '');

              END IF;

            END IF;

          END IF;

          IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
             (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
             NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE IS NULL AND
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
               'PAD' THEN
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE +
                                                                          NVL(P_PRODUCT_DEFINITION.CLAIM_DAYS,
                                                                              0);
            END IF;
          END IF;

        ELSE
          DBG('Expiry is not Null..');

          IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' OR
             (P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
             NVL(P_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE IS NULL AND
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
               'PAD' THEN
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE +
                                                                          NVL(P_PRODUCT_DEFINITION.CLAIM_DAYS,
                                                                              0);
            END IF;
          END IF;

          DBG('Expiry Date-->' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
          DBG('before assigning Stop Date-->' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE);
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE;
          DBG('Stop Date-->' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE);
          DBG('Closure Days-->' || P_PRODUCT_DEFINITION.CLOSURE_DAYS);
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NULL THEN
            IF P_PRODUCT_DEFINITION.CLOSURE_DAYS IS NOT NULL THEN

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE) +

                                                                     P_PRODUCT_DEFINITION.CLOSURE_DAYS;
            ELSE
              DBG('its cmg here');

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := TO_DATE(NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE)) + 30;

            END IF;

          END IF;

          DBG('Closure Date-->' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE);

          DBG('Expiry is Given and Deriving Tenor ..');
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <> 'PAD' THEN

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR := (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                                                            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE) || 'D';
          END IF;

        END IF;

        IF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
           ('CNF', 'ANC'))

         THEN
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
                 'N') = 'Y' THEN
            IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT,
                   0) = 0 AND
               NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT, 0) = 0 THEN

              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT    := 100;
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT     := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;
              P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;
            END IF;

          ELSE
            DBG('Prev Opr:: ' ||
                P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT := 100;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT  := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY;

            DBG('In modify current availablity::' ||
                P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY);
            DBG('In modify previous current availablity::' ||
                P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY);
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT := NVL(P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT,
                                                                             0) +
                                                                         (P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY -
                                                                          P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY);

          END IF;

        END IF;

        DBG('In modify available_confirmed_amt::' ||
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT);

        DBG('Defaulting for Fn_calc_Amts..' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        IF NOT FN_CALCULATE_AMTS(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ACTION_CODE,
                                 P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER,
                                 P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS,
                                 P_PRODUCT_DEFINITION,
                                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER,
                                 P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
          DBG('Failed in Fn_Calculate_Amts');
          RETURN FALSE;
        END IF;

      ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
        DBG('Closure days at product level is : ' ||
            P_PRODUCT_DEFINITION.CLOSURE_DAYS);
        DBG('Expiry date is : ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        DBG('Prev Version no is : ' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
        DBG('Curr Version no is : ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
        DBG('Prev Event Seq no is : ' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        DBG('Curr Event Seq no is : ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);

        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE,
                                                                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE) +

                                                               NVL(P_PRODUCT_DEFINITION.CLOSURE_DAYS,
                                                                   30);
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE    := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE;
        DBG('Now the closure date iss : ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE);
        DBG('Stop date iss : ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE);

        DBG('Defaulting for Fn_calc_Amts..' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        DBG('curr contract amount ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);

        BEGIN
          SELECT CONTRACT_AMT
            INTO L_CONTRACT_AMT
            FROM LCTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_CONTRACT_MASTER
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                     AND EVENT_SEQ_NO <
                         (SELECT MAX(EVENT_SEQ_NO)
                            FROM LCTBS_CONTRACT_MASTER
                           WHERE CONTRACT_REF_NO =
                                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO));

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('When No data found of MASTER');

        END;

        DBG('l_contract_amt' || L_CONTRACT_AMT);

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT <
           L_CONTRACT_AMT THEN
          DBG('Contract amount cannot be reduced');
          P_ERR_CODE   := 'LC-VALS-385';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

        IF NOT FN_CALCULATE_AMTS(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ACTION_CODE,
                                 P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER,
                                 P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS,
                                 P_PRODUCT_DEFINITION,
                                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER,
                                 P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
          DBG('Failed in Fn_Calculate_Amts');
          RETURN FALSE;
        END IF;

        DBG('latest_version_no2 ' ||
            P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
        DBG('latest_event_seq_no 2' ||
            P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        DBG('latest_version_no2 ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
        DBG('latest_event_seq_no2 ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        DBG('Event code2 ' ||
            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE);
        DBG(' con amt2 ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        DBG('Max con amt2 ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);
        DBG('Max liab amt2 ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT);

      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
        BEGIN
          SELECT CHAR_FIELD92
            INTO P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92
            FROM CSTBS_UI_COLUMNS
           WHERE CHAR_FIELD2 =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

        EXCEPTION
          WHEN OTHERS THEN
            P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 := 'Y';

        END;

        IF P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 = 'Y' THEN
          DBG('Setting g_incr_amnd_no to TRUE for REOPEN event');
          G_INCR_AMND_NO := TRUE;
        ELSE
          DBG('Setting g_incr_amnd_no to FALSE for REOPEN event');
          G_INCR_AMND_NO := FALSE;

        END IF;

      END IF;

      DBG('Flag status:::' ||
          P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92);
      DBG('Prev amnd num:::' ||
          P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO);
      DBG('Current amnd num:::' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO);
      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        IF P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 = 'Y' OR
           P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO <>
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO THEN
          DBG('Setting g_incr_amnd_no to TRUE for AMND event');
          G_INCR_AMND_NO := TRUE;
        ELSE
          DBG('Setting g_incr_amnd_no to FALSE for REOPEN event');
          G_INCR_AMND_NO := FALSE;

        END IF;

      END IF;

    END IF;
    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CUSTOM THEN
      DEBUG.PR_DEBUG('LC',
                     'Calling  Lcpks_Lcdtronl_Utils_custom.Fn_Post_Default_Master..');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CUSTOM.FN_POST_DEFAULT_MASTER(P_SOURCE,
                                                             P_SOURCE_OPERATION,
                                                             P_FUNCTION_ID,
                                                             P_ACTION_CODE,
                                                             P_PRODUCT_DEFINITION,
                                                             P_LCDTRONL,
                                                             P_PREV_LCDTRONL,
                                                             P_WRK_LCDTRONL,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in  Lcpks_Lcdtronl_Utils_custom.Fn_Post_Default_Master..');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CLUSTER THEN
      DEBUG.PR_DEBUG('LC',
                     'Calling  Lcpks_Lcdtronl_Utils_Cluster.Fn_Post_Default_Master..');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CLUSTER.FN_POST_DEFAULT_MASTER(P_SOURCE,
                                                              P_SOURCE_OPERATION,
                                                              P_FUNCTION_ID,
                                                              P_ACTION_CODE,
                                                              P_PRODUCT_DEFINITION,
                                                              P_LCDTRONL,
                                                              P_PREV_LCDTRONL,
                                                              P_WRK_LCDTRONL,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('LC',
                       'Failed in  Lcpks_Lcdtronl_Utils_Cluster.Fn_Post_Default_Master..');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Retruning true from Fn_Default_Master');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_default_master');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.fn_default_master~' ||
                         SQLCODE);
      RETURN FALSE;

  END FN_DEFAULT_MASTER;

  FUNCTION FN_DEFAULT_PARTIES(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_SOURCE_OPERATION   IN VARCHAR2,
                              P_FUNCTION_ID        IN VARCHAR2,
                              P_ACTION_CODE        IN VARCHAR2,
                              P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                              P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_WRK_LCDTRONL       IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_ERR_CODE           IN OUT VARCHAR2,
                              P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_CUST_NAME     STTM_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_LANG_CODE     STTM_CUSTOMER.LANGUAGE%TYPE;
    L_CNTRY_CODE    STTM_CUSTOMER.COUNTRY%TYPE;
    L_CUST_TYPE     STTMS_CUSTOMER.CUSTOMER_TYPE%TYPE;
    L_ADDRESS_LINE1 STTMS_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDRESS_LINE2 STTMS_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDRESS_LINE3 STTMS_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS_LINE4 STTMS_CUSTOMER.ADDRESS_LINE4%TYPE;
    L_COUNT         NUMBER := 0;
    L_PARTY_FOUND   BOOLEAN := FALSE;
    L_CIF_ENTERED   BOOLEAN := FALSE;
    L_CIF_REC       NUMBER := 1;
    L_MAIN_CIF_ID   VARCHAR2(100);
    L_PRTY_CIF_ID   VARCHAR2(100);
    L_PATRY_TYPE    LCTBS_CONTRACT_MASTER.CUST_TYPE%TYPE;
    L_PARTY_NAME    LCTBS_CONTRACT_MASTER.CUST_NAME%TYPE;

  BEGIN

    DBG('Defaulting Parties....');

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CUSTOM THEN
      DBG('Calling lcpks_lcdtronl_utils_custom.Fn_Pre_Linkage_Parties');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CUSTOM.FN_PRE_DEFAULT_PARTIES(P_SOURCE,
                                                             P_SOURCE_OPERATION,
                                                             P_FUNCTION_ID,
                                                             P_ACTION_CODE,
                                                             P_PRODUCT_DEFINITION,
                                                             P_LCDTRONL,
                                                             P_WRK_LCDTRONL,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_CLUSTER THEN
      DBG('Calling lcpks_lcdtronl_utils_cluster.Fn_Pre_Linkage_Parties');
      IF NOT
          LCPKS_LCDTRONL_UTILS_CLUSTER.FN_PRE_DEFAULT_PARTIES(P_SOURCE,
                                                              P_SOURCE_OPERATION,
                                                              P_FUNCTION_ID,
                                                              P_ACTION_CODE,
                                                              P_PRODUCT_DEFINITION,
                                                              P_LCDTRONL,
                                                              P_WRK_LCDTRONL,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT LCPKS_LCDTRONL_UTILS.FN_SKIP_KERNEL THEN

      L_COUNT := P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT;
      DBG('l_Count' || L_COUNT ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
      L_MAIN_CIF_ID := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID;
      IF L_COUNT > 0 THEN

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE IS NOT NULL THEN
          DBG('Check If this Party is available in  Partile List..');
          FOR I IN 1 .. L_COUNT LOOP
            DBG('its cmg here');
            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .PARTY_TYPE =
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE THEN
              L_PARTY_FOUND := TRUE;
              L_CIF_REC     := I;
              L_PRTY_CIF_ID := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID;
              L_PARTY_NAME  := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_NAME;
              DBG('its cmg here2..');
              IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID IS NOT NULL THEN
                L_CIF_ENTERED := TRUE;
                DBG('its cmg here3');
              END IF;

              EXIT;
            END IF;

          END LOOP;

        END IF;

      END IF;

      DBG('l_Main_Cif_Id::' || L_MAIN_CIF_ID || ' l_Prty_Cif_Id::' ||
          L_PRTY_CIF_ID);
      IF NOT L_PARTY_FOUND THEN
        L_COUNT := L_COUNT + 1;
        DBG('first thing is ' || L_COUNT);
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT) . PARTY_TYPE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT) . CIF_ID := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID;
      ELSE
        IF L_MAIN_CIF_ID IS NOT NULL THEN
          IF L_PRTY_CIF_ID IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC) . CIF_ID := L_MAIN_CIF_ID;
          ELSE
            IF L_MAIN_CIF_ID <> L_PRTY_CIF_ID AND
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE <> 'E' THEN
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC) . CIF_ID := L_MAIN_CIF_ID;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).CUST_NAME := NULL;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).COUNTRY_CODE := NULL;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).LANG_CODE := NULL;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).CUST_ADDRESS_LIN1 := NULL;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).CUST_ADDRESS_LIN2 := NULL;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).CUST_ADDRESS_LIN3 := NULL;
              P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).CUST_ADDRESS_LIN4 := NULL;
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-VALS-115',
                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE);

            END IF;

          END IF;

          DBG('cust ref no## ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC)
              .CUST_REF_NO);
          DBG('cust ref date## ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC)
              .CUST_REF_DATE);

          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).CUST_REF_NO := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC)
                                                                       .CUST_REF_NO,
                                                                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO);
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).CUST_REF_DATE := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC)
                                                                         .CUST_REF_DATE,
                                                                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE);

        ELSE
          IF L_PRTY_CIF_ID IS NOT NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID := L_PRTY_CIF_ID;
          END IF;

        END IF;

      END IF;

      DBG('product type: ' || P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE);
      DBG('Party id = ' || P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID ||
          ' ~ ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC) .
          CIF_ID || ' ~ ' || L_PRTY_CIF_ID || ' ~ ' || L_MAIN_CIF_ID);

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'E' THEN
        IF L_MAIN_CIF_ID <> L_PRTY_CIF_ID AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE = 'BEN' THEN
          DBG('Party id are different for BEN....');
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID := L_PRTY_CIF_ID;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_CIF_REC).CIF_ID := L_PRTY_CIF_ID;
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_NAME := L_PARTY_NAME;

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-118', NULL);

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'I' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_NAME <> L_PARTY_NAME AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE = 'APP' THEN
          DBG('Party name are different for APP....');
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_NAME := L_PARTY_NAME;
        END IF;
      END IF;

      DBG('l_Count' || L_COUNT);
      IF L_COUNT > 0 THEN
        FOR I IN 1 .. L_COUNT LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_NAME IS NULL OR P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .COUNTRY_CODE IS NULL OR P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
             .LANG_CODE IS NULL THEN
            DBG('p_Wrk_Lcdtronl.v_Lctbs_Parties(i).Cif_Id' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                .CIF_ID);
            BEGIN
              SELECT CUSTOMER_NAME1,
                     LANGUAGE,
                     COUNTRY,
                     CUSTOMER_TYPE,
                     ADDRESS_LINE1,
                     ADDRESS_LINE2,
                     ADDRESS_LINE3,
                     ADDRESS_LINE4
                INTO L_CUST_NAME,
                     L_LANG_CODE,
                     L_CNTRY_CODE,
                     L_CUST_TYPE,
                     L_ADDRESS_LINE1,
                     L_ADDRESS_LINE2,
                     L_ADDRESS_LINE3,
                     L_ADDRESS_LINE4
                FROM STTM_CUSTOMER
               WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID;

            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in   Selecting the Customer Record For :' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                    .CIF_ID);
                L_CUST_NAME     := NULL;
                L_LANG_CODE     := NULL;
                L_CNTRY_CODE    := NULL;
                L_CUST_TYPE     := NULL;
                L_ADDRESS_LINE1 := NULL;
                L_ADDRESS_LINE2 := NULL;
                L_ADDRESS_LINE3 := NULL;
                L_ADDRESS_LINE4 := NULL;

            END;

          END IF;

          P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_NAME := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                                             .CUST_NAME,
                                                             L_CUST_NAME);
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).COUNTRY_CODE := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                                                .COUNTRY_CODE,
                                                                L_CNTRY_CODE);
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).LANG_CODE := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                                             .LANG_CODE,
                                                             L_LANG_CODE);

          IF ((P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_ADDRESS_LIN1 IS NULL) AND
             (P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_ADDRESS_LIN2 IS NULL) AND
             (P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_ADDRESS_LIN3 IS NULL) AND
             (P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_ADDRESS_LIN4 IS NULL)) THEN

            P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_ADDRESS_LIN1 := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                                                       .CUST_ADDRESS_LIN1,
                                                                       L_ADDRESS_LINE1);
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_ADDRESS_LIN2 := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                                                       .CUST_ADDRESS_LIN2,
                                                                       L_ADDRESS_LINE2);
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_ADDRESS_LIN3 := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                                                       .CUST_ADDRESS_LIN3,
                                                                       L_ADDRESS_LINE3);
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_ADDRESS_LIN4 := NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                                                       .CUST_ADDRESS_LIN4,
                                                                       L_ADDRESS_LINE4);
          END IF;

          P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).VERSION_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).EVENT_SEQ_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).EVENT_CODE := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE;

        END LOOP;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).CIF_ID IS NULL THEN
            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT > 0 THEN
              FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT LOOP
                IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).PARTY_TYPE = P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                   .PARTY_TYPE THEN
                  P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).CIF_ID := P_WRK_LCDTRONL.V_LCTBS_PARTIES(J)
                                                                      .CIF_ID;
                  EXIT;
                END IF;

              END LOOP;

            END IF;

          END IF;

          P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).VERSION_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO;
          P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).EVENT_SEQ_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;
          P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).EVENT_CODE := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE;
        END LOOP;

      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    DBG('Returning true Fn_Default_Parties ....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_default_parties');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.fn_default_parties~' ||
                         SQLCODE);
      RETURN FALSE;

  END FN_DEFAULT_PARTIES;

  FUNCTION FN_DEFAULT_DRAFTS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_SOURCE_OPERATION   IN VARCHAR2,
                             P_FUNCTION_ID        IN VARCHAR2,
                             P_ACTION_CODE        IN VARCHAR2,
                             P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                             P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_ERR_CODE           IN OUT VARCHAR2,
                             P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_COUNT     NUMBER;
    L_ROUND_AMT LCTBS_DRAFTS.DRAFT_AMT%TYPE;

  BEGIN
    DBG('In Fn_Default_Drafts...');

    IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).VERSION_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO;
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).EVENT_SEQ_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).EVENT_CODE := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE;

        IF ((P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS1 IS NULL) AND
           (P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS2 IS NULL) AND
           (P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3 IS NULL)) THEN

          SELECT COUNT(*)
            INTO L_COUNT
            FROM ISTMS_BIC_DIRECTORY
           WHERE BANK_NAME = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';

          IF L_COUNT > 0 THEN

            SELECT BANK_NAME, BANK_ADDRESS1, BANK_ADDRESS2, BANK_ADDRESS3
              INTO P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE,
                   P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS1,
                   P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS2,
                   P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3

              FROM ISTMS_BIC_DIRECTORY
             WHERE BIC_CODE = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';

          ELSE
            BEGIN
              SELECT CUSTOMER_NAME1,
                     ADDRESS_LINE1,
                     ADDRESS_LINE2,
                     ADDRESS_LINE3 || ' ' || ADDRESS_LINE4
                INTO P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE,
                     P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS1,
                     P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS2,
                     P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).ADDRESS3
                FROM STTMS_CUSTOMER
               WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A';

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Invalid customer');

            END;

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
           .INSURANCE_COMP_CODE IS NOT NULL THEN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM BCTM_INSURANCE_COMP
             WHERE INSURANCE_COMP_CODE = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                  .INSURANCE_COMP_CODE
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';

            IF L_COUNT > 0 THEN
              IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_CO IS NULL THEN
                SELECT INSURANCE_COMP_NAME
                  INTO P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_CO
                  FROM BCTMS_INSURANCE_COMP
                 WHERE INSURANCE_COMP_CODE = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                      .INSURANCE_COMP_CODE;

              END IF;

            ELSE
              P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_COMP_CODE := 'XXXXXXXXX';

            END IF;

          END IF;

        END IF;

      END LOOP;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
      FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT LOOP

        IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT > 0 THEN
          FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT LOOP
            P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
            P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I).EVENT_SEQ_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;

          END LOOP;

        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(J).DRAFT_AMT IS NOT NULL THEN
          DBG('Draft Amount Formatting');
          IF NOT
              CYPKSS.FN_AMT_ROUND(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                  P_WRK_LCDTRONL.V_LCTBS_DRAFTS(J).DRAFT_AMT,
                                  L_ROUND_AMT) THEN
            P_ERR_CODE   := 'LC-VALS-006';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

          DBG('Rounded Rate' || L_ROUND_AMT);
          DBG('Rate before round' || P_WRK_LCDTRONL.V_LCTBS_DRAFTS(J)
              .DRAFT_AMT);
          P_WRK_LCDTRONL.V_LCTBS_DRAFTS(J).DRAFT_AMT := L_ROUND_AMT;
        END IF;

      END LOOP;

    END IF;

    DBG('Returning true Fn_Default_Drafts ....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_default_parties');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.fn_default_parties~' ||
                         SQLCODE);
      RETURN FALSE;

  END FN_DEFAULT_DRAFTS;

  FUNCTION FN_DEFAULT_DOCUMENTS_CLAUSES(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                        P_FUNCTION_ID        IN VARCHAR2,
                                        P_ACTION_CODE        IN VARCHAR2,
                                        P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                        P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                        P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                        P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                        P_ERR_CODE           IN OUT VARCHAR2,
                                        P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_DOC_CNTR    NUMBER := 0;
    L_CLAUSE_CNTR NUMBER := 0;
    L_INCO_TERM   LCTBS_CONTRACT_MASTER.INCO_TERM%TYPE;

    CURSOR C_DOCS IS
      SELECT PD.DOCUMENT_CODE,
             ROWNUM,
             PD.DOCUMENT_TYPE,
             DM.DOC_LONG_DESC,
             PD.ORIGINAL_REQUIRED,
             PD.NO_OF_COPIES,
             PD.NO_OF_ORIGINALS
        FROM LCTMS_PRODUCT_DOCUMENTS PD, BCTMS_DOCS_MASTER DM

       WHERE PD.PRODUCT_CODE = P_PRODUCT_DEFINITION.PRODUCT_CODE
         AND PD.DOCUMENT_CODE = DM.DOC_CODE
         AND DM.LANG_CODE = GLOBAL.LANG;

    CURSOR C_CLAUSES(C_INCO TFTMS_INCO_DOCS.INCO_TERM%TYPE,
                     C_DOC  TFTMS_INCO_DOCS.DOC_CODE%TYPE) IS
      SELECT PDC.DOCUMENT_CODE,
             PDC.CLAUSE_CODE,
             ROWNUM,
             CM.CLAUSE_DESCRIPTION
        FROM LCTMS_PRODUCT_DOC_CLAUSE PDC, LCTMS_CLAUSE_MASTER CM

       WHERE PDC.PRODUCT_CODE = P_PRODUCT_DEFINITION.PRODUCT_CODE
         AND PDC.DOCUMENT_CODE = C_DOC
         AND PDC.CLAUSE_CODE = CM.CLAUSE_CODE
         AND CM.LANGUAGE_CODE = GLOBAL.LANG

      UNION ALL

      SELECT C_DOC, CM.CLAUSE_CODE, ROWNUM, CM.CLAUSE_DESCRIPTION

        FROM LCTMS_CLAUSE_MASTER CM
       WHERE CM.CLAUSE_CODE IN (SELECT CLAUSE_CODE
                                  FROM TFTMS_INCO_DOCS_CLAUSES
                                 WHERE INCO_TERM = C_INCO
                                   AND DOC_CODE = C_DOC)
         AND LANGUAGE_CODE = GLOBAL.LANG
         AND CM.CLAUSE_CODE NOT IN
             (SELECT CLAUSE_CODE
                FROM LCTMS_PRODUCT_DOC_CLAUSE
               WHERE DOCUMENT_CODE = C_DOC
                 AND PRODUCT_CODE = P_PRODUCT_DEFINITION.PRODUCT_CODE);

    CURSOR C_INCO_DOCS(C_INCO TFTMS_INCO_DOCS.INCO_TERM%TYPE) IS
      SELECT DM.DOC_CODE      AS DOCUMENT_CODE,
             ROWNUM,
             DM.DOC_TYPE      AS DOCUMENT_TYPE,
             DM.DOC_LONG_DESC,
             NULL             AS ORIGINAL_REQUIRED,
             NULL             NO_OF_COPIES,
             NULL             NO_OF_ORIGINALS
        FROM BCTMS_DOCS_MASTER DM
       WHERE DOC_CODE IN
             (SELECT DOC_CODE
                FROM TFTMS_INCO_DOCS
               WHERE INCO_TERM = C_INCO
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A'
                 AND LANG_CODE = GLOBAL.LANG
                 AND DOC_CODE NOT IN
                     (SELECT DOCUMENT_CODE
                        FROM LCTMS_PRODUCT_DOCUMENTS PD, BCTMS_DOCS_MASTER DM
                       WHERE PD.PRODUCT_CODE =
                             P_PRODUCT_DEFINITION.PRODUCT_CODE
                         AND PD.DOCUMENT_CODE = DM.DOC_CODE
                         AND DM.LANG_CODE = GLOBAL.LANG));

    CURSOR C_INCO_CLAUSES(C_INCO TFTMS_INCO_DOCS.INCO_TERM%TYPE,
                          C_DOC  TFTMS_INCO_DOCS.DOC_CODE%TYPE) IS

      SELECT *
        FROM LCTMS_CLAUSE_MASTER
       WHERE CLAUSE_CODE IN (SELECT CLAUSE_CODE
                               FROM TFTMS_INCO_DOCS_CLAUSES
                              WHERE INCO_TERM = C_INCO
                                AND DOC_CODE = C_DOC)
         AND LANGUAGE_CODE = GLOBAL.LANG;

  BEGIN
    DBG('In Fn_Default_Documents...');

    IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT = 0 THEN
      DBG('In Documents Count--->');
      L_INCO_TERM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM;
      FOR DOC IN C_DOCS LOOP
        L_DOC_CNTR := L_DOC_CNTR + 1;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).VERSION_NO := 1;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).EVENT_SEQ_NO := 1;

        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_CODE := DOC.DOCUMENT_CODE;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_SL_NO := L_DOC_CNTR;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_TYPE := DOC.DOCUMENT_TYPE;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_DESCR := DOC.DOC_LONG_DESC;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_ORIGINAL := DOC.ORIGINAL_REQUIRED;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_COPIES := DOC.NO_OF_COPIES;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).NO_OF_ORIGINALS := DOC.NO_OF_ORIGINALS;
      END LOOP;

      FOR DOC IN C_DOCS LOOP
        FOR CLAUSE IN C_CLAUSES(L_INCO_TERM, DOC.DOCUMENT_CODE) LOOP
          L_CLAUSE_CNTR := L_CLAUSE_CNTR + 1;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).VERSION_NO := 1;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).EVENT_SEQ_NO := 1;

          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).DOC_CODE := CLAUSE.DOCUMENT_CODE;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).CLAUSE_CODE := CLAUSE.CLAUSE_CODE;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).CLAUSE_SL_NO := L_CLAUSE_CNTR;

          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).CLAUSE_DESCR := CLAUSE.CLAUSE_DESCRIPTION;
        END LOOP;

      END LOOP;

      FOR INCODOC IN C_INCO_DOCS(L_INCO_TERM) LOOP

        L_DOC_CNTR := L_DOC_CNTR + 1;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).VERSION_NO := 1;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).EVENT_SEQ_NO := 1;

        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_CODE := INCODOC.DOCUMENT_CODE;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_SL_NO := L_DOC_CNTR;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_TYPE := INCODOC.DOCUMENT_TYPE;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_DESCR := INCODOC.DOC_LONG_DESC;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_ORIGINAL := INCODOC.ORIGINAL_REQUIRED;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).DOC_COPIES := INCODOC.NO_OF_COPIES;
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_DOC_CNTR).NO_OF_ORIGINALS := INCODOC.NO_OF_ORIGINALS;

        FOR INCOCLAUSE IN C_INCO_CLAUSES(L_INCO_TERM, INCODOC.DOCUMENT_CODE) LOOP

          L_CLAUSE_CNTR := L_CLAUSE_CNTR + 1;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).VERSION_NO := 1;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).EVENT_SEQ_NO := 1;

          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).DOC_CODE := INCODOC.DOCUMENT_CODE;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).CLAUSE_CODE := INCOCLAUSE.CLAUSE_CODE;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).CLAUSE_SL_NO := L_CLAUSE_CNTR;
          P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_CLAUSE_CNTR).CLAUSE_DESCR := INCOCLAUSE.CLAUSE_DESCRIPTION;
        END LOOP;

      END LOOP;

    END IF;

    DBG('Returning true Fn_Default_Documents ....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_default_parties');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.fn_default_parties~' ||
                         SQLCODE);
      RETURN FALSE;

  END FN_DEFAULT_DOCUMENTS_CLAUSES;

  FUNCTION FN_DEFAULT_TRACERS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_FUNCTION_ID        IN VARCHAR2,
                              P_ACTION_CODE        IN VARCHAR2,
                              P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                              P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_ERR_CODE           IN OUT VARCHAR2,
                              P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_TRACER_CNTR NUMBER;
    L_MODULE      SMTB_MENU.MODULE%TYPE;

    CURSOR C_TRACERS(P_MODULE SMTB_MENU.MODULE%TYPE) IS
      SELECT PT.TRACER_CODE,
             MT.DESCRIPTION,
             PT.REQUIRED,
             PT.START_DAYS,
             PT.FREQUENCY,
             PT.NO_OF_TRACERS_TO_SEND
        FROM LCTMS_PRODUCT_TRACERS PT, MSTMS_MSG_TYPE MT

       WHERE PT.PRODUCT_CODE = P_PRODUCT_DEFINITION.PRODUCT_CODE
         AND MT.TRACER = 'Y'
         AND PT.TRACER_CODE = MT.MSG_TYPE
         AND MT.MODULE = P_MODULE;

  BEGIN
    DBG('Inn Default Tracers..');

    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;

    END;

    L_TRACER_CNTR := 0;
    IF P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT = 0 THEN

      FOR TRACER IN C_TRACERS(L_MODULE) LOOP

        L_TRACER_CNTR := L_TRACER_CNTR + 1;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).VERSION_NO := 1;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).EVENT_SEQ_NO := 1;

        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).TRACER_CODE := TRACER.TRACER_CODE;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).TRACER_DESCR := TRACER.DESCRIPTION;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).REQUIRED := TRACER.REQUIRED;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).TRACER_PARTY := NULL;

        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).START_DAYS := TRACER.START_DAYS;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).FREQUENCY := TRACER.FREQUENCY;
        P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_TRACER_CNTR).MAX_TRACERS := TRACER.NO_OF_TRACERS_TO_SEND;

      END LOOP;

    END IF;

    DBG('Returning true Fn_Default_tracers ....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_default_parties');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.fn_default_parties~' ||
                         SQLCODE);
      RETURN FALSE;

  END FN_DEFAULT_TRACERS;

  FUNCTION FN_DEFAULT_GOODS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                            P_SOURCE_OPERATION   IN VARCHAR2,
                            P_FUNCTION_ID        IN VARCHAR2,
                            P_ACTION_CODE        IN VARCHAR2,
                            P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                            P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_ERR_CODE           IN OUT VARCHAR2,
                            P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN
    DBG('In Fn_Default_Goods..');

    IF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE IS NOT NULL AND
       P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR IS NULL THEN
      BEGIN
        SELECT GOODS_DESC
          INTO P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR
          FROM BCTMS_GOODS_MASTER
         WHERE GOODS_CODE = P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE
           AND LANGUAGE_CODE = GLOBAL.LANG
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in Selecting Goods Description For :' ||
              P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE);

      END;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_GOODS.INCO_TERM IS NULL AND
       P_PRODUCT_DEFINITION.PRODUCT_TYPE NOT IN ('H', 'G') THEN
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM IS NOT NULL THEN
        P_WRK_LCDTRONL.V_LCTBS_GOODS.INCO_TERM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM;
      ELSE
        P_WRK_LCDTRONL.V_LCTBS_GOODS.INCO_TERM := P_PRODUCT_DEFINITION.INCO_TERM;

      END IF;

    END IF;

    DBG('Returning from  Fn_Default_Goods..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_default_ship_docs');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.fn_default_ship_docs~' ||
                         SQLCODE);
      RETURN FALSE;

  END FN_DEFAULT_GOODS;

  FUNCTION FN_DEFAULT_SHIP_DOCS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_FUNCTION_ID        IN VARCHAR2,
                                P_ACTION_CODE        IN VARCHAR2,
                                P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_ERR_CODE           IN OUT VARCHAR2,
                                P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_WHNO      NUMBER;
    L_UNIT      CHAR(1);
    L_SHIP_DATE DATE;

  BEGIN
    DBG('In Fn_Default_Ship_Docs..');

    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'G' THEN
      IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT, 'N') <> 'Y' THEN

        P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT := NULL;
      END IF;

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT, 'N') <> 'Y' THEN

        P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT := NULL;
      END IF;

    END IF;

    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE != 'E' THEN

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION IS NULL AND
         NOT LCPKS_LCDTRONL_KERNEL.G_ACTION_L THEN

        BEGIN
          IF P_PRODUCT_DEFINITION.CALCULATED_DAYS = 'N' THEN

            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION := P_PRODUCT_DEFINITION.NUMBER_OF_DAYS;
          ELSE
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                                                                              P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE;

          END IF;

        END;

      END IF;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_PRODUCT_DEFINITION.NUMBER_OF_DAYS IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION IS NULL THEN
        DBG('override is raised ');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'LC-ADV-022',
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION);
      END IF;
    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE IS NOT NULL AND
       P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR IS NULL THEN
      BEGIN
        SELECT GOODS_DESC
          INTO P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR
          FROM BCTMS_GOODS_MASTER
         WHERE GOODS_CODE = P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE
           AND LANGUAGE_CODE = GLOBAL.LANG
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed to select the description');
          P_ERR_CODE   := 'LCUPLD-059';
          P_ERR_PARAMS := NULL;

      END;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE IS NOT NULL THEN
      P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DAYS := P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE -
                                                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE;
    ELSIF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DAYS IS NOT NULL AND
          P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE IS NULL THEN
      P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE := P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DAYS +
                                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_default_ship_docs');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.fn_default_ship_docs~' ||
                         SQLCODE);
      RETURN FALSE;

  END FN_DEFAULT_SHIP_DOCS;

  FUNCTION FN_DEFAULT(P_SOURCE           IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                      P_SOURCE_OPERATION IN VARCHAR2,
                      P_FUNCTION_ID      IN VARCHAR2,
                      P_ACTION_CODE      IN VARCHAR2,
                      P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                      P_PREV_LCDTRONL    IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                      P_WRK_LCDTRONL     IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                      P_ERR_CODE         IN OUT VARCHAR2,
                      P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_PRODUCT_DEFINITION LCTMS_PRODUCT_DEFINITION%ROWTYPE;
    L_PROD_REC           CSTM_PRODUCT%ROWTYPE;
    L_FUNCTION_ID        VARCHAR2(10);

    L_TENOR LCTB_CONTRACT_MASTER.TENOR%TYPE;

    LL_CONTRACT_AMT         LCTB_CONTRACT_MASTER.CONTRACT_AMT%TYPE;
    LL_POSITIVE_TOLERANCE   LCTB_CONTRACT_MASTER.POSITIVE_TOLERANCE%TYPE;
    LL_MAX_CONTRACT_AMT     LCTB_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;
    LL_CURRENT_AVAILABILITY LCTB_AVAILMENTS.CURRENT_AVAILABILITY%TYPE;
    LL_OS_LIABILITY         LCTB_AVAILMENTS.OS_LIABILITY%TYPE;
    LL_PREV_EVENT_SEQ_NO    LCTB_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE;
    LL_PRE_AVL_ESN          LCTB_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE;
    L_MAX_ROPN_ESN          LCTB_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE;
    L_MAX_PCLS_ESN          LCTB_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE;

    LL_MAX_LIAB_AMT LCTB_CONTRACT_MASTER.MAX_LIABILITY_AMT%TYPE;

    L_COLLAMT                  LCTB_COLLATERAL.COLLATERAL_AMT%TYPE;
    L_COLLAMT_RN               LCTB_COLLATERAL.COLLATERAL_AMT%TYPE;
    L_RATE                     CYTMS_RATES.MID_RATE%TYPE;
    L_RATE_FLAG                NUMBER;
    L_CONVERTED_COLLATERAL_AMT LCTB_COLLATERAL.COLLATERAL_AMT%TYPE;

    L_LATEST_AVAILIBILITY LCTB_AVAILMENTS.CURRENT_AVAILABILITY%TYPE;

  BEGIN
    DBG('In Fn_Default...');

    IF NOT FN_GET_PRODUCT_DETAILS(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                  L_PROD_REC,
                                  L_PRODUCT_DEFINITION,
                                  P_FUNCTION_ID,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Get_Product_Details ...');
      RETURN FALSE;
    END IF;

    IF P_ACTION_CODE NOT IN
       (CSPKS_REQ_GLOBAL.P_DELETE,
        CSPKS_REQ_GLOBAL.P_AUTH,
        CSPKS_REQ_GLOBAL.P_COPY,
        CSPKS_REQ_GLOBAL.P_CLOSE,
        CSPKS_REQ_GLOBAL.P_REOPEN,
        CSPKS_REQ_GLOBAL.P_REVERSE) THEN

      DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Master');
      IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_MASTER(P_SOURCE,
                                                    P_SOURCE_OPERATION,
                                                    P_FUNCTION_ID,
                                                    P_ACTION_CODE,
                                                    L_PRODUCT_DEFINITION,
                                                    P_LCDTRONL,
                                                    P_PREV_LCDTRONL,
                                                    P_WRK_LCDTRONL,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Master ...');
        RETURN FALSE;
      END IF;

      DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Ship_Docs');
      IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_SHIP_DOCS(P_SOURCE,
                                                       P_FUNCTION_ID,
                                                       P_ACTION_CODE,
                                                       L_PRODUCT_DEFINITION,
                                                       P_LCDTRONL,
                                                       P_WRK_LCDTRONL,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN

        DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Parties ...');
        RETURN FALSE;
      END IF;

      DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Parties');
      IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_PARTIES(P_SOURCE,
                                                     P_SOURCE_OPERATION,
                                                     P_FUNCTION_ID,
                                                     P_ACTION_CODE,
                                                     L_PRODUCT_DEFINITION,
                                                     P_LCDTRONL,
                                                     P_WRK_LCDTRONL,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN

        DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Parties ...');
        RETURN FALSE;
      END IF;

      DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Parties');
      IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_DRAFTS(P_SOURCE,
                                                    P_SOURCE_OPERATION,
                                                    P_FUNCTION_ID,
                                                    P_ACTION_CODE,
                                                    L_PRODUCT_DEFINITION,
                                                    P_LCDTRONL,
                                                    P_PREV_LCDTRONL,
                                                    P_WRK_LCDTRONL,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Drafts ...');
        RETURN FALSE;
      END IF;

      DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Goods');
      IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_GOODS(P_SOURCE,
                                                   P_SOURCE_OPERATION,
                                                   P_FUNCTION_ID,
                                                   P_ACTION_CODE,
                                                   L_PRODUCT_DEFINITION,
                                                   P_LCDTRONL,
                                                   P_PREV_LCDTRONL,
                                                   P_WRK_LCDTRONL,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Goods ...');
        RETURN FALSE;
      END IF;

      IF NOT LCPKS_LCDTRONL_MAIN. FN_SYS_QUERY_DESC_FIELDS(P_SOURCE,
                                  P_SOURCE_OPERATION,
                                  L_FUNCTION_ID,
                                  P_ACTION_CODE,
                                  P_WRK_LCDTRONL,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN

        DBG('Failed in desc fields');
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT > 0 THEN
        DBG('In Assinging the linkage ref no');
        FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT LOOP
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LINKAGE_TYPE,
                 'L') = 'L' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
            .LINKED_REF_NO IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LINKED_REF_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                                                                       .LIABLITY_NO;
          END IF;
        END LOOP;
      END IF;

    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      DBG('Inside fn_default for reopen');
      DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Master');
      IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_MASTER(P_SOURCE,
                                                    P_SOURCE_OPERATION,
                                                    P_FUNCTION_ID,
                                                    P_ACTION_CODE,
                                                    L_PRODUCT_DEFINITION,
                                                    P_LCDTRONL,
                                                    P_PREV_LCDTRONL,
                                                    P_WRK_LCDTRONL,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Master ...');
        RETURN FALSE;
      END IF;

      DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Ship_Docs');
      P_WRK_LCDTRONL.V_LCTBS_SHIPMENT              := P_LCDTRONL.V_LCTBS_SHIPMENT;
      P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.EVENT_CODE   := 'ROPN';
      P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.VERSION_NO   := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO;
      P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.EVENT_SEQ_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;
      IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_SHIP_DOCS(P_SOURCE,
                                                       P_FUNCTION_ID,
                                                       P_ACTION_CODE,
                                                       L_PRODUCT_DEFINITION,
                                                       P_LCDTRONL,
                                                       P_WRK_LCDTRONL,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN

        DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Parties ...');
        RETURN FALSE;
      END IF;

      DBG('latest_version_no1 ' ||
          P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
      DBG('latest_event_seq_no1 ' ||
          P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
      DBG('latest_version_no1 ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
      DBG('latest_event_seq_no1 ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
      DBG('Event code 1' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE);
      DBG(' con amt 1' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
      DBG('Max con amt1 ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);
      DBG('Max liab amt 1' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT);
      BEGIN
        DBG('Before updating master record' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        DBG('Dates' || P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE);

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NULL THEN
          L_TENOR := NULL;
        ELSE
          L_TENOR := (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE) || 'D';

        END IF;

        UPDATE LCTB_CONTRACT_MASTER
           SET CONTRACT_AMT     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
               EXPIRY_DATE      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE,
               CLOSURE_DATE     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE,
               STOP_DATE        = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE,
               MAX_CONTRACT_AMT = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,

               MAX_LIABILITY_AMT =
               (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT *
               (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE / 100)) +
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT

              ,
               TENOR = L_TENOR

              ,
               AMENDMENT_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO

         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND VERSION_NO =
               (SELECT MAX(VERSION_NO)
                  FROM LCTB_CONTRACT_MASTER
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while updating master record' || SQLERRM);
          NULL;

      END;

      BEGIN
        SELECT MAX(EVENT_SEQ_NO)
          INTO LL_PREV_EVENT_SEQ_NO
          FROM LCTB_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_SEQ_NO <
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTB_CONTRACT_MASTER
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in fetching the previous event sequence number');

      END;

      DBG('ll_prev_event_seq_no issss-->' || LL_PREV_EVENT_SEQ_NO);
      BEGIN

        SELECT CONTRACT_AMT,
               POSITIVE_TOLERANCE,
               MAX_CONTRACT_AMT,
               MAX_LIABILITY_AMT
          INTO LL_CONTRACT_AMT,
               LL_POSITIVE_TOLERANCE,
               LL_MAX_CONTRACT_AMT,
               LL_MAX_LIAB_AMT

          FROM LCTB_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_SEQ_NO = LL_PREV_EVENT_SEQ_NO;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in selecting the details from the lctb_contract_master');

      END;

      BEGIN
        SELECT NVL(MAX(EVENT_SEQ_NO), 0)
          INTO L_MAX_ROPN_ESN
          FROM LCTB_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_CODE = 'ROPN';

        DEBUG.PR_DEBUG('LC', 'l_Max_ROPN_Esn' || L_MAX_ROPN_ESN);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in selecting the details from the lctb_contract_master');

      END;

      BEGIN
        SELECT NVL(MAX(EVENT_SEQ_NO), 0)
          INTO L_MAX_PCLS_ESN
          FROM LCTB_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_CODE = 'PCLS'
           AND EVENT_SEQ_NO > L_MAX_ROPN_ESN;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in selecting the details from the lctb_contract_master');

      END;

      DEBUG.PR_DEBUG('LC', 'l_Max_pcls_Esn' || L_MAX_PCLS_ESN);
      IF L_MAX_PCLS_ESN > 0 THEN
        LL_PRE_AVL_ESN := L_MAX_PCLS_ESN;
        DEBUG.PR_DEBUG('CF',
                       'For PCLS Fired l_prev_event_seq_no' ||
                       LL_PRE_AVL_ESN);
      ELSE
        BEGIN
          SELECT MAX(EVENT_SEQ_NO)
            INTO LL_PRE_AVL_ESN
            FROM LCTB_AVAILMENTS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO <
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTB_AVAILMENTS
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO)

             AND EVENT_CODE NOT IN ('CLOS', 'PCLS');

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in the fetching the event sequence number in lctb_availments');

        END;

      END IF;

      DBG('ll_pre_avl_esn iss-->' || LL_PRE_AVL_ESN);
      BEGIN
        SELECT CURRENT_AVAILABILITY, OS_LIABILITY
          INTO LL_CURRENT_AVAILABILITY, LL_OS_LIABILITY
          FROM LCTB_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_SEQ_NO = LL_PRE_AVL_ESN;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in the select of values from lctb_availments');

      END;

      DBG('ll_contract_amt isssss-->' || LL_CONTRACT_AMT);
      DBG('ll_max_contract_amt iss->' || LL_MAX_CONTRACT_AMT);
      DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Max_Contract_Amt iss-->' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);
      DBG('contract amount is-->' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
      DBG('ll_current_availability isss-->' || LL_CURRENT_AVAILABILITY);
      DBG('ll_current_availability iss-->' || LL_OS_LIABILITY);
      BEGIN
        DBG('Before updating master record' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        UPDATE LCTB_AVAILMENTS

           SET CURRENT_AVAILABILITY = LL_CURRENT_AVAILABILITY +
                                      (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT -
                                      LL_MAX_CONTRACT_AMT),
               OS_LIABILITY         = LL_OS_LIABILITY + (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT -
                                      LL_MAX_LIAB_AMT)

         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND VERSION_NO =
               (SELECT MAX(VERSION_NO)
                  FROM LCTB_AVAILMENTS
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while updating avail record' || SQLERRM);
          NULL;

      END;

      BEGIN
        DBG('Before updating master record' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE);
        UPDATE CSTB_CONTRACT
           SET LATEST_VERSION_NO   = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
               LATEST_EVENT_SEQ_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
               CURR_EVENT_CODE     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while updating core record' || SQLERRM);
          NULL;

      END;

      BEGIN
        DBG('Before updating SHIPEMENT record' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE);
        UPDATE LCTB_SHIPMENT
           SET FROM_PLACE           = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.FROM_PLACE,
               TO_PLACE             = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TO_PLACE,
               LATEST_SHIPMENT_DATE = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE,
               PARTIAL_SHIPMENT     = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT,
               TRANS_SHIPMENT       = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT,
               SHIPMENT_DETAILS     = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS,
               SHIPMENT_MARKS       = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS,
               SHIPMENT_PERIOD      = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_PERIOD,
               PORT_DISCHARGE       = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_DISCHARGE,
               PORT_LOADING         = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_LOADING,
               SHIPMENT_DAYS        = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DAYS

              ,
               PARTIAL_SHIPMENT_DETAILS = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT_DETAILS,
               TRANS_SHIPMENT_DETAILS   = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT_DETAILS

         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND VERSION_NO =
               (SELECT MAX(VERSION_NO)
                  FROM LCTB_SHIPMENT
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while updating SHIPEMENT record' || SQLERRM);
          NULL;

      END;

      BEGIN
        DBG('Before updating collateral record' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT ||
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_PCT);

        L_LATEST_AVAILIBILITY := LL_CURRENT_AVAILABILITY +
                                 (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT -
                                 LL_MAX_CONTRACT_AMT);
        DBG('28541135_FIM::Ll_Current_Availability' ||
            LL_CURRENT_AVAILABILITY);
        DBG('28541135_FIM::p_wrk_lcdtronl.v_lctbs_availments.current_availability' ||
            P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY);
        IF P_ACTION_CODE = 'REOPEN' THEN
          L_COLLAMT := L_LATEST_AVAILIBILITY *
                       (P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_PCT / 100);
        ELSE

          L_COLLAMT := P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY *
                       (P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_PCT / 100);
          DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Contract_ccy ' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY);
          DBG('p_Wrk_Lcdtronl.Ty_Lcctrclt.v_Lctbs_Collateral.Collateral_ccy' ||
              P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY);
        END IF;
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY <>
           P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY THEN
          DBG('Collateral ccy is not same as contract ccy');
          IF NOT CYPKS.FN_GETRATE(SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                         1,
                                         3),
                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                  P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY,
                                  L_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN
            DBG('failed in cypks.get rate :' || SQLERRM);
            RETURN FALSE;
          END IF;
          DBG('Exchange Rate' || L_RATE);
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                               1,
                                               3),
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                        P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY,
                                        L_COLLAMT,
                                        'Y',
                                        L_CONVERTED_COLLATERAL_AMT,
                                        L_RATE,
                                        P_ERR_CODE) THEN
            DEBUG.PR_DEBUG('LC',
                           '  failed in collateral_amt  conversion >' ||
                           P_ERR_CODE);
            RETURN FALSE;
          END IF;
        ELSE
          DBG('Collateral ccy is same as contract ccy');
          L_CONVERTED_COLLATERAL_AMT := L_COLLAMT;
        END IF;
        DBG('l_converted_collateral_amt before rounding' ||
            L_CONVERTED_COLLATERAL_AMT);

        L_CONVERTED_COLLATERAL_AMT := NVL(L_CONVERTED_COLLATERAL_AMT, 0);
        IF L_CONVERTED_COLLATERAL_AMT <> 0 THEN
          IF NOT CYPKSS.FN_AMT_ROUND(P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY,
                                     L_CONVERTED_COLLATERAL_AMT,
                                     L_COLLAMT_RN) THEN
            DBG('Failed in Cypkss.Fn_Amt_Round of Collateral amount during Reopen operation');
            P_ERR_CODE   := 'LC-VALS-006';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;

        END IF;
        DBG('Collateral amt before Rounding' || L_CONVERTED_COLLATERAL_AMT ||
            'Collateral amt after rounding' || L_COLLAMT_RN);

        UPDATE LCTB_COLLATERAL

           SET COLLATERAL_AMT = L_COLLAMT_RN

         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND VERSION_NO =
               (SELECT MAX(VERSION_NO)
                  FROM LCTB_COLLATERAL
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

        DBG('After updating collateral record' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT *
            (P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_PCT / 100));
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while updating collateral record' || SQLERRM);
          NULL;

      END;

    END IF;

    DBG('Returning true Fn_Default ....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_default_parties');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.fn_default_parties~' ||
                         SQLCODE);
      RETURN FALSE;

  END FN_DEFAULT;

  FUNCTION FN_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_PREV_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_FUNCTION_ID       VARCHAR2(50) := 'LCDTRONL';
    L_SUBSYS_STAT       VARCHAR2(500);
    L_EVENT_SEQ_NO      NUMBER;
    L_EVENT_CODE        VARCHAR2(10);
    L_TENOR             NUMBER;
    L_LATEST_VERSION_NO CSTBS_CONTRACT.LATEST_VERSION_NO%TYPE;
    L_PRODUCT           VARCHAR2(10);
    L_CPARTY            VARCHAR2(20);
    L_PICKEDUP          BOOLEAN := TRUE;
    L_STAT              VARCHAR2(1);

    L_MODULE       SMTB_MENU.MODULE%TYPE;
    L_APP_DATE     DATE := GLOBAL.APPLICATION_DATE;
    L_ZERO         NUMBER := 0;
    L_UDF_TBL      UVPKS_UDF_UPLOAD.TY_UPL_CONT_UDF;
    L_VERSION_NO   CSTMS_CONTRACT_USERDEF_FIELDS.VERSION_NO%TYPE;
    L_ACT_ACTION   VARCHAR(40);
    L_FCC_REF      CSTB_CONTRACT.CONTRACT_REF_NO%TYPE;
    P_WRK_CFCTRCOM CFPKS_CFCTRCOM_MAIN.TY_CFCTRCOM;
    P_WRK_CFCTRCHG CFPKS_CFCTRCHG_MAIN.TY_CFCTRCHG;

    L_COUNT           NUMBER;
    L_PICKUP          BOOLEAN := TRUE;
    L_POS             NUMBER;
    L_LOAN_PRODUCT    VARCHAR2(4);
    L_PRODUCT_TYPE    VARCHAR2(1);
    L_ADJUSTMENT_AMT  LCTBS_COLLATERAL.ADJUSTMENT_AMT%TYPE;
    L_ADJUSTMENT_SIGN NUMBER(1);

    TYPE TY_TB_V_CONTRACT_EVENT_ADVICE IS TABLE OF CSTB_CONTRACT_EVENT_ADVICE%ROWTYPE INDEX BY BINARY_INTEGER;

    L_PICKED_ADVICES LCPKS_LCDTRONL_MAIN.TY_TB_V_CONTRACT_EVENT_ADVICE;

    L_GUD_UNTIL_DATE CFTB_CONTRACT_COMMISSION.GOOD_UNTIL_DATE%TYPE;
    L_OLD_EXP_DT     CFTB_CONTRACT_COMMISSION.GOOD_UNTIL_DATE%TYPE;
    L_GUD_OR_EXP_DT  CFTB_CONTRACT_COMMISSION.GOOD_UNTIL_DATE%TYPE;

    L_BOOL1    BOOLEAN := TRUE;
    L_COL_CCY  LCTBS_COLLATERAL.COLLATERAL_CCY%TYPE;
    L_COL_AMT  LCTBS_COLLATERAL.COLLATERAL_AMT%TYPE;
    L_ADJ_AMT  LCTBS_COLLATERAL.ADJUSTMENT_AMT%TYPE;
    L_ADJ_SIGN NUMBER(1);

    L_MULTI_TRIP_ID VARCHAR2(50);

    P_PREV_CSCDOCTR CSPKS_CSCDOCTR_MAIN.TY_CSCDOCTR;
    P_WRK_CSCDOCTR  CSPKS_CSCDOCTR_MAIN.TY_CSCDOCTR;
    P_CSCDOCTR      CSPKS_CSCDOCTR_MAIN.TY_CSCDOCTR;

    L_WAIVER          VARCHAR2(1) := NULL;
    L_WRK_WAIVE       VARCHAR2(1) := NULL;
    L_BASIS_COMPONENT TATBS_TXNRULE.BASIS_AMOUNT_TAG%TYPE;
    L_COMPONENT       TATBS_TXNRULE.BASIS_AMOUNT_TAG%TYPE;

    L_MIS_COUNT       NUMBER := 0;
    L_USERREF_IN_MSGS BCTM_BRANCH_PARAMETERS.USE_USERREF_IN_MSGS%TYPE;
    L_ORG_ACTION      VARCHAR2(30);
    L_REIM_TYPE       LCTM_PRODUCT_DEFINITION.REIMBURSEMENT%TYPE;

  BEGIN
    DBG('In  Subsyspkp of Utils ...');

    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;

    END;

    SELECT PRODUCT_TYPE, REIMBURSEMENT
      INTO L_PRODUCT_TYPE, L_REIM_TYPE
      FROM LCTMS_PRODUCT_DEFINITION
     WHERE PRODUCT_CODE =
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE;

    DBG('Product_Type >' || L_PRODUCT_TYPE);

    IF P_SOURCE = 'FCAT' THEN
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT := 'MICTRMIS:D;ISCTRSTL:U;TACTRTAX:D;CSCTRUDF:D;CFCTRCHG:D;CFCTRCOM:D;CVS_MAIN__TAB_ADVICES:U;LCCTRCLT:D;';
    ELSE
      IF P_SOURCE NOT IN ('FLEXCUBE') THEN
        DBG('23658471 :: Inside assinging the value for subsys...');

        IF P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT > 0 THEN

          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT := 'MICTRMIS:D;ISCTRSTL:D;TACTRTAX:D;CSCTRUDF:D;CFCTRCHG:D;CFCTRCOM:D;CVS_MAIN__TAB_ADVICES:U;LCCTRCLT:D;';

        ELSE
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT := 'MICTRMIS:D;ISCTRSTL:D;TACTRTAX:D;CSCTRUDF:D;CFCTRCHG:D;CFCTRCOM:D;CVS_MAIN__TAB_ADVICES:D;LCCTRCLT:D;';
        END IF;

      END IF;
    END IF;

    DBG('l_Subsys_Stat ...' || L_SUBSYS_STAT);

    L_SUBSYS_STAT := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT;
    DBG('l_Subsys_Stat ' || L_SUBSYS_STAT);
    IF P_ACTION_CODE = 'HOLD' THEN

      L_POS := INSTR(L_SUBSYS_STAT, ':U');
      DBG('l_Pos' || L_POS);
      IF L_POS > 0 THEN
        L_PICKUP := TRUE;
      ELSE
        L_PICKUP := FALSE;

      END IF;

    END IF;

    IF L_PICKUP THEN
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE := P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;
      L_SUBSYS_STAT                                       := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT;

      L_FCC_REF           := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      L_EVENT_SEQ_NO      := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;
      L_EVENT_CODE        := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE;
      L_TENOR             := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE -
                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE;
      L_LATEST_VERSION_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO;
      L_PRODUCT           := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;
      L_CPARTY            := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.COUNTERPARTY;
      DBG('l_Subsys_Stat' || L_SUBSYS_STAT);
      DBG('Reference No :' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);
      DBG('Event Code   :' || L_EVENT_CODE);
      DBG('Event seq No :' || L_EVENT_SEQ_NO);
      DBG('Tenor        :' || L_TENOR);
      DBG('Version       :' || L_LATEST_VERSION_NO);

      IF P_ACTION_CODE = 'REOPEN' THEN
        DBG('In Reopen Contract' ||
            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
        DBG('Version NO' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
        DBG('Event Seq No' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        DBG('AMOUNT' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);

        BEGIN
          DBG('Before selecting expiry date  ');
          SELECT EXPIRY_DATE
            INTO L_OLD_EXP_DT
            FROM LCTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND VERSION_NO =
                 (SELECT MAX(VERSION_NO) - 1
                    FROM LCTBS_CONTRACT_MASTER
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

          DBG('Expiry date is  ' || L_OLD_EXP_DT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In others1');
            NULL;

        END;

        IF GLOBAL.APPLICATION_DATE < L_OLD_EXP_DT THEN
          L_TENOR := 0;
          DBG('In tenor 0');
        ELSE
          DBG('In Else ' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE);
          BEGIN
            SELECT GOOD_UNTIL_DATE
              INTO L_GUD_UNTIL_DATE
              FROM CFTB_CONTRACT_COMMISSION
             WHERE CONTRACT_REFERENCE_NO =
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
               AND EVENT_SEQ_NO =
                   (SELECT MIN(EVENT_SEQ_NO)
                      FROM CFTB_CONTRACT_COMMISSION
                     WHERE CONTRACT_REFERENCE_NO =
                           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO)
               AND COMPONENT = (SELECT COMPONENT
                                  FROM CFTM_PRODUCT_ICCF
                                 WHERE PRODUCT =
                                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE
                                   AND SHOWN_IN_CONTRACT_MAIN_SCREEN = 'Y'
                                   AND ROWNUM = 1);

            DBG('Good until date is  ' || L_GUD_UNTIL_DATE);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('In others1');
              NULL;

          END;

          IF L_GUD_UNTIL_DATE > L_OLD_EXP_DT THEN
            L_GUD_OR_EXP_DT := L_GUD_UNTIL_DATE;
          ELSE
            L_GUD_OR_EXP_DT := L_OLD_EXP_DT;

          END IF;

          DBG('Good / Expiry  date is  ' || L_GUD_OR_EXP_DT);
          L_TENOR := GLOBAL.APPLICATION_DATE - L_GUD_OR_EXP_DT;
          DBG('Tenor is  ' || L_TENOR);

        END IF;

      END IF;

      DBG('Import License Pickup');
      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'LCCILUTL',
                                                            L_SUBSYS_STAT);
      DBG('l_Stat' || L_STAT);
      IF L_STAT = 'R' THEN
        DBG('Falied in Import License pick up ......');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-UTL-028', NULL);
      END IF;

      DBG('p_Wrk_Lcdtronl.ty_lccilutl.v_lctbs_license_utl_detail.COUNT::' ||
          P_WRK_LCDTRONL.TY_LCCILUTL.V_LCTBS_LICENSE_UTL_DETAIL.COUNT);
      IF L_STAT = 'U' THEN

        DBG('Upload Import License');
        IF NOT LCPKS_LCCILUTL_UTILS.FN_UPLOAD(P_SOURCE,
                                              P_SOURCE_OPERATION,
                                              P_FUNCTION_ID,
                                              P_ACTION_CODE,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_EVENT_SEQ_NO,
                                              L_EVENT_CODE,
                                              P_WRK_LCDTRONL.TY_LCCILUTL,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in lcpks_lccilutl_utils.Fn_upload');
          RETURN FALSE;
        END IF;

      END IF;

      DBG('Commission Pickup..');

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'CFCTRCOM',
                                                            L_SUBSYS_STAT);
      DBG('l_Stat' || L_STAT);
      IF L_STAT = 'R' THEN

        DBG('Falied Commision subsys pick up ......');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CF-CCOM-RDF', NULL);
      END IF;

      DBG('l_Event_Seq_No' || L_EVENT_SEQ_NO);
      IF L_EVENT_CODE <> 'AMND' THEN
        DBG('Calling Iccf Pickup....');
        IF NOT LCPKSS_IFACE.FN_DOICCFPICKUP(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                                            L_EVENT_SEQ_NO,
                                            L_EVENT_CODE,
                                            L_APP_DATE,
                                            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN

          DBG('Failed in Lcpkss_Iface.Fn_Doiccfpickup');
          L_PICKEDUP := FALSE;
          RETURN FALSE;
        END IF;

      ELSE
        DBG('Calling Iccf Pickup.... for  ACON with start date as' ||
            TO_CHAR(GLOBAL.APPLICATION_DATE, 'DD-MON-YY'));
        IF NOT LCPKSS_IFACE.FN_DOICCFPICKUP(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                                            L_EVENT_SEQ_NO,
                                            L_EVENT_CODE,
                                            L_APP_DATE,
                                            TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                    'DD-MON-YY'),
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
          DBG('Failed in Lcpkss_Iface.Fn_Doiccfpickup');
          L_PICKEDUP := FALSE;
          RETURN FALSE;
        END IF;

      END IF;

      IF L_STAT = 'R' THEN

        L_SUBSYS_STAT := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('CFCTRCOM',
                                                                 'S',
                                                                 L_SUBSYS_STAT);
      END IF;

      IF L_PICKEDUP AND L_STAT = 'U' AND
         P_WRK_LCDTRONL.TY_CFCTRCOM.V_CFTBS_CONTRACT_COMMISSION.COUNT > 0 THEN
        P_WRK_LCDTRONL.TY_CFCTRCOM.V_CSTBS_CONTRACT__COM := P_WRK_LCDTRONL.V_CSTBS_CONTRACT;
        DBG('Validate Commission');
        IF NOT CFPKS_CFCTRCOM_UTILS.FN_VALIDATE(P_SOURCE,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.TY_CFCTRCOM,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
          DBG('Failed in Cfpks_Fcj_Cfctrchg_Addon.Fn_Validate..');
          RETURN FALSE;
        END IF;

        IF NOT CFPKS_CFCTRCOM_UTILS.FN_UPLOAD(P_SOURCE,
                                              L_MODULE,
                                              P_ACTION_CODE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_EVENT_SEQ_NO,
                                              P_WRK_LCDTRONL.TY_CFCTRCOM,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in Cfpks_Fcj_Cfctrchg_Addon.Fn_Upload..');
          RETURN FALSE;
        END IF;

      END IF;

      DBG('Charge Pickup..');

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'CFCTRCHG',
                                                            L_SUBSYS_STAT);
      DBG('l_Stat' || L_STAT);
      IF L_STAT = 'R' THEN

        DBG('Falied Chrage subsys pick up ......');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CF-CHGS-RDF', NULL);
      END IF;
      DBG('Coming here..');
      IF NOT TFPKS_CHARGES.FN_CLASS_PICKUP(L_EVENT_CODE,
                                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                           L_EVENT_SEQ_NO,
                                           '',
                                           '',
                                           L_TENOR,
                                           P_ERR_CODE) THEN

        DBG('Failed in Tfpks_Charges.Fn_Class_Pickup ');
        L_PICKEDUP := FALSE;
        RETURN FALSE;
      END IF;

      IF L_STAT = 'R' THEN

        L_SUBSYS_STAT := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('CFCTRCHG',
                                                                 'S',
                                                                 L_SUBSYS_STAT);
      END IF;

      IF L_PICKEDUP AND L_STAT = 'U' AND

         P_WRK_LCDTRONL.TY_CFCTRCHG.V_CFTBS_CHARGE_ASSOC.COUNT > 0 THEN

        DBG('Calling the Cfpks_Cfctrchg_Utils.Fn_Validate');

        IF NOT CFPKS_CFCTRCHG_UTILS.FN_VALIDATE(P_SOURCE,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.TY_CFCTRCHG,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
          DBG('Failed in Cfpks_Fcj_Cfctrchg_Addon.Fn_Validate..');
          RETURN FALSE;
        END IF;
        DBG('Calling the  Cfpks_Cfctrchg_Utils.Fn_Upload');
        IF NOT CFPKS_CFCTRCHG_UTILS.FN_UPLOAD(P_SOURCE,
                                              L_MODULE,
                                              P_ACTION_CODE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_EVENT_SEQ_NO,
                                              P_WRK_LCDTRONL.TY_CFCTRCHG,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in Cfpks_Fcj_Cfctrchg_Addon.Fn_Upload..');
          RETURN FALSE;
        END IF;

      END IF;

      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        DBG('validating chg_com_tracer for reimbursement claim');
        SELECT COUNT(1)
          INTO L_COUNT
          FROM LCTBS_DEFERRED_INT_COM
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

        IF L_COUNT <> 0 AND P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT <> 0 THEN
          FOR I IN P_WRK_LCDTRONL.V_LCTBS_TRACERS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_TRACERS.LAST LOOP
            IF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I)
             .TRACER_CODE = 'CHG_COM_TRACER' AND L_REIM_TYPE = 'Y' THEN
              DBG('CHG_COM_TRACER NOT ALLOWED FOR THE CONTRACT UNDER REIMB CLAIM......');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'BC-TR026', NULL);
            END IF;
          END LOOP;

        END IF;
      END IF;

      DBG('Collateral Pickup..');

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'LCCTRCLT',
                                                            L_SUBSYS_STAT);
      IF L_STAT = 'R' THEN
        DBG('Falied Collateral subsys pick up ......');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-LCLT-RDF', NULL);
      END IF;

      DBG('p_Action_Code' || P_ACTION_CODE);

      IF P_ACTION_CODE IN ('NEW') THEN

        L_ACT_ACTION := 'N';

      ELSIF P_ACTION_CODE IN ('HOLD') THEN
        L_ACT_ACTION := 'H';

      ELSE
        L_ACT_ACTION := 'M';

      END IF;

      IF P_FUNCTION_ID IN ('LCDAMEND', 'LIDAMEND') THEN
        L_ACT_ACTION := 'A';
      END IF;

      IF P_ACTION_CODE IN ('NEW', 'MODIFY', 'HOLD', 'ROPN') THEN

        DBG('l_Event_Seq_No' || L_EVENT_SEQ_NO);
        IF NOT LCPKS_COLL.FN_COLLATERALENTRYPOINT(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                  L_EVENT_SEQ_NO,
                                                  L_EVENT_CODE,
                                                  L_LATEST_VERSION_NO,
                                                  L_ACT_ACTION,
                                                  P_FUNCTION_ID,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
          DBG('failing in collatral pick up');
          L_PICKEDUP := FALSE;
          RETURN FALSE;

        END IF;

        DBG('TEST ' ||
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_CODE);

        DBG('l_Stat Before Validate' || L_STAT || ' l_Subsys_Stat >>' ||
            L_SUBSYS_STAT);

        DBG('TEST ' || P_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EXCH_RATE);
        DBG('TEST ' ||
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EXCH_RATE);
        DBG('TEST ' ||
            P_PREV_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EXCH_RATE);
        DBG('TEST ' ||
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_CODE);
        DBG('TEST ' ||
            P_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_CODE);

        IF P_SOURCE <> 'FLEXCUBE' THEN
          IF P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.CONTRACT_REF_NO IS NULL THEN
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
          END IF;

          IF P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_SEQ_NO IS NULL THEN
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_SEQ_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;
          END IF;

          IF P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_CODE IS NULL THEN
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_CODE := L_EVENT_CODE;
          END IF;

        END IF;

        BEGIN
          SELECT COLLATERAL_CCY,
                 COLLATERAL_AMT,
                 ADJUSTMENT_AMT,
                 ADJUSTMENT_SIGN
            INTO L_COL_CCY, L_COL_AMT, L_ADJ_AMT, L_ADJ_SIGN
            FROM LCTBS_COLLATERAL
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_COLLATERAL
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_COL_CCY  := NULL;
            L_COL_AMT  := 0;
            L_ADJ_AMT  := 0;
            L_ADJ_SIGN := NULL;

        END;

        DBG('adj amt: ' || L_ADJ_AMT);
        DBG('adj sign: ' || L_ADJ_SIGN);

        IF P_FUNCTION_ID IN ('LCDAMEND', 'LIDAMEND') AND
           L_EVENT_CODE = 'AMND' THEN

          BEGIN
            SELECT ADJUSTMENT_AMT, ADJUSTMENT_SIGN

              INTO L_ADJUSTMENT_AMT, L_ADJUSTMENT_SIGN

              FROM LCTBS_AMND_VALS_COLLATERAL
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
               AND AMND_SEQ_NO =
                   (SELECT MAX(AMND_SEQ_NO)
                      FROM LCTBS_AMND_VALS_COLLATERAL
                     WHERE CONTRACT_REF_NO =
                           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

          EXCEPTION
            WHEN OTHERS THEN
              DBG('failed to fetch from lctbs_amnd_vals_collateral' ||
                  SQLERRM);

          END;

          DBG('adj amt: ' || L_ADJUSTMENT_AMT);
          DBG('adj sign: ' || L_ADJUSTMENT_SIGN);

          IF L_ADJUSTMENT_AMT <> L_ADJ_AMT OR
             L_ADJUSTMENT_SIGN <> L_ADJ_SIGN THEN
            DBG('settign subsys stat to U');
            L_SUBSYS_STAT                                                 := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('LCCTRCLT',
                                                                                                                     'U',
                                                                                                                     L_SUBSYS_STAT);
            L_STAT                                                        := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                                                                                     'LCCTRCLT',
                                                                                                                     L_SUBSYS_STAT);
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY  := L_COL_CCY;
            P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_SEQ_NO    := L_EVENT_SEQ_NO;
            DBG(P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.CONTRACT_REF_NO || ' ' ||
                P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY || ' ' ||
                P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_SEQ_NO);
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY IS NOT NULL AND

           P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY =
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_CCY

         THEN
          DBG('defaulting exch rate to 1.');
          P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EXCH_RATE := 1;

        END IF;

        IF L_PICKEDUP AND L_STAT = 'U' AND
           NVL(P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.CONTRACT_REF_NO,
               P_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.CONTRACT_REF_NO) IS NOT NULL AND
           NVL(P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY,
               P_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY) IS NOT NULL AND
           NVL(P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_SEQ_NO,
               P_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EVENT_SEQ_NO) IS NOT NULL THEN
          DBG('Gng to validate ...');

          IF L_BOOL1 THEN

            DBG('test111' ||
                P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.EXCH_RATE);
            IF NOT LCPKS_LCCTRCLT_UTILS.FN_VALIDATE(P_SOURCE,
                                                    L_MODULE,
                                                    P_ACTION_CODE,
                                                    P_FUNCTION_ID,
                                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                    L_EVENT_SEQ_NO

                                                   ,
                                                    P_WRK_LCDTRONL.TY_LCCTRCLT

                                                   ,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
              DBG('Failed in Lcpks_Lcctrclt_Utils.Fn_Validate..');
              RETURN FALSE;
            END IF;

          END IF;
          IF NOT LCPKS_LCCTRCLT_UTILS.FN_UPLOAD(P_SOURCE,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO

                                               ,
                                                P_WRK_LCDTRONL.TY_LCCTRCLT

                                               ,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
            DBG('Failed in Lcpks_Fcj_Lcctrclt_Addon.Fn_Upload..');
            RETURN FALSE;
          END IF;

        END IF;

      END IF;

      DBG('Collateral l_stat' || L_STAT);
      IF L_STAT = 'R' THEN
        L_SUBSYS_STAT := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('LCCTRCLT',
                                                                 'S',
                                                                 L_SUBSYS_STAT);
      END IF;

      DBG('Tax Pickup..');

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'TACTRTAX',
                                                            L_SUBSYS_STAT);
      IF L_STAT = 'R' THEN
        DBG('Falied tax subsys pick up ......');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'TA-TTAX-RDF', NULL);
      END IF;

      IF NOT LCPKSS_IFACE.FN_DOTAXPICKUPANDCOMPUTE(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                   L_EVENT_SEQ_NO,
                                                   L_EVENT_CODE,
                                                   L_LATEST_VERSION_NO,
                                                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                                                   'N',
                                                   L_APP_DATE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN

        DBG('Failed in Lcpkss_Iface.Fn_Dotaxpickupandcompute');
        L_PICKEDUP := FALSE;
        RETURN FALSE;
      END IF;

      IF L_STAT = 'R' THEN

        L_SUBSYS_STAT := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('TACTRTAX',
                                                                 'S',
                                                                 L_SUBSYS_STAT);
      END IF;

      DBG('l_stat ' || L_STAT);

      IF P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE.COUNT > 0 THEN
        FOR INDX IN P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE.FIRST .. P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE.LAST LOOP
          DBG('Looping for the Component: ' || P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE(INDX)
              .BASIS_AMOUNT_TAG);
          L_COMPONENT       := P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE(INDX)
                               .BASIS_AMOUNT_TAG;
          L_BASIS_COMPONENT := SUBSTR(L_COMPONENT,
                                      1,
                                      (INSTR(L_COMPONENT, '_LIQD', -1)) - 1);
          IF L_BASIS_COMPONENT IS NULL THEN
            L_BASIS_COMPONENT := SUBSTR(L_COMPONENT,
                                        1,
                                        (INSTR(L_COMPONENT, '_LEQV', -1)) - 1);
          END IF;

          IF L_BASIS_COMPONENT IS NULL THEN
            L_BASIS_COMPONENT := L_COMPONENT;
          END IF;

          DBG('Getting the Waiver Status for the Derived Component: ' ||
              L_BASIS_COMPONENT);
          BEGIN
            SELECT WAIVER
              INTO L_WAIVER
              FROM CFTBS_CHARGE_APPLN
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
               AND EVENT_SEQ_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO
               AND COMPONENT = L_BASIS_COMPONENT;

            DBG('--l_Waiver--' || L_WAIVER || '---p_Component--' ||
                L_BASIS_COMPONENT);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('NOT A TAX ON CHARGE,CHECK FOR COMMISSION');
              BEGIN
                SELECT WAIVER
                  INTO L_WAIVER
                  FROM CFTB_CONTRACT_COMMISSION
                 WHERE CONTRACT_REFERENCE_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                   AND EVENT_SEQ_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO
                   AND COMPONENT = L_BASIS_COMPONENT;

                DBG('--l_Waiver--' || L_WAIVER || '---p_Component--' ||
                    L_BASIS_COMPONENT);
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('NOT A TAX ON COMMISSION AS WELL');
                  L_WAIVER := 'N';

              END;

          END;

          DBG('p_wrk_lcdtronl.ty_tactrtax.v_tatbs_txnrule(indx).waiver ' || P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE(INDX)
              .WAIVER);
          DBG('p_lcdtronl.ty_tactrtax.v_tatbs_txnrule(indx).waiver ' || P_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE(INDX)
              .WAIVER);
          DBG('l_waiver' || L_WAIVER);
          L_WRK_WAIVE := P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE(INDX)
                         .WAIVER;

          DBG('Charge/Commission is Waived, thus applying the same to tax');
          P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_TXNRULE(INDX).WAIVER := L_WAIVER;

        END LOOP;

      END IF;

      IF L_PICKEDUP AND L_STAT = 'U' AND
         P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_MAINTXN.CONTRACT_REF_NO IS NOT NULL AND
         P_WRK_LCDTRONL.TY_TACTRTAX.V_TATBS_MAINTXN.SCHEME IS NOT NULL THEN

        DBG('Tax validations....');

        IF NOT TAPKS_TACTRTAX_UTILS.FN_VALIDATE(P_SOURCE,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.TY_TACTRTAX,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
          DBG('Failed in Cfpks_Fcj_Cfctrchg_Addon.Fn_Validate..');
          RETURN FALSE;
        END IF;

        IF NOT TAPKS_TACTRTAX_UTILS.FN_UPLOAD(P_SOURCE,
                                              L_MODULE,
                                              P_ACTION_CODE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_EVENT_SEQ_NO,
                                              P_WRK_LCDTRONL.TY_TACTRTAX,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in Tapks_Fcj_Tactrtax_Addon.Fn_Upload..');
          RETURN FALSE;
        END IF;

      END IF;

      DBG('MIS Pick up.....');

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'MICTRMIS',
                                                            L_SUBSYS_STAT);
      IF L_STAT = 'R' THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'MI-CMIS-RDF', NULL);
      END IF;

      IF NOT
          MIPKSS_REFERRAL.FN_GET_CON_DEFAULT(GLOBAL.CURRENT_BRANCH,
                                             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY) THEN
        DBG('failed in mipkss_referral.fn_get_con_default');

        OVPKS.PR_APPENDTBL('LCUPLD-100',
                           'mipkss_referral.fn_get_con_default');
        RETURN FALSE;
      END IF;

      IF L_STAT = 'R' THEN

        L_SUBSYS_STAT := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('MICTRMIS',
                                                                 'S',
                                                                 L_SUBSYS_STAT);
      END IF;

      IF L_STAT NOT IN ('U', 'S') THEN
        IF NOT MIPKS_MICTRMIS_MAIN.FN_QUERY(P_SOURCE,
                                            P_SOURCE_OPERATION,
                                            'MICTRMIS',
                                            P_ACTION_CODE,
                                            P_FUNCTION_ID,
                                            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                            'N',
                                            P_LCDTRONL.TY_MICTRMIS,
                                            P_WRK_LCDTRONL.TY_MICTRMIS,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
          DBG('Failed in Mipks_Mictrmis_Main. Fn_Query..');
          RETURN FALSE;
        END IF;

      ELSIF P_SOURCE NOT IN ('FLEXCUBE', 'FCAT') THEN
        BEGIN
          SELECT BRANCH_CODE, UNIT_REF_NO, UNIT_TYPE
            INTO P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.BRANCH_CODE,
                 P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.UNIT_REF_NO,
                 P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.UNIT_TYPE
            FROM MITBS_CLASS_MAPPING
           WHERE UNIT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In When others of selecting the Unit Ref no');
        END;

        DBG('p_Wrk_Lcdtronl.Ty_Mictrmis.v_Mitbs_Class_Mapping.branch_code::' ||
            P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.BRANCH_CODE);
        DBG('p_Wrk_Lcdtronl.Ty_Mictrmis.v_Mitbs_Class_Mapping.Unit_Ref_No::' ||
            P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.UNIT_REF_NO);
        DBG('p_Wrk_Lcdtronl.Ty_Mictrmis.v_Mitbs_Class_Mapping.unit_type::' ||
            P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.UNIT_TYPE);

      END IF;

      IF L_PICKEDUP AND
         P_WRK_LCDTRONL.TY_MICTRMIS.V_MITBS_CLASS_MAPPING.UNIT_REF_NO IS NOT NULL THEN
        IF NVL(SUBSTR(CSPKS_REQ_WRAPPER.G_ACTION_CODE,
                      1,
                      LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)),
               'XXX') <> CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP THEN

          DBG('Calling validations');
          IF NOT MIPKS_MICTRMIS_UTILS.FN_VALIDATE(P_SOURCE,
                                                  L_MODULE,
                                                  P_ACTION_CODE,
                                                  P_FUNCTION_ID,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                  L_EVENT_SEQ_NO,
                                                  P_WRK_LCDTRONL.TY_MICTRMIS,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in validate');
            RETURN FALSE;
          END IF;

        END IF;

        IF L_STAT = 'U' THEN

          DBG('Calling  Mipks_mictrmis_utils.Fn_Upload..');
          IF NOT MIPKS_MICTRMIS_UTILS.FN_UPLOAD(P_SOURCE,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.TY_MICTRMIS,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
            DBG('Failed in mipks_mictrmis_utils.Fn_Upload..');
            RETURN FALSE;
          END IF;

        END IF;
      END IF;

      DBG('Advice Pickup..');

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'CVS_MAIN__TAB_ADVICES',
                                                            L_SUBSYS_STAT);
      IF L_STAT = 'R' THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CS-CADF-RDF', NULL);
      END IF;

      DBG('p_wrk_lcdtronl.v_contract_event_advice.COUNT::' ||
          P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT);
      DBG('l_stat::' || L_STAT);

      IF NOT LCPKS_LCDTRONL_UTILS.FN_PICKUP_ADVICES(P_SOURCE,
                                                    P_ACTION_CODE,
                                                    P_FUNCTION_ID,
                                                    L_PRODUCT,
                                                    L_FCC_REF,
                                                    L_EVENT_SEQ_NO,
                                                    L_LATEST_VERSION_NO,
                                                    L_EVENT_CODE,
                                                    L_CPARTY,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Pickup_Advices ');
        L_PICKEDUP := FALSE;
        RETURN FALSE;

      END IF;

      IF L_STAT = 'R' THEN

        L_SUBSYS_STAT := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('CVS_MAIN__TAB_ADVICES',
                                                                 'S',
                                                                 L_SUBSYS_STAT);
      END IF;

      DBG('SUBSYSSTAT AFTER ADVICE PICKUP : ' || L_SUBSYS_STAT);

      IF L_PICKEDUP

       THEN

        FOR L_REC_COUNTER IN 1 .. P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT LOOP
          DBG('Inc Flag: ' ||
              P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92);
          DBG('MSG_TYPE: ' || P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(L_REC_COUNTER)
              .MSG_TYPE);
          DBG('Suppress flag: ' || P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(L_REC_COUNTER)
              .SUPPRESS);
          IF (NOT G_INCR_AMND_NO AND P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(L_REC_COUNTER)
             .MSG_TYPE = 'LC_AMND_INSTR') AND L_EVENT_CODE = 'AMND' AND P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(L_REC_COUNTER)
            .SUPPRESS = 'N' THEN

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG = 'Y' THEN
              DBG('Anc mesg is checked so surpassing the overide');
            ELSE

              DBG('Override for Increment Amendment Number: LC-AMND-01');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-AMND-01', NULL);
            END IF;
          END IF;

        END LOOP;

        IF L_STAT = 'U' THEN

          IF NOT LCPKS_LCDTRONL_UTILS.FN_UPLOAD_ADVICES(P_SOURCE,
                                                        P_FUNCTION_ID,
                                                        P_ACTION_CODE,
                                                        L_FCC_REF,
                                                        L_EVENT_SEQ_NO,
                                                        P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
            DBG('Failed in Fn_Pickup_Advices ');
            L_PICKEDUP := FALSE;
            RETURN FALSE;
          END IF;

        END IF;

        IF L_STAT = 'U'

         THEN
          BEGIN
            DBG('l_event_seq_no===>>>' || L_EVENT_SEQ_NO);
            DBG('l_fcc_ref===>>>' || L_FCC_REF);

            DELETE LCTB_FFTS
             WHERE CONTRACT_REF_NO = L_FCC_REF
               AND EVENT_SEQ_NO = L_EVENT_SEQ_NO;

            DBG('Inserting into LCTBS_FFTS..' ||
                P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT);

            L_COUNT := P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT;
            DBG('l_count===>>>' || L_COUNT);

            FORALL L_INDEX IN 1 .. L_COUNT
              INSERT INTO LCTB_FFTS
              VALUES P_WRK_LCDTRONL.V_LCTBS_FFTS
                (L_INDEX);

          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Insert into LCTBS_FFTS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_FFTS';
              RETURN FALSE;

          END;

        END IF;

      END IF;

      L_COUNT := P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT;

      DBG('Settlement Pickup..');

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'ISCTRSTL',
                                                            L_SUBSYS_STAT);

      IF L_STAT = 'R' THEN
        DBG('Falied Settelemnnt subsys pick up ......');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IS-ISTL-RDF', NULL);
      END IF;

      IF NOT LCPKSS_IFACE.FN_DOSETLPICKUP(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                                          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                          L_EVENT_CODE,
                                          L_APP_DATE,
                                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS) THEN

        DBG('Failed in Lcpkss_Iface.Fn_Dosetlpickup');
        L_PICKEDUP := FALSE;

        IF P_ERR_CODE IS NULL THEN
          P_ERR_CODE := 'IS-RES01';
        END IF;

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, NULL);

        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE = 'AMND' THEN
        DBG('Calling Lcpks_Comm_Service.Fn_Comm_Main..');
        IF NOT LCPKS_COMM_SERVICE.FN_COMM_MAIN('RCOM',
                                               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                               L_EVENT_SEQ_NO,
                                               L_EVENT_SEQ_NO,
                                               'AMND',
                                               L_APP_DATE,
                                               L_ZERO,
                                               P_ERR_CODE) THEN
          DBG('Failed in Lcpks_Comm_Service.Fn_Comm_Main');
          L_PICKEDUP := FALSE;
          RETURN FALSE;
        END IF;

      END IF;

      IF L_STAT = 'R' THEN

        L_SUBSYS_STAT := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('ISCTRSTL',
                                                                 'S',
                                                                 L_SUBSYS_STAT);
      END IF;
      IF L_PICKEDUP AND L_STAT = 'U' AND
         P_WRK_LCDTRONL.TY_ISCTRSTL.V_ISTBS_CONTRACTIS__CONIS.COUNT > 0 THEN

        DBG('Its cm ghere ....');
        IF NOT ISPKS_ISCTRSTL_UTILS.FN_VALIDATE(P_SOURCE,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.TY_ISCTRSTL,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
          DBG('Failed in Ispks_Fcj_Isctrstl_Addon.Fn_Validate..');

          IF P_ERR_CODE IS NULL THEN
            P_ERR_CODE := 'LCUPLD-225';
          END IF;

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, NULL);

          RETURN FALSE;
        END IF;

        IF NOT ISPKS_ISCTRSTL_UTILS.FN_UPLOAD(P_SOURCE,
                                              L_MODULE,
                                              P_ACTION_CODE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_EVENT_SEQ_NO,
                                              P_WRK_LCDTRONL.TY_ISCTRSTL,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in Ispks_Fcj_Isctrstl_Addon.Fn_Upload..');
          RETURN FALSE;
        END IF;

      END IF;

      DBG('linkages pick up');
      DBG('--------------------');
      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'CSCTRLNK',
                                                            L_SUBSYS_STAT);

      IF L_STAT = 'R' THEN

        DBG('Falied link subsys pick up ......');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CS-CLNK-RDF', NULL);
      END IF;

      DBG('Calling Linkage Validations ...');
      IF NOT CSPKS_CSCTRLNK_UTILS.FN_VALIDATE(P_SOURCE,
                                              L_MODULE,
                                              P_ACTION_CODE,
                                              P_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_EVENT_SEQ_NO,
                                              P_WRK_LCDTRONL.TY_CSCTRLNK,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
        DBG('Failed in validations');
        RETURN FALSE;
      ELSE

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL AND
           L_PRODUCT_TYPE = 'H' THEN
          IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
            DBG('Calling Linkage Validations for LC linkage  ...');
            IF NOT CSPKS_CSCTRLNK_UTILS.FN_UPLOAD(P_SOURCE,
                                                  L_MODULE,
                                                  P_ACTION_CODE,
                                                  P_FUNCTION_ID,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                  L_EVENT_SEQ_NO,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                                  P_WRK_LCDTRONL.TY_CSCTRLNK,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
              DBG('Failed in Upload. FOR LC');
              RETURN FALSE;
            END IF;

          END IF;

        ELSE

          DBG('Calling Linkages Upload...');
          IF NOT CSPKS_CSCTRLNK_UTILS.FN_UPLOAD(P_SOURCE,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                P_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.TY_CSCTRLNK,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
            DBG('Failed in Upload..');
            RETURN FALSE;
          END IF;

        END IF;

      END IF;

      IF L_PRODUCT_TYPE = 'H' THEN

        DBG('------------------------------');
        DBG('Pick up Loan preferences......');

        L_PICKEDUP := TRUE;
        L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                              'BCCTRPRF',
                                                              L_SUBSYS_STAT);

        IF L_STAT = 'R' THEN

          DBG('Falied Loan subsys pick up ......');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CS-TPRF-RDF', NULL);
        END IF;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.COLLAT_LOAN_ALLOWED,
               'N') = 'Y' THEN
          DBG('Pick up the  preferences....');
          IF NOT FN_PICK_LOAN_PREFERENCE(P_SOURCE,
                                         P_FUNCTION_ID,
                                         P_ACTION_CODE,
                                         P_SOURCE_OPERATION,
                                         P_LCDTRONL,
                                         P_PREV_LCDTRONL,
                                         P_WRK_LCDTRONL,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN

            DBG('Falied in the pick up loan preferences......');
          END IF;

          IF NOT FN_PICK_LOAN_ICCF(P_SOURCE,
                                   P_FUNCTION_ID,
                                   P_ACTION_CODE,
                                   P_SOURCE_OPERATION,
                                   P_LCDTRONL,
                                   P_PREV_LCDTRONL,
                                   P_WRK_LCDTRONL,
                                   L_LOAN_PRODUCT,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
            DBG('Falied in the pick up loan iccf......');
          END IF;

          IF L_STAT = 'R' THEN

            L_SUBSYS_STAT := BCPKS_BCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('BCCTRPRF',
                                                                     'S',
                                                                     L_SUBSYS_STAT);
          END IF;
          DBG('l_stat >>' || L_STAT);
          IF L_PICKEDUP AND L_STAT = 'U' THEN

            DBG('Validate');
            IF NOT
                BCPKS_BCCTRPRF_UTILS.FN_VALIDATE_LOAN_PREFERENCES(P_SOURCE,
                                                                  L_MODULE,
                                                                  P_ACTION_CODE,
                                                                  L_FUNCTION_ID,
                                                                  P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                                  L_EVENT_SEQ_NO,
                                                                  P_WRK_LCDTRONL.TY_BCCTRPRF,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
              DBG('Failed in Cfpks_Fcj_Cfctrchg_Addon.Fn_Validate..');
              RETURN FALSE;
            END IF;

            IF NOT
                BCPKS_BCCTRPRF_UTILS.FN_VALIDATE_LOAN_ICCF(P_SOURCE,
                                                           L_MODULE,
                                                           P_ACTION_CODE,
                                                           L_FUNCTION_ID,
                                                           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                           L_EVENT_SEQ_NO,
                                                           P_WRK_LCDTRONL.TY_BCCTRPRF,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
              DBG('Failed in Cfpks_Fcj_Cfctrchg_Addon.Fn_Validate..');
              RETURN FALSE;
            END IF;

            DBG('Upload of loan preferences .....');

            IF NOT
                BCPKS_BCCTRPRF_UTILS.FN_UPLOAD_LOAN_PREFERENCES(P_SOURCE,
                                                                L_MODULE,
                                                                P_ACTION_CODE,
                                                                L_FUNCTION_ID,
                                                                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                                L_EVENT_SEQ_NO,
                                                                P_WRK_LCDTRONL.TY_BCCTRPRF,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAMS) THEN
              DBG('Failed in Tapks_Fcj_Tactrtax_Addon.Fn_Upload..');
              RETURN FALSE;
            END IF;

            DBG('Upload of loan iccf....');
            IF NOT BCPKS_BCCTRPRF_UTILS.FN_UPLOAD_LOAN_ICCF(P_SOURCE,
                                                            L_MODULE,
                                                            P_ACTION_CODE,
                                                            L_FUNCTION_ID,
                                                            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                            L_EVENT_SEQ_NO,
                                                            P_WRK_LCDTRONL.TY_BCCTRPRF,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
              DBG('Failed in Tapks_Fcj_Tactrtax_Addon.Fn_Upload..');
              RETURN FALSE;
            END IF;

          END IF;

        END IF;

        DBG('Loan preferences and iccf ends....');

        DBG('Split Settlement Pick up...');
        DBG('--------------------');

        L_PICKEDUP := TRUE;
        L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                              'CSCTRSPT',
                                                              L_SUBSYS_STAT);

        IF L_STAT = 'R' THEN

          DBG('Falied Split subsys pick up ......');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CS-RSPT-RDF', NULL);
        END IF;

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
          DBG('Calling cspkss_split.fn_create_split_master for COLL_AMT_INCR..... ');

          IF NOT CSPKSS_SPLIT.FN_CREATE_SPLIT_MASTER(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                     L_EVENT_SEQ_NO,
                                                     'BISS',
                                                     'COLL_AMT_INCR',

                                                     P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY,

                                                     '',
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
            DBG('Cspkss_Split.Fn_Create_Split_Master..');
            RETURN FALSE;
          END IF;

        END IF;

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
          DBG('Calling cspkss_split.fn_create_split_master for COLL_AMNDAMT..... ');
          IF NOT CSPKSS_SPLIT.FN_CREATE_SPLIT_MASTER(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                     L_EVENT_SEQ_NO,
                                                     'AMND',
                                                     'COLL_AMNDAMT',

                                                     P_WRK_LCDTRONL.TY_LCCTRCLT.V_LCTBS_COLLATERAL.COLLATERAL_CCY,

                                                     '',
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
            DBG('Cspkss_Split.Fn_Create_Split_Master..');
            RETURN FALSE;
          END IF;

        END IF;

        DBG('Selecting Adjustment_Amt for split master updation..... ');

        IF L_STAT = 'R' THEN

          L_SUBSYS_STAT := LCPKS_LCDTRONL_UTILS.FN_UPD_SUBSYS_STAT('CSCTRSPT',
                                                                   'S',
                                                                   L_SUBSYS_STAT);
        END IF;

        DBG('l_stat ' || L_STAT || ' v_cstbs_split_tag_detail COUNT ' ||
            P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_SPLIT_TAG_DETAIL.COUNT);
        IF L_PICKEDUP AND L_STAT = 'U' AND
           P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_SPLIT_TAG_DETAIL.COUNT > 0 THEN
          DBG('Validate the split detail');
          IF NOT CSPKS_CSCTRSPT_UTILS.FN_VALIDATE(P_SOURCE,
                                                  P_FUNCTION_ID,
                                                  L_MODULE,
                                                  P_ACTION_CODE,
                                                  L_FUNCTION_ID,
                                                  P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                  L_EVENT_SEQ_NO,
                                                  P_WRK_LCDTRONL.TY_CSCTRSPT,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in validate of csctrspt');
            RETURN FALSE;
          END IF;

          DBG('Upload both the tables--masster and detail ...');

          IF NOT CSPKS_CSCTRSPT_UTILS.FN_UPLOAD(P_SOURCE,
                                                P_FUNCTION_ID,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                L_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.TY_CSCTRSPT,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
            DBG('Failed in upload of the csctrspt');
            RETURN FALSE;
          END IF;

        END IF;

      END IF;

      DBG('UDF PCIKUP');

      L_PICKEDUP := TRUE;
      L_STAT     := FN_GET_SUBSYS_STAT(P_SOURCE, 'CSCTRUDF', L_SUBSYS_STAT);

      IF L_STAT = 'R' THEN

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CS-CUDF-RDF', NULL);
      END IF;

      IF NOT UVPKSS_UDF_UPLOAD.FN_PICKUP_CONT_UDF(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                  L_MODULE,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN

        DBG('Failed in Uvpkss_Udf_Upload.Fn_Pickup_Cont_Udf..');
        L_PICKEDUP := FALSE;
        RETURN FALSE;
      END IF;

      IF L_STAT = 'R' THEN

        L_SUBSYS_STAT := FN_UPD_SUBSYS_STAT('CSCTRUDF', 'S', L_SUBSYS_STAT);
      END IF;

      IF L_MODULE = 'LC' THEN
        L_ORG_ACTION := SUBSTR(LCPKS_LCDTRONL_MAIN.FN_GET_ORIGINAL_ACTION,
                               1,
                               LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP));
      ELSIF L_MODULE = 'LI' THEN
        L_ORG_ACTION := SUBSTR(LIPKS_LIDTRONL_MAIN.FN_GET_ORIGINAL_ACTION,
                               1,
                               LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP));
      END IF;
      DBG('l_org_action' || L_ORG_ACTION);

      DBG('cspks_req_global.p_subsyspickup' ||
          CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP);
      DBG('cspks_req_wrapper.g_action_code' ||
          CSPKS_REQ_WRAPPER.G_ACTION_CODE);
      IF L_STAT NOT IN ('U', 'S')

         AND ((L_ORG_ACTION <> CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)

         OR SUBSTR(CSPKS_REQ_WRAPPER.G_ACTION_CODE,
                        1,
                        LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) <>
         CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)

       THEN
        IF UVPKS_UDF_UPLOAD.FN_QUERY_CONT_UDFDETAILS('LCDTRONL',
                                                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                     L_UDF_TBL,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS)

         THEN
          IF P_ACTION_CODE = 'NEW'

             AND L_UDF_TBL.COUNT <> 0 THEN

            DBG('p_source is :' || P_SOURCE);
            IF P_SOURCE NOT IN ('FLXECUBE', 'FCAT') AND
               P_WRK_LCDTRONL.TXN_UDF_DETAILS.COUNT <> 0 THEN
              DBG('No need to assign the default values');
            ELSE
              DBG('Goin to assign to the default values');

              P_WRK_LCDTRONL.TXN_UDF_DETAILS := L_UDF_TBL;
            END IF;
          END IF;
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.TXN_UDF_DETAILS.COUNT > 0

       THEN

        IF SUBSTR(CSPKS_REQ_WRAPPER.G_ACTION_CODE,
                  1,
                  LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) <>
           CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP OR
           (L_ORG_ACTION <> CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP) THEN

          IF NOT UVPKS_UDF_UPLOAD.FN_VALIDATE_CONTRACT_UDF(P_WRK_LCDTRONL.TXN_UDF_DETAILS,
                                                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                           L_EVENT_CODE,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
            DBG('Failed in Uvpks_Udf_Upload.Fn_Validate_Contract_Udf..');
            RETURN FALSE;

          END IF;

        END IF;

        BEGIN
          SELECT NVL(MAX(VERSION_NO), 1)
            INTO L_VERSION_NO
            FROM CSTMS_CONTRACT_USERDEF_FIELDS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed While Selecting the latest version from cstms_contract_userdef_fields');
            DBG(SQLERRM);
            L_VERSION_NO := 1;

        END;

        IF NOT
            UVPKSS_UDF_UPLOAD.FN_CONTRACT_UDF_UPLOAD_TYPE(P_SOURCE,
                                                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO,
                                                          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                          L_VERSION_NO,
                                                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                                                          P_ACTION_CODE,
                                                          P_WRK_LCDTRONL.TXN_UDF_DETAILS,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN

          DBG('Failed in Uvpkss_Udf_Upload.Fn_Contract_Udf_Upload_Type ');
          L_PICKEDUP := FALSE;
          RETURN FALSE;
        END IF;

      END IF;

      DBG('Brokerage Pick up');

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'BCCBRDET',
                                                            L_SUBSYS_STAT);
      IF L_STAT = 'R' THEN
        DBG('Falied Settelemnnt subsys pick up ......');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'BC-BROK-RDF', NULL);
      END IF;

      IF P_WRK_LCDTRONL.TY_BCCBRDET.V_BCTBS_BROK_DETAIL.COUNT > 0 THEN
        DBG('It has come here...');
        IF NOT BCPKS_BCCBRDET_UTILS.FN_VALIDATE(P_SOURCE,
                                                L_MODULE,
                                                P_ACTION_CODE,
                                                L_FUNCTION_ID,
                                                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                L_EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.TY_BCCBRDET,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
          DBG('Failed in bcpks_bccbrdet_utils.fn_validate..');
          RETURN FALSE;
        END IF;

        IF NOT BCPKS_BCCBRDET_UTILS.FN_UPLOAD(P_SOURCE,
                                              L_MODULE,
                                              P_ACTION_CODE,
                                              L_FUNCTION_ID,
                                              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_EVENT_SEQ_NO,
                                              P_WRK_LCDTRONL.TY_BCCBRDET,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in bcpks_bccbrdet_utils.fn_upload..');
          RETURN FALSE;
        END IF;

      END IF;

      DBG('before calling document upload..');
      DBG('GSK :: p_Action_Code :' || P_ACTION_CODE);

      DBG('Key ID : ' ||
          P_WRK_LCDTRONL.TY_CSCDOCTR.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);

      P_WRK_LCDTRONL.TY_CSCDOCTR.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID := GLOBAL.CURRENT_BRANCH || ':' ||
                                                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
      DBG('After Key ID : ' ||
          P_WRK_LCDTRONL.TY_CSCDOCTR.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);

      P_PREV_CSCDOCTR := P_PREV_LCDTRONL.TY_CSCDOCTR;
      IF CSPKS_REQ_GLOBAL.P_MODIFY = P_ACTION_CODE OR
         P_PREV_CSCDOCTR.V_CSTB_DOC_UPLOAD_DETAIL.COUNT > 0 THEN
        P_WRK_CSCDOCTR := P_LCDTRONL.TY_CSCDOCTR;
      ELSE
        P_WRK_CSCDOCTR := P_WRK_LCDTRONL.TY_CSCDOCTR;

      END IF;

      DBG('COUNT@' || P_PREV_CSCDOCTR.V_CSTB_DOC_UPLOAD_DETAIL.COUNT);
      IF P_PREV_CSCDOCTR.V_CSTB_DOC_UPLOAD_DETAIL.COUNT > 0

         OR (CSPKS_REQ_GLOBAL.P_MODIFY = P_ACTION_CODE AND
         P_WRK_LCDTRONL.TY_CSCDOCTR.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID IS NOT NULL AND
         P_WRK_CSCDOCTR.V_CSTB_DOC_UPLOAD_DETAIL.COUNT > 0)

       THEN

        IF NOT CSPKS_CSCDOCTR_UTILS.FN_UPLOAD(P_SOURCE,
                                              P_SOURCE_OPERATION,
                                              P_FUNCTION_ID,
                                              'MODIFY',
                                              'LCDTRONL',
                                              P_CSCDOCTR,
                                              P_PREV_CSCDOCTR,
                                              P_WRK_CSCDOCTR,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in mipks_mictrmis_utils.Fn_Upload..');
          RETURN FALSE;
        END IF;

      ELSE
        IF NOT CSPKS_CSCDOCTR_UTILS.FN_UPLOAD(P_SOURCE,
                                              P_SOURCE_OPERATION,
                                              P_FUNCTION_ID,
                                              P_ACTION_CODE,
                                              'LCDTRONL',
                                              P_CSCDOCTR,
                                              P_PREV_CSCDOCTR,
                                              P_WRK_CSCDOCTR,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in mipks_mictrmis_utils.Fn_Upload..');
          RETURN FALSE;
        END IF;

      END IF;

      L_PICKEDUP := TRUE;
      L_STAT     := LCPKS_LCDTRONL_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                            'MSCCOMPM',
                                                            L_SUBSYS_STAT);
      DBG('MSCCOMPM STATUS' || L_STAT);
      IF L_STAT = 'D' THEN
        P_WRK_LCDTRONL.TY_MSCCOMPM := NULL;
        BEGIN
          SELECT USE_USERREF_IN_MSGS
            INTO L_USERREF_IN_MSGS
            FROM LCTM_BRANCH_PARAMETERS
           WHERE BRANCH = GLOBAL.CURRENT_BRANCH;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('failed in querying Bc branch paramater ');
        END;
        DBG('l_userref_in_msgs' || L_USERREF_IN_MSGS);
        IF L_USERREF_IN_MSGS = 'Y' THEN
          BEGIN
            SELECT USER_REF_NO
              INTO P_WRK_LCDTRONL.TY_MSCCOMPM.V_MSTBS_COMMSG_DETAIL.TAG_20
              FROM CSTBS_CONTRACT
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Contract reference number not available in flexcube');
          END;
        ELSE
          P_WRK_LCDTRONL.TY_MSCCOMPM.V_MSTBS_COMMSG_DETAIL.TAG_20 := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
        END IF;
        DBG('p_wrk_lcdtronl.ty_msccompm.v_mstbs_commsg_detail.tag_20' ||
            P_WRK_LCDTRONL.TY_MSCCOMPM.V_MSTBS_COMMSG_DETAIL.TAG_20);
      END IF;

      IF L_STAT = 'U' AND
         P_WRK_LCDTRONL.TY_MSCCOMPM.V_MSTBS_COMMSG_MASTER.SWIFT_MSG_TYPE IS NOT NULL THEN
        DBG('validating common group message');
        IF NOT MSPKS_MSCCOMPM_UTILS.FN_VALIDATE(P_SOURCE,
                                                P_SOURCE_OPERATION,
                                                P_FUNCTION_ID,
                                                P_ACTION_CODE,
                                                P_WRK_LCDTRONL.TY_MSCCOMPM,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN
          DBG('Failed in common message group
               Fn_upload');
          RETURN FALSE;
        END IF;

        DBG('Upload common message group');
        IF NOT MSPKS_MSCCOMPM_UTILS.FN_UPLOAD(P_SOURCE,
                                              P_SOURCE_OPERATION,
                                              P_FUNCTION_ID,
                                              P_ACTION_CODE,
                                              P_WRK_LCDTRONL.TY_MSCCOMPM,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_EVENT_SEQ_NO,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in common message group
               Fn_upload');
          RETURN FALSE;
        END IF;
      END IF;

      DBG(' Based the susbsystemm status the  screen  will be shown, so this update is needed');
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT := L_SUBSYS_STAT;
      BEGIN
        UPDATE LCTB_CONTRACT_MASTER
           SET SUBSYSTEMSTAT = L_SUBSYS_STAT
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_SEQ_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Updation Failed ' || SQLERRM);

      END;

      DBG('Setting the status' || L_SUBSYS_STAT);
    END IF;

    DBG('Returning from Fn_Subsys_Pickup');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      DEBUG.PR_DEBUG('**', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_SUBSYS_PICKUP;

  FUNCTION FN_PROCESS(P_SOURCE           IN VARCHAR2,
                      P_SOURCE_OPERATION IN VARCHAR2,
                      P_FUNCTION_ID      IN VARCHAR2,
                      P_ACTION_CODE      IN VARCHAR2,
                      P_MULTI_TRIP_ID    IN VARCHAR2,
                      P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                      P_PREV_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                      P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                      P_ERR_CODE         IN OUT VARCHAR2,
                      P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_TAG_LIST              VARCHAR2(2000);
    L_TAG_CCY_LIST          VARCHAR2(2000);
    L_PAY_RECEIVE_LIST      VARCHAR2(2000);
    L_ACCOUNT_LIST          VARCHAR2(2000);
    L_AC_BRANCH_LIST        VARCHAR2(2000);
    L_ACC_CCY_LIST          VARCHAR2(2000);
    L_EX_RATE_LIST          VARCHAR2(2000);
    L_SETTLEMENT_AMT_LIST   VARCHAR2(2000);
    L_VALUE_DATE_LIST       VARCHAR2(2000);
    L_PAYMENT_BY_LIST       VARCHAR2(2000);
    L_TRANSFER_TYPE_LIST    VARCHAR2(2000);
    L_INSTR_TYPE_LIST       VARCHAR2(2000);
    L_INSTR_NO_LIST         VARCHAR2(2000);
    L_COVER_REQD_LIST       VARCHAR2(2000);
    L_CHARGES_DETAILS_LIST  VARCHAR2(2000);
    L_OUR_CORRESP_LIST      VARCHAR2(2000);
    L_RECEIVER_LIST         VARCHAR2(2000);
    L_INT_REIM_INST_LIST    VARCHAR2(2000);
    L_RCVR_CORRESP_LIST     VARCHAR2(2000);
    L_INTERMEDIARY_LIST     VARCHAR2(2000);
    L_ACC_WITH_INSTN_LIST   VARCHAR2(2000);
    L_PAY_DETAILS_LIST      VARCHAR2(2000);
    L_SNDR_TO_RCVR_LIST     VARCHAR2(2000);
    L_ORDERING_INST_LIST    VARCHAR2(2000);
    L_ORDERING_CUST_LIST    VARCHAR2(2000);
    L_BENEF_INST_LIST       VARCHAR2(2000);
    L_ULT_BENEF_LIST        VARCHAR2(2000);
    L_DELTALCAMT            NUMBER;
    L_DELTAMAXLCAMT         NUMBER;
    L_DELTAMAXLIABILITYAMT  NUMBER;
    L_DELTACOLLATERALAMT    NUMBER;
    L_OLDOPER               VARCHAR2(3);
    L_NEWOPER               VARCHAR2(3);
    L_APP_DATE              DATE := GLOBAL.APPLICATION_DATE;
    N                       NUMBER(10);
    L_ACCREC                STTBS_ACCOUNT%ROWTYPE;
    L_ANACC                 STTBS_ACCOUNT.AC_GL_NO%TYPE;
    L_ANDRCR                ISTBS_CONTRACTIS.PAY_RECEIVE%TYPE;
    L_ANBRN                 STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_COUNT_PROD            NUMBER;
    L_COUNT_PROD1           NUMBER;
    L_WRK_LCDTRONL          LCPKS_LCDTRONL_MAIN.TY_LCDTRONL;
    L_USER_ID               SMTB_USER.USER_ID%TYPE := GLOBAL.USER_ID;
    L_STATUS                VARCHAR2(2);
    L_COUNT                 NUMBER := 0;
    L_EVT_CODE              CSTB_CONTRACT.CURR_EVENT_CODE%TYPE;
    L_REL_REF_NO            LCTB_AVAILMENTS.RELATED_REF_NO%TYPE;
    L_LCMASTERRECORD        LCTBS_CONTRACT_MASTER%ROWTYPE;
    L_LCSHIPMENTRECORD      LCTBS_SHIPMENT%ROWTYPE;
    L_LCAVAILMENTRECORD     LCTBS_AVAILMENTS%ROWTYPE;
    L_LCPRODUCTRECORD       LCTMS_PRODUCT_DEFINITION%ROWTYPE;
    L_LCCOLLATERALRECORD    LCTBS_COLLATERAL%ROWTYPE;
    L_ESN                   CSTBS_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE;
    LSTSTATICTAG            VARCHAR2(32767);
    LSTSTATICAMT            VARCHAR2(32767);
    LSTSTATICCCY            VARCHAR2(32767);
    LSTSTATICLCYAMT         VARCHAR2(32767);
    LSTSTATICVALUEDATE      VARCHAR2(32767);
    LSTSTATICRATE           VARCHAR2(32767);
    TAGPOSN                 INTEGER;
    TAGAMOUNT               VARCHAR2(100);
    TAGCCY                  VARCHAR2(3);
    TAGVALUEDATE            VARCHAR2(100);
    TAGLCYAMOUNT            VARCHAR2(100);
    L_APPDATE               DATE := GLOBAL.CONVERSION_DATE;
    L_LOG_REC               CSTBS_CONTRACT_EVENT_LOG%ROWTYPE;
    L_PREV_LCDTRONL         LCPKS_LCDTRONL_MAIN.TY_LCDTRONL;
    L_LCBTS_CONTRACT_MASTER LCTBS_CONTRACT_MASTER%ROWTYPE;
    L_REF_NO                VARCHAR2(100);
    L_USER_REF_NO           VARCHAR2(100);
    L_ERR_CODE              VARCHAR2(11);
    L_LINKAGE_REC           LMTM_POOL_COLLATERAL_LINKAGES%ROWTYPE;
    L_MODE                  VARCHAR2(1);
    L_LIAB_ID               VARCHAR2(9);
    L_OS_AMOUNT             NUMBER;
    L_AVAILMENT_AMT         NUMBER;
    L_REVERSED_AMT          NUMBER;
    L_SUBSYSSTAT            VARCHAR2(200);
    L_POLAMT                NUMBER;
    L_POSITIVE              NUMBER;
    L_NEGATIVE              NUMBER;
    L_AUTH_STAT             VARCHAR2(1);
    L_FUND_REF_NO           VARCHAR2(20);

    L_NO_OF_MATCH    NUMBER;
    L_DRAFTS_SUM_NUM NUMBER;
    L_PRODUCT_TYPE   LCTM_PRODUCT_DEFINITION.PRODUCT_TYPE%TYPE;
    L_PROD_CODE      LCTM_PRODUCT_DEFINITION.PRODUCT_CODE%TYPE;
    L_CHECK          BOOLEAN := FALSE;
    L_MODULE         SMTB_MENU.MODULE%TYPE;
    L_CHECK1         BOOLEAN := FALSE;

    L_LINK_COUNT NUMBER := 0;

    L_ERRLIST      VARCHAR2(32767);
    L_ERRPARAMLIST VARCHAR2(32767);

    CURSOR C_EVENT_ADV IS
      SELECT *
        FROM CSTBS_CONTRACT_EVENT_ADVICE
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;

    CURSOR C_FFTS IS
      SELECT *
        FROM LCTBS_FFTS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;

    L_FFT_INS_DESCR LCTBS_FFTS.FFT_INS_DESCR%TYPE;

    CURSOR C_EVENT_LOG(C_CONTRACT_REF_NO IN VARCHAR2) IS
      SELECT *
        FROM CSTB_CONTRACT_EVENT_LOG
       WHERE CONTRACT_REF_NO = C_CONTRACT_REF_NO
         AND AUTH_STATUS = 'U';

    CURSOR C_DUAL_AUTH(C_CONTRACT_REF_NO IN VARCHAR2,
                       C_EVENT_SEQ_NO    IN CSTBS_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE) IS
      SELECT *
        FROM CSTB_CONTRACT_OVD
       WHERE CONTRACT_REF_NO = C_CONTRACT_REF_NO
         AND EVENT_SEQ_NO = C_EVENT_SEQ_NO;

    L_OVD_STATUS VARCHAR2(1) := 'N';
    L_OVD_TYPE   VARCHAR2(1) := '';

    L_CONTRACT_COUNT NUMBER;
    L_STAGE          LCTBS_REG_MASTER.STAGE%TYPE;

    L_ANERROR VARCHAR2(1000);
    L_ANPARAM VARCHAR2(1000);

    L_CNT               NUMBER := 0;
    L_SWIFT2019_ENABLED VARCHAR2(1);
    L_CNT_45L           NUMBER := 0;

    L_23HFFT_COUNT  NUMBER;
    L_45DAFFT_COUNT NUMBER;
    L_45DBFFT_COUNT NUMBER;

    L_DOCS_COUNT     NUMBER := 0;
    L_DOCUMENTS_TBL  LCPKS_GOODS_TAGS.DOCUMENTS_TBL_TYPE;
    L_FFT_DESC       LCTBS_FFTS.FFT_INS_DESCR%TYPE;
    L_SWIFT_TAG      VARCHAR2(3);
    L_SHIP_DET       LCTBS_SHIPMENT.SHIPMENT_DETAILS%TYPE;
    L_SHIP_MARK      LCTBS_SHIPMENT.SHIPMENT_MARKS%TYPE;
    L_ADV_TAG        MSTBS_ADV_INPUT.FIELD_TAG%TYPE;
    L_ADV_TAG1       MSTBS_ADV_INPUT.FIELD_TAG%TYPE;
    L_ADV_TAG2       MSTBS_ADV_INPUT.FIELD_TAG%TYPE;
    L_ADV_TAG3       MSTBS_ADV_INPUT.FIELD_TAG%TYPE;
    L_ADV_TAG4       MSTBS_ADV_INPUT.FIELD_TAG%TYPE;
    L_MSG_FFT_TABLE  LCPKS_GOODS_TAGS.MSG_FFT_TABLE;
    L_CLAUSES_TBL    LCPKS_GOODS_TAGS.CLAUSES_TBL_TYPE;
    I                NUMBER(3);
    J                NUMBER(3);
    LM               NUMBER(4) := 1;
    L_TEMP_STR       VARCHAR2(32000);
    L_GOODS_DESCR    LCTBS_GOODS.GOODS_DESCR%TYPE;
    L_GOODS_COUNT    NUMBER := 0;
    L_FFT_COUNT      NUMBER;
    L_GOODS_TBL      LCPKS_GOODS_TAGS.GOODS_TBL_TYPE;
    L_INCO_TERM      LCTBS_CONTRACT_MASTER.INCO_TERM%TYPE;
    L_PLACE          VARCHAR2(100);
    L_PARAM_INCO     VARCHAR2(1);
    L_FROM_PLACE     LCTBS_SHIPMENT.FROM_PLACE%TYPE;
    L_TO_PLACE       LCTBS_SHIPMENT.TO_PLACE%TYPE;
    L_PORT_DISCHARGE LCTBS_SHIPMENT.PORT_DISCHARGE%TYPE;
    L_PORT_LOADING   LCTBS_SHIPMENT.PORT_LOADING%TYPE;
    CURSOR C_FFT_CURSOR_VAL(P_MESG_TYPE IN CSTB_CONTRACT_EVENT_ADVICE.MSG_TYPE%TYPE) IS
      SELECT DECODE(GLOBAL.X9$,
                    'OMRIBO',
                    DECODE(SUBSTR(MESG_TYPE, 1, 3),
                           'GUA',
                           LTRIM(FFT_INS_DESCR),
                           FFT_INS_SL_NO || '. ' || LTRIM(FFT_INS_DESCR)),
                    LTRIM(FFT_INS_DESCR)) FFT_INS_DESCR
        FROM LCTBS_FFTS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
         AND EVENT_SEQ_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO
         AND MESG_TYPE = P_MESG_TYPE
         AND NOT REGEXP_LIKE(FFT_INS_CODE, '^SND2RECMT\d{3}$')
         AND FFT_INS_CODE NOT LIKE 'INSTRUCTION%'
         AND FFT_INS_CODE NOT LIKE 'SND2RECINFO%'
         AND FFT_INS_CODE NOT IN ('23XFILEIDENT',
                                  '49FCONFINFO',
                                  '49YCHGINFO',
                                  '47EABKINFO',
                                  '21SBANKREF',
                                  '21TCUSTREF',
                                  '29BCONTINF',
                                  '72ZBNKCRPINF',
                                  '72CBNKCRPINF',
                                  '49HSPCLAGRMT',
                                  '29DCONTINF',
                                  '45CDRAWNGREQ')
         AND FFT_INS_CODE NOT LIKE '71B%'
       ORDER BY FFT_INS_SL_NO;
    L_RET_VALUE BOOLEAN := TRUE;

    L_SWIFT_MSGTYPE MSTMS_MSG_TYPE.SWIFT_MSG_TYPE%TYPE;
    L_INCR_AMND_NO  VARCHAR2(1);
    L_CHAR_FIELD1   VARCHAR(10);

  BEGIN

    DBG('In Fn_Process');

    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;

    END;

    IF NOT LCPKS_UPLOAD_UTILS.FN_DATETIME(L_APP_DATE) THEN

      DBG('Failed in lcpks_upload_utils.fn_datetime');
    END IF;

    L_PROD_CODE := SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                          4,
                          4);
    BEGIN
      SELECT PRODUCT_TYPE
        INTO L_PRODUCT_TYPE
        FROM LCTMS_PRODUCT_DEFINITION
       WHERE PRODUCT_CODE = L_PROD_CODE;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No Records Founds');
        DBG(SQLERRM);
        RETURN FALSE;

    END;

    DBG('l_product_type:: ' || L_PRODUCT_TYPE);

    BEGIN
      SELECT PARAM_VAL
        INTO L_SWIFT2019_ENABLED
        FROM CSTB_PARAM
       WHERE PARAM_NAME = 'SWIFTTRADE2019_ENABLED';
    EXCEPTION
      WHEN OTHERS THEN
        L_SWIFT2019_ENABLED := 'N';
        DEBUG.PR_DEBUG('LC', 'Failed in selecting swift enabled param');
    END;
    IF NVL(L_SWIFT2019_ENABLED, 'N') = 'N' THEN

      IF L_PRODUCT_TYPE = 'G' THEN
        FOR REC IN C_EVENT_ADV LOOP
          IF NVL(REC.SUPPRESS, 'Y') = 'N' AND REC.MSG_TYPE = 'GUARANTEE' THEN
            FOR REC1 IN C_FFTS LOOP
              IF REC1.MESG_TYPE = 'GUARANTEE' THEN
                L_CHECK := TRUE;
              END IF;

              DBG('rec1.FFT_INS_CODE-->' || REC1.FFT_INS_CODE);
            END LOOP;

            IF NOT L_CHECK THEN
              DBG('FFT is not there for the msg type GUARANTEE');
              P_ERR_CODE   := 'LCCON-217';
              P_ERR_PARAMS := NULL;
              RETURN FALSE;
            END IF;

          END IF;

        END LOOP;

      END IF;
    END IF;

    IF NVL(LCPKS_ADVICES.G_SWIFT2018_ENABLED, 'N') = 'Y' THEN
      FOR REC IN C_EVENT_ADV LOOP
        DBG('Rec.Msg_Type1' || REC.MSG_TYPE);
        DBG('Rec.Suppress' || REC.SUPPRESS);

        BEGIN
          SELECT SWIFT_MSG_TYPE
            INTO L_SWIFT_MSGTYPE
            FROM MSTM_MSG_TYPE
           WHERE MSG_TYPE = REC.MSG_TYPE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Unable to get SWIFT Message Type');
        END;
        DBG('l_Swift_MsgType' || L_SWIFT_MSGTYPE);
        BEGIN
          SELECT CHAR_FIELD92, CHAR_FIELD1
            INTO L_INCR_AMND_NO, L_CHAR_FIELD1
            FROM CSTBS_UI_COLUMNS
           WHERE CHAR_FIELD2 = REC.CONTRACT_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN

            DBG('Faild in Querying cstb_ui_columns');
            L_INCR_AMND_NO := 'Y';
        END;
        DBG('l_Char_Field1 -->' || L_CHAR_FIELD1);
        IF (L_SWIFT_MSGTYPE = '799' AND
           REC.MSG_TYPE IN ('ADV_FOR_APRE',
                             'CANC_REIM_AUTH',
                             'CHNG_REB',
                             'CLOS_REIM_AUTH',
                             'LC_CANCEL_ADV')) OR
           (REC.MSG_TYPE IN ('LC_AMND_INSTR', 'GUA_AMND_INSTR') AND
           L_INCR_AMND_NO = 'N' AND
           NVL(L_CHAR_FIELD1, 'N') NOT IN ('LCDAMEND', 'LCDGUAMD')) THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG_FUNCTION IS NOT NULL AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG = 'N' THEN
            DEBUG.PR_DEBUG('LC',
                           'Ancillary Message Function should not be entered while ancillary message is not checked');

            P_ERR_CODE   := 'LC-ADV-48';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-48',
                         P_ERR_PARAMS);
          END IF;
          DBG('l_Char_Field1 -->' || L_CHAR_FIELD1 ||
              'p_wrk_Lcdtronl.v_Lctbs_Contract_Master.ancillary_mesg' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG);

          IF NVL(REC.SUPPRESS, 'Y') = 'N' AND
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG = 'Y' THEN

            SELECT COUNT(*)
              INTO L_45DAFFT_COUNT
              FROM LCTB_FFTS
             WHERE CONTRACT_REF_NO = REC.CONTRACT_REF_NO
               AND MESG_TYPE = REC.MSG_TYPE
               AND EVENT_SEQ_NO = REC.EVENT_SEQ_NO
               AND FFT_INS_CODE = '45DANARRATIV';

            SELECT COUNT(*)
              INTO L_45DBFFT_COUNT
              FROM LCTB_FFTS
             WHERE CONTRACT_REF_NO = REC.CONTRACT_REF_NO
               AND MESG_TYPE = REC.MSG_TYPE
               AND EVENT_SEQ_NO = REC.EVENT_SEQ_NO
               AND FFT_INS_CODE = '45DBNARRATIV';
            DEBUG.PR_DEBUG('BC', 'l_45Dbfft_count...' || L_45DBFFT_COUNT);

          ELSIF L_45DAFFT_COUNT = 0 AND L_45DBFFT_COUNT = 0 THEN
            DEBUG.PR_DEBUG('BC',
                           'Mandatory FFTs are missing for ANCILLARY MESG2');
            P_ERR_CODE   := 'LC-ADV-39';
            P_ERR_PARAMS := '45DANARRATIV or 45DBNARRATIV';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-39',
                         P_ERR_PARAMS);

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG_FUNCTION IS NULL THEN
            DEBUG.PR_DEBUG('LC', 'Mandatory field 23H is missing');

            P_ERR_CODE   := 'LC-ADV-47';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-ADV-47',
                         P_ERR_PARAMS);
          END IF;
          IF L_PRODUCT_TYPE = 'S' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG_FUNCTION NOT IN
             ('CLSVOPEN',
                                       'CLSVCLOS',
                                       'FRAUDMSG',
                                       'GENINFAD',
                                       'OTHERFNC',
                                       'REIMBURS',
                                       'REQFINAN',
                                       'TRANSFER') THEN
            DBG('This function is not applicable');
            P_ERR_CODE   := 'LC-MSG-759';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-MSG-759',
                         'CLSVOPEN CLSVCLOS FRAUDMSG GENINFAD
                      OTHERFNC REIMBURS REQFINAN TRANSFER');
            RETURN FALSE;
          ELSIF L_PRODUCT_TYPE = 'G' AND
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_REQUEST = 'I' AND
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG_FUNCTION NOT IN
                ('CLSVOPEN',
                 'CLSVCLOS',
                 'FRAUDMSG',
                 'GENINFAD',
                 'OTHERFNC',
                 'REIMBURS',
                 'REQFINAN',
                 'TRANSFER') THEN
            DBG('This function is not applicable');
            P_ERR_CODE   := 'LC-MSG-759';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-MSG-759',
                         'CLSVOPEN CLSVCLOS FRAUDMSG
                         GENINFAD OTHERFNC REIMBURS REQFINAN TRANSFER');
            RETURN FALSE;
          ELSIF L_PRODUCT_TYPE = 'G' AND
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_REQUEST = 'R' AND
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG_FUNCTION NOT IN
                ('CLSVOPEN',
                 'CLSVCLOS',
                 'FRAUDMSG',
                 'GENINFAD',
                 'OTHERFNC',
                 'REIMBURS',
                 'REQFINAN',
                 'TRANSFER',
                 'ISSUANCE',
                 'REQISSUE',
                 'REQAMEND',
                 'ISSAMEND') THEN
            DBG('This function is not applicable');
            P_ERR_CODE   := 'LC-MSG-759';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-MSG-759',
                         'CLSVOPEN CLSVCLOS FRAUDMSG GENINFAD
                            OTHERFNC REIMBURS REQFINAN TRANSFER ISSUANCE REQISSUE REQAMEND ISSAMEND');
            RETURN FALSE;
          ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG_FUNCTION NOT IN
                ('CLSVOPEN',
                 'CLSVCLOS',
                 'FRAUDMSG',
                 'GENINFAD',
                 'OTHERFNC',
                 'REIMBURS',
                 'REQFINAN') THEN
            DBG('This function is not applicable');
            P_ERR_CODE   := 'LC-MSG-759';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-MSG-759',
                         'CLSVOPEN CLSVCLOS FRAUDMSG
                           GENINFAD OTHERFNC REIMBURS REQFINAN');
            RETURN FALSE;
          END IF;

        END IF;
      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('LC', 'Enter into goods count');
    IF LCPKS_GOODS_TAGS.FN_MSG_45A(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                   L_SWIFT_TAG,
                                   L_GOODS_TBL) THEN
      FOR I IN L_GOODS_TBL.FIRST .. L_GOODS_TBL.LAST LOOP
        L_GOODS_COUNT := L_GOODS_COUNT +
                         NVL(LENGTH(L_GOODS_TBL(I).GOODS_DESCR), 0);
      END LOOP;
      BEGIN
        DEBUG.PR_DEBUG('LC', 'Before selecting param value INCO_TERM_REQD');
        SELECT NVL(PARAM_VAL, 'N')
          INTO L_PARAM_INCO
          FROM CSTB_PARAM
         WHERE PARAM_NAME = 'INCO_TERM_REQD';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('LC', 'when no data found');
          L_PARAM_INCO := 'N';
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('LC', 'when others..');
          RETURN FALSE;
      END;
      IF L_PARAM_INCO = 'Y' THEN
        BEGIN
          SELECT INCO_TERM
            INTO L_INCO_TERM
            FROM LCTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;
          DEBUG.PR_DEBUG('LC', 'l_inco_term-->' || L_INCO_TERM);
          IF L_INCO_TERM IS NOT NULL THEN
            IF L_INCO_TERM IN ('EXW', 'FCA', 'DAF') THEN
              L_PLACE := L_FROM_PLACE;
            ELSIF L_INCO_TERM IN ('CPT', 'CIP', 'DDU', 'DAT', 'DAP', 'DDP') THEN
              L_PLACE := L_TO_PLACE;
            ELSIF L_INCO_TERM IN ('FAS', 'FOB') THEN
              L_PLACE := L_PORT_LOADING;
            ELSIF L_INCO_TERM IN ('CFR', 'CIF', 'DES', 'DEQ') THEN
              L_PLACE := L_PORT_DISCHARGE;
            END IF;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('LC', 'inside no data found');
            NULL;
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('LC', 'inside when others then-->' || SQLERRM);
            RETURN FALSE;
        END;
      END IF;
      L_GOODS_COUNT := L_GOODS_COUNT +
                       LENGTH(SUBSTR('+' || L_INCO_TERM || ' ' || L_PLACE,
                                     1,
                                     65));
      IF L_SHIP_DET IS NULL THEN
        L_GOODS_COUNT := L_GOODS_COUNT + NVL(LENGTH(L_SHIP_MARK), 0);
      ELSE
        L_GOODS_COUNT := L_GOODS_COUNT +
                         NVL(LENGTH(L_SHIP_DET || CSPKES_MISC.FN_GETCHR(10) ||
                                    L_SHIP_MARK),
                             0);
      END IF;
    END IF;
    DBG('Length of goods descr---->' || L_GOODS_COUNT);
    IF L_GOODS_COUNT > 52000 THEN
      DBG('Length of goods descr---->' || LENGTH(L_GOODS_DESCR));
      DBG('Length of goods descr should be less than 52000');
      P_ERR_CODE   := 'LC-VALS-589';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    IF LCPKSS_GOODS_TAGS.FN_MSG_46A(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                    L_SWIFT_TAG,
                                    L_ADV_TAG1,
                                    L_ADV_TAG2,
                                    L_ADV_TAG3,
                                    L_ADV_TAG4,
                                    L_DOCUMENTS_TBL) THEN

      DBG('Length of Docs descr---->' || L_DOCS_COUNT);
      I := L_DOCUMENTS_TBL.FIRST;
      WHILE I <= L_DOCUMENTS_TBL.LAST LOOP

        L_DOCS_COUNT := L_DOCS_COUNT +
                        NVL(LENGTH('+' || L_DOCUMENTS_TBL(I).DOC_ORIGINAL),
                            0);

        L_DOCS_COUNT := L_DOCS_COUNT +
                        NVL(LENGTH(L_DOCUMENTS_TBL(I).DOC_COPIES), 0);
        L_DOCS_COUNT := L_DOCS_COUNT +
                        NVL(LENGTH(L_DOCUMENTS_TBL(I).DOC_DESCR), 0);
        IF LCPKS_GOODS_TAGS.GET_CLAUSE_DETAILS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                               L_DOCUMENTS_TBL(I).DOC_CODE,
                                               L_CLAUSES_TBL) THEN
          J := L_CLAUSES_TBL.FIRST;
          WHILE J <= L_CLAUSES_TBL.LAST LOOP
            L_TEMP_STR   := L_CLAUSES_TBL(J).CLAUSE_DESCR;
            L_DOCS_COUNT := L_DOCS_COUNT + NVL(LENGTH(L_TEMP_STR), 0);
            J            := J + 1;
          END LOOP;
        END IF;
        I := I + 1;
      END LOOP;
    END IF;
    DBG('Length of Docs descr---->' || L_DOCS_COUNT);
    IF L_DOCS_COUNT > 52000 THEN
      DBG('Length of Docs descr should be less than 52000');
      P_ERR_CODE   := 'LC-VALS-590';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('Entaring into length of FFT descr');
    L_FFT_COUNT := 0;
    DBG('Length of fft descr---->' || L_FFT_COUNT);
    FOR J IN (SELECT *
                FROM CSTB_CONTRACT_EVENT_ADVICE
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                 AND EVENT_SEQ_NO =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO) LOOP
      IF J.MSG_TYPE IN ('LC_INSTRUMENT', 'ADV_THIRD_BANK') THEN
        FOR I IN C_FFT_CURSOR_VAL(J.MSG_TYPE) LOOP

          L_FFT_COUNT := L_FFT_COUNT +
                         NVL(LENGTH('+' || I.FFT_INS_DESCR), 0);
        END LOOP;
      END IF;
    END LOOP;
    DBG('Length of fft descr---->' || L_FFT_COUNT);

    IF L_FFT_COUNT > 52000 THEN
      DBG('length of fft descr should be less than 52000');
      P_ERR_CODE   := 'LC-VALS-591';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('p_action_code---> ' || P_ACTION_CODE);
    DBG('p_wrk_lcdtronl.v_lctbs_contract_master.partial_closure---> ' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
       NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE, 'N') = 'Y' THEN
      IF P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.COUNT > 0 THEN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM LDTBS_CONTRACT_LINKAGES
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND EVENT_SEQ_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO
           AND NVL(LINKAGE_VALID, 'N') = 'Y';

      END IF;

      IF L_COUNT > 0 THEN
        DBG('Linkages are attached for PCLS');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-122', NULL);
      END IF;

    END IF;

    FOR REC2 IN C_FFTS LOOP

      IF REGEXP_LIKE(REC2.FFT_INS_CODE, '^SND2RECMT\d{3}$') OR
         SUBSTR(REC2.FFT_INS_CODE, 1, 11) = 'INSTRUCTION' THEN
        BEGIN
          DBG('Enter into 72 field');
          SELECT FFT_INS_DESCR
            INTO L_FFT_INS_DESCR
            FROM LCTBS_FFTS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_FFTS
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO)
             AND MESG_TYPE IN ('LC_INSTR_COPY', 'LC_INSTRUMENT')
             AND FFT_INS_CODE = REC2.FFT_INS_CODE;

          DBG('getting fft details L_FFT_INS_DESCR-->' || L_FFT_INS_DESCR);

          IF REGEXP_LIKE(REC2.FFT_INS_CODE, '^SND2RECMT\d{3}$') THEN
            IF L_FFT_INS_DESCR IS NOT NULL THEN
              DBG('Enter into Sender To Receiver Information..');
              IF LENGTH(L_FFT_INS_DESCR) > 210 THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-104', NULL);
              END IF;

            END IF;

          ELSIF SUBSTR(REC2.FFT_INS_CODE, 1, 11) = 'INSTRUCTION' THEN
            IF L_FFT_INS_DESCR IS NOT NULL THEN
              IF LENGTH(L_FFT_INS_DESCR) > 780 THEN
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-ADV-105', NULL);
              END IF;

            END IF;

          END IF;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('inside no data found');
            NULL;
          WHEN OTHERS THEN
            DBG('When others of FFT--> ' || SQLERRM);
            P_ERR_CODE   := 'ST-OTHR-001';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;

        END;

      END IF;

    END LOOP;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_COPY) THEN
      FOR REC1 IN C_FFTS LOOP

        IF REC1.FFT_INS_CODE IS NOT NULL THEN

          IF REGEXP_LIKE(REC1.FFT_INS_CODE, '^SND2RECMT\d{3}$') THEN
            DBG('Rec1.Fft_Ins_Code-->SND2RECINFO');
            IF LENGTH(REC1.FFT_INS_DESCR) > 210 THEN
              DBG('length is more');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-SWIFT01',
                           REC1.FFT_INS_CODE);
            END IF;

          END IF;

        END IF;

      END LOOP;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_ROLLOVER) THEN

      IF L_PRODUCT_TYPE = 'H' THEN

        IF P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_SPLIT_TAG_DETAIL.COUNT = 1 THEN
          DBG(' BASIS_AMOUNT_TAG   ' || P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_SPLIT_TAG_DETAIL(1)
              .BASIS_AMOUNT_TAG);
          DBG('   CONTRACT_REF_NO  ' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

          IF NVL(P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_SPLIT_TAG_DETAIL(1)
                 .SPLIT_AMOUNT,
                 0) = 0 AND P_WRK_LCDTRONL.TY_CSCTRSPT.V_CSTBS_SPLIT_TAG_DETAIL(1)
            .BASIS_AMOUNT_TAG IN ('COLL_AMT_INCR', 'COLL_AMNDAMT') THEN

            DBG('calling Cspkss_Split.Fn_Validate_Split');
            IF NOT CSPKSS_SPLIT.FN_VALIDATE_SPLIT(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                  P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                                  TRUE,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS,
                                                  'LDDCOMNT') THEN

              DBG('Failed in cspkss_split.fn_validate_split with err code ');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           P_ERR_CODE,
                           P_ERR_PARAMS);
            END IF;

          END IF;

        END IF;

      END IF;

      IF P_ACTION_CODE IN ('NEW') THEN
        DBG('calling Ldpkss_Link.Fn_Link_During_Book ..');
        IF NOT LDPKSS_LINK.FN_LINK_DURING_BOOK(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO

                                              ,
                                               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                               'U',
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN
          DBG('Failed in linkeage on book....... ');
          RETURN FALSE;
        END IF;

      END IF;

      DBG('curr event code: ' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE);

      DBG('Calling Bcpkss_Utils.Tfdbklsts..');
      IF NOT BCPKSS_UTILS.TFDBKLSTS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                    L_MODULE,
                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE,
                                    L_NO_OF_MATCH) THEN

        DBG('Failed in Bcpkss_Utils.Tfdbklsts..');
        RETURN FALSE;
      END IF;

      IF L_NO_OF_MATCH > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'TFDBLK-096',
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);
      END IF;

      DBG('Calling Stpkss_Sdn.Fn_Check_Contract..');
      IF NOT STPKSS_SDN.FN_CHECK_CONTRACT(L_MODULE,
                                          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS) THEN

        DBG('Calling Stpkss_Sdn.Fn_Check_Contract..');
        RETURN FALSE;
      END IF;

      IF GLOBAL_ADDON.FUND_BRANCH THEN

        SELECT FUND_REF_NO
          INTO L_FUND_REF_NO
          FROM CSTBS_CONTRACT
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        DBG('Calling ampkss_copy.fn_update_mis');
        IF NOT AMPKSS_COPY.FN_UPDATE_MIS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                         L_FUND_REF_NO,
                                         P_ERR_CODE) THEN

          DBG('Failed in ampkss_copy.fn_update_mis');
          RETURN FALSE;
        END IF;

      END IF;

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD, 'N') = 'A' THEN
        IF NOT LCPKSS_COMMON.FN_GETDRAFTSTOTAL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                               '1',
                                               '1',
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                               L_DRAFTS_SUM_NUM) THEN

          DBG('override for draft amt');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-064', NULL);
        END IF;

      END IF;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) THEN

      DBG('Calling Lcpkss_Save.Fn_Savecontract..');
      IF NOT LCPKS_SAVE.FN_SAVECONTRACT(GLOBAL.USER_ID,
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                        '1',
                                        '1',
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE,
                                        'N',
                                        'N',
                                        L_APP_DATE,
                                        NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE),
                                        'Y',
                                        'Y',
                                        'Y',
                                        'Y',

                                        L_ERRLIST,
                                        L_ERRPARAMLIST)

       THEN
        DBG('Failed in Lcpkss_Save.Fn_Savecontract');

        RETURN FALSE;
      END IF;

      DBG('Calling Ispkss.Fn_Referral ..');
      IF NOT ISPKSS.FN_REFERRAL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                L_TAG_LIST,
                                'N',
                                L_TAG_CCY_LIST,
                                L_PAY_RECEIVE_LIST,
                                L_AC_BRANCH_LIST,
                                L_ACCOUNT_LIST,
                                L_ACC_CCY_LIST,
                                L_EX_RATE_LIST,
                                L_SETTLEMENT_AMT_LIST,
                                L_VALUE_DATE_LIST,
                                L_PAYMENT_BY_LIST,
                                L_TRANSFER_TYPE_LIST,
                                L_INSTR_TYPE_LIST,
                                L_INSTR_NO_LIST,
                                L_COVER_REQD_LIST,
                                L_CHARGES_DETAILS_LIST,
                                L_OUR_CORRESP_LIST,
                                L_RECEIVER_LIST,
                                L_INT_REIM_INST_LIST,
                                L_RCVR_CORRESP_LIST,
                                L_INTERMEDIARY_LIST,
                                L_ACC_WITH_INSTN_LIST,
                                L_PAY_DETAILS_LIST,
                                L_SNDR_TO_RCVR_LIST,
                                L_ORDERING_INST_LIST,
                                L_ORDERING_CUST_LIST,
                                L_BENEF_INST_LIST,
                                L_ULT_BENEF_LIST,
                                P_ERR_CODE) THEN
        DBG('Failed in ispkss.fn_referral');
      ELSE
        DBG('ispkss.fn_referral returned true');
        N                  := 1;
        L_ACCOUNT_LIST     := L_ACCOUNT_LIST || '~';
        L_PAY_RECEIVE_LIST := L_PAY_RECEIVE_LIST || '~';
        L_AC_BRANCH_LIST   := L_AC_BRANCH_LIST || '~';

        L_ANACC  := CSPKES_MISC.FN_GETPARAM(L_ACCOUNT_LIST, N, '~');
        L_ANDRCR := CSPKES_MISC.FN_GETPARAM(L_PAY_RECEIVE_LIST, N, '~');
        L_ANBRN  := CSPKES_MISC.FN_GETPARAM(L_AC_BRANCH_LIST, N, '~');

        WHILE L_ANACC <> 'EOPL' LOOP
          IF L_ANDRCR = 'R' THEN
            IF CVPKS_UTILS.GET_STTB_ACC(L_ANBRN, L_ANACC, L_ACCREC) THEN
              IF L_ACCREC.AC_OR_GL = 'A' THEN

                BEGIN
                  DBG('Selecting from the product view');
                  SELECT COUNT(*)
                    INTO L_COUNT_PROD
                    FROM CSVWS_ALLOWED_PRODUCTS
                   WHERE CUSTAC = L_ANACC
                     AND BRANCH_CODE = L_ANBRN
                     AND PRODUCT_CODE =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE
                     AND DEBIT_TXN = 'Y';

                  DBG('Count from the product view is ' || L_COUNT_PROD);
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('When others of select from the views' || SQLERRM);

                END;

                IF L_COUNT_PROD = 0 THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               'AC-PROD2',
                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE || '~' ||
                               L_ANACC || '~');

                END IF;

              END IF;

            END IF;

          ELSIF L_ANDRCR = 'P' THEN
            IF CVPKS_UTILS.GET_STTB_ACC(L_ANBRN, L_ANACC, L_ACCREC) THEN
              IF L_ACCREC.AC_OR_GL = 'A' THEN

                BEGIN
                  DBG('Selecting from the product view');
                  SELECT COUNT(*)
                    INTO L_COUNT_PROD1
                    FROM CSVWS_ALLOWED_PRODUCTS
                   WHERE CUSTAC = L_ANACC
                     AND BRANCH_CODE = L_ANBRN
                     AND PRODUCT_CODE =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE
                     AND CREDIT_TXN = 'Y';

                  DBG('Count from the product view is ' || L_COUNT_PROD);
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('When others of select from the views' || SQLERRM);

                END;

                IF L_COUNT_PROD1 = 0 THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               'AC-PROD2',
                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE || '~' ||
                               L_ANACC || '~');
                END IF;

              END IF;

            END IF;

          END IF;

          N        := N + 1;
          L_ANACC  := NULL;
          L_ANDRCR := NULL;
          L_ANBRN  := NULL;
          L_ANACC  := CSPKES_MISC.FN_GETPARAM(L_ACCOUNT_LIST, N, '~');
          L_ANDRCR := CSPKES_MISC.FN_GETPARAM(L_PAY_RECEIVE_LIST, N, '~');
          L_ANBRN  := CSPKES_MISC.FN_GETPARAM(L_AC_BRANCH_LIST, N, '~');
        END LOOP;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL AND
         L_PRODUCT_TYPE = 'H' THEN
        DBG('Calling Ldpkss_Link.fn_lc_linkage..... ');
        IF NOT LDPKSS_LINK.FN_LC_LINKAGE(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN

          DBG('failed in Ldpkss_Link.fn_lc_linkage..');
          RETURN FALSE;
        END IF;

      END IF;

      IF L_PRODUCT_TYPE = 'H' THEN

        DBG('Calling Ldpkss_Link.fn_create_advance_loan..... ');
        IF NOT LDPKSS_LINK.FN_CREATE_ADVANCE_LOAN(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                                  P_WRK_LCDTRONL.V_CSTBS_CONTRACT.BRANCH,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN

          DBG('failed in Ldpkss_Link.fn_create_advance_loan..');
          RETURN FALSE;
        END IF;

      END IF;

      IF P_SOURCE <> 'FLEXCUBE' THEN

        UPDATE CSTB_CONTRACT
           SET SOURCE = P_SOURCE
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

      END IF;

      UPDATE LCTB_CONTRACT_MASTER
         SET SUBSYSTEMSTAT = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO IS NOT NULL THEN
        DBG('Updating Lctb_Reg_Master during new operation ');
        BEGIN
          UPDATE LCTB_REG_MASTER
             SET CONTRACT_REF_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                 STAGE           = 'P'
           WHERE ACKREFNO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In when others exception ' || SQLERRM);
        END;
      END IF;

      DBG('l_swift2019_enabled-1111->' || L_SWIFT2019_ENABLED);
      DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Contract_Ref_No-1111->' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);
      DBG('p_Wrk_Lcdtronl.v_Cstbs_Contract.Latest_Event_Seq_No-1111->' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO);
      IF L_SWIFT2019_ENABLED = 'Y' THEN
        FOR I IN (SELECT *
                    FROM CSTB_CONTRACT_EVENT_ADVICE
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                     AND EVENT_SEQ_NO =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO
                     AND MSG_TYPE = 'GUARANTEE') LOOP
          DBG('Inside contract advice loop');
          IF NVL(I.SUPPRESS, 'N') <> 'Y' AND I.MEDIUM = 'SWIFT' THEN
            DBG('Suppress is N');
            FOR J IN (SELECT *
                        FROM LCTB_FFTS
                       WHERE CONTRACT_REF_NO =
                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                         AND EVENT_SEQ_NO =
                             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO) LOOP
              DBG('Inside fft loop');
              IF J.MESG_TYPE = I.MSG_TYPE THEN
                DBG('Inside 77U count');
                SELECT COUNT(*)
                  INTO L_CNT
                  FROM LCTB_FFTS
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                   AND EVENT_SEQ_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO
                   AND MESG_TYPE = J.MESG_TYPE
                   AND FFT_INS_CODE = '77UGUATERMS'
                   AND FFT_INS_DESCR IS NOT NULL;
                DBG('l_cnt-->' || L_CNT);
              END IF;
              IF J.MESG_TYPE = I.MSG_TYPE THEN
                DBG('Inside 45L count');
                SELECT COUNT(*)
                  INTO L_CNT_45L
                  FROM LCTB_FFTS
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                   AND EVENT_SEQ_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO
                   AND MESG_TYPE = J.MESG_TYPE
                   AND FFT_INS_CODE = '45LTRNDTSEQC'
                   AND FFT_INS_DESCR IS NOT NULL;
                DBG('l_cnt_45l-->' || L_CNT_45L);
              END IF;
            END LOOP;
            DBG('Out of fft loop');
            IF L_CNT = 0 THEN
              DBG('FFT 77UGUATERMS is mandatory');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-GUA-011', NULL);
            END IF;
            IF L_CNT_45L = 0 AND
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_REQUEST = 'R' THEN
              DBG('FFT 45LTRNDTSEQC is mandatory');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-GUA-003', NULL);
            END IF;
            DBG('Out of 1st IF');
          END IF;
          DBG('Out of 2nd IF');
        END LOOP;
        DBG('Out of loop');
      END IF;

    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      IF L_PRODUCT_TYPE <> 'H' THEN
        IF (P_PREV_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.COUNT > 0 AND
           P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.COUNT = 0) THEN
          FOR I IN 1 .. P_PREV_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.COUNT LOOP
            DBG('Calling Ldpkss_Link.Fn_Link_During_amend..');
            IF NOT LDPKSS_LINK.FN_LINK_DURING_AMEND(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO

                                                   ,
                                                    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                                    GLOBAL.APPLICATION_DATE

                                                   ,
                                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                                    'U',
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
              DBG('Faile inlinkeage on amend ');
              RETURN FALSE;
            END IF;

          END LOOP;

        END IF;

      END IF;

      DBG('Checking for mandetory FFT Codes ' ||
          P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT);
      FOR REC IN C_EVENT_ADV LOOP
        DBG('Entered into Advice cursor for ' || REC.MSG_TYPE);
        IF ABKCHANGED = 'Y' AND
           REC.MSG_TYPE IN ('LC_AMND_INSTR', 'GUA_AMD_INSTR') THEN
          DBG('ABK has been modified');
          L_CHECK1 := FALSE;
          FOR REC1 IN C_FFTS LOOP
            DBG('Entered into FFT cursor for ' || REC1.FFT_INS_CODE ||
                'and ' || REC1.MESG_TYPE);
            IF REC1.MESG_TYPE IN ('LC_AMND_INSTR', 'GUA_AMD_INSTR') AND
               REC1.FFT_INS_CODE = 'CANCEL' THEN
              L_CHECK1 := TRUE;
            END IF;

          END LOOP;

          IF NOT L_CHECK1 THEN
            DBG('Proper FFT is not there for the msg type ' ||
                REC.MSG_TYPE);
            P_ERR_CODE   := 'LCCON-226';
            P_ERR_PARAMS := 'CANCEL' || '~' || REC.MSG_TYPE || '~' ||
                            REC.PARTY_TYPE;

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

          END IF;

        ELSIF REBCHANGED = 'Y' AND REC.MSG_TYPE = 'LC_AMD_AUTH_REB' AND
              P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 <> 'LCDAMEND' THEN

          DBG('REB has been modified');
          L_CHECK1 := FALSE;
          FOR REC1 IN C_FFTS LOOP
            DBG('Entered into FFT cursor for ' || REC1.FFT_INS_CODE ||
                'and ' || REC1.MESG_TYPE);
            IF REC1.MESG_TYPE = 'LC_AMD_AUTH_REB' AND
               REC1.FFT_INS_CODE = 'CANC' THEN
              L_CHECK1 := TRUE;
            END IF;

          END LOOP;

          IF NOT L_CHECK1 THEN
            DBG('Proper FFT is not there for the msg type ' ||
                REC.MSG_TYPE);
            P_ERR_CODE   := 'LCCON-226';
            P_ERR_PARAMS := 'CANC' || '~' || REC.MSG_TYPE || '~' ||
                            REC.PARTY_TYPE;

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

          END IF;

        ELSIF BENCHANGED = 'Y' AND
              (REC.MSG_TYPE IN ('LC_AMD_AUTH_REB', 'LC_AUTH_REIMB') OR
              (REC.MSG_TYPE = 'LC_AMND_INSTR' AND
              P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 = 'LCDAMEND') AND
              REBEXISTS = 'Y') THEN
          DBG('BEN has been modified');
          L_CHECK1 := FALSE;
          FOR REC1 IN C_FFTS LOOP
            DBG('Entered into FFT cursor for ' || REC1.FFT_INS_CODE ||
                'and ' || REC1.MESG_TYPE);
            IF REC1.MESG_TYPE IN ('LC_AMD_AUTH_REB', 'LC_AUTH_REIMB') OR
               (REC1.MESG_TYPE = 'LC_AMND_INSTR' AND
               P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 = 'LCDAMEND') AND

               REGEXP_LIKE(REC1.FFT_INS_CODE, '^SND2RECMT\d{3}$') THEN
              L_CHECK1 := TRUE;
            END IF;

          END LOOP;

          IF NOT L_CHECK1 THEN
            DBG('Proper FFT is not there for the msg type ' ||
                REC.MSG_TYPE);
            P_ERR_CODE   := 'LCCON-226';
            P_ERR_PARAMS := 'SND2RECINFO' || '~' || REC.MSG_TYPE || '~' ||
                            'BEN';

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

          END IF;

        END IF;

      END LOOP;

      DBG('p_PREV_Lcdtronl.ty_csctrlnk.v_ldtbs_contract_linkages.COUNT -->' ||
          P_PREV_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.COUNT);
      DBG('p_wrk_Lcdtronl.ty_csctrlnk.v_ldtbs_contract_linkages.COUNT -->' ||
          P_WRK_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.COUNT);
      DBG('p_Lcdtronl.ty_csctrlnk.v_ldtbs_contract_linkages.COUNT -->' ||
          P_LCDTRONL.TY_CSCTRLNK.V_LDTBS_CONTRACT_LINKAGES.COUNT);

      DBG('previous linkage count: ' || L_LINK_COUNT);

      DBG('Calling Ldpkss_Link.Fn_Link_During_amend..');
      IF NOT LDPKSS_LINK.FN_LINK_DURING_AMEND(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO

                                             ,

                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO - 1

                                             ,
                                              GLOBAL.APPLICATION_DATE

                                             ,
                                              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                              'U',
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
        DBG('Faile inlinkeage on amend ');
        RETURN FALSE;
      END IF;

      DBG('Calling Lcpkss_Save.Fn_Savecontract..');
      IF NOT LCPKSS_SAVE.FN_SAVECONTRACT(L_USER_ID,
                                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE,
                                         'N',
                                         'N',
                                         L_APP_DATE

                                        ,
                                         L_APP_DATE,
                                         'Y',
                                         'Y',
                                         'Y',
                                         'Y',

                                         L_ERRLIST,
                                         L_ERRPARAMLIST)

       THEN
        DBG('Failed in Lcpkss_Save.Fn_Savecontract');

        RETURN FALSE;
      END IF;

      DBG('Calling Ispkss.Fn_Referral ..');
      IF NOT ISPKSS.FN_REFERRAL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                L_TAG_LIST,
                                'N',
                                L_TAG_CCY_LIST,
                                L_PAY_RECEIVE_LIST,
                                L_AC_BRANCH_LIST,
                                L_ACCOUNT_LIST,
                                L_ACC_CCY_LIST,
                                L_EX_RATE_LIST,
                                L_SETTLEMENT_AMT_LIST,
                                L_VALUE_DATE_LIST,
                                L_PAYMENT_BY_LIST,
                                L_TRANSFER_TYPE_LIST,
                                L_INSTR_TYPE_LIST,
                                L_INSTR_NO_LIST,
                                L_COVER_REQD_LIST,
                                L_CHARGES_DETAILS_LIST,
                                L_OUR_CORRESP_LIST,
                                L_RECEIVER_LIST,
                                L_INT_REIM_INST_LIST,
                                L_RCVR_CORRESP_LIST,
                                L_INTERMEDIARY_LIST,
                                L_ACC_WITH_INSTN_LIST,
                                L_PAY_DETAILS_LIST,
                                L_SNDR_TO_RCVR_LIST,
                                L_ORDERING_INST_LIST,
                                L_ORDERING_CUST_LIST,
                                L_BENEF_INST_LIST,
                                L_ULT_BENEF_LIST,
                                P_ERR_CODE) THEN
        DBG('Failed in ispkss.fn_referral');
      ELSE
        DBG('ispkss.fn_referral returned true');
        N                  := 1;
        L_ACCOUNT_LIST     := L_ACCOUNT_LIST || '~';
        L_PAY_RECEIVE_LIST := L_PAY_RECEIVE_LIST || '~';
        L_AC_BRANCH_LIST   := L_AC_BRANCH_LIST || '~';

        L_ANACC  := CSPKES_MISC.FN_GETPARAM(L_ACCOUNT_LIST, N, '~');
        L_ANDRCR := CSPKES_MISC.FN_GETPARAM(L_PAY_RECEIVE_LIST, N, '~');
        L_ANBRN  := CSPKES_MISC.FN_GETPARAM(L_AC_BRANCH_LIST, N, '~');

        WHILE L_ANACC <> 'EOPL' LOOP
          IF L_ANDRCR = 'R' THEN
            IF CVPKS_UTILS.GET_STTB_ACC(L_ANBRN, L_ANACC, L_ACCREC) THEN
              IF L_ACCREC.AC_OR_GL = 'A' THEN

                BEGIN
                  DBG('Selecting from the product view');
                  SELECT COUNT(*)
                    INTO L_COUNT_PROD
                    FROM CSVWS_ALLOWED_PRODUCTS
                   WHERE CUSTAC = L_ANACC
                     AND BRANCH_CODE = L_ANBRN
                     AND PRODUCT_CODE =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE
                     AND DEBIT_TXN = 'Y';

                  DBG('Count from the product view is ' || L_COUNT_PROD);
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('When others of select from the views' || SQLERRM);

                END;

                IF L_COUNT_PROD = 0 THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               'AC-PROD2',
                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE || '~' ||
                               L_ANACC || '~');

                END IF;

              END IF;

            END IF;

          ELSIF L_ANDRCR = 'P' THEN
            IF CVPKS_UTILS.GET_STTB_ACC(L_ANBRN, L_ANACC, L_ACCREC) THEN
              IF L_ACCREC.AC_OR_GL = 'A' THEN

                BEGIN
                  DBG('Selecting from the product view');
                  SELECT COUNT(*)
                    INTO L_COUNT_PROD1
                    FROM CSVWS_ALLOWED_PRODUCTS
                   WHERE CUSTAC = L_ANACC
                     AND BRANCH_CODE = L_ANBRN
                     AND PRODUCT_CODE =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE
                     AND CREDIT_TXN = 'Y';

                  DBG('Count from the product view is ' || L_COUNT_PROD);
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('When others of select from the views' || SQLERRM);

                END;

                IF L_COUNT_PROD1 = 0 THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               P_SOURCE,
                               'AC-PROD2',
                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE || '~' ||
                               L_ANACC || '~');

                END IF;

              END IF;

            END IF;

          END IF;

          N        := N + 1;
          L_ANACC  := NULL;
          L_ANDRCR := NULL;
          L_ANBRN  := NULL;
          L_ANACC  := CSPKES_MISC.FN_GETPARAM(L_ACCOUNT_LIST, N, '~');
          L_ANDRCR := CSPKES_MISC.FN_GETPARAM(L_PAY_RECEIVE_LIST, N, '~');
          L_ANBRN  := CSPKES_MISC.FN_GETPARAM(L_AC_BRANCH_LIST, N, '~');
        END LOOP;

      END IF;

      DBG('KER ITR1#708: p_wrk_lcdtronl.v_lctbs_contract_master.beneficiary_conf_reqd ==> ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD || '~');
      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD,
             'N') = 'Y' THEN

        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM CSTBS_CONTRACT_EVENT_LOG
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_CODE = 'AMND'
             AND AUTH_STATUS = 'U';

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No records');
            RETURN FALSE;

        END;

        IF L_COUNT != 0 THEN
          DBG('Calling Lcpkss_Common.Fn_Getdeltaamounts..');
          IF NOT LCPKSS_COMMON.FN_GETDELTAAMOUNTS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                                  L_DELTALCAMT,
                                                  L_DELTAMAXLCAMT,
                                                  L_DELTAMAXLIABILITYAMT,
                                                  L_DELTACOLLATERALAMT,
                                                  L_OLDOPER,
                                                  L_NEWOPER) THEN

            DBG('Failed in Lcpkss_Common.Fn_Getdeltaamounts..');
            RETURN FALSE;
          END IF;

          IF L_DELTALCAMT < 0 THEN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM LCTBS_AMND_VALS_MASTER
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
               AND AMND_STATUS = 'U';

            IF L_COUNT <> 0 THEN
              P_ERR_CODE   := 'LC-AMND2';
              P_ERR_PARAMS := NULL;
              RETURN FALSE;
            END IF;

            DBG('Calling Lcpkss_Common.Fn_Getcurrentrecord..');
            IF NOT LCPKSS_COMMON.FN_GETCURRENTRECORD(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE,
                                                     L_LCMASTERRECORD,
                                                     L_LCSHIPMENTRECORD,
                                                     L_LCAVAILMENTRECORD,
                                                     L_LCCOLLATERALRECORD,
                                                     L_LCPRODUCTRECORD) THEN

              DBG('Failed in Lcpkss_Common.Fn_Getcurrentrecord');
              RETURN FALSE;
            END IF;

            DBG('Calling Lcpkss_Iface.Fn_Getstatictags..');
            IF NOT LCPKSS_IFACE.FN_GETSTATICTAGS(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                                                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE,
                                                 L_LCMASTERRECORD,
                                                 L_LCAVAILMENTRECORD,
                                                 L_LCCOLLATERALRECORD,
                                                 L_APPDATE,
                                                 LSTSTATICTAG,
                                                 LSTSTATICAMT,
                                                 LSTSTATICCCY,
                                                 LSTSTATICVALUEDATE,
                                                 LSTSTATICLCYAMT,
                                                 LSTSTATICRATE) THEN
              DBG('Failed in Lcpkss_Iface.Fn_Getstatictags');
              RETURN FALSE;
            END IF;

            TAGPOSN := CSPKES_MISC.FN_GETPARAM_NO(LSTSTATICTAG,
                                                  'LIAB_AMND_AMT',
                                                  '~');
            IF TAGPOSN = 0 THEN
              RETURN FALSE;
            END IF;

            TAGAMOUNT    := CSPKES_MISC.FN_GETPARAM(LSTSTATICAMT,
                                                    TAGPOSN,
                                                    '~');
            TAGCCY       := CSPKES_MISC.FN_GETPARAM(LSTSTATICCCY,
                                                    TAGPOSN,
                                                    '~');
            TAGVALUEDATE := CSPKES_MISC.FN_GETPARAM(LSTSTATICVALUEDATE,
                                                    TAGPOSN,
                                                    '~');
            TAGLCYAMOUNT := CSPKES_MISC.FN_GETPARAM(LSTSTATICLCYAMT,
                                                    TAGPOSN,
                                                    '~');
            BEGIN
              SELECT MAX(EVENT_SEQ_NO)
                INTO L_ESN
                FROM CSTBS_CONTRACT_EVENT_LOG
               WHERE CONTRACT_REF_NO =
                     P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                 AND EVENT_CODE = 'AMND';

            EXCEPTION
              WHEN OTHERS THEN
                DBG('Error in Selecting Cstbs_Contract_Event_Log');

            END;

            BEGIN
              INSERT INTO LCTBS_AMND_VALS
                (CONTRACT_REF_NO,
                 VERSION_NO,
                 EVENT_SEQ_NO,
                 DECREASED_LC_AMT,
                 CONFIRMED,
                 AMENDMENT_REJ_ESN,
                 AMENDMENT_CONF_ESN,
                 DECREASED_MAXLIAB_AMT,
                 DECREASED_MAXLIAB_AMT_LCY)
              VALUES
                (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                 L_ESN,
                 L_DELTALCAMT,
                 'U',
                 0,
                 0,
                 TAGAMOUNT,
                 TAGLCYAMOUNT);

            EXCEPTION
              WHEN OTHERS THEN
                DBG('Error in Inserting Lctbs_Amnd_Vals..');

            END;

          END IF;

        END IF;

      END IF;

      IF L_PRODUCT_TYPE = 'H' THEN

        DBG('Calling Ldpkss_Link.fn_create_advance_loan..... ');
        IF NOT LDPKSS_LINK.FN_CREATE_ADVANCE_LOAN(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                                  P_WRK_LCDTRONL.V_CSTBS_CONTRACT.BRANCH,
                                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN

          DBG('failed in Ldpkss_Link.fn_create_advance_loan..');
          RETURN FALSE;
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO IS NOT NULL THEN
        DBG('Updating Lctb_Reg_Master during modify operation ');
        BEGIN
          UPDATE LCTB_REG_MASTER
             SET CONTRACT_REF_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                 STAGE           = 'P'
           WHERE ACKREFNO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In when others exception ' || SQLERRM);
        END;
      END IF;

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN

      SELECT *
        INTO L_LOG_REC
        FROM CSTB_CONTRACT_EVENT_LOG
       WHERE CONTRACT_REF_NO = P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM CSTB_CONTRACT_EVENT_LOG
               WHERE CONTRACT_REF_NO =
                     P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

      DBG(' p_Lcdtronl.v_Cstbs_Contract.SOURCE :: ' ||
          P_LCDTRONL.V_CSTBS_CONTRACT.SOURCE);
      IF NVL(L_LOG_REC.MAKER_ID, '*') <> GLOBAL.USER_ID AND
         P_LCDTRONL.V_CSTBS_CONTRACT.SOURCE <> 'FCAT' THEN
        DBG('Only Maker Can Delete The Contract..');
        P_ERR_CODE   := 'LC-VALS-007';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      IF NVL(L_LOG_REC.AUTH_STATUS, '*') <> 'U' THEN

        DBG('Transaction Is Not In Un AUth State..');
        P_ERR_CODE   := 'LC-VALS-008';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      DBG('l_Log_Rec.Event_Code' || L_LOG_REC.EVENT_CODE);
      IF L_LOG_REC.EVENT_CODE IN ('AVAL', 'RAVL') THEN

        P_ERR_CODE   := 'LCCON-082';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      IF NOT FN_VALIDATE_DELETE(P_SOURCE,
                                P_FUNCTION_ID,
                                P_WRK_LCDTRONL,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Validate_Delete');
        RETURN FALSE;
      END IF;

      SELECT AUTH_STATUS
        INTO L_AUTH_STAT
        FROM CSTB_CONTRACT_EVENT_LOG
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
         AND EVENT_SEQ_NO =
             (SELECT MIN(EVENT_SEQ_NO)
                FROM CSTB_CONTRACT_EVENT_LOG
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

      IF L_AUTH_STAT = 'U' THEN

        BEGIN
          SELECT NVL(POSITIVE_TOLERANCE, 0), NVL(NEGATIVE_TOLERANCE, 0)
            INTO L_POSITIVE, L_NEGATIVE

            FROM LCTB_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTB_CONTRACT_MASTER
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('BC', ' no data in lctb_contract_master');

        END;

        L_POLAMT := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT;
        IF L_POSITIVE <> 0 THEN
          L_POLAMT := L_POLAMT * (1 + NVL(L_POSITIVE, 0) / 100);
        ELSIF L_NEGATIVE <> 0 THEN
          L_POLAMT := L_POLAMT * (1 - NVL(L_NEGATIVE, 0) / 100);

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL AND
         L_PRODUCT_TYPE = 'H' AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE = 'BISS' THEN
        DBG('Calling Ldpkss_Link.fn_delete_LC_sg_linkage..... ');
        IF NOT LDPKSS_LINK.FN_DELETE_LC_SG_LINKAGE(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN

          DBG('Ldpkss_Link.fn_delete_LC_sg_linkage..');
          RETURN FALSE;
        END IF;

      END IF;

      IF NOT LCPKSS_DELETE.FN_DELETECONTRACT(GLOBAL.USER_ID,
                                             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                                             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE,
                                             FN_MNTSTAMP,
                                             L_APP_DATE,
                                             'Y',
                                             P_ERR_CODE,
                                             P_ERR_PARAMS) THEN
        DBG('Failed in Lcpkss_Delete.Fn_Deletecontract..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      ELSE
        DBG('Lmpkss_Collat.Fn_Revert_Collateral_Amendment');
        IF NOT LMPKSS_COLLAT.FN_REVERT_COLLATERAL_AMENDMENT(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                                                            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN

          DBG('Failed in Lmpkss_Collat.Fn_Revert_Collateral_Amendment..');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO IS NOT NULL THEN

        DBG('checking if the ack ref number is not mapped to any contract ');

        SELECT COUNT(1)
          INTO L_CONTRACT_COUNT
          FROM LCTB_CONTRACT_MASTER
         WHERE ACKREFNO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;

        DBG('checking status of the request is processed');
        BEGIN
          SELECT STAGE
            INTO L_STAGE
            FROM LCTB_REG_MASTER
           WHERE ACKREFNO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('In no data found while selecting stage ');
          WHEN OTHERS THEN
            DBG('In When others exception' || SQLERRM);
        END;

        IF L_CONTRACT_COUNT = 0 AND L_STAGE = 'P' THEN
          DBG('Updating lctb_reg_master during delete operation');
          BEGIN
            UPDATE LCTB_REG_MASTER
               SET STAGE           = 'R',
                   CONTRACT_REF_NO =
                   (SELECT DECODE(REG_TYPE,
                                  'LC',
                                  NULL,
                                  'SG',
                                  NULL,
                                  'BG',
                                  NULL,
                                  'AM',
                                  P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO)
                      FROM LCTB_REG_MASTER
                     WHERE ACKREFNO =
                           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO)
             WHERE ACKREFNO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('In when others exception ' || SQLERRM);
          END;
        END IF;
      END IF;

    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_ROLLOVER) THEN

      IF NOT LCPKSS_SAVE.FN_SAVECONTRACT(GLOBAL.USER_ID,
                                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                         NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                                             1),
                                         NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                             1),
                                         'REIN',
                                         'N',
                                         'N',
                                         L_APP_DATE,
                                         L_APP_DATE,
                                         'Y',
                                         'Y',
                                         'Y',
                                         'Y',

                                         L_ERRLIST,
                                         L_ERRPARAMLIST)

       THEN
        DBG('failed in lcpkss_save.fn_SaveContract');
        RETURN FALSE;
      END IF;

    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_CLOSE) THEN
      IF NOT LCPKS_SAVE.FN_SAVECONTRACT(GLOBAL.USER_ID,
                                        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                                        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE,
                                        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS,
                                        'N',
                                        L_APP_DATE,
                                        L_APP_DATE,

                                        'Y',
                                        'Y',
                                        'Y',
                                        'Y',

                                        L_ERRLIST,
                                        L_ERRPARAMLIST)

       THEN
        DBG('failed in lcpkss_save.fn_SaveContract');
        RETURN FALSE;
      END IF;

    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_REOPEN) THEN

      DBG('In fn_process - Reopen');
      P_WRK_LCDTRONL := P_LCDTRONL;
      DBG('In fn_process - Reopen');
      DBG('Amount1..' || P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
      DBG('Amount2..' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
      DBG('Amount3..' ||
          P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
      DBG('l_cont_rec.latest_version_no ' ||
          P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
      DBG('l_cont_rec.latest_event_seq_no ' ||
          P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
      DBG('latest_version_no ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
      DBG('latest_event_seq_no ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
      DBG('Event code ' || P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE);
      DBG('Max con amt ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);
      DBG('Max liab amt ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT);
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE := 'ROPN';

      BEGIN
        DBG('Before selecting master record');
        SELECT *
          INTO P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER
          FROM LCTB_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND VERSION_NO =
               (SELECT MAX(VERSION_NO)
                  FROM LCTB_CONTRACT_MASTER
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

      EXCEPTION
        WHEN OTHERS THEN
          NULL;

      END;

      IF P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 = 'Y' THEN
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO + 1,
                                                                   1);
      END IF;

      IF NOT FN_DEFAULT(P_SOURCE,
                        P_SOURCE_OPERATION,
                        P_FUNCTION_ID,
                        CSPKS_REQ_GLOBAL.P_REOPEN,

                        P_LCDTRONL,
                        L_PREV_LCDTRONL,
                        P_WRK_LCDTRONL,
                        P_ERR_CODE,
                        P_ERR_PARAMS) THEN
        DBG('Failed in fn_process - Reopen...');
      END IF;

      DBG('latest_version_no ' ||
          P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
      DBG('latest_event_seq_no ' ||
          P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
      DBG('latest_version_no ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
      DBG('latest_event_seq_no ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
      DBG('Event code ' || P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE);
      DBG(' con amt ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
      DBG('Max con amt ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);
      DBG('Max liab amt ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT);

      DBG('calling Ldpkss_Link.Fn_Link_During_Book ..');
      IF NOT LDPKSS_LINK.FN_LINK_DURING_BOOK(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                             'U',
                                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                                             P_ERR_CODE,
                                             P_ERR_PARAMS) THEN
        DBG('Failed in linkeage on book....... ');
        RETURN FALSE;
      END IF;

      IF NOT LCPKS_SAVE.FN_SAVECONTRACT(GLOBAL.USER_ID,
                                        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,

                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,

                                        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE,
                                        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS,
                                        'N',
                                        L_APP_DATE,
                                        L_APP_DATE,

                                        'Y',
                                        'Y',
                                        'Y',
                                        'Y',

                                        L_ERRLIST,
                                        L_ERRPARAMLIST)

       THEN
        DBG('failed in lcpkss_save.fn_SaveContract');
        RETURN FALSE;
      END IF;

    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) THEN

      BEGIN
        SELECT EVENT_CODE
          INTO L_EVT_CODE
          FROM CSTB_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND EVENT_SEQ_NO =
               (SELECT MAX(A.EVENT_SEQ_NO)
                  FROM CSTB_CONTRACT_EVENT_LOG A
                 WHERE A.CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to get  event_code');

      END;

      BEGIN
        SELECT RELATED_REF_NO
          INTO L_REL_REF_NO
          FROM LCTB_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND EVENT_SEQ_NO =
               (SELECT MAX(A.EVENT_SEQ_NO)
                  FROM CSTB_CONTRACT_EVENT_LOG A
                 WHERE A.CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

      EXCEPTION
        WHEN OTHERS THEN
          L_REL_REF_NO := NULL;
          DBG('Failed to get  related_ref_no');

      END;

      IF L_EVT_CODE IN ('AVAL', 'RAVL') THEN
        IF L_REL_REF_NO IS NOT NULL THEN
          DBG('l_Rel_Ref_No' || L_REL_REF_NO);
          DBG('l_Evt_Code' || L_EVT_CODE);
          P_ERR_CODE   := 'LCCON-081';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

      END IF;

      DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Fin_Flag' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_FLAG);
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_FLAG = 'Y' THEN
        DBG('Confirmed Contract can not be Authorized by same user');
        P_ERR_CODE                          := 'LCAMEND-001';
        P_ERR_PARAMS                        := NULL;
        CSPKSS_REQ_GLOBAL.G_FINAL_AUTH_STAT := 'N';
        RETURN TRUE;
      END IF;

      FOR I IN C_EVENT_LOG(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO) LOOP
        DBG('i.Event_Seq_No >>>>>>' || I.EVENT_SEQ_NO);
        DBG('i.Event_Code >>>>>>' || I.EVENT_CODE);
        FOR J IN C_DUAL_AUTH(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                             I.EVENT_SEQ_NO) LOOP

          L_ERR_CODE := J.ERR_CODE;

          L_OVD_TYPE := OVPKSS.FN_GETTYPE(L_ERR_CODE);
          DBG('l_Ovd_Type>>>>>>' || L_OVD_TYPE);

          IF L_OVD_TYPE = 'D' THEN
            DEBUG.PR_DEBUG('LM',
                           'Contract Having Dual Auth Override Setting Auth Status to U');
            L_OVD_STATUS := 'Y';
            EXIT;
          END IF;
        END LOOP;
      END LOOP;

      DBG('l_Status>>>>>>' || L_STATUS);
      DBG('Contract Having Dual Auth Override thats y Exclitly not allowing to Authorize');

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL AND
         L_PRODUCT_TYPE = 'H' AND L_EVT_CODE = 'CLOS' THEN

        DBG('Calling Ldpkss_Link.fn_auth_lc_linkage..... ');
        IF NOT LDPKSS_LINK.FN_CLOSE_LC_SG_LINKAGE(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN

          DBG('Ldpkss_Link.fn_Close_LC_sg_linkage..');
          RETURN FALSE;
        END IF;

      END IF;

      IF L_OVD_STATUS = 'N' THEN
        DBG('l_Status before calling Fn_Authorise>>>>>>' || L_STATUS);
        DBG('call Fn_Authorise..');

        DBG('in auth: ' ||
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO || '-' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO);
        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE <> 'ROPN' THEN
          IF P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO <>
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO THEN
            DBG('increment amendment number flag is checked ... coming here to set global variable');
            LCPKSS_LCDTRONL_UTILS.G_INCR_AMND_NO := TRUE;
          ELSE
            LCPKSS_LCDTRONL_UTILS.G_INCR_AMND_NO := FALSE;

          END IF;

        END IF;

        IF NOT LCPKS_LCDTRAUT_UTILS.FN_AUTHORIZE(P_SOURCE,
                                                 P_SOURCE_OPERATION,
                                                 P_FUNCTION_ID,
                                                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                 'Y',
                                                 P_ERR_CODE,
                                                 P_ERR_PARAMS) THEN
          DBG('Failed in auth');
        END IF;

      END IF;

      DBG('calling the update...');
      BEGIN
        UPDATE LCTB_CONTRACT_MASTER

           SET SUBSYSTEMSTAT = 'MICTRMIS:D;ISCTRSTL:D;TACTRTAX:D;CSCTRUDF:D;CFCTRCHG:D;CFCTRCOM:D;CVS_MAIN__TAB_ADVICES:D;LCCTRCLT:D;LCCILUTL:D;CSCTRSPT:D;BCCTRPRF:D;MSCCOMPM:D;'

         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed over here in update of subsystem');

      END;

      DBG('selecting the status');
      BEGIN
        SELECT SUBSYSTEMSTAT
          INTO L_SUBSYSSTAT
          FROM LCTBS_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('failed');

      END;

      DBG('l_subsysstat' || L_SUBSYSSTAT);

      IF ABKCHANGED = 'Y' OR BENCHANGED = 'Y' OR REBCHANGED = 'Y' THEN

        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM LCTBS_FFTS
           WHERE CONTRACT_REF_NO =
                 P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 P_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO

             AND FFT_INS_CODE IN ('CANCEL', 'CANC')
              OR REGEXP_LIKE(FFT_INS_CODE, '^SND2RECMT\d{3}$');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_COUNT := 0;

        END;

        IF L_COUNT <> 0 THEN
          DELETE FROM LCTB_FFTS
           WHERE CONTRACT_REF_NO =
                 P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 P_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO

             AND FFT_INS_CODE IN ('CANCEL', 'CANC')
              OR REGEXP_LIKE(FFT_INS_CODE, '^SND2RECMT\d{3}$');

        END IF;

      END IF;

      DBG('ROWS DELETED ' || SQL%ROWCOUNT);

    ELSIF P_ACTION_CODE IN (CSPKS_SERVICE.P_COPY) THEN

      DBG('Calling the copy contract ...');
      P_WRK_LCDTRONL := P_LCDTRONL;

      BEGIN
        SELECT *
          INTO L_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER
          FROM LCTBS_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO =
               P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTBS_CONTRACT_MASTER
                 WHERE CONTRACT_REF_NO =
                       P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('INTO Exception when selecting LCTBS_CONTRACT_MASTER');
          RETURN FALSE;

      END;

      IF NOT FN_GENERATE_REF_NO(P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                L_REF_NO,
                                L_USER_REF_NO,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN

        DBG('Failed in Lcpks_Fcj_Lcdtronl_Utils.Fn_Generate_Ref_No..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

      END IF;

      P_WRK_LCDTRONL                                      := P_LCDTRONL;
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_CCY        := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE := P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;
      IF NOT FN_DEFAULT(P_SOURCE,
                        P_SOURCE_OPERATION,
                        P_FUNCTION_ID,
                        CSPKS_REQ_GLOBAL.P_NEW,
                        P_LCDTRONL,
                        L_PREV_LCDTRONL,
                        P_WRK_LCDTRONL,
                        P_ERR_CODE,
                        P_ERR_PARAMS) THEN

        DBG('Failed in Defaulting of the copy...');
      END IF;

      DBG('p_Err_Code-->' || P_ERR_CODE);
      DBG('p_Err_Params-->' || P_ERR_PARAMS);
      OVPKS.PR_INITERRTBL;
      P_ERR_CODE   := NULL;
      P_ERR_PARAMS := NULL;

      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO := L_REF_NO;
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO     := L_USER_REF_NO;
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO := L_REF_NO;

      DBG('calling Lcpkss_Server.Fn_Duplicatecontract...' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

      IF NOT LCPKSS_SERVER.FN_DUPLICATECONTRACT(P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                                P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                                'COPY',
                                                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO

                                               ,
                                                L_APP_DATE

                                               ,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN

        DBG('Failed in the Copy of the contract ...');
        RETURN FALSE;
      END IF;

      IF NOT MIPKSS_REFERRAL.FN_COPY_CONTRACT(P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                              L_REF_NO,
                                              'R') THEN
        DBG('Failed to Copy MIS details');
        RETURN FALSE;
      ELSE
        DBG('MIS details successfully copied :- ');
      END IF;

      BEGIN
        UPDATE LCTB_PARTIES
           SET CUST_REF_NO = NULL, CUST_REF_DATE = NULL
         WHERE CONTRACT_REF_NO = L_REF_NO;

        DBG('RETRO SQLRWOCOUNT: ' || SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Exception occured in Cust Ref No and Date updation to NULL is : ' ||
              SQLERRM);

      END;

      UPDATE CSTB_CONTRACT
         SET EXTERNAL_REF_NO = L_REF_NO
       WHERE CONTRACT_REF_NO = L_REF_NO;

      BEGIN
        UPDATE LCTB_CONTRACT_MASTER

           SET SUBSYSTEMSTAT = 'MICTRMIS:U;ISCTRSTL:D;TACTRTAX:D;CSCTRUDF:D;CFCTRCHG:D;CFCTRCOM:D;CVS_MAIN__TAB_ADVICES:D;LCCTRCLT:D;LCCILUTL:D;CSCTRSPT:D;BCCTRPRF:D;MSCCOMPM:D;'

              ,
               NEXT_REINSTATEMENT_DATE = NULL
         WHERE CONTRACT_REF_NO = L_REF_NO
           AND EVENT_SEQ_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed over here in update of subsystem');

      END;

      BEGIN
        UPDATE LCTB_TRACERS
           SET TRACER_PARTY     = NULL,
               MEDIUM           = NULL,
               SENT_TO_DATE     = NULL,
               LAST_TRACER_DATE = NULL
         WHERE CONTRACT_REF_NO = L_REF_NO;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Update of Lctb_Tracers Failed');

      END;

      DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Set_Event_And_Seq_No...');

      DBG('For Copy subsystem pickup skipped ');

      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT := 'MICTRMIS:D;ISCTRSTL:D;TACTRTAX:D;CSCTRUDF:D;CFCTRCHG:D;CFCTRCOM:D;CVS_MAIN__TAB_ADVICES:D;LCCTRCLT:D;CSCTRSPT:D;MSCCOMPM:D;';

    ELSIF P_ACTION_CODE IN (CSPKS_SERVICE.P_REVERSE) THEN

      DBG('mpkss_collat.fn_allow_amendment.... ');
      IF NOT LMPKSS_COLLAT.FN_ALLOW_AMENDMENT(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                                              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                              L_LINKAGE_REC,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Calling Lcpkss_Delete.Fn_Reversecontract..');
      IF NOT LCPKSS_DELETE.FN_REVERSECONTRACT(GLOBAL.USER_ID,
                                              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
                                              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                              1,
                                              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                                              'REVR'

                                             ,
                                              L_APP_DATE,
                                              L_APP_DATE

                                             ,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
        DBG('Failed in Lcpkss_Delete.Fn_Reversecontract....');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      IF P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS IN ('S', 'K', 'V') THEN

        L_OS_AMOUNT := 0;

      ELSE
        SELECT NVL(SUM(AVAILMENT_AMT), 0)
          INTO L_AVAILMENT_AMT
          FROM LCTBS_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND EVENT_CODE = 'AVAL';

        SELECT NVL(SUM(AVAILMENT_AMT), 0)
          INTO L_REVERSED_AMT
          FROM LCTBS_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND EVENT_CODE IN ('RAVL', 'REVR');

        L_AVAILMENT_AMT := L_AVAILMENT_AMT - L_REVERSED_AMT;

        L_OS_AMOUNT := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT -
                       L_AVAILMENT_AMT;

      END IF;

      DBG('Value of Liability No  ' || L_LIAB_ID);
      DBG('Os Amount ' || L_OS_AMOUNT);

      DBG('Calling lmpkss_Collat.Fn_update_collat_pool_linkage for availment ');
      IF NOT LMPKSS_COLLAT.FN_COLLATERAL_AMENDMENT(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.COUNTERPARTY,
                                                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                   L_OS_AMOUNT,
                                                   L_MODE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN

        DBG('lmpkss_Collat.Fn_update_collat_pool_linkage return false ');
        RETURN FALSE;
      END IF;

    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_HOLD) THEN

      DBG('No Process for hold');
      RETURN TRUE;

    END IF;

    IF P_ACTION_CODE NOT IN
       (CSPKS_REQ_GLOBAL.P_AUTH, CSPKS_REQ_GLOBAL.P_DELETE) THEN
      BEGIN
        UPDATE LCTB_CONTRACT_MASTER
           SET SUBSYSTEMSTAT = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_SEQ_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('failed in updating....');

      END;

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      UPDATE LCTB_CONTRACT_MASTER

         SET SUBSYSTEMSTAT = 'MICTRMIS:D;ISCTRSTL:D;TACTRTAX:D;CSCTRUDF:D;CFCTRCHG:D;CFCTRCOM:D;CVS_MAIN__TAB_ADVICES:D;LCCTRCLT:D;BCCBRDET:D;LCCILUTL:D;CSCTRSPT:D;BCCTRPRF:D;MSCCOMPM:D;'

       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

    END IF;

    FOR SV_ACC_REC IN (SELECT *
                         FROM SVTBS_ACCOUNT_HANDOFF
                        WHERE CONTRACT_REF_NO =
                              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO) LOOP
      IF SV_ACC_REC.ERR_CODE IS NOT NULL THEN
        L_COUNT := 1;
        WHILE (CSPKES_MISC.FN_GETPARAM(SV_ACC_REC.ERR_CODE, L_COUNT, ';') <>
              'EOPL') LOOP
          L_ANERROR := CSPKES_MISC.FN_GETPARAM(SV_ACC_REC.ERR_CODE,
                                               L_COUNT,
                                               ';');
          L_ANPARAM := CSPKES_MISC.FN_GETPARAM(SV_ACC_REC.PARAMETERS,
                                               L_COUNT,
                                               ';');
          L_COUNT   := L_COUNT + 1;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, L_ANERROR, L_ANPARAM);
        END LOOP;
      END IF;
    END LOOP;

    IF P_ACTION_CODE NOT IN (CSPKS_REQ_GLOBAL.P_DELETE,
                             CSPKS_REQ_GLOBAL.P_AUTH,
                             CSPKS_REQ_GLOBAL.P_COPY) THEN
      DBG('Calling the overirides....');
      IF NOT LCPKS_LCDTRONL_UTILS.FN_LOG_OVERRIDES(P_SOURCE,
                                                   P_ACTION_CODE,
                                                   P_WRK_LCDTRONL,
                                                   P_FUNCTION_ID,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN

        DBG('Failed in log overrides');
        RETURN FALSE;
      END IF;

    END IF;

    DBG('Returning from Fn_Process');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_PROCESS;

  FUNCTION FN_VALIDATE_RELATED_REFNO(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                     P_FUNCTION_ID        IN VARCHAR2,
                                     P_ACTION_CODE        IN VARCHAR2,
                                     P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                     P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                     P_ERR_CODE           IN OUT VARCHAR2,
                                     P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_SHIPMENT_DATE    DATE;
    L_EXPIRY_DATE      DATE;
    L_CIFID            LCVWS_UPLOAD_MASTER.CIF_ID%TYPE;
    L_AMOUNT           LCVWS_UPLOAD_MASTER.CONTRACT_AMT%TYPE;
    L_CCY              LCVWS_UPLOAD_MASTER.CONTRACT_CCY%TYPE;
    L_EXCH_RATE        NUMBER(24, 12);
    L_RATE_FLAG        NUMBER(10);
    L_CONT_AMT         LCVWS_UPLOAD_MASTER.CONTRACT_AMT%TYPE;
    L_ERR_CODE         VARCHAR2(20);
    L_PRD_TYP          VARCHAR2(1);
    L_REL_COUNT        NUMBER := 0;
    L_EVENT_CODE       CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE;
    L_CONTRACT_STATUS  CSTBS_CONTRACT.CONTRACT_STATUS%TYPE;
    L_MAX_CONTRACT_AMT LCTB_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;

    L_CURR_AVLABILITY LCTBS_AVAILMENTS.CURRENT_AVAILABILITY%TYPE;
    L_MAX_AMOUNT      LCTB_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;
    L_AVAILABILITY    LCTBS_AVAILMENTS.CURRENT_AVAILABILITY%TYPE;

  BEGIN

    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE NOT IN ('I', 'H') AND
       (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BACK_TO_BACK_LC = 'Y' OR
       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL) THEN

      DBG('Back to Back LC cannot be linked for the Export LC');
      L_ERR_CODE := 'LC-BKB-009';
      OVPKS.PR_APPENDTBL(L_ERR_CODE, NULL);
    END IF;

    IF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'I' THEN
      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BACK_TO_BACK_LC, 'N') = 'N' THEN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL THEN
          DBG('Back to Back LC is Unchecked and thus an Export LC should not be linked to an Import LC');
          L_ERR_CODE := 'LC-BKB-012';
          OVPKS.PR_APPENDTBL(L_ERR_CODE, NULL);
        END IF;

      ELSE
        DBG('Back to Back LC..');
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NULL THEN
          DBG('Back to Back LC is Checked and thus an Export LC should be linked to an Import LC');
          L_ERR_CODE := 'LC-BKB-011';
          OVPKS.PR_APPENDTBL(L_ERR_CODE, NULL);
        ELSE
          BEGIN
            SELECT PRODUCT_TYPE, CONTRACT_STATUS
              INTO L_PRD_TYP, L_CONTRACT_STATUS

              FROM CSTB_CONTRACT
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO;

          EXCEPTION
            WHEN OTHERS THEN
              L_PRD_TYP := 'I';

          END;

          IF L_PRD_TYP <> 'E' THEN

            DBG('Only Export LC can be linked to Import LC');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-103', NULL);
          ELSE

            SELECT COUNT(*)
              INTO L_REL_COUNT
              FROM LCTB_CONTRACT_MASTER
             WHERE RELATED_LC_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO
               AND CONTRACT_REF_NO <>
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

            IF L_REL_COUNT > 0 THEN
              DBG('Related Reference NUmber is alredt attache dto another LC.');
              L_ERR_CODE := 'LC-BKB-014';
              OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
            END IF;

            BEGIN
              SELECT LATEST_SHIPMENT_DATE
                INTO L_SHIPMENT_DATE
                FROM LCTBS_SHIPMENT
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO
                 AND EVENT_SEQ_NO =
                     (SELECT MAX(EVENT_SEQ_NO)
                        FROM LCTBS_SHIPMENT
                       WHERE CONTRACT_REF_NO =
                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO);

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Reference Number linked to the contract is invalid');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-BKB-013', NULL);

            END;

            SELECT COUNT(*)
              INTO L_REL_COUNT
              FROM LCTB_CONTRACT_MASTER
             WHERE RELATED_LC_REF_NO =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO
               AND CONTRACT_REF_NO <>
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

            IF L_REL_COUNT > 0 THEN
              DBG('Related Reference NUmber is alredt attache dto another LC.');
              L_ERR_CODE := 'LC-BKB-014';
              OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
            END IF;

            BEGIN
              SELECT EXPIRY_DATE,
                     CIF_ID,
                     CONTRACT_AMT,
                     CONTRACT_CCY,
                     MAX_CONTRACT_AMT
                INTO L_EXPIRY_DATE,
                     L_CIFID,
                     L_AMOUNT,
                     L_CCY,
                     L_MAX_CONTRACT_AMT
                FROM LCTB_CONTRACT_MASTER
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO
                 AND EVENT_SEQ_NO =
                     (SELECT MAX(EVENT_SEQ_NO)
                        FROM LCTBS_CONTRACT_MASTER
                       WHERE CONTRACT_REF_NO =
                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO);

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Reference Number linked to the contract is invalid');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-BKB-013', NULL);

            END;

            BEGIN
              DBG('Selecting current availability of related LC');
              SELECT CURRENT_AVAILABILITY
                INTO L_CURR_AVLABILITY
                FROM LCTBS_AVAILMENTS
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO
                 AND EVENT_SEQ_NO =
                     (SELECT MAX(EVENT_SEQ_NO)
                        FROM LCTBS_AVAILMENTS
                       WHERE CONTRACT_REF_NO =
                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO);

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('No data found for current availability');
                L_CURR_AVLABILITY := 0;
            END;

            DBG('current availability' || L_CURR_AVLABILITY ||
                'max contract amt' || L_MAX_CONTRACT_AMT);

            IF L_CCY <> P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY THEN
              IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                       L_CCY,
                                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                       'STANDARD',
                                       'M',
                                       L_EXCH_RATE,
                                       L_RATE_FLAG,
                                       L_ERR_CODE) THEN
                DBG('lcpks_upload_create.fn_validate_related_refno ->fn_getrate returned FALSE');
                RETURN FALSE;
              END IF;

              DBG('l_exch_rate ' || L_EXCH_RATE);
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CCY,
                                            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                            L_AMOUNT,
                                            L_EXCH_RATE,
                                            'N',
                                            L_CONT_AMT,
                                            L_ERR_CODE) THEN

                DBG('lcpks_upload_create.fn_validate_related_refno ->fn_amt1_to_amt2 returned FALSE');
                RETURN FALSE;
              END IF;

              DBG('l_max_contract_amt' || L_MAX_CONTRACT_AMT);
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CCY,
                                            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                            L_MAX_CONTRACT_AMT,
                                            L_EXCH_RATE,
                                            'N',
                                            L_MAX_AMOUNT,
                                            L_ERR_CODE) THEN

                DBG('fn_amt1_to_amt2 returned FALSE for l_max_contract_amt');
                RETURN FALSE;
              END IF;

              DBG('l_Curr_Avlability' || L_CURR_AVLABILITY);
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CCY,
                                            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                            L_CURR_AVLABILITY,
                                            L_EXCH_RATE,
                                            'N',
                                            L_AVAILABILITY,
                                            L_ERR_CODE) THEN

                DBG('fn_amt1_to_amt2 returned FALSE for l_Curr_Avlability');
                RETURN FALSE;
              END IF;
              DBG('after conversion l_max_contract_amt' || L_MAX_AMOUNT);
              DBG('after conversion l_Curr_Avlability' || L_AVAILABILITY);

            ELSE
              L_CONT_AMT := L_AMOUNT;

              L_MAX_AMOUNT   := L_MAX_CONTRACT_AMT;
              L_AVAILABILITY := L_CURR_AVLABILITY;

            END IF;

            IF L_CIFID <> P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID THEN
              DBG('Counter Parties should be same for both Import and Export LC');
              L_ERR_CODE := 'LC-BKB-003';
              OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
            END IF;

            IF L_SHIPMENT_DATE IS NOT NULL AND
               P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE IS NOT NULL THEN
              IF L_SHIPMENT_DATE <
                 P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE THEN
                DBG('Latest Shipment Date of Export LC is less than  Latest Shipment Date of Import LC');
                L_ERR_CODE := 'LC-BKB-020';
                OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
              END IF;

            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE >
               L_EXPIRY_DATE THEN
              DBG('Expiry Date of Import LC cannot be greater than  Expiry Date of Export LC');
              L_ERR_CODE := 'LC-BKB-005';
              OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
            END IF;

            DBG('l_cont_amt ' || L_CONT_AMT);
            IF L_CONT_AMT <
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT THEN
              DBG('Import LC Amount is greater than Export LC Amount');
              L_ERR_CODE := 'LC-BKB-006';
              OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
            END IF;

            DBG('l_max_contract_amount ' || L_MAX_AMOUNT);
            IF L_MAX_AMOUNT <
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT THEN

              DBG('Import LC Maximum Amount is greater than Export LC Maximum Amount');
              L_ERR_CODE := 'LC-BKB-016';
              OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT >
               L_AVAILABILITY THEN
              DBG('Available amount in Export LC being linked is less than the Import LC');
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-BKB-021', NULL);
            END IF;

            DBG('Checking for parent-child linkage1 ' || P_ACTION_CODE ||
                L_CONTRACT_STATUS);
            IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
              IF L_CONTRACT_STATUS = 'S' THEN
                DBG('Parent LC has to be reopened first, then only child LC can be reopened');

                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'LC-BKB-007',
                             '@' ||
                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO || '~@' ||
                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO || '~@' ||
                             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO);
              END IF;

            END IF;

          END IF;

        END IF;

      END IF;

    ELSIF P_PRODUCT_DEFINITION.PRODUCT_TYPE = 'H' THEN

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO IS NOT NULL THEN

        BEGIN
          SELECT PRODUCT_TYPE, CONTRACT_STATUS
            INTO L_PRD_TYP, L_CONTRACT_STATUS

            FROM CSTB_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO;

        EXCEPTION
          WHEN OTHERS THEN
            L_PRD_TYP := 'I';

        END;

        SELECT EXPIRY_DATE, CIF_ID, CONTRACT_CCY
          INTO L_EXPIRY_DATE, L_CIFID, L_CCY

          FROM LCTB_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTBS_CONTRACT_MASTER
                 WHERE CONTRACT_REF_NO =
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO);

        DBG('coming to valdiate for PCLS');
        SELECT CURR_EVENT_CODE
          INTO L_EVENT_CODE
          FROM CSTBS_CONTRACT
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO;

        DBG('l_event_code-->' || L_EVENT_CODE);
        IF L_EVENT_CODE = 'PCLS' THEN

          DBG('coming to bomb for PCLS event');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-337', NULL);
        END IF;

        IF L_CCY <> P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY OR
           L_CIFID <> P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID THEN
          DBG('Invalid LC linked as related reference.');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-337', NULL);
        END IF;

        IF L_PRD_TYP <> 'I' THEN

          DBG('Only Import LC  can be linked to Shipping Guarantees');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-102', NULL);
        END IF;

        DBG('Checking for parent-child linkage2 ' || P_ACTION_CODE ||
            L_CONTRACT_STATUS);
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
          IF L_CONTRACT_STATUS = 'S' THEN
            DBG('Parent LC has to be reopened first, then only child LC can be reopened 2');

            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'LC-BKB-007',
                         '@' ||
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO || '~@' ||
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO || '~@' ||
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO);
          END IF;

        END IF;

      END IF;

    END IF;

    RETURN TRUE;
  END FN_VALIDATE_RELATED_REFNO;

  FUNCTION FN_VALIDATE_EVENTCODE(P_SOURCE        IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                 P_FUNCTION_ID   IN VARCHAR2,
                                 P_ACTION_CODE   IN VARCHAR2,
                                 P_LCDTRONL      IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_PREV_LCDTRONL IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_WRK_LCDTRONL  IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_ERR_CODE      IN OUT VARCHAR2,
                                 P_ERR_PARAMS    IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT       NUMBER := 0;
    L_LINKAGE_REC LMTM_POOL_COLLATERAL_LINKAGES%ROWTYPE;
    DUMMY_VAR     CSTMS_PRODUCT_EVENT%ROWTYPE;
    P_EVENT_CODE  VARCHAR2(10);
    L_LIAB_ID     LCTBS_CONTRACT_MASTER.CIF_ID%TYPE;
    L_ERR_CODE    VARCHAR2(11);
    L_ERR_PARAMS  VARCHAR2(2000);
    L_LC_AMT      NUMBER;
    L_LIQD_LC_AMT NUMBER;
    L_REVR_LC_AMT NUMBER;
    TRNS_FLAG     NUMBER(1);
    L_REVOLING    VARCHAR(1);
    L_AVAILMENT   LCTBS_AVAILMENTS%ROWTYPE;
    L_REL_COUNT   NUMBER;
    L_BILL_COUNT  NUMBER := 0;

    L_FROM_LCREF LCTB_TRANSFER_DETAILS.FROM_LCREF%TYPE;
    L_TRN_ESN    LCTB_TRANSFER_DETAILS.ESN%TYPE;

    L_TOT_BLOCK_AMT BCTB_LC_BLOCK_DETAILS.BLOCK_AMT%TYPE;
    L_LQ_COUNT      NUMBER;
  BEGIN
    DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Event_Code' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE);
    DBG('Global.Application_Date' || GLOBAL.APPLICATION_DATE);
    DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Master.Closure_Date' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE);

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_REVERSE,
                         CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      SELECT COUNT(*)
        INTO L_REL_COUNT
        FROM LCTB_CONTRACT_MASTER
       WHERE RELATED_LC_REF_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

      IF L_REL_COUNT > 0 THEN

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE IN ('E') THEN

          DBG('This export is related with another Import');
          L_ERR_CODE := 'LC-BKB-015';
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-BKB-015', L_ERR_PARAMS);

        ELSIF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE IN ('I') THEN
          DBG('This contract is likned with a SG contract');
          L_ERR_CODE := 'LC-BKB-022';
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-BKB-022', L_ERR_PARAMS);
        END IF;

      END IF;

    END IF;

    IF P_ACTION_CODE NOT IN
       (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_COPY) THEN
      BEGIN
        SELECT COUNT(1)
          INTO TRNS_FLAG
          FROM CSTBS_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND EVENT_CODE = 'TRNF'
           AND AUTH_STATUS = 'U';

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Bombed in SELECT STMT' || SQLERRM);
          TRNS_FLAG := 0;
      END;

      DBG('Trns_Flag' || TRNS_FLAG);
      IF TRNS_FLAG > 0 THEN
        DBG('Last Event can be $1 only from Transfer Function');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-025', NULL);
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_DELETE) THEN
      BEGIN
        SELECT FROM_LCREF, ESN
          INTO L_FROM_LCREF, L_TRN_ESN
          FROM LCTBS_TRANSFER_DETAILS
         WHERE TO_LCREF = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Bombed in selecting From LC refernce number' || SQLERRM);
      END;
      DBG('l_from_lcref' || L_FROM_LCREF);
      DBG('l_trn_esn' || L_TRN_ESN);
      BEGIN
        SELECT COUNT(1)
          INTO TRNS_FLAG
          FROM CSTBS_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO = L_FROM_LCREF
           AND EVENT_SEQ_NO = L_TRN_ESN
           AND EVENT_CODE = 'TRNF'
           AND AUTH_STATUS = 'U';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Bombed in SELECT STMT' || SQLERRM);
          TRNS_FLAG := 0;
      END;

      DBG('Trns_Flag' || TRNS_FLAG);
      IF TRNS_FLAG > 0 THEN
        DBG('Child LC cannot be modified before authorizing the transfer event');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-067', NULL);
      END IF;
    END IF;

    P_EVENT_CODE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE;

    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE IN
       ('CLOS', 'CANC') THEN

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE = 'CLOS' THEN

        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS := 'S';
      ELSE
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS := 'K';

      END IF;

      IF P_EVENT_CODE IN ('CANC', 'CLOS') THEN

        L_LIAB_ID := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID;
        DBG('Calling lmpkss_collat ');
        IF NOT LMPKSS_COLLAT.FN_ALLOW_AMENDMENT(L_LIAB_ID,
                                                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                L_LINKAGE_REC,
                                                L_ERR_CODE,
                                                L_ERR_PARAMS) THEN

          DBG(' lmpkss_collat return false');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, L_ERR_CODE, L_ERR_PARAMS);
        ELSE
          DBG(' lmpkss_collat return true');
          IF L_ERR_CODE IS NOT NULL THEN

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, L_ERR_CODE, L_ERR_PARAMS);
          END IF;

        END IF;

      END IF;

      BEGIN
        SELECT *
          INTO DUMMY_VAR
          FROM CSTMS_PRODUCT_EVENT
         WHERE PRODUCT_CODE = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE
           AND EVENT_CODE = P_EVENT_CODE;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('The event $1 is not maintained for this product');

          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LCCON-076',
                       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE);

      END;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO !=
         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO THEN

        DBG('This Is Not The Latest Version');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-002', NULL);
      END IF;

      SELECT SUM(LC_AMT)
        INTO L_LC_AMT
        FROM (SELECT *
                FROM BCTB_CONTRACT_MASTER A
               WHERE A.OUR_LC_REF =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                 AND A.LC_FLAG = 'Y'
                 AND A.EVENT_SEQ_NO =
                     (SELECT MAX(EVENT_SEQ_NO)
                        FROM BCTB_CONTRACT_MASTER B
                       WHERE B.BCREFNO = A.BCREFNO)
                 AND EXISTS (SELECT 1
                        FROM CSTB_CONTRACT C
                       WHERE C.CONTRACT_REF_NO = A.BCREFNO

                         AND C.CONTRACT_STATUS = 'A'));

      SELECT SUM(DECODE(EVENT_CODE, 'LIQD', A.BILL_AMT_LIQD, 0)),
             SUM(DECODE(EVENT_CODE, 'REVR', A.BILL_AMT_LIQD, 0))
        INTO L_LIQD_LC_AMT, L_REVR_LC_AMT

        FROM BCTB_CONTRACT_MASTER A
       WHERE A.OUR_LC_REF = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EXISTS (SELECT 1
                FROM CSTB_CONTRACT C
               WHERE C.CONTRACT_REF_NO = A.BCREFNO

                 AND C.CONTRACT_STATUS = 'A');

      BEGIN
        SELECT SUM(BLOCK_AMT)
          INTO L_TOT_BLOCK_AMT
          FROM BCTB_LC_BLOCK_DETAILS
         WHERE LCREFNO = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND BLOCK_STATUS = 'U';
      EXCEPTION
        WHEN OTHERS THEN
          L_TOT_BLOCK_AMT := 0;
      END;

      IF NVL(L_LC_AMT, 0) <>
         (NVL(L_LIQD_LC_AMT, 0) - NVL(L_REVR_LC_AMT, 0)) OR
         NVL(L_TOT_BLOCK_AMT, 0) <> 0 THEN
        DBG('LC is linked to some BC(s)');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-351', NULL);
      END IF;

      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM LCTBS_CONTRACT_MASTER
         WHERE RELATED_LC_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        IF L_COUNT > 0 THEN
          P_ERR_CODE := 'LC-BKB-008';
          OVPKS.PR_APPENDTBL(P_ERR_CODE, NULL);
          DBG('Error Code:' || P_ERR_CODE);
          DBG('This Export LC is Linked to an Import LC.So the above action cannot be performed');
        END IF;

      END;

    ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE IN ('ROPN') THEN

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE IN ('H') THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-502', NULL);
      END IF;

      L_LIAB_ID := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID;
      DBG('Calling lmpkss_collat');
      IF NOT LMPKSS_COLLAT.FN_ALLOW_AMENDMENT(L_LIAB_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_LINKAGE_REC,
                                              L_ERR_CODE,
                                              L_ERR_PARAMS) THEN

        DBG(' lmpkss_collat return false');

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, L_ERR_CODE, L_ERR_PARAMS);
      ELSE
        DBG(' lmpkss_collat return true');
        IF L_ERR_CODE IS NOT NULL THEN

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, L_ERR_CODE, L_ERR_PARAMS);
        END IF;

      END IF;

      BEGIN
        SELECT *
          INTO DUMMY_VAR
          FROM CSTMS_PRODUCT_EVENT
         WHERE PRODUCT_CODE = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE
           AND EVENT_CODE = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE;

        RETURN TRUE;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('The event $1 is not maintained for this product');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'LCCON-076',
                       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE);

      END;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO !=
         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO THEN

        DBG('This Is Not The Latest Version');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-002', NULL);
      END IF;

    ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE IN ('REIN') THEN

      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO !=
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO THEN
        DBG('The version numbers are different');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-002', NULL);

      END IF;

      SELECT COUNT(*)
        INTO L_COUNT
        FROM CSTMS_PRODUCT_EVENT
       WHERE PRODUCT_CODE = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE
         AND EVENT_CODE = 'REIN';

      IF L_COUNT = 0 THEN
        DBG('Failed in fn_validate');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-076', NULL);

      END IF;

      BEGIN
        SELECT REVOLVING
          INTO L_REVOLING
          FROM LCTMS_PRODUCT_DEFINITION
         WHERE PRODUCT_CODE = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Product revolving or not is not find' ||
              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE);

      END;

      IF NVL(L_REVOLING, 'N') = 'N' THEN

        DBG('Cannot rollover');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-104', NULL);

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN = 'T' AND

         NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE,
             GLOBAL.APPLICATION_DATE) > GLOBAL.APPLICATION_DATE THEN
        DBG('Cannot revolve');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-049', NULL);

      END IF;

      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE, 'M') = 'A' THEN

        DBG('override for conformation');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-047', NULL);

        BEGIN
          SELECT *
            INTO L_AVAILMENT
            FROM LCTBS_AVAILMENTS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(LATEST_EVENT_SEQ_NO)
                    FROM CSTBS_CONTRACT
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Failed to fetch');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-105', NULL);

        END;

        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE, 'X') = 'N' THEN
          IF L_AVAILMENT.OS_LIABILITY <
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT THEN

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-048', NULL);

          END IF;

        ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE, 'X') = 'C' THEN
          IF L_AVAILMENT.OS_LIABILITY < P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT +
             L_AVAILMENT.CURRENT_AVAILABILITY THEN

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-048', NULL);

          END IF;

        END IF;

      END IF;

      DBG('Calling lmpkss_Collat.fn_allow_amendment');
      IF NOT LMPKSS_COLLAT.FN_ALLOW_AMENDMENT(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                                              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                              L_LINKAGE_REC,
                                              L_ERR_CODE,
                                              L_ERR_PARAMS) THEN

        DBG('Failed in lmpkss_Collat.fn_allow_amendment');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, L_ERR_CODE, L_ERR_PARAMS);

      ELSE
        IF L_ERR_CODE IS NOT NULL THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, L_ERR_CODE, L_ERR_PARAMS);
        END IF;

      END IF;

    ELSIF P_EVENT_CODE = 'REVR' THEN

      DBG('Before fetching Bill Count');
      SELECT COUNT(*)
        INTO L_BILL_COUNT
        FROM (SELECT DISTINCT BCREFNO
                FROM BCTB_CONTRACT_MASTER A
               WHERE A.OUR_LC_REF =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                 AND A.LC_FLAG = 'Y'
                 AND A.BCREFNO IN (SELECT CONTRACT_REF_NO
                                     FROM CSTB_CONTRACT C
                                    WHERE C.CONTRACT_REF_NO = A.BCREFNO
                                      AND C.CONTRACT_STATUS IN ('A', 'L')
                                       OR C.AUTH_STATUS = 'U'));

      DBG('l_Bill_Count' || L_BILL_COUNT);
      IF L_BILL_COUNT > 0 THEN
        DBG('LC is linked to some BC(s)');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-351', NULL);
      END IF;

      SELECT COUNT(*)
        INTO L_LQ_COUNT
        FROM CSTBS_CHG_LIQ A
       WHERE A.CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND LATEST_EVENT_SEQ_NO =
             (SELECT MAX(LATEST_EVENT_SEQ_NO)
                FROM CSTBS_CHG_LIQ B
               WHERE B.LIQ_REF_NO = A.LIQ_REF_NO)
         AND LATEST_EVENT_CODE <> 'ZRVR';
      DBG('Count of LQ contracts associated with this LC' || L_LQ_COUNT);
      IF L_LQ_COUNT > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LQ-REV-001', NULL);
      END IF;

    END IF;

    DBG('Returning true from Fn_Validate_Eventcode');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE_EVENTCODE;

  FUNCTION FN_VALIDATE_DEFAULT(P_SOURCE           IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                               P_SOURCE_OPERATION IN VARCHAR2,
                               P_FUNCTION_ID      IN VARCHAR2,
                               P_ACTION_CODE      IN VARCHAR2,
                               P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                               P_PREV_LCDTRONL    IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                               P_WRK_LCDTRONL     IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                               P_ERR_CODE         IN OUT VARCHAR2,
                               P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_LCTMS_PRDUCT_DEFINITIION LCTMS_PRODUCT_DEFINITION%ROWTYPE;
    L_SWIFT2019_ENABLED        VARCHAR2(1);
  BEGIN
    DBG('Inside  Fn_validate_Default' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);

    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
       ('OPN', 'ONC', 'PAD', 'ADV', 'CNF', 'ANC', 'RMB') THEN
      DBG('Invalid operation code' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
      P_ERR_CODE   := 'LCUPLD-067';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
    END IF;

    DBG('p_Lcdtronl.v_Cstbs_Contract.Product_Code' ||
        P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE);
    BEGIN
      SELECT *
        INTO L_LCTMS_PRDUCT_DEFINITIION
        FROM LCTMS_PRODUCT_DEFINITION
       WHERE PRODUCT_CODE = P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in select');

    END;

    BEGIN
      SELECT PARAM_VAL
        INTO L_SWIFT2019_ENABLED
        FROM CSTB_PARAM
       WHERE PARAM_NAME = 'SWIFTTRADE2019_ENABLED';
    EXCEPTION
      WHEN OTHERS THEN
        L_SWIFT2019_ENABLED := 'N';
        DEBUG.PR_DEBUG('LC', 'Failed in selecting swift enabled param');
    END;
    DBG('l_swift2019_enabled-->' || L_SWIFT2019_ENABLED);

    DBG(' l_Lctms_Prduct_Definitiion.Product_Type' ||
        L_LCTMS_PRDUCT_DEFINITIION.PRODUCT_TYPE);
    IF L_LCTMS_PRDUCT_DEFINITIION.PRODUCT_TYPE != 'E' THEN

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
         ('OPN', 'ONC', 'RMB', 'PAD')

         OR (L_LCTMS_PRDUCT_DEFINITIION.PRODUCT_TYPE IN ('G', 'H') AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD')

       THEN
        DBG('Invalid combination of product code and operation code');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-088', NULL);
      END IF;

    ELSE
      IF L_LCTMS_PRDUCT_DEFINITIION.ADVICE_OF_GUARANTEE = 'Y' THEN

        IF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
           ('ADV') AND L_SWIFT2019_ENABLED = 'N') OR
           (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
           ('ADV', 'ANC') AND L_SWIFT2019_ENABLED = 'Y') THEN

          DBG('Invalid combination of product code and operation code');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-088', NULL);
        END IF;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
            ('ADV', 'ANC', 'CNF', 'PAD') THEN
        DBG('Invalid combination of product code and operation code');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-088', NULL);

      END IF;

    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRE_ADV_DATE >
       GLOBAL.APPLICATION_DATE THEN
      DBG('Pre Advice Date cannot be greater than application date');
      P_ERR_CODE   := 'LCUPLD-360';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('Retruning from  Fn_validate_Default');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_VALIDATE_DEFAULT;

  FUNCTION FN_VALIDATE_DELETE(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_FUNCTION_ID  IN VARCHAR2,
                              P_WRK_LCDTRONL IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_ERR_CODE     IN OUT VARCHAR2,
                              P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_UDTBS_CTRL_COUNT NUMBER;
    L_MIN_ESN_EVENT    CSTBS_CONTRACT_EVENT_LOG.EVENT_CODE%TYPE;
    TRNS_FLAG          NUMBER(1);
    COUNTIS            NUMBER;
    L_AMND_COUNT       NUMBER(3);
    L_PRODUCT_TYPE     CSTBS_CONTRACT.PRODUCT_TYPE%TYPE;
    L_BILL_LINK        NUMBER;
    L_CL_LINK          NUMBER;
    L_EVENT_SEQ_NO     CSTBS_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE;
    L_SGLINK           NUMBER;
    L_AMND_CNT         NUMBER := 0;

  BEGIN
    DBG('Checking Last Amendment');

    DBG('Checking For Event Code From Amendment ' ||
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.EVENT_CODE);

    SELECT COUNT(1)
      INTO L_AMND_COUNT
      FROM CSTBS_CONTRACT_EVENT_LOG
     WHERE CONTRACT_REF_NO =
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
       AND EVENT_CODE = 'AMNV'
       AND CHECKER_ID IS NULL
       AND AUTH_STATUS = 'U';

    DBG('l_Amnd_Count' || L_AMND_COUNT);

    IF L_AMND_COUNT > 0

     THEN
      P_ERR_CODE   := 'LC-AMNV2';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-AMNV2', NULL);
      RETURN FALSE;

    END IF;

    DBG('p_Wrk_Lcdtronl.v_Cstbs_Ui_Columns.Char_Field1 ' ||
        P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1);
    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_FLAG = 'Y' AND
       P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 NOT IN
       ('LCDAMEND', 'LIDAMEND') THEN
      DBG('Now we are trying to delete  financial amendment thru lcdtronl,Hence deletion not allowed');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-AMND-006', NULL);
      RETURN FALSE;
    END IF;

    DBG('Checking Auth Status');
    IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTH_STATUS = 'A' THEN

      DBG('Auth Status Check Failed...');

      P_ERR_CODE   := 'LC-AMND2';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-009', NULL);
    END IF;

    DBG('Checking Version Number');
    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO !=
       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO THEN
      DBG('Version Number Check Failed...');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-002', NULL);
    END IF;

    DBG('Checking User Defined Events');
    SELECT COUNT(*)
      INTO L_UDTBS_CTRL_COUNT
      FROM UDTBS_CONTRACT_CONTROL
     WHERE CONTRACT_REF_NO =
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

    DBG('in lccononl_del:' || L_UDTBS_CTRL_COUNT);
    IF L_UDTBS_CTRL_COUNT > 0 THEN
      DBG('User Defined Events Check Failed...');
      P_ERR_CODE   := 'LC-AMND2';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'UD-EVE205', NULL);
    END IF;

    DBG('Checking Template Status');
    IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.TEMPLATE_STATUS = 'Y' THEN

      DBG('Template Status Check Failed...');
      P_ERR_CODE   := 'LCCON-007';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('FCAT p_Wrk_Lcdtronl.Tronl_ cstbs_Contract.contract_status ' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS);
    IF GLOBAL.USER_ID != P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.MAKER_ID AND
       P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS <> 'H' THEN
      DBG('Maker ID Check Failed...');
      P_ERR_CODE   := 'LCCON-083';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('Checking Event Code');
    IF P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.EVENT_CODE IN
       ('AVAL', 'RAVL') THEN
      DBG('Event Code Check Failed...1');
      P_ERR_CODE   := 'LCCON-082';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

    END IF;

    BEGIN
      SELECT EVENT_CODE, EVENT_SEQ_NO
        INTO L_MIN_ESN_EVENT, L_EVENT_SEQ_NO

        FROM CSTBS_CONTRACT_EVENT_LOG
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MIN(EVENT_SEQ_NO)
                               FROM CSTBS_CONTRACT_EVENT_LOG
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND CHECKER_ID IS NULL
                                AND AUTH_STATUS = 'U');

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_MIN_ESN_EVENT := 'ASDF';
      WHEN OTHERS THEN
        DBG('INTO EXCEPTION');
        DBG('Event Code Check Failed...2');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-010', NULL);

    END;

    IF L_MIN_ESN_EVENT IN ('CLIQ', 'RLIQ') THEN

      DBG('Event Code Check Failed...3');
      P_ERR_CODE   := 'LC-PMT06';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('l_min_esn_event' || L_MIN_ESN_EVENT);
    DBG('p_function_id' || P_FUNCTION_ID);

    IF L_MIN_ESN_EVENT IN ('ACON') AND
       P_FUNCTION_ID NOT IN ('LCDAMEND', 'LIDAMEND') THEN

      DBG('RASK COMING HERE');
      P_ERR_CODE   := 'LCCON-132';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('p_wrk_lcdtronl.v_lctbs_contract_master.event_seq_no-->' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
    SELECT COUNT(*)
      INTO L_AMND_CNT
      FROM LCTB_AMND_VALS_MASTER
     WHERE CONTRACT_REF_NO =
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
       AND AMND_SEQ_NO =
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;
    DBG('l_amnd_cnt-->' || L_AMND_CNT);
    IF L_MIN_ESN_EVENT IN ('AMND', 'CANC') AND L_AMND_CNT > 0 AND
       P_FUNCTION_ID NOT IN ('LCDAMEND', 'LIDAMEND', 'LCDGUAMD') THEN
      DBG('AMND and CANC from LCDAMEND cannot be deleted here');
      P_ERR_CODE   := 'LCCON-132';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    SELECT PRODUCT_TYPE
      INTO L_PRODUCT_TYPE
      FROM CSTBS_CONTRACT
     WHERE CONTRACT_REF_NO =
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

    SELECT COUNT(1)
      INTO L_BILL_LINK
      FROM LDTBS_CONTRACT_LINKAGES
     WHERE LINKED_TO_REF = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO

       AND LINKAGE_TYPE = 'S';

    IF L_MIN_ESN_EVENT = 'CANC' AND L_PRODUCT_TYPE = 'H' AND
       L_BILL_LINK > 0 THEN
      DBG('Independent Deletion Of Event CANC Is Not Allowed');
      P_ERR_CODE   := 'LC-DEL01';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    SELECT COUNT(1)
      INTO L_SGLINK
      FROM LDTBS_CONTRACT_LINKAGES
     WHERE LINKED_TO_REF = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
       AND LINKAGE_TYPE = 'L';

    IF L_MIN_ESN_EVENT = 'BKSG' AND L_SGLINK > 0 THEN
      DBG('LC is linked to a Shipping Guarantee. Independent Deletion Of Event Is Not Allowed.');
      P_ERR_CODE   := 'LC-DEL03';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    SELECT COUNT(1)
      INTO L_CL_LINK
      FROM LDTBS_CONTRACT_LINKAGES
     WHERE EVENT_SEQ_NO = L_EVENT_SEQ_NO
       AND LINKAGE_TYPE = 'C'
       AND LINKED_TO_REF = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

    IF L_MIN_ESN_EVENT IN ('BISS', 'AMND') AND L_CL_LINK > 0 THEN
      DBG('CL account created has to be manually reversed ');
      P_ERR_CODE   := 'LC-DEL01';
      P_ERR_PARAMS := NULL;

    END IF;

    IF P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.EVENT_CODE = 'TRNF' THEN

      DBG('Event Code Check Failed...4');
      P_ERR_CODE   := 'LC-TRNF-025';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('Event Code Check Success...');
    DBG('Checking Transaction Flag');
    BEGIN
      SELECT 1
        INTO TRNS_FLAG
        FROM LCTBS_TRANSFER_DETAILS
       WHERE TO_LCREF = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND AUTH_STATUS = 'U';

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        TRNS_FLAG := 0;
      WHEN OTHERS THEN
        DBG('Bombed in SELECT STMT' || SQLERRM);
        DBG('Transaction Flag Check Failed...1');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-010', NULL);

    END;

    IF TRNS_FLAG = 1 THEN
      DBG('Transaction Flag Check Failed...2');
      P_ERR_CODE   := 'LC-TRNF-025';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    END IF;

    DBG('Transaction Flag Check Success...');

    DBG('cstbs_ext_contract_stat Count Check Success...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Some Other Exception ->' || SQLERRM);
      OVPKS.PR_APPENDTBL('LCCON-108', NULL);
      RETURN FALSE;

  END FN_VALIDATE_DELETE;

  FUNCTION FN_UPDATE_POL_UTIL_AMT(P_SOURCE             IN VARCHAR2,
                                  P_FUNCTION_ID        IN VARCHAR2,
                                  P_OPEN_POLICY_CODE   IN LCTB_OPEN_POLICY.OPEN_POLICY_CODE%TYPE,
                                  P_CONTRACT_AMOUNT    IN NUMBER,
                                  P_SIGN               IN VARCHAR2,
                                  P_POSITIVE_TOLERANCE IN LCTB_CONTRACT_MASTER.POSITIVE_TOLERANCE%TYPE,
                                  P_NEGATIVE_TOLERANCE IN LCTB_CONTRACT_MASTER.NEGATIVE_TOLERANCE%TYPE,
                                  P_ERR_CODE           IN OUT VARCHAR2,
                                  P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_LC_OPEN_POLICY     LCTB_OPEN_POLICY%ROWTYPE;
    L_TOLERANCE          NUMBER;
    P_UTILIZATION_AMOUNT LCTB_OPEN_POLICY.UTILIZATION_AMT%TYPE;
    P_AVAIL_AMT          LCTB_OPEN_POLICY.AVAIL_AMT%TYPE;

  BEGIN
    L_TOLERANCE := 1;

    BEGIN
      DEBUG.PR_DEBUG('BC', 'Inside Fn_update_pol_util_Amt');

      BEGIN
        SELECT *
          INTO L_LC_OPEN_POLICY
          FROM LCTBS_OPEN_POLICY
         WHERE OPEN_POLICY_CODE = P_OPEN_POLICY_CODE;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('BC', 'No data found in lctbs_open_policy');
          P_ERR_CODE := 'LC-INR002';
          OVPKS.PR_APPENDTBL(P_ERR_CODE, NULL);
          DBG('Error Code:' || P_ERR_CODE);

      END;

      L_LC_OPEN_POLICY .MOD_NO := L_LC_OPEN_POLICY.MOD_NO + 1;
      P_UTILIZATION_AMOUNT := NVL(L_LC_OPEN_POLICY.UTILIZATION_AMT, 0);
      DEBUG.PR_DEBUG('BC',
                     'l_Lc_open_policy.mod_no' || L_LC_OPEN_POLICY.MOD_NO);
      DEBUG.PR_DEBUG('BC', 'p_utilization_amount' || P_UTILIZATION_AMOUNT);
      DEBUG.PR_DEBUG('BC', 'P_contract_amount' || P_CONTRACT_AMOUNT);

      IF NVL(P_POSITIVE_TOLERANCE, 0) <> 0 THEN
        L_TOLERANCE := L_TOLERANCE + (NVL(P_POSITIVE_TOLERANCE, 0) / 100);
      ELSIF NVL(P_NEGATIVE_TOLERANCE, 0) <> 0 THEN
        L_TOLERANCE := L_TOLERANCE - (NVL(P_NEGATIVE_TOLERANCE, 0) / 100);

      END IF;

      IF (P_SIGN = 'PLUS') THEN

        P_UTILIZATION_AMOUNT := P_UTILIZATION_AMOUNT +
                                (L_TOLERANCE * NVL(P_CONTRACT_AMOUNT, 0));

      ELSIF (P_SIGN = 'MINUS') THEN

        P_UTILIZATION_AMOUNT := P_UTILIZATION_AMOUNT -
                                (L_TOLERANCE * NVL(P_CONTRACT_AMOUNT, 0));

      END IF;

      P_AVAIL_AMT := L_LC_OPEN_POLICY.SUM_ASSURED_AMT -
                     P_UTILIZATION_AMOUNT;
      DEBUG.PR_DEBUG('BC',
                     'Updating utilization amt and mod no in lctb_open_policy');

      IF NVL(P_AVAIL_AMT, 0) < 0 THEN
        P_AVAIL_AMT          := 0;
        P_UTILIZATION_AMOUNT := L_LC_OPEN_POLICY.SUM_ASSURED_AMT;

      END IF;

      IF NVL(P_UTILIZATION_AMOUNT, 0) < 0 THEN
        P_UTILIZATION_AMOUNT := 0;
        P_AVAIL_AMT          := L_LC_OPEN_POLICY.SUM_ASSURED_AMT;
      END IF;

      BEGIN
        UPDATE LCTB_OPEN_POLICY
           SET UTILIZATION_AMT = P_UTILIZATION_AMOUNT,
               MOD_NO          = L_LC_OPEN_POLICY.MOD_NO,
               AVAIL_AMT       = P_AVAIL_AMT
         WHERE OPEN_POLICY_CODE = P_OPEN_POLICY_CODE;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('BC', 'No data found in lctbs_open_policy');
          P_ERR_CODE := 'LC-INR002';
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, NULL);
          DBG('Error Code:' || P_ERR_CODE);

      END;

    END;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'FAILED inside Fn_update_pol_util_Amt');
      DEBUG.PR_DEBUG('BC', 'ERROR IS - ' || SQLERRM);
      RETURN FALSE;

  END FN_UPDATE_POL_UTIL_AMT;

  FUNCTION FN_OPEN_POLICY_UPDATE(P_SOURCE          IN VARCHAR2,
                                 P_FUNCTION_ID     IN VARCHAR2,
                                 P_SIGN            IN VARCHAR2,
                                 P_AMT             IN NUMBER,
                                 P_REF_NO          IN VARCHAR2,
                                 P_DELINKCHECKFLAG IN VARCHAR2,
                                 P_WRK_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_ERR_CODE        IN OUT VARCHAR2,
                                 P_ERR_PARAMS      IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_OPEN_POLICY_FLG         VARCHAR2(1);
    L_POLICY_NUMBER           VARCHAR2(105);
    L_POS_TOL                 NUMBER := 0;
    L_NEG_TOL                 NUMBER := 0;
    L_AMT                     NUMBER;
    L_UPDATE_UTILIZATION_FLAG VARCHAR2(1);

    CURSOR C_DRAFTS IS
      SELECT *
        FROM LCTB_DRAFTS
       WHERE CONTRACT_REF_NO = P_REF_NO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM LCTB_DRAFTS
               WHERE CONTRACT_REF_NO = P_REF_NO);

  BEGIN
    DBG('Inside fn_open_policy_update..');

    FOR DRAFT IN C_DRAFTS LOOP

      L_OPEN_POLICY_FLG := NVL(DRAFT.OPEN_POLICY_FLAG, 'N');
      L_POLICY_NUMBER   := DRAFT.INSURANCE_POLICY_NO;

      IF P_DELINKCHECKFLAG = 'Y' THEN
        IF NVL(DRAFT.DELINK_FLAG, 'N') = 'Y' THEN

          UPDATE LCTB_DRAFTS
             SET OPEN_POLICY_FLAG = 'Y', DELINK_FLAG = NULL

           WHERE CONTRACT_REF_NO = P_REF_NO
             AND EVENT_SEQ_NO = DRAFT.EVENT_SEQ_NO
             AND DRAFT_SL_NO = DRAFT.DRAFT_SL_NO
             AND DELINK_FLAG = 'Y';

        END IF;

      END IF;

      IF L_OPEN_POLICY_FLG = 'Y' AND L_POLICY_NUMBER IS NOT NULL THEN
        BEGIN
          SELECT AUTO_UPDATE_UTILIZATION
            INTO L_UPDATE_UTILIZATION_FLAG
            FROM LCTB_OPEN_POLICY
           WHERE OPEN_POLICY_CODE = L_POLICY_NUMBER;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in selectiong from Lctb_Open_Policy..' ||
                L_POLICY_NUMBER);
            L_UPDATE_UTILIZATION_FLAG := 'N';

        END;

        IF L_UPDATE_UTILIZATION_FLAG = 'Y' THEN

          DBG('Calling POlicy Utilization..');
          L_AMT     := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                           0);
          L_POS_TOL := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                           0);
          L_NEG_TOL := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                           0);

          IF NOT FN_UPDATE_POL_UTIL_AMT(P_SOURCE,
                                        P_FUNCTION_ID,
                                        L_POLICY_NUMBER,
                                        P_AMT,
                                        P_SIGN,
                                        L_POS_TOL,
                                        L_NEG_TOL,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN

            DBG('failed in updating utilization amount for Policy Policy.');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

        ELSE

          DBG('Utilization Amount Needs to be updated manually for the Open Policy ');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-INR008', NULL);

        END IF;

      END IF;

    END LOOP;

    DBG('Retruning true from fn_open_policy_update');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of fn_open_policy_update');
      DBG(SQLERRM);
      RETURN FALSE;

  END FN_OPEN_POLICY_UPDATE;

  FUNCTION FN_GET_FID_ACTION(P_FINC_ID     IN OUT VARCHAR2,
                             P_ACTION_CODE IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN
    DBG('In Fn_Get_Fid_Action....');

    P_FINC_ID     := G_CALLING_FUNCTION;
    P_ACTION_CODE := G_ACTION_CODE;

    DBG('Returning from  Fn_Get_Fid_Action....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of Fn_Get_Fid_Action');
      DBG(SQLERRM);
      RETURN FALSE;

  END;

  FUNCTION FN_UPLD760(P_SOURCE          IN VARCHAR2,
                      P_FUNCTION_ID     IN VARCHAR2,
                      P_USER_ID         IN VARCHAR2,
                      P_DCN             IN MSTBS_DLY_MSG_IN.DCN%TYPE,
                      P_CONTRACT_REF_NO IN LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO%TYPE,
                      P_VERSION_NO      IN LCTBS_CONTRACT_MASTER.VERSION_NO%TYPE,
                      P_EVENT_SEQ_NO    IN LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE,
                      P_EVENT_CODE      IN LCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE,
                      P_MSG_TYPE        IN CSTBS_CONTRACT_EVENT_ADVICE.MSG_TYPE%TYPE,
                      P_PARTY_TYPE      IN CSTBS_CONTRACT_EVENT_ADVICE.PARTY_TYPE%TYPE,
                      P_ERR_CODE        IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                      P_ERR_PARAMS      IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN
    DBG('Inside fn_upld760..');

    DBG('Calling lcpkss_upload_MT760.fn_process_msg_for_upload..');
    IF NOT LCPKSS_UPLOAD_MT760.FN_PROCESS_MSG_FOR_UPLOAD(P_USER_ID,
                                                         '760',
                                                         P_DCN,
                                                         P_CONTRACT_REF_NO,
                                                         P_VERSION_NO,
                                                         P_EVENT_SEQ_NO,
                                                         P_EVENT_CODE,
                                                         P_MSG_TYPE,
                                                         P_PARTY_TYPE,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
      DBG('failed in lcpkss_upload_MT760.fn_process_msg_for_upload.');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;

    DBG('Returning from Fn_Upld760....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of Fn_Upld760');
      DBG(SQLERRM);
      RETURN FALSE;

  END FN_UPLD760;

  FUNCTION FN_GET_INS_AMT_LCY(P_CONTRACT_REF_NO VARCHAR2,
                              P_INS_CCY         VARCHAR2,
                              P_INS_AMT         BCTM_CUSTOMER_INSURANCE.UTILIZATION_AMT%TYPE,
                              P_UTL_AMT         BCTM_CUSTOMER_INSURANCE.UTILIZATION_AMT%TYPE,
                              P_CONTRACT_CCY    VARCHAR2) RETURN NUMBER IS
    L_INS_AMT    NUMBER;
    L_RATE       VARCHAR2(100);
    L_ERROR_CODE VARCHAR2(200);

  BEGIN

    IF NOT CYPKSS.FN_AMT1_TO_AMT2(SUBSTR(P_CONTRACT_REF_NO, 1, 3),
                                  P_INS_CCY,
                                  P_CONTRACT_CCY,
                                  'STANDARD',
                                  'M',
                                  P_INS_AMT - P_UTL_AMT,
                                  'Y',
                                  L_INS_AMT,
                                  L_RATE,
                                  L_ERROR_CODE) THEN
      DEBUG.PR_DEBUG('LC', 'Failed in Amount Conversion:' || SQLERRM);
    END IF;

    RETURN L_INS_AMT;

  END FN_GET_INS_AMT_LCY;

  FUNCTION FN_ANY_FIELD_MODIFIED(P_SOURCE           IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                 P_AMENDABLE_NODES  IN CSPKS_REQ_GLOBAL.TY_AMEND_NODES,
                                 P_AMENDABLE_FIELDS IN CSPKS_REQ_GLOBAL.TY_AMEND_FIELDS,
                                 P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,

                                 P_ERR_CODE   IN OUT VARCHAR2,
                                 P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN AS

    L_FIELD_COUNT      NUMBER := P_AMENDABLE_FIELDS.COUNT;
    L_AMENDABLE_NODES  CSPKS_REQ_GLOBAL.TY_AMEND_NODES;
    L_AMENDABLE_FIELDS CSPKS_REQ_GLOBAL.TY_AMEND_FIELDS;

  BEGIN
    DBG('Inside fn_any_field_modified ' || P_AMENDABLE_NODES.COUNT);
    L_FIELD_COUNT := P_AMENDABLE_NODES.COUNT;
    FOR I IN 1 .. L_FIELD_COUNT LOOP
      DBG('Inside loop');
      DBG('Parties Count = ' || P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <>
         P_PREV_LCDTRONL.V_LCTBS_PARTIES.COUNT THEN
        DBG('Addition or Deletion is not allowed for PLCS');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Party Details';
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_PARTIES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.LAST LOOP
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID, '@') <>
             NVL(P_PREV_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID, '@') THEN

            DBG('Modification is not allowed for CIF_ID');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Party ID';
            RETURN FALSE;
          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE, '@') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE, '@') THEN

            DBG('Modification is not allowed for PARTY_TYPE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Party Type';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO, '@') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_NO, '@') THEN

            DBG('Modification is not allowed for CUST_REF_NO');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Customer Reference No';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
           .CUST_REF_DATE <> P_PREV_LCDTRONL.V_LCTBS_PARTIES(I)
                .CUST_REF_DATE OR
                 (P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CUST_REF_DATE IS NOT NULL AND P_PREV_LCDTRONL.V_LCTBS_PARTIES(I)
                  .CUST_REF_DATE IS NULL) THEN
            DBG('Modification is not allowed for CUST_REF_DATE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Customer Reference Date';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).ISSUER_IS_BANK, '@') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_PARTIES(I).ISSUER_IS_BANK, '@') THEN

            DBG('Modification is not allowed for ISSUER_IS_BANK');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Issuer';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).TEMPLATE_ID, '@') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_PARTIES(I).TEMPLATE_ID, '@') THEN

            DBG('Modification is not allowed for TEMPLATE_ID');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Template ID';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).LANG_CODE, '@') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_PARTIES(I).LANG_CODE, '@') THEN

            DBG('Modification is not allowed for LANG_CODE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Language';
            RETURN FALSE;

          END IF;

        END LOOP;

      END IF;

      DBG('Clause Count ' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT <>
         P_PREV_LCDTRONL.V_LCTBS_CLAUSES.COUNT THEN
        DBG('Addition or Deletion is not allowed for Claues Code');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Clause Details';
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_CLAUSES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.LAST LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
           .CLAUSE_CODE <> P_PREV_LCDTRONL.V_LCTBS_CLAUSES(I).CLAUSE_CODE THEN
            DBG('Modification is not allowed for Claues Code');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Clause Code';
            RETURN FALSE;
          ELSIF P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).CLAUSE_DESCR <> P_PREV_LCDTRONL.V_LCTBS_CLAUSES(I)
                .CLAUSE_DESCR THEN
            DBG('Modification is not allowed for CLAUSE_DESCR');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Clause Description';
            RETURN FALSE;

          END IF;

        END LOOP;

      END IF;

      DBG('Document Count ' || P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT <>
         P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT THEN
        DBG('Addition or Deletion is not allowed for Document Details');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Document Details';
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.LAST LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
           .DOC_CODE <> P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE THEN
            DBG('Modification is not allowed for DOC_CODE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Document Code';
            RETURN FALSE;
          ELSIF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
           .DOC_DESCR <> P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_DESCR THEN
            DBG('Modification is not allowed for DOC_DESCR');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Document Description';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_REFERENCE <> P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                .DOC_REFERENCE THEN
            DBG('Modification is not allowed for DOC_REFERENCE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Document Reference';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_COPIES <> P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                .DOC_COPIES THEN
            DBG('Modification is not allowed for DOC_COPIES');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Document Copy';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).NO_OF_ORIGINALS <> P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                .NO_OF_ORIGINALS THEN
            DBG('Modification is not allowed for NO_OF_ORIGINALS');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'No of Originals';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_ORIGINAL <> P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                .DOC_ORIGINAL THEN
            DBG('Modification is not allowed for DOC_ORIGINAL');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Originals Required';
            RETURN FALSE;

          END IF;

        END LOOP;

      END IF;

      DBG('FFT Count = ' || P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT);

      IF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE <>
         P_PREV_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE THEN
        DBG('Modification is not allowed for GOODS_CODE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Goods Code';
        RETURN FALSE;
      ELSIF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR <>
            P_PREV_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR THEN
        DBG('Modification is not allowed for GOODS_DESCR');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Goods Description';
        RETURN FALSE;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_GOODS.PRE_ADVICE_DESCR <>
            P_PREV_LCDTRONL.V_LCTBS_GOODS.PRE_ADVICE_DESCR THEN
        DBG('Modification is not allowed for PRE_ADVICE_DESCR');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Pre Advice Description';
        RETURN FALSE;

      END IF;

      DBG('TRACER Count = ' || P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT <>
         P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT THEN
        DBG('Addition or Deletion is not allowed for Tracer Code');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Tracer Details';
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_TRACERS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_TRACERS.LAST LOOP
          IF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).TRACER_PARTY <> P_PREV_LCDTRONL.V_LCTBS_TRACERS(I)
             .TRACER_PARTY THEN
            DBG('Modification is not allowed for TRACER_PARTY');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Tracer Party';
            RETURN FALSE;
          ELSIF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I)
           .REQUIRED <> P_PREV_LCDTRONL.V_LCTBS_TRACERS(I).REQUIRED THEN
            DBG('Modification is not allowed for Required');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Tracer Required';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).MAX_TRACERS <> P_PREV_LCDTRONL.V_LCTBS_TRACERS(I)
                .MAX_TRACERS THEN
            DBG('Modification is not allowed for MAX_TRACERS');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Maximum Tracers';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I)
           .START_DAYS <> P_PREV_LCDTRONL.V_LCTBS_TRACERS(I).START_DAYS THEN
            DBG('Modification is not allowed for START_DAYS');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Start Days';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I)
           .MEDIUM <> P_PREV_LCDTRONL.V_LCTBS_TRACERS(I).MEDIUM THEN
            DBG('Modification is not allowed for MEDIUM');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Medium';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I)
           .FREQUENCY <> P_PREV_LCDTRONL.V_LCTBS_TRACERS(I).FREQUENCY THEN
            DBG('Modification is not allowed for FREQUENCY');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Tracer Frequency';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_TRACERS(I).TEMPLATE_ID <> P_PREV_LCDTRONL.V_LCTBS_TRACERS(I)
                .TEMPLATE_ID THEN
            DBG('Modification is not allowed for TEMPLATE_ID');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Template ID';
            RETURN FALSE;

          END IF;

        END LOOP;

      END IF;

      DBG('Checking for LCTBS_CONTRACT_MASTER details');
      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACCOUNT_FOR_ISB, '@') <>
         NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACCOUNT_FOR_ISB, '@') THEN

        DBG('Modification is not allowed for ACCOUNT_FOR_ISB');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Account for ISB';
        RETURN FALSE;
      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKN_DATE <>
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKN_DATE OR
            (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKN_DATE IS NOT NULL AND
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKN_DATE IS NULL) THEN

        DBG('Modification is not allowed for ACKN_DATE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Acknowledgement Date';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKN_RECVD, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKN_RECVD, 'N') THEN

        DBG('Modification is not allowed for ACKN_RECVD');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Account for ISB';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED,
                '@') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED,
                            '@') THEN
        DBG('Modification is not allowed for ADDITIONAL_AMTS_COVERED');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Additional Amount Covered';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ALLOW_PREPAY, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ALLOW_PREPAY, 'N') THEN

        DBG('Modification is not allowed for ALLOW_PREPAY');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Allow Prepay';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO, '0') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO, '0') THEN

        DBG('Modification is not allowed for AMENDMENT_NO');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Amendment No';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE,
                'N') THEN
        DBG('Modification is not allowed for APPLICABLE_RULE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Applicable Rule';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE,
                'N') THEN
        DBG('Modification is not allowed for APPLICABLE_RULE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Applicable Rule';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BACK_TO_BACK_LC, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BACK_TO_BACK_LC,
                'N') THEN
        DBG('Modification is not allowed for BACK_TO_BACK_LC');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Back to Back LC';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_BEN,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_BEN,
                            'N') THEN
        DBG('Modification is not allowed for CHARGES_FROM_BEN');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Charges Form BEN';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_ISB,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_ISB,
                            'N') THEN
        DBG('Modification is not allowed for CHARGES_FROM_ISB');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Charges From ISB';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGE_AMT_ISB, '0') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGE_AMT_ISB, '0') THEN

        DBG('Modification is not allowed for CHARGE_AMT_ISB');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Amount Charges From ISB';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGE_CCY_ISB, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGE_CCY_ISB, 'N') THEN

        DBG('Modification is not allowed for CHARGE_CCY_ISB');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Charge Currency From ISB ';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID, 'N') THEN

        DBG('Modification is not allowed for CIF_ID');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Customer';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY, 'N') THEN

        DBG('Modification is not allowed for CONTRACT_CCY');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Contract Currency';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH,
                'N') THEN
        DBG('Modification is not allowed for CREDIT_AVL_WITH');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Credit Available With';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE, 'N') THEN

        DBG('Modification is not allowed for CUMULATIVE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Cumulative';
        RETURN FALSE;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE <>
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE OR
            (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE IS NOT NULL AND
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE IS NULL) THEN

        DBG('Modification is not allowed for CUST_REF_DATE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Customer Reference Date';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO, 'N') THEN

        DBG('Modification is not allowed for CUST_REF_NO');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Customer Reference No';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE, 'N') THEN

        DBG('Modification is not allowed for CUST_TYPE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Customer Type';
        RETURN FALSE;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE <>
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE OR
            (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE IS NOT NULL AND
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE IS NULL) THEN

        DBG('Modification is not allowed for EFFECTIVE_DATE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Effective Date';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_PLACE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_PLACE, 'N') THEN

        DBG('Modification is not allowed for EXPIRY_PLACE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Expiry Place';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY, '0') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY, '0') THEN

        DBG('Modification is not allowed for FREQUENCY');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Frequency';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.GUARANTEE_TYPE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.GUARANTEE_TYPE, 'N') THEN

        DBG('Modification is not allowed for GUARANTEE_TYPE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Guarentee Type';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM, 'N') THEN

        DBG('Modification is not allowed for INCO_TERM');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'INCO Term';
        RETURN FALSE;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISB_DATE <>
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISB_DATE OR
            (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISB_DATE IS NOT NULL AND
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISB_DATE IS NULL) THEN

        DBG('Modification is not allowed for ISB_DATE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Issuing Bank Date';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE, '0') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE, '0') THEN

        DBG('Modification is not allowed for LIAB_TOLERANCE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Liability Tolerance';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIMITS_TRACKING_TENOR_TYPE,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIMITS_TRACKING_TENOR_TYPE,
                            'N') THEN
        DBG('Modification is not allowed for LIMITS_TRACKING_TENOR_TYPE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Limit Tracking Tenor Type';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                '0') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                            '0') THEN
        DBG('Modification is not allowed for MAX_CONTRACT_AMT');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Max Contract Amount';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT,
                '0') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT,
                            '0') THEN
        DBG('Modification is not allowed for MAX_LIABILITY_AMT');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Max Liability Amount';
        RETURN FALSE;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE <>
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE OR
            (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE IS NOT NULL AND
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE IS NULL) THEN

        DBG('Modification is not allowed for NEXT_REINSTATEMENT_DATE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Next Reinstatement Date';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE, 'N') THEN

        DBG('Modification is not allowed for OPERATION_CODE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Operation Code';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS,
                'N') THEN
        DBG('Modification is not allowed for PAYMENT_DETAILS');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Payment Details';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION,
                            'N') THEN
        DBG('Modification is not allowed for PERIOD_FOR_PRESENTATION');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Period for Presentation';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REIMBURSEMENT_TYPE,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REIMBURSEMENT_TYPE,
                            'N') THEN
        DBG('Modification is not allowed for REIMBURSEMENT_TYPE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Reimbursement Type';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO,
                            'N') THEN
        DBG('Modification is not allowed for RELATED_LC_REF_NO');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Related LC Ref No';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REMARKS, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REMARKS, 'N') THEN

        DBG('Modification is not allowed for REMARKS');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Remarks';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN, 'N') THEN

        DBG('Modification is not allowed for REVOLVES_IN');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Resolves In';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RULE_NARRATIVE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RULE_NARRATIVE, 'N') THEN

        DBG('Modification is not allowed for RULE_NARRATIVE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Rule Narrative';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD,
                            'N') THEN
        DBG('Modification is not allowed for SETTLEMENT_METHOD');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Settlement Method';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_TYPE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_TYPE,
                'N') THEN
        DBG('Modification is not allowed for SETTLEMENT_TYPE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Settlement Type';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR, '0') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR, '0') THEN

        DBG('Modification is not allowed for TENOR');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Tenor';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT, 'N') THEN

        DBG('Modification is not allowed for TOLERANCE_TEXT');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Tolerance Text';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') THEN

        DBG('Modification is not allowed for TRACK_LIMIT');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Track Limit';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE, 'N') THEN

        DBG('Modification is not allowed for TRANSFERABLE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Transferable';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE, 'N') THEN

        DBG('Modification is not allowed for TRANSFERABLE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Transferable';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS, 'N') THEN

        DBG('Modification is not allowed for UNITS');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Units';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
                            'N') THEN
        DBG('Modification is not allowed for PARTIAL_CONFIRMATION_ALLOW');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Partial Confirmation Allowed';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHG_CLM_SWIFT, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHG_CLM_SWIFT, 'N') THEN

        DBG('Modification is not allowed for CHG_CLM_SWIFT');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Charge Claim Swift';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHGCLM_TEMPLATE_ID,
                'N') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHGCLM_TEMPLATE_ID,
                            'N') THEN
        DBG('Modification is not allowed for CHGCLM_TEMPLATE_ID');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Charge Claim Template ID';
        RETURN FALSE;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE <>
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE OR
            (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE IS NOT NULL AND
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE IS NULL) THEN

        DBG('Modification is not allowed for UNDERTAKING_EXPIRY_DATE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Undertaking Expiry Date';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                '0') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                            '0') THEN
        DBG('Modification is not allowed for UNDERTAKING_AMOUNT');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Undertaking Amount';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AVAILED_UNDERTAKING_AMOUNT,
                '0') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AVAILED_UNDERTAKING_AMOUNT,
                            '0') THEN
        DBG('Modification is not allowed for AVAILED_UNDERTAKING_AMOUNT');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Availed Undertaking Amount';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_LC_REF_NO, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_LC_REF_NO, 'N') THEN

        DBG('Modification is not allowed for USER_LC_REF_NO');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'User LC Reference No';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.URR_PREFERENCE, 'N') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.URR_PREFERENCE, 'N') THEN

        DBG('Modification is not allowed for URR_PREFERENCE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'URR Preference';
        RETURN FALSE;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE <>
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE OR
            (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NOT NULL AND
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE IS NULL) THEN

        DBG('Modification is not allowed for CLOSURE_DATE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Closure Date';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT, '0') <>
            NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT, '0') THEN

        DBG('Modification is not allowed for CONTRACT_AMT');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Contract Amount';
        RETURN FALSE;

      ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE <>
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE OR
            (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NOT NULL AND
            P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE IS NULL) THEN

        DBG('Modification is not allowed for EXPIRY_DATE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Expiry Date';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                '0') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                            '0') THEN
        DBG('Modification is not allowed for NEGATIVE_TOLERANCE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Negetive Tolerance';
        RETURN FALSE;

      ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                '0') <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                            '0') THEN
        DBG('Modification is not allowed for POSITIVE_TOLERANCE');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Positive Tolerance';
        RETURN FALSE;

      END IF;

      DBG('Checking for Other Address ' ||
          P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT <>
         P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT THEN
        DBG('Addition or Deletion is not allowed for PLCS');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Other Address Details';
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.FIRST .. P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.LAST LOOP
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).MEDIUM_TYPE, '@') <>
             NVL(P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).MEDIUM_TYPE,
                 '@') THEN
            DBG('Modification is not allowed for MEDIUM_TYPE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Media Type';
            RETURN FALSE;
          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).ACC_NO, '@') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).ACC_NO, '@') THEN

            DBG('Modification is not allowed for ACC_NO');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Account No';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I).MEDIUM_ADDRESS,
                    '@') <> NVL(P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(I)
                                .MEDIUM_ADDRESS,
                                '@') THEN
            DBG('Modification is not allowed for MEDIUM_ADDRESS');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Media Address';
            RETURN FALSE;

          END IF;

        END LOOP;

      END IF;

      DBG('Checking for Draft ' || P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT <>
         P_PREV_LCDTRONL.V_LCTBS_DRAFTS.COUNT THEN
        DBG('Addition or Deletion is not allowed for PLCS');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Draft Details';
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.LAST LOOP
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).CREDIT_DAYS_FROM, 'N') <>
             NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I).CREDIT_DAYS_FROM, 'N') THEN

            DBG('Modification is not allowed for CREDIT_DAYS_FROM');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Credit Days From';
            RETURN FALSE;
          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_SL_NO, '0') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_SL_NO, '0') THEN

            DBG('Modification is not allowed for DRAFT_SL_NO');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Draft Serial No';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_TENOR, '0') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I).DRAFT_TENOR, '0') THEN

            DBG('Modification is not allowed for DRAFT_TENOR');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Draft Tenor';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE, 'N') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I).DRAWEE, 'N') THEN

            DBG('Modification is not allowed for DRAWEE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Drawee';
            RETURN FALSE;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
           .INSURANCE_EXPIRY_DATE <> P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I)
                .INSURANCE_EXPIRY_DATE OR
                 (P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I)
                  .INSURANCE_EXPIRY_DATE IS NOT NULL AND P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I)
                  .INSURANCE_EXPIRY_DATE IS NULL) THEN
            DBG('Modification is not allowed for INSURANCE_EXPIRY_DATE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Insurance Expiry Date';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_COMP_CODE,
                    'N') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_COMP_CODE,
                    'N') THEN
            DBG('Modification is not allowed for INSURANCE_COMP_CODE');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Insurance Company Code';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_POLICY_NO,
                    'N') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I).INSURANCE_POLICY_NO,
                    'N') THEN
            DBG('Modification is not allowed for INSURANCE_POLICY_NO');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Insurance Policy No';
            RETURN FALSE;

          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(I).PCT_AMT, '0') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(I).PCT_AMT, '0') THEN

            DBG('Modification is not allowed for PCT_AMT');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'PCT Amount';
            RETURN FALSE;

          END IF;

        END LOOP;

      END IF;

      DBG('Checking for Draft details ' ||
          P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT);
      IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT <>
         P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT THEN
        DBG('Addition or Deletion is not allowed for PLCS');
        P_ERR_CODE   := 'LCUPLD-517';
        P_ERR_PARAMS := 'Draft Details';
        RETURN FALSE;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT <> 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.LAST LOOP
          IF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I).AMOUNT_NAME, 'N') <>
             NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I).AMOUNT_NAME, 'N') THEN

            DBG('Modification is not allowed for AMOUNT_NAME');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Amount Name';
            RETURN FALSE;
          ELSIF NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I).AMOUNT, '0') <>
                NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(I).AMOUNT, '0') THEN

            DBG('Modification is not allowed for AMOUNT');
            P_ERR_CODE   := 'LCUPLD-517';
            P_ERR_PARAMS := 'Amount';
            RETURN FALSE;

          END IF;

        END LOOP;

      END IF;

    END LOOP;

    DBG('Returning true from any field modified');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Inside when others of any field modified');
      RETURN FALSE;

  END FN_ANY_FIELD_MODIFIED;

  FUNCTION FN_DFLT_JV_CUSTOMERS(P_SOURCE           IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    K                 INTEGER := 0;
    L_LIMIT_AMOUNT    LCTBS_CONTRACT_LIMITS.LIMIT_AMOUNT%TYPE;
    L_OS_LIABILITY    LCTBS_AVAILMENTS.OS_LIABILITY%TYPE;
    L_PARTY_POPUALTED BOOLEAN := FALSE;
    L_CHK_PARENT      BOOLEAN := FALSE;
    CURSOR CUR_JV(PCIFID IN VARCHAR2) IS
      SELECT CUSTOMER_NO, PARTY_ID, PARTY_RATIO

        FROM STTM_CUST_JV
       WHERE CUSTOMER_NO = PCIFID;

  BEGIN
    DBG('In Fn_dflt_jv_customers');
    BEGIN
      SELECT OS_LIABILITY
        INTO L_OS_LIABILITY
        FROM LCTBS_AVAILMENTS
       WHERE EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM LCTBS_AVAILMENTS
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO)
         AND CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_OS_LIABILITY := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT +
                          (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT *
                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE / 100);

    END;

    DBG('p_wrk_lcdtronl.v_cstbs_contract.latest_version_no ' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO);
    DBG('p_wrk_lcdtronl.v_lctbs_contract_master.latest_version_no ' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
    IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') = 'Y' THEN

      K := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT + 1;
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT LOOP
        DBG('came here');
        FOR REC IN CUR_JV(P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID) LOOP

          DBG('came here 11');
          L_LIMIT_AMOUNT := L_OS_LIABILITY * REC.PARTY_RATIO / 100;
          FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT LOOP
            DBG('hey..');
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
             .JV_PARENT = REC.CUSTOMER_NO AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
               .CUSTOMER_NO = REC.PARTY_ID THEN
              L_PARTY_POPUALTED := TRUE;
            END IF;

          END LOOP;

          IF NOT L_PARTY_POPUALTED THEN
            DBG('hey we have got something');
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).EVENT_SEQ_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).VERSION_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).EVENT_CODE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).PARTY_TYPE := P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                                                                    .PARTY_TYPE;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).CUSTOMER_NO := REC.PARTY_ID;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).LINKAGE_TYPE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K)
                                                                      .LINKAGE_TYPE;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).LINKAGE_PERCENTAGE := REC.PARTY_RATIO;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).LINKED_REF_NO := '';
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).LINKAGE_SEQ_NO := K;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).LINKED_CCY := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).OPERATION := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).LIMIT_AMOUNT := L_LIMIT_AMOUNT;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).JV_PARENT := REC.CUSTOMER_NO;
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).AMOUNT_TAG := 'LIAB_OS_AMT';
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(K).LIABLITY_NO := '';
            K := K + 1;
            L_CHK_PARENT := TRUE;
          END IF;

          L_PARTY_POPUALTED := FALSE;
        END LOOP;

      END LOOP;

      IF NOT L_CHK_PARENT THEN
        DBG('CAME HERE for checking parent');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LM-VALS-383', NULL);
      END IF;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('error here is:' || SQLERRM);
      RETURN FALSE;

  END FN_DFLT_JV_CUSTOMERS;

  FUNCTION FN_VALIDATE_LIMITS(P_SOURCE        IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_FUNCTION_ID   IN VARCHAR2,
                              P_ACTION_CODE   IN VARCHAR2,
                              P_LCDTRONL      IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_PREV_LCDTRONL IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_WRK_LCDTRONL  IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                              P_ERR_CODE      IN OUT VARCHAR2,
                              P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_PRODUCT_TYPE  LCTMS_PRODUCT_DEFINITION.PRODUCT_TYPE%TYPE;
    L_REIM          LCTMS_PRODUCT_DEFINITION.REIMBURSEMENT%TYPE;
    L_OS_LIABILITY  LCTBS_AVAILMENTS.OS_LIABILITY%TYPE;
    L_TOTAL_PERCENT NUMBER := 0;
    L_CHK_SUM       BOOLEAN := FALSE;
    K               INTEGER := 1;
    L_CHK_PARTY     BOOLEAN := FALSE;
    L_CUSTOMER_NO   STTM_CUST_JV.CUSTOMER_NO%TYPE;
    L_PARTY_ID      STTM_CUST_JV.PARTY_ID%TYPE;

    L_END_DATE   LCTBS_CONTRACT_MASTER.ISSUE_DATE%TYPE;
    L_START_DATE LCTBS_CONTRACT_MASTER.ISSUE_DATE%TYPE;

    L_CUST_TYPE            CHAR(1 CHAR);
    L_LIMITS_TRACKED       STTM_CUSTOMER.TRACK_LIMITS%TYPE;
    L_MANDATE_TRACK_LIMITS CHAR(1 CHAR);
    L_SUCCESS              BOOLEAN := FALSE;
    L_ADV_OF_GUARANTEE     LCTMS_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE%TYPE;

    L_PROD_DESC SMTBS_PRODUCT_TYPES.PRODUCT_TYPE_DESC%TYPE;
    L_MODULE    SMTB_MENU.MODULE%TYPE;

  BEGIN
    DBG('came here Fn_validate_limits');
    BEGIN
      SELECT PRODUCT_TYPE, REIMBURSEMENT, ADVICE_OF_GUARANTEE
        INTO L_PRODUCT_TYPE, L_REIM, L_ADV_OF_GUARANTEE
        FROM LCTM_PRODUCT_DEFINITION
       WHERE PRODUCT_CODE = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting product type..');
        RETURN FALSE;

    END;

    BEGIN
      SELECT OS_LIABILITY
        INTO L_OS_LIABILITY
        FROM LCTBS_AVAILMENTS
       WHERE EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM LCTBS_AVAILMENTS
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO)
         AND CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_OS_LIABILITY := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT +
                          (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT *
                          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE / 100);

    END;

    BEGIN
      SELECT NVL(C.TRACK_LIMITS, 'N'), C.CUSTOMER_TYPE
        INTO L_LIMITS_TRACKED, L_CUST_TYPE
        FROM STTM_CUSTOMER C
       WHERE C.CUSTOMER_NO = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_CUST_TYPE := 'I';
    END;
    BEGIN
      SELECT NVL(DECODE(L_CUST_TYPE,
                        'I',
                        B.LIMIT_TRACK_CIF_INDL,
                        'C',
                        B.LIMIT_TRACK_CIF_CORP,
                        'B',
                        B.LIMIT_TRACK_CIF_BANK),
                 'N')
        INTO L_MANDATE_TRACK_LIMITS
        FROM STTM_BANK B;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_MANDATE_TRACK_LIMITS := 'N';
    END;

    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;
    END;

    DBG('Customer for tracking : ' ||
        P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
    DBG('customer Limit tracking  : ' || L_LIMITS_TRACKED);
    DBG('l_Mandate_Track_Limits   : ' || L_MANDATE_TRACK_LIMITS);
    DBG('(l_Product_Type    : ' || L_PRODUCT_TYPE);
    DBG('OPERATION_code ' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
    IF ((L_PRODUCT_TYPE = 'E' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE NOT IN
       ('ADV', 'PAD') AND NVL(L_ADV_OF_GUARANTEE, 'N') = 'N') OR
       (L_PRODUCT_TYPE IN ('I', 'C', 'S', 'H', 'G'))) THEN
      DBG('About to validate track limit at bank and customer level');
      IF L_MANDATE_TRACK_LIMITS = 'Y' THEN
        IF L_LIMITS_TRACKED = 'Y' THEN
          FOR J IN 1 .. P_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT LOOP
            IF P_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
             .CUSTOMER_NO = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID THEN
              DBG('Limit is Maintained for cutomer : ' ||
                  P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
              L_SUCCESS := TRUE;
              EXIT;
            END IF;
          END LOOP;
          IF NOT L_SUCCESS AND L_PRODUCT_TYPE = 'E' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
             ('ANC', 'CNF') AND
             P_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT > 0 THEN
            DBG('Limit is tracked for the customer other than the main customer');
            L_SUCCESS := TRUE;
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-415', NULL);
          END IF;
          IF NOT L_SUCCESS THEN

            DBG('l_Product_Type' || L_PRODUCT_TYPE);

            IF L_PRODUCT_TYPE IN ('I', 'C', 'S', 'H', 'G') THEN

              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-VALS-123',
                           P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);

            ELSE

              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           'LC-VALS-223',
                           P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);

            END IF;

          END IF;
        END IF;
      END IF;
    END IF;

    IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') = 'Y' AND
       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT = 0

     THEN
      DBG('Credit line must be entered as limit tracking flag is checked');
      P_ERR_CODE := 'LM-VALS-386';
      RETURN FALSE;
    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT = 0 THEN
      DBG('NO REC FOR Fn_validate_limits');
      RETURN TRUE;
    END IF;

    IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') = 'N' AND
       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT <> 0 THEN
      DBG('Limit Tracking should be checked');
      P_ERR_CODE := 'LM-VALS-381';
      RETURN FALSE;
    END IF;

    FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT LOOP
      L_CHK_SUM := FALSE;
      K         := 1;
      FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LINKAGE_SEQ_NO := K;
        IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
           .PARTY_TYPE THEN
          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).JV_PARENT IS NOT NULL THEN
            L_CHK_SUM := TRUE;
            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID <> P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
               .JV_PARENT THEN
              DBG('party id and party type should be same as that of parties');
              P_ERR_CODE := 'LM-VALS-372';
              RETURN FALSE;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
             .CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID THEN
              DBG('party id and party type should be same as that of parties');
              P_ERR_CODE := 'LM-VALS-373';
              RETURN FALSE;
              NULL;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
             .AMOUNT_TAG <> 'LIAB_OS_AMT' THEN
              DBG('Invalid Amount Tag');
              P_ERR_CODE := 'LM-VALS-375';
              RETURN FALSE;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
             .LINKAGE_PERCENTAGE IS NULL THEN
              DBG('Percentage cannot be null');
              P_ERR_CODE := 'LM-VALS-382';
              RETURN FALSE;
            END IF;

            L_TOTAL_PERCENT := L_TOTAL_PERCENT + P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                              .LINKAGE_PERCENTAGE;
            BEGIN
              SELECT CUSTOMER_NO, PARTY_ID
                INTO L_CUSTOMER_NO, L_PARTY_ID

                FROM STTM_CUST_JV
               WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                    .JV_PARENT
                 AND PARTY_ID = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                    .CUSTOMER_NO;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('jv parent and customer:' || P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                    .JV_PARENT || ' not Found..');
                P_ERR_CODE := 'LM-VALS-385';
                RETURN FALSE;

            END;

          ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).JV_PARENT IS NULL THEN
            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).CIF_ID <> P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
               .CUSTOMER_NO THEN
              DBG('party id and party type should be same as that of parties');
              P_ERR_CODE := 'LM-VALS-374';
              RETURN FALSE;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
             .LINKAGE_PERCENTAGE IS NULL OR P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
               .LINKAGE_PERCENTAGE = 100 THEN
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LINKAGE_PERCENTAGE := 100;
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LIMIT_AMOUNT := L_OS_LIABILITY * P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                                                                       .LINKAGE_PERCENTAGE / 100;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).AMOUNT_TAG IS NULL THEN
              DBG('AMOUNT TAG CANNOT BE NULL');
              P_ERR_CODE := 'LM-VALS-379';
              RETURN FALSE;
            END IF;

            SELECT PRODUCT_TYPE_DESC
              INTO L_PROD_DESC
              FROM SMTBS_PRODUCT_TYPES
             WHERE MODULE = L_MODULE
               AND LANGUAGE_CODE = GLOBAL.LANG
               AND PRODUCT_TYPE =
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
             .AMOUNT_TAG IN ('CNF_LIAB_OS_AMT', 'UCNF_LIAB_OS_AMT') AND
                L_PRODUCT_TYPE <> 'E' THEN
              DBG('Invalid Amount Tag');
              P_ERR_CODE := 'LM-VALS-376';

              P_ERR_PARAMS := L_PROD_DESC;

              RETURN FALSE;
            END IF;

            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
             .AMOUNT_TAG IN ('REIM_OS_UND_AMT', 'REIM_OS_NON_UND_AMT') AND

                NVL(L_REIM, 'N') = 'N' THEN

              DBG('Invalid Amount Tag');
              P_ERR_CODE := 'LM-VALS-376';

              P_ERR_PARAMS := L_PROD_DESC;

              RETURN FALSE;
            END IF;

          END IF;

          IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LINKAGE_TYPE,
                 'L') = 'L' AND
             (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LINKED_REF_NO IS NOT NULL AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
              .LINKED_REF_NO <> P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
              .LIABLITY_NO) THEN
            DBG('Linkage refernce number should be null if linkage type is null');
            P_ERR_CODE := 'LM-VALS-384';
            RETURN FALSE;
          END IF;

          IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LINKAGE_TYPE,
                 'L') = 'L' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
            .LINKED_REF_NO IS NULL THEN
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LINKED_REF_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                                                                       .LIABLITY_NO;
          ELSIF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
           .LINKAGE_TYPE IN ('F', 'P', 'C') AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                .LINKED_REF_NO IS NULL THEN
            P_ERR_CODE := 'LM-VALS-380';
            RETURN FALSE;

          END IF;

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J).LIABLITY_NO IS NULL THEN
            DBG('LIABILITY NO CANNOT BE NULL');
            P_ERR_CODE := 'LM-VALS-378';
            RETURN FALSE;
          END IF;
        END IF;

        K := K + 1;

        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
         .LINKAGE_TYPE = 'C' AND P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
           .LINKED_REF_NO IS NOT NULL THEN
          DBG('Entered to validate the collateral expiry date with the contract Issue date');
          BEGIN
            SELECT END_DATE, START_DATE
              INTO L_END_DATE, L_START_DATE
              FROM GETM_COLLAT
             WHERE COLLATERAL_CODE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(J)
                  .LINKED_REF_NO
               AND RECORD_STAT = 'O'
               AND ONCE_AUTH = 'Y';

            IF L_END_DATE IS NOT NULL AND
               NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                   GLOBAL.MIN_DATE) > L_END_DATE

             THEN
              P_ERR_CODE := 'LC-VALS-61';
              DBG('Contract Issue date is greater than the collateral expiry date');
              RETURN FALSE;
            END IF;

            IF NVL(L_START_DATE, GLOBAL.MIN_DATE) >
               NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                   GLOBAL.MIN_DATE) THEN
              P_ERR_CODE := 'LC-VALS-62';
              DBG('Collateral start date is greater than the contract Issue date. Cannot attach future dated collateral');
              RETURN FALSE;
            END IF;

          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed here because of--> ' || SQLERRM);

          END;

        END IF;

      END LOOP;

      DBG('CAME OUT' || L_TOTAL_PERCENT);
      IF L_CHK_SUM AND NVL(L_TOTAL_PERCENT, 0) <> 100 THEN
        DBG('sum of percentage should be 100');
        P_ERR_CODE := 'LM-VALS-371';
        RETURN FALSE;
      END IF;

      L_TOTAL_PERCENT := 0;

    END LOOP;

    FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT LOOP
      L_CHK_PARTY := FALSE;
      DBG('contract_limits::' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT);

      L_TOTAL_PERCENT := L_TOTAL_PERCENT + P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                        .LINKAGE_PERCENTAGE;
      DBG('total perc' || L_TOTAL_PERCENT);

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I).PARTY_TYPE IS NULL THEN
        DBG('Mandatory field Party type should be input');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-400', NULL);
      ELSE

        FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT LOOP

          IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
           .PARTY_TYPE = P_WRK_LCDTRONL.V_LCTBS_PARTIES(J).PARTY_TYPE THEN
            L_CHK_PARTY := TRUE;
          END IF;

        END LOOP;

        IF NOT L_CHK_PARTY THEN
          DBG('Invalid party type');
          P_ERR_CODE   := 'LM-VALS-377';
          P_ERR_PARAMS := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                          .PARTY_TYPE;
          RETURN FALSE;
        END IF;

      END IF;

      DBG('TOATAL_PRERCENTAGE' || L_TOTAL_PERCENT);
      IF NVL(L_TOTAL_PERCENT, 0) > 100 THEN
        DBG('Sum of linkage percentage should not be greater than be 100');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-404', NULL);
      END IF;

    END LOOP;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('error here is:' || SQLERRM);
      RETURN FALSE;

  END FN_VALIDATE_LIMITS;

END LCPKS_LCDTRONL_UTILS;
/