insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGADVCHG', 'BG Advicing charges', 'CH', null, null, null, 'O', 'A', 'Y', 'YRAROTH1', to_date('14-01-2020 09:27:44', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH1', to_date('14-01-2020 09:27:44', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGCANCHG', 'BG Cancellation Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 20:10:09', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 20:10:09', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGCLMCHG', 'Guarantee Claim Charge', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('07-03-2019 14:00:29', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('07-03-2019 14:00:30', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGCOURIER', 'BG Courier Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 20:10:44', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 20:10:44', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGSWIFTAMN', 'BG SWIFT Charge for Amendment', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('06-03-2019 20:09:49', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('06-03-2019 20:09:49', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'BGSWIFTISS', 'BG SWIFT Charge for Issuance', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('06-03-2019 20:10:15', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('06-03-2019 20:10:15', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCADVAMND', 'LC Export Advicing charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 11:01:01', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 11:01:01', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCADVCHG', 'LC Export Advicing charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 18:02:05', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 18:02:05', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCAMENDMEN', 'Other BG Amendment', 'CH', null, null, null, 'O', 'A', 'Y', 'CMAKARA', to_date('14-01-2020 09:57:39', 'dd-mm-yyyy hh24:mi:ss'), 'CMAKARA', to_date('14-01-2020 09:57:39', 'dd-mm-yyyy hh24:mi:ss'), 10);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCAMNDAMTD', 'Amendment of LC Amount - Decrease', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('14-01-2020 13:52:24', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 13:52:24', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCAMNDEXDT', 'Amendment of LC Expiry Date - Increase', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 15:20:11', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 15:20:11', 'dd-mm-yyyy hh24:mi:ss'), 5);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCAMNEXDTD', 'BG Amendment on Increase Expiry Date', 'CH', null, null, null, 'O', 'A', 'Y', 'CMAKARA', to_date('14-01-2020 09:58:59', 'dd-mm-yyyy hh24:mi:ss'), 'CMAKARA', to_date('14-01-2020 09:58:59', 'dd-mm-yyyy hh24:mi:ss'), 5);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCCANCHG', 'LC Cancellation Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('06-03-2019 16:13:14', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('06-03-2019 16:13:14', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCCNFMCHG', 'LC Confirming Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 18:00:05', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 18:00:05', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCCOURIER', 'LC Courier Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 11:41:26', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 11:41:26', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCDOCCHG', 'LC Documentary Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE2', to_date('06-03-2019 16:12:39', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE2', to_date('06-03-2019 16:12:39', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCECORBANC', 'LC Export Courier Charges Advice and Confirm', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 21:37:09', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 21:37:09', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCEEV', 'LC EXPORT EVENTS', 'AC', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 18:47:01', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 18:47:01', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCER2H', 'LC EXPORT ROLE 2 HEAD', 'RH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 18:12:01', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 18:12:01', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCICABBISS', 'LC Export Courier Charges Advice and Confirm', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 20:09:35', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 20:09:36', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCIDAMAMND', 'Import LC Decrease Amount Amendment Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 12:39:02', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:39:02', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCIDEXAMND', 'Import LC Decrease Expiry Date Amendment Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 12:43:00', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 12:43:00', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCIEV', 'LC Import EVENTS', 'AC', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 12:19:47', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 12:19:47', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCIR2H', 'LC IMPORT  ROLE 2 HEAD', 'RH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 12:37:21', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 12:37:21', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCISSUANCE', 'LC Issuance Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 11:40:27', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 11:40:27', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCSWIFTAMN', 'LC SWIFT Charge for Amendment', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 11:39:30', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 11:39:30', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCSWIFTISS', 'LC SWIFT Charge for Issuance', 'CH', null, null, null, 'O', 'A', 'Y', 'TECHURATE1', to_date('06-03-2019 11:42:22', 'dd-mm-yyyy hh24:mi:ss'), 'TECHURATE1', to_date('06-03-2019 11:42:22', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'OAMENDMENT', 'Other LC Amendment', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('14-01-2020 14:34:57', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('14-01-2020 14:34:57', 'dd-mm-yyyy hh24:mi:ss'), 1);

COMMIT;
