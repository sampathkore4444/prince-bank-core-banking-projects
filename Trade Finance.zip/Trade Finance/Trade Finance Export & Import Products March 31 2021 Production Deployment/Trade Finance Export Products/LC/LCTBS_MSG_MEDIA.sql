insert into LCTBS_MSG_MEDIA (MSG_TYPE, MEDIUM)
values ('LC_CANCEL_ADV', 'MAIL');

insert into LCTBS_MSG_MEDIA (MSG_TYPE, MEDIUM)
values ('LC_CANCEL_ADV', 'SWIFT');

insert into LCTBS_MSG_MEDIA (MSG_TYPE, MEDIUM)
values ('LC_CANCEL_ADV', 'TELEX');

COMMIT;
