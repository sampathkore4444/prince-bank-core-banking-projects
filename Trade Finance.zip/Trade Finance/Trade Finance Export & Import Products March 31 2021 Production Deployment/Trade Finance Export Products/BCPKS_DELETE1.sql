CREATE OR REPLACE PACKAGE BODY BCPKS_DELETE1 AS

  FUNCTION FN_BCDELETE_ANEVENT(P_BCREFNO    IN BCTBS_CONTRACT_MASTER.BCREFNO%TYPE,
                               P_ESN        IN BCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE,
                               P_EVENT      IN BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE,
                               P_ACTION     IN VARCHAR2,
                               P_ERR_CODES  IN OUT VARCHAR2,
                               P_ERR_PARAMS IN OUT VARCHAR2)

   RETURN BOOLEAN AS

    LSPRTR VARCHAR2(1) := '~';

    P_LCREFNO BCTBS_CONTRACT_MASTER.OUR_LC_REF%TYPE;

    CURSOR UNREALIZED_CURSOR IS
      SELECT DISTINCT AC_CCY,
                      RTRIM(AMOUNT_TAG, '_LIQD_PY') COMPONENT,
                      NVL(FCY_AMOUNT, LCY_AMOUNT) AMOUNT

        FROM (SELECT AC_CCY, AMOUNT_TAG, FCY_AMOUNT, LCY_AMOUNT
                FROM ACTBS_DAILY_LOG
               WHERE TRN_REF_NO = P_BCREFNO
                 AND EVENT_SR_NO = P_ESN
                 AND DELETE_STAT <> 'D'
                 AND AMOUNT_TAG LIKE '%_LIQD_PY'
              UNION
              SELECT A.AC_CCY, A.AMOUNT_TAG, A.FCY_AMOUNT, A.LCY_AMOUNT
                FROM ACTBS_ENTRIES_HANDOFF A
               WHERE A.TRN_REF_NO = P_BCREFNO
                 AND A.EVENT_SR_NO = P_ESN
                 AND A.TXN_STAT = 'U'
                 AND A.AMOUNT_TAG LIKE '%_LIQD_PY'
                 AND NOT EXISTS
               (SELECT 1
                        FROM ACTB_ACSERVICE_HANDOFF B
                       WHERE B.ACTION_CODE = 'D'
                         AND B.GRP_REF_NO = A.GRP_REF_NO
                         AND B.TRN_REF_NO = A.TRN_REF_NO
                         AND B.EVENT_SR_NO = A.EVENT_SR_NO));

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Just Entered BCPKSS_DELETE1.fn_bcdelete_anevent');
    DEBUG.PR_DEBUG('BC', 'The IN parameters passed are as follows :- ');
    DEBUG.PR_DEBUG('BC', 'p_bcrefno is =             ' || P_BCREFNO);
    DEBUG.PR_DEBUG('BC', 'p_esn is =                 ' || P_ESN);
    DEBUG.PR_DEBUG('BC', 'p_event is =               ' || P_EVENT);

    P_ERR_CODES  := '';
    P_ERR_PARAMS := '';

    OVPKSS.PR_INITERRTBL;

    DEBUG.PR_DEBUG('BC',
                   'Going to call BCPKSS_DELETE2.fn_delete_amount_due ');

    IF NOT FN_DELETE_AMOUNT_DUE(P_BCREFNO,
                                P_ESN,
                                P_EVENT,
                                P_ACTION,
                                P_ERR_CODES,
                                P_ERR_PARAMS) THEN
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE2.fn_delete_amount_due returned FALSE');
      DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
      DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);
      OVPKSS.PR_APPENDTBL('BC-DE0001',
                          P_BCREFNO || LSPRTR || P_EVENT || LSPRTR || P_ESN ||
                          LSPRTR);
      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN FALSE;
    ELSE
      DEBUG.PR_DEBUG('BC', 'BCPKSS_DELETE1.fn_bcdelete_book returned TRUE');
    END IF;

    DEBUG.PR_DEBUG('BC',
                   'Returned successfully BCPKSS_DELETE2.fn_delete_amount_due ');

    DEBUG.PR_DEBUG('LC', 'Before unrealized cursor in Delete');
    FOR I IN UNREALIZED_CURSOR LOOP
      DEBUG.PR_DEBUG('LC', 'Looping for component' || I.COMPONENT);
      DEBUG.PR_DEBUG('LC', 'Amount is ' || I.AMOUNT);

      UPDATE CSTBS_UNREALIZED_PNL
         SET AMOUNT_SETTLED = AMOUNT_SETTLED - I.AMOUNT
       WHERE CONTRACT_REF_NO = P_BCREFNO
         AND COMPONENT = I.COMPONENT;
    END LOOP;
    DEBUG.PR_DEBUG('LC', 'After unrealized cursor in Delete');

    IF P_EVENT IN ('INIT', 'LIQD', 'AMND', 'REVR', 'CRST') THEN

      BEGIN
        SELECT OUR_LC_REF
          INTO P_LCREFNO
          FROM BCTB_CONTRACT_MASTER
         WHERE BCREFNO = P_BCREFNO
           AND VERSION_NO = (SELECT MAX(VERSION_NO)
                               FROM BCTB_CONTRACT_MASTER
                              WHERE BCREFNO = P_BCREFNO);
      EXCEPTION
        WHEN OTHERS THEN
          P_LCREFNO := NULL;
      END;

      IF P_LCREFNO IS NOT NULL THEN
        IF NOT BCPKSS_CONTRACT.FN_DELETE_DEFERRED_TAGS(P_BCREFNO,
                                                       P_LCREFNO,
                                                       P_ESN,
                                                       P_EVENT,
                                                       'D',
                                                       P_ERR_CODES,
                                                       P_ERR_PARAMS) THEN
          DEBUG.PR_DEBUG('BC',
                         'BCPKSS_DELETE2.fn_bcdelete_deferred tags returned FALSE');
          DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
          DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

          OVPKSS.PR_APPENDTBL('BC-DE0001',
                              P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                              P_ESN || LSPRTR);

          OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

          RETURN FALSE;

        END IF;
      END IF;
    END IF;

    DELETE MSTBS_CONTRACT_COMMSG
     WHERE CONTRACT_REF_NO = P_BCREFNO
       AND EVENT_SEQ_NO = P_ESN;
    DELETE MSTBS_COMMSG_DETAIL
     WHERE REFERENCE_NO = (SELECT MSG_REF_NO
                             FROM MSTBS_CONTRACT_COMMSG
                            WHERE CONTRACT_REF_NO = P_BCREFNO
                              AND EVENT_SEQ_NO = P_ESN);
    DELETE MSTBS_COMMSG_MASTER
     WHERE REFERENCE_NO = (SELECT MSG_REF_NO
                             FROM MSTBS_CONTRACT_COMMSG
                            WHERE CONTRACT_REF_NO = P_BCREFNO
                              AND EVENT_SEQ_NO = P_ESN);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      DEBUG.PR_DEBUG('BC',
                     'Calling bcpks_delete1_custom.fn_bcdelete_anevent ');
      IF NOT BCPKS_DELETE1_CLUSTER.FN_BCDELETE_ANEVENT(P_BCREFNO,
                                                       P_ESN,
                                                       P_EVENT,
                                                       P_ACTION,
                                                       P_ERR_CODES,
                                                       P_ERR_PARAMS,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('BC',
                       'bcpks_delete1_cluster.fn_bcdelete_anevent has returned false' ||
                       SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);
        RETURN FALSE;

      --ELSE   --sampath commented changes
        --RETURN TRUE; --sampath commented ends

      END IF;
    END IF;

    IF P_EVENT = 'BOOK' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_book');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_BOOK(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_book returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_book returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event BOOK went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'INIT' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_init');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_INIT(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_init returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_init returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event BOOK went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'BDIS' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_bdis');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_BDIS(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_bdis returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_bdis returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event BDIS went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'BADV' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_badv');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_BADV(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_badv returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_badv returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event BADV went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'FACP' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_bdis');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_FACP(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_facp returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_facp returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event FACP went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'FDIS' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_fdis');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_FDIS(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_fdis returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_fdis returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event FDIS went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'BPUR' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_bpur');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_BPUR(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_bpur returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_bpur returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event BPUR went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'BCOL' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_bcol');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_BCOL(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_bcol returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_bcol returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event BCOL went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'LDIS' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_ldis');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_LDIS(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_ldis returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_ldis returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event LDIS went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'LADV' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_ladv');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_LADV(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_ladv returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_ladv returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event LADV went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'LPUR' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_lpur');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_LPUR(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_lpur returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_lpur returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event LPUR went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'LCOL' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_lcol');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_LCOL(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_lcol returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_lcol returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event LCOL went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT IN ('LIQD', 'CRST')

     THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_liqd');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_LIQD(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_liqd returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_liqd returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event LIQD went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'AMND' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_amnd');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_AMND(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_amnd returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_amnd returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event AMND went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'ACKB' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_ackb');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_ACKB(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_ackb returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_ackb returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event ACKB went through SUCCESSFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'RAMT' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_ramt');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_RAMT(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_ramt returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_ramt returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event RAMT went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'ACCR' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_accr');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_ACCR(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_accr returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_accr returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event ACCR went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'YACR' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_yacr');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_YACR(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_yacr returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_yacr returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event YACR went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'STCH' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_stch');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_STCH(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_stch returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_stch returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event STCH went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'CLOS' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_clos');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_CLOS(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_clos returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_clos returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event CLOS went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT IN ('REVR', 'BLNK', 'RLNK')

     THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE2.fn_bcdelete_revr');

      IF NOT BCPKSS_DELETE2.FN_BCDELETE_REVR(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE2.fn_bcdelete_revr returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_revr returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event REVR went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'RRES' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_rres');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_RRES(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_rres returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_rres returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event RRES went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'ADIS' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_adis');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_ADIS(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_adis returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_adis returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event ADIS went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'BACP' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_bacp');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_BACP(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_bacp returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_bacp returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event BACP went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'BACI' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_baci');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_BACI(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_baci returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_baci returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event BACI went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'PFAT' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_pfat');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_PFAT(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_pfat returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_pfat returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event PFAT went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'AFAT' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_afat');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_AFAT(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_afat returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_afat returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event AFAT went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'TPAY' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_tpay');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_TPAY(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_tpay returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_tpay returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event TPAY went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'TACP' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_tacp');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_TACP(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_tacp returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_tacp returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event TACP went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'TAFT' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_taft');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_TAFT(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_taft returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_taft returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event TAFT went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'TPFT' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_tpft');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_TPFT(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_tpft returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_tpft returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event TPFT went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'REFP' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_refp');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_REFP(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_refp returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_refp returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event REFP went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'REFA' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_refa');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_REFA(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_refa returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_refa returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event REFA went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'PRNP' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_prnp');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_PRNP(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_prnp returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_prnp returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event PRNP went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'PRNA' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_prna');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_PRNA(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_prna returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_prna returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event PRNA went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'REAS' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_reas');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_REAS(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_reas returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_reas returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event REAS went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'REGN' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_regn');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_REGN(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_regn returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_regn returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event REGN went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    IF P_EVENT = 'ROLL' THEN
      DEBUG.PR_DEBUG('BC', 'About to Call BCPKSS_DELETE4.fn_bcdelete_roll');

      IF NOT BCPKSS_DELETE4.FN_BCDELETE_ROLL(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT,
                                             P_ACTION,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE4.fn_bcdelete_roll returned FALSE');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
        DEBUG.PR_DEBUG('BC', 'Value of p_err_codes is ' || P_ERR_CODES);

        OVPKSS.PR_APPENDTBL('BC-DE0001',
                            P_BCREFNO || LSPRTR || P_EVENT || LSPRTR ||
                            P_ESN || LSPRTR);

        OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

        RETURN FALSE;
      ELSE
        DEBUG.PR_DEBUG('BC',
                       'BCPKSS_DELETE1.fn_bcdelete_roll returned TRUE');
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'Deletion of Event ROLL went through SUCCESFULLY');
      DEBUG.PR_DEBUG('BC',
                     'BCPKSS_DELETE1.fn_bcdelete_anevent was SUCCESSFUL');
      DEBUG.PR_DEBUG('BC',
                     'Exitting out of BCPKSS_DELETE1.fn_bcdelete_anevent');

      OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

      RETURN TRUE;

    END IF;

    DEBUG.PR_DEBUG('BC',
                   'CRITICAL ERROR - There is no function to handle ' ||
                   ' deletion of Event ' || P_EVENT);
    DEBUG.PR_DEBUG('BC',
                   'CONTROL has come to the end of BCPKSS_DELETE1' ||
                   '.fn_bcdelete_anevent and still Event has NOT ' ||
                   'BEEN DELETED - RETURNING FALSE.');

    OVPKSS.PR_APPENDTBL('BC-DE0001',
                        P_BCREFNO || LSPRTR || P_EVENT || LSPRTR || P_ESN ||
                        LSPRTR);

    OVPKSS.PR_READTBL(P_ERR_CODES, P_ERR_PARAMS);

    RETURN FALSE;

  EXCEPTION

    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC',
                     'BOMBED in the body of BCPKSS_DELETE1' ||
                     '.fn_bcdelete_anevent while processing.');
      DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);

      OVPKSS.PR_APPENDTBL('BC-DE0001',
                          P_BCREFNO || LSPRTR || P_EVENT || LSPRTR || P_ESN ||
                          LSPRTR);

      RETURN FALSE;

  END FN_BCDELETE_ANEVENT;

  FUNCTION FN_DELETE_AMOUNT_DUE(P_BCREFNO    IN BCTBS_CONTRACT_MASTER.BCREFNO%TYPE,
                                P_ESN        IN BCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE,
                                P_EVENT      IN BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE,
                                P_ACTION     IN VARCHAR2,
                                P_ERR_CODES  IN OUT VARCHAR2,
                                P_ERR_PARAMS IN OUT VARCHAR2)

   RETURN BOOLEAN IS
    LSPRTR VARCHAR2(1) := '~';

  BEGIN
    DEBUG.PR_DEBUG('BC', 'Inside fn_delete_amount_due');

    DELETE CSTBS_AMOUNT_DUE
     WHERE CONTRACT_REF_NO = P_BCREFNO
       AND COMPONENT_TYPE = 'H'
       AND COMPONENT IN
           (SELECT COMPONENT
              FROM CFTMS_PRODUCT_CHARGE
             WHERE PRODUCT = SUBSTR(P_BCREFNO, 4, 4)
               AND EVENT_FOR_LIQUIDATION = P_EVENT);

    DEBUG.PR_DEBUG('BC', 'Going to exit fn_delete_amount_due');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC',
                     'BOMBED in the body of BCPKSS_DELETE1.fn_delete_amount_due while processing.');
      DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
      OVPKSS.PR_APPENDTBL('BC-DE0001',
                          P_BCREFNO || LSPRTR || P_EVENT || LSPRTR || P_ESN ||
                          LSPRTR);
      RETURN FALSE;

  END FN_DELETE_AMOUNT_DUE;

END BCPKS_DELETE1;
/