CREATE OR REPLACE PACKAGE BODY mspks_custom AS

  PROCEDURE DBG(P_MSG IN VARCHAR2) IS
  BEGIN
    IF (DEBUG.PKG_DEBUG_ON <> 2) THEN
      DEBUG.PR_DEBUG('MSPKS_CUSTOM', 'MSPKS -->' || P_MSG);
    END IF;
  END DBG;

  FUNCTION replacepos(source_in      IN VARCHAR2,
                      replacechar_in IN VARCHAR2,
                      position_in    IN NUMBER) RETURN VARCHAR2 IS
    l_returnvalue VARCHAR2(32767);
  BEGIN
    -- copy from the source string up to, but not including,
    -- the character position
    -- to be replaced
    l_returnvalue := substr(str1 => source_in,
                            pos  => 1,
                            len  => position_in - 1);
    -- add the replacement character
    -- just a single character, but more can be sent in,
    -- so substring the parameter
    l_returnvalue := l_returnvalue ||
                     substr(str1 => replacechar_in, pos => 1, len => 1);
    -- copy the rest of the source string
    l_returnvalue := l_returnvalue ||
                     substr(str1 => source_in, pos => position_in + 1);
    RETURN l_returnvalue;
  END replacepos;

  FUNCTION FN_GENERATE_MSG_OUT(P_MSG_HANDOFF     IN OUT MSTBS_MSG_HANDOFF%ROWTYPE,
                               P_COMMIT          IN OUT VARCHAR2,
                               PM_BAD_DCNS       IN OUT VARCHAR2,
                               P_FN_CALL_ID      IN OUT NUMBER,
                               P_TB_CLUSTER_DATA IN OUT GLOBAL.TY_TB_CLUSTER_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('**',
                   'Inside the function mspks_custom.Fn_Generate_Msg_Out..');
  
    DEBUG.PR_DEBUG('**',
                   'Returning successfully from the function Fn_Generate_Msg_Out..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Generate_Msg_Out..');
      RETURN FALSE;
  END FN_GENERATE_MSG_OUT;

  FUNCTION FN_GET_OTHRDTL(P_MSG_HANDOFF    MSTBS_MSG_HANDOFF%ROWTYPE,
                          P_DLY_MSG_TBL    IN OUT MSPKS.DLY_MSG_TBLTYPE,
                          P_CUR_BRANCH     IN MSTBS_MSG_HANDOFF.BRANCH%TYPE,
                          P_CUR_ACCOUNT    IN MSTBS_MSG_HANDOFF.CUST_AC_NO%TYPE,
                          P_CUR_MOD        IN OUT MSTBS_MSG_HANDOFF.MODULE%TYPE,
                          P_CUR_MSG_TYPE   IN MSTBS_MSG_HANDOFF.MSG_TYPE%TYPE,
                          P_FN_CALL_ID     IN NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'Inside the function Fn_get_othrdtl..');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function Fn_get_othrdtl..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS', 'w/o of Fn_get_othrdtl for custom ...');
      RETURN FALSE;
  END FN_GET_OTHRDTL;

  PROCEDURE PRE_PR_BG_GEN_MSG_OUT IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'Inside Custom Pre_Pr_Bg_Gen_Msg_Out ...');
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'In When Others of Mspks_custom.Pre_Pr_Bg_Gen_Msg_Out ..');
      DEBUG.PR_DEBUG('MS', SQLERRM);
  END PRE_PR_BG_GEN_MSG_OUT;

  PROCEDURE POST_PR_BG_GEN_MSG_OUT IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'Inside Custom Post_Pr_Bg_Gen_Msg_Out ...');
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'In When Others of Mspks_custom.Post_Pr_Bg_Gen_Msg_Out ..');
      DEBUG.PR_DEBUG('MS', SQLERRM);
  END POST_PR_BG_GEN_MSG_OUT;

  FUNCTION FN_GET_MESSAGE_DETAILS(P_DCN            IN MSTBS_DLY_MSG_OUT.DCN%TYPE,
                                  P_FN_CALL_ID     IN OUT NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'Inside Fn_Get_Message_Details for custom');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function Fn_Get_Message_Details for custom');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'In when others of Fn_Get_Message_Details for custom');
      DEBUG.PR_DEBUG('MS', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_MESSAGE_DETAILS;

  FUNCTION FN_VALIDATE_SWIFT_CHAR(P_DCN IN MSTBS_DLY_MSG_OUT.DCN%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'Fn_Validate_Swift_Char for custom ...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS', 'w/o of Fn_Validate_Swift_Char for custom ...');
      RETURN FALSE;
  END FN_VALIDATE_SWIFT_CHAR;

  FUNCTION PRE_FN_INSERT_DLY_MSG_OUT(P_DLY_MSG_OUT IN OUT MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'Inside Custom Pre_Fn_Insert_Dly_Msg_Out ...');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function Pre_Fn_Insert_Dly_Msg_Out..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'In When Others of Mspks_custom.Pre_Fn_Insert_Dly_Msg_Out ..');
      DEBUG.PR_DEBUG('MS', SQLERRM);
      RETURN FALSE;
  END PRE_FN_INSERT_DLY_MSG_OUT;

  FUNCTION POST_FN_INSERT_DLY_MSG_OUT(P_DLY_MSG_OUT IN MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'Inside Custom Post_Fn_Insert_Dly_Msg_Out ...');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function Post_Fn_Insert_Dly_Msg_Out..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'In When Others of Mspks_custom.Post_Fn_Insert_Dly_Msg_Out ..');
      DEBUG.PR_DEBUG('MS', SQLERRM);
      RETURN FALSE;
  END POST_FN_INSERT_DLY_MSG_OUT;

  FUNCTION FN_CALL_MCS_FUNC(PM_DCN            IN MSTBS_DLY_MSG_OUT.DCN%TYPE,
                            PM_NODE           IN MSTBS_DLY_MSG_OUT.NODE%TYPE,
                            PM_MEDIA          IN MSTBS_DLY_MSG_OUT.MEDIA%TYPE,
                            PM_MCS            IN MSTBS_DLY_MSG_OUT.MCS%TYPE,
                            PM_TWAUTH         IN BOOLEAN,
                            P_FN_CALL_ID      IN NUMBER,
                            P_TB_CLUSTER_DATA IN OUT GLOBAL.TY_TB_CLUSTER_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'Inside Fn_Call_Mcs_Func ...');
  
    DEBUG.PR_DEBUG('MS', 'Returning Successfully from Fn_Call_Mcs_Func..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS', 'w/o of Fn_Call_Mcs_Func for custom ...');
      RETURN FALSE;
  END FN_CALL_MCS_FUNC;

  FUNCTION FN_GET_MCS(P_DLY_MSG_OUT IN OUT MSTBS_DLY_MSG_OUT%ROWTYPE,
                      P_FN_CALL_ID  IN OUT NUMBER) RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS', 'In fn_get_MCS');
  
    DEBUG.PR_DEBUG('MS', 'Returning success from fn_get_MCS');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS', 'Failed inside function fn_get_MCS ' || SQLERRM);
      RETURN FALSE;
  END FN_GET_MCS;

  FUNCTION FN_REPLACE_SWIFT(PM_DCN       IN MSTBS_DLY_MSG_OUT.DCN%TYPE,
                            P_FN_CALL_ID IN NUMBER
                            
                           ,
                            P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
    --sampath starts
    L_TRANSMSG         CLOB;
    L_MSTB_DLY_MSG_OUT MSTB_DLY_MSG_OUT%ROWTYPE;
    --sampath ends
  
  BEGIN
    DEBUG.PR_DEBUG('MS',
                   'Inside the function mspks_custom.fn_replace_swift..');
  
    --sampath starts
    IF P_FN_CALL_ID = 2 THEN
    
      BEGIN
        SELECT *
          INTO L_MSTB_DLY_MSG_OUT
          FROM MSTB_DLY_MSG_OUT
         WHERE DCN = PM_DCN;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
      END;
    
      IF L_MSTB_DLY_MSG_OUT.SWIFT_MSG_TYPE = '700' THEN
      
        L_TRANSMSG := P_TB_CUSTOM_DATA('msg');
      
        L_TRANSMSG := REPLACE(L_TRANSMSG, ':57D:', ':57A:');
      
        L_TRANSMSG := REPLACE(L_TRANSMSG, ':42D:', ':42A:');
                    
        P_TB_CUSTOM_DATA('msg') := L_TRANSMSG;
      
      END IF;
    
    END IF;
    --sampath ends
  
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function fn_replace_swift..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of fn_replace_swift..');
      dbg('error code=' || sqlcode);
      dbg('error message=' || sqlerrm);
      dbg('error line number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_REPLACE_SWIFT;

  FUNCTION FN_GENERATE_OUT_MSGS(P_DCNS            VARCHAR2,
                                P_FN_CALL_ID      IN OUT NUMBER,
                                P_TB_CLUSTER_DATA IN OUT GLOBAL.TY_TB_CLUSTER_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('**',
                   'Inside the function mspks_custom.Fn_Generate_Out_Msgs..');
  
    DEBUG.PR_DEBUG('**',
                   'Returning successfully from the function Fn_Generate_Out_Msgs..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Generate_Out_Msgs..');
      RETURN FALSE;
  END FN_GENERATE_OUT_MSGS;

  PROCEDURE PR_INT_ADVICE(P_MODPROC_REC IN MSTBS_DLY_MSG_OUT%ROWTYPE,
                          P_MOD         IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('MS',
                   'Inside the function mspks_custom.pr_int_advice..');
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function mspks_custom.pr_int_advice..');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'When Others Then Exception in mspks_custom.pr_int_advice' ||
                     SQLERRM);
      RAISE;
  END PR_INT_ADVICE;

  FUNCTION FN_HOLD_MESSAGE(DLY_MSG_OUT      IN MSTB_DLY_MSG_OUT%ROWTYPE,
                           P_FN_CALL_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS',
                   'Inside the function mspks_custom.fn_hold_message...');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function fn_hold_message..');
    RETURN FALSE;
  END FN_HOLD_MESSAGE;

  FUNCTION FN_GET_PRE_ADDRESS(P_MSG_HANDOFF IN OUT MSTBS_MSG_HANDOFF%ROWTYPE,
                              P_DLY_MSG_TBL IN OUT MSPKS.DLY_MSG_TBLTYPE)
    RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('MS',
                   'Inside the function mspks_custom.FN_GET_PRE_ADDRESS...');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning success from mspks_custom.FN_GET_PRE_ADDRESS...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'In When Others of Mspks_custom.FN_GET_PRE_ADDRESS ..' ||
                     SQLERRM);
      RETURN FALSE;
  END FN_GET_PRE_ADDRESS;

  FUNCTION FN_GET_POST_ADDRESS(P_MSG_HANDOFF IN OUT MSTBS_MSG_HANDOFF%ROWTYPE,
                               P_DLY_MSG_TBL IN OUT MSPKS.DLY_MSG_TBLTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS',
                   'Inside the function mspks_custom.FN_GET_POST_ADDRESS...');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning success from mspks_custom.FN_GET_POST_ADDRESS...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'In When Others of Mspks_custom.FN_GET_POST_ADDRESS ..' ||
                     SQLERRM);
      RETURN FALSE;
  END FN_GET_POST_ADDRESS;

  FUNCTION FN_PRE_GET_FORMAT(P_DLY_MSG_OUT IN OUT MSTBS_DLY_MSG_OUT%ROWTYPE)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS',
                   'Inside the function mspks_custom.Fn_Pre_Get_Format...');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function Fn_Pre_Get_Format..');
  
    RETURN TRUE;
  END FN_PRE_GET_FORMAT;

  FUNCTION FN_GENERATE_DUP_COPY(P_MODPROC_REC    IN MSTBS_DLY_MSG_OUT%ROWTYPE,
                                P_ORG_MSG        IN MSTMS_MSG_TYPE.ORG_MSG_TYPE%TYPE,
                                P_ERR_CODE       IN OUT MSTBS_DLY_MSG_OUT.REPAIR_REASON%TYPE,
                                P_ORG_DCN        IN MSTBS_DLY_MSG_OUT.ORIGINAL_DCN%TYPE,
                                P_FN_CALL_ID     IN OUT NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS',
                   'Inside the function mspks_custom.Fn_Generate_Dup_Copy...');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning success from mspks_custom.Fn_Generate_Dup_Copy...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'In When Others of Mspks_custom.Fn_Generate_Dup_Copy ..' ||
                     SQLERRM);
      RETURN FALSE;
  END FN_GENERATE_DUP_COPY;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_PRE_VALIDATE_SWIFT_CHAR(P_DCN IN MSTBS_DLY_MSG_OUT.DCN%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('MS',
                   'Inside the function mspks_custom.Fn_Pre_Validate_Swift_Char...');
  
    DEBUG.PR_DEBUG('MS',
                   'Returning successfully from the function Fn_Pre_Validate_Swift_Char..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('MS',
                     'w/o of Fn_Pre_Validate_Swift_Char for cluster ...');
  END FN_PRE_VALIDATE_SWIFT_CHAR;

END MSPKS_CUSTOM;
