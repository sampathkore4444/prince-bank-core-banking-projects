CREATE OR REPLACE PACKAGE BODY bcpks_acc_entries AS

  G_EVENT_CODE VARCHAR2(4);
  FUNCTION FN_INSERT_CHGS(P_CONTRACT_REF_NO IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                          P_EVENT_SEQ_NO    IN BCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE,
                          P_EVENT_CODE      IN BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE,
                          P_AMOUNT_TAG      IN VARCHAR2,
                          P_LCY_AMOUNT      IN NUMBER,
                          P_VALUE_DATE      IN DATE) RETURN BOOLEAN;

  FUNCTION FN_STATUS_GLS(P_BCREFNO             IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                         P_EVENT_CODE          IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                         P_USER_DEFINED_STATUS IN CSTBS_CONTRACT.USER_DEFINED_STATUS%TYPE,
                         P_ACC_LOOKUP_TBL      IN OUT ACPKSS.TBL_LOOKUP,
                         P_ERR_CODE            IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                         P_ERR_PARAMS          IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_LC_CHARGES_TRANSFER(PCTB_CONTRACT    IN BCTB_CONTRACT_MASTER%ROWTYPE,
                                  P_EVENT_CODE     IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                                  INTERMEDIATE_TBL IN OUT INTERMEDIATE_TBL_TYPE,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_SETTLEMENT_UPDATES_TMP(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                                     P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                                     P_INTERMEDIATE_TBL IN INTERMEDIATE_TBL_TYPE,
                                     P_ERR_CODE         IN OUT VARCHAR2,
                                     P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_ASSIGN_VDATE(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                           P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                           P_EVENT_CODE       IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                           P_INTERMEDIATE_TBL IN OUT INTERMEDIATE_TBL_TYPE)
    RETURN BOOLEAN;

  FUNCTION FN_AVG_LCY_EQ(P_INTER_TBL IN OUT BCPKSS_ACC_ENTRIES.INTERMEDIATE_TBL_TYPE,
                         P_BCREFNO   IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                         P_ESN       IN CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE)
    RETURN BOOLEAN IS

    TYPE INDEX_TBL IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;

    L_INTER_TBL       BCPKSS_ACC_ENTRIES.INTERMEDIATE_TBL_TYPE;
    L_INDEX_TBL       INDEX_TBL;
    L_AC_OR_GL        STTBS_ACCOUNT.AC_OR_GL%TYPE;
    L_AVERAGE_LCY     NUMBER;
    L_AVG_LCY_ROUNDED NUMBER(22, 3);
    L_DERIVED_EX_RATE NUMBER(11, 5);
    J                 NUMBER;
    K                 NUMBER;

    L_BASIS_TAG      CSTBS_AMOUNT_TAG.AMOUNT_TAG%TYPE;
    L_BASIS_TAG_PREV CSTBS_AMOUNT_TAG.AMOUNT_TAG%TYPE;
    L_BASIS_TAG_NEXT CSTBS_AMOUNT_TAG.AMOUNT_TAG%TYPE;
    L_CHG_EQ         NUMBER;
    L_ACC_BRANCH     STTMS_BRANCH. BRANCH_CODE%TYPE;
    L_ACC_CCY        CYTMS_CCY_DEFN.CCY_CODE%TYPE;

    L_TMP_TBL2    BCPKSS_ACC_ENTRIES.INTERMEDIATE_TBL_TYPE;
    L_TMP_TBL3    BCPKSS_ACC_ENTRIES.INTERMEDIATE_TBL_TYPE;
    L_TMP_COUNT   INTEGER;
    L_TMP_IND_TBL INDEX_TBL;

    L_TMP_CONT_TBL   BCPKSS_ACC_ENTRIES.INTERMEDIATE_TBL_TYPE;
    L_INDEX_CONT_TBL INDEX_TBL;
    L_CONT_TBL_INDEX NUMBER;

    L_INTER_TEMP_TBL BCPKSS_ACC_ENTRIES.INTERMEDIATE_TBL_TYPE;
    L_INDEX_TEMP_TBL INDEX_TBL;
    L_TEMP_COUNT     NUMBER := 0;
    L_INDEX_RESTART  NUMBER;
    L_INTER_RESTART  NUMBER;
    L_DISC_EXISTS    BOOLEAN := FALSE;

    FUNCTION FN_REMOVE_UNDERSCORE(P_STRING IN VARCHAR2) RETURN VARCHAR2 IS
      RET_STRING CSTBS_AMOUNT_TAG.AMOUNT_TAG%TYPE := NULL;
    BEGIN
      IF LENGTH(P_STRING) = 0 THEN
        RETURN NULL;
      END IF;

      FOR I IN 1 .. LENGTH(P_STRING) LOOP
        IF SUBSTR(P_STRING, I, 1) <> '_' THEN
          RET_STRING := RET_STRING || SUBSTR(P_STRING, I, 1);
        END IF;
      END LOOP;

      RETURN RET_STRING;
    END;

  BEGIN

    L_INTER_TBL.DELETE;
    L_INDEX_TBL.DELETE;
    L_INDEX_CONT_TBL.DELETE;

    DEBUG.PR_DEBUG('BC', '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
    DEBUG.PR_DEBUG('BC', 'Inside LCY Averaging Function');

    DEBUG.PR_DEBUG('BC', 'INTERMEDIATE TBL IS ');

    FOR I IN 1 .. NVL(P_INTER_TBL.COUNT, 0) LOOP
      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - AMOUNT TAG  ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                     .AMT_TAG);
      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - ACCOUNT  ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                     .ACCOUNT);
      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - Acc Ccy     ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                     .ACC_CCY);
      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - Exch Rate   ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                     .EXCH_RATE);
      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - Fcy Amount  ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                     .FCY_AMT);
      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - Lcy Amount  ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                     .LCY_AMT);
      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - Gl Category ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                     .GLCAT);
      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - Trn Code ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                     .TRNCODE);
    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Before deleting temp. tables');

    L_TMP_TBL2.DELETE;
    L_TMP_TBL3.DELETE;
    L_TMP_CONT_TBL.DELETE;

    FOR I IN 1 .. 100 LOOP
      L_INDEX_TBL(I) := -9999;
      L_INDEX_CONT_TBL(I) := -9999;
    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Before Taking care of cross currency problem');

    L_TMP_COUNT := 1;

    FOR I IN 1 .. NVL(P_INTER_TBL.COUNT, 0) LOOP

      IF NVL(P_INTER_TBL(I).GLCAT, 'X') = 'X' THEN
        BEGIN
          SELECT ACC_CCY
            INTO L_ACC_CCY
            FROM ISTBS_CONTRACTIS
           WHERE CONTRACT_REF_NO = P_BCREFNO
             AND EVENT_SEQ_NO = P_ESN
             AND AMOUNT_TAG = P_INTER_TBL(I).AMT_TAG;
          P_INTER_TBL(I).ACC_CCY := L_ACC_CCY;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      END IF;

      IF NVL(P_INTER_TBL(I).TAGTYPE, 'X') <> 'H' AND P_INTER_TBL(I)
        .GLCAT NOT IN ('5', '6') THEN

        L_TMP_TBL2(L_TMP_COUNT) := P_INTER_TBL(I);
        L_INDEX_TBL(L_TMP_COUNT) := I;
        L_TMP_COUNT := L_TMP_COUNT + 1;
      END IF;

    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Contigent Entries');
    FOR I IN 1 .. NVL(P_INTER_TBL.COUNT, 0) LOOP
      IF P_INTER_TBL(I).GLCAT IN ('5', '6') THEN

        L_TMP_CONT_TBL(I) := P_INTER_TBL(I);
        L_INDEX_CONT_TBL(I) := I;
        DEBUG.PR_DEBUG('BC', 'Amount Tag ' || L_TMP_CONT_TBL(I).AMT_TAG);
      END IF;
    END LOOP;

    FOR I IN 1 .. NVL(L_TMP_TBL2.COUNT, 0) LOOP
      FOR J IN I .. NVL(L_TMP_TBL2.COUNT, 0) LOOP
        DEBUG.PR_DEBUG('BC',
                       '1 - ' || TO_CHAR(I) || ' ' || L_TMP_TBL2(I).AMT_TAG);
        DEBUG.PR_DEBUG('BC',
                       '2 - ' || TO_CHAR(J) || ' ' || L_TMP_TBL2(J).AMT_TAG);
        IF FN_REMOVE_UNDERSCORE(L_TMP_TBL2(I).AMT_TAG) >
           FN_REMOVE_UNDERSCORE(L_TMP_TBL2(J).AMT_TAG) THEN
          L_TMP_TBL3(1) := L_TMP_TBL2(I);
          L_TMP_TBL2(I) := L_TMP_TBL2(J);
          L_TMP_TBL2(J) := L_TMP_TBL3(1);

          L_TMP_IND_TBL(1) := L_INDEX_TBL(I);
          L_INDEX_TBL(I) := L_INDEX_TBL(J);
          L_INDEX_TBL(J) := L_TMP_IND_TBL(1);
        END IF;
      END LOOP;
    END LOOP;

    DEBUG.PR_DEBUG('BC', 'After Ascending Order');

    FOR I IN 1 .. NVL(L_TMP_TBL2.COUNT, 0) LOOP
      L_INTER_TBL(I) := L_TMP_TBL2(I);

      DEBUG.PR_DEBUG('BC',
                     'FN_AVG - AMOUNT TAG ' || TO_CHAR(I) || ' - ' || L_INTER_TBL(I)
                     .AMT_TAG);
    END LOOP;

    L_TMP_TBL2.DELETE;
    L_TMP_TBL3.DELETE;
    L_TMP_IND_TBL.DELETE;

    L_CHG_EQ := NVL(L_INTER_TBL.COUNT, 0) + 1;

    FOR I IN 1 .. NVL(P_INTER_TBL.COUNT, 0) LOOP
      IF NVL(P_INTER_TBL(I).TAGTYPE, 'X') = 'H' THEN
        IF P_INTER_TBL(I).AMT_TAG LIKE '%LEQV' THEN
          L_BASIS_TAG := SUBSTR(P_INTER_TBL(I).AMT_TAG,
                                1,
                                LENGTH(P_INTER_TBL(I).AMT_TAG) - 5);
          DEBUG.PR_DEBUG('BC', 'l_basis_tag ....' || L_BASIS_TAG);
          BEGIN
            L_BASIS_TAG_PREV := SUBSTR(P_INTER_TBL(I - 1).AMT_TAG,
                                       1,
                                       LENGTH(P_INTER_TBL(I - 1).AMT_TAG) - 5);
            DEBUG.PR_DEBUG('BC',
                           'l_basis_tag_prev ....' || L_BASIS_TAG_PREV);
          EXCEPTION
            WHEN OTHERS THEN
              L_BASIS_TAG_PREV := NULL;
          END;

          BEGIN
            L_BASIS_TAG_NEXT := SUBSTR(P_INTER_TBL(I + 1).AMT_TAG,
                                       1,
                                       LENGTH(P_INTER_TBL(I + 1).AMT_TAG) - 5);
            DEBUG.PR_DEBUG('BC',
                           'l_basis_tag_next ....' || L_BASIS_TAG_NEXT);
          EXCEPTION
            WHEN OTHERS THEN
              L_BASIS_TAG_NEXT := NULL;
          END;

          IF L_BASIS_TAG_PREV IS NOT NULL THEN
            IF L_BASIS_TAG = L_BASIS_TAG_PREV AND
               NVL(P_INTER_TBL(I - 1).GLCAT, 'X') =
               'X' AND P_INTER_TBL(I - 1).AMT_TAG LIKE '%LIQD' THEN

              DEBUG.PR_DEBUG('BC', 'HERE WITH 1...' || L_CHG_EQ);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i).amt_tag' || P_INTER_TBL(I)
                             .AMT_TAG);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i).acc_ccy' || P_INTER_TBL(I)
                             .ACC_CCY);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i).account' || P_INTER_TBL(I)
                             .ACCOUNT);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i-1).amt_tag' || P_INTER_TBL(I - 1)
                             .AMT_TAG);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i-1).acc_ccy' || P_INTER_TBL(I - 1)
                             .ACC_CCY);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i-1).account' || P_INTER_TBL(I - 1)
                             .ACCOUNT);

              L_INDEX_TBL(L_CHG_EQ) := I;
              L_INTER_TBL(L_CHG_EQ) := P_INTER_TBL(I);
              L_INDEX_TBL(L_CHG_EQ + 1) := I - 1;
              L_INTER_TBL(L_CHG_EQ + 1) := P_INTER_TBL(I - 1);
              L_CHG_EQ := L_CHG_EQ + 2;
            END IF;
          END IF;

          IF L_BASIS_TAG_NEXT IS NOT NULL THEN
            IF L_BASIS_TAG = L_BASIS_TAG_NEXT AND
               NVL(P_INTER_TBL(I + 1).GLCAT, 'X') =
               'X' AND P_INTER_TBL(I + 1).AMT_TAG LIKE '%LIQD' THEN

              DEBUG.PR_DEBUG('BC', 'HERE WITH 2...' || L_CHG_EQ);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i).amt_tag' || P_INTER_TBL(I)
                             .AMT_TAG);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i).acc_ccy' || P_INTER_TBL(I)
                             .ACC_CCY);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i).account' || P_INTER_TBL(I)
                             .ACCOUNT);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i+1).amt_tag' || P_INTER_TBL(I + 1)
                             .AMT_TAG);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i+1).acc_ccy' || P_INTER_TBL(I + 1)
                             .ACC_CCY);
              DEBUG.PR_DEBUG('BC',
                             'p_inter_tbl(i+1).account' || P_INTER_TBL(I + 1)
                             .ACCOUNT);

              L_INDEX_TBL(L_CHG_EQ) := I;
              L_INTER_TBL(L_CHG_EQ) := P_INTER_TBL(I);
              L_INDEX_TBL(L_CHG_EQ + 1) := I + 1;
              L_INTER_TBL(L_CHG_EQ + 1) := P_INTER_TBL(I + 1);
              L_CHG_EQ := L_CHG_EQ + 2;
            END IF;
          END IF;
        END IF;
      END IF;

      IF (P_INTER_TBL(I)
         .AMT_TAG LIKE '%DISC' OR P_INTER_TBL(I).AMT_TAG LIKE '%PREM') THEN

        L_DISC_EXISTS := TRUE;

        DEBUG.PR_DEBUG('BC', 'Encountered ....' || P_INTER_TBL(I).AMT_TAG);
        DEBUG.PR_DEBUG('BC', 'Index ....' || I);

        DEBUG.PR_DEBUG('BC',
                       'Before l_index_tbl(l_chg_eq) is ' ||
                       L_INDEX_TBL(L_CHG_EQ));
        DEBUG.PR_DEBUG('BC', 'Before l_chg_eq is ' || L_CHG_EQ);

        L_INDEX_TBL(L_CHG_EQ) := I;
        L_INTER_TBL(L_CHG_EQ) := P_INTER_TBL(I);
        L_CHG_EQ := L_CHG_EQ + 1;

        DEBUG.PR_DEBUG('BC',
                       'After l_index_tbl(l_chg_eq) is ' ||
                       L_INDEX_TBL(L_CHG_EQ));
        DEBUG.PR_DEBUG('BC', 'After l_chg_eq is ' || L_CHG_EQ);

      END IF;

    END LOOP;

    L_INDEX_RESTART := L_CHG_EQ;
    L_INTER_RESTART := L_CHG_EQ;

    DEBUG.PR_DEBUG('BC',
                   'Count of records in intertbl is ' ||
                   NVL(L_INTER_TBL.COUNT, 0));
    DEBUG.PR_DEBUG('BC',
                   'Count of records in inter temp tbl is ' ||
                   NVL(L_INTER_TEMP_TBL.COUNT, 0));

    IF L_DISC_EXISTS THEN
      DEBUG.PR_DEBUG('BC', 'DISC tags exists');
    ELSE
      DEBUG.PR_DEBUG('BC', 'DISC tags do not exists..');
    END IF;

    IF MOD(NVL(L_INTER_TBL.COUNT, 0), 2) <> 0 THEN
      DEBUG.PR_DEBUG('BC',
                     'There are ' || NVL(L_INTER_TBL.COUNT, 0) ||
                     ' rows to PROCESS for AVG. LCY equiv. ERROR!');
      DEBUG.PR_DEBUG('BC', 'MOD NOT equals ZERO');

      RETURN FALSE;
      DEBUG.PR_DEBUG('BC',
                     'Returns FALSE as mod(NVL(l_inter_tbl.COUNT,0),2) <> 0 if condition fails');

    END IF;

    DEBUG.PR_DEBUG('BC', 'Finished SFU ....');
    DEBUG.PR_DEBUG('BC', 'INTERMEDIATE TBL IS ');

    DEBUG.PR_DEBUG('BC',
                   'Printing index table, count = ' || L_INDEX_TBL.COUNT);
    IF L_INDEX_TBL.COUNT > 0 THEN
      FOR K IN L_INDEX_TBL.FIRST .. L_INDEX_TBL.LAST LOOP
        IF L_INDEX_TBL(K) <> -9999 THEN
          DEBUG.PR_DEBUG('BC', K || '~' || L_INDEX_TBL(K));
        END IF;
      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('BC', 'About to Calculate Average LCY');

    FOR I IN 1 .. NVL(L_INDEX_TBL.COUNT, 0) LOOP
      DEBUG.PR_DEBUG('BC',
                     'Inside For Loop l_index_tbl.COUNT' ||
                     L_INDEX_TBL.COUNT);
      DEBUG.PR_DEBUG('BC', 'Inside For Loop i value is ' || I);

      IF MOD(I, 2) != 0 AND (L_INDEX_TBL(I) != -9999) THEN

        IF L_INTER_TBL(I)
         .ACC_CCY = GLOBAL.LCY AND L_INTER_TBL(I + 1).ACC_CCY <>
            GLOBAL.LCY THEN
          L_AVERAGE_LCY := L_INTER_TBL(I).LCY_AMT;
          DEBUG.PR_DEBUG('BC', 'intertbl1 lcy ' || L_AVERAGE_LCY);
        ELSIF L_INTER_TBL(I + 1)
         .ACC_CCY = GLOBAL.LCY AND L_INTER_TBL(I).ACC_CCY <> GLOBAL.LCY THEN
          L_AVERAGE_LCY := L_INTER_TBL(I + 1).LCY_AMT;
          DEBUG.PR_DEBUG('BC', 'intertbl2 lcy ' || L_AVERAGE_LCY);
        ELSE
          L_AVERAGE_LCY := (L_INTER_TBL(I)
                           .LCY_AMT + L_INTER_TBL(I + 1).LCY_AMT) / 2;
          DEBUG.PR_DEBUG('BC', 'Taking the average ' || L_AVERAGE_LCY);
        END IF;

        IF NOT
            CYPKSS.FN_AMT_ROUND(GLOBAL.LCY, L_AVERAGE_LCY, L_AVG_LCY_ROUNDED) THEN
          DEBUG.PR_DEBUG('BC',
                         'AVERAGE LCY Equivalent could not be ROUNDED');
          RETURN FALSE;
        END IF;

        P_INTER_TBL(L_INDEX_TBL(I)).LCY_AMT := L_AVG_LCY_ROUNDED;
        IF P_INTER_TBL(L_INDEX_TBL(I)).ACC_CCY <> GLOBAL.LCY THEN
          IF NOT
              CYPKSS.FN_AMT_TO_RATE(P_INTER_TBL      (L_INDEX_TBL(I)).ACC_CCY,
                                    GLOBAL.LCY,
                                    P_INTER_TBL      (L_INDEX_TBL(I)).FCY_AMT,
                                    L_AVG_LCY_ROUNDED,
                                    L_DERIVED_EX_RATE) THEN
            DEBUG.PR_DEBUG('BC', 'Failed to Derive the Exchange Rate ');
            RETURN FALSE;
          ELSE
            P_INTER_TBL(L_INDEX_TBL(I)).EXCH_RATE := L_DERIVED_EX_RATE;
          END IF;
        ELSE
          P_INTER_TBL(L_INDEX_TBL(I)).EXCH_RATE := '';
        END IF;

        P_INTER_TBL(L_INDEX_TBL(I + 1)).LCY_AMT := L_AVG_LCY_ROUNDED;
        IF P_INTER_TBL(L_INDEX_TBL(I + 1)).ACC_CCY <> GLOBAL.LCY THEN
          IF NOT CYPKSS.FN_AMT_TO_RATE(P_INTER_TBL      (L_INDEX_TBL(I + 1))
                                       .ACC_CCY,
                                       GLOBAL.LCY,
                                       P_INTER_TBL      (L_INDEX_TBL(I + 1))
                                       .FCY_AMT,
                                       L_AVG_LCY_ROUNDED,
                                       L_DERIVED_EX_RATE) THEN
            DEBUG.PR_DEBUG('BC', 'Failed to Derive the Exchange Rate ');
            RETURN FALSE;
          ELSE
            P_INTER_TBL(L_INDEX_TBL(I + 1)).EXCH_RATE := L_DERIVED_EX_RATE;
          END IF;
        ELSE
          P_INTER_TBL(L_INDEX_TBL(I + 1)).EXCH_RATE := '';
        END IF;

        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - AMOUNT TAG ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                       .AMT_TAG);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - ACCOUNT ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                       .ACCOUNT);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Acc Ccy ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                       .ACC_CCY);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Exch Rate ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                       .EXCH_RATE);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Fcy Amount ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                       .FCY_AMT);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Lcy Amount ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                       .LCY_AMT);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Trn Code ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I)
                       .TRNCODE);

        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - AMOUNT TAG ' || TO_CHAR(I + 1) || ' - ' || P_INTER_TBL(I + 1)
                       .AMT_TAG);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - ACCOUNT ' || TO_CHAR(I + 1) || ' - ' || P_INTER_TBL(I + 1)
                       .ACCOUNT);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Acc Ccy ' || TO_CHAR(I + 1) || ' - ' || P_INTER_TBL(I + 1)
                       .ACC_CCY);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Exch Rate ' || TO_CHAR(I + 1) || ' - ' || P_INTER_TBL(I + 1)
                       .EXCH_RATE);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Fcy Amount ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I + 1)
                       .FCY_AMT);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Lcy Amount ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I + 1)
                       .LCY_AMT);
        DEBUG.PR_DEBUG('BC',
                       'FN_AVG - Trn Code ' || TO_CHAR(I) || ' - ' || P_INTER_TBL(I + 1)
                       .TRNCODE);

      END IF;

    END LOOP;

    L_CONT_TBL_INDEX := P_INTER_TBL.COUNT;

    FOR I IN 1 .. NVL(L_INDEX_CONT_TBL.COUNT, 0) LOOP
      IF L_INDEX_CONT_TBL(I) <> -9999 THEN
        P_INTER_TBL(I) := L_TMP_CONT_TBL(I);
      END IF;

    END LOOP;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'ORACLE ERROR in FN_AVG_LCY_EQ : ' || SQLERRM);
      RETURN FALSE;
  END FN_AVG_LCY_EQ;

  FUNCTION FN_ASSIGN_VIRTUALACC(P_BCREFNO    IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                                P_ESN        IN BCTBS_ICCF_MASTER.PESN%TYPE,
                                P_TAG        IN VARCHAR2,
                                P_REALACC    IN VARCHAR2,
                                P_VIRTUALACC OUT VARCHAR2,
                                P_ERR_CODE   IN OUT VARCHAR2,
                                P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_PASS_ACC_ENTRIES(P_BCREFNO             IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                               P_EVENT_CODE          IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                               P_ESN                 IN BCTBS_ICCF_MASTER.PESN%TYPE,
                               P_REPLICATE           IN VARCHAR2,
                               P_USER_DEFINED_STATUS IN CSTBS_CONTRACT.USER_DEFINED_STATUS%TYPE,
                               P_MODULE              IN CSTBS_CONTRACT_EVENT_LOG.MODULE%TYPE,
                               P_PROCESS_CHARGES     IN CHAR,
                               P_PROCESS_TAX         IN CHAR,
                               P_ACC_LOOKUP_REQ      IN CHAR,
                               P_ACTION_CODE         IN CHAR,
                               P_SUSPENCE            IN CHAR,
                               P_ACC_LOOKUP_TBL      IN OUT ACPKSS.TBL_LOOKUP,
                               P_AMTTAG_TBL          IN OUT BCPKSS_ICCF2.ICCF_TBL_TYPE,
                               P_ERR_CODE            IN OUT VARCHAR2,
                               P_ERR_PARAMS          IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN
    IF NOT FN_PASS_ACC_ENTRIES(P_BCREFNO,
                               P_EVENT_CODE,
                               P_ESN,
                               P_REPLICATE,
                               P_USER_DEFINED_STATUS,
                               P_MODULE,
                               P_PROCESS_CHARGES,
                               P_PROCESS_TAX,
                               P_ACC_LOOKUP_REQ,
                               P_ACTION_CODE,
                               P_SUSPENCE,
                               P_ACC_LOOKUP_TBL,
                               P_AMTTAG_TBL,
                               P_ERR_CODE,
                               P_ERR_PARAMS,
                               'N') THEN
      DEBUG.PR_DEBUG('BC',
                     'Passing Accounting Entries Failed with' || SQLERRM);
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END FN_PASS_ACC_ENTRIES;

  FUNCTION FN_PASS_ACC_ENTRIES(P_BCREFNO             IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                               P_EVENT_CODE          IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                               P_ESN                 IN BCTBS_ICCF_MASTER.PESN%TYPE,
                               P_REPLICATE           IN VARCHAR2,
                               P_USER_DEFINED_STATUS IN CSTBS_CONTRACT.USER_DEFINED_STATUS%TYPE,
                               P_MODULE              IN CSTBS_CONTRACT_EVENT_LOG.MODULE%TYPE,
                               P_PROCESS_CHARGES     IN CHAR,
                               P_PROCESS_TAX         IN CHAR,
                               P_ACC_LOOKUP_REQ      IN CHAR,
                               P_ACTION_CODE         IN CHAR,
                               P_SUSPENCE            IN CHAR,
                               P_ACC_LOOKUP_TBL      IN OUT ACPKSS.TBL_LOOKUP,
                               P_AMTTAG_TBL          IN OUT BCPKSS_ICCF2.ICCF_TBL_TYPE,
                               P_ERR_CODE            IN OUT VARCHAR2,
                               P_ERR_PARAMS          IN OUT VARCHAR2,
                               P_CHG_REQD            IN VARCHAR2)
    RETURN BOOLEAN IS

    INTERMEDIATE_TBL INTERMEDIATE_TBL_TYPE;
    L_TAG_LST        VARCHAR2(1000) := '';
    ACC_HANDOFF_TBL  ACPKSS.TBL_ACHOFF;
    TMP_HANDOFF_TBL  ACPKSS.TBL_ACHOFF;
    L_TEMPTAG_TBL    BCPKSS_ICCF2.ICCF_TBL_TYPE;
    L_ALL_PICKUP     CHAR(1);
    PROCESS_FAILED EXCEPTION;
    THIS_FN       VARCHAR2(50) := 'BCPKS_ACC_ENTRIES.fn_pass_acc_entries';
    J             NUMBER := 0;
    L_UDEF_STATUS BCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS%TYPE;

    L_LIST_CHARGE_TAGS   VARCHAR2(10000);
    L_LIST_CHARGE_TAGCCY VARCHAR2(10000);
    L_LIST_CHARGE_TAGAMT VARCHAR2(10000);

    CNT_CCY                      VARCHAR2(100);
    CHG_AMT_IN_CNT_CCY           VARCHAR2(100);
    L_LIST_OF_CNT_CCY            VARCHAR2(10000);
    L_LIST_OF_CHG_AMT_IN_CNT_CCY VARCHAR2(10000);

    I        NUMBER := 0;
    K        NUMBER := 0;
    ATAG     VARCHAR2(100);
    ACCY     VARCHAR2(100);
    ANAMOUNT VARCHAR2(100);

    I_NP            INTEGER := 0;
    L_COMPONENT     VARCHAR2(15);
    P1              NUMBER;
    L_VALUE_DATE    DATE;
    L_CHQ_UPDATED   BOOLEAN := FALSE;
    L_BCTB_CONTRACT BCTBS_CONTRACT_MASTER%ROWTYPE;
    LBCTB_CONTRACT  BCTBS_CONTRACT_MASTER%ROWTYPE;
    L_AC_BRANCH     ISTBS_CONTRACTIS.ACC_BRANCH%TYPE;
    L_AC_NO         ISTBS_CONTRACTIS.ACCOUNT%TYPE;
    L_AMT           ISTBS_CONTRACTIS.SETTLEMENT_AMT%TYPE;
    L_ERR_CODES     ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAMS    ERTBS_MSGS.MESSAGE%TYPE;

    L_CHECK_NUMBER BCTBS_CONTRACT_MASTER.CHECK_NUMBER%TYPE;
    L_LIQ_AMT      BCTBS_CONTRACT_MASTER.BILL_AMT_LIQD%TYPE;
    L_CHK_ACCOUNT  ACTBS_DAILY_LOG.AC_NO%TYPE;
    L_ACC_BRANCH   ACTBS_DAILY_LOG.AC_BRANCH%TYPE;
    L_AC_OR_GL     STTBS_ACCOUNT.AC_OR_GL%TYPE;
    L_CHECK_STATUS VARCHAR2(20);
    L_COUNT        NUMBER;

    L_BRIDGE_GL VARCHAR2(9);

    L_EOD STTMS_BRANCH.END_OF_INPUT%TYPE;

    L_LIQD_AMT BCTBS_CONTRACT_MASTER.BILL_AMT_LIQD%TYPE;

    L_EXCH_RATE      CYTMS_RATES.BUY_RATE%TYPE;
    L_RET_AMT        BCTBS_CONTRACT_MASTER.BILL_AMT%TYPE;
    L_COLLAT_BRIDGE  LCTM_PRODUCT_DEFINITION.COLLATERAL_TRANSFER_BRIDGE%TYPE;
    L_RELATED_REF_NO LCTB_AVAILMENTS.RELATED_REF_NO%TYPE;
    L_EVENT_CODE     LCTB_AVAILMENTS.EVENT_CODE%TYPE;

    L_AMT_TAG      CSTMS_PRODUCT_EVENT_ACCT_ENTRY.AMT_TAG%TYPE;
    L_ACCOUNT_ROLE CSTMS_PRODUCT_EVENT_ACCT_ENTRY.ACCOUNT_ROLE_CODE%TYPE;
    L_FOUND        BOOLEAN;
    L_BOOKING_CCY  BRTBS_TXNBOOK.BOOKING_CCY%TYPE;

    LBRKBOOKED        BCTBS_CONTRACT_MASTER.BILL_AMT%TYPE;
    LBRKEXRATE        BRTBS_TXNBOOK.BOOKING_EX_RATE%TYPE;
    L_BROKAMT         BRTB_MAINTXN.BROKERAGE_AMOUNT%TYPE;
    L_BROKCCY         BRTB_MAINTXN.BROKERAGE_CCY%TYPE;
    L_BROK_PAYABLE_GL VARCHAR2(20);

    L_LIQD_USING_COLLAT  VARCHAR2(1);
    L_COLLAT_ACCOUNT     ISTB_CONTRACTIS.ACCOUNT%TYPE;
    L_EVENT_SEQ_NO       ISTB_CONTRACTIS.EVENT_SEQ_NO%TYPE;
    L_BILL_DUE_AMT       BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE;
    P_REAL_TO_CONTINGENT BOOLEAN := FALSE;
    L_ADV_BY_LOAN        BCTB_CONTRACT_MASTER.ADVANCE_BY_LOAN%TYPE;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;

    L_AMTTAG_TBL        BCPKSS_ICCF2.ICCF_TBL_TYPE;
    L_ROLETYPE          CSTMS_PRODUCT_EVENT_ACCT_ENTRY.ROLE_TYPE%TYPE;
    L_NETTING_INDICATOR ISTBS_CONTRACTIS.NETTING_INDICATOR%TYPE;

    L_TAGAVBL BOOLEAN := FALSE;

  BEGIN
    DEBUG.PR_DEBUG('BC', 'Inside BCPKS_ACC_ENTRIES.fn_pass_acc_entries');
    DEBUG.PR_DEBUG('BC',
                   'Incoming amttag_tbl has ' || P_AMTTAG_TBL.COUNT ||
                   ' rows');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';
    G_EVENT_CODE := P_EVENT_CODE;
    DEBUG.PR_DEBUG('BC', 'g_event_code is-->' || G_EVENT_CODE);
    IF P_ACC_LOOKUP_REQ = 'Y' THEN
      IF NOT FN_DO_ACC_LOOKUP(P_BCREFNO,
                              P_EVENT_CODE,
                              P_USER_DEFINED_STATUS,
                              P_ACC_LOOKUP_TBL,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'fn_acc_lookup FAILED-' || SQLERRM);
        RAISE PROCESS_FAILED;
      END IF;

      DEBUG.PR_DEBUG('BC', 'Acc_lookup thru');
    END IF;

    DEBUG.PR_DEBUG('BC',
                   'Acc_lookup_tbl has ' || P_ACC_LOOKUP_TBL.COUNT ||
                   ' rows');

    IF P_ACC_LOOKUP_TBL.COUNT = 0 THEN
      P_ERR_CODE   := 'BC-AT005';
      P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~' || P_EVENT_CODE || '~';
      DEBUG.PR_DEBUG('BC', 'NOTHING in acc_lookup_tbl for acc_entries');
      DEBUG.PR_DEBUG('BC', 'Exiting accounting server');
      RETURN TRUE;
    END IF;

    IF NOT
        FN_SORT_ACC_LOOKUP_TBL(P_ACC_LOOKUP_TBL, P_ERR_CODE, P_ERR_PARAMS) THEN
      RAISE PROCESS_FAILED;
    END IF;

    DEBUG.PR_DEBUG('BC', 'Printing the sorted acc_lookup_tbl');

    DEBUG.PR_DEBUG('BC',
                   'Tbl_index' || ' - ' || 'acc_role' || ' - ' || 'account' ||
                   ' - ' || 'amttag');

    DEBUG.PR_DEBUG('BC',
                   'l_user_defined_status - ' || P_USER_DEFINED_STATUS);
    IF P_USER_DEFINED_STATUS <> 'NORM' THEN
      IF NOT BCPKSS_STATUS1.FN_REAL_TO_CONTINGENT(SUBSTR(P_BCREFNO, 4, 4),
                                                  P_USER_DEFINED_STATUS,
                                                  'NORM',
                                                  P_REAL_TO_CONTINGENT,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'FUNCTION real to contingent retuned false');
        RETURN FALSE;
      END IF;

      IF P_REAL_TO_CONTINGENT AND SUBSTR(P_EVENT_CODE, 1, 1) = 'L' THEN
        IF NOT FN_STATUS_GLS(P_BCREFNO,
                             P_EVENT_CODE,
                             P_USER_DEFINED_STATUS,
                             P_ACC_LOOKUP_TBL,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
          RAISE PROCESS_FAILED;
        END IF;
      END IF;
    END IF;
    DEBUG.PR_DEBUG('BC',
                   'Printing the acc_lookup_tbl for sttaus in contingents ...');
    DEBUG.PR_DEBUG('BC',
                   'Tbl_index' || ' - ' || 'acc_role' || ' - ' || 'account' ||
                   ' - ' || 'amttag');
    FOR I IN P_ACC_LOOKUP_TBL.FIRST .. P_ACC_LOOKUP_TBL.LAST LOOP
      DEBUG.PR_DEBUG('BC',
                     I || ' - ' || P_ACC_LOOKUP_TBL(I).ACCROLE || ' - ' || P_ACC_LOOKUP_TBL(I)
                     .ACCOUNT || ' - ' || P_ACC_LOOKUP_TBL(I).AMTTAG);
    END LOOP;

    DEBUG.PR_DEBUG('BC', ' p_event_code ---> ' || P_EVENT_CODE);
    IF P_MODULE IN ('BC', 'IB') AND P_EVENT_CODE = 'LIQD' THEN

      BEGIN
        SELECT *
          INTO LBCTB_CONTRACT
          FROM BCTBS_CONTRACT_MASTER A
         WHERE A.BCREFNO = P_BCREFNO
           AND A.EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM BCTBS_CONTRACT_MASTER B
                 WHERE B.BCREFNO = P_BCREFNO

                   AND B.EVENT_SEQ_NO < P_ESN);

      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC', 'Select from bctbs_contract_master failed');
          DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
          RETURN FALSE;
      END;

      BEGIN
        SELECT END_OF_INPUT
          INTO L_EOD
          FROM STTMS_BRANCH
         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC', 'Branch Record not found in sttms_branch');
          RETURN FALSE;
      END;

      BEGIN
        SELECT BILL_AMT_LIQD, BILL_DUE_AMT, ADVANCE_BY_LOAN
          INTO L_LIQD_AMT, L_BILL_DUE_AMT, L_ADV_BY_LOAN
          FROM BCTB_CONTRACT_MASTER
         WHERE BCREFNO = P_BCREFNO
           AND EVENT_SEQ_NO = P_ESN;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_LIQD_AMT := LBCTB_CONTRACT.BILL_AMT_LIQD;
      END;

    END IF;

    IF P_MODULE IN ('BC', 'IB') AND
       P_EVENT_CODE NOT IN
       ('LIQD', 'LADV', 'LCOL', 'LDIS', 'LPUR', 'BDIS', 'BPUR', 'CLOS') THEN

      BEGIN
        SELECT VALUE_DATE
          INTO L_VALUE_DATE
          FROM BCTBS_CONTRACT_MASTER
         WHERE BCREFNO = P_BCREFNO
           AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                                 FROM BCTBS_CONTRACT_MASTER
                                WHERE BCREFNO = P_BCREFNO);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN

          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM BCTBS_ACCRUAL_DETAILS
             WHERE PRODUCT_ACCRUAL_REF_NO = P_BCREFNO;

            IF L_COUNT > 0 THEN
              L_VALUE_DATE := TO_DATE(GLOBAL.APPLICATION_DATE);
            ELSE
              RETURN FALSE;
            END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              RETURN FALSE;
          END;
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC', 'Failed to get Value date - ' || SQLERRM);
          RETURN FALSE;
      END;
    ELSE
      L_VALUE_DATE := TO_DATE(GLOBAL.APPLICATION_DATE);
    END IF;

    DEBUG.PR_DEBUG('BC', 'Got value date as - ' || L_VALUE_DATE);

    IF P_PROCESS_CHARGES = 'Y' THEN

      DEBUG.PR_DEBUG('BC', 'About to Liquidate Charges');
      IF NOT CFPKSS_CHARGE.FN_LIQUIDATE_FOR_A_EVENT(P_BCREFNO,
                                                    P_ESN,
                                                    P_EVENT_CODE,

                                                    L_VALUE_DATE,
                                                    L_LIST_CHARGE_TAGS,
                                                    L_LIST_CHARGE_TAGCCY,
                                                    L_LIST_CHARGE_TAGAMT,

                                                    'A',
                                                    L_LIST_OF_CNT_CCY,
                                                    L_LIST_OF_CHG_AMT_IN_CNT_CCY,

                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'liqd-for-charge FAILED');
        DEBUG.PR_DEBUG('BC', P_ERR_CODE || '-' || SQLERRM);
        RAISE PROCESS_FAILED;
      END IF;

      I := 1;

      ATAG     := CSPKES_MISC.FN_GETPARAM(L_LIST_CHARGE_TAGS, I, '~');
      ACCY     := CSPKES_MISC.FN_GETPARAM(L_LIST_CHARGE_TAGCCY, I, '~');
      ANAMOUNT := CSPKES_MISC.FN_GETPARAM(L_LIST_CHARGE_TAGAMT, I, '~');

      CNT_CCY            := CSPKES_MISC.FN_GETPARAM(L_LIST_OF_CNT_CCY,
                                                    I,
                                                    '~');
      CHG_AMT_IN_CNT_CCY := CSPKES_MISC.FN_GETPARAM(L_LIST_OF_CHG_AMT_IN_CNT_CCY,
                                                    I,
                                                    '~');

      K := NVL(P_AMTTAG_TBL.LAST, 0) + 1;
      DEBUG.PR_DEBUG('BC', 'PL/SQL TABLE index is ' || K);

      WHILE ATAG <> 'EOPL' LOOP
        DEBUG.PR_DEBUG('BC',
                       '24707222 :: inside the loop :: atag :: ' || ATAG);
        P_AMTTAG_TBL(K).TAG := ATAG;
        P_AMTTAG_TBL(K).AMT := TO_NUMBER(ANAMOUNT);
        P_AMTTAG_TBL(K).CCY := ACCY;

        IF CNT_CCY IS NOT NULL THEN
          DEBUG.PR_DEBUG('BC',
                         'DAN-> Assigning, contract ccy = ' || CNT_CCY ||
                         ', chg amt in cont ccy = ' ||
                         TO_NUMBER(CHG_AMT_IN_CNT_CCY));
          P_AMTTAG_TBL(K).CONTRACT_CCY := CNT_CCY;
          P_AMTTAG_TBL(K).CHG_AMT_IN_CONTRACT_CCY := TO_NUMBER(CHG_AMT_IN_CNT_CCY);
        END IF;

        P_AMTTAG_TBL(K).VDATE := L_VALUE_DATE;
        P_AMTTAG_TBL(K).LCY_AMT_EQUIV := '';
        P_AMTTAG_TBL(K).SETTLEMENT_FLAG := '';
        P_AMTTAG_TBL(K).TAG_TYPE := '';

        K := K + 1;

        I := I + 1;

        ATAG := CSPKES_MISC.FN_GETPARAM(L_LIST_CHARGE_TAGS, I, '~');
        DEBUG.PR_DEBUG('BC', 'Adding Tag ' || ATAG);
        ACCY     := CSPKES_MISC.FN_GETPARAM(L_LIST_CHARGE_TAGCCY, I, '~');
        ANAMOUNT := CSPKES_MISC.FN_GETPARAM(L_LIST_CHARGE_TAGAMT, I, '~');

        CNT_CCY            := CSPKES_MISC.FN_GETPARAM(L_LIST_OF_CNT_CCY,
                                                      I,
                                                      '~');
        CHG_AMT_IN_CNT_CCY := CSPKES_MISC.FN_GETPARAM(L_LIST_OF_CHG_AMT_IN_CNT_CCY,
                                                      I,
                                                      '~');

      END LOOP;

      DEBUG.PR_DEBUG('BC',
                     'After processing charges Amttag_tbl has ' ||
                     P_AMTTAG_TBL.COUNT || ' rows');
      DEBUG.PR_DEBUG('BC', '24564136 :: g_event_code :: ' || G_EVENT_CODE);
      IF G_EVENT_CODE = 'LIQD' THEN

        DEBUG.PR_DEBUG('BC',
                       '24707222 :: calling the to get the charge details... ');
        IF NOT BCPKSS_ICCF2.FN_GET_CHARGE_DETAILS(P_BCREFNO,
                                                  P_ESN,
                                                  'N',
                                                  L_AMTTAG_TBL,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
          DEBUG.PR_DEBUG('BC',
                         'bcpkss_iccf2.fn_get_charge_Details ' ||
                         'returned FALSE');
          DEBUG.PR_DEBUG('BC',
                         'The value of p_err_codes is ' || P_ERR_CODE);
          DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
          RETURN FALSE;
        ELSE
          DEBUG.PR_DEBUG('BC',
                         '24707222 :: bcpkss_iccf2.fn_get_charge_Details ' ||
                         'returned TRUE');
          DEBUG.PR_DEBUG('BC',
                         '24707222 :: bcpkss_iccf2.fn_get_charge_Details ' ||
                         L_AMTTAG_TBL.COUNT || ' tags');
          L_COUNT := L_AMTTAG_TBL.COUNT;

          DEBUG.PR_DEBUG('BC', 'l_count :: ' || L_COUNT);

          IF L_COUNT > 0 THEN
            FOR I IN L_AMTTAG_TBL.FIRST .. L_AMTTAG_TBL.LAST LOOP
              DEBUG.PR_DEBUG('BC',
                             'l_amttag_tbl(I).TAG :: ' || L_AMTTAG_TBL(I).TAG);
              DEBUG.PR_DEBUG('BC',
                             'l_amttag_tbl(I).AMT :: ' || L_AMTTAG_TBL(I).AMT);
              DEBUG.PR_DEBUG('BC',
                             'l_amttag_tbl(I).CCY :: ' || L_AMTTAG_TBL(I).CCY);
              DEBUG.PR_DEBUG('BC',
                             'l_amttag_tbl(I).LCY_AMT_EQUIV :: ' || L_AMTTAG_TBL(I)
                             .LCY_AMT_EQUIV);
            END LOOP;
          END IF;
        END IF;

      ELSE
        DEBUG.PR_DEBUG('BC', '24564136 :: inside the else part..1. ');
        L_AMTTAG_TBL := P_AMTTAG_TBL;
      END IF;

    END IF;

    IF P_PROCESS_TAX = 'Y' THEN
      DEBUG.PR_DEBUG('BC', 'About to process Tax');
      IF NOT BCPKSS_ICCF2.FN_GET_TAX_DETAILS(P_BCREFNO,
                                             P_ESN,
                                             P_EVENT_CODE,
                                             P_MODULE,
                                             L_AMTTAG_TBL,
                                             P_ERR_CODE,
                                             P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'fn_pass_acc_entries get tax FAILED');
        DEBUG.PR_DEBUG('BC', P_ERR_CODE || '-' || SQLERRM);
        RAISE PROCESS_FAILED;
      END IF;
      DEBUG.PR_DEBUG('BC',
                     'After processing tax Amttag_tbl has ' ||
                     P_AMTTAG_TBL.COUNT || ' rows');
      DEBUG.PR_DEBUG('BC',
                     '24707222 :: After processing tax l_amttag_tbl has ' ||
                     L_AMTTAG_TBL.COUNT || ' rows');
      IF G_EVENT_CODE = 'LIQD' THEN

        IF L_AMTTAG_TBL.COUNT > L_COUNT THEN
          DEBUG.PR_DEBUG('BC', 'Inside Else');
          FOR I IN 1 .. L_AMTTAG_TBL.COUNT LOOP
            DEBUG.PR_DEBUG('BC', '***************************************');
            DEBUG.PR_DEBUG('BC',
                           'l_amttag_tbl.tag:           ' || L_AMTTAG_TBL(I).TAG);
            DEBUG.PR_DEBUG('BC', '***************************************');
            L_TAGAVBL := FALSE;
            FOR J IN 1 .. P_AMTTAG_TBL.COUNT LOOP

              DEBUG.PR_DEBUG('BC',
                             'p_amttag_tbl(j).tag::' || P_AMTTAG_TBL(J).TAG);
              IF L_AMTTAG_TBL(I).TAG = P_AMTTAG_TBL(J).TAG THEN
                DEBUG.PR_DEBUG('BC', 'Found the tag');
                L_TAGAVBL := TRUE;
                EXIT;
              END IF;
            END LOOP;

            IF NOT L_TAGAVBL THEN
              DEBUG.PR_DEBUG('BC', 'Not available');
              P_AMTTAG_TBL(P_AMTTAG_TBL.COUNT + 1) := L_AMTTAG_TBL(I);
            END IF;

          END LOOP;
        END IF;

      ELSE
        DEBUG.PR_DEBUG('BC', '24564136 :: inside the else part..2. ');
        P_AMTTAG_TBL := L_AMTTAG_TBL;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('BC',
                   'No of rows in Amttag_tbl here in SPRING TIME After Processing Subsystems::- ' ||
                   P_AMTTAG_TBL.COUNT);

    FOR I IN 1 .. P_AMTTAG_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC',
                     '----------------Starts SPRING ---------------------');
      DEBUG.PR_DEBUG('BC',
                     'SPRING TIME tag:           ' || P_AMTTAG_TBL(I).TAG);
      DEBUG.PR_DEBUG('BC',
                     'SPRING TIME amt:           ' || P_AMTTAG_TBL(I).AMT);
      DEBUG.PR_DEBUG('BC',
                     'SPRING TIME ccy:           ' || P_AMTTAG_TBL(I).CCY);
      DEBUG.PR_DEBUG('BC',
                     'SPRING TIME sett_flag: ' || P_AMTTAG_TBL(I)
                     .SETTLEMENT_FLAG);
      DEBUG.PR_DEBUG('BC',
                     'SPRING TIME tag_type:  ' || P_AMTTAG_TBL(I).TAG_TYPE);
      DEBUG.PR_DEBUG('BC',
                     'SPRING TIME vdate:     ' || P_AMTTAG_TBL(I).VDATE);
      DEBUG.PR_DEBUG('BC',
                     '----------------Ends SPRING ----------------------');
    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Deleting rows in Amttag_tbl with tag_amt = 0');
    DEBUG.PR_DEBUG('BC',
                   'Deleting rows in Amttag_tbl with tag_amt = 0 for event code = ' ||
                   P_EVENT_CODE);
    L_TEMPTAG_TBL.DELETE;
    J := 0;

    IF P_AMTTAG_TBL.COUNT > 0 THEN

      FOR I IN P_AMTTAG_TBL.FIRST .. P_AMTTAG_TBL.LAST LOOP

        IF (P_AMTTAG_TBL(I).AMT > 0 OR P_EVENT_CODE = 'STCH') THEN
          DEBUG.PR_DEBUG('BC',
                         'Inside If Statement with p_amttag_tbl(i).amt :' || P_AMTTAG_TBL(I).AMT);
          DEBUG.PR_DEBUG('BC',
                         'Inside If Statement with p_event_code :' ||
                         P_EVENT_CODE);
          J := J + 1;
          L_TEMPTAG_TBL(J) := P_AMTTAG_TBL(I);

        ELSIF (P_AMTTAG_TBL(I)
              .AMT < 0 AND

               ((P_AMTTAG_TBL(I).TAG IN ('BILL_AMND_AMT', 'BILL_AMND_AMTEQ')) OR

               (INSTR(P_AMTTAG_TBL(I).TAG, '_ACPP') > 1) OR
               (INSTR(P_AMTTAG_TBL(I).TAG, '_RADJ') > 1))

              ) THEN
          DEBUG.PR_DEBUG('BC',
                         'Inside If Statement with p_amttag_tbl(i).amt :' || P_AMTTAG_TBL(I).AMT);
          DEBUG.PR_DEBUG('BC',
                         'Inside If Statement with p_amttag_tbl(i).tag  :' || P_AMTTAG_TBL(I).TAG);
          DEBUG.PR_DEBUG('BC',
                         'Adding amt tag = ' || P_AMTTAG_TBL(I).TAG ||
                         ', amt = ' || P_AMTTAG_TBL(I).AMT);
          J := J + 1;
          L_TEMPTAG_TBL(J) := P_AMTTAG_TBL(I);
        END IF;

      END LOOP;

      IF J > 0 THEN
        P_AMTTAG_TBL.DELETE;
        P_AMTTAG_TBL := L_TEMPTAG_TBL;
      END IF;
    END IF;

    IF P_AMTTAG_TBL.COUNT = 0 THEN
      P_ERR_CODE   := 'BC-AT006';
      P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~' || P_EVENT_CODE || '~';

      DEBUG.PR_DEBUG('BC', 'Nothing in Amttag_tbl to pass for acc_entries');
      DEBUG.PR_DEBUG('BC',
                     'Exiting BCPKSS_ACC_ENTRIES.fn_pass_acc_entries');
      RETURN TRUE;
    END IF;

    DEBUG.PR_DEBUG('BC',
                   'Printing amttag tbl before building intermed..tbl');
    DEBUG.PR_DEBUG('BC',
                   'No of rows in Amttag_tbl - ' || P_AMTTAG_TBL.COUNT);
    FOR I IN 1 .. P_AMTTAG_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC', 'tag:           ' || P_AMTTAG_TBL(I).TAG);
      DEBUG.PR_DEBUG('BC', 'amt:           ' || P_AMTTAG_TBL(I).AMT);
      DEBUG.PR_DEBUG('BC', 'ccy:           ' || P_AMTTAG_TBL(I).CCY);
      DEBUG.PR_DEBUG('BC',
                     'sett_flag: ' || P_AMTTAG_TBL(I).SETTLEMENT_FLAG);
      DEBUG.PR_DEBUG('BC', 'tag_type:  ' || P_AMTTAG_TBL(I).TAG_TYPE);
      DEBUG.PR_DEBUG('BC', 'vdate:     ' || P_AMTTAG_TBL(I).VDATE);
      DEBUG.PR_DEBUG('BC', '--------------------------------------');
    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Building INTERMEDIATE tbl');

    IF NOT FN_BUILD_MID_TBL(P_BCREFNO,
                            P_MODULE,
                            INTERMEDIATE_TBL,
                            P_AMTTAG_TBL,
                            P_ACC_LOOKUP_TBL,
                            L_TAG_LST,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DEBUG.PR_DEBUG('BC', 'fn_pass_acc_entries build mid tbl FAILED');
      DEBUG.PR_DEBUG('BC', P_ERR_CODE || '-' || SQLERRM);
      RAISE PROCESS_FAILED;
    END IF;

    IF NOT FN_ASSIGN_VDATE(P_BCREFNO, P_ESN, P_EVENT_CODE, INTERMEDIATE_TBL) THEN
      DEBUG.PR_DEBUG('BC', 'FN_ASSIGN_VDATE FAILED' || '-' || SQLERRM);
      RAISE PROCESS_FAILED;
    END IF;

    DEBUG.PR_DEBUG('BC', 'Checking if Intermediate tbl has any rows');

    IF INTERMEDIATE_TBL.COUNT = 0 THEN
      DEBUG.PR_DEBUG('BC',
                     'Intermediate tbl has 0 rows. Exiting acc_entries');
      RETURN TRUE;
    END IF;

    DEBUG.PR_DEBUG('BC',
                   'Printing the built INTERMEDIATE tbl before processing');

    DEBUG.PR_DEBUG('BC', 'Printing only TAG  and ACCROLE');

    DEBUG.PR_DEBUG('BC',
                   'Tbl Index' || ' - ' || 'Amttag' || ' - ' || 'Acc_role');

    FOR I IN 1 .. INTERMEDIATE_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC',
                     I || ' - ' || INTERMEDIATE_TBL(I).AMT_TAG || ' - ' || INTERMEDIATE_TBL(I)
                     .ACCROLE);

      IF INTERMEDIATE_TBL(I).GLCAT = 'X' THEN

        DEBUG.PR_DEBUG('BC', '#25665835 p_bcrefno  ' || P_BCREFNO);
        DEBUG.PR_DEBUG('BC', '#25665835 p_event_code  ' || P_EVENT_CODE);
        DEBUG.PR_DEBUG('BC',
                       '#25665835 intermediate_tbl(i).amt_tag  ' || INTERMEDIATE_TBL(I)
                       .AMT_TAG);
        DEBUG.PR_DEBUG('BC', '#25665835 p_esn  ' || P_ESN);
        BEGIN
          SELECT NVL(NETTING_INDICATOR, 'N')
            INTO L_NETTING_INDICATOR
            FROM ISTBS_CONTRACTIS
           WHERE CONTRACT_REF_NO = P_BCREFNO
             AND AMOUNT_TAG = INTERMEDIATE_TBL(I).AMT_TAG

             AND EVENT_SEQ_NO = P_ESN;
          DEBUG.PR_DEBUG('BC',
                         '#25665835 l_netting_indicator  ' ||
                         L_NETTING_INDICATOR);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('BC',
                           '#25665835 Failed in fetching  the netting indiactor');

        END;

        DEBUG.PR_DEBUG('BC',
                       '#25665835 Netting Ind' || L_NETTING_INDICATOR ||
                       'amt_tag   >>' || INTERMEDIATE_TBL(I).AMT_TAG ||
                       'p_event_code' || P_EVENT_CODE);

        INTERMEDIATE_TBL(I).NETIND := NVL(L_NETTING_INDICATOR,

                                          INTERMEDIATE_TBL(I).NETIND);

        DEBUG.PR_DEBUG('BC',
                       '#25665835 intermediate_tbl(i).netind  ' || INTERMEDIATE_TBL(I)
                       .NETIND);

      END IF;

    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Printing the complete table before processing');

    DEBUG.PR_DEBUG('BC',
                   'tbl_index-amttag-accrole-acc_br-account-' ||
                   'acc_ccy-drcrind-netind-trncode-glcat-tag_type-tag_ccy-tag_amt-' ||
                   'fcy_amt-exchrate-lcy_amt-instr_code-vdate-tag_sett_rate-' ||
                   'sett_flag-tag_index');

    DEBUG.PR_DEBUG('BC', '------------------------------');

    FOR I IN 1 .. INTERMEDIATE_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC',
                     I || '-' || INTERMEDIATE_TBL(I).AMT_TAG || '-' || INTERMEDIATE_TBL(I)
                     .ACCROLE || '-' || INTERMEDIATE_TBL(I).ACC_BRANCH || '-' || INTERMEDIATE_TBL(I)
                     .ACCOUNT || '-' || INTERMEDIATE_TBL(I).ACC_CCY || '-' || INTERMEDIATE_TBL(I)
                     .DRCRIND || '-' || INTERMEDIATE_TBL(I).NETIND || '-' || INTERMEDIATE_TBL(I)
                     .TRNCODE || '-' || INTERMEDIATE_TBL(I).GLCAT || '-' || INTERMEDIATE_TBL(I)
                     .TAGTYPE || '-' || INTERMEDIATE_TBL(I).TAG_CCY || '-' || INTERMEDIATE_TBL(I)
                     .TAG_AMT || '-' || INTERMEDIATE_TBL(I).FCY_AMT || '-' || INTERMEDIATE_TBL(I)
                     .EXCH_RATE || '-' || INTERMEDIATE_TBL(I).LCY_AMT || '-' || INTERMEDIATE_TBL(I)
                     .INSTRUMENT_CODE || '-' || INTERMEDIATE_TBL(I).VDATE || '-' || INTERMEDIATE_TBL(I)
                     .TAG_SETTLEMENT_RATE || '-' || INTERMEDIATE_TBL(I)
                     .SETTLEMENT_FLAG || '-' || INTERMEDIATE_TBL(I)
                     .TAG_INDEX);
    END LOOP;
    DEBUG.PR_DEBUG('BC', 'Processing mid tbl for UI acct types');

    IF L_TAG_LST IS NOT NULL THEN

      DEBUG.PR_DEBUG('BC', 'Calling fn_settlement_updates_tmp');

      IF NOT FN_SETTLEMENT_UPDATES_TMP(P_BCREFNO,
                                       P_ESN,
                                       INTERMEDIATE_TBL,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'fn_settlement_update_tmp FAILED');
        DEBUG.PR_DEBUG('BC', P_ERR_CODE || '-' || SQLERRM);
        RAISE PROCESS_FAILED;
      END IF;

      DEBUG.PR_DEBUG('BC', 'fn_settlement_update_tmp PASSED');

      DEBUG.PR_DEBUG('BC', 'Processing mid tbl for UI acct types');

      IF NOT FN_PROCESS_TBL_FOR_UI_ACCTS(P_BCREFNO,
                                         P_ESN,
                                         P_MODULE,
                                         P_REPLICATE,
                                         L_TAG_LST,
                                         INTERMEDIATE_TBL,
                                         P_AMTTAG_TBL,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'fn_pass_acc_entries process ui accts FAILED');
        DEBUG.PR_DEBUG('BC', P_ERR_CODE || '-' || SQLERRM);
        RAISE PROCESS_FAILED;
      END IF;
      DEBUG.PR_DEBUG('BC', 'fn_process_tbl_for_ui_accts PASSED');
    ELSE
      DEBUG.PR_DEBUG('BC',
                     'No X type tags to call fn_process..for_ui_accts');
    END IF;

    IF L_TAG_LST IS NOT NULL THEN
      DEBUG.PR_DEBUG('BC',
                     'Printing INTERMEDIATE_TBL after processing ' ||
                     'for UI accts');

      DEBUG.PR_DEBUG('BC',
                     'tbl_index-amttag-accrole-acc_br-account-' ||
                     'acc_ccy-drcrind-netind-trncode-glcat-tag_type-tag_ccy-tag_amt-' ||
                     'fcy_amt-exchrate-lcy_amt-instr_code-vdate-tag_sett_rate-' ||
                     'sett_flag-tag_index');

      DEBUG.PR_DEBUG('BC', '------------------------------');

      FOR I IN 1 .. INTERMEDIATE_TBL.COUNT LOOP
        DEBUG.PR_DEBUG('BC',
                       I || '-' || INTERMEDIATE_TBL(I).AMT_TAG || '-' || INTERMEDIATE_TBL(I)
                       .ACCROLE || '-' || INTERMEDIATE_TBL(I).ACC_BRANCH || '-' || INTERMEDIATE_TBL(I)
                       .ACCOUNT || '-' || INTERMEDIATE_TBL(I).ACC_CCY || '-' || INTERMEDIATE_TBL(I)
                       .DRCRIND || '-' || INTERMEDIATE_TBL(I).NETIND || '-' || INTERMEDIATE_TBL(I)
                       .TRNCODE || '-' || INTERMEDIATE_TBL(I).GLCAT || '-' || INTERMEDIATE_TBL(I)
                       .TAGTYPE || '-' || INTERMEDIATE_TBL(I).TAG_CCY || '-' || INTERMEDIATE_TBL(I)
                       .TAG_AMT || '-' || INTERMEDIATE_TBL(I).FCY_AMT || '-' || INTERMEDIATE_TBL(I)
                       .EXCH_RATE || '-' || INTERMEDIATE_TBL(I).LCY_AMT || '-' || INTERMEDIATE_TBL(I)
                       .INSTRUMENT_CODE || '-' || INTERMEDIATE_TBL(I).VDATE || '-' || INTERMEDIATE_TBL(I)
                       .TAG_SETTLEMENT_RATE || '-' || INTERMEDIATE_TBL(I)
                       .SETTLEMENT_FLAG || '-' || INTERMEDIATE_TBL(I)
                       .TAG_INDEX);
        DEBUG.PR_DEBUG('BC', '----------------');
      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('BC', 'Processing mid tbl for NUI acct types');

    IF NOT FN_PROCESS_TBL_FOR_NUI_ACCTS(P_BCREFNO,
                                        P_MODULE,
                                        P_EVENT_CODE,
                                        INTERMEDIATE_TBL,
                                        P_AMTTAG_TBL,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
      DEBUG.PR_DEBUG('BC', 'fn_pass_acc_entries process nui accts FAILED');
      DEBUG.PR_DEBUG('BC', P_ERR_CODE || '-' || SQLERRM);
      RAISE PROCESS_FAILED;
    END IF;

    DEBUG.PR_DEBUG('BC', 'fn_process_tbl_for_nui_accts PASSED');

    DEBUG.PR_DEBUG('BC',
                   'Printing INTERMEDIATE_TBL after processing ' ||
                   'for NUI accts');

    DEBUG.PR_DEBUG('BC',
                   'tbl_index-amttag-accrole-acc_br-account-' ||
                   'acc_ccy-drcrind-netind-trncode-glcat-tag_type-tag_ccy-tag_amt-' ||
                   'fcy_amt-exchrate-lcy_amt-instr_code-vdate-tag_sett_rate-' ||
                   'sett_flag-tag_index');

    DEBUG.PR_DEBUG('BC', '------------------------------');

    FOR I IN 1 .. INTERMEDIATE_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC',
                     I || '-' || INTERMEDIATE_TBL(I).AMT_TAG || '-' || INTERMEDIATE_TBL(I)
                     .ACCROLE || '-' || INTERMEDIATE_TBL(I).ACC_BRANCH || '-' || INTERMEDIATE_TBL(I)
                     .ACCOUNT || '-' || INTERMEDIATE_TBL(I).ACC_CCY || '-' || INTERMEDIATE_TBL(I)
                     .DRCRIND || '-' || INTERMEDIATE_TBL(I).NETIND || '-' || INTERMEDIATE_TBL(I)
                     .TRNCODE || '-' || INTERMEDIATE_TBL(I).GLCAT || '-' || INTERMEDIATE_TBL(I)
                     .TAGTYPE || '-' || INTERMEDIATE_TBL(I).TAG_CCY || '-' || INTERMEDIATE_TBL(I)
                     .TAG_AMT || '-' || INTERMEDIATE_TBL(I).FCY_AMT || '-' || INTERMEDIATE_TBL(I)
                     .EXCH_RATE || '-' || INTERMEDIATE_TBL(I).LCY_AMT || '-' || INTERMEDIATE_TBL(I)
                     .INSTRUMENT_CODE || '-' || INTERMEDIATE_TBL(I).VDATE || '-' || INTERMEDIATE_TBL(I)
                     .TAG_SETTLEMENT_RATE || '-' || INTERMEDIATE_TBL(I)
                     .SETTLEMENT_FLAG || '-' || INTERMEDIATE_TBL(I)
                     .TAG_INDEX);
    END LOOP;

    FOR I IN 1 .. INTERMEDIATE_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC', 'Tag Name - ' || INTERMEDIATE_TBL(I).AMT_TAG);
      DEBUG.PR_DEBUG('BC', 'Tag Type - ' || INTERMEDIATE_TBL(I).TAGTYPE);
      DEBUG.PR_DEBUG('BC', 'cHECKING dEFERRED - ');

      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM LDTBS_CONTRACT_LINKAGES
         WHERE CONTRACT_REF_NO = P_BCREFNO
           AND LINKAGE_TYPE = 'E'
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LDTBS_CONTRACT_LINKAGES
                 WHERE CONTRACT_REF_NO = P_BCREFNO);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('BC', 'IN WNDF MB0725 LDTBS_CONTRACT_LINKAGES');
          L_COUNT := 0;
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC',
                         'FAILED IN SELECTING FROM LDTBS_CONTRACT_LINKAGES: ' ||
                         SQLERRM);
      END;
      DEBUG.PR_DEBUG('BC', 'count in linkages :' || L_COUNT);

      IF NVL(INTERMEDIATE_TBL(I).TAGTYPE, '*') = 'E' OR
         NVL(INTERMEDIATE_TBL(I).TAGTYPE, '*') = 'R'

         OR (NVL(INTERMEDIATE_TBL(I).TAGTYPE, 'Z') = 'H' AND L_COUNT <> 0)

       THEN
        IF INTERMEDIATE_TBL(I).TAG_CCY != GLOBAL.LCY THEN

          DEBUG.PR_DEBUG('BC', 'amt_ccy != lcy');
          DEBUG.PR_DEBUG('BC',
                         'Processing Tag --->> ' || INTERMEDIATE_TBL(I)
                         .AMT_TAG);
          DEBUG.PR_DEBUG('BC',
                         ' Tag Amount --->> ' || INTERMEDIATE_TBL(I)
                         .TAG_AMT);

          IF NOT BCPKSS_UTILS.FN_LCY_EQUIV(SUBSTR(P_BCREFNO, 4, 4),

                                           P_MODULE,

                                           INTERMEDIATE_TBL(I).TAG_AMT,
                                           INTERMEDIATE_TBL(I).TAG_CCY,
                                           'Y',
                                           L_RET_AMT,
                                           L_EXCH_RATE,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN
            IF P_ERR_CODE IS NULL THEN
              DEBUG.PR_DEBUG('BC', 'BCPKSS_UTILS.fn_lcy_equiv FAILED');
            END IF;
            DEBUG.PR_DEBUG('BC', 'fn_get_bcmodule_tags FAILED');
            RETURN FALSE;
          END IF;
          INTERMEDIATE_TBL(I).EXCH_RATE := L_EXCH_RATE;
          INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT;
          INTERMEDIATE_TBL(I).FCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
        ELSE
          INTERMEDIATE_TBL(I).EXCH_RATE := 1;
          INTERMEDIATE_TBL(I).LCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
          INTERMEDIATE_TBL(I).FCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
        END IF;
      END IF;
    END LOOP;
    
    --sampath commented starts
    /*IF NOT FN_AVG_LCY_EQ(INTERMEDIATE_TBL, P_BCREFNO, P_ESN) THEN
      DEBUG.PR_DEBUG('BC', 'LCY Averaging Function failed');
    END IF;*/
    --sampath commeneted ends

    BEGIN
      SELECT BRIDGE_GL
        INTO L_BRIDGE_GL
        FROM BCTMS_LOAN_PREFERENCE
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM BCTMS_LOAN_PREFERENCE
                              WHERE BCREFNO = P_BCREFNO);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('BC', 'Select from bctms_loan_preference failed');
        DEBUG.PR_DEBUG('BC', 'ORACLE ERROR is ' || SQLERRM);
    END;

    DEBUG.PR_DEBUG('BC', 'chking lquidate using collateral case');
    BEGIN
      SELECT NVL(LIQD_USING_COLLAT, 'N')
        INTO L_LIQD_USING_COLLAT
        FROM BCTB_CONTRACT_MASTER
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM BCTB_CONTRACT_MASTER
                              WHERE BCREFNO = P_BCREFNO);
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('BC', 'In Exception..');
        L_LIQD_USING_COLLAT := 'N';
    END;

    IF L_LIQD_USING_COLLAT = 'Y' THEN
      BEGIN
        SELECT EVENT_SEQ_NO
          INTO L_EVENT_SEQ_NO
          FROM CSTB_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO = P_BCREFNO
           AND EVENT_CODE = 'INIT';
        DEBUG.PR_DEBUG('BC', ' init event seq no >>' || L_EVENT_SEQ_NO);

      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC', 'Failed in selecing the event seq no');
      END;

      BEGIN
        SELECT AC_NO
          INTO L_COLLAT_ACCOUNT
          FROM ACVW_ALL_UN_AC_ENTRIES
         WHERE TRN_REF_NO = P_BCREFNO
           AND EVENT_SR_NO = L_EVENT_SEQ_NO
           AND EVENT = 'INIT'
           AND DRCR_IND = 'C'
           AND AC_BRANCH = SUBSTR(P_BCREFNO, 1, 3)
           AND AMOUNT_TAG IN ('COLL_AMT',
                              'CASH_COLL_AMT',
                              'COLL_AMTEQ',
                              'CASH_COLL_AMTEQ');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('BC', 'COLL_AMT is not maintained');
          BEGIN
            SELECT AC_NO
              INTO L_COLLAT_ACCOUNT
              FROM ACVW_ALL_UN_AC_ENTRIES
             WHERE TRN_REF_NO = P_BCREFNO
               AND EVENT_SR_NO = L_EVENT_SEQ_NO
               AND EVENT = 'INIT'
               AND DRCR_IND = 'C'
               AND AC_BRANCH = SUBSTR(P_BCREFNO, 1, 3)
               AND AMOUNT_TAG IN ('LC_COLL_TFR', 'LC_COLL_TFREQ');
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DEBUG.PR_DEBUG('BC', 'LC Collateral transfer not maintained');
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('BC',
                             'No split liquidate using collateral case');
          END;
      END;
    END IF;

    IF P_MODULE IN ('BC', 'IB') AND LBCTB_CONTRACT.OUR_LC_REF IS NOT NULL THEN
      DEBUG.PR_DEBUG('BC', 'inside BC');
      BEGIN
        SELECT COLLATERAL_TRANSFER_BRIDGE
          INTO L_COLLAT_BRIDGE
          FROM LCTM_PRODUCT_DEFINITION
         WHERE PRODUCT_CODE = SUBSTR(LBCTB_CONTRACT.OUR_LC_REF, 4, 4);
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC',
                         'select from  LCTM_PRODUCT_DEFINITION failed ' ||
                         SQLERRM);
          RETURN FALSE;
      END;
    ELSIF P_MODULE = 'LC' THEN
      BEGIN
        SELECT RELATED_REF_NO, EVENT_CODE
          INTO L_RELATED_REF_NO, L_EVENT_CODE
          FROM LCTB_AVAILMENTS
         WHERE CONTRACT_REF_NO = P_BCREFNO
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM LCTB_AVAILMENTS
                 WHERE CONTRACT_REF_NO = P_BCREFNO);
      EXCEPTION
        WHEN OTHERS THEN

          L_RELATED_REF_NO := NULL;
          L_EVENT_CODE     := NULL;
      END;
      DEBUG.PR_DEBUG('BC',
                     'inside LC - BC refno and event ' || P_BCREFNO || '~' ||
                     L_RELATED_REF_NO || '~' || L_EVENT_CODE);
      IF L_RELATED_REF_NO IS NOT NULL AND L_EVENT_CODE = 'AVAL' THEN
        BEGIN
          SELECT COLLATERAL_TRANSFER_BRIDGE
            INTO L_COLLAT_BRIDGE
            FROM LCTM_PRODUCT_DEFINITION
           WHERE PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('BC',
                           'select from  LCTM_PRODUCT_DEFINITION failed ' ||
                           SQLERRM);
            RETURN FALSE;
        END;
      ELSE

        L_COLLAT_BRIDGE := NULL;
      END IF;
    END IF;

    FOR I IN INTERMEDIATE_TBL.FIRST .. INTERMEDIATE_TBL.LAST LOOP
      DEBUG.PR_DEBUG('BC',
                     I || ' - ' || INTERMEDIATE_TBL(I).ACCROLE || ' - ' || INTERMEDIATE_TBL(I)
                     .ACCOUNT || ' - ' || INTERMEDIATE_TBL(I).AMT_TAG);
      DEBUG.PR_DEBUG('BC',
                     ' lbctb_contract.auto_liq_flag ---> ' ||
                     LBCTB_CONTRACT.AUTO_LIQ_FLAG);
      DEBUG.PR_DEBUG('BC',
                     ' lbctb_contract.bill_due_amt ---> ' ||
                     LBCTB_CONTRACT.BILL_DUE_AMT);
      DEBUG.PR_DEBUG('BC',
                     ' lbctb_contract.advance_by_loan ---> ' ||
                     LBCTB_CONTRACT.ADVANCE_BY_LOAN);
      DEBUG.PR_DEBUG('BC',
                     'intermediate_tbl(i).accrole ---> ' || INTERMEDIATE_TBL(I)
                     .ACCROLE);
      DEBUG.PR_DEBUG('BC',
                     'intermediate_tbl(i).amttag ---> ' || INTERMEDIATE_TBL(I)
                     .AMT_TAG);
      IF L_EOD = 'N' AND L_LIQD_AMT <> 0 THEN

        IF NVL(L_ADV_BY_LOAN, 'N') = 'Y' AND
           P_EVENT_CODE IN ('LIQD', 'CRST') THEN
          IF INTERMEDIATE_TBL(I).ACCROLE = 'BC CUSTOMER' AND INTERMEDIATE_TBL(I)
             .AMT_TAG IN ('BILL_AMOUNT',
                          'BILL_LIQ_AMT',
                          'BILL_AMT_EQUIV',
                          'BILL_LIQ_AMTEQ') THEN
            IF L_BRIDGE_GL IS NOT NULL THEN
              DEBUG.PR_DEBUG('BC', 'l_bridge_gl ===> ' || L_BRIDGE_GL);
              INTERMEDIATE_TBL(I).ACCOUNT := L_BRIDGE_GL;
              INTERMEDIATE_TBL(I).ACC_CCY := GLOBAL.LCY;
            ELSE
              P_ERR_CODE := 'BC-LD004';
              DEBUG.PR_DEBUG('BC',
                             'Bridge Gl cannot be null when advance by loan is checked');
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'intermediate_tbl(i).accrole::' || INTERMEDIATE_TBL(I)
                     .ACCROLE);

      BEGIN
        SELECT ROLE_TYPE
          INTO L_ROLETYPE
          FROM CSTMS_PRODUCT_EVENT_ACCT_ENTRY
         WHERE EVENT_CODE = 'LIQD'
           AND AMT_TAG = 'BILL_LIQ_AMT'
           AND ACCOUNT_ROLE_CODE = INTERMEDIATE_TBL(I).ACCROLE
           AND PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4);
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC', 'In When others');
          L_ROLETYPE := 'X';
      END;

      DEBUG.PR_DEBUG('BC', 'p_module::' || P_MODULE);
      DEBUG.PR_DEBUG('BC', 'p_event_code::' || P_EVENT_CODE);
      DEBUG.PR_DEBUG('BC',
                     'intermediate_tbl(i).amt_tag::' || INTERMEDIATE_TBL(I)
                     .AMT_TAG);
      DEBUG.PR_DEBUG('BC',
                     'intermediate_tbl(i).drcrind::' || INTERMEDIATE_TBL(I)
                     .DRCRIND);
      DEBUG.PR_DEBUG('BC', 'l_bill_due_amt::' || L_BILL_DUE_AMT);
      DEBUG.PR_DEBUG('BC', 'l_liqd_using_collat::' || L_LIQD_USING_COLLAT);
      DEBUG.PR_DEBUG('BC', 'l_collat_account::' || L_COLLAT_ACCOUNT);
      DEBUG.PR_DEBUG('BC', 'l_roletype::' || L_ROLETYPE);

      IF P_MODULE IN ('BC', 'IB') AND P_EVENT_CODE = 'LIQD' AND INTERMEDIATE_TBL(I)
        .AMT_TAG = 'BILL_LIQ_AMT' AND INTERMEDIATE_TBL(I).DRCRIND = 'D' AND
         L_BILL_DUE_AMT = 0 AND L_LIQD_USING_COLLAT = 'Y' AND
         L_COLLAT_ACCOUNT IS NOT NULL AND L_ROLETYPE = 'X' THEN
        INTERMEDIATE_TBL(I).ACCOUNT := L_COLLAT_ACCOUNT;
        DEBUG.PR_DEBUG('BC', ' collat_account is >> ' || L_COLLAT_ACCOUNT);
      END IF;

      IF INTERMEDIATE_TBL(I)
       .ACCROLE = 'LC_BC_COLL_BRIDGE' AND L_COLLAT_BRIDGE IS NOT NULL THEN
        DEBUG.PR_DEBUG('BC',
                       'inside lc bc col' || P_MODULE || '~' ||
                       LBCTB_CONTRACT.OUR_LC_REF || '~' || P_BCREFNO);

        DEBUG.PR_DEBUG('BC',
                       'Bridge GL got is ' || INTERMEDIATE_TBL(I).ACCROLE || '~' ||
                       L_COLLAT_BRIDGE);

        INTERMEDIATE_TBL(I).ACCOUNT := L_COLLAT_BRIDGE;
      END IF;
    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Printing mid table after calling fn_avg_lcy');
    DEBUG.PR_DEBUG('BC',
                   ' TAG    --  FCY AMT  --  LCY AMT  --  EXCH RATE ');
    FOR I IN 1 .. INTERMEDIATE_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC',
                     INTERMEDIATE_TBL(I)
                     .AMT_TAG || ' --- ' || INTERMEDIATE_TBL(I).FCY_AMT ||
                      ' --- ' || INTERMEDIATE_TBL(I).LCY_AMT || ' --- ' || INTERMEDIATE_TBL(I)
                     .EXCH_RATE);
    END LOOP;

    IF LBCTB_CONTRACT.ADVANCE_BY_LOAN = 'Y' AND P_EVENT_CODE = 'CRST' THEN
      IF NOT FN_LC_CHARGES_TRANSFER(LBCTB_CONTRACT,
                                    P_EVENT_CODE,
                                    INTERMEDIATE_TBL,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'Some problem in fn_lc_charges_transfer');
        RETURN FALSE;
      END IF;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      L_FN_CALL_ID      := 1;
      IF NOT
          BCPKS_ACC_ENTRIES_CLUSTER.FN_PASS_ACC_ENTRIES(P_BCREFNO,
                                                        P_EVENT_CODE,
                                                        P_ESN,
                                                        P_REPLICATE,
                                                        P_USER_DEFINED_STATUS,
                                                        P_MODULE,
                                                        P_PROCESS_CHARGES,
                                                        P_PROCESS_TAX,
                                                        P_ACC_LOOKUP_REQ,
                                                        P_ACTION_CODE,
                                                        P_SUSPENCE,
                                                        P_ACC_LOOKUP_TBL,
                                                        P_AMTTAG_TBL,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS,
                                                        'N',
                                                        INTERMEDIATE_TBL,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('BC',
                       'bcpks_acc_entries_cluster.fn_pass_acc_entries Failed with' ||
                       SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF NOT FN_BUILD_ACC_HANDOFF_TBL(P_BCREFNO,
                                      P_ESN,
                                      P_EVENT_CODE,
                                      P_MODULE,
                                      INTERMEDIATE_TBL,
                                      ACC_HANDOFF_TBL,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'fn_build_acc_hoff_tbl FAILED');
        RAISE PROCESS_FAILED;
      END IF;
    END IF;

    DEBUG.PR_DEBUG('BC', 'After building acc_hoff_tbl');

    IF ACC_HANDOFF_TBL.COUNT = 0 THEN
      DEBUG.PR_DEBUG('BC',
                     'Acc_handoff_tbl is EMPTY. Nothing to pass for
                            accounting entries');
      RETURN TRUE;
    END IF;

    DEBUG.PR_DEBUG('BC', 'Deleting rows with lcy_amt = 0');

    TMP_HANDOFF_TBL.DELETE;

    FOR IC IN 1 .. ACC_HANDOFF_TBL.LAST LOOP
      DEBUG.PR_DEBUG('BC',
                     'DAN->LOOP->lcy amount = ' || ACC_HANDOFF_TBL(IC)
                     .LCY_AMOUNT);
      IF NVL(ACC_HANDOFF_TBL(IC).LCY_AMOUNT, 0) <> 0 THEN
        DEBUG.PR_DEBUG('BC',
                       'Adding Tag ' || ACC_HANDOFF_TBL(IC).AMOUNT_TAG);
        TMP_HANDOFF_TBL(NVL(TMP_HANDOFF_TBL.LAST, 0) + 1) := ACC_HANDOFF_TBL(IC);
      END IF;
    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Printing amt tags in acc_handoff tbl');

    IF TMP_HANDOFF_TBL.COUNT = 0 THEN
      DEBUG.PR_DEBUG('BC',
                     'Acc_handoff_tbl is EMPTY. Nothing to pass for
                            accounting entries');
      RETURN TRUE;
    END IF;

    FOR IC IN 1 .. TMP_HANDOFF_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC', TMP_HANDOFF_TBL(IC).AMOUNT_TAG);
    END LOOP;

    ACC_HANDOFF_TBL.DELETE;
    ACC_HANDOFF_TBL := TMP_HANDOFF_TBL;

    DEBUG.PR_DEBUG('BC', 'Printing acc_handoff tbl before handing off');

    DEBUG.PR_DEBUG('BC',
                   'Tbl_index-refno-esn-event-acc_br-' ||
                   'acc_no-acc_ccy-drcrind-trncode-lcyamt-fcyamt-rate-' ||
                   'nett_ind-trndate-vdate-userid-module');

    FOR I IN 1 .. ACC_HANDOFF_TBL.COUNT LOOP
      IF ACC_HANDOFF_TBL(I).AC_CCY = GLOBAL.LCY THEN
        ACC_HANDOFF_TBL(I).FCY_AMOUNT := NULL;
        ACC_HANDOFF_TBL(I).EXCH_RATE := NULL;
      END IF;

      IF ACC_HANDOFF_TBL(I)
       .DRCR_IND = 'D' AND ACC_HANDOFF_TBL(I).CUST_GL = 'A' THEN

        IF NOT L_CHQ_UPDATED THEN
          BEGIN
            SELECT *
              INTO L_BCTB_CONTRACT
              FROM BCTBS_CONTRACT_MASTER
             WHERE BCREFNO = ACC_HANDOFF_TBL(I).TRN_REF_NO
               AND EVENT_SEQ_NO = ACC_HANDOFF_TBL(I).EVENT_SR_NO
               AND ROWNUM = 1;
          EXCEPTION
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('BC',
                             'ORACLE ERROR in l_chq_updated SELECT : ' ||
                             SQLERRM);

          END;
          IF L_BCTB_CONTRACT.CHECK_NUMBER IS NOT NULL THEN
            BEGIN
              SELECT A.ACC_BRANCH, A.ACCOUNT, A.SETTLEMENT_AMT
                INTO L_AC_BRANCH, L_AC_NO, L_AMT
                FROM ISTBS_CONTRACTIS    A,
                     STTBS_ACCOUNT       B,
                     CATMS_CHECK_DETAILS C
               WHERE A.CONTRACT_REF_NO = ACC_HANDOFF_TBL(I).TRN_REF_NO
                 AND A.EVENT_SEQ_NO = ACC_HANDOFF_TBL(I).EVENT_SR_NO
                 AND A.PAY_RECEIVE = 'R'
                 AND B.CUST_NO = L_BCTB_CONTRACT.CUSTOMER_ID
                 AND A.ACC_BRANCH = ACC_HANDOFF_TBL(I).AC_BRANCH
                 AND A.ACCOUNT = ACC_HANDOFF_TBL(I).AC_NO
                 AND ACC_HANDOFF_TBL(I).DRCR_IND = 'D'
                 AND B.BRANCH_CODE = A.ACC_BRANCH
                 AND B.AC_GL_NO = A.ACCOUNT
                 AND C.BRANCH = B.BRANCH_CODE
                 AND C.ACCOUNT = B.AC_GL_NO
                 AND C.CHECK_NO = L_BCTB_CONTRACT.CHECK_NUMBER

                 AND ROWNUM = 1;

              ACC_HANDOFF_TBL(I).INSTRUMENT_CODE := L_BCTB_CONTRACT.CHECK_NUMBER;
              L_CHQ_UPDATED := TRUE;

            EXCEPTION
              WHEN OTHERS THEN
                DEBUG.PR_DEBUG('BC',
                               'ORACLE ERROR in FN_chq_no : ' || SQLERRM);
                DEBUG.PR_DEBUG('BC',
                               'Check number a/c doesn not match with a/c handoff');

            END;

          END IF;

        END IF;
      END IF;

      DEBUG.PR_DEBUG('BC',
                     ACC_HANDOFF_TBL(I)
                     .AMOUNT_TAG || '-' || ACC_HANDOFF_TBL(I).TRN_REF_NO || '-' || ACC_HANDOFF_TBL(I)
                     .EVENT_SR_NO || '-' || ACC_HANDOFF_TBL(I).EVENT || '-' || ACC_HANDOFF_TBL(I)
                     .AC_BRANCH || '-' || ACC_HANDOFF_TBL(I).AC_NO || '-' || ACC_HANDOFF_TBL(I)
                     .AC_CCY || '-' || ACC_HANDOFF_TBL(I).DRCR_IND || '-' || ACC_HANDOFF_TBL(I)
                     .TRN_CODE || '-' || ACC_HANDOFF_TBL(I).LCY_AMOUNT || '-' || ACC_HANDOFF_TBL(I)
                     .FCY_AMOUNT || '-' || ACC_HANDOFF_TBL(I).EXCH_RATE || '-' || ACC_HANDOFF_TBL(I)
                     .NETTING_IND || '-' || ACC_HANDOFF_TBL(I).TRN_DT || '-' || ACC_HANDOFF_TBL(I)
                     .VALUE_DT || '-' || ACC_HANDOFF_TBL(I).USER_ID || '-' || ACC_HANDOFF_TBL(I)
                     .MODULE);
    END LOOP;

    IF L_BCTB_CONTRACT.CHECK_NUMBER IS NOT NULL AND NOT L_CHQ_UPDATED THEN
      DEBUG.PR_DEBUG('BC',
                     'Check number a/c doesn not match with a/c handoff');
      P_ERR_CODE   := 'BC-CHK01';
      P_ERR_PARAMS := P_BCREFNO || '~' || L_BCTB_CONTRACT.CHECK_NUMBER || '~';
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('BC', 'Calling ACPKSS.fn_achandoff');

    IF NOT ACPKSS.FN_ACHANDOFF(P_BCREFNO,
                               P_ESN,
                               GLOBAL.APPLICATION_DATE,
                               ACC_HANDOFF_TBL,
                               P_ACTION_CODE,
                               P_SUSPENCE,
                               'Y',
                               GLOBAL.USER_ID,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
      DEBUG.PR_DEBUG('BC', 'ACPKSS.fn_achandoff FAILED' || SQLERRM);
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT007';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~' || P_EVENT_CODE || '~';
      END IF;
      RAISE PROCESS_FAILED;
    END IF;

    DEBUG.PR_DEBUG('BC', 'After acc_handoff');

    IF P_MODULE IN ('BC', 'IB') AND SUBSTR(P_EVENT_CODE, 1, 1) = 'L' THEN
      BEGIN
        SELECT CHECK_NUMBER, NVL(BILL_AMT_LIQD, 0)
          INTO L_CHECK_NUMBER, L_LIQ_AMT
          FROM BCTBS_CONTRACT_MASTER
         WHERE BCREFNO = P_BCREFNO
           AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                                 FROM BCTBS_CONTRACT_MASTER
                                WHERE BCREFNO = P_BCREFNO
                                  AND EVENT_SEQ_NO <= P_ESN);
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC',
                         'Failed to get the check number from bctbs_contract_master with : ' ||
                         SQLERRM);
          RAISE PROCESS_FAILED;
      END;
      DEBUG.PR_DEBUG('BC', 'About to update the check status ');
      IF L_CHECK_NUMBER IS NOT NULL AND L_LIQ_AMT <> 0 THEN
        DEBUG.PR_DEBUG('BC', 'Check number present : ' || L_CHECK_NUMBER);
        FOR I IN 1 .. ACC_HANDOFF_TBL.COUNT LOOP
          IF ACC_HANDOFF_TBL(I)
           .AMOUNT_TAG IN ('BILL_LIQ_AMT', 'BILL_LIQ_AMTEQ') AND ACC_HANDOFF_TBL(I)
             .DRCR_IND = 'D' THEN
            L_CHK_ACCOUNT := ACC_HANDOFF_TBL(I).AC_NO;
            L_ACC_BRANCH  := ACC_HANDOFF_TBL(I).AC_BRANCH;
            DEBUG.PR_DEBUG('BC',
                           'The account no. for check updation is : ' ||
                           L_CHK_ACCOUNT);
            BEGIN
              SELECT AC_OR_GL
                INTO L_AC_OR_GL
                FROM STTBS_ACCOUNT
               WHERE AC_GL_NO = L_CHK_ACCOUNT
                 AND NVL(BRANCH_CODE, L_ACC_BRANCH) = L_ACC_BRANCH;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DEBUG.PR_DEBUG('BC', 'We can assume this is a GL');
                L_AC_OR_GL := 'G';
              WHEN OTHERS THEN
                DEBUG.PR_DEBUG('BC',
                               'The account details not found. Sorry ' ||
                               SQLERRM);
                RAISE PROCESS_FAILED;
            END;
            DEBUG.PR_DEBUG('BC', 'A/c or GL is : ' || L_AC_OR_GL);
            IF L_AC_OR_GL = 'A' THEN
              EXIT;
            ELSE
              L_CHK_ACCOUNT := NULL;
            END IF;
          END IF;
        END LOOP;
        DEBUG.PR_DEBUG('BC',
                       'The account no. for check updation is : ' ||
                       L_CHK_ACCOUNT);
        IF L_CHK_ACCOUNT IS NOT NULL THEN
          L_CHECK_STATUS := CASAPKSS.FN_GET_CHECK_STATUS(L_ACC_BRANCH,
                                                         GLOBAL.APPLICATION_DATE,
                                                         L_CHK_ACCOUNT,
                                                         'Y',
                                                         L_CHECK_NUMBER,
                                                         'Y',
                                                         GLOBAL.USER_ID,
                                                         P_BCREFNO,
                                                         L_LIQ_AMT);
          DEBUG.PR_DEBUG('BC', 'The check status is : ' || L_CHECK_STATUS);
          IF SUBSTR(L_CHECK_STATUS, 1, 1) = 'M' THEN
            P_ERR_CODE   := 'CS-CLG016';
            P_ERR_PARAMS := NULL;
            RAISE PROCESS_FAILED;
          ELSIF SUBSTR(L_CHECK_STATUS, 1, 1) = 'S' THEN
            P_ERR_CODE   := 'CA-00109';
            P_ERR_PARAMS := NULL;
            RAISE PROCESS_FAILED;
          ELSIF L_CHECK_STATUS = 'CA-CKUSED' THEN

            P_ERR_CODE := 'CA-CKUSED';

            P_ERR_PARAMS := NULL;
            RAISE PROCESS_FAILED;

          ELSIF L_CHECK_STATUS = 'CA-03000' THEN
            P_ERR_CODE   := 'CA-03000';
            P_ERR_PARAMS := NULL;
            RAISE PROCESS_FAILED;

          END IF;
        ELSE
          DEBUG.PR_DEBUG('BC',
                         'Attention!!!! The check account not found......');
        END IF;
      END IF;
    END IF;

    IF P_MODULE IN ('BC', 'IB')

     THEN
      DEBUG.PR_DEBUG('BC', 'Doing Brokerage updates after acc_entries');
      BEGIN
        SELECT *
          INTO L_BCTB_CONTRACT
          FROM BCTBS_CONTRACT_MASTER
         WHERE BCREFNO = P_BCREFNO
           AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                                 FROM BCTB_CONTRACT_MASTER
                                WHERE BCREFNO = P_BCREFNO);
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('BC',
                         'ORACLE ERROR in l_chq_updated SELECT : ' ||
                         SQLERRM);

      END;
      DEBUG.PR_DEBUG('BC',
                     'Allow Brokerage is : ' ||
                     L_BCTB_CONTRACT.ALLOW_BROKERAGE);
      DEBUG.PR_DEBUG('BC',
                     'Brokerage paid by us is : ' ||
                     L_BCTB_CONTRACT.BROK_PAID_BY_US);
      DEBUG.PR_DEBUG('BC',
                     'value_date is : ' || L_BCTB_CONTRACT.VALUE_DATE);

      DEBUG.PR_DEBUG('BC', 'p_event_code is : ' || P_EVENT_CODE);

      IF NVL(L_BCTB_CONTRACT.ALLOW_BROKERAGE, 'N') = 'Y' AND
         NVL(L_BCTB_CONTRACT.BROK_PAID_BY_US, 'N') = 'Y' THEN

        BEGIN
          SELECT AMT_TAG, ACCOUNT_ROLE_CODE
            INTO L_AMT_TAG, L_ACCOUNT_ROLE
            FROM CSTMS_PRODUCT_EVENT_ACCT_ENTRY
           WHERE PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4)
             AND EVENT_CODE = P_EVENT_CODE
             AND AMT_TAG LIKE 'BROK_LIQD%'

             AND ACCOUNT_ROLE_CODE NOT IN ('BC CUSTOMER', 'NOSTRO ACCOUNT');

          DEBUG.PR_DEBUG('BC', 'Record found setting l found to true');

          L_FOUND := TRUE;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('BC',
                           'Record not found setting l found to false');
            L_FOUND := FALSE;
          WHEN OTHERS THEN
            RETURN FALSE;
        END;

        IF L_FOUND THEN

          DEBUG.PR_DEBUG('BC', 'Inside l found');
          DEBUG.PR_DEBUG('BC', 'amt tag is ' || L_AMT_TAG);
          DEBUG.PR_DEBUG('BC', 'Role is ' || L_ACCOUNT_ROLE);

          FOR I IN 1 .. ACC_HANDOFF_TBL.COUNT LOOP
            DEBUG.PR_DEBUG('BC',
                           'Hoff tbl.amt tag is ' || ACC_HANDOFF_TBL(I)
                           .AMOUNT_TAG);

            IF INSTR(ACC_HANDOFF_TBL(I).AMOUNT_TAG, L_AMT_TAG) > 0 THEN

              IF L_ACCOUNT_ROLE <> 'BROKPAY' THEN
                DEBUG.PR_DEBUG('BC',
                               'Updating the table BCTB_BROK_DETAIL..');

                UPDATE BCTBS_BROK_DETAIL
                   SET LIQ_STATUS = 1
                 WHERE BCREFNO = P_BCREFNO
                   AND EVENT_SEQ_NO = L_BCTB_CONTRACT.EVENT_SEQ_NO;

              END IF;
            END IF;
          END LOOP;

        END IF;

      END IF;
    END IF;

    IF P_PROCESS_TAX = 'Y' THEN
      DEBUG.PR_DEBUG('BC', 'Doing tax updates after acc_entries');
      IF NOT TAPKSS_NEW.FN_STATUS_UPDATE(P_BCREFNO,
                                         P_ESN,
                                         NULL,
                                         GLOBAL.APPLICATION_DATE,
                                         'L') THEN
        P_ERR_CODE   := 'BC-AT008';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~' || P_EVENT_CODE || '~';

        DEBUG.PR_DEBUG('BC',
                       'TAPKSS_NEW.fn_status_update BOMBED-' || SQLERRM);
        RAISE PROCESS_FAILED;
      END IF;
      DEBUG.PR_DEBUG('BC', 'TAPKSS_NEW.fn_status_update PASSED');
    END IF;

    DEBUG.PR_DEBUG('BC', 'Doing Settlement updates after acc_entries');

    IF NOT FN_SETTLEMENT_UPDATES(P_BCREFNO,
                                 P_ESN,
                                 INTERMEDIATE_TBL,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      DEBUG.PR_DEBUG('BC', 'fn_settlement_update FAILED');
      DEBUG.PR_DEBUG('BC', P_ERR_CODE || '-' || SQLERRM);
      RAISE PROCESS_FAILED;
    END IF;
    DEBUG.PR_DEBUG('BC', 'fn_settlement_update PASSED');

    IF P_MODULE IN ('BC', 'IB') THEN

      IF NOT BCPKSS_ACC_ENTRIES.FN_INS_CHARGES(P_BCREFNO,
                                               P_ESN,
                                               INTERMEDIATE_TBL,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('BC', 'fn_ins_charges FAILED');
        DEBUG.PR_DEBUG('BC', P_ERR_CODE || '-' || SQLERRM);
        RAISE PROCESS_FAILED;
      END IF;
      DEBUG.PR_DEBUG('BC', 'fn_ins_charges PASSED');
    END IF;

    DEBUG.PR_DEBUG('BC', 'BCPKSS_ACC_ENTRIES.fn_pass_acc_antries PASSED');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    RETURN TRUE;

  EXCEPTION
    WHEN PROCESS_FAILED THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT004';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~' || P_EVENT_CODE || '~';

      END IF;
      DEBUG.PR_DEBUG('BC', THIS_FN || ' FAILED' || SQLERRM);
      RETURN FALSE;

    WHEN OTHERS THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT004';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~' || P_EVENT_CODE || '~';

      END IF;
      DEBUG.PR_DEBUG('BC', THIS_FN || ' FAILED' || SQLERRM);
      RETURN FALSE;

  END FN_PASS_ACC_ENTRIES;

  FUNCTION FN_SORT_ACC_LOOKUP_TBL(P_ACC_LOOKUP_TBL IN OUT ACPKSS.TBL_LOOKUP,
                                  P_ERR_CODE       IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                  P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_TEMP_TBL ACPKSS.TBL_LOOKUP;
    J          BINARY_INTEGER := 0;

  BEGIN
    DEBUG.PR_DEBUG('BC', 'Inside fn_sort_acc_lookup_tbl');
    L_TEMP_TBL.DELETE;

    J := 0;

    FOR I IN P_ACC_LOOKUP_TBL.FIRST .. P_ACC_LOOKUP_TBL.LAST LOOP
      IF P_ACC_LOOKUP_TBL(I).ACCOUNT = 'USERINPUT' THEN
        J := J + 1;
        L_TEMP_TBL(J) := P_ACC_LOOKUP_TBL(I);
      END IF;
    END LOOP;

    J := NVL(L_TEMP_TBL.LAST, 0);

    FOR I IN P_ACC_LOOKUP_TBL.FIRST .. P_ACC_LOOKUP_TBL.LAST LOOP
      IF P_ACC_LOOKUP_TBL(I).ACCOUNT != 'USERINPUT' THEN
        J := J + 1;
        L_TEMP_TBL(J) := P_ACC_LOOKUP_TBL(I);
      END IF;
    END LOOP;

    P_ACC_LOOKUP_TBL.DELETE;

    P_ACC_LOOKUP_TBL := L_TEMP_TBL;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'fn_sort_acc_lookup_tbl FAILED: ' || SQLERRM);
      RETURN FALSE;

  END FN_SORT_ACC_LOOKUP_TBL;

  FUNCTION FN_SPLIT_CHECK(P_CONT_REF_NO    IN VARCHAR2,
                          P_EVENT_SEQ_NO   IN NUMBER,
                          P_AMT_TAG_LST    IN OUT VARCHAR2,
                          P_SETTLE_AMT_LST IN OUT VARCHAR2,
                          P_ERROR_CODE     OUT VARCHAR2) RETURN BOOLEAN IS

    L_AMT_TAG             VARCHAR2(1000);
    L_SETTEL_AMT          VARCHAR2(1000);
    L_AFTR_AMT_TAG_LST    VARCHAR2(1000) := '';
    L_AFTR_SETTLE_AMT_LST VARCHAR2(1000) := '';
    LO_ORG_EXCH_RATE      VARCHAR2(25);
    K                     NUMBER;
    L_SPLIT_COUNT         NUMBER;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside bcpks_acc_entries-->fn_split_check');
    DEBUG.PR_DEBUG('BC', 'p_amt_tag_lst ' || P_AMT_TAG_LST);
    DEBUG.PR_DEBUG('BC', 'p_settle_amt_lst ' || P_SETTLE_AMT_LST);
    K                     := 1;
    L_AMT_TAG             := CSPKES_MISC.FN_GETPARAM(P_AMT_TAG_LST, K, '~');
    L_SETTEL_AMT          := CSPKES_MISC.FN_GETPARAM(P_SETTLE_AMT_LST,
                                                     K,
                                                     '~');
    L_AFTR_AMT_TAG_LST    := P_AMT_TAG_LST;
    L_AFTR_SETTLE_AMT_LST := P_SETTLE_AMT_LST;

    WHILE L_AMT_TAG <> 'EOPL' LOOP
      DEBUG.PR_DEBUG('BC', 'l_amt_tag >> ' || L_AMT_TAG);
      SELECT COUNT(1)
        INTO L_SPLIT_COUNT
        FROM CSTBS_SPLIT_TAG_MASTER
       WHERE BASIS_AMOUNT_TAG = L_AMT_TAG
         AND BASIS_AMOUNT_TAG LIKE 'BROK%'
         AND EVENT_SEQ_NO = P_EVENT_SEQ_NO
         AND SPLIT_EVENT_CODE = 'LIQD'
         AND CONTRACT_REF_NO = P_CONT_REF_NO;
      DEBUG.PR_DEBUG('BC', 'l_split_count >> ' || L_SPLIT_COUNT);
      IF L_SPLIT_COUNT > 0 THEN
        SELECT COUNT(1)
          INTO L_SPLIT_COUNT
          FROM CSTBS_SPLIT_TAG_DETAIL
         WHERE BASIS_AMOUNT_TAG = L_AMT_TAG
           AND EVENT_SEQ_NO = P_EVENT_SEQ_NO
           AND CONTRACT_REF_NO = P_CONT_REF_NO;
        IF L_SPLIT_COUNT > 0 THEN
          L_SETTEL_AMT := 0;
        END IF;
      END IF;

      IF K = 1 THEN
        L_AFTR_AMT_TAG_LST    := L_AMT_TAG;
        L_AFTR_SETTLE_AMT_LST := L_SETTEL_AMT;
      ELSE
        L_AFTR_AMT_TAG_LST    := L_AFTR_AMT_TAG_LST || '~' || L_AMT_TAG;
        L_AFTR_SETTLE_AMT_LST := L_AFTR_SETTLE_AMT_LST || '~' ||
                                 L_SETTEL_AMT;
      END IF;
      K := K + 1;
      DEBUG.PR_DEBUG('BC', 'k = ' || K);
      L_AMT_TAG    := CSPKES_MISC.FN_GETPARAM(P_AMT_TAG_LST, K, '~');
      L_SETTEL_AMT := CSPKES_MISC.FN_GETPARAM(P_SETTLE_AMT_LST, K, '~');
    END LOOP;
    P_AMT_TAG_LST    := L_AFTR_AMT_TAG_LST;
    P_SETTLE_AMT_LST := L_AFTR_SETTLE_AMT_LST;
    DEBUG.PR_DEBUG('BC', 'p_amt_tag_lst >>> ' || P_AMT_TAG_LST);
    DEBUG.PR_DEBUG('BC', 'p_settle_amt_lst >>>' || P_SETTLE_AMT_LST);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'WOT in fn_split_check ' || SQLERRM);
      RETURN FALSE;
  END FN_SPLIT_CHECK;

  FUNCTION FN_UPDATE(P_CONT_REF_NO    IN VARCHAR2,
                     P_EVENT_SEQ_NO   IN NUMBER,
                     P_AMOUNT_TAGS    IN VARCHAR2,
                     P_ORG_EXCH_RATES IN VARCHAR2,
                     P_ERROR_CODE     OUT VARCHAR2) RETURN BOOLEAN IS

    LO_AMT_TAG       VARCHAR2(25);
    LO_ORG_EXCH_RATE VARCHAR2(25);
    K                NUMBER;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside bcpks_acc_entries-->fn_update');
    K                := 1;
    LO_AMT_TAG       := CSPKES_MISC.FN_GETPARAM(P_AMOUNT_TAGS, K, '~');
    LO_ORG_EXCH_RATE := CSPKES_MISC.FN_GETPARAM(P_ORG_EXCH_RATES, K, '~');
    WHILE LO_AMT_TAG <> 'EOPL' LOOP
      BEGIN
        DEBUG.PR_DEBUG('BC', LO_AMT_TAG);
        DEBUG.PR_DEBUG('BC', 'lo_org_exch_rate:' || LO_ORG_EXCH_RATE);
        UPDATE ISTBS_CONTRACTIS
           SET ORG_EXCH_RATE = LO_ORG_EXCH_RATE
         WHERE CONTRACT_REF_NO = P_CONT_REF_NO
           AND EVENT_SEQ_NO = P_EVENT_SEQ_NO
           AND AMOUNT_TAG = LO_AMT_TAG;
        DEBUG.PR_DEBUG('BC', 'Rows Updated = ' || SQL%ROWCOUNT);

      EXCEPTION
        WHEN OTHERS THEN

          DEBUG.PR_DEBUG('BC', 'updation bombed with err' || SQLERRM);
          P_ERROR_CODE := 'IS-UPD02';
          RETURN FALSE;
      END;
      K := K + 1;
      DEBUG.PR_DEBUG('BC', 'k = ' || K);
      LO_AMT_TAG       := CSPKES_MISC.FN_GETPARAM(P_AMOUNT_TAGS, K, '~');
      LO_ORG_EXCH_RATE := CSPKES_MISC.FN_GETPARAM(P_ORG_EXCH_RATES, K, '~');
      DEBUG.PR_DEBUG('BC', 'End Loop tag = ' || LO_AMT_TAG);
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN

      P_ERROR_CODE := 'IS-UPD01';
      DEBUG.PR_DEBUG('BC', SQLERRM);
      RETURN FALSE;
  END FN_UPDATE;

  FUNCTION FN_SETTLEMENT_UPDATES(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                                 P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                                 P_INTERMEDIATE_TBL IN INTERMEDIATE_TBL_TYPE,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_AMT_TAG_LST         VARCHAR2(1000) := '';
    L_SETTLE_AMT_LST      VARCHAR2(1000) := '';
    L_EXCH_RATE_LST       VARCHAR2(1000) := '';
    L_VDATE_LST           VARCHAR2(1000) := '';
    L_NETIND_LST          VARCHAR2(1000) := '';
    L_ORG_EXCH_RATE_LST   VARCHAR2(1000) := '';
    L_AFTR_AMT_TAG_LST    VARCHAR2(1000) := '';
    L_AFTR_SETTLE_AMT_LST VARCHAR2(1000) := '';
    PROCESS_FAILED EXCEPTION;
    THIS_FN VARCHAR2(50) := 'BCPKS_ACC_ENTRIES.fn_settlement_update';

    LSETLTAG         VARCHAR2(100);
    L_GENMSG_LST     VARCHAR2(1000);
    L_SAME_CCY_COUNT NUMBER;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside fn_settlement_updates');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    FOR I IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
      IF P_INTERMEDIATE_TBL(I).SETTLEMENT_FLAG = 'Y' THEN

        L_GENMSG_LST := L_GENMSG_LST || '~' || P_INTERMEDIATE_TBL(I)
                       .GEN_MSG;

        L_AMT_TAG_LST := L_AMT_TAG_LST || '~' || P_INTERMEDIATE_TBL(I)
                        .AMT_TAG;

        IF P_INTERMEDIATE_TBL(I).ACC_CCY != GLOBAL.LCY THEN
          L_SETTLE_AMT_LST := L_SETTLE_AMT_LST || '~' || P_INTERMEDIATE_TBL(I)
                             .FCY_AMT;
        ELSE
          L_SETTLE_AMT_LST := L_SETTLE_AMT_LST || '~' || P_INTERMEDIATE_TBL(I)
                             .LCY_AMT;
        END IF;

        DEBUG.PR_DEBUG('BC',
                       'account ccy   >>' || P_INTERMEDIATE_TBL(I).ACC_CCY);
        SELECT COUNT(1)
          INTO L_SAME_CCY_COUNT
          FROM ISTBS_CONTRACTIS
         WHERE CONTRACT_REF_NO = P_BCREFNO
           AND AMOUNT_TAG = P_INTERMEDIATE_TBL(I).AMT_TAG
           AND TAG_CCY = P_INTERMEDIATE_TBL(I).ACC_CCY
           AND ACC_CCY = P_INTERMEDIATE_TBL(I).ACC_CCY
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM ISTBS_CONTRACTIS
                 WHERE CONTRACT_REF_NO = P_BCREFNO);

        IF L_SAME_CCY_COUNT = 0 THEN
          L_EXCH_RATE_LST := L_EXCH_RATE_LST || '~' || P_INTERMEDIATE_TBL(I)
                            .TAG_SETTLEMENT_RATE;

          L_ORG_EXCH_RATE_LST := L_ORG_EXCH_RATE_LST || '~' || P_INTERMEDIATE_TBL(I)
                                .ORG_EXCH_RATE;

        ELSE
          L_EXCH_RATE_LST := L_EXCH_RATE_LST || '~' || 1;

          L_ORG_EXCH_RATE_LST := L_ORG_EXCH_RATE_LST || '~' || 1;

        END IF;
        DEBUG.PR_DEBUG('BC',
                       'amt_tag   >>' || P_INTERMEDIATE_TBL(I).AMT_TAG ||
                       ' exch_rate chk last >>' || L_EXCH_RATE_LST);

        L_VDATE_LST  := L_VDATE_LST || '~' || P_INTERMEDIATE_TBL(I).VDATE;
        L_NETIND_LST := L_NETIND_LST || '~' || P_INTERMEDIATE_TBL(I).NETIND;
      END IF;
    END LOOP;
    L_AMT_TAG_LST       := SUBSTR(L_AMT_TAG_LST, 2);
    L_SETTLE_AMT_LST    := SUBSTR(L_SETTLE_AMT_LST, 2);
    L_EXCH_RATE_LST     := SUBSTR(L_EXCH_RATE_LST, 2);
    L_VDATE_LST         := SUBSTR(L_VDATE_LST, 2);
    L_NETIND_LST        := SUBSTR(L_NETIND_LST, 2);
    L_GENMSG_LST        := SUBSTR(L_GENMSG_LST, 2);
    L_ORG_EXCH_RATE_LST := SUBSTR(L_ORG_EXCH_RATE_LST, 2);

    DEBUG.PR_DEBUG('BC',
                   'Printing the lists before Settlement update
        for contract : ' || P_BCREFNO);

    DEBUG.PR_DEBUG('BC', 'l_amt_tag_lst      :' || L_AMT_TAG_LST);
    DEBUG.PR_DEBUG('BC', 'l_settle_amt_lst   :' || L_SETTLE_AMT_LST);
    DEBUG.PR_DEBUG('BC', 'l_exch_rate_lst    :' || L_EXCH_RATE_LST);
    DEBUG.PR_DEBUG('BC', 'l_vdate_lst            :' || L_VDATE_LST);
    DEBUG.PR_DEBUG('BC', 'l_netind_lst       :' || L_NETIND_LST);
    DEBUG.PR_DEBUG('BC', 'l_genmsg_lst       :' || L_GENMSG_LST);
    DEBUG.PR_DEBUG('BC', 'l_org_exch_rate_lst :' || L_ORG_EXCH_RATE_LST);

    IF NOT FN_SPLIT_CHECK(P_BCREFNO,
                          P_ESN,
                          L_AMT_TAG_LST,
                          L_SETTLE_AMT_LST,
                          P_ERR_CODE) THEN
      DEBUG.PR_DEBUG('BC', 'bombed in fn_split_check ');
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('BC',
                   'After fn_split_check l_settle_amt_lst ' ||
                   L_SETTLE_AMT_LST);
    IF NOT ISPKSS.FN_UPDATE(P_BCREFNO,
                            P_ESN,
                            L_AMT_TAG_LST,
                            L_SETTLE_AMT_LST,
                            L_EXCH_RATE_LST,
                            L_VDATE_LST,
                            L_NETIND_LST,
                            L_GENMSG_LST,
                            P_ERR_CODE) THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT009';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~';

        DEBUG.PR_DEBUG('BC', 'ISPKSS.fn_update bombed');
      END IF;
      RAISE PROCESS_FAILED;
    END IF;

    IF NOT FN_UPDATE(P_BCREFNO,
                     P_ESN,
                     L_AMT_TAG_LST,
                     L_ORG_EXCH_RATE_LST,
                     P_ERR_CODE) THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT009';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~';

        DEBUG.PR_DEBUG('BC', 'fn_update bombed');
      END IF;
      RAISE PROCESS_FAILED;
    END IF;

    DEBUG.PR_DEBUG('BC', 'Settlement update PASSED');

    RETURN TRUE;

  EXCEPTION
    WHEN PROCESS_FAILED THEN
      DEBUG.PR_DEBUG('BC', THIS_FN || ' FAILED');
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', THIS_FN || SQLERRM);
      RETURN FALSE;

  END FN_SETTLEMENT_UPDATES;

  FUNCTION FN_CHARGE_UPDATES(

                             P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                             P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                             P_INTERMEDIATE_TBL IN INTERMEDIATE_TBL_TYPE,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_COMPONENT VARCHAR2(15);
    PROCESS_FAILED EXCEPTION;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside fn_charge_updates');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    FOR I IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP

      IF P_INTERMEDIATE_TBL(I).TAGTYPE = 'H' THEN
        L_COMPONENT := P_INTERMEDIATE_TBL(I).AMT_TAG;

        IF NOT CFPKSS_SERVICES.FN_UPDATE_STATUS(P_BCREFNO,
                                                P_ESN,
                                                P_ESN,
                                                L_COMPONENT,
                                                'L',
                                                FALSE) THEN
          P_ERR_CODE   := 'BC-AT010';
          P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~';

          DEBUG.PR_DEBUG('BC', 'CFPKSS_SERVICES.fn_update_status FAILED');
          RAISE PROCESS_FAILED;
        END IF;
      END IF;
    END LOOP;

    DEBUG.PR_DEBUG('BC', 'fn_charge_updates PASSED');

    RETURN TRUE;

  EXCEPTION
    WHEN PROCESS_FAILED THEN
      DEBUG.PR_DEBUG('BC', 'fn_charge_updates FAILED');
      RETURN FALSE;

  END FN_CHARGE_UPDATES;

  FUNCTION FN_BUILD_ACC_HANDOFF_TBL(P_BCREFNO          IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                                    P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                                    P_EVENT_CODE       IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                                    P_MODULE           IN CSTBS_CONTRACT.MODULE_CODE%TYPE,
                                    P_INTERMEDIATE_TBL IN INTERMEDIATE_TBL_TYPE,
                                    P_ACC_HANDOFF_TBL  IN OUT ACPKSS.TBL_ACHOFF,
                                    P_ERR_CODE         IN OUT VARCHAR2,
                                    P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_HOFF_REC ACTBS_HANDOFF%ROWTYPE;
    RELCUST    CSTBS_CONTRACT.COUNTERPARTY%TYPE;
  BEGIN

    DEBUG.PR_DEBUG('BC',
                   'BCPKSS_ACC_ENTRIES.Inside fn_build_acc_handoff_tbl');

    BEGIN
      SELECT COUNTERPARTY
        INTO RELCUST
        FROM CSTBS_CONTRACT
       WHERE CONTRACT_REF_NO = P_BCREFNO;

      IF RELCUST IS NULL THEN
        SELECT CUSTOMER_ID
          INTO RELCUST
          FROM BCTBS_CONTRACT_MASTER
         WHERE BCREFNO = P_BCREFNO
           AND EVENT_SEQ_NO = P_ESN;
      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('BC',
                       'Error in getting Related Customer for ' ||
                       P_BCREFNO || ' Was : ' || SQLERRM);
        RELCUST := NULL;
    END;

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    FOR I IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
      DEBUG.PR_DEBUG('BC',
                     'DAN->bcacct1->Lcy Amt    = ' || P_INTERMEDIATE_TBL(I)
                     .LCY_AMT);
      P_ACC_HANDOFF_TBL(I) := L_HOFF_REC;
      P_ACC_HANDOFF_TBL(I).TRN_REF_NO := P_BCREFNO;
      P_ACC_HANDOFF_TBL(I).EVENT_SR_NO := P_ESN;
      P_ACC_HANDOFF_TBL(I).EVENT := P_EVENT_CODE;
      P_ACC_HANDOFF_TBL(I).AC_BRANCH := P_INTERMEDIATE_TBL(I).ACC_BRANCH;

      P_ACC_HANDOFF_TBL(I).AC_NO := LTRIM(RTRIM(P_INTERMEDIATE_TBL(I)
                                                .ACCOUNT));

      P_ACC_HANDOFF_TBL(I).VIRTUAL_AC_NO := LTRIM(RTRIM(P_INTERMEDIATE_TBL(I)
                                                        .VIRTUALACNO));

      P_ACC_HANDOFF_TBL(I).AC_CCY := P_INTERMEDIATE_TBL(I).ACC_CCY;
      P_ACC_HANDOFF_TBL(I).DRCR_IND := P_INTERMEDIATE_TBL(I).DRCRIND;
      P_ACC_HANDOFF_TBL(I).TRN_CODE := P_INTERMEDIATE_TBL(I).TRNCODE;
      P_ACC_HANDOFF_TBL(I).AMOUNT_TAG := P_INTERMEDIATE_TBL(I).AMT_TAG;
      P_ACC_HANDOFF_TBL(I).FCY_AMOUNT := P_INTERMEDIATE_TBL(I).FCY_AMT;
      P_ACC_HANDOFF_TBL(I).EXCH_RATE := P_INTERMEDIATE_TBL(I).EXCH_RATE;
      P_ACC_HANDOFF_TBL(I).LCY_AMOUNT := P_INTERMEDIATE_TBL(I).LCY_AMT;

      P_ACC_HANDOFF_TBL(I).RELATED_CUSTOMER := RELCUST;

      P_ACC_HANDOFF_TBL(I).TRN_DT := GLOBAL.APPLICATION_DATE;
      P_ACC_HANDOFF_TBL(I).VALUE_DT := P_INTERMEDIATE_TBL(I).VDATE;
      P_ACC_HANDOFF_TBL(I).TXN_INIT_DATE := NULL;
      P_ACC_HANDOFF_TBL(I).FINANCIAL_CYCLE := NULL;
      P_ACC_HANDOFF_TBL(I).PERIOD_CODE := NULL;

      P_ACC_HANDOFF_TBL(I).INSTRUMENT_CODE := P_INTERMEDIATE_TBL(I)
                                              .INSTRUMENT_CODE;

      P_ACC_HANDOFF_TBL(I).BATCH_NO := NULL;
      P_ACC_HANDOFF_TBL(I).CURR_NO := NULL;
      P_ACC_HANDOFF_TBL(I).NETTING_IND := P_INTERMEDIATE_TBL(I).NETIND;
      P_ACC_HANDOFF_TBL(I).USER_ID := GLOBAL.USER_ID;
      P_ACC_HANDOFF_TBL(I).BANK_CODE := NULL;
      P_ACC_HANDOFF_TBL(I).AVLDAYS := NULL;
      P_ACC_HANDOFF_TBL(I).BALANCE_UPD := NULL;
      P_ACC_HANDOFF_TBL(I).TYPE := NULL;
      P_ACC_HANDOFF_TBL(I).UPDACT := NULL;
      P_ACC_HANDOFF_TBL(I).CATEGORY := P_INTERMEDIATE_TBL(I).GLCAT;
      P_ACC_HANDOFF_TBL(I).CUST_GL := NULL;
      P_ACC_HANDOFF_TBL(I).DISTRIBUTED := NULL;
      P_ACC_HANDOFF_TBL(I).NODE := NULL;
      P_ACC_HANDOFF_TBL(I).ON_LINE := NULL;
      P_ACC_HANDOFF_TBL(I).MODULE := P_MODULE;
      P_ACC_HANDOFF_TBL(I).RELATED_ACCOUNT := NULL;
      P_ACC_HANDOFF_TBL(I).MIS_HEAD := P_INTERMEDIATE_TBL(I).MIS_HEAD;
      P_ACC_HANDOFF_TBL(I).RELATED_REFERENCE := NULL;
      P_ACC_HANDOFF_TBL(I).MIS_FLAG := NULL;

    END LOOP;

    DEBUG.PR_DEBUG('BC', 'fn_build_acc_handoff PASSED');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN (CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      IF NOT
          BCPKS_ACC_ENTRIES_CUSTOM.FN_POST_BUILD_ACC_HANDOFF_TBL(P_BCREFNO,
                                                                 P_ESN,
                                                                 P_EVENT_CODE,
                                                                 P_MODULE,
                                                                 P_INTERMEDIATE_TBL,
                                                                 P_ACC_HANDOFF_TBL,
                                                                 P_ERR_CODE,
                                                                 P_ERR_PARAMS) THEN

        DEBUG.PR_DEBUG('BC',
                       'Failed in fn_post_build_acc_handoff_tbl' || SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'fn_build_acc_handoff_tbl FAILED-' || SQLERRM);
      RETURN FALSE;

  END FN_BUILD_ACC_HANDOFF_TBL;

  FUNCTION FN_GET_EVENT_ENTRY_COUNT(P_BCREFNO           IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                                    P_AMTTAG            IN CSTBS_AMOUNT_TAG.AMOUNT_TAG%TYPE,
                                    P_MODULE            IN CSTBS_CONTRACT_EVENT_LOG.MODULE%TYPE,
                                    P_EVENT_ENTRY_COUNT IN OUT NUMBER)
    RETURN BOOLEAN IS
    
    L_EVENT_ENTRY_COUNT NUMBER := 0;
    L_PRIN_TAG_COUNT    NUMBER := 0;
    
  BEGIN
    DEBUG.PR_DEBUG('BC', 'Inside the get_event_entry_count');
    DEBUG.PR_DEBUG('BC', 'Contract Ref No :: ' || P_BCREFNO);
    DEBUG.PR_DEBUG('BC', 'Amount Tag      :: ' || P_AMTTAG);
    DEBUG.PR_DEBUG('BC', 'p_module        :: ' || P_MODULE);
    SELECT COUNT(1)
      INTO L_PRIN_TAG_COUNT
      FROM CSTB_AMOUNT_TAG
     WHERE AMOUNT_TAG = P_AMTTAG
       AND AMOUNT_TAG_TYPE IS NULL
       AND MODULE = P_MODULE;

    IF L_PRIN_TAG_COUNT > 0 THEN
      DEBUG.PR_DEBUG('BC', 'Princ amount tag is  :' || P_AMTTAG);
      SELECT COUNT(1)
        INTO L_EVENT_ENTRY_COUNT
        FROM CSTM_PRODUCT_EVENT_ACCT_ENTRY
       WHERE PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4)
         AND AMT_TAG = P_AMTTAG
         AND EVENT_CODE = 'BOOK';
    ELSE
      L_EVENT_ENTRY_COUNT := 1;
    END IF;

    DEBUG.PR_DEBUG('BC', 'l_event_entry_count :' || L_EVENT_ENTRY_COUNT);
    P_EVENT_ENTRY_COUNT := L_EVENT_ENTRY_COUNT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'Failed in get_event_entry_count:' || SQLERRM);
  END FN_GET_EVENT_ENTRY_COUNT;

  FUNCTION FN_BUILD_MID_TBL(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                            P_MODULE           IN CSTBS_CONTRACT_EVENT_LOG.MODULE%TYPE,
                            P_INTERMEDIATE_TBL IN OUT INTERMEDIATE_TBL_TYPE,
                            P_AMTTAG_TBL       IN OUT BCPKSS_ICCF2.ICCF_TBL_TYPE,
                            P_ACC_LOOKUP_TBL   IN ACPKSS.TBL_LOOKUP,
                            P_TAG_LST          IN OUT VARCHAR2,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    J BINARY_INTEGER := 0;
    K BINARY_INTEGER := 0;

    LSETLTAG   VARCHAR2(100);
    LCOMPONENT CSTBS_AMOUNT_DUE.COMPONENT%TYPE;
    LAMTDUEREC CSTBS_AMOUNT_DUE%ROWTYPE;

    L_COMPONENT   VARCHAR2(15);
    P1            NUMBER := 0;
    I_NP          NUMBER := 0;
    L_UDEF_STATUS CSTBS_CONTRACT.USER_DEFINED_STATUS%TYPE;

    L_PREV_BILL_AMT BCTBS_CONTRACT_MASTER.BILL_AMT%TYPE;
    L_BILL_AMT      BCTBS_CONTRACT_MASTER.BILL_AMT%TYPE;
    L_MAX_VERSION   BCTBS_CONTRACT_MASTER.VERSION_NO%TYPE;

    L_ACC_HEAD           GLTMS_GLMASTER.GL_CODE%TYPE;
    P_REAL_TO_CONTINGENT BOOLEAN := FALSE;
    L_GLCAT              GLTMS_GLMASTER.CATEGORY%TYPE;

    L_BCTBS_CONTRACT_MASTER BCTBS_CONTRACT_MASTER%ROWTYPE;
    L_EVENT_COUNT           NUMBER := 0;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside BCPKSS_ACC_ENTRIES.fn_build_mid_tbl');

    IF P_MODULE IS NULL THEN
      DEBUG.PR_DEBUG('BC', 'ERROR - Module cannot be NULL');
      RETURN FALSE;
    END IF;

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    DEBUG.PR_DEBUG('BC', 'Module - ' || P_MODULE);

    BEGIN
      SELECT USER_DEFINED_STATUS
        INTO L_UDEF_STATUS
        FROM CSTBS_CONTRACT
       WHERE CONTRACT_REF_NO = P_BCREFNO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_UDEF_STATUS := 'NORM';
    END;

    DEBUG.PR_DEBUG('BC', 'UDEF status :' || L_UDEF_STATUS);

    I_NP := P_AMTTAG_TBL.COUNT;

    IF L_UDEF_STATUS <> 'NORM' THEN

      FOR I IN 1 .. P_AMTTAG_TBL.COUNT LOOP
        DEBUG.PR_DEBUG('BC', 'Tag  :' || P_AMTTAG_TBL(I).TAG);
        IF P_AMTTAG_TBL(I).TAG LIKE '%LIQD' THEN
          I_NP        := I_NP + 1;
          P1          := INSTR(P_AMTTAG_TBL(I).TAG, '_LIQD');
          L_COMPONENT := SUBSTR(P_AMTTAG_TBL(I).TAG, 1, P1 - 1);
          DEBUG.PR_DEBUG('BC', 'component :' || L_COMPONENT);
          P_AMTTAG_TBL(I_NP).TAG := L_COMPONENT || 'NP_LIQD';
          DEBUG.PR_DEBUG('BC',
                         'extra amt tag created :' || P_AMTTAG_TBL(I_NP).TAG);
          P_AMTTAG_TBL(I_NP).AMT := P_AMTTAG_TBL(I).AMT;
          P_AMTTAG_TBL(I_NP).CCY := P_AMTTAG_TBL(I).CCY;
          P_AMTTAG_TBL(I_NP).SETTLEMENT_FLAG := P_AMTTAG_TBL(I)
                                                .SETTLEMENT_FLAG;
          P_AMTTAG_TBL(I_NP).TAG_TYPE := P_AMTTAG_TBL(I).TAG_TYPE;
          P_AMTTAG_TBL(I_NP).VDATE := P_AMTTAG_TBL(I).VDATE;
        END IF;

      END LOOP;
    END IF;

    BEGIN
      SELECT *
        INTO L_BCTBS_CONTRACT_MASTER
        FROM BCTBS_CONTRACT_MASTER
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM BCTBS_CONTRACT_MASTER
                              WHERE BCREFNO = P_BCREFNO);
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('BC', 'Failed over here :' || SQLERRM);
    END;

    FOR I IN P_AMTTAG_TBL.FIRST .. P_AMTTAG_TBL.LAST LOOP
      DEBUG.PR_DEBUG('BC',
                     'Checking for existence of tag -->' || P_AMTTAG_TBL(I).TAG);
      J := P_ACC_LOOKUP_TBL.FIRST;
      WHILE J <= P_ACC_LOOKUP_TBL.LAST LOOP
        DEBUG.PR_DEBUG('BC',
                       J || ' - ' || P_ACC_LOOKUP_TBL(J).AMTTAG || ' Vs ' || P_AMTTAG_TBL(I).TAG);
        IF P_ACC_LOOKUP_TBL(J)
         .AMTTAG = P_AMTTAG_TBL(I).TAG AND

           P_ACC_LOOKUP_TBL(J)
           .ACCROLE = NVL(P_AMTTAG_TBL    (I).ACCOUNT_ROLE_CODE,
                          P_ACC_LOOKUP_TBL(J).ACCROLE)

         THEN
          DEBUG.PR_DEBUG('BC',
                         'Creating entry in intermediate table for tag -->' || P_AMTTAG_TBL(I).TAG);

          DEBUG.PR_DEBUG('BC', 'Stage :' || L_BCTBS_CONTRACT_MASTER.STAGE);
          DEBUG.PR_DEBUG('BC',
                         'Event :' || L_BCTBS_CONTRACT_MASTER.EVENT_CODE);

          IF L_BCTBS_CONTRACT_MASTER.STAGE = 'INI' AND
             L_BCTBS_CONTRACT_MASTER.EVENT_CODE = 'CLOS' THEN

            DEBUG.PR_DEBUG('BC', 'About to call get_event_entry_count');
            IF NOT FN_GET_EVENT_ENTRY_COUNT(P_BCREFNO,
                                            P_AMTTAG_TBL(I).TAG,
                                            P_MODULE,
                                            L_EVENT_COUNT) THEN
              DEBUG.PR_DEBUG('BC',
                             'Failed in getting the event count :' ||
                             SQLERRM);
              L_EVENT_COUNT := 0;
            END IF;

            DEBUG.PR_DEBUG('BC', 'Event entry count :' || L_EVENT_COUNT);
            IF L_EVENT_COUNT = 0 THEN
              DEBUG.PR_DEBUG('BC',
                             'Entry should not fire for this amount tag :' || P_AMTTAG_TBL(I).TAG);
              J := J + 1;
              CONTINUE;
            END IF;
            DEBUG.PR_DEBUG('BC',
                           'l_bctbs_contract_master.event_code :' ||
                           L_BCTBS_CONTRACT_MASTER.EVENT_CODE);
          END IF;

          K := K + 1;
          P_INTERMEDIATE_TBL(K).MULTITENOR := P_AMTTAG_TBL(I).MULTITENOR;
          P_INTERMEDIATE_TBL(K).AMT_TAG := P_AMTTAG_TBL(I).TAG;
          P_INTERMEDIATE_TBL(K).ACCROLE := P_ACC_LOOKUP_TBL(J).ACCROLE;
          P_INTERMEDIATE_TBL(K).ACC_BRANCH := '';
          P_INTERMEDIATE_TBL(K).ACCOUNT := P_ACC_LOOKUP_TBL(J).ACCOUNT;
          P_INTERMEDIATE_TBL(K).ACC_CCY := '';

          DEBUG.PR_DEBUG('BC',
                         'p_acc_lookup_tbl(j).accrole >' || P_ACC_LOOKUP_TBL(J)
                         .ACCROLE);
          DEBUG.PR_DEBUG('BC', 'l_user_defined_status - ' || L_UDEF_STATUS);
          IF L_UDEF_STATUS <> 'NORM' THEN
            IF NOT
                BCPKSS_STATUS1.FN_REAL_TO_CONTINGENT(SUBSTR(P_BCREFNO, 4, 4),
                                                     L_UDEF_STATUS,
                                                     'NORM',
                                                     P_REAL_TO_CONTINGENT,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
              DEBUG.PR_DEBUG('BC',
                             'FUNCTION real to contingent retuned false');
              RETURN FALSE;
            END IF;

            IF P_REAL_TO_CONTINGENT THEN
              IF (P_AMTTAG_TBL(I)
                 .TAG LIKE '%ACPP' OR P_AMTTAG_TBL(I).TAG LIKE '%ACCR1') THEN
                DEBUG.PR_DEBUG('BC',
                               ' Replacing Gl head for p_amttag_tbl(i).tag - ' || P_AMTTAG_TBL(I).TAG);
                BEGIN
                  SELECT TRANSFER_GL
                    INTO L_ACC_HEAD
                    FROM CSTMS_PRODUCT_STATUS_GL
                   WHERE PRODUCT = SUBSTR(P_BCREFNO, 4, 4)
                     AND ACCOUNT_ROLE = P_ACC_LOOKUP_TBL(J).ACCROLE
                     AND STATUS = 'NORM';
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DEBUG.PR_DEBUG('BC',
                                   'For NORM STATUS gl code is not found');
                    SELECT ACCOUNT_HEAD
                      INTO L_ACC_HEAD
                      FROM CSTMS_PRODUCT_ACCROLE
                     WHERE PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4)
                       AND ACCOUNTING_ROLE = P_ACC_LOOKUP_TBL(J).ACCROLE
                       AND STATUS = 'NORM';
                  WHEN OTHERS THEN
                    DEBUG.PR_DEBUG('BC',
                                   'in when others in l_acc_head select for ACPP tag :' ||
                                   SQLERRM);
                END;

                SELECT CATEGORY
                  INTO L_GLCAT
                  FROM GLTMS_GLMASTER
                 WHERE GL_CODE = L_ACC_HEAD;

                P_INTERMEDIATE_TBL(K).ACCOUNT := L_ACC_HEAD;
                P_INTERMEDIATE_TBL(K).GLCAT := L_GLCAT;
              END IF;
            END IF;
          END IF;

          IF P_AMTTAG_TBL(I).NORM_OR_REVR = 'R' THEN
            IF P_ACC_LOOKUP_TBL(J).DRCRIND = 'C' THEN
              P_INTERMEDIATE_TBL(K).DRCRIND := 'D';
            ELSE
              P_INTERMEDIATE_TBL(K).DRCRIND := 'C';
            END IF;
          ELSE
            P_INTERMEDIATE_TBL(K).DRCRIND := P_ACC_LOOKUP_TBL(J).DRCRIND;
          END IF;

          P_INTERMEDIATE_TBL(K).TAG_AMT := P_AMTTAG_TBL(I).AMT;

          P_INTERMEDIATE_TBL(K).NETIND := P_ACC_LOOKUP_TBL(J).NETIND;
          P_INTERMEDIATE_TBL(K).TRNCODE := P_ACC_LOOKUP_TBL(J).TRNCODE;

          IF P_INTERMEDIATE_TBL(K).GLCAT IS NULL THEN

            P_INTERMEDIATE_TBL(K).GLCAT := P_ACC_LOOKUP_TBL(J).GLCAT;
          END IF;
          P_INTERMEDIATE_TBL(K).MIS_HEAD := P_ACC_LOOKUP_TBL(J).MIS_HEAD;
          P_INTERMEDIATE_TBL(K).TAGTYPE := P_ACC_LOOKUP_TBL(J).TAGTYPE;
          P_AMTTAG_TBL(I).TAG_TYPE := P_ACC_LOOKUP_TBL(J).TAGTYPE;
          P_INTERMEDIATE_TBL(K).TAG_CCY := P_AMTTAG_TBL(I).CCY;

          P_INTERMEDIATE_TBL(K).FCY_AMT := NULL;
          P_INTERMEDIATE_TBL(K).ORG_EXCH_RATE := NULL;
          P_INTERMEDIATE_TBL(K).EXCH_RATE := NULL;
          P_INTERMEDIATE_TBL(K).LCY_AMT := NULL;
          P_INTERMEDIATE_TBL(K).VDATE := P_AMTTAG_TBL(I).VDATE;
          P_INTERMEDIATE_TBL(K).SETTLEMENT_FLAG := 'N';
          P_INTERMEDIATE_TBL(K).TAG_INDEX := I;
          P_INTERMEDIATE_TBL(K).TAG_SETTLEMENT_RATE := '';

          IF P_INTERMEDIATE_TBL(K).ACCOUNT = 'USERINPUT' THEN
            P_INTERMEDIATE_TBL(K).SETTLEMENT_FLAG := 'Y';
            P_TAG_LST := P_TAG_LST || '~' || P_INTERMEDIATE_TBL(K).AMT_TAG;

            P_AMTTAG_TBL(I).SETTLEMENT_FLAG := 'Y';

            LSETLTAG := P_INTERMEDIATE_TBL(K).AMT_TAG;
            IF P_INTERMEDIATE_TBL(K).TAGTYPE IN ('I', 'C') THEN
              LCOMPONENT := SUBSTR(LSETLTAG, 1, LENGTH(LSETLTAG) - 5);

            ELSE
              LCOMPONENT := LSETLTAG;
            END IF;

            BEGIN
              SELECT *
                INTO LAMTDUEREC
                FROM CSTBS_AMOUNT_DUE
               WHERE CONTRACT_REF_NO = P_BCREFNO
                 AND COMPONENT = LCOMPONENT;

              P_INTERMEDIATE_TBL(K).SGEN_XRATE := LAMTDUEREC.SGEN_XRATE;
            EXCEPTION
              WHEN OTHERS THEN
                P_INTERMEDIATE_TBL(K).GEN_MSG := NULL;

                P_INTERMEDIATE_TBL(K).SGEN_XRATE := NULL;
            END;

          ELSE
            P_INTERMEDIATE_TBL(K).SGEN_XRATE := NULL;
            P_INTERMEDIATE_TBL(K).GEN_MSG := NULL;
            P_INTERMEDIATE_TBL(K).SETTLEMENT_FLAG := 'N';

          END IF;

        END IF;
        J := J + 1;
      END LOOP;
    END LOOP;

    P_TAG_LST := SUBSTR(P_TAG_LST, 2);

    DEBUG.PR_DEBUG('BC', 'fn_build_mid_tbl PASSED');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'fn_build_mid_tbl FAILED- ' || SQLERRM);
      RETURN FALSE;

  END FN_BUILD_MID_TBL;

  FUNCTION FN_PROCESS_TBL_FOR_NUI_ACCTS(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                                        P_MODULE           IN CSTBS_CONTRACT.MODULE_CODE%TYPE,
                                        P_EVENT_CODE       IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                                        P_INTERMEDIATE_TBL IN OUT INTERMEDIATE_TBL_TYPE,
                                        P_AMTTAG_TBL       IN OUT BCPKSS_ICCF2.ICCF_TBL_TYPE,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_XRATE_TYPE BCTMS_PRODUCT_MASTER.XRATE_TYPE%TYPE;
    L_RET_AMT    BCTBS_CONTRACT_MASTER.BILL_AMT%TYPE;
    L_RATEFLAG   NUMBER;
    L_EXCH_RATE  CYTMS_RATES.MID_RATE%TYPE;
    THIS_FN      VARCHAR2(50) := 'BCPKS_ACC_ENTRIES.fn_tbl_for_nui_accts';
    PROCESS_FAILED      EXCEPTION;
    GETRATE_FAILED      EXCEPTION;
    AMT1_TO_AMT2_FAILED EXCEPTION;
    L_CCY1 CFTBS_CONTRACT_INTEREST.CURRENCY%TYPE;
    L_CCY2 CFTBS_CONTRACT_INTEREST.CURRENCY%TYPE;

    L_BRANCH               STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_SETTLEMENT_EXCH_RATE ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_SETTLEMENT_AMOUNT    ACTBS_HANDOFF.FCY_AMOUNT%TYPE;
    L_LCY_EXCH_RATE        ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_LCY_EQUIVALENT       ACTBS_HANDOFF.LCY_AMOUNT%TYPE;
    L_RELATED_FCY          ACTBS_HANDOFF.AC_CCY%TYPE;
    L_CUST_ENTRY           NUMBER := 0;
    L_CHG_CCY              ACTBS_HANDOFF.AC_CCY%TYPE;
    L_CHG_AMT_IN_CHG_CCY   ACTBS_HANDOFF.LCY_AMOUNT%TYPE;

    L_PRODUCT_TYPE   BCTMS_PRODUCT_MASTER.PRODUCT_TYPE%TYPE;
    L_RATE_INDICATOR CSTMS_PRODUCT.PRODUCT_CODE%TYPE;

    L_ORG_EXCH_RATE CYTMS_RATES.MID_RATE%TYPE;
    L_CUST_NO       STTMS_CUSTOMER.CUSTOMER_NO%TYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside fn_process_tbl_for_nui_accts');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';
    DEBUG.PR_DEBUG('BC', 'Event Code is ' || P_EVENT_CODE);
    G_EVENT_CODE := P_EVENT_CODE;
    IF P_MODULE IN ('BC', 'IB') THEN
      BEGIN
        DEBUG.PR_DEBUG('BC', 'Selecting xrate_type from BC table');
        SELECT XRATE_TYPE, PRODUCT_TYPE
          INTO L_XRATE_TYPE, L_PRODUCT_TYPE
          FROM BCTMS_PRODUCT_MASTER
         WHERE PROD_CODE = SUBSTR(P_BCREFNO, 4, 4);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('BC', 'BCTMS_PRODUCT_MASTER- ' || SQLERRM);
          RAISE PROCESS_FAILED;
      END;

    ELSE
      BEGIN
        DEBUG.PR_DEBUG('BC', 'Selecting xrate_type from LC table');

        SELECT EXCHANGE_RATE_TYPE, PRODUCT_TYPE
          INTO L_XRATE_TYPE, L_PRODUCT_TYPE
          FROM LCTMS_PRODUCT_DEFINITION
         WHERE PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('BC', 'LCTMS_PRODUCT_DEFINITION-' || SQLERRM);
          L_XRATE_TYPE := 'STANDARD';
      END;

    END IF;

    L_BRANCH := SUBSTR(P_BCREFNO, 1, 3);

    DEBUG.PR_DEBUG('BC', 'Entering loop to process NUI acct types');

    FOR I IN P_AMTTAG_TBL.FIRST .. P_AMTTAG_TBL.LAST LOOP

      DEBUG.PR_DEBUG('BC',
                     'NUI - Settlement flag: ' || P_AMTTAG_TBL(I)
                     .SETTLEMENT_FLAG);
      DEBUG.PR_DEBUG('BC', 'NUI - Amount tag -> ' || P_AMTTAG_TBL(I).TAG);
      DEBUG.PR_DEBUG('BC', 'NUI - Tag ccy    -> ' || P_AMTTAG_TBL(I).CCY);
      DEBUG.PR_DEBUG('BC', 'NUI - Amount     -> ' || P_AMTTAG_TBL(I).AMT);

      IF P_AMTTAG_TBL(I)
       .TAG NOT LIKE '%DISC' AND P_AMTTAG_TBL(I).TAG NOT LIKE '%PREM' THEN

        IF NVL(P_AMTTAG_TBL(I).SETTLEMENT_FLAG, 'X') != 'Y' THEN
          DEBUG.PR_DEBUG('BC', 'Amttag_tbl index: ' || I);
          IF P_AMTTAG_TBL(I).CCY != GLOBAL.LCY THEN

            DEBUG.PR_DEBUG('BC', 'module code  is -->' || P_MODULE);
            DEBUG.PR_DEBUG('BC', 'product type  is -->' || L_PRODUCT_TYPE);

            DEBUG.PR_DEBUG('BC', 'module code  is -->>' || P_MODULE);
            DEBUG.PR_DEBUG('BC',
                           'product type  is -->>>' || L_PRODUCT_TYPE);

            IF P_MODULE IN ('BC', 'IB', 'LC')

             THEN
              IF NVL(L_PRODUCT_TYPE, 'X') = 'I' THEN
                L_RATE_INDICATOR := 'S';
              ELSIF NVL(L_PRODUCT_TYPE, 'X') = 'E' THEN
                DEBUG.PR_DEBUG('BC',
                               'checking here -->>' || L_PRODUCT_TYPE);
                L_RATE_INDICATOR := 'B';
              ELSE
                L_RATE_INDICATOR := 'M';
              END IF;
            ELSE
              L_RATE_INDICATOR := 'M';
            END IF;
            DEBUG.PR_DEBUG('BC',
                           'rate indicator  is -->>' || L_RATE_INDICATOR);

            DEBUG.PR_DEBUG('BC', 'amttag_tbl.ccy != Lcy');
            DEBUG.PR_DEBUG('BC',
                           P_AMTTAG_TBL(I).CCY || ' != ' || GLOBAL.LCY);
            DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
            IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                     
                                     GLOBAL.LCY,           --sampath interchanged changes
                                     P_AMTTAG_TBL(I).CCY, --sampath interchanged changes
                                     L_XRATE_TYPE,

                                     L_RATE_INDICATOR--'M' --sampath changes

                                    ,
                                     L_EXCH_RATE,
                                     L_RATEFLAG,
                                     P_ERR_CODE) THEN
              L_CCY1 := P_AMTTAG_TBL(I).CCY;
              L_CCY2 := GLOBAL.LCY;
              RAISE GETRATE_FAILED;
            END IF;

            DEBUG.PR_DEBUG('BC', 'Exch rate is: ' || L_EXCH_RATE);
            
            --sampath starts
            BEGIN
              NULL; 
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
            --sampath ends
            
          END IF;

          FOR J IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
            IF P_INTERMEDIATE_TBL(J).AMT_TAG = P_AMTTAG_TBL(I).TAG THEN

              DEBUG.PR_DEBUG('BC',
                             ' p_intermediate_tbl(j).amt_tag ' || P_INTERMEDIATE_TBL(J)
                             .AMT_TAG);
              DEBUG.PR_DEBUG('BC',
                             ' p_intermediate_tbl(j).exch_rate ' || P_INTERMEDIATE_TBL(J)
                             .EXCH_RATE);
              IF P_INTERMEDIATE_TBL(J).EXCH_RATE IS NULL THEN

                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                  L_FN_CALL_ID      := 1;
                  L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;

                  IF NOT
                      BCPKS_ACC_ENTRIES_CLUSTER.FN_PROCESS_TBL_FOR_NUI_ACCTS(P_BCREFNO,
                                                                             P_MODULE,
                                                                             P_EVENT_CODE,
                                                                             P_INTERMEDIATE_TBL,
                                                                             P_AMTTAG_TBL,
                                                                             P_ERR_CODE,
                                                                             P_ERR_PARAMS,
                                                                             L_FN_CALL_ID,
                                                                             L_TB_CLUSTER_DATA) THEN
                    DEBUG.PR_DEBUG('BC', 'inside if 111 vinay failed');
                    RETURN FALSE;

                  END IF;
                  DEBUG.PR_DEBUG('BC', 'inside if 111 vinay fail 1212');
                END IF;

                P_INTERMEDIATE_TBL(J).EXCH_RATE := NVL(L_EXCH_RATE, 1);

                P_INTERMEDIATE_TBL(J).ORG_EXCH_RATE := NVL(L_EXCH_RATE, 1);

              ELSE
                L_EXCH_RATE := P_INTERMEDIATE_TBL(J).EXCH_RATE;
              END IF;

            END IF;
          END LOOP;

          IF P_AMTTAG_TBL(I).CCY != GLOBAL.LCY THEN
            DEBUG.PR_DEBUG('BC', 'Calling fn_amt1_to_amt2');
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_AMTTAG_TBL(I).CCY,
                                          GLOBAL.LCY,
                                          P_AMTTAG_TBL(I).AMT,
                                          L_EXCH_RATE,
                                          'Y',
                                          L_RET_AMT,
                                          P_ERR_CODE) THEN
              L_CCY1 := P_AMTTAG_TBL(I).CCY;
              L_CCY2 := GLOBAL.LCY;
              RAISE AMT1_TO_AMT2_FAILED;
            END IF;

            DEBUG.PR_DEBUG('BC', 'fn_amt1_to_amt2 in nui PASSED');
            DEBUG.PR_DEBUG('BC', 'Exch_rate for convsn: ' || L_EXCH_RATE);
            DEBUG.PR_DEBUG('BC', 'the converted amount is: ' || L_RET_AMT);

            P_AMTTAG_TBL(I).LCY_AMT_EQUIV := L_RET_AMT;
          ELSE
            P_AMTTAG_TBL(I).LCY_AMT_EQUIV := P_AMTTAG_TBL(I).AMT;
          END IF;
        END IF;

      ELSE
        DEBUG.PR_DEBUG('BC',
                       'inside Else Statement p_amttag_tbl(i).tag : ' || P_AMTTAG_TBL(I).TAG);
        L_CHG_CCY            := P_AMTTAG_TBL(I).CCY;
        L_CHG_AMT_IN_CHG_CCY := P_AMTTAG_TBL(I).AMT;

        DEBUG.PR_DEBUG('BC',
                       'Calling ldpks_acc_entry.fn_compute_lcy_equivalent for NUI accts....3');
        DEBUG.PR_DEBUG('BC',
                       'RIA/PIA Head should be hit in Contract currency');

        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).tag                =' || P_AMTTAG_TBL(I).TAG);
        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).amt                =' || P_AMTTAG_TBL(I).AMT);
        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).ccy                =' || P_AMTTAG_TBL(I).CCY);
        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).contract_ccy       =' || P_AMTTAG_TBL(I)
                       .CONTRACT_CCY);
        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).chg_amt_in_contract_ccy=' || P_AMTTAG_TBL(I)
                       .CHG_AMT_IN_CONTRACT_CCY);

        IF NOT LDPKSS_ACC_ENTRY.FN_COMPUTE_LCY_EQUIVALENT(P_MODULE,
                                                          P_AMTTAG_TBL          (I).TAG,
                                                          P_AMTTAG_TBL          (I).AMT,
                                                          NULL,
                                                          P_AMTTAG_TBL          (I).CCY,
                                                          P_AMTTAG_TBL          (I)
                                                          .CONTRACT_CCY,
                                                          L_SETTLEMENT_EXCH_RATE,
                                                          NULL,
                                                          NULL,
                                                          L_SETTLEMENT_AMOUNT,
                                                          L_LCY_EQUIVALENT,
                                                          L_LCY_EXCH_RATE,
                                                          L_RELATED_FCY,
                                                          P_AMTTAG_TBL          (I)
                                                          .CONTRACT_CCY,
                                                          P_AMTTAG_TBL          (I)
                                                          .CHG_AMT_IN_CONTRACT_CCY,
                                                          NULL,
                                                          P_BCREFNO,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
          DEBUG.PR_DEBUG('BC',
                         'Call to ldpks_acc_entry.fn_compute_lcy_equivalent returned false');
          RETURN FALSE;
        END IF;

        DEBUG.PR_DEBUG('BC', 'Values returned are as follows....3');

        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).tag                =' || P_AMTTAG_TBL(I).TAG);
        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).amt                =' || P_AMTTAG_TBL(I).AMT);
        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).ccy                =' || P_AMTTAG_TBL(I).CCY);
        DEBUG.PR_DEBUG('BC',
                       'p_amttag_tbl(i).contract_ccy       =' || P_AMTTAG_TBL(I)
                       .CONTRACT_CCY);
        DEBUG.PR_DEBUG('BC',
                       'l_settlement_exch_rate         =' ||
                       L_SETTLEMENT_EXCH_RATE);
        DEBUG.PR_DEBUG('BC',
                       'l_settlement_amount                =' ||
                       L_SETTLEMENT_AMOUNT);
        DEBUG.PR_DEBUG('BC',
                       'l_lcy_equivalent               =' ||
                       L_LCY_EQUIVALENT);
        DEBUG.PR_DEBUG('BC',
                       'l_lcy_exch_rate                =' ||
                       L_LCY_EXCH_RATE);
        DEBUG.PR_DEBUG('BC',
                       'l_related_fcy                  =' || L_RELATED_FCY);

        P_AMTTAG_TBL(I).LCY_AMT_EQUIV := L_LCY_EQUIVALENT;

        FOR J IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
          IF (P_INTERMEDIATE_TBL(J).AMT_TAG = P_AMTTAG_TBL(I).TAG) AND
             (NVL(P_INTERMEDIATE_TBL(J).SETTLEMENT_FLAG, 'N') != 'Y') AND
             (P_INTERMEDIATE_TBL(J).ACCROLE LIKE '%RIA' OR P_INTERMEDIATE_TBL(J)
             .ACCROLE LIKE '%PIA') THEN
            DEBUG.PR_DEBUG('BC',
                           '1.Assignment being done ~ ' || P_INTERMEDIATE_TBL(J)
                           .AMT_TAG || ' ~ ' || P_INTERMEDIATE_TBL(J)
                           .ACCROLE);
            P_INTERMEDIATE_TBL(J).EXCH_RATE := L_LCY_EXCH_RATE;
            P_INTERMEDIATE_TBL(J).FCY_AMT := L_SETTLEMENT_AMOUNT;
            P_INTERMEDIATE_TBL(J).ACC_CCY := P_AMTTAG_TBL(I).CONTRACT_CCY;
            P_INTERMEDIATE_TBL(J).LCY_AMT := L_LCY_EQUIVALENT;
            P_INTERMEDIATE_TBL(J).ACC_BRANCH := L_BRANCH;
          END IF;
        END LOOP;

        DEBUG.PR_DEBUG('BC', 'Find if both acc entry legs are GL..');

        SELECT COUNT(*)
          INTO L_CUST_ENTRY
          FROM CSTMS_PRODUCT_EVENT_ACCT_ENTRY
         WHERE PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4)
           AND EVENT_CODE = P_EVENT_CODE
           AND AMT_TAG = P_AMTTAG_TBL(I).TAG
           AND ROLE_TYPE = 'X';

        DEBUG.PR_DEBUG('BC', 'Number of non-GL Legs = ' || L_CUST_ENTRY);

        IF L_CUST_ENTRY = 0 THEN
          DEBUG.PR_DEBUG('BC',
                         'Both are GL legs - Processing for CUSTOMER leg will start now..');

          DEBUG.PR_DEBUG('BC',
                         'Calling ldpks_acc_entry.fn_compute_lcy_equivalent for NUI accts....4');
          DEBUG.PR_DEBUG('BC',
                         'Non RIA/PIA Head should be hit in Charge currency');

          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).tag                =' || P_AMTTAG_TBL(I).TAG);
          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).amt                =' || P_AMTTAG_TBL(I).AMT);
          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).ccy                =' || P_AMTTAG_TBL(I).CCY);
          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).contract_ccy       =' || P_AMTTAG_TBL(I)
                         .CONTRACT_CCY);
          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).chg_amt_in_contract_ccy=' || P_AMTTAG_TBL(I)
                         .CHG_AMT_IN_CONTRACT_CCY);

          P_AMTTAG_TBL(I).CCY := L_CHG_CCY;
          P_AMTTAG_TBL(I).AMT := L_CHG_AMT_IN_CHG_CCY;

          IF NOT LDPKSS_ACC_ENTRY.FN_COMPUTE_LCY_EQUIVALENT(P_MODULE,
                                                            P_AMTTAG_TBL          (I).TAG,
                                                            P_AMTTAG_TBL          (I).AMT,
                                                            NULL,
                                                            P_AMTTAG_TBL          (I).CCY,
                                                            P_AMTTAG_TBL          (I).CCY,
                                                            L_SETTLEMENT_EXCH_RATE,
                                                            NULL,
                                                            NULL,
                                                            L_SETTLEMENT_AMOUNT,
                                                            L_LCY_EQUIVALENT,
                                                            L_LCY_EXCH_RATE,
                                                            L_RELATED_FCY,
                                                            P_AMTTAG_TBL          (I)
                                                            .CONTRACT_CCY,
                                                            P_AMTTAG_TBL          (I)
                                                            .CHG_AMT_IN_CONTRACT_CCY,
                                                            NULL,
                                                            P_BCREFNO,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
            DEBUG.PR_DEBUG('BC',
                           'Call to ldpks_acc_entry.fn_compute_lcy_equivalent returned false');
            RETURN FALSE;
          END IF;

          DEBUG.PR_DEBUG('BC', 'Values returned are as follows....4');

          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).tag                =' || P_AMTTAG_TBL(I).TAG);
          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).amt                =' || P_AMTTAG_TBL(I).AMT);
          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).ccy                =' || P_AMTTAG_TBL(I).CCY);
          DEBUG.PR_DEBUG('BC',
                         'p_amttag_tbl(i).contract_ccy       =' || P_AMTTAG_TBL(I)
                         .CONTRACT_CCY);
          DEBUG.PR_DEBUG('BC',
                         'l_settlement_exch_rate         =' ||
                         L_SETTLEMENT_EXCH_RATE);
          DEBUG.PR_DEBUG('BC',
                         'l_settlement_amount                =' ||
                         L_SETTLEMENT_AMOUNT);
          DEBUG.PR_DEBUG('BC',
                         'l_lcy_equivalent               =' ||
                         L_LCY_EQUIVALENT);
          DEBUG.PR_DEBUG('BC',
                         'l_lcy_exch_rate                =' ||
                         L_LCY_EXCH_RATE);
          DEBUG.PR_DEBUG('BC',
                         'l_related_fcy                  =' ||
                         L_RELATED_FCY);

          P_AMTTAG_TBL(I).LCY_AMT_EQUIV := L_LCY_EQUIVALENT;

          FOR J IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
            IF (P_INTERMEDIATE_TBL(J).AMT_TAG = P_AMTTAG_TBL(I).TAG) AND
               (P_INTERMEDIATE_TBL(J).ACCROLE NOT LIKE '%RIA') AND
               (P_INTERMEDIATE_TBL(J).ACCROLE NOT LIKE '%PIA') THEN
              DEBUG.PR_DEBUG('BC',
                             '2.Assignment being done ~ ' || P_INTERMEDIATE_TBL(J)
                             .AMT_TAG || ' ~ ' || P_INTERMEDIATE_TBL(J)
                             .ACCROLE);
              P_INTERMEDIATE_TBL(J).EXCH_RATE := L_LCY_EXCH_RATE;
              P_INTERMEDIATE_TBL(J).FCY_AMT := L_SETTLEMENT_AMOUNT;
              P_INTERMEDIATE_TBL(J).ACC_CCY := P_AMTTAG_TBL(I).CCY;
              P_INTERMEDIATE_TBL(J).LCY_AMT := L_LCY_EQUIVALENT;
              P_INTERMEDIATE_TBL(J).ACC_BRANCH := L_BRANCH;
            END IF;
          END LOOP;
        END IF;

      END IF;

    END LOOP;

    DEBUG.PR_DEBUG('BC', 'Processing intermediate_tbl for NUI accts');

    FOR I IN P_AMTTAG_TBL.FIRST .. P_AMTTAG_TBL.LAST LOOP
      DEBUG.PR_DEBUG('BC', 'Before If Statement of Retroed IF --> ');
      IF P_AMTTAG_TBL(I)
       .TAG NOT LIKE '%DISC' AND P_AMTTAG_TBL(I).TAG NOT LIKE '%PREM' THEN
        DEBUG.PR_DEBUG('BC',
                       'Processing amt tag --> ' || P_AMTTAG_TBL(I).TAG);
        DEBUG.PR_DEBUG('BC', 'Inside If Statement of Retroed IF --> ');

        FOR J IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
          DEBUG.PR_DEBUG('BC',
                         '[' || P_INTERMEDIATE_TBL(J).AMT_TAG || '-Vs-' || P_AMTTAG_TBL(I).TAG ||
                         '] - ' || P_AMTTAG_TBL(I).SETTLEMENT_FLAG);
          IF P_INTERMEDIATE_TBL(J)
           .AMT_TAG = P_AMTTAG_TBL(I).TAG

             AND NVL(P_AMTTAG_TBL(I).SETTLEMENT_FLAG, 'N') != 'Y'

           THEN
            P_INTERMEDIATE_TBL(J).ACC_BRANCH := GLOBAL.CURRENT_BRANCH;
            P_INTERMEDIATE_TBL(J).ACC_CCY := P_INTERMEDIATE_TBL(J).TAG_CCY;

            IF P_INTERMEDIATE_TBL(J).ACC_CCY = GLOBAL.LCY THEN
              P_INTERMEDIATE_TBL(J).LCY_AMT := P_AMTTAG_TBL(I).AMT;
            ELSE
              P_INTERMEDIATE_TBL(J).FCY_AMT := P_AMTTAG_TBL(I).AMT;
              P_INTERMEDIATE_TBL(J).LCY_AMT := P_AMTTAG_TBL(I).LCY_AMT_EQUIV;
            END IF;

            IF P_AMTTAG_TBL(I)
             .TAG NOT IN
                ('EIMDISC_ACCR', 'EIMINTADJ_ACCR', 'EIMPREM_ACCR') THEN

              IF P_MODULE IN ('BC', 'IB') AND P_INTERMEDIATE_TBL(J)
                .LCY_AMT < 0

                 AND INSTR(P_INTERMEDIATE_TBL(J).AMT_TAG, '_ACPP') = 0

               THEN
                IF P_INTERMEDIATE_TBL(J).DRCRIND = 'D' THEN
                  P_INTERMEDIATE_TBL(J).DRCRIND := 'C';
                ELSE
                  P_INTERMEDIATE_TBL(J).DRCRIND := 'D';
                END IF;
                IF P_INTERMEDIATE_TBL(J).ACC_CCY = GLOBAL.LCY THEN
                  P_INTERMEDIATE_TBL(J).LCY_AMT := ABS(P_INTERMEDIATE_TBL(J)
                                                       .LCY_AMT);
                ELSE
                  P_INTERMEDIATE_TBL(J).FCY_AMT := ABS(P_INTERMEDIATE_TBL(J)
                                                       .FCY_AMT);
                  P_INTERMEDIATE_TBL(J).LCY_AMT := ABS(P_INTERMEDIATE_TBL(J)
                                                       .LCY_AMT);
                END IF;
              END IF;

            END IF;

          END IF;

          IF P_INTERMEDIATE_TBL(J)
           .AMT_TAG = P_AMTTAG_TBL(I).TAG AND
              NVL(P_INTERMEDIATE_TBL(J).SETTLEMENT_FLAG, 'N') != 'Y' AND P_INTERMEDIATE_TBL(J)
             .GLCAT IN ('5', '6') THEN
            DEBUG.PR_DEBUG('BC',
                           'Inside If Statement of Retroed IF 11111111 --> ' || P_AMTTAG_TBL(I)
                           .EXCH_RATE);
            P_INTERMEDIATE_TBL(J).ACC_BRANCH := GLOBAL.CURRENT_BRANCH;
            P_INTERMEDIATE_TBL(J).ACC_CCY := P_INTERMEDIATE_TBL(J).TAG_CCY;
            IF P_INTERMEDIATE_TBL(J).ACC_CCY = GLOBAL.LCY THEN
              P_INTERMEDIATE_TBL(J).LCY_AMT := P_AMTTAG_TBL(I).AMT;
            ELSE
              DEBUG.PR_DEBUG('BC', 'amttag_tbl.ccy != Lcy');
              DEBUG.PR_DEBUG('BC',
                             P_AMTTAG_TBL(I).CCY || ' != ' || GLOBAL.LCY);
              DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
              IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                       GLOBAL.LCY,  --sampath interchanged changes
                                       P_INTERMEDIATE_TBL(J).ACC_CCY,  --sampath interchanged changes
                                       
                                       L_XRATE_TYPE

                                      ,
                                       L_RATE_INDICATOR--'M' --sampath changes

                                      ,
                                       L_EXCH_RATE,
                                       L_RATEFLAG,
                                       P_ERR_CODE) THEN
                L_CCY1 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                L_CCY2 := GLOBAL.LCY;
                RAISE GETRATE_FAILED;
              END IF;
              DEBUG.PR_DEBUG('BC', 'Exch rate is: ' || L_EXCH_RATE);

              DEBUG.PR_DEBUG('BC', 'Calling fn_amt1_to_amt2');
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_INTERMEDIATE_TBL(J).ACC_CCY,
                                            GLOBAL.LCY,
                                            P_AMTTAG_TBL      (I).AMT,
                                            L_EXCH_RATE,
                                            'Y',
                                            L_RET_AMT,
                                            P_ERR_CODE) THEN
                L_CCY1 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                L_CCY2 := GLOBAL.LCY;
                RAISE AMT1_TO_AMT2_FAILED;
              END IF;

              DEBUG.PR_DEBUG('BC', 'fn_amt1_to_amt2 in nui PASSED');
              DEBUG.PR_DEBUG('BC', 'Exch_rate for convsn: ' || L_EXCH_RATE);
              DEBUG.PR_DEBUG('BC',
                             'the converted amount is: ' || L_RET_AMT);
              DEBUG.PR_DEBUG('BC',
                             'the exchange rate is: ' || P_AMTTAG_TBL(I)
                             .EXCH_RATE);
              P_INTERMEDIATE_TBL(J).FCY_AMT := P_AMTTAG_TBL(I).AMT;
              P_AMTTAG_TBL(I).LCY_AMT_EQUIV := L_RET_AMT;
              P_INTERMEDIATE_TBL(J).LCY_AMT := P_AMTTAG_TBL(I).LCY_AMT_EQUIV;
              P_INTERMEDIATE_TBL(J).EXCH_RATE := L_EXCH_RATE;
            END IF;

          END IF;

        END LOOP;
      END IF;
    END LOOP;

    RETURN TRUE;
  EXCEPTION
    WHEN GETRATE_FAILED THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT001';
        P_ERR_PARAMS := L_CCY1 || '~' || L_CCY2 || '~';
      END IF;
      RETURN FALSE;

    WHEN AMT1_TO_AMT2_FAILED THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT002';
        P_ERR_PARAMS := L_CCY1 || '~' || L_CCY2 || '~';
      END IF;
      RETURN FALSE;

    WHEN PROCESS_FAILED THEN
      DEBUG.PR_DEBUG('BC', THIS_FN || ' FAILED');
      RETURN FALSE;

    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC',
                     'fn_process_tbl_for_nui_accts FAILED - ' || SQLERRM);
      RETURN FALSE;

  END FN_PROCESS_TBL_FOR_NUI_ACCTS;

  FUNCTION FN_PROCESS_TBL_FOR_UI_ACCTS(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                                       P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                                       P_MODULE           IN CSTBS_CONTRACT.MODULE_CODE%TYPE,
                                       P_REPLICATE        IN VARCHAR2,
                                       P_TAG_LST          IN VARCHAR2,
                                       P_INTERMEDIATE_TBL IN OUT INTERMEDIATE_TBL_TYPE,
                                       P_AMTTAG_TBL       IN OUT BCPKSS_ICCF2.ICCF_TBL_TYPE,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_TAG_CCY_LST        VARCHAR2(2000) := '';
    L_PAY_RECEIVE_LST    VARCHAR2(2000) := '';
    L_ACC_BRANCH_LST     VARCHAR2(2000) := '';
    L_ACC_LST            VARCHAR2(2000) := '';
    L_ACC_CCY_LST        VARCHAR2(2000) := '';
    L_EXCH_RATE_LST      VARCHAR2(2000) := '';
    L_SETTLEMENT_AMT_LST VARCHAR2(2000) := '';
    L_VDATE_LST          VARCHAR2(2000) := '';
    L_INSTRUMENT_NO_LST  VARCHAR2(2000) := '';
    L_TAG_LST            VARCHAR2(2000) := '';
    ATAG                 VARCHAR2(35);
    L_RATEFLAG           NUMBER;
    L_RET_AMT            BCTBS_ICCF_MASTER.AMT_DUE%TYPE;
    I                    BINARY_INTEGER;
    J                    BINARY_INTEGER;
    L_INDEX              BINARY_INTEGER;
    L_XRATE_TYPE         BCTMS_PRODUCT_MASTER.XRATE_TYPE%TYPE;

    L_EXCH_RATE VARCHAR2(50);

    L_EXCH_RATE_NUM CYTMS_RATES.MID_RATE%TYPE;
    PROCESS_FAILED      EXCEPTION;
    GETRATE_FAILED      EXCEPTION;
    AMT1_TO_AMT2_FAILED EXCEPTION;
    THIS_FN             VARCHAR2(50) := 'BCPKS_ACC_ENTRIES.fn_process_tbl_for_ui_accts';
    L_ACC_BRANCH        VARCHAR2(4);
    L_ACC_CCY           VARCHAR2(4);
    L_TAG_LCY_EXCH_RATE CYTMS_RATES.MID_RATE%TYPE;
    L_CCY1              CFTBS_CONTRACT_INTEREST.CURRENCY%TYPE;
    L_CCY2              CFTBS_CONTRACT_INTEREST.CURRENCY%TYPE;

    L_SETTLEMENT_EXCH_RATE    ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_SETTLEMENT_AMOUNT       ACTBS_HANDOFF.FCY_AMOUNT%TYPE;
    L_LCY_EXCH_RATE           ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_LCY_EQUIVALENT          ACTBS_HANDOFF.LCY_AMOUNT%TYPE;
    L_RELATED_FCY             ACTBS_HANDOFF.AC_CCY%TYPE;
    L_CONTRACT_CCY            ACTBS_HANDOFF.AC_CCY%TYPE;
    L_CHG_AMT_IN_CONTRACT_CCY ACTBS_HANDOFF.FCY_AMOUNT%TYPE;
    L_CHARGE_CCY              ACTBS_HANDOFF.AC_CCY%TYPE;
    L_CHG_AMT_IN_CHARGE_CCY   ACTBS_HANDOFF.FCY_AMOUNT%TYPE;

    L_AMT_TAG           VARCHAR2(35);
    L_LIQD_USING_COLLAT VARCHAR2(1);
    L_COLLAT_ACCOUNT    ISTB_CONTRACTIS.ACCOUNT%TYPE;
    L_EVENT_SEQ_NO      ISTB_CONTRACTIS.EVENT_SEQ_NO%TYPE;

    L_ORG_RATE          VARCHAR2(50);
    L_ORG_EXCH_RATE     CYTMS_RATES.MID_RATE%TYPE;
    L_CUST_NO           STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_ORG_EXCH_RATE_LST VARCHAR2(2000) := '';

    L_AC_OR_GL   STTBS_ACCOUNT.AC_OR_GL%TYPE;
    L_RP_CUST_NO STTBS_ACCOUNT.CUST_NO%TYPE;

    L_PRODUCT_TYPE   LCTMS_PRODUCT_DEFINITION.PRODUCT_TYPE%TYPE;
    L_RATE_INDICATOR CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
    OUTER_I          BINARY_INTEGER;

    L_VIRTUALACC ISTB_CONTRACTIS.UI_ACCOUNT%TYPE;
  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside fn_process_tbl_for_ui_accts');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    DEBUG.PR_DEBUG('BC', 'Calling ISPKSS.fn_fin_referral');

    IF NOT ISPKSS.FN_FIN_REFERRAL(P_BCREFNO,
                                  P_ESN,
                                  L_TAG_LST,
                                  P_REPLICATE,
                                  L_TAG_CCY_LST,
                                  L_PAY_RECEIVE_LST,
                                  L_ACC_BRANCH_LST,
                                  L_ACC_LST,
                                  L_ACC_CCY_LST,
                                  L_EXCH_RATE_LST,
                                  L_SETTLEMENT_AMT_LST,
                                  L_VDATE_LST,
                                  L_INSTRUMENT_NO_LST,
                                  P_ERR_CODE) THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT011';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~';

      END IF;
      DEBUG.PR_DEBUG('BC', 'ISPKSS.fn_fin_referral FAILED' || SQLERRM);
      RAISE PROCESS_FAILED;
    END IF;

    L_ORG_EXCH_RATE_LST := ISPKSS.G_LIST_OF_ORG_EX_RATE;

    DEBUG.PR_DEBUG('BC', 'Printing values returned by fn_fin_referral');

    DEBUG.PR_DEBUG('BC', 'refno: ' || P_BCREFNO);
    DEBUG.PR_DEBUG('BC', 'esn:       ' || P_ESN);
    DEBUG.PR_DEBUG('BC', 'tag:       ' || L_TAG_LST);
    DEBUG.PR_DEBUG('BC', 'replic..:' || P_REPLICATE);
    DEBUG.PR_DEBUG('BC', 'tag_ccy:   ' || L_TAG_CCY_LST);
    DEBUG.PR_DEBUG('BC', 'pay_rec.:' || L_PAY_RECEIVE_LST);
    DEBUG.PR_DEBUG('BC', 'acc_br:    ' || L_ACC_BRANCH_LST);
    DEBUG.PR_DEBUG('BC', 'account:   ' || L_ACC_LST);
    DEBUG.PR_DEBUG('BC', 'acc_ccy:   ' || L_ACC_CCY_LST);
    DEBUG.PR_DEBUG('BC', 'Original exchrate:' || L_ORG_EXCH_RATE_LST);
    DEBUG.PR_DEBUG('BC', 'exchrate:' || L_EXCH_RATE_LST);
    DEBUG.PR_DEBUG('BC', 'sett_amt:' || L_SETTLEMENT_AMT_LST);
    DEBUG.PR_DEBUG('BC', 'vdate: ' || L_VDATE_LST);
    DEBUG.PR_DEBUG('BC', 'instr_no:' || L_INSTRUMENT_NO_LST);
    DEBUG.PR_DEBUG('BC', 'g_event_code is here-->' || G_EVENT_CODE);
    DEBUG.PR_DEBUG('BC', 'Getting xrate_type');

    IF P_MODULE IN ('BC', 'IB') THEN
      BEGIN
        DEBUG.PR_DEBUG('BC', 'Selecting xrate_type from BC table');
        SELECT XRATE_TYPE, PRODUCT_TYPE
          INTO L_XRATE_TYPE, L_PRODUCT_TYPE
          FROM BCTMS_PRODUCT_MASTER
         WHERE PROD_CODE = SUBSTR(P_BCREFNO, 4, 4);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('BC',
                         'Select from BCTMS_PRODUCT_MASTER FAILED ' ||
                         SQLERRM);
          RAISE PROCESS_FAILED;
      END;

    ELSE
      BEGIN
        DEBUG.PR_DEBUG('BC', 'Selecting xrate_type from LC table');
        SELECT EXCHANGE_RATE_TYPE, PRODUCT_TYPE
          INTO L_XRATE_TYPE, L_PRODUCT_TYPE
          FROM LCTMS_PRODUCT_DEFINITION
         WHERE PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('BC',
                         'Select from LCTMS_PRODUCT_DEFINITION FAILED ' ||
                         SQLERRM);
          L_XRATE_TYPE := 'STANDARD';
      END;

    END IF;

    I := 1;

    ATAG := CSPKES_MISC.FN_GETPARAM(L_TAG_LST, I, '~');

    DEBUG.PR_DEBUG('BC', 'Entering loop for processing UI accts');

    WHILE ATAG <> 'EOPL' LOOP
      DEBUG.PR_DEBUG('BC', 'Tag is : ' || ATAG);
      FOR J IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
        IF P_INTERMEDIATE_TBL(J)
         .AMT_TAG = ATAG AND P_INTERMEDIATE_TBL(J).SETTLEMENT_FLAG = 'Y' THEN
          IF ATAG NOT LIKE '%DISC' AND ATAG NOT LIKE '%PREM' THEN

            DEBUG.PR_DEBUG('BC', 'module code  is ==' || P_MODULE);
            DEBUG.PR_DEBUG('BC', 'product type  is ==' || L_PRODUCT_TYPE);

            IF P_MODULE IN ('LC', 'BC', 'IB')

             THEN
              IF NVL(L_PRODUCT_TYPE, 'X') = 'I' THEN

                L_RATE_INDICATOR := 'S';

              ELSIF NVL(L_PRODUCT_TYPE, 'X') = 'E' THEN
                L_RATE_INDICATOR := 'B';
              ELSE
                L_RATE_INDICATOR := 'M';
              END IF;
            ELSE
              L_RATE_INDICATOR := 'M';
            END IF;
            DEBUG.PR_DEBUG('BC', 'l_rate_indicator::' || L_RATE_INDICATOR);

            DEBUG.PR_DEBUG('BC',
                           'Tag is: >>' || P_INTERMEDIATE_TBL(J).AMT_TAG);
            L_ACC_BRANCH := CSPKES_MISC.FN_GETPARAM(L_ACC_BRANCH_LST,
                                                    I,
                                                    '~');
            P_INTERMEDIATE_TBL(J).ACC_BRANCH := L_ACC_BRANCH;
            P_INTERMEDIATE_TBL(J).ACCOUNT := CSPKES_MISC.FN_GETPARAM(L_ACC_LST,
                                                                     I,
                                                                     '~');

            L_ACC_CCY := CSPKES_MISC.FN_GETPARAM(L_ACC_CCY_LST, I, '~');
            P_INTERMEDIATE_TBL(J).ACC_CCY := L_ACC_CCY;

            P_INTERMEDIATE_TBL(J).INSTRUMENT_CODE := LTRIM(RTRIM(CSPKES_MISC.FN_GETPARAM(L_INSTRUMENT_NO_LST,
                                                                                         I,
                                                                                         '~')));
            IF LENGTH(P_INTERMEDIATE_TBL(J).INSTRUMENT_CODE) = 0 THEN
              P_INTERMEDIATE_TBL(J).INSTRUMENT_CODE := P_BCREFNO;
            END IF;

            IF NOT FN_ASSIGN_VIRTUALACC(P_BCREFNO,
                                        P_ESN,
                                        ATAG,
                                        P_INTERMEDIATE_TBL(J).ACCOUNT,
                                        L_VIRTUALACC,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
              DEBUG.PR_DEBUG('BC',
                             'Failed in fn_assign_virtualacc' || P_ERR_CODE ||
                             SQLERRM);
              P_INTERMEDIATE_TBL(J).VIRTUALACNO := NULL;
            ELSE
              P_INTERMEDIATE_TBL(J).VIRTUALACNO := L_VIRTUALACC;
            END IF;

            IF ATAG NOT LIKE '%LIQD' OR
               ATAG NOT IN ('AMT_PURCHASED',
                            'AMT_PURCHASEDEQ',
                            'LOAN_LIQD_AMT',
                            'COLL_LIQ_AMT',
                            'COLL_LIQ_AMTEQ') THEN

              P_INTERMEDIATE_TBL(J).VDATE := CSPKES_MISC.FN_GETPARAM(L_VDATE_LST,
                                                                     I,
                                                                     '~');

            END IF;

            IF P_INTERMEDIATE_TBL(J).VDATE IS NULL THEN

              P_INTERMEDIATE_TBL(J).VDATE := GLOBAL.APPLICATION_DATE;

            END IF;
            DEBUG.PR_DEBUG('BC',
                           'Tag is: ' || ATAG || ' vdate ' || P_INTERMEDIATE_TBL(J)
                           .VDATE);

            IF P_INTERMEDIATE_TBL(J).TAG_CCY = P_INTERMEDIATE_TBL(J).ACC_CCY AND P_INTERMEDIATE_TBL(J)
               .TAG_CCY = GLOBAL.LCY THEN
              DEBUG.PR_DEBUG('BC', 'CASE 1');
              DEBUG.PR_DEBUG('BC', 'Tag_ccy = Acc_ccy = Lcy');
              P_INTERMEDIATE_TBL(J).LCY_AMT := P_INTERMEDIATE_TBL(J).TAG_AMT;
              P_INTERMEDIATE_TBL(J).FCY_AMT := NULL;
              P_INTERMEDIATE_TBL(J).TAG_SETTLEMENT_RATE := 1;
              P_INTERMEDIATE_TBL(J).ORG_EXCH_RATE := 1;
            END IF;

            DEBUG.PR_DEBUG('BC', 'step1-before getting RP details');
            BEGIN
              SELECT AC_OR_GL, CUST_NO
                INTO L_AC_OR_GL, L_RP_CUST_NO
                FROM STTBS_ACCOUNT
               WHERE AC_GL_NO = P_INTERMEDIATE_TBL(J).ACCOUNT
                 AND NVL(BRANCH_CODE, P_INTERMEDIATE_TBL(J).ACC_BRANCH) = P_INTERMEDIATE_TBL(J)
                    .ACC_BRANCH;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DEBUG.PR_DEBUG('BC', 'In no data found' || SQLERRM);
                P_ERR_CODE := 'IS-REF14';
                RETURN FALSE;
            END;

            DEBUG.PR_DEBUG('BC', 'l_ac_or_gl:' || L_AC_OR_GL);
            DEBUG.PR_DEBUG('BC', 'l_rp_cust_no:' || L_RP_CUST_NO);

            IF NVL(L_AC_OR_GL, 'G') = 'A' THEN
              L_CUST_NO := L_RP_CUST_NO;
            ELSE
              L_CUST_NO := NULL;
            END IF;

            IF P_INTERMEDIATE_TBL(J).TAG_CCY = GLOBAL.LCY AND P_INTERMEDIATE_TBL(J)
               .ACC_CCY != GLOBAL.LCY THEN
              DEBUG.PR_DEBUG('BC', 'CASE 2');
              DEBUG.PR_DEBUG('BC', 'Tag_ccy = Lcy AND Acc_ccy != Lcy');
              L_EXCH_RATE := CSPKES_MISC.FN_GETPARAM(L_EXCH_RATE_LST,
                                                     I,
                                                     '~');

              L_ORG_RATE      := CSPKES_MISC.FN_GETPARAM(L_ORG_EXCH_RATE_LST,
                                                         I,
                                                         '~');
              L_ORG_EXCH_RATE := TO_NUMBER(NVL(P_INTERMEDIATE_TBL(J)
                                               .SGEN_XRATE,
                                               L_ORG_RATE));

              L_EXCH_RATE_NUM := TO_NUMBER(NVL(P_INTERMEDIATE_TBL(J)
                                               .SGEN_XRATE,
                                               L_EXCH_RATE));
              L_AMT_TAG       := CSPKES_MISC.FN_GETPARAM(L_TAG_LST, I, '~');
              IF NVL(P_INTERMEDIATE_TBL(J).SGEN_XRATE, L_EXCH_RATE) IS NULL THEN

                DEBUG.PR_DEBUG('BC', 'amount tag here is-->' || L_AMT_TAG);
                IF L_AMT_TAG NOT IN ('LOAN_LIQD_AMT') THEN

                  DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
                  IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                           P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                           P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                           L_XRATE_TYPE,
                                           L_RATE_INDICATOR,
                                           L_EXCH_RATE_NUM,
                                           L_RATEFLAG,
                                           P_ERR_CODE) THEN
                    L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                    L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                    RAISE GETRATE_FAILED;
                  END IF;

                  L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                  IF L_CUST_NO IS NOT NULL THEN

                    DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate1');

                    DEBUG.PR_DEBUG('BC',
                                   'Original p_Exch_Rate:' ||
                                   L_EXCH_RATE_NUM);

                    IF NOT
                        COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                           ,
                                                            L_CUST_NO,
                                                            SUBSTR(P_BCREFNO,
                                                                   4,
                                                                   4),
                                                            NULL,
                                                            P_INTERMEDIATE_TBL(J)
                                                            .TAG_CCY,
                                                            P_INTERMEDIATE_TBL(J)
                                                            .ACC_CCY,
                                                            L_ORG_EXCH_RATE,
                                                            L_EXCH_RATE_NUM,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
                      DEBUG.PR_DEBUG('BC',
                                     'failed to get RP exchange rate ');
                      RAISE GETRATE_FAILED;
                    END IF;

                    DEBUG.PR_DEBUG('BC',
                                   'Post RP l_exch_rate is:' ||
                                   L_EXCH_RATE_NUM);

                  END IF;

                ELSE
                  DEBUG.PR_DEBUG('BC', 'event code is-->' || G_EVENT_CODE);
                  IF G_EVENT_CODE IN ('LIQD', 'LDIS', 'LPUR') THEN
                    DEBUG.PR_DEBUG('BC',
                                   'here the amount tag is loan_liqd_amt11');
                    BEGIN
                      SELECT EX_RATE
                        INTO L_EXCH_RATE_NUM
                        FROM BCTBS_PURCHASE_LIQ_DTLS
                       WHERE BCREFNO = P_BCREFNO
                         AND EVENT_SEQ_NO = P_ESN
                         AND AMOUNT_TAG = 'LOAN_LIQD_AMT';
                      DEBUG.PR_DEBUG('BC',
                                     'here the exchange rate coming 11-->' ||
                                     L_EXCH_RATE_NUM);
                    EXCEPTION
                      WHEN TOO_MANY_ROWS THEN
                        BEGIN
                          DEBUG.PR_DEBUG('BC',
                                         'inside too many rows of the select11');
                          SELECT EX_RATE
                            INTO L_EXCH_RATE_NUM
                            FROM BCTBS_PURCHASE_LIQ_DTLS
                           WHERE BCREFNO = P_BCREFNO
                             AND EVENT_SEQ_NO = P_ESN
                             AND AMOUNT_TAG = 'LOAN_LIQD_AMT'
                             AND ENTRY_SR_NO =
                                 (SELECT MIN(ENTRY_SR_NO)
                                    FROM BCTBS_PURCHASE_LIQ_DTLS
                                   WHERE BCREFNO = P_BCREFNO
                                     AND EVENT_SEQ_NO = P_ESN
                                     AND AMOUNT_TAG = 'LOAN_LIQD_AMT');
                          DEBUG.PR_DEBUG('BC',
                                         'here the exchange rate coming as11-->' ||
                                         L_EXCH_RATE_NUM);
                        EXCEPTION
                          WHEN OTHERS THEN
                            DEBUG.PR_DEBUG('BC',
                                           'inside when others of this select13-->' ||
                                           SQLERRM);
                            DEBUG.PR_DEBUG('BC',
                                           'Calling CYPKSS.fn_getrate');
                            IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                                     P_INTERMEDIATE_TBL   (J)
                                                     .TAG_CCY,
                                                     P_INTERMEDIATE_TBL   (J)
                                                     .ACC_CCY,
                                                     L_XRATE_TYPE,
                                                     'M',
                                                     L_EXCH_RATE_NUM,
                                                     L_RATEFLAG,
                                                     P_ERR_CODE) THEN
                              L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                              L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                              RAISE GETRATE_FAILED;
                            END IF;

                            L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                            IF L_CUST_NO IS NOT NULL THEN

                              DEBUG.PR_DEBUG('BC',
                                             'calling fn_get_rp_rate2');

                              DEBUG.PR_DEBUG('BC',
                                             'Original p_Exch_Rate:' ||
                                             L_EXCH_RATE_NUM);

                              IF NOT
                                  COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                                     ,
                                                                      L_CUST_NO,
                                                                      SUBSTR(P_BCREFNO,
                                                                             4,
                                                                             4),
                                                                      NULL,
                                                                      P_INTERMEDIATE_TBL(J)
                                                                      .TAG_CCY,
                                                                      P_INTERMEDIATE_TBL(J)
                                                                      .ACC_CCY,
                                                                      L_ORG_EXCH_RATE,
                                                                      L_EXCH_RATE_NUM,
                                                                      P_ERR_CODE,
                                                                      P_ERR_PARAMS) THEN
                                DEBUG.PR_DEBUG('BC',
                                               'failed to get RP exchange rate ');
                                RAISE GETRATE_FAILED;
                              END IF;

                              DEBUG.PR_DEBUG('BC',
                                             'Post RP l_exch_rate is:' ||
                                             L_EXCH_RATE_NUM);

                            END IF;

                            DEBUG.PR_DEBUG('BC',
                                           'got th edit rate is11-->' ||
                                           L_EXCH_RATE_NUM);
                        END;
                      WHEN OTHERS THEN
                        DEBUG.PR_DEBUG('BC',
                                       'inside when others again11-->' ||
                                       SQLERRM);
                        DEBUG.PR_DEBUG('BC',
                                       'Calling CYPKSS.fn_getrate1211');
                        DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
                        IF NOT
                            CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                              P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                              P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                              L_XRATE_TYPE,
                                              'M',
                                              L_EXCH_RATE_NUM,
                                              L_RATEFLAG,
                                              P_ERR_CODE) THEN
                          L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                          L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                          RAISE GETRATE_FAILED;
                        END IF;

                        L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                        IF L_CUST_NO IS NOT NULL THEN

                          DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate3');

                          DEBUG.PR_DEBUG('BC',
                                         'Original p_Exch_Rate:' ||
                                         L_EXCH_RATE_NUM);

                          IF NOT
                              COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                                 ,
                                                                  L_CUST_NO,
                                                                  SUBSTR(P_BCREFNO,
                                                                         4,
                                                                         4),
                                                                  NULL,
                                                                  P_INTERMEDIATE_TBL(J)
                                                                  .TAG_CCY,
                                                                  P_INTERMEDIATE_TBL(J)
                                                                  .ACC_CCY,
                                                                  L_ORG_EXCH_RATE,
                                                                  L_EXCH_RATE_NUM,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
                            DEBUG.PR_DEBUG('BC',
                                           'failed to get RP exchange rate ');
                            RAISE GETRATE_FAILED;
                          END IF;

                          DEBUG.PR_DEBUG('BC',
                                         'Post RP l_exch_rate is:' ||
                                         L_EXCH_RATE_NUM);

                        END IF;

                        DEBUG.PR_DEBUG('BC',
                                       'got th edit rate is211-->' ||
                                       L_EXCH_RATE_NUM);

                    END;
                  ELSE
                    DEBUG.PR_DEBUG('BC', 'this is not liquidation');
                    IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                             P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                             P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                             L_XRATE_TYPE,
                                             'M',
                                             L_EXCH_RATE_NUM,
                                             L_RATEFLAG,
                                             P_ERR_CODE) THEN
                      L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                      L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                      RAISE GETRATE_FAILED;
                    END IF;

                    L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                    IF L_CUST_NO IS NOT NULL THEN

                      DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate4');

                      DEBUG.PR_DEBUG('BC',
                                     'Original p_Exch_Rate:' ||
                                     L_EXCH_RATE_NUM);

                      IF NOT
                          COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                             ,
                                                              L_CUST_NO,
                                                              SUBSTR(P_BCREFNO,
                                                                     4,
                                                                     4),
                                                              NULL,
                                                              P_INTERMEDIATE_TBL(J)
                                                              .TAG_CCY,
                                                              P_INTERMEDIATE_TBL(J)
                                                              .ACC_CCY,
                                                              L_ORG_EXCH_RATE,
                                                              L_EXCH_RATE_NUM,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
                        DEBUG.PR_DEBUG('BC',
                                       'failed to get RP exchange rate ');
                        RAISE GETRATE_FAILED;
                      END IF;

                      DEBUG.PR_DEBUG('BC',
                                     'Post RP l_exch_rate is:' ||
                                     L_EXCH_RATE_NUM);

                    END IF;

                    DEBUG.PR_DEBUG('BC',
                                   'exchange rate here is111-->' ||
                                   L_EXCH_RATE_NUM);
                  END IF;
                END IF;

                DEBUG.PR_DEBUG('BC', 'fn_getrate PASSED');
              END IF;
              DEBUG.PR_DEBUG('BC', 'Exch_rate is: ' || L_EXCH_RATE_NUM);
              DEBUG.PR_DEBUG('BC', 'Calling fn_amt1_to_amt2');
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_INTERMEDIATE_TBL(J).TAG_CCY,
                                            P_INTERMEDIATE_TBL(J).ACC_CCY,
                                            P_INTERMEDIATE_TBL(J).TAG_AMT,
                                            L_EXCH_RATE_NUM,
                                            'Y',
                                            L_RET_AMT,
                                            P_ERR_CODE) THEN
                L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                RAISE AMT1_TO_AMT2_FAILED;
              END IF;
              DEBUG.PR_DEBUG('BC', 'fn_amt1_to_amt2 PASSED');
              DEBUG.PR_DEBUG('BC',
                             'Exch_rate for convsn: ' || L_EXCH_RATE_NUM);
              DEBUG.PR_DEBUG('BC', 'Converted amount: ' || L_RET_AMT);
              P_INTERMEDIATE_TBL(J).TAG_SETTLEMENT_RATE := L_EXCH_RATE_NUM;
              P_INTERMEDIATE_TBL(J).EXCH_RATE := L_EXCH_RATE_NUM;
              P_INTERMEDIATE_TBL(J).LCY_AMT := P_INTERMEDIATE_TBL(J).TAG_AMT;
              P_INTERMEDIATE_TBL(J).FCY_AMT := L_RET_AMT;

              P_INTERMEDIATE_TBL(J).ORG_EXCH_RATE := NVL(L_ORG_EXCH_RATE,
                                                         L_EXCH_RATE_NUM);

            END IF;

            IF P_INTERMEDIATE_TBL(J)
             .TAG_CCY != GLOBAL.LCY AND P_INTERMEDIATE_TBL(J)
               .ACC_CCY != GLOBAL.LCY AND P_INTERMEDIATE_TBL(J)
               .TAG_CCY != P_INTERMEDIATE_TBL(J).ACC_CCY THEN
              DEBUG.PR_DEBUG('BC', 'CASE 3');
              DEBUG.PR_DEBUG('BC',
                             'Tag_ccy != Lcy AND Acc_ccy != Lcy AND ' ||
                             'Tag_ccy != Acc_ccy');
              L_EXCH_RATE := CSPKES_MISC.FN_GETPARAM(L_EXCH_RATE_LST,
                                                     I,
                                                     '~');

              IF P_INTERMEDIATE_TBL(J).TAG_CCY <> P_INTERMEDIATE_TBL(J)
                 .ACC_CCY AND L_EXCH_RATE = 1 THEN
                L_EXCH_RATE := NULL;
              END IF;

              L_ORG_RATE      := CSPKES_MISC.FN_GETPARAM(L_ORG_EXCH_RATE_LST,
                                                         I,
                                                         '~');
              L_ORG_EXCH_RATE := TO_NUMBER(NVL(P_INTERMEDIATE_TBL(J)
                                               .SGEN_XRATE,
                                               L_ORG_RATE));

              L_EXCH_RATE_NUM := TO_NUMBER(NVL(P_INTERMEDIATE_TBL(J)
                                               .SGEN_XRATE,
                                               L_EXCH_RATE));
              L_AMT_TAG       := CSPKES_MISC.FN_GETPARAM(L_TAG_LST, I, '~');
              IF NVL(P_INTERMEDIATE_TBL(J).SGEN_XRATE, L_EXCH_RATE) IS NULL THEN

                DEBUG.PR_DEBUG('BC',
                               'amount tag here is11-->' || L_AMT_TAG);
                IF L_AMT_TAG NOT IN ('LOAN_LIQD_AMT') THEN

                  DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
                  IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                           P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                           P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                           L_XRATE_TYPE,
                                           'M',
                                           L_EXCH_RATE_NUM,
                                           L_RATEFLAG,
                                           P_ERR_CODE) THEN
                    L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                    L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                    RAISE GETRATE_FAILED;
                  END IF;

                  L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                  IF L_CUST_NO IS NOT NULL THEN

                    DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate5');

                    DEBUG.PR_DEBUG('BC',
                                   'Original p_Exch_Rate:' ||
                                   L_EXCH_RATE_NUM);

                    IF NOT
                        COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                           ,
                                                            L_CUST_NO,
                                                            SUBSTR(P_BCREFNO,
                                                                   4,
                                                                   4),
                                                            NULL,
                                                            P_INTERMEDIATE_TBL(J)
                                                            .TAG_CCY,
                                                            P_INTERMEDIATE_TBL(J)
                                                            .ACC_CCY,
                                                            L_ORG_EXCH_RATE,
                                                            L_EXCH_RATE_NUM,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
                      DEBUG.PR_DEBUG('BC',
                                     'failed to get RP exchange rate ');
                      RAISE GETRATE_FAILED;
                    END IF;

                    DEBUG.PR_DEBUG('BC',
                                   'Post RP l_exch_rate is:' ||
                                   L_EXCH_RATE_NUM);

                  END IF;

                ELSE
                  DEBUG.PR_DEBUG('BC',
                                 'g_event_code is111-->' || G_EVENT_CODE);
                  IF G_EVENT_CODE IN ('LIQD', 'LDIS', 'LPUR') THEN
                    DEBUG.PR_DEBUG('BC',
                                   'here the amount tag is loan_liqd_amt33');
                    BEGIN
                      SELECT EX_RATE
                        INTO L_EXCH_RATE_NUM
                        FROM BCTBS_PURCHASE_LIQ_DTLS
                       WHERE BCREFNO = P_BCREFNO
                         AND EVENT_SEQ_NO = P_ESN
                         AND AMOUNT_TAG = 'LOAN_LIQD_AMT';
                      DEBUG.PR_DEBUG('BC',
                                     'here the exchange rate coming 33-->' ||
                                     L_EXCH_RATE_NUM);
                    EXCEPTION
                      WHEN TOO_MANY_ROWS THEN
                        BEGIN
                          DEBUG.PR_DEBUG('BC',
                                         'inside too many rows of the select33');
                          SELECT EX_RATE
                            INTO L_EXCH_RATE_NUM
                            FROM BCTBS_PURCHASE_LIQ_DTLS
                           WHERE BCREFNO = P_BCREFNO
                             AND EVENT_SEQ_NO = P_ESN
                             AND AMOUNT_TAG = 'LOAN_LIQD_AMT'
                             AND ENTRY_SR_NO =
                                 (SELECT MIN(ENTRY_SR_NO)
                                    FROM BCTBS_PURCHASE_LIQ_DTLS
                                   WHERE BCREFNO = P_BCREFNO
                                     AND EVENT_SEQ_NO = P_ESN
                                     AND AMOUNT_TAG = 'LOAN_LIQD_AMT');
                          DEBUG.PR_DEBUG('BC',
                                         'here the exchange rate coming as33-->' ||
                                         L_EXCH_RATE_NUM);
                        EXCEPTION
                          WHEN OTHERS THEN
                            DEBUG.PR_DEBUG('BC',
                                           'inside when others of this select33-->' ||
                                           SQLERRM);
                            DEBUG.PR_DEBUG('BC',
                                           'Calling CYPKSS.fn_getrate');
                            IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                                     P_INTERMEDIATE_TBL   (J)
                                                     .TAG_CCY,
                                                     P_INTERMEDIATE_TBL   (J)
                                                     .ACC_CCY,
                                                     L_XRATE_TYPE,
                                                     'M',
                                                     L_EXCH_RATE_NUM,
                                                     L_RATEFLAG,
                                                     P_ERR_CODE) THEN
                              L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                              L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                              RAISE GETRATE_FAILED;
                            END IF;

                            L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                            IF L_CUST_NO IS NOT NULL THEN

                              DEBUG.PR_DEBUG('BC',
                                             'calling fn_get_rp_rate6');

                              DEBUG.PR_DEBUG('BC',
                                             'Original p_Exch_Rate:' ||
                                             L_EXCH_RATE_NUM);

                              IF NOT
                                  COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                                     ,
                                                                      L_CUST_NO,
                                                                      SUBSTR(P_BCREFNO,
                                                                             4,
                                                                             4),
                                                                      NULL,
                                                                      P_INTERMEDIATE_TBL(J)
                                                                      .TAG_CCY,
                                                                      P_INTERMEDIATE_TBL(J)
                                                                      .ACC_CCY,
                                                                      L_ORG_EXCH_RATE,
                                                                      L_EXCH_RATE_NUM,
                                                                      P_ERR_CODE,
                                                                      P_ERR_PARAMS) THEN
                                DEBUG.PR_DEBUG('BC',
                                               'failed to get RP exchange rate ');
                                RAISE GETRATE_FAILED;
                              END IF;

                              DEBUG.PR_DEBUG('BC',
                                             'Post RP l_exch_rate is:' ||
                                             L_EXCH_RATE_NUM);

                            END IF;

                            DEBUG.PR_DEBUG('BC',
                                           'got th edit rate is33-->' ||
                                           L_EXCH_RATE_NUM);
                        END;
                      WHEN OTHERS THEN
                        DEBUG.PR_DEBUG('BC',
                                       'inside when others again33-->' ||
                                       SQLERRM);
                        DEBUG.PR_DEBUG('BC',
                                       'Calling CYPKSS.fn_getrate1233');
                        DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
                        IF NOT
                            CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                              P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                              P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                              L_XRATE_TYPE,
                                              'M',
                                              L_EXCH_RATE_NUM,
                                              L_RATEFLAG,
                                              P_ERR_CODE) THEN
                          L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                          L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                          RAISE GETRATE_FAILED;
                        END IF;

                        L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;

                        IF L_CUST_NO IS NOT NULL THEN

                          DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate7');

                          DEBUG.PR_DEBUG('BC',
                                         'Original p_Exch_Rate:' ||
                                         L_EXCH_RATE_NUM);

                          IF NOT
                              COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                                 ,
                                                                  L_CUST_NO,
                                                                  SUBSTR(P_BCREFNO,
                                                                         4,
                                                                         4),
                                                                  NULL,
                                                                  P_INTERMEDIATE_TBL(J)
                                                                  .TAG_CCY,
                                                                  P_INTERMEDIATE_TBL(J)
                                                                  .ACC_CCY,
                                                                  L_ORG_EXCH_RATE,
                                                                  L_EXCH_RATE_NUM,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
                            DEBUG.PR_DEBUG('BC',
                                           'failed to get RP exchange rate ');
                            RAISE GETRATE_FAILED;
                          END IF;

                          DEBUG.PR_DEBUG('BC',
                                         'Post RP l_exch_rate is:' ||
                                         L_EXCH_RATE_NUM);

                        END IF;

                        DEBUG.PR_DEBUG('BC',
                                       'got th edit rate is233-->' ||
                                       L_EXCH_RATE_NUM);

                    END;
                  ELSE
                    DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate6666');
                    IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                             P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                             P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                             L_XRATE_TYPE,
                                             'M',
                                             L_EXCH_RATE_NUM,
                                             L_RATEFLAG,
                                             P_ERR_CODE) THEN
                      L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                      L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                      RAISE GETRATE_FAILED;
                    END IF;

                    L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                    IF L_CUST_NO IS NOT NULL THEN

                      DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate8');

                      DEBUG.PR_DEBUG('BC',
                                     'Original p_Exch_Rate:' ||
                                     L_EXCH_RATE_NUM);

                      IF NOT
                          COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                             ,
                                                              L_CUST_NO,
                                                              SUBSTR(P_BCREFNO,
                                                                     4,
                                                                     4),
                                                              NULL,
                                                              P_INTERMEDIATE_TBL(J)
                                                              .TAG_CCY,
                                                              P_INTERMEDIATE_TBL(J)
                                                              .ACC_CCY,
                                                              L_ORG_EXCH_RATE,
                                                              L_EXCH_RATE_NUM,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
                        DEBUG.PR_DEBUG('BC',
                                       'failed to get RP exchange rate ');
                        RAISE GETRATE_FAILED;
                      END IF;

                      DEBUG.PR_DEBUG('BC',
                                     'Post RP l_exch_rate is:' ||
                                     L_EXCH_RATE_NUM);

                    END IF;

                    DEBUG.PR_DEBUG('BC',
                                   'here the rate is111111-->' ||
                                   L_EXCH_RATE_NUM);

                  END IF;
                END IF;

                DEBUG.PR_DEBUG('BC', 'exch_rate is: ' || L_EXCH_RATE_NUM);
                DEBUG.PR_DEBUG('BC', 'fn_getrate PASSED');
              END IF;
              DEBUG.PR_DEBUG('BC', 'Calling fn_amt1_to_amt2');
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_INTERMEDIATE_TBL(J).TAG_CCY,
                                            P_INTERMEDIATE_TBL(J).ACC_CCY,
                                            P_INTERMEDIATE_TBL(J).TAG_AMT,
                                            L_EXCH_RATE_NUM,
                                            'Y',
                                            L_RET_AMT,
                                            P_ERR_CODE) THEN
                L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                RAISE AMT1_TO_AMT2_FAILED;
              END IF;

              DEBUG.PR_DEBUG('BC', 'fn_amt1_to_amt2 PASSED');
              DEBUG.PR_DEBUG('BC',
                             'Exch_rate for convsn: ' || L_EXCH_RATE_NUM);
              DEBUG.PR_DEBUG('BC', 'Converted amount: ' || L_RET_AMT);

              P_INTERMEDIATE_TBL(J).TAG_SETTLEMENT_RATE := L_EXCH_RATE_NUM;
              P_INTERMEDIATE_TBL(J).FCY_AMT := L_RET_AMT;

              P_INTERMEDIATE_TBL(J).ORG_EXCH_RATE := NVL(L_ORG_EXCH_RATE,
                                                         L_EXCH_RATE_NUM);

              DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
              IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                       GLOBAL.LCY,
                                       P_INTERMEDIATE_TBL(J).ACC_CCY,
                                       L_XRATE_TYPE,
                                       L_RATE_INDICATOR,
                                       L_EXCH_RATE_NUM,
                                       L_RATEFLAG,
                                       P_ERR_CODE) THEN
                L_CCY1 := GLOBAL.LCY;
                L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                RAISE GETRATE_FAILED;
              END IF;

              L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
              IF L_CUST_NO IS NOT NULL THEN

                DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate9');

                DEBUG.PR_DEBUG('BC',
                               'Original p_Exch_Rate:' || L_EXCH_RATE_NUM);

                IF NOT COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                          ,
                                                           L_CUST_NO,
                                                           SUBSTR(P_BCREFNO,
                                                                  4,
                                                                  4),
                                                           NULL,
                                                           GLOBAL.LCY,
                                                           P_INTERMEDIATE_TBL(J)
                                                           .ACC_CCY,
                                                           L_ORG_EXCH_RATE,
                                                           L_EXCH_RATE_NUM,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
                  DEBUG.PR_DEBUG('BC', 'failed to get RP exchange rate ');
                  RAISE GETRATE_FAILED;
                END IF;

                DEBUG.PR_DEBUG('BC',
                               'Post RP l_exch_rate is:' || L_EXCH_RATE_NUM);

              END IF;

              DEBUG.PR_DEBUG('BC', 'fn_getrate PASSED');
              DEBUG.PR_DEBUG('BC', 'exch_rate is: ' || L_EXCH_RATE_NUM);
              DEBUG.PR_DEBUG('BC', 'Calling fn_amt1_to_amt2');

              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_INTERMEDIATE_TBL(J).ACC_CCY,
                                            GLOBAL.LCY,
                                            P_INTERMEDIATE_TBL(J).FCY_AMT,
                                            L_EXCH_RATE_NUM,
                                            'Y',
                                            L_RET_AMT,
                                            P_ERR_CODE) THEN
                L_CCY1 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                L_CCY2 := GLOBAL.LCY;
                RAISE AMT1_TO_AMT2_FAILED;
              END IF;

              DEBUG.PR_DEBUG('BC', 'fn_amt1_to_amt2 PASSED');
              DEBUG.PR_DEBUG('BC',
                             'Exch_rate for convsn: ' || L_EXCH_RATE_NUM);
              DEBUG.PR_DEBUG('BC', 'Converted amount: ' || L_RET_AMT);

              P_INTERMEDIATE_TBL(J).LCY_AMT := L_RET_AMT;
              P_INTERMEDIATE_TBL(J).EXCH_RATE := L_EXCH_RATE_NUM;

            END IF;

            IF P_INTERMEDIATE_TBL(J).TAG_CCY = P_INTERMEDIATE_TBL(J).ACC_CCY AND P_INTERMEDIATE_TBL(J)
               .TAG_CCY != GLOBAL.LCY THEN

              DEBUG.PR_DEBUG('BC', 'CASE 4');
              DEBUG.PR_DEBUG('BC', 'Tag_ccy = Acc_ccy AND Tag_ccy != Lcy');

              P_INTERMEDIATE_TBL(J).FCY_AMT := P_INTERMEDIATE_TBL(J).TAG_AMT;
              L_EXCH_RATE := CSPKES_MISC.FN_GETPARAM(L_EXCH_RATE_LST,
                                                     I,
                                                     '~');

              L_ORG_RATE      := CSPKES_MISC.FN_GETPARAM(L_ORG_EXCH_RATE_LST,
                                                         I,
                                                         '~');
              L_ORG_EXCH_RATE := TO_NUMBER(NVL(P_INTERMEDIATE_TBL(J)
                                               .SGEN_XRATE,
                                               L_ORG_RATE));

              L_EXCH_RATE_NUM := TO_NUMBER(L_EXCH_RATE);
              L_AMT_TAG       := CSPKES_MISC.FN_GETPARAM(L_TAG_LST, I, '~');

              IF L_EXCH_RATE IS NULL OR L_EXCH_RATE_NUM = 1

               THEN

                DEBUG.PR_DEBUG('BC', 'amount tag here is-->' || L_AMT_TAG);

                IF L_AMT_TAG NOT IN ('LOAN_LIQD_AMT') THEN

                  DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
                  IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH

                                          ,
                                           P_INTERMEDIATE_TBL(J).ACC_CCY,
                                           GLOBAL.LCY

                                          ,
                                           L_XRATE_TYPE

                                          ,
                                           'M'

                                          ,
                                           L_EXCH_RATE_NUM,
                                           L_RATEFLAG,
                                           P_ERR_CODE) THEN
                    L_CCY1 := GLOBAL.LCY;
                    L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                    RAISE GETRATE_FAILED;
                  END IF;

                  L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                  IF L_CUST_NO IS NOT NULL THEN

                    DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate10');

                    DEBUG.PR_DEBUG('BC',
                                   'Original p_Exch_Rate:' ||
                                   L_EXCH_RATE_NUM);

                    IF NOT
                        COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                           ,
                                                            L_CUST_NO,
                                                            SUBSTR(P_BCREFNO,
                                                                   4,
                                                                   4),
                                                            NULL,
                                                            GLOBAL.LCY,
                                                            P_INTERMEDIATE_TBL(J)
                                                            .ACC_CCY,
                                                            L_ORG_EXCH_RATE,
                                                            L_EXCH_RATE_NUM,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
                      DEBUG.PR_DEBUG('BC',
                                     'failed to get RP exchange rate ');
                      RAISE GETRATE_FAILED;
                    END IF;

                    DEBUG.PR_DEBUG('BC',
                                   'Post RP l_exch_rate is:' ||
                                   L_EXCH_RATE_NUM);

                  END IF;

                ELSE
                  DEBUG.PR_DEBUG('BC',
                                 'here the amount tag is loan_liqd_amt');
                  DEBUG.PR_DEBUG('BC',
                                 'g_event_code is222-->' || G_EVENT_CODE);
                  IF G_EVENT_CODE IN ('LIQD', 'LDIS', 'LPUR') THEN
                    BEGIN
                      SELECT EX_RATE
                        INTO L_EXCH_RATE_NUM
                        FROM BCTBS_PURCHASE_LIQ_DTLS
                       WHERE BCREFNO = P_BCREFNO
                         AND EVENT_SEQ_NO = P_ESN
                         AND AMOUNT_TAG = 'LOAN_LIQD_AMT';
                      DEBUG.PR_DEBUG('BC',
                                     'here the exchange rate coming as-->' ||
                                     L_EXCH_RATE_NUM);
                    EXCEPTION
                      WHEN TOO_MANY_ROWS THEN
                        BEGIN
                          DEBUG.PR_DEBUG('BC',
                                         'inside too many rows of the select');
                          SELECT EX_RATE
                            INTO L_EXCH_RATE_NUM
                            FROM BCTBS_PURCHASE_LIQ_DTLS
                           WHERE BCREFNO = P_BCREFNO
                             AND EVENT_SEQ_NO = P_ESN
                             AND AMOUNT_TAG = 'LOAN_LIQD_AMT'
                             AND ENTRY_SR_NO =
                                 (SELECT MIN(ENTRY_SR_NO)
                                    FROM BCTBS_PURCHASE_LIQ_DTLS
                                   WHERE BCREFNO = P_BCREFNO
                                     AND EVENT_SEQ_NO = P_ESN
                                     AND AMOUNT_TAG = 'LOAN_LIQD_AMT');
                          DEBUG.PR_DEBUG('BC',
                                         'here the exchange rate coming as1-->' ||
                                         L_EXCH_RATE_NUM);
                        EXCEPTION
                          WHEN OTHERS THEN
                            DEBUG.PR_DEBUG('BC',
                                           'inside when others of this select12-->' ||
                                           SQLERRM);
                            IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                                     GLOBAL.LCY,
                                                     P_INTERMEDIATE_TBL(J)
                                                     .ACC_CCY,
                                                     L_XRATE_TYPE,
                                                     'M',
                                                     L_EXCH_RATE_NUM,
                                                     L_RATEFLAG,
                                                     P_ERR_CODE) THEN
                              L_CCY1 := GLOBAL.LCY;
                              L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                              RAISE GETRATE_FAILED;
                            END IF;

                            L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                            IF L_CUST_NO IS NOT NULL THEN

                              DEBUG.PR_DEBUG('BC',
                                             'calling fn_get_rp_rate11');

                              DEBUG.PR_DEBUG('BC',
                                             'Original p_Exch_Rate:' ||
                                             L_EXCH_RATE_NUM);

                              IF NOT
                                  COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                                     ,
                                                                      L_CUST_NO,
                                                                      SUBSTR(P_BCREFNO,
                                                                             4,
                                                                             4),
                                                                      NULL,
                                                                      GLOBAL.LCY,
                                                                      P_INTERMEDIATE_TBL(J)
                                                                      .ACC_CCY,
                                                                      L_ORG_EXCH_RATE,
                                                                      L_EXCH_RATE_NUM,
                                                                      P_ERR_CODE,
                                                                      P_ERR_PARAMS) THEN
                                DEBUG.PR_DEBUG('BC',
                                               'failed to get RP exchange rate ');
                                RAISE GETRATE_FAILED;
                              END IF;

                              DEBUG.PR_DEBUG('BC',
                                             'Post RP l_exch_rate is:' ||
                                             L_EXCH_RATE_NUM);

                            END IF;

                            DEBUG.PR_DEBUG('BC',
                                           'got th edit rate is-->' ||
                                           L_EXCH_RATE_NUM);
                        END;
                      WHEN OTHERS THEN
                        DEBUG.PR_DEBUG('BC',
                                       'inside when others again-->' ||
                                       SQLERRM);
                        DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate12');
                        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                                 GLOBAL.LCY,
                                                 P_INTERMEDIATE_TBL(J).ACC_CCY,
                                                 L_XRATE_TYPE,
                                                 'M',
                                                 L_EXCH_RATE_NUM,
                                                 L_RATEFLAG,
                                                 P_ERR_CODE) THEN
                          L_CCY1 := GLOBAL.LCY;
                          L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                          RAISE GETRATE_FAILED;
                        END IF;

                        L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                        IF L_CUST_NO IS NOT NULL THEN

                          DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate12');

                          DEBUG.PR_DEBUG('BC',
                                         'Original p_Exch_Rate:' ||
                                         L_EXCH_RATE_NUM);

                          IF NOT
                              COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                                 ,
                                                                  L_CUST_NO,
                                                                  SUBSTR(P_BCREFNO,
                                                                         4,
                                                                         4),
                                                                  NULL,
                                                                  GLOBAL.LCY,
                                                                  P_INTERMEDIATE_TBL(J)
                                                                  .ACC_CCY,
                                                                  L_ORG_EXCH_RATE,
                                                                  L_EXCH_RATE_NUM,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
                            DEBUG.PR_DEBUG('BC',
                                           'failed to get RP exchange rate ');
                            RAISE GETRATE_FAILED;
                          END IF;

                          DEBUG.PR_DEBUG('BC',
                                         'Post RP l_exch_rate is:' ||
                                         L_EXCH_RATE_NUM);

                        END IF;

                        DEBUG.PR_DEBUG('BC',
                                       'got th edit rate is2-->' ||
                                       L_EXCH_RATE_NUM);

                    END;
                  ELSE
                    DEBUG.PR_DEBUG('BC', 'this is not liquidation888');
                    DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate12');
                    IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                             GLOBAL.LCY,
                                             P_INTERMEDIATE_TBL(J).ACC_CCY,
                                             L_XRATE_TYPE,
                                             'M',
                                             L_EXCH_RATE_NUM,
                                             L_RATEFLAG,
                                             P_ERR_CODE) THEN
                      L_CCY1 := GLOBAL.LCY;
                      L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                      RAISE GETRATE_FAILED;
                    END IF;

                    L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                    IF L_CUST_NO IS NOT NULL THEN

                      DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate13');

                      DEBUG.PR_DEBUG('BC',
                                     'Original p_Exch_Rate:' ||
                                     L_EXCH_RATE_NUM);

                      IF NOT
                          COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                             ,
                                                              L_CUST_NO,
                                                              SUBSTR(P_BCREFNO,
                                                                     4,
                                                                     4),
                                                              NULL,
                                                              GLOBAL.LCY,
                                                              P_INTERMEDIATE_TBL(J)
                                                              .ACC_CCY,
                                                              L_ORG_EXCH_RATE,
                                                              L_EXCH_RATE_NUM,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
                        DEBUG.PR_DEBUG('BC',
                                       'failed to get RP exchange rate ');
                        RAISE GETRATE_FAILED;
                      END IF;

                      DEBUG.PR_DEBUG('BC',
                                     'Post RP l_exch_rate is:' ||
                                     L_EXCH_RATE_NUM);

                    END IF;

                    DEBUG.PR_DEBUG('BC',
                                   'coming exchange rate is-->' ||
                                   L_EXCH_RATE_NUM);
                  END IF;
                END IF;

              END IF;

              DEBUG.PR_DEBUG('BC',
                             'fn_getrate PASSED l_exch_rate_num-->' ||
                             L_EXCH_RATE_NUM);
              DEBUG.PR_DEBUG('BC', 'fn_getrate PASSED');
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_INTERMEDIATE_TBL(J).ACC_CCY,
                                            GLOBAL.LCY,
                                            P_INTERMEDIATE_TBL(J).TAG_AMT,
                                            L_EXCH_RATE_NUM,
                                            'Y',
                                            L_RET_AMT,
                                            P_ERR_CODE) THEN
                L_CCY1 := GLOBAL.LCY;
                L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                RAISE AMT1_TO_AMT2_FAILED;
              END IF;

              DEBUG.PR_DEBUG('BC', 'fn_amt1_to_amt2 PASSED');
              DEBUG.PR_DEBUG('BC',
                             'Exch_rate for convsn: ' || L_EXCH_RATE_NUM);
              DEBUG.PR_DEBUG('BC', 'Converted amount: ' || L_RET_AMT);
              P_INTERMEDIATE_TBL(J).TAG_SETTLEMENT_RATE := 1;
              P_INTERMEDIATE_TBL(J).EXCH_RATE := L_EXCH_RATE_NUM;
              P_INTERMEDIATE_TBL(J).LCY_AMT := L_RET_AMT;

              P_INTERMEDIATE_TBL(J).ORG_EXCH_RATE := 1;

            END IF;

            IF P_INTERMEDIATE_TBL(J).TAG_CCY != GLOBAL.LCY AND P_INTERMEDIATE_TBL(J)
               .ACC_CCY = GLOBAL.LCY THEN
              DEBUG.PR_DEBUG('BC', 'CASE 5');
              DEBUG.PR_DEBUG('BC', 'Tag_ccy != Lcy AND Acc_ccy = Lcy');
              L_EXCH_RATE := CSPKES_MISC.FN_GETPARAM(L_EXCH_RATE_LST,
                                                     I,
                                                     '~');

              L_ORG_RATE      := CSPKES_MISC.FN_GETPARAM(L_ORG_EXCH_RATE_LST,
                                                         I,
                                                         '~');
              L_ORG_EXCH_RATE := TO_NUMBER(NVL(P_INTERMEDIATE_TBL(J)
                                               .SGEN_XRATE,
                                               L_ORG_RATE));

              L_EXCH_RATE_NUM := TO_NUMBER(NVL(P_INTERMEDIATE_TBL(J)
                                               .SGEN_XRATE,
                                               L_EXCH_RATE));
              DEBUG.PR_DEBUG('BC',
                             'exch_rate got from fin_referral is:' ||
                             L_EXCH_RATE || ' i: ' || I);
              L_AMT_TAG := CSPKES_MISC.FN_GETPARAM(L_TAG_LST, I, '~');
              IF NVL(P_INTERMEDIATE_TBL(J).SGEN_XRATE, L_EXCH_RATE) IS NULL THEN

                DEBUG.PR_DEBUG('BC', 'amount tag here is-->' || L_AMT_TAG);
                IF L_AMT_TAG NOT IN ('LOAN_LIQD_AMT') THEN

                  DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
                  IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                           P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                           P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                           L_XRATE_TYPE,
                                           'M',
                                           L_EXCH_RATE_NUM,
                                           L_RATEFLAG,
                                           P_ERR_CODE) THEN
                    L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                    L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                    RAISE GETRATE_FAILED;
                  ELSE

                    DEBUG.PR_DEBUG('BC',
                                   'CYPKSS.fn_getRate returned ' ||
                                   L_EXCH_RATE_NUM);
                  END IF;

                  L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                  IF L_CUST_NO IS NOT NULL THEN

                    DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate14');

                    DEBUG.PR_DEBUG('BC',
                                   'Original p_Exch_Rate:' ||
                                   L_EXCH_RATE_NUM);

                    IF NOT
                        COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                           ,
                                                            L_CUST_NO,
                                                            SUBSTR(P_BCREFNO,
                                                                   4,
                                                                   4),
                                                            NULL,
                                                            GLOBAL.LCY,
                                                            P_INTERMEDIATE_TBL(J)
                                                            .ACC_CCY,
                                                            L_ORG_EXCH_RATE,
                                                            L_EXCH_RATE_NUM,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
                      DEBUG.PR_DEBUG('BC',
                                     'failed to get RP exchange rate ');
                      RAISE GETRATE_FAILED;
                    END IF;

                    DEBUG.PR_DEBUG('BC',
                                   'Post RP l_exch_rate is:' ||
                                   L_EXCH_RATE_NUM);

                  END IF;
                  DEBUG.PR_DEBUG('BC', 'fn_getrate PASSED');

                ELSE
                  DEBUG.PR_DEBUG('BC',
                                 'now g_event_code is-->' || G_EVENT_CODE);
                  IF G_EVENT_CODE IN ('LIQD', 'LDIS', 'LPUR') THEN
                    DEBUG.PR_DEBUG('BC',
                                   'here the amount tag is loan_liqd_amt');
                    BEGIN
                      SELECT EX_RATE
                        INTO L_EXCH_RATE_NUM
                        FROM BCTBS_PURCHASE_LIQ_DTLS
                       WHERE BCREFNO = P_BCREFNO
                         AND EVENT_SEQ_NO = P_ESN
                         AND AMOUNT_TAG = 'LOAN_LIQD_AMT';
                      DEBUG.PR_DEBUG('BC',
                                     'here the exchange rate coming as-->' ||
                                     L_EXCH_RATE_NUM);
                    EXCEPTION
                      WHEN TOO_MANY_ROWS THEN
                        BEGIN
                          DEBUG.PR_DEBUG('BC',
                                         'inside too many rows of the select');
                          SELECT EX_RATE
                            INTO L_EXCH_RATE_NUM
                            FROM BCTBS_PURCHASE_LIQ_DTLS
                           WHERE BCREFNO = P_BCREFNO
                             AND EVENT_SEQ_NO = P_ESN
                             AND AMOUNT_TAG = 'LOAN_LIQD_AMT'
                             AND ENTRY_SR_NO =
                                 (SELECT MIN(ENTRY_SR_NO)
                                    FROM BCTBS_PURCHASE_LIQ_DTLS
                                   WHERE BCREFNO = P_BCREFNO
                                     AND EVENT_SEQ_NO = P_ESN
                                     AND AMOUNT_TAG = 'LOAN_LIQD_AMT');
                          DEBUG.PR_DEBUG('BC',
                                         'here the exchange rate coming as1-->' ||
                                         L_EXCH_RATE_NUM);
                        EXCEPTION
                          WHEN OTHERS THEN
                            DEBUG.PR_DEBUG('BC',
                                           'inside when others of this select12-->' ||
                                           SQLERRM);
                            DEBUG.PR_DEBUG('BC',
                                           'Calling CYPKSS.fn_getrate');
                            DEBUG.PR_DEBUG('BC',
                                           'Calling CYPKSS.fn_getrate');
                            IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                                     P_INTERMEDIATE_TBL   (J)
                                                     .TAG_CCY,
                                                     P_INTERMEDIATE_TBL   (J)
                                                     .ACC_CCY,
                                                     L_XRATE_TYPE,
                                                     'M',
                                                     L_EXCH_RATE_NUM,
                                                     L_RATEFLAG,
                                                     P_ERR_CODE) THEN
                              L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                              L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                              RAISE GETRATE_FAILED;
                            ELSE
                              DEBUG.PR_DEBUG('BC',
                                             'CYPKSS.fn_getRate returned ' ||
                                             L_EXCH_RATE_NUM);
                            END IF;

                            L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                            IF L_CUST_NO IS NOT NULL THEN

                              DEBUG.PR_DEBUG('BC',
                                             'calling fn_get_rp_rate15');

                              DEBUG.PR_DEBUG('BC',
                                             'Original p_Exch_Rate:' ||
                                             L_EXCH_RATE_NUM);

                              IF COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                                    ,
                                                                     L_CUST_NO,
                                                                     SUBSTR(P_BCREFNO,
                                                                            4,
                                                                            4),
                                                                     NULL,
                                                                     P_INTERMEDIATE_TBL(J)
                                                                     .TAG_CCY,
                                                                     P_INTERMEDIATE_TBL(J)
                                                                     .ACC_CCY,
                                                                     L_ORG_EXCH_RATE,
                                                                     L_EXCH_RATE_NUM,
                                                                     P_ERR_CODE,
                                                                     P_ERR_PARAMS) THEN
                                DEBUG.PR_DEBUG('BC',
                                               'failed to get RP exchange rate ');
                                RAISE GETRATE_FAILED;
                              END IF;

                              DEBUG.PR_DEBUG('BC',
                                             'Post RP l_exch_rate is:' ||
                                             L_EXCH_RATE_NUM);

                            END IF;

                            DEBUG.PR_DEBUG('BC',
                                           'got th edit rate is-->' ||
                                           L_EXCH_RATE_NUM);
                        END;
                      WHEN OTHERS THEN
                        DEBUG.PR_DEBUG('BC',
                                       'inside when others again-->' ||
                                       SQLERRM);
                        DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate12');
                        DEBUG.PR_DEBUG('BC', 'Calling CYPKSS.fn_getrate');
                        IF NOT
                            CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                              P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                              P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                              L_XRATE_TYPE,
                                              'M',
                                              L_EXCH_RATE_NUM,
                                              L_RATEFLAG,
                                              P_ERR_CODE) THEN
                          L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                          L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                          RAISE GETRATE_FAILED;
                        ELSE
                          DEBUG.PR_DEBUG('BC',
                                         'CYPKSS.fn_getRate returned ' ||
                                         L_EXCH_RATE_NUM);
                        END IF;

                        L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                        IF L_CUST_NO IS NOT NULL THEN

                          DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate16');

                          DEBUG.PR_DEBUG('BC',
                                         'Original p_Exch_Rate:' ||
                                         L_EXCH_RATE_NUM);

                          IF NOT
                              COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                                 ,
                                                                  L_CUST_NO,
                                                                  SUBSTR(P_BCREFNO,
                                                                         4,
                                                                         4),
                                                                  NULL,
                                                                  P_INTERMEDIATE_TBL(J)
                                                                  .TAG_CCY,
                                                                  P_INTERMEDIATE_TBL(J)
                                                                  .ACC_CCY,
                                                                  L_ORG_EXCH_RATE,
                                                                  L_EXCH_RATE_NUM,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
                            DEBUG.PR_DEBUG('BC',
                                           'failed to get RP exchange rate ');
                            RAISE GETRATE_FAILED;
                          END IF;

                          DEBUG.PR_DEBUG('BC',
                                         'Post RP l_exch_rate is:' ||
                                         L_EXCH_RATE_NUM);

                        END IF;

                        DEBUG.PR_DEBUG('BC',
                                       'got th edit rate is2-->' ||
                                       L_EXCH_RATE_NUM);

                    END;
                  ELSE
                    DEBUG.PR_DEBUG('BC',
                                   'this is not liquidation so take the general flow');
                    IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                             P_INTERMEDIATE_TBL   (J).TAG_CCY,
                                             P_INTERMEDIATE_TBL   (J).ACC_CCY,
                                             L_XRATE_TYPE,
                                             'M',
                                             L_EXCH_RATE_NUM,
                                             L_RATEFLAG,
                                             P_ERR_CODE) THEN
                      L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                      L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                      RAISE GETRATE_FAILED;
                    ELSE
                      DEBUG.PR_DEBUG('BC',
                                     'CYPKSS.fn_getRate returned ' ||
                                     L_EXCH_RATE_NUM);
                    END IF;

                    L_ORG_EXCH_RATE := L_EXCH_RATE_NUM;
                    IF L_CUST_NO IS NOT NULL THEN

                      DEBUG.PR_DEBUG('BC', 'calling fn_get_rp_rate17');

                      DEBUG.PR_DEBUG('BC',
                                     'Original p_Exch_Rate:' ||
                                     L_EXCH_RATE_NUM);

                      IF NOT
                          COPKSS_RP_PROCESSING.FN_GET_RP_RATE(GLOBAL.CURRENT_BRANCH

                                                             ,
                                                              L_CUST_NO,
                                                              SUBSTR(P_BCREFNO,
                                                                     4,
                                                                     4),
                                                              NULL,
                                                              P_INTERMEDIATE_TBL(J)
                                                              .TAG_CCY,
                                                              P_INTERMEDIATE_TBL(J)
                                                              .ACC_CCY,
                                                              L_ORG_EXCH_RATE,
                                                              L_EXCH_RATE_NUM,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
                        DEBUG.PR_DEBUG('BC',
                                       'failed to get RP exchange rate ');
                        RAISE GETRATE_FAILED;
                      END IF;

                      DEBUG.PR_DEBUG('BC',
                                     'Post RP l_exch_rate is:' ||
                                     L_EXCH_RATE_NUM);

                    END IF;

                    DEBUG.PR_DEBUG('BC',
                                   'exchange rate coming isdwd-->' ||
                                   L_EXCH_RATE_NUM);
                  END IF;
                END IF;

              END IF;

              DEBUG.PR_DEBUG('BC', 'Calling fn_amt1_to_amt2');
              DEBUG.PR_DEBUG('BC',
                             ' 1 ->' || P_INTERMEDIATE_TBL(J).TAG_CCY || '~' || P_INTERMEDIATE_TBL(J)
                             .ACC_CCY || '~' || P_INTERMEDIATE_TBL(J)
                             .TAG_AMT);
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_INTERMEDIATE_TBL(J).TAG_CCY,
                                            P_INTERMEDIATE_TBL(J).ACC_CCY,
                                            P_INTERMEDIATE_TBL(J).TAG_AMT,
                                            L_EXCH_RATE_NUM,
                                            'Y',
                                            L_RET_AMT,
                                            P_ERR_CODE) THEN
                L_CCY1 := P_INTERMEDIATE_TBL(J).TAG_CCY;
                L_CCY2 := P_INTERMEDIATE_TBL(J).ACC_CCY;
                RAISE AMT1_TO_AMT2_FAILED;
              END IF;
              DEBUG.PR_DEBUG('BC', 'fn_amt1_to_amt2 PASSED');
              DEBUG.PR_DEBUG('BC',
                             ' 2 ->' || P_INTERMEDIATE_TBL(J).TAG_CCY || '~' || P_INTERMEDIATE_TBL(J)
                             .ACC_CCY || '~' || P_INTERMEDIATE_TBL(J)
                             .TAG_AMT);
              DEBUG.PR_DEBUG('BC',
                             'Exch_rate for convsn: ' || L_EXCH_RATE_NUM);
              DEBUG.PR_DEBUG('BC', 'Converted amount: ' || L_RET_AMT);

              P_INTERMEDIATE_TBL(J).TAG_SETTLEMENT_RATE := L_EXCH_RATE_NUM;
              DEBUG.PR_DEBUG('BC', 'Settlment_rate was assigned');

              P_INTERMEDIATE_TBL(J).EXCH_RATE := NVL(L_EXCH_RATE_NUM, 1);

              DEBUG.PR_DEBUG('BC', 'Exhange Rate was assigned');

              P_INTERMEDIATE_TBL(J).ORG_EXCH_RATE := NVL(L_ORG_EXCH_RATE,
                                                         L_EXCH_RATE_NUM);

              P_INTERMEDIATE_TBL(J).FCY_AMT := 0;

              DEBUG.PR_DEBUG('BC', 'FCY Amount was assigned');

              P_INTERMEDIATE_TBL(J).LCY_AMT := L_RET_AMT;
              DEBUG.PR_DEBUG('BC', 'LCY Amount was assigned');
            END IF;
            DEBUG.PR_DEBUG('BC', 'CASE 5 was SUCCESSFUL');

          ELSE
            DEBUG.PR_DEBUG('BC',
                           'inside Else Statement Newly Retroed from 4.8');
            DEBUG.PR_DEBUG('BC',
                           'Geting into special processing for UI accts..7');

            L_ACC_BRANCH := CSPKES_MISC.FN_GETPARAM(L_ACC_BRANCH_LST,
                                                    I,
                                                    '~');
            P_INTERMEDIATE_TBL(J).ACC_BRANCH := L_ACC_BRANCH;
            P_INTERMEDIATE_TBL(J).ACCOUNT := CSPKES_MISC.FN_GETPARAM(L_ACC_LST,
                                                                     I,
                                                                     '~');
            L_ACC_CCY := CSPKES_MISC.FN_GETPARAM(L_ACC_CCY_LST, I, '~');
            P_INTERMEDIATE_TBL(J).ACC_CCY := L_ACC_CCY;

            L_INDEX := P_INTERMEDIATE_TBL(J).TAG_INDEX;

            L_CONTRACT_CCY            := P_AMTTAG_TBL(L_INDEX).CONTRACT_CCY;
            L_CHG_AMT_IN_CONTRACT_CCY := P_AMTTAG_TBL(L_INDEX)
                                         .CHG_AMT_IN_CONTRACT_CCY;

            DEBUG.PR_DEBUG('BC',
                           'Printing values in intermediate table...............................');
            DEBUG.PR_DEBUG('BC',
                           'amt tag                    = ' || P_INTERMEDIATE_TBL(J)
                           .AMT_TAG);
            DEBUG.PR_DEBUG('BC',
                           'acc ccy                    = ' || P_INTERMEDIATE_TBL(J)
                           .ACC_CCY);
            DEBUG.PR_DEBUG('BC',
                           'Tag ccy                    = ' || P_INTERMEDIATE_TBL(J)
                           .TAG_CCY);
            DEBUG.PR_DEBUG('BC',
                           'Tag amt                = ' || P_INTERMEDIATE_TBL(J)
                           .TAG_AMT);
            DEBUG.PR_DEBUG('BC',
                           'p_intermediate_tbl(j).lcy_amt  = ' || P_INTERMEDIATE_TBL(J)
                           .LCY_AMT);
            DEBUG.PR_DEBUG('BC',
                           'p_intermediate_tbl(j).fcy_amt  = ' || P_INTERMEDIATE_TBL(J)
                           .FCY_AMT);

            DEBUG.PR_DEBUG('BC',
                           'Printing values in amt tag table after fetching l_index...............');
            DEBUG.PR_DEBUG('BC',
                           'Tag                    = ' || P_AMTTAG_TBL(L_INDEX).TAG);
            DEBUG.PR_DEBUG('BC',
                           'Amt                    = ' || P_AMTTAG_TBL(L_INDEX).AMT);
            DEBUG.PR_DEBUG('BC',
                           'ccy                    = ' || P_AMTTAG_TBL(L_INDEX).CCY);
            DEBUG.PR_DEBUG('BC',
                           'contract_ccy               = ' || P_AMTTAG_TBL(L_INDEX)
                           .CONTRACT_CCY);
            DEBUG.PR_DEBUG('BC',
                           'chg_amt_in_contract_ccy        = ' || P_AMTTAG_TBL(L_INDEX)
                           .CHG_AMT_IN_CONTRACT_CCY);

            DEBUG.PR_DEBUG('BC',
                           'Going to call ldpks_acc_entry.fn_compute_lcy_equivalent from UI accts..');

            IF NOT
                LDPKSS_ACC_ENTRY.FN_COMPUTE_LCY_EQUIVALENT(P_MODULE,
                                                           P_INTERMEDIATE_TBL       (J)
                                                           .AMT_TAG,
                                                           P_INTERMEDIATE_TBL       (J)
                                                           .TAG_AMT,
                                                           NULL,
                                                           P_INTERMEDIATE_TBL       (J)
                                                           .TAG_CCY,
                                                           P_INTERMEDIATE_TBL       (J)
                                                           .ACC_CCY,
                                                           L_SETTLEMENT_EXCH_RATE,
                                                           NULL,
                                                           NULL,
                                                           L_SETTLEMENT_AMOUNT,
                                                           L_LCY_EQUIVALENT,
                                                           L_LCY_EXCH_RATE,
                                                           L_RELATED_FCY,
                                                           L_CONTRACT_CCY,
                                                           L_CHG_AMT_IN_CONTRACT_CCY,
                                                           P_ESN,
                                                           P_BCREFNO,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
              DEBUG.PR_DEBUG('BC',
                             'Call to ldpks_acc_entry.fn_compute_lcy_equivalent returned false...');
              RETURN FALSE;
            END IF;

            DEBUG.PR_DEBUG('BC',
                           'l_settlement_amount = ' || L_SETTLEMENT_AMOUNT);

            DEBUG.PR_DEBUG('BC',
                           'p_intermediate_tbl(j).acc_ccy = ' || P_INTERMEDIATE_TBL(J)
                           .ACC_CCY);
            DEBUG.PR_DEBUG('BC',
                           'p_intermediate_tbl(j).tag_ccy = ' || P_INTERMEDIATE_TBL(J)
                           .TAG_CCY);
            DEBUG.PR_DEBUG('BC',
                           'p_intermediate_tbl(j).tag_amt = ' || P_INTERMEDIATE_TBL(J)
                           .TAG_AMT);

            P_INTERMEDIATE_TBL(J).LCY_AMT := L_LCY_EQUIVALENT;

            IF P_INTERMEDIATE_TBL(J).ACC_CCY <> GLOBAL.LCY THEN
              P_INTERMEDIATE_TBL(J).FCY_AMT := L_SETTLEMENT_AMOUNT;
            END IF;

            P_INTERMEDIATE_TBL(J).TAG_SETTLEMENT_RATE := L_SETTLEMENT_EXCH_RATE;

            P_INTERMEDIATE_TBL(J).ORG_EXCH_RATE := L_SETTLEMENT_EXCH_RATE;

            P_INTERMEDIATE_TBL(J).EXCH_RATE := L_LCY_EXCH_RATE;
            P_INTERMEDIATE_TBL(J).ACC_CCY := P_INTERMEDIATE_TBL(J).ACC_CCY;

            P_INTERMEDIATE_TBL(J).TAG_AMT := L_CHG_AMT_IN_CHARGE_CCY;
            P_INTERMEDIATE_TBL(J).TAG_CCY := L_CHARGE_CCY;

          END IF;

        END IF;

        IF P_INTERMEDIATE_TBL(J)
         .AMT_TAG = ATAG AND P_INTERMEDIATE_TBL(J).SETTLEMENT_FLAG = 'Y' THEN

          L_INDEX := P_INTERMEDIATE_TBL(J).TAG_INDEX;
          P_AMTTAG_TBL(L_INDEX).LCY_AMT_EQUIV := P_INTERMEDIATE_TBL(J)
                                                 .LCY_AMT;
          DEBUG.PR_DEBUG('BC',
                         'Assigned lcy_amt of Mid_tbl(' || J ||
                         ') to amttag_tbl(' || L_INDEX || ')');

          P_AMTTAG_TBL(L_INDEX).EXCH_RATE := P_INTERMEDIATE_TBL(J).EXCH_RATE;

          DEBUG.PR_DEBUG('BC',
                         'Assigned Exchange Rate ' || P_INTERMEDIATE_TBL(J)
                         .TAG_SETTLEMENT_RATE);

        END IF;
      END LOOP;

      DEBUG.PR_DEBUG('BC',
                     'Now Checking for the other leg of UI ' ||
                     'Accounting Entries hitting GL');
      OUTER_I := I;

      FOR I IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
        IF ATAG NOT LIKE '%DISC' AND ATAG NOT LIKE '%PREM' THEN

          IF P_INTERMEDIATE_TBL(I)
           .AMT_TAG = ATAG AND P_INTERMEDIATE_TBL(I).SETTLEMENT_FLAG = 'N' THEN
            L_INDEX             := P_INTERMEDIATE_TBL(I).TAG_INDEX;
            L_TAG_LCY_EXCH_RATE := 0;

            DEBUG.PR_DEBUG('BC', 'Value of l_index is ' || L_INDEX);
            DEBUG.PR_DEBUG('BC',
                           'Checking for ' || P_INTERMEDIATE_TBL(I).ACCROLE);

            IF P_AMTTAG_TBL(L_INDEX).CCY = GLOBAL.LCY THEN
              L_TAG_LCY_EXCH_RATE := 1;
            ELSE

              IF P_AMTTAG_TBL(L_INDEX).EXCH_RATE IS NOT NULL THEN
                DEBUG.PR_DEBUG('BC',
                               'Exchange Rate is ' || P_AMTTAG_TBL(L_INDEX)
                               .EXCH_RATE);
                L_TAG_LCY_EXCH_RATE := P_AMTTAG_TBL(L_INDEX).EXCH_RATE;
              ELSE

                DEBUG.PR_DEBUG('BC', 'About to Call CYPKSS.fn_amt_to_rate');
                IF NOT CYPKSS.FN_AMT_TO_RATE(GLOBAL.LCY,
                                             P_AMTTAG_TBL       (L_INDEX).CCY,
                                             P_AMTTAG_TBL       (L_INDEX)
                                             .LCY_AMT_EQUIV,
                                             P_AMTTAG_TBL       (L_INDEX).AMT,
                                             L_TAG_LCY_EXCH_RATE) THEN
                  L_CCY1       := GLOBAL.LCY;
                  L_CCY2       := P_AMTTAG_TBL(L_INDEX).CCY;
                  P_ERR_CODE   := 'BC-AT001';
                  P_ERR_PARAMS := L_CCY1 || '~' || L_CCY2 || '~';
                  DEBUG.PR_DEBUG('BC',
                                 'CYPKSS.fn_amt_to_rate returned FALSE');
                  RAISE PROCESS_FAILED;
                END IF;
                DEBUG.PR_DEBUG('BC', 'fn_amt_to_rate PASSED');
              END IF;

            END IF;

            P_INTERMEDIATE_TBL(I).EXCH_RATE := L_TAG_LCY_EXCH_RATE;

            P_INTERMEDIATE_TBL(I).ORG_EXCH_RATE := L_TAG_LCY_EXCH_RATE;

            P_INTERMEDIATE_TBL(I).LCY_AMT := P_AMTTAG_TBL(L_INDEX)
                                             .LCY_AMT_EQUIV;
            P_INTERMEDIATE_TBL(I).ACC_BRANCH := GLOBAL.CURRENT_BRANCH;
            P_INTERMEDIATE_TBL(I).FCY_AMT := P_AMTTAG_TBL(L_INDEX).AMT;
            P_INTERMEDIATE_TBL(I).ACC_CCY := P_AMTTAG_TBL(L_INDEX).CCY;
            DEBUG.PR_DEBUG('BC',
                           'Updated lcy_amt_equiv: ' || P_AMTTAG_TBL(L_INDEX)
                           .LCY_AMT_EQUIV);
            DEBUG.PR_DEBUG('BC',
                           'Updated exch rate: ' || L_TAG_LCY_EXCH_RATE);
            DEBUG.PR_DEBUG('BC',
                           'Updated acc_branch: ' || GLOBAL.CURRENT_BRANCH);
            DEBUG.PR_DEBUG('BC',
                           'Updated fcy_amt: ' || P_AMTTAG_TBL(L_INDEX).AMT);
            DEBUG.PR_DEBUG('BC',
                           'Updated acc_ccy: ' || P_AMTTAG_TBL(L_INDEX).CCY);

          END IF;
        END IF;
      END LOOP;

      I    := I + 1;
      ATAG := CSPKES_MISC.FN_GETPARAM(L_TAG_LST, I, '~');
    END LOOP;
    RETURN TRUE;

  EXCEPTION
    WHEN GETRATE_FAILED THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT001';
        P_ERR_PARAMS := L_CCY1 || '~' || L_CCY2 || '~';
      END IF;
      RETURN FALSE;

    WHEN AMT1_TO_AMT2_FAILED THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT002';
        P_ERR_PARAMS := L_CCY1 || '~' || L_CCY2 || '~';
      END IF;
      RETURN FALSE;

    WHEN PROCESS_FAILED THEN
      DEBUG.PR_DEBUG('BC', THIS_FN || ' FAILED');
      RETURN FALSE;

  END FN_PROCESS_TBL_FOR_UI_ACCTS;

  FUNCTION FN_DO_ACC_LOOKUP(P_BCREFNO             IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                            P_EVENT_CODE          IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                            P_USER_DEFINED_STATUS IN CSTBS_CONTRACT.USER_DEFINED_STATUS%TYPE,
                            P_ACC_LOOKUP_TBL      IN OUT ACPKSS.TBL_LOOKUP,
                            P_ERR_CODE            IN OUT VARCHAR2,
                            P_ERR_PARAMS          IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_ACC_HEAD GLTMS_GLMASTER.GL_CODE%TYPE;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside BCPKSS_ACC_ENTRIES.fn_do_acc_lookup');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    IF NOT ACPKSS.ACFN_LOOKUP(SUBSTR(P_BCREFNO, 4, 4),
                              P_EVENT_CODE,
                              P_USER_DEFINED_STATUS,
                              P_ACC_LOOKUP_TBL,
                              P_ERR_CODE) THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT003';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_EVENT_CODE || '~';

      END IF;
      DEBUG.PR_DEBUG('BC', 'ACPKSS.acfn_lookup failed');
      RETURN FALSE;
    END IF;

    IF P_EVENT_CODE IN ('ACCR', 'LIQD') AND P_USER_DEFINED_STATUS <> 'NORM' THEN
      DEBUG.PR_DEBUG('BC', 'event code is :' || P_EVENT_CODE);
      DEBUG.PR_DEBUG('BC', 'status is :' || P_USER_DEFINED_STATUS);

      FOR I IN P_ACC_LOOKUP_TBL.FIRST .. P_ACC_LOOKUP_TBL.LAST LOOP
        L_ACC_HEAD := '-1';
        BEGIN
          SELECT TRANSFER_GL
            INTO L_ACC_HEAD
            FROM CSTMS_PRODUCT_STATUS_GL
           WHERE PRODUCT = SUBSTR(P_BCREFNO, 4, 4)
             AND ACCOUNT_ROLE = P_ACC_LOOKUP_TBL(I).ACCROLE
             AND STATUS = P_USER_DEFINED_STATUS;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('BC',
                           'For ' || P_USER_DEFINED_STATUS ||
                           ' gl code is not found');
        END;
        IF L_ACC_HEAD = '' THEN
          L_ACC_HEAD := '-1';
        END IF;
        IF L_ACC_HEAD <> '-1' THEN
          DEBUG.PR_DEBUG('BC', 'about to assign l_acc_head ');
          P_ACC_LOOKUP_TBL(I).ACCOUNT := L_ACC_HEAD;

        END IF;

      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('BC', 'fn_do_acc_lookup PASSED');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'fn_do_acc_lookup FAILED' || SQLERRM);
      RETURN FALSE;

  END FN_DO_ACC_LOOKUP;

  FUNCTION FN_INS_CHARGES(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                          P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                          P_INTERMEDIATE_TBL IN INTERMEDIATE_TBL_TYPE,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_COMPONENT BCTBS_ICCF_MASTER.COMPONENT%TYPE;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside BCPKSS_ACC_ENTRIES.fn_ins_charges');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    FOR I IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
      IF P_INTERMEDIATE_TBL(I)
       .TAGTYPE = 'H' AND P_INTERMEDIATE_TBL(I).DRCRIND <> 'D'

       THEN
        L_COMPONENT := P_INTERMEDIATE_TBL(I).AMT_TAG;

        IF NOT BCPKSS_ICCF2.FN_INS_CHARGE_DETAILS(P_BCREFNO,
                                                  L_COMPONENT,
                                                  P_INTERMEDIATE_TBL     (I)
                                                  .TAGTYPE,
                                                  P_ESN,
                                                  P_INTERMEDIATE_TBL     (I)
                                                  .TAG_AMT,
                                                  P_INTERMEDIATE_TBL     (I)
                                                  .TAG_CCY,
                                                  GLOBAL.APPLICATION_DATE,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
          DEBUG.PR_DEBUG('BC', 'BCPKSS_ICCF2.fn_ins_charges failed');
          RETURN FALSE;
        END IF;
        DEBUG.PR_DEBUG('BC', 'After fn_ins_charge_details');
      END IF;
    END LOOP;

    RETURN TRUE;

  END FN_INS_CHARGES;

  FUNCTION FN_INSERT_CHGS(P_CONTRACT_REF_NO IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                          P_EVENT_SEQ_NO    IN BCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE,
                          P_EVENT_CODE      IN BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE,
                          P_AMOUNT_TAG      IN VARCHAR2,
                          P_LCY_AMOUNT      IN NUMBER,
                          P_VALUE_DATE      IN DATE) RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('BC', 'Inserting into charge_application');
    INSERT INTO CFTBS_CHARGE_APPLN
      (CONTRACT_REF_NO,
       COMPONENT,
       EVENT_SEQ_NO,
       VALUE_DATE,
       TRANSACTION_DATE,
       ALLOW_AMOUNT_AMENDMENT,
       CHARGE_CCY,
       COMPUTED_CHARGE_AMOUNT,
       LIQUIDATION_INDICATOR,
       WAIVER,
       ASSOCIATION_EVENT_SEQ_NO,
       EVENT,
       CREATION_ESN,
       TAG_CCY,
       TAG_AMOUNT,
       CHARGE_AMOUNT)
    VALUES
      (P_CONTRACT_REF_NO,
       SUBSTR(P_AMOUNT_TAG, 4),
       P_EVENT_SEQ_NO,
       P_VALUE_DATE,
       GLOBAL.APPLICATION_DATE,
       'N',
       GLOBAL.LCY,
       P_LCY_AMOUNT,
       'Y',
       'N',
       P_EVENT_SEQ_NO,
       P_EVENT_CODE,
       P_EVENT_SEQ_NO,
       GLOBAL.LCY,
       P_LCY_AMOUNT,
       P_LCY_AMOUNT);
    DEBUG.PR_DEBUG('BC', 'Inserting into cftbs_charge assoc');
    INSERT INTO CFTBS_CHARGE_ASSOC
      (CONTRACT_REF_NO,
       COMPONENT,
       EVENT_SEQ_NO,
       VALUE_DATE,
       TRANSACTION_DATE,
       ALLOW_RULE_AMENDMENT,
       WAIVER,
       RULE,
       CREATION_ESN,
       EVENT,
       PRODUCT)
    VALUES
      (P_CONTRACT_REF_NO,
       SUBSTR(P_AMOUNT_TAG, 4),
       P_EVENT_SEQ_NO,
       P_VALUE_DATE,
       GLOBAL.APPLICATION_DATE,
       'N',
       'N',
       SUBSTR(P_AMOUNT_TAG, 4),
       P_EVENT_SEQ_NO,
       P_EVENT_CODE,
       SUBSTR(P_CONTRACT_REF_NO, 4, 4));
    DEBUG.PR_DEBUG('BC', 'Inserting into cftbs_charge liquidation');
    INSERT INTO CFTBS_CHARGE_LIQD_MASTER
      (CONTRACT_REF_NO,
       COMPONENT,
       EVENT_SEQ_NO,
       VALUE_DATE,
       TRANSACTION_DATE,
       ASSOCIATION_EVENT_SEQ_NO,
       EVENT,
       ASSOCIATION_CONTRACT_REF_NO,
       CHARGE_CCY,
       CHARGE_AMOUNT,
       LIQUIDATION_STATUS,
       ASSOCIATION_PRODUCT)
    VALUES
      (P_CONTRACT_REF_NO,
       SUBSTR(P_AMOUNT_TAG, 4),
       P_EVENT_SEQ_NO,
       P_VALUE_DATE,
       GLOBAL.APPLICATION_DATE,
       P_EVENT_SEQ_NO,
       P_EVENT_CODE,
       P_CONTRACT_REF_NO,
       GLOBAL.LCY,
       P_LCY_AMOUNT,
       'A',
       SUBSTR(P_CONTRACT_REF_NO, 4, 4));
    DEBUG.PR_DEBUG('BC', 'Inserting into cftbs_charge liqd detail');
    INSERT INTO CFTBS_CHARGE_LIQD_DETAIL
      (CONTRACT_REF_NO,
       COMPONENT,
       EVENT_SEQ_NO,
       APPLICATION_EVENT_SEQ_NO,
       APPLICATION_CREATION_ESN,
       CHARGE_CCY,
       CHARGE_AMOUNT)
    VALUES
      (P_CONTRACT_REF_NO,
       SUBSTR(P_AMOUNT_TAG, 4),
       P_EVENT_SEQ_NO,
       P_EVENT_SEQ_NO,
       P_EVENT_SEQ_NO,
       GLOBAL.LCY,
       P_LCY_AMOUNT);
    RETURN TRUE;
  END FN_INSERT_CHGS;

  FUNCTION FN_SETTLEMENT_UPDATES_TMP(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                                     P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                                     P_INTERMEDIATE_TBL IN INTERMEDIATE_TBL_TYPE,
                                     P_ERR_CODE         IN OUT VARCHAR2,
                                     P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_AMT_TAG_LST    VARCHAR2(1000) := '';
    L_SETTLE_AMT_LST VARCHAR2(1000) := '';
    L_EXCH_RATE_LST  VARCHAR2(1000) := '';
    L_VDATE_LST      VARCHAR2(1000) := '';
    L_NETIND_LST     VARCHAR2(1000) := '';

    L_ORG_EXCH_RATE_LST VARCHAR2(1000) := '';
    L_TAG_NO            INTEGER;
    K                   NUMBER;

    PROCESS_FAILED EXCEPTION;
    THIS_FN VARCHAR2(50) := 'BCPKS_ACC_ENTRIES.fn_settlement_updates_tmp';

    LSETLTAG     VARCHAR2(100);
    L_GENMSG_LST VARCHAR2(1000);

    L_LIST_OF_IS_AMOUNT_TAGS  VARCHAR2(1000);
    L_LIST_OF_IS_TAG_CCYS     VARCHAR2(1000);
    L_LIST_OF_IS_TAG_PAYS     VARCHAR2(1000);
    L_LIST_OF_IS_AMOUNTS      VARCHAR2(1000);
    L_LIST_OF_IS_VALUE_DATES  VARCHAR2(1000);
    L_LIST_OF_IS_BRANCHES     VARCHAR2(1000);
    L_LIST_OF_IS_ACCOUNTS     VARCHAR2(1000);
    L_LIST_OF_IS_ACCOUNT_CCYS VARCHAR2(1000);
    L_LIST_OF_IS_EXCH_RATES   VARCHAR2(1000);
    L_LIST_OF_IS_INSTRUMENTS  VARCHAR2(1000);

    L_ACCOUNT_BRANCH       ACTBS_HANDOFF.AC_BRANCH%TYPE;
    L_ACCOUNT              ACTBS_HANDOFF.AC_NO%TYPE;
    L_INSTRUMENT_CODE      ACTBS_HANDOFF.INSTRUMENT_CODE%TYPE;
    L_SETTLEMENT_CCY       ACTBS_HANDOFF.AC_CCY%TYPE;
    L_SETTLEMENT_EXCH_RATE ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_SETTLEMENT_AMOUNT    ACTBS_HANDOFF.FCY_AMOUNT%TYPE;
    L_AM_SETTLEMENT_AMOUNT ACTBS_HANDOFF.FCY_AMOUNT%TYPE;

    CURSOR C1 IS
      SELECT *
        FROM ISTB_CONTRACTIS
       WHERE CONTRACT_REF_NO = P_BCREFNO
         AND EVENT_SEQ_NO = P_ESN;

    TYPE TY_SETTLEMENT_DETAILS IS TABLE OF ISTBS_CONTRACTIS%ROWTYPE INDEX BY VARCHAR2(100);
    TYPE TY_INT_SETTLEMENT_DETAILS IS TABLE OF ISTBS_CONTRACTIS%ROWTYPE INDEX BY BINARY_INTEGER;

    L_INT_SETTLEMENT_DETAILS TY_INT_SETTLEMENT_DETAILS;
    L_SETTLEMENT_DETAILS     TY_SETTLEMENT_DETAILS;
    L_SETTLE_COUNT           NUMBER := 0;

  BEGIN

    DEBUG.PR_DEBUG('BC', 'Inside fn_settlement_updates_tmp');

    P_ERR_CODE   := '';
    P_ERR_PARAMS := '';

    OPEN C1;
    LOOP
      FETCH C1 BULK COLLECT
        INTO L_INT_SETTLEMENT_DETAILS;
      EXIT WHEN C1%NOTFOUND;
    END LOOP;

    L_SETTLE_COUNT := L_INT_SETTLEMENT_DETAILS.COUNT;

    IF L_SETTLE_COUNT > 0 THEN
      FOR I IN 1 .. L_SETTLE_COUNT LOOP
        L_SETTLEMENT_DETAILS(L_INT_SETTLEMENT_DETAILS(I).AMOUNT_TAG) := L_INT_SETTLEMENT_DETAILS(I);
      END LOOP;
    END IF;

    FOR I IN P_INTERMEDIATE_TBL.FIRST .. P_INTERMEDIATE_TBL.LAST LOOP
      IF P_INTERMEDIATE_TBL(I).SETTLEMENT_FLAG = 'Y' THEN

        L_GENMSG_LST := L_GENMSG_LST || '~' || P_INTERMEDIATE_TBL(I)
                       .GEN_MSG;

        L_AMT_TAG_LST := L_AMT_TAG_LST || '~' || P_INTERMEDIATE_TBL(I)
                        .AMT_TAG;

        IF P_INTERMEDIATE_TBL(I).ACC_CCY != GLOBAL.LCY THEN
          L_SETTLE_AMT_LST := L_SETTLE_AMT_LST || '~' || P_INTERMEDIATE_TBL(I)
                             .TAG_AMT;
        ELSE
          L_SETTLE_AMT_LST := L_SETTLE_AMT_LST || '~' || P_INTERMEDIATE_TBL(I)
                             .TAG_AMT;
        END IF;

        IF L_SETTLEMENT_DETAILS.EXISTS(P_INTERMEDIATE_TBL(I).AMT_TAG) THEN
          L_EXCH_RATE_LST := L_EXCH_RATE_LST || '~' || L_SETTLEMENT_DETAILS(P_INTERMEDIATE_TBL(I).AMT_TAG)
                            .EX_RATE;
        ELSE
          L_EXCH_RATE_LST := L_EXCH_RATE_LST || '~' || P_INTERMEDIATE_TBL(I)
                            .TAG_SETTLEMENT_RATE;
        END IF;

        L_ORG_EXCH_RATE_LST := L_ORG_EXCH_RATE_LST || '~' || P_INTERMEDIATE_TBL(I)
                              .ORG_EXCH_RATE;

        L_VDATE_LST  := L_VDATE_LST || '~' || P_INTERMEDIATE_TBL(I).VDATE;
        L_NETIND_LST := L_NETIND_LST || '~' || P_INTERMEDIATE_TBL(I).NETIND;
      END IF;

    END LOOP;
    L_AMT_TAG_LST    := SUBSTR(L_AMT_TAG_LST, 2);
    L_SETTLE_AMT_LST := SUBSTR(L_SETTLE_AMT_LST, 2);
    L_EXCH_RATE_LST  := SUBSTR(L_EXCH_RATE_LST, 2);
    L_VDATE_LST      := SUBSTR(L_VDATE_LST, 2);
    L_NETIND_LST     := SUBSTR(L_NETIND_LST, 2);
    L_GENMSG_LST     := SUBSTR(L_GENMSG_LST, 2);

    L_ORG_EXCH_RATE_LST := SUBSTR(L_ORG_EXCH_RATE_LST, 2);

    DEBUG.PR_DEBUG('BC',
                   'Printing the lists before Settlement update
        for contract : ' || P_BCREFNO);

    DEBUG.PR_DEBUG('BC', 'l_amt_tag_lst      :' || L_AMT_TAG_LST);
    DEBUG.PR_DEBUG('BC', 'l_settle_amt_lst   :' || L_SETTLE_AMT_LST);
    DEBUG.PR_DEBUG('BC', 'l_exch_rate_lst    :' || L_EXCH_RATE_LST);
    DEBUG.PR_DEBUG('BC', 'l_vdate_lst            :' || L_VDATE_LST);
    DEBUG.PR_DEBUG('BC', 'l_netind_lst       :' || L_NETIND_LST);
    DEBUG.PR_DEBUG('BC', 'l_genmsg_lst       :' || L_GENMSG_LST);
    DEBUG.PR_DEBUG('BC', 'l_org_exch_rate_lst  :' || L_ORG_EXCH_RATE_LST);

    IF NOT ISPKSS.FN_UPDATE(P_BCREFNO,
                            P_ESN,
                            L_AMT_TAG_LST,
                            L_SETTLE_AMT_LST,
                            L_EXCH_RATE_LST,
                            L_VDATE_LST,
                            L_NETIND_LST,
                            L_GENMSG_LST,
                            P_ERR_CODE) THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT009';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~';

        DEBUG.PR_DEBUG('BC', 'ISPKSS.fn_update bombed');
      END IF;
      RAISE PROCESS_FAILED;
    END IF;

    IF NOT FN_UPDATE(P_BCREFNO,
                     P_ESN,
                     L_AMT_TAG_LST,
                     L_ORG_EXCH_RATE_LST,
                     P_ERR_CODE) THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT009';
        P_ERR_PARAMS := P_BCREFNO || '~' || P_ESN || '~';

        DEBUG.PR_DEBUG('BC', 'fn_update bombed');
      END IF;
      RAISE PROCESS_FAILED;
    END IF;

    DEBUG.PR_DEBUG('BC', 'Settlement update PASSED');

    RETURN TRUE;

  EXCEPTION
    WHEN PROCESS_FAILED THEN
      DEBUG.PR_DEBUG('BC', THIS_FN || ' FAILED');
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', THIS_FN || SQLERRM);
      RETURN FALSE;

  END FN_SETTLEMENT_UPDATES_TMP;

  FUNCTION FN_ASSIGN_VDATE(P_BCREFNO          IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                           P_ESN              IN BCTBS_ICCF_MASTER.PESN%TYPE,
                           P_EVENT_CODE       IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                           P_INTERMEDIATE_TBL IN OUT INTERMEDIATE_TBL_TYPE)
    RETURN BOOLEAN IS
    L_CONTRACT_REC BCTBS_CONTRACT_MASTER%ROWTYPE;
    L_VALUE_DATE   DATE;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DEBUG.PR_DEBUG('BC', 'Start of function FN_ASSIGN_VDATE');

    SELECT *
      INTO L_CONTRACT_REC
      FROM BCTBS_CONTRACT_MASTER
     WHERE BCREFNO = P_BCREFNO
       AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                             FROM BCTBS_CONTRACT_MASTER
                            WHERE BCREFNO = P_BCREFNO
                              AND EVENT_SEQ_NO <= P_ESN);
    DEBUG.PR_DEBUG('BC',
                   'l_contract_rec.cr_value_date ::' ||
                   L_CONTRACT_REC.CR_VALUE_DATE);
    DEBUG.PR_DEBUG('BC',
                   'l_contract_rec.dr_value_date ::' ||
                   L_CONTRACT_REC.DR_VALUE_DATE);
    DEBUG.PR_DEBUG('BC',
                   'l_contract_rec.liquidation_date ::' ||
                   L_CONTRACT_REC.LIQUIDATION_DATE);
    DEBUG.PR_DEBUG('BC',
                   'l_contract_rec.value_date ::' ||
                   L_CONTRACT_REC.VALUE_DATE);
    FOR I IN 1 .. P_INTERMEDIATE_TBL.COUNT LOOP
      DEBUG.PR_DEBUG('BC',
                     I || ' - ' || P_INTERMEDIATE_TBL(I).AMT_TAG || ' - ' || P_INTERMEDIATE_TBL(I)
                     .ACCROLE);

      IF (P_INTERMEDIATE_TBL(I)
         .AMT_TAG = 'BILL_OVRDUE_AMT' AND SUBSTR(P_EVENT_CODE, 1, 1) = 'L') THEN
        P_INTERMEDIATE_TBL(I).VDATE := NVL(L_CONTRACT_REC.LIQUIDATION_DATE,
                                           GLOBAL.APPLICATION_DATE);
      ELSE

        IF P_INTERMEDIATE_TBL(I).AMT_TAG IN ('BILL_LIQ_AMT',
                        'BILL_LIQ_AMTEQ',
                        'BILL_OS_AMTEQV',
                        'BILL_OS_AMT',
                        'BILL_AMOUNT',
                        'BILL_AMT',
                        'BILL_AMT_EQUIV',
                        'BILL_OVRDUE_AMT') THEN
          DEBUG.PR_DEBUG('BC',
                         I || 'principal tags - ' || P_INTERMEDIATE_TBL(I)
                         .AMT_TAG);

          IF P_INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN

            P_INTERMEDIATE_TBL(I).VDATE := NVL(L_CONTRACT_REC.DR_VALUE_DATE,
                                               L_CONTRACT_REC.VALUE_DATE);
          ELSIF P_INTERMEDIATE_TBL(I).DRCRIND = 'C' THEN

            P_INTERMEDIATE_TBL(I).VDATE := NVL(L_CONTRACT_REC.CR_VALUE_DATE,
                                               L_CONTRACT_REC.VALUE_DATE);
          END IF;
        ELSE

          IF P_EVENT_CODE <> 'CLOS' THEN
            P_INTERMEDIATE_TBL(I).VDATE := L_CONTRACT_REC.VALUE_DATE;
            DEBUG.PR_DEBUG('BC',
                           I || 'other tags - ' || P_INTERMEDIATE_TBL(I)
                           .AMT_TAG);
          END IF;
        END IF;

        IF L_CONTRACT_REC.AUTO_LIQ_FLAG = 'A' AND P_EVENT_CODE = 'LIQD' THEN
          P_INTERMEDIATE_TBL(I).VDATE := NVL(L_CONTRACT_REC.LIQUIDATION_DATE,
                                             GLOBAL.APPLICATION_DATE);

          IF P_INTERMEDIATE_TBL(I).VDATE IS NULL THEN
            IF P_INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN

              P_INTERMEDIATE_TBL(I).VDATE := NVL(L_CONTRACT_REC.VALUE_DATE,
                                                 L_CONTRACT_REC.DR_VALUE_DATE);

            ELSIF P_INTERMEDIATE_TBL(I).DRCRIND = 'C' THEN

              P_INTERMEDIATE_TBL(I).VDATE := NVL(L_CONTRACT_REC.VALUE_DATE,
                                                 L_CONTRACT_REC.CR_VALUE_DATE);

            END IF;
          END IF;

        END IF;

        IF P_EVENT_CODE IN ('ACCR', 'YACR') THEN
          P_INTERMEDIATE_TBL(I).VDATE := GLOBAL.APPLICATION_DATE;

        END IF;

        IF P_EVENT_CODE IN
           ('LIQD', 'LADV', 'LCOL', 'LDIS', 'LPUR', 'BDIS', 'BPUR') THEN

          IF P_EVENT_CODE IN ('LIQD', 'LADV', 'LCOL', 'LDIS', 'LPUR') THEN
            IF P_INTERMEDIATE_TBL(I).DRCRIND = 'C' THEN
              P_INTERMEDIATE_TBL(I).VDATE := NVL(L_CONTRACT_REC.CR_VALUE_DATE,
                                                 GLOBAL.APPLICATION_DATE);
            ELSIF P_INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN
              P_INTERMEDIATE_TBL(I).VDATE := NVL(L_CONTRACT_REC.DR_VALUE_DATE,
                                                 GLOBAL.APPLICATION_DATE);
            END IF;
          ELSE

            P_INTERMEDIATE_TBL(I).VDATE := GLOBAL.APPLICATION_DATE;
          END IF;
        END IF;

        IF P_INTERMEDIATE_TBL(I)
         .AMT_TAG LIKE '%_LQPP' AND L_CONTRACT_REC.ALLOW_PREPAY = 'Y' THEN
          BEGIN
            SELECT VALUE_DATE
              INTO L_VALUE_DATE
              FROM BCTB_CONTRACT_LIQ_SUMMARY
             WHERE CONTRACT_REF_NO = P_BCREFNO
               AND EVENT_SEQ_NO =
                   (SELECT MAX(EVENT_SEQ_NO)
                      FROM BCTB_CONTRACT_LIQ_SUMMARY
                     WHERE CONTRACT_REF_NO = P_BCREFNO
                       AND EVENT_SEQ_NO <= P_ESN);
          EXCEPTION
            WHEN OTHERS THEN
              L_VALUE_DATE := '';
              DEBUG.PR_DEBUG('BC', ' Inside No Data Found');
          END;
          DEBUG.PR_DEBUG('BC', ' l_value_date' || L_VALUE_DATE);
          DEBUG.PR_DEBUG('BC',
                         ' l_contract_rec.dr_value_date' ||
                         L_CONTRACT_REC.DR_VALUE_DATE);
          IF L_VALUE_DATE IS NOT NULL THEN
            P_INTERMEDIATE_TBL(I).VDATE := L_VALUE_DATE;
          END IF;
          DEBUG.PR_DEBUG('BC',
                         ' p_intermediate_tbl(i).vdate' || P_INTERMEDIATE_TBL(I)
                         .VDATE);
          DEBUG.PR_DEBUG('BC', ' Inside No Data Found');
        END IF;

      END IF;

      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA('i') := I;
        IF NOT
            BCPKS_ACC_ENTRIES_CLUSTER.FN_ASSIGN_VDATE(P_BCREFNO,
                                                      P_ESN,
                                                      P_EVENT_CODE,
                                                      P_INTERMEDIATE_TBL,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
          DEBUG.PR_DEBUG('BC',
                         'bcpks_acc_entries_cluster.fn_assign_vdate failed');
          RETURN FALSE;
        END IF;
      END IF;

      DEBUG.PR_DEBUG('BC',
                     'neel intermediate_tbl(i).amt_tag' || P_INTERMEDIATE_TBL(I)
                     .AMT_TAG || ' p_intermediate_tbl(i).vdate:' || P_INTERMEDIATE_TBL(I)
                     .VDATE);
    END LOOP;

    RETURN TRUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DEBUG.PR_DEBUG('BC',
                     'NO DATA FOUND IN BCTBS_CONTRACT_MASTER IE IT IS LC CONTRACT');
      RETURN TRUE;

    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'FN_ASSIGN_VDATE FAILED- ' || SQLERRM);
      RETURN FALSE;

  END FN_ASSIGN_VDATE;

  FUNCTION FN_CONVERT_AMOUNT(PCCY1             IN CYTMS_CCY_DEFN.CCY_CODE%TYPE,
                             PCCY2             IN CYTMS_CCY_DEFN.CCY_CODE%TYPE,
                             PAMTTOBECONVERTED IN NUMBER,
                             PCONVERTEDAMT     IN OUT NUMBER,
                             PEXCHRATETYPE     IN CYTMS_RATE_TYPE.CCY_RATE_TYPE%TYPE,
                             PEXCHRAGECODE     IN VARCHAR2,
                             PEXCHRATE         IN OUT CYTMS_RATES.MID_RATE%TYPE,
                             P_ERR_CODE        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_RATE_FLAG NUMBER;
  BEGIN
    DEBUG.PR_DEBUG('BC', 'In fn_convert_amount of bcpks_acc_entries');
    DEBUG.PR_DEBUG('BC', 'pCcy1  = ' || PCCY1);
    DEBUG.PR_DEBUG('BC', 'pCcy2  = ' || PCCY2);
    DEBUG.PR_DEBUG('BC', 'pAmttobeConverted = ' || PAMTTOBECONVERTED);
    DEBUG.PR_DEBUG('BC', 'pExchRateType  = ' || PEXCHRATETYPE);
    DEBUG.PR_DEBUG('BC', 'pExchRageCode  = ' || PEXCHRAGECODE);
    DEBUG.PR_DEBUG('BC', 'pExchRate  = ' || PEXCHRATE);

    IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                             PCCY1,
                             PCCY2,
                             PEXCHRATETYPE,
                             PEXCHRAGECODE,
                             PEXCHRATE,
                             L_RATE_FLAG,
                             P_ERR_CODE) THEN
      DEBUG.PR_DEBUG('BC', 'Error in getting the exch_rate');
      RETURN FALSE;
    END IF;

    IF NOT CYPKSS.FN_AMT1_TO_AMT2(PCCY1,
                                  PCCY2,
                                  PAMTTOBECONVERTED,
                                  PEXCHRATE,
                                  'Y',
                                  PCONVERTEDAMT,
                                  P_ERR_CODE) THEN
      DEBUG.PR_DEBUG('BC', 'FAILED to The equiv');
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('BC', 'pConvertedAmt = ' || PCONVERTEDAMT);

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END FN_CONVERT_AMOUNT;

  FUNCTION FN_LC_CHARGES_TRANSFER(PCTB_CONTRACT    IN BCTB_CONTRACT_MASTER%ROWTYPE,
                                  P_EVENT_CODE     IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                                  INTERMEDIATE_TBL IN OUT INTERMEDIATE_TBL_TYPE,
                                  P_ERR_CODE       IN OUT VARCHAR2,
                                  P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CURSOR CR_COMM_TAGS IS
      SELECT SUM(NVL(AMOUNT_PAID, 0)) COMP_CHARGE,
             A.COMPONENT,
             COMPONENT_CCY,
             EX_RATE
        FROM LCTBS_DEFERRED_LIQ_BILL A, CFTM_PRODUCT_ICCF B
       WHERE BCREFNO = PCTB_CONTRACT.BCREFNO
         AND PRODUCT = SUBSTR(PCTB_CONTRACT.OUR_LC_REF, 4, 4)
         AND A.COMPONENT = B.COMPONENT
       GROUP BY A.COMPONENT, A.COMPONENT_CCY, EX_RATE;

    CURSOR CR_CHG_TAGS IS
      SELECT SUM(NVL(AMOUNT_PAID, 0)) COMP_CHARGE,
             A.COMPONENT,
             COMPONENT_CCY,
             EX_RATE
        FROM LCTBS_DEFERRED_LIQ_BILL A, CFTM_PRODUCT_CHARGE B
       WHERE BCREFNO = PCTB_CONTRACT.BCREFNO
         AND PRODUCT = SUBSTR(PCTB_CONTRACT.OUR_LC_REF, 4, 4)
         AND A.COMPONENT = B.COMPONENT
       GROUP BY A.COMPONENT, A.COMPONENT_CCY, EX_RATE;

    L_LOAN_PREF           BCTMS_LOAN_PREFERENCE%ROWTYPE;
    L_LOAN_IN_BILL_CCY    NUMBER;
    L_LOAN_XCHG_RATE_CODE BCTMS_PRODUCT_MASTER.RATE_CODE%TYPE;
    L_LOAN_XCHG_RATE_TYPE BCTMS_PRODUCT_MASTER.RATE_TYPE%TYPE;
    L_LOAN_XCHG_RATE      CYTMS_RATES.MID_RATE%TYPE;
    L_RET_AMT             BCTBS_CONTRACT_MASTER.BILL_AMT%TYPE;
    L_RET_AMT_LCY         BCTBS_CONTRACT_MASTER.BILL_AMT%TYPE;
    L_LOAN_XCHG_RATE_LCY  CYTMS_RATES.MID_RATE%TYPE;
  BEGIN

    BEGIN
      SELECT *
        INTO L_LOAN_PREF
        FROM BCTMS_LOAN_PREFERENCE
       WHERE BCREFNO = PCTB_CONTRACT.BCREFNO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM BCTMS_LOAN_PREFERENCE
               WHERE BCREFNO = PCTB_CONTRACT.BCREFNO);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('BC', 'Loan Preference Not present.');
        NULL;

    END;

    BEGIN
      SELECT RATE_CODE, RATE_TYPE
        INTO L_LOAN_XCHG_RATE_CODE, L_LOAN_XCHG_RATE_TYPE
        FROM BCTMS_PRODUCT_MASTER
       WHERE PROD_CODE = SUBSTR(PCTB_CONTRACT.BCREFNO, 4, 4);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('BC',
                       'Loan Rate type not found in BCTMS_PRODUCT_MASTER');
        L_LOAN_XCHG_RATE_TYPE := 'STANDARD';
        L_LOAN_XCHG_RATE_CODE := 'M';
    END;

    FOR C1 IN CR_COMM_TAGS LOOP
      FOR I IN 1 .. INTERMEDIATE_TBL.COUNT LOOP
        DEBUG.PR_DEBUG('BC', 'Tag Name - ' || INTERMEDIATE_TBL(I).AMT_TAG);
        DEBUG.PR_DEBUG('BC', 'Tag Ccy - ' || INTERMEDIATE_TBL(I).TAG_CCY);
        DEBUG.PR_DEBUG('BC', 'Tag Type - ' || INTERMEDIATE_TBL(I).TAGTYPE);
        DEBUG.PR_DEBUG('BC', 'Charge - ' || C1.COMPONENT || '_TFR');
        DEBUG.PR_DEBUG('BC', 'Loan Ccy -' || L_LOAN_PREF.CURRENCY);

        IF INTERMEDIATE_TBL(I).AMT_TAG = C1.COMPONENT || '_TFR' AND
            C1.COMPONENT_CCY <> L_LOAN_PREF.CURRENCY THEN
          IF L_LOAN_PREF.CRYSTALLIZATION_TYPE <> 'L' THEN
            IF NOT FN_CONVERT_AMOUNT(INTERMEDIATE_TBL     (I).TAG_CCY,
                                     L_LOAN_PREF.CURRENCY,
                                     INTERMEDIATE_TBL     (I).TAG_AMT,
                                     L_RET_AMT,
                                     L_LOAN_XCHG_RATE_TYPE,
                                     L_LOAN_XCHG_RATE_CODE,
                                     L_LOAN_XCHG_RATE,
                                     P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('BC',
                             'Problem in converting amounts ' || P_ERR_CODE);
              RETURN FALSE;
            END IF;
          ELSE

            IF L_LOAN_PREF.CURRENCY = GLOBAL.LCY THEN

              DEBUG.PR_DEBUG('BC',
                             'Linked Loan Exchange Rate ' || C1.EX_RATE);
              L_LOAN_XCHG_RATE := C1.EX_RATE;

              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           INTERMEDIATE_TBL     (I).TAG_CCY,
                                           L_LOAN_PREF.CURRENCY,
                                           L_LOAN_XCHG_RATE_TYPE,
                                           L_LOAN_XCHG_RATE_CODE,
                                           INTERMEDIATE_TBL     (I).TAG_AMT,
                                           'Y',
                                           L_RET_AMT,
                                           L_LOAN_XCHG_RATE,
                                           P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('BC', 'Failed in converting amount');
                RETURN FALSE;
              END IF;

              DEBUG.PR_DEBUG('BC',
                             'Xchg rate for ' || INTERMEDIATE_TBL(I)
                             .TAG_CCY || ' to ' || L_LOAN_PREF.CURRENCY ||
                              ' = ' || L_LOAN_XCHG_RATE);
              DEBUG.PR_DEBUG('BC',
                             'FCY Amount after the conversion = ' ||
                             L_RET_AMT);

              IF INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN
                INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT;
                INTERMEDIATE_TBL(I).FCY_AMT := 0;
                INTERMEDIATE_TBL(I).ACC_CCY := L_LOAN_PREF.CURRENCY;
              ELSE
                INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT;
                INTERMEDIATE_TBL(I).FCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
              END IF;

              INTERMEDIATE_TBL(I).EXCH_RATE := L_LOAN_XCHG_RATE;

            ELSIF C1.COMPONENT_CCY = GLOBAL.LCY THEN
              L_LOAN_XCHG_RATE := C1.EX_RATE;

              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           INTERMEDIATE_TBL     (I).TAG_CCY,
                                           L_LOAN_PREF.CURRENCY,
                                           L_LOAN_XCHG_RATE_TYPE,
                                           L_LOAN_XCHG_RATE_CODE,
                                           INTERMEDIATE_TBL     (I).TAG_AMT,
                                           'Y',
                                           L_RET_AMT,
                                           L_LOAN_XCHG_RATE,
                                           P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('BC', 'Failed in converting amount');
                RETURN FALSE;
              END IF;

              IF INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN
                INTERMEDIATE_TBL(I).LCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
                INTERMEDIATE_TBL(I).FCY_AMT := L_RET_AMT;
                INTERMEDIATE_TBL(I).ACC_CCY := L_LOAN_PREF.CURRENCY;
              ELSE
                INTERMEDIATE_TBL(I).LCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
                INTERMEDIATE_TBL(I).FCY_AMT := 0;
              END IF;

              INTERMEDIATE_TBL(I).EXCH_RATE := L_LOAN_XCHG_RATE;

            ELSIF ((C1.COMPONENT_CCY <> GLOBAL.LCY) AND
                  (L_LOAN_PREF.CURRENCY <> GLOBAL.LCY)) THEN

              L_LOAN_XCHG_RATE := C1.EX_RATE;

              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           INTERMEDIATE_TBL     (I).TAG_CCY,
                                           L_LOAN_PREF.CURRENCY,
                                           L_LOAN_XCHG_RATE_TYPE,
                                           L_LOAN_XCHG_RATE_CODE,
                                           INTERMEDIATE_TBL     (I).TAG_AMT,
                                           'Y',
                                           L_RET_AMT,
                                           L_LOAN_XCHG_RATE,
                                           P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('BC', 'Failed in converting amount');
                RETURN FALSE;
              END IF;

              DEBUG.PR_DEBUG('BC',
                             'amount returned for tag to loan here is ' ||
                             L_RET_AMT);

              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           L_LOAN_PREF.CURRENCY,
                                           GLOBAL.LCY,
                                           L_LOAN_XCHG_RATE_TYPE,
                                           L_LOAN_XCHG_RATE_CODE,
                                           L_RET_AMT,
                                           'Y',
                                           L_RET_AMT_LCY,
                                           L_LOAN_XCHG_RATE_LCY,
                                           P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('BC', 'Failed in converting amount');
                RETURN FALSE;
              END IF;

              DEBUG.PR_DEBUG('BC',
                             'amount returned for loan to global is ' ||
                             L_RET_AMT_LCY || '~' || L_LOAN_XCHG_RATE_LCY);

              IF INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN
                INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT_LCY;
                INTERMEDIATE_TBL(I).FCY_AMT := L_RET_AMT;
                INTERMEDIATE_TBL(I).EXCH_RATE := L_LOAN_XCHG_RATE;
                INTERMEDIATE_TBL(I).ACC_CCY := L_LOAN_PREF.CURRENCY;
              ELSE
                INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT_LCY;
                INTERMEDIATE_TBL(I).FCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
                INTERMEDIATE_TBL(I).EXCH_RATE := L_LOAN_XCHG_RATE_LCY;
              END IF;
            END IF;

            DEBUG.PR_DEBUG('BC',
                           'intermediate_tbl(i).tag_ccy' || INTERMEDIATE_TBL(I)
                           .ACC_CCY);
            DEBUG.PR_DEBUG('BC',
                           'intermediate_tbl(i).exch_rate ' || INTERMEDIATE_TBL(I)
                           .EXCH_RATE);
            DEBUG.PR_DEBUG('BC',
                           'intermediate_tbl(i).lcy_amt' || INTERMEDIATE_TBL(I)
                           .LCY_AMT);
            DEBUG.PR_DEBUG('BC',
                           'intermediate_tbl(i).fcy_amt' || INTERMEDIATE_TBL(I)
                           .FCY_AMT);
          END IF;
        END IF;
      END LOOP;
    END LOOP;

    FOR C2 IN CR_CHG_TAGS LOOP
      FOR I IN 1 .. INTERMEDIATE_TBL.COUNT LOOP
        DEBUG.PR_DEBUG('BC', 'Tag Name - ' || INTERMEDIATE_TBL(I).AMT_TAG);
        DEBUG.PR_DEBUG('BC', 'Tag Ccy - ' || INTERMEDIATE_TBL(I).TAG_CCY);
        DEBUG.PR_DEBUG('BC', 'Tag Type - ' || INTERMEDIATE_TBL(I).TAGTYPE);
        DEBUG.PR_DEBUG('BC', 'Charge - ' || C2.COMPONENT || '_TFR');
        DEBUG.PR_DEBUG('BC', 'Loan Ccy -' || L_LOAN_PREF.CURRENCY);

        IF INTERMEDIATE_TBL(I).AMT_TAG = C2.COMPONENT || '_TFR' AND
            C2.COMPONENT_CCY <> L_LOAN_PREF.CURRENCY THEN
          IF L_LOAN_PREF.CRYSTALLIZATION_TYPE <> 'L' THEN
            IF NOT FN_CONVERT_AMOUNT(INTERMEDIATE_TBL     (I).TAG_CCY,
                                     L_LOAN_PREF.CURRENCY,
                                     INTERMEDIATE_TBL     (I).TAG_AMT,
                                     L_RET_AMT,
                                     L_LOAN_XCHG_RATE_TYPE,
                                     L_LOAN_XCHG_RATE_CODE,
                                     L_LOAN_XCHG_RATE,
                                     P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('BC',
                             'Problem in converting amounts ' || P_ERR_CODE);
              RETURN FALSE;
            END IF;
          ELSE

            IF L_LOAN_PREF.CURRENCY = GLOBAL.LCY THEN
              DEBUG.PR_DEBUG('BC',
                             'Linked Loan Exchange Rate ' || C2.EX_RATE);
              L_LOAN_XCHG_RATE := C2.EX_RATE;

              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           INTERMEDIATE_TBL     (I).TAG_CCY,
                                           L_LOAN_PREF.CURRENCY,
                                           L_LOAN_XCHG_RATE_TYPE,
                                           L_LOAN_XCHG_RATE_CODE,
                                           INTERMEDIATE_TBL     (I).TAG_AMT,
                                           'Y',
                                           L_RET_AMT,
                                           L_LOAN_XCHG_RATE,
                                           P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('BC', 'Failed in converting amount');
                RETURN FALSE;
              END IF;

              DEBUG.PR_DEBUG('BC',
                             'Xchg rate for ' || INTERMEDIATE_TBL(I)
                             .TAG_CCY || ' to ' || L_LOAN_PREF.CURRENCY ||
                              ' = ' || L_LOAN_XCHG_RATE);
              DEBUG.PR_DEBUG('BC',
                             'FCY Amount after the conversion = ' ||
                             L_RET_AMT);

              IF INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN
                INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT;
                INTERMEDIATE_TBL(I).FCY_AMT := 0;
                INTERMEDIATE_TBL(I).ACC_CCY := L_LOAN_PREF.CURRENCY;
              ELSE
                INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT;
                INTERMEDIATE_TBL(I).FCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
              END IF;

              INTERMEDIATE_TBL(I).EXCH_RATE := L_LOAN_XCHG_RATE;

            ELSIF C2.COMPONENT_CCY = GLOBAL.LCY THEN

              L_LOAN_XCHG_RATE := C2.EX_RATE;

              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           INTERMEDIATE_TBL     (I).TAG_CCY,
                                           L_LOAN_PREF.CURRENCY,
                                           L_LOAN_XCHG_RATE_TYPE,
                                           L_LOAN_XCHG_RATE_CODE,
                                           INTERMEDIATE_TBL     (I).TAG_AMT,
                                           'Y',
                                           L_RET_AMT,
                                           L_LOAN_XCHG_RATE,
                                           P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('BC', 'Failed in converting amount');
                RETURN FALSE;
              END IF;

              IF INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN
                INTERMEDIATE_TBL(I).LCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
                INTERMEDIATE_TBL(I).FCY_AMT := L_RET_AMT;
                INTERMEDIATE_TBL(I).ACC_CCY := L_LOAN_PREF.CURRENCY;
              ELSE
                INTERMEDIATE_TBL(I).LCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
                INTERMEDIATE_TBL(I).FCY_AMT := 0;
              END IF;

              INTERMEDIATE_TBL(I).EXCH_RATE := L_LOAN_XCHG_RATE;

            ELSIF ((C2.COMPONENT_CCY <> GLOBAL.LCY) AND
                  (L_LOAN_PREF.CURRENCY <> GLOBAL.LCY)) THEN

              L_LOAN_XCHG_RATE := C2.EX_RATE;

              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           INTERMEDIATE_TBL     (I).TAG_CCY,
                                           L_LOAN_PREF.CURRENCY,
                                           L_LOAN_XCHG_RATE_TYPE,
                                           L_LOAN_XCHG_RATE_CODE,
                                           INTERMEDIATE_TBL     (I).TAG_AMT,
                                           'Y',
                                           L_RET_AMT,
                                           L_LOAN_XCHG_RATE,
                                           P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('BC', 'Failed in converting amount');
                RETURN FALSE;
              END IF;

              DEBUG.PR_DEBUG('BC',
                             'amount returned for tag to loan here is ' ||
                             L_RET_AMT);

              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           L_LOAN_PREF.CURRENCY,
                                           GLOBAL.LCY,
                                           L_LOAN_XCHG_RATE_TYPE,
                                           L_LOAN_XCHG_RATE_CODE,
                                           L_RET_AMT,
                                           'Y',
                                           L_RET_AMT_LCY,
                                           L_LOAN_XCHG_RATE_LCY,
                                           P_ERR_CODE) THEN
                DEBUG.PR_DEBUG('BC', 'Failed in converting amount');
                RETURN FALSE;
              END IF;

              DEBUG.PR_DEBUG('BC',
                             'amount returned for loan to global is ' ||
                             L_RET_AMT_LCY || '~' || L_LOAN_XCHG_RATE_LCY);

              IF INTERMEDIATE_TBL(I).DRCRIND = 'D' THEN
                INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT_LCY;
                INTERMEDIATE_TBL(I).FCY_AMT := L_RET_AMT;
                INTERMEDIATE_TBL(I).EXCH_RATE := L_LOAN_XCHG_RATE;
                INTERMEDIATE_TBL(I).ACC_CCY := L_LOAN_PREF.CURRENCY;
              ELSE
                INTERMEDIATE_TBL(I).LCY_AMT := L_RET_AMT_LCY;
                INTERMEDIATE_TBL(I).FCY_AMT := INTERMEDIATE_TBL(I).TAG_AMT;
                INTERMEDIATE_TBL(I).EXCH_RATE := L_LOAN_XCHG_RATE_LCY;
              END IF;
            END IF;

            DEBUG.PR_DEBUG('BC',
                           'intermediate_tbl(i).tag_ccy' || INTERMEDIATE_TBL(I)
                           .ACC_CCY);
            DEBUG.PR_DEBUG('BC',
                           'intermediate_tbl(i).exch_rate ' || INTERMEDIATE_TBL(I)
                           .EXCH_RATE);
            DEBUG.PR_DEBUG('BC',
                           'intermediate_tbl(i).lcy_amt' || INTERMEDIATE_TBL(I)
                           .LCY_AMT);
            DEBUG.PR_DEBUG('BC',
                           'intermediate_tbl(i).fcy_amt' || INTERMEDIATE_TBL(I)
                           .FCY_AMT);
          END IF;
        END IF;
      END LOOP;
    END LOOP;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC',
                     'When others in fn_lc_charges_transfer' || SQLERRM);
      RETURN FALSE;
  END FN_LC_CHARGES_TRANSFER;

  FUNCTION FN_STATUS_GLS(P_BCREFNO             IN CSTBS_CONTRACT.CONTRACT_REF_NO%TYPE,
                         P_EVENT_CODE          IN CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE,
                         P_USER_DEFINED_STATUS IN CSTBS_CONTRACT.USER_DEFINED_STATUS%TYPE,
                         P_ACC_LOOKUP_TBL      IN OUT ACPKSS.TBL_LOOKUP,
                         P_ERR_CODE            IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                         P_ERR_PARAMS          IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_GL_CAT VARCHAR2(4);
  BEGIN
    DEBUG.PR_DEBUG('BC', 'Inside -- fn_status_gls');
    IF NOT FN_DO_ACC_LOOKUP(P_BCREFNO,
                            P_EVENT_CODE,
                            'NORM',
                            P_ACC_LOOKUP_TBL,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DEBUG.PR_DEBUG('BC', 'fn_acc_lookup FAILED-' || SQLERRM);
      RETURN FALSE;
    END IF;
    DEBUG.PR_DEBUG('BC',
                   'Acc_lookup thru for LIQD event in contingent GLs');
    DEBUG.PR_DEBUG('BC', 'RETURNING TRUE FROM fn_status_gls ');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'fn_status_gls FAILED: ' || SQLERRM);
      RETURN FALSE;
  END;

  FUNCTION FN_ASSIGN_VIRTUALACC(P_BCREFNO    IN BCTBS_ICCF_MASTER.BCREFNO%TYPE,
                                P_ESN        IN BCTBS_ICCF_MASTER.PESN%TYPE,
                                P_TAG        IN VARCHAR2,
                                P_REALACC    IN VARCHAR2,
                                P_VIRTUALACC OUT VARCHAR2,
                                P_ERR_CODE   IN OUT VARCHAR2,
                                P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_UI_ACCOUNT     ISTB_CONTRACTIS.UI_ACCOUNT%TYPE;
    L_VIRTUALACC_CNT NUMBER;
    L_UI_ACCOUNT_CCY ISTB_CONTRACTIS.ACC_CCY%TYPE;
    L_UI_ACCOUNT_BRN ISTB_CONTRACTIS.ACC_BRANCH%TYPE;
    L_VIR_ACC_NAME   VARCHAR2(100);
    L_PHY_ACC        ISTB_CONTRACTIS.ACCOUNT%TYPE;

  BEGIN
    DEBUG.PR_DEBUG('BC',
                   'Inside -- fn_assign_virtualacc for the tag with account ' ||
                   P_TAG || P_REALACC);

    L_VIRTUALACC_CNT := 0;
    BEGIN
      SELECT UI_ACCOUNT, ACC_CCY, ACC_BRANCH
        INTO L_UI_ACCOUNT, L_UI_ACCOUNT_CCY, L_UI_ACCOUNT_BRN
        FROM ISTBS_CONTRACTIS
       WHERE CONTRACT_REF_NO = P_BCREFNO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM ISTBS_CONTRACTIS
               WHERE CONTRACT_REF_NO = P_BCREFNO)
         AND NVL(MIN_EVENT_SEQ_NO, 1) <= P_ESN
         AND AMOUNT_TAG = P_TAG;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('BC',
                       'Exception while selecting UI account for the tag  ' ||
                       P_TAG || SQLERRM);
        P_VIRTUALACC := NULL;
        RETURN TRUE;
    END;
    IF L_UI_ACCOUNT <> P_REALACC THEN
      DEBUG.PR_DEBUG('BC',
                     'Checking if the inputted UI account is a virtual account');

      SELECT COUNT(*)
        INTO L_VIRTUALACC_CNT
        FROM STTMS_CORE_ACCOUNT
       WHERE CUST_ACCOUNT_NO = L_UI_ACCOUNT
         AND ACCOUNT_CLASS = '10';

      IF L_VIRTUALACC_CNT > 0 THEN
        DEBUG.PR_DEBUG('BC',
                       'The inputted UI account is a virtual account');
        P_VIRTUALACC := L_UI_ACCOUNT;
      END IF;

    END IF;
    DEBUG.PR_DEBUG('BC', 'RETURNING TRUE FROM fn_assign_virtualacc ');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('BC', 'fn_assign_virtualacc FAILED: ' || SQLERRM);
      RETURN FALSE;
  END;

END BCPKS_ACC_ENTRIES;
/