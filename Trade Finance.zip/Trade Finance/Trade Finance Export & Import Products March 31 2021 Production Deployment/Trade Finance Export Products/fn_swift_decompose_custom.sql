CREATE OR REPLACE FUNCTION fn_swift_decompose_custom(P_DCN             IN VARCHAR2,
                                                     P_RUNNING_NO      IN NUMBER,
                                                     P_BROWSER_TYPE    IN CHAR DEFAULT 'OUT',
                                                     P_MSG_PASSED      IN CHAR DEFAULT 'N',
                                                     P_MSG_TYPE        IN VARCHAR2,
                                                     P_MESSAGE         IN VARCHAR2,
                                                     P_FN_CALL_ID      IN OUT NUMBER,
                                                     P_TB_CLUSTER_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
  RETURN BOOLEAN IS

  --sampath starts
  L_TRANSMSG         CLOB;
  L_MSTB_DLY_MSG_OUT MSTB_DLY_MSG_OUT%ROWTYPE;
  --sampath ends

BEGIN

  DEBUG.PR_DEBUG('MS', 'In fn_swift_decompose_custom');

  --sampath starts
  IF P_FN_CALL_ID = 5 THEN
  
    BEGIN
      SELECT *
        INTO L_MSTB_DLY_MSG_OUT
        FROM MSTB_DLY_MSG_OUT
       WHERE DCN = P_DCN;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('MS', 'ERROR CODE=' || SQLCODE);
        DEBUG.PR_DEBUG('MS', 'ERROR MESSAGE=' || SQLERRM);
    END;
  
    IF L_MSTB_DLY_MSG_OUT.SWIFT_MSG_TYPE = '700' THEN
    
      L_TRANSMSG := P_TB_CLUSTER_DATA('MESSAGE');
    
      L_TRANSMSG := REPLACE(L_TRANSMSG, '        :42A:', ':42A: Drawee'||CHR(10)||CHR(09));
      
      --L_TRANSMSG := REPLACE(L_TRANSMSG,':42D: Drawee',':42A: Drawee');
    
      P_TB_CLUSTER_DATA('MESSAGE') := L_TRANSMSG;
    
    END IF;
  
  END IF;
  --sampath ends

  RETURN TRUE;

EXCEPTION
  WHEN OTHERS THEN
    DEBUG.PR_DEBUG('MS', 'When others in fn_swift_decompose' || SQLERRM);
    DEBUG.PR_DEBUG('MS', 'Error Code' || SQLCODE);
    RETURN FALSE;
END;
