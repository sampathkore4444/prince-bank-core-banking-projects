CREATE OR REPLACE PACKAGE BODY cfpks_computation IS

  G_SKIP_CLUSTER BOOLEAN := FALSE;
  G_SKIP_CUSTOM  BOOLEAN := FALSE;
  G_SKIP_KERNEL  BOOLEAN := FALSE;

  FUNCTION FN_TIER_AMT_FLAT_TENOR(P_AMOUNT            IN CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE,
                                  P_ICCF_RULE         IN CFTMS_RULE%ROWTYPE,
                                  P_RATE              OUT CFTBS_CONTRACT_COMMISSION.RATE%TYPE,
                                  P_NUMBER_OF_PERIODS IN NUMBER,
                                  P_ROUNDING_PERIOD   IN CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD%TYPE,
                                  P_RATE_PERIOD       IN CFTBS_CONTRACT_COMMISSION.RATE_PERIOD%TYPE,
                                  P_TENOR             IN NUMBER,
                                  
                                  P_TENOR_IN_DAYS          IN NUMBER,
                                  P_TOTAL_DAYS             IN NUMBER,
                                  P_ERR_CODE               IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                  P_COMMISSION_AMOUNT_CALC OUT NUMBER,
                                  P_ORIGINAL_TAG_AMOUNT    IN NUMBER)
    RETURN BOOLEAN;

  FUNCTION FN_GET_GUD_REC(P_COMMISSION_REC            IN OUT TY_FOR_COMMISSION,
                          J                           IN INTEGER,
                          P_ICCF_RULE                 IN CFTMS_RULE%ROWTYPE,
                          P_CFTBS_CONTRACT_COMMISSION IN CFTBS_CONTRACT_COMMISSION%ROWTYPE,
                          P_TY_COMMISSION_GUD         IN OUT TY_COMMISSION_GOOD)
    RETURN BOOLEAN;

  FUNCTION FN_TIER_AMT_TIER_TENOR(P_TENOR            IN NUMBER,
                                  P_GOOD_UNTIL_TENOR IN NUMBER,
                                  
                                  P_TENOR_IN_DAYS          IN NUMBER,
                                  P_TOTAL_DAYS             IN NUMBER,
                                  P_ICCF_RULE              IN CFTMS_RULE%ROWTYPE,
                                  P_AMOUNT                 IN CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE,
                                  P_COMMISSION_AMOUNT_CALC OUT NUMBER,
                                  P_TIER_RATE              OUT CFTMS_BRACKET_TENOR.RATE%TYPE,
                                  P_ERR_CODE               IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                  P_ORIGINAL_TAG_AMOUNT    IN NUMBER)
    RETURN BOOLEAN;

  FUNCTION FN_TENOR_BASED_COMM_CALC(P_TENOR            IN NUMBER,
                                    P_GOOD_UNTIL_TENOR IN NUMBER,
                                    
                                    P_TENOR_IN_DAYS          IN NUMBER,
                                    P_TOTAL_DAYS             IN NUMBER,
                                    P_ICCF_RULE              IN CFTMS_RULE%ROWTYPE,
                                    P_AMOUNT                 IN CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE,
                                    P_COMMISSION_AMOUNT_CALC OUT NUMBER,
                                    P_TIER_RATE              OUT CFTMS_BRACKET_TENOR.RATE%TYPE,
                                    P_ERR_CODE               IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                    P_ORIGINAL_TAG_AMOUNT    IN NUMBER)
    RETURN BOOLEAN;

  FUNCTION FN_TIER_AMT_TENOR_COMM(P_TENOR            IN NUMBER,
                                  P_GOOD_UNTIL_TENOR IN NUMBER,
                                  
                                  P_TENOR_IN_DAYS          IN NUMBER,
                                  P_TOTAL_DAYS             IN NUMBER,
                                  P_ICCF_RULE              IN CFTMS_RULE%ROWTYPE,
                                  P_AMOUNT                 IN CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE,
                                  P_COMMISSION_AMOUNT_CALC OUT NUMBER,
                                  P_TIER_RATE              OUT CFTMS_BRACKET_TENOR.RATE%TYPE,
                                  P_ERR_CODE               IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                  P_ORIGINAL_TAG_AMOUNT    IN NUMBER,
                                  P_BASIS_AMOUNT_TO        NUMBER)
    RETURN BOOLEAN;
  L_PERIOD_DAYS NUMBER := 0;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    
    END IF;
  
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    
    ELSE
      RETURN G_SKIP_CLUSTER;
    
    END IF;
  
  END FN_SKIP_CLUSTER;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    
    ELSE
      RETURN G_SKIP_CUSTOM;
    
    END IF;
  
  END FN_SKIP_CUSTOM;

  FUNCTION FN_INT_COMPUTATION(P_TY_INT IN OUT TY_INT) RETURN BOOLEAN IS
    L_FIRST          NUMBER;
    L_COUNT          NUMBER;
    L_COMPONENT      CFTBS_CONTRACT_INTEREST.COMPONENT%TYPE;
    L_INTEREST_BASIS CFTBS_CONTRACT_INTEREST.INTEREST_BASIS%TYPE;
    L_INTEREST       NUMBER;
    L_ESN            CFTBS_CONTRACT_INTEREST.EVENT_SEQUENCE_NO%TYPE;
  
    L_DENOMINATOR_BASIS VARCHAR2(1);
    L_BASIS_366         VARCHAR2(1);
    L_NO_OF_INT_PERIOD  NUMBER;
    L_REFERENCE_NO      VARCHAR2(20);
  
    L_MAT_DATE  DATE := NULL;
    L_PENL_TYPE CFTBS_CONTRACT_INTEREST.PENALTY_TYPE%TYPE := 'N';
  
    L_RATE_TYPE CFTBS_CONTRACT_INTEREST.RATE_TYPE%TYPE;
  BEGIN
  
    IF NOT CFPKS_COMPUTATION.FN_SKIP_CUSTOM THEN
      DEBUG.PR_DEBUG('CF',
                     'Calling  cfpks_computation.fn_pre_int_computation!!');
      IF NOT CFPKS_COMPUTATION_CUSTOM.FN_PRE_INT_COMPUTATION(P_TY_INT) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT CFPKS_COMPUTATION.FN_SKIP_CLUSTER THEN
      DEBUG.PR_DEBUG('CF',
                     'Calling  cfpks_computation.fn_pre_int_computation!!');
      IF NOT CFPKS_COMPUTATION_CLUSTER.FN_PRE_INT_COMPUTATION(P_TY_INT) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT CFPKS_COMPUTATION.G_SKIP_KERNEL THEN
    
      L_FIRST     := P_TY_INT.FIRST;
      L_COMPONENT := P_TY_INT(L_FIRST).P_COMPONENT;
      L_COUNT     := P_TY_INT.COUNT;
    
      L_REFERENCE_NO := P_TY_INT(L_FIRST).P_CONTRACT_REFERENCE_NO;
    
      BEGIN
        SELECT DENOMINATOR_BASIS,
               BASIS_366,
               NO_OF_INT_PERIOD,
               PENALTY_TYPE,
               RATE_TYPE
          INTO L_DENOMINATOR_BASIS,
               L_BASIS_366,
               L_NO_OF_INT_PERIOD,
               L_PENL_TYPE,
               L_RATE_TYPE
          FROM CFTBS_CONTRACT_INTEREST
         WHERE CONTRACT_REFERENCE_NO = L_REFERENCE_NO
           AND COMPONENT = L_COMPONENT
           AND EVENT_SEQUENCE_NO =
               (SELECT MAX(EVENT_SEQUENCE_NO)
                  FROM CFTBS_CONTRACT_INTEREST
                 WHERE CONTRACT_REFERENCE_NO = L_REFERENCE_NO)
           AND PICKUP_EVENT_SEQUENCE_NO =
               (SELECT MAX(PICKUP_EVENT_SEQUENCE_NO)
                  FROM CFTBS_CONTRACT_INTEREST
                 WHERE CONTRACT_REFERENCE_NO = L_REFERENCE_NO);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_DENOMINATOR_BASIS := NULL;
          L_BASIS_366         := NULL;
          L_NO_OF_INT_PERIOD  := NULL;
          L_PENL_TYPE         := 'N';
          L_RATE_TYPE         := 'X';
      END;
    
      DEBUG.PR_DEBUG('CF',
                     'l_denominator_basis :: ' || L_DENOMINATOR_BASIS);
      DEBUG.PR_DEBUG('CF', 'l_basis_366 :: ' || L_BASIS_366);
      DEBUG.PR_DEBUG('CF', 'l_no_of_int_period :: ' || L_NO_OF_INT_PERIOD);
      DEBUG.PR_DEBUG('CF', 'l_penl_type :: ' || L_PENL_TYPE);
      DEBUG.PR_DEBUG('CF', 'l_rate_type :: ' || L_RATE_TYPE);
    
      IF L_PENL_TYPE = 'N' THEN
        BEGIN
          SELECT MATURITY_DATE
            INTO L_MAT_DATE
            FROM LDTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO = L_REFERENCE_NO
             AND VERSION_NO =
                 (SELECT MAX(VERSION_NO)
                    FROM LDTBS_CONTRACT_MASTER
                   WHERE CONTRACT_REF_NO = L_REFERENCE_NO);
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_MAT_DATE := NULL;
        END;
      END IF;
    
      IF L_RATE_TYPE != 'S' THEN
        FOR I IN L_FIRST .. L_COUNT LOOP
        
          IF P_TY_INT(I).P_INTEREST_BASIS IS NULL THEN
            SELECT MAX(EVENT_SEQUENCE_NO)
              INTO L_ESN
              FROM CFTBS_CONTRACT_INTEREST
             WHERE CONTRACT_REFERENCE_NO = P_TY_INT(I)
                  .P_CONTRACT_REFERENCE_NO;
          
            SELECT INTEREST_BASIS
              INTO P_TY_INT(I).P_INTEREST_BASIS
              FROM CFTBS_CONTRACT_INTEREST
             WHERE CONTRACT_REFERENCE_NO = P_TY_INT(I)
                  .P_CONTRACT_REFERENCE_NO
               AND COMPONENT = L_COMPONENT
               AND EVENT_SEQUENCE_NO = L_ESN
               AND PICKUP_EVENT_SEQUENCE_NO =
                   (SELECT MAX(PICKUP_EVENT_SEQUENCE_NO)
                      FROM CFTBS_CONTRACT_INTEREST
                     WHERE CONTRACT_REFERENCE_NO = L_REFERENCE_NO);
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'p_ty_int(i).p_end_date :: ' || P_TY_INT(I)
                         .P_END_DATE);
          DEBUG.PR_DEBUG('CF',
                         'p_ty_int(i).p_basis_amount :: ' || P_TY_INT(I)
                         .P_BASIS_AMOUNT);
          DEBUG.PR_DEBUG('CF',
                         'p_ty_int(i).p_interest_basis :: ' || P_TY_INT(I)
                         .P_INTEREST_BASIS);
          DEBUG.PR_DEBUG('CF',
                         'p_ty_int(i).p_rate :: ' || P_TY_INT(I).P_RATE);
          IF P_TY_INT(I).P_END_DATE IS NOT NULL THEN
            IF NOT
                CSPKSS_INTEREST.FN_CALC_INT(P_TY_INT     (I).P_BASIS_AMOUNT,
                                            P_TY_INT     (I).P_START_DATE,
                                            P_TY_INT     (I).P_END_DATE,
                                            P_TY_INT     (I).P_INTEREST_BASIS,
                                            P_TY_INT     (I).P_RATE,
                                            '0',
                                            L_PERIOD_DAYS,
                                            L_INTEREST
                                            
                                           ,
                                            L_DENOMINATOR_BASIS,
                                            L_BASIS_366,
                                            L_NO_OF_INT_PERIOD
                                            
                                           ,
                                            L_MAT_DATE) THEN
              DEBUG.PR_DEBUG('CF', 'calc interest failed');
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('CF',
                           'p_ty_int(i).p_basis_amount_currency :' || P_TY_INT(I)
                           .P_BASIS_AMOUNT_CURRENCY);
            DEBUG.PR_DEBUG('CF', 'l_interest :' || L_INTEREST);
            DEBUG.PR_DEBUG('CF',
                           'p_ty_int(i).p_int_amount :' || P_TY_INT(I)
                           .P_INT_AMOUNT);
          
            IF NOT CYPKSS.FN_AMT_ROUND(P_TY_INT  (I).P_BASIS_AMOUNT_CURRENCY,
                                       L_INTEREST,
                                       P_TY_INT  (I).P_INT_AMOUNT) THEN
              DEBUG.PR_DEBUG('CF', 'CYPKSS.fn_amt_round is failed ');
              RETURN FALSE;
            END IF;
            IF NOT CSPKSS_INTEREST.FN_DATE_DIFF(P_TY_INT  (I).P_START_DATE,
                                                P_TY_INT  (I).P_END_DATE,
                                                P_TY_INT  (I).P_INTEREST_BASIS,
                                                P_TY_INT  (I).P_NUMBER_OF_DAYS,
                                                P_MAT_DATE => L_MAT_DATE) THEN
              DEBUG.PR_DEBUG('CF', 'number of days failed');
              RETURN FALSE;
            END IF;
          END IF;
        
          IF P_TY_INT(I).P_INTEREST_BASIS IN (1, 2, 3, -4) THEN
            L_INTEREST_BASIS := 3;
          ELSIF P_TY_INT(I).P_INTEREST_BASIS IN (4, 5, 6, -6) THEN
            L_INTEREST_BASIS := 6;
          ELSIF P_TY_INT(I).P_INTEREST_BASIS IN (7, 8, 9, -3) THEN
            L_INTEREST_BASIS := 9;
          
          ELSIF P_TY_INT(I).P_INTEREST_BASIS IN (0, -1, -2, -5) THEN
            L_INTEREST_BASIS := 0;
          
          END IF;
          IF NOT
              CSPKSS_INTEREST.FN_CALC_INT(P_TY_INT        (I).P_BASIS_AMOUNT,
                                          P_TY_INT        (I).P_START_DATE,
                                          P_TY_INT        (I).P_START_DATE + 1,
                                          L_INTEREST_BASIS,
                                          P_TY_INT        (I).P_RATE,
                                          '0',
                                          L_PERIOD_DAYS,
                                          P_TY_INT        (I)
                                          .P_DAILY_INT_AMOUNT
                                          
                                         ,
                                          L_DENOMINATOR_BASIS,
                                          L_BASIS_366,
                                          L_NO_OF_INT_PERIOD
                                          
                                          ) THEN
            DEBUG.PR_DEBUG('CF', 'calc interest for one day failed');
            RETURN FALSE;
          END IF;
          DEBUG.PR_DEBUG('CF',
                         'p_ty_int(i).p_daily_int_amount :: ' || P_TY_INT(I)
                         .P_DAILY_INT_AMOUNT);
        END LOOP;
      END IF;
    
    END IF;
    IF NOT CFPKS_COMPUTATION.FN_SKIP_CLUSTER THEN
      DEBUG.PR_DEBUG('CF',
                     'Calling  cfpks_computation.fn_post_int_computation!!');
      IF NOT CFPKS_COMPUTATION_CLUSTER.FN_POST_INT_COMPUTATION(P_TY_INT) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT CFPKS_COMPUTATION.FN_SKIP_CUSTOM THEN
      DEBUG.PR_DEBUG('CF',
                     'Calling  cfpks_computation.fn_post_int_computation!!');
      IF NOT CFPKS_COMPUTATION_CUSTOM.FN_POST_INT_COMPUTATION(P_TY_INT) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CF', 'failed in interest ' || SQLERRM);
      RETURN FALSE;
  END FN_INT_COMPUTATION;

  FUNCTION FN_COMMISSION_COMPUTATION(P_TY_COMMISSION IN OUT TY_FOR_COMMISSION)
    RETURN BOOLEAN
  
   IS
    L_EVENT_SEQ_NO              CFTBS_CONTRACT_COMMISSION.EVENT_SEQ_NO%TYPE;
    L_FIRST                     NUMBER := 0;
    L_COUNT                     NUMBER := 0;
    L_ICCF_RULE                 CFTMS_RULE%ROWTYPE;
    L_CFTBS_CONTRACT_COMMISSION CFTBS_CONTRACT_COMMISSION%ROWTYPE;
    L_RULE                      CFTMS_RULE.RULE%TYPE;
    L_PRODUCT                   CSTBS_CONTRACT.PRODUCT_CODE%TYPE;
    L_BRANCH                    CSTBS_CONTRACT.BRANCH%TYPE;
    L_BOOK_DATE                 CSTBS_CONTRACT.BOOK_DATE%TYPE;
    L_SERIAL_NO                 CSTBS_CONTRACT.SERIAL_NO%TYPE;
    L_CURRENCY                  CFTMS_RULE.CURRENCY%TYPE;
    L_CURRENCY2                 CFTMS_RULE.CURRENCY2%TYPE;
    L_AMOUNT                    CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE;
    L_AMOUNT_FOR_SLAB           CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE;
    L_ROUND_AMOUNT              CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE;
    L_MAX_BASIS_AMOUNT_TO       CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE;
    L_MIN_BASIS_AMOUNT_TO       CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE;
    L_ICCF_BRACKET              CFTMS_BRACKET%ROWTYPE;
    L_CUSTOMER                  CFTMS_RULE.CUSTOMER%TYPE;
    L_NUMBER_OF_PERIODS         NUMBER := 0;
    L_CURRENT_DATE              CFTBS_CONTRACT_COMMISSION.TRANSACTION_DATE%TYPE;
    L_RATE                      CFTBS_CONTRACT_COMMISSION.RATE%TYPE;
    L_ROUNDING_PERIOD           CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD%TYPE;
    L_RATE_PERIOD               CFTBS_CONTRACT_COMMISSION.RATE_PERIOD%TYPE;
    L_COLLECTION_PERIOD         CFTBS_CONTRACT_COMMISSION.COLLECTION_PERIOD%TYPE;
    L_CALCULATION_METHOD        CFTBS_CONTRACT_COMMISSION.CALCULATION_METHOD%TYPE;
    DAY_OF_MONTH                VARCHAR2(2);
    MONTH_YEAR                  VARCHAR2(6);
    END_OF_MONTH                DATE;
  
    L_TXN_CCY       CFTMS_RULE.CURRENCY%TYPE;
    L_BASIS_AMT_CCY CFTMS_RULE.BASIS_AMOUNT_CCY%TYPE;
    L_ERR_CODE      VARCHAR2(100);
    L_CONVAMT       CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE;
    L_CCY_RATE      CYTMS_RATES.MID_RATE%TYPE;
  
    L_TENOR                      NUMBER := 0;
    L_EXPIRY_DATE_CALC           LCTBS_CONTRACT_MASTER.EXPIRY_DATE%TYPE;
    L_ICCF_BRACKET_TENOR         CFTMS_BRACKET_TENOR%ROWTYPE;
    L_MAX_TENOR_TO               CFTMS_BRACKET_TENOR.TENOR_TO%TYPE;
    L_MIN_TENOR_TO               CFTMS_BRACKET_TENOR.TENOR_TO%TYPE;
    COMMISSION_AMOUNT_CALC       NUMBER := 0;
    L_COMMISSION_CHARGE_CURRENCY CFTMS_RULE.BASIS_AMOUNT_CCY%TYPE;
    L_TIER_RATE                  CFTMS_BRACKET_TENOR.RATE%TYPE;
    L_TEMP                       COMMISSION_AMOUNT_CALC%TYPE;
    L_BASIS_AMOUNT_TYPE          CFTMS_PRODUCT_ICCF.BASIS_AMOUNT_TYPE%TYPE;
    L_RETROSPECTIVE_FLAG         CFTBS_CONTRACT_COMMISSION.RETROSPECTIVE_FLAG%TYPE;
    L_GOOD_UNTIL_TENOR           NUMBER := 0;
    L_GOOD_UNTIL_DATE            CFTBS_CONTRACT_COMMISSION.GOOD_UNTIL_DATE%TYPE;
    L_GOOD_UNTIL_AMOUNT          CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE;
    L_FIRST_TIME                 BOOLEAN := TRUE;
    L_ORIGINAL_TAG_AMOUNT        LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE := 0;
    L_MAX_CONTRACT_AMT           LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE := 0;
    L_AMOUNT_TAG                 CFTMS_PRODUCT_ICCF.BASIS_AMOUNT_TYPE%TYPE;
  
    L_CON_CCY             CFTMS_RULE.CURRENCY%TYPE;
    L_OLD_GOOD_UNTIL_DATE CFTBS_CONTRACT_COMMISSION.GOOD_UNTIL_DATE%TYPE;
  
    L_TENOR_IN_DAYS NUMBER := 0;
    L_YEAR          NUMBER;
    L_LEAP_YEAR     BOOLEAN;
    L_TOTAL_DAYS    NUMBER;
  
    L_CHARGE_GROUP   STTMS_CUSTOMER.CHARGE_GROUP%TYPE;
    L_CUSTOMER_GROUP CFTMS_RULE.CUSTOMER_GROUP%TYPE;
    L_BRANCH_CODE    CFTMS_RULE.BRANCH_CODE%TYPE := GLOBAL.CURRENT_BRANCH;
  
    L_INCLUDE_TO_DATE VARCHAR2(1);
    L_COMM_CALC_BASIS NUMBER := NULL;
    L_DAYS            NUMBER;
    L_TOTAL_COM_DAYS  NUMBER;
  
    L_RP_DTLS           COPKS_RP_PROCESSING.TY_REC_RP_DETAILS;
    L_MODULE            CSTMS_PRODUCT.MODULE%TYPE;
    L_ERROR_CODE        VARCHAR2(1000) := NULL;
    L_ERROR_PARAM       VARCHAR2(1000) := NULL;
    L_TY_COMMISSION_GUD CFPKSS_COMPUTATION.TY_COMMISSION_GOOD;
    L_NEW_GUD           DATE;
    START_OF_CENTURY    DATE := GLOBAL.MIN_DATE;
    L_CONTRACT_CCY      LCTBS_CONTRACT_MASTER.CONTRACT_CCY%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DEBUG.PR_DEBUG('CF',
                   'Inside cfpks_computation.fn_commission_computation');
  
    DEBUG.PR_DEBUG('CF',
                   'Inside cfpks_computation.fn_commission_computation  >>>' ||
                   CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_FN_CALL_ID      := 2;
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      DEBUG.PR_DEBUG('CF',
                     'Before Calling cfpks_computation_cluster.fn_commission_computation');
      IF NOT
          CFPKS_COMPUTATION_CLUSTER.FN_COMMISSION_COMPUTATION(P_TY_COMMISSION,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('CF',
                       'Failed in bcpks_bcdtronl_utils_cluster.fn_unlock');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      DEBUG.PR_DEBUG('CF', 'Inside Kernel Code');
    
      L_FIRST := P_TY_COMMISSION.FIRST;
      L_COUNT := P_TY_COMMISSION.COUNT;
    
      FOR I IN L_FIRST .. L_COUNT LOOP
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Computation - ' ||
                       L_FIRST || '  to  ' || L_COUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>component   - ' || P_TY_COMMISSION(I)
                       .P_COMPONENT);
      
        IF NOT CSPKES_MISC.FN_SPLITREFNO(P_TY_COMMISSION(I)
                                         .P_CONTRACT_REFERENCE_NO,
                                         L_BRANCH,
                                         L_PRODUCT,
                                         L_BOOK_DATE,
                                         L_SERIAL_NO) THEN
          RETURN FALSE;
        END IF;
      
        SELECT MAX(EVENT_SEQ_NO)
          INTO L_EVENT_SEQ_NO
          FROM CFTBS_CONTRACT_COMMISSION
         WHERE CONTRACT_REFERENCE_NO = P_TY_COMMISSION(I)
              .P_CONTRACT_REFERENCE_NO
           AND COMPONENT = P_TY_COMMISSION(I).P_COMPONENT
           AND PICKUP_EVENT_SEQUENCE_NO = P_TY_COMMISSION(I).P_PESN;
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Latest ESN     - ' ||
                       L_EVENT_SEQ_NO);
      
        BEGIN
          SELECT *
            INTO L_CFTBS_CONTRACT_COMMISSION
            FROM CFTBS_CONTRACT_COMMISSION
           WHERE CONTRACT_REFERENCE_NO = P_TY_COMMISSION(I)
                .P_CONTRACT_REFERENCE_NO
             AND EVENT_SEQ_NO = L_EVENT_SEQ_NO
             AND PICKUP_EVENT_SEQUENCE_NO = P_TY_COMMISSION(I).P_PESN
             AND COMPONENT = P_TY_COMMISSION(I).P_COMPONENT;
        
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>New records - ' || P_TY_COMMISSION(I)
                           .P_CONTRACT_REFERENCE_NO || ' ESN - ' ||
                            L_EVENT_SEQ_NO || ' PESN ' || P_TY_COMMISSION(I)
                           .P_COMPONENT || ' Comp - ' || P_TY_COMMISSION(I)
                           .P_COMPONENT);
          
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>Err - ' || SQLERRM);
          
        END;
        DEBUG.PR_DEBUG('CF',
                       ' retrospective_flag >>> ' ||
                       L_CFTBS_CONTRACT_COMMISSION.RETROSPECTIVE_FLAG);
      
        L_RETROSPECTIVE_FLAG := NVL(P_TY_COMMISSION(I).P_RETROSPECTIVE_FLAG,
                                    NVL(L_CFTBS_CONTRACT_COMMISSION.RETROSPECTIVE_FLAG,
                                        'N'));
        L_GOOD_UNTIL_DATE    := NULL;
        L_GOOD_UNTIL_AMOUNT  := 0;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation> - retrospective_flag now set to ' ||
                       L_RETROSPECTIVE_FLAG);
      
        BEGIN
          SELECT A.GOOD_UNTIL_DATE, A.AMOUNT
            INTO L_GOOD_UNTIL_DATE, L_GOOD_UNTIL_AMOUNT
            FROM CFTBS_CONTRACT_COMMISSION A
           WHERE CONTRACT_REFERENCE_NO = P_TY_COMMISSION(I)
                .P_CONTRACT_REFERENCE_NO
             AND COMPONENT = P_TY_COMMISSION(I).P_COMPONENT
             AND PICKUP_EVENT_SEQUENCE_NO = P_TY_COMMISSION(I).P_PESN
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM CFTBS_CONTRACT_COMMISSION
                   WHERE CONTRACT_REFERENCE_NO = P_TY_COMMISSION(I)
                        .P_CONTRACT_REFERENCE_NO
                     AND COMPONENT = P_TY_COMMISSION(I).P_COMPONENT
                     AND PICKUP_EVENT_SEQUENCE_NO = P_TY_COMMISSION(I)
                        .P_PESN
                     AND EVENT_SEQ_NO < L_EVENT_SEQ_NO);
          L_FIRST_TIME := FALSE;
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>selected l_good_until_date as ' ||
                         L_GOOD_UNTIL_DATE);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>selected l_good_until_amount as ' ||
                         L_GOOD_UNTIL_AMOUNT);
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>This is first time calculation ');
            L_FIRST_TIME := TRUE;
          
        END;
      
        SELECT RULE, BASIS_AMOUNT_TYPE
          INTO L_RULE, L_BASIS_AMOUNT_TYPE
          FROM CFTMS_PRODUCT_ICCF
         WHERE PRODUCT = L_PRODUCT
           AND COMPONENT = P_TY_COMMISSION(I).P_COMPONENT;
      
        BEGIN
          SELECT NVL(CHARGE_GROUP, 'ALL')
            INTO L_CHARGE_GROUP
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = P_TY_COMMISSION(I).P_CUSTOMER
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_CHARGE_GROUP := 'ALL';
        END;
      
        BEGIN
          SELECT *
            INTO L_ICCF_RULE
            FROM CFTMS_RULE
           WHERE RULE = L_RULE
             AND CUSTOMER = P_TY_COMMISSION(I).P_CUSTOMER
             AND CURRENCY = P_TY_COMMISSION(I).P_BASIS_AMOUNT_CURRENCY
             AND CURRENCY2 = P_TY_COMMISSION(I).P_BASIS_AMOUNT_CURRENCY
             AND CUSTOMER_GROUP = L_CHARGE_GROUP
             AND BRANCH_CODE = L_BRANCH_CODE
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        
          L_CURRENCY       := P_TY_COMMISSION(I).P_BASIS_AMOUNT_CURRENCY;
          L_CURRENCY2      := P_TY_COMMISSION(I).P_BASIS_AMOUNT_CURRENCY;
          L_CUSTOMER       := P_TY_COMMISSION(I).P_CUSTOMER;
          L_CUSTOMER_GROUP := L_CHARGE_GROUP;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT *
                INTO L_ICCF_RULE
                FROM CFTMS_RULE
               WHERE RULE = L_RULE
                 AND CUSTOMER = P_TY_COMMISSION(I).P_CUSTOMER
                 AND CURRENCY = 'ALL'
                 AND CURRENCY2 = 'ALL'
                 AND CUSTOMER_GROUP = L_CHARGE_GROUP
                 AND BRANCH_CODE = L_BRANCH_CODE
                 AND AUTH_STAT = 'A'
                 AND RECORD_STAT = 'O';
            
              L_CURRENCY       := 'ALL';
              L_CURRENCY2      := 'ALL';
              L_CUSTOMER       := P_TY_COMMISSION(I).P_CUSTOMER;
              L_CUSTOMER_GROUP := L_CHARGE_GROUP;
            
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
              
                BEGIN
                  SELECT *
                    INTO L_ICCF_RULE
                    FROM CFTMS_RULE
                   WHERE RULE = L_RULE
                     AND CUSTOMER = 'ALL'
                     AND CURRENCY = P_TY_COMMISSION(I)
                        .P_BASIS_AMOUNT_CURRENCY
                     AND CURRENCY2 = P_TY_COMMISSION(I)
                        .P_BASIS_AMOUNT_CURRENCY
                     AND CUSTOMER_GROUP = L_CHARGE_GROUP
                     AND BRANCH_CODE = L_BRANCH_CODE
                     AND AUTH_STAT = 'A'
                     AND RECORD_STAT = 'O';
                
                  L_CURRENCY       := P_TY_COMMISSION(I)
                                      .P_BASIS_AMOUNT_CURRENCY;
                  L_CURRENCY2      := P_TY_COMMISSION(I)
                                      .P_BASIS_AMOUNT_CURRENCY;
                  L_CUSTOMER       := 'ALL';
                  L_CUSTOMER_GROUP := L_CHARGE_GROUP;
                
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                  
                    BEGIN
                      SELECT *
                        INTO L_ICCF_RULE
                        FROM CFTMS_RULE
                       WHERE RULE = L_RULE
                         AND CUSTOMER = 'ALL'
                         AND CURRENCY = P_TY_COMMISSION(I)
                            .P_BASIS_AMOUNT_CURRENCY
                         AND CURRENCY2 = P_TY_COMMISSION(I)
                            .P_BASIS_AMOUNT_CURRENCY
                         AND CUSTOMER_GROUP = 'ALL'
                         AND BRANCH_CODE = L_BRANCH_CODE
                         AND AUTH_STAT = 'A'
                         AND RECORD_STAT = 'O';
                    
                      L_CURRENCY       := P_TY_COMMISSION(I)
                                          .P_BASIS_AMOUNT_CURRENCY;
                      L_CURRENCY2      := P_TY_COMMISSION(I)
                                          .P_BASIS_AMOUNT_CURRENCY;
                      L_CUSTOMER       := 'ALL';
                      L_CUSTOMER_GROUP := 'ALL';
                    
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                      
                        BEGIN
                          SELECT *
                            INTO L_ICCF_RULE
                            FROM CFTMS_RULE
                           WHERE RULE = L_RULE
                             AND CUSTOMER = 'ALL'
                             AND CURRENCY = 'ALL'
                             AND CURRENCY2 = 'ALL'
                             AND CUSTOMER_GROUP = L_CHARGE_GROUP
                             AND BRANCH_CODE = L_BRANCH_CODE
                             AND AUTH_STAT = 'A'
                             AND RECORD_STAT = 'O';
                        
                          L_CURRENCY       := 'ALL';
                          L_CURRENCY2      := 'ALL';
                          L_CUSTOMER       := 'ALL';
                          L_CUSTOMER_GROUP := L_CHARGE_GROUP;
                        
                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                          
                            BEGIN
                              SELECT *
                                INTO L_ICCF_RULE
                                FROM CFTMS_RULE
                               WHERE RULE = L_RULE
                                 AND CUSTOMER = 'ALL'
                                 AND CURRENCY = 'ALL'
                                 AND CURRENCY2 = 'ALL'
                                 AND CUSTOMER_GROUP = 'ALL'
                                 AND BRANCH_CODE = L_BRANCH_CODE
                                 AND AUTH_STAT = 'A'
                                 AND RECORD_STAT = 'O';
                            
                              L_CURRENCY       := 'ALL';
                              L_CURRENCY2      := 'ALL';
                              L_CUSTOMER       := 'ALL';
                              L_CUSTOMER_GROUP := 'ALL';
                            
                            EXCEPTION
                              WHEN NO_DATA_FOUND THEN
                              
                                BEGIN
                                  SELECT *
                                    INTO L_ICCF_RULE
                                    FROM CFTMS_RULE
                                   WHERE RULE = L_RULE
                                     AND CUSTOMER = P_TY_COMMISSION(I)
                                        .P_CUSTOMER
                                     AND CURRENCY = P_TY_COMMISSION(I)
                                        .P_BASIS_AMOUNT_CURRENCY
                                     AND CURRENCY2 = P_TY_COMMISSION(I)
                                        .P_BASIS_AMOUNT_CURRENCY
                                     AND CUSTOMER_GROUP = L_CHARGE_GROUP
                                     AND BRANCH_CODE = 'ALL'
                                     AND AUTH_STAT = 'A'
                                     AND RECORD_STAT = 'O';
                                
                                  L_CURRENCY       := P_TY_COMMISSION(I)
                                                      .P_BASIS_AMOUNT_CURRENCY;
                                  L_CURRENCY2      := P_TY_COMMISSION(I)
                                                      .P_BASIS_AMOUNT_CURRENCY;
                                  L_CUSTOMER       := P_TY_COMMISSION(I)
                                                      .P_CUSTOMER;
                                  L_CUSTOMER_GROUP := L_CHARGE_GROUP;
                                  L_BRANCH_CODE    := 'ALL';
                                
                                EXCEPTION
                                  WHEN NO_DATA_FOUND THEN
                                  
                                    BEGIN
                                      SELECT *
                                        INTO L_ICCF_RULE
                                        FROM CFTMS_RULE
                                       WHERE RULE = L_RULE
                                         AND CUSTOMER = P_TY_COMMISSION(I)
                                            .P_CUSTOMER
                                         AND CURRENCY = 'ALL'
                                         AND CURRENCY2 = 'ALL'
                                         AND CUSTOMER_GROUP =
                                             L_CHARGE_GROUP
                                         AND BRANCH_CODE = 'ALL'
                                         AND AUTH_STAT = 'A'
                                         AND RECORD_STAT = 'O';
                                    
                                      L_CURRENCY       := 'ALL';
                                      L_CURRENCY2      := 'ALL';
                                      L_CUSTOMER       := P_TY_COMMISSION(I)
                                                          .P_CUSTOMER;
                                      L_CUSTOMER_GROUP := L_CHARGE_GROUP;
                                      L_BRANCH_CODE    := 'ALL';
                                    
                                    EXCEPTION
                                      WHEN NO_DATA_FOUND THEN
                                      
                                        BEGIN
                                          SELECT *
                                            INTO L_ICCF_RULE
                                            FROM CFTMS_RULE
                                           WHERE RULE = L_RULE
                                             AND CUSTOMER = 'ALL'
                                             AND CURRENCY = P_TY_COMMISSION(I)
                                                .P_BASIS_AMOUNT_CURRENCY
                                             AND CURRENCY2 = P_TY_COMMISSION(I)
                                                .P_BASIS_AMOUNT_CURRENCY
                                             AND CUSTOMER_GROUP =
                                                 L_CHARGE_GROUP
                                             AND BRANCH_CODE = 'ALL'
                                             AND AUTH_STAT = 'A'
                                             AND RECORD_STAT = 'O';
                                        
                                          L_CURRENCY       := P_TY_COMMISSION(I)
                                                              .P_BASIS_AMOUNT_CURRENCY;
                                          L_CURRENCY2      := P_TY_COMMISSION(I)
                                                              .P_BASIS_AMOUNT_CURRENCY;
                                          L_CUSTOMER       := 'ALL';
                                          L_CUSTOMER_GROUP := L_CHARGE_GROUP;
                                          L_BRANCH_CODE    := 'ALL';
                                        
                                        EXCEPTION
                                          WHEN NO_DATA_FOUND THEN
                                          
                                            BEGIN
                                              SELECT *
                                                INTO L_ICCF_RULE
                                                FROM CFTMS_RULE
                                               WHERE RULE = L_RULE
                                                 AND CUSTOMER = 'ALL'
                                                 AND CURRENCY = P_TY_COMMISSION(I)
                                                    .P_BASIS_AMOUNT_CURRENCY
                                                 AND CURRENCY2 = P_TY_COMMISSION(I)
                                                    .P_BASIS_AMOUNT_CURRENCY
                                                 AND CUSTOMER_GROUP = 'ALL'
                                                 AND BRANCH_CODE = 'ALL'
                                                 AND AUTH_STAT = 'A'
                                                 AND RECORD_STAT = 'O';
                                            
                                              L_CURRENCY       := P_TY_COMMISSION(I)
                                                                  .P_BASIS_AMOUNT_CURRENCY;
                                              L_CURRENCY2      := P_TY_COMMISSION(I)
                                                                  .P_BASIS_AMOUNT_CURRENCY;
                                              L_CUSTOMER       := 'ALL';
                                              L_CUSTOMER_GROUP := 'ALL';
                                              L_BRANCH_CODE    := 'ALL';
                                            
                                            EXCEPTION
                                              WHEN NO_DATA_FOUND THEN
                                              
                                                BEGIN
                                                  SELECT *
                                                    INTO L_ICCF_RULE
                                                    FROM CFTMS_RULE
                                                   WHERE RULE = L_RULE
                                                     AND CUSTOMER = 'ALL'
                                                     AND CURRENCY = 'ALL'
                                                     AND CURRENCY2 = 'ALL'
                                                     AND CUSTOMER_GROUP =
                                                         L_CHARGE_GROUP
                                                     AND BRANCH_CODE =
                                                         'ALL'
                                                     AND AUTH_STAT = 'A'
                                                     AND RECORD_STAT = 'O';
                                                
                                                  L_CURRENCY       := 'ALL';
                                                  L_CURRENCY2      := 'ALL';
                                                  L_CUSTOMER       := 'ALL';
                                                  L_CUSTOMER_GROUP := L_CHARGE_GROUP;
                                                  L_BRANCH_CODE    := 'ALL';
                                                
                                                EXCEPTION
                                                  WHEN NO_DATA_FOUND THEN
                                                  
                                                    BEGIN
                                                      SELECT *
                                                        INTO L_ICCF_RULE
                                                        FROM CFTMS_RULE
                                                       WHERE RULE = L_RULE
                                                         AND CURRENCY =
                                                             'ALL'
                                                         AND CURRENCY2 =
                                                             'ALL'
                                                         AND CUSTOMER =
                                                             'ALL'
                                                         AND CUSTOMER_GROUP =
                                                             'ALL'
                                                         AND BRANCH_CODE =
                                                             'ALL'
                                                         AND AUTH_STAT = 'A'
                                                         AND RECORD_STAT = 'O';
                                                    
                                                      L_CURRENCY       := 'ALL';
                                                      L_CURRENCY2      := 'ALL';
                                                      L_CUSTOMER       := 'ALL';
                                                      L_CUSTOMER_GROUP := 'ALL';
                                                      L_BRANCH_CODE    := 'ALL';
                                                    
                                                    EXCEPTION
                                                      WHEN NO_DATA_FOUND THEN
                                                        RETURN FALSE;
                                                    END;
                                                END;
                                            END;
                                        END;
                                    END;
                                END;
                            END;
                        END;
                    END;
                END;
            END;
        END;
      
        IF L_ICCF_RULE.ROUNDING_PERIOD IS NULL THEN
          L_ICCF_RULE.ROUNDING_PERIOD := 0;
        END IF;
      
        L_AMOUNT        := P_TY_COMMISSION(I).P_BASIS_AMOUNT;
        L_BASIS_AMT_CCY := L_ICCF_RULE.BASIS_AMOUNT_CCY;
      
        SELECT BASIS_AMOUNT_TYPE
          INTO L_AMOUNT_TAG
          FROM CFTMS_PRODUCT_ICCF
         WHERE PRODUCT = L_PRODUCT
           AND COMPONENT = P_TY_COMMISSION(I).P_COMPONENT;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>cascade amount is set to ' ||
                       (NVL(L_ICCF_RULE.CASCADE_AMOUNT, 'N')));
      
        IF NVL(L_ICCF_RULE.CASCADE_AMOUNT, 'N') = 'Y' AND
           L_AMOUNT_TAG IN ('LC_AMND_AMT', 'LIAB_AMND_AMT') THEN
          DEBUG.PR_DEBUG('CF',
                         '25564998::going to fetch l_max_contract_amt and l_contract_ccy ');
          DEBUG.PR_DEBUG('CF',
                         '25564998::p_ty_commission(i).p_contract_reference_no-->  ' || P_TY_COMMISSION(I)
                         .P_CONTRACT_REFERENCE_NO);
        
          SELECT MAX_CONTRACT_AMT, A.CONTRACT_CCY
            INTO L_MAX_CONTRACT_AMT, L_CONTRACT_CCY
          
            FROM LCTBS_CONTRACT_MASTER A, CSTBS_CONTRACT B
           WHERE A.CONTRACT_REF_NO = P_TY_COMMISSION(I)
                .P_CONTRACT_REFERENCE_NO
             AND A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
             AND A.VERSION_NO = B.LATEST_VERSION_NO;
        
          DEBUG.PR_DEBUG('CF',
                         '25564998::l_max_contract_amt->  ' ||
                         L_MAX_CONTRACT_AMT);
          DEBUG.PR_DEBUG('CF',
                         '25564998::l_contract_ccy->  ' || L_CONTRACT_CCY);
        
          BEGIN
            DEBUG.PR_DEBUG('CF',
                           '25564998::going to fetch l_original_tag_amount ');
            SELECT MAX_CONTRACT_AMT
              INTO L_ORIGINAL_TAG_AMOUNT
              FROM LCTBS_CONTRACT_MASTER A, CSTBS_CONTRACT B
             WHERE A.CONTRACT_REF_NO = P_TY_COMMISSION(I)
                  .P_CONTRACT_REFERENCE_NO
               AND A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
               AND A.VERSION_NO = (B.LATEST_VERSION_NO - 1);
          
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>original tag amount is ' ||
                           L_ORIGINAL_TAG_AMOUNT);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DEBUG.PR_DEBUG('CF', '25564998::In exception -->' || SQLERRM);
              L_ORIGINAL_TAG_AMOUNT := 0;
          END;
          DEBUG.PR_DEBUG('CF',
                         '25564998::l_original_tag_amount->  ' ||
                         L_ORIGINAL_TAG_AMOUNT);
        
        ELSE
          DEBUG.PR_DEBUG('CF',
                         '25564998::in else making l_original_tag_amount to 0');
          L_ORIGINAL_TAG_AMOUNT := 0;
        END IF;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Resolved basis amt ccy in com comm ' ||
                       L_BASIS_AMT_CCY);
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>l_contract_ccy: ' ||
                       L_CONTRACT_CCY);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>p_ty_commission(i).p_basis_amount_currency: ' || P_TY_COMMISSION(I)
                       .P_BASIS_AMOUNT_CURRENCY);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>l_original_tag_amount: ' ||
                       L_ORIGINAL_TAG_AMOUNT);
        IF L_CONTRACT_CCY <> P_TY_COMMISSION(I).P_BASIS_AMOUNT_CURRENCY AND
           NVL(L_ORIGINAL_TAG_AMOUNT, 0) <> 0 THEN
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                        L_CONTRACT_CCY,
                                        L_BASIS_AMT_CCY,
                                        NVL(L_ICCF_RULE.RATE_CODE, 'STANDARD'),
                                        NVL(L_ICCF_RULE.RATE_CODE_TYPE, 'M'),
                                        TO_NUMBER(L_ORIGINAL_TAG_AMOUNT),
                                        'N',
                                        L_ORIGINAL_TAG_AMOUNT,
                                        L_CCY_RATE,
                                        L_ERR_CODE) THEN
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>Failed to convert amount' ||
                           L_ERR_CODE);
            RETURN FALSE;
          END IF;
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>l_rate ' ||
                         TO_CHAR(L_CCY_RATE));
          L_ORIGINAL_TAG_AMOUNT := TO_CHAR(L_ORIGINAL_TAG_AMOUNT);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>new l_original_tag_amount ' ||
                         L_ORIGINAL_TAG_AMOUNT);
        END IF;
      
        L_AMOUNT_FOR_SLAB := P_TY_COMMISSION(I)
                             .P_BASIS_AMOUNT + L_ORIGINAL_TAG_AMOUNT;
        L_TXN_CCY         := P_TY_COMMISSION(I).P_BASIS_AMOUNT_CURRENCY;
      
        L_CON_CCY := P_TY_COMMISSION(I).P_COMMISSION_CURRENCY;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>l_txn_ccy    :' ||
                       L_TXN_CCY);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>l_basis_amt_ccy  :' ||
                       L_BASIS_AMT_CCY || '-component no-' || I);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>l_amount_for_slab  :' ||
                       TO_CHAR(L_AMOUNT_FOR_SLAB));
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Lcy basis Amt   : ' || P_TY_COMMISSION(I)
                       .P_BASIS_AMOUNT_LCY_EQUIV);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Basis Amt  : ' || P_TY_COMMISSION(I)
                       .P_BASIS_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Customer= ' || L_CUSTOMER ||
                       '   ccy=' || L_CURRENCY || ' for all pickup ');
      
        BEGIN
        
          IF L_TXN_CCY <> L_BASIS_AMT_CCY THEN
          
            IF NOT
                CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH
                                       
                                      ,
                                       L_TXN_CCY
                                       
                                      ,
                                       L_BASIS_AMT_CCY,
                                       NVL(L_ICCF_RULE.RATE_CODE, 'STANDARD'),
                                       NVL(L_ICCF_RULE.RATE_CODE_TYPE, 'M'),
                                       TO_NUMBER(L_AMOUNT_FOR_SLAB),
                                       'N',
                                       L_CONVAMT,
                                       L_CCY_RATE,
                                       L_ERR_CODE) THEN
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>Failed to convert amount' ||
                             L_ERR_CODE);
              RETURN FALSE;
            END IF;
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>l_rate ' ||
                           TO_CHAR(L_CCY_RATE));
            L_AMOUNT_FOR_SLAB := TO_CHAR(L_CONVAMT);
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>new l_convAmt ' ||
                           L_CONVAMT);
          
            L_AMOUNT := L_AMOUNT_FOR_SLAB;
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>l_amount ' ||
                           TO_CHAR(L_AMOUNT));
          END IF;
        
          SELECT *
            INTO L_ICCF_BRACKET
            FROM CFTMS_BRACKET
           WHERE RULE = L_RULE
             AND CURRENCY = L_CURRENCY
             AND CURRENCY2 = L_CURRENCY
             AND CUSTOMER = L_CUSTOMER
             AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
             AND BRANCH_CODE = L_BRANCH_CODE
             AND L_AMOUNT_FOR_SLAB <= BASIS_AMOUNT_TO
             AND L_AMOUNT_FOR_SLAB >= BASIS_AMOUNT_FROM;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT MAX(BASIS_AMOUNT_TO), MIN(BASIS_AMOUNT_TO)
              INTO L_MAX_BASIS_AMOUNT_TO, L_MIN_BASIS_AMOUNT_TO
              FROM CFTMS_BRACKET
             WHERE RULE = L_RULE
               AND CURRENCY = L_CURRENCY
               AND CURRENCY2 = L_CURRENCY2
               AND CUSTOMER = L_CUSTOMER
               AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
               AND BRANCH_CODE = L_BRANCH_CODE;
          
            IF L_AMOUNT_FOR_SLAB > L_MAX_BASIS_AMOUNT_TO THEN
              SELECT *
                INTO L_ICCF_BRACKET
                FROM CFTMS_BRACKET
               WHERE RULE = L_RULE
                 AND CURRENCY = L_CURRENCY
                 AND CURRENCY2 = L_CURRENCY2
                 AND CUSTOMER = L_CUSTOMER
                 AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
                 AND BRANCH_CODE = L_BRANCH_CODE
                 AND BASIS_AMOUNT_TO = L_MAX_BASIS_AMOUNT_TO;
            ELSE
              SELECT *
                INTO L_ICCF_BRACKET
                FROM CFTMS_BRACKET
               WHERE RULE = L_RULE
                 AND CURRENCY = L_CURRENCY
                 AND CURRENCY2 = L_CURRENCY2
                 AND CUSTOMER = L_CUSTOMER
                 AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
                 AND BRANCH_CODE = L_BRANCH_CODE
                 AND BASIS_AMOUNT_TO = L_MIN_BASIS_AMOUNT_TO;
            END IF;
        END;
      
        L_EXPIRY_DATE_CALC := P_TY_COMMISSION(I).P_END_DATE;
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>End Date is  ' ||
                       L_EXPIRY_DATE_CALC);
      
        IF L_CFTBS_CONTRACT_COMMISSION.STOP_DATE IS NOT NULL THEN
          IF P_TY_COMMISSION(I)
           .P_END_DATE > L_CFTBS_CONTRACT_COMMISSION.STOP_DATE THEN
            L_EXPIRY_DATE_CALC := L_CFTBS_CONTRACT_COMMISSION.STOP_DATE;
          END IF;
        END IF;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation> Calculating Commission till ' ||
                       L_EXPIRY_DATE_CALC);
      
        BEGIN
          SELECT NVL(INCLUDE_TO_DATE, 'Y')
            INTO L_INCLUDE_TO_DATE
            FROM LCTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO = P_TY_COMMISSION(I)
                .P_CONTRACT_REFERENCE_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_CONTRACT_MASTER
                   WHERE CONTRACT_REF_NO = P_TY_COMMISSION(I)
                        .P_CONTRACT_REFERENCE_NO);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('CF',
                           'BOMBED WHILE SELECTING INC TO DATE 1->' ||
                           SQLERRM);
            RETURN FALSE;
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CF',
                           'BOMBED WHILE SELECTING INC TO DATE 2->' ||
                           SQLERRM);
            RETURN FALSE;
        END;
      
        DEBUG.PR_DEBUG('CF',
                       'b4 select baba->COMM CALC METHOD->' ||
                       L_CFTBS_CONTRACT_COMMISSION.COMM_CALC_BASIS);
        DEBUG.PR_DEBUG('CF',
                       'b4 select baba->COMM CALC METHOD->' || P_TY_COMMISSION(I)
                       .P_ROUNDING_PERIOD);
        DEBUG.PR_DEBUG('CF',
                       'b4 select baba->COMM CALC METHOD->' ||
                       L_ICCF_RULE.ROUNDING_PERIOD);
      
        DEBUG.PR_DEBUG('CF',
                       'b4 select baba->BASIS AMT CCY IS ->' || P_TY_COMMISSION(I)
                       .P_BASIS_AMOUNT_CURRENCY);
        DEBUG.PR_DEBUG('CF',
                       'b4 select baba->COMM CCY IS->' || P_TY_COMMISSION(I)
                       .P_COMMISSION_CURRENCY);
        IF L_CFTBS_CONTRACT_COMMISSION.COMM_CALC_BASIS IS NULL THEN
          DEBUG.PR_DEBUG('CF', 'ENTERED BECOS CFTBS_COMM IS NULL');
          BEGIN
            SELECT NVL(COMM_CALC_BASIS, 9)
              INTO L_COMM_CALC_BASIS
              FROM CFTMS_PRODUCT_COMCALC_BASIS
             WHERE PRODUCT =
                   SUBSTR(P_TY_COMMISSION(I).P_CONTRACT_REFERENCE_NO, 4, 4)
               AND COMPONENT = P_TY_COMMISSION(I).P_COMPONENT
               AND CURRENCY = P_TY_COMMISSION(I).P_COMMISSION_CURRENCY;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DEBUG.PR_DEBUG('CF',
                             'IN WNDF WHILE SELECTING CALC METHOD FROM MAIN TABLE');
              BEGIN
                SELECT NVL(CCY_INT_METHOD, 9)
                  INTO L_COMM_CALC_BASIS
                  FROM CYTMS_CCY_DEFN
                 WHERE CCY_CODE = P_TY_COMMISSION(I).P_COMMISSION_CURRENCY
                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A';
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DEBUG.PR_DEBUG('CF',
                                 'IN WNDF WHILE SELECTING CALC METHOD FROM CYTM_CCY_DEFN');
                  RETURN FALSE;
                WHEN OTHERS THEN
                  DEBUG.PR_DEBUG('CF',
                                 'IN WO WHILE SELECTING CALC METHOD FROM CYTM_CCY_DEFN->' ||
                                 SQLERRM);
                  RETURN FALSE;
              END;
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('CF',
                             'IN WO WHILE SELECTING CALC METHOD FROM MAIN TABLE->' ||
                             SQLERRM);
              RETURN FALSE;
          END;
        ELSE
          DEBUG.PR_DEBUG('CF', 'ENTERED BECOS CFTBS_COMM IS NOT NULL');
          L_COMM_CALC_BASIS := L_CFTBS_CONTRACT_COMMISSION.COMM_CALC_BASIS;
        END IF;
      
        L_YEAR      := TO_CHAR(P_TY_COMMISSION(I).P_START_DATE, 'YYYY');
        L_LEAP_YEAR := CEPKSS_DATE.FN_ISLEAPYEAR(L_YEAR);
      
        IF L_LEAP_YEAR THEN
          L_TOTAL_DAYS := 366;
        ELSE
          L_TOTAL_DAYS := 365;
        END IF;
      
        DEBUG.PR_DEBUG('CF', 'Total days - ' || L_TOTAL_DAYS);
        DEBUG.PR_DEBUG('CF', 'INC TO DATE----- - ' || L_INCLUDE_TO_DATE);
        DEBUG.PR_DEBUG('CF',
                       'ROUNDING PERIOD FROM CONTRACT COMMISSION TABLE----- - ' ||
                       L_CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD);
        DEBUG.PR_DEBUG('CF',
                       'ROUNDING PERIOD FROM RULE----- - ' ||
                       L_ICCF_RULE.ROUNDING_PERIOD);
        DEBUG.PR_DEBUG('CF', 'COMM CALC BASIS---- ' || L_COMM_CALC_BASIS);
      
        IF L_RETROSPECTIVE_FLAG = 'Y' OR L_FIRST_TIME THEN
          IF P_TY_COMMISSION(I)
           .P_START_DATE = LAST_DAY(P_TY_COMMISSION(I).P_START_DATE) AND
              L_EXPIRY_DATE_CALC < LAST_DAY(L_EXPIRY_DATE_CALC) AND
              TO_CHAR(P_TY_COMMISSION(I).P_START_DATE, 'DD') <=
              TO_CHAR(L_EXPIRY_DATE_CALC, 'DD') THEN
          
            L_TENOR := TRUNC(MONTHS_BETWEEN(L_EXPIRY_DATE_CALC,
                                            P_TY_COMMISSION(I).P_START_DATE));
          
            L_TENOR_IN_DAYS := (L_EXPIRY_DATE_CALC - P_TY_COMMISSION(I)
                               .P_START_DATE) + 1;
          
            IF L_EXPIRY_DATE_CALC IS NOT NULL THEN
              IF NOT CSPKSS_INTEREST.FN_DATE_DIFF(P_TY_COMMISSION(I)
                                                  .P_START_DATE,
                                                  L_EXPIRY_DATE_CALC,
                                                  L_COMM_CALC_BASIS,
                                                  L_DAYS) THEN
                DEBUG.PR_DEBUG('CF', 'CALC OF number of days failed 1');
                RETURN FALSE;
              END IF;
            END IF;
          
            DEBUG.PR_DEBUG('CF', 'Entered here 1');
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 1->' ||
                           L_TENOR_IN_DAYS);
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 1->' || L_DAYS);
          
          ELSE
          
            L_TENOR := 1 +
                       TRUNC(MONTHS_BETWEEN(L_EXPIRY_DATE_CALC,
                                            P_TY_COMMISSION(I).P_START_DATE) -
                             0.0001);
          
            L_TENOR_IN_DAYS := (L_EXPIRY_DATE_CALC - P_TY_COMMISSION(I)
                               .P_START_DATE) + 1;
            DEBUG.PR_DEBUG('CF',
                           'Entered here 2 EXPIRY DATE ' ||
                           L_EXPIRY_DATE_CALC);
          
            IF L_EXPIRY_DATE_CALC IS NOT NULL THEN
              IF NOT CSPKSS_INTEREST.FN_DATE_DIFF(P_TY_COMMISSION(I)
                                                  .P_START_DATE,
                                                  L_EXPIRY_DATE_CALC,
                                                  L_COMM_CALC_BASIS,
                                                  L_DAYS) THEN
                DEBUG.PR_DEBUG('CF', 'CALC OF number of days failed 2');
                RETURN FALSE;
              END IF;
            END IF;
            DEBUG.PR_DEBUG('CF', 'Entered here 2');
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 2->' ||
                           L_TENOR_IN_DAYS);
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 2->' || L_DAYS);
          
          END IF;
          L_GOOD_UNTIL_TENOR := 0;
        
          IF L_GOOD_UNTIL_DATE IS NULL THEN
            IF L_TENOR < L_ICCF_RULE.MINIMUM_PERIOD THEN
              L_TENOR := L_ICCF_RULE.MINIMUM_PERIOD;
            
              P_TY_COMMISSION(I).P_END_DATE := ADD_MONTHS(P_TY_COMMISSION(I)
                                                          .P_START_DATE,
                                                          L_TENOR) - 1;
            
              L_TENOR_IN_DAYS := (P_TY_COMMISSION(I).P_END_DATE - P_TY_COMMISSION(I)
                                 .P_START_DATE) + 1;
            
              IF P_TY_COMMISSION(I).P_END_DATE IS NOT NULL THEN
                IF NOT CSPKSS_INTEREST.FN_DATE_DIFF(P_TY_COMMISSION  (I)
                                                    .P_START_DATE,
                                                    P_TY_COMMISSION  (I)
                                                    .P_END_DATE,
                                                    L_COMM_CALC_BASIS,
                                                    L_DAYS) THEN
                  DEBUG.PR_DEBUG('CF', 'CALC OF number of days failed 3');
                  RETURN FALSE;
                END IF;
              END IF;
              DEBUG.PR_DEBUG('CF', 'Entered here 3');
              DEBUG.PR_DEBUG('CF',
                             'tenor in days Entered here 3->' ||
                             L_TENOR_IN_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'tenor in days Entered here 3->' || L_DAYS);
            
            END IF;
          END IF;
        END IF;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>original good_until_date ' ||
                       L_GOOD_UNTIL_DATE);
      
        IF L_RETROSPECTIVE_FLAG = 'N' THEN
        
          DEBUG.PR_DEBUG('CF',
                         'l_expiry_date_calc >>> ' || L_EXPIRY_DATE_CALC);
          IF NOT FN_GET_GUD_REC(P_TY_COMMISSION,
                                I,
                                L_ICCF_RULE,
                                L_CFTBS_CONTRACT_COMMISSION,
                                L_TY_COMMISSION_GUD) THEN
            DEBUG.PR_DEBUG('CF', 'failed in  fn_get_gud_rec ');
          ELSE
            IF MONTHS_BETWEEN(P_TY_COMMISSION(I).P_END_DATE,
                              P_TY_COMMISSION(I).P_START_DATE) <
               L_ICCF_RULE.MINIMUM_PERIOD THEN
              L_EXPIRY_DATE_CALC := ADD_MONTHS(P_TY_COMMISSION(I)
                                               .P_START_DATE,
                                               L_ICCF_RULE.MINIMUM_PERIOD) - 1;
            ELSE
              IF NOT
                  CFPKSS_COMPUTATION.FN_COMMISSION_GOOD_UNTIL_DATE(L_TY_COMMISSION_GUD) THEN
                DEBUG.PR_DEBUG('CF', 'GUD - failed ');
              END IF;
              DEBUG.PR_DEBUG('CF',
                             'Calculating the NEW GOOD UNTIL DATE' || L_TY_COMMISSION_GUD(1)
                             .P_GOOD_UNTIL_DATE);
              IF L_TY_COMMISSION_GUD(1).P_GOOD_UNTIL_DATE IS NOT NULL THEN
                IF L_TY_COMMISSION_GUD(1)
                 .P_GOOD_UNTIL_DATE >
                    NVL(L_GOOD_UNTIL_DATE, START_OF_CENTURY) THEN
                  L_EXPIRY_DATE_CALC := L_TY_COMMISSION_GUD(1)
                                        .P_GOOD_UNTIL_DATE;
                END IF;
              END IF;
            END IF;
          END IF;
          DEBUG.PR_DEBUG('CF',
                         'l_expiry_date_calc >>> ' || L_EXPIRY_DATE_CALC);
        
          IF L_GOOD_UNTIL_DATE IS NOT NULL AND
             L_GOOD_UNTIL_DATE > P_TY_COMMISSION(I).P_START_DATE THEN
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>Recalculating the tenor');
          
            IF L_GOOD_UNTIL_DATE >= L_EXPIRY_DATE_CALC THEN
              L_TENOR         := 0;
              L_TENOR_IN_DAYS := 0;
              L_DAYS          := 0;
            ELSE
            
              IF MOD(MONTHS_BETWEEN(L_EXPIRY_DATE_CALC,
                                    L_GOOD_UNTIL_DATE + 1),
                     1) <> 0 THEN
                L_TENOR := 1 +
                           TRUNC(MONTHS_BETWEEN(L_EXPIRY_DATE_CALC,
                                                L_GOOD_UNTIL_DATE + 1));
              
                L_TENOR_IN_DAYS := (L_EXPIRY_DATE_CALC - L_GOOD_UNTIL_DATE) + 1;
              
                IF L_EXPIRY_DATE_CALC IS NOT NULL THEN
                  IF NOT CSPKSS_INTEREST.FN_DATE_DIFF(L_GOOD_UNTIL_DATE,
                                                      L_EXPIRY_DATE_CALC,
                                                      L_COMM_CALC_BASIS,
                                                      L_DAYS) THEN
                    DEBUG.PR_DEBUG('CF', 'CALC OF number of days failed 4');
                    RETURN FALSE;
                  END IF;
                END IF;
              
                DEBUG.PR_DEBUG('CF', 'Entered here 4');
                DEBUG.PR_DEBUG('CF',
                               'tenor in days Entered here 4->' ||
                               L_TENOR_IN_DAYS);
                DEBUG.PR_DEBUG('CF',
                               'tenor in days Entered here 4->' || L_DAYS);
              
              ELSE
                L_TENOR := TRUNC(MONTHS_BETWEEN(L_EXPIRY_DATE_CALC,
                                                L_GOOD_UNTIL_DATE + 1));
              
                L_TENOR_IN_DAYS := (L_EXPIRY_DATE_CALC - L_GOOD_UNTIL_DATE) + 1;
              
                IF L_EXPIRY_DATE_CALC IS NOT NULL THEN
                  IF NOT CSPKSS_INTEREST.FN_DATE_DIFF(L_GOOD_UNTIL_DATE,
                                                      L_EXPIRY_DATE_CALC,
                                                      L_COMM_CALC_BASIS,
                                                      L_DAYS) THEN
                    DEBUG.PR_DEBUG('CF', 'CALC OF number of days failed 4');
                    RETURN FALSE;
                  END IF;
                END IF;
              
                DEBUG.PR_DEBUG('CF', 'Entered here 5');
                DEBUG.PR_DEBUG('CF',
                               'tenor in days Entered here 5->' ||
                               L_TENOR_IN_DAYS);
                DEBUG.PR_DEBUG('CF',
                               'tenor in days Entered here 5->' || L_DAYS);
              
              END IF;
            
            END IF;
          
            IF MOD(MONTHS_BETWEEN(L_GOOD_UNTIL_DATE,
                                  P_TY_COMMISSION(I).P_START_DATE),
                   1) <> 0 THEN
              L_GOOD_UNTIL_TENOR := 1 +
                                    TRUNC(MONTHS_BETWEEN(L_GOOD_UNTIL_DATE,
                                                         P_TY_COMMISSION(I)
                                                         .P_START_DATE));
            ELSE
              L_GOOD_UNTIL_TENOR := TRUNC(MONTHS_BETWEEN(L_GOOD_UNTIL_DATE,
                                                         P_TY_COMMISSION(I)
                                                         .P_START_DATE));
            END IF;
          
          ELSIF P_TY_COMMISSION(I)
           .P_CALCULATION_METHOD = 'P' AND
                 L_GOOD_UNTIL_DATE IS NOT NULL AND
                 L_GOOD_UNTIL_DATE < P_TY_COMMISSION(I).P_START_DATE THEN
            IF MOD(MONTHS_BETWEEN(P_TY_COMMISSION(I).P_START_DATE,
                                  P_TY_COMMISSION(I).P_END_DATE + 1),
                   1) <> 0 THEN
            
              L_TENOR := 1 +
                         TRUNC(MONTHS_BETWEEN((P_TY_COMMISSION(I)
                                              .P_END_DATE + 1),
                                              P_TY_COMMISSION(I).P_START_DATE));
            ELSE
            
              L_TENOR := TRUNC(MONTHS_BETWEEN((P_TY_COMMISSION(I)
                                              .P_END_DATE + 1),
                                              P_TY_COMMISSION(I).P_START_DATE));
            END IF;
            L_TENOR_IN_DAYS := (P_TY_COMMISSION(I)
                               .P_END_DATE - P_TY_COMMISSION(I).P_START_DATE) + 1;
          
            IF P_TY_COMMISSION(I).P_END_DATE IS NOT NULL THEN
              IF NOT
                  CSPKSS_INTEREST.FN_DATE_DIFF(P_TY_COMMISSION  (I)
                                               .P_START_DATE,
                                               P_TY_COMMISSION  (I).P_END_DATE,
                                               L_COMM_CALC_BASIS,
                                               L_DAYS) THEN
                DEBUG.PR_DEBUG('CF', 'CALC OF number of days failed 6');
                RETURN FALSE;
              END IF;
            END IF;
          
            DEBUG.PR_DEBUG('CF', 'Entered here 6');
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 6->' ||
                           L_TENOR_IN_DAYS);
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 6->' || L_DAYS);
          
          END IF;
        
        END IF;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>The final tenor for calc is - ' ||
                       L_TENOR);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Good_until_tenor is - ' ||
                       L_GOOD_UNTIL_TENOR);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>What is my l_iccf_rule ' ||
                       L_ICCF_RULE.RULE);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>What is my l_iccf_rule tier flag ' ||
                       NVL(L_ICCF_RULE.TIERED_TENOR, 'N'));
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Tenor Calculated before minimum period ' ||
                       TO_CHAR(L_TENOR));
      
        IF L_TENOR < L_ICCF_RULE.MINIMUM_PERIOD AND L_TENOR > 0 THEN
        
          L_TENOR := L_ICCF_RULE.MINIMUM_PERIOD;
        
          IF L_GOOD_UNTIL_DATE IS NOT NULL THEN
            P_TY_COMMISSION(I).P_END_DATE := ADD_MONTHS((L_GOOD_UNTIL_DATE + 1),
                                                        L_TENOR);
            L_TENOR_IN_DAYS := (P_TY_COMMISSION(I)
                               .P_END_DATE - L_GOOD_UNTIL_DATE);
          
            IF P_TY_COMMISSION(I).P_END_DATE IS NOT NULL THEN
              IF NOT
                  CSPKSS_INTEREST.FN_DATE_DIFF(L_GOOD_UNTIL_DATE,
                                               P_TY_COMMISSION(I).P_END_DATE,
                                               L_COMM_CALC_BASIS,
                                               L_DAYS) THEN
                DEBUG.PR_DEBUG('CF', 'CALC OF number of days failed 7');
                RETURN FALSE;
              END IF;
            END IF;
          
            DEBUG.PR_DEBUG('CF', 'Entered here 7');
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 7->' ||
                           L_TENOR_IN_DAYS);
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 7->' || L_DAYS);
          
          ELSE
            P_TY_COMMISSION(I).P_END_DATE := ADD_MONTHS(P_TY_COMMISSION(I)
                                                        .P_START_DATE,
                                                        L_TENOR);
          
            L_TENOR_IN_DAYS := (P_TY_COMMISSION(I)
                               .P_END_DATE - P_TY_COMMISSION(I).P_START_DATE) + 1;
          
            IF P_TY_COMMISSION(I).P_END_DATE IS NOT NULL THEN
              IF NOT
                  CSPKSS_INTEREST.FN_DATE_DIFF(P_TY_COMMISSION  (I)
                                               .P_START_DATE,
                                               P_TY_COMMISSION  (I).P_END_DATE,
                                               L_COMM_CALC_BASIS,
                                               L_DAYS) THEN
                DEBUG.PR_DEBUG('CF', 'CALC OF number of days failed 8');
                RETURN FALSE;
              END IF;
            END IF;
          
            DEBUG.PR_DEBUG('CF', 'Entered here 8');
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 8->' ||
                           L_TENOR_IN_DAYS);
            DEBUG.PR_DEBUG('CF',
                           'tenor in days Entered here 8->' || L_DAYS);
          
          END IF;
        END IF;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Tenor Calculated after minimum period ' ||
                       TO_CHAR(L_TENOR));
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Calculating Commission using MIN period till ' ||
                       L_EXPIRY_DATE_CALC);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>End Date now stands at ' || P_TY_COMMISSION(I)
                       .P_END_DATE);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>basis_amount_to ' ||
                       L_ICCF_BRACKET.BASIS_AMOUNT_TO);
      
        IF NVL(L_ICCF_RULE.TIERED_TENOR, 'N') != 'Y' THEN
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Came to within Tiered Tenor not being True');
          BEGIN
            SELECT *
              INTO L_ICCF_BRACKET_TENOR
              FROM CFTMS_BRACKET_TENOR
             WHERE RULE = L_RULE
               AND CURRENCY = L_CURRENCY
               AND CURRENCY2 = L_CURRENCY
               AND CUSTOMER = L_CUSTOMER
               AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
               AND BRANCH_CODE = L_BRANCH_CODE
               AND BASIS_AMOUNT_TO = L_ICCF_BRACKET.BASIS_AMOUNT_TO
               AND L_TENOR <= TENOR_TO
               AND L_TENOR >= TENOR_FROM;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>customer+ccy+basis_amount_to+l_tenor failed');
              SELECT MAX(TENOR_TO), MIN(TENOR_TO)
                INTO L_MAX_TENOR_TO, L_MIN_TENOR_TO
                FROM CFTMS_BRACKET_TENOR
               WHERE RULE = L_RULE
                 AND CURRENCY = L_CURRENCY
                 AND CURRENCY2 = L_CURRENCY2
                 AND CUSTOMER = L_CUSTOMER
                 AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
                 AND BRANCH_CODE = L_BRANCH_CODE
                 AND BASIS_AMOUNT_TO = L_ICCF_BRACKET.BASIS_AMOUNT_TO;
              IF L_TENOR > L_MAX_TENOR_TO THEN
                SELECT *
                  INTO L_ICCF_BRACKET_TENOR
                  FROM CFTMS_BRACKET_TENOR
                 WHERE RULE = L_RULE
                   AND CURRENCY = L_CURRENCY
                   AND CURRENCY2 = L_CURRENCY2
                   AND CUSTOMER = L_CUSTOMER
                   AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
                   AND BRANCH_CODE = L_BRANCH_CODE
                   AND BASIS_AMOUNT_TO = L_ICCF_BRACKET.BASIS_AMOUNT_TO
                   AND TENOR_TO = L_MAX_TENOR_TO;
              ELSE
                SELECT *
                  INTO L_ICCF_BRACKET_TENOR
                  FROM CFTMS_BRACKET_TENOR
                 WHERE RULE = L_RULE
                   AND CURRENCY = L_CURRENCY
                   AND CURRENCY2 = L_CURRENCY2
                   AND CUSTOMER = L_CUSTOMER
                   AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
                   AND BRANCH_CODE = L_BRANCH_CODE
                   AND BASIS_AMOUNT_TO = L_ICCF_BRACKET.BASIS_AMOUNT_TO
                   AND TENOR_TO = L_MIN_TENOR_TO;
              END IF;
          END;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Have managed to select the Tenor Row Applicable ' ||
                         L_ICCF_BRACKET_TENOR.TENOR_TO);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Start Tenor Row Applicable ' ||
                         L_ICCF_BRACKET_TENOR.TENOR_FROM);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Follow rule    - ' || P_TY_COMMISSION(I)
                         .P_FOLLOW_RULE);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>CFTM_BRACKET_TENOR RATE PICKED UP    - ' ||
                         L_ICCF_BRACKET_TENOR.RATE);
        
          IF NVL(P_TY_COMMISSION(I).P_FOLLOW_RULE, 'N') = 'Y' THEN
            P_TY_COMMISSION(I).P_FOLLOW_RULE := 'Y';
          ELSE
            IF NVL(L_ICCF_RULE.CUMULATIVE, 'N') = 'N' THEN
              P_TY_COMMISSION(I).P_FOLLOW_RULE := 'N';
            ELSE
              P_TY_COMMISSION(I).P_FOLLOW_RULE := 'R';
            END IF;
          END IF;
        
          IF L_RETROSPECTIVE_FLAG = 'Y' AND P_TY_COMMISSION(I)
            .P_CALCULATION_METHOD = 'N' THEN
            P_TY_COMMISSION(I).P_FOLLOW_RULE := 'R';
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Follow rule now modified   - ' || P_TY_COMMISSION(I)
                         .P_FOLLOW_RULE);
          IF P_TY_COMMISSION(I).P_FOLLOW_RULE = 'Y' THEN
            L_RATE               := L_ICCF_BRACKET_TENOR.RATE;
            L_COLLECTION_PERIOD  := L_ICCF_RULE.ROUNDING_PERIOD;
            L_RATE_PERIOD        := L_ICCF_RULE.RATE_PERIOD;
            L_ROUNDING_PERIOD    := L_ICCF_RULE.ROUNDING_PERIOD;
            L_CALCULATION_METHOD := P_TY_COMMISSION(I).P_CALCULATION_METHOD;
          ELSIF P_TY_COMMISSION(I).P_FOLLOW_RULE = 'R' THEN
            L_RATE        := L_ICCF_BRACKET_TENOR.RATE;
            L_RATE_PERIOD := L_ICCF_RULE.RATE_PERIOD;
          
            L_COLLECTION_PERIOD  := NVL(L_CFTBS_CONTRACT_COMMISSION.COLLECTION_PERIOD,
                                        L_ICCF_RULE.ROUNDING_PERIOD);
            L_ROUNDING_PERIOD    := NVL(L_CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD,
                                        L_ICCF_RULE.ROUNDING_PERIOD);
            L_CALCULATION_METHOD := NVL(L_CFTBS_CONTRACT_COMMISSION.CALCULATION_METHOD,
                                        P_TY_COMMISSION(I)
                                        .P_CALCULATION_METHOD);
          
          ELSE
            L_RATE               := L_CFTBS_CONTRACT_COMMISSION.RATE;
            L_COLLECTION_PERIOD  := L_CFTBS_CONTRACT_COMMISSION.COLLECTION_PERIOD;
            L_RATE_PERIOD        := L_CFTBS_CONTRACT_COMMISSION.RATE_PERIOD;
            L_ROUNDING_PERIOD    := L_CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD;
            L_CALCULATION_METHOD := L_CFTBS_CONTRACT_COMMISSION.CALCULATION_METHOD;
          END IF;
        
          P_TY_COMMISSION(I).P_RATE := L_RATE;
          P_TY_COMMISSION(I).P_COLLECTION_PERIOD := L_COLLECTION_PERIOD;
          P_TY_COMMISSION(I).P_RATE_PERIOD := L_RATE_PERIOD;
          P_TY_COMMISSION(I).P_ROUNDING_PERIOD := L_ROUNDING_PERIOD;
          P_TY_COMMISSION(I).P_CALCULATION_METHOD := L_CALCULATION_METHOD;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> p_ty_commission.p_rate now set to ' ||
                         L_RATE);
        
          IF P_TY_COMMISSION(I).P_CALCULATION_METHOD = 'P' THEN
            L_CURRENT_DATE := ADD_MONTHS(P_TY_COMMISSION(I).P_START_DATE,
                                         L_COLLECTION_PERIOD);
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>NEXT START Date    - ' || P_TY_COMMISSION(I)
                           .P_START_DATE);
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>Cur Date    - ' ||
                           L_CURRENT_DATE);
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>End Date    - ' || P_TY_COMMISSION(I)
                           .P_END_DATE);
          
            IF P_TY_COMMISSION(I)
             .P_START_DATE <> LAST_DAY(P_TY_COMMISSION(I).P_START_DATE) THEN
              DAY_OF_MONTH   := LEAST(TO_CHAR(L_CURRENT_DATE, 'DD'),
                                      TO_CHAR(P_TY_COMMISSION(I).P_START_DATE,
                                              'DD'));
              MONTH_YEAR     := TO_CHAR(L_CURRENT_DATE, 'MMYYYY');
              END_OF_MONTH   := TO_DATE(MONTH_YEAR || DAY_OF_MONTH,
                                        'MMYYYYDD');
              L_CURRENT_DATE := LEAST(END_OF_MONTH, L_CURRENT_DATE);
            END IF;
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>Cur Date    - ' ||
                           L_CURRENT_DATE);
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>End Date    - ' || P_TY_COMMISSION(I)
                           .P_END_DATE);
          
            IF (L_CURRENT_DATE - 1) > P_TY_COMMISSION(I).P_END_DATE THEN
              P_TY_COMMISSION(I).P_CALCULATION_METHOD := 'L';
            
              IF L_GOOD_UNTIL_DATE IS NOT NULL THEN
                IF L_GOOD_UNTIL_DATE < P_TY_COMMISSION(I).P_START_DATE AND
                   L_RETROSPECTIVE_FLAG = 'N' THEN
                  IF MOD(MONTHS_BETWEEN(P_TY_COMMISSION(I).P_START_DATE,
                                        P_TY_COMMISSION(I).P_END_DATE + 1),
                         1) <> 0 THEN
                    L_TENOR := 1 + TRUNC(MONTHS_BETWEEN((P_TY_COMMISSION(I)
                                                        .P_END_DATE + 1),
                                                        P_TY_COMMISSION(I)
                                                        .P_START_DATE));
                  ELSE
                    L_TENOR := TRUNC(MONTHS_BETWEEN((P_TY_COMMISSION(I)
                                                    .P_END_DATE + 1),
                                                    P_TY_COMMISSION(I)
                                                    .P_START_DATE));
                  END IF;
                
                  L_TENOR_IN_DAYS := (P_TY_COMMISSION(I).P_END_DATE - P_TY_COMMISSION(I)
                                     .P_START_DATE) + 1;
                
                  IF P_TY_COMMISSION(I).P_END_DATE IS NOT NULL THEN
                    IF NOT CSPKSS_INTEREST.FN_DATE_DIFF(P_TY_COMMISSION  (I)
                                                        .P_START_DATE,
                                                        P_TY_COMMISSION  (I)
                                                        .P_END_DATE,
                                                        L_COMM_CALC_BASIS,
                                                        L_DAYS) THEN
                      DEBUG.PR_DEBUG('CF',
                                     'CALC OF number of days failed 6');
                      RETURN FALSE;
                    END IF;
                  END IF;
                
                  DEBUG.PR_DEBUG('CF', 'Entered here 9');
                  DEBUG.PR_DEBUG('CF',
                                 'tenor in days Entered here 9->' ||
                                 L_TENOR_IN_DAYS);
                  DEBUG.PR_DEBUG('CF',
                                 'tenor in days Entered here 9->' || L_DAYS);
                END IF;
              END IF;
            END IF;
          
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Calc method    - ' || P_TY_COMMISSION(I)
                         .P_CALCULATION_METHOD);
        
          IF L_CFTBS_CONTRACT_COMMISSION.STOP_DATE IS NOT NULL THEN
            IF P_TY_COMMISSION(I)
             .P_END_DATE > L_CFTBS_CONTRACT_COMMISSION.STOP_DATE THEN
              P_TY_COMMISSION(I).P_END_DATE := L_CFTBS_CONTRACT_COMMISSION.STOP_DATE;
              P_TY_COMMISSION(I).P_CALCULATION_METHOD := 'A';
            END IF;
          END IF;
        
          IF P_TY_COMMISSION(I).P_ROUNDING_PERIOD = 0 THEN
            DEBUG.PR_DEBUG('CF', 'ENTERED HERE 12');
            P_TY_COMMISSION(I).P_COMM_CALC_BASIS := L_COMM_CALC_BASIS;
          ELSIF P_TY_COMMISSION(I).P_ROUNDING_PERIOD <> 0 OR P_TY_COMMISSION(I)
                .P_ROUNDING_PERIOD IS NULL THEN
            DEBUG.PR_DEBUG('CF', 'ENTERED HERE 13');
            P_TY_COMMISSION(I).P_COMM_CALC_BASIS := 9;
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Calc Meth      : ' || P_TY_COMMISSION(I)
                         .P_CALCULATION_METHOD);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Stop date      : ' ||
                         L_CFTBS_CONTRACT_COMMISSION.STOP_DATE);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>End date       : ' || P_TY_COMMISSION(I)
                         .P_END_DATE);
          DEBUG.PR_DEBUG('CF',
                         'AFTER ASSIGING IT TO THE TYPE->CALC METHOD IS-> ' || P_TY_COMMISSION(I)
                         .P_COMM_CALC_BASIS);
        
          IF NOT CSPKSS_INTEREST.FN_TNR_DENO(P_TY_COMMISSION (I).P_START_DATE,
                                             P_TY_COMMISSION (I).P_END_DATE,
                                             P_TY_COMMISSION (I)
                                             .P_COMM_CALC_BASIS,
                                             L_TOTAL_COM_DAYS) THEN
            DEBUG.PR_DEBUG('CF',
                           'CALCULATION OF TOTAL DAYS FOR DENOM failed');
            RETURN FALSE;
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>rolled->TOTAL DAYS denom  : ' ||
                         L_TOTAL_COM_DAYS);
        
          IF P_TY_COMMISSION(I).P_CALCULATION_METHOD IN ('N', 'L') THEN
            L_CURRENT_DATE      := P_TY_COMMISSION(I).P_START_DATE;
            L_NUMBER_OF_PERIODS := 0;
          
            IF NVL(L_ROUNDING_PERIOD, 0) != 0 THEN
              IF TRUNC(L_TENOR / L_ROUNDING_PERIOD) <>
                 L_TENOR / L_ROUNDING_PERIOD THEN
                L_NUMBER_OF_PERIODS := TRUNC(L_TENOR / L_ROUNDING_PERIOD) + 1;
              ELSE
                L_NUMBER_OF_PERIODS := TRUNC(L_TENOR / L_ROUNDING_PERIOD);
              END IF;
            ELSE
              L_NUMBER_OF_PERIODS := L_TENOR;
            END IF;
          
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>No of Per    - ' ||
                           L_NUMBER_OF_PERIODS);
          
            IF L_ROUNDING_PERIOD != 0 THEN
            
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final TOTAL DAYS denom 11111  : ' ||
                             L_TOTAL_COM_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final TOTAL DAYS denom 11111  : ' ||
                             L_TOTAL_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final Tenor in DAYS 11111  : ' ||
                             L_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final Tenor in DAYS 11111  : ' ||
                             L_TENOR_IN_DAYS);
            
              IF NVL(L_ICCF_RULE.CUMULATIVE, 'N') != 'Y' THEN
              
                DEBUG.PR_DEBUG('CF', 'INSIDE IF CONDITION');
                DEBUG.PR_DEBUG('CF', 'L_AMOUNT=' || L_AMOUNT);
                DEBUG.PR_DEBUG('CF', 'L_RATE=' || L_RATE);
                DEBUG.PR_DEBUG('CF',
                               'L_NUMBER_OF_PERIODS=' ||
                               L_NUMBER_OF_PERIODS);
                DEBUG.PR_DEBUG('CF',
                               'L_ROUNDING_PERIOD=' || L_ROUNDING_PERIOD);
                DEBUG.PR_DEBUG('CF', 'L_RATE_PERIOD=' || L_RATE_PERIOD);
              
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := ((L_AMOUNT *
                                                          NVL(L_RATE, 0) *
                                                          L_NUMBER_OF_PERIODS) *
                                                          L_ROUNDING_PERIOD /
                                                          L_RATE_PERIOD) / 100;
              ELSE
                L_TEMP := 0;
              
                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                  L_FN_CALL_ID      := 1;
                  L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                  DEBUG.PR_DEBUG('CF',
                                 'Before Calling cfpks_computation_cluster.fn_commission_computation');
                  IF NOT
                      CFPKS_COMPUTATION_CLUSTER.FN_COMMISSION_COMPUTATION(P_TY_COMMISSION,
                                                                          L_FN_CALL_ID,
                                                                          L_TB_CLUSTER_DATA) THEN
                    DEBUG.PR_DEBUG('CF',
                                   'Failed in bcpks_bcdtronl_utils_cluster.fn_unlock');
                    RETURN FALSE;
                  END IF;
                END IF;
              
                IF NOT GLOBAL.G_SKIP_KERNEL THEN
                  DEBUG.PR_DEBUG('CF', 'Inside Kernel Code');
                
                  IF NOT FN_TIER_AMT_FLAT_TENOR(L_AMOUNT,
                                                L_ICCF_RULE,
                                                L_RATE,
                                                L_NUMBER_OF_PERIODS,
                                                L_ROUNDING_PERIOD,
                                                L_RATE_PERIOD,
                                                L_TENOR,
                                                L_TENOR_IN_DAYS,
                                                L_TOTAL_DAYS,
                                                L_ERR_CODE,
                                                L_TEMP,
                                                L_ORIGINAL_TAG_AMOUNT) THEN
                    RETURN FALSE;
                  ELSE
                    DEBUG.PR_DEBUG('CF',
                                   'fn_commission_computation>commission in tiered amount calculated is ' ||
                                   L_TEMP);
                    P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_TEMP;
                  END IF;
                END IF;
              END IF;
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation> COMMISSION CCY        - ' || P_TY_COMMISSION(I)
                             .P_COMMISSION_CURRENCY);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>ICCF BASIS CCY        - ' ||
                             L_ICCF_RULE.BASIS_AMOUNT_CCY);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>ty_comm basis ccy     - ' || P_TY_COMMISSION(I)
                             .P_BASIS_AMOUNT_CURRENCY);
            
              P_TY_COMMISSION(I).P_COMMISSION_CURRENCY := P_TY_COMMISSION(I)
                                                          .P_BASIS_AMOUNT_CURRENCY;
            ELSE
            
              IF L_INCLUDE_TO_DATE = 'Y' THEN
                L_TENOR_IN_DAYS := L_DAYS + 1;
                L_TOTAL_DAYS    := L_TOTAL_COM_DAYS;
              
              ELSE
                L_TENOR_IN_DAYS := L_DAYS;
                L_TOTAL_DAYS    := L_TOTAL_COM_DAYS;
              END IF;
            
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final TOTAL DAYS denom 2222  : ' ||
                             L_TOTAL_COM_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final TOTAL DAYS denom 2222  : ' ||
                             L_TOTAL_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final Tenor in DAYS 2222  : ' ||
                             L_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final Tenor in DAYS 2222  : ' ||
                             L_TENOR_IN_DAYS);
            
              IF NVL(L_ICCF_RULE.CUMULATIVE, 'N') != 'Y' THEN
              
                DEBUG.PR_DEBUG('CF', 'INSIDE IF CONDITION');
                DEBUG.PR_DEBUG('CF', 'L_AMOUNT=' || L_AMOUNT);
                DEBUG.PR_DEBUG('CF', 'L_RATE=' || L_RATE);
                DEBUG.PR_DEBUG('CF', 'L_TENOR_IN_DAYS=' || L_TENOR_IN_DAYS);
                DEBUG.PR_DEBUG('CF', 'L_TOTAL_DAYS=' || L_TOTAL_DAYS);
              
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := ((L_AMOUNT *
                                                          NVL(L_RATE, 0) *
                                                          L_TENOR_IN_DAYS) * 1 /
                                                          L_TOTAL_DAYS) / 100;
              ELSE
                DEBUG.PR_DEBUG('CF', 'INSIDE ELSE CONDITION');
              
                L_TEMP := 0;
                IF NOT FN_TIER_AMT_FLAT_TENOR(L_AMOUNT,
                                              L_ICCF_RULE,
                                              L_RATE,
                                              L_NUMBER_OF_PERIODS,
                                              L_ROUNDING_PERIOD,
                                              L_RATE_PERIOD,
                                              L_TENOR,
                                              L_TENOR_IN_DAYS,
                                              L_TOTAL_DAYS,
                                              L_ERR_CODE,
                                              L_TEMP,
                                              L_ORIGINAL_TAG_AMOUNT) THEN
                  RETURN FALSE;
                ELSE
                  DEBUG.PR_DEBUG('CF',
                                 'fn_commission_computation>commission in tiered amount calculated is ' ||
                                 L_TEMP);
                  P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_TEMP;
                END IF;
              END IF;
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation> COMMISSION CCY        - ' || P_TY_COMMISSION(I)
                             .P_COMMISSION_CURRENCY);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>ICCF BASIS CCY        - ' ||
                             L_ICCF_RULE.BASIS_AMOUNT_CCY);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>ty_comm basis ccy     - ' || P_TY_COMMISSION(I)
                             .P_BASIS_AMOUNT_CURRENCY);
            
              P_TY_COMMISSION(I).P_COMMISSION_CURRENCY := P_TY_COMMISSION(I)
                                                          .P_BASIS_AMOUNT_CURRENCY;
            END IF;
          END IF;
        
          IF P_TY_COMMISSION(I).P_CALCULATION_METHOD IN ('P') THEN
          
            IF L_ROUNDING_PERIOD != 0 THEN
            
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final TOTAL DAYS denom 33333  : ' ||
                             L_TOTAL_COM_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final TOTAL DAYS denom 33333  : ' ||
                             L_TOTAL_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final Tenor in DAYS 33333  : ' ||
                             L_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final Tenor in DAYS 33333  : ' ||
                             L_TENOR_IN_DAYS);
              IF NVL(L_ICCF_RULE.CUMULATIVE, 'N') != 'Y' THEN
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := (L_AMOUNT *
                                                          NVL(L_RATE, 0) *
                                                          (L_COLLECTION_PERIOD /
                                                          L_RATE_PERIOD)) / 100;
              ELSE
                L_TEMP := 0;
                IF NOT FN_TIER_AMT_FLAT_TENOR(L_AMOUNT,
                                              L_ICCF_RULE,
                                              L_RATE,
                                              L_COLLECTION_PERIOD,
                                              1,
                                              L_RATE_PERIOD,
                                              L_TENOR,
                                              L_TENOR_IN_DAYS,
                                              L_TOTAL_DAYS,
                                              L_ERR_CODE,
                                              L_TEMP,
                                              L_ORIGINAL_TAG_AMOUNT) THEN
                  RETURN FALSE;
                ELSE
                  DEBUG.PR_DEBUG('CF',
                                 ' commission in tiered amount calculated to ' ||
                                 L_TEMP);
                  P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_TEMP;
                
                END IF;
              END IF;
            
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation> COMMISSION CCY        - ' || P_TY_COMMISSION(I)
                             .P_COMMISSION_CURRENCY);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>ICCF BASIS CCY        - ' ||
                             L_ICCF_RULE.BASIS_AMOUNT_CCY);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>ty_comm basis ccy     - ' || P_TY_COMMISSION(I)
                             .P_BASIS_AMOUNT_CURRENCY);
              P_TY_COMMISSION(I).P_COMMISSION_CURRENCY := P_TY_COMMISSION(I)
                                                          .P_BASIS_AMOUNT_CURRENCY;
            ELSE
            
              IF L_INCLUDE_TO_DATE = 'Y' THEN
                L_TENOR_IN_DAYS := L_DAYS + 1;
                L_TOTAL_DAYS    := L_TOTAL_COM_DAYS;
              ELSE
                L_TENOR_IN_DAYS := L_DAYS;
                L_TOTAL_DAYS    := L_TOTAL_COM_DAYS;
              END IF;
            
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final TOTAL DAYS denom 44444  : ' ||
                             L_TOTAL_COM_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final TOTAL DAYS denom 44444  : ' ||
                             L_TOTAL_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final Tenor in DAYS 44444  : ' ||
                             L_DAYS);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>final Tenor in DAYS 44444  : ' ||
                             L_TENOR_IN_DAYS);
            
              IF L_COLLECTION_PERIOD = 0 THEN
                L_COLLECTION_PERIOD := 1;
                P_TY_COMMISSION(I).P_COLLECTION_PERIOD := L_COLLECTION_PERIOD;
              END IF;
            
              IF NVL(L_ICCF_RULE.CUMULATIVE, 'N') != 'Y' THEN
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := (L_AMOUNT *
                                                          NVL(L_RATE, 0) *
                                                          ((L_COLLECTION_PERIOD * 30) /
                                                          L_TOTAL_DAYS)) / 100;
              ELSE
                L_TEMP := 0;
                IF NOT FN_TIER_AMT_FLAT_TENOR(L_AMOUNT,
                                              L_ICCF_RULE,
                                              L_RATE,
                                              L_COLLECTION_PERIOD,
                                              1,
                                              L_RATE_PERIOD,
                                              L_TENOR,
                                              L_TENOR_IN_DAYS,
                                              L_TOTAL_DAYS,
                                              L_ERR_CODE,
                                              L_TEMP,
                                              L_ORIGINAL_TAG_AMOUNT) THEN
                  RETURN FALSE;
                ELSE
                  DEBUG.PR_DEBUG('CF',
                                 ' commission in tiered amount calculated to ' ||
                                 L_TEMP);
                  P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_TEMP;
                
                END IF;
              END IF;
            
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation> COMMISSION CCY        - ' || P_TY_COMMISSION(I)
                             .P_COMMISSION_CURRENCY);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>ICCF BASIS CCY        - ' ||
                             L_ICCF_RULE.BASIS_AMOUNT_CCY);
              DEBUG.PR_DEBUG('CF',
                             'fn_commission_computation>ty_comm basis ccy     - ' || P_TY_COMMISSION(I)
                             .P_BASIS_AMOUNT_CURRENCY);
              P_TY_COMMISSION(I).P_COMMISSION_CURRENCY := P_TY_COMMISSION(I)
                                                          .P_BASIS_AMOUNT_CURRENCY;
            END IF;
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Basis amt       - ' ||
                         L_AMOUNT);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Coll period     - ' ||
                         L_COLLECTION_PERIOD);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Rate period     - ' ||
                         L_RATE_PERIOD);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Rate            - ' ||
                         L_RATE);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Calc period     - ' || P_TY_COMMISSION(I)
                         .P_CALCULATION_METHOD);
        
          IF P_TY_COMMISSION(I).P_CALCULATION_METHOD IN ('A') THEN
          
            IF L_ROUNDING_PERIOD != 0 THEN
              P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := ((L_AMOUNT *
                                                        NVL(L_RATE, 0)) *
                                                        (L_COLLECTION_PERIOD /
                                                        L_RATE_PERIOD) *
                                                        (P_TY_COMMISSION(I)
                                                        .P_END_DATE - P_TY_COMMISSION(I)
                                                        .P_START_DATE) /
                                                        (L_COLLECTION_PERIOD * 30)) / 100;
            
            ELSIF L_ROUNDING_PERIOD = 0 THEN
              DEBUG.PR_DEBUG('CF',
                             'CALCULATION METHOD IF --> IN A----> ' ||
                             L_CFTBS_CONTRACT_COMMISSION.CALCULATION_METHOD);
              IF L_CFTBS_CONTRACT_COMMISSION.CALCULATION_METHOD = 'N' THEN
                IF NOT
                    CSPKSS_INTEREST.FN_DATE_DIFF(P_TY_COMMISSION(I)
                                                 .P_START_DATE,
                                                 P_TY_COMMISSION(I).P_END_DATE,
                                                 P_TY_COMMISSION(I)
                                                 .P_COMM_CALC_BASIS,
                                                 L_DAYS) THEN
                  DEBUG.PR_DEBUG('CF',
                                 'CALC OF number of days IN CALULATION METHOD =A failed 8');
                  RETURN FALSE;
                END IF;
              
                IF L_INCLUDE_TO_DATE = 'Y' THEN
                  L_TENOR_IN_DAYS := L_DAYS + 1;
                  L_TOTAL_DAYS    := L_TOTAL_COM_DAYS;
                ELSE
                  L_TENOR_IN_DAYS := L_DAYS;
                  L_TOTAL_DAYS    := L_TOTAL_COM_DAYS;
                END IF;
              
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := ((L_AMOUNT *
                                                          NVL(L_RATE, 0) *
                                                          L_TENOR_IN_DAYS) * 1 /
                                                          L_TOTAL_DAYS) / 100;
              
              ELSIF L_CFTBS_CONTRACT_COMMISSION.CALCULATION_METHOD = 'P' THEN
              
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := ((L_AMOUNT *
                                                          NVL(L_RATE, 0)) *
                                                          (L_COLLECTION_PERIOD /
                                                          L_RATE_PERIOD) *
                                                          (P_TY_COMMISSION(I)
                                                          .P_END_DATE - P_TY_COMMISSION(I)
                                                          .P_START_DATE) /
                                                          (L_COLLECTION_PERIOD * 30)) / 100;
              END IF;
            
            END IF;
          
            P_TY_COMMISSION(I).P_COMMISSION_CURRENCY := P_TY_COMMISSION(I)
                                                        .P_BASIS_AMOUNT_CURRENCY;
          
          END IF;
        ELSE
        
          COMMISSION_AMOUNT_CALC := 0;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Came here for the Tiered Tenor Calculation Part');
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Tenor is now' ||
                         L_TENOR);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Amount for Calculation of Commission is ' ||
                         TO_CHAR(L_AMOUNT));
        
          DEBUG.PR_DEBUG('CF',
                         'B4 ASSIGING IT TO THE TYPE->CALC METHOD IS-> ' ||
                         L_COMM_CALC_BASIS);
          IF L_ICCF_RULE.ROUNDING_PERIOD = 0 THEN
            P_TY_COMMISSION(I).P_COMM_CALC_BASIS := L_COMM_CALC_BASIS;
          ELSE
            P_TY_COMMISSION(I).P_COMM_CALC_BASIS := 9;
          END IF;
          DEBUG.PR_DEBUG('CF',
                         'AFTER ASSIGING IT TO THE TYPE->CALC METHOD IS-> ' || P_TY_COMMISSION(I)
                         .P_COMM_CALC_BASIS);
        
          IF NOT CSPKSS_INTEREST.FN_TNR_DENO(P_TY_COMMISSION (I).P_START_DATE,
                                             P_TY_COMMISSION (I).P_END_DATE,
                                             P_TY_COMMISSION (I)
                                             .P_COMM_CALC_BASIS,
                                             L_TOTAL_COM_DAYS) THEN
            DEBUG.PR_DEBUG('CF',
                           'CALCULATION OF TOTAL DAYS FOR DENOM failed');
            RETURN FALSE;
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>rolled->TOTAL DAYS denom  : ' ||
                         L_TOTAL_COM_DAYS);
        
          IF L_ICCF_RULE.ROUNDING_PERIOD = 0 THEN
            IF L_INCLUDE_TO_DATE = 'Y' THEN
              L_TENOR_IN_DAYS := L_DAYS + 1;
              L_TOTAL_DAYS    := L_TOTAL_COM_DAYS;
            ELSE
              L_TENOR_IN_DAYS := L_DAYS;
              L_TOTAL_DAYS    := L_TOTAL_COM_DAYS;
            END IF;
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>ROLLED IN ELSE ' ||
                         L_TENOR_IN_DAYS);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>ROLLED IN ELSE->TOTAL COM DAYS ' ||
                         L_TOTAL_DAYS);
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>final TOTAL DAYS denom 66666  : ' ||
                         L_TOTAL_COM_DAYS);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>final TOTAL DAYS denom 66666  : ' ||
                         L_TOTAL_DAYS);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>final Tenor in DAYS 66666  : ' ||
                         L_DAYS);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>final Tenor in DAYS 66666  : ' ||
                         L_TENOR_IN_DAYS);
        
          IF L_ICCF_RULE.CUMULATIVE = 'Y' THEN
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation> executing FN_TIER_AMT_TIER_TENOR_calc');
          
            IF NOT FN_TIER_AMT_TIER_TENOR(L_TENOR,
                                          L_GOOD_UNTIL_TENOR,
                                          L_TENOR_IN_DAYS,
                                          L_TOTAL_DAYS,
                                          L_ICCF_RULE,
                                          L_AMOUNT,
                                          COMMISSION_AMOUNT_CALC,
                                          L_TIER_RATE,
                                          L_ERR_CODE,
                                          L_ORIGINAL_TAG_AMOUNT) THEN
              RETURN FALSE;
            END IF;
          
          ELSE
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation>executing fn_tenor_based_comm_calc');
          
            IF NVL(L_ICCF_RULE.ROUNDING_PERIOD, 0) != 0 THEN
              IF TRUNC(L_TENOR / L_ICCF_RULE.ROUNDING_PERIOD) <>
                 L_TENOR / L_ICCF_RULE.ROUNDING_PERIOD THEN
                L_NUMBER_OF_PERIODS := TRUNC(L_TENOR /
                                             L_ICCF_RULE.ROUNDING_PERIOD) + 1;
              ELSE
                L_NUMBER_OF_PERIODS := TRUNC(L_TENOR /
                                             L_ICCF_RULE.ROUNDING_PERIOD);
              END IF;
            
              L_TENOR := L_NUMBER_OF_PERIODS * L_ICCF_RULE.ROUNDING_PERIOD;
            
            END IF;
          
            IF NOT FN_TENOR_BASED_COMM_CALC(L_TENOR,
                                            L_GOOD_UNTIL_TENOR,
                                            L_TENOR_IN_DAYS,
                                            L_TOTAL_DAYS,
                                            L_ICCF_RULE,
                                            L_AMOUNT,
                                            COMMISSION_AMOUNT_CALC,
                                            L_TIER_RATE,
                                            L_ERR_CODE,
                                            L_ORIGINAL_TAG_AMOUNT) THEN
              RETURN FALSE;
            END IF;
          END IF;
          P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := COMMISSION_AMOUNT_CALC;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Assigning values ot rate code and rounding');
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>rate ' || L_TIER_RATE);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>rate period ' ||
                         L_ICCF_RULE.RATE_PERIOD);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>rounding  period ' ||
                         L_ICCF_RULE.ROUNDING_PERIOD);
          P_TY_COMMISSION(I).P_RATE := L_TIER_RATE;
          P_TY_COMMISSION(I).P_RATE_PERIOD := L_ICCF_RULE.RATE_PERIOD;
          P_TY_COMMISSION(I).P_ROUNDING_PERIOD := L_ICCF_RULE.ROUNDING_PERIOD;
          P_TY_COMMISSION(I).P_COLLECTION_PERIOD := L_ICCF_RULE.ROUNDING_PERIOD;
        
        END IF;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Rate           - ' ||
                       L_RATE);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Basis Amt      - ' ||
                       L_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>coll per       - ' ||
                       L_COLLECTION_PERIOD);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Calc meth      - ' || P_TY_COMMISSION(I)
                       .P_CALCULATION_METHOD);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Comm amt       - ' || P_TY_COMMISSION(I)
                       .P_COMMISSION_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Minm amt       - ' ||
                       L_ICCF_RULE.MINIMUM_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Maxm amt       - ' ||
                       L_ICCF_RULE.MAXIMUM_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>minmax_type      - ' ||
                       L_ICCF_RULE.MINMAX_TYPE);
        IF L_ICCF_RULE.MINMAX_TYPE = 'A' THEN
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> CNSL_RETRO p_ty_commission(i).p_commission_amount before: ' || P_TY_COMMISSION(I)
                         .P_COMMISSION_AMOUNT);
          IF P_TY_COMMISSION(I)
           .P_COMMISSION_AMOUNT < NVL(L_ICCF_RULE.MINIMUM_AMOUNT, 0) THEN
            P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := NVL(L_ICCF_RULE.MINIMUM_AMOUNT,
                                                          0);
          ELSIF P_TY_COMMISSION(I)
           .P_COMMISSION_AMOUNT >
                 NVL(L_ICCF_RULE.MAXIMUM_AMOUNT,
                     P_TY_COMMISSION(I).P_COMMISSION_AMOUNT + 1) THEN
            P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_ICCF_RULE.MAXIMUM_AMOUNT;
          END IF;
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> CNSL_RETRO p_ty_commission(i).p_commission_amount After: ' || P_TY_COMMISSION(I)
                         .P_COMMISSION_AMOUNT);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> CNSL_RETRO p_ty_commission(i).p_rate Before: ' || P_TY_COMMISSION(I)
                         .P_RATE);
          
          DEBUG.PR_DEBUG('CF', 'L_ICCF_RULE.MINIMUM_AMOUNT='||L_ICCF_RULE.MINIMUM_AMOUNT);
          
          --sampath starts for commission calculation
         -- IF L_ICCF_RULE.MINIMUM_AMOUNT IS NOT NULL AND L_ICCF_RULE.MINIMUM_AMOUNT < 20  THEN
            
            IF (L_AMOUNT * (L_RATE/100)) <  L_ICCF_RULE.MINIMUM_AMOUNT THEN
            
            P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_ICCF_RULE.MINIMUM_AMOUNT *
                                                      L_NUMBER_OF_PERIODS;
                                                      
            END IF;
            
            DEBUG.PR_DEBUG('CF','P_TY_COMMISSION(I).P_COMMISSION_AMOUNT='||P_TY_COMMISSION(I).P_COMMISSION_AMOUNT);
            
          --END IF;
          --sampath ends for commission calculation
        
        ELSIF L_ICCF_RULE.MINMAX_TYPE = 'R' THEN
        
          IF P_TY_COMMISSION(I).P_RATE < NVL(L_ICCF_RULE.MINIMUM_RATE, 0) THEN
            P_TY_COMMISSION(I).P_RATE := NVL(L_ICCF_RULE.MINIMUM_RATE, 0);
          ELSIF P_TY_COMMISSION(I)
           .P_RATE >
                 NVL(L_ICCF_RULE.MAXIMUM_RATE, P_TY_COMMISSION(I).P_RATE + 1) THEN
            P_TY_COMMISSION(I).P_RATE := NVL(L_ICCF_RULE.MAXIMUM_RATE, 0);
          END IF;
        
        END IF;
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation> CNSL_RETRO p_ty_commission(i).p_rate After: ' || P_TY_COMMISSION(I)
                       .P_RATE);
      
        DEBUG.PR_DEBUG('LC',
                       'Flat amt ccy - ' ||
                       NVL(L_ICCF_RULE.FLAT_AMOUNT_CURRENCY, 'ALL'));
      
        IF NVL(L_ICCF_RULE.FLAT_AMOUNT_CURRENCY, 'ALL') = 'ALL' THEN
        
          L_COMMISSION_CHARGE_CURRENCY := L_CON_CCY;
        ELSE
          L_COMMISSION_CHARGE_CURRENCY := L_ICCF_RULE.FLAT_AMOUNT_CURRENCY;
        
          DEBUG.PR_DEBUG('CF',
                         'l_cftbs_contract_commission.currency' ||
                         L_CFTBS_CONTRACT_COMMISSION.CURRENCY);
          IF L_CFTBS_CONTRACT_COMMISSION.CURRENCY IS NOT NULL AND
             (L_CFTBS_CONTRACT_COMMISSION.CURRENCY <>
             L_ICCF_RULE.FLAT_AMOUNT_CURRENCY) THEN
            DEBUG.PR_DEBUG('CF',
                           'When charge currency associated with commission is NULL or ALL, contract commission currency should be same same as charge currency  ');
            OVPKSS.PR_APPENDTBL('CFCOM-LC-10', '');
          END IF;
        
        END IF;
      
        DEBUG.PR_DEBUG('LC', 'Basis amt ccy - ' || L_BASIS_AMT_CCY);
        DEBUG.PR_DEBUG('LC',
                       'Comm charge ccy - ' || L_COMMISSION_CHARGE_CURRENCY);
      
        IF L_COMMISSION_CHARGE_CURRENCY <> L_BASIS_AMT_CCY THEN
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> l_basis_amt_ccy ' ||
                         L_BASIS_AMT_CCY);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> l_iccf_rule.flat_amount_currency ' ||
                         L_ICCF_RULE.FLAT_AMOUNT_CURRENCY);
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> l_commission_charge_currency ' ||
                         L_COMMISSION_CHARGE_CURRENCY);
          L_CCY_RATE := NULL;
        
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                        L_BASIS_AMT_CCY,
                                        L_COMMISSION_CHARGE_CURRENCY,
                                        NVL(L_ICCF_RULE.RATE_CODE, 'STANDARD'),
                                        NVL(L_ICCF_RULE.RATE_CODE_TYPE, 'M'),
                                        P_TY_COMMISSION(I).P_COMMISSION_AMOUNT,
                                        'Y',
                                        L_CONVAMT,
                                        L_CCY_RATE,
                                        L_ERR_CODE) THEN
            DEBUG.PR_DEBUG('CF',
                           'fn_commission_computation> Failed to convert amount' ||
                           L_ERR_CODE);
            RETURN FALSE;
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> Final l_charge_amount ' ||
                         TO_CHAR(L_CONVAMT));
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation> Rate ' ||
                         TO_CHAR(L_CCY_RATE));
        
          P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_CONVAMT;
        
        END IF;
      
        P_TY_COMMISSION(I).P_COMMISSION_CURRENCY := L_COMMISSION_CHARGE_CURRENCY;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Comm amt       - ' || P_TY_COMMISSION(I)
                       .P_COMMISSION_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Comm ccy       - ' || P_TY_COMMISSION(I)
                       .P_COMMISSION_CURRENCY);
      
        IF NOT
            CYPKSS.FN_AMT_ROUND(P_TY_COMMISSION(I).P_COMMISSION_CURRENCY,
                                NVL(P_TY_COMMISSION(I).P_COMMISSION_AMOUNT, 0),
                                L_ROUND_AMOUNT) THEN
          DEBUG.PR_DEBUG('CF',
                         'fn_commission_computation>Rounding Bombed ');
          RETURN FALSE;
        END IF;
      
        P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_ROUND_AMOUNT;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>>> santosh >>-custmr: ' || P_TY_COMMISSION(I)
                       .P_CUSTOMER);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>>>  >>-refno: ' || P_TY_COMMISSION(I)
                       .P_CONTRACT_REFERENCE_NO);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>>>  >>-component: ' || P_TY_COMMISSION(I)
                       .P_COMPONENT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>>>  >>- comm ccy: ' || P_TY_COMMISSION(I)
                       .P_COMMISSION_CURRENCY);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>>>  >>- basis amt ccy: ' || P_TY_COMMISSION(I)
                       .P_BASIS_AMOUNT_CURRENCY);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>>>  >>- pdt: ' ||
                       L_PRODUCT);
      
        DEBUG.PR_DEBUG('CF',
                       'Check for RP...calling procedure for RP Detail...');
      
        COPKS_RP_PROCESSING.PR_GET_RP_DETAILS(L_RP_DTLS,
                                              L_ERROR_CODE,
                                              L_ERROR_PARAM);
        IF L_ERROR_CODE IS NOT NULL THEN
          OVPKSS.PR_APPENDTBL(L_ERROR_CODE, L_ERROR_PARAM);
        END IF;
      
        IF NVL(L_RP_DTLS.P_RP_FLAG, FALSE) = TRUE THEN
          DEBUG.PR_DEBUG('CF',
                         'RP charge indicator--> l_rp_dtls.p_var_value ' ||
                         L_RP_DTLS.P_VAR_VALUE);
          IF L_RP_DTLS.P_VAR_VALUE <> '99999999999999999999' THEN
            DEBUG.PR_DEBUG('CF',
                           'RP is applicable to this customer ' || P_TY_COMMISSION(I)
                           .P_CUSTOMER);
            DEBUG.PR_DEBUG('CF',
                           '>> Comm amt bf4 RP applied: ' || P_TY_COMMISSION(I)
                           .P_COMMISSION_AMOUNT);
            DEBUG.PR_DEBUG('CF',
                           '>> benefit type: ' || L_RP_DTLS.P_BEN_TYPE);
          
            IF L_RP_DTLS.P_BEN_TYPE = 'W' THEN
              P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := 0;
            
            ELSIF L_RP_DTLS.P_BEN_TYPE = 'V' THEN
              DEBUG.PR_DEBUG('CF',
                             'Value from copks_rp_processing.pr_get_rp_details() var type: ' ||
                             L_RP_DTLS.P_VAR_TYPE);
              DEBUG.PR_DEBUG('CF',
                             'Value from copks_rp_processing.pr_get_rp_details() var value: ' ||
                             L_RP_DTLS.P_VAR_VALUE);
            
              IF L_RP_DTLS.P_VAR_TYPE = 'A' THEN
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := L_RP_DTLS.P_VAR_VALUE;
              ELSIF L_RP_DTLS.P_VAR_TYPE = 'T' THEN
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := (P_TY_COMMISSION(I)
                                                          .P_COMMISSION_AMOUNT +
                                                           (L_RP_DTLS.P_VAR_VALUE));
              ELSIF L_RP_DTLS.P_VAR_TYPE = 'P' THEN
                P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := (P_TY_COMMISSION(I)
                                                          .P_COMMISSION_AMOUNT +
                                                           (P_TY_COMMISSION(I)
                                                           .P_COMMISSION_AMOUNT *
                                                            ((L_RP_DTLS.P_VAR_VALUE) / 100)));
              END IF;
            END IF;
            DEBUG.PR_DEBUG('CF',
                           '>> Comm amt after RP applied: ' || P_TY_COMMISSION(I)
                           .P_COMMISSION_AMOUNT);
          END IF;
        END IF;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Rate           - ' ||
                       L_RATE);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Basis Amt      - ' ||
                       L_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>coll per       - ' ||
                       L_COLLECTION_PERIOD);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Calc meth      - ' || P_TY_COMMISSION(I)
                       .P_CALCULATION_METHOD);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Comm amt       - ' || P_TY_COMMISSION(I)
                       .P_COMMISSION_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Minm amt       - ' ||
                       L_ICCF_RULE.MINIMUM_AMOUNT);
        DEBUG.PR_DEBUG('CF',
                       'fn_commission_computation>Maxm amt       - ' ||
                       L_ICCF_RULE.MAXIMUM_AMOUNT);
      
        DEBUG.PR_DEBUG('CF',
                       'HELLO HERE 1------>RETRO FLAG ' ||
                       L_RETROSPECTIVE_FLAG);
        IF L_RETROSPECTIVE_FLAG = 'Y' THEN
          P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := GREATEST(P_TY_COMMISSION(I)
                                                             .P_COMMISSION_AMOUNT,
                                                             L_GOOD_UNTIL_AMOUNT);
        
          DEBUG.PR_DEBUG('CF',
                         'HELLO HERE 2------>AMOUNT ' || P_TY_COMMISSION(I)
                         .P_COMMISSION_AMOUNT);
        ELSE
        
          DEBUG.PR_DEBUG('CF',
                         'HELLO HERE 3------>AMOUNT FROM SQL TABLE ' || P_TY_COMMISSION(I)
                         .P_COMMISSION_AMOUNT);
          DEBUG.PR_DEBUG('CF',
                         'HELLO HERE 4------>AMOUNT FROM CFTBS' ||
                         L_GOOD_UNTIL_AMOUNT);
          DEBUG.PR_DEBUG('CF',
                         'HELLO HERE 4444444444------>p_ty_commission(i).p_calculation_method' || P_TY_COMMISSION(I)
                         .P_CALCULATION_METHOD);
        
          IF P_TY_COMMISSION(I).P_CALCULATION_METHOD NOT IN ('P', 'L') THEN
          
            P_TY_COMMISSION(I).P_COMMISSION_AMOUNT := P_TY_COMMISSION(I)
                                                      .P_COMMISSION_AMOUNT +
                                                       L_GOOD_UNTIL_AMOUNT;
          END IF;
        
          DEBUG.PR_DEBUG('CF',
                         'HELLO HERE 5------>AMOUNT FROM SQL TABLE AFTER CALC ' || P_TY_COMMISSION(I)
                         .P_COMMISSION_AMOUNT);
        
        END IF;
      
        IF NVL(L_RP_DTLS.P_RP_FLAG, FALSE) = TRUE THEN
          DEBUG.PR_DEBUG('LD',
                         '>> CFPKS_COMPUTATION--> l_rp_dtls.p_var_value: ' ||
                         L_RP_DTLS.P_VAR_VALUE);
          IF L_RP_DTLS.P_VAR_VALUE <> '99999999999999999999' THEN
            L_RP_DTLS.P_PRICE_CCY      := P_TY_COMMISSION(I)
                                          .P_COMMISSION_CURRENCY;
            L_RP_DTLS.P_ORIGINAL_PRICE := L_ROUND_AMOUNT;
            L_RP_DTLS.P_FINAL_PRICE    := P_TY_COMMISSION(I)
                                          .P_COMMISSION_AMOUNT;
          
            IF NOT
                COPKS_RP_PROCESSING.FN_INSERT_SCHEME_APP(L_RP_DTLS,
                                                         L_ERROR_CODE,
                                                         L_ERROR_PARAM) THEN
              DEBUG.PR_DEBUG('CF',
                             'Falied to insert in cotb_cust_avld_scheme_dtls for RP functionality');
              OVPKSS.PR_APPENDTBL(L_ERROR_CODE, L_ERROR_PARAM);
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      
      END LOOP;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    DEBUG.PR_DEBUG('CF',
                   'fn_commission_computation>  Computation >>>> SUCCESSFUL <<<<<');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CF',
                     'fn_commission_computation>failed in comm ' || SQLERRM);
      RETURN FALSE;
  END FN_COMMISSION_COMPUTATION;

  FUNCTION FN_COMMISSION_GOOD_UNTIL_DATE(P_TY_COMMISSION_GOOD IN OUT TY_COMMISSION_GOOD)
    RETURN BOOLEAN IS
    L_FIRST           NUMBER;
    L_COUNT           NUMBER;
    L_ROUNDING_PERIOD CFTMS_RULE.ROUNDING_PERIOD%TYPE;
    L_PRODUCT         CSTBS_CONTRACT.PRODUCT_CODE%TYPE;
    L_BRANCH          CSTBS_CONTRACT.BRANCH%TYPE;
    L_BOOK_DATE       CSTBS_CONTRACT.BOOK_DATE%TYPE;
    L_SERIAL_NO       CSTBS_CONTRACT.SERIAL_NO%TYPE;
    L_RULE            CFTMS_RULE.RULE%TYPE;
    L_CURRENT_DATE    CFTBS_CONTRACT_COMMISSION.TRANSACTION_DATE%TYPE;
    L_START_DATE      CFTBS_CONTRACT_COMMISSION.TRANSACTION_DATE%TYPE;
    DAY_OF_MONTH      VARCHAR2(2);
    MONTH_YEAR        VARCHAR2(6);
    END_OF_MONTH      DATE;
  
    L_MIN_END_DATE DATE;
    L_MIN_PERIOD   CFTMS_RULE.MINIMUM_PERIOD%TYPE;
    L_CHARGE_GROUP STTMS_CUSTOMER.CHARGE_GROUP%TYPE;
    L_BRANCH_CODE  STTMS_BRANCH.BRANCH_CODE%TYPE := GLOBAL.CURRENT_BRANCH;
  BEGIN
    L_FIRST := P_TY_COMMISSION_GOOD.FIRST;
    L_COUNT := P_TY_COMMISSION_GOOD.COUNT;
    FOR I IN L_FIRST .. L_COUNT LOOP
      IF NOT CSPKES_MISC.FN_SPLITREFNO(P_TY_COMMISSION_GOOD(I)
                                       .P_CONTRACT_REFERENCE_NO,
                                       L_BRANCH,
                                       L_PRODUCT,
                                       L_BOOK_DATE,
                                       L_SERIAL_NO) THEN
        RETURN FALSE;
      END IF;
      SELECT RULE
        INTO L_RULE
        FROM CFTMS_PRODUCT_ICCF
       WHERE PRODUCT = L_PRODUCT
         AND COMPONENT = P_TY_COMMISSION_GOOD(I).P_COMPONENT;
    
      BEGIN
        SELECT NVL(CHARGE_GROUP, 'ALL')
          INTO L_CHARGE_GROUP
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_TY_COMMISSION_GOOD(I).P_CUSTOMER
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_CHARGE_GROUP := 'ALL';
      END;
    
      BEGIN
        SELECT ROUNDING_PERIOD, MINIMUM_PERIOD
          INTO L_ROUNDING_PERIOD, L_MIN_PERIOD
          FROM CFTMS_RULE
         WHERE RULE = L_RULE
           AND CUSTOMER = P_TY_COMMISSION_GOOD(I).P_CUSTOMER
           AND CURRENCY = P_TY_COMMISSION_GOOD(I).P_CURRENCY
           AND CURRENCY2 = P_TY_COMMISSION_GOOD(I).P_CURRENCY
           AND CUSTOMER_GROUP = L_CHARGE_GROUP
           AND BRANCH_CODE = L_BRANCH_CODE
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            SELECT ROUNDING_PERIOD, MINIMUM_PERIOD
              INTO L_ROUNDING_PERIOD, L_MIN_PERIOD
              FROM CFTMS_RULE
             WHERE RULE = L_RULE
               AND CUSTOMER = P_TY_COMMISSION_GOOD(I).P_CUSTOMER
               AND CURRENCY = 'ALL'
               AND CURRENCY2 = 'ALL'
               AND CUSTOMER_GROUP = L_CHARGE_GROUP
               AND BRANCH_CODE = L_BRANCH_CODE
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              BEGIN
                SELECT ROUNDING_PERIOD, MINIMUM_PERIOD
                  INTO L_ROUNDING_PERIOD, L_MIN_PERIOD
                  FROM CFTMS_RULE
                 WHERE RULE = L_RULE
                   AND CUSTOMER = 'ALL'
                   AND CURRENCY = P_TY_COMMISSION_GOOD(I).P_CURRENCY
                   AND CURRENCY2 = P_TY_COMMISSION_GOOD(I).P_CURRENCY
                   AND CUSTOMER_GROUP = L_CHARGE_GROUP
                   AND BRANCH_CODE = L_BRANCH_CODE
                   AND AUTH_STAT = 'A'
                   AND RECORD_STAT = 'O';
              
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  BEGIN
                    SELECT ROUNDING_PERIOD, MINIMUM_PERIOD
                      INTO L_ROUNDING_PERIOD, L_MIN_PERIOD
                      FROM CFTMS_RULE
                     WHERE RULE = L_RULE
                       AND CUSTOMER = 'ALL'
                       AND CURRENCY = P_TY_COMMISSION_GOOD(I).P_CURRENCY
                       AND CURRENCY2 = P_TY_COMMISSION_GOOD(I).P_CURRENCY
                       AND CUSTOMER_GROUP = 'ALL'
                       AND BRANCH_CODE = L_BRANCH_CODE
                       AND AUTH_STAT = 'A'
                       AND RECORD_STAT = 'O';
                  
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      BEGIN
                        SELECT ROUNDING_PERIOD, MINIMUM_PERIOD
                          INTO L_ROUNDING_PERIOD, L_MIN_PERIOD
                          FROM CFTMS_RULE
                         WHERE RULE = L_RULE
                           AND CUSTOMER = 'ALL'
                           AND CURRENCY = 'ALL'
                           AND CURRENCY2 = 'ALL'
                           AND CUSTOMER_GROUP = L_CHARGE_GROUP
                           AND BRANCH_CODE = L_BRANCH_CODE
                           AND AUTH_STAT = 'A'
                           AND RECORD_STAT = 'O';
                      EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                          BEGIN
                            SELECT ROUNDING_PERIOD, MINIMUM_PERIOD
                              INTO L_ROUNDING_PERIOD, L_MIN_PERIOD
                              FROM CFTMS_RULE
                             WHERE RULE = L_RULE
                               AND CUSTOMER = 'ALL'
                               AND CURRENCY = 'ALL'
                               AND CURRENCY2 = 'ALL'
                               AND CUSTOMER_GROUP = 'ALL'
                               AND BRANCH_CODE = L_BRANCH_CODE
                               AND AUTH_STAT = 'A'
                               AND RECORD_STAT = 'O';
                          EXCEPTION
                            WHEN NO_DATA_FOUND THEN
                              BEGIN
                                SELECT ROUNDING_PERIOD, MINIMUM_PERIOD
                                  INTO L_ROUNDING_PERIOD, L_MIN_PERIOD
                                  FROM CFTMS_RULE
                                 WHERE RULE = L_RULE
                                   AND CUSTOMER = P_TY_COMMISSION_GOOD(I)
                                      .P_CUSTOMER
                                   AND CURRENCY = P_TY_COMMISSION_GOOD(I)
                                      .P_CURRENCY
                                   AND CURRENCY2 = P_TY_COMMISSION_GOOD(I)
                                      .P_CURRENCY
                                   AND CUSTOMER_GROUP = L_CHARGE_GROUP
                                   AND BRANCH_CODE = 'ALL'
                                   AND AUTH_STAT = 'A'
                                   AND RECORD_STAT = 'O';
                              EXCEPTION
                                WHEN NO_DATA_FOUND THEN
                                  BEGIN
                                    SELECT ROUNDING_PERIOD, MINIMUM_PERIOD
                                      INTO L_ROUNDING_PERIOD, L_MIN_PERIOD
                                      FROM CFTMS_RULE
                                     WHERE RULE = L_RULE
                                       AND CUSTOMER = P_TY_COMMISSION_GOOD(I)
                                          .P_CUSTOMER
                                       AND CURRENCY = 'ALL'
                                       AND CURRENCY2 = 'ALL'
                                       AND CUSTOMER_GROUP = L_CHARGE_GROUP
                                       AND BRANCH_CODE = 'ALL'
                                       AND AUTH_STAT = 'A'
                                       AND RECORD_STAT = 'O';
                                  EXCEPTION
                                    WHEN NO_DATA_FOUND THEN
                                      BEGIN
                                        SELECT ROUNDING_PERIOD,
                                               MINIMUM_PERIOD
                                          INTO L_ROUNDING_PERIOD,
                                               L_MIN_PERIOD
                                          FROM CFTMS_RULE
                                         WHERE RULE = L_RULE
                                           AND CUSTOMER = 'ALL'
                                           AND CURRENCY = P_TY_COMMISSION_GOOD(I)
                                              .P_CURRENCY
                                           AND CURRENCY2 = P_TY_COMMISSION_GOOD(I)
                                              .P_CURRENCY
                                           AND CUSTOMER_GROUP =
                                               L_CHARGE_GROUP
                                           AND BRANCH_CODE = 'ALL'
                                           AND AUTH_STAT = 'A'
                                           AND RECORD_STAT = 'O';
                                      
                                      EXCEPTION
                                        WHEN NO_DATA_FOUND THEN
                                          BEGIN
                                            SELECT ROUNDING_PERIOD,
                                                   MINIMUM_PERIOD
                                              INTO L_ROUNDING_PERIOD,
                                                   L_MIN_PERIOD
                                              FROM CFTMS_RULE
                                             WHERE RULE = L_RULE
                                               AND CUSTOMER = 'ALL'
                                               AND CURRENCY = P_TY_COMMISSION_GOOD(I)
                                                  .P_CURRENCY
                                               AND CURRENCY2 = P_TY_COMMISSION_GOOD(I)
                                                  .P_CURRENCY
                                               AND CUSTOMER_GROUP = 'ALL'
                                               AND BRANCH_CODE = 'ALL'
                                               AND AUTH_STAT = 'A'
                                               AND RECORD_STAT = 'O';
                                          EXCEPTION
                                            WHEN NO_DATA_FOUND THEN
                                              BEGIN
                                                SELECT ROUNDING_PERIOD,
                                                       MINIMUM_PERIOD
                                                  INTO L_ROUNDING_PERIOD,
                                                       L_MIN_PERIOD
                                                  FROM CFTMS_RULE
                                                 WHERE RULE = L_RULE
                                                   AND CUSTOMER = 'ALL'
                                                   AND CURRENCY = 'ALL'
                                                   AND CURRENCY2 = 'ALL'
                                                   AND CUSTOMER_GROUP =
                                                       L_CHARGE_GROUP
                                                   AND BRANCH_CODE = 'ALL'
                                                   AND AUTH_STAT = 'A'
                                                   AND RECORD_STAT = 'O';
                                              
                                              EXCEPTION
                                                WHEN NO_DATA_FOUND THEN
                                                  BEGIN
                                                    SELECT ROUNDING_PERIOD,
                                                           MINIMUM_PERIOD
                                                      INTO L_ROUNDING_PERIOD,
                                                           L_MIN_PERIOD
                                                      FROM CFTMS_RULE
                                                     WHERE RULE = L_RULE
                                                       AND CURRENCY = 'ALL'
                                                       AND CURRENCY2 =
                                                           'ALL'
                                                       AND CUSTOMER = 'ALL'
                                                       AND CUSTOMER_GROUP =
                                                           'ALL'
                                                       AND BRANCH_CODE =
                                                           'ALL'
                                                       AND AUTH_STAT = 'A'
                                                       AND RECORD_STAT = 'O';
                                                  END;
                                              END;
                                          END;
                                      END;
                                  END;
                              END;
                          END;
                      END;
                  END;
              END;
          END;
      END;
      IF NVL(P_TY_COMMISSION_GOOD(I).P_ROUNDING_PERIOD, 0) <> 0 THEN
        L_ROUNDING_PERIOD := P_TY_COMMISSION_GOOD(I).P_ROUNDING_PERIOD;
      END IF;
      L_START_DATE   := P_TY_COMMISSION_GOOD(I).P_START_DATE;
      L_CURRENT_DATE := P_TY_COMMISSION_GOOD(I).P_START_DATE;
    
      IF P_TY_COMMISSION_GOOD(I).P_END_DATE IS NULL THEN
      
        IF NVL(L_ROUNDING_PERIOD, 0) <> 0 THEN
          L_CURRENT_DATE := ADD_MONTHS(L_CURRENT_DATE, L_ROUNDING_PERIOD);
          IF L_START_DATE <> LAST_DAY(L_START_DATE) THEN
            DAY_OF_MONTH   := LEAST(TO_CHAR(L_CURRENT_DATE, 'DD'),
                                    TO_CHAR(L_START_DATE, 'DD'));
            MONTH_YEAR     := TO_CHAR(L_CURRENT_DATE, 'MMYYYY');
            END_OF_MONTH   := TO_DATE(MONTH_YEAR || DAY_OF_MONTH,
                                      'MMYYYYDD');
            L_CURRENT_DATE := LEAST(END_OF_MONTH, L_CURRENT_DATE);
          END IF;
        
        ELSE
          L_CURRENT_DATE := L_CURRENT_DATE + 1;
        
        END IF;
      
      ELSE
      
        IF NVL(L_ROUNDING_PERIOD, 0) <> 0 THEN
          WHILE L_CURRENT_DATE - 1 < P_TY_COMMISSION_GOOD(I).P_END_DATE
          
           LOOP
            L_CURRENT_DATE := ADD_MONTHS(L_CURRENT_DATE, L_ROUNDING_PERIOD);
            IF L_START_DATE <> LAST_DAY(L_START_DATE) THEN
              DAY_OF_MONTH   := LEAST(TO_CHAR(L_CURRENT_DATE, 'DD'),
                                      TO_CHAR(L_START_DATE, 'DD'));
              MONTH_YEAR     := TO_CHAR(L_CURRENT_DATE, 'MMYYYY');
              END_OF_MONTH   := TO_DATE(MONTH_YEAR || DAY_OF_MONTH,
                                        'MMYYYYDD');
              L_CURRENT_DATE := LEAST(END_OF_MONTH, L_CURRENT_DATE);
            END IF;
          END LOOP;
        ELSE
          L_CURRENT_DATE := P_TY_COMMISSION_GOOD(I).P_END_DATE + 1;
        END IF;
      
      END IF;
    
      L_MIN_END_DATE := ADD_MONTHS(P_TY_COMMISSION_GOOD(I).P_START_DATE,
                                   L_MIN_PERIOD);
      IF L_CURRENT_DATE < L_MIN_END_DATE THEN
        P_TY_COMMISSION_GOOD(I).P_GOOD_UNTIL_DATE := L_MIN_END_DATE - 1;
      ELSE
        P_TY_COMMISSION_GOOD(I).P_GOOD_UNTIL_DATE := L_CURRENT_DATE - 1;
      END IF;
    
      DEBUG.PR_DEBUG('CF',
                     'fn_commission_good_until_date>GUD    - ' ||
                     L_CURRENT_DATE);
      DEBUG.PR_DEBUG('CF',
                     'fn_commission_good_until_date>End dt - ' || P_TY_COMMISSION_GOOD(I)
                     .P_END_DATE);
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END FN_COMMISSION_GOOD_UNTIL_DATE;

  FUNCTION FN_TENOR_BASED_COMM_CALC(P_TENOR            IN NUMBER,
                                    P_GOOD_UNTIL_TENOR IN NUMBER,
                                    
                                    P_TENOR_IN_DAYS          IN NUMBER,
                                    P_TOTAL_DAYS             IN NUMBER,
                                    P_ICCF_RULE              IN CFTMS_RULE%ROWTYPE,
                                    P_AMOUNT                 IN CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE,
                                    P_COMMISSION_AMOUNT_CALC OUT NUMBER,
                                    P_TIER_RATE              OUT CFTMS_BRACKET_TENOR.RATE%TYPE,
                                    P_ERR_CODE               IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                    P_ORIGINAL_TAG_AMOUNT    IN NUMBER)
    RETURN BOOLEAN IS
  
    CURSOR C_TENOR_BRACKET(L_BASIS_AMOUNT_TO CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE) IS
      SELECT *
        FROM CFTMS_BRACKET_TENOR
       WHERE RULE = P_ICCF_RULE.RULE
         AND CURRENCY = P_ICCF_RULE.CURRENCY
         AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
         AND CUSTOMER = P_ICCF_RULE.CUSTOMER
         AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
         AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
         AND BASIS_AMOUNT_TO = L_BASIS_AMOUNT_TO;
  
    L_COMMISSION_AMOUNT_CALC NUMBER := 0;
    L_CALC_PERIOD            NUMBER := 0;
    L_MAX_BASIS_AMOUNT_TO    CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE;
    L_MIN_BASIS_AMOUNT_TO    CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE;
    L_ICCF_BRACKET           CFTMS_BRACKET%ROWTYPE;
  
  BEGIN
    P_TIER_RATE := NULL;
  
    BEGIN
      SELECT *
        INTO L_ICCF_BRACKET
        FROM CFTMS_BRACKET
       WHERE RULE = P_ICCF_RULE.RULE
         AND CURRENCY = P_ICCF_RULE.CURRENCY
         AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
         AND CUSTOMER = P_ICCF_RULE.CUSTOMER
         AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
         AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
         AND P_ORIGINAL_TAG_AMOUNT + P_AMOUNT <= BASIS_AMOUNT_TO
         AND P_ORIGINAL_TAG_AMOUNT + P_AMOUNT >= BASIS_AMOUNT_FROM;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        SELECT MAX(BASIS_AMOUNT_TO), MIN(BASIS_AMOUNT_TO)
          INTO L_MAX_BASIS_AMOUNT_TO, L_MIN_BASIS_AMOUNT_TO
          FROM CFTMS_BRACKET
         WHERE RULE = P_ICCF_RULE.RULE
           AND CURRENCY = P_ICCF_RULE.CURRENCY
           AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
           AND CUSTOMER = P_ICCF_RULE.CUSTOMER
           AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
           AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE;
        IF P_ORIGINAL_TAG_AMOUNT + P_AMOUNT > L_MAX_BASIS_AMOUNT_TO THEN
          SELECT *
            INTO L_ICCF_BRACKET
            FROM CFTMS_BRACKET
           WHERE RULE = P_ICCF_RULE.RULE
             AND CURRENCY = P_ICCF_RULE.CURRENCY
             AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
             AND CUSTOMER = P_ICCF_RULE.CUSTOMER
             AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
             AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
             AND BASIS_AMOUNT_TO = L_MAX_BASIS_AMOUNT_TO;
        ELSE
          SELECT *
            INTO L_ICCF_BRACKET
            FROM CFTMS_BRACKET
           WHERE RULE = P_ICCF_RULE.RULE
             AND CURRENCY = P_ICCF_RULE.CURRENCY
             AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
             AND CUSTOMER = P_ICCF_RULE.CUSTOMER
             AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
             AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
             AND BASIS_AMOUNT_TO = L_MIN_BASIS_AMOUNT_TO;
        END IF;
    END;
  
    FOR EACH_TIER IN C_TENOR_BRACKET(L_ICCF_BRACKET.BASIS_AMOUNT_TO) LOOP
    
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>retrospective is not set. So I am here');
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>EachTier.Tenor_From : ' ||
                     EACH_TIER.TENOR_FROM);
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>l_tenor                : ' ||
                     P_TENOR);
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>l_good_until_tenor  : ' ||
                     P_GOOD_UNTIL_TENOR);
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>l_tenor + l_good_until_tenor  : ' ||
                     (P_GOOD_UNTIL_TENOR + P_TENOR));
    
      IF EACH_TIER.TENOR_FROM > (P_TENOR + P_GOOD_UNTIL_TENOR) THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 1 Reached');
        L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC + 0;
      
      ELSIF P_GOOD_UNTIL_TENOR < EACH_TIER.TENOR_TO THEN
        L_CALC_PERIOD := LEAST(EACH_TIER.TENOR_TO,
                               P_TENOR + P_GOOD_UNTIL_TENOR) -
                         GREATEST(P_GOOD_UNTIL_TENOR,
                                  EACH_TIER.TENOR_FROM - 1);
      
        IF P_ICCF_RULE.ROUNDING_PERIOD != 0 THEN
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD /
                                      (100 * P_ICCF_RULE.RATE_PERIOD));
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD * 30 /
                                      (100 * P_TOTAL_DAYS));
        END IF;
        P_TIER_RATE := EACH_TIER.RATE;
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor From is ' ||
                       TO_CHAR(EACH_TIER.TENOR_FROM));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor To is ' ||
                       TO_CHAR(EACH_TIER.TENOR_TO));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Rate used is ' ||
                       TO_CHAR(EACH_TIER.RATE));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Commission till now >> ' ||
                       TO_CHAR(L_COMMISSION_AMOUNT_CALC));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Period of CALC - ' ||
                       L_CALC_PERIOD);
      
      ELSIF EACH_TIER.TENOR_FROM >= P_GOOD_UNTIL_TENOR AND
            (P_GOOD_UNTIL_TENOR + P_TENOR) <= EACH_TIER.TENOR_TO THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 3 Reached');
      
        L_CALC_PERIOD := P_GOOD_UNTIL_TENOR + P_TENOR -
                         EACH_TIER.TENOR_FROM + 1;
        IF P_GOOD_UNTIL_TENOR = EACH_TIER.TENOR_FROM THEN
          L_CALC_PERIOD := L_CALC_PERIOD - 1;
        END IF;
      
        IF P_ICCF_RULE.ROUNDING_PERIOD != 0 THEN
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD /
                                      (100 * P_ICCF_RULE.RATE_PERIOD));
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD * 30 /
                                      (100 * P_TOTAL_DAYS));
        END IF;
      
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor From is ' ||
                       TO_CHAR(EACH_TIER.TENOR_FROM));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor To is ' ||
                       TO_CHAR(EACH_TIER.TENOR_TO));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Rate used is ' ||
                       TO_CHAR(EACH_TIER.RATE));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Commission till now >> ' ||
                       TO_CHAR(L_COMMISSION_AMOUNT_CALC));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Period of CALC - ' ||
                       L_CALC_PERIOD);
      
      ELSIF (EACH_TIER.TENOR_FROM >= (P_GOOD_UNTIL_TENOR + 1) AND
            EACH_TIER.TENOR_TO <= (P_GOOD_UNTIL_TENOR + P_TENOR)) THEN
      
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 4 Reached');
        L_CALC_PERIOD := (EACH_TIER.TENOR_TO - EACH_TIER.TENOR_FROM + 1);
      
        IF P_ICCF_RULE.ROUNDING_PERIOD != 0 THEN
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD /
                                      (100 * P_ICCF_RULE.RATE_PERIOD));
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD * 30 /
                                      (100 * P_TOTAL_DAYS));
        END IF;
        P_TIER_RATE := EACH_TIER.RATE;
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor From is ' ||
                       TO_CHAR(EACH_TIER.TENOR_FROM));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor To is ' ||
                       TO_CHAR(EACH_TIER.TENOR_TO));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Rate used is ' ||
                       TO_CHAR(EACH_TIER.RATE));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Commission till now >> ' ||
                       TO_CHAR(L_COMMISSION_AMOUNT_CALC));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Period of CALC - ' ||
                       L_CALC_PERIOD);
      END IF;
    END LOOP;
  
    P_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC;
    DEBUG.PR_DEBUG('CF',
                   'fn_tenor_based_comm_calc..>Exiting function fn_tenor_based_comm_calc');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CF',
                     'In when others fn_tenor_based_comm_calc ' || SQLCODE ||
                     SQLERRM);
      DEBUG.PR_DEBUG('CF',
                     'In when others fn_tenor_based_comm_calc ' || SQLCODE ||
                     SQLERRM);
      P_ERR_CODE := 'CF-001';
      RETURN FALSE;
  END FN_TENOR_BASED_COMM_CALC;

  FUNCTION FN_TIER_AMT_TENOR_COMM(P_TENOR            IN NUMBER,
                                  P_GOOD_UNTIL_TENOR IN NUMBER,
                                  
                                  P_TENOR_IN_DAYS          IN NUMBER,
                                  P_TOTAL_DAYS             IN NUMBER,
                                  P_ICCF_RULE              IN CFTMS_RULE%ROWTYPE,
                                  P_AMOUNT                 IN CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE,
                                  P_COMMISSION_AMOUNT_CALC OUT NUMBER,
                                  P_TIER_RATE              OUT CFTMS_BRACKET_TENOR.RATE%TYPE,
                                  P_ERR_CODE               IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                  P_ORIGINAL_TAG_AMOUNT    IN NUMBER,
                                  P_BASIS_AMOUNT_TO        IN NUMBER)
    RETURN BOOLEAN IS
  
    CURSOR C_TENOR_BRACKET(L_BASIS_AMOUNT_TO CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE,
                           
                           L_CUSTOMER_GROUP CFTMS_BRACKET.CUSTOMER_GROUP%TYPE) IS
    
      SELECT *
        FROM CFTMS_BRACKET_TENOR
       WHERE RULE = P_ICCF_RULE.RULE
         AND CURRENCY = P_ICCF_RULE.CURRENCY
         AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
         AND CUSTOMER = P_ICCF_RULE.CUSTOMER
         AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
         AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
         AND BASIS_AMOUNT_TO = L_BASIS_AMOUNT_TO;
  
    L_COMMISSION_AMOUNT_CALC NUMBER := 0;
    L_CALC_PERIOD            NUMBER := 0;
    L_MAX_BASIS_AMOUNT_TO    CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE;
    L_MIN_BASIS_AMOUNT_TO    CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE;
    L_ICCF_BRACKET           CFTMS_BRACKET%ROWTYPE;
    L_CHARGE_GROUP           CFTMS_RULE.CUSTOMER_GROUP%TYPE;
  
  BEGIN
    P_TIER_RATE := NULL;
  
    BEGIN
      SELECT NVL(CHARGE_GROUP, 'ALL')
        INTO L_CHARGE_GROUP
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = P_ICCF_RULE.CUSTOMER
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_CHARGE_GROUP := 'ALL';
    END;
  
    BEGIN
      SELECT *
        INTO L_ICCF_BRACKET
        FROM CFTMS_BRACKET
       WHERE RULE = P_ICCF_RULE.RULE
         AND CURRENCY = P_ICCF_RULE.CURRENCY
         AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
         AND CUSTOMER = P_ICCF_RULE.CUSTOMER
         AND CUSTOMER_GROUP = L_CHARGE_GROUP
         AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
         AND P_ORIGINAL_TAG_AMOUNT + P_AMOUNT <= BASIS_AMOUNT_TO
         AND P_ORIGINAL_TAG_AMOUNT + P_AMOUNT >= BASIS_AMOUNT_FROM;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        SELECT MAX(BASIS_AMOUNT_TO), MIN(BASIS_AMOUNT_TO)
          INTO L_MAX_BASIS_AMOUNT_TO, L_MIN_BASIS_AMOUNT_TO
          FROM CFTMS_BRACKET
         WHERE RULE = P_ICCF_RULE.RULE
           AND CURRENCY = P_ICCF_RULE.CURRENCY
           AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
           AND CUSTOMER = P_ICCF_RULE.CUSTOMER
           AND CUSTOMER_GROUP = L_CHARGE_GROUP
           AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE;
        IF P_ORIGINAL_TAG_AMOUNT + P_AMOUNT > L_MAX_BASIS_AMOUNT_TO THEN
          SELECT *
            INTO L_ICCF_BRACKET
            FROM CFTMS_BRACKET
           WHERE RULE = P_ICCF_RULE.RULE
             AND CURRENCY = P_ICCF_RULE.CURRENCY
             AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
             AND CUSTOMER = P_ICCF_RULE.CUSTOMER
             AND CUSTOMER_GROUP = L_CHARGE_GROUP
             AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
             AND BASIS_AMOUNT_TO = L_MAX_BASIS_AMOUNT_TO;
        ELSE
          SELECT *
            INTO L_ICCF_BRACKET
            FROM CFTMS_BRACKET
           WHERE RULE = P_ICCF_RULE.RULE
             AND CURRENCY = P_ICCF_RULE.CURRENCY
             AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
             AND CUSTOMER = P_ICCF_RULE.CUSTOMER
             AND CUSTOMER_GROUP = L_CHARGE_GROUP
             AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
             AND BASIS_AMOUNT_TO = L_MIN_BASIS_AMOUNT_TO;
        END IF;
    END;
  
    FOR EACH_TIER IN C_TENOR_BRACKET(P_BASIS_AMOUNT_TO, L_CHARGE_GROUP) LOOP
    
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>retrospective is not set. So I am here');
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>EachTier.Tenor_From : ' ||
                     EACH_TIER.TENOR_FROM);
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>l_tenor                : ' ||
                     P_TENOR);
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>l_good_until_tenor  : ' ||
                     P_GOOD_UNTIL_TENOR);
      DEBUG.PR_DEBUG('CF',
                     'fn_tenor_based_comm_calc..>l_tenor + l_good_until_tenor  : ' ||
                     (P_GOOD_UNTIL_TENOR + P_TENOR));
    
      IF EACH_TIER.TENOR_FROM > (P_TENOR + P_GOOD_UNTIL_TENOR) THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 1 Reached');
        L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC + 0;
      
      ELSIF P_GOOD_UNTIL_TENOR < EACH_TIER.TENOR_TO THEN
        L_CALC_PERIOD := LEAST(EACH_TIER.TENOR_TO,
                               P_TENOR + P_GOOD_UNTIL_TENOR) -
                         GREATEST(P_GOOD_UNTIL_TENOR,
                                  EACH_TIER.TENOR_FROM - 1);
      
        IF P_ICCF_RULE.ROUNDING_PERIOD != 0 THEN
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD /
                                      (100 * P_ICCF_RULE.RATE_PERIOD));
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD * 30 /
                                      (100 * P_TOTAL_DAYS));
        END IF;
        P_TIER_RATE := EACH_TIER.RATE;
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor From is ' ||
                       TO_CHAR(EACH_TIER.TENOR_FROM));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor To is ' ||
                       TO_CHAR(EACH_TIER.TENOR_TO));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Rate used is ' ||
                       TO_CHAR(EACH_TIER.RATE));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Commission till now >> ' ||
                       TO_CHAR(L_COMMISSION_AMOUNT_CALC));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Period of CALC - ' ||
                       L_CALC_PERIOD);
      
      ELSIF EACH_TIER.TENOR_FROM >= P_GOOD_UNTIL_TENOR AND
            (P_GOOD_UNTIL_TENOR + P_TENOR) <= EACH_TIER.TENOR_TO THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 3 Reached');
      
        L_CALC_PERIOD := P_GOOD_UNTIL_TENOR + P_TENOR -
                         EACH_TIER.TENOR_FROM + 1;
        IF P_GOOD_UNTIL_TENOR = EACH_TIER.TENOR_FROM THEN
          L_CALC_PERIOD := L_CALC_PERIOD - 1;
        END IF;
        IF P_ICCF_RULE.ROUNDING_PERIOD != 0 THEN
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD /
                                      (100 * P_ICCF_RULE.RATE_PERIOD));
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD * 30 /
                                      (100 * P_TOTAL_DAYS));
        END IF;
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor From is ' ||
                       TO_CHAR(EACH_TIER.TENOR_FROM));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor To is ' ||
                       TO_CHAR(EACH_TIER.TENOR_TO));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Rate used is ' ||
                       TO_CHAR(EACH_TIER.RATE));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Commission till now >> ' ||
                       TO_CHAR(L_COMMISSION_AMOUNT_CALC));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Period of CALC - ' ||
                       L_CALC_PERIOD);
      
      ELSIF (EACH_TIER.TENOR_FROM >= (P_GOOD_UNTIL_TENOR + 1) AND
            EACH_TIER.TENOR_TO <= (P_GOOD_UNTIL_TENOR + P_TENOR)) THEN
      
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 4 Reached');
        L_CALC_PERIOD := (EACH_TIER.TENOR_TO - EACH_TIER.TENOR_FROM + 1);
      
        IF P_ICCF_RULE.ROUNDING_PERIOD != 0 THEN
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD /
                                      (100 * P_ICCF_RULE.RATE_PERIOD));
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (P_AMOUNT * EACH_TIER.RATE *
                                      L_CALC_PERIOD * 30 /
                                      (100 * P_TOTAL_DAYS));
        END IF;
        P_TIER_RATE := EACH_TIER.RATE;
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor From is ' ||
                       TO_CHAR(EACH_TIER.TENOR_FROM));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Tenor To is ' ||
                       TO_CHAR(EACH_TIER.TENOR_TO));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Rate used is ' ||
                       TO_CHAR(EACH_TIER.RATE));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Commission till now >> ' ||
                       TO_CHAR(L_COMMISSION_AMOUNT_CALC));
        DEBUG.PR_DEBUG('CF',
                       'fn_tenor_based_comm_calc..>Period of CALC - ' ||
                       L_CALC_PERIOD);
      END IF;
    END LOOP;
  
    P_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC;
    DEBUG.PR_DEBUG('CF',
                   'fn_tenor_based_comm_calc..>Exiting function fn_tenor_based_comm_calc');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CF',
                     'In when others fn_tenor_based_comm_calc ' || SQLCODE ||
                     SQLERRM);
      DEBUG.PR_DEBUG('CF',
                     'In when others fn_tenor_based_comm_calc ' || SQLCODE ||
                     SQLERRM);
      P_ERR_CODE := 'CF-001';
      RETURN FALSE;
  END FN_TIER_AMT_TENOR_COMM;

  FUNCTION FN_TIER_AMT_TIER_TENOR(P_TENOR                  IN NUMBER,
                                  P_GOOD_UNTIL_TENOR       IN NUMBER,
                                  P_TENOR_IN_DAYS          IN NUMBER,
                                  P_TOTAL_DAYS             IN NUMBER,
                                  P_ICCF_RULE              IN CFTMS_RULE%ROWTYPE,
                                  P_AMOUNT                 IN CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE,
                                  P_COMMISSION_AMOUNT_CALC OUT NUMBER,
                                  P_TIER_RATE              OUT CFTMS_BRACKET_TENOR.RATE%TYPE,
                                  P_ERR_CODE               IN OUT ERTB_MSGS.ERR_CODE%TYPE,
                                  P_ORIGINAL_TAG_AMOUNT    IN NUMBER)
    RETURN BOOLEAN IS
  
    CURSOR C_AMOUNT_BRACKET(L_BASIS_AMOUNT_TO CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE,
                            
                            L_CUSTOMER_GROUP CFTMS_BRACKET.CUSTOMER_GROUP%TYPE) IS
    
      SELECT *
        FROM CFTMS_BRACKET
       WHERE RULE = P_ICCF_RULE.RULE
         AND CURRENCY = P_ICCF_RULE.CURRENCY
         AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
         AND CUSTOMER = P_ICCF_RULE.CUSTOMER
         AND CUSTOMER_GROUP = L_CUSTOMER_GROUP
         AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
         AND BASIS_AMOUNT_TO <= L_BASIS_AMOUNT_TO;
  
    L_COMMISSION_AMOUNT_CALC NUMBER := 0;
    L_TEMP                   NUMBER := 0;
    L_CALC_PERIOD            NUMBER := 0;
    L_MAX_BASIS_AMOUNT_TO    CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE;
    L_MIN_BASIS_AMOUNT_TO    CFTMS_BRACKET.BASIS_AMOUNT_TO%TYPE;
    L_ICCF_BRACKET           CFTMS_BRACKET%ROWTYPE;
    L_CALC_AMOUNT            NUMBER(22, 3);
    L_CHARGE_GROUP           STTMS_CUSTOMER.CHARGE_GROUP%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT NVL(CHARGE_GROUP, 'ALL')
        INTO L_CHARGE_GROUP
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = P_ICCF_RULE.CUSTOMER
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_CHARGE_GROUP := 'ALL';
    END;
  
    BEGIN
      SELECT *
        INTO L_ICCF_BRACKET
        FROM CFTMS_BRACKET
       WHERE RULE = P_ICCF_RULE.RULE
         AND CURRENCY = P_ICCF_RULE.CURRENCY
         AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
         AND CUSTOMER = P_ICCF_RULE.CUSTOMER
         AND CUSTOMER_GROUP = L_CHARGE_GROUP
         AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
         AND P_ORIGINAL_TAG_AMOUNT + P_AMOUNT <= BASIS_AMOUNT_TO
         AND P_ORIGINAL_TAG_AMOUNT + P_AMOUNT >= BASIS_AMOUNT_FROM;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('CF', 'Into exception of select from cftms_bracket');
        DEBUG.PR_DEBUG('CF', 'Into exception of select from cftms_bracket');
        SELECT MAX(BASIS_AMOUNT_TO), MIN(BASIS_AMOUNT_TO)
          INTO L_MAX_BASIS_AMOUNT_TO, L_MIN_BASIS_AMOUNT_TO
          FROM CFTMS_BRACKET
         WHERE RULE = P_ICCF_RULE.RULE
           AND CURRENCY = P_ICCF_RULE.CURRENCY
           AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
           AND CUSTOMER = P_ICCF_RULE.CUSTOMER
           AND CUSTOMER_GROUP = L_CHARGE_GROUP
           AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE;
        IF P_ORIGINAL_TAG_AMOUNT + P_AMOUNT > L_MAX_BASIS_AMOUNT_TO THEN
          SELECT *
            INTO L_ICCF_BRACKET
            FROM CFTMS_BRACKET
           WHERE RULE = P_ICCF_RULE.RULE
             AND CURRENCY = P_ICCF_RULE.CURRENCY
             AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
             AND CUSTOMER = P_ICCF_RULE.CUSTOMER
             AND CUSTOMER_GROUP = L_CHARGE_GROUP
             AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
             AND BASIS_AMOUNT_TO = L_MAX_BASIS_AMOUNT_TO;
        ELSE
          SELECT *
            INTO L_ICCF_BRACKET
            FROM CFTMS_BRACKET
           WHERE RULE = P_ICCF_RULE.RULE
             AND CURRENCY = P_ICCF_RULE.CURRENCY
             AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
             AND CUSTOMER = P_ICCF_RULE.CUSTOMER
             AND CUSTOMER_GROUP = L_CHARGE_GROUP
             AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
             AND BASIS_AMOUNT_TO = L_MIN_BASIS_AMOUNT_TO;
        END IF;
    END;
  
    DEBUG.PR_DEBUG('CF',
                   'l_iccf_bracket.basis_amount_to ' ||
                   L_ICCF_BRACKET.BASIS_AMOUNT_TO);
    DEBUG.PR_DEBUG('CF',
                   'l_iccf_bracket.basis_amount_to ' ||
                   L_ICCF_BRACKET.BASIS_AMOUNT_TO);
  
    FOR EACH_TIER IN C_AMOUNT_BRACKET(L_ICCF_BRACKET.BASIS_AMOUNT_TO,
                                      L_CHARGE_GROUP) LOOP
    
      IF EACH_TIER.BASIS_AMOUNT_FROM > P_AMOUNT + P_ORIGINAL_TAG_AMOUNT THEN
        DEBUG.PR_DEBUG('CF',
                       'fn_tiered_amount_tier_tenor> Case 1 Reached-the lc amount < basis-from. Commission amount calc is 0');
      
        L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC + 0;
      
      ELSIF P_ORIGINAL_TAG_AMOUNT < EACH_TIER.BASIS_AMOUNT_TO THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 2 Reached');
        L_CALC_AMOUNT := LEAST(EACH_TIER.BASIS_AMOUNT_TO,
                               P_AMOUNT + P_ORIGINAL_TAG_AMOUNT) -
                         GREATEST(P_ORIGINAL_TAG_AMOUNT,
                                  EACH_TIER.BASIS_AMOUNT_FROM - 1);
        DEBUG.PR_DEBUG('CF', 'calc amount passed ' || L_CALC_AMOUNT);
        DEBUG.PR_DEBUG('CF', 'calc amount passed ' || L_CALC_AMOUNT);
        DEBUG.PR_DEBUG('CF', 'p tenor amount' || P_TENOR);
        DEBUG.PR_DEBUG('CF',
                       'p orginal tag amount ' || P_ORIGINAL_TAG_AMOUNT);
        DEBUG.PR_DEBUG('CF', 'p_tier_rate ' || P_TIER_RATE);
        DEBUG.PR_DEBUG('CF', 'l_temp ' || L_TEMP);
        DEBUG.PR_DEBUG('CF', 'p_tier_rate ' || P_TIER_RATE);
      
        IF NOT FN_TIER_AMT_TENOR_COMM(P_TENOR,
                                      P_GOOD_UNTIL_TENOR,
                                      P_TENOR_IN_DAYS,
                                      P_TOTAL_DAYS,
                                      P_ICCF_RULE,
                                      L_CALC_AMOUNT,
                                      L_TEMP,
                                      P_TIER_RATE,
                                      P_ERR_CODE,
                                      P_ORIGINAL_TAG_AMOUNT,
                                      EACH_TIER.BASIS_AMOUNT_TO) THEN
          RETURN FALSE;
        END IF;
      
        L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC + L_TEMP;
      
      ELSIF EACH_TIER.BASIS_AMOUNT_FROM >= P_ORIGINAL_TAG_AMOUNT AND
            (P_ORIGINAL_TAG_AMOUNT + P_AMOUNT) <= EACH_TIER.BASIS_AMOUNT_TO THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 3 Reached');
      
        L_CALC_AMOUNT := P_ORIGINAL_TAG_AMOUNT + P_AMOUNT -
                         EACH_TIER.BASIS_AMOUNT_FROM + 1;
        IF P_ORIGINAL_TAG_AMOUNT = EACH_TIER.BASIS_AMOUNT_FROM THEN
          L_CALC_AMOUNT := L_CALC_AMOUNT - 1;
        END IF;
      
        IF NOT FN_TIER_AMT_TENOR_COMM(P_TENOR,
                                      P_GOOD_UNTIL_TENOR,
                                      P_TENOR_IN_DAYS,
                                      P_TOTAL_DAYS,
                                      P_ICCF_RULE,
                                      L_CALC_AMOUNT,
                                      L_TEMP,
                                      P_TIER_RATE,
                                      P_ERR_CODE,
                                      P_ORIGINAL_TAG_AMOUNT,
                                      EACH_TIER.BASIS_AMOUNT_TO) THEN
          RETURN FALSE;
        END IF;
      
        L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC + L_TEMP;
      
      ELSIF (EACH_TIER.BASIS_AMOUNT_FROM >= (P_ORIGINAL_TAG_AMOUNT + 1) AND
            EACH_TIER.BASIS_AMOUNT_TO <=
            (P_ORIGINAL_TAG_AMOUNT + P_AMOUNT)) THEN
      
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 4 Reached');
        L_CALC_AMOUNT := (EACH_TIER.BASIS_AMOUNT_TO -
                         EACH_TIER.BASIS_AMOUNT_FROM + 1);
        IF NOT FN_TIER_AMT_TENOR_COMM(P_TENOR,
                                      P_GOOD_UNTIL_TENOR,
                                      P_TENOR_IN_DAYS,
                                      P_TOTAL_DAYS,
                                      P_ICCF_RULE,
                                      L_CALC_AMOUNT,
                                      L_TEMP,
                                      P_TIER_RATE,
                                      P_ERR_CODE,
                                      P_ORIGINAL_TAG_AMOUNT,
                                      EACH_TIER.BASIS_AMOUNT_TO) THEN
          RETURN FALSE;
        END IF;
      
        L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC + L_TEMP;
      
      END IF;
    
      DEBUG.PR_DEBUG('CF',
                     'fn_tiered_amount_tier_tenor>Loop - Amount From ' ||
                     EACH_TIER.BASIS_AMOUNT_FROM || ' Amount To ' ||
                     EACH_TIER.BASIS_AMOUNT_TO);
      DEBUG.PR_DEBUG('CF',
                     'fn_tiered_amount_tier_tenor>Rate used is ' ||
                     EACH_TIER.RATE);
      DEBUG.PR_DEBUG('CF',
                     'fn_tiered_amount_tier_tenor>Amount passed is ' ||
                     P_AMOUNT);
      DEBUG.PR_DEBUG('CF',
                     'fn_tiered_amount_tier_tenor>Rate period is ' ||
                     P_ICCF_RULE.RATE_PERIOD);
      DEBUG.PR_DEBUG('CF',
                     'fn_tiered_amount_tier_tenor>Commission till now >> ' ||
                     L_COMMISSION_AMOUNT_CALC);
    
    END LOOP;
  
    P_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC;
    DEBUG.PR_DEBUG('CF',
                   'fn_tiered_amount_tier_tenor>Exiting function fn_tiered_amount_based_comm_calc');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'CF-002';
      RETURN FALSE;
  END FN_TIER_AMT_TIER_TENOR;

  FUNCTION FN_TIER_AMT_FLAT_TENOR(P_AMOUNT                 IN CFTBS_CONTRACT_COMMISSION.AMOUNT%TYPE,
                                  P_ICCF_RULE              IN CFTMS_RULE%ROWTYPE,
                                  P_RATE                   OUT CFTBS_CONTRACT_COMMISSION.RATE%TYPE,
                                  P_NUMBER_OF_PERIODS      IN NUMBER,
                                  P_ROUNDING_PERIOD        IN CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD%TYPE,
                                  P_RATE_PERIOD            IN CFTBS_CONTRACT_COMMISSION.RATE_PERIOD%TYPE,
                                  P_TENOR                  IN NUMBER,
                                  P_TENOR_IN_DAYS          IN NUMBER,
                                  P_TOTAL_DAYS             IN NUMBER,
                                  P_ERR_CODE               IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                  P_COMMISSION_AMOUNT_CALC OUT NUMBER,
                                  P_ORIGINAL_TAG_AMOUNT    IN NUMBER)
    RETURN BOOLEAN IS
  
    CURSOR C_AMOUNT_BRACKET IS
      SELECT *
        FROM CFTMS_BRACKET
       WHERE RULE = P_ICCF_RULE.RULE
         AND CURRENCY = P_ICCF_RULE.CURRENCY
         AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
         AND CUSTOMER = P_ICCF_RULE.CUSTOMER
         AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
         AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
         AND BASIS_AMOUNT_TO <=
             (SELECT MIN(BASIS_AMOUNT_TO)
                FROM CFTMS_BRACKET
               WHERE RULE = P_ICCF_RULE.RULE
                 AND CURRENCY = P_ICCF_RULE.CURRENCY
                 AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
                 AND CUSTOMER = P_ICCF_RULE.CUSTOMER
                 AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
                 AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
                 AND BASIS_AMOUNT_TO >= P_AMOUNT + P_ORIGINAL_TAG_AMOUNT);
  
    L_COMMISSION_AMOUNT_CALC NUMBER := 0;
    L_TEMP                   NUMBER := 0;
    L_RATE                   CFTMS_BRACKET_TENOR.RATE%TYPE := 0;
    L_CALC_AMOUNT            NUMBER(22, 3);
  
  BEGIN
    DEBUG.PR_DEBUG('CF',
                   'fn_tier_amt_flat_tenor>Entered function fn_tier_amt_flat_tenor. amount passed is ' ||
                   P_AMOUNT);
    DEBUG.PR_DEBUG('CF',
                   'fn_tier_amt_flat_tenor>Entered function fn_tier_amt_flat_tenor. ORIGINAL amount passed is ' ||
                   P_ORIGINAL_TAG_AMOUNT);
    DEBUG.PR_DEBUG('CF',
                   'fn_tier_amt_flat_tenor>customer is ' ||
                   P_ICCF_RULE.CUSTOMER);
    DEBUG.PR_DEBUG('CF',
                   'fn_tier_amt_flat_tenor>currency is ' ||
                   P_ICCF_RULE.CURRENCY);
    DEBUG.PR_DEBUG('CF', 'fn_tier_amt_flat_tenor>tenor is ' || P_TENOR);
  
    FOR EACH_TIER IN C_AMOUNT_BRACKET LOOP
    
      BEGIN
        DEBUG.PR_DEBUG('CF',
                       'fn_tier_amt_flat_tenor>now selecting the bracket tenor ' ||
                       P_ICCF_RULE.CURRENCY);
        SELECT RATE
          INTO L_RATE
          FROM CFTMS_BRACKET_TENOR
         WHERE RULE = P_ICCF_RULE.RULE
           AND CURRENCY = P_ICCF_RULE.CURRENCY
           AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
           AND CUSTOMER = P_ICCF_RULE.CUSTOMER
           AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
           AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
           AND BASIS_AMOUNT_TO = EACH_TIER.BASIS_AMOUNT_TO
           AND TENOR_TO =
               (SELECT MIN(TENOR_TO)
                  FROM CFTMS_BRACKET_TENOR
                 WHERE RULE = P_ICCF_RULE.RULE
                   AND CURRENCY = P_ICCF_RULE.CURRENCY
                   AND CURRENCY2 = P_ICCF_RULE.CURRENCY2
                   AND CUSTOMER = P_ICCF_RULE.CUSTOMER
                   AND CUSTOMER_GROUP = P_ICCF_RULE.CUSTOMER_GROUP
                   AND BRANCH_CODE = P_ICCF_RULE.BRANCH_CODE
                   AND BASIS_AMOUNT_TO = EACH_TIER.BASIS_AMOUNT_TO
                   AND TENOR_TO >= P_TENOR);
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('LC',
                         'fn_tier_amt_flat_tenor>Error in getting CFTMS_BRACKET_TENOR ' ||
                         SQLERRM);
          RETURN FALSE;
      END;
    
      DEBUG.PR_DEBUG('CF',
                     'fn_tier_amt_flat_tenor>rate selected is ' || L_RATE);
    
      IF EACH_TIER.BASIS_AMOUNT_FROM > (P_AMOUNT + P_ORIGINAL_TAG_AMOUNT) THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 1 Reached');
        L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC + 0;
      
      ELSIF P_ORIGINAL_TAG_AMOUNT < EACH_TIER.BASIS_AMOUNT_TO THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 2 Reached');
      
        L_CALC_AMOUNT := LEAST(EACH_TIER.BASIS_AMOUNT_TO,
                               P_AMOUNT + P_ORIGINAL_TAG_AMOUNT) -
                         GREATEST(P_ORIGINAL_TAG_AMOUNT,
                                  EACH_TIER.BASIS_AMOUNT_FROM - 1);
      
        IF P_ROUNDING_PERIOD != 0 THEN
        
          DEBUG.PR_DEBUG('CF', 'i am heer for rounding rule');
          DEBUG.PR_DEBUG('CF',
                         'p_number_of_periods-->' || P_NUMBER_OF_PERIODS);
          DEBUG.PR_DEBUG('CF', 'l_rate-->' || L_RATE);
          DEBUG.PR_DEBUG('CF', 'p_rounding_period-->' || P_ROUNDING_PERIOD);
          DEBUG.PR_DEBUG('CF', 'p_rate_period-->' || P_RATE_PERIOD);
        
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      ((L_CALC_AMOUNT * NVL(L_RATE, 0) *
                                      P_NUMBER_OF_PERIODS) *
                                      P_ROUNDING_PERIOD / P_RATE_PERIOD) / 100;
        
          DEBUG.PR_DEBUG('CF',
                         'l_commission_amount_calc-->' ||
                         L_COMMISSION_AMOUNT_CALC);
        
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (L_CALC_AMOUNT * L_RATE *
                                      P_TENOR_IN_DAYS /
                                      (100 * P_TOTAL_DAYS));
        END IF;
        P_RATE := L_RATE;
      
      ELSIF EACH_TIER.BASIS_AMOUNT_FROM >= P_ORIGINAL_TAG_AMOUNT AND
            (P_ORIGINAL_TAG_AMOUNT + P_AMOUNT) <= EACH_TIER.BASIS_AMOUNT_TO THEN
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 3 Reached');
      
        L_CALC_AMOUNT := P_ORIGINAL_TAG_AMOUNT + P_AMOUNT -
                         EACH_TIER.BASIS_AMOUNT_FROM + 1;
      
        IF P_ORIGINAL_TAG_AMOUNT = EACH_TIER.BASIS_AMOUNT_FROM THEN
          L_CALC_AMOUNT := L_CALC_AMOUNT - 1;
        END IF;
      
        IF P_ROUNDING_PERIOD != 0 THEN
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (L_CALC_AMOUNT * L_RATE * P_TENOR /
                                      (100 * P_ICCF_RULE.RATE_PERIOD));
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (L_CALC_AMOUNT * L_RATE *
                                      P_TENOR_IN_DAYS /
                                      (100 * P_TOTAL_DAYS));
        END IF;
        P_RATE := L_RATE;
      
      ELSIF (EACH_TIER.BASIS_AMOUNT_FROM >= (P_ORIGINAL_TAG_AMOUNT + 1) AND
            EACH_TIER.BASIS_AMOUNT_TO <=
            (P_ORIGINAL_TAG_AMOUNT + P_AMOUNT)) THEN
      
        DEBUG.PR_DEBUG('CF', 'fn_tenor_based_comm_calc..>Case 4 Reached');
        L_CALC_AMOUNT := (EACH_TIER.BASIS_AMOUNT_TO -
                         EACH_TIER.BASIS_AMOUNT_FROM + 1);
        IF P_ROUNDING_PERIOD != 0 THEN
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (L_CALC_AMOUNT * L_RATE * P_TENOR /
                                      (100 * P_ICCF_RULE.RATE_PERIOD));
        ELSE
          L_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC +
                                      (L_CALC_AMOUNT * L_RATE *
                                      P_TENOR_IN_DAYS /
                                      (100 * P_TOTAL_DAYS));
        END IF;
        P_RATE := L_RATE;
      END IF;
      DEBUG.PR_DEBUG('CF',
                     'fn_tier_amt_flat_tenor>Loop - Amount From ' ||
                     EACH_TIER.BASIS_AMOUNT_FROM || ' Amount To ' ||
                     EACH_TIER.BASIS_AMOUNT_TO);
      DEBUG.PR_DEBUG('CF',
                     'fn_tier_amt_flat_tenor>Rate used is ' || L_RATE);
      DEBUG.PR_DEBUG('CF',
                     'fn_tier_amt_flat_tenor>Amount passed is ' || P_AMOUNT);
      DEBUG.PR_DEBUG('CF',
                     'fn_tier_amt_flat_tenor>Rate period is ' ||
                     P_ICCF_RULE.RATE_PERIOD);
      DEBUG.PR_DEBUG('CF',
                     'fn_tier_amt_flat_tenor>Commission till now >> ' ||
                     L_COMMISSION_AMOUNT_CALC);
    
    END LOOP;
  
    P_COMMISSION_AMOUNT_CALC := L_COMMISSION_AMOUNT_CALC;
    P_RATE                   := L_RATE;
    DEBUG.PR_DEBUG('CF',
                   'fn_tier_amt_flat_tenor>Exiting function fn_tiered_amount_based_comm_calc');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_CODE := 'CF-002';
      RETURN FALSE;
  END FN_TIER_AMT_FLAT_TENOR;

  FUNCTION FN_GET_GUD_REC(P_COMMISSION_REC            IN OUT TY_FOR_COMMISSION,
                          J                           IN INTEGER,
                          P_ICCF_RULE                 IN CFTMS_RULE%ROWTYPE,
                          P_CFTBS_CONTRACT_COMMISSION IN CFTBS_CONTRACT_COMMISSION%ROWTYPE,
                          P_TY_COMMISSION_GUD         IN OUT TY_COMMISSION_GOOD)
    RETURN BOOLEAN IS
  
    I                            INTEGER := 1;
    L_ROUNDING_PERIOD            CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD%TYPE;
    L_CON_CCY                    CFTMS_RULE.BASIS_AMOUNT_CCY%TYPE;
    L_COMMISSION_CHARGE_CURRENCY CFTMS_RULE.BASIS_AMOUNT_CCY%TYPE;
    L_CURRENCY                   CFTMS_RULE.BASIS_AMOUNT_CCY%TYPE;
    L_END_DATE                   DATE;
  BEGIN
    DEBUG.PR_DEBUG('CF', 'Inside fn_get_gud_rec....... ');
    IF NVL(P_COMMISSION_REC(J).P_FOLLOW_RULE, 'N') = 'Y' THEN
      P_COMMISSION_REC(J).P_FOLLOW_RULE := 'Y';
    ELSE
      IF NVL(P_ICCF_RULE.CUMULATIVE, 'N') = 'N' THEN
        P_COMMISSION_REC(J).P_FOLLOW_RULE := 'N';
      ELSE
        P_COMMISSION_REC(J).P_FOLLOW_RULE := 'R';
      END IF;
    END IF;
  
    IF P_COMMISSION_REC(J).P_FOLLOW_RULE = 'Y' THEN
      L_ROUNDING_PERIOD := P_ICCF_RULE.ROUNDING_PERIOD;
    ELSIF P_COMMISSION_REC(J).P_FOLLOW_RULE = 'R' THEN
      L_ROUNDING_PERIOD := NVL(P_CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD,
                               P_ICCF_RULE.ROUNDING_PERIOD);
    ELSE
      L_ROUNDING_PERIOD := P_CFTBS_CONTRACT_COMMISSION.ROUNDING_PERIOD;
    END IF;
    DEBUG.PR_DEBUG('CF',
                   'fn_get_gud_rec  l_rounding_period ' ||
                   L_ROUNDING_PERIOD);
    L_END_DATE := P_COMMISSION_REC(J).P_END_DATE;
    IF P_CFTBS_CONTRACT_COMMISSION.STOP_DATE IS NOT NULL THEN
      IF P_COMMISSION_REC(J)
       .P_END_DATE > P_CFTBS_CONTRACT_COMMISSION.STOP_DATE THEN
        L_END_DATE := P_CFTBS_CONTRACT_COMMISSION.STOP_DATE;
      END IF;
    END IF;
    DEBUG.PR_DEBUG('CF', 'fn_get_gud_rec  l_end_date ' || L_END_DATE);
    L_CON_CCY := P_COMMISSION_REC(J).P_COMMISSION_CURRENCY;
    IF NVL(P_ICCF_RULE.FLAT_AMOUNT_CURRENCY, 'ALL') = 'ALL' THEN
      L_COMMISSION_CHARGE_CURRENCY := L_CON_CCY;
    ELSE
      L_COMMISSION_CHARGE_CURRENCY := P_ICCF_RULE.FLAT_AMOUNT_CURRENCY;
    END IF;
    L_CURRENCY := L_COMMISSION_CHARGE_CURRENCY;
    DEBUG.PR_DEBUG('CF', 'fn_get_gud_rec  l_currency ' || L_CURRENCY);
    P_TY_COMMISSION_GUD(I).P_CONTRACT_REFERENCE_NO := P_COMMISSION_REC(J)
                                                      .P_CONTRACT_REFERENCE_NO;
    P_TY_COMMISSION_GUD(I).P_COMPONENT := P_COMMISSION_REC(J).P_COMPONENT;
    P_TY_COMMISSION_GUD(I).P_START_DATE := P_COMMISSION_REC(J).P_START_DATE;
    P_TY_COMMISSION_GUD(I).P_ROUNDING_PERIOD := L_ROUNDING_PERIOD;
    P_TY_COMMISSION_GUD(I).P_CUSTOMER := P_COMMISSION_REC(J).P_CUSTOMER;
    P_TY_COMMISSION_GUD(I).P_CURRENCY := L_CURRENCY;
    P_TY_COMMISSION_GUD(I).P_END_DATE := L_END_DATE;
    DEBUG.PR_DEBUG('CF', 'fn_get_gud_rec   RETURN TRUE ');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CF', 'fn_get_gud_rec WOT' || SQLERRM);
      RETURN FALSE;
  END FN_GET_GUD_REC;

END CFPKS_COMPUTATION;
/