update sttm_branch set swift_addr = 'PINCKHPP' where swift_addr is null 
/
COMMIT
/