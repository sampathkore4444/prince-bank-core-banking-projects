insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'ACON', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'AMNV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'AOCF', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'APRE', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'AREJ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'AVAL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'BISS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'BKSG', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'BPRE', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'CALC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'CANC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'CASG', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'CLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'CLOA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'EXPA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'RAVL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'RLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'ROPN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'RVSG', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'TRGN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILSR', 'WAIV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'ACON', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'AMNV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'AOCF', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'APRE', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'AREJ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'AVAL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'BISS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'BKSG', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'BPRE', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'CALC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'CANC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'CASG', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'CLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'CLOA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'EXPA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'RAVL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'RLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'ROPN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'RVSG', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'TRGN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ILUR', 'WAIV', null);

COMMIT;
