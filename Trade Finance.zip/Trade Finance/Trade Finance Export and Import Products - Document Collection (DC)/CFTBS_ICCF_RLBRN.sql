insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('DCECOLINIT', 'Documentary Collection Export Collection Fee During INIT Event', 'D', 'SAMPATH2', to_date('14-01-2020 19:27:25', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:27:25', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('DCECORINIT', 'Documentary Collection Export Courier Fee During INIT Event', 'D', 'SAMPATH2', to_date('14-01-2020 19:28:11', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:28:11', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('DCICOLINIT', 'Documentary Collection Import Collection Fee During INIT Event', 'D', 'SAMPATH2', to_date('14-01-2020 19:12:45', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:12:45', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 2, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('DCICOSINIT', 'Documentary Collection Import Collection Settlement Fee During INIT Event', 'D', 'SAMPATH2', to_date('14-01-2020 19:17:02', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:17:02', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 1, 'N', 'N');

COMMIT;