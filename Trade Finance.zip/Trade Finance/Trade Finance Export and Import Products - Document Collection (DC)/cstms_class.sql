insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCICOLINIT', 'BC Opening Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 19:20:11', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:20:11', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCICOSINIT', 'BC Opening Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 19:20:21', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:20:21', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCECOLINIT', 'BC Opening Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 19:30:55', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:30:55', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCECORINIT', 'BC Opening Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 19:31:05', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:31:05', 'dd-mm-yyyy hh24:mi:ss'), 1);

COMMIT;
