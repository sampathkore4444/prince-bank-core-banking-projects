prompt Importing table TATM_PRODUCT_SCHEME...
set feedback off
set define off
insert into TATM_PRODUCT_SCHEME (PRODUCT_OR_MARKET_CODE, SCHEME, MODULE, SCHEME_ONCE_AUTH)
values ('STLC', null, 'LC', null);

prompt Done.
