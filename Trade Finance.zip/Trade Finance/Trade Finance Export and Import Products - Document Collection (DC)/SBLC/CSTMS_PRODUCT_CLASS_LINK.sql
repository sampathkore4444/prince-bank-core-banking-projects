prompt Importing table CSTMS_PRODUCT_CLASS_LINK...
set feedback off
set define off
insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('STLC', 'AC', 'LCIEV');

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('STLC', 'CB', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('STLC', 'CR', null);

insert into CSTMS_PRODUCT_CLASS_LINK (PRODUCT, CLASS_TYPE, CLASS_CODE)
values ('STLC', 'RH', 'LCIR2H');

prompt Done.
