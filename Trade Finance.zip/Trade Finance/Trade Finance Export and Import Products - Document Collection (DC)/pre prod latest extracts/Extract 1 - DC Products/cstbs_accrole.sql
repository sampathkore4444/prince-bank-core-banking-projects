insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCORCG_REC', 'BC Correspondent Charge', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCORCG_INC', 'BC Correspondent Charge', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCORCG_IFBR', 'BC Correspondent Charge', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BCCORCG_RIA', 'BC Correspondent Charge', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLINIT_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLINIT_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLINIT_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLINIT_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECOLINIT_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECOLINIT_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECOLINIT_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECOLINIT_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECORINIT_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECORINIT_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECORINIT_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECORINIT_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOSLIQD_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOSLIQD_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOSLIQD_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOSLIQD_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLLIQD_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLLIQD_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLLIQD_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLLIQD_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

COMMIT;