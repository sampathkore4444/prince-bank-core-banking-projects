insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'BCCORCG', 'BC Correspondent Charge', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('22-03-2021 15:26:53', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('22-03-2021 15:26:53', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCECOLINIT', 'Collection Fee', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 19:30:55', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:30:55', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCECORINIT', 'Courier Fee', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 19:31:05', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:31:05', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCICOLLIQD', 'BC Opening Charges', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('22-03-2021 14:50:37', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('22-03-2021 14:50:37', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCICOSLIQD', 'Collection Settlement Fee', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('22-03-2021 09:59:05', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('22-03-2021 09:59:05', 'dd-mm-yyyy hh24:mi:ss'), 1);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('BC', 'DCICOLINIT', 'Collection Fee', 'CH', null, null, null, 'O', 'A', 'Y', 'SAMPATH2', to_date('14-01-2020 19:20:11', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 19:20:11', 'dd-mm-yyyy hh24:mi:ss'), 1);

COMMIT;