insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVAMND_INC', 'LC Export Advicing charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVAMND_IFBR', 'LC Export Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVAMND_RIA', 'LC Export Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCOTHAMND_INC', 'STLC - All other guarantee amendment', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCOTHAMND_IFBR', 'STLC - All other guarantee amendment', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCOTHAMND_RIA', 'STLC - All other guarantee amendment', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVCHG_INC', 'LC Export Advicing charges', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVCHG_IFBR', 'LC Export Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCADVCHG_RIA', 'LC Export Advicing charges', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCANFEE_INC', 'STLC - Guarantee cancellation Fee', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCANFEE_IFBR', 'STLC - Guarantee cancellation Fee', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCCANFEE_RIA', 'STLC - Guarantee cancellation Fee', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEINC', 'STLC - Guarantee Issuance Fee', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEEXP', 'STLC - Guarantee Issuance Fee', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEPAY', 'STLC - Guarantee Issuance Fee', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEREC', 'STLC - Guarantee Issuance Fee', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEERECV', 'STLC - Guarantee Issuance Fee', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEERIA', 'STLC - Guarantee Issuance Fee', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEPIA', 'STLC - Guarantee Issuance Fee', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEAQR', 'STLC - Guarantee Issuance Fee', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEPPD', 'STLC - Guarantee Issuance Fee', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEUNRL', 'STLC - Guarantee Issuance Fee', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEINC', 'STLC - Guarantee Issuance Fee', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEEXP', 'STLC - Guarantee Issuance Fee', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEPAY', 'STLC - Guarantee Issuance Fee', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEREC', 'STLC - Guarantee Issuance Fee', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_LCISSFEERECV', 'STLC - Guarantee Issuance Fee', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEERECV', 'STLC - Guarantee Issuance Fee', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEERIA', 'STLC - Guarantee Issuance Fee', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEPIA', 'STLC - Guarantee Issuance Fee', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEAQR', 'STLC - Guarantee Issuance Fee', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEPPD', 'STLC - Guarantee Issuance Fee', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEEUNRL', 'STLC - Guarantee Issuance Fee', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCISSFEENORMINC', 'STLC - Guarantee Issuance Fee', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMINC', 'STLC - Guarantee Amendment increase amount', 'I', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMEXP', 'STLC - Guarantee Amendment increase amount', 'E', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMPAY', 'STLC - Guarantee Amendment increase amount', 'L', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMREC', 'STLC - Guarantee Amendment increase amount', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMRECV', 'STLC - Guarantee Amendment increase amount', 'A', 'LC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMRIA', 'STLC - Guarantee Amendment increase amount', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMPIA', 'STLC - Guarantee Amendment increase amount', 'A', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMAQR', 'STLC - Guarantee Amendment increase amount', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMPPD', 'STLC - Guarantee Amendment increase amount', 'L', 'LC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMUNRL', 'STLC - Guarantee Amendment increase amount', 'A', 'LC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMINC', 'STLC - Guarantee Amendment increase amount', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMEXP', 'STLC - Guarantee Amendment increase amount', 'E', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMPAY', 'STLC - Guarantee Amendment increase amount', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMREC', 'STLC - Guarantee Amendment increase amount', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('BC_LCAMNDINAMRECV', 'STLC - Guarantee Amendment increase amount', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMRECV', 'STLC - Guarantee Amendment increase amount', 'A', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMRIA', 'STLC - Guarantee Amendment increase amount', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMPIA', 'STLC - Guarantee Amendment increase amount', 'A', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMAQR', 'STLC - Guarantee Amendment increase amount', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMPPD', 'STLC - Guarantee Amendment increase amount', 'L', 'BC', 'N', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMUNRL', 'STLC - Guarantee Amendment increase amount', 'A', 'BC', 'N', null, 'Y');

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('LCAMNDINAMNORMINC', 'STLC - Guarantee Amendment increase amount', 'I', 'LC', 'Y', null, null);


COMMIT;