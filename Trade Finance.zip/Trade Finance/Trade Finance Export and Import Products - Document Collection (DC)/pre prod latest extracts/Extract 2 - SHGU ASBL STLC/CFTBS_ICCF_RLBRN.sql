insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCADVAMND', 'Amendment Advising Charge', 'D', 'HLEANG', to_date('22-03-2021 15:08:18', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('22-03-2021 15:08:19', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 2, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCCANFEE', 'SBLC Cancellation Charge', 'D', 'SAMPATH2', to_date('22-03-2021 10:48:26', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('22-03-2021 10:48:26', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 2, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCADVCHG', 'Advising SBLC Fee', 'D', 'HLEANG', to_date('22-03-2021 11:29:46', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('22-03-2021 11:29:48', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 5, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCOTHAMND', 'SBLC all other amendment', 'D', 'SAMPATH2', to_date('22-03-2021 10:47:57', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('22-03-2021 10:47:57', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 2, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCAMNDINAM', 'STLC - Guarantee Amendment increase amount ', 'D', 'SAMPATH2', to_date('22-03-2021 10:48:44', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('22-03-2021 10:48:44', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 2, 'N', 'N');

insert into CFTBS_ICCF_RLBRN (RULE_ID, DESCRIPTION, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, AUTH_STAT, RECORD_STAT, ONCE_AUTH, MOD_NO, TRACK_RECEIVABLE, TRACK_PAYABLE)
values ('LCISSFEE', 'STLC - Guarantee Issuance Fee', 'D', 'SAMPATH2', to_date('22-03-2021 10:48:36', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('22-03-2021 10:48:36', 'dd-mm-yyyy hh24:mi:ss'), 'A', 'O', 'Y', 2, 'N', 'N');

COMMIT;