insert into CFTMS_COMMISSION_CLASS (MODULE, CLASS_CODE, CLASS_DESCRIPTION, RULE, RECORD_STAT, ONCE_AUTH, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, COLL_LC_COMM_IN_BILLS)
values ('LC', 'LCISSFEE', 'STLC - Guarantee Issuance Fee', 'LCISSFEE', 'O', 'Y', 'A', 1, 'SAMPATH2', to_date('22-03-2021 11:12:59', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('22-03-2021 11:12:59', 'dd-mm-yyyy hh24:mi:ss'), 'N');

insert into CFTMS_COMMISSION_CLASS (MODULE, CLASS_CODE, CLASS_DESCRIPTION, RULE, RECORD_STAT, ONCE_AUTH, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, COLL_LC_COMM_IN_BILLS)
values ('LC', 'LCAMNDINAM', 'STLC - Guarantee Amendment increase amount', 'LCAMNDINAM', 'O', 'Y', 'A', 1, 'SAMPATH2', to_date('22-03-2021 11:13:15', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('22-03-2021 11:13:15', 'dd-mm-yyyy hh24:mi:ss'), 'N');

ចោមមិតើ