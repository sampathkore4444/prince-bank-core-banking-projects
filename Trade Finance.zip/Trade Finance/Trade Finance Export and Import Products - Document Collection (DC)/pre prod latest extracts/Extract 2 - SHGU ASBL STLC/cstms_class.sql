insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCADVAMND', 'LC Export Advicing charges', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('22-03-2021 15:26:00', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('22-03-2021 15:26:00', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCADVCHG', 'Advising SBLC Fee', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('19-05-2020 16:15:36', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('19-05-2020 16:50:42', 'dd-mm-yyyy hh24:mi:ss'), 2);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCCANFEE', 'SBLC Cancellation Charge', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('22-03-2021 09:12:39', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('22-03-2021 09:12:40', 'dd-mm-yyyy hh24:mi:ss'), 3);

insert into cstms_class (MODULE, CLASS_CODE, CLASS_DESCRIPTION, CLASS_TYPE, TAX_BASIS, RESTRICTION_TYPE, RESTRICTION_TYPE2, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('LC', 'LCOTHAMND', 'SBLC all other amendment', 'CH', null, null, null, 'O', 'A', 'Y', 'HLEANG', to_date('22-03-2021 09:13:49', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('22-03-2021 09:13:49', 'dd-mm-yyyy hh24:mi:ss'), 2);

COMMIT;