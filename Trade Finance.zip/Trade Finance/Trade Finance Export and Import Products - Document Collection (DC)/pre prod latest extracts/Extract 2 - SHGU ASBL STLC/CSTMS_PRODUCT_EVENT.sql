insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'AATC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'ACON', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'AMNV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'APAC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'APAD', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'AREJ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'AVAL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'BADV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'BANC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'BCFM', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'BPRE', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'CANC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'CLOA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'EXPA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'RAVL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'REIN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'RLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'ROPN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('ASBL', 'TRNF', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'ACON', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'AMNV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'AOCF', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'AREJ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'AVAL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'BISS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'CANC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'CLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'CLOA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'EXPA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'RAVL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'REIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'RLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'ROPN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'RVSG', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'TRGN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('SHGU', 'WAIV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'ACON', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'AMNV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'AOCF', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'AREJ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'AVAL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'BISS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'CALC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'CANC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'CLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'CLOA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'EXPA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'RAVL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'REIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'RLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'ROPN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'TRGN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('STLC', 'WAIV', null);

COMMIT;