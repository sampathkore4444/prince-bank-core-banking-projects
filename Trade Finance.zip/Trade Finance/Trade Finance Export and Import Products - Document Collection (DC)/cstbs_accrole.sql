insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLINIT_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLINIT_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLINIT_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOLINIT_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOSINIT_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOSINIT_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOSINIT_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCICOSINIT_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECOLINIT_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECOLINIT_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECOLINIT_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECOLINIT_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECORINIT_REC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECORINIT_INC', 'BC Opening Charges', 'I', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECORINIT_IFBR', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

insert into cstbs_accrole (ROLE_CODE, ROLE_DESCRIPTION, ROLE_TYPE, MODULE, ALLOW_TRANSFER_GL, USER_DEFINED, UNREALISED)
values ('DCECORINIT_RIA', 'BC Opening Charges', 'L', 'BC', 'Y', null, null);

COMMIT;
