insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'BCOL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'BLNK', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'BLRV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'BOOK', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'INIT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'LCOL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'LIQD', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'PRNP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'REVR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'STCH', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDSC', 'TPFT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'AFAT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'BACP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'BCOL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'BOOK', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'INIT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'LCOL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'LIQD', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'PRNA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'PRNP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'REFA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'REFP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'REVR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'STCH', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'TAFT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('EDUA', 'TPFT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'AFAT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'BACP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'BOOK', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'DNTC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'INIT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'LIQD', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'PFAT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'REFA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'REFP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'REVR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'STCH', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'TACP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDSC', 'TPAY', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'AFAT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'BACP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'BOOK', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'DNTC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'INIT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'LIQD', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'PFAT', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'REFA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'REFP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'REVR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'STCH', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'TACP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('IDUA', 'TPAY', null);

COMMIT;
