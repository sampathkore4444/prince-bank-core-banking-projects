insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'ACCR', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'ACON', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'AMND', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'AMNV', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'AREJ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'AVAL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'BISS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'CANC', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'CLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'CLOA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'CLOS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'EXPA', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'GCLM', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'GCLP', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'RAVL', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'REIS', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'RLIQ', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'ROPN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'TRGN', null);

insert into CSTMS_PRODUCT_EVENT (PRODUCT_CODE, EVENT_CODE, SEQ_NO)
values ('GUPP', 'WAIV', null);

COMMIT;
