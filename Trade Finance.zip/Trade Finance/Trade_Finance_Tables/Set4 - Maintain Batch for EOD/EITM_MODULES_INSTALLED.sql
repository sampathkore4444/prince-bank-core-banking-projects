--Please do it for all branches from the front end
--Please do it for all branches from the front end
--Please do it for all branches from the front end
--Please do it for all branches from the front end
--Please do it for all branches from the front end
--Please do it for all branches from the front end
insert into EITM_MODULES_INSTALLED (BRANCH_CODE, EOC_GROUP, FUNCTION_ID, MODULE_ID, FREQUENCY, NO_DAYS, HOLIDAY_RULE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ERR_HANDLING, RUN_DATE, SEQ_NO, ERROR_HANDLING, EXTERNAL_IND, EXECUTION_LAYER, JOB_CODE, EOC_GROUP_STAGE)
values ('001', 'B', 'LCEOD', 'LC', 'D', null, 'X', 'SAMPATH1', to_date('06-03-2019 16:57:02', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH1', to_date('06-03-2019 16:57:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'O', 'A', 'Y', 'S', null, 10, 'S', null, 'DB', null, 1);

insert into EITM_MODULES_INSTALLED (BRANCH_CODE, EOC_GROUP, FUNCTION_ID, MODULE_ID, FREQUENCY, NO_DAYS, HOLIDAY_RULE, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, RECORD_STAT, AUTH_STAT, ONCE_AUTH, ERR_HANDLING, RUN_DATE, SEQ_NO, ERROR_HANDLING, EXTERNAL_IND, EXECUTION_LAYER, JOB_CODE, EOC_GROUP_STAGE)
values ('001', 'T', 'LCEOD', 'LC', 'D', null, 'X', 'SAMPATH1', to_date('06-03-2019 17:01:13', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH1', to_date('06-03-2019 17:01:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'O', 'A', 'Y', 'S', null, 23, 'S', null, 'DB', null, 1);

COMMIT;
