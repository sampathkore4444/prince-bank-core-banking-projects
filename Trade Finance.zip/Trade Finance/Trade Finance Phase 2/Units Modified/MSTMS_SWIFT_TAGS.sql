prompt Importing table MSTMS_SWIFT_TAGS...
set feedback off
set define off
insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '20', 'M', 1, 3, 'N', null, 'Documentary Credit Number', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '21P', 'M', 1, 2, 'N', null, 'Bank Reference Number', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '27', 'M', 1, 1, 'N', null, 'Sequence of Total', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '31D', 'M', 1, 7, 'N', null, 'Date and Place of Expiry', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '32B', 'M', 1, 11, 'N', null, 'Currency Code, Amount', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '39A', 'O', 1, 12, 'N', null, 'Percentage Credit Amount Tolerance', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '40A', 'M', 1, 2, 'N', null, 'Form of Documentary Credit', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '40E', 'M', 1, 6, 'N', null, 'Applicable Rules', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '41D', 'M', 5, 15, 'N', 'AD', 'Available With ... By ...', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '42C', 'O', 3, 16, 'N', null, 'Drafts at ...', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '43P', 'O', 1, 20, 'N', null, 'Partial Shipments', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '43T', 'O', 1, 21, 'N', null, 'Transshipment', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '44C', 'O', 1, 26, 'N', null, 'Latest Date of Shipment', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '31C', 'M', 1, 5, 'N', null, 'Date of Issue', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '42P', 'O', 4, 18, 'N', null, 'Negotiation/Deferred Payment Details', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '42D', 'M', 1, 16, 'N', 'AD', 'Drawee', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '44A', 'O', 1, 22, 'N', null, 'Place of Taking in Charge/Dispatch from .../Place of Receipt', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '44B', 'O', 1, 25, 'N', null, 'Place of Final Destination/For Transportation to .../Place of Delivery', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '44D', 'O', 6, 27, 'N', null, 'Shipment Period', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '44E', 'O', 1, 23, 'N', null, 'Port of Loading/Airport of Departure', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '44F', 'O', 1, 24, 'N', null, 'Port of Discharge/Airport of Destination', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '45A', 'O', 100, 28, 'N', null, 'Description of Goods and/or Services', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '46A', 'O', 100, 29, 'N', null, 'Documents Required', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '47A', 'O', 100, 30, 'N', null, 'Additional Conditions', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '48', 'O', 4, 33, 'N', null, 'Period for Presentation in Days', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '49', 'M', 1, 34, 'N', null, 'Confirmation Instructions', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '49G', 'O', 100, 31, 'N', null, 'Special Payment Conditions for Beneficiary', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '49H', 'O', 100, 32, 'N', 'AD', 'Special Payment Conditions for Receiving Bank', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '50', 'M', 4, 9, 'N', null, 'Applicant', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '57A', 'O', 2, 36, 'N', 'ABD', '''Advice Through'' Bank', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '57B', 'O', 2, 42, 'N', 'ABD', '''Advice Through'' Bank', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '57D', 'O', 5, 40, 'N', 'ABD', '''Advice Through'' Bank', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '58A', 'O', 100, 35, 'N', 'AD', 'Requested Confirmation Party', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '59', 'M', 1, 10, 'N', null, 'Beneficiary', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '71D', 'O', 6, 33, 'N', null, 'Charges', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '78', 'O', 12, 37, 'N', null, 'Instructions to the Paying/Accepting/Negotiating Bank', 'A');

insert into MSTMS_SWIFT_TAGS (MSG_TYPE, TAG_VALUE, TAG_OPTION, LINES, SEQUENCE, REPEATABLE, ALL_OPTIONS, DESCRIPTION, SEQUENCE_NAME)
values ('700', '72Z', 'O', 6, 39, 'N', null, 'Sender to Receiver Information', 'A');

prompt Done.
