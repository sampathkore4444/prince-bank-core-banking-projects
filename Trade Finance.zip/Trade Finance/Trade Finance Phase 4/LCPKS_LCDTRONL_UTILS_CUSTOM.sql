CREATE OR REPLACE PACKAGE BODY lcpks_lcdtronl_utils_custom AS




/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2001,2015  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
CHANGE-HISTORY :


    Modified By             : Kore Sampath Kumar
    Modified On             : 09-April-2020
    Modified Reason         : Make Claim Expiry Date needs to be inputted by user instead of auto by System
    Search String           : Make Claim Expiry Date needs to be inputted by user instead of auto by System

*/

  FUNCTION FN_VALID_CHARS(P_IN_STRING      IN VARCHAR2,
                          P_FIELD_TYPE     IN VARCHAR2,
                          P_OUT_STRING     IN OUT VARCHAR2,
                          P_FN_CALL_ID     IN OUT NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN

    DEBUG.PR_DEBUG('LC',
                   'In fn_valid_chars of lcpks_lcdtronl_utils_custom..');

    DEBUG.PR_DEBUG('LC',
                   'Returning Success From fn_valid_chars of lcpks_lcdtronl_utils_custom..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of lcpks_lcdtronl_utils_custom.fn_valid_chars ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_VALID_CHARS;

  FUNCTION FN_SWIFT_VALIDATIONS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_FUNCTION_ID        IN VARCHAR2,
                                P_ACTION_CODE        IN VARCHAR2,
                                P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_FN_CALL_ID         IN OUT NUMBER,
                                P_TB_CUSTOM_DATA     IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                                P_ERR_CODE           IN OUT VARCHAR2,
                                P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DEBUG.PR_DEBUG('LC',
                   'In fn_swift_validations of lcpks_lcdtronl_utils_custom..');

    DEBUG.PR_DEBUG('LC',
                   'Returning Success From fn_swift_validations of lcpks_lcdtronl_utils_custom..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of lcpks_lcdtronl_utils_custom.fn_swift_validations ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SWIFT_VALIDATIONS;

  FUNCTION FN_CALCULATE_AMTS(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_FUNCTION_ID        IN VARCHAR2,
                             P_ACTION_CODE        IN VARCHAR2,
                             P_PREV_MASTER_REC    IN LCTBS_CONTRACT_MASTER%ROWTYPE,
                             P_PREV_AVAILMENT_REC IN LCTBS_AVAILMENTS%ROWTYPE,
                             P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                             P_MASTER_REC         IN OUT LCTBS_CONTRACT_MASTER%ROWTYPE,
                             P_AVAILMENT_REC      IN OUT LCTBS_AVAILMENTS%ROWTYPE,
                             P_FN_CALL_ID         IN OUT NUMBER,
                             P_TB_CUSTOM_DATA     IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                             P_ERR_CODE           IN OUT VARCHAR2,
                             P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DEBUG.PR_DEBUG('LC',
                   'In Fn_Calculate_Amts of lcpks_lcdtronl_utils_custom..');

    DEBUG.PR_DEBUG('LC',
                   'Returning Success From Fn_Calculate_Amts of lcpks_lcdtronl_utils_custom..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of lcpks_lcdtronl_utils_custom.Fn_Calculate_Amts ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_CALCULATE_AMTS;

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('LC', 'lcpks_lcdtronl_utils_custom ==>' || P_DBG);
  END DBG;

  FUNCTION FN_PRE_VALIDATE_MASTER(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                  P_FUNCTION_ID        IN VARCHAR2,
                                  P_ACTION_CODE        IN VARCHAR2,
                                  P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                  P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_ERR_CODE           IN OUT VARCHAR2,
                                  P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In lcpks_lcdtronl_utils_custom.fn_pre_Validate_Master..');

    --Make Claim Expiry Date needs to be inputted by user instead of auto by System starts

    DBG('P_ACTION_CODE=' || P_ACTION_CODE);

    DBG('P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_DATE=' ||
        P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_DATE);
    DBG('P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_EXPIRY_DATE=' ||
        P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_EXPIRY_DATE);

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) /*AND
       P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_EXPIRY_DATE IS NOT NULL*/ THEN

      P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_EXPIRY_DATE := NULL;
      P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_DATE := null;

    END IF;

    --Make Claim Expiry Date needs to be inputted by user instead of auto by System ends


    DBG('Returning Success From lcpks_lcdtronl_utils_custom.fn_pre_Validate_Master');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of lcpks_lcdtronl_utils_custom.fn_pre_Validate_Master..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-OTHR-001', '~');
      RETURN FALSE;
  END FN_PRE_VALIDATE_MASTER;

  FUNCTION FN_POST_VALIDATE_MASTER(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                   P_FUNCTION_ID        IN VARCHAR2,
                                   P_ACTION_CODE        IN VARCHAR2,
                                   P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                   P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_ERR_CODE           IN OUT VARCHAR2,
                                   P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In lcpks_lcdtronl_utils_custom.fn_post_Validate_Master..');

    DBG('Returning Success From lcpks_lcdtronl_utils_custom.fn_post_Validate_Master');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of lcpks_lcdtronl_utils_custom.fn_post_Validate_Master ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-OTHR-001', '~');
      RETURN FALSE;
  END FN_POST_VALIDATE_MASTER;

  FUNCTION FN_PICKUP_ADVICES(P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_ACTION_CODE    IN VARCHAR2,
                             P_FUNCTION_ID    IN VARCHAR2,
                             P_PRODUCT        IN VARCHAR2,
                             P_FCC_REF        IN VARCHAR2,
                             P_EVENT_SEQ_NO   IN CSTB_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE,
                             P_LATEST_VERSION IN NUMBER,
                             P_EVENT          IN CSTB_CONTRACT.CURR_EVENT_CODE%TYPE,
                             P_COUNTERPARTY   IN VARCHAR2,
                             P_ERR_CODE       IN OUT VARCHAR2,
                             P_ERR_PARAMS     IN OUT VARCHAR2,
                             P_FN_CALL_ID     IN OUT NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS

  BEGIN
    DEBUG.PR_DEBUG('**',
                   'Inside the function lcpks_lcdtronl_utils_custom.Fn_Pickup_Advices..');

    DEBUG.PR_DEBUG('**',
                   'Returning successfully from the function lcpks_auth_custom.Fn_Pickup_Advices..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Pickup_Advices..');
      RETURN FALSE;
  END FN_PICKUP_ADVICES;

  FUNCTION FN_PRE_DEFAULT_MASTER(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                 P_SOURCE_OPERATION   IN VARCHAR2,
                                 P_FUNCTION_ID        IN VARCHAR2,
                                 P_ACTION_CODE        IN VARCHAR2,
                                 P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                 P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_PREV_LCDTRONL      IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_WRK_LCDTRONL       IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_ERR_CODE           IN OUT VARCHAR2,
                                 P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In lcpks_lcdtronl_utils_custom.Fn_Pre_Default_Master..');

    DBG('Returning Success From lcpks_lcdtronl_utils_custom.Fn_Pre_Default_Master');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of lcpks_lcdtronl_utils_custom.Fn_Pre_Default_Master..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-OTHR-001', '~');
      RETURN FALSE;
  END FN_PRE_DEFAULT_MASTER;

  FUNCTION FN_POST_DEFAULT_MASTER(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                  P_SOURCE_OPERATION   IN VARCHAR2,
                                  P_FUNCTION_ID        IN VARCHAR2,
                                  P_ACTION_CODE        IN VARCHAR2,
                                  P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                  P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_PREV_LCDTRONL      IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_WRK_LCDTRONL       IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_ERR_CODE           IN OUT VARCHAR2,
                                  P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In lcpks_lcdtronl_utils_custom.Fn_Post_Default_Master..');

    --Make Claim Expiry Date needs to be inputted by user instead of auto by System starts

    DBG('P_ACTION_CODE=' || P_ACTION_CODE);

    DBG('P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_DATE=' ||
        P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_DATE);
    DBG('P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_EXPIRY_DATE=' ||
        P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_EXPIRY_DATE);

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) /*AND
       P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_EXPIRY_DATE IS NOT NULL*/ THEN

      P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_EXPIRY_DATE := NULL;
      P_WRK_LCDTRONL.v_lctbs_contract_master.CLAIM_DATE := null;

    END IF;

    --Make Claim Expiry Date needs to be inputted by user instead of auto by System ends

    DBG('Returning Success From lcpks_lcdtronl_utils_custom.Fn_Post_Default_Master');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of lcpks_lcdtronl_utils_custom.Fn_Post_Default_Master..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-OTHR-001', '~');
      RETURN FALSE;
  END FN_POST_DEFAULT_MASTER;

  FUNCTION FN_PRE_DEFAULT_PARTIES(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                  P_SOURCE_OPERATION   IN VARCHAR2,
                                  P_FUNCTION_ID        IN VARCHAR2,
                                  P_ACTION_CODE        IN VARCHAR2,
                                  P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                  P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_WRK_LCDTRONL       IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_ERR_CODE           IN OUT VARCHAR2,
                                  P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN
    DBG('In lcpks_lcdtronl_utils_custom.Fn_Pre_Default_Parties..');

    DBG('Returning True from In lcpks_lcdtronl_utils_custom.Fn_Pre_Default_Parties..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in when others of Fn_Pre_Default_Parties');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('LC-UPLOTH',
                         'Lcpks_Lcdtronl_Dflt.Fn_Pre_Default_Parties~' ||
                         SQLCODE);
      RETURN FALSE;
  END FN_PRE_DEFAULT_PARTIES;

  FUNCTION FN_PRE_VALIDATE_PARTIES(P_SOURCE             IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                   P_FUNCTION_ID        IN VARCHAR2,
                                   P_ACTION_CODE        IN VARCHAR2,
                                   P_PRODUCT_DEFINITION IN LCTMS_PRODUCT_DEFINITION%ROWTYPE,
                                   P_LCDTRONL           IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_PREV_LCDTRONL      IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_WRK_LCDTRONL       IN OUT NOCOPY LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_ERR_CODE           IN OUT VARCHAR2,
                                   P_ERR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN
    DBG('In lcpks_lcdtronl_utils_custom.Fn_Pre_Validate_Parties..');

    DBG('Returning True from In lcpks_lcdtronl_utils_custom.Fn_Pre_Validate_Parties..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Pre_Validate_Parties ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_VALIDATE_PARTIES;

  FUNCTION FN_UNLOCK(P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                     P_FUNCTION_ID    IN VARCHAR2,
                     P_ACTION_CODE    IN OUT VARCHAR2,
                     P_LCDTRONL       IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                     P_ERR_CODE       IN OUT VARCHAR2,
                     P_ERR_PARAMS     IN OUT VARCHAR2,
                     P_FN_CALL_ID     IN OUT NUMBER,
                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS

  BEGIN
    DBG('In lcpks_lcdtronl_utils_custom.Fn_Unlock..');

    DBG('Returning True from In lcpks_lcdtronl_utils_custom.Fn_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of  Fn_Unlock ');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_UNLOCK;

END LCPKS_LCDTRONL_UTILS_CUSTOM;
