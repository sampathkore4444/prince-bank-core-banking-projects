CREATE OR REPLACE PACKAGE BODY Lcpks_Lcdtronl_Kernel AS

  G_UI_NAME VARCHAR2(50) := 'LCDTRONL';

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'lcpks_lcdtronl_Kernel ==>' || P_MSG;
    DEBUG.PR_DEBUG('LC', L_MSG);

  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler');
  END PR_SKIP_HANDLER;

  FUNCTION FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                        P_LCDTRONL         IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_MODULE SMTB_MENU.MODULE%TYPE;
  BEGIN

    DBG('In fn_Post_build_type_structure');

    DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others while getting module..');
        RETURN FALSE;
    END;

    DBG('Returning Success from fn_Post_build_type_structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_Post_build_type_structure ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_BUILD_TYPE_STRUCTURE;

  FUNCTION FN_PRE_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CHILD_FUNCTION   IN VARCHAR2,
                                  P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                  P_LCDTRONL         IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

    L_MODULE            CSTBS_CONTRACT.MODULE_CODE%TYPE;
    L_PRODUCT_TYPE      CSTBS_CONTRACT.PRODUCT_TYPE%TYPE;
    L_SWIFT2020_ENABLED VARCHAR2(1);
    L_SBLC_ENABLED      VARCHAR2(1) := 'N';
    L_EVENT_CODE        CSTB_CONTRACT_EVENT_LOG.EVENT_CODE%TYPE;
  BEGIN

    DBG('In fn_pre_check_mandatory');

    IF P_FUNCTION_ID NOT IN
       ('LIDTRONL', 'LIDAMEND', 'LIDGUONL', 'LIDGUAMD', 'LIDGCLM') THEN

      BEGIN
        DBG('Checking for module code');

        SELECT MODULE
          INTO L_MODULE
          FROM CSTM_PRODUCT
         WHERE PRODUCT_CODE = SUBSTR(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                     4,
                                     4);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found for module code');
          L_MODULE := NULL;
        WHEN OTHERS THEN
          DBG('Failed in selecting module...' || SQLERRM);
      END;
      DBG('Module = ' || L_MODULE);

      IF L_MODULE NOT IN ('LC') THEN
        P_ERR_CODE   := 'LC-UP1012';
        P_ERR_PARAMS := L_MODULE;
        RETURN FALSE;
      END IF;
    END IF;

    L_SWIFT2020_ENABLED := LCPKS_UTILS.FN_GET_SWIFT_PARAM;

    DBG('l_swift2020_enabled-->' || L_SWIFT2020_ENABLED);

    L_SBLC_ENABLED := LCPKS_UTILS.FN_GET_SBLC_PREF;
    DBG('l_sblc_enabled-->' || L_SBLC_ENABLED);

    IF P_FUNCTION_ID NOT IN ('LCDGUONL',
                             'LCDGUAMD',
                             'LCDGCLM',
                             'LCDTRSIM',
                             'LCDGUSIM',
                             'LCDGAMSM',
                             'LIDGUONL',
                             'LIDGUAMD',
                             'LIDGCLM') THEN

      BEGIN
        DBG('Checking for product type');

        SELECT PRODUCT_TYPE
          INTO L_PRODUCT_TYPE
          FROM CSTM_PRODUCT
         WHERE PRODUCT_CODE = SUBSTR(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                     4,
                                     4);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found for product type');
          L_MODULE := NULL;
        WHEN OTHERS THEN
          DBG('Failed in selecting product type...' || SQLERRM);
      END;
      DBG('Product Type = ' || L_PRODUCT_TYPE);

      IF NOT
          (L_PRODUCT_TYPE IN ('I', 'E', 'C', 'H', 'R') OR
          (L_PRODUCT_TYPE IN ('S', 'B', 'G', 'A') AND
          'N' = NVL(L_SWIFT2020_ENABLED, 'N')) OR
          (L_PRODUCT_TYPE IN ('S', 'B') AND 'Y' = NVL(L_SBLC_ENABLED, 'N')))

       THEN
        P_ERR_CODE   := 'LC-UP1013';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

      IF L_PRODUCT_TYPE IN ('S', 'B') AND L_SWIFT2020_ENABLED = 'Y' AND
         NOT
          (P_FUNCTION_ID IN ('LCDTRONL', 'LCDAMEND', 'LIDTRONL', 'LIDAMEND') AND
          NVL(L_SBLC_ENABLED, 'N') = 'Y') THEN
        P_ERR_CODE   := 'LC-UP1013';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;

    END IF;

    IF P_FUNCTION_ID NOT IN ('LCDTRONL',
                             'LCDAMEND',
                             'LIDTRONL',
                             'LIDAMEND',
                             'LCDTRSIM',
                             'LCDAMSIM') THEN
      BEGIN
        DBG('Checking for product type');

        SELECT PRODUCT_TYPE
          INTO L_PRODUCT_TYPE
          FROM CSTM_PRODUCT
         WHERE PRODUCT_CODE = SUBSTR(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                     4,
                                     4);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found for product type');
          L_MODULE := NULL;
        WHEN OTHERS THEN
          DBG('Failed in selecting product type...' || SQLERRM);
      END;
      DBG('Product Type = ' || L_PRODUCT_TYPE);

      IF L_PRODUCT_TYPE NOT IN ('G', 'A', 'S', 'B') THEN
        P_ERR_CODE   := 'LC-UP1014';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE <> 'EXECUTEQUERY' THEN

      DBG('CUST ID: ' || P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
      IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID IS NOT NULL THEN
        IF NOT CSPKS_STAFF_RESTR.FN_CHECK_CUST(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                                               NULL,
                                               GLOBAL.CURRENT_BRANCH,
                                               'N',
                                               P_ERR_PARAMS,
                                               P_ERR_CODE)

         THEN
          DBG('Staff Acc Restr failed for :' ||
              P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID);
          DBG('FAILED IN fn_check_cust' || SQLERRM);
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);

          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    BEGIN
      SELECT EVENT_CODE
        INTO L_EVENT_CODE
        FROM CSTB_CONTRACT_EVENT_LOG
       WHERE CONTRACT_REF_NO = P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO IN
             (SELECT MAX(EVENT_SEQ_NO)
                FROM CSTB_CONTRACT_EVENT_LOG
               WHERE CONTRACT_REF_NO =
                     P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                 AND EVENT_CODE NOT IN ('ACCR', 'CLIQ'));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    DBG('Latest event is-->' || L_EVENT_CODE);
    IF L_EVENT_CODE = 'REVR' THEN
      DBG('action code is-->' || P_ACTION_CODE);
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_ROLLOVER,
                           CSPKS_REQ_GLOBAL.P_COPY,
                           CSPKS_REQ_GLOBAL.P_CLOSE,
                           CSPKS_REQ_GLOBAL.P_REVERSE) THEN
        DBG('These actions cannot be performed on a reversed contract');
        P_ERR_CODE   := 'LC-REV-001';
        P_ERR_PARAMS := P_ACTION_CODE;
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning Success from fn_pre_check_mandatory');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_check_mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_PK_OR_FULL VARCHAR2(20);

  BEGIN
    DBG('In fn_post_check_mandatory');

    L_PK_OR_FULL := P_PK_OR_FULL;
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_PRDDFLT OR
       SUBSTR(P_ACTION_CODE, 1, LENGTH(CSPKS_REQ_GLOBAL.P_ENRICH)) =
       CSPKS_REQ_GLOBAL.P_ENRICH OR
       SUBSTR(P_ACTION_CODE, 1, LENGTH(CSPKS_REQ_GLOBAL.P_ENRICH)) =
       CSPKS_REQ_GLOBAL.P_ENRICH OR P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_HOLD THEN
      IF NOT LCPKS_LCDTRONL_UTILS.FN_CHECK_MANDATORY(P_SOURCE,
                                                     P_FUNCTION_ID,
                                                     P_ACTION_CODE,
                                                     L_PK_OR_FULL,
                                                     P_LCDTRONL,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN

        DBG('Failed in Check Mandatory....');
        RETURN FALSE;
      END IF;
    ELSE

      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_ROLLOVER,
                           CSPKS_REQ_GLOBAL.P_CLOSE) THEN

        IF NOT LCPKS_LCDTRONL_MAIN. FN_SYS_CHECK_MANDATORY(P_SOURCE,
                                  L_PK_OR_FULL,
                                  P_LCDTRONL,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN

          DBG('Failed in Check Mandatory....');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    DBG('Returning Success from fn_post_check_mandatory');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_post_check_mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CHILD_FUNCTION   IN VARCHAR2,
                                       P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                       P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                       P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In fn_pre_default_and_validate');

    DBG('p_Source: ' || P_SOURCE);
    DBG('p_Wrk_Lcdtronl.v_cstbs_contract.CONTRACT_REF_NO: ' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
    DBG('p_Lcdtronl.v_cstbs_contract.CONTRACT_REF_NO: ' ||
        P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

    IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT IS NULL THEN
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT := 'N';
    ELSE
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT;
    END IF;
    IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') = 'N' THEN

      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIMITS_TRACKING_TENOR_TYPE := NULL;
    END IF;

    IF P_FUNCTION_ID NOT IN ('LCDGUONL', 'LCDGUSIM', 'LIDGUONL') THEN
      DBG('p_action_code' || P_ACTION_CODE);
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_HOLD,
                           'DEFAULTDOC',
                           'POPULATELIMIT') THEN
        P_WRK_LCDTRONL := P_LCDTRONL;
      ELSE
        P_WRK_LCDTRONL := P_PREV_LCDTRONL;
      END IF;
    END IF;

    DBG('Returning Success from fn_pre_default_and_validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_default_and_validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

  FUNCTION FN_POST_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                        P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                        P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CURSOR CUR_CLAUSE_CODE(L_DOC LCTB_DOCUMENTS.DOC_CODE%TYPE) IS
      SELECT CLAUSE_CODE, CLAUSE_DESCRIPTION

        FROM LCTMS_CLAUSE_MASTER
       WHERE LANGUAGE_CODE = UPPER(GLOBAL.LANG)
         AND CLAUSE_CODE IN (SELECT CLAUSE_CODE
                               FROM BCTMS_DOCS_CLAUSES
                              WHERE DOC_CODE = L_DOC);

    CURSOR CUR_DOCS IS
      SELECT PD.DOCUMENT_CODE AS DOCUMENT_CODE,
             ROWNUM,
             PD.DOCUMENT_TYPE,
             DM.DOC_LONG_DESC,
             PD.ORIGINAL_REQUIRED,
             PD.NO_OF_COPIES,
             PD.NO_OF_ORIGINALS
        FROM LCTMS_PRODUCT_DOCUMENTS PD, BCTMS_DOCS_MASTER DM

       WHERE PD.PRODUCT_CODE = P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE
         AND PD.DOCUMENT_CODE = DM.DOC_CODE
         AND DM.LANG_CODE = GLOBAL.LANG
      UNION
      SELECT DM.DOC_CODE      AS DOCUMENT_CODE,
             ROWNUM,
             DM.DOC_TYPE      AS DOCUMENT_TYPE,
             DM.DOC_LONG_DESC,
             NULL             AS ORIGINAL_REQUIRED,
             NULL             NO_OF_COPIES,
             NULL             NO_OF_ORIGINALS
        FROM BCTMS_DOCS_MASTER DM
       WHERE DOC_CODE IN
             (SELECT DOC_CODE
                FROM TFTMS_INCO_DOCS
               WHERE INCO_TERM =
                     P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A'
                 AND DOC_CODE NOT IN
                     (SELECT DOCUMENT_CODE
                        FROM LCTMS_PRODUCT_DOCUMENTS PD, BCTMS_DOCS_MASTER DM
                       WHERE PD.PRODUCT_CODE =
                             P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE
                         AND PD.DOCUMENT_CODE = DM.DOC_CODE
                         AND DM.LANG_CODE = GLOBAL.LANG));
    L_COUNT NUMBER := 1;

    L_SOURCE_OPERATION VARCHAR2(30);
    L_MODULE           SMTB_MENU.MODULE%TYPE;
    L_DOC_FLG          BOOLEAN;
    L_PRODUCT_REC      LCTMS_PRODUCT_DEFINITION%ROWTYPE;

    L_ADVINDEX NUMBER;
    L_FFTINDEX NUMBER;
    L_FFTSLNO  NUMBER;

    L_COUNT1 NUMBER;
    L_INDEX  NUMBER;

    L_POS_TOL LCTB_CONTRACT_MASTER.POSITIVE_TOLERANCE%TYPE;
    L_NEG_TOL LCTB_CONTRACT_MASTER.NEGATIVE_TOLERANCE%TYPE;

    L_TRNF_AMT                LCTB_TRANSFER_DETAILS.TRANSFER_AMT%TYPE;
    L_EXPIRY_DATE             LCTB_TRANSFER_DETAILS.NEW_EXPIRY_DATE%TYPE;
    L_PERIOD_FOR_PRESENTATION LCTB_TRANSFER_DETAILS.PERIOD_FOR_PRESENTATION%TYPE;
    L_LATEST_SHIPMENT_DATE    LCTB_TRANSFER_DETAILS.NEW_LATEST_SHIPMENT_DATE%TYPE;
    L_UNAUTH_COUNT            NUMBER;

    TYPE TY_CLAUSE IS TABLE OF LCTB_CLAUSES%ROWTYPE INDEX BY VARCHAR2(32);
    L_CLAUSE TY_CLAUSE;

    L_SL_NO   NUMBER := 0;
    LO_MX_LC  LCTB_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;
    OUT_MX_LC LCTB_CONTRACT_MASTER.MAX_CONTRACT_AMT%TYPE;

    CURSOR C_DOC_UPLOAD_1 IS
      SELECT *
        FROM CSTB_DOC_UPLOAD_DETAIL
       WHERE KEY_ID = GLOBAL.CURRENT_BRANCH || ':' ||
             P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

    L_TOT_GOODS_AMT NUMBER := 0;

    L_VALIDATELIMITS   BOOLEAN := TRUE;
    L_LCTBCONLIMITTYPE LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_CONTRACT_LIMITS;

    L_SWIFT2020_ENABLED VARCHAR2(1);
  BEGIN
    DBG('In fn_post_default_and_validate' || P_ACTION_CODE);

    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM SMTB_MENU
       WHERE FUNCTION_ID = P_FUNCTION_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_MODULE := 'LC';
        DBG('No module found, so assigning BC');
    END;

    DBG('module' || L_MODULE);

    L_SWIFT2020_ENABLED := LCPKS_UTILS.FN_GET_SWIFT_PARAM;

    DBG('l_swift2020_enabled-->' || L_SWIFT2020_ENABLED);

    OPEN C_DOC_UPLOAD_1;
    LOOP
      FETCH C_DOC_UPLOAD_1 BULK COLLECT
        INTO P_PREV_LCDTRONL.TY_CSCDOCTR.V_CSTB_DOC_UPLOAD_DETAIL;
      EXIT WHEN C_DOC_UPLOAD_1%NOTFOUND;
    END LOOP;
    CLOSE C_DOC_UPLOAD_1;

    L_COUNT1 := P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT;
    FOR X IN 1 .. L_COUNT1 LOOP

      IF (P_WRK_LCDTRONL.V_LCTBS_DRAFTS(X).DRAFT_SL_NO IS NULL) THEN
        DBG('Coming herezz');
        P_ERR_CODE   := 'ST-MAND-011';
        P_ERR_PARAMS := '@LCTBS_DRAFTS';
        RETURN FALSE;

      END IF;
    END LOOP;

    IF P_SOURCE = 'FLEXCUBE' THEN

      L_SOURCE_OPERATION := P_FUNCTION_ID || '_' || P_ACTION_CODE;
    ELSE
      L_SOURCE_OPERATION := P_SOURCE_OPERATION;
    END IF;
    DBG('Source Operation = ' || L_SOURCE_OPERATION);

    IF P_ACTION_CODE = 'DEFAULTDOC' THEN

      G_LCDTRONL := P_LCDTRONL;

      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT LOOP
        DBG('Value of i is' || I);
        DBG('before Clause code is' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
            .CLAUSE_CODE);
        DBG('clause_descr is' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
            .CLAUSE_DESCR);
        DBG('contract_ref_no is' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
            .CONTRACT_REF_NO);
        DBG('doc_code is' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE);

      END LOOP;

      DBG('p_Lcdtronl.v_Lctbs_Clauses.count' ||
          P_LCDTRONL.V_LCTBS_CLAUSES.COUNT);
      FOR I IN 1 .. P_LCDTRONL.V_LCTBS_CLAUSES.COUNT LOOP
        L_CLAUSE(P_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE) := P_LCDTRONL.V_LCTBS_CLAUSES(I);
        DBG('l_clause(p_Lcdtronl.v_Lctbs_Clauses(i).doc_code)' || L_CLAUSE(P_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE)
            .DOC_CODE);
        DBG('l_clause(p_Lcdtronl.v_Lctbs_Clauses(i).clause_code)' || L_CLAUSE(P_LCDTRONL.V_LCTBS_CLAUSES(I).DOC_CODE)
            .CLAUSE_CODE);
      END LOOP;
      DBG('l_clause_count' || L_CLAUSE.COUNT);

      BEGIN

        IF P_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 THEN
          DBG('Count' || P_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT);
          FOR I IN 1 .. P_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT LOOP

            FOR DOCS IN CUR_DOCS LOOP
              DBG('outer doc code' || P_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                  .DOC_CODE);
              DBG('inner doc code' || DOCS.DOCUMENT_CODE);

              IF L_CLAUSE.EXISTS(P_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE) THEN

                IF (P_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                   .DOC_CODE = DOCS.DOCUMENT_CODE

                   OR (P_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE = L_CLAUSE(P_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE)
                    .DOC_CODE)) AND L_CLAUSE(P_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_CODE)
                  .CLAUSE_CODE IS NOT NULL THEN

                  DBG('setting true');
                  L_DOC_FLG := TRUE;
                  EXIT;
                ELSE
                  DBG('setting false');
                  L_DOC_FLG := FALSE;
                END IF;

              ELSE
                DBG('setting2 false');
                L_DOC_FLG := FALSE;
              END IF;

            END LOOP;
            IF L_DOC_FLG = FALSE THEN

              L_INDEX := P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT;
              FOR CLAUSES IN CUR_CLAUSE_CODE(P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                                             .DOC_CODE) LOOP
                DBG('Clause Code : ' || CLAUSES.CLAUSE_CODE);
                DBG('Clause Code : ' || CLAUSES.CLAUSE_DESCRIPTION);
                L_INDEX := L_INDEX + 1;
                P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX).CLAUSE_CODE := CLAUSES.CLAUSE_CODE;
                P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX).CLAUSE_DESCR := CLAUSES.CLAUSE_DESCRIPTION;
                P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX).CONTRACT_REF_NO := P_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                                                                           .CONTRACT_REF_NO;
                P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX).DOC_CODE := P_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                                                                    .DOC_CODE;

                DBG('the value of l_Index is' || L_INDEX);
              END LOOP;

            END IF;
          END LOOP;

          FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT LOOP
            DBG('Value of i is' || I);
            DBG('after Clause code is' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
                .CLAUSE_CODE);
            DBG('clause_descr is' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
                .CLAUSE_DESCR);
            DBG('contract_ref_no is' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
                .CONTRACT_REF_NO);
            DBG('doc_code is' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(I)
                .DOC_CODE);

          END LOOP;

        END IF;
      EXCEPTION

        WHEN OTHERS THEN
          DBG('SQLERROR' || SQLERRM);
      END;
    END IF;

    IF P_ACTION_CODE = 'POPULATELIMIT' THEN

      DBG('coming into populate action');
      G_LCDTRONL := P_LCDTRONL;

      SELECT *
        INTO L_PRODUCT_REC
        FROM LCTMS_PRODUCT_DEFINITION
       WHERE PRODUCT_CODE = SUBSTR(P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                   4,
                                   4);

      IF NOT LCPKS_LCDTRONL_MAIN.FN_SYS_BASIC_VALS(P_SOURCE,
                                                   P_LCDTRONL,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN

        DBG('Failed in  Lcpks_Lcdtronl_Main.Fn_Sys_Basic_Vals....');
        RETURN FALSE;
      END IF;
      IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') = 'Y' THEN
        IF NOT LCPKS_LCDTRONL_UTILS.FN_VALIDATE_PARTIES(P_SOURCE,
                                                        P_FUNCTION_ID,
                                                        P_ACTION_CODE,
                                                        L_PRODUCT_REC,
                                                        P_LCDTRONL,
                                                        P_PREV_LCDTRONL,
                                                        P_WRK_LCDTRONL,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
          DBG('Failed in  Lcpks_Lcdtronl_Main.fn_validate_parties....');
          RETURN FALSE;
        END IF;
        IF NOT LCPKS_LCDTRONL_UTILS.FN_DFLT_JV_CUSTOMERS(P_SOURCE,
                                                         P_SOURCE_OPERATION,
                                                         P_FUNCTION_ID,
                                                         P_ACTION_CODE,
                                                         P_LCDTRONL,
                                                         P_PREV_LCDTRONL,
                                                         P_WRK_LCDTRONL,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN

          DBG('Failed Lcpks_Lcdtronl_Utils.Fn_Default..');
          RETURN FALSE;
        END IF;
      ELSE
        DBG('Tracking Limit should be Checked');
        P_ERR_CODE := 'LM-VALS-381';
        RETURN FALSE;
      END IF;
    END IF;

    DBG('25840131_changes: p_Action_Code--> ' || P_ACTION_CODE);

    IF P_FUNCTION_ID IN ('LCDTRONL',
                         'LCDAMEND',
                         'LIDTRONL',
                         'LIDAMEND',
                         'LCDGUAMD',
                         'LCDAMSIM',
                         'LCDGAMSM',
                         'LIDGUAMD') OR
       LCPKS_LCDTRONL_KERNEL.ISCHILDFUNCTION

     THEN

      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                           CSPKS_REQ_GLOBAL.P_HOLD,
                           CSPKS_REQ_GLOBAL.P_MODIFY

                          ,
                           CSPKS_REQ_GLOBAL.P_CLOSE,
                           CSPKS_REQ_GLOBAL.P_REOPEN) THEN
        IF P_FUNCTION_ID IN ('LCDTRONL', 'LIDTRONL') OR
           LCPKS_LCDTRONL_KERNEL.ISCHILDFUNCTION THEN

          IF NOT LCPKS_LCDTRONL_MAIN.FN_SYS_BASIC_VALS(P_SOURCE,
                                                       P_LCDTRONL,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN
            DBG('Failed in  Lcpks_Lcdtronl_Main.Fn_Sys_Basic_Vals....');
            RETURN FALSE;
          END IF;

        END IF;

        IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY,
                             CSPKS_REQ_GLOBAL.P_ROLLOVER,
                             CSPKS_REQ_GLOBAL.P_CLOSE,
                             CSPKS_REQ_GLOBAL.P_REOPEN) THEN

          DBG('p_function_id' || P_FUNCTION_ID);

          IF P_FUNCTION_ID IN ('LCDAMEND',
                               'LIDAMEND',
                               'LCDGUAMD',
                               'LCDAMSIM',
                               'LCDGAMSM',
                               'LIDGUAMD')

           THEN

            IF NOT SUBSTR(LCPKS_LCDTRONL_MAIN.FN_GET_ORIGINAL_ACTION,
                          1,
                          LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) =
                CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP THEN

              DBG('inside 1');
              IF NOT
                  LCPKS_LCDTRONL_MAIN.FN_SYS_MERGE_AMENDABLES(P_SOURCE,

                                                              P_SOURCE_OPERATION,

                                                              P_LCDTRONL,
                                                              P_PREV_LCDTRONL,
                                                              P_WRK_LCDTRONL,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN

                DBG('Failed in Lcpks_Lcdtronl_Main.Fn_Sys_Merge_Amendables....');
                RETURN FALSE;
              END IF;

            ELSIF P_FUNCTION_ID IN
                  ('LCDAMEND', 'LCDGUAMD', 'LIDGUAMD', 'LIDAMEND') AND
                  P_SOURCE_OPERATION = 'LCDTRONL_SUBSYSPKP_MODIFY' THEN
              DBG('inside 30895697');

              IF NOT
                  LCPKS_LCDTRONL_MAIN.FN_SYS_MERGE_AMENDABLES(P_SOURCE,
                                                              'LCDTRONL_MODIFY',
                                                              P_LCDTRONL,
                                                              P_PREV_LCDTRONL,
                                                              P_WRK_LCDTRONL,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN

                DBG('Failed in Lcpks_Lcdtronl_Main.Fn_Sys_Merge_Amendables....');
                RETURN FALSE;
              END IF;

            END IF;

          ELSE
            DBG('inside 2');
            IF NOT
                LCPKS_LCDTRONL_MAIN.FN_SYS_MERGE_AMENDABLES(P_SOURCE,
                                                            L_SOURCE_OPERATION,
                                                            P_LCDTRONL,
                                                            P_PREV_LCDTRONL,
                                                            P_WRK_LCDTRONL,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN

              DBG('Failed in Lcpks_Lcdtronl_Main.Fn_Sys_Merge_Amendables....');
              RETURN FALSE;
            END IF;
          END IF;

        END IF;

        IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE IS NULL THEN
          DBG('PRODUCT_TYPE is NULL...');
          BEGIN
            SELECT PRODUCT_TYPE
              INTO P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE
              FROM LCTMS_PRODUCT_DEFINITION
             WHERE PRODUCT_CODE = P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('No PRODUCT_TYPE found in Lctms_Product_Definition...');
              DEBUG.PR_DEBUG('**', SQLERRM);
              P_ERR_CODE   := 'ST-OTHR-001';
              P_ERR_PARAMS := NULL;
              RETURN FALSE;
          END;
        END IF;
        DBG('In PRODUCT_TYPE' ||
            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE);

        IF L_MODULE = 'LC' THEN
          IF P_FUNCTION_ID = 'LCDTRONL' OR
             LCPKS_LCDTRONL_KERNEL.ISCHILDFUNCTION THEN

            IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
              DBG('Checking if to validate limits');
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                      0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                0) > 0) OR
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                      0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                                0) > 0) OR
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                      0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                                0) > 0) OR
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE,
                      0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE,
                                0) > 0) OR
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT,
                      0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT,
                                0) > 0) OR
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT,
                      0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT,
                                0) > 0) OR
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                      0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                                0) > 0) OR
                 (P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT = 0 AND
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT > 0 AND
                 NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE,
                      'N') <> 'Y') OR
                 (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR <>
                 P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR) OR
                 (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE <>
                 P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE) THEN
                DBG('Validate limits');
                L_VALIDATELIMITS := TRUE;
              ELSE
                DBG('Do not Validate limits');
                L_VALIDATELIMITS   := FALSE;
                L_LCTBCONLIMITTYPE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS;
                P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.DELETE;
              END IF;

            ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
              L_VALIDATELIMITS   := FALSE;
              L_LCTBCONLIMITTYPE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS;
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.DELETE;

            END IF;

            IF NOT LCPKS_LCDTRONL_MAIN.FN_SYS_LOV_VALS(P_SOURCE,
                                                       P_WRK_LCDTRONL,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN

              DBG('Failed in  Lcpks_Lcdtronl_Main.Fn_Sys_Lov_Vals....');
              RETURN FALSE;
            END IF;

            IF NOT L_VALIDATELIMITS THEN
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS := L_LCTBCONLIMITTYPE;
            END IF;

          END IF;
        END IF;
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
         P_FUNCTION_ID IN ('LCDGUAMD', 'LCDGAMSM', 'LIDGUAMD') THEN
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_CONDITION      := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_CONDITION;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXPIRY_DATE := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXPIRY_DATE;

        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AUTO_EXTN_PERIOD         := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AUTO_EXTN_PERIOD;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXTN_DETAILS             := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXTN_DETAILS;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FINAL_EXPIRY_DATE        := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FINAL_EXPIRY_DATE;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NOTIFICATION_PERIOD      := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NOTIFICATION_PERIOD;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NON_EXT_NOTIF_DETAILS    := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NON_EXT_NOTIF_DETAILS;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_FINAL_EXP_DATE := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_FINAL_EXP_DATE;

        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_CONTRACT_AMT  := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_CONTRACT_AMT;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXP_TYPE      := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXP_TYPE;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXP_COND      := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXP_COND;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_AUTO_EXTN_PRD := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_AUTO_EXTN_PRD;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXTN_DETAILS  := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXTN_DETAILS;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_NOTIF_PRD     := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_NOTIF_PRD;
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_NOTIF_DETAILS := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_NOTIF_DETAILS;

      END IF;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_HOLD,

                         'DEFAULTDOC',
                         'POPULATELIMIT',
                         'DEFAULTLOCALDET')

     THEN
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_CCY        := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE := P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;

      DBG('count in lctbs_fft is::' || P_LCDTRONL.V_LCTBS_FFTS.COUNT);
      DBG('count for advices is::' ||
          P_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT);
      IF P_SOURCE = 'FCAT' THEN
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE := P_LCDTRONL.V_CONTRACT_EVENT_ADVICE;
        P_WRK_LCDTRONL.V_LCTBS_FFTS            := P_LCDTRONL.V_LCTBS_FFTS;
      END IF;

    ELSIF P_ACTION_CODE IN

          (CSPKS_REQ_GLOBAL.P_MODIFY,
           CSPKS_REQ_GLOBAL.P_ROLLOVER,
           CSPKS_REQ_GLOBAL.P_CLOSE) THEN

      P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE := P_LCDTRONL.V_CONTRACT_EVENT_ADVICE;
      P_WRK_LCDTRONL.V_LCTBS_FFTS            := P_LCDTRONL.V_LCTBS_FFTS;
      P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS      := P_LCDTRONL.V_CSTBS_UI_COLUMNS;
      P_WRK_LCDTRONL.TXN_UDF_DETAILS         := P_LCDTRONL.TXN_UDF_DETAILS;
    END IF;

    DBG('Char_Field92 Values Are : ' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE || '~' ||
        P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 || '~' ||
        P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92);

    IF P_FUNCTION_ID IN
       ('LCDTRONL', 'LCDGUONL', 'LCDGUSIM', 'LIDGUONL', 'LIDTRONL') AND
       NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE, '#') = 'G' THEN
      P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 := NVL(P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92,
                                                            'N');

    ELSIF P_FUNCTION_ID IN ('LCDTRONL') THEN
      DBG('Char_Field92 is defaultted as N');
      P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 := 'N';
    END IF;

    IF P_ACTION_CODE NOT IN
       ('DEFAULTDOC', 'POPULATELIMIT', 'DEFAULTLOCALDET')

     THEN

      DBG('Confirm_Percent ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT);
      DBG('Confirm_Amount ' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT);

      IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
        IF (P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IN
           ('CNF', 'ANC'))

           AND NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
                   'N') = 'N' THEN

          IF P_ACTION_CODE = 'NEW' THEN

            IF P_FUNCTION_ID NOT IN ('LCDGUONL', 'LIDGUONL') THEN
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT,
                      0) <> 100 OR
                 NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                      0) <> NVL(P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY,
                                 0)) THEN
                DBG('Confirm percent is not 100 or confirm amount is not equal to current availability');
                PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-506', NULL);
              END IF;
            END IF;
          ELSIF P_ACTION_CODE = 'MODIFY' THEN
            LO_MX_LC := NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                            0) * (1 + NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                                          0) / 100);
            DBG(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY ||
                ' - ' || LO_MX_LC);
            IF NOT CYPKSS.FN_AMT_ROUND(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                                       LO_MX_LC,
                                       OUT_MX_LC) THEN
              DBG('Failed in Cypkss.Fn_Amt_Round');
              P_ERR_CODE   := 'LC-VALS-006';
              P_ERR_PARAMS := NULL;
              RETURN FALSE;
            END IF;
            DBG('Prev Current Avail:' ||
                P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT);
            DBG('p_Prev_Lcdtronl.v_Lctbs_Contract_Master.Max_Contract_Amt' ||
                P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);
            DBG('Out_Mx_Lc' || OUT_MX_LC);
            IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT,
                    0) <> 100 OR
               (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                     0) <> NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                                 0) AND
               NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                     0) <>
               (NVL(P_PREV_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY,
                      0) +
               (NVL(OUT_MX_LC, 0) - NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                                           0))))) THEN
              DBG('Confirm percent cannot be greater than 100 and Confirm Amount cannot be greater than Current Availability');

              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCUPLD-506', NULL);

            END IF;
          END IF;
        END IF;
      END IF;

      IF P_ACTION_CODE <> CSPKS_REQ_GLOBAL.P_DELETE THEN

        DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Default...');
        IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT(P_SOURCE,
                                               P_SOURCE_OPERATION,
                                               P_FUNCTION_ID,
                                               P_ACTION_CODE,
                                               P_LCDTRONL,
                                               P_PREV_LCDTRONL,
                                               P_WRK_LCDTRONL,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN

          DBG('Failed Lcpks_Lcdtronl_Utils.Fn_Default..');
          RETURN FALSE;
        END IF;

        IF L_SWIFT2020_ENABLED = 'Y' AND
           P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
          BEGIN
            SELECT *
              INTO L_PRODUCT_REC
              FROM LCTMS_PRODUCT_DEFINITION
             WHERE PRODUCT_CODE =

                   SUBSTR(P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO, 4, 4);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('No data found');
          END;
          DBG('defaulting claim date here');
          DBG('l_Product_Rec.Product_Type-->' ||
              L_PRODUCT_REC.PRODUCT_TYPE);
          IF L_PRODUCT_REC.PRODUCT_TYPE = 'G' OR
             (L_PRODUCT_REC.PRODUCT_TYPE = 'E' AND
             NVL(L_PRODUCT_REC.ADVICE_OF_GUARANTEE, 'N') = 'Y') THEN
            DBG('in here');
            IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_DATE IS NULL AND
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE <>
               'PAD' THEN
              DBG('Claim date not inputted. Guarantee expiry date will be defaulted as claim date');
              P_ERR_CODE   := 'LC-VALS-551';
              P_ERR_PARAMS := NULL;
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           P_ERR_CODE,
                           P_ERR_PARAMS);
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_DATE := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE;
            END IF;
          END IF;
          DBG('claim date 1111' ||
              P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_DATE);
        END IF;

        DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Set_Event_And_Seq_No...');
        IF NOT LCPKS_LCDTRONL_UTILS.FN_SET_EVENT_AND_SEQ_NO(P_SOURCE,
                                                            P_SOURCE_OPERATION,
                                                            P_FUNCTION_ID,
                                                            P_ACTION_CODE,
                                                            P_LCDTRONL,
                                                            P_PREV_LCDTRONL,
                                                            P_WRK_LCDTRONL,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN

          DBG('Failed in Setting Lcpks_Lcdtronl_Utils.Fn_Set_Event_And_Seq_No...');
          RETURN FALSE;
        END IF;

        IF P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT > 0 THEN

          IF P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT > 0 THEN
            FOR L_ADVINDEX IN 1 .. P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT LOOP
              L_FFTSLNO := 1;
              FOR L_FFTINDEX IN 1 .. P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT LOOP
                IF P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(L_ADVINDEX)
                 .MSG_TYPE = P_WRK_LCDTRONL.V_LCTBS_FFTS(L_FFTINDEX)
                   .MESG_TYPE THEN
                  P_WRK_LCDTRONL.V_LCTBS_FFTS(L_FFTINDEX).FFT_INS_SL_NO := L_FFTSLNO;
                  L_FFTSLNO := L_FFTSLNO + 1;
                END IF;
              END LOOP;
            END LOOP;
          END IF;
        END IF;

      END IF;

      IF P_ACTION_CODE <> CSPKS_REQ_GLOBAL.P_HOLD

         AND ((SUBSTR(LCPKS_LCDTRONL_MAIN.FN_GET_ORIGINAL_ACTION,

                      1,
                      LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) <>
         CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP

         ) OR (SUBSTR(LIPKS_LIDTRONL_MAIN.FN_GET_ORIGINAL_ACTION,
                           1,
                           LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) <>
         CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)

         OR (SUBSTR(LCPKS_LCDGUONL_MAIN.FN_GET_ORIGINAL_ACTION,
                         1,
                         LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) <>
         CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP) OR
         (SUBSTR(LIPKS_LIDGUONL_MAIN.FN_GET_ORIGINAL_ACTION,
                      1,
                      LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) <>
         CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP))

       THEN
        DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Validate...');
        IF NOT LCPKS_LCDTRONL_UTILS.FN_VALIDATE(P_SOURCE,
                                                P_FUNCTION_ID,
                                                P_ACTION_CODE,
                                                P_LCDTRONL,
                                                P_PREV_LCDTRONL,
                                                P_WRK_LCDTRONL,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS) THEN

          DBG('Failed in the validate of the  Lcpks_Lcdtronl_Utils.validate...');
          RETURN FALSE;
        END IF;

      ELSIF P_ACTION_CODE = 'NEW' THEN
        DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Validate_Limits...');
        IF NOT LCPKS_LCDTRONL_UTILS.FN_VALIDATE_LIMITS(P_SOURCE,
                                                       P_FUNCTION_ID,
                                                       P_ACTION_CODE,
                                                       P_LCDTRONL,
                                                       P_PREV_LCDTRONL,
                                                       P_WRK_LCDTRONL,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN
          DBG('Failed in the validate of the  Lcpks_Lcdtronl_Utils.Fn_Validate_Limits...');
          RETURN FALSE;
        END IF;

      END IF;

      DBG('Calling the Lcpks_Lcdtronl_Utils.Fn_Validate_Eventcode..');
      IF NOT LCPKS_LCDTRONL_UTILS.FN_VALIDATE_EVENTCODE(P_SOURCE,
                                                        P_FUNCTION_ID,
                                                        P_ACTION_CODE,
                                                        P_LCDTRONL,
                                                        P_PREV_LCDTRONL,
                                                        P_WRK_LCDTRONL,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN

        DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Validate_Eventcode');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      DBG('inside lcdtronl' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
      SELECT COUNT(*)
        INTO L_UNAUTH_COUNT
        FROM LCTBS_TRANSFER_DETAILS
       WHERE TO_LCREF = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND AUTH_STATUS = 'U';
      DBG('l_Unauth_count' || L_UNAUTH_COUNT);
      IF L_UNAUTH_COUNT > 0 THEN
        BEGIN
          SELECT TRANSFER_AMT,

                 POSITIVE_TOLERANCE,
                 NEGATIVE_TOLERANCE,

                 NEW_EXPIRY_DATE,
                 PERIOD_FOR_PRESENTATION,
                 NEW_LATEST_SHIPMENT_DATE
            INTO L_TRNF_AMT,

                 L_POS_TOL,
                 L_NEG_TOL,

                 L_EXPIRY_DATE,
                 L_PERIOD_FOR_PRESENTATION,
                 L_LATEST_SHIPMENT_DATE
            FROM LCTB_TRANSFER_DETAILS
           WHERE TO_LCREF =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('failed in selectind details from lctb_transfer_details');
        END;
        IF L_TRNF_AMT <>
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT THEN
          DBG('Contract amount cannot be different from the transferred amount');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-060', NULL);

        END IF;
        DBG('l_expiry_date' || L_EXPIRY_DATE);
        DBG('p_wrk_lcdtronl.v_lctbs_contract_master.expiry_date' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        DBG('p_lcdtronl.v_lctbs_contract_master.expiry_date' ||
            P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE);
        IF L_EXPIRY_DATE <>
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE THEN
          DBG('Expiry date cannot be modified for child LC');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-063', NULL);

        END IF;

        IF NVL(L_PERIOD_FOR_PRESENTATION, 0) <>
           NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION,
               0)

         THEN
          DBG('Period of presentation cannot be modified for child LC');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-061', NULL);

        END IF;
        DBG('dateee' ||
            P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE);

        DBG('p_wrk_lcdtronl.v_lctbs_shipment.latest_shipment_date' ||
            P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE);
        DBG('p_lcdtronl.v_lctbs_shipment.latest_shipment_date' ||
            P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE);

        IF NVL(L_LATEST_SHIPMENT_DATE,
               TO_DATE('01-JAN-1800', 'DD-MON-YYYY')) <>
           NVL(P_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE,
               TO_DATE('01-JAN-1800', 'DD-MON-YYYY'))

         THEN
          DBG('Latest shipment date cannot be modified for child LC');

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-062', NULL);

        END IF;

        IF NVL(L_POS_TOL, 0) <>
           NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE, 0)

         THEN
          DBG('there is mismatch in the positive tolerance');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-064', NULL);

        END IF;

        IF NVL(L_NEG_TOL, 0) <>
           NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE, 0)

         THEN
          DBG('there is mismatch in the negative tolerance');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-TRNF-065', NULL);
        END IF;

      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_HOLD) THEN
      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_DATE IS NOT NULL THEN
        DBG('Amendment Date should not be Entered');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-125', NULL);
      END IF;
    END IF;

    IF NOT
        (P_FUNCTION_ID IN ('LCDAMEND', 'LIDAMEND', 'LCDGUAMD', 'LIDGUAMD') AND
        P_SOURCE_OPERATION = 'LCDTRONL_SUBSYSPKP_MODIFY') THEN
      IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'R' THEN
        DBG('Product Type to be set back to import');
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'I';
      ELSIF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'A' THEN
        DBG('Product Type to be set back to Advice of Guarantee');
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'E';

      ELSIF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'B' THEN
        DBG('Product Type to be set back to Advice of Guarantee');
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'E';

      END IF;
    END IF;
    DBG('p_Wrk_Lcdtronl.v_Cstbs_Contract.Product_type' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE);

    IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT LOOP
        P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I).DOC_SL_NO := I;
        L_SL_NO := 0;
        IF P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT > 0 THEN
          FOR J IN 1 .. P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT LOOP
            IF P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
             .DOC_CODE = P_WRK_LCDTRONL.V_LCTBS_CLAUSES(J).DOC_CODE THEN
              DBG('doc.doc_code' || P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
                  .DOC_CODE);
              DBG('clause.doc_code' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(J)
                  .DOC_CODE);
              DBG('clause.clause_code' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(J)
                  .CLAUSE_CODE);
              L_SL_NO := L_SL_NO + 1;
              P_WRK_LCDTRONL.V_LCTBS_CLAUSES(J).CLAUSE_SL_NO := L_SL_NO;
              DBG('clause_serial_no' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(J)
                  .CLAUSE_SL_NO);
            END IF;
          END LOOP;
        END IF;
        DBG('doc_serial_no' || P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(I)
            .DOC_SL_NO);
      END LOOP;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('Count:' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT);
      IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT LOOP
          DBG('chk GOODS_CODE:' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
              .GOODS_CODE);
          DBG('chk UNITS:' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
              .NO_OF_UNITS);
          DBG('chk PRICE:' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
              .PRICE_PER_UNIT);
          L_TOT_GOODS_AMT := L_TOT_GOODS_AMT + (P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                             .NO_OF_UNITS * P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                             .PRICE_PER_UNIT);
          DBG('l_tot_goods_amt:::' || L_TOT_GOODS_AMT);
        END LOOP;

        DBG('LC_amt ' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT);
        IF NVL(L_TOT_GOODS_AMT, 0) > 0 AND
           NVL(L_TOT_GOODS_AMT, 0) <>
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT THEN
          DBG('LC Contract amount and Total goods amount has to be equal');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LC-VALS-568', NULL);
        END IF;

      END IF;
      P_WRK_LCDTRONL.V_CSTB_UI_COLUMNS__GOODS.NUM_FIELD20 := L_TOT_GOODS_AMT;
    END IF;

    DBG('Returning Success from fn_post_default_and_validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_post_default_and_validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DEFAULT_AND_VALIDATE;

  FUNCTION FN_PRE_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_LCDTRONL         IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    DBG('In Fn_Pre_Resolve_Ref_Numbers..');

    DBG('Returning from Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_RESOLVE_REF_NUMBERS;
  FUNCTION FN_POST_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_LCDTRONL         IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_BRANCHCODE  STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_PRODUCTCODE VARCHAR2(4);
    L_DATE        DATE;
    L_SERIAL      VARCHAR2(10);

  BEGIN
    DBG('In Fn_Post_Resolve_Ref_Numbers..');

    DBG('p_source_operation ' || P_SOURCE_OPERATION);
    DBG('p_action_code ' || P_ACTION_CODE);

    IF P_ACTION_CODE LIKE 'SUBSYSPKP_%' OR
       P_ACTION_CODE IN ('HOLD', 'NEW', 'MODIFY') THEN
      G_ACTION_L := TRUE;
    END IF;

    IF P_SOURCE <> 'FLEXCUBE' AND
       P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_HOLD)

     THEN

      DBG('p_Lcdtronl.v_cstbs_contract.CONTRACT_REF_NO: ' ||
          P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
      IF P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO IS NULL THEN

        IF NOT LCPKS_LCDTRONL_UTILS.FN_GENERATE_REF_NO(P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                       P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                       P_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS)

         THEN
          DBG('Failed  in the Resolve ref no of Utils');
          RETURN FALSE;
        END IF;

      ELSE
        DBG('Going to validate the given Contract ref no: ' ||
            P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
        IF NOT TRPKS.FN_SPLIT_REFNO(P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                    L_BRANCHCODE,
                                    L_PRODUCTCODE,
                                    L_DATE,
                                    L_SERIAL,
                                    P_ERR_CODE) THEN
          DBG('Failed  in trpks.fn_split_refno');
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
        DBG('l_branchcode: ' || L_BRANCHCODE);
        DBG('l_productcode: ' || L_PRODUCTCODE);
        DBG('l_date: ' || L_DATE);
        DBG('l_serial: ' || L_SERIAL);
        IF L_BRANCHCODE <> GLOBAL.CURRENT_BRANCH THEN
          DBG('Error: TR-12002: Invalid Branch Code in the given Reference Number.');
          P_ERR_CODE   := 'TR-12002';
          P_ERR_PARAMS := L_BRANCHCODE || '~' ||
                          P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          RETURN FALSE;
        END IF;
        IF L_PRODUCTCODE <> P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE THEN
          DBG('Error: TR-12003: Invalid Product Code in the given Reference Number.');
          P_ERR_CODE   := 'TR-12003';
          P_ERR_PARAMS := L_PRODUCTCODE || '~' ||
                          P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          RETURN FALSE;
        END IF;
      END IF;

      IF P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE IS NULL THEN
        BEGIN
          SELECT PRODUCT_TYPE
            INTO P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE
            FROM LCTM_PRODUCT_DEFINITION
           WHERE PRODUCT_CODE = P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In When Others when Selecting Product_Type ' || SQLERRM);
            RETURN FALSE;
        END;
      END IF;
      DBG('Product_type## ' || P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE);

    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
      IF NOT LCPKS_LCDTRONL_UTILS.FN_RESOLVE_REF_NO(P_SOURCE,
                                                    P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                                    P_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO,
                                                    P_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN

        DBG('Failed  in the Resolve ref no of Utils');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Contract_Ref_No 3 :: ' ||
        P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);

    DBG('Returning from Fn_Post_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Main.Fn_Post_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_RESOLVE_REF_NUMBERS;
  FUNCTION FN_PRE_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In fn_pre_Product_Default');

    P_WRK_LCDTRONL := P_LCDTRONL;

    DBG('Returning Success from fn_pre_Product_Default');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PRODUCT_DEFAULT;

  FUNCTION FN_POST_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_PROD_REC           CSTMS_PRODUCT%ROWTYPE;
    L_PRODUCT_DEFINITION LCTMS_PRODUCT_DEFINITION%ROWTYPE;
    L_COUNT              NUMBER := 0;
    L_PREV_LCDTRONL      LCPKS_LCDTRONL_MAIN.TY_LCDTRONL;
    L_ACTION_CODE        VARCHAR2(20);

  BEGIN
    DBG('In fn_Post_Product_Default');

    L_ACTION_CODE := 'PRDDFLT';
    DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Get_Product_Details');
    IF NOT LCPKS_LCDTRONL_UTILS.FN_GET_PRODUCT_DETAILS(P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_CODE,
                                                       L_PROD_REC,
                                                       L_PRODUCT_DEFINITION,
                                                       L_ACTION_CODE,
                                                       P_FUNCTION_ID,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Get_Product_Details ...');
      RETURN FALSE;
    END IF;

    DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Master' || L_ACTION_CODE);
    IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_MASTER(P_SOURCE,
                                                  P_SOURCE_OPERATION,
                                                  P_FUNCTION_ID,
                                                  L_ACTION_CODE,
                                                  L_PRODUCT_DEFINITION,
                                                  P_LCDTRONL,
                                                  L_PREV_LCDTRONL,
                                                  P_WRK_LCDTRONL,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Master ...');
      RETURN FALSE;
    END IF;

    DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Default_Documents_Clauses..');
    IF NOT
        LCPKS_LCDTRONL_UTILS.FN_DEFAULT_DOCUMENTS_CLAUSES(P_SOURCE,
                                                          P_FUNCTION_ID,
                                                          L_ACTION_CODE,
                                                          L_PRODUCT_DEFINITION,
                                                          P_LCDTRONL,
                                                          L_PREV_LCDTRONL,
                                                          P_WRK_LCDTRONL,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Documents and Clauses.. ...');
      RETURN FALSE;
    END IF;
    DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Default_Tracers');
    IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_TRACERS(P_SOURCE,
                                                   P_FUNCTION_ID,
                                                   L_ACTION_CODE,
                                                   L_PRODUCT_DEFINITION,
                                                   P_LCDTRONL,
                                                   L_PREV_LCDTRONL,
                                                   P_WRK_LCDTRONL,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Tracers ...');
      RETURN FALSE;
    END IF;

    DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Default_Ship_Docs..');
    IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_SHIP_DOCS(P_SOURCE,
                                                     P_FUNCTION_ID,
                                                     P_ACTION_CODE,
                                                     L_PRODUCT_DEFINITION,
                                                     P_LCDTRONL,
                                                     P_WRK_LCDTRONL,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Parties ...');
      RETURN FALSE;
    END IF;

    DBG('Calling cpks_Lcdtronl_Utils.Fn_Default_Goods');
    IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT_GOODS(P_SOURCE,
                                                 P_SOURCE_OPERATION,
                                                 P_FUNCTION_ID,
                                                 L_ACTION_CODE,
                                                 L_PRODUCT_DEFINITION,
                                                 P_LCDTRONL,
                                                 L_PREV_LCDTRONL,
                                                 P_WRK_LCDTRONL,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default_Goods ...');
      RETURN FALSE;
    END IF;

    DBG('In Fn_Default_parties..' || L_PRODUCT_DEFINITION.PRODUCT_TYPE);
    IF P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT = 0 THEN
      IF L_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('E') THEN
        L_COUNT := L_COUNT + 1;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).EVENT_SEQ_NO := 1;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).PARTY_TYPE := 'APP';

        L_COUNT := L_COUNT + 1;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).EVENT_SEQ_NO := 1;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).PARTY_TYPE := 'BEN';

        L_COUNT := L_COUNT + 1;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).EVENT_SEQ_NO := 1;
        P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).PARTY_TYPE := 'ISB';

      ELSIF L_PRODUCT_DEFINITION.PRODUCT_TYPE IN ('I', 'C', 'S', 'H', 'G') THEN

        IF L_PRODUCT_DEFINITION.REIMBURSEMENT = 'Y' THEN

          L_COUNT := L_COUNT + 1;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).EVENT_SEQ_NO := 1;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).PARTY_TYPE := 'ISB';
        ELSE

          L_COUNT := L_COUNT + 1;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).EVENT_SEQ_NO := 1;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).PARTY_TYPE := 'APP';

          L_COUNT := L_COUNT + 1;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).EVENT_SEQ_NO := 1;
          P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).PARTY_TYPE := 'BEN';

          IF L_PRODUCT_DEFINITION.PRODUCT_TYPE <> 'H' THEN --sampath

            L_COUNT := L_COUNT + 1;
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).EVENT_SEQ_NO := 1;
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_COUNT).PARTY_TYPE := 'ABK';
          END IF;
        END IF;
      END IF;
    END IF;

    DBG('Stetting up the status of subsystem');

    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT := 'MICTRMIS:D;ISCTRSTL:D;TACTRTAX:D;CSCTRUDF:D;CFCTRCHG:D;CFCTRCOM:D;CVS_MAIN__TAB_ADVICES:D;LCCTRCLT:D;BCCBRDET:D;LCCILUTL:D;CSCTRSPT:D;BCCTRPRF:D;MSCCOMPM:D;';

    IF L_PRODUCT_DEFINITION.PRODUCT_TYPE = 'I' AND
       L_PRODUCT_DEFINITION.REIMBURSEMENT = 'Y' THEN
      DBG('Product Type to be set as reimbursement');
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'R';
    ELSIF L_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
          L_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE = 'Y' THEN
      DBG('Product Type to be set as Advice of Guarantee');
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'A';

    ELSIF L_PRODUCT_DEFINITION.PRODUCT_TYPE = 'E' AND
          L_PRODUCT_DEFINITION.ADVICE_OF_STANDBYLC = 'Y' THEN
      DBG('Product Type to be set as Advice of StandbyLC');
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'B';

    END IF;
    DBG('p_Wrk_Lcdtronl.v_Cstbs_Contract.Product_type' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE);

    P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_CONTRACT_MASTER')(1)('SWIFT_PARAM') := LCPKS_UTILS.FN_GET_SWIFT_PARAM;
    DBG('swift param::' ||
        P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_CONTRACT_MASTER') (1)
        ('SWIFT_PARAM'));

    DBG('Returning Success from fn_Post_Product_Default');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_Post_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PRODUCT_DEFAULT;

  FUNCTION FN_PRE_UNLOCK(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN OUT VARCHAR2,
                         P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    DBG('In fn_pre_Unlock');

    DBG('Returning Success from fn_pre_Unlock');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UNLOCK;

  FUNCTION FN_POST_UNLOCK(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN OUT VARCHAR2,
                          P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('In fn_Post_Unlock');

    IF NOT LCPKS_LCDTRONL_UTILS.FN_UNLOCK(P_SOURCE,
                                          P_FUNCTION_ID,
                                          P_ACTION_CODE,
                                          P_LCDTRONL,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Unlock ...');
      RETURN FALSE;
    END IF;

    DBG('Returning Success from fn_Post_Unlock');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_Post_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UNLOCK;

  FUNCTION FN_PRE_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    DBG('In fn_pre_Subsys_Pickup');

    DBG('Returning Success from fn_pre_Subsys_Pickup');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_SUBSYS_PICKUP;

  FUNCTION FN_POST_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_ACT_ACTION    VARCHAR2(20);
    L_MULTI_TRIP_ID VARCHAR2(20);

    L_COUNT      NUMBER := 0;
    L_TYPE       VARCHAR2(1);
    L_ERROR_CODE VARCHAR2(255);

  BEGIN
    DBG('In fn_Post_Subsys_Pickup');

    L_ACT_ACTION := P_ACTION_CODE;
    DBG('l_Act_Action' || L_ACT_ACTION);

    IF (SUBSTR(LCPKS_LCDTRONL_MAIN.FN_GET_ORIGINAL_ACTION,
               1,
               LENGTH(CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP)) =
       CSPKS_REQ_GLOBAL.P_SUBSYSPICKUP) OR
       LCPKS_LCDTRONL_KERNEL.ISCHILDFUNCTION THEN
      DBG('Calling Lcpks_Lcdtronl_Main.Fn_Default_And_Validate...');
      IF NOT LCPKS_LCDTRONL_MAIN.FN_DEFAULT_AND_VALIDATE(P_SOURCE,
                                                         P_SOURCE_OPERATION,
                                                         P_FUNCTION_ID,
                                                         L_ACT_ACTION,
                                                         P_LCDTRONL,
                                                         P_PREV_LCDTRONL,
                                                         P_WRK_LCDTRONL,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN

        DBG('Failed in the Lcpks_Lcdtronl_Main.Fn_Default_And_Validate...');
        RETURN FALSE;
      END IF;

      DBG('Calling Lcpks_Lcdtronl_Main.Fn_Upload_Db...');
      IF NOT LCPKS_LCDTRONL_MAIN.FN_UPLOAD_DB(P_SOURCE,
                                              P_SOURCE_OPERATION,
                                              P_FUNCTION_ID,
                                              L_ACT_ACTION,
                                              L_MULTI_TRIP_ID,
                                              P_LCDTRONL,
                                              P_PREV_LCDTRONL,
                                              P_WRK_LCDTRONL,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN

        DBG('Failed in Lcpks_Lcdtronl_Main.Fn_Upload_Db...');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Subsys_Pickup...');
    IF NOT LCPKS_LCDTRONL_UTILS.FN_SUBSYS_PICKUP(P_SOURCE,
                                                 P_SOURCE_OPERATION,
                                                 P_FUNCTION_ID,
                                                 L_ACT_ACTION,
                                                 P_LCDTRONL,
                                                 P_PREV_LCDTRONL,
                                                 P_WRK_LCDTRONL,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Subsys_Pickup ...');
      RETURN FALSE;
    END IF;

    DBG('p_Action_Code--->' || P_ACTION_CODE);
    DBG('p_Lcdtronl.v_Cstbs_Ui_Columns.Char_Field1--->' ||
        P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1);
    DBG('Lcpks_Lcdtronl_Main.Fn_Get_Original_Action --> ' ||
        LCPKS_LCDTRONL_MAIN.FN_GET_ORIGINAL_ACTION);
    IF P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 IN ('LCDAMEND') AND
       LCPKS_LCDTRONL_MAIN.FN_GET_ORIGINAL_ACTION IN ('SUBSYSPKP_MODIFY') THEN
      L_COUNT := OVPKS.GL_TBLERROR.COUNT;
      DBG('l_Count-->' || L_COUNT);
      IF L_COUNT > 0 THEN
        FOR I IN OVPKS.GL_TBLERROR.FIRST .. OVPKS.GL_TBLERROR.LAST LOOP
          L_ERROR_CODE := OVPKS.GL_TBLERROR(I).ERR_CODE;
          DBG('l_Error_Code--->' || L_ERROR_CODE);
          L_TYPE := OVPKSS.FN_GETTYPE(TRIM(REPLACE(L_ERROR_CODE, '~', '')));
          DBG('l_Type-->' || L_TYPE);
          IF L_TYPE = 'E' THEN
            DBG('error type E is found');
            EXIT;
          END IF;
        END LOOP;
      END IF;
      DBG('L_TYPE-->' || L_TYPE);
      IF L_TYPE <> 'E' THEN
        DBG('no errors during susbystem pickup on confirm action.Hence initializing error table');
        OVPKS.PR_INITERRTBL;
      END IF;
    END IF;

    DBG('Returning Success from fn_Post_Subsys_Pickup');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_Post_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_SUBSYS_PICKUP;

  FUNCTION FN_PRE_ENRICH(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                         P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                         P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    DBG('In fn_pre_Enrich');

    DBG('Returning Success from fn_pre_Enrich');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_ENRICH;

  FUNCTION FN_POST_ENRICH(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                          P_PREV_LCDTRONL    IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                          P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_BLK VARCHAR2(50);
    L_FLD VARCHAR2(50);

  BEGIN
    DBG('In fn_Post_Enrich');

    P_WRK_LCDTRONL := P_LCDTRONL;

    L_BLK := 'LCTBS_CONTRACT_MASTER';
    L_FLD := 'LCTBS_CONTRACT_MASTER.CONTRACT_CCY';
    IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY IS NULL THEN
      DBG('Mandatory column contract_ccy cannot be Null');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   P_SOURCE,
                   'ST-MAND-005',
                   '@' || L_FLD || '~@' || L_BLK);
      RETURN FALSE;
    END IF;
    L_FLD := 'LCTBS_CONTRACT_MASTER.CONTRACT_AMT';
    IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT IS NULL THEN
      DBG('Mandatory column contract_amt cannot be Null');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   P_SOURCE,
                   'ST-MAND-005',
                   '@' || L_FLD || '~@' || L_BLK);
      RETURN FALSE;
    END IF;
    L_FLD := 'LCTBS_CONTRACT_MASTER.OPERATION_CODE';
    IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE IS NULL THEN
      DBG('Mandatory column operation_code cannot be Null');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   P_SOURCE,
                   'ST-MAND-005',
                   '@' || L_FLD || '~@' || L_BLK);
      RETURN FALSE;
    END IF;

    L_FLD := 'LCTBS_CONTRACT_MASTER.CIF_ID';
    IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID IS NULL THEN
      DBG('Mandatory column cif_id cannot be Null');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   P_SOURCE,
                   'ST-MAND-005',
                   '@' || L_FLD || '~@' || L_BLK);
      RETURN FALSE;
    END IF;

    L_FLD := 'LCTBS_CONTRACT_MASTER.CUST_TYPE';
    IF P_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE = 'S' AND
       P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE IS NULL THEN
      DBG('The Party Cannot Be null for the Stand By Product');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   P_SOURCE,
                   'ST-MAND-005',
                   '@' || L_FLD || '~@' || L_BLK);
      RETURN FALSE;
    END IF;

    DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Validate_Default...' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
    IF NOT LCPKS_LCDTRONL_UTILS.FN_VALIDATE_DEFAULT(P_SOURCE,
                                                    P_SOURCE_OPERATION,
                                                    P_FUNCTION_ID,
                                                    P_ACTION_CODE,
                                                    P_LCDTRONL,
                                                    P_PREV_LCDTRONL,
                                                    P_WRK_LCDTRONL,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Validate_Default ...');
      RETURN FALSE;
    END IF;

    DBG('Calling cpks_Lcdtronl_Utils.Fn_Default');
    IF NOT LCPKS_LCDTRONL_UTILS.FN_DEFAULT(P_SOURCE,
                                           P_SOURCE_OPERATION,
                                           P_FUNCTION_ID,
                                           P_ACTION_CODE,
                                           P_LCDTRONL,
                                           P_PREV_LCDTRONL,
                                           P_WRK_LCDTRONL,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN

      DBG('Failed in Lcpks_Lcdtronl_Utils.Fn_Default ...');
      RETURN FALSE;
    END IF;

    DBG('p_Wrk_Lcdtronl.v_Lctbs_Drafts.Count::' ||
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT);
    IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
      FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT LOOP
        DBG('p_wrk_lcdtronl.v_lctbs_contract_master.CONTRACT_CCY:;' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY);
        P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_DRAFTS')(I)('DRFTCCY') := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
        DBG('DRFTCCY::' || P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_DRAFTS') (I)
            ('DRFTCCY'));
      END LOOP;
    END IF;

    DBG('Returning Success from fn_Post_Enrich');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_Post_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_ENRICH;

  FUNCTION FN_PRE_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_CHILD_FUNCTION   IN VARCHAR2,
                            P_MULTI_TRIP_ID    IN VARCHAR2,
                            P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_PREV_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    DBG('In fn_pre_upload_db');

    IF P_SOURCE = 'FCAT' THEN
      P_WRK_LCDTRONL.V_CSTBS_CONTRACT.SOURCE := P_SOURCE;
    END IF;

    DBG('Returning Success from fn_pre_upload_db');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_upload_db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UPLOAD_DB;

  FUNCTION FN_POST_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_MULTI_TRIP_ID    IN VARCHAR2,
                             P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_PREV_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT                   NUMBER := 0;
    L_INS_COUNT               NUMBER := 0;
    L_UPD_COUNT               NUMBER := 0;
    L_DEL_COUNT               NUMBER := 0;
    L_WRK_COUNT               NUMBER := 0;
    L_PREV_COUNT              NUMBER := 0;
    L_REC_FOUND               BOOLEAN := FALSE;
    L_ROW_ID                  ROWID;
    I_V_LCTBS_PARTIES         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_PARTIES;
    U_V_LCTBS_PARTIES         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_PARTIES;
    D_V_LCTBS_PARTIES         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_PARTIES;
    I_V_LCTBS_OTHER_ADDRESSES LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_OTHER_ADDRESSES;
    U_V_LCTBS_OTHER_ADDRESSES LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_OTHER_ADDRESSES;
    D_V_LCTBS_OTHER_ADDRESSES LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_OTHER_ADDRESSES;
    I_V_LCTBS_DOCUMENTS       LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DOCUMENTS;
    U_V_LCTBS_DOCUMENTS       LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DOCUMENTS;
    D_V_LCTBS_DOCUMENTS       LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DOCUMENTS;
    I_V_LCTBS_CLAUSES         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_CLAUSES;
    U_V_LCTBS_CLAUSES         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_CLAUSES;
    D_V_LCTBS_CLAUSES         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_CLAUSES;
    I_V_LCTBS_TRACERS         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_TRACERS;
    U_V_LCTBS_TRACERS         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_TRACERS;
    D_V_LCTBS_TRACERS         LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_TRACERS;
    I_V_LCTBS_DRAFTS          LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DRAFTS;
    U_V_LCTBS_DRAFTS          LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DRAFTS;
    D_V_LCTBS_DRAFTS          LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DRAFTS;
    I_V_LCTBS_DRAFTS_DETAILS  LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DRAFTS_DETAILS;
    U_V_LCTBS_DRAFTS_DETAILS  LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DRAFTS_DETAILS;
    D_V_LCTBS_DRAFTS_DETAILS  LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_DRAFTS_DETAILS;
    L_APP_DATE                DATE := GLOBAL.APPLICATION_DATE;
    L_LCTBS_AVAILAMENTS       LCTB_AVAILMENTS%ROWTYPE;
    L_MODULE                  SMTB_MENU.MODULE%TYPE;
    U_V_LCTBS_FFTS            LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_FFTS;
    I_V_LCTBS_FFTS            LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_FFTS;
    D_V_LCTBS_FFTS            LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_FFTS;

    I_V_LCTBS_CONTRACT_LIMITS LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_CONTRACT_LIMITS;
    U_V_LCTBS_CONTRACT_LIMITS LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_CONTRACT_LIMITS;
    D_V_LCTBS_CONTRACT_LIMITS LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_CONTRACT_LIMITS;

    L_CON_REF          VARCHAR2(1000);
    L_EVENT_DATE       CSTB_CONTRACT_EVENT_LOG.EVENT_DATE%TYPE;
    L_CONTRACT_REMARKS CSTB_CONTRACT_REMARKS%ROWTYPE;

    L_SK_ARGMNT_CNT         NUMBER;
    I_V_LCTBS_GOODS_DETAILS LCPKS_LCDTRONL_MAIN.TY_TB_V_GOODS_DETAILS__DETAIL;
    U_V_LCTBS_GOODS_DETAILS LCPKS_LCDTRONL_MAIN.TY_TB_V_GOODS_DETAILS__DETAIL;
    D_V_LCTBS_GOODS_DETAILS LCPKS_LCDTRONL_MAIN.TY_TB_V_GOODS_DETAILS__DETAIL;

    I_V_LCTBS_TERMS_CONDITIONS LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_TERMS_CONDITIONS;
    U_V_LCTBS_TERMS_CONDITIONS LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_TERMS_CONDITIONS;
    D_V_LCTBS_TERMS_CONDITIONS LCPKS_LCDTRONL_MAIN.TY_TB_V_LCTBS_TERMS_CONDITIONS;

    L_CONTRACT_COUNT NUMBER := 0;

    L_ACONCOUNT NUMBER := 0;

  BEGIN

    DBG('In fn_post_upload_db');

    IF NOT LCPKS_UPLOAD_UTILS.FN_DATETIME(L_APP_DATE) THEN

      DBG('Failed in lcpks_upload_utils.fn_datetime');
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) AND
       NVL(CSPKS_REQ_WRAPPER.G_FUNCTION_ID, '**') IN ('LCDTRONL') THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_CONTRACT_COUNT
          FROM CSTBS_CONTRACT
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND BRANCH = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.BRANCH
           AND CONTRACT_STATUS = 'A'
           AND AUTH_STATUS = 'A';
      EXCEPTION
        WHEN OTHERS THEN
          L_CONTRACT_COUNT := 0;
      END;
    END IF;

    DBG('Calling fn_log_contract_remarks FOR ' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO || '~' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO);
    DBG('Calling fn_log_contract_remarks FOR ' ||
        P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO || '~' ||
        P_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO);
    L_CONTRACT_REMARKS.CONTRACT_REF_NO := P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    L_CONTRACT_REMARKS.EVENT_SEQ_NO    := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO;

    IF (CSPKS_REQ_WRAPPER.G_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
       P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO IS NOT NULL) THEN
      BEGIN
        SELECT MAKER_ID, MAKER_DT_STAMP, REMARKS
          INTO L_CONTRACT_REMARKS.INPUT_BY,
               L_CONTRACT_REMARKS.INPUT_DATE,
               L_CONTRACT_REMARKS.REMARKS
          FROM LCTB_REG_MASTER
         WHERE ACKREFNO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('LC', 'Failed in selection Registration remarks');
          NULL;
      END;
      L_CONTRACT_REMARKS.EVENT_CODE := 'REGN';
      IF NOT CSPKS_CSCREMKS_KERNEL.FN_LOG_CONTRACT_REMARKS(L_CONTRACT_REMARKS,
                                                           NVL(CSPKS_REQ_WRAPPER.G_ACTION_CODE,
                                                               P_ACTION_CODE),
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
        DBG('failed in fn_log_contract_remarks for registration...');
      END IF;
    END IF;
    L_CONTRACT_REMARKS.EVENT_CODE                  := P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.EVENT_CODE;
    L_CONTRACT_REMARKS.INPUT_BY                    := GLOBAL.USER_ID;
    L_CONTRACT_REMARKS.INPUT_DATE                  := L_APP_DATE;
    L_CONTRACT_REMARKS.REMARKS                     := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REMARKS;
    P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REMARKS := P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REMARKS;
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_REOPEN,
                         CSPKS_REQ_GLOBAL.P_ROLLOVER) THEN
      UPDATE LCTB_CONTRACT_MASTER
         SET REMARKS = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REMARKS

            ,
             ANCILLARY_MESG          = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG,
             ANCILLARY_MESG_FUNCTION = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG_FUNCTION

       WHERE CONTRACT_REF_NO = P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM LCTB_CONTRACT_MASTER
               WHERE CONTRACT_REF_NO =
                     P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
    END IF;
    IF NOT CSPKS_CSCREMKS_KERNEL.FN_LOG_CONTRACT_REMARKS(L_CONTRACT_REMARKS,
                                                         NVL(CSPKS_REQ_WRAPPER.G_ACTION_CODE,
                                                             P_ACTION_CODE),
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
      DBG('failed in fn_log_contract_remarks...');
    END IF;

    DBG('l_Act_Action' || P_ACTION_CODE ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE);

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      BEGIN
        SELECT CHAR_FIELD2
          INTO L_CON_REF
          FROM CSTBS_UI_COLUMNS
         WHERE CHAR_FIELD2 =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        IF (L_CON_REF IS NOT NULL) THEN

          UPDATE CSTBS_UI_COLUMNS
             SET CHAR_FIELD92 = NVL(P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92,
                                    'N')

                ,
                 CHAR_FIELD1 = P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1

           WHERE CHAR_FIELD2 =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          INSERT INTO CSTBS_UI_COLUMNS

            (CHAR_FIELD2, CHAR_FIELD92, CHAR_FIELD1)

          VALUES
            (P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
             NVL(P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92, 'N'),
             P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1);
      END;
      DBG('Char_Field2:::' ||
          P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD2);
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE AND
       P_FUNCTION_ID NOT IN ('LCDAMEND', 'LIDAMEND') THEN

      DBG('checkevent' || P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91);
      BEGIN
        SELECT CHAR_FIELD2
          INTO L_CON_REF
          FROM CSTBS_UI_COLUMNS
         WHERE CHAR_FIELD2 =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        IF (L_CON_REF IS NOT NULL) THEN
          UPDATE CSTBS_UI_COLUMNS
             SET CHAR_FIELD91 = NVL(P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91,
                                    'CLOSE')
           WHERE CHAR_FIELD2 =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('In no data found');
          INSERT INTO CSTBS_UI_COLUMNS
            (CHAR_FIELD2, CHAR_FIELD91)
          VALUES
            (P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
             NVL(P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD91, 'CLOSE'));
      END;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_HOLD) THEN
      DBG('Curr_Event_Code 5' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE);
      DBG('Curr_Event_Code 5' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
      BEGIN
        INSERT INTO CSTB_CONTRACT
        VALUES P_WRK_LCDTRONL.V_CSTBS_CONTRACT
        RETURNING ROWID INTO L_ROW_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in Insert into CSTBS_CONTRACT..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@CSTBS_CONTRACT';
          RETURN FALSE;
        WHEN OTHERS THEN
          DBG('Failed in Insert into CSTBS_CONTRACT..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@CSTBS_CONTRACT';
          RETURN FALSE;
      END;

      BEGIN
        IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO IS NOT NULL AND
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO IS NOT NULL THEN
          DBG('Record Sent..');
          INSERT INTO LCTB_CONTRACT_MASTER
          VALUES P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_CONTRACT_MASTER..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_CONTRACT_MASTER';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_AVAILMENTS..' ||
          P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.EVENT_CODE);

      BEGIN
        IF P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CONTRACT_REF_NO IS NOT NULL AND
           P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.EVENT_SEQ_NO IS NOT NULL THEN
          DBG('Record Sent..');
          INSERT INTO LCTB_AVAILMENTS
          VALUES P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_AVAILMENTS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_AVAILMENTS';
          RETURN FALSE;
      END;

      BEGIN
        SELECT *
          INTO L_LCTBS_AVAILAMENTS
          FROM LCTB_AVAILMENTS
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In when Others....');
      END;

      DBG('Inserting into LCTBS_PARTIES..Count is' ||
          P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT);
      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT;
        IF L_COUNT > 0 THEN
          FOR I IN 1 .. L_COUNT LOOP
            P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).EVENT_SEQ_NO := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;

            IF P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE = 'ABK' THEN
              BEGIN
                SELECT COUNT(*)
                  INTO L_SK_ARGMNT_CNT
                  FROM ISTM_BIC_DIRECTORY
                 WHERE CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                      .CIF_ID
                   AND SK_ARRANGEMENT = 'Y'
                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A';
                DBG('.SK_Argmnt_cnt..' || L_SK_ARGMNT_CNT);
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Inside Exception..' || SQLERRM);
              END;
              IF L_SK_ARGMNT_CNT = 0 THEN
                P_ERR_CODE   := 'LC-VAL-01';
                P_ERR_PARAMS := NULL;
                OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              END IF;
            END IF;

          END LOOP;
        END IF;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_PARTIES
          VALUES P_WRK_LCDTRONL.V_LCTBS_PARTIES
            (L_INDEX);

      EXCEPTION

        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_PARTIES..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_PARTIES';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_OTHER_ADDRESSES..');
      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_OTHER_ADDRESSES
          VALUES P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_OTHER_ADDRESSES..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_OTHER_ADDRESSES';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_DOCUMENTS..');
      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_DOCUMENTS
          VALUES P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_DOCUMENTS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_DOCUMENTS';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_CLAUSES..');
      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_CLAUSES
          VALUES P_WRK_LCDTRONL.V_LCTBS_CLAUSES
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_CLAUSES..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_CLAUSES';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_SHIPMENT..');
      BEGIN

        DBG('Record Sent..');
        INSERT INTO LCTB_SHIPMENT VALUES P_WRK_LCDTRONL.V_LCTBS_SHIPMENT;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_SHIPMENT..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_SHIPMENT';
          RETURN FALSE;
      END;

      DBG('Inserting Into LCTBS_GOODS_DETAILS__DETAIL..');
      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_GOODS_DETAILS
          VALUES P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed In Insert intoLCTBS_GOODS_DETAILS__DETAIL..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_GOODS_DETAILS__DETAIL';
          RETURN FALSE;
      END;

      DBG('Chk contract_ref_no:' ||
          P_LCDTRONL.V_GOODS_DETAILS__MASTER.CONTRACT_REF_NO || '~' ||
          'OTHR event_seq_no:' ||
          P_LCDTRONL.V_GOODS_DETAILS__MASTER.EVENT_SEQ_NO);
      DBG('Count:' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT);
      IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT > 0 THEN
        P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR := NULL;

      END IF;

      DBG('Inserting into LCTBS_GOODS..');
      BEGIN

        IF (P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE IS NOT NULL OR
           P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR IS NOT NULL OR
           P_WRK_LCDTRONL.V_LCTBS_GOODS.INCO_TERM IS NOT NULL) OR
           P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE = 'PAD' THEN

          DBG('Record Sent..');
          INSERT INTO LCTB_GOODS VALUES P_WRK_LCDTRONL.V_LCTBS_GOODS;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_GOODS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_GOODS';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_TRACERS..');
      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_TRACERS
          VALUES P_WRK_LCDTRONL.V_LCTBS_TRACERS
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_TRACERS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_TRACERS';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_DRAFTS..');
      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT;

        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_DRAFTS
          VALUES P_WRK_LCDTRONL.V_LCTBS_DRAFTS
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_DRAFTS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_DRAFTS';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_DRAFTS_DETAILS..');
      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT;
        DBG('Inserting into LCTBS_DRAFTS_DETAILS..' || L_COUNT);
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_DRAFTS_DETAILS
          VALUES P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_DRAFTS_DETAILS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_DRAFTS_DETAILS';
          RETURN FALSE;
      END;
      DBG('Inserting into CSTBS_CONTRACT_EVENT_LOG ' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE);

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT > 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.LAST LOOP
          DELETE FROM LCTB_CONTRACT_LIMITS
           WHERE CONTRACT_REF_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .CONTRACT_REF_NO
             AND EVENT_SEQ_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .EVENT_SEQ_NO
             AND VERSION_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .VERSION_NO
             AND CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .CUSTOMER_NO
             AND PARTY_TYPE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .PARTY_TYPE
             AND LINKED_REF_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .LINKED_REF_NO
             AND LINKAGE_TYPE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .LINKAGE_TYPE;
        END LOOP;
      END IF;

      BEGIN
        L_COUNT := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_CONTRACT_LIMITS
          VALUES P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS
            (L_INDEX);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_contract_limits..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_CONTRACT_LIMITS';
          RETURN FALSE;
      END;

      DBG('Inserting into LCTBS_SPLPYMT_CONDITIONS..');
      IF P_FUNCTION_ID = 'LCDTRONL' OR
         LCPKS_LCDTRONL_KERNEL.ISCHILDFUNCTION THEN
        BEGIN
          DBG('Record Sent..');
          INSERT INTO LCTBS_SPLPYMT_CONDITIONS
          VALUES P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Insert into LCTBS_SPLPYMT_CONDITIONS..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@LCTBS_SPLPYMT_CONDITIONS';
            RETURN FALSE;
        END;
      END IF;

      IF P_FUNCTION_ID IN ('LCDGUONL', 'LIDGUONL', 'LCDGUAMD', 'LIDGUAMD') THEN

        DBG('Inserting terms and conditions');
        BEGIN
          L_COUNT := P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS.COUNT;
          FORALL L_INDEX IN 1 .. L_COUNT
            INSERT INTO LCTBS_TERMS_CONDITIONS
            VALUES P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS
              (L_INDEX);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Insert into LCTBS_TERMS_CONDITIONS..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@LCTBS_TERMS_CONDITIONS';
            RETURN FALSE;
        END;
      END IF;

      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_HOLD) THEN

        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.CONTRACT_STATUS := 'H';
      END IF;

      DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
      BEGIN
        SELECT MODULE
          INTO L_MODULE
          FROM SMTB_MENU
         WHERE FUNCTION_ID = P_FUNCTION_ID;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In when others while getting module..');
          RETURN FALSE;
      END;

      DBG('Inserting into CSTBS_CONTRACT_EVENT_LOG ' ||
          P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.AUTH_STATUS);
      BEGIN
        INSERT INTO CSTBS_CONTRACT_EVENT_LOG
          (MODULE,
           CONTRACT_REF_NO,
           MAKER_ID,
           MAKER_DT_STAMP,
           EVENT_SEQ_NO,
           EVENT_CODE,
           CONTRACT_STATUS,
           AUTH_STATUS)
        VALUES
          (L_MODULE,
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
           GLOBAL.USER_ID,
           L_APP_DATE,
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE,
           P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.CONTRACT_STATUS,
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTH_STATUS);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert into CSTBS_CONTRACT_EVENT_LOG..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@CSTBS_CONTRACT_EVENT_LOG';
          RETURN FALSE;
      END;

      IF NOT LCPKS_LCDTRONL_UTILS.FN_OPEN_POLICY_UPDATE(P_SOURCE,
                                                        P_FUNCTION_ID,
                                                        'PLUS',
                                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                        'N',
                                                        P_WRK_LCDTRONL,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN

        DBG('failed in fn_open_policy_update');
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;
      END IF;

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

      DBG('UPDATE' || P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO);
      DBG('IN UPDATE' ||
          P_WRK_LCDTRONL.TY_CFCTRCOM.V_CFTBS_CONTRACT_COMMISSION.COUNT);

      IF P_FUNCTION_ID = 'LCDTRONL' OR
         LCPKS_LCDTRONL_KERNEL.ISCHILDFUNCTION THEN
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_DATE := GLOBAL.APPLICATION_DATE;

      ELSIF P_FUNCTION_ID IN ('LCDAMEND', 'LCDAMSIM') THEN

        BEGIN
          SELECT EVENT_DATE
            INTO L_EVENT_DATE
            FROM CSTB_CONTRACT_EVENT_LOG
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO IN
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM CSTB_CONTRACT_EVENT_LOG
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                     AND EVENT_CODE = 'AMNV');
        EXCEPTION
          WHEN OTHERS THEN
            L_EVENT_DATE := NULL;
        END;
        DBG('l_event_date-->' || L_EVENT_DATE ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_DATE := SUBSTR(L_EVENT_DATE,
                                                                        1,
                                                                        9);

      END IF;

      BEGIN
        UPDATE CSTB_CONTRACT
           SET REVERSED_CONT_REF      = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.REVERSED_CONT_REF,
               BOOK_DATE              = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.BOOK_DATE,
               SERIAL_NO              = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.SERIAL_NO,
               LATEST_EVENT_SEQ_NO    = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
               USER_REF_NO            = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_REF_NO,
               LATEST_VERSION_NO      = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_VERSION_NO,
               COUNTERPARTY           = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.COUNTERPARTY,
               CONTRACT_STATUS        = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_STATUS,
               AUTH_STATUS            = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTH_STATUS,
               PRODUCT_TYPE           = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE,
               CURR_EVENT_CODE        = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CURR_EVENT_CODE,
               USER_DEFINED_STATUS    = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.USER_DEFINED_STATUS,
               CONTRACT_CCY           = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_CCY,
               LATEST_EVENT_DATE      = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_DATE,
               EXTERNAL_REF_NO        = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.EXTERNAL_REF_NO,
               AUTO_MANUAL_FLAG       = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTO_MANUAL_FLAG,
               FUND_REF_NO            = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.FUND_REF_NO,
               RESPONSE_STAT          = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.RESPONSE_STAT,
               SECURITY_UPLOAD_STATUS = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.SECURITY_UPLOAD_STATUS,
               STOP_DATE              = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.STOP_DATE,
               LIABILITY_CIF          = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LIABILITY_CIF,
               SOURCE                 = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.SOURCE
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert into CSTBS_CONTRACT..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@CSTBS_CONTRACT';
          RETURN FALSE;
      END;

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO IS NOT NULL THEN
        DBG('Record Sent..');

        BEGIN
          UPDATE LCTB_CONTRACT_MASTER
             SET SUBSYSTEMSTAT              = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SUBSYSTEMSTAT,
                 AMENDMENT_DATE             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_DATE,
                 UNITS                      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNITS,
                 INCLUDE_TO_DATE            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCLUDE_TO_DATE,
                 RULE_NARRATIVE             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RULE_NARRATIVE,
                 APPLICABLE_RULE            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.APPLICABLE_RULE,
                 VERSION_NO                 = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                 EVENT_CODE                 = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE,
                 OPERATION_CODE             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE,
                 DEAL_SOURCE                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.DEAL_SOURCE,
                 EXT_REF_NO                 = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXT_REF_NO,
                 RELATED_LC_REF_NO          = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.RELATED_LC_REF_NO,
                 PRODUCT_CODE               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRODUCT_CODE,
                 TRANSFERABLE               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFERABLE,
                 SETTLEMENT_TYPE            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_TYPE,
                 SETTLEMENT_METHOD          = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.SETTLEMENT_METHOD,
                 GUARANTEE_TYPE             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.GUARANTEE_TYPE,
                 CONTRACT_CCY               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY,
                 CONTRACT_AMT               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                 MAX_CONTRACT_AMT           = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT,
                 TOLERANCE_TEXT             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TOLERANCE_TEXT,
                 NEGATIVE_TOLERANCE         = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEGATIVE_TOLERANCE,
                 POSITIVE_TOLERANCE         = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.POSITIVE_TOLERANCE,
                 LIAB_TOLERANCE             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIAB_TOLERANCE,
                 MAX_LIABILITY_AMT          = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_LIABILITY_AMT,
                 EXPIRY_DATE                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_DATE,
                 EXPIRY_PLACE               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_PLACE,
                 ISSUE_DATE                 = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_DATE,
                 CLOSURE_DATE               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_DATE,
                 CLOSURE_TYPE               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLOSURE_TYPE,
                 CIF_ID                     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CIF_ID,
                 CUST_TYPE                  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_TYPE,
                 CUST_NAME                  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_NAME,
                 CUST_REF_NO                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_NO,
                 CUST_REF_DATE              = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUST_REF_DATE,
                 TRACK_LIMIT                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT,
                 CREDIT_LINE                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_LINE,
                 LINE_PARTY_TYPE            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LINE_PARTY_TYPE,
                 LINE_CIF_ID                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LINE_CIF_ID,
                 ADDITIONAL_AMTS_COVERED    = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADDITIONAL_AMTS_COVERED,
                 REIMBURSEMENT_TYPE         = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REIMBURSEMENT_TYPE,
                 PERIOD_FOR_PRESENTATION    = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PERIOD_FOR_PRESENTATION,
                 REMARKS                    = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REMARKS,
                 PAYMENT_DETAILS            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PAYMENT_DETAILS,
                 CHARGES_FROM_BEN           = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_BEN,
                 REINSTATEMENT_TYPE         = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REINSTATEMENT_TYPE,
                 REVOLVES_IN                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REVOLVES_IN,
                 CUMULATIVE                 = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CUMULATIVE,
                 FREQUENCY                  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FREQUENCY,
                 NEXT_REINSTATEMENT_DATE    = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NEXT_REINSTATEMENT_DATE,
                 CREDIT_AVL_WITH            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CREDIT_AVL_WITH,
                 CHARGES_FROM_ISB           = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGES_FROM_ISB,
                 ACCOUNT_FOR_ISB            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACCOUNT_FOR_ISB,
                 LC_LANG_CODE               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LC_LANG_CODE,
                 AMENDMENT_NO               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AMENDMENT_NO,
                 CHARGE_AMT_ISB             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGE_AMT_ISB,
                 CHARGE_CCY_ISB             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHARGE_CCY_ISB,
                 EFFECTIVE_DATE             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EFFECTIVE_DATE,
                 ISB_DATE                   = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISB_DATE,
                 ISSUE_REQUEST              = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ISSUE_REQUEST,
                 INCO_TERM                  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM,
                 MAY_CONFIRM                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAY_CONFIRM,
                 STOP_DATE                  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STOP_DATE,
                 OS_LC_AMOUNT               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OS_LC_AMOUNT,
                 TENOR                      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TENOR,
                 LIMITS_TRACKING_TENOR_TYPE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LIMITS_TRACKING_TENOR_TYPE,
                 ALLOW_PREPAY               = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ALLOW_PREPAY,
                 URR_PREFERENCE             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.URR_PREFERENCE

                ,
                 ACKN_RECVD = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKN_RECVD,
                 ACKN_DATE  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKN_DATE

                ,
                 FIN_AMND_NO                = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_AMND_NO,
                 FIN_FLAG                   = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FIN_FLAG,
                 PARTIAL_CONFIRMATION_ALLOW = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CONFIRMATION_ALLOW,
                 CONFIRM_PERCENT            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_PERCENT,
                 CONFIRM_AMOUNT             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONFIRM_AMOUNT,
                 PARTIAL_CLOSURE            = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PARTIAL_CLOSURE,

                 UNDERTAKING_AMOUNT         = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_AMOUNT,
                 UNDERTAKING_EXPIRY_DATE    = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNDERTAKING_EXPIRY_DATE,
                 AVAILED_UNDERTAKING_AMOUNT = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AVAILED_UNDERTAKING_AMOUNT

                ,
                 UNCONFIRM_AMOUNT = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.UNCONFIRM_AMOUNT

                ,
                 USER_DEFINED_STATUS     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.USER_DEFINED_STATUS,
                 CONTRACT_DERIVED_STATUS = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_DERIVED_STATUS,
                 STATUS_CONTROL_FLAG     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.STATUS_CONTROL_FLAG,
                 BENEFICIARY_CONF_REQD   = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.BENEFICIARY_CONF_REQD

                ,
                 ACKREFNO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ACKREFNO

                ,
                 CHG_CLM_SWIFT      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHG_CLM_SWIFT,
                 CHGCLM_TEMPLATE_ID = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CHGCLM_TEMPLATE_ID

                ,
                 CLAIM_DATE        = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_DATE,
                 CLAIM_EXPIRY_DATE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_EXPIRY_DATE

                ,
                 EXPIRY_CONDITION      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXPIRY_CONDITION,
                 CLAIM_INDICATOR       = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CLAIM_INDICATOR,
                 LOCAL_GUA_ISSUE_DATE  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_ISSUE_DATE,
                 LOCAL_GUA_EXPIRY_DATE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXPIRY_DATE

                ,
                 ANCILLARY_MESG          = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG,
                 ANCILLARY_MESG_FUNCTION = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ANCILLARY_MESG_FUNCTION

                ,
                 PRESENTATION_NARRATIVE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.PRESENTATION_NARRATIVE,
                 REQ_CONFIRM_PARTY      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.REQ_CONFIRM_PARTY

                ,
                 TRANSFER_CONDITIONS = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRANSFER_CONDITIONS,
                 ADVICE_OF_REDUCTION = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.ADVICE_OF_REDUCTION,
                 VALIDITY_TYPE       = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VALIDITY_TYPE

                ,
                 COLLATERAL_PCT_OBP       = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.COLLATERAL_PCT_OBP,
                 AUTO_EXTN_PERIOD         = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.AUTO_EXTN_PERIOD,
                 EXTN_DETAILS             = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EXTN_DETAILS,
                 NON_EXT_NOTIF_DETAILS    = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NON_EXT_NOTIF_DETAILS,
                 NOTIFICATION_PERIOD      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.NOTIFICATION_PERIOD,
                 FINAL_EXPIRY_DATE        = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.FINAL_EXPIRY_DATE,
                 LOCAL_GUA_FINAL_EXP_DATE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_FINAL_EXP_DATE

                ,
                 LOCAL_GUA_APPL_RULE     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_APPL_RULE,
                 LOCAL_GUA_RULE_NARRAT   = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_RULE_NARRAT,
                 LOCAL_GUA_EXP_TYPE      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXP_TYPE,
                 LOCAL_GUA_EXP_COND      = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXP_COND,
                 LOCAL_GUA_CONTRACT_AMT  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_CONTRACT_AMT,
                 LOCAL_GUA_CONTRACT_CCY  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_CONTRACT_CCY,
                 LOCAL_GUA_CRD_AVL_WITH  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_CRD_AVL_WITH,
                 LOCAL_GUA_CHG_FROM_BEN  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_CHG_FROM_BEN,
                 LOCAL_GUA_AUTO_EXTN_PRD = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_AUTO_EXTN_PRD,
                 LOCAL_GUA_EXTN_DETAILS  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_EXTN_DETAILS,
                 LOCAL_GUA_NOTIF_PRD     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_NOTIF_PRD,
                 LOCAL_GUA_NOTIF_DETAILS = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_NOTIF_DETAILS,
                 LOCAL_GUA_CLAIM_IND     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_CLAIM_IND,
                 LOCAL_GUA_TRANSFERABLE  = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_TRANSFERABLE,
                 LOCAL_GUA_TRNF_COND     = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.LOCAL_GUA_TRNF_COND

           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND VERSION_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Insert into LCTBS_CONTRACT_MASTER..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@LCTBS_CONTRACT_MASTER';
            RETURN FALSE;
        END;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CONTRACT_REF_NO IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.EVENT_SEQ_NO IS NOT NULL THEN
        DBG('Record Sent..');
        DBG('Updating Child data..Single Record Node :  LCTBS_AVAILMENTS..');
        BEGIN
          UPDATE LCTB_AVAILMENTS
             SET EVENT_CODE                    = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.EVENT_CODE,
                 AVAILMENT_AMT                 = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILMENT_AMT,
                 AVAILMENT_TYPE                = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILMENT_TYPE,
                 CURRENT_AVAILABILITY          = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CURRENT_AVAILABILITY,
                 OS_LIABILITY                  = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.OS_LIABILITY,
                 RELATED_REF_NO                = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.RELATED_REF_NO,
                 REMARKS                       = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.REMARKS,
                 REVERSAL_EVENT_SEQ_NO         = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.REVERSAL_EVENT_SEQ_NO,
                 VALUE_DATE                    = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.VALUE_DATE,
                 LIABILITY_AMT                 = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.LIABILITY_AMT,
                 AVAILABLE_CONFIRMED_AMT       = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_CONFIRMED_AMT,
                 UNCNFIRM_AVAILED_AMT          = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.UNCNFIRM_AVAILED_AMT,
                 AVAILABLE_UNDERTAKING_AMOUNT  = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_UNDERTAKING_AMOUNT,
                 AVAILED_NOTUNDERTAKING_AMOUNT = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILED_NOTUNDERTAKING_AMOUNT

                ,
                 AVAILABLE_UNCONFIRMED_AMT = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.AVAILABLE_UNCONFIRMED_AMT

           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.CONTRACT_REF_NO
             AND VERSION_NO = P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS.VERSION_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Insert into LCTBS_AVAILMENTS..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@LCTBS_AVAILMENTS';
            RETURN FALSE;
        END;
      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.CONTRACT_REF_NO IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.EVENT_SEQ_NO IS NOT NULL THEN
        DBG('Record Sent..');
        DBG('Updating Child data..Single Record Node :  LCTBS_SHIPMENT..');
        BEGIN
          UPDATE LCTB_SHIPMENT
             SET VERSION_NO           = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.VERSION_NO,
                 EVENT_CODE           = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.EVENT_CODE,
                 FROM_PLACE           = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.FROM_PLACE,
                 TO_PLACE             = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TO_PLACE,
                 LATEST_SHIPMENT_DATE = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.LATEST_SHIPMENT_DATE,
                 PARTIAL_SHIPMENT     = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT,
                 TRANS_SHIPMENT       = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT,
                 SHIPMENT_DETAILS     = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DETAILS,
                 SHIPMENT_MARKS       = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_MARKS,
                 SHIPMENT_PERIOD      = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_PERIOD,
                 PORT_DISCHARGE       = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_DISCHARGE,
                 PORT_LOADING         = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PORT_LOADING,
                 SHIPMENT_DAYS        = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.SHIPMENT_DAYS

                ,
                 PARTIAL_SHIPMENT_DETAILS = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.PARTIAL_SHIPMENT_DETAILS,
                 TRANS_SHIPMENT_DETAILS   = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.TRANS_SHIPMENT_DETAILS

           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.CONTRACT_REF_NO
             AND VERSION_NO = P_WRK_LCDTRONL.V_LCTBS_SHIPMENT.VERSION_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Insert into LCTBS_SHIPMENT..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@LCTBS_SHIPMENT';
            RETURN FALSE;
        END;

        IF SQL%ROWCOUNT = 0 THEN

          BEGIN
            INSERT INTO LCTB_SHIPMENT
            VALUES P_WRK_LCDTRONL.V_LCTBS_SHIPMENT;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Insert into LCTBS_GOODS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_SHIPMENTS';
              RETURN FALSE;
          END;

        END IF;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.CONTRACT_REF_NO IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.EVENT_SEQ_NO IS NOT NULL THEN
        DBG('Record Sent..');
        DBG('Updating Child data..Single Record Node :  LCTBS_SHIPMENT..');
        DBG('p_lcdtronl.v_Lctbs_Contract_Master.event_seq_no' ||
            P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        BEGIN
          UPDATE LCTB_SPLPYMT_CONDITIONS
             SET VERSION_NO              = P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.VERSION_NO,
                 EVENT_CODE              = P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.EVENT_CODE,
                 EVENT_SEQ_NO            = P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                 CONDITIONS_FOR_BEN      = P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.CONDITIONS_FOR_BEN,
                 CONDITIONS_FOR_RECVBANK = P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.CONDITIONS_FOR_RECVBANK
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.CONTRACT_REF_NO
             AND VERSION_NO =
                 P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS.VERSION_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Insert into LCTBS_SPLPYMT_CONDITIONS..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@LCTBS_SPLPYMT_CONDITIONS';
            RETURN FALSE;
        END;
        IF SQL%ROWCOUNT = 0 THEN
          BEGIN
            INSERT INTO LCTBS_SPLPYMT_CONDITIONS
            VALUES P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Insert into LCTBS_SPLPYMT_CONDITIONS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_SPLPYMT_CONDITIONS';
              RETURN FALSE;
          END;
        END IF;
      END IF;

      DBG('Preparing Insert and Update Types for LCTBS_GOODS_DETAILS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT;

      DBG('l_Wrk_Count:' || L_WRK_COUNT);
      DBG('l_Prev_Count:' || L_PREV_COUNT);
      DBG('CNT:' || P_PREV_LCDTRONL.V_LCTBS_PARTIES.COUNT);

      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(L_INDEX)
                      .GOODS_CODE,
                      '@') = NVL(P_PREV_LCDTRONL.V_GOODS_DETAILS__DETAIL(L_INDEX1)
                                  .GOODS_CODE,
                                  '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;

          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_GOODS_DETAILS(U_V_LCTBS_GOODS_DETAILS.COUNT + 1) := P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_GOODS_DETAILS(I_V_LCTBS_GOODS_DETAILS.COUNT + 1) := P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preparing Delete Types for LCTBS_GOODS_DETAILS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(L_INDEX)
                      .GOODS_CODE,
                      '@') = NVL(P_PREV_LCDTRONL.V_GOODS_DETAILS__DETAIL(L_INDEX1)
                                  .GOODS_CODE,
                                  '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;

          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_GOODS_DETAILS(D_V_LCTBS_GOODS_DETAILS.COUNT + 1) := P_PREV_LCDTRONL.V_GOODS_DETAILS__DETAIL(L_INDEX1);
          END IF;
        END LOOP;
      END IF;

      L_DEL_COUNT := D_V_LCTBS_GOODS_DETAILS.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_GOODS_DETAILS
           WHERE CONTRACT_REF_NO = D_V_LCTBS_GOODS_DETAILS(L_INDEX)
                .CONTRACT_REF_NO
             AND EVENT_SEQ_NO = D_V_LCTBS_GOODS_DETAILS(L_INDEX)
                .EVENT_SEQ_NO
             AND GOODS_CODE = D_V_LCTBS_GOODS_DETAILS(L_INDEX).GOODS_CODE;
        END LOOP;
      END IF;

      L_INS_COUNT := I_V_LCTBS_GOODS_DETAILS.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      BEGIN
        L_COUNT := I_V_LCTBS_GOODS_DETAILS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_GOODS_DETAILS
          VALUES I_V_LCTBS_GOODS_DETAILS
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert into LCTBS_GOODS_DETAILS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_PARTIES';
          RETURN FALSE;
      END;

      L_UPD_COUNT := U_V_LCTBS_GOODS_DETAILS.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          BEGIN
            UPDATE LCTB_GOODS_DETAILS
               SET GOODS_DESCR    = U_V_LCTBS_GOODS_DETAILS(L_INDEX)
                                    .GOODS_DESCR,
                   NO_OF_UNITS    = U_V_LCTBS_GOODS_DETAILS(L_INDEX)
                                    .NO_OF_UNITS,
                   CCY            = U_V_LCTBS_GOODS_DETAILS(L_INDEX).CCY,
                   PRICE_PER_UNIT = U_V_LCTBS_GOODS_DETAILS(L_INDEX)
                                    .PRICE_PER_UNIT
             WHERE CONTRACT_REF_NO = U_V_LCTBS_GOODS_DETAILS(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_GOODS_DETAILS(L_INDEX)
                  .EVENT_SEQ_NO
               AND GOODS_CODE = U_V_LCTBS_GOODS_DETAILS(L_INDEX).GOODS_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_GOODS_DETAILS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_GOODS_DETAILS';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Chk contract_ref_no:' ||
          P_LCDTRONL.V_GOODS_DETAILS__MASTER.CONTRACT_REF_NO || '~' ||
          'OTHR event_seq_no:' ||
          P_LCDTRONL.V_GOODS_DETAILS__MASTER.EVENT_SEQ_NO);
      IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT > 0 THEN
        P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR := NULL;

      END IF;

      IF P_WRK_LCDTRONL.V_LCTBS_GOODS.CONTRACT_REF_NO IS NOT NULL AND
         P_WRK_LCDTRONL.V_LCTBS_GOODS.EVENT_SEQ_NO IS NOT NULL THEN
        DBG('Record Sent..');
        DBG('Updating Child data..Single Record Node :  LCTBS_GOODS..');
        BEGIN
          UPDATE LCTB_GOODS
             SET VERSION_NO       = P_WRK_LCDTRONL.V_LCTBS_GOODS.VERSION_NO,
                 EVENT_CODE       = P_WRK_LCDTRONL.V_LCTBS_GOODS.EVENT_CODE,
                 GOODS_DESCR      = P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR,
                 GOODS_CODE       = P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE,
                 PRE_ADVICE_DESCR = P_WRK_LCDTRONL.V_LCTBS_GOODS.PRE_ADVICE_DESCR
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_GOODS.CONTRACT_REF_NO
             AND VERSION_NO = P_WRK_LCDTRONL.V_LCTBS_GOODS.VERSION_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Insert into LCTBS_GOODS..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@LCTBS_GOODS';
            RETURN FALSE;
        END;

        IF SQL%ROWCOUNT = 0 THEN
          IF P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_CODE IS NOT NULL OR
             P_WRK_LCDTRONL.V_LCTBS_GOODS.GOODS_DESCR IS NOT NULL OR
             P_WRK_LCDTRONL.V_LCTBS_GOODS.INCO_TERM IS NOT NULL THEN

            BEGIN
              INSERT INTO LCTB_GOODS VALUES P_WRK_LCDTRONL.V_LCTBS_GOODS;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in Insert into LCTBS_GOODS..');
                DBG(SQLERRM);
                P_ERR_CODE   := 'ST-UPLD-001';
                P_ERR_PARAMS := '@LCTBS_GOODS';
                RETURN FALSE;
            END;
          END IF;
        END IF;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_PARTIES..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_PARTIES.COUNT;
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_INDEX).PARTY_TYPE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_PARTIES(L_INDEX1).PARTY_TYPE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_PARTIES(U_V_LCTBS_PARTIES.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_PARTIES(I_V_LCTBS_PARTIES.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  LCTBS_PARTIES..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_PARTIES.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_PARTIES(L_INDEX).PARTY_TYPE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_PARTIES(L_INDEX1).PARTY_TYPE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_PARTIES(D_V_LCTBS_PARTIES.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_PARTIES(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_PARTIES.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);

      DBG('Latest Event Seq No is: ' ||
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_PARTIES
           WHERE CONTRACT_REF_NO = D_V_LCTBS_PARTIES(L_INDEX)
                .CONTRACT_REF_NO
             AND PARTY_TYPE = D_V_LCTBS_PARTIES(L_INDEX).PARTY_TYPE

             AND EVENT_SEQ_NO =
                 NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                     D_V_LCTBS_PARTIES(L_INDEX).EVENT_SEQ_NO);

        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_PARTIES.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      BEGIN
        L_COUNT := I_V_LCTBS_PARTIES.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_PARTIES VALUES I_V_LCTBS_PARTIES (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_PARTIES..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_PARTIES';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_PARTIES.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          BEGIN
            UPDATE LCTB_PARTIES
               SET VERSION_NO        = U_V_LCTBS_PARTIES(L_INDEX).VERSION_NO,
                   EVENT_CODE        = U_V_LCTBS_PARTIES(L_INDEX).EVENT_CODE,
                   CIF_ID            = U_V_LCTBS_PARTIES(L_INDEX).CIF_ID,
                   CUST_NAME         = U_V_LCTBS_PARTIES(L_INDEX).CUST_NAME,
                   COUNTRY_CODE      = U_V_LCTBS_PARTIES(L_INDEX)
                                       .COUNTRY_CODE,
                   CUST_ADDRESS_LIN1 = U_V_LCTBS_PARTIES(L_INDEX)
                                       .CUST_ADDRESS_LIN1,
                   CUST_ADDRESS_LIN2 = U_V_LCTBS_PARTIES(L_INDEX)
                                       .CUST_ADDRESS_LIN2,
                   CUST_ADDRESS_LIN3 = U_V_LCTBS_PARTIES(L_INDEX)
                                       .CUST_ADDRESS_LIN3,
                   CUST_ADDRESS_LIN4 = U_V_LCTBS_PARTIES(L_INDEX)
                                       .CUST_ADDRESS_LIN4,
                   CUST_REF_NO       = U_V_LCTBS_PARTIES(L_INDEX).CUST_REF_NO,
                   CUST_REF_DATE     = U_V_LCTBS_PARTIES(L_INDEX)
                                       .CUST_REF_DATE,
                   LANG_CODE         = U_V_LCTBS_PARTIES(L_INDEX).LANG_CODE,
                   ISSUER_IS_BANK    = U_V_LCTBS_PARTIES(L_INDEX)
                                       .ISSUER_IS_BANK,
                   TEMPLATE_ID       = U_V_LCTBS_PARTIES(L_INDEX).TEMPLATE_ID
             WHERE CONTRACT_REF_NO = U_V_LCTBS_PARTIES(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_PARTIES(L_INDEX).EVENT_SEQ_NO
               AND PARTY_TYPE = U_V_LCTBS_PARTIES(L_INDEX).PARTY_TYPE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_PARTIES..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_PARTIES';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_FFTS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_FFTS.COUNT;
      DBG('wrk count : ' || L_WRK_COUNT || ' prev count: ' || L_PREV_COUNT);

      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_FFTS(L_INDEX).FFT_INS_CODE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_FFTS(L_INDEX1).FFT_INS_CODE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_FFTS(U_V_LCTBS_FFTS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_FFTS(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_FFTS(I_V_LCTBS_FFTS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_FFTS(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  LCTBS_FFTS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_FFTS.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_FFTS(L_INDEX).FFT_INS_CODE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_FFTS(L_INDEX1).FFT_INS_CODE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_FFTS(D_V_LCTBS_FFTS.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_FFTS(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_FFTS.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);

      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTBS_FFTS
           WHERE CONTRACT_REF_NO = D_V_LCTBS_FFTS(L_INDEX).CONTRACT_REF_NO
             AND PARTY_TYPE = D_V_LCTBS_FFTS(L_INDEX).PARTY_TYPE

             AND EVENT_SEQ_NO =
                 NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                     D_V_LCTBS_FFTS(L_INDEX).EVENT_SEQ_NO);

        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_FFTS.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      IF L_INS_COUNT > 0 THEN

        FOR L_INDEX IN 1 .. L_INS_COUNT LOOP
          DBG('party type: ' || I_V_LCTBS_FFTS(L_INDEX).PARTY_TYPE);
          DBG('message type: ' || I_V_LCTBS_FFTS(L_INDEX).MESG_TYPE);
          DBG('fft code: ' || I_V_LCTBS_FFTS(L_INDEX).FFT_INS_CODE);
        END LOOP;
      END IF;
      BEGIN
        L_COUNT := I_V_LCTBS_FFTS.COUNT;
        IF L_COUNT > 0 THEN
          FORALL L_INDEX IN 1 .. L_COUNT
            INSERT INTO LCTB_FFTS VALUES I_V_LCTBS_FFTS (L_INDEX);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert into LCTBS_ffts..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_FFTS';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_FFTS.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          BEGIN
            UPDATE LCTB_FFTS
               SET VERSION_NO    = U_V_LCTBS_FFTS(L_INDEX).VERSION_NO,
                   EVENT_CODE    = U_V_LCTBS_FFTS(L_INDEX).EVENT_CODE,
                   FFT_INS_SL_NO = U_V_LCTBS_FFTS(L_INDEX).FFT_INS_SL_NO,
                   FFT_INS_DESCR = U_V_LCTBS_FFTS(L_INDEX).FFT_INS_DESCR,
                   PARTY_TYPE    = U_V_LCTBS_FFTS(L_INDEX).PARTY_TYPE,
                   SINGLE_FFT    = U_V_LCTBS_FFTS(L_INDEX).SINGLE_FFT,
                   GUARREFNO     = U_V_LCTBS_FFTS(L_INDEX).GUARREFNO
             WHERE CONTRACT_REF_NO = U_V_LCTBS_FFTS(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_FFTS(L_INDEX).EVENT_SEQ_NO
               AND PARTY_TYPE = U_V_LCTBS_FFTS(L_INDEX).PARTY_TYPE;

          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_FFTS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_FFTS';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_OTHER_ADDRESSES..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT;
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                      .PARTY_TYPE,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(L_INDEX1)
                                  .PARTY_TYPE,
                                  '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_OTHER_ADDRESSES(U_V_LCTBS_OTHER_ADDRESSES.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_OTHER_ADDRESSES(I_V_LCTBS_OTHER_ADDRESSES.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  LCTBS_OTHER_ADDRESSES..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                      .PARTY_TYPE,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(L_INDEX1)
                                  .PARTY_TYPE,
                                  '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_OTHER_ADDRESSES(D_V_LCTBS_OTHER_ADDRESSES.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_OTHER_ADDRESSES(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_OTHER_ADDRESSES.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_OTHER_ADDRESSES
           WHERE CONTRACT_REF_NO = D_V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                .CONTRACT_REF_NO
             AND PARTY_TYPE = D_V_LCTBS_OTHER_ADDRESSES(L_INDEX).PARTY_TYPE

             AND EVENT_SEQ_NO =
                 NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                     D_V_LCTBS_OTHER_ADDRESSES(L_INDEX).EVENT_SEQ_NO);

        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_OTHER_ADDRESSES.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      BEGIN
        L_COUNT := I_V_LCTBS_OTHER_ADDRESSES.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_OTHER_ADDRESSES
          VALUES I_V_LCTBS_OTHER_ADDRESSES
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_OTHER_ADDRESSES..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_OTHER_ADDRESSES';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_OTHER_ADDRESSES.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          DBG('Updating the  Record...');
          BEGIN
            NULL;
            UPDATE LCTB_OTHER_ADDRESSES

               SET EVENT_CODE     = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                                    .EVENT_CODE,
                   VERSION_NO     = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                                    .VERSION_NO,
                   CIF_ID         = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX).CIF_ID,
                   MEDIUM_TYPE    = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                                    .MEDIUM_TYPE,
                   MEDIUM_ADDRESS = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                                    .MEDIUM_ADDRESS,
                   ACC_NO         = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX).ACC_NO
             WHERE CONTRACT_REF_NO = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                  .EVENT_SEQ_NO
               AND PARTY_TYPE = U_V_LCTBS_OTHER_ADDRESSES(L_INDEX)
                  .PARTY_TYPE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_OTHER_ADDRESSES..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_OTHER_ADDRESSES';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_DOCUMENTS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT;
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_INDEX).DOC_CODE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(L_INDEX1).DOC_CODE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_DOCUMENTS(U_V_LCTBS_DOCUMENTS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_DOCUMENTS(I_V_LCTBS_DOCUMENTS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  LCTBS_DOCUMENTS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS(L_INDEX).DOC_CODE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(L_INDEX1).DOC_CODE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_DOCUMENTS(D_V_LCTBS_DOCUMENTS.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_DOCUMENTS(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_DOCUMENTS.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_DOCUMENTS
           WHERE CONTRACT_REF_NO = D_V_LCTBS_DOCUMENTS(L_INDEX)
                .CONTRACT_REF_NO
             AND DOC_CODE = D_V_LCTBS_DOCUMENTS(L_INDEX).DOC_CODE

             AND EVENT_SEQ_NO =
                 NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                     D_V_LCTBS_DOCUMENTS(L_INDEX).EVENT_SEQ_NO);

        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_DOCUMENTS.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      DBG('l_Ins_Count' || L_INS_COUNT);
      BEGIN
        L_COUNT := I_V_LCTBS_DOCUMENTS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_DOCUMENTS VALUES I_V_LCTBS_DOCUMENTS (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_DOCUMENTS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_DOCUMENTS';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_DOCUMENTS.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          DBG('Updating the  Record...');
          BEGIN
            UPDATE LCTB_DOCUMENTS
               SET VERSION_NO      = U_V_LCTBS_DOCUMENTS(L_INDEX).VERSION_NO,
                   EVENT_CODE      = U_V_LCTBS_DOCUMENTS(L_INDEX).EVENT_CODE,
                   DOC_SL_NO       = U_V_LCTBS_DOCUMENTS(L_INDEX).DOC_SL_NO,
                   DOC_TYPE        = U_V_LCTBS_DOCUMENTS(L_INDEX).DOC_TYPE,
                   DOC_DESCR       = U_V_LCTBS_DOCUMENTS(L_INDEX).DOC_DESCR,
                   DOC_ORIGINAL    = U_V_LCTBS_DOCUMENTS(L_INDEX)
                                     .DOC_ORIGINAL,
                   DOC_COPIES      = U_V_LCTBS_DOCUMENTS(L_INDEX).DOC_COPIES,
                   NO_OF_ORIGINALS = U_V_LCTBS_DOCUMENTS(L_INDEX)
                                     .NO_OF_ORIGINALS,
                   DOC_REFERENCE   = U_V_LCTBS_DOCUMENTS(L_INDEX)
                                     .DOC_REFERENCE
             WHERE CONTRACT_REF_NO = U_V_LCTBS_DOCUMENTS(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_DOCUMENTS(L_INDEX).EVENT_SEQ_NO
               AND DOC_CODE = U_V_LCTBS_DOCUMENTS(L_INDEX).DOC_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_DOCUMENTS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_DOCUMENTS';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_CLAUSES..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_CLAUSES.COUNT;
      DBG('l_Wrk_Count:' || L_WRK_COUNT || 'l_Prev_Count:' || L_PREV_COUNT);
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX).DOC_CODE, '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX1).DOC_CODE,
                      '@')) AND
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX).CLAUSE_CODE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX1).CLAUSE_CODE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                DBG('p_Wrk_Lcdtronl.v_Lctbs_Clauses(l_Index).Clause_Code' || P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX)
                    .CLAUSE_CODE);
                DBG('p_Prev_Lcdtronl.v_Lctbs_Clauses(l_Index1).Clause_Code' || P_PREV_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX1)
                    .CLAUSE_CODE);
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_CLAUSES(U_V_LCTBS_CLAUSES.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_CLAUSES(I_V_LCTBS_CLAUSES.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  LCTBS_CLAUSES..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_CLAUSES.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_CLAUSES.COUNT;
      DBG('l_Wrk_Count:' || L_WRK_COUNT || 'l_Prev_Count:' || L_PREV_COUNT);
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX).DOC_CODE, '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX1).DOC_CODE,
                      '@')) AND
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX).CLAUSE_CODE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX1).CLAUSE_CODE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_CLAUSES(D_V_LCTBS_CLAUSES.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_CLAUSES(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_CLAUSES.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_CLAUSES
           WHERE CONTRACT_REF_NO = D_V_LCTBS_CLAUSES(L_INDEX)
                .CONTRACT_REF_NO
             AND DOC_CODE = D_V_LCTBS_CLAUSES(L_INDEX).DOC_CODE
             AND CLAUSE_CODE = D_V_LCTBS_CLAUSES(L_INDEX).CLAUSE_CODE

             AND EVENT_SEQ_NO =
                 NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                     D_V_LCTBS_CLAUSES(L_INDEX).EVENT_SEQ_NO);

        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_CLAUSES.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      BEGIN
        L_COUNT := I_V_LCTBS_CLAUSES.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_CLAUSES VALUES I_V_LCTBS_CLAUSES (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_CLAUSES..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_CLAUSES';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_CLAUSES.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          DBG('Updating the  Record...');
          BEGIN
            UPDATE LCTB_CLAUSES
               SET CLAUSE_SL_NO = U_V_LCTBS_CLAUSES(L_INDEX).CLAUSE_SL_NO,
                   CLAUSE_DESCR = U_V_LCTBS_CLAUSES(L_INDEX).CLAUSE_DESCR
             WHERE CONTRACT_REF_NO = U_V_LCTBS_CLAUSES(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_CLAUSES(L_INDEX).EVENT_SEQ_NO
               AND DOC_CODE = U_V_LCTBS_CLAUSES(L_INDEX).DOC_CODE
               AND CLAUSE_CODE = U_V_LCTBS_CLAUSES(L_INDEX).CLAUSE_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_CLAUSES..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_CLAUSES';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_TRACERS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_TRACERS.COUNT;
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_INDEX).TRACER_CODE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_TRACERS(L_INDEX1).TRACER_CODE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_TRACERS(U_V_LCTBS_TRACERS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_TRACERS(I_V_LCTBS_TRACERS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  LCTBS_TRACERS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_TRACERS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_TRACERS.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_TRACERS(L_INDEX).TRACER_CODE,
                      '@') =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_TRACERS(L_INDEX1).TRACER_CODE,
                      '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_TRACERS(D_V_LCTBS_TRACERS.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_TRACERS(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_TRACERS.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_TRACERS
           WHERE CONTRACT_REF_NO = D_V_LCTBS_TRACERS(L_INDEX)
                .CONTRACT_REF_NO
             AND TRACER_CODE = D_V_LCTBS_TRACERS(L_INDEX).TRACER_CODE;
        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_TRACERS.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      BEGIN
        L_COUNT := I_V_LCTBS_TRACERS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_TRACERS VALUES I_V_LCTBS_TRACERS (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_TRACERS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_TRACERS';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_TRACERS.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          DBG('Updating the  Record...');
          BEGIN
            UPDATE LCTB_TRACERS
               SET VERSION_NO       = U_V_LCTBS_TRACERS(L_INDEX).VERSION_NO,
                   EVENT_CODE       = U_V_LCTBS_TRACERS(L_INDEX).EVENT_CODE,
                   TRACER_DESCR     = U_V_LCTBS_TRACERS(L_INDEX).TRACER_DESCR,
                   REQUIRED         = U_V_LCTBS_TRACERS(L_INDEX).REQUIRED,
                   TRACER_PARTY     = U_V_LCTBS_TRACERS(L_INDEX).TRACER_PARTY,
                   MEDIUM           = U_V_LCTBS_TRACERS(L_INDEX).MEDIUM,
                   START_DAYS       = U_V_LCTBS_TRACERS(L_INDEX).START_DAYS,
                   FREQUENCY        = U_V_LCTBS_TRACERS(L_INDEX).FREQUENCY,
                   MAX_TRACERS      = U_V_LCTBS_TRACERS(L_INDEX).MAX_TRACERS,
                   SENT_TO_DATE     = U_V_LCTBS_TRACERS(L_INDEX).SENT_TO_DATE,
                   LAST_TRACER_DATE = U_V_LCTBS_TRACERS(L_INDEX)
                                      .LAST_TRACER_DATE,
                   TEMPLATE_ID      = U_V_LCTBS_TRACERS(L_INDEX).TEMPLATE_ID
             WHERE CONTRACT_REF_NO = U_V_LCTBS_TRACERS(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_TRACERS(L_INDEX).EVENT_SEQ_NO
               AND TRACER_CODE = U_V_LCTBS_TRACERS(L_INDEX).TRACER_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_TRACERS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_TRACERS';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_DRAFTS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_DRAFTS.COUNT;
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(L_INDEX).DRAFT_SL_NO,
                      -1) =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(L_INDEX1).DRAFT_SL_NO,
                      -1)) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_DRAFTS(U_V_LCTBS_DRAFTS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_DRAFTS(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_DRAFTS(I_V_LCTBS_DRAFTS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_DRAFTS(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  LCTBS_DRAFTS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_DRAFTS.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS(L_INDEX).DRAFT_SL_NO,
                      -1) =
                 NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS(L_INDEX1).DRAFT_SL_NO,
                      -1)) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_DRAFTS(D_V_LCTBS_DRAFTS.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_DRAFTS(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_DRAFTS.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_DRAFTS
           WHERE CONTRACT_REF_NO = D_V_LCTBS_DRAFTS(L_INDEX)
                .CONTRACT_REF_NO
             AND DRAFT_SL_NO = D_V_LCTBS_DRAFTS(L_INDEX).DRAFT_SL_NO

             AND EVENT_SEQ_NO =
                 NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                     D_V_LCTBS_DRAFTS(L_INDEX).EVENT_SEQ_NO);

        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_DRAFTS.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      BEGIN
        L_COUNT := I_V_LCTBS_DRAFTS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_DRAFTS VALUES I_V_LCTBS_DRAFTS (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_DRAFTS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_DRAFTS';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_DRAFTS.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          DBG('Updating the  Record...');
          BEGIN
            UPDATE LCTB_DRAFTS
               SET VERSION_NO            = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .VERSION_NO,
                   EVENT_CODE            = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .EVENT_CODE,
                   DRAFT_TENOR           = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .DRAFT_TENOR,
                   CREDIT_DAYS_FROM      = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .CREDIT_DAYS_FROM,
                   PCT_AMT               = U_V_LCTBS_DRAFTS(L_INDEX).PCT_AMT,
                   DRAFT_AMT             = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .DRAFT_AMT,
                   DRAFT_PCT             = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .DRAFT_PCT,
                   DRAWEE                = U_V_LCTBS_DRAFTS(L_INDEX).DRAWEE,
                   INSURANCE_CO          = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .INSURANCE_CO,
                   INSURANCE_EXPIRY_DATE = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .INSURANCE_EXPIRY_DATE,
                   INSURANCE_POLICY_NO   = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .INSURANCE_POLICY_NO,
                   INSURANCE_COMP_CODE   = U_V_LCTBS_DRAFTS(L_INDEX)
                                           .INSURANCE_COMP_CODE,
                   ADDRESS1              = U_V_LCTBS_DRAFTS(L_INDEX).ADDRESS1,
                   ADDRESS2              = U_V_LCTBS_DRAFTS(L_INDEX).ADDRESS2,
                   ADDRESS3              = U_V_LCTBS_DRAFTS(L_INDEX).ADDRESS3
             WHERE CONTRACT_REF_NO = U_V_LCTBS_DRAFTS(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_DRAFTS(L_INDEX).EVENT_SEQ_NO
               AND DRAFT_SL_NO = U_V_LCTBS_DRAFTS(L_INDEX).DRAFT_SL_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_DRAFTS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_DRAFTS';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_DRAFTS_DETAILS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT;
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                      .DRAFT_SL_NO,
                      -1) = NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX1)
                                 .DRAFT_SL_NO,
                                 -1)) AND
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                      .AMOUNT_NAME,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX1)
                                  .AMOUNT_NAME,
                                  '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_DRAFTS_DETAILS(U_V_LCTBS_DRAFTS_DETAILS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX);
          ELSE
            DBG('Record is Added...');
            I_V_LCTBS_DRAFTS_DETAILS(I_V_LCTBS_DRAFTS_DETAILS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  LCTBS_DRAFTS_DETAILS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                      .DRAFT_SL_NO,
                      -1) = NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX1)
                                 .DRAFT_SL_NO,
                                 -1)) AND
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                      .AMOUNT_NAME,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX1)
                                  .AMOUNT_NAME,
                                  '@')) THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            D_V_LCTBS_DRAFTS_DETAILS(D_V_LCTBS_DRAFTS_DETAILS.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_DRAFTS_DETAILS(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_DRAFTS_DETAILS.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_DRAFTS_DETAILS
           WHERE CONTRACT_REF_NO = D_V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                .CONTRACT_REF_NO
             AND DRAFT_SL_NO = D_V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                .DRAFT_SL_NO
             AND AMOUNT_NAME = D_V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                .AMOUNT_NAME

             AND EVENT_SEQ_NO =
                 NVL(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO,
                     D_V_LCTBS_DRAFTS_DETAILS(L_INDEX).EVENT_SEQ_NO);

        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_DRAFTS_DETAILS.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      BEGIN
        L_COUNT := I_V_LCTBS_DRAFTS_DETAILS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_DRAFTS_DETAILS
          VALUES I_V_LCTBS_DRAFTS_DETAILS
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_DRAFTS_DETAILS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_DRAFTS_DETAILS';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_DRAFTS_DETAILS.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          DBG('Updating the  Record...');
          BEGIN
            UPDATE LCTB_DRAFTS_DETAILS
               SET AMOUNT = U_V_LCTBS_DRAFTS_DETAILS(L_INDEX).AMOUNT
             WHERE CONTRACT_REF_NO = U_V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                  .EVENT_SEQ_NO
               AND DRAFT_SL_NO = U_V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                  .DRAFT_SL_NO
               AND AMOUNT_NAME = U_V_LCTBS_DRAFTS_DETAILS(L_INDEX)
                  .AMOUNT_NAME;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_DRAFTS_DETAILS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_DRAFTS_DETAILS';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      DBG('Preapring Insert and Update Types for  LCTBS_CONTRACT_LIMITS..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT;
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                      .PARTY_TYPE,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1)
                                  .PARTY_TYPE,
                                  '@')) AND

                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                      .CUSTOMER_NO,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1)
                                  .CUSTOMER_NO,
                                  '@')) AND
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                      .LINKED_REF_NO,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1)
                                  .LINKED_REF_NO,
                                  '@'))

               THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF L_REC_FOUND THEN
            DBG('Record is Modified...');
            U_V_LCTBS_CONTRACT_LIMITS(U_V_LCTBS_CONTRACT_LIMITS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX);
          ELSE
            DBG('Record is Added...');
            DBG('p_wrk_lcdtronl customer_no >> ' || P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                .CUSTOMER_NO);
            I_V_LCTBS_CONTRACT_LIMITS(I_V_LCTBS_CONTRACT_LIMITS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX);
          END IF;
        END LOOP;
      END IF;

      DBG('Preapring Delete Types for  lctbs_contract_limits..');
      L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT;
      L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT;
      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_REC_FOUND := FALSE;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                      .PARTY_TYPE,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1)
                                  .PARTY_TYPE,
                                  '@')) AND
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                      .CUSTOMER_NO,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1)
                                  .CUSTOMER_NO,
                                  '@')) AND
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                      .CUSTOMER_NO,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1)
                                  .CUSTOMER_NO,
                                  '@')) AND
                 (NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                      .LINKED_REF_NO,
                      '@') = NVL(P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1)
                                  .LINKED_REF_NO,
                                  '@'))

               THEN
                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;
                EXIT;
              END IF;
            END LOOP;
          END IF;
          IF NOT L_REC_FOUND THEN
            DBG('Record is Deleted...');
            DBG('p_prev_lcdtronl customer_no >> ' || P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1)
                .CUSTOMER_NO);
            D_V_LCTBS_CONTRACT_LIMITS(D_V_LCTBS_CONTRACT_LIMITS.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(L_INDEX1);
          END IF;
        END LOOP;
      END IF;
      L_DEL_COUNT := D_V_LCTBS_CONTRACT_LIMITS.COUNT;
      DBG('Records Deleted  :' || L_DEL_COUNT);
      IF L_DEL_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
          DBG('Deleting Record...');
          DELETE LCTB_CONTRACT_LIMITS
           WHERE CONTRACT_REF_NO = D_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                .CONTRACT_REF_NO
             AND EVENT_SEQ_NO = D_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                .EVENT_SEQ_NO
             AND PARTY_TYPE = D_V_LCTBS_CONTRACT_LIMITS(L_INDEX).PARTY_TYPE
             AND CUSTOMER_NO = D_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                .CUSTOMER_NO
             AND LINKAGE_TYPE = D_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                .LINKAGE_TYPE
             AND LINKED_REF_NO = D_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                .LINKED_REF_NO;
        END LOOP;
      END IF;
      L_INS_COUNT := I_V_LCTBS_CONTRACT_LIMITS.COUNT;
      DBG('New Records Added  :' || L_INS_COUNT);
      DBG('l_Ins_Count' || L_INS_COUNT);
      DBG('CSPKS_req_wrapper.g_Function_id' ||
          CSPKS_REQ_WRAPPER.G_FUNCTION_ID);

      DBG('p_Wrk_Lcdtronl.v_Lctbs_Contract_Limits.COUNT::' ||
          P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT);
      DBG('l_Contract_count::' || L_CONTRACT_COUNT);

      SELECT COUNT(1)
        INTO L_ACONCOUNT
        FROM CSTBS_CONTRACT_EVENT_LOG
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
         AND EVENT_CODE = 'ACON'
         AND AUTH_STATUS = 'U';

      DBG('l_aconcount::' || L_ACONCOUNT);

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.COUNT > 0 AND
         NVL(CSPKS_REQ_WRAPPER.G_FUNCTION_ID, '**') <> 'LCDAMEND' AND
         L_CONTRACT_COUNT = 0 AND L_ACONCOUNT = 0 THEN
        FOR I IN P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS.LAST LOOP
          DELETE FROM LCTB_CONTRACT_LIMITS
           WHERE CONTRACT_REF_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .CONTRACT_REF_NO
             AND EVENT_SEQ_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .EVENT_SEQ_NO
             AND VERSION_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .VERSION_NO
             AND CUSTOMER_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .CUSTOMER_NO
             AND PARTY_TYPE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .PARTY_TYPE
             AND LINKED_REF_NO = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .LINKED_REF_NO
             AND LINKAGE_TYPE = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS(I)
                .LINKAGE_TYPE;
        END LOOP;
      END IF;

      BEGIN
        L_COUNT := I_V_LCTBS_CONTRACT_LIMITS.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO LCTB_CONTRACT_LIMITS
          VALUES I_V_LCTBS_CONTRACT_LIMITS
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Insert intoLCTBS_CONTRACT_LIMITS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@LCTBS_CONTRACT_LIMITS';
          RETURN FALSE;
      END;
      L_UPD_COUNT := U_V_LCTBS_CONTRACT_LIMITS.COUNT;
      DBG('Records Modified  :' || L_UPD_COUNT);
      IF L_UPD_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
          DBG('Updating the  Record...');
          BEGIN
            UPDATE LCTB_CONTRACT_LIMITS
               SET VERSION_NO         = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .VERSION_NO,
                   EVENT_CODE         = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .EVENT_CODE,
                   LINKAGE_PERCENTAGE = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .LINKAGE_PERCENTAGE,
                   LINKAGE_SEQ_NO     = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .LINKAGE_SEQ_NO,
                   OPERATION          = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .OPERATION,
                   LIMIT_AMOUNT       = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .LIMIT_AMOUNT,
                   JV_PARENT          = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .JV_PARENT,
                   AMOUNT_TAG         = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .AMOUNT_TAG,
                   LIABLITY_NO        = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                                        .LIABLITY_NO
             WHERE CONTRACT_REF_NO = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                  .CONTRACT_REF_NO
               AND EVENT_SEQ_NO = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                  .EVENT_SEQ_NO
               AND PARTY_TYPE = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                  .PARTY_TYPE
               AND CUSTOMER_NO = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                  .CUSTOMER_NO
               AND LINKAGE_TYPE = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                  .LINKAGE_TYPE
               AND LINKED_REF_NO = U_V_LCTBS_CONTRACT_LIMITS(L_INDEX)
                  .LINKED_REF_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Updating LCTBS_CONTRACT_LIMITS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_CONTRACT_LIMITS';
              RETURN FALSE;
          END;
        END LOOP;
      END IF;

      IF P_FUNCTION_ID IN ('LCDGUONL', 'LIDGUONL', 'LCDGUAMD', 'LIDGUAMD') THEN

        DBG('Preapring Insert and Update Types for  LCTBS_TERMS_CONDITIONS..');
        L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS.COUNT;
        L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_TERMS_CONDITIONS.COUNT;
        IF L_WRK_COUNT > 0 THEN
          FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
            L_REC_FOUND := FALSE;
            IF L_PREV_COUNT > 0 THEN
              FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                IF P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                 .TERMS_SL_NO = P_PREV_LCDTRONL.V_LCTBS_TERMS_CONDITIONS(L_INDEX1)
                   .TERMS_SL_NO THEN
                  DBG('Record Has been Found.Update Case..');
                  L_REC_FOUND := TRUE;
                  EXIT;
                END IF;
              END LOOP;
            END IF;
            IF L_REC_FOUND THEN
              DBG('Record is Modified...');
              U_V_LCTBS_TERMS_CONDITIONS(U_V_LCTBS_TERMS_CONDITIONS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS(L_INDEX);
            ELSE
              DBG('Record is Added...');
              I_V_LCTBS_TERMS_CONDITIONS(I_V_LCTBS_TERMS_CONDITIONS.COUNT + 1) := P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS(L_INDEX);
            END IF;
          END LOOP;
        END IF;

        DBG('Preapring Delete Types for  LCTBS_TERMS_CONDITIONS..');
        L_WRK_COUNT  := P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS.COUNT;
        L_PREV_COUNT := P_PREV_LCDTRONL.V_LCTBS_TERMS_CONDITIONS.COUNT;
        IF L_PREV_COUNT > 0 THEN
          FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
            L_REC_FOUND := FALSE;
            IF L_WRK_COUNT > 0 THEN
              FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
                IF P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                 .TERMS_SL_NO = P_PREV_LCDTRONL.V_LCTBS_TERMS_CONDITIONS(L_INDEX1)
                   .TERMS_SL_NO THEN
                  DBG('Record Has been Found.Update Case..');
                  L_REC_FOUND := TRUE;
                  EXIT;
                END IF;
              END LOOP;
            END IF;
            IF NOT L_REC_FOUND THEN
              DBG('Record is Deleted...');
              D_V_LCTBS_TERMS_CONDITIONS(D_V_LCTBS_TERMS_CONDITIONS.COUNT + 1) := P_PREV_LCDTRONL.V_LCTBS_TERMS_CONDITIONS(L_INDEX1);
            END IF;
          END LOOP;
        END IF;
        L_DEL_COUNT := D_V_LCTBS_TERMS_CONDITIONS.COUNT;
        DBG('Records Deleted  :' || L_DEL_COUNT);
        IF L_DEL_COUNT > 0 THEN
          FOR L_INDEX IN 1 .. L_DEL_COUNT LOOP
            DBG('Deleting Record...');
            DELETE LCTBS_TERMS_CONDITIONS
             WHERE CONTRACT_REF_NO = D_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                  .CONTRACT_REF_NO
               AND TERMS_SL_NO = D_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                  .TERMS_SL_NO
               AND EVENT_SEQ_NO = D_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                  .EVENT_SEQ_NO;
          END LOOP;
        END IF;
        L_INS_COUNT := I_V_LCTBS_TERMS_CONDITIONS.COUNT;
        DBG('New Records Added  :' || L_INS_COUNT);
        DBG('l_Ins_Count' || L_INS_COUNT);
        BEGIN
          L_COUNT := I_V_LCTBS_TERMS_CONDITIONS.COUNT;
          FORALL L_INDEX IN 1 .. L_COUNT
            INSERT INTO LCTBS_TERMS_CONDITIONS
            VALUES I_V_LCTBS_TERMS_CONDITIONS
              (L_INDEX);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Insert into LCTBS_TERMS_CONDITIONS..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@LCTBS_TERMS_CONDITIONS';
            RETURN FALSE;
        END;
        L_UPD_COUNT := U_V_LCTBS_TERMS_CONDITIONS.COUNT;
        DBG('Records Modified  :' || L_UPD_COUNT);
        IF L_UPD_COUNT > 0 THEN
          FOR L_INDEX IN 1 .. L_UPD_COUNT LOOP
            DBG('Updating the  Record...');
            BEGIN
              UPDATE LCTBS_TERMS_CONDITIONS
                 SET VERSION_NO       = U_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                                        .VERSION_NO,
                     EVENT_CODE       = U_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                                        .EVENT_CODE,
                     UNDERTAKING_TYPE = U_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                                        .UNDERTAKING_TYPE,
                     TERMS_CONDITIONS = U_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                                        .TERMS_CONDITIONS
               WHERE CONTRACT_REF_NO = U_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                    .CONTRACT_REF_NO
                 AND EVENT_SEQ_NO = U_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                    .EVENT_SEQ_NO
                 AND TERMS_SL_NO = U_V_LCTBS_TERMS_CONDITIONS(L_INDEX)
                    .TERMS_SL_NO;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in Updating LCTBS_TERMS_CONDITIONS..');
                DBG(SQLERRM);
                P_ERR_CODE   := 'ST-UPLD-001';
                P_ERR_PARAMS := '@LCTBS_TERMS_CONDITIONS';
                RETURN FALSE;
            END;
          END LOOP;
        END IF;
      END IF;

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      DBG('Calling Lcpks_Lcdtronl_Utils.Fn_Open_Policy_Update..');

      IF NOT LCPKS_LCDTRONL_UTILS.FN_OPEN_POLICY_UPDATE(P_SOURCE,
                                                        P_FUNCTION_ID,
                                                        'MINUS',
                                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                        'N',
                                                        P_WRK_LCDTRONL,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN

        DBG('failed in fn_open_policy_update');
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;
      END IF;

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      DBG('Only Server Processing Requied..');

      IF NOT LCPKS_LCDTRONL_UTILS.FN_OPEN_POLICY_UPDATE(P_SOURCE,
                                                        P_FUNCTION_ID,
                                                        'MINUS',
                                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                        'N',
                                                        P_WRK_LCDTRONL,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN

        DBG('failed in fn_open_policy_update');
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;
      END IF;

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      DBG('Only Server Processing Requied..');
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REVERSE THEN

      IF NOT LCPKS_LCDTRONL_UTILS.FN_OPEN_POLICY_UPDATE(P_SOURCE,
                                                        P_FUNCTION_ID,
                                                        'MINUS',
                                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_AMT,
                                                        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                                        'N',
                                                        P_WRK_LCDTRONL,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN

        DBG('failed in fn_open_policy_update');
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;
      END IF;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_ROLLOVER) THEN

      IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM IS NULL THEN
        IF P_WRK_LCDTRONL.V_LCTBS_GOODS.INCO_TERM IS NOT NULL THEN

          UPDATE LCTBS_CONTRACT_MASTER
             SET INCO_TERM = P_WRK_LCDTRONL.V_LCTBS_GOODS.INCO_TERM
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;
        END IF;

      ELSE

        UPDATE LCTBS_GOODS
           SET INCO_TERM = P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_GOODS.CONTRACT_REF_NO
           AND EVENT_SEQ_NO = P_WRK_LCDTRONL.V_LCTBS_GOODS.EVENT_SEQ_NO;

        IF SQL%ROWCOUNT = 0 THEN
          DBG('Inserting Goods Record for Inco TErm..');

          P_WRK_LCDTRONL.V_LCTBS_GOODS.INCO_TERM := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.INCO_TERM;

          BEGIN
            INSERT INTO LCTB_GOODS VALUES P_WRK_LCDTRONL.V_LCTBS_GOODS;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in Insert intoLCTBS_GOODS..');
              DBG(SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@LCTBS_GOODS';
              RETURN FALSE;
          END;
        END IF;

      END IF;

    END IF;

    DBG('Returning Success from fn_post_upload_db');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_post_upload_db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UPLOAD_DB;

  FUNCTION FN_PRE_PROCESS(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_CHILD_FUNCTION   IN VARCHAR2,
                          P_MULTI_TRIP_ID    IN VARCHAR2,
                          P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                          P_PREV_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                          P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    DBG('In fn_pre_Process');

    DBG('Returning Success from fn_pre_Process');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PROCESS;

  FUNCTION FN_POST_PROCESS(P_SOURCE           IN VARCHAR2,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_FUNCTION_ID      IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_CHILD_FUNCTION   IN VARCHAR2,
                           P_MULTI_TRIP_ID    IN VARCHAR2,
                           P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                           P_PREV_LCDTRONL    IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                           P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_PREV_LCDTRONL LCPKS_LCDTRONL_MAIN.TY_LCDTRONL := P_PREV_LCDTRONL;

    L_MSG_TYPE   CSTBS_CONTRACT_EVENT_ADVICE.MSG_TYPE%TYPE;
    L_PARTY_TYPE CSTBS_CONTRACT_EVENT_ADVICE.PARTY_TYPE%TYPE;
    L_DCN        MSTBS_DLY_MSG_IN.DCN%TYPE;
    L_ERR_CODE   ERTBS_MSGS.ERR_CODE%TYPE;
    L_PROD_TYPE  LCTMS_PRODUCT_DEFINITION.PRODUCT_TYPE%TYPE;

    L_EVENTCODE     CSTBS_CONTRACT_EVENT_LOG.EVENT_CODE%TYPE;
    L_POST_UPL_STAT VARCHAR2(1);

    L_OVD_STATUS   VARCHAR2(1) := 'N';
    L_OVD_TYPE     VARCHAR2(1) := '';
    L_EVENT_SEQ_NO CSTBS_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE;

    CURSOR C_DUAL_AUTH(C_CONTRACT_REF_NO IN VARCHAR2,
                       C_EVENT_SEQ_NO    IN CSTBS_CONTRACT_EVENT_LOG.EVENT_SEQ_NO%TYPE) IS
      SELECT *
        FROM CSTB_CONTRACT_OVD
       WHERE CONTRACT_REF_NO = C_CONTRACT_REF_NO
         AND EVENT_SEQ_NO >= C_EVENT_SEQ_NO;

  BEGIN
    DBG('In fn_post_Process' || P_ACTION_CODE);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_ROLLOVER,
                         CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_REOPEN,
                         CSPKS_REQ_GLOBAL.P_CONFIRM,
                         CSPKS_REQ_GLOBAL.P_REVERSE,
                         CSPKS_REQ_GLOBAL.P_HOLD) THEN

      DBG('Calling the lcpks_lcdtonl_Main.Fn_Subsys_Pickup..');
      IF NOT LCPKS_LCDTRONL_MAIN.FN_SUBSYS_PICKUP(P_SOURCE,
                                                  P_SOURCE_OPERATION,
                                                  P_FUNCTION_ID,
                                                  P_ACTION_CODE,
                                                  P_LCDTRONL,
                                                  L_PREV_LCDTRONL,
                                                  P_WRK_LCDTRONL,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN

        DBG('Failed in the lcpks_lcdtonl_Main.Fnsubsyspkp.....');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('USER ID:: ' || GLOBAL.USER_ID);
    DBG('DCN:: ' || P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD94);
    DBG('Contract_ref_no:: ' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO);
    DBG('Version_no:: ' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
    DBG('Event_seq_no:: ' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
    DBG('Event Code:: ' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE);
    DBG('Guarantee_ref_no:: ' ||
        P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD95);
    DBG('Guarantee_ref_no:: ' ||
        P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD95);

    IF P_ACTION_CODE NOT IN
       ('DEFAULTDOC', 'POPULATELIMIT', 'DEFAULTLOCALDET')

     THEN

      BEGIN
        SELECT PRODUCT_TYPE
          INTO L_PROD_TYPE
          FROM LCTMS_PRODUCT_DEFINITION
         WHERE PRODUCT_CODE = SUBSTR(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                     4,
                                     4);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No Such Product Exists');
          RETURN FALSE;
      END;

      FOR I IN 1 .. P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT LOOP
        IF P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(I).MSG_TYPE = 'GUARANTEE' THEN
          L_MSG_TYPE   := P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(I).MSG_TYPE;
          L_PARTY_TYPE := P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(I)
                          .PARTY_TYPE;
          EXIT;
        ELSIF ((P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE(I)
              .MSG_TYPE <> 'GUARANTEE' OR L_PROD_TYPE <> 'G') AND
              P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD95 IS NOT NULL) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'LCCON-097', NULL);

          RETURN FALSE;
        END IF;
      END LOOP;

      L_DCN := P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD94;
      IF P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD95 IS NOT NULL THEN
        IF NOT LCPKS_LCDTRONL_UTILS.FN_UPLD760(P_SOURCE,
                                               P_FUNCTION_ID,
                                               GLOBAL.USER_ID,
                                               L_DCN,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_CODE,
                                               L_MSG_TYPE,
                                               L_PARTY_TYPE,
                                               L_ERR_CODE,
                                               P_ERR_PARAMS) THEN

          DBG('failed in fn_upld760');
          OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);

          RETURN FALSE;
        END IF;
      END IF;

      IF P_ACTION_CODE <> CSPKS_REQ_GLOBAL.P_HOLD THEN
        DBG('Calling the lcpks_lcdtonl_utils.Fn_Process...');
        IF NOT LCPKS_LCDTRONL_UTILS.FN_PROCESS(P_SOURCE,
                                               P_SOURCE_OPERATION,
                                               P_FUNCTION_ID,
                                               P_ACTION_CODE,
                                               P_MULTI_TRIP_ID,
                                               P_LCDTRONL,
                                               P_PREV_LCDTRONL,
                                               P_WRK_LCDTRONL,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN

          DBG('Failed in the lcpks_lcdtonl_utils.Fn_Process...');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE AND
       P_FUNCTION_ID NOT IN ('LCDAMEND', 'LIDAMEND', 'LCDGUAMD') THEN
      DBG('Action is Close');

      BEGIN
        SELECT EVENT_CODE, EVENT_SEQ_NO
          INTO L_EVENTCODE, L_EVENT_SEQ_NO
          FROM CSTBS_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND EVENT_SEQ_NO = (SELECT MIN(EVENT_SEQ_NO)
                                 FROM CSTBS_CONTRACT_EVENT_LOG
                                WHERE CONTRACT_REF_NO =
                                      P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
                                  AND AUTH_STATUS = 'U');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data');
          DBG(SQLERRM);
      END;

      IF NOT CSPKS_REQ_UTILS.FN_GET_AUTO_AUTH_STATUS(P_SOURCE,
                                                     P_SOURCE_OPERATION,
                                                     P_FUNCTION_ID,
                                                     P_ACTION_CODE,
                                                     'A',
                                                     NULL,
                                                     NULL,
                                                     L_POST_UPL_STAT,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
        DBG('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Kernel Calling Cspks_Req_Utils.Fn_Get_Upload_Status..');
      IF NOT CSPKS_REQ_UTILS.FN_GET_UPLOAD_STATUS(P_SOURCE,
                                                  P_SOURCE_OPERATION,
                                                  P_FUNCTION_ID,
                                                  P_ACTION_CODE,
                                                  CSPKS_GLOBAL.G_HEADER('MULTITRIPID'),
                                                  NULL,
                                                  L_POST_UPL_STAT,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
        DBG('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('l_Event_Seq_No >>>>>>' || L_EVENT_SEQ_NO);
      DBG('l_eventcode >>>>>>' || L_EVENTCODE);
      FOR J IN C_DUAL_AUTH(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                           L_EVENT_SEQ_NO) LOOP

        L_ERR_CODE := J.ERR_CODE;
        L_OVD_TYPE := OVPKSS.FN_GETTYPE(L_ERR_CODE);
        DBG('l_Ovd_Type>>>>>>' || L_OVD_TYPE);
        IF L_OVD_TYPE = 'D' THEN
          DBG('Contract Having Dual Auth Override Setting Auth Status to U');
          L_OVD_STATUS := 'Y';
          EXIT;
        END IF;
      END LOOP;

      DBG('l_Post_Upl_Stat::' || L_POST_UPL_STAT);
      IF L_POST_UPL_STAT IN ('U', 'A') THEN
        CSPKS_REQ_GLOBAL.PR_SET_LOG_RESULT_ERROR_CODE(FALSE);
      END IF;

      IF L_EVENTCODE = 'CLOS' THEN

        IF L_POST_UPL_STAT = 'A' AND L_OVD_STATUS = 'N'

         THEN
          DBG('Operation is Close and Auth');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'FX-RESP-009', NULL);

        ELSIF L_POST_UPL_STAT = 'U' THEN

          DBG('Operation is Close');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'FX-RESP-006', NULL);
        END IF;
      ELSIF L_EVENTCODE = 'CANC' THEN

        IF L_POST_UPL_STAT = 'A' AND L_OVD_STATUS = 'N'

         THEN
          DBG('Operation is Cancel and Auth');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'PD-ONL18', NULL);

        ELSIF L_POST_UPL_STAT = 'U' THEN

          DBG('Operation is Cancel');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'PD-ONL17', NULL);
        END IF;
      END IF;
    END IF;

    DBG('Returning Success from fn_post_Process');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_post_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PROCESS;

  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CHILD_FUNCTION   IN VARCHAR2,
                        P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                        P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                        P_QRYDATA_REQD     IN VARCHAR2,
                        P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                        P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    DBG('In fn_pre_query');

    DBG(' p_Wrk_Lcdtronl.v_Cstbs_Contract.Contract_Ref_No ::::: ' ||
        P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_COPY THEN
      DBG('p_Action_Code is Copy');
      BEGIN
        SELECT *
          INTO P_WRK_LCDTRONL.V_CSTBS_CONTRACT
          FROM CSTB_CONTRACT
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in selecting the master Recotrd');
          DBG('Record Does not Exist..');
      END;
      BEGIN
        SELECT *
          INTO P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER
          FROM LCTBS_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND VERSION_NO = 1;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Error in Selecting  Lctbs_Contract_Master ');
      END;
    END IF;

    P_WRK_LCDTRONL.TY_MSCCOMPM.V_MSTB_CONTRACT_COMMSG.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
    P_WRK_LCDTRONL.TY_MSCCOMPM.V_MSTB_CONTRACT_COMMSG.EVENT_SEQ_NO    := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO;
    DBG(' p_Wrk_lcdtronl.Ty_msccompm.v_mstbs_commsg_master.contract_ref_no ::::: ' ||
        P_WRK_LCDTRONL.TY_MSCCOMPM.V_MSTB_CONTRACT_COMMSG.CONTRACT_REF_NO);
    DBG(' p_Wrk_lcdtronl.Ty_msccompm.v_mstb_contract_commsg.event_seq_no ::::: ' ||
        P_WRK_LCDTRONL.TY_MSCCOMPM.V_MSTB_CONTRACT_COMMSG.EVENT_SEQ_NO);

    DBG('Returning Success from fn_pre_query');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_pre_query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;

  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CHILD_FUNCTION   IN VARCHAR2,
                         P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                         P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                         P_QRYDATA_REQD     IN VARCHAR2,
                         P_LCDTRONL         IN LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                         P_WRK_LCDTRONL     IN OUT LCPKS_LCDTRONL_MAIN.TY_LCDTRONL,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_TOT_GOODS_AMT NUMBER := 0;
    L_VERSION       NUMBER;
    L_EVENT_SEQ_NO  NUMBER;

    L_LOG_REC    CSTB_CONTRACT_EVENT_LOG%ROWTYPE;
    L_AUTH_COUNT NUMBER := 0;
    L_REC_EXISTS BOOLEAN := TRUE;
    RECORD_LOCKED EXCEPTION;
    L_FLD    VARCHAR2(100);
    L_MODULE SMTB_MENU.MODULE%TYPE;
    L_ESN    NUMBER;

    L_NXT_EVENT_SEQ_NO NUMBER;
    L_EVENT_SEQ_NO_NEW NUMBER;
    L_EVSEQ1           NUMBER;

    L_REIM_FLAG           LCTM_PRODUCT_DEFINITION.REIMBURSEMENT%TYPE;
    L_ADVOFGUA_FLG        LCTM_PRODUCT_DEFINITION.ADVICE_OF_GUARANTEE%TYPE;
    L_PRODUCT_TYPE        LCTM_PRODUCT_DEFINITION.PRODUCT_TYPE%TYPE;
    L_ADVICE_OF_STANDBYLC LCTM_PRODUCT_DEFINITION.ADVICE_OF_STANDBYLC%TYPE;

    CURSOR C_DOC_UPLOAD_1 IS
      SELECT *
        FROM CSTB_DOC_UPLOAD_DETAIL
       WHERE KEY_ID = GLOBAL.CURRENT_BRANCH || ':' ||
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

    CURSOR C_PARTIES(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTB_PARTIES
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTBS_PARTIES
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND EVENT_SEQ_NO <= P_SEQ);

    CURSOR CR_GOODS_DETAILS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTB_GOODS_DETAILS A
       WHERE A.CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND A.EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM LCTB_GOODS_DETAILS
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                 AND EVENT_SEQ_NO <= P_SEQ);

    CURSOR C_OTHER_ADDRESS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTBS_OTHER_ADDRESSES
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTBS_OTHER_ADDRESSES
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND EVENT_SEQ_NO <= P_SEQ);

    CURSOR C_DOCUMENTS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTB_DOCUMENTS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTBS_DOCUMENTS
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO

                                AND EVENT_SEQ_NO <= P_SEQ)
       ORDER BY DOC_SL_NO;

    CURSOR C_DOC_CLAUSE(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTBS_CLAUSES
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTBS_CLAUSES
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND EVENT_SEQ_NO <= P_SEQ);

    CURSOR C_TRACERS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTB_TRACERS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTBS_TRACERS
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND EVENT_SEQ_NO <= P_SEQ);

    CURSOR C_DRAFTS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTB_DRAFTS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTB_DRAFTS
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND EVENT_SEQ_NO <= P_SEQ);

    CURSOR C_DRAFTS_DETAILS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTB_DRAFTS_DETAILS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTB_DRAFTS_DETAILS
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND EVENT_SEQ_NO <= P_SEQ);

    CURSOR C_FFTS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTB_FFTS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTB_FFTS
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO

                                AND EVENT_SEQ_NO <= P_SEQ)

       ORDER BY FFT_INS_SL_NO;

    CURSOR C_ADVICES(P_SEQ_NO NUMBER) IS
      SELECT *
        FROM CSTB_CONTRACT_EVENT_ADVICE
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = P_SEQ_NO;

    CURSOR C_FFTS_QUERY(L_VERSION NUMBER) IS
      SELECT *
        FROM LCTB_FFTS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO

         AND VERSION_NO = L_VERSION

       ORDER BY FFT_INS_SL_NO;

    CURSOR C_ADVICES_QUERY(P_SEQ_NO           NUMBER,
                           L_NXT_EVENT_SEQ_NO NUMBER,
                           P_EVSEQ            NUMBER) IS

      SELECT *
        FROM CSTB_CONTRACT_EVENT_ADVICE
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO BETWEEN P_SEQ_NO AND
             NVL(L_NXT_EVENT_SEQ_NO, P_EVSEQ);

    CURSOR C_TRANS(P_SEQ_NO NUMBER) IS

      SELECT A.*
        FROM LCTBS_TRANSFER_DETAILS A
       WHERE A.FROM_LCREF = P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND A.ESN <= P_SEQ_NO;

    CURSOR C_ADVICESUNAUTH IS
      SELECT A.*
        FROM CSTB_CONTRACT_EVENT_ADVICE A, CSTB_CONTRACT_EVENT_LOG B
       WHERE A.CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
         AND B.AUTH_STATUS = 'U'
         AND A.EVENT_SEQ_NO = B.EVENT_SEQ_NO;

    CURSOR C_ADVICESUNAUTHAMND(P_ESN NUMBER) IS
      SELECT A.*
        FROM CSTB_CONTRACT_EVENT_ADVICE A
       WHERE A.CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND A.EVENT_SEQ_NO >= P_ESN;

    CURSOR C_LIMITS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTBS_CONTRACT_LIMITS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTBS_CONTRACT_LIMITS
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND EVENT_SEQ_NO <= P_SEQ);

    L_COUNT NUMBER;

    CURSOR CR_UDFDET(P_REF VARCHAR2, P_VER NUMBER) IS

      SELECT CONTRACT_REF_NO,
             VERSION_NO,
             FIELD_NAME,
             FIELD_VALUE,
             '',
             '',
             DATA_TYPE,
             VAL_TYPE,
             '',
             GLOBAL.CURRENT_BRANCH,
             '',
             MANDATORY,
             FIELD_DESCRIPTION
        FROM (SELECT U.CONTRACT_REF_NO,
                     VERSION_NO,
                     P.FIELD_NAME,
                     P.FIELD_NUM,

                     DECODE(P.FIELD_NUM,
                            1,
                            FIELD_VAL_1,
                            2,
                            FIELD_VAL_2,
                            3,
                            FIELD_VAL_3,
                            4,
                            FIELD_VAL_4,
                            5,
                            FIELD_VAL_5,
                            6,
                            FIELD_VAL_6,
                            7,
                            FIELD_VAL_7,
                            8,
                            FIELD_VAL_8,
                            9,
                            FIELD_VAL_9,
                            10,
                            FIELD_VAL_10,
                            11,
                            FIELD_VAL_11,
                            12,
                            FIELD_VAL_12,
                            13,
                            FIELD_VAL_13,
                            14,
                            FIELD_VAL_14,
                            15,
                            FIELD_VAL_15,
                            16,
                            FIELD_VAL_16,
                            17,
                            FIELD_VAL_17,
                            18,
                            FIELD_VAL_18,
                            19,
                            FIELD_VAL_19,
                            20,
                            FIELD_VAL_20,
                            21,
                            FIELD_VAL_21,
                            22,
                            FIELD_VAL_22,
                            23,
                            FIELD_VAL_23,
                            24,
                            FIELD_VAL_24,
                            25,
                            FIELD_VAL_25,
                            26,
                            FIELD_VAL_26,
                            27,
                            FIELD_VAL_27,
                            28,
                            FIELD_VAL_28,
                            29,
                            FIELD_VAL_29,
                            30,
                            FIELD_VAL_30,
                            31,
                            FIELD_VAL_31,
                            32,
                            FIELD_VAL_32,
                            33,
                            FIELD_VAL_33,
                            34,
                            FIELD_VAL_34,
                            35,
                            FIELD_VAL_35,
                            36,
                            FIELD_VAL_36,
                            37,
                            FIELD_VAL_37,
                            38,
                            FIELD_VAL_38,
                            39,
                            FIELD_VAL_39,
                            40,
                            FIELD_VAL_40,
                            41,
                            FIELD_VAL_41,
                            42,
                            FIELD_VAL_42,
                            43,
                            FIELD_VAL_43,
                            44,
                            FIELD_VAL_44,
                            45,
                            FIELD_VAL_45,
                            46,
                            FIELD_VAL_46,
                            47,
                            FIELD_VAL_47,
                            48,
                            FIELD_VAL_48,
                            49,
                            FIELD_VAL_49,
                            50,
                            FIELD_VAL_50,
                            51,
                            FIELD_VAL_51,
                            52,
                            FIELD_VAL_52,
                            53,
                            FIELD_VAL_53,
                            54,
                            FIELD_VAL_54,
                            55,
                            FIELD_VAL_55,
                            56,
                            FIELD_VAL_56,
                            57,
                            FIELD_VAL_57,
                            58,
                            FIELD_VAL_58,
                            59,
                            FIELD_VAL_59,
                            60,
                            FIELD_VAL_60,
                            61,
                            FIELD_VAL_61,
                            62,
                            FIELD_VAL_62,
                            63,
                            FIELD_VAL_63,
                            64,
                            FIELD_VAL_64,
                            65,
                            FIELD_VAL_65,
                            66,
                            FIELD_VAL_66,
                            67,
                            FIELD_VAL_67,
                            68,
                            FIELD_VAL_68,
                            69,
                            FIELD_VAL_69,
                            70,
                            FIELD_VAL_70,
                            71,
                            FIELD_VAL_71,
                            72,
                            FIELD_VAL_72,
                            73,
                            FIELD_VAL_73,
                            74,
                            FIELD_VAL_74,
                            75,
                            FIELD_VAL_75,
                            76,
                            FIELD_VAL_76,
                            77,
                            FIELD_VAL_77,
                            78,
                            FIELD_VAL_78,
                            79,
                            FIELD_VAL_79,
                            80,
                            FIELD_VAL_80,
                            81,
                            FIELD_VAL_81,
                            82,
                            FIELD_VAL_82,
                            83,
                            FIELD_VAL_83,
                            84,
                            FIELD_VAL_84,
                            85,
                            FIELD_VAL_85,
                            86,
                            FIELD_VAL_86,
                            87,
                            FIELD_VAL_87,
                            88,
                            FIELD_VAL_88,
                            89,
                            FIELD_VAL_89,
                            90,
                            FIELD_VAL_90,
                            91,
                            FIELD_VAL_91,
                            92,
                            FIELD_VAL_92,
                            93,
                            FIELD_VAL_93,
                            94,
                            FIELD_VAL_94,
                            95,
                            FIELD_VAL_95,
                            96,
                            FIELD_VAL_96,
                            97,
                            FIELD_VAL_97,
                            98,
                            FIELD_VAL_98,
                            99,
                            FIELD_VAL_99) AS FIELD_VALUE,
                     '',
                     '',
                     F.FIELD_TYPE AS DATA_TYPE,
                     F.VAL_TYPE AS VAL_TYPE,
                     '',
                     GLOBAL.CURRENT_BRANCH,
                     '',
                     F.MANDATORY,
                     F.FIELD_DESCRIPTION
                FROM CSTMS_CONTRACT_USERDEF_FIELDS U,
                     CSTMS_PRODUCT_UDF_FIELDS_MAP  P,
                     UDTM_FIELDS                   F
               WHERE P.PRODUCT_CODE = SUBSTR(P_REF, 4, 4)
                 AND P.AUTH_STAT = 'A'
                 AND F.FIELD_NAME = P.FIELD_NAME
                 AND U.PRODUCT_CODE(+) = P.PRODUCT_CODE
                 AND U.CONTRACT_REF_NO(+) = P_REF
                 AND U.VERSION_NO IN
                     (SELECT MAX(VERSION_NO)
                        FROM CSTM_CONTRACT_USERDEF_FIELDS
                       WHERE CONTRACT_REF_NO = P_REF
                         AND VERSION_NO <= P_VER)
                 AND P.FIELD_NUM <= 99
              UNION

              SELECT U.CONTRACT_REF_NO,
                     VERSION_NO,
                     P.FIELD_NAME,
                     P.FIELD_NUM,

                     DECODE(P.FIELD_NUM,
                            100,
                            FIELD_VAL_100,
                            101,
                            FIELD_VAL_101,
                            102,
                            FIELD_VAL_102,
                            103,
                            FIELD_VAL_103,
                            104,
                            FIELD_VAL_104,
                            105,
                            FIELD_VAL_105,
                            106,
                            FIELD_VAL_106,
                            107,
                            FIELD_VAL_107,
                            108,
                            FIELD_VAL_108,
                            109,
                            FIELD_VAL_109,
                            110,
                            FIELD_VAL_110,
                            111,
                            FIELD_VAL_111,
                            112,
                            FIELD_VAL_112,
                            113,
                            FIELD_VAL_113,
                            114,
                            FIELD_VAL_114,
                            115,
                            FIELD_VAL_115,
                            116,
                            FIELD_VAL_116,
                            117,
                            FIELD_VAL_117,
                            118,
                            FIELD_VAL_118,
                            119,
                            FIELD_VAL_119,
                            120,
                            FIELD_VAL_120,
                            121,
                            FIELD_VAL_121,
                            122,
                            FIELD_VAL_122,
                            123,
                            FIELD_VAL_123,
                            124,
                            FIELD_VAL_124,
                            125,
                            FIELD_VAL_125,
                            126,
                            FIELD_VAL_126,
                            127,
                            FIELD_VAL_127,
                            128,
                            FIELD_VAL_128,
                            129,
                            FIELD_VAL_129,
                            130,
                            FIELD_VAL_130,
                            131,
                            FIELD_VAL_131,
                            132,
                            FIELD_VAL_132,
                            133,
                            FIELD_VAL_133,
                            134,
                            FIELD_VAL_134,
                            135,
                            FIELD_VAL_135,
                            136,
                            FIELD_VAL_136,
                            137,
                            FIELD_VAL_137,
                            138,
                            FIELD_VAL_138,
                            139,
                            FIELD_VAL_139,
                            140,
                            FIELD_VAL_140,
                            141,
                            FIELD_VAL_141,
                            142,
                            FIELD_VAL_142,
                            143,
                            FIELD_VAL_143,
                            144,
                            FIELD_VAL_144,
                            145,
                            FIELD_VAL_145,
                            146,
                            FIELD_VAL_146,
                            147,
                            FIELD_VAL_147,
                            148,
                            FIELD_VAL_148,
                            149,
                            FIELD_VAL_149,
                            150,
                            FIELD_VAL_150,
                            151,
                            FIELD_VAL_151,
                            152,
                            FIELD_VAL_152,
                            153,
                            FIELD_VAL_153,
                            154,
                            FIELD_VAL_154,
                            155,
                            FIELD_VAL_155,
                            156,
                            FIELD_VAL_156,
                            157,
                            FIELD_VAL_157,
                            158,
                            FIELD_VAL_158,
                            159,
                            FIELD_VAL_159,
                            160,
                            FIELD_VAL_160,
                            161,
                            FIELD_VAL_161,
                            162,
                            FIELD_VAL_162,
                            163,
                            FIELD_VAL_163,
                            164,
                            FIELD_VAL_164,
                            165,
                            FIELD_VAL_165,
                            166,
                            FIELD_VAL_166,
                            167,
                            FIELD_VAL_167,
                            168,
                            FIELD_VAL_168,
                            169,
                            FIELD_VAL_169,
                            170,
                            FIELD_VAL_170,
                            171,
                            FIELD_VAL_171,
                            172,
                            FIELD_VAL_172,
                            173,
                            FIELD_VAL_173,
                            174,
                            FIELD_VAL_174,
                            175,
                            FIELD_VAL_175,
                            176,
                            FIELD_VAL_176,
                            177,
                            FIELD_VAL_177,
                            178,
                            FIELD_VAL_178,
                            179,
                            FIELD_VAL_179,
                            180,
                            FIELD_VAL_180,
                            181,
                            FIELD_VAL_181,
                            182,
                            FIELD_VAL_182,
                            183,
                            FIELD_VAL_183,
                            184,
                            FIELD_VAL_184,
                            185,
                            FIELD_VAL_185,
                            186,
                            FIELD_VAL_186,
                            187,
                            FIELD_VAL_187,
                            188,
                            FIELD_VAL_188,
                            189,
                            FIELD_VAL_189,
                            190,
                            FIELD_VAL_190,
                            191,
                            FIELD_VAL_191,
                            192,
                            FIELD_VAL_192,
                            193,
                            FIELD_VAL_193,
                            194,
                            FIELD_VAL_194,
                            195,
                            FIELD_VAL_195,
                            196,
                            FIELD_VAL_196,
                            197,
                            FIELD_VAL_197,
                            198,
                            FIELD_VAL_198,
                            199,
                            FIELD_VAL_199,
                            200,
                            FIELD_VAL_200) AS FIELD_VALUE,
                     '',
                     '',
                     F.FIELD_TYPE AS DATA_TYPE,
                     F.VAL_TYPE AS VAL_TYPE,
                     '',
                     GLOBAL.CURRENT_BRANCH,
                     '',
                     F.MANDATORY,
                     F.FIELD_DESCRIPTION
                FROM CSTMS_CONTRACT_USERDEF_FIELDS U,
                     CSTMS_PRODUCT_UDF_FIELDS_MAP  P,
                     UDTM_FIELDS                   F
               WHERE P.PRODUCT_CODE = SUBSTR(P_REF, 4, 4)
                 AND P.AUTH_STAT = 'A'
                 AND F.FIELD_NAME = P.FIELD_NAME
                 AND U.PRODUCT_CODE(+) = P.PRODUCT_CODE
                 AND U.CONTRACT_REF_NO(+) = P_REF
                 AND U.VERSION_NO IN
                     (SELECT MAX(VERSION_NO)
                        FROM CSTM_CONTRACT_USERDEF_FIELDS
                       WHERE CONTRACT_REF_NO = P_REF
                         AND VERSION_NO <= P_VER)

                 AND P.FIELD_NUM > 99
               ORDER BY FIELD_NUM)
       WHERE 1 = 1;

    CURSOR C_TERMS_CONDITIONS(P_SEQ NUMBER) IS
      SELECT *
        FROM LCTB_TERMS_CONDITIONS
       WHERE CONTRACT_REF_NO =
             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM LCTB_TERMS_CONDITIONS
                              WHERE CONTRACT_REF_NO =
                                    P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                                AND EVENT_SEQ_NO <= P_SEQ)

       ORDER BY TERMS_SL_NO;

  BEGIN

    DBG('In fn_post_query' || P_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD1);

    IF P_ACTION_CODE NOT IN
       ('DEFAULTDOC', 'POPULATELIMIT', 'DEFAULTLOCALDET')

     THEN

      IF NVL(P_WITH_LOCK, 'N') = 'Y' THEN

        DBG('p_Action_Code Not query');
        BEGIN
          SELECT *
            INTO P_WRK_LCDTRONL.V_CSTBS_CONTRACT
            FROM CSTB_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             FOR UPDATE NOWAIT;
        EXCEPTION
          WHEN RECORD_LOCKED THEN
            DBG('Failed to Obtain the Lock..');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-LOCK-001', NULL);

            RETURN FALSE;
          WHEN NO_DATA_FOUND THEN
            DBG('Failed in selecting the master Recotrd');
            DBG('Record Does not Exist..');
            L_REC_EXISTS := FALSE;
        END;

      ELSE
        DBG('For query it will come here');

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
          L_FLD := 'CSTBS_CONTRACT.CONTRACT_REF_NO';

          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO := P_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

          BEGIN
            SELECT CHAR_FIELD92
              INTO P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92
              FROM CSTBS_UI_COLUMNS
             WHERE CHAR_FIELD2 =
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 := 'Y';
          END;

        END IF;
        BEGIN
          SELECT *
            INTO P_WRK_LCDTRONL.V_CSTBS_CONTRACT
            FROM CSTB_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Failed in selecting the master Recotrd thru ref no');
            DBG('Record Does not Exist..');

            IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_DELETE) THEN

              DBG('Record has been deleted in the process ');
              L_REC_EXISTS := FALSE;
              RETURN TRUE;
            END IF;
            P_ERR_CODE := 'ST-VALS-002';

            P_ERR_PARAMS := '@' || L_FLD;

            L_REC_EXISTS := FALSE;
            RETURN FALSE;
        END;

      END IF;

      IF L_REC_EXISTS THEN

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
          DBG('Its cmg here...');

          IF P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO IS NULL THEN

            DBG('Not a version query');
            BEGIN
              SELECT LATEST_VERSION_NO, LATEST_EVENT_SEQ_NO
                INTO L_VERSION, L_EVENT_SEQ_NO

                FROM CSTB_CONTRACT
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

              SELECT EVENT_SEQ_NO
                INTO L_EVENT_SEQ_NO_NEW
                FROM LCTB_CONTRACT_MASTER
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                 AND VERSION_NO = L_VERSION;

            EXCEPTION
              WHEN OTHERS THEN
                DBG('Error in Selecting the Version Number ');
            END;
          ELSE
            DBG('This version query...' ||
                P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
            BEGIN
              SELECT VERSION_NO, EVENT_SEQ_NO
                INTO L_VERSION, L_EVENT_SEQ_NO

                FROM LCTB_CONTRACT_MASTER
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                 AND VERSION_NO =
                     (SELECT MAX(VERSION_NO)
                        FROM LCTB_CONTRACT_MASTER
                       WHERE CONTRACT_REF_NO =
                             P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO

                         AND VERSION_NO <=
                             P_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);

            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in selecting the version No');
            END;
          END IF;

        ELSE
          DBG('when Action  is not query...' || P_ACTION_CODE ||
              P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
          BEGIN
            SELECT LATEST_VERSION_NO, LATEST_EVENT_SEQ_NO
              INTO L_VERSION, L_EVENT_SEQ_NO

              FROM CSTB_CONTRACT
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

            DBG('l_version : ##' || L_VERSION);
            DBG('p_Action_Code :: ' || P_ACTION_CODE);
            DBG('p_wrk_lcdtronl.v_cstbs_contract.auth_status : ' ||
                P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTH_STATUS);
            IF P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTH_STATUS = 'A' THEN
              SELECT EVENT_SEQ_NO
                INTO L_EVENT_SEQ_NO_NEW
                FROM LCTB_CONTRACT_MASTER
               WHERE CONTRACT_REF_NO =
                     P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                 AND VERSION_NO = L_VERSION;
            END IF;

          EXCEPTION
            WHEN OTHERS THEN
              DBG('Error in Selecting the Version Number ');
          END;
        END IF;

        DBG('VERSION and EVENT NO :' || L_VERSION || L_EVENT_SEQ_NO);

        L_EVENT_SEQ_NO_NEW := NVL(L_EVENT_SEQ_NO_NEW, L_EVENT_SEQ_NO);
        BEGIN
          SELECT EVENT_SEQ_NO
            INTO L_NXT_EVENT_SEQ_NO
            FROM LCTB_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND VERSION_NO = L_VERSION + 1;

          L_NXT_EVENT_SEQ_NO := L_NXT_EVENT_SEQ_NO - 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Inside no data found');
            L_NXT_EVENT_SEQ_NO := NULL;
        END;
        DBG('l_nxt_event_seq_no----->' || L_NXT_EVENT_SEQ_NO);

        BEGIN
          SELECT *
            INTO L_LOG_REC
            FROM CSTBS_CONTRACT_EVENT_LOG
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO = L_EVENT_SEQ_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in Selecting the Cstbs_Contract_Event_Log  ');
        END;

        BEGIN
          SELECT *
            INTO P_WRK_LCDTRONL.V_CSTBS_CONTRACT
            FROM CSTBS_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        EXCEPTION

          WHEN NO_DATA_FOUND THEN
            DBG('Error in Selecting the Cstbs_Contract No data found');
          WHEN OTHERS THEN
            DBG('Error in Selecting the Cstbs_Contract when othres  ');
        END;

        BEGIN
          SELECT PRODUCT_TYPE,
                 REIMBURSEMENT,
                 ADVICE_OF_GUARANTEE,
                 ADVICE_OF_STANDBYLC
            INTO L_PRODUCT_TYPE,
                 L_REIM_FLAG,
                 L_ADVOFGUA_FLG,
                 L_ADVICE_OF_STANDBYLC
            FROM LCTM_PRODUCT_DEFINITION
           WHERE PRODUCT_CODE = SUBSTR(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO,
                                       4,
                                       4);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Unable to fetch Product type , reimbursement and Advice of Gua flag');
        END;
        IF L_PRODUCT_TYPE = 'I' AND L_REIM_FLAG = 'Y' THEN
          DBG('Product Type to be set as reimbursement');
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'R';
        ELSIF L_PRODUCT_TYPE = 'E' AND L_ADVOFGUA_FLG = 'Y' THEN
          DBG('Product Type to be set as Advice of Guarantee');
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'A';

        ELSIF L_PRODUCT_TYPE = 'E' AND L_ADVICE_OF_STANDBYLC = 'Y' THEN
          DBG('Product Type to be set as Advice of Guarantee');
          P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE := 'B';

        END IF;
        DBG('p_Wrk_Lcdtronl.v_Cstbs_Contract.Product_type' ||
            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE);

        DBG('Querying the master data' || L_VERSION);
        BEGIN
          SELECT *
            INTO P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER
            FROM LCTBS_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND VERSION_NO = L_VERSION;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in Selecting  Lctbs_Contract_Master ');
        END;
        DBG('p_wrk_Lcdtronl.v_Lctbs_Contract_Master.Max_Contract_Amt' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.MAX_CONTRACT_AMT);
        BEGIN
          SELECT *
            INTO P_WRK_LCDTRONL.V_LCTBS_AVAILMENTS
            FROM LCTBS_AVAILMENTS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_AVAILMENTS
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                     AND VERSION_NO <= L_VERSION);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in Selecting Lctbs_Availments ');
        END;

        BEGIN
          SELECT *
            INTO P_WRK_LCDTRONL.V_LCTBS_SHIPMENT
            FROM LCTBS_SHIPMENT
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_SHIPMENT
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                     AND VERSION_NO <= L_VERSION);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in Selecting Lctbs_Shipment');
        END;

        DBG('About to Query LCTBS_SPLPYMT_CONDITIONS');
        BEGIN
          SELECT *
            INTO P_WRK_LCDTRONL.V_LCTBS_SPLPYMT_CONDITIONS
            FROM LCTBS_SPLPYMT_CONDITIONS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND VERSION_NO = L_VERSION;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in Selecting Lctbs_Splpymt_Conditions');
        END;

        DBG('Seleting Goods Details');
        BEGIN
          SELECT *
            INTO P_WRK_LCDTRONL.V_LCTBS_GOODS
            FROM LCTBS_GOODS
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT MAX(EVENT_SEQ_NO)
                    FROM LCTBS_GOODS
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
                     AND VERSION_NO <= L_VERSION);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in Selecting the Lctbs_Goods ');
        END;

        DBG('anjali->action_code' || P_ACTION_CODE);
        IF P_ACTION_CODE <> CSPKS_REQ_GLOBAL.P_MODIFY THEN
          DBG('anjali->fetching the value in detail table');
          OPEN C_DOC_UPLOAD_1;
          LOOP
            FETCH C_DOC_UPLOAD_1 BULK COLLECT
              INTO P_WRK_LCDTRONL.TY_CSCDOCTR.V_CSTB_DOC_UPLOAD_DETAIL;
            EXIT WHEN C_DOC_UPLOAD_1%NOTFOUND;
          END LOOP;
          CLOSE C_DOC_UPLOAD_1;
          DBG('Get the Record For :cstb_doc_upload_detail');
        END IF;

        DBG('Seleting Parties Details');
        OPEN C_PARTIES(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_PARTIES BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_PARTIES;

          EXIT WHEN C_PARTIES%NOTFOUND;
        END LOOP;
        CLOSE C_PARTIES;

        BEGIN
          SELECT CONTRACT_REF_NO, EVENT_SEQ_NO, CONTRACT_CCY
            INTO P_WRK_LCDTRONL.V_GOODS_DETAILS__MASTER.CONTRACT_REF_NO,
                 P_WRK_LCDTRONL.V_GOODS_DETAILS__MASTER.EVENT_SEQ_NO,
                 P_WRK_LCDTRONL.V_GOODS_DETAILS__MASTER.CCY
            FROM LCTB_CONTRACT_MASTER
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
             AND EVENT_SEQ_NO =
                 (SELECT (MAX(EVENT_SEQ_NO))
                    FROM LCTB_CONTRACT_MASTER
                   WHERE CONTRACT_REF_NO =
                         P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in Selecting the Lctbs_Goods_Details');
        END;

        DBG('chkkk:::' || L_EVENT_SEQ_NO);
        DBG('Seleting new Goods Details - esn' ||
            P_WRK_LCDTRONL.V_GOODS_DETAILS__MASTER.EVENT_SEQ_NO);
        OPEN CR_GOODS_DETAILS(L_EVENT_SEQ_NO);
        LOOP
          FETCH CR_GOODS_DETAILS BULK COLLECT
            INTO P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL;
          EXIT WHEN CR_GOODS_DETAILS%NOTFOUND;
        END LOOP;
        CLOSE CR_GOODS_DETAILS;
        DBG('printing the count:' ||
            P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT);

        IF P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT > 0 THEN
          FOR I IN 1 .. P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL.COUNT LOOP
            DBG('chk GOODS_CODE:' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                .GOODS_CODE);
            DBG('chk UNITS:' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                .NO_OF_UNITS);
            DBG('chk PRICE:' || P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                .PRICE_PER_UNIT);
            L_TOT_GOODS_AMT := L_TOT_GOODS_AMT + (P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                               .NO_OF_UNITS * P_WRK_LCDTRONL.V_GOODS_DETAILS__DETAIL(I)
                               .PRICE_PER_UNIT);
            DBG('l_tot_goods_amt:::' || L_TOT_GOODS_AMT);
          END LOOP;
        END IF;
        P_WRK_LCDTRONL.V_CSTB_UI_COLUMNS__GOODS.NUM_FIELD20 := L_TOT_GOODS_AMT;

        DBG('Seleting Document Details');
        OPEN C_DOCUMENTS(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_DOCUMENTS BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_DOCUMENTS;
          EXIT WHEN C_DOCUMENTS%NOTFOUND;
        END LOOP;
        CLOSE C_DOCUMENTS;

        OPEN C_DOC_CLAUSE(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_DOC_CLAUSE BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_CLAUSES;
          EXIT WHEN C_DOC_CLAUSE%NOTFOUND;
        END LOOP;
        CLOSE C_DOC_CLAUSE;

        DBG('selecting Tracers');
        OPEN C_TRACERS(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_TRACERS BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_TRACERS;
          EXIT WHEN C_TRACERS%NOTFOUND;
        END LOOP;
        CLOSE C_TRACERS;

        DBG('After selecting Drafts');
        OPEN C_DRAFTS(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_DRAFTS BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_DRAFTS;
          EXIT WHEN C_DRAFTS%NOTFOUND;
        END LOOP;
        CLOSE C_DRAFTS;

        DBG('Selecting drafts details');
        OPEN C_DRAFTS_DETAILS(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_DRAFTS_DETAILS BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_DRAFTS_DETAILS;
          EXIT WHEN C_DRAFTS_DETAILS%NOTFOUND;
        END LOOP;
        CLOSE C_DRAFTS_DETAILS;

        DBG('Selecting parties Details');
        OPEN C_PARTIES(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_PARTIES BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_PARTIES;
          EXIT WHEN C_PARTIES%NOTFOUND;
        END LOOP;
        CLOSE C_PARTIES;

        OPEN C_OTHER_ADDRESS(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_OTHER_ADDRESS BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_OTHER_ADDRESSES;
          EXIT WHEN C_OTHER_ADDRESS%NOTFOUND;
        END LOOP;
        CLOSE C_OTHER_ADDRESS;

        DBG('Selecting Advices' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO);
        DBG('l_Event_Seq_No' || L_EVENT_SEQ_NO);
        DBG('p_wrk_lcdtronl.v_cstbs_contract::' ||
            P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTH_STATUS);

        BEGIN
          SELECT LATEST_EVENT_SEQ_NO
            INTO L_EVSEQ1
            FROM CSTBS_CONTRACT
           WHERE CONTRACT_REF_NO =
                 P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No Data Found');
        END;

        DBG('Seleting Terms and Conditions');

        OPEN C_TERMS_CONDITIONS(L_EVENT_SEQ_NO);

        LOOP
          FETCH C_TERMS_CONDITIONS BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_TERMS_CONDITIONS;
          EXIT WHEN C_TERMS_CONDITIONS%NOTFOUND;
        END LOOP;
        CLOSE C_TERMS_CONDITIONS;

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY OR
           P_WRK_LCDTRONL.V_CSTBS_CONTRACT.AUTH_STATUS = 'A' THEN
          DBG('inside query--->' || L_EVENT_SEQ_NO || ' ' ||
              L_NXT_EVENT_SEQ_NO);

          OPEN C_ADVICES_QUERY(L_EVENT_SEQ_NO_NEW,
                               L_NXT_EVENT_SEQ_NO,
                               L_EVSEQ1);
          LOOP
            FETCH C_ADVICES_QUERY BULK COLLECT
              INTO P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE;
            EXIT WHEN C_ADVICES_QUERY%NOTFOUND;
          END LOOP;
          CLOSE C_ADVICES_QUERY;
          DBG('p_wrk_lcdtronl.v_contract_event_advice.COUNT::' ||
              P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT);

        ELSIF P_ACTION_CODE = 'COPY'

         THEN
          OPEN C_ADVICES(L_EVENT_SEQ_NO);
          LOOP
            FETCH C_ADVICES BULK COLLECT
              INTO P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE;
            EXIT WHEN C_ADVICES%NOTFOUND;
          END LOOP;
          CLOSE C_ADVICES;
        ELSE

          DBG('iNSIDE');
          OPEN C_ADVICESUNAUTH;
          LOOP
            FETCH C_ADVICESUNAUTH BULK COLLECT
              INTO P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE;
            EXIT WHEN C_ADVICESUNAUTH%NOTFOUND;
          END LOOP;
          CLOSE C_ADVICESUNAUTH;

          BEGIN
            SELECT MIN(EVENT_SEQ_NO)
              INTO L_ESN
              FROM CSTB_CONTRACT_EVENT_LOG
             WHERE CONTRACT_REF_NO =
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
               AND AUTH_STATUS = 'U';
          EXCEPTION
            WHEN OTHERS THEN
              DBG('l_esn' || L_ESN || SQLERRM);
          END;
          DBG('l_esn' || L_ESN);

          IF P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT = 0 THEN
            OPEN C_ADVICESUNAUTHAMND(L_ESN);
            LOOP
              FETCH C_ADVICESUNAUTHAMND BULK COLLECT
                INTO P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE;
              EXIT WHEN C_ADVICESUNAUTHAMND%NOTFOUND;
            END LOOP;
            CLOSE C_ADVICESUNAUTHAMND;
          END IF;

          DBG('p_wrk_lcdtronl.v_contract_event_advice::' ||
              P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT);

        END IF;

        DBG('p_Wrk_Lcdtronl.v_Contract_Event_Advice' ||
            P_WRK_LCDTRONL.V_CONTRACT_EVENT_ADVICE.COUNT);
        DBG('Selecting FFTs');

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
          DBG('inside fft query l_version--->' || L_VERSION);
          OPEN C_FFTS_QUERY(L_VERSION);
          LOOP
            FETCH C_FFTS_QUERY BULK COLLECT
              INTO P_WRK_LCDTRONL.V_LCTBS_FFTS;
            EXIT WHEN C_FFTS_QUERY%NOTFOUND;
          END LOOP;
          DBG('Selecting FFTs23' || L_VERSION ||
              P_WRK_LCDTRONL.V_LCTBS_FFTS.COUNT);
          CLOSE C_FFTS_QUERY;
        ELSE

          OPEN C_FFTS(L_EVENT_SEQ_NO);
          LOOP
            FETCH C_FFTS BULK COLLECT
              INTO P_WRK_LCDTRONL.V_LCTBS_FFTS;
            EXIT WHEN C_FFTS%NOTFOUND;
          END LOOP;
          CLOSE C_FFTS;
        END IF;
        DBG('Calling the Transfer cursor' || L_EVENT_SEQ_NO);
        OPEN C_TRANS(L_EVENT_SEQ_NO);
        LOOP
          FETCH C_TRANS BULK COLLECT
            INTO P_WRK_LCDTRONL.V_LCTBS_TRANSFER_DETAILS;
          EXIT WHEN C_TRANS%NOTFOUND;
          DBG('p_Wrk_Lcdtronl.v_Lctbs_Transfer_Details.from_lcref' || P_WRK_LCDTRONL.V_LCTBS_TRANSFER_DETAILS(1)
              .FROM_LCREF);
        END LOOP;
        CLOSE C_TRANS;

        SELECT COUNT(*)
          INTO L_AUTH_COUNT
          FROM CSTB_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND AUTH_STATUS = 'A';

        DBG('l_Log_Rec.Auth_Status;' || L_LOG_REC.AUTH_STATUS);
        DBG('l_Log_Rec.Contract_Status' || L_LOG_REC.CONTRACT_STATUS);
        DBG('l_Log_Rec.Maker_Id;' || L_LOG_REC.MAKER_ID);
        DBG('l_Log_Rec.Checker_Id' || L_LOG_REC.CHECKER_ID);

        DBG('Fetching module code for functionID:' || P_FUNCTION_ID);
        BEGIN
          SELECT MODULE
            INTO L_MODULE
            FROM SMTB_MENU
           WHERE FUNCTION_ID = P_FUNCTION_ID;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In when others while getting module..');
            RETURN FALSE;
        END;

        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.CONTRACT_REF_NO := P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO;

        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.MAKER_ID         := L_LOG_REC.MAKER_ID;
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.MAKER_DT_STAMP   := L_LOG_REC.MAKER_DT_STAMP;
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.CHECKER_ID       := L_LOG_REC.CHECKER_ID;
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.CHECKER_DT_STAMP := L_LOG_REC.CHECKER_DT_STAMP;
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.CONTRACT_STATUS  := L_LOG_REC.CONTRACT_STATUS;
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.AUTH_STATUS      := L_LOG_REC.AUTH_STATUS;
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.MODULE           := L_MODULE;

        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.EVENT_SEQ_NO := L_LOG_REC.EVENT_SEQ_NO;
        P_WRK_LCDTRONL.V_CONTRACT_EVENT_LOG__LOG.EVENT_CODE   := L_LOG_REC.EVENT_CODE;

        SELECT COUNT(*)
          INTO L_AUTH_COUNT
          FROM CSTB_CONTRACT_EVENT_LOG
         WHERE CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_CSTBS_CONTRACT.CONTRACT_REF_NO
           AND AUTH_STATUS = 'A';
        DBG('l_Auth_Count' || L_AUTH_COUNT);
        IF L_AUTH_COUNT > 0 THEN
          P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD93 := 'Y';
        ELSE
          P_WRK_LCDTRONL.V_CSTBS_UI_COLUMNS.CHAR_FIELD93 := 'N';
        END IF;

        DBG('LIMIT RECORDS>>');

        DBG('Track_Limit>>' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT);
        IF NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.TRACK_LIMIT, 'N') = 'Y' THEN
          DBG('INSIDE LIMIT QUERY');

          OPEN C_LIMITS(L_EVENT_SEQ_NO);
          LOOP
            FETCH C_LIMITS BULK COLLECT
              INTO P_WRK_LCDTRONL.V_LCTBS_CONTRACT_LIMITS;
            EXIT WHEN C_LIMITS%NOTFOUND;
          END LOOP;
          CLOSE C_LIMITS;
        END IF;

      END IF;
    END IF;

    DBG('Calling Cspks_Req_Utils.Fn_Check_Branch_Rights..');
    IF NOT CSPKS_REQ_UTILS.FN_CHECK_BRANCH_RIGHTS(P_WRK_LCDTRONL.V_CSTBS_CONTRACT.BRANCH,
                                                  GLOBAL.USER_ID,
                                                  P_FUNCTION_ID,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
      DBG('Failed in Cspks_Req_Utils.Fn_Check_Branch_Rights: user does not have rights to query');
      RETURN FALSE;
    END IF;

    IF P_FUNCTION_ID = 'LCDTRONL' THEN
      DBG('FINAL In Fn_Post_Query1' ||
          P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT);
      DBG('In Fn_Post_Query1' || P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT);
      L_COUNT := P_WRK_LCDTRONL.V_LCTBS_PARTIES.COUNT;
      IF L_COUNT > 0 THEN
        FOR I IN 1 .. L_COUNT LOOP
          BEGIN
            SELECT B.ITEM_VAL_DESC
              INTO P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_PARTIES')(I)('PARTYDESC')
              FROM LCTB_ALLOWED_PARTIES A, STTBS_VALUE_DESC B
             WHERE UPPER(B.ITEM_VALUE) = UPPER(A.PARTY_TYPE)
               AND UPPER(A.PARTY_TYPE) = P_WRK_LCDTRONL.V_LCTBS_PARTIES(I)
                  .PARTY_TYPE
               AND UPPER(B.BLOCK_NAME) = 'LCTBS_PARTIES'
               AND UPPER(B.ITEM_NAME) = 'PARTY_TYPE'

               AND UPPER(B.LANGUAGE_CODE) = 'ENG'

               AND A.PRODUCT_TYPE =
                   P_WRK_LCDTRONL.V_CSTBS_CONTRACT.PRODUCT_TYPE
               AND A.OPERATION_CODE =
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE;
            DBG('desc-->POST_QUERY' ||
                P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_PARTIES') (I)
                ('PARTYDESC'));
            DBG('type' || P_WRK_LCDTRONL.V_LCTBS_PARTIES(I).PARTY_TYPE);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in assigning the party description');
          END;
        END LOOP;
      END IF;
    END IF;

    IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
      FOR K IN 1 .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT LOOP
        BEGIN
          SELECT ADDRESS_LINE1, ADDRESS_LINE2, ADDRESS_LINE3, ADDRESS_LINE4
            INTO P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_DRAFTS')(K)('ADDRSLIN1'),
                 P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_DRAFTS')(K)('ADDRSLIN2'),
                 P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_DRAFTS')(K)('ADDRSLIN3'),
                 P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_DRAFTS')(K)('ADDRSLIN4')
            FROM BCTMS_INSURANCE_COMP
           WHERE INSURANCE_COMP_CODE = P_WRK_LCDTRONL.V_LCTBS_DRAFTS(K)
                .INSURANCE_COMP_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in selecting the address Details');
        END;
      END LOOP;
    END IF;

    OPEN CR_UDFDET(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO,
                   P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
    LOOP
      DBG('Populating the UDF details during query');
      FETCH CR_UDFDET BULK COLLECT
        INTO P_WRK_LCDTRONL.TXN_UDF_DETAILS;
      EXIT WHEN CR_UDFDET%NOTFOUND;
    END LOOP;
    CLOSE CR_UDFDET;

    IF P_WRK_LCDTRONL.TXN_UDF_DETAILS.COUNT > 0 THEN
      FOR I IN P_WRK_LCDTRONL.TXN_UDF_DETAILS.FIRST .. P_WRK_LCDTRONL.TXN_UDF_DETAILS.COUNT LOOP

        IF P_WRK_LCDTRONL.TXN_UDF_DETAILS(I).FIELD_VAL IS NULL THEN
          P_WRK_LCDTRONL.TXN_UDF_DETAILS(I).FIELD_VAL_DESC := NULL;
        END IF;

        IF P_WRK_LCDTRONL.TXN_UDF_DETAILS(I).VAL_TYPE = 'V' AND P_WRK_LCDTRONL.TXN_UDF_DETAILS(I)
           .FIELD_VAL IS NOT NULL THEN
          BEGIN
            SELECT LOV_DESC
              INTO P_WRK_LCDTRONL.TXN_UDF_DETAILS(I).FIELD_VAL_DESC
              FROM UDTM_LOV
             WHERE FIELD_NAME = P_WRK_LCDTRONL.TXN_UDF_DETAILS(I)
                  .FIELD_NAME
               AND LOV = P_WRK_LCDTRONL.TXN_UDF_DETAILS(I).FIELD_VAL;
          EXCEPTION
            WHEN OTHERS THEN
              P_WRK_LCDTRONL.TXN_UDF_DETAILS(I).FIELD_VAL_DESC := NULL;
          END;
        END IF;
      END LOOP;
    END IF;

    DBG('p_Wrk_Lcdtronl.v_Lctbs_Drafts.Count::' ||
        P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT);
    IF P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT > 0 THEN
      FOR I IN P_WRK_LCDTRONL.V_LCTBS_DRAFTS.FIRST .. P_WRK_LCDTRONL.V_LCTBS_DRAFTS.COUNT LOOP
        DBG('p_wrk_lcdtronl.v_lctbs_contract_master.CONTRACT_CCY:;' ||
            P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY);
        P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_DRAFTS')(I)('DRFTCCY') := P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_CCY;
        DBG('DRFTCCY::' || P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_DRAFTS') (I)
            ('DRFTCCY'));
      END LOOP;
    END IF;

    DBG('ESN:: ' || P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO ||
        ' ~ Ver:: ' || P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO);
    DBG('At last EVENT AND VERSION NO :' || L_VERSION || L_EVENT_SEQ_NO);
    DBG('Operation Code: ' ||
        P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.OPERATION_CODE);
    IF P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO IS NOT NULL THEN
      BEGIN
        SELECT B.ITEM_VAL_DESC
          INTO P_WRK_LCDTRONL.DESC_FIELDS('LCTBS_CONTRACT_MASTER')(1)('OPRCDDESC')
          FROM LCTB_CONTRACT_MASTER A, STTBS_VALUE_DESC B
         WHERE UPPER(B.ITEM_VALUE) = UPPER(A.OPERATION_CODE)
           AND UPPER(B.BLOCK_NAME) = 'LCTBS_CONTRACT_MASTER'
           AND UPPER(B.ITEM_NAME) = 'OPERATION_CODE'
           AND UPPER(B.LANGUAGE_CODE) = 'ENG'
           AND UPPER(B.FUNCTION_ID) = 'LCDTRONL'
           AND A.CONTRACT_REF_NO =
               P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.CONTRACT_REF_NO
           AND A.EVENT_SEQ_NO = NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.EVENT_SEQ_NO,
                                    L_EVENT_SEQ_NO)
           AND A.VERSION_NO = NVL(P_WRK_LCDTRONL.V_LCTBS_CONTRACT_MASTER.VERSION_NO,
                                  L_VERSION);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in selecting the desc for operation code');
      END;
    END IF;

    DBG('Returning Success from fn_post_query');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of lcpks_lcdtronl_Kernel.fn_post_query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

END LCPKS_LCDTRONL_KERNEL;
/