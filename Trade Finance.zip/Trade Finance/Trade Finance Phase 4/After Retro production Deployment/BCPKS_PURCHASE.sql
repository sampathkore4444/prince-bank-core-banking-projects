CREATE OR REPLACE PACKAGE BODY BCPKS_PURCHASE IS

  TYPE TY_FX_LINKAGE IS TABLE OF TFTBS_FX_LINKAGE%ROWTYPE INDEX BY BINARY_INTEGER;

  TYPE TY_LINKAGES IS TABLE OF BCTBS_PURCHASE_FX_DTLS%ROWTYPE INDEX BY VARCHAR2(16);

  PROCEDURE DBG(P_MSG IN VARCHAR2) IS
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      DEBUG.PR_DEBUG('BC', 'bcpks_purchase->' || P_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_INS_PURCHASE_LIQ(P_BCREFNO         IN VARCHAR2,
                                P_CL_ACCOUNT      IN VARCHAR2,
                                P_ESN             IN NUMBER,
                                P_EVENT_CODE      IN VARCHAR2,
                                P_PUR_AMT_TAG_CCY IN NUMBER,
                                P_PUR_AMT_LCY     IN NUMBER,
                                P_AMT_TAG         IN VARCHAR2,
                                P_ACCOUNTING_ROLE IN VARCHAR2,
                                P_SETTLED         IN VARCHAR2,
                                P_EX_RATE         IN NUMBER);

  FUNCTION FN_LIQD_LOAN(P_BCREFNO    IN BCTBS_CONTRACT_MASTER.BCREFNO%TYPE,
                        P_ESN        IN BCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE,
                        P_EVENT      IN BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE,
                        P_ERR_CODES  IN OUT VARCHAR2,
                        P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_PAYMENT_OBJ            CLPKSS_PAYMENT_OBJECT.TY_REC_PAYMENT;
    L_LOAN_REF_NO            CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE;
    L_CONTRACT_REC           CLTBS_ACCOUNT_MASTER%ROWTYPE;
    L_REC_ACCOUNT            CLPKSS_OBJECT.TY_REC_ACCOUNT;
    L_BRANCH_CODE            VARCHAR2(3);
    L_LIMIT_DT               DATE;
    L_VALUE_DATE             DATE;
    L_LATEST_ESN             CLTB_ACCOUNT_EVENTS_DIARY.EVENT_SEQ_NO%TYPE;
    IDX_COMP_SUM             CLTBS_LIQ_COMP_SUMMARY.COMPONENT_NAME%TYPE;
    L_COMPONENT              CSTBS_AMOUNT_DUE.COMPONENT%TYPE;
    L_CCY                    VARCHAR2(3);
    L_TOT_LOAN_OS            CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE;
    L_BILL_CCY               BCTBS_CONTRACT_MASTER.BILL_CCY%TYPE;
    L_LCY_RATE               NUMBER(14, 7);
    L_RATE_FLAG              NUMBER;
    L_DR_PROD_AC             CSTM_PRODUCT_ACCROLE.ACCOUNT_HEAD %TYPE;
    L_OPERATION              BCTBS_CONTRACT_MASTER.OPERATION%TYPE;
    L_BILL_OR_PUR_AMT_LIQD   BCTBS_CONTRACT_MASTER.BILL_AMT_LIQD%TYPE := 0;
    L_UNLINKED_FX_RATE       BCTBS_CONTRACT_MASTER.UNLINKED_FX_RATE%TYPE;
    L_PURCHASE_AMOUNT        BCTBS_CONTRACT_MASTER.PURCHASE_AMT%TYPE := 0;
    L_BILL_VALUE_DATE        BCTBS_CONTRACT_MASTER.VALUE_DATE%TYPE;
    L_BC_PRODUCT_TYPE        BCTBS_CONTRACT_MASTER.PRODUCT_TYPE%TYPE;
    L_LOAN_ESN               CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE;
    L_AMT_DUE                CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_LOAN_CCY               VARCHAR2(3);
    L_ROWID                  ROWID;
    L_EFFC_LCY_COL_EX_RATE   BCTBS_CONTRACT_MASTER.EFFC_LCY_COL_EX_RATE%TYPE;
    L_EFFC_LCY_PUR_XRATE     BCTBS_CONTRACT_MASTER.EFFC_LCY_PUR_XRATE%TYPE;
    L_OUTSTANDING_AMT        NUMBER;
    L_STTL_REF_NO            CLTBS_LIQ_SETTLEMENTS.SETTLEMENT_REF_NO%TYPE;
    L_PSERIAL                VARCHAR2(4);
    L_COMPARE_AMT            CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_LIQD_AMT               CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_HOLD_AMT               CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    PROCEED_BOOL             BOOLEAN := TRUE;
    L_AMT_TO_LIQ_EQ          CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_CL_LINKED              NUMBER;
    L_BOOL_LINK_PRCD         BOOLEAN := FALSE;
    L_PROCESSED_CNT          NUMBER := 0;
    I                        NUMBER;
    L_AMT_PURCHASED_BILL_CCY CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_AMT_PURCHASED_LCY      CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_HOLD_AMT_BILL_CCY      CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_LOAN_LIQD_AMT          CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_LOAN_LIQ_AMT_BILL_CCY  CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_UNSETTLED_AMOUNT       CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_SETTLED_AMOUNT         CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_REMAINING_AMT          CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_SETTLD_LIQ_AMT         CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_LOCAL_AMT              CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_UNSETTLED_LOAN_AMOUNT  CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_UNSETLD_LNAMOUNT_BLCCY CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_COLL_LIQ_AMT           CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_COLL_LIQ_AMT_EQ        CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_LINKED_PART            CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_UNLINKED_PART          CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_TOT_FX_AMT             CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_LINKED_PART_EQ         CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    L_UNLINKED_PART_EQ       CSTBS_AMOUNT_DUE.AMOUNT_DUE%TYPE := 0;
    LINKED_BOOL              BOOLEAN := FALSE;
    LINK_UNLINK_BOOL         BOOLEAN := FALSE;
    L_COMMON_RATE            NUMBER(14, 7) := 0;
    L_COUNT                  NUMBER;
    L_XRATE_TYPE             BCTMS_PRODUCT_MASTER.XRATE_TYPE%TYPE;
    L_FX_COUNT               NUMBER;
    PURCHASE_EXCEPTION EXCEPTION;
    L_X_RATE                 NUMBER(24, 7);
    L_PURCHASE_AMT_TAG_CCY   NUMBER(22, 3) := 0;
    L_PURCHASE_AMT_LCY       NUMBER(22, 3) := 0;
    L_TOTAL_AMT              NUMBER(22, 3) := 0;
    L_X_RATE_LIQD            NUMBER(14, 7);
    L_CURRENCY               VARCHAR2(3);
    L_PURC_AMT_TAG_CCY       NUMBER(22, 3) := 0;
    L_RESIDUAL_AMT           NUMBER(22, 3) := 0;
    L_HOLD_LIQD_AMT          NUMBER(22, 3) := 0;
    L_COMPARE_LIQD_AMT       NUMBER(22, 3) := 0;
    L_NO_FX_BOOL             BOOLEAN := FALSE;
    L_RESIDUAL_LINK_PART     NUMBER(22, 3) := 0;
    L_RESIDUAL_UNLINK_PART   NUMBER(22, 3) := 0;
    L_LINKED_PART_BILL_CCY   NUMBER(22, 3) := 0;
    L_UNLINKED_PART_BILL_CCY NUMBER(22, 3) := 0;
    L_USED_UNLINKED_PART     NUMBER(22, 3) := 0;
    L_TOT_LIQD_AMT           NUMBER(22, 3) := 0;
    L_COL_BOOL               BOOLEAN := FALSE;
    L_IS_PROCEED             BOOLEAN := FALSE;
    L_MARK_BOOL              BOOLEAN := TRUE;
    L_DIST_CCY               VARCHAR2(3);
    L_LAST_HOLD_AMT          NUMBER(22, 3) := 0;
    L_LIQD_UTILIZATION_AMT   NUMBER(22, 3) := 0;
    L_ACTUAL_LIQD_AMT        NUMBER(22, 3) := 0;
    L_CHK_OUTSTANDING_AMT    NUMBER(22, 3) := 0;
    L_TOT_COMP_OUTSTNADING   NUMBER(22, 3) := 0;
    L_ROUND_OUT_AMT          NUMBER(22, 3) := 0;
    L_UTILIZED_LINK_PART     NUMBER(22, 3) := 0;
    L_UTILIZED_UNLINK_PART   NUMBER(22, 3) := 0;
    M                        NUMBER := 0;
    L_VALIDATION_AMT         NUMBER(22, 3) := 0;
    L_TOT_VALIDATION_AMT     NUMBER(22, 3) := 0;
    L_VAL_ROUND_AMT          NUMBER(22, 3) := 0;
    L_TOT_VAD_OS             NUMBER(22, 3) := 0;
    L_LIQ_SETL_COUNT         NUMBER := 0;
    L_EVENT_CODE             VARCHAR2(4);
    L_COLLECTION_AGENT       CNTBS_COLLECTIONS_MASTER.COLLECTION_AGENT%TYPE;
    L_TEMP_OVERRIDES         OVPKSS.TBL_ERROR;
    CURSOR CR_PUR_DTLS IS
      SELECT *
        FROM BCTBS_PACK_CREDIT_DTLS
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_CODE = P_EVENT
       ORDER BY SEQ_NO;
  BEGIN
    P_ERR_CODES  := '';
    P_ERR_PARAMS := '';
    M            := NVL(BCPKSS_UPLOAD_CREATE.P_TY_BC_OVD_TBL.COUNT, 0);
    L_EVENT_CODE := P_EVENT;
    SAVEPOINT START_LOAN_LIQD;
    DBG('inside the function bcpkss_purchase.fn_liqd_loan -->' ||
        P_BCREFNO || '-->' || P_ESN || 'p_Event-->' || P_EVENT);
    BEGIN
      SELECT A.BILL_CCY,
             A.BILL_AMT_LIQD,
             A.UNLINKED_FX_RATE,
             A.PURCHASE_AMT,
             A.OPERATION,
             A.VALUE_DATE,
             A.PRODUCT_TYPE,
             A.EFFC_LCY_COL_EX_RATE,
             A.EFFC_LCY_PUR_XRATE,
             B.XRATE_TYPE
        INTO L_BILL_CCY,
             L_BILL_OR_PUR_AMT_LIQD,
             L_UNLINKED_FX_RATE,
             L_PURCHASE_AMOUNT,
             L_OPERATION,
             L_BILL_VALUE_DATE,
             L_BC_PRODUCT_TYPE,
             L_EFFC_LCY_COL_EX_RATE,
             L_EFFC_LCY_PUR_XRATE,
             L_XRATE_TYPE
        FROM BCTBS_CONTRACT_MASTER A, BCTMS_PRODUCT_MASTER B
       WHERE A.BCREFNO = P_BCREFNO
         AND A.EVENT_SEQ_NO = P_ESN
         AND B.PROD_CODE = SUBSTR(P_BCREFNO, 4, 4);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('inside when others-->' || SQLERRM);
        OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
        RETURN FALSE;
    END;
    L_ACTUAL_LIQD_AMT := L_BILL_OR_PUR_AMT_LIQD;
    DBG('after selecting from Bctbs_Contract_Master');
    DBG('the purchse amount is-->' || L_PURCHASE_AMOUNT);
    DBG('the unliked fx rate  is-->' || L_UNLINKED_FX_RATE);
    DBG('the effective purchase exrate  is-->' || L_EFFC_LCY_PUR_XRATE);
    DBG('the effective collection exrate  is-->' || L_EFFC_LCY_COL_EX_RATE);
    DBG('the  operation is-->' || L_OPERATION);
    DBG('the  event is-->' || P_EVENT);
    DBG('l_Bill_Or_Pur_Amt_Liqd-->' || L_BILL_OR_PUR_AMT_LIQD);

    DELETE FROM BCTBS_PURCHASE_LIQ_DTLS
     WHERE BCREFNO = P_BCREFNO
       AND EVENT_SEQ_NO = 0;
    DBG('no of rows deleted is-->' || SQL%ROWCOUNT);
    IF P_EVENT IN ('LPUR', 'LDIS', 'LIQD') THEN
      DBG('here am taking the back up');
      FOR EACH_REC IN (SELECT *
                         FROM BCTBS_PURCHASE_LIQ_DTLS
                        WHERE BCREFNO = P_BCREFNO
                          AND SETTLED IN ('N', 'Y')
                          AND EVENT_SEQ_NO =
                              (SELECT MIN(EVENT_SEQ_NO)
                                 FROM BCTBS_PURCHASE_LIQ_DTLS
                                WHERE BCREFNO = P_BCREFNO)
                        ORDER BY ENTRY_SR_NO) LOOP
        DBG('inserting the amount tag-->' || EACH_REC.AMOUNT_TAG);
        DBG('inserting the each_rec.Purchase_amt_tag_ccy-->' ||
            EACH_REC.PURCHASE_AMT_TAG_CCY);
        DBG('inserting the each_rec.Purchase_amt_lcy-->' ||
            EACH_REC.PURCHASE_AMT_LCY);
        INSERT INTO BCTBS_PURCHASE_LIQ_DTLS
          (BCREFNO,
           CL_ACCT_NO,
           EVENT_SEQ_NO,
           EVENT_CODE,
           PURCHASE_AMT_TAG_CCY,
           PURCHASE_AMT_LCY,
           ACCOUNTING_ROLE,
           AMOUNT_TAG,
           SETTLED,
           EX_RATE,
           ENTRY_SR_NO)
        VALUES
          (EACH_REC.BCREFNO,
           EACH_REC.CL_ACCT_NO,
           0,
           EACH_REC.EVENT_CODE,
           EACH_REC.PURCHASE_AMT_TAG_CCY,
           EACH_REC.PURCHASE_AMT_LCY,
           EACH_REC.ACCOUNTING_ROLE,
           EACH_REC.AMOUNT_TAG,
           DECODE(EACH_REC.SETTLED, 'N', 'M', 'Y', 'X'),
           EACH_REC.EX_RATE,
           - (EACH_REC.ENTRY_SR_NO));

      END LOOP;
      DBG('no of rows inserted is-->' || SQL%ROWCOUNT);
    END IF;

    SELECT COUNT(*)
      INTO L_CL_LINKED
      FROM BCTBS_PACK_CREDIT_DTLS
     WHERE BCREFNO = P_BCREFNO
       AND EVENT_CODE = P_EVENT;
    IF L_CL_LINKED <> 0 THEN
      DBG('no of rows are -->' || L_COUNT);
      BEGIN
        SELECT DISTINCT (LINKED_CCY)
          INTO L_LOAN_CCY
          FROM BCTBS_PACK_CREDIT_DTLS
         WHERE BCREFNO = P_BCREFNO;
      EXCEPTION
        WHEN TOO_MANY_ROWS THEN
          OVPKSS.PR_APPENDTBL('BC-PUR-036', ' ');
          RETURN FALSE;
        WHEN OTHERS THEN
          OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
          RAISE PURCHASE_EXCEPTION;

      END;
    END IF;
    IF L_LOAN_CCY <> GLOBAL.LCY THEN
      IF L_UNLINKED_FX_RATE IS NOT NULL THEN
        DBG('unlinked fx rate should be null');
        OVPKSS.PR_APPENDTBL('BC-PUR-040', ' ');
        RETURN FALSE;
      END IF;
    END IF;

    SELECT COUNT(*)
      INTO L_FX_COUNT
      FROM TFTBS_FX_LINKAGE A
     WHERE A.TF_REF_NO = P_BCREFNO
       AND A.FX_REF_NO IN
           (SELECT B.CONTRACT_REF_NO
              FROM CSTBS_CONTRACT B
             WHERE B.CONTRACT_REF_NO = A.FX_REF_NO
               AND B.CONTRACT_STATUS NOT IN ('L', 'V', 'S'));
    IF L_CL_LINKED <> 0 THEN
      IF (L_FX_COUNT <> 0 AND L_LOAN_CCY = GLOBAL.LCY) THEN
        DBG('fx are linked so no need to calculate the rate here');
        NULL;

      ELSE
        DBG('fx are not linked so we have to calcualte here');
        IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                 L_BILL_CCY,
                                 L_LOAN_CCY,
                                 L_XRATE_TYPE,
                                 'M',
                                 L_LCY_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODES) THEN
          DBG('failed during fetching rate between bill ccy and loan ccy');
          OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
        END IF;
        DBG('fx are not linked so we have to calcualte here l_lcy_rate-->' ||
            L_LCY_RATE || 'p_event-->' || P_EVENT || 'l_operation-->' ||
            L_OPERATION);
        IF P_EVENT IN ('BPUR', 'BDIS') OR
           (P_EVENT IN ('INIT') AND L_OPERATION IN ('DIS', 'PUR', 'NEG')) THEN

          DBG('this is bpur l_lcy_rate-->' || L_LCY_RATE);
          L_EFFC_LCY_PUR_XRATE := L_LCY_RATE;
        ELSIF P_EVENT IN ('LPUR', 'LDIS', 'LIQD') THEN
          DBG('this is liquidation l_lcy_rate-->' || L_LCY_RATE);
          L_EFFC_LCY_COL_EX_RATE := L_LCY_RATE;
        ELSE
          DBG('purchase details given to the wrong event');
          OVPKSS.PR_APPENDTBL('BC-PUR-018', ' ');
        END IF;
      END IF;
    ELSE
      DBG('there are no laons linked withthe event-->' || P_EVENT);
      IF P_EVENT IN ('BPUR', 'BDIS') OR
         (P_EVENT IN ('INIT') AND L_OPERATION IN ('DIS', 'PUR', 'NEG')) THEN
        L_EFFC_LCY_PUR_XRATE := 1;
      ELSIF P_EVENT IN ('LPUR', 'LDIS', 'LIQD') THEN
        L_EFFC_LCY_COL_EX_RATE := 1;
      ELSE
        DBG('purchase details given to the wrong event');
        OVPKSS.PR_APPENDTBL('BC-PUR-018', ' ');
      END IF;
    END IF;
    DBG('after the select for loan currency common rate is-->' ||
        L_COMMON_RATE);
    DBG('again printing l_effc_lcy_col_ex_rate-->' ||
        L_EFFC_LCY_COL_EX_RATE);
    DBG('again printing l_effc_lcy_pur_xrate-->' || L_EFFC_LCY_PUR_XRATE);
    IF (P_EVENT IN ('BPUR', 'BDIS')) OR
       (P_EVENT IN ('INIT') AND L_OPERATION IN ('DIS', 'PUR', 'NEG')) THEN
      DBG('after the select for loan currency1');
      L_COMMON_RATE := L_EFFC_LCY_PUR_XRATE;
    ELSIF (P_EVENT IN ('LPUR''LDIS', 'LIQD')) THEN
      DBG('after the select for loan currency2');
      L_COMMON_RATE := L_EFFC_LCY_COL_EX_RATE;
    END IF;
    DBG('linked currency coming here is-->' || L_LOAN_CCY);
    DBG('gloabl currency coming here is-->' || GLOBAL.LCY);

    DBG('i am here for event-->' || L_EVENT_CODE ||
        'l_effc_lcy_pur_xrate-->' || L_EFFC_LCY_PUR_XRATE);
    DBG('here again l_effc_lcy_col_ex_rate-->' || L_EFFC_LCY_COL_EX_RATE);
    IF L_COMMON_RATE IS NULL OR L_COMMON_RATE = 0 THEN
      IF L_EVENT_CODE IN ('INIT', 'BPUR', 'BDIS') THEN
        DBG('event code coming for init l_effc_lcy_pur_xrate-->' ||
            L_EFFC_LCY_PUR_XRATE);
        L_COMMON_RATE := L_EFFC_LCY_PUR_XRATE;

      ELSIF SUBSTR(L_EVENT_CODE, 1, 1) = 'L' THEN
        DBG('event code coming for liqd l_effc_lcy_col_ex_rate-->' ||
            L_EFFC_LCY_COL_EX_RATE);
        L_COMMON_RATE := L_EFFC_LCY_COL_EX_RATE;
      END IF;

    END IF;

    DBG('finally the common rate coming is-->' || L_COMMON_RATE);
    IF SUBSTR(P_EVENT, 1, 1) = 'L' THEN
      DBG('l_Bill_Or_Pur_Amt_Liqd is-->' || L_BILL_OR_PUR_AMT_LIQD);
      L_PURCHASE_AMOUNT := L_BILL_OR_PUR_AMT_LIQD;
    END IF;

    IF L_CL_LINKED <> 0 THEN

      DBG('some cls are linked');
      IF L_LOAN_CCY <> GLOBAL.LCY THEN
        DBG('insde if loop before amt');
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                      L_BILL_CCY,
                                      L_LOAN_CCY,
                                      L_PURCHASE_AMOUNT,
                                      'Y',
                                      L_COMPARE_AMT,
                                      L_COMMON_RATE,
                                      P_ERR_CODES) THEN
          OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
          RAISE PURCHASE_EXCEPTION;
        END IF;
      ELSE
        DBG('insde select  before amt');
        SELECT SUM(NVL(A.TF_AMOUNT, 0))
          INTO L_TOT_FX_AMT
          FROM TFTBS_FX_LINKAGE A
         WHERE TF_REF_NO = P_BCREFNO
           AND A.FX_REF_NO IN
               (SELECT B.CONTRACT_REF_NO
                  FROM CSTBS_CONTRACT B
                 WHERE B.CONTRACT_REF_NO = A.FX_REF_NO
                   AND B.CONTRACT_STATUS NOT IN ('L', 'V', 'S'));
        DBG('total fx linked is-->' || L_TOT_FX_AMT);
        IF L_TOT_FX_AMT <> 0 THEN
          DBG('purchase amount is-->' || L_PURCHASE_AMOUNT);
          DBG('total fx amount liked is-->' || L_TOT_FX_AMT);
          IF L_TOT_FX_AMT >= L_PURCHASE_AMOUNT THEN
            L_LINKED_PART := L_PURCHASE_AMOUNT;
            LINKED_BOOL   := TRUE;
          ELSE
            L_LINKED_PART    := L_TOT_FX_AMT;
            L_UNLINKED_PART  := L_PURCHASE_AMOUNT - L_LINKED_PART;
            LINK_UNLINK_BOOL := TRUE;
          END IF;
          DBG('linked part is-->' || L_LINKED_PART);
          DBG('unlinked part is-->' || L_UNLINKED_PART);
          IF LINKED_BOOL THEN
            DBG('here the purchase amount is falling under the linked part-->' ||
                L_LINKED_PART);
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          L_BILL_CCY,
                                          GLOBAL.LCY,

                                          L_LINKED_PART,
                                          'Y',
                                          L_COMPARE_AMT,
                                          L_COMMON_RATE,
                                          P_ERR_CODES) THEN
              OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
              RAISE PURCHASE_EXCEPTION;
            END IF;
            L_LINKED_PART_EQ := L_COMPARE_AMT;
            DBG('this time the linked part coming here is-->' ||
                L_LINKED_PART_EQ);
            DBG('fx are linked the compare amount here is-->' ||
                L_COMPARE_AMT);
          ELSIF LINK_UNLINK_BOOL THEN
            DBG('here the rate is coming as-->' || L_COMMON_RATE);
            DBG('here the linked part coming as-->' || L_LINKED_PART);
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          L_BILL_CCY,
                                          GLOBAL.LCY,
                                          L_LINKED_PART,
                                          'Y',
                                          L_LINKED_PART_EQ,
                                          L_COMMON_RATE,
                                          P_ERR_CODES) THEN
              OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
              RAISE PURCHASE_EXCEPTION;
            END IF;

            DBG('here the linked part equivalent is -->' ||
                L_LINKED_PART_EQ);
            DBG('now coming to the unlinked part-->' || L_UNLINKED_PART);
            DBG('now coming to the unlinked fx rate is-->' ||
                L_UNLINKED_FX_RATE);
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          L_BILL_CCY,
                                          GLOBAL.LCY,
                                          L_UNLINKED_PART,
                                          'Y',
                                          L_UNLINKED_PART_EQ,
                                          L_UNLINKED_FX_RATE,
                                          P_ERR_CODES) THEN
              OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
              RAISE PURCHASE_EXCEPTION;
            END IF;
            DBG('here the unlinked part equivalent is -->' ||
                L_LINKED_PART_EQ);
            L_COMPARE_AMT := L_LINKED_PART_EQ + L_UNLINKED_PART_EQ;
            DBG('now the total compare amount is-->' || L_COMPARE_AMT);
          END IF;

          FOR EACH_LOAN IN (SELECT CL_ACCOUNT
                              FROM BCTBS_PACK_CREDIT_DTLS
                             WHERE BCREFNO = P_BCREFNO) LOOP
            DBG('loan coming here is-->' || EACH_LOAN.CL_ACCOUNT);

            IF NOT CLPKSS_IFACE.FN_GET_OUTSTANDING_AMOUNT(EACH_LOAN.CL_ACCOUNT,
                                                          SUBSTR(EACH_LOAN.CL_ACCOUNT,
                                                                 1,
                                                                 3),
                                                          GLOBAL.APPLICATION_DATE,
                                                          'B',
                                                          L_OUTSTANDING_AMT,
                                                          L_LOAN_CCY,
                                                          P_ERR_CODES,
                                                          P_ERR_PARAMS) THEN
              DBG('failed in getting the total outstanding amount from the clpkss_iface');
              OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);
              RAISE PURCHASE_EXCEPTION;
            END IF;

            DBG('the outstanding for the loan -->' || EACH_LOAN.CL_ACCOUNT || ' ' || 'is' || ' ' ||
                L_OUTSTANDING_AMT);
            L_CHK_OUTSTANDING_AMT := L_CHK_OUTSTANDING_AMT +
                                     L_OUTSTANDING_AMT;
          END LOOP;
          IF L_CHK_OUTSTANDING_AMT <> 0 THEN
            IF L_CHK_OUTSTANDING_AMT < L_LINKED_PART_EQ THEN

              DBG('as the total loan linked is less than the linked part');
              M := M + 1;
              BCPKSS_UPLOAD_CREATE.P_TY_BC_OVD_TBL(M).ERR_CODE := 'BC-PUR-042;';
              BCPKSS_UPLOAD_CREATE.P_TY_BC_OVD_TBL(M).ERR_PARAM := ' ';
              BCPKSS_UPLOAD_CREATE.P_TY_BC_OVD_TBL(M).MODULE := 'BC';

            END IF;

          END IF;
        ELSE
          DBG(' no fx are linked');
          L_NO_FX_BOOL := TRUE;
          DBG('l_common_rate is 1111-->' || L_COMMON_RATE);
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                        L_BILL_CCY,
                                        GLOBAL.LCY,
                                        L_PURCHASE_AMOUNT,
                                        'Y',
                                        L_COMPARE_AMT,
                                        L_COMMON_RATE,
                                        P_ERR_CODES) THEN
            DBG(' Returning false from cypks');
            OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
            RAISE PURCHASE_EXCEPTION;
          END IF;
          DBG('amount to compare is-->' || L_COMPARE_AMT);
        END IF;
      END IF;

    END IF;
    DBG('finally the total compate amount is-->' || L_COMPARE_AMT);
    DBG('after selecting the details');
    DBG('total no of cls linked -->' || L_CL_LINKED);
    DBG('inside the function Fn_Liqd_Loan l_operation-->' || L_OPERATION ||
        P_EVENT);
    IF P_EVENT IN ('LIQD', 'LPUR', 'LDIS') OR P_EVENT IN ('BPUR', 'BDIS') OR
       (P_EVENT = 'INIT' AND L_OPERATION IN ('DIS', 'PUR', 'NEG')) THEN
      DBG('correct type of operation');
    ELSE
      DBG('wrong type of operation');
      OVPKSS.PR_APPENDTBL('BC-PUR-005', P_EVENT);
      RAISE PURCHASE_EXCEPTION;
    END IF;
    IF L_PURCHASE_AMOUNT <= 0 THEN
      OVPKSS.PR_APPENDTBL('BC-PUR-013', P_EVENT);
      RAISE PURCHASE_EXCEPTION;
    END IF;

    FOR EACH_LOAN IN (SELECT CL_ACCOUNT
                        FROM BCTBS_PACK_CREDIT_DTLS
                       WHERE BCREFNO = P_BCREFNO) LOOP
      DBG('loan coming here is-->' || EACH_LOAN.CL_ACCOUNT);

      IF NOT CLPKSS_IFACE.FN_GET_OUTSTANDING_AMOUNT(EACH_LOAN.CL_ACCOUNT,
                                                    SUBSTR(EACH_LOAN.CL_ACCOUNT,
                                                           1,
                                                           3),
                                                    GLOBAL.APPLICATION_DATE,
                                                    'B',
                                                    L_VALIDATION_AMT,
                                                    L_LOAN_CCY,
                                                    P_ERR_CODES,
                                                    P_ERR_PARAMS) THEN
        DBG('failed in getting the total outstanding amount from the clpkss_iface');
        OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);
        RAISE PURCHASE_EXCEPTION;
      END IF;
      DBG('l_validation_amt is-->' || L_VALIDATION_AMT);
      IF NOT
          CYPKSS.FN_AMT_ROUND(L_LOAN_CCY, L_VALIDATION_AMT, L_VAL_ROUND_AMT) THEN
        DBG('failed while rounding the amount');
        L_TOT_VAD_OS := L_VALIDATION_AMT;
      ELSE
        DBG('l_val_round_amt is-->' || L_VAL_ROUND_AMT);
        L_TOT_VAD_OS := L_VAL_ROUND_AMT;
      END IF;
      DBG('afetr rounding l_validation_amt is-->' || L_TOT_VAD_OS);
      DBG('the outstanding for the loan -->' || EACH_LOAN.CL_ACCOUNT || ' ' || 'is' || ' ' ||
          L_TOT_VAD_OS);
      L_TOT_VALIDATION_AMT := L_TOT_VALIDATION_AMT + L_TOT_VAD_OS;
    END LOOP;
    DBG('l_tot_validation_amt is-->' || L_TOT_VALIDATION_AMT);
    DBG('again l_compare_amt is-->' || L_COMPARE_AMT || 'p_event-->' ||
        P_EVENT);
    IF L_TOT_VALIDATION_AMT <> 0 THEN
      DBG('again printing l_tot_validation_amt-->' || L_TOT_VALIDATION_AMT);
      DBG('again printing l_compare_amt-->' || L_COMPARE_AMT);
      IF L_TOT_VALIDATION_AMT > L_COMPARE_AMT THEN

        IF P_EVENT IN ('BPUR', 'BDIS') OR
           (P_EVENT IN ('INIT') AND L_OPERATION IN ('DIS', 'PUR', 'NEG')) THEN

          DBG('as the total loan linked is greater  than the compare amount for init event');

          P_ERR_CODES  := 'BC-PUR-043';
          P_ERR_PARAMS := '';
          OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);

        ELSIF SUBSTR(P_EVENT, 1, 1) = 'L' THEN
          DBG('as the total loan linked is greater  than the compare amount for LIQD event');

          P_ERR_CODES  := 'BC-PUR-044';
          P_ERR_PARAMS := '';
          OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);

        END IF;
      END IF;

    END IF;

    I := 1;

    DBG('what is the count-->' || L_COUNT);
    FOR CREC IN CR_PUR_DTLS LOOP
      DBG('inside the loop11-->' || CREC.CL_ACCOUNT);
      L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS.DELETE;
      G_PAYMENT_THROUGH_BC := TRUE;
      L_PROCESSED_CNT      := I;
      L_LOAN_REF_NO        := CREC.CL_ACCOUNT;
      L_IS_PROCEED         := TRUE;
      L_MARK_BOOL          := TRUE;
      DBG('crec.cl_account-->' || CREC.CL_ACCOUNT);
      SELECT COUNT(*)
        INTO L_COUNT
        FROM BCTBS_PACK_CREDIT_DTLS
       WHERE BCREFNO = P_BCREFNO
         AND CL_ACCOUNT = CREC.CL_ACCOUNT;

      DBG('l_count-->' || L_COUNT);
      IF L_COUNT <> 1 THEN
        OVPKSS.PR_APPENDTBL('BC-PUR-011', ' ');
        RETURN FALSE;
      END IF;

      BEGIN
        SELECT DISTINCT LINKED_CCY
          INTO L_DIST_CCY
          FROM BCTBS_PACK_CREDIT_DTLS
         WHERE BCREFNO = P_BCREFNO;
      EXCEPTION
        WHEN TOO_MANY_ROWS THEN
          DBG('insode two many rows');
          OVPKSS.PR_APPENDTBL('BC-PUR-036', ' ');
          RETURN FALSE;
      END;
      G_PURCHASE_LOAN_CCY := L_DIST_CCY;
      DBG('l_dist_ccy-->' || L_DIST_CCY);
      BEGIN
        SELECT *
          INTO L_CONTRACT_REC
          FROM CLTBS_ACCOUNT_MASTER
         WHERE ACCOUNT_NUMBER = L_LOAN_REF_NO
           AND BRANCH_CODE = SUBSTR(L_LOAN_REF_NO, 1, 3)
           AND AUTH_STAT = 'A';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('inside when others while selecting cltbs_account_master-->' ||
              SQLERRM);
          OVPKSS.PR_APPENDTBL('BC-PUR-007', ' ');
          RAISE PURCHASE_EXCEPTION;
      END;
      BEGIN
        SELECT NVL(LATEST_ESN, 0) + 1
          INTO L_LATEST_ESN
          FROM CLTB_ACCOUNT_MASTER
         WHERE ACCOUNT_NUMBER = L_LOAN_REF_NO;
        DBG('l_Loan_Esn-->' || L_LATEST_ESN);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('inside when others while selecting cltbs_account_master1-->' ||
              SQLERRM);
          OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
          RAISE PURCHASE_EXCEPTION;
      END;

      DBG('l_Loan_Ref_No-->' || L_LOAN_REF_NO);
      DBG('l_Branch_Code-->' || L_BRANCH_CODE);
      DBG('l_Value_Date-->' || L_VALUE_DATE);
      DBG('l_Limit_Dt-->' || L_LIMIT_DT);
      L_BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
      L_LIMIT_DT    := GLOBAL.APPLICATION_DATE;
      L_VALUE_DATE  := GLOBAL.APPLICATION_DATE;

      L_PAYMENT_OBJ.REC_LIQ.ACCOUNT_NUMBER := L_LOAN_REF_NO;
      L_PAYMENT_OBJ.REC_LIQ.BRANCH_CODE    := SUBSTR(L_LOAN_REF_NO, 1, 3);
      L_PAYMENT_OBJ.REC_LIQ.VALUE_DATE     := L_VALUE_DATE;
      L_PAYMENT_OBJ.REC_LIQ.EXECUTION_DATE := L_VALUE_DATE;
      L_PAYMENT_OBJ.REC_LIQ.LIMIT_DATE     := L_LIMIT_DT;
      L_PAYMENT_OBJ.REC_LIQ.EVENT_SEQ_NO   := L_LATEST_ESN;

      DBG('before selecting collection agent');
      BEGIN
        SELECT A.COLLECTION_AGENT
          INTO L_COLLECTION_AGENT
          FROM CNTB_COLLECTIONS_MASTER A, CSTB_CONTRACT B
         WHERE A.ASSET_REFERENCE_NO = 'TBREPREGBP00072'
           AND B.AUTH_STATUS = 'A'
           AND B.CONTRACT_REF_NO = A.COLLECTION_REF_NO
           AND A.VERSION_NO = B.LATEST_VERSION_NO
           AND B.CONTRACT_STATUS <> 'C';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('inisde when others selecting collection agent-->' ||
              SQLERRM);
          L_COLLECTION_AGENT := 'XXXXX';
      END;
      L_PAYMENT_OBJ.REC_LIQ.COLLECTION_AGENT := NVL(L_COLLECTION_AGENT,
                                                    'XXXXX');

      IF NOT
          CLPKSS_IFACE.FN_GET_OUTSTANDING_AMOUNT(L_LOAN_REF_NO,
                                                 SUBSTR(L_LOAN_REF_NO, 1, 3),
                                                 GLOBAL.APPLICATION_DATE,
                                                 'B',
                                                 L_OUTSTANDING_AMT,
                                                 L_LOAN_CCY,
                                                 P_ERR_CODES,
                                                 P_ERR_PARAMS) THEN
        DBG('failed in getting the total outstanding amount from the clpkss_iface');
        OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);
        RAISE PURCHASE_EXCEPTION;
      END IF;

      DBG('l_outstanding_amt-->' || L_OUTSTANDING_AMT);

      IF NOT
          CYPKSS.FN_AMT_ROUND(L_LOAN_CCY, L_OUTSTANDING_AMT, L_ROUND_OUT_AMT) THEN
        DBG('failed while rounding the amount');
        L_TOT_LOAN_OS := L_OUTSTANDING_AMT;
      ELSE
        L_TOT_LOAN_OS := L_ROUND_OUT_AMT;
      END IF;

      DBG('the total outstanding for the loan is-->' || L_TOT_LOAN_OS);
      IF L_TOT_LOAN_OS = 0 THEN
        OVPKSS.PR_APPENDTBL('BC-PUR-008', '');
        RAISE PURCHASE_EXCEPTION;
      END IF;

      DBG('Total error count iss : ' || OVPKSS.GL_TBLERROR.COUNT);
      IF OVPKSS.GL_TBLERROR.COUNT > 0 THEN
        FOR I IN 1 .. OVPKSS.GL_TBLERROR.COUNT LOOP
          DBG('Error code for i ' || I || ' iss : ' || OVPKSS.GL_TBLERROR(I)
              .ERR_CODE);
        END LOOP;
        DBG('After ovpks');
      END IF;
      L_TEMP_OVERRIDES := OVPKSS.GL_TBLERROR;

      IF NOT CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_LOAN_REF_NO,
                                                 SUBSTR(L_LOAN_REF_NO, 1, 3),
                                                 L_REC_ACCOUNT,
                                                 P_ERR_CODES,
                                                 P_ERR_PARAMS) THEN
        OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);
        RAISE PURCHASE_EXCEPTION;
      END IF;
      DBG('after creating the object');
      CLPKSS_CONTEXT.G_ACCOUNT_OBJ := L_REC_ACCOUNT;
      IF NOT CLPKS_PAYMENT.FN_NEW(L_PAYMENT_OBJ, P_ERR_CODES, P_ERR_PARAMS) THEN
        OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);
        RAISE PURCHASE_EXCEPTION;
      END IF;
      DBG('after the call to Clpks_Payment.Fn_new');
      IDX_COMP_SUM := L_PAYMENT_OBJ.TB_LIQ_COMP_SUMMARY.FIRST;

      WHILE IDX_COMP_SUM IS NOT NULL LOOP
        L_TOT_COMP_OUTSTNADING := 0;
        DBG('component is not null');
        L_COMPONENT := L_PAYMENT_OBJ.TB_LIQ_COMP_SUMMARY(IDX_COMP_SUM)
                       .REC_COMP_SUMMARY.COMPONENT_NAME;
        DBG('l_Component-->' || L_COMPONENT);
        L_AMT_DUE := NVL(L_PAYMENT_OBJ.TB_LIQ_COMP_SUMMARY(IDX_COMP_SUM)
                         .REC_COMP_SUMMARY.AMOUNT_NOT_DUE,
                         0) + NVL(L_PAYMENT_OBJ.TB_LIQ_COMP_SUMMARY(IDX_COMP_SUM)
                                  .REC_COMP_SUMMARY.AMOUNT_DUE,
                                  0) + NVL(L_PAYMENT_OBJ.TB_LIQ_COMP_SUMMARY(IDX_COMP_SUM)
                                           .REC_COMP_SUMMARY.AMOUNT_OVERDUE,
                                           0);
        DBG('l_Amt_Due-->' || L_AMT_DUE);
        L_CCY := L_PAYMENT_OBJ.TB_LIQ_COMP_SUMMARY(IDX_COMP_SUM)
                 .REC_COMP_SUMMARY.COMPONENT_CCY;
        DBG('l_Ccy-->' || L_CCY);

        L_TOT_COMP_OUTSTNADING := NVL(L_AMT_DUE, 0);
        DBG('total outstnading for component is-->' ||
            L_TOT_COMP_OUTSTNADING);
        IDX_COMP_SUM := L_PAYMENT_OBJ.TB_LIQ_COMP_SUMMARY.NEXT(IDX_COMP_SUM);
      END LOOP;

      DBG('now the Tot_Loan_Os is-->' || L_TOT_LOAN_OS);
      DBG('now the l_bill_ccy is-->' || L_BILL_CCY);
      DBG('now the crec.linked_ccy is-->' || CREC.LINKED_CCY);
      DBG('now the crec.global.lcy is-->' || GLOBAL.LCY);
      IF L_NO_FX_BOOL THEN
        DBG('fx are not linked');
      ELSE
        DBG('fx   linked');
      END IF;
      IF ROUND(L_TOT_LOAN_OS, 1) <> 0 THEN
        IF (CREC.LINKED_CCY <> GLOBAL.LCY) OR
           (CREC.LINKED_CCY = GLOBAL.LCY AND L_NO_FX_BOOL = TRUE) THEN
          DBG('now i am here');
          IF P_EVENT IN ('BPUR', 'BDIS') OR
             (P_EVENT IN ('INIT') AND L_OPERATION IN ('PUR', 'DIS', 'NEG')) THEN
            L_HOLD_AMT := L_HOLD_AMT + L_TOT_LOAN_OS;
            DBG('l_processed_cnt-->' || L_PROCESSED_CNT);
            DBG('l_cl_linked-->' || L_CL_LINKED);
            IF L_PROCESSED_CNT = L_CL_LINKED THEN
              L_BOOL_LINK_PRCD := TRUE;
              PROCEED_BOOL     := FALSE;
            END IF;
            DBG('l_hold_amt-->' || L_HOLD_AMT);
            DBG('l_compare_amt-->' || L_COMPARE_AMT);
            IF L_HOLD_AMT < L_COMPARE_AMT THEN
              L_LIQD_AMT := L_TOT_LOAN_OS;
              IF L_BOOL_LINK_PRCD THEN
                DBG('this is the last linkage with rate-->' ||
                    L_EFFC_LCY_PUR_XRATE);
                L_MARK_BOOL := FALSE;
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                              CREC.LINKED_CCY,
                                              L_BILL_CCY,
                                              L_LIQD_AMT,
                                              'Y',
                                              L_HOLD_AMT_BILL_CCY,
                                              L_EFFC_LCY_PUR_XRATE,
                                              P_ERR_CODES) THEN
                  OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                  RAISE PURCHASE_EXCEPTION;
                END IF;
                DBG('here l_hold_amt_bill_ccy-->' || L_HOLD_AMT_BILL_CCY);
                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_LIQD_AMT,
                                    L_HOLD_AMT_BILL_CCY,
                                    'BILLS PURCHASED',
                                    'LOAN_LIQD_AMT',
                                    'N',
                                    L_EFFC_LCY_PUR_XRATE);
                DBG('now here l_hold_amt_bill_ccy-->' ||
                    L_HOLD_AMT_BILL_CCY);

                DBG('here l_Purchase_Amount is-->' || L_PURCHASE_AMOUNT);
                L_AMT_PURCHASED_BILL_CCY := L_PURCHASE_AMOUNT -
                                            L_HOLD_AMT_BILL_CCY;
                DBG('here l_amt_purchased_bill_ccy is-->' ||
                    L_AMT_PURCHASED_BILL_CCY);
                L_AMT_PURCHASED_LCY := L_COMPARE_AMT - L_HOLD_AMT;
                DBG('here l_amt_purchased_lcy is-->' ||
                    L_AMT_PURCHASED_LCY);
                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_AMT_PURCHASED_BILL_CCY,
                                    L_AMT_PURCHASED_BILL_CCY,
                                    'BILLS PURCHASED',
                                    'AMT_PURCHASED',
                                    'N',
                                    L_EFFC_LCY_PUR_XRATE);
                PROCEED_BOOL := FALSE;

              END IF;
              DBG('this is the general process');
              IF L_MARK_BOOL THEN
                DBG('here m for general process');
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                              CREC.LINKED_CCY,
                                              L_BILL_CCY,
                                              L_LIQD_AMT,
                                              'Y',
                                              L_HOLD_AMT_BILL_CCY,
                                              L_EFFC_LCY_PUR_XRATE,
                                              P_ERR_CODES) THEN
                  OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                  RAISE PURCHASE_EXCEPTION;
                END IF;
                DBG('going to insert for LOAN_LIQD_AMT for -->' ||
                    L_LIQD_AMT);
                DBG('going to insert for l_local_amt for -->' ||
                    L_LOCAL_AMT);
                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_LIQD_AMT,
                                    L_HOLD_AMT_BILL_CCY,
                                    'BILLS PURCHASED',
                                    'LOAN_LIQD_AMT',
                                    'N',
                                    L_EFFC_LCY_PUR_XRATE);
              END IF;

            ELSIF L_HOLD_AMT = L_COMPARE_AMT THEN
              DBG('here it seems to be hold amount is = loan linked amt');
              L_LIQD_AMT      := L_TOT_LOAN_OS;
              L_LOAN_LIQD_AMT := L_HOLD_AMT;
              DBG('the loan_liqd_amt going to be-->' || L_TOT_LOAN_OS);
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                            CREC.LINKED_CCY,
                                            L_BILL_CCY,
                                            L_LIQD_AMT,
                                            'Y',
                                            L_LOCAL_AMT,
                                            L_EFFC_LCY_PUR_XRATE,
                                            P_ERR_CODES) THEN
                OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                RAISE PURCHASE_EXCEPTION;
              END IF;
              DBG('hold amount in this is-->' || L_HOLD_AMT);
              DBG('local amount in this is-->' || L_LOCAL_AMT);
              PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                  CREC.CL_ACCOUNT,
                                  P_ESN,
                                  CREC.EVENT_CODE,
                                  L_HOLD_AMT,
                                  L_LOCAL_AMT,
                                  'BILLS PURCHASED',
                                  'LOAN_LIQD_AMT',
                                  'N',
                                  L_EFFC_LCY_PUR_XRATE);
              PROCEED_BOOL := FALSE;
            ELSIF L_HOLD_AMT > L_COMPARE_AMT THEN
              DBG('here it seems to be hold amount is greater than compare amount');
              L_LIQD_AMT := L_TOT_LOAN_OS - (L_HOLD_AMT - L_COMPARE_AMT);
              DBG('liquidation amount is-->' || L_LIQD_AMT);
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                            CREC.LINKED_CCY,
                                            L_BILL_CCY,
                                            L_LIQD_AMT,
                                            'Y',
                                            L_LOCAL_AMT,
                                            L_EFFC_LCY_PUR_XRATE,
                                            P_ERR_CODES) THEN
                OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                RAISE PURCHASE_EXCEPTION;
              END IF;

              DBG('amount bill currency is-->' || L_LOCAL_AMT);
              PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                  CREC.CL_ACCOUNT,
                                  P_ESN,
                                  CREC.EVENT_CODE,
                                  L_LIQD_AMT,
                                  L_LOCAL_AMT,
                                  'BILLS PURCHASED',
                                  'LOAN_LIQD_AMT',
                                  'N',
                                  L_EFFC_LCY_PUR_XRATE);
              PROCEED_BOOL := FALSE;
            END IF;
          ELSIF SUBSTR(P_EVENT, 1, 1) = 'L' THEN
            L_HOLD_AMT := L_HOLD_AMT + L_TOT_LOAN_OS;
            DBG('for liquidation l_processed_cnt is-->' || L_PROCESSED_CNT);
            DBG('for liquidation l_cl_linked is-->' || L_CL_LINKED);
            IF L_PROCESSED_CNT = L_CL_LINKED THEN
              DBG('this is the end');
              L_BOOL_LINK_PRCD := TRUE;
              PROCEED_BOOL     := FALSE;
            END IF;
            IF L_HOLD_AMT < L_COMPARE_AMT THEN
              DBG('for liquidation hold amount is less than the compare amount');
              L_LIQD_AMT := L_TOT_LOAN_OS;

              IF L_BOOL_LINK_PRCD THEN
                L_MARK_BOOL := FALSE;
                DBG('i am coming here for last cl linked');
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                              CREC.LINKED_CCY,
                                              L_BILL_CCY,
                                              L_LIQD_AMT,
                                              'Y',
                                              L_HOLD_AMT_BILL_CCY,
                                              L_EFFC_LCY_COL_EX_RATE,
                                              P_ERR_CODES) THEN
                  OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                  RAISE PURCHASE_EXCEPTION;
                END IF;

                DBG('for liquidation loan_liqd_amt wil be-->' ||
                    L_TOT_LOAN_OS);
                DBG('for liquidation loan_liqd_amt in bill ccy-->' ||
                    L_HOLD_AMT_BILL_CCY);

                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_TOT_LOAN_OS,

                                    L_HOLD_AMT_BILL_CCY,
                                    'BILLS PURCHASED',
                                    'LOAN_LIQD_AMT',
                                    'Y',
                                    L_EFFC_LCY_COL_EX_RATE);

                DBG('here l_Bill_Or_Pur_Amt_Liqd -->' ||
                    L_BILL_OR_PUR_AMT_LIQD);
                DBG('here l_hold_amt_bill_ccy -->' || L_HOLD_AMT_BILL_CCY);
                L_COLL_LIQ_AMT := L_BILL_OR_PUR_AMT_LIQD -
                                  L_HOLD_AMT_BILL_CCY;
                DBG('here l_coll_liq_amt is-->' || L_COLL_LIQ_AMT);
                L_HOLD_LIQD_AMT := L_COLL_LIQ_AMT;

                IF L_COLL_LIQ_AMT > 0 THEN
                  DBG('coll liq_amt is der');
                  FOR EACH_REC IN (SELECT *
                                     FROM BCTBS_PURCHASE_LIQ_DTLS
                                    WHERE BCREFNO = P_BCREFNO
                                      AND SETTLED = 'N'
                                      AND EVENT_SEQ_NO =
                                          (SELECT MIN(EVENT_SEQ_NO)
                                             FROM BCTBS_PURCHASE_LIQ_DTLS
                                            WHERE BCREFNO = P_BCREFNO
                                              AND EVENT_SEQ_NO > 0)
                                    ORDER BY ENTRY_SR_NO) LOOP
                    L_COL_BOOL := TRUE;
                    DBG('some loans are der each_rec.cl_acct_no-->' ||
                        EACH_REC.CL_ACCT_NO);
                    IF EACH_REC.CL_ACCT_NO IS NOT NULL THEN

                      DBG('cl account is not null');
                      BEGIN
                        SELECT CURRENCY
                          INTO L_CURRENCY
                          FROM CLTBS_ACCOUNT_MASTER
                         WHERE BRANCH_CODE =
                               SUBSTR(EACH_REC.CL_ACCT_NO, 1, 3)
                           AND ACCOUNT_NUMBER = EACH_REC.CL_ACCT_NO;
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('inside when others of this select-->' ||
                              SQLERRM);
                          RETURN FALSE;
                      END;
                    ELSE

                      DBG('no cls are linked');
                      L_CURRENCY := L_BILL_CCY;
                    END IF;

                    DBG('l_currency here-->' || L_CURRENCY);
                    IF EACH_REC.AMOUNT_TAG <> 'AMT_PURCHASED' THEN
                      DBG('each_rec.amount_tag is here-->' ||
                          EACH_REC.AMOUNT_TAG);
                      IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                    L_CURRENCY,
                                                    L_BILL_CCY,
                                                    EACH_REC.PURCHASE_AMT_TAG_CCY,
                                                    'Y',
                                                    L_PURC_AMT_TAG_CCY,
                                                    EACH_REC.EX_RATE,
                                                    P_ERR_CODES) THEN
                        OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                        RAISE PURCHASE_EXCEPTION;
                      END IF;
                    ELSE
                      DBG('each_rec.purchase_amt_tag_ccy here is-->' ||
                          EACH_REC.PURCHASE_AMT_TAG_CCY);
                      L_PURC_AMT_TAG_CCY := EACH_REC.PURCHASE_AMT_TAG_CCY;
                    END IF;

                    DBG('l_purc_amt_tag_ccy here-->' || L_PURC_AMT_TAG_CCY);
                    L_COMPARE_LIQD_AMT := L_COMPARE_LIQD_AMT +
                                          L_PURC_AMT_TAG_CCY;
                    DBG('compare liqd amt is-->' || L_COMPARE_LIQD_AMT);
                    DBG('the hold liqd amt is-->' || L_HOLD_LIQD_AMT);
                    IF L_HOLD_LIQD_AMT = L_COMPARE_LIQD_AMT THEN
                      DBG('seemd to be both are equal');
                      PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                          EACH_REC.CL_ACCT_NO,
                                          P_ESN,
                                          CREC.EVENT_CODE,
                                          L_PURC_AMT_TAG_CCY,
                                          L_LOCAL_AMT,
                                          'BILLS PURCHASED',
                                          'AMT_PURCHASED',
                                          'Y',
                                          L_EFFC_LCY_COL_EX_RATE);
                      UPDATE BCTBS_PURCHASE_LIQ_DTLS
                         SET SETTLED = 'Y'
                       WHERE BCREFNO = CREC.BCREFNO
                         AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
                         AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
                      EXIT;
                    ELSIF L_HOLD_LIQD_AMT > L_COMPARE_LIQD_AMT THEN
                      DBG('seems to be hold liqd amt is greater than compare_liqd_amt');
                      PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                          EACH_REC.CL_ACCT_NO,
                                          P_ESN,
                                          CREC.EVENT_CODE,
                                          L_PURC_AMT_TAG_CCY,
                                          L_LOCAL_AMT,
                                          'BILLS PURCHASED',
                                          'AMT_PURCHASED',
                                          'Y',

                                          L_EFFC_LCY_PUR_XRATE);
                      UPDATE BCTBS_PURCHASE_LIQ_DTLS
                         SET SETTLED = 'Y'
                       WHERE BCREFNO = CREC.BCREFNO
                         AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
                         AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
                    ELSIF L_HOLD_LIQD_AMT < L_COMPARE_LIQD_AMT THEN

                      DBG('seems to be hold liqd amt is greater than l_compare_liqd_amt');
                      L_RESIDUAL_AMT := L_PURC_AMT_TAG_CCY -
                                        (L_COMPARE_LIQD_AMT -
                                        L_HOLD_LIQD_AMT);
                      DBG('l_residual_amt coming here is-->' ||
                          L_RESIDUAL_AMT || '~' || EACH_REC.AMOUNT_TAG);
                      IF EACH_REC.AMOUNT_TAG = 'AMT_PURCHASED' THEN
                        DBG('here i am l_residual_amt-->' ||
                            L_RESIDUAL_AMT);
                        PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                            EACH_REC.CL_ACCT_NO,
                                            P_ESN,
                                            CREC.EVENT_CODE,
                                            L_RESIDUAL_AMT,
                                            L_LOCAL_AMT,
                                            'BILLS PURCHASED',
                                            'AMT_PURCHASED',
                                            'Y',
                                            L_EFFC_LCY_COL_EX_RATE);
                        UPDATE BCTBS_PURCHASE_LIQ_DTLS
                           SET SETTLED              = 'N',
                               PURCHASE_AMT_TAG_CCY = L_RESIDUAL_AMT,
                               PURCHASE_AMT_LCY     = L_RESIDUAL_AMT
                         WHERE BCREFNO = CREC.BCREFNO
                           AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
                           AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
                      ELSIF EACH_REC.AMOUNT_TAG = 'LOAN_LIQD_AMT' THEN
                        DBG('each_rec.amount_tag is here');
                        IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                      L_BILL_CCY,
                                                      L_CURRENCY,
                                                      L_RESIDUAL_AMT,
                                                      'Y',
                                                      L_PURC_AMT_TAG_CCY,
                                                      EACH_REC.EX_RATE,
                                                      P_ERR_CODES) THEN
                          OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                          RAISE PURCHASE_EXCEPTION;
                        END IF;
                        DBG('l_purc_amt_tag_ccy is-->' ||
                            L_PURC_AMT_TAG_CCY);
                        DBG('l_residual_amt is-->' || L_RESIDUAL_AMT);
                        UPDATE BCTBS_PURCHASE_LIQ_DTLS
                           SET SETTLED              = 'N',
                               PURCHASE_AMT_TAG_CCY = L_PURC_AMT_TAG_CCY,
                               PURCHASE_AMT_LCY     = L_RESIDUAL_AMT
                         WHERE BCREFNO = CREC.BCREFNO
                           AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
                           AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
                      END IF;
                      EXIT;
                    END IF;
                  END LOOP;
                  IF NOT L_COL_BOOL THEN
                    DBG('l_col_bool is false');
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,

                                        '',

                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_COLL_LIQ_AMT,
                                        L_COLL_LIQ_AMT,
                                        'BILLS PURCHASED',
                                        'COLL_LIQ_AMT',
                                        'Y',
                                        L_EFFC_LCY_COL_EX_RATE);
                  END IF;
                  IF L_COL_BOOL THEN
                    DBG('l_col_bool is true l_coll_liq_amt-->' ||
                        L_COLL_LIQ_AMT || '~' || L_COMPARE_LIQD_AMT);
                    IF (L_COLL_LIQ_AMT - L_COMPARE_LIQD_AMT) > 0 THEN
                      DBG('(l_coll_liq_amt- l_compare_liqd_amt) is greater than zero');
                      PR_INS_PURCHASE_LIQ(CREC.BCREFNO,

                                          '',

                                          P_ESN,
                                          CREC.EVENT_CODE,
                                          (L_COLL_LIQ_AMT -
                                          L_COMPARE_LIQD_AMT),
                                          (L_COLL_LIQ_AMT -
                                          L_COMPARE_LIQD_AMT),
                                          'BILLS PURCHASED',
                                          'COLL_LIQ_AMT',
                                          'Y',
                                          L_EFFC_LCY_COL_EX_RATE);

                    END IF;
                  END IF;
                END IF;
                PROCEED_BOOL := FALSE;
              END IF;
              IF L_MARK_BOOL THEN
                DBG('l_mark_bool is true l_liqd_amt-->' || L_LIQD_AMT || '~' ||
                    L_LOCAL_AMT);
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                              CREC.LINKED_CCY,
                                              L_BILL_CCY,
                                              L_LIQD_AMT,
                                              'Y',
                                              L_LOCAL_AMT,
                                              L_EFFC_LCY_COL_EX_RATE,
                                              P_ERR_CODES) THEN
                  OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                  RAISE PURCHASE_EXCEPTION;
                END IF;
                DBG('l_mark_bool is true l_liqd_amt111-->' || L_LIQD_AMT || '~' ||
                    L_LOCAL_AMT);
                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_LIQD_AMT,
                                    L_LOCAL_AMT,
                                    'BILLS PURCHASED',
                                    'LOAN_LIQD_AMT',
                                    'Y',
                                    L_EFFC_LCY_COL_EX_RATE);
              END IF;
            ELSIF L_HOLD_AMT = L_COMPARE_AMT THEN
              DBG('seems both are same l_Tot_Loan_Os-->' || L_TOT_LOAN_OS);
              L_LIQD_AMT := L_TOT_LOAN_OS;
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                            CREC.LINKED_CCY,
                                            L_BILL_CCY,
                                            L_LIQD_AMT,
                                            'Y',
                                            L_HOLD_AMT_BILL_CCY,
                                            L_EFFC_LCY_COL_EX_RATE,
                                            P_ERR_CODES) THEN
                RETURN FALSE;
                RAISE PURCHASE_EXCEPTION;
              END IF;
              DBG('l_liqd_amt and l_hold_amt_bill_ccy is-->' || L_LIQD_AMT || '~' ||
                  L_HOLD_AMT_BILL_CCY);
              PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                  CREC.CL_ACCOUNT,
                                  P_ESN,
                                  CREC.EVENT_CODE,
                                  L_LIQD_AMT,
                                  L_HOLD_AMT_BILL_CCY,
                                  'BILLS PURCHASED',
                                  'LOAN_LIQD_AMT',
                                  'Y',
                                  L_EFFC_LCY_COL_EX_RATE);
              PROCEED_BOOL := FALSE;
            ELSIF L_HOLD_AMT > L_COMPARE_AMT THEN
              DBG('l_hold_amt is graeter than l_compare_amt l_Tot_Loan_Os-->' ||
                  L_TOT_LOAN_OS || '~' || L_HOLD_AMT || '~' ||
                  L_COMPARE_AMT);
              L_LIQD_AMT := L_TOT_LOAN_OS - (L_HOLD_AMT - L_COMPARE_AMT);
              DBG('l_liqd_amt here is-->' || L_LIQD_AMT);
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                            L_BILL_CCY,
                                            GLOBAL.LCY,
                                            L_LIQD_AMT,
                                            'Y',
                                            L_HOLD_AMT_BILL_CCY,
                                            L_EFFC_LCY_COL_EX_RATE,
                                            P_ERR_CODES) THEN
                OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                RAISE PURCHASE_EXCEPTION;
              END IF;
              DBG('inserting into pr_ins_purchase_liq-->' ||
                  L_HOLD_AMT_BILL_CCY || '~' || L_LIQD_AMT);
              PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                  CREC.CL_ACCOUNT,
                                  P_ESN,
                                  CREC.EVENT_CODE,
                                  L_LIQD_AMT,
                                  L_HOLD_AMT_BILL_CCY,
                                  'BILLS PURCHASED',
                                  'LOAN_LIQD_AMT',
                                  'Y',
                                  L_EFFC_LCY_COL_EX_RATE);
              PROCEED_BOOL := FALSE;
            END IF;
          END IF;
          DBG('for no fx linked loan liquidation amount is-->' ||
              L_LIQD_AMT);
          L_AMT_TO_LIQ_EQ := L_LIQD_AMT;
        ELSIF (CREC.LINKED_CCY = GLOBAL.LCY AND L_NO_FX_BOOL = FALSE) THEN
          DBG('the linked currency is same as the global currency and fx are linked');
          DBG('event code is -->' || P_EVENT);
          DBG('operation code is -->' || L_OPERATION);
          IF P_EVENT IN ('BPUR', 'BDIS') OR
             (P_EVENT IN ('INIT') AND L_OPERATION IN ('PUR', 'DIS', 'NEG')) THEN
            L_HOLD_AMT := L_HOLD_AMT + L_TOT_LOAN_OS;
            DBG('now the processing count is-->' || L_PROCESSED_CNT);
            DBG(' the total no of cl linked is-->' || L_CL_LINKED);
            IF L_PROCESSED_CNT = L_CL_LINKED THEN
              DBG('this seems to be the last cl');
              L_BOOL_LINK_PRCD := TRUE;
              PROCEED_BOOL     := FALSE;
            END IF;
            DBG('l_hold_amt-->' || L_HOLD_AMT || 'l_Tot_Loan_Os-->' ||
                L_TOT_LOAN_OS);
            DBG('the compare amount is-->' || L_COMPARE_AMT);
            IF L_HOLD_AMT < L_COMPARE_AMT THEN
              DBG(' here when total loan linked amount is less than purchase amount');
              L_LIQD_AMT := L_TOT_LOAN_OS;
              IF L_BOOL_LINK_PRCD THEN
                DBG('this seems to be the last cl which linked l_hold_amt-->' ||
                    L_HOLD_AMT || '~' || L_LINKED_PART_EQ);
                L_MARK_BOOL := FALSE;
                IF L_HOLD_AMT < L_LINKED_PART_EQ OR
                   L_HOLD_AMT = L_LINKED_PART_EQ THEN
                  DBG('here the total linked amount is less than linked equivalent part');
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_LIQD_AMT,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_EFFC_LCY_PUR_XRATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('inserting laon_liqd_amt');
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_LIQD_AMT,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'N',
                                      L_EFFC_LCY_PUR_XRATE);
                  DBG('l_hold_amt_bill_ccy here1-->' ||
                      L_HOLD_AMT_BILL_CCY);
                  DBG('l_hold_amt her1-->' || L_HOLD_AMT);

                  DBG('l_Purchase_Amount~l_hold_amt_bill_ccy-->' ||
                      L_PURCHASE_AMOUNT || '~' || L_HOLD_AMT_BILL_CCY);
                  L_AMT_PURCHASED_BILL_CCY := L_PURCHASE_AMOUNT -
                                              L_HOLD_AMT_BILL_CCY;
                  DBG('l_compare_amt~l_hold_amt-->' || L_COMPARE_AMT || '~' ||
                      L_HOLD_AMT);
                  L_AMT_PURCHASED_LCY := L_COMPARE_AMT - L_HOLD_AMT;
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_AMT_PURCHASED_BILL_CCY,
                                      L_AMT_PURCHASED_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'AMT_PURCHASED',
                                      'N',
                                      L_EFFC_LCY_PUR_XRATE);
                  PROCEED_BOOL := FALSE;
                ELSIF L_HOLD_AMT > L_LINKED_PART_EQ THEN
                  DBG('coming here');
                  DBG('the hold amount here is-->' || L_HOLD_AMT);
                  DBG('the liqd amount here is-->' || L_LIQD_AMT);
                  L_LAST_HOLD_AMT := L_HOLD_AMT - L_LIQD_AMT;
                  DBG('l_last_hold_amt~l_linked_part_eq-->' ||
                      L_LAST_HOLD_AMT || '~' || L_LINKED_PART_EQ);
                  IF L_LAST_HOLD_AMT >= L_LINKED_PART_EQ THEN
                    DBG('last hold amount is greater than l_linked_part_eq');
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_LINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_EFFC_LCY_PUR_XRATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;
                    DBG('LOAN_LIQD_AMT is-->' || L_RESIDUAL_LINK_PART || '~' ||
                        L_HOLD_AMT_BILL_CCY);
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_LINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'N',
                                        L_EFFC_LCY_PUR_XRATE);
                  END IF;

                  DBG('l_linked_part_eq-->' || L_LINKED_PART_EQ);
                  IF L_LAST_HOLD_AMT < L_LINKED_PART_EQ THEN

                    DBG('last hold amount is-->' || L_LAST_HOLD_AMT);
                    DBG('l_linked_part_eq~l_last_hold_amt-->' ||
                        L_LAST_HOLD_AMT || '-->' || L_LAST_HOLD_AMT);
                    L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ -
                                            L_LAST_HOLD_AMT;

                    DBG('residual part coming here is-->' ||
                        L_RESIDUAL_LINK_PART);
                    IF L_RESIDUAL_LINK_PART <> 0 THEN
                      IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                    CREC.LINKED_CCY,
                                                    L_BILL_CCY,
                                                    L_RESIDUAL_LINK_PART,
                                                    'Y',
                                                    L_HOLD_AMT_BILL_CCY,
                                                    L_EFFC_LCY_PUR_XRATE,
                                                    P_ERR_CODES) THEN
                        OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                        RAISE PURCHASE_EXCEPTION;
                      END IF;
                      DBG('residual part coming here is going to insert pr_ins_purchase_liq');
                      PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                          CREC.CL_ACCOUNT,
                                          P_ESN,
                                          CREC.EVENT_CODE,
                                          L_RESIDUAL_LINK_PART,
                                          L_HOLD_AMT_BILL_CCY,
                                          'BILLS PURCHASED',
                                          'LOAN_LIQD_AMT',
                                          'N',
                                          L_EFFC_LCY_PUR_XRATE);
                    END IF;

                    DBG('l_residual_link_part-->l_Tot_Loan_Os-->' ||
                        L_RESIDUAL_LINK_PART || '-->' || L_TOT_LOAN_OS);
                    L_RESIDUAL_UNLINK_PART := ABS(L_RESIDUAL_LINK_PART -
                                                  L_TOT_LOAN_OS);

                    DBG('l_residual_unlink_part is-->' ||
                        L_RESIDUAL_UNLINK_PART);
                    IF L_RESIDUAL_UNLINK_PART <> 0 THEN
                      DBG('its greater than zero');
                      IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                    CREC.LINKED_CCY,
                                                    L_BILL_CCY,
                                                    L_RESIDUAL_UNLINK_PART,
                                                    'Y',
                                                    L_HOLD_AMT_BILL_CCY,
                                                    L_UNLINKED_FX_RATE,
                                                    P_ERR_CODES) THEN
                        OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                        RAISE PURCHASE_EXCEPTION;
                      END IF;
                      DBG('LOAN_LIQD_AMT is-->' || L_RESIDUAL_UNLINK_PART ||
                          '-->' || L_HOLD_AMT_BILL_CCY);
                      PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                          CREC.CL_ACCOUNT,
                                          P_ESN,
                                          CREC.EVENT_CODE,
                                          L_RESIDUAL_UNLINK_PART,
                                          L_HOLD_AMT_BILL_CCY,
                                          'BILLS PURCHASED',
                                          'LOAN_LIQD_AMT',
                                          'N',

                                          L_UNLINKED_FX_RATE);
                    END IF;

                    DBG('linked part conversion for -->' ||
                        L_LINKED_PART_EQ || '~' || L_LINKED_PART_BILL_CCY);
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_LINKED_PART_EQ,
                                                  'Y',
                                                  L_LINKED_PART_BILL_CCY,
                                                  L_EFFC_LCY_PUR_XRATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;

                    DBG('unlinked part conversion-->' || L_HOLD_AMT || '~' ||
                        L_LINKED_PART_EQ);
                    L_USED_UNLINKED_PART := L_HOLD_AMT - L_LINKED_PART_EQ;
                    DBG('unused unlinked part is-->' ||
                        L_USED_UNLINKED_PART);
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_USED_UNLINKED_PART,
                                                  'Y',
                                                  L_UNLINKED_PART_BILL_CCY,
                                                  L_UNLINKED_FX_RATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;
                    DBG('unused unlinked part is11-->' ||
                        L_USED_UNLINKED_PART || '-->' ||
                        L_UNLINKED_PART_BILL_CCY);
                    DBG('l_remaining_amt-->l_Purchase_Amount-->' ||
                        L_PURCHASE_AMOUNT || '-->' ||
                        L_LINKED_PART_BILL_CCY || '-->' ||
                        L_UNLINKED_PART_BILL_CCY);
                    L_REMAINING_AMT := L_PURCHASE_AMOUNT -
                                       (L_LINKED_PART_BILL_CCY +
                                       L_UNLINKED_PART_BILL_CCY);
                    DBG('l_remaining_amt is-->' || L_REMAINING_AMT);
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_REMAINING_AMT,
                                        L_REMAINING_AMT,
                                        'BILLS PURCHASED',
                                        'AMT_PURCHASED',
                                        'N',
                                        L_EFFC_LCY_PUR_XRATE);
                  END IF;
                  PROCEED_BOOL := FALSE;
                END IF;
              END IF;

              IF L_MARK_BOOL THEN
                DBG('this is a general process with the fx linked');
                DBG('now the hold amount is-->' || L_HOLD_AMT);
                DBG('now the l_linked_part_eq is-->' || L_LINKED_PART_EQ);
                DBG('now the l_unlinked_part_eq is-->' ||
                    L_UNLINKED_PART_EQ);
                IF L_HOLD_AMT < L_LINKED_PART_EQ OR
                   L_HOLD_AMT = L_LINKED_PART_EQ THEN
                  DBG('this is falling under linked part');
                  DBG('rate will apply as-->' || L_EFFC_LCY_PUR_XRATE);
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_LIQD_AMT,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_EFFC_LCY_PUR_XRATE,
                                                P_ERR_CODES) THEN

                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('here the loan_liqd_amt going to be in bill ccy-->' ||
                      L_HOLD_AMT_BILL_CCY);
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_LIQD_AMT,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'N',
                                      L_EFFC_LCY_PUR_XRATE);
                ELSIF L_HOLD_AMT > L_LINKED_PART_EQ THEN
                  DBG('see now linked part got over it seems l_linked_part_eq-->' ||
                      L_LINKED_PART_EQ || '-->' || L_HOLD_AMT || '-->' ||
                      L_TOT_LOAN_OS);
                  L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ -
                                          (L_HOLD_AMT - L_TOT_LOAN_OS);
                  DBG('finally the residual linked part amount is-->' ||
                      L_RESIDUAL_LINK_PART);
                  IF L_RESIDUAL_LINK_PART <> 0 THEN
                    DBG('so some residual is there for linked part');
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_LINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_EFFC_LCY_PUR_XRATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;
                    DBG('so converted residual part is-->' ||
                        L_HOLD_AMT_BILL_CCY);
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_LINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'N',
                                        L_EFFC_LCY_PUR_XRATE);
                  END IF;
                  DBG('outstanding for this laon is-->' || L_TOT_LOAN_OS);
                  L_RESIDUAL_UNLINK_PART := L_TOT_LOAN_OS -
                                            L_RESIDUAL_LINK_PART;
                  DBG('now the residual unlinked part is-->' ||
                      L_RESIDUAL_UNLINK_PART);
                  IF L_RESIDUAL_UNLINK_PART <> 0 THEN
                    DBG('some unlink part is also der-->' ||
                        L_RESIDUAL_UNLINK_PART);
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_UNLINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_UNLINKED_FX_RATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;

                    DBG('after this l_hold_amt_bill_ccy is-->' ||
                        L_HOLD_AMT_BILL_CCY);
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_UNLINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'N',
                                        L_UNLINKED_FX_RATE);
                  END IF;
                END IF;
              END IF;
            ELSIF L_HOLD_AMT = L_COMPARE_AMT THEN
              DBG('if the total linked cl os amount is equal to purchase amount l_Tot_Loan_Os-->' ||
                  L_TOT_LOAN_OS || '~' || L_HOLD_AMT);
              L_LIQD_AMT      := L_TOT_LOAN_OS;
              L_LOAN_LIQD_AMT := L_HOLD_AMT;

              DBG('l_hold_amt~l_linked_part_eq-->' || L_LINKED_PART_EQ ||
                  '-->' || L_HOLD_AMT);
              IF L_HOLD_AMT < L_LINKED_PART_EQ OR
                 L_HOLD_AMT = L_LINKED_PART_EQ THEN
                DBG('the total loan liqd amt is-->' || L_LOAN_LIQD_AMT);
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                              CREC.LINKED_CCY,
                                              L_BILL_CCY,
                                              L_LIQD_AMT,
                                              'Y',
                                              L_LOCAL_AMT,
                                              L_EFFC_LCY_PUR_XRATE,
                                              P_ERR_CODES) THEN
                  OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                  RAISE PURCHASE_EXCEPTION;
                END IF;
                DBG('this l_local_amt-->' || L_LOCAL_AMT);
                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_HOLD_AMT,
                                    L_LOCAL_AMT,
                                    'BILLS PURCHASED',
                                    'LOAN_LIQD_AMT',
                                    'N',
                                    L_EFFC_LCY_PUR_XRATE);

              ELSIF L_HOLD_AMT > L_LINKED_PART_EQ THEN
                DBG('this time the l_hold_amt  is-->' || L_HOLD_AMT ||
                    '-->' || L_LIQD_AMT);
                L_LAST_HOLD_AMT := L_HOLD_AMT - L_LIQD_AMT;
                DBG('this time the hold amount is-->' || L_LAST_HOLD_AMT);
                IF L_LAST_HOLD_AMT >= L_LINKED_PART_EQ THEN
                  DBG('l_last_hold_amt is more than l_linked_part_eq');
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_LIQD_AMT,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_UNLINKED_FX_RATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('l_hold_amt_bill_ccy xoming is -->' ||
                      L_HOLD_AMT_BILL_CCY);
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_LIQD_AMT,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'N',
                                      L_UNLINKED_FX_RATE);
                ELSIF L_LAST_HOLD_AMT < L_LINKED_PART_EQ THEN

                  DBG('last hold amount is-->' || L_LAST_HOLD_AMT || '~' ||
                      L_LINKED_PART_EQ);

                  L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ -
                                          L_LAST_HOLD_AMT;
                  DBG('the residual linked part here is-->' ||
                      L_RESIDUAL_LINK_PART);
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_RESIDUAL_LINK_PART,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_EFFC_LCY_PUR_XRATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('here l_residual_link_part is-->' ||
                      L_RESIDUAL_LINK_PART);
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_RESIDUAL_LINK_PART,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'N',
                                      L_EFFC_LCY_PUR_XRATE);

                  L_RESIDUAL_UNLINK_PART := L_LIQD_AMT -
                                            L_RESIDUAL_LINK_PART;

                  DBG('the residual unlinked part here is-->' ||
                      L_RESIDUAL_LINK_PART);
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_RESIDUAL_UNLINK_PART,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_UNLINKED_FX_RATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('inserting l_residual_unlink_part-->' ||
                      L_RESIDUAL_UNLINK_PART);
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_RESIDUAL_UNLINK_PART,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'N',
                                      L_UNLINKED_FX_RATE);
                END IF;

              END IF;
              PROCEED_BOOL := FALSE;
            ELSIF L_HOLD_AMT > L_COMPARE_AMT THEN
              DBG('the total amount liked is more than the purchase amount ');
              DBG('the total amount liked l_Tot_Loan_Os --> ' ||
                  L_TOT_LOAN_OS);
              DBG('the total amount liked l_hold_amt --> ' || L_HOLD_AMT);
              DBG('the total amount liked l_compare_amt --> ' ||
                  L_COMPARE_AMT);
              DBG('the total amount liked l_linked_part_eq --> ' ||
                  L_LINKED_PART_EQ);
              DBG('the total amount liked l_unlinked_part_eq --> ' ||
                  L_UNLINKED_PART_EQ);
              L_LIQD_AMT := L_TOT_LOAN_OS - (L_HOLD_AMT - L_COMPARE_AMT);
              DBG('the liquidation amount is-->' || L_LIQD_AMT);
              IF L_HOLD_AMT < L_LINKED_PART_EQ OR
                 L_HOLD_AMT = L_LINKED_PART_EQ THEN
                DBG('the hold amount is still less than the linked part ');

                IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                              CREC.LINKED_CCY,
                                              L_BILL_CCY,
                                              L_LIQD_AMT,
                                              'Y',
                                              L_LOCAL_AMT,
                                              L_EFFC_LCY_PUR_XRATE,
                                              P_ERR_CODES) THEN
                  OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                  RAISE PURCHASE_EXCEPTION;
                END IF;
                DBG('total loan liqd amit is--> ' || L_LIQD_AMT);
                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_LIQD_AMT,
                                    L_LOCAL_AMT,
                                    'BILLS PURCHASED',
                                    'LOAN_LIQD_AMT',
                                    'N',
                                    L_EFFC_LCY_PUR_XRATE);
              ELSIF L_HOLD_AMT > L_LINKED_PART_EQ THEN
                DBG('the hold amount is still greater than the linked part ');
                L_LAST_HOLD_AMT := L_HOLD_AMT - L_TOT_LOAN_OS;
                DBG('the last hold amount is-->' || L_LAST_HOLD_AMT);
                IF L_LAST_HOLD_AMT >= L_LINKED_PART_EQ THEN
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_LIQD_AMT,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_UNLINKED_FX_RATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_LIQD_AMT,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'N',
                                      L_UNLINKED_FX_RATE);

                ELSIF (L_LAST_HOLD_AMT < L_LINKED_PART_EQ AND
                      L_LAST_HOLD_AMT <> 0) THEN
                  DBG('last hold amount is-->' || L_LAST_HOLD_AMT);

                  L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ -
                                          L_LAST_HOLD_AMT;
                  DBG('the residual linked part here is-->' ||
                      L_RESIDUAL_LINK_PART);
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_RESIDUAL_LINK_PART,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_EFFC_LCY_PUR_XRATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('l_residual_link_part~~~l_hold_amt_bill_ccy-->' ||
                      L_RESIDUAL_LINK_PART || '~~' || L_HOLD_AMT_BILL_CCY);
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_RESIDUAL_LINK_PART,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'N',
                                      L_EFFC_LCY_PUR_XRATE);
                  DBG('l_residual_link_part111l_liqd_amt-->' || L_LIQD_AMT ||
                      '111' || L_RESIDUAL_LINK_PART);
                  L_RESIDUAL_UNLINK_PART := L_LIQD_AMT -
                                            L_RESIDUAL_LINK_PART;
                  DBG('the residual unlinked part here is-->' ||
                      L_RESIDUAL_LINK_PART || '~~' || L_UNLINKED_FX_RATE);
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_RESIDUAL_UNLINK_PART,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_UNLINKED_FX_RATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('l_residual_unlink_part222l_hold_amt_bill_ccy-->' ||
                      L_RESIDUAL_UNLINK_PART || '222' ||
                      L_HOLD_AMT_BILL_CCY);
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_RESIDUAL_UNLINK_PART,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'N',
                                      L_UNLINKED_FX_RATE);

                ELSIF L_LAST_HOLD_AMT = 0 THEN
                  DBG('there may be only one cl linked');
                  DBG('here the linked part is-->' || L_LINKED_PART_EQ);
                  DBG('here the unlinked part is-->' || L_UNLINKED_PART_EQ);
                  IF L_LIQD_AMT > L_LINKED_PART_EQ THEN
                    L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ;
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_LINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_EFFC_LCY_PUR_XRATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_LINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'N',
                                        L_EFFC_LCY_PUR_XRATE);

                    L_RESIDUAL_UNLINK_PART := L_LIQD_AMT - L_LINKED_PART_EQ;

                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_UNLINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_UNLINKED_FX_RATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_UNLINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'N',
                                        L_UNLINKED_FX_RATE);
                  END IF;
                END IF;
              END IF;
              PROCEED_BOOL := FALSE;
            END IF;
            L_AMT_TO_LIQ_EQ := L_LIQD_AMT;
            DBG('finally the amount o be liquidated is-->' ||
                L_AMT_TO_LIQ_EQ);
          ELSIF SUBSTR(P_EVENT, 1, 1) IN ('L') THEN
            L_HOLD_AMT := L_HOLD_AMT + L_TOT_LOAN_OS;
            DBG('l_hold_amt-->' || L_HOLD_AMT);
            DBG('l_Tot_Loan_Os-->' || L_TOT_LOAN_OS);
            DBG('l_Bill_Or_Pur_Amt_Liqd-->' || L_BILL_OR_PUR_AMT_LIQD);
            IF L_PROCESSED_CNT = L_CL_LINKED THEN
              L_BOOL_LINK_PRCD := TRUE;
              PROCEED_BOOL     := FALSE;
            END IF;
            DBG('l_compare_amt-->' || L_COMPARE_AMT);
            IF L_HOLD_AMT < L_COMPARE_AMT THEN

              L_LIQD_AMT := L_TOT_LOAN_OS;
              IF L_BOOL_LINK_PRCD THEN
                L_MARK_BOOL := FALSE;
                DBG('inside this1');
                IF L_HOLD_AMT < L_LINKED_PART_EQ OR
                   L_HOLD_AMT = L_LINKED_PART_EQ THEN

                  DBG('hold amt here is-->' || L_HOLD_AMT);
                  DBG('l_linked_part_eq amt here is-->' ||
                      L_LINKED_PART_EQ);
                  DBG('l_effc_lcy_col_ex_rate coming here is-->' ||
                      L_EFFC_LCY_COL_EX_RATE);
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_LIQD_AMT,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_EFFC_LCY_COL_EX_RATE,
                                                P_ERR_CODES) THEN
                    DBG('failed while converting rate');
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('l_hold_amt_bill_ccy in bill ccy is->' ||
                      L_HOLD_AMT_BILL_CCY);
                  L_TOT_LIQD_AMT := L_TOT_LIQD_AMT + L_HOLD_AMT_BILL_CCY;
                  DBG('total liq amt became-->' || L_TOT_LIQD_AMT);

                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_TOT_LOAN_OS,

                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'Y',
                                      L_EFFC_LCY_COL_EX_RATE);

                  DBG('after callinf pr_ins_purchase_liq is-->' ||
                      L_HOLD_AMT_BILL_CCY);

                ELSIF L_HOLD_AMT > L_LINKED_PART_EQ THEN
                  DBG('l_hold_amt is greater than l_linked_part_eq l_hold_amt-->' ||
                      L_HOLD_AMT);
                  DBG('l_hold_amt is greater than l_linked_part_eq l_linked_part_eq-->' ||
                      L_LINKED_PART_EQ);
                  DBG('the total loan outstandinga mount is-->' ||
                      L_TOT_LOAN_OS);
                  L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ -
                                          (L_HOLD_AMT - L_TOT_LOAN_OS);
                  L_UTILIZED_LINK_PART := L_RESIDUAL_LINK_PART;
                  DBG('now the utilized linked part is-->' ||
                      L_UTILIZED_LINK_PART);
                  DBG('residual linked part is-->' || L_RESIDUAL_LINK_PART);
                  IF L_RESIDUAL_LINK_PART <> 0 THEN
                    DBG('some residual part is der-->' ||
                        L_RESIDUAL_LINK_PART);
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_LINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_EFFC_LCY_COL_EX_RATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_LINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'Y',
                                        L_EFFC_LCY_COL_EX_RATE);
                  END IF;
                  L_TOT_LIQD_AMT := L_TOT_LIQD_AMT + L_HOLD_AMT_BILL_CCY;
                  DBG('the total liquidation amount became-->' ||
                      L_TOT_LIQD_AMT);
                  L_RESIDUAL_UNLINK_PART := ABS(L_TOT_LOAN_OS -
                                                L_RESIDUAL_LINK_PART);
                  DBG('now the unlinked part coming here is-->' ||
                      L_RESIDUAL_UNLINK_PART);
                  IF L_RESIDUAL_UNLINK_PART <> 0 THEN
                    DBG('unlinked part is there l_residual_unlink_part-->' ||
                        L_RESIDUAL_UNLINK_PART || '-->' ||
                        L_UNLINKED_FX_RATE);
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_UNLINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_UNLINKED_FX_RATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;
                    DBG('the converetd amount coming here is-->' ||
                        L_HOLD_AMT_BILL_CCY);
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_UNLINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'Y',
                                        L_UNLINKED_FX_RATE);
                  END IF;
                  L_TOT_LIQD_AMT := L_TOT_LIQD_AMT + L_HOLD_AMT_BILL_CCY;
                  DBG('the total liquidation amount here is-->' ||
                      L_TOT_LIQD_AMT);

                END IF;

                L_COLL_LIQ_AMT  := L_BILL_OR_PUR_AMT_LIQD - L_TOT_LIQD_AMT;
                L_HOLD_LIQD_AMT := L_COLL_LIQ_AMT;
                DBG('l_coll_liq_amt here-->' || L_COLL_LIQ_AMT);
                DBG('l_hold_liqd_amt here-->' || L_HOLD_LIQD_AMT);
                IF L_COLL_LIQ_AMT > 0 THEN
                  DBG('coll liq amt is greater than zero');
                  FOR EACH_REC IN (SELECT *
                                     FROM BCTBS_PURCHASE_LIQ_DTLS
                                    WHERE BCREFNO = P_BCREFNO
                                      AND SETTLED = 'N'
                                      AND EVENT_SEQ_NO =
                                          (SELECT MIN(EVENT_SEQ_NO)
                                             FROM BCTBS_PURCHASE_LIQ_DTLS
                                            WHERE BCREFNO = P_BCREFNO
                                              AND EVENT_SEQ_NO > 0)
                                    ORDER BY ENTRY_SR_NO) LOOP

                    DBG('the unsettled amount tag is-->' ||
                        EACH_REC.AMOUNT_TAG);
                    L_COL_BOOL := TRUE;
                    DBG('each_rec.cl_acct_no is-->' || EACH_REC.CL_ACCT_NO);
                    IF EACH_REC.CL_ACCT_NO IS NOT NULL THEN

                      BEGIN
                        SELECT CURRENCY
                          INTO L_CURRENCY
                          FROM CLTBS_ACCOUNT_MASTER
                         WHERE BRANCH_CODE =
                               SUBSTR(EACH_REC.CL_ACCT_NO, 1, 3)
                           AND ACCOUNT_NUMBER = EACH_REC.CL_ACCT_NO;
                        DBG('currency of the cl linked was-->' ||
                            L_CURRENCY);
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('inside when others of this select-->' ||
                              SQLERRM);
                          RETURN FALSE;
                      END;
                    ELSE
                      DBG('no cl linked at that time so taking biil _cyy -->' ||
                          L_BILL_CCY);
                      L_CURRENCY := L_BILL_CCY;
                    END IF;
                    DBG('wat is the amount tag here-->' ||
                        EACH_REC.AMOUNT_TAG);
                    IF EACH_REC.AMOUNT_TAG <> 'AMT_PURCHASED' THEN
                      DBG('amount tag is not equal to AMT_PURCHASED-->' ||
                          EACH_REC.AMOUNT_TAG);
                      DBG('the purchase amount atg ccy is-->' ||
                          EACH_REC.PURCHASE_AMT_TAG_CCY || 'with rate-->' ||
                          EACH_REC.EX_RATE);
                      IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                    L_CURRENCY,
                                                    L_BILL_CCY,
                                                    EACH_REC.PURCHASE_AMT_TAG_CCY,
                                                    'Y',
                                                    L_PURC_AMT_TAG_CCY,
                                                    EACH_REC.EX_RATE,
                                                    P_ERR_CODES) THEN
                        OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                        RAISE PURCHASE_EXCEPTION;
                      END IF;
                    ELSE
                      DBG('the amount tag is--> AMT_PURCHASED-->' ||
                          EACH_REC.PURCHASE_AMT_TAG_CCY);
                      L_PURC_AMT_TAG_CCY := EACH_REC.PURCHASE_AMT_TAG_CCY;
                    END IF;

                    DBG('l_purc_amt_tag_ccy here is-->' ||
                        L_PURC_AMT_TAG_CCY);
                    DBG('l_compare_liqd_amt here is-->' ||
                        L_COMPARE_LIQD_AMT);
                    L_COMPARE_LIQD_AMT := L_COMPARE_LIQD_AMT +
                                          L_PURC_AMT_TAG_CCY;
                    DBG('l_compare_liqd_amt heer is-->' ||
                        L_COMPARE_LIQD_AMT);
                    IF L_HOLD_LIQD_AMT = L_COMPARE_LIQD_AMT THEN

                      DBG('l_hold_liqd_amt = l_compare_liqd_amt');
                      PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                          EACH_REC.CL_ACCT_NO,
                                          P_ESN,
                                          CREC.EVENT_CODE,
                                          L_PURC_AMT_TAG_CCY,
                                          L_LOCAL_AMT,
                                          'BILLS PURCHASED',
                                          'AMT_PURCHASED',
                                          'Y',
                                          L_EFFC_LCY_COL_EX_RATE);
                      DBG('each_rec.entry_sr_no is-->' ||
                          EACH_REC.ENTRY_SR_NO || 'each_rec.cl_acct_no-->' ||
                          EACH_REC.CL_ACCT_NO);
                      UPDATE BCTBS_PURCHASE_LIQ_DTLS
                         SET SETTLED = 'Y'
                       WHERE BCREFNO = CREC.BCREFNO
                         AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
                         AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
                      DBG('no of rows updated here is-->' || SQL%ROWCOUNT);
                      EXIT;
                    ELSIF L_HOLD_LIQD_AMT > L_COMPARE_LIQD_AMT THEN
                      DBG('l_hold_liqd_amt > l_compare_liqd_amt');
                      PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                          EACH_REC.CL_ACCT_NO,
                                          P_ESN,
                                          CREC.EVENT_CODE,
                                          L_PURC_AMT_TAG_CCY,
                                          L_LOCAL_AMT,
                                          'BILLS PURCHASED',
                                          'AMT_PURCHASED',
                                          'Y',
                                          L_EFFC_LCY_COL_EX_RATE);
                      UPDATE BCTBS_PURCHASE_LIQ_DTLS
                         SET SETTLED = 'Y'
                       WHERE BCREFNO = CREC.BCREFNO
                         AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
                         AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
                    ELSIF L_HOLD_LIQD_AMT < L_COMPARE_LIQD_AMT THEN
                      DBG('l_hold_liqd_amt < l_compare_liqd_amt');
                      L_RESIDUAL_AMT := L_PURC_AMT_TAG_CCY -
                                        (L_COMPARE_LIQD_AMT -
                                        L_HOLD_LIQD_AMT);
                      DBG('l_residual_amt------->' || L_RESIDUAL_AMT);
                      IF EACH_REC.AMOUNT_TAG = 'AMT_PURCHASED' THEN
                        DBG('each_rec.amount_tag <> AMT_PURCHASED');
                        PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                            EACH_REC.CL_ACCT_NO,
                                            P_ESN,
                                            CREC.EVENT_CODE,
                                            L_RESIDUAL_AMT,
                                            L_LOCAL_AMT,
                                            'BILLS PURCHASED',
                                            'AMT_PURCHASED',
                                            'Y',
                                            L_EFFC_LCY_COL_EX_RATE);
                        UPDATE BCTBS_PURCHASE_LIQ_DTLS
                           SET SETTLED              = 'N',
                               PURCHASE_AMT_TAG_CCY = L_RESIDUAL_AMT,
                               PURCHASE_AMT_LCY     = L_RESIDUAL_AMT
                         WHERE BCREFNO = CREC.BCREFNO
                           AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
                           AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
                      ELSIF EACH_REC.AMOUNT_TAG = 'LOAN_LIQD_AMT' THEN
                        DBG('each_rec.amount_tag <> LOAN_LIQD_AMT');
                        IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                      L_BILL_CCY,
                                                      L_CURRENCY,
                                                      L_RESIDUAL_AMT,
                                                      'Y',
                                                      L_PURC_AMT_TAG_CCY,
                                                      EACH_REC.EX_RATE,
                                                      P_ERR_CODES) THEN
                          OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                          RAISE PURCHASE_EXCEPTION;
                        END IF;
                        DBG('l_purc_amt_tag_ccy is-->' ||
                            L_PURC_AMT_TAG_CCY);
                        UPDATE BCTBS_PURCHASE_LIQ_DTLS
                           SET SETTLED              = 'N',
                               PURCHASE_AMT_TAG_CCY = L_PURC_AMT_TAG_CCY,
                               PURCHASE_AMT_LCY     = L_RESIDUAL_AMT
                         WHERE BCREFNO = CREC.BCREFNO
                           AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
                           AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
                      END IF;
                      EXIT;
                    END IF;
                  END LOOP;
                  IF NOT L_COL_BOOL THEN
                    DBG('l_coll_liq_amt now is-->' || L_COLL_LIQ_AMT);
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,

                                        '',

                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_COLL_LIQ_AMT,
                                        L_COLL_LIQ_AMT,
                                        'BILLS PURCHASED',
                                        'COLL_LIQ_AMT',
                                        'Y',
                                        L_EFFC_LCY_COL_EX_RATE);
                  END IF;
                  IF L_COL_BOOL THEN

                    DBG('l_coll_liq_amt - l_compare_liqd_amt-->' ||
                        (L_COLL_LIQ_AMT - L_COMPARE_LIQD_AMT));
                    IF (L_COLL_LIQ_AMT - L_COMPARE_LIQD_AMT) > 0 THEN
                      PR_INS_PURCHASE_LIQ(CREC.BCREFNO,

                                          '',

                                          P_ESN,
                                          CREC.EVENT_CODE,
                                          (L_COLL_LIQ_AMT -
                                          L_COMPARE_LIQD_AMT),
                                          (L_COLL_LIQ_AMT -
                                          L_COMPARE_LIQD_AMT),
                                          'BILLS PURCHASED',
                                          'COLL_LIQ_AMT',
                                          'Y',
                                          L_EFFC_LCY_COL_EX_RATE);

                    END IF;
                  END IF;
                END IF;
                PROCEED_BOOL := FALSE;
              END IF;
              IF L_MARK_BOOL THEN
                DBG('this is a general process l_hold_amt-->' ||
                    L_HOLD_AMT || '-->' || L_LINKED_PART_EQ);
                IF L_HOLD_AMT < L_LINKED_PART_EQ OR
                   L_HOLD_AMT = L_LINKED_PART_EQ THEN
                  DBG('l_hold_amt < l_linked_part_eq or l_hold_amt = l_linked_part_eq l_liqd_amt-->' ||
                      L_LIQD_AMT);
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_LIQD_AMT,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_EFFC_LCY_COL_EX_RATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  DBG('this is a general l_hold_amt_bill_ccy -->' ||
                      L_HOLD_AMT_BILL_CCY);
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_LIQD_AMT,
                                      L_LOCAL_AMT,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'Y',
                                      L_EFFC_LCY_COL_EX_RATE);
                ELSIF L_HOLD_AMT > L_LINKED_PART_EQ THEN

                  DBG('l_hold_amt is greater than l_linked_part_eq');
                  L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ -
                                          (L_HOLD_AMT - L_TOT_LOAN_OS);
                  DBG('l_residual_link_part is-->' || L_RESIDUAL_LINK_PART);
                  IF L_RESIDUAL_LINK_PART <> 0 THEN
                    DBG('l_residual_link_part is not zero');
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_LINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_EFFC_LCY_COL_EX_RATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;
                    DBG('is l_hold_amt_bill_ccy-->' || L_HOLD_AMT_BILL_CCY);
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_LINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'Y',
                                        L_EFFC_LCY_COL_EX_RATE);
                  END IF;
                  L_RESIDUAL_UNLINK_PART := L_RESIDUAL_LINK_PART -
                                            L_TOT_LOAN_OS;
                  DBG('is l_residual_unlink_part-->' ||
                      L_RESIDUAL_UNLINK_PART);
                  IF L_RESIDUAL_UNLINK_PART <> 0 THEN
                    DBG('l_residual_unlink_part is not equal to zero');
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                  CREC.LINKED_CCY,
                                                  L_BILL_CCY,
                                                  L_RESIDUAL_UNLINK_PART,
                                                  'Y',
                                                  L_HOLD_AMT_BILL_CCY,
                                                  L_UNLINKED_FX_RATE,
                                                  P_ERR_CODES) THEN
                      OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                      RAISE PURCHASE_EXCEPTION;
                    END IF;

                    DBG('l_hold_amt_bill_ccy is-->' || L_HOLD_AMT_BILL_CCY);
                    PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                        CREC.CL_ACCOUNT,
                                        P_ESN,
                                        CREC.EVENT_CODE,
                                        L_RESIDUAL_UNLINK_PART,
                                        L_HOLD_AMT_BILL_CCY,
                                        'BILLS PURCHASED',
                                        'LOAN_LIQD_AMT',
                                        'Y',
                                        L_UNLINKED_FX_RATE);
                  END IF;
                END IF;
              END IF;
            ELSIF L_HOLD_AMT = L_COMPARE_AMT THEN
              DBG('if the total linked cl os amount is equal to purchase amount');
              L_LIQD_AMT      := L_TOT_LOAN_OS;
              L_LOAN_LIQD_AMT := L_HOLD_AMT;
              IF L_HOLD_AMT < L_LINKED_PART_EQ OR
                 L_HOLD_AMT = L_LINKED_PART_EQ THEN
                DBG('the total loan liqd amt is-->' || L_LOAN_LIQD_AMT ||
                    'l_liqd_amt-->' || L_LIQD_AMT);
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                              CREC.LINKED_CCY,
                                              L_BILL_CCY,
                                              L_LIQD_AMT,
                                              'Y',
                                              L_LOCAL_AMT,
                                              L_EFFC_LCY_COL_EX_RATE,
                                              P_ERR_CODES) THEN
                  OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                  RAISE PURCHASE_EXCEPTION;
                END IF;
                DBG('local amount here is-->' || L_LOCAL_AMT);
                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_HOLD_AMT,
                                    L_LOCAL_AMT,
                                    'BILLS PURCHASED',
                                    'LOAN_LIQD_AMT',
                                    'Y',
                                    L_EFFC_LCY_COL_EX_RATE);
                PROCEED_BOOL := FALSE;
              ELSIF L_HOLD_AMT > L_LINKED_PART_EQ THEN

                DBG('l_hold_amt~l_linked_part_eq-->' || L_LINKED_PART_EQ || '~' ||
                    L_HOLD_AMT);
                L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ -
                                        (L_HOLD_AMT - L_TOT_LOAN_OS);
                DBG('now l_residual_link_part here is-->' ||
                    L_RESIDUAL_LINK_PART);
                IF L_RESIDUAL_LINK_PART <> 0 THEN
                  DBG('now l_residual_link_part <> 0');
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_RESIDUAL_LINK_PART,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_EFFC_LCY_COL_EX_RATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_RESIDUAL_LINK_PART,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'Y',
                                      L_EFFC_LCY_COL_EX_RATE);
                END IF;
                L_RESIDUAL_UNLINK_PART := L_RESIDUAL_LINK_PART -
                                          L_TOT_LOAN_OS;
                DBG('l_residual_unlink_part is------>' ||
                    L_RESIDUAL_UNLINK_PART);
                IF L_RESIDUAL_UNLINK_PART <> 0 THEN
                  DBG('now l_residual_unlink_part <> 0');
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_RESIDUAL_UNLINK_PART,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_UNLINKED_FX_RATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_RESIDUAL_UNLINK_PART,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'Y',
                                      L_UNLINKED_FX_RATE);
                END IF;
              END IF;
              PROCEED_BOOL := FALSE;
            ELSIF L_HOLD_AMT > L_COMPARE_AMT THEN
              DBG('the total amount liked is more than the purchase amount ');
              DBG('l_Tot_Loan_Os------------->' || L_TOT_LOAN_OS);
              DBG('l_hold_amt------------->' || L_HOLD_AMT);
              DBG('l_compare_amt------------->' || L_COMPARE_AMT);
              L_LIQD_AMT := L_TOT_LOAN_OS - (L_HOLD_AMT - L_COMPARE_AMT);
              DBG('l_liqd_amt is---------->' || L_LIQD_AMT);
              DBG('l_hold_amt-------------->' || L_HOLD_AMT);
              DBG('l_linked_part_eq------->' || L_LINKED_PART_EQ);
              IF L_HOLD_AMT < L_LINKED_PART_EQ OR
                 L_HOLD_AMT = L_LINKED_PART_EQ THEN
                DBG('l_hold_amt < l_linked_part_eq');
                DBG('l_hold_amt =  l_hold_amt');
                IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                              CREC.LINKED_CCY,
                                              L_BILL_CCY,
                                              L_LIQD_AMT,
                                              'Y',
                                              L_LOCAL_AMT,
                                              L_EFFC_LCY_PUR_XRATE,
                                              P_ERR_CODES) THEN
                  OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                  RAISE PURCHASE_EXCEPTION;
                END IF;
                PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                    CREC.CL_ACCOUNT,
                                    P_ESN,
                                    CREC.EVENT_CODE,
                                    L_LIQD_AMT,
                                    L_LOCAL_AMT,
                                    'BILLS PURCHASED',
                                    'LOAN_LIQD_AMT',
                                    'Y',
                                    L_EFFC_LCY_PUR_XRATE);
              ELSIF L_HOLD_AMT > L_LINKED_PART_EQ THEN
                DBG('l_hold_amt > l_linked_part_eq');
                DBG('l_linked_part_eq----------->' || L_LINKED_PART_EQ);
                DBG('l_hold_amt------------------>' || L_HOLD_AMT);
                DBG('l_Tot_Loan_Os---------------->' || L_TOT_LOAN_OS);
                L_RESIDUAL_LINK_PART := L_LINKED_PART_EQ -
                                        (L_HOLD_AMT - L_TOT_LOAN_OS);
                IF L_RESIDUAL_LINK_PART <> 0 THEN
                  DBG('l_residual_link_part is not zero');
                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_RESIDUAL_LINK_PART,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_EFFC_LCY_PUR_XRATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_RESIDUAL_LINK_PART,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'Y',
                                      L_EFFC_LCY_PUR_XRATE);
                END IF;
                DBG('l_Tot_Loan_Os----------->' || L_TOT_LOAN_OS);
                DBG('l_residual_link_part=--------->' ||
                    L_RESIDUAL_LINK_PART);
                L_RESIDUAL_UNLINK_PART := L_RESIDUAL_LINK_PART -
                                          L_TOT_LOAN_OS;
                DBG('l_residual_unlink_part===========>' ||
                    L_RESIDUAL_UNLINK_PART);
                IF L_RESIDUAL_UNLINK_PART <> 0 THEN

                  IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                CREC.LINKED_CCY,
                                                L_BILL_CCY,
                                                L_RESIDUAL_UNLINK_PART,
                                                'Y',
                                                L_HOLD_AMT_BILL_CCY,
                                                L_UNLINKED_FX_RATE,
                                                P_ERR_CODES) THEN
                    OVPKSS.PR_APPENDTBL(P_ERR_CODES, ' ');
                    RAISE PURCHASE_EXCEPTION;
                  END IF;
                  PR_INS_PURCHASE_LIQ(CREC.BCREFNO,
                                      CREC.CL_ACCOUNT,
                                      P_ESN,
                                      CREC.EVENT_CODE,
                                      L_RESIDUAL_UNLINK_PART,
                                      L_HOLD_AMT_BILL_CCY,
                                      'BILLS PURCHASED',
                                      'LOAN_LIQD_AMT',
                                      'Y',
                                      L_UNLINKED_FX_RATE);
                END IF;

              END IF;
              PROCEED_BOOL := FALSE;
            END IF;
            L_AMT_TO_LIQ_EQ := L_LIQD_AMT;
          END IF;
        END IF;

        DBG('here the total outstanding is-->' ||
            L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS.COUNT);
        DBG('inside the loop-->' || CREC.LINKED_CCY);
        L_BRANCH_CODE := SUBSTR(L_LOAN_REF_NO, 1, 3);
        IF NOT TRPKSS.FN_GET_PROCESS_REFNO(L_PAYMENT_OBJ.REC_LIQ.BRANCH_CODE,
                                           'ZSTL',
                                           L_PAYMENT_OBJ.REC_LIQ.VALUE_DATE,
                                           L_PSERIAL,
                                           L_STTL_REF_NO,
                                           P_ERR_CODES) THEN
          OVPKSS.PR_APPENDTBL(P_ERR_CODES, '~;');
          RETURN FALSE;
        END IF;
        DBG('settlement reference number is-->' || L_STTL_REF_NO);
        DBG('l_amt_to_liq_eq here is-->' || L_AMT_TO_LIQ_EQ);

        DBG('Count here for liq settlement is ' ||
            L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS.COUNT);

        L_STTL_REF_NO := 1;
        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS.COUNT + 1).REC_LIQ_SETTLEMENTS.SETTLE_AMOUNT := L_AMT_TO_LIQ_EQ;

        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).REC_LIQ_SETTLEMENTS.ACCOUNT_NUMBER := L_LOAN_REF_NO;
        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).REC_LIQ_SETTLEMENTS.BRANCH_CODE := L_BRANCH_CODE;
        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).REC_LIQ_SETTLEMENTS.LOAN_CCY_EQUIV := L_AMT_TO_LIQ_EQ;
        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).REC_LIQ_SETTLEMENTS.SETTLE_MODE := 'ACC';
        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).REC_LIQ_SETTLEMENTS.SETTLE_CCY := CREC.LINKED_CCY;
        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).REC_LIQ_SETTLEMENTS.SETTLE_BRN := L_BRANCH_CODE;
        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).REC_LIQ_SETTLEMENTS.SETTLEMENT_REF_NO := L_STTL_REF_NO;
        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).G_ACTION := 'I';

        DBG('after assigning l_Payment_Obj.Tb_Liq_Settlements');
        L_PAYMENT_OBJ.G_ACTION               := 'I';
        L_PAYMENT_OBJ.REC_LIQ.AUTH_STAT      := 'U';
        L_PAYMENT_OBJ.REC_LIQ.MAKER_ID       := GLOBAL.USER_ID;
        L_PAYMENT_OBJ.REC_LIQ.MAKER_DT_STAMP := FN_MNTSTAMP;
        DBG('after populating the maintenance stamp');
        IF L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).G_ACTION <> 'I' THEN
          DBG('l_Payment_Obj.Tb_Liq_Settlements(l_sttl_ref_no ).g_Action <> I');
          L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).G_ACTION := 'I';
        END IF;

        DBG('after setting the g action to I');
        BEGIN
          IF P_EVENT IN ('BPUR', 'BDIS') OR
             (P_EVENT = 'INIT' AND L_OPERATION IN ('DIS', 'PUR', 'NEG')) OR
             SUBSTR(P_EVENT, 1, 1) = 'L' THEN
            DBG('going to select from bctms_product_master');
            SELECT BRIDGE_GL
              INTO L_DR_PROD_AC
              FROM BCTMS_PRODUCT_MASTER
             WHERE PROD_CODE = SUBSTR(P_BCREFNO, 4, 4);
          ELSE
            DBG('invalid event code');
            OVPKSS.PR_APPENDTBL('BC-PUR-025', '~;');
            RAISE PURCHASE_EXCEPTION;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('inside when others -->' || SQLERRM);
            OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
            RAISE PURCHASE_EXCEPTION;
        END;
        DBG('l_Dr_Prod_Ac-->' || L_DR_PROD_AC);

        L_PAYMENT_OBJ.TB_LIQ_SETTLEMENTS(L_STTL_REF_NO).REC_LIQ_SETTLEMENTS.SETTLE_ACC := L_DR_PROD_AC;

        DBG('going to call Clpkss_Payment.Fn_Allocate');
        IF NOT CLPKSS_PAYMENT.FN_ALLOCATE(L_PAYMENT_OBJ,
                                          P_ERR_CODES,
                                          P_ERR_PARAMS) THEN
          OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);
          RAISE PURCHASE_EXCEPTION;
        END IF;
        DBG('going to call Clpkss_Payment.Fn_Save_Payment-->' ||
            L_LIQD_AMT);

        CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;
        CLPKSS_CONTEXT.PR_CLEAR_ACCOUNT_OBJ;
        IF NOT CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_PAYMENT_OBJ.REC_LIQ.ACCOUNT_NUMBER,
                                                   L_PAYMENT_OBJ.REC_LIQ.BRANCH_CODE,
                                                   CLPKSS_CONTEXT.G_ACCOUNT_OBJ,
                                                   P_ERR_CODES,
                                                   P_ERR_PARAMS) THEN
          DBG('Clpkss_Object.Fn_Create_Acct_Object failed with :-( ' ||
              P_ERR_CODES || ':' || P_ERR_PARAMS);
          OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);
          ROLLBACK TO START_LOAN_LIQD;
          RAISE PURCHASE_EXCEPTION;
        END IF;

        CLPKS_CONTEXT.G_FUNCTION_ID := 'CLDPMNT';
        IF NOT CLPKS_PAYMENT.FN_SAVE_PAYMENT(L_PAYMENT_OBJ,
                                             L_ROWID,
                                             P_ERR_CODES,
                                             P_ERR_PARAMS) THEN
          DBG('payment failed with error code-->' || P_ERR_CODES);
          OVPKSS.PR_APPENDTBL(P_ERR_CODES, P_ERR_PARAMS);
          ROLLBACK TO START_LOAN_LIQD;
          RAISE PURCHASE_EXCEPTION;
        END IF;

        DBG('2222Now the overrides from clpks_payment count iss ..' ||
            OVPKSS.GL_TBLERROR.COUNT);
        DBG('2222l_temp_overrides count iss : ' || L_TEMP_OVERRIDES.COUNT);
        IF OVPKSS.GL_TBLERROR.COUNT = 0 THEN
          OVPKSS.GL_TBLERROR := L_TEMP_OVERRIDES;
        ELSIF L_TEMP_OVERRIDES.COUNT > 0 AND OVPKSS.GL_TBLERROR.COUNT > 0 THEN
          FOR I IN 1 .. L_TEMP_OVERRIDES.COUNT LOOP
            DBG('2222clpks_paymentError code for i ' || I || ' iss : ' || L_TEMP_OVERRIDES(I)
                .ERR_CODE);
            OVPKSS.PR_APPENDTBL(L_TEMP_OVERRIDES(I).ERR_CODE,
                                L_TEMP_OVERRIDES(I).PARAMS);
          END LOOP;
          DBG('2222After clpks_payment ovpks');
        END IF;

        DBG('finally updating the settled amount for the cl account');
        UPDATE BCTBS_PACK_CREDIT_DTLS
           SET SETTLED_AMT = L_AMT_TO_LIQ_EQ
         WHERE BCREFNO = CREC.BCREFNO
           AND CL_ACCOUNT = CREC.CL_ACCOUNT
           AND SEQ_NO = CREC.SEQ_NO
           AND EVENT_CODE = CREC.EVENT_CODE;
        IF SQL%ROWCOUNT = 0 THEN
          DBG('updation got failed');
          OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
          RAISE PURCHASE_EXCEPTION;
        END IF;
      END IF;

      IF NOT PROCEED_BOOL THEN
        DBG('at last m going out');
        EXIT;
      END IF;

      I := I + 1;

    END LOOP;
    IF NOT L_IS_PROCEED THEN
      DBG('seems to be no loan accounts are linked');
      IF P_EVENT IN ('BPUR', 'BDIS') OR
         (P_EVENT IN ('INIT') AND L_OPERATION IN ('DIS', 'PUR', 'NEG')) THEN
        DBG(' there is no loans are linked for INIT event');
        DBG('so passing all the purchase amount to amt_purchased for amt-->' ||
            L_PURCHASE_AMOUNT);
        DBG('effective lcy purchase rate is-->' || L_EFFC_LCY_PUR_XRATE);
        PR_INS_PURCHASE_LIQ(P_BCREFNO,

                            '',

                            P_ESN,
                            P_EVENT,
                            L_PURCHASE_AMOUNT,
                            L_PURCHASE_AMOUNT,
                            'BILLS PURCHASED',
                            'AMT_PURCHASED',
                            'N',
                            L_EFFC_LCY_PUR_XRATE);
      ELSIF P_EVENT IN ('LPUR', 'LDIS', 'LIQD') THEN
        DBG('now its in liqd and no loans are linked-->' || P_BCREFNO);
        FOR EACH_REC IN (SELECT *
                           FROM BCTBS_PURCHASE_LIQ_DTLS
                          WHERE BCREFNO = P_BCREFNO
                            AND SETTLED = 'N'
                            AND EVENT_SEQ_NO =
                                (SELECT MIN(EVENT_SEQ_NO)
                                   FROM BCTBS_PURCHASE_LIQ_DTLS
                                  WHERE BCREFNO = P_BCREFNO
                                    AND EVENT_SEQ_NO > 0)
                          ORDER BY ENTRY_SR_NO) LOOP

          DBG('first amount tag which needs to be settled-->' ||
              EACH_REC.AMOUNT_TAG);
          DBG(' each_rec.purchase_amt_tag_ccy-->' ||
              EACH_REC.PURCHASE_AMT_TAG_CCY);
          DBG(' each_rec.ex_rate-->' || EACH_REC.EX_RATE);
          DBG('each_rec.purchase_amt_lcy-->' || EACH_REC.PURCHASE_AMT_LCY);
          DBG('l_amt_purchased_bill_ccy-->' || L_AMT_PURCHASED_BILL_CCY);
          DBG('l_Bill_Or_Pur_Amt_Liqd-->' || L_BILL_OR_PUR_AMT_LIQD);
          IF L_BILL_OR_PUR_AMT_LIQD >= EACH_REC.PURCHASE_AMT_LCY THEN
            DBG('liquidation amount is der to settle');
            PR_INS_PURCHASE_LIQ(P_BCREFNO,

                                '',

                                P_ESN,
                                P_EVENT,
                                EACH_REC.PURCHASE_AMT_LCY,
                                EACH_REC.PURCHASE_AMT_LCY,
                                'BILLS PURCHASED',
                                'AMT_PURCHASED',
                                'Y',
                                EACH_REC.EX_RATE);

            DBG('each_rec.event_seq_no-->' || EACH_REC.EVENT_SEQ_NO);
            DBG('each_rec.event_code-->' || EACH_REC.EVENT_CODE);
            DBG('each_rec.entry_sr_no-->' || EACH_REC.ENTRY_SR_NO);
            DBG('each_rec.cl_acct_no-->' || EACH_REC.CL_ACCT_NO);
            UPDATE BCTBS_PURCHASE_LIQ_DTLS
               SET SETTLED = 'Y'
             WHERE BCREFNO = P_BCREFNO
               AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
               AND EVENT_SEQ_NO = EACH_REC.EVENT_SEQ_NO
               AND EVENT_CODE = EACH_REC.EVENT_CODE
               AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
            DBG('no of rows updated are-->' || SQL%ROWCOUNT);
            L_LIQD_UTILIZATION_AMT := L_LIQD_UTILIZATION_AMT +
                                      EACH_REC.PURCHASE_AMT_LCY;
          ELSIF L_BILL_OR_PUR_AMT_LIQD < EACH_REC.PURCHASE_AMT_LCY THEN
            DBG('liquidation amount decreased ');
            PR_INS_PURCHASE_LIQ(P_BCREFNO,

                                '',

                                P_ESN,
                                P_EVENT,
                                L_BILL_OR_PUR_AMT_LIQD,
                                L_BILL_OR_PUR_AMT_LIQD,
                                'BILLS PURCHASED',
                                'AMT_PURCHASED',
                                'Y',
                                EACH_REC.EX_RATE);

            DBG('each_rec.event_seq_no-->' || EACH_REC.EVENT_SEQ_NO);
            DBG('each_rec.event_code-->' || EACH_REC.EVENT_CODE);
            DBG('each_rec.entry_sr_no-->' || EACH_REC.ENTRY_SR_NO);
            DBG('each_rec.cl_acct_no-->' || EACH_REC.CL_ACCT_NO);
            UPDATE BCTBS_PURCHASE_LIQ_DTLS
               SET SETTLED          = 'N',
                   PURCHASE_AMT_LCY = EACH_REC.PURCHASE_AMT_LCY -
                                      L_BILL_OR_PUR_AMT_LIQD
             WHERE BCREFNO = P_BCREFNO
               AND CL_ACCT_NO = EACH_REC.CL_ACCT_NO
               AND EVENT_SEQ_NO = EACH_REC.EVENT_SEQ_NO
               AND EVENT_CODE = EACH_REC.EVENT_CODE
               AND ENTRY_SR_NO = EACH_REC.ENTRY_SR_NO;
            DBG('no of rows updated are-->' || SQL%ROWCOUNT);
            L_LIQD_UTILIZATION_AMT := L_LIQD_UTILIZATION_AMT +
                                      L_BILL_OR_PUR_AMT_LIQD;

            EXIT;
          END IF;
          DBG('the liquidation utilization amount is-->' ||
              L_LIQD_UTILIZATION_AMT);
          L_BILL_OR_PUR_AMT_LIQD   := L_BILL_OR_PUR_AMT_LIQD -
                                      EACH_REC.PURCHASE_AMT_LCY;
          L_AMT_PURCHASED_BILL_CCY := L_AMT_PURCHASED_BILL_CCY +
                                      EACH_REC.PURCHASE_AMT_LCY;

        END LOOP;
        DBG('now the total liquidation utilization amount is-->' ||
            L_LIQD_UTILIZATION_AMT);
        DBG('l_amt_purchased_bill_ccy-->' || L_AMT_PURCHASED_BILL_CCY);
        L_RESIDUAL_AMT := L_BILL_OR_PUR_AMT_LIQD -
                          NVL(L_AMT_PURCHASED_BILL_CCY, 0);
        DBG('l_residual_amt here is-->' || L_RESIDUAL_AMT);
        DBG('the actual liquidation amount is-->' || L_ACTUAL_LIQD_AMT);
        DBG('here the total used amount is-->' || L_LIQD_UTILIZATION_AMT);
        IF L_ACTUAL_LIQD_AMT > L_LIQD_UTILIZATION_AMT THEN
          L_RESIDUAL_AMT := L_ACTUAL_LIQD_AMT -
                            NVL(L_LIQD_UTILIZATION_AMT, 0);
          DBG('part of the liqd amount going for coll_liq_amt is-->' ||
              L_RESIDUAL_AMT);
          PR_INS_PURCHASE_LIQ(P_BCREFNO,

                              '',

                              P_ESN,
                              P_EVENT,
                              L_RESIDUAL_AMT,
                              L_RESIDUAL_AMT,
                              'BILLS PURCHASED',
                              'COLL_LIQ_AMT',
                              'Y',
                              L_EFFC_LCY_COL_EX_RATE);

        END IF;
      END IF;

    END IF;

    DBG('it seems to be success for packing credit');
    RETURN TRUE;
  EXCEPTION
    WHEN PURCHASE_EXCEPTION THEN
      DBG('inside the user defined exception purchase_exception');
      ROLLBACK TO START_LOAN_LIQD;
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('inside when others of fn_liqd_loan-->' || SQLERRM);
      OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
      ROLLBACK TO START_LOAN_LIQD;
      RETURN FALSE;
  END FN_LIQD_LOAN;

  FUNCTION FN_GET_EFF_PUR_LIQD_RATE(P_BCREFNO           IN VARCHAR2,
                                    P_LOAN_CCY          IN VARCHAR2,
                                    P_BCTB_CONTRACT_REC IN BCTBS_CONTRACT_MASTER%ROWTYPE,
                                    P_BC_PRODUCT        IN CFTMS_PRODUCT_ICCF.PRODUCT%TYPE,
                                    P_BILL_CCY          IN BCTB_CONTRACT_MASTER.BILL_CCY%TYPE,
                                    P_RATE              OUT NUMBER,
                                    P_ERR_CODE          IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_XRATE_TYPE          CYTMS_RATE_TYPE.CCY_RATE_TYPE%TYPE;
    L_RATE                CYTMS_RATES.MID_RATE%TYPE;
    L_RATE_FLAG           NUMBER;
    L_PROCEED             BOOLEAN := TRUE;
    L_FX_AMOUNT           NUMBER(22, 3);
    TB_FX_LINKAGE         TY_FX_LINKAGE;
    L_DIVISOR             NUMBER(35, 3) := 0;
    L_DIVIDEND            NUMBER(35, 3) := 0;
    L_TOTAL_HOLD_AMT      FXTBS_CONTRACT_MASTER.BOT_AMOUNT%TYPE := 0;
    L_LINKED_FX_AMT       FXTBS_CONTRACT_MASTER.BOT_AMOUNT%TYPE := 0;
    L_XRATE               BCTBS_CONTRACT_MASTER.EFFC_LCY_PUR_XRATE%TYPE;
    L_SETLD_AMT_IB_BLCCY  BCTBS_PACK_CRDT_SUMMARY.SETTLED_AMT%TYPE := 0;
    L_TOT_SETLD_AMT_BLCCY BCTBS_PACK_CRDT_SUMMARY.SETTLED_AMT%TYPE := 0;
    L_UNUSED_FX_AMT       FXTBS_CONTRACT_MASTER.BOT_AMOUNT%TYPE := 0;
    L_FX_REF_NO           TFTBS_FX_LINKAGE.FX_REF_NO%TYPE;
    L_EVENT_CODE          BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE;
    L_OPERATION           BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE;
    L_RESIDUAL_FX_AMT     FXTBS_CONTRACT_MASTER.BOT_AMOUNT%TYPE := 0;
    L_FX_COUNT            NUMBER;
    CURSOR CR_FX_LINKAGE IS
      SELECT *
        FROM TFTBS_FX_LINKAGE A
       WHERE TF_REF_NO = P_BCREFNO

         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM TFTBS_FX_LINKAGE
                              WHERE TF_REF_NO = P_BCREFNO)

         AND A.FX_REF_NO IN
             (SELECT B.CONTRACT_REF_NO
                FROM CSTBS_CONTRACT B
               WHERE B.CONTRACT_REF_NO = A.FX_REF_NO
                 AND B.CONTRACT_STATUS NOT IN ('L', 'V', 'S'));
  BEGIN
    DBG('inside the function fn_get_eff_pur_liqd_rate');
    DBG('p_Bctb_Contract_Rec.purchase_amt here is-->' ||
        P_BCTB_CONTRACT_REC.PURCHASE_AMT);
    DBG('p_Bctb_Contract_Rec.unlinked_fx_rate here is-->' ||
        P_BCTB_CONTRACT_REC.UNLINKED_FX_RATE);
    IF P_LOAN_CCY = GLOBAL.LCY THEN
      SELECT SUM(TF_AMOUNT)
        INTO L_LINKED_FX_AMT
        FROM TFTBS_FX_LINKAGE A
       WHERE A.TF_REF_NO = P_BCREFNO

         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM TFTBS_FX_LINKAGE
                              WHERE TF_REF_NO = P_BCREFNO)

         AND A.FX_REF_NO IN
             (SELECT B.CONTRACT_REF_NO
                FROM CSTBS_CONTRACT B
               WHERE B.CONTRACT_REF_NO = A.FX_REF_NO
                 AND B.CONTRACT_STATUS NOT IN ('L', 'V', 'S'));

      DBG('l_linked_fx_amt-->' || L_LINKED_FX_AMT);
      DBG('p_Bctb_Contract_Rec.purchase_amt-->' ||
          P_BCTB_CONTRACT_REC.PURCHASE_AMT);
      DBG('p_Bctb_Contract_Rec.purchase_amt-->' ||
          P_BCTB_CONTRACT_REC.PURCHASE_AMT);
      IF P_BCTB_CONTRACT_REC.EVENT_CODE IN ('BPUR', 'BDIS') OR
         (P_BCTB_CONTRACT_REC.EVENT_CODE IN ('INIT') AND
         P_BCTB_CONTRACT_REC.OPERATION IN ('DIS', 'PUR', 'NEG')) THEN
        IF L_LINKED_FX_AMT < P_BCTB_CONTRACT_REC.PURCHASE_AMT THEN
          IF P_BCTB_CONTRACT_REC.UNLINKED_FX_RATE IS NULL THEN
            DBG('I AM HERE');
            P_ERR_CODE := 'BC-PUR-014';
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
      DBG('p_Bctb_Contract_Rec.bill_amt_liqd-->' ||
          P_BCTB_CONTRACT_REC.BILL_AMT_LIQD);
      IF (P_BCTB_CONTRACT_REC.EVENT_CODE IN ('LPUR''LDIS', 'LIQD')) THEN
        IF P_BCTB_CONTRACT_REC.BILL_AMT_LIQD <> 0 THEN
          DBG('inside this');
          IF L_LINKED_FX_AMT < P_BCTB_CONTRACT_REC.BILL_AMT_LIQD THEN
            IF P_BCTB_CONTRACT_REC.UNLINKED_FX_RATE IS NULL THEN
              DBG('I AM HERE');
              P_ERR_CODE := 'BC-PUR-014';
              RETURN FALSE;
            END IF;
          END IF;

          IF P_BCTB_CONTRACT_REC.PURCHASE_AMT IS NOT NULL THEN
            DBG('inside this1');
            P_ERR_CODE := 'BC-PUR-029';
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;
    SELECT COUNT(*)
      INTO L_FX_COUNT
      FROM TFTBS_FX_LINKAGE
     WHERE TF_REF_NO = P_BCREFNO;
    DBG('l_fx_count-->' || L_FX_COUNT);
    L_EVENT_CODE := P_BCTB_CONTRACT_REC.EVENT_CODE;
    L_OPERATION  := P_BCTB_CONTRACT_REC.OPERATION;
    DBG('l_event_code is-->' || L_EVENT_CODE);
    DBG('l_operation is-->' || L_OPERATION);
    L_LINKED_FX_AMT := 0;
    IF L_FX_COUNT <> 0 THEN
      IF P_LOAN_CCY = GLOBAL.LCY THEN
        DBG('loan ccy is equla to global ccy-->' || 'l_event_code-->' ||
            L_EVENT_CODE || 'l_operation-->' || L_OPERATION);
        IF L_EVENT_CODE IN ('BPUR', 'BDIS') OR
           (L_EVENT_CODE IN ('INIT') AND
           L_OPERATION IN ('DIS', 'PUR', 'NEG')) THEN
          FOR EACH_LINKAGE IN CR_FX_LINKAGE LOOP
            DBG('each_linkage-->' || EACH_LINKAGE.FX_REF_NO);

            DBG('here the total linked amount is-->' ||
                EACH_LINKAGE.TF_AMOUNT);
            L_TOTAL_HOLD_AMT := L_TOTAL_HOLD_AMT + EACH_LINKAGE.TF_AMOUNT;
            DBG('l_total_hold_amt-->' || L_TOTAL_HOLD_AMT);
            DBG('p_Bctb_Contract_Rec.purchase_amt-->' ||
                P_BCTB_CONTRACT_REC.PURCHASE_AMT);
            IF L_TOTAL_HOLD_AMT >= P_BCTB_CONTRACT_REC.PURCHASE_AMT THEN
              DBG('here amount is increasing');
              L_PROCEED := FALSE;
            END IF;
            IF NOT L_PROCEED THEN

              DBG('its the end');
              L_LINKED_FX_AMT := (EACH_LINKAGE.TF_AMOUNT -
                                 (L_TOTAL_HOLD_AMT -
                                 P_BCTB_CONTRACT_REC.PURCHASE_AMT));

              L_UNUSED_FX_AMT := EACH_LINKAGE.TF_AMOUNT - L_LINKED_FX_AMT;
              DBG('unused fx amount is-->' || L_UNUSED_FX_AMT);
            ELSE

              L_LINKED_FX_AMT := EACH_LINKAGE.TF_AMOUNT;
              DBG('this is the general process l_linked_fx_amt-->' ||
                  L_LINKED_FX_AMT);
            END IF;
            DBG('now the fx amount we are utilizing is-->' ||
                L_LINKED_FX_AMT);

            IF L_UNUSED_FX_AMT <> 0 THEN
              BEGIN
                DBG('inserting here for -->' ||
                    P_BCTB_CONTRACT_REC.BCREFNO || '~' ||
                    EACH_LINKAGE.FX_REF_NO || L_UNUSED_FX_AMT);
                INSERT INTO BCTBS_PURCHASE_FX_DTLS
                  (BCREFNO, FX_REF_NO, UNUSED_FX_AMT)
                VALUES
                  (P_BCTB_CONTRACT_REC.BCREFNO,
                   EACH_LINKAGE.FX_REF_NO,
                   L_UNUSED_FX_AMT);
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  DBG('updating here for -->' ||
                      P_BCTB_CONTRACT_REC.BCREFNO || '~' ||
                      EACH_LINKAGE.FX_REF_NO || L_UNUSED_FX_AMT);
                  UPDATE BCTBS_PURCHASE_FX_DTLS
                     SET UNUSED_FX_AMT = L_UNUSED_FX_AMT
                   WHERE BCREFNO = P_BCTB_CONTRACT_REC.BCREFNO
                     AND FX_REF_NO = EACH_LINKAGE.FX_REF_NO;
                WHEN OTHERS THEN
                  DBG('inside when others of insert into Bctbs_purchase_fx_dtls-->' ||
                      SQLERRM);
                  P_ERR_CODE := 'BC-PUR-015';
                  RETURN FALSE;
              END;
            END IF;
            DBG('each_linkage.tf_rate-->' || EACH_LINKAGE.TF_RATE);
            DBG('previously the l_dividend is -->' || L_DIVIDEND);
            DBG('previously the l_linked_fx_amt is -->' || L_LINKED_FX_AMT);
            L_DIVIDEND := L_DIVIDEND +
                          ((L_LINKED_FX_AMT) * (EACH_LINKAGE.TF_RATE));
            L_DIVISOR  := L_DIVISOR + L_LINKED_FX_AMT;
            DBG('l_dividend-->' || L_DIVIDEND);
            DBG('l_divisor-->' || L_DIVISOR);
            IF NOT L_PROCEED THEN
              EXIT;
            END IF;
            EXIT WHEN CR_FX_LINKAGE%NOTFOUND;
          END LOOP;
          DBG('finnaly the l_dividend we need is-->' || L_DIVIDEND);
          DBG('finnaly the l_divisor we need is-->' || L_DIVISOR);
          P_RATE := (L_DIVIDEND / L_DIVISOR);
          DBG('finnaly the rate we need is-->' || P_RATE);
        ELSIF L_EVENT_CODE IN ('LPUR', 'LDIS', 'LIQD') THEN
          DBG('now the event is-->' || L_EVENT_CODE);
          L_LINKED_FX_AMT := 0;

          FOR EACH_FX_LINKED IN (SELECT *
                                   FROM TFTBS_FX_LINKAGE A
                                  WHERE TF_REF_NO = P_BCREFNO

                                    AND EVENT_SEQ_NO =
                                        (SELECT MAX(EVENT_SEQ_NO)
                                           FROM TFTBS_FX_LINKAGE
                                          WHERE TF_REF_NO = P_BCREFNO)

                                    AND A.FX_REF_NO IN
                                        (SELECT B.CONTRACT_REF_NO
                                           FROM CSTBS_CONTRACT B
                                          WHERE B.CONTRACT_REF_NO =
                                                A.FX_REF_NO
                                            AND B.CONTRACT_STATUS NOT IN
                                                ('L', 'V', 'S'))) LOOP

            DBG('each_fx_linked.tf_amount linked amount is-->' ||
                EACH_FX_LINKED.TF_AMOUNT);
            L_LINKED_FX_AMT := EACH_FX_LINKED.TF_AMOUNT;

            DBG('now the total linked amount is-->' || L_LINKED_FX_AMT);
            DBG('previously l_total_hold_amt is-->' || L_TOTAL_HOLD_AMT);

            L_TOTAL_HOLD_AMT := L_TOTAL_HOLD_AMT + L_LINKED_FX_AMT;
            DBG('now the total hold amount is-->' || L_TOTAL_HOLD_AMT);
            DBG('here p_Bctb_Contract_Rec.bill_amt_liqd is-->' ||
                P_BCTB_CONTRACT_REC.BILL_AMT_LIQD);
            IF L_TOTAL_HOLD_AMT >= P_BCTB_CONTRACT_REC.BILL_AMT_LIQD THEN
              DBG('m making the proceed to false here ');
              L_PROCEED := FALSE;
            END IF;
            IF NOT L_PROCEED THEN
              L_LINKED_FX_AMT := (EACH_FX_LINKED.TF_AMOUNT -
                                 (L_TOTAL_HOLD_AMT -
                                 P_BCTB_CONTRACT_REC.BILL_AMT_LIQD));
              DBG('the last linked fx account is-->' ||
                  EACH_FX_LINKED.FX_REF_NO);
              DBG('the total fx amount  is-->' || L_LINKED_FX_AMT);
            END IF;
            L_UNUSED_FX_AMT := EACH_FX_LINKED.TF_AMOUNT - L_LINKED_FX_AMT;
            DBG('here the unused amount is-->' || L_UNUSED_FX_AMT);
            BEGIN
              DBG('inserting here for liqd -->' ||
                  P_BCTB_CONTRACT_REC.BCREFNO || '~' ||
                  EACH_FX_LINKED.FX_REF_NO || L_UNUSED_FX_AMT);
              INSERT INTO BCTBS_PURCHASE_FX_DTLS
                (BCREFNO, FX_REF_NO, UNUSED_FX_AMT)
              VALUES
                (P_BCTB_CONTRACT_REC.BCREFNO,
                 EACH_FX_LINKED.FX_REF_NO,
                 L_UNUSED_FX_AMT);
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                DBG('updating here for liqd -->' ||
                    P_BCTB_CONTRACT_REC.BCREFNO || '~' ||
                    EACH_FX_LINKED.FX_REF_NO || '~' || L_UNUSED_FX_AMT);
                UPDATE BCTBS_PURCHASE_FX_DTLS
                   SET UNUSED_FX_AMT = L_UNUSED_FX_AMT
                 WHERE BCREFNO = P_BCTB_CONTRACT_REC.BCREFNO
                   AND FX_REF_NO = EACH_FX_LINKED.FX_REF_NO;
              WHEN OTHERS THEN
                DBG('inisde when others here-->' || SQLERRM);
                OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
                RETURN FALSE;
            END;
            L_DIVIDEND := L_DIVIDEND +
                          ((L_LINKED_FX_AMT) * (EACH_FX_LINKED.TF_RATE));
            L_DIVISOR  := L_DIVISOR + L_LINKED_FX_AMT;
            DBG('in liqd l_dividend is-->' || L_DIVIDEND);
            DBG('in liqd l_divisor is-->' || L_DIVISOR);
            IF NOT L_PROCEED THEN
              DBG('now m exiting');
              EXIT;
            END IF;
          END LOOP;

          P_RATE := (L_DIVIDEND / L_DIVISOR);
          DBG('rate calculated is-->' || P_RATE);
        END IF;

      ELSE
        DBG('loan currency is not in global.lcy');

        IF P_BCTB_CONTRACT_REC.UNLINKED_FX_RATE IS NOT NULL THEN
          P_ERR_CODE := 'BC-PUR-040';
          RETURN FALSE;
        END IF;
        P_RATE := NULL;
      END IF;

      DBG('p_Bctb_Contract_Rec.unlinked_fx_rate is-->' ||
          P_BCTB_CONTRACT_REC.UNLINKED_FX_RATE);
      IF P_BCTB_CONTRACT_REC.UNLINKED_FX_RATE IS NOT NULL THEN
        UPDATE BCTBS_CONTRACT_MASTER
           SET UNLINKED_FX_RATE = P_BCTB_CONTRACT_REC.UNLINKED_FX_RATE
         WHERE BCREFNO = P_BCREFNO
           AND EVENT_SEQ_NO =
               (SELECT EVENT_SEQ_NO
                  FROM BCTBS_CONTRACT_MASTER
                 WHERE BCREFNO = P_BCREFNO
                   AND VERSION_NO =
                       (SELECT MAX(VERSION_NO)
                          FROM BCTBS_CONTRACT_MASTER
                         WHERE BCREFNO = P_BCREFNO));
        DBG('no of rows updated for unlinked fx rate is-->' ||
            SQL%ROWCOUNT);
      END IF;

    ELSE
      DBG('no fx are linked to the contract');
      P_RATE := NULL;
    END IF;
    DBG('before returning true from fn_get_eff_pur_liqd_rate ');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('inside when others of fn_get_eff_pur_liqd_rate -->' || SQLERRM);
      P_ERR_CODE := 'BC-PUR-015';
      RETURN FALSE;
  END FN_GET_EFF_PUR_LIQD_RATE;

  FUNCTION FN_GET_DIS_COLL_LIQD(P_REC          IN BCTBS_CONTRACT_MULTITNR%ROWTYPE,
                                P_LIQ_DIS_AMT  OUT NUMBER,
                                P_LIQ_COLL_AMT OUT NUMBER,
                                P_ERR_CODE     IN OUT VARCHAR2,
                                P_ERR_PARAMS   IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_SPLIT_DIS_PENDING          NUMBER := 0;
    L_SPLIT_COLL_LIQD            NUMBER := 0;
    L_COLL_PORTION               NUMBER := 0;
    L_PREV_COLLSPLIT_LIQD_AMOUNT BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
  BEGIN
    DBG('l_split_dis_pending ' || L_SPLIT_DIS_PENDING);
    DBG('l_split_coll_liqd ' || L_SPLIT_COLL_LIQD);
    DBG('l_coll_portion ' || L_COLL_PORTION);
    DBG('liquidated_amount ' || P_REC.LIQUIDATED_AMOUNT);
    DBG('liquidation_amount ' || P_REC.LIQUIDATION_AMOUNT);
    DBG('discounted_amount ' || P_REC.DISCOUNTED_AMOUNT);
    BEGIN
      SELECT NVL(LIQUIDATED_AMOUNT, 0)
        INTO L_PREV_COLLSPLIT_LIQD_AMOUNT
        FROM BCTBS_CONTRACT_MULTITNR
       WHERE BCREFNO = P_REC.BCREFNO
         AND SERIAL_NUMBER = P_REC.SERIAL_NUMBER
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM BCTBS_CONTRACT_MULTITNR
               WHERE BCREFNO = P_REC.BCREFNO
                 AND SERIAL_NUMBER = P_REC.SERIAL_NUMBER

                 AND EVENT_SEQ_NO <
                     (SELECT MAX(EVENT_SEQ_NO)
                        FROM BCTBS_CONTRACT_MULTITNR
                       WHERE BCREFNO = P_REC.BCREFNO
                         AND SERIAL_NUMBER = P_REC.SERIAL_NUMBER)

              );
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_PREV_COLLSPLIT_LIQD_AMOUNT := 0;
    END;
    DBG('l_prev_collsplit_liqd_amount ' || L_PREV_COLLSPLIT_LIQD_AMOUNT);
    DBG('p_rec.liquidated_amount ' || P_REC.LIQUIDATED_AMOUNT);
    IF P_REC.LIQUIDATED_AMOUNT > L_PREV_COLLSPLIT_LIQD_AMOUNT THEN
      L_PREV_COLLSPLIT_LIQD_AMOUNT := L_PREV_COLLSPLIT_LIQD_AMOUNT;
    ELSE
      L_PREV_COLLSPLIT_LIQD_AMOUNT := P_REC.LIQUIDATED_AMOUNT;
    END IF;
    DBG('l_prev_collsplit_liqd_amount ' || L_PREV_COLLSPLIT_LIQD_AMOUNT);
    L_SPLIT_DIS_PENDING := NVL(L_PREV_COLLSPLIT_LIQD_AMOUNT, 0) -
                           NVL(P_REC.DISCOUNTED_AMOUNT, 0);
    L_SPLIT_COLL_LIQD   := NVL(P_REC.DISCOUNTED_AMOUNT, 0) -
                           (NVL(L_PREV_COLLSPLIT_LIQD_AMOUNT, 0) +
                            NVL(P_REC.LIQUIDATION_AMOUNT, 0));
    L_COLL_PORTION      := NVL(P_REC.BILL_AMOUNT, 0) -
                           NVL(P_REC.DISCOUNTED_AMOUNT, 0);
    DBG('l_split_dis_pending ' || L_SPLIT_DIS_PENDING);
    DBG('l_split_coll_liqd ' || L_SPLIT_COLL_LIQD);
    DBG('l_coll_portion ' || L_COLL_PORTION);
    P_LIQ_DIS_AMT  := 0;
    P_LIQ_COLL_AMT := 0;
    IF L_SPLIT_DIS_PENDING <= P_REC.LIQUIDATION_AMOUNT AND
       P_REC.LIQUIDATION_AMOUNT > 0 THEN
      IF L_SPLIT_COLL_LIQD > 0 THEN
        P_LIQ_DIS_AMT := ABS(L_SPLIT_DIS_PENDING) - L_SPLIT_COLL_LIQD;
      ELSE
        P_LIQ_DIS_AMT := ABS(L_SPLIT_DIS_PENDING);
      END IF;
    END IF;
    IF L_SPLIT_COLL_LIQD < 0 AND L_COLL_PORTION > 0 AND
       P_REC.LIQUIDATION_AMOUNT > 0 THEN
      IF ABS(L_SPLIT_COLL_LIQD) > P_REC.LIQUIDATION_AMOUNT THEN
        P_LIQ_COLL_AMT := P_REC.LIQUIDATION_AMOUNT;
      ELSE
        P_LIQ_COLL_AMT := ABS(L_SPLIT_COLL_LIQD);
      END IF;
    END IF;
    DBG('p_liq_dis_amt ' || P_LIQ_DIS_AMT);
    DBG('p_liq_coll_amt ' || P_LIQ_COLL_AMT);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('inside when others of fn_get_dis_coll_liqd-->' || SQLERRM);
      OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
      RETURN FALSE;
  END FN_GET_DIS_COLL_LIQD;

  FUNCTION FN_GET_TAG_AMOUNT(P_BCREFNO         IN VARCHAR2,
                             P_EVENT           IN VARCHAR2,
                             P_ESN             IN NUMBER,
                             P_AMOUNT_TAG      IN VARCHAR2,
                             P_AMT_IN_BILL_CCY OUT NUMBER,
                             P_AMT_IN_LCY      OUT NUMBER,
                             P_ERR_CODE        IN OUT VARCHAR2,
                             P_ERR_PRM         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    TBL_PCK_CRDT           TY_PURCHASE;
    TBL_FX_LINKAGE         TY_FX_LINKAGE;
    I                      NUMBER := 1;
    J                      NUMBER := 1;
    L_XRATE_TYPE           NUMBER(14, 7);
    L_PURCHASE_AMT         BCTBS_CONTRACT_MASTER.PURCHASE_AMT%TYPE;
    L_UNLINKED_FXRATE      BCTBS_CONTRACT_MASTER.UNLINKED_FX_RATE%TYPE;
    L_EFF_COL_RATE         BCTBS_CONTRACT_MASTER.EFFC_LCY_COL_EX_RATE%TYPE;
    L_EFF_PUR_RATE         BCTBS_CONTRACT_MASTER.EFFC_LCY_PUR_XRATE%TYPE;
    L_PAID_IN_BILL_CCY     BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_PAID_IN_LCY          BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_PAID_IN_LN_CCY       BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_TOT_PAID_IN_BILL_CCY BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_TOT_LINKED           BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_PURCHASE_CCY         BCTBS_CONTRACT_MASTER.BILL_CCY%TYPE;
    L_TOTAL_FX_LINKED      NUMBER(22, 3) := 0;
    L_UNLINK_FX_PROCEED    BOOLEAN := FALSE;
    L_EFF_RATE_PROCEED     BOOLEAN := FALSE;
    L_NO_FX_LINKED         BOOLEAN := TRUE;
    L_CLCOUNTER            NUMBER;
    L_EXCH_RATE            NUMBER(14, 7);
    L_PAID                 NUMBER(22, 3);
    L_RATE                 NUMBER(14, 7);
    L_RATE_FLAG            NUMBER;
    L_COUNTER              NUMBER;
    L_PURC_AMT_IN_LCY      BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_AMT_PURCHASED_LCY    BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_OPERATION            BCTBS_CONTRACT_MASTER.OPERATION%TYPE;
    L_LINKED_CCY           VARCHAR2(3);
    L_COUNT                NUMBER;

    L_EX_RATE    BCTBS_PURCHASE_LIQ_DTLS.EX_RATE%TYPE;
    L_AMT_IN_LCY BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_CNT        NUMBER := 0;

    L_BCTB_CONTRACT_REC BCTB_CONTRACT_MASTER%ROWTYPE;

    L_BCCL_LINK_COUNT NUMBER := 0;

    L_AMT_LIQUIDATED_ALREADY NUMBER := 0;
    L_TOTAL_AMT_LIQD         NUMBER := 0;
    L_PREV_ESN               NUMBER := 0;
    L_PREV_BILL_DUE_AMT      BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_REM_PUR_AMT            BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;

    L_COLL_BCTB_CONTRACT_REC BCTB_CONTRACT_MASTER%ROWTYPE;

    L_PREV_COLLSPLIT_LIQD_AMOUNT BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_SPLIT_LIQD_AMT             BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_SPLIT_TOT_LIQD_AMT         BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_SPLIT_DISCOUNT_AMT         BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_SPLIT_COLL_PORTION         BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_SPLIT_DIS_PENDING_PORTION  BCTBS_CONTRACT_MASTER.BILL_DUE_AMT%TYPE := 0;
    L_PREV_COLLSPLIT_LIQD_ESN    BCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE;
    CURSOR C_MULTITNR(P_BCREFNO BCTBS_CONTRACT_MASTER.BCREFNO%TYPE) IS
      SELECT *
        FROM BCTBS_CONTRACT_MULTITNR
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                               FROM BCTBS_CONTRACT_MULTITNR
                              WHERE BCREFNO = P_BCREFNO);

    L_LIQ_DIS_AMT  NUMBER := 0;
    L_LIQ_COLL_AMT NUMBER := 0;
    
    --sampath starts
    L_PRODUCT_TYPE BCTMS_PRODUCT_MASTER.PRODUCT_TYPE%TYPE;
    L_RATEFLAG     NUMBER;
    L_CCY1         CFTBS_CONTRACT_INTEREST.CURRENCY%TYPE;
    L_CCY2         CFTBS_CONTRACT_INTEREST.CURRENCY%TYPE;
    GETRATE_FAILED EXCEPTION;
    
    --sampath ends

  BEGIN
    DBG('inside the function fn_get_tag_amount');
    DBG('p_bcrefno-->' || P_BCREFNO);
    DBG('p_event-->' || P_EVENT);
    DBG('p_esn-->' || P_ESN);
    DBG('p_amount_tag-->' || P_AMOUNT_TAG);
    IF P_AMOUNT_TAG NOT IN
       ('LOAN_LIQD_AMT', 'AMT_PURCHASED', 'COLL_LIQ_AMT') THEN
      DBG('m helpless for these amount tags');
      RETURN TRUE;
    END IF;

    BEGIN
      SELECT *
        INTO L_BCTB_CONTRACT_REC

        FROM BCTBS_CONTRACT_MASTER
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_SEQ_NO =
             (SELECT MAX(EVENT_SEQ_NO)
                FROM BCTBS_CONTRACT_MASTER
               WHERE BCREFNO = P_BCREFNO
                 AND PURCHASE_AMT IS NOT NULL);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN

        BEGIN
          SELECT *
            INTO L_BCTB_CONTRACT_REC
            FROM BCTBS_CONTRACT_MASTER
           WHERE BCREFNO = P_BCREFNO
             AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                                   FROM BCTBS_CONTRACT_MASTER
                                  WHERE BCREFNO = P_BCREFNO);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('PURCHASE PROCESSING IS NOT REQD');
            RETURN TRUE;
        END;

    END;

    IF P_EVENT <> 'BCOL' THEN

      BEGIN
        SELECT *
          INTO L_COLL_BCTB_CONTRACT_REC
          FROM BCTBS_CONTRACT_MASTER
         WHERE BCREFNO = P_BCREFNO
           AND EVENT_SEQ_NO = (SELECT MAX(EVENT_SEQ_NO)
                                 FROM BCTBS_CONTRACT_MASTER
                                WHERE BCREFNO = P_BCREFNO
                                  AND PURCHASE_AMT IS NULL);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No Data Found for Latest record before purchase');
      END;

    END IF;

    DBG('bill amt is ' || L_BCTB_CONTRACT_REC.BILL_AMT);
    DBG('due amt is ' || L_BCTB_CONTRACT_REC.BILL_DUE_AMT);
    DBG('purchase amt is ' || L_BCTB_CONTRACT_REC.PURCHASE_AMT);
    DBG('bill amt liqd ' || L_BCTB_CONTRACT_REC.BILL_AMT_LIQD);

    L_AMT_LIQUIDATED_ALREADY := (NVL(L_BCTB_CONTRACT_REC.BILL_AMT, 0) -
                                NVL(L_BCTB_CONTRACT_REC.BILL_DUE_AMT, 0)) -
                                (NVL(L_COLL_BCTB_CONTRACT_REC.BILL_AMT, 0) -
                                NVL(L_COLL_BCTB_CONTRACT_REC.BILL_DUE_AMT,
                                     0));

    L_TOTAL_AMT_LIQD := L_AMT_LIQUIDATED_ALREADY;

    DBG(' AMt liquiated alredy is ' || L_AMT_LIQUIDATED_ALREADY);
    SELECT NVL(MAX(EVENT_SEQ_NO), 0)
      INTO L_PREV_ESN
      FROM BCTBS_CONTRACT_MASTER
     WHERE BCREFNO = P_BCREFNO
       AND EVENT_SEQ_NO < (SELECT MAX(EVENT_SEQ_NO)
                             FROM BCTBS_CONTRACT_MASTER
                            WHERE BCREFNO = P_BCREFNO);
    DBG(' l_prev_esn ' || L_PREV_ESN);
    IF L_PREV_ESN > 0 THEN
      SELECT NVL(BILL_DUE_AMT, 0)
        INTO L_PREV_BILL_DUE_AMT
        FROM BCTBS_CONTRACT_MASTER
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_SEQ_NO = L_PREV_ESN;
    END IF;
    IF P_AMOUNT_TAG = 'AMT_PURCHASED' THEN

      SELECT COUNT(*)
        INTO L_BCCL_LINK_COUNT
        FROM BCTBS_PACK_CREDIT_DTLS
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_CODE = P_EVENT;
      IF L_BCCL_LINK_COUNT = 0 THEN

        IF SUBSTR(P_EVENT, 1, 1) <> 'L' THEN

          IF L_TOTAL_AMT_LIQD = 0 THEN

            P_AMT_IN_BILL_CCY := L_BCTB_CONTRACT_REC.PURCHASE_AMT;

          ELSIF L_TOTAL_AMT_LIQD >=
                NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0) THEN
            P_AMT_IN_BILL_CCY := 0;
          ELSIF NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0) > L_TOTAL_AMT_LIQD THEN
            P_AMT_IN_BILL_CCY := NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0) -
                                 L_TOTAL_AMT_LIQD;
          END IF;

          DBG('p_amt_in_bill_ccy  ' || P_AMT_IN_BILL_CCY);

        ELSE

          L_TOTAL_AMT_LIQD := NVL(L_BCTB_CONTRACT_REC.BILL_AMT, 0) -
                              NVL(L_PREV_BILL_DUE_AMT, 0) -
                              (NVL(L_COLL_BCTB_CONTRACT_REC.BILL_AMT, 0) -
                               NVL(L_COLL_BCTB_CONTRACT_REC.BILL_DUE_AMT, 0));

          DBG('inside amt purchased l_total_amt_liqd ' || L_TOTAL_AMT_LIQD);

          IF L_BCTB_CONTRACT_REC.TENOR_CODE <> 'M' THEN
            IF L_TOTAL_AMT_LIQD = 0 AND
               NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0) <> 0 THEN

              DBG('Not a MultiTenor Contract');
              P_AMT_IN_BILL_CCY := LEAST(L_BCTB_CONTRACT_REC.PURCHASE_AMT,
                                         L_BCTB_CONTRACT_REC.BILL_AMT_LIQD);
            ELSIF L_TOTAL_AMT_LIQD >=
                  NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0) THEN
              P_AMT_IN_BILL_CCY := 0;
            ELSIF NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0) >
                  L_TOTAL_AMT_LIQD THEN
              L_REM_PUR_AMT := NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0) -
                               L_TOTAL_AMT_LIQD;
              DBG('l_rem_pur_amt  ' || L_REM_PUR_AMT);
              P_AMT_IN_BILL_CCY := LEAST(L_REM_PUR_AMT,
                                         NVL(L_BCTB_CONTRACT_REC.BILL_AMT_LIQD,
                                             0));
            END IF;
            DBG('p_amt_in_bill_ccy  ' || P_AMT_IN_BILL_CCY);

          ELSE
            DBG('MultiTenor Contract');
            P_AMT_IN_BILL_CCY := 0;
            FOR EACH_REC IN C_MULTITNR(L_BCTB_CONTRACT_REC.BCREFNO) LOOP
              DBG('each_rec.serial_number: ' || EACH_REC.SERIAL_NUMBER);
              DBG('each_rec.event_seq_no: ' || EACH_REC.EVENT_SEQ_NO);
              DBG('each_rec.liquidation_amount ::' ||
                  EACH_REC.LIQUIDATION_AMOUNT);
              DBG('each_rec.liquidated_amount ::' ||
                  EACH_REC.LIQUIDATED_AMOUNT);
              DBG('MultiTenor Contract');
              L_SPLIT_LIQD_AMT     := NVL(EACH_REC.LIQUIDATION_AMOUNT, 0);
              L_SPLIT_TOT_LIQD_AMT := NVL(EACH_REC.LIQUIDATED_AMOUNT, 0) -
                                      L_SPLIT_LIQD_AMT;
              L_SPLIT_DISCOUNT_AMT := NVL(EACH_REC.DISCOUNTED_AMOUNT, 0);
              BEGIN
                SELECT NVL(LIQUIDATED_AMOUNT, 0)
                  INTO L_PREV_COLLSPLIT_LIQD_AMOUNT
                  FROM BCTBS_CONTRACT_MULTITNR
                 WHERE BCREFNO = L_BCTB_CONTRACT_REC.BCREFNO
                   AND SERIAL_NUMBER = EACH_REC.SERIAL_NUMBER
                   AND EVENT_SEQ_NO =
                       (SELECT MAX(EVENT_SEQ_NO)
                          FROM BCTBS_CONTRACT_MULTITNR
                         WHERE BCREFNO = L_BCTB_CONTRACT_REC.BCREFNO
                           AND SERIAL_NUMBER = EACH_REC.SERIAL_NUMBER
                           AND NVL(DISCOUNTED_AMOUNT, 0) = 0);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  L_PREV_COLLSPLIT_LIQD_AMOUNT := 0;
              END;
              DBG('l_prev_collsplit_liqd_amount ::' ||
                  L_PREV_COLLSPLIT_LIQD_AMOUNT);

              IF L_SPLIT_DISCOUNT_AMT > 0 AND L_SPLIT_LIQD_AMT > 0 AND
                 (L_SPLIT_TOT_LIQD_AMT - L_PREV_COLLSPLIT_LIQD_AMOUNT) <
                 L_SPLIT_DISCOUNT_AMT THEN
                P_AMT_IN_BILL_CCY := P_AMT_IN_BILL_CCY +
                                     LEAST(L_SPLIT_LIQD_AMT,
                                           (L_SPLIT_DISCOUNT_AMT -
                                           (L_SPLIT_TOT_LIQD_AMT -
                                           L_PREV_COLLSPLIT_LIQD_AMOUNT)));
                DBG('p_amt_in_bill_ccy ::' || P_AMT_IN_BILL_CCY);
              END IF;
            END LOOP;
            DBG('p_amt_in_bill_ccy after loop::' || P_AMT_IN_BILL_CCY);
          END IF;

        END IF;

        IF L_BCTB_CONTRACT_REC.BILL_CCY <> GLOBAL.LCY AND
           P_AMT_IN_BILL_CCY IS NOT NULL THEN

          DBG('23616076 :: getting exchange rate from istbs contractis table....');
          BEGIN

            SELECT EX_RATE
              INTO L_EX_RATE
              FROM ISTBS_CONTRACTIS
             WHERE CONTRACT_REF_NO = P_BCREFNO
               AND AMOUNT_TAG = 'AMT_PURCHASEDEQ'
               AND EVENT_SEQ_NO = P_ESN;

          EXCEPTION
            WHEN OTHERS THEN
              DBG('23616076 :: Exception... :: ' || SQLERRM);
              L_EX_RATE := NULL;
          END;
          DBG('23616076 :: l_ex_rate :: ' || L_EX_RATE);
          
          --sampath starts
          DBG('GLOBAL.fn_get_module_id='||GLOBAL.fn_get_module_id);
          DBG('P_BCREFNO='||P_BCREFNO);
          
          IF GLOBAL.fn_get_module_id IN ('BC', 'IB') THEN
            BEGIN
              DEBUG.PR_DEBUG('BC', 'Selecting xrate_type from BC table');
              SELECT XRATE_TYPE, PRODUCT_TYPE
                INTO L_XRATE_TYPE, L_PRODUCT_TYPE
                FROM BCTMS_PRODUCT_MASTER
               WHERE PROD_CODE = SUBSTR(P_BCREFNO, 4, 4);
            
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DEBUG.PR_DEBUG('BC', 'BCTMS_PRODUCT_MASTER- ' || SQLERRM);
            END;
          
          /*ELSE
            BEGIN
              DEBUG.PR_DEBUG('BC', 'Selecting xrate_type from LC table');
            
              SELECT EXCHANGE_RATE_TYPE, PRODUCT_TYPE
                INTO L_XRATE_TYPE, L_PRODUCT_TYPE
                FROM LCTMS_PRODUCT_DEFINITION
               WHERE PRODUCT_CODE = SUBSTR(P_BCREFNO, 4, 4);
            
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DEBUG.PR_DEBUG('BC',
                               'LCTMS_PRODUCT_DEFINITION-' || SQLERRM);
                L_XRATE_TYPE := 'STANDARD';
            END;*/
          
          END IF;
        
          IF SUBSTR(P_BCREFNO, 4, 4) IN
             ('EBUA', 'EBUP', 'EDSC', 'EDUA', 'ELSR', 'ELUR', 'ASBL') THEN
          
            IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                     L_BCTB_CONTRACT_REC.BILL_CCY,
                                     GLOBAL.LCY,
                                     L_XRATE_TYPE,
                                     
                                     'B',
                                     L_EXCH_RATE,
                                     L_RATEFLAG,
                                     P_ERR_CODE) THEN
              RAISE GETRATE_FAILED;
            END IF;
          
          ELSIF SUBSTR(P_BCREFNO, 4, 4) IN
                ('IBSP', 'IBUA', 'IDSC', 'IDUA', 'ILSR', 'ILUR', 'SHGU') THEN
          
            IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                     L_BCTB_CONTRACT_REC.BILL_CCY,
                                     GLOBAL.LCY,
                                     L_XRATE_TYPE,
                                     
                                     'S',
                                     L_EXCH_RATE,
                                     L_RATEFLAG,
                                     P_ERR_CODE) THEN
              RAISE GETRATE_FAILED;
            END IF;
          END IF;
          
          DBG('L_EXCH_RATE L_EXCH_RATE=||L_EXCH_RATE');
          --sampath ends

          IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                        L_BCTB_CONTRACT_REC.BILL_CCY,
                                        GLOBAL.LCY,
                                        P_AMT_IN_BILL_CCY,
                                        'Y',
                                        P_AMT_IN_LCY,
                                        L_EXCH_RATE,--L_EX_RATE, --sampath commented,
                                        P_ERR_CODE) THEN
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, ' ');
            RETURN FALSE;
          END IF;
        ELSE
          P_AMT_IN_LCY := P_AMT_IN_BILL_CCY;
        END IF;
        DBG('  returing true from AMT_PURCHASED' || P_AMT_IN_BILL_CCY);
        RETURN TRUE;
      END IF;
    ELSIF P_AMOUNT_TAG = 'COLL_LIQ_AMT' THEN

      DBG('inside coll liq amt');
      SELECT COUNT(*)
        INTO L_BCCL_LINK_COUNT
        FROM BCTBS_PACK_CREDIT_DTLS
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_CODE = P_EVENT;

      IF L_BCCL_LINK_COUNT = 0 THEN
        IF L_PREV_BILL_DUE_AMT = 0 THEN
          L_TOTAL_AMT_LIQD := 0;
        ELSE

          L_TOTAL_AMT_LIQD := NVL(L_BCTB_CONTRACT_REC.BILL_AMT, 0) -
                              NVL(L_PREV_BILL_DUE_AMT, 0) -
                              (NVL(L_COLL_BCTB_CONTRACT_REC.BILL_AMT, 0) -
                               NVL(L_COLL_BCTB_CONTRACT_REC.BILL_DUE_AMT, 0));

        END IF;

        DBG('inside amt COLL_LIQ_AMT l_total_amt_liqd ' ||
            L_TOTAL_AMT_LIQD);

        DBG('l_total_amt_liqd >>' || L_TOTAL_AMT_LIQD);
        DBG('purchase_amt >>' || L_BCTB_CONTRACT_REC.PURCHASE_AMT);
        IF SUBSTR(P_EVENT, 1, 1) <> 'L' THEN
          P_AMT_IN_BILL_CCY := L_BCTB_CONTRACT_REC.BILL_AMT -
                               NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0);
        ELSE
          IF L_BCTB_CONTRACT_REC.TENOR_CODE <> 'M' THEN
            DBG('Not a MultiTenor Contract - Collection Portion');
            IF L_TOTAL_AMT_LIQD >= NVL(L_BCTB_CONTRACT_REC.PURCHASE_AMT, 0) THEN

              P_AMT_IN_BILL_CCY := L_BCTB_CONTRACT_REC.BILL_AMT_LIQD;
            ELSE
              P_AMT_IN_BILL_CCY := GREATEST(((L_BCTB_CONTRACT_REC.BILL_AMT_LIQD +
                                            L_TOTAL_AMT_LIQD) -
                                            L_BCTB_CONTRACT_REC.PURCHASE_AMT),
                                            0);
              DBG('p_amt_in_bill_ccy >>' || P_AMT_IN_BILL_CCY);
            END IF;

          ELSE
            DBG('MultiTenor Contract - Collection Portion');
            P_AMT_IN_BILL_CCY := 0;
            FOR EACH_REC IN C_MULTITNR(L_BCTB_CONTRACT_REC.BCREFNO) LOOP

              IF NOT FN_GET_DIS_COLL_LIQD(EACH_REC,
                                          L_LIQ_DIS_AMT,
                                          L_LIQ_COLL_AMT,
                                          P_ERR_CODE,
                                          P_ERR_PRM) THEN
                DEBUG.PR_DEBUG('BC',
                               'Function fn_get_dis_coll_liqd returned FALSE in BC');
                RETURN FALSE;
              END IF;
              DBG(' p_amt_in_bill_ccy: ' || P_AMT_IN_BILL_CCY);
              DBG(' l_liq_coll: ' || L_LIQ_COLL_AMT);
              P_AMT_IN_BILL_CCY := P_AMT_IN_BILL_CCY +
                                   NVL(L_LIQ_COLL_AMT, 0);
              DBG(' p_amt_in_bill_ccy: ' || P_AMT_IN_BILL_CCY);

            END LOOP;
            DBG('p_amt_in_bill_ccy after loop::' || P_AMT_IN_BILL_CCY);
          END IF;

        END IF;
        DBG('p_amt_in_bill_ccy  ' || P_AMT_IN_BILL_CCY);
        IF L_BCTB_CONTRACT_REC.BILL_CCY <> GLOBAL.LCY AND
           P_AMT_IN_BILL_CCY IS NOT NULL THEN
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                        L_BCTB_CONTRACT_REC.BILL_CCY,
                                        GLOBAL.LCY,
                                        P_AMT_IN_BILL_CCY,
                                        'Y',
                                        P_AMT_IN_LCY,
                                        L_EX_RATE,
                                        P_ERR_CODE) THEN
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, ' ');
            RETURN FALSE;
          END IF;
        ELSE
          P_AMT_IN_LCY := P_AMT_IN_BILL_CCY;
        END IF;
        DBG('  returing true from COLL_LIQ_AMT' || P_AMT_IN_BILL_CCY);
        RETURN TRUE;
      END IF;

    END IF;

    SELECT COUNT(*)
      INTO L_COUNT
      FROM BCTBS_PURCHASE_LIQ_DTLS
     WHERE BCREFNO = P_BCREFNO
       AND AMOUNT_TAG = P_AMOUNT_TAG
       AND EVENT_SEQ_NO > 0;
    DBG('total no of count is-->' || L_COUNT);
    IF P_AMOUNT_TAG = 'LOAN_LIQD_AMT' OR P_AMOUNT_TAG = 'AMT_PURCHASED' OR
       P_AMOUNT_TAG = 'COLL_LIQ_AMT' THEN
      SELECT SUM(NVL(PURCHASE_AMT_TAG_CCY, 0))
        INTO P_AMT_IN_BILL_CCY
        FROM BCTBS_PURCHASE_LIQ_DTLS
       WHERE BCREFNO = P_BCREFNO
         AND EVENT_CODE = P_EVENT
         AND EVENT_SEQ_NO = P_ESN
         AND AMOUNT_TAG = P_AMOUNT_TAG;

    END IF;

    IF P_AMOUNT_TAG IN ('AMT_PURCHASED', 'COLL_LIQ_AMT') THEN

      FOR EACH_REC IN (SELECT *
                         FROM BCTBS_PURCHASE_LIQ_DTLS
                        WHERE BCREFNO = P_BCREFNO
                          AND EVENT_CODE = P_EVENT
                          AND EVENT_SEQ_NO = P_ESN
                          AND AMOUNT_TAG = P_AMOUNT_TAG) LOOP
        L_CNT := L_CNT + 1;
        DBG('Loop Number:: ' || L_CNT);
        DBG('Amount Tag here is:: ' || P_AMOUNT_TAG);
        DBG('inisde the loop for local currency');
        DBG('the exchange rate here is-->' || EACH_REC.EX_RATE);
        DBG('the amount in bill ccy is-->' || EACH_REC.PURCHASE_AMT_LCY);

        L_EX_RATE := NVL(EACH_REC.EX_RATE, 1);
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,

                                      L_BCTB_CONTRACT_REC.BILL_CCY,

                                      GLOBAL.LCY,
                                      EACH_REC.PURCHASE_AMT_LCY,
                                      'Y',
                                      L_PURC_AMT_IN_LCY,
                                      L_EX_RATE,
                                      P_ERR_CODE) THEN
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, ' ');
          RETURN FALSE;
        END IF;
        DBG('amount in local lcy is-->' || L_PURC_AMT_IN_LCY);

        DBG('l_amt_in_lcy-->' || L_AMT_IN_LCY);
        L_AMT_IN_LCY := L_AMT_IN_LCY + L_PURC_AMT_IN_LCY;

      END LOOP;
    END IF;

    DBG('now the amount lcy is-->' || L_AMT_IN_LCY);
    P_AMT_IN_LCY := L_AMT_IN_LCY;

    DBG('p_amt_in_bill_ccy--> for amount tag ' || P_AMOUNT_TAG || '-->' ||
        P_AMT_IN_BILL_CCY);
    DBG('p_amt_in_lcy for amount tag' || '  ' || P_AMOUNT_TAG || '-->' ||
        P_AMT_IN_LCY);

    RETURN TRUE;
  EXCEPTION
     --sampath starts
    WHEN GETRATE_FAILED THEN
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'BC-AT001';
        P_ERR_PRM := L_CCY1 || '~' || L_CCY2 || '~';
      END IF;
      RETURN FALSE;
      --sampath ends
    WHEN OTHERS THEN
      DBG('inside when others of fn_get_tag_amount-->' || SQLERRM);
      OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
      RETURN FALSE;
  END FN_GET_TAG_AMOUNT;

  FUNCTION FN_DELETE_CLDPMNT(P_BCREFNO     IN BCTBS_CONTRACT_MASTER.BCREFNO%TYPE,
                             P_EVENT_CODE  IN BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE,
                             P_ERROR_CODE  IN OUT VARCHAR2,
                             P_ERROR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_BRANCH_CODE       CLTBS_ACCOUNT_MASTER.BRANCH_CODE%TYPE;
    L_ALT_AC_NO         CLTBS_ACCOUNT_MASTER.ALT_ACC_NO%TYPE;
    L_ESN               CLTBS_LIQ.EVENT_SEQ_NO%TYPE;
    P_CL_ACCOUNT_NUMBER CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE;
  BEGIN
    DBG('inside fn_delete_cldpmnt p_bcrefno-->' || P_BCREFNO ||
        'p_event_code-->' || P_EVENT_CODE);
    FOR EACH_REC IN (SELECT *
                       FROM BCTBS_PACK_CREDIT_DTLS
                      WHERE BCREFNO = P_BCREFNO
                        AND EVENT_CODE = P_EVENT_CODE) LOOP
      DBG('each_rec.cl_account-->' || EACH_REC.CL_ACCOUNT);
      L_BRANCH_CODE := SUBSTR(EACH_REC.CL_ACCOUNT, 1, 3);
      SELECT MAX(EVENT_SEQ_NO)
        INTO L_ESN
        FROM CLTBS_LIQ
       WHERE BRANCH_CODE = L_BRANCH_CODE
         AND ACCOUNT_NUMBER = EACH_REC.CL_ACCOUNT;
      DBG('esn is-->' || L_ESN);
      IF NOT CLPKSS_IFACE.FN_DELT_CLDPMNT(EACH_REC.CL_ACCOUNT,
                                          L_BRANCH_CODE,
                                          L_ALT_AC_NO,
                                          L_ESN,
                                          P_ERROR_CODE,
                                          P_ERROR_PARAM) THEN
        DBG('failed in call to clpkss_iface.fn_delt_cldpmnt');
        OVPKSS.PR_APPENDTBL(P_ERROR_CODE, P_ERROR_PARAM);
        RETURN FALSE;
      END IF;
      DBG('going to call clpkss_iface.fn_auth_CLDACCDT for authorisation of-->' ||
          EACH_REC.CL_ACCOUNT);
      CLPKSS_IFACE.G_ACC_AUTH_STATUS := TRUE;
      IF NOT CLPKSS_IFACE.FN_AUTH_CLDACCDT(EACH_REC.CL_ACCOUNT,
                                           L_BRANCH_CODE,
                                           L_ALT_AC_NO,
                                           P_ERROR_CODE,
                                           P_ERROR_PARAM) THEN
        DBG('clpkss_iface.fn_auth_CLDACCDT returning false-->' ||
            P_ERROR_CODE);
        OVPKSS.PR_APPENDTBL(P_ERROR_CODE, P_ERROR_PARAM);
        RETURN FALSE;
      END IF;

      UPDATE CLTBS_ACCOUNT_MASTER
         SET AUTH_STAT = 'A'
       WHERE BRANCH_CODE = L_BRANCH_CODE
         AND ACCOUNT_NUMBER = EACH_REC.CL_ACCOUNT;
    END LOOP;

    DELETE FROM BCTBS_PACK_CREDIT_DTLS WHERE BCREFNO = P_BCREFNO;
    DBG('no of rows deleted-->' || SQL%ROWCOUNT);

    DBG('cl deletion is success');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('inside when others during deletion of payment-->' || SQLERRM);
      OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
      RETURN FALSE;
  END FN_DELETE_CLDPMNT;

  FUNCTION FN_AUTH_CLDPMNT(P_BCREFNO     IN BCTBS_CONTRACT_MASTER.BCREFNO%TYPE,
                           P_EVENT_CODE  IN BCTBS_CONTRACT_MASTER.EVENT_CODE%TYPE,
                           P_ERROR_CODE  IN OUT VARCHAR2,
                           P_ERROR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_BRANCH_CODE       CLTBS_ACCOUNT_MASTER.BRANCH_CODE%TYPE;
    L_ALT_AC_NO         CLTBS_ACCOUNT_MASTER.ALT_ACC_NO%TYPE;
    L_ESN               CLTBS_LIQ.EVENT_SEQ_NO%TYPE;
    V_TB_PACK_CRDT_DTLS TB_PACK_CRDT_DTLS;
    L_ERRIDX            PLS_INTEGER;
    L_COUNTER           NUMBER;
    L_EVENT_SEQ_NO      BCTBS_CONTRACT_MASTER.EVENT_SEQ_NO%TYPE;
    L_SEQ_NO            BCTBS_PACK_CRDT_SUMMARY.SEQ_NO%TYPE;
    I                   NUMBER;
    L_SEQ_COUNT         NUMBER := 0;
  BEGIN
    DBG('inside the function fn_auth_CLDPMNT');
    L_COUNTER := 1;
    SELECT MAX(EVENT_SEQ_NO)
      INTO L_EVENT_SEQ_NO
      FROM BCTBS_CONTRACT_MASTER
     WHERE BCREFNO = P_BCREFNO;

    DBG('here l_event_seq_no is-->' || L_EVENT_SEQ_NO);

    BEGIN
      SELECT MAX(SEQ_NO)
        INTO L_SEQ_NO
        FROM BCTBS_PACK_CRDT_SUMMARY
       WHERE BCREFNO = P_BCREFNO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No records in pack credit Summary table');
        L_SEQ_NO := 0;

    END;

    DBG('Max Sequence Number here--> ' || L_SEQ_NO);

    IF L_SEQ_NO IS NULL THEN
      L_SEQ_NO := 0;

    END IF;

    I := 1;
    DBG('l_seq_no coming here is-->' || L_SEQ_NO);
    FOR EACH_REC IN (SELECT *
                       FROM BCTBS_PACK_CREDIT_DTLS
                      WHERE BCREFNO = P_BCREFNO
                        AND EVENT_CODE = P_EVENT_CODE) LOOP
      L_BRANCH_CODE := SUBSTR(EACH_REC.CL_ACCOUNT, 1, 3);
      DBG('Found CL Account here as :: ' || EACH_REC.CL_ACCOUNT ||
          'l_counter-->' || L_COUNTER || 'each_rec.seq_no-->' ||
          EACH_REC.SEQ_NO);
      SELECT MAX(EVENT_SEQ_NO)
        INTO L_ESN
        FROM CLTBS_LIQ
       WHERE BRANCH_CODE = L_BRANCH_CODE
         AND ACCOUNT_NUMBER = EACH_REC.CL_ACCOUNT;
      DBG('CL Account here:: ' || EACH_REC.CL_ACCOUNT || '-->' || L_ESN);
      IF NOT CLPKSS_IFACE.FN_AUTH_CLDPMNT(EACH_REC.CL_ACCOUNT,
                                          L_BRANCH_CODE,
                                          L_ALT_AC_NO,
                                          L_ESN,
                                          P_ERROR_CODE,
                                          P_ERROR_PARAM) THEN
        DBG('failed in call to clpkss_iface.fn_auth_CLDPMNT');
        OVPKSS.PR_APPENDTBL(P_ERROR_CODE, P_ERROR_PARAM);
        RETURN FALSE;
      END IF;
      DBG('after authorizing the cl-->' || EACH_REC.CL_ACCOUNT);

      DBG('BC Reference Number--> ' || EACH_REC.BCREFNO);

      DBG('Sequence Number here--> ' || EACH_REC.SEQ_NO);
      DBG('the max seq number is-->' || L_SEQ_NO);
      DBG('value of i is-->' || I);
      L_SEQ_COUNT := L_SEQ_NO + I;
      DBG(' Now l_seq_count--> ' || L_SEQ_COUNT);

      V_TB_PACK_CRDT_DTLS(L_COUNTER).BCREFNO := EACH_REC.BCREFNO;
      V_TB_PACK_CRDT_DTLS(L_COUNTER).CL_ACCOUNT := EACH_REC.CL_ACCOUNT;

      V_TB_PACK_CRDT_DTLS(L_COUNTER).SEQ_NO := L_SEQ_COUNT;
      V_TB_PACK_CRDT_DTLS(L_COUNTER).LINKED_CCY := EACH_REC.LINKED_CCY;
      V_TB_PACK_CRDT_DTLS(L_COUNTER).OUTSTANDING_AMT := EACH_REC.OUTSTANDING_AMT;
      V_TB_PACK_CRDT_DTLS(L_COUNTER).EVENT_CODE := P_EVENT_CODE;
      V_TB_PACK_CRDT_DTLS(L_COUNTER).SETTLED_AMT := EACH_REC.SETTLED_AMT;
      V_TB_PACK_CRDT_DTLS(L_COUNTER).EVENT_SEQ_NO := L_EVENT_SEQ_NO;

      I         := I + 1;
      L_COUNTER := L_COUNTER + 1;
    END LOOP;
    BEGIN
      FORALL I IN V_TB_PACK_CRDT_DTLS.FIRST .. V_TB_PACK_CRDT_DTLS.LAST SAVE
                                               EXCEPTIONS
        INSERT INTO BCTBS_PACK_CRDT_SUMMARY VALUES V_TB_PACK_CRDT_DTLS (I);
      DBG('bcpkss_purchase no of rows inserted is-->' || SQL%ROWCOUNT);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In WHEN OTHERS, while Insert into Bctbs_pack_crdt_summary SQL%BULK_EXCEPTIONS.COUNT:' ||
            SQL%BULK_EXCEPTIONS.COUNT);
        FOR ERRIDX IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
          L_ERRIDX := SQL%BULK_EXCEPTIONS(ERRIDX).ERROR_INDEX;
          CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                       NULL,
                                       GLOBAL.APPLICATION_DATE,
                                       'MLIQ',
                                       'Bulk Operation (Inserting cltb_calc_dates) Failed ' ||
                                       ' Error:' ||
                                       SUBSTR(SQLERRM(-SQL%BULK_EXCEPTIONS(ERRIDX)
                                                      .ERROR_CODE),
                                              1,
                                              1500));
        END LOOP;

        OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
        RETURN FALSE;
    END;
    DELETE FROM BCTBS_PACK_CREDIT_DTLS WHERE BCREFNO = P_BCREFNO;
    DBG('no of rows deleted from bctbs_pack_credit_dtls is-->' ||
        SQL%ROWCOUNT);

    DBG('at last authorisation process got success');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('inisde when others of fn_auth_cldpmnt-->' || SQLERRM);
      OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
      RETURN FALSE;
  END FN_AUTH_CLDPMNT;

  PROCEDURE PR_INS_PURCHASE_LIQ(P_BCREFNO         IN VARCHAR2,
                                P_CL_ACCOUNT      IN VARCHAR2,
                                P_ESN             IN NUMBER,
                                P_EVENT_CODE      IN VARCHAR2,
                                P_PUR_AMT_TAG_CCY IN NUMBER,
                                P_PUR_AMT_LCY     IN NUMBER,
                                P_AMT_TAG         IN VARCHAR2,
                                P_ACCOUNTING_ROLE IN VARCHAR2,
                                P_SETTLED         IN VARCHAR2,
                                P_EX_RATE         IN NUMBER) IS
    L_ENTRY_SR_NO NUMBER := 0;
    P_ENTRY_SR_NO NUMBER := 0;
  BEGIN
    DBG('inside the procedure pr_ins_purchase_liq');
    DBG('p_bcrefno-->' || P_BCREFNO);
    DBG('p_esn-->' || P_ESN);
    DBG('p_cl_account-->' || P_CL_ACCOUNT);
    DBG('p_event_code-->' || P_EVENT_CODE);
    DBG('p_pur_amt_tag_ccy-->' || P_PUR_AMT_TAG_CCY);
    DBG('p_pur_amt_lcy-->' || P_PUR_AMT_LCY);
    DBG('p_accounting_role-->' || P_ACCOUNTING_ROLE);
    DBG('p_amt_tag-->' || P_AMT_TAG);
    DBG('p_settled-->' || P_SETTLED);
    BEGIN
      SELECT NVL(MAX(ENTRY_SR_NO), 0)
        INTO L_ENTRY_SR_NO
        FROM BCTBS_PURCHASE_LIQ_DTLS
       WHERE BCREFNO = P_BCREFNO;
      P_ENTRY_SR_NO := L_ENTRY_SR_NO + 1;
      DBG('p_entry_sr_no-->' || P_ENTRY_SR_NO);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('inside when others of pr_ins_purchase_li111-->' || SQLERRM);
        OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
        RETURN;
    END;
    INSERT INTO BCTBS_PURCHASE_LIQ_DTLS

      (BCREFNO,
       CL_ACCT_NO,
       EVENT_SEQ_NO,
       EVENT_CODE,
       PURCHASE_AMT_TAG_CCY,
       PURCHASE_AMT_LCY,
       ACCOUNTING_ROLE,
       AMOUNT_TAG,
       SETTLED,
       EX_RATE,
       ENTRY_SR_NO)
    VALUES
      (P_BCREFNO,
       P_CL_ACCOUNT,
       P_ESN,
       P_EVENT_CODE,
       P_PUR_AMT_TAG_CCY,
       P_PUR_AMT_LCY,
       P_AMT_TAG,
       P_ACCOUNTING_ROLE,
       P_SETTLED,
       P_EX_RATE,
       P_ENTRY_SR_NO);
    DBG('the total no of rows inserted is-->' || SQL%ROWCOUNT);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('inside when others of pr_ins_purchase_liq-->' || SQLERRM);
      OVPKSS.PR_APPENDTBL('BC-PUR-015', ' ');
      RETURN;
  END PR_INS_PURCHASE_LIQ;

END BCPKS_PURCHASE;
/