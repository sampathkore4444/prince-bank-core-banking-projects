CREATE OR REPLACE PACKAGE BODY GWPKS_QUERYRETAILTLR_CUSTOM AS
  /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Change Tag        : PRF_CUSTOM_05_03072018
   **    Changes By        : Aniket
   **    Changes on        : 03-JUL-2018
   **    Description       : Changes related to teller advices specific to Prince Finance
  
         Modified By           : Kore Sampath Kumar
         Modified On           : 12-July-2019
         Modified Reason       : LOCH transaction and offset Amount to display with negative sign for reversal Changes
         Search String         : LOCH transaction and offset Amount to display with negative sign for reversal Changes
  
        Modified By         : Kore Sampath Kumar
        Modified Description : Prince Bank AML Changes
  
        Changed By         : Kore Sampath Kumar
        Change Description : Prince Bank Credit Card Payment by Cash GL Changes
  
        Modified By         : Kore Sampath Kumar
        Modified Description : Cheque Withdrawal Reverse
        
       **    Changed By        : Kore Sampath Kumar
       **    Changed on        : 15-July-2020
       **    Description       : Prince NBC RFT Changes
       **    Change Tag        : Prince NBC RFT Changes
  
  
  
    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'gwpks_queryretailtlr_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('RT', L_MSG);
  END DBG;

  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN
    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('IF',
                     '[ERROR] ' || 'gwpks_queryretailtlr_custom :' || P_DBG);
    ELSE
      DEBUG.PR_DEBUG('IF',
                     '[DEBUG] ' || 'gwpks_queryretailtlr_custom :' || P_DBG);
    END IF;
  END DBG;

  --participant no changes starts
  PROCEDURE PR_INSERT_PARTICIPANT_INFO(P_FUNC_ID   IN VARCHAR2,
                                       P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS
  
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    DBG('P_FUNC_ID=' || P_FUNC_ID);
    DBG('INSIDE PR_INSERT_PARTICIPANT_INFO STARTS');
  
    IF P_FUNC_ID = '1001' THEN
    
      INSERT INTO IFTB_AML_PARTICIPANT_INFO_1001
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34);
    
    END IF;
  
    IF P_FUNC_ID = '1401' THEN
    
      INSERT INTO IFTB_AML_PARTICIPANT_INFO_1401
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35);
    
    END IF;
  
    IF P_FUNC_ID = '1013' THEN
    
      INSERT INTO IFTB_AML_PARTICIPANT_INFO_1013
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD36,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD37);
    
    END IF;
  
    IF P_FUNC_ID = '8203' THEN
    
      INSERT INTO IFTB_AML_PARTICIPANT_INFO_8203
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35,
         P_TY_RTUPLD.ty_upld_rtl_teller.REL_CUSTOMER,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD1,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD6);
    
    END IF;
  
    IF P_FUNC_ID = '8004' THEN
    
      DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD1=' ||
          P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD1);
      DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD6=' ||
          P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD6);
    
      INSERT INTO IFTB_AML_PARTICIPANT_INFO_8004
      VALUES
        (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD35,
         P_TY_RTUPLD.ty_upld_rtl_teller.REL_CUSTOMER,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD1,
         P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD6);
    
    END IF;
  
    COMMIT;
    DBG('INSIDE PR_INSERT_PARTICIPANT_INFO ENDS');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR IN PR_INSERT_PARTICIPANT_INFO');
      DBG('ERROR CODE IN PR_INSERT_PARTICIPANT_INFO=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_PARTICIPANT_INFO=' || SQLERRM);
  END PR_INSERT_PARTICIPANT_INFO;
  --participant no changes ends

  --Cheque Withdrawal Reverse Starts
  PROCEDURE PR_INSERT_CHEQUE_WITHDRAWAL(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS
  
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    DBG('P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT=' ||
        P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT);
  
    INSERT INTO IFTB_CHEQUE_WITHDRAWAL_CUSTOM
    VALUES
      (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
       P_TY_RTUPLD.ty_upld_rtl_teller.XREF,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD31,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD32,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD33,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD34,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD36,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD37,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD40 --AML Participant Enhancements Changes
       );
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR IN PR_INSERT_CHEQUE_WITHDRAWAL');
      DBG('ERROR CODE IN PR_INSERT_CHEQUE_WITHDRAWAL=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_CHEQUE_WITHDRAWAL=' || SQLERRM);
  END PR_INSERT_CHEQUE_WITHDRAWAL;
  --Cheque Withdrawal Reverse Ends

  --Prince Bank Credit Card Payment by Cash GL Changes Starts
  PROCEDURE PR_INSERT_CASH_BY_GL(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS
  
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    DBG('P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT=' ||
        P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT);
  
    INSERT INTO IFTB_CREDIT_CARD_PYMNT_BY_CASH
    VALUES
      (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
       P_TY_RTUPLD.ty_upld_rtl_teller.TXN_ACC,
       P_TY_RTUPLD.ty_upld_rtl_teller.TXN_CCY,
       P_TY_RTUPLD.ty_upld_rtl_teller.OFS_CCY,
       P_TY_RTUPLD.ty_upld_rtl_teller.OFS_AMOUNT,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD9,
       P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT,
       P_TY_RTUPLD.ty_upld_rtl_teller.NARRATIVE,
       'O',
       'A',
       1,
       GWPKS_UTIL.G_MAKERID,
       GLOBAL.application_date,
       P_TY_RTUPLD.ty_upld_rtl_teller.CHECKER_ID,
       GLOBAL.APPLICATION_DATE,
       'Y',
       P_TY_RTUPLD.ty_upld_rtl_teller.EXCH_RATE,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD4,
       GLOBAL.application_date,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD7,
       SUBSTR(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3, 1, 4) ||
       'XXXXXXXX' ||
       SUBSTR(P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD3, 13),
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD5);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR IN PR_INSERT_CASH_BY_GL');
      DBG('ERROR CODE IN PR_INSERT_CASH_BY_GL=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_CASH_BY_GL=' || SQLERRM);
  END PR_INSERT_CASH_BY_GL;

  --Prince NBC RFT changes Starts
  PROCEDURE PR_INSERT_RFT_PASSCODE_INFO(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS
  
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    DBG('INSIDE PR_INSERT_RFT_PASSCODE_INFO STARTS');
  
    INSERT INTO IFTB_RFT_PASSCODE_INFO
    VALUES
      (P_TY_RTUPLD.ty_upld_rtl_teller.TRN_REF_NO,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD41,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD42,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD43,
       P_TY_RTUPLD.ty_cstbs_ui_columns.NUM_FIELD25,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD44,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD45,
       P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD46);
  
    COMMIT;
  
    DBG('INSIDE PR_INSERT_RFT_PASSCODE_INFO ENDS');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR IN PR_INSERT_RFT_PASSCODE_INFO');
      DBG('ERROR CODE IN PR_INSERT_RFT_PASSCODE_INFO=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_RFT_PASSCODE_INFO=' || SQLERRM);
  END PR_INSERT_RFT_PASSCODE_INFO;
  --Prince NBC RFT changes Ends

  FUNCTION FN_GET_SVXP_TEMPLATE RETURN CLOB IS
  
    L_CLOB CLOB;
  
  BEGIN
    DBG('START OF FN_GET_SVXP_TEMPLATE');
  
    L_CLOB := '<clearing xmlns="http://bpc.ru/sv/SVXP/clearing">
  <file_type>FLTP1700</file_type>
  <operation>
    <oper_type>OPTP0028</oper_type>
    <msg_type>MSGTPRES</msg_type>
    <sttl_type>STTT0000</sttl_type>
    <oper_date>$L_DATE</oper_date>
    <oper_amount>
      <amount_value>$L_AMOUNT</amount_value>
      <currency>$L_ISO_CCY_CODE</currency>
    </oper_amount>
    <status>OPST0100</status>
    <is_reversal>0</is_reversal>
    <originator_refnum>$L_REFERENCE_NO</originator_refnum>
    <terminal_number>EPIN0001</terminal_number>
    <merchant_number>EPIN_MERCHANT</merchant_number>
    <issuer>
      <client_id_type>CITPACCT</client_id_type>
      <client_id_value>$L_CREDIT_CARD_AC_NO</client_id_value>
      <inst_id>1001</inst_id>
      <network_id>1001</network_id>
    </issuer>
    <acquirer>
            <inst_id>1001</inst_id>
    </acquirer>
    <note>
      <note_type>NTTPUSER </note_type>
      <note_content language="LANGENG">
        <note_header>Payment from CBS</note_header>
        <note_text>Customer did payment from cbs</note_text>
      </note_content>
    </note>
  </operation>
</clearing>';
  
    RETURN L_CLOB;
  
    DBG('END OF FN_GET_SVXP_TEMPLATE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_SVXP_TEMPLATE');
      DBG('ERROR CODE IN FN_GET_SVXP_TEMPLATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_SVXP_TEMPLATE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN FN_GET_SVXP_TEMPLATE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
  END FN_GET_SVXP_TEMPLATE;

  PROCEDURE PR_WRITE_CLOB_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                  P_IN_FILE_NAME IN VARCHAR2,
                                  P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_CLOB_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_CLOB_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_CLOB_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_CLOB_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_CLOB_TO_FILE;

  PROCEDURE PR_GEN_CCPAYMNT_SVXP_FILE(P_TY_RTUPLD IN OUT DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC) IS
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
    L_RESP_CODE     VARCHAR2(10);
  BEGIN
  
    --GLOBAL.pr_init('001', 'SYSTEM');
    DBG('START OF PR_GEN_CCPAYMNT_SVXP_FILE');
  
    L_RESP_TEMPLATE := FN_GET_SVXP_TEMPLATE;
  
    L_FILE_NAME := 'SVXP_OUT_PMNT_' ||
                   P_TY_RTUPLD.ty_upld_rtl_teller.trn_ref_no || '_' ||
                   GLOBAL.APPLICATION_DATE;
  
    /*TO_CHAR(P_TY_RETAIL_TELLER.TIME_RECEIVED,
    CSPKS_REQ_GLOBAL.G_DATE_TIME_FORMAT)*/
    DBG('P_TY_RTUPLD.ty_upld_rtl_teller.time_received=' ||
        P_TY_RTUPLD.ty_upld_rtl_teller.time_received);
  
    P_TY_RTUPLD.ty_upld_rtl_teller.TIME_RECEIVED := CSFNS_TIMESTAMP;
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_DATE',
                               SUBSTR(TO_CHAR(P_TY_RTUPLD.ty_upld_rtl_teller.TIME_RECEIVED,
                                              Cspks_Req_Global.G_DATE_TIME_FORMAT),
                                      1,
                                      10) || 'T' ||
                               SUBSTR(TO_CHAR(P_TY_RTUPLD.ty_upld_rtl_teller.TIME_RECEIVED,
                                              Cspks_Req_Global.G_DATE_TIME_FORMAT),
                                      12));
    --TO_DATE(GLOBAL.application_date,Cspks_Req_Global.g_Date_Format));
    --SUBSTR(p_ifdcccas.v_credit_card_pymnt_by_cash.checker_dt_stamp,1,10)||'T'||SUBSTR(p_ifdcccas.v_credit_card_pymnt_by_cash.checker_dt_stamp,12));
    --p_ifdcccas.v_credit_card_pymnt_by_cash.payment_date);
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_AMOUNT',
                               P_TY_RTUPLD.ty_upld_rtl_teller.TXN_AMOUNT * 100);
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE, '$L_ISO_CCY_CODE', '840');
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_REFERENCE_NO',
                               P_TY_RTUPLD.ty_upld_rtl_teller.trn_ref_no);
  
    L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                               '$L_CREDIT_CARD_AC_NO',
                               P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4);
  
    L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
  
    DBG('L_RESP_CLOB=' || L_RESP_CLOB);
  
    --L_RESP_TEMPLATE := NULL;
  
    --END LOOP;
  
    DBG('DONE WITH GENERATING CLOB RESPONSE');
  
    --Write to output file
    DBG('START OF WRITING CLOB TO AN XML FILE');
    PR_WRITE_CLOB_TO_FILE('CREDIT_CARD_PAYMENT_CASH',
                          REPLACE(L_FILE_NAME, 'REQ', 'RES') || '.XML',
                          L_RESP_CLOB);
  
    DBG('END OF WRITING CLOB TO AN XML FILE');
  
    DBG('END OF PR_GEN_CCPAYMNT_SVXP_FILE');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GEN_CCPAYMNT_SVXP_FILE');
      DBG('ERROR CODE IN PR_GEN_CCPAYMNT_SVXP_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GEN_CCPAYMNT_SVXP_FILE=' || SQLERRM);
  END PR_GEN_CCPAYMNT_SVXP_FILE;
  --Prince Bank Credit Card Payment by Cash GL Changes ends

  FUNCTION FN_BUILD_RTDETAILS(P_SOURCE         IN VARCHAR2,
                              P_PARENT_RES     IN VARCHAR2,
                              P_REFERENCE_NO   IN VARCHAR2,
                              P_TY_RTUPLD      IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                              P_PARENT         IN OUT VARCHAR2,
                              P_KEY            IN OUT VARCHAR2,
                              P_DATA           IN OUT VARCHAR2,
                              P_FORMAT         IN OUT VARCHAR2,
                              P_NODE           IN OUT VARCHAR2,
                              P_FN_CALL_ID     IN NUMBER,
                              P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    --LOCH transaction and offset Amount to display with negative sign for reversal Changes starts
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    --LOCH transaction and offset Amount to display with negative sign for reversal Changes ends
    --Prince Bank AML Changes Starts
    L_WALKIN_CUSTOMER VARCHAR2(100);
    --Prince Bank AML Changes Ends
  BEGIN
    IF P_FN_CALL_ID = 1 THEN
    
      DBG('IF', 'Inside fn_build_rtdetails ...');
    
      DBG('GWPKS_UTIL.PKG_ACTTYPE=' || GWPKS_UTIL.PKG_ACTTYPE);
    
      DBG('GWPKS_UTIL.PKG_FUNC=' || GWPKS_UTIL.PKG_FUNC);
    
      --Prince Bank Credit Card Payment by Cash GL Changes starts
      IF GWPKS_UTIL.PKG_FUNC IN ('CCCG') THEN
      
        P_KEY := 'CHAR_FIELD3' || '~' || 'CHAR_FIELD4' || '~' ||
                 'CHAR_FIELD5' || '~' || 'CHAR_FIELD6' || '~' ||
                 'CHAR_FIELD7' || '~' || 'CHAR_FIELD8' || '~' ||
                 'CHAR_FIELD9' || '~' || P_KEY;
      
        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field3 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field4 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field5 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field7 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field8 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field9 || '~' ||
                  P_DATA;
      
      END IF;
      --Prince Bank Credit Card Payment by Cash GL Changes ends
    
      --LOCH transaction and offset Amount to display with negative sign for reversal Changes starts
      IF GWPKS_UTIL.PKG_FUNC IN ('LOCH') THEN
        IF GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
        
          dbg('DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.xref=' ||
              DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.xref);
          dbg('DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.trn_ref_no=' ||
              DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.trn_ref_no);
          dbg('P_TY_RTUPLD.ty_upld_rtl_teller.xref=' ||
              P_TY_RTUPLD.ty_upld_rtl_teller.xref);
          DBG('P_REFERENCE_NO=' || P_REFERENCE_NO);
        
          --Get details
          BEGIN
            SELECT *
              INTO L_DETB_RTL_TELLER
              FROM DETB_RTL_TELLER
             WHERE TRN_REF_NO = P_REFERENCE_NO;
          EXCEPTION
            WHEN OTHERS THEN
              L_DETB_RTL_TELLER := NULL;
          END;
        
          P_KEY  := 'PRINTXNAMT' || '~' || 'PRINOFFSAMT' || '~' || P_KEY;
          P_DATA := '-' ||
                    TRIM(CSFNS_FORMAT_AMT(L_DETB_RTL_TELLER.TXN_CCY,
                                          L_DETB_RTL_TELLER.TXN_AMOUNT)) || '~' || '-' ||
                    TRIM(CSFNS_FORMAT_AMT(L_DETB_RTL_TELLER.OFS_CCY,
                                          L_DETB_RTL_TELLER.OFS_AMOUNT)) || '~' ||
                    P_DATA;
        
        ELSE
        
          P_KEY  := 'PRINTXNAMT' || '~' || 'PRINOFFSAMT' || '~' || P_KEY;
          P_DATA := TRIM(CSFNS_FORMAT_AMT(DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_CCY,
                                          DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT)) || '~' ||
                    TRIM(CSFNS_FORMAT_AMT(DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.OFS_CCY,
                                          DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.OFS_AMOUNT)) || '~' ||
                    P_DATA;
        
        END IF;
      
        DBG('MODIFIED P_KEY=' || P_KEY);
        DBG('MODIFIED P_DATA=' || P_DATA);
      
      END IF;
      --LOCH transaction and offset Amount to display with negative sign for reversal Changes ends
    
      --Prince Bank AML Changes Starts
      IF GWPKS_UTIL.PKG_FUNC IN ('1001', '1401', '1013') THEN
      
        IF GWPKS_UTIL.PKG_FUNC IN ('1013') THEN
          P_KEY := 'CHAR_FIELD40' || '~' || 'CHAR_FIELD31' || '~' ||
                   'CHAR_FIELD32' || '~' || 'CHAR_FIELD33' || '~' || --AML Participant Enhancements Changes
                   'CHAR_FIELD34' || '~' || 'CHAR_FIELD36' || '~' ||
                   'CHAR_FIELD37' || '~' || P_KEY;
        
          P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field40 || '~' || --AML Participant Enhancements Changes
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field33 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field36 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field37 || '~' ||
                    P_DATA;
        ELSIF GWPKS_UTIL.PKG_FUNC IN ('1001') THEN
          P_KEY := 'CHAR_FIELD40' || '~' || 'CHAR_FIELD31' || '~' || --AML Participant Enhancements Changes
                   'CHAR_FIELD32' || '~' || 'CHAR_FIELD33' || '~' ||
                   'CHAR_FIELD34' || '~' || P_KEY;
        
          P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field40 || '~' || --AML Participant Enhancements Changes
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field33 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                    P_DATA;
        ELSE
          P_KEY := 'CHAR_FIELD40' || '~' || 'CHAR_FIELD31' || '~' || --AML Participant Enhancements Changes
                   'CHAR_FIELD32' || '~' || 'CHAR_FIELD33' || '~' ||
                   'CHAR_FIELD34' || '~' || 'CHAR_FIELD35' || '~' || P_KEY;
        
          P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field40 || '~' || --AML Participant Enhancements Changes
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field33 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                    P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35 || '~' ||
                    P_DATA;
        END IF;
      END IF;
    
      IF GWPKS_UTIL.PKG_FUNC IN ('8203', '8004') THEN
      
        P_KEY := 'RELCUST' || '~' || 'CHAR_FIELD34' || '~' ||
                 'CHAR_FIELD35' || '~' || P_KEY;
      
        SELECT DECODE(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER,
                      global_frc.g_tbl_sttm_branch_rec.walkin_customer,
                      NULL,
                      P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER)
          INTO L_WALKIN_CUSTOMER
          FROM DUAL;
      
        DBG('L_WALKIN_CUSTOMER=' || L_WALKIN_CUSTOMER);
        DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER=' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER);
        DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34=' ||
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34);
        DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35=' ||
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35);
      
        DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.char_field1=' ||
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field1);
      
        DBG('P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6=' ||
            P_TY_RTUPLD.ty_cstbs_ui_columns.char_field6);
      
        P_DATA := P_TY_RTUPLD.TY_UPLD_RTL_TELLER.REL_CUSTOMER || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35 || '~' ||
                  P_DATA;
      
      END IF;
    
      --Prince Bank AML Changes Ends
    
      --Prince NBC RFT changes Starts
      IF GWPKS_UTIL.PKG_FUNC IN ('RFTM') THEN
      
        P_KEY := 'CHAR_FIELD41' || '~' || 'CHAR_FIELD42' || '~' ||
                 'CHAR_FIELD43' || '~' || 'NUM_FIELD25' || '~' ||
                 'CHAR_FIELD44' || '~' || 'CHAR_FIELD47' || '~' ||
                 'CHAR_FIELD45' || '~' || 'CHAR_FIELD46' || '~' || P_KEY;
      
        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field41 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field42 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field43 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.num_field25 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field44 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.CHAR_FIELD47 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field45 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field46 || '~' ||
                  P_DATA;
      
      END IF;
    
      --Prince NBC RFT Changes Ends
    
      --Bongluy Cash In Integration Starts
      IF GWPKS_UTIL.PKG_FUNC IN ('BLIN') THEN
      
        P_KEY := 'CHAR_FIELD40' || '~' || 'CHAR_FIELD31' || '~' ||
                 'CHAR_FIELD32' || '~' || 'CHAR_FIELD33' || '~' ||
                 'CHAR_FIELD34' || '~' || 'CHAR_FIELD35' || '~' ||
                 'CHAR_FIELD36' || '~' || 'CHAR_FIELD37' || '~' ||
                 'NUM_FIELD14' || '~' || 'CHAR_FIELD38' || '~' ||
                 'CHAR_FIELD41' || '~' || 'CHAR_FIELD42' || '~' ||
                
                 P_KEY;
      
        P_DATA := P_TY_RTUPLD.ty_cstbs_ui_columns.char_field40 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field31 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field32 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field33 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field34 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field35 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field36 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field37 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.num_field14 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field38 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field41 || '~' ||
                  P_TY_RTUPLD.ty_cstbs_ui_columns.char_field42 || '~' ||
                  P_DATA;
      
      END IF;
      --Bongluy Cash In Integration Ends
    
    END IF;
  
    DBG('IF', 'Returning Successfully from fn_build_rtdetails..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IF',
          'In When Others of gwpks_queryretailtlr_custom.fn_build_rtdetails ..');
      DBG('IF', SQLERRM);
      RETURN FALSE;
  END FN_BUILD_RTDETAILS;

  FUNCTION FN_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                            P_PARENT_RES     IN VARCHAR2,
                            P_FCCREF         IN VARCHAR2,
                            P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                            P_XREF           IN VARCHAR2,
                            P_PARENT         IN OUT VARCHAR2,
                            P_TAG            IN OUT VARCHAR2,
                            P_DATA           IN OUT VARCHAR2,
                            P_FORMAT         IN OUT VARCHAR2,
                            P_FN_CALL_ID     IN NUMBER,
                            P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside CUSTOM function fn_build_fsreply..');
  
    DBG('**',
        'Returning successfully from the CUSTOM function fn_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of CUSTOM fn_build_fsreply..');
      RETURN FALSE;
  END FN_BUILD_FSREPLY;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_REPLY_FTDETAILS_PRE(P_TY_RTUPLD IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                  P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                                  P_DATA      IN OUT VARCHAR2,
                                  P_KEY       IN OUT VARCHAR2,
                                  P_PARENT    IN OUT VARCHAR2,
                                  P_FORMAT    IN OUT VARCHAR2,
                                  P_NODE      IN OUT VARCHAR2,
                                  P_CNT_LVL   IN OUT VARCHAR2,
                                  P_ERR_CODE  IN OUT VARCHAR2,
                                  P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_reply_ftdetails_Pre');
  
    DBG('Returning success from fn_reply_ftdetails_Pre');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of gwpks_queryretailtlr_custom.fn_reply_ftdetails_Pre..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      RETURN FALSE;
  END FN_REPLY_FTDETAILS_PRE;

  FUNCTION FN_REPLY_FTDETAILS_POST(P_TY_RTUPLD IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                   P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                                   P_DATA      IN OUT VARCHAR2,
                                   P_KEY       IN OUT VARCHAR2,
                                   P_PARENT    IN OUT VARCHAR2,
                                   P_FORMAT    IN OUT VARCHAR2,
                                   P_NODE      IN OUT VARCHAR2,
                                   P_CNT_LVL   IN OUT VARCHAR2,
                                   P_ERR_CODE  IN OUT VARCHAR2,
                                   P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_reply_ftdetails_Post');
  
    DBG('Returning success from fn_reply_ftdetails_Post');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_queryretailtlr_custom.fn_reply_ftdetails_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_REPLY_FTDETAILS_POST;

  FUNCTION FN_REPLY_CHGDETS(P_SOURCE         IN VARCHAR2,
                            P_FCCREF         IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE,
                            P_DATA           IN OUT VARCHAR2,
                            P_KEY            IN OUT VARCHAR2,
                            P_PARENT         IN OUT VARCHAR2,
                            P_FORMAT         IN OUT VARCHAR2,
                            P_NODE           IN OUT VARCHAR2,
                            P_CNT_LVL        IN OUT VARCHAR2,
                            P_TS_LIST        IN OUT VARCHAR2,
                            P_TS_LIST1       IN OUT VARCHAR2,
                            P_TS_VALUE       IN OUT VARCHAR2,
                            P_TS_VALUE1      IN OUT VARCHAR2,
                            P_COUNT          IN INTEGER,
                            P_FN_CALL_ID     IN OUT NUMBER,
                            P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside Custom function fn_reply_chgdets ...');
  
    DBG('Returning success from Custom function Fn_reply_chgdets');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of fn_reply_chgdets..');
      RETURN FALSE;
    
  END FN_REPLY_CHGDETS;

  FUNCTION FN_PRE_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                                P_PARENT_RES     IN VARCHAR2,
                                P_FCCREF         IN VARCHAR2,
                                P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                P_XREF           IN VARCHAR2,
                                P_PARENT         IN OUT VARCHAR2,
                                P_TAG            IN OUT VARCHAR2,
                                P_DATA           IN OUT VARCHAR2,
                                P_FORMAT         IN OUT VARCHAR2,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAM      IN OUT VARCHAR2,
                                P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                P_FN_CALL_ID     IN NUMBER) RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside the function Gwpks_Queryretailtlr_Custom.fn_pre_build_fsreply..');
  
    DBG('Returning successfully from the function fn_pre_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_pre_build_fsreply..');
      RETURN FALSE;
  END FN_PRE_BUILD_FSREPLY;

  FUNCTION FN_POST_BUILD_FSREPLY(P_SOURCE         IN VARCHAR2,
                                 P_PARENT_RES     IN VARCHAR2,
                                 P_FCCREF         IN VARCHAR2,
                                 P_TY_RTUPLD      IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC,
                                 P_XREF           IN VARCHAR2,
                                 P_PARENT         IN OUT VARCHAR2,
                                 P_TAG            IN OUT VARCHAR2,
                                 P_DATA           IN OUT VARCHAR2,
                                 P_FORMAT         IN OUT VARCHAR2,
                                 P_ERR_CODE       IN OUT VARCHAR2,
                                 P_ERR_PARAM      IN OUT VARCHAR2,
                                 P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                 P_FN_CALL_ID     IN NUMBER) RETURN BOOLEAN IS
    --PRF_CUSTOM_05_03072018 changes starts
    L_TB_EMPTY_TBL     GWPKS_CREATERETAILTLR.TY_RECS_TBL;
    L_TB_NAME_VAL_PAIR GWPKS_CREATERETAILTLR.TY_RECS_TBL;
  
    L_TS_TAG_VALUES VARCHAR2(32767);
    L_TS_TAG_NAMES  VARCHAR2(32767);
    L_NODE_NAME     VARCHAR2(50);
    L_CURR_TAG      VARCHAR2(255);
    L_P_CNT         INTEGER;
    L_TAG           VARCHAR2(32767);
    L_DATA          VARCHAR2(32767);
    L_NAME          VARCHAR2(650);
    L_F_NAME        VARCHAR2(200);
    L_M_NAME        VARCHAR2(200);
    L_L_NAME        VARCHAR2(200);
    L_DEP_TYPE      VARCHAR2(50);
    L_BEN_NAME      VARCHAR2(500);
    L_AMT_WORDS     VARCHAR2(4000);
    L_RTL_TELLER    DETBS_RTL_TELLER%ROWTYPE;
    L_ADV_TOP       VARCHAR2(500);
    L_MOB_NO        VARCHAR2(50);
  
    --PRF_CUSTOM_05_03072018 changes ends
  
    --Prince Bank Credit Card Payment by Cash GL Changes
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_ACTB_DAILY_LOG  ACTB_DAILY_LOG%ROWTYPE;
    --Prince Bank Credit Card Payment by Cash GL Changes
  
    --Cheque Withdrawal Reverse Starts
    L_IFTB_CHEQUE_CUSTOM IFTB_CHEQUE_WITHDRAWAL_CUSTOM%ROWTYPE;
    --Cheque Withdrawal Reverse Ends
  
    --AML Participant Enhancements Starts
    L_IFTB_AML_PARTI_INFO_1401 IFTB_AML_PARTICIPANT_INFO_1401%ROWTYPE;
    L_IFTB_AML_PARTI_INFO_1001 IFTB_AML_PARTICIPANT_INFO_1001%ROWTYPE;
    L_IFTB_AML_PARTI_INFO_1013 IFTB_AML_PARTICIPANT_INFO_1013%ROWTYPE;
    L_IFTB_AML_PARTI_INFO_8203 IFTB_AML_PARTICIPANT_INFO_8203%ROWTYPE;
    L_IFTB_AML_PARTI_INFO_8004 IFTB_AML_PARTICIPANT_INFO_8004%ROWTYPE;
    --AML Participant Enhancements Ends
  
    --Prince NBC RFT changes Starts
    L_IFTB_RFT_PASSCODE_INFO IFTB_RFT_PASSCODE_INFO%ROWTYPE;
    --Prince NBC RFT changes Ends
  
  BEGIN
    DBG('Inside the function Gwpks_Queryretailtlr_Custom.fn_post_build_fsreply..');
  
    --PRF_CUSTOM_05_03072018 CHANGES STARTS
    DBG('PROD :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE);
    DBG('ANIKET WIL BE MODFYING THE TAGS HERE');
  
    L_TAG  := '';
    L_DATA := '';
  
    L_P_CNT := 1;
  
    L_NODE_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_PARENT,
                                               NULL,
                                               'N',
                                               L_P_CNT,
                                               '>'),
                       '??');
  
    WHILE L_NODE_NAME <> 'EOPL' LOOP
      DBG('Processing the node: ' || L_NODE_NAME);
      L_TB_NAME_VAL_PAIR := L_TB_EMPTY_TBL;
      L_TS_TAG_NAMES     := NVL(CSPKES_MISC.FN_GETPARAM(P_TAG,
                                                        P_TAG,
                                                        'N',
                                                        L_P_CNT,
                                                        '>'),
                                '??');
    
      IF L_TS_TAG_NAMES <> '??' THEN
        L_TAG := L_TAG || L_TS_TAG_NAMES;
      END IF;
    
      L_TS_TAG_VALUES := NVL(CSPKES_MISC.FN_GETPARAM(P_DATA,
                                                     P_DATA,
                                                     'N',
                                                     L_P_CNT,
                                                     '>'),
                             '??');
    
      IF L_TS_TAG_VALUES <> '??' THEN
        L_DATA := L_DATA || L_TS_TAG_VALUES;
      END IF;
    
      DBG('L_NODE_NAME :' || L_NODE_NAME);
    
      IF L_NODE_NAME = 'Blk-Transaction-Details' THEN
        DBG('before L_DATA :' || L_DATA);
        DBG('XREF :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF || '~' ||
            P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      
        BEGIN
          SELECT *
            INTO L_RTL_TELLER
            FROM DETBS_RTL_TELLER
           WHERE XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED SELECTING FROM THE RTL TELLER ' || SQLERRM);
            BEGIN
              SELECT *
                INTO L_RTL_TELLER
                FROM DETBS_RTL_TELLER
               WHERE TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('FAILED AGAIN ' || SQLERRM);
                L_RTL_TELLER := NULL;
            END;
        END;
      
        DBG('TXN AMT :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT || '~' ||
            L_RTL_TELLER.TXN_AMOUNT);
        IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_AMOUNT,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'TXN_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        ELSIF L_RTL_TELLER.TXN_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  L_RTL_TELLER.TXN_AMOUNT,
                                                  L_RTL_TELLER.TXN_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'TXN_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        END IF;
      
        DBG('OFS AMT :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT);
        IF P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_AMOUNT,
                                                  P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'OFS_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        ELSIF L_RTL_TELLER.OFS_AMOUNT IS NOT NULL THEN
          L_AMT_WORDS := CSPKES_MISC.FN_NUM2WORDS(GLOBAL.LANG,
                                                  L_RTL_TELLER.OFS_AMOUNT,
                                                  L_RTL_TELLER.OFS_CCY);
          DBG('WORDS :' || L_AMT_WORDS);
          L_TAG  := L_TAG || 'OFS_AMTWORDS~';
          L_DATA := L_DATA || L_AMT_WORDS || '~';
        END IF;
      
        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                             L_RTL_TELLER.TXN_BRANCH)) LOOP
          L_TAG  := L_TAG || 'TXN_BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;
      
        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH,
                             L_RTL_TELLER.OFS_BRANCH)) LOOP
          L_TAG  := L_TAG || 'OFS_BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;
      
        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE);
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.BRANCH_CODE,
                             L_RTL_TELLER.BRANCH_CODE)) LOOP
          L_TAG  := L_TAG || 'BRANCH_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        END LOOP;
      
        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE);
        FOR X IN (SELECT *
                    FROM CSTMS_PRODUCT
                   WHERE PRODUCT_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.PRODUCT_CODE,
                             L_RTL_TELLER.PRODUCT_CODE)) LOOP
          L_TAG     := L_TAG || 'PRODUCT_DESC~';
          L_DATA    := L_DATA || X.PRODUCT_DESCRIPTION || '~';
          L_ADV_TOP := X.PRODUCT_DESCRIPTION;
        END LOOP;
      
        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC);
        FOR X IN (SELECT DECODE(ACCOUNT_TYPE,
                                'N',
                                'NOSTRO',
                                'S',
                                'SAVINGS',
                                'U',
                                'CHECKING',
                                'Y',
                                'TERM DEPOSIT',
                                '') AS AC_TYPE
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO = NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_ACC,
                                          L_RTL_TELLER.TXN_ACC)
                     AND BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TXN_BRANCH,
                             L_RTL_TELLER.TXN_BRANCH)) LOOP
          L_TAG  := L_TAG || 'TXN_AC_TYPE~';
          L_DATA := L_DATA || X.AC_TYPE || '~';
        END LOOP;
      
        DBG('Selecting :' || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC);
        FOR X IN (SELECT DECODE(ACCOUNT_TYPE,
                                'N',
                                'NOSTRO',
                                'S',
                                'SAVINGS',
                                'U',
                                'CHECKING',
                                'Y',
                                'TERM DEPOSIT',
                                '') AS AC_TYPE
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO = NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_ACC,
                                          L_RTL_TELLER.OFS_ACC)
                     AND BRANCH_CODE =
                         NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.OFS_BRANCH,
                             L_RTL_TELLER.OFS_BRANCH)) LOOP
          L_TAG  := L_TAG || 'OFS_AC_TYPE~';
          L_DATA := L_DATA || X.AC_TYPE || '~';
        END LOOP;
      
        IF P_TY_RTUPLD.TBL_UDFDETAILS.COUNT > 0 THEN
          FOR X IN P_TY_RTUPLD.TBL_UDFDETAILS.FIRST .. P_TY_RTUPLD.TBL_UDFDETAILS.COUNT LOOP
            DBG(P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME || '~' || P_TY_RTUPLD.TBL_UDFDETAILS(X)
                .FIELD_VAL);
            IF P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_NAME = 'BENEFICIARY_NAME' THEN
              L_TAG  := L_TAG || 'UD_BENF_NAME~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            ELSIF P_TY_RTUPLD.TBL_UDFDETAILS(X)
             .FIELD_NAME = 'BENEFICIARY_ID_TYPE' THEN
              L_TAG  := L_TAG || 'UD_BENF_ID_TYPE~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            ELSIF P_TY_RTUPLD.TBL_UDFDETAILS(X)
             .FIELD_NAME = 'BENEFICIARY_ID_NO' THEN
              L_TAG  := L_TAG || 'UD_BENF_ID_NO~';
              L_DATA := L_DATA || P_TY_RTUPLD.TBL_UDFDETAILS(X).FIELD_VAL || '~';
            END IF;
          END LOOP;
        END IF;
      END IF;
    
      DBG('ACTION TYPE IS :' || GWPKS_UTIL.PKG_ACTTYPE);
      IF GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
        L_ADV_TOP := L_ADV_TOP || ' REVERSAL';
      END IF;
    
      L_TAG  := L_TAG || 'ADV_TOP~';
      L_DATA := L_DATA || L_ADV_TOP || '~';
    
      IF L_TS_TAG_NAMES <> '??' THEN
        L_TAG := L_TAG || '>';
      END IF;
    
      IF L_TS_TAG_VALUES <> '??' THEN
        L_DATA := L_DATA || '>';
      END IF;
    
      L_P_CNT     := L_P_CNT + 1;
      L_NODE_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_PARENT, L_P_CNT, '>'),
                         '??');
    END LOOP;
    DBG('P_TAG :' || P_TAG);
    DBG('L_TAG :' || L_TAG);
    DBG('P_DATA :' || P_DATA);
    DBG('L_DATA :' || L_DATA);
    P_TAG  := L_TAG;
    P_DATA := L_DATA;
    DBG('Completed the data preparation into PL/SQL collection');
    --PRF_CUSTOM_05_03072018 CHANGES ENDS
  
    --Prince Bank Credit Card Payment by Cash GL Changes starts
  
    IF GWPKS_UTIL.PKG_FUNC IN ('CCCG') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
    
      /*BEGIN
        SELECT *
          INTO L_FBTB_TXNLOG_MASTER
          FROM FBTB_TXNLOG_MASTER
          WHERE XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      EXCEPTION
        WHEN OTHERS THEN
          L_FBTB_TXNLOG_MASTER := NULL;
      END;*/
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO
           AND A.PRODUCT_CODE IN ('CCCH', 'CCCV');
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      /* BEGIN
        SELECT *
          INTO L_ACTB_DAILY_LOG
          FROM ACTB_DAILY_LOG
          WHERE EXTERNAL_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
          AND ROWNUM=1;
      EXCEPTION
        WHEN OTHERS THEN
          L_ACTB_DAILY_LOG := NULL;
      END;*/
    
      --IF L_FBTB_TXNLOG_MASTER.TXNSTATUS = 'IPR' THEN
    
      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
      --DBG('AUTH STAT1=' || L_ACTB_DAILY_LOG.AUTH_STAT);
      --DBG('CHEKER ID1='||L_ACTB_DAILY_LOG.AUTH_ID);
    
      -- IF L_FBTB_TXNLOG_MASTER.TXNSTATUS = 'IPR' THEN
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN
      
        --insert into cash by gl master table
        PR_INSERT_CASH_BY_GL(P_TY_RTUPLD);
        --generate svxp file
        PR_GEN_CCPAYMNT_SVXP_FILE(P_TY_RTUPLD);
      
      END IF;
    
      --END IF;
    END IF;
  
    --Cheque Withdrawal Reverse Starts
  
    IF GWPKS_UTIL.PKG_FUNC IN ('1013') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO
           AND A.PRODUCT_CODE IN ('CQWL');
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
    
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN
      
        PR_INSERT_CHEQUE_WITHDRAWAL(P_TY_RTUPLD);
      
      END IF;
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('1013') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
    
      BEGIN
        SELECT *
          INTO L_IFTB_CHEQUE_CUSTOM
          FROM IFTB_CHEQUE_WITHDRAWAL_CUSTOM A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO
           AND A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      EXCEPTION
        WHEN OTHERS THEN
          L_IFTB_CHEQUE_CUSTOM := NULL;
      END;
    
      P_DATA := L_IFTB_CHEQUE_CUSTOM.char_field40 || '~' || --AML Participant Enhancements Changes
                L_IFTB_CHEQUE_CUSTOM.char_field31 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field32 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field33 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field34 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field36 || '~' ||
                L_IFTB_CHEQUE_CUSTOM.char_field37 || '~' ||
               
                SUBSTR(P_DATA, 8); --AML Participant Enhancements Changes
    
    END IF;
  
    --Cheque Withdrawal Reverse Ends
  
    --END IF;
  
    --Prince Bank Credit Card Payment by Cash GL Changes ends
  
    --AML Participant Enhancements Starts
    IF GWPKS_UTIL.PKG_FUNC IN ('1001') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
    
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN
      
        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);
      
      END IF;
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('1001') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
    
      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_1001
          FROM IFTB_AML_PARTICIPANT_INFO_1001 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      EXCEPTION
        WHEN OTHERS THEN
          L_IFTB_AML_PARTI_INFO_1001 := NULL;
      END;
    
      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);
    
      P_DATA := L_IFTB_AML_PARTI_INFO_1001.PARTICIPANT_NO || '~' ||
                L_IFTB_AML_PARTI_INFO_1001.SAME_AS_ACC_OWN || '~' ||
                L_IFTB_AML_PARTI_INFO_1001.PARTICIPANT_NAME || '~' ||
                L_IFTB_AML_PARTI_INFO_1001.MOBILE_NUMBER || '~' ||
                L_IFTB_AML_PARTI_INFO_1001.PURPOSE_OF_TXN || '~' ||
               
                SUBSTR(P_DATA, 6);
    
      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('1401') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
    
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN
      
        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);
      
      END IF;
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('1401') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
    
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);
    
      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_1401
          FROM IFTB_AML_PARTICIPANT_INFO_1401 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');
        
          L_IFTB_AML_PARTI_INFO_1401 := NULL;
      END;
    
      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);
    
      P_DATA := L_IFTB_AML_PARTI_INFO_1401.PARTICIPANT_NO || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.SAME_AS_ACC_OWN || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.PARTICIPANT_NAME || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.MOBILE_NUMBER || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.PURPOSE_OF_TXN || '~' ||
                L_IFTB_AML_PARTI_INFO_1401.SOURCE_OF_FUNDS || '~' ||
               
                SUBSTR(P_DATA, 7);
    
      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('1013') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
    
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN
      
        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);
      
      END IF;
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('1013') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
    
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);
    
      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_1013
          FROM IFTB_AML_PARTICIPANT_INFO_1013 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');
        
          L_IFTB_AML_PARTI_INFO_1013 := NULL;
      END;
    
      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);
    
      P_DATA := L_IFTB_AML_PARTI_INFO_1013.PARTICIPANT_NO || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.SAME_AS_ACC_OWN || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.PARTICIPANT_NAME || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.MOBILE_NUMBER || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.PURPOSE_OF_TXN || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.UID_NAME || '~' ||
                L_IFTB_AML_PARTI_INFO_1013.UID_VALUE || '~' ||
               
                SUBSTR(P_DATA, 8);
    
      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('8203') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
    
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN
      
        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);
      
      END IF;
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('8203') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
    
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);
    
      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_8203
          FROM IFTB_AML_PARTICIPANT_INFO_8203 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');
        
          L_IFTB_AML_PARTI_INFO_8203 := NULL;
      END;
    
      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);
    
      P_DATA := L_IFTB_AML_PARTI_INFO_8203.REL_CUSTOMER || '~' ||
                L_IFTB_AML_PARTI_INFO_8203.PURPOSE_OF_TXN || '~' ||
                L_IFTB_AML_PARTI_INFO_8203.SOURCE_OF_FUNDS || '~' ||
               
                SUBSTR(P_DATA, 4);
    
      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('8004') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
    
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN
      
        DBG('INSIDE IF CONDITION');
        --insert into participant info table table
        PR_INSERT_PARTICIPANT_INFO(GWPKS_UTIL.PKG_FUNC, P_TY_RTUPLD);
      
      END IF;
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('8004') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
    
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);
    
      BEGIN
        SELECT *
          INTO L_IFTB_AML_PARTI_INFO_8004
          FROM IFTB_AML_PARTICIPANT_INFO_8004 A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');
        
          L_IFTB_AML_PARTI_INFO_8004 := NULL;
      END;
    
      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);
    
      P_DATA := L_IFTB_AML_PARTI_INFO_8004.REL_CUSTOMER || '~' ||
                L_IFTB_AML_PARTI_INFO_8004.PURPOSE_OF_TXN || '~' ||
                L_IFTB_AML_PARTI_INFO_8004.SOURCE_OF_FUNDS || '~' ||
               
                SUBSTR(P_DATA, 4);
    
      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);
    
    END IF;
    --AML Participant Enhancements Ends
  
    --Prince NBC RFT changes Starts
  
    IF GWPKS_UTIL.PKG_FUNC IN ('RFTM') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF
           AND A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      DBG('AUTH STAT=' || L_DETB_RTL_TELLER.AUTH_STAT);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
    
      IF L_DETB_RTL_TELLER.AUTH_STAT = 'A' AND
         L_DETB_RTL_TELLER.CHECKER_ID IS NOT NULL AND
         L_DETB_RTL_TELLER.MAKER_ID <> L_DETB_RTL_TELLER.CHECKER_ID THEN
      
        DBG('INSIDE IF CONDITION');
      
        --insert into RFT Passcode table
        PR_INSERT_RFT_PASSCODE_INFO(P_TY_RTUPLD);
      
      END IF;
    
    END IF;
  
    IF GWPKS_UTIL.PKG_FUNC IN ('RFTM') AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
    
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO);
      DBG('P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF=' ||
          P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF);
    
      BEGIN
        SELECT *
          INTO L_IFTB_RFT_PASSCODE_INFO
          FROM IFTB_RFT_PASSCODE_INFO A
         WHERE A.TRN_REF_NO = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.TRN_REF_NO;
        --AND A.XREFID = P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('SOME EXCEPTION IN SELECT STATEMENT');
        
          L_IFTB_RFT_PASSCODE_INFO := NULL;
      END;
    
      DBG('P_DATA BEOFORE IN REVERSE=' || P_DATA);
    
      /* P_DATA := L_IFTB_RFT_PASSCODE_INFO.PARTICIPANT_NO || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.SAME_AS_ACC_OWN || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.PARTICIPANT_NAME || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.MOBILE_NUMBER || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.PURPOSE_OF_TXN || '~' ||
      L_IFTB_RFT_PASSCODE_INFO.SOURCE_OF_FUNDS || '~' ||
      
      SUBSTR(P_DATA, 7);*/
    
      DBG('P_DATA AFTER IN REVERSE=' || P_DATA);
    
    END IF;
  
    --Prince NBC RFT changes Ends
  
    DBG('Returning successfully from the function fn_post_build_fsreply..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_post_build_fsreply..');
      RETURN FALSE;
  END FN_POST_BUILD_FSREPLY;

  FUNCTION FN_PRE_BUILD_RTDETL_DEDQUERY(P_SOURCE       IN VARCHAR2,
                                        P_PARENT_RES   IN VARCHAR2,
                                        P_REFERENCE_NO IN VARCHAR2,
                                        P_PARENT       IN OUT VARCHAR2,
                                        P_TAG          IN OUT VARCHAR2,
                                        P_DATA         IN OUT VARCHAR2,
                                        P_FORMAT       IN OUT VARCHAR2,
                                        P_ERR_CODE     IN OUT VARCHAR2,
                                        P_ERR_PARAM    IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  BEGIN
    DBG('**',
        'Inside the function gwpks_queryretailtlr_custom.fn_pre_build_rtdetl_dedquery..');
  
    DBG('**',
        'Returning successfully from the function fn_pre_build_rtdetl_dedquery..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('**', 'In when others of fn_pre_build_rtdetl_dedquery..');
      RETURN FALSE;
  END FN_PRE_BUILD_RTDETL_DEDQUERY;

END GWPKS_QUERYRETAILTLR_CUSTOM;
/