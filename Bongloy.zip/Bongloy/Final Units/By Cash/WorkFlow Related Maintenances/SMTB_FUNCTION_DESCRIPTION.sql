insert into SMTB_FUNCTION_DESCRIPTION (LANG_CODE, FUNCTION_ID, MAIN_MENU, SUB_MENU_1, SUB_MENU_2, BALOON_HELP, BRANCH_MODULE, BRANCH_PARENT_TASK, DESCRIPTION, RAD_FUNCTION_ID)
values ('ENG', 'BLIN', 'Teller', 'Cash Transactions', 'Bongluy Cash In', null, 'WB', null, 'Bongluy Cash In', 'BLIN');

commit;
