insert into cstms_branch_func_control (FUNCTION_ID, OFFLINE_SUPPORT, REVERSAL_ALLOWED, CONFIRM_SUPPORT)
values ('BLIN', 'Y', 'Y', null);

commit;
