function fnPickUp() {
	debugs("In fnPickup", "A");
	g_prevAction = gAction;
	gAction = "PICKUP";
	appendData();
	gAction = "PICKUP";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}