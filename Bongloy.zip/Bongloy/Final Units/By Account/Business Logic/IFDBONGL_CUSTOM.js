
function fnPostNew_CUSTOM(){
	debugs("In fnPostNew_CUSTOM", "A");
	document.getElementById("BLK_BONGLOY_MASTER__BRANCH_CODE").value = mainWin.CurrentBranch;
	document.getElementById("BLK_BONGLOY_MASTER__TRANSFER_DATE").value = mainWin.AppDate;
	return true;	
}

function fnPostLoad_CUSTOM(){
	debugs("In fnPostLoad_CUSTOM");
	
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostLoad_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){		
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
		EnableToolbar_buttons("Reverse");
	}
	
	if (l_AuthVal != "A"){
		DisableToolbar_buttons("Reverse");
	}
	
	return true;
}

function fnPostCopy_CUSTOM() {
	debugs("In fnPostCopy_CUSTOM", "A");
	document.getElementById("BLK_BONGLOY_MASTER__BRANCH_CODE").value = mainWin.CurrentBranch;
	document.getElementById("BLK_BONGLOY_MASTER__TRANSFER_DATE").value = mainWin.AppDate;
	document.getElementById("BLK_BONGLOY_MASTER__ENQUIRY_NO").value = "";
	document.getElementById("BLK_BONGLOY_MASTER__BONGLOY_PAYMENT_ID").value = "";
	return true;
}

function fnPickUp() {
	debugs("In fnPickup", "A");
	g_prevAction = gAction;
	gAction = "PICKUP";
	appendData();
	gAction = "PICKUP";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}

function fnPostAuthorize_CUSTOM(){
	debugs("In fnPostAuthorize_CUSTOM");
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostAuthorize_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
		EnableToolbar_buttons("Reverse");
	}
	return true;
}

function fnPostReverse_CUSTOM() {
debugs("IFDBONGL", "fnPostReverse");	
if (document.getElementById("BLK_BONGLOY_MASTER__RECORD_STAT").value === "V")	
{
	debugs("IFDBONGL", "Record already reversed");
	DisableToolbar_buttons("Reverse");
	debugs("IFDBONGL", "Reverse button disabled");
}
if (document.getElementById("BLK_BONGLOY_MASTER__AUTH_STAT").value === "A")	
{
	debugs("IFDBONGL", "Record already auth");
	DisableToolbar_buttons("Authorize");
	debugs("IFDBONGL", "auth button disabled");
}

if ((document.getElementById("BLK_BONGLOY_MASTER__RECORD_STAT").value === "V") &&(document.getElementById("BLK_BONGLOY_MASTER__AUTH_STAT").value === "U") )
{
	debugs("IFDBONGL", "Disabling Delete");
	DisableToolbar_buttons("Delete");
}

return true;
}

function fnPostExecuteQuery_CUSTOM(){
	debugs("In fnPostExecuteQuery_CUSTOM");
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostExecuteQuery_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
		EnableToolbar_buttons("Reverse");
	}
	if (l_AuthVal != "A"){
		DisableToolbar_buttons("Reverse");
	}
	return true;
}