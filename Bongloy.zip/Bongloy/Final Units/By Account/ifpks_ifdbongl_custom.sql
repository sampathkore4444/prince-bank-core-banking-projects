CREATE OR REPLACE PACKAGE BODY ifpks_ifdbongl_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdbongl_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdbongl_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  PROCEDURE PR_INSERT_BONGLUY_WS_LOG(P_SEQ_NO          IN VARCHAR2,
                                     P_TRN_REF_NO      IN VARCHAR2,
                                     P_INVOKE_DATE     IN VARCHAR2,
                                     P_BONGLUY_ACCOUNT IN VARCHAR2,
                                     P_REQ_TYPE        IN VARCHAR2,
                                     P_REQ_MSG         IN VARCHAR2,
                                     P_ADDL_INFO       IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    DBG('START OF PR_INSERT_BONGLUY_WS_LOG');
  
    INSERT INTO IFTB_BONGLUY_WS_LOG
      (SEQ_NO,
       TRN_REF_NO,
       INVOKE_DATE,
       BONGLUY_ACCOUNT,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_TRN_REF_NO,
       P_INVOKE_DATE,
       P_BONGLUY_ACCOUNT,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);
  
    COMMIT;
  
    DBG('END OF PR_INSERT_BONGLUY_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_BONGLUY_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_BONGLUY_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_BONGLUY_WS_LOG=' || SQLERRM);
    
  END PR_INSERT_BONGLUY_WS_LOG;

  PROCEDURE PR_UPDATE_BONGLUY_WS_LOG(P_TRN_REF_NO         IN IFTB_BONGLUY_PAY_MASTER.TRN_REF_NO%TYPE,
                                     P_SEQ_NO             IN VARCHAR2,
                                     P_ENQUIRY_NO         IN IFTB_BONGLUY_PAY_MASTER.ENQUIRY_NO%TYPE,
                                     P_BONGLUY_PAYMENT_ID IN IFTB_BONGLUY_PAY_MASTER.BONGLUY_PAYMENT_ID%TYPE,
                                     P_STATUS             IN CHAR,
                                     P_RES_MSG            IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_BONGLUY_WS_LOG');
  
    UPDATE IFTB_BONGLUY_WS_LOG
       SET ENQUIRY_NO         = P_ENQUIRY_NO,
           BONGLUY_PAYMENT_ID = P_BONGLUY_PAYMENT_ID,
           RES_MSG            = P_RES_MSG,
           STATUS             = P_STATUS
     WHERE TRN_REF_NO = P_TRN_REF_NO
       AND SEQ_NO = P_SEQ_NO;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_BONGLUY_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_BONGLUY_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_BONGLUY_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_BONGLUY_WS_LOG=' || SQLERRM);
  END PR_UPDATE_BONGLUY_WS_LOG;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_BONGLUY_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_GET_BONGLUY_ACC_ENQUIRY RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_BONGLUY_ACC_ENQUIRY');
  
    L_FORMATTED_MSG := 'channel=01&&account_no=$L_ACCOUNT_NO&&currency=$L_CCY&&amount=$L_AMT&&transaction_id=$L_TXN_ID&&remark=$L_REMARKS';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_BONGLUY_ACC_ENQUIRY');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_BONGLUY_ACC_ENQUIRY');
      DBG('ERROR CODE IN FN_GET_BONGLUY_ACC_ENQUIRY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_BONGLUY_ACC_ENQUIRY=' || SQLERRM);
    
  END FN_GET_BONGLUY_ACC_ENQUIRY;

  FUNCTION FN_GET_FMT_BONGLUY_ACC_ENQ(P_IFDBONGL IN ifpks_ifdbongl_Main.Ty_ifdbongl)
    RETURN CLOB IS
  
    L_ACCOUNT_NO    IFTB_BONGLUY_PAY_MASTER.BONGLUY_ACC_NO%TYPE;
    L_CCY           IFTB_BONGLUY_PAY_MASTER.BONGLUY_ACC_CCY%TYPE;
    L_AMT           IFTB_BONGLUY_PAY_MASTER.BONGLUY_CASHIN_AMT%TYPE;
    L_TXN_ID        IFTB_BONGLUY_PAY_MASTER.TRN_REF_NO%TYPE;
    L_REMARKS       VARCHAR2(100);
    L_FORMATTED_MSG CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_GET_FMT_BONGLUY_ACC_ENQ');
  
    L_FORMATTED_MSG := FN_GET_BONGLUY_ACC_ENQUIRY;
  
    DBG('BEFORE REPLACEMENT OF BONGLUY OUT ACC ENQUIRY JSON=' ||
        L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_ACCOUNT_NO := p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_NO;
  
    DBG('L_ACCOUNT_NO=' || L_ACCOUNT_NO);
  
    L_CCY := p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY;
  
    DBG('L_CCY=' || L_CCY);
  
    L_AMT := p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_CASHIN_AMT;
  
    DBG('L_AMT=' || L_AMT);
  
    L_TXN_ID := TO_CHAR(GLOBAL.APPLICATION_DATE, 'YYYYMMDD') || 'PB';
  
    DBG('L_TXN_ID=' || L_TXN_ID);
  
    --L_REMARKS := p_ifdbongl.v_iftb_bongluy_pay_master.REMARKS;
  
    --DBG('L_REMARKS=' || L_REMARKS);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_ACCOUNT_NO',
                               L_ACCOUNT_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CCY', L_CCY);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AMT', L_AMT);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_ID', L_TXN_ID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_REMARKS', L_REMARKS);
  
    DBG('BEFORE REPLACEMENT OF BONGLUY ACC ENQUIRY JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_BONGLUY_ACC_ENQ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_BONGLUY_ACC_ENQ');
      DBG('ERROR CODE IN FN_GET_FMT_BONGLUY_ACC_ENQ=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_BONGLUY_ACC_ENQ=' || SQLERRM);
  END FN_GET_FMT_BONGLUY_ACC_ENQ;

  FUNCTION FN_GET_BONGLUY_PAYMENT RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_BONGLUY_PAYMENT');
  
    L_FORMATTED_MSG := 'inquiry_no=$L_ENQUIRY_ID';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_BONGLUY_PAYMENT');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_BONGLUY_PAYMENT');
      DBG('ERROR CODE IN FN_GET_BONGLUY_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_BONGLUY_PAYMENT=' || SQLERRM);
    
  END FN_GET_BONGLUY_PAYMENT;

  FUNCTION FN_GET_FMT_BONGLUY_PAYMENT(P_IFDBONGL IN ifpks_ifdbongl_Main.Ty_ifdbongl)
    RETURN CLOB IS
  
    L_ENQUIRY_ID    IFTB_BONGLUY_PAY_MASTER.BONGLUY_ACC_NO%TYPE; --need to change to enquiry id
    L_FORMATTED_MSG CLOB; --varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_FMT_BONGLUY_PAYMENT');
  
    L_FORMATTED_MSG := FN_GET_BONGLUY_PAYMENT;
  
    DBG('BEFORE REPLACEMENT OF BONGLUY PAYMENT JSON=' || L_FORMATTED_MSG);
  
    --Replace tags with actual values
    L_ENQUIRY_ID := p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_NO; --need to change to enquiry id
  
    DBG('L_ENQUIRY_ID=' || L_ENQUIRY_ID);
  
    DBG('BEFORE REPLACEMENT OF BONGLUY ACC ENQUIRY JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_BONGLUY_PAYMENT');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_BONGLUY_PAYMENT');
      DBG('ERROR CODE IN FN_GET_FMT_BONGLUY_PAYMENT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_BONGLUY_PAYMENT=' || SQLERRM);
    
  END FN_GET_FMT_BONGLUY_PAYMENT;

  FUNCTION FN_BONGLUY_WS_CALL(p_bongluy_call in varchar2,
                              p_out_msg      VARCHAR2,
                              p_in_resp      IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
  
  BEGIN
    dbg('START OF FN_BONGLUY_WS_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
  
    IF p_bongluy_call = 'I' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_BONGLUY_ACC_ENQ_URL');
    
    ELSIF p_bongluy_call = 'C' THEN
    
      L_URL := FN_GET_PARAM_VAL('PGW_BONGLUY_PAYCONFIRM_URL');
    
    END IF;
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
  
    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_BONGLUY_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_BONGLUY_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    utl_http.set_transfer_timeout(300);
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('Error Line Number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_BONGLUY_WS_CALL;

  FUNCTION fn_save(p_ifdbongl              IN OUT ifpks_ifdbongl_main.ty_ifdbongl,
                   pkg_detb_rtl_teller_rec IN OUT detbs_rtl_teller%ROWTYPE,
                   p_err_code              IN OUT VARCHAR2,
                   p_err_params            IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_cust_ac    sttm_cust_account%ROWTYPE;
    l_arc_maint  iftms_arc_maint%ROWTYPE;
    l_cust       sttm_customer%ROWTYPE;
    l_prod       cstm_product%ROWTYPE;
    l_ib_flag    VARCHAR2(1) DEFAULT 'Y';
    l_txn_amt    iftbs_fast_master.txn_amt%TYPE;
    l_txn_amt1   iftbs_fast_master.txn_amt%TYPE;
    l_rate       NUMBER;
    l_rate_code  cstm_product.rate_code_preferred%Type;
    l_rate_code1 cstm_product.rate_code_preferred%Type;
  
  BEGIN
    dbg('In FN_SAVE');
  
    SELECT x.* INTO l_prod FROM cstm_product x WHERE product_code = 'BLOT';
  
    SELECT x.*
      INTO l_cust_ac
      FROM sttm_cust_account x
     WHERE x.cust_ac_no = p_ifdbongl.v_iftb_bongluy_pay_master.cust_ac_no;
  
    -- msg id
  
    SELECT x.*
      INTO l_cust
      FROM sttm_customer x
     WHERE x.customer_no = l_cust_ac.cust_no;
  
    cspkss_arc.pr_get_arc_row(GLOBAL.current_branch,
                              'BLOT',
                              'P',
                              '*.*', -- trans_type
                              p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy,
                              l_ib_flag,
                              l_arc_maint,
                              p_err_code,
                              p_err_params,
                              p_ifdbongl.v_iftb_bongluy_pay_master.CUST_AC_NO,
                              GLOBAL.current_branch);
  
    IF p_err_code IS NOT NULL THEN
      dbg('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
      RETURN FALSE;
    END IF;
  
    pkg_detb_rtl_teller_rec.xref         := p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no;
    pkg_detb_rtl_teller_rec.product_code := 'BLOT';
    pkg_detb_rtl_teller_rec.branch_code  := GLOBAL.CURRENT_BRANCH;
    pkg_detb_rtl_teller_rec.trn_ref_no   := p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no;
  
    pkg_detb_rtl_teller_rec.txn_acc := p_ifdbongl.v_iftb_bongluy_pay_master.CUST_AC_NO;
    pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
    --pkg_detb_rtl_teller_rec.txn_branch := GLOBAL.CURRENT_BRANCH;
    pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;
  
    pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
    pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY;
    pkg_detb_rtl_teller_rec.ofs_amount := p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_CASHIN_AMT; --p_ifdbongl.v_iftb_bongluy_pay_master.txn_amt;
    /* pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                    '*.*',
                                                    GLOBAL.CURRENT_BRANCH);
    */
    --Get Nostro Account Branch for the offset leg
    BEGIN
      SELECT BRANCH_CODE
        INTO pkg_detb_rtl_teller_rec.ofs_branch
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = pkg_detb_rtl_teller_rec.ofs_acc;
    EXCEPTION
      WHEN OTHERS THEN
        pkg_detb_rtl_teller_rec.ofs_branch := '991';
    END;
  
    -- Begin ACCOUNTING ENTRIES Display and fix for Wrong Exch calculation
    IF p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy <> l_cust_ac.ccy THEN
      l_rate     := NULL;
      l_txn_amt1 := p_ifdbongl.v_iftb_bongluy_pay_master.txn_amt;
    
      If l_prod.rate_code_preferred = 'B' Then
        l_rate_code := Null;
        If (p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy = global.lcy and
           l_cust_ac.ccy != global.lcy) Or
           (p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy != global.lcy and
           l_cust_ac.ccy <> global.lcy and
           p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy <> l_cust_ac.ccy) Then
          l_rate_code := 'B';
        Elsif p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy != global.lcy and
              l_cust_ac.ccy = global.lcy Then
          l_rate_code := 'S';
        Else
          l_rate_code := l_prod.rate_code_preferred;
        End If;
      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;
    
      dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
          l_rate_code1);
      If l_cust_ac.ccy <> global.lcy Then
        begin
          select decode(l_rate_code,
                        'B',
                        'S',
                        'S',
                        'B',
                        'M',
                        'M',
                        l_rate_code)
            Into l_rate_code1
            from dual;
        exception
          when others then
            dbg('Exception found l_rate_code-> ' || l_rate_code);
        end;
      End If;
      dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
          l_rate_code1);
    
      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy,
                                    l_cust_ac.ccy,
                                    l_txn_amt1,
                                    p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    END IF;
    dbg('l_txn_amt1->' || l_txn_amt1);
    dbg('l_txn_amt1->' || l_txn_amt);
    pkg_detb_rtl_teller_rec.txn_amount := l_txn_amt;
    -- END
  
    pkg_detb_rtl_teller_rec.txn_trn_code := l_arc_maint.cod_main_txn_code;
    pkg_detb_rtl_teller_rec.ofs_trn_code := l_arc_maint.cod_offset_txn_code;
  
    IF l_cust_ac.ccy <>
       p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY THEN
    
      pkg_detb_rtl_teller_rec.exch_rate := p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate;
    
    ELSE
    
      pkg_detb_rtl_teller_rec.exch_rate := 1;
    
    END IF;
  
    pkg_detb_rtl_teller_rec.trn_dt           := GLOBAL.APPLICATION_dATE;
    pkg_detb_rtl_teller_rec.value_dt         := GLOBAL.APPLICATION_dATE;
    pkg_detb_rtl_teller_rec.rel_customer     := l_cust_ac.cust_no;
    pkg_detb_rtl_teller_rec.benef_name       := l_cust.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := l_cust.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := l_cust.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := l_cust.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := l_cust.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := GLOBAL.application_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := GLOBAL.USER_ID;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdbongl.v_iftb_bongluy_pay_master.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdbongl.v_iftb_bongluy_pay_master.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdbongl.v_iftb_bongluy_pay_master.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdbongl.v_iftb_bongluy_pay_master.mod_no;
    pkg_detb_rtl_teller_rec.scode            := 'FLEXCUBE';
    pkg_detb_rtl_teller_rec.dr_acc           := l_arc_maint.dr_acc;
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;
  
    dbg('Calling depks_rtl_teller.fn_save');
  
    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      RETURN FALSE;
    END IF;
    dbg('Calling depks_rtl_teller.pr_messaging');
    --depks_rtl_teller.pr_messaging;
  
    dbg('Returning Success From FN_SAVE..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.FN_SAVE ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_save;

  FUNCTION fn_process_entries(p_ifdbongl  IN OUT ifpks_ifdbongl_main.ty_ifdbongl,
                              p_action    CHAR,
                              p_errcode   IN OUT VARCHAR2,
                              p_errparams IN OUT VARCHAR2) RETURN BOOLEAN IS
    CURSOR cur_acc IS
      SELECT t.trn_ref_no, t.event_sr_no, t.ac_ccy, t.ac_branch, t.user_id
        FROM actb_daily_log t, iftb_bongluy_pay_master t1
       WHERE t.trn_ref_no = t1.trn_ref_no
         AND t.trn_ref_no = p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no
         AND t.event_sr_no = 1
         AND t.auth_stat <> 'A';
    i           NUMBER := 0;
    l_terminate BOOLEAN := FALSE;
  BEGIN
    dbg('In fn_process_entries with ' ||
        p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no || '~~~' ||
        p_action);
    IF p_action NOT IN ('D', 'A') THEN
      dbg('Action code not in Delete or Auth...Return TRUE now');
      RETURN TRUE;
    END IF;
    FOR c1 IN cur_acc LOOP
      i := 0;
      IF acpkss.fn_acservice(c1.ac_branch,
                             global.application_date,
                             global.lcy,
                             c1.trn_ref_no,
                             c1.event_sr_no,
                             p_action,
                             GLOBAL.USER_ID,
                             p_errcode,
                             p_errparams) THEN
        dbg('SUCCESS - ' || c1.trn_ref_no);
      ELSE
        dbg('ERROR - ' || c1.trn_ref_no || SQLERRM);
        dbg('ERROR - ' || p_errcode || '~~~' || p_errparams);
        l_terminate := TRUE;
        dbg('After setting l_terminate to TRUE and leave the LOOP');
        EXIT;
      END IF;
      UPDATE detbs_rtl_teller
         SET auth_stat        = 'A',
             checker_id       = global.user_id,
             checker_dt_stamp = csfn_timestamp,
             record_stat      = decode(record_stat, 'O', 'A', record_stat),
             mod_no           = 1
       WHERE trn_ref_no = c1.trn_ref_no;
    
      i := i + 1;
      dbg('COUNT-->' || i);
    END LOOP;
    IF NOT l_terminate THEN
      dbg('AUTH is fine...Return TRUE now ');
      RETURN TRUE;
    ELSE
      dbg('AUTH is NOT fine...Return FALSE now ');
      RETURN FALSE;
    END IF;
    dbg('Leaving fn_process_entries now....');
  END fn_process_entries;

  FUNCTION fn_msg_upload(p_source      IN VARCHAR2,
                         p_function_id IN VARCHAR2,
                         p_ifdbongl    IN OUT ifpks_ifdbongl_main.ty_ifdbongl,
                         P_REQ_TYPE    IN VARCHAR2,
                         P_REQ_MSG     IN OUT CLOB,
                         P_ADDL_INFO   IN VARCHAR2,
                         p_err_code    IN OUT VARCHAR2,
                         p_err_params  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
  
    L_IN_RESP CLOB;
    E_UPDATE_ERROR EXCEPTION;
    L_STATUS_CODE VARCHAR2(100);
    L_STATUS_MSG  VARCHAR2(100);
  
    L_RESP_IN_XML    CLOB;
    P_DOCUMENT_XML   XMLTYPE;
    L_ENQUIRY_ID     IFTB_BONGLUY_PAY_MASTER.ENQUIRY_NO%TYPE;
    L_BONGLUY_PAY_ID IFTB_BONGLUY_PAY_MASTER.BONGLUY_PAYMENT_ID%TYPE;
    L_GEN_SEQ_NO     VARCHAR2(100);
  
  BEGIN
    dbg('Inside fn_msg_upload - inserting to iftbs_pgw_msgs');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
  
    --Log Webservice Call
    PR_INSERT_BONGLUY_WS_LOG(L_GEN_SEQ_NO,
                             p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no,
                             SYSDATE,
                             p_ifdbongl.v_iftb_bongluy_pay_master.bongluy_acc_no,
                             P_REQ_TYPE,
                             P_REQ_MSG,
                             P_ADDL_INFO);
  
    IF NOT FN_BONGLUY_WS_CALL(P_REQ_TYPE, P_REQ_MSG, L_IN_RESP) THEN
      DBG('FAILED TO CALL WEBSERVICE CALL');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('SENT AND RESPONSE IN JSON IS ' || L_IN_RESP);
  
    --Get JSON in XML
    L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
    DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
    DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
  
    L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
    DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
  
    DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
  
    P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
  
    L_STATUS_CODE := P_DOCUMENT_XML.EXTRACT('/root/errorCode/text()')
                     .GETSTRINGVAL;
  
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/root/errorMessage/text()')
                    .GETSTRINGVAL;
  
    DBG('L_STATUS_CODE =' || L_STATUS_CODE);
    DBG('L_STATUS_MSG =' || L_STATUS_MSG);
  
    IF L_STATUS_CODE = 'ERROR_500' THEN
    
      dbg('BONGLUY SYSTEM IS DOWN');
    
      p_err_code := 'IF-RFT-017';
    
      pr_log_error('IFDBONGL', 'FLEXCUBE', p_err_code, NULL);
    
      RETURN FALSE;
    
    END IF;
  
    --Handle All Errro Codes ad return false
  
    IF P_REQ_TYPE = 'I' THEN
    
      IF L_STATUS_CODE = 'SUCCESS' AND L_STATUS_MSG = 'SUCCESS' THEN
      
        L_ENQUIRY_ID := P_DOCUMENT_XML.EXTRACT('/root/data/inqiury_no/text()')
                        .GETSTRINGVAL;
      
        DBG('L_ENQUIRY_ID =' || L_ENQUIRY_ID);
      
        L_BONGLUY_PAY_ID := P_DOCUMENT_XML.EXTRACT('/root/data/bongloy_payment_id/text()')
                            
                            .GETSTRINGVAL;
      
        DBG('L_BONGLUY_PAY_ID =' || L_BONGLUY_PAY_ID);
      
        PR_UPDATE_BONGLUY_WS_LOG(p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no,
                                 L_GEN_SEQ_NO,
                                 L_ENQUIRY_ID,
                                 L_BONGLUY_PAY_ID,
                                 'S',
                                 L_IN_RESP);
      
      ELSE
      
        PR_UPDATE_BONGLUY_WS_LOG(p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no,
                                 L_GEN_SEQ_NO,
                                 L_ENQUIRY_ID,
                                 L_BONGLUY_PAY_ID,
                                 'F',
                                 L_IN_RESP);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    IF P_REQ_TYPE = 'C' THEN
    
      IF L_STATUS_CODE = 'SUCCESS' AND L_STATUS_MSG = 'SUCCESS' THEN
      
        L_BONGLUY_PAY_ID := P_DOCUMENT_XML.EXTRACT('/root/data/bongloy_payment_id/text()')
                            
                            .GETSTRINGVAL;
      
        DBG('L_BONGLUY_PAY_ID =' || L_BONGLUY_PAY_ID);
      
        PR_UPDATE_BONGLUY_WS_LOG(p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no,
                                 L_GEN_SEQ_NO,
                                 NULL, --L_ENQUIRY_ID,
                                 L_BONGLUY_PAY_ID,
                                 'S',
                                 L_IN_RESP);
      
        RETURN TRUE;
      
      ELSE
      
        PR_UPDATE_BONGLUY_WS_LOG(p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no,
                                 L_GEN_SEQ_NO,
                                 NULL, --L_ENQUIRY_ID,
                                 L_BONGLUY_PAY_ID,
                                 'F',
                                 L_IN_RESP);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  FUNCTION fn_enrich_product(p_ifdbongl   IN OUT ifpks_ifdbongl_main.ty_ifdbongl,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no    VARCHAR2(16);
    l_trn_ref_no   iftb_bongluy_pay_master.trn_ref_no%TYPE;
    l_ty_rtupld    depks_retailtellerupload.typ_retailtellerupld_rec;
    l_ret          BOOLEAN;
    l_tot_chg_amt  NUMBER(22, 3);
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_prod         cstm_product%ROWTYPE;
    l_rate         NUMBER;
    l_rate_flag    NUMBER;
    l_ccy1         iftb_bongluy_pay_master.txn_ccy%TYPE;
    l_ccy2         iftb_bongluy_pay_master.txn_ccy%TYPE;
  
    l_tot_chg_amount            iftb_bongluy_pay_master.net_txn_amt%TYPE;
    l_txn_amt                   iftb_bongluy_pay_master.txn_amt%TYPE;
    l_txn_amt1                  iftb_bongluy_pay_master.txn_amt%TYPE;
    l_rate_code                 cstm_product.rate_code_preferred%Type;
    l_rate_code1                cstm_product.rate_code_preferred%Type;
    l_tot_chg_amt_in_txn_ccy    iftb_bongluy_pay_master.txn_amt%TYPE;
    l_tot_chg_amt_in_lcy_ccy    iftb_bongluy_pay_master.txn_amt%TYPE;
    l_arc_rate_code_type        iftm_arc_maint.cod_rate_code%Type;
    l_tot_chg_amount_in_txn_ccy iftb_bongluy_pay_master.txn_amt%TYPE;
    l_tot_chg_amount_in_acc_ccy iftb_bongluy_pay_master.txn_amt%TYPE;
    L_STTB_ACCOUNT              STTB_ACCOUNT%ROWTYPE;
    L_STTM_CUST_ACCOUNT         STTM_CUST_ACCOUNT%ROWTYPE;
  
    L_FORMATTED_MSG CLOB;
    L_MSG_TYPE      VARCHAR2(100);
    L_ADDL_INFO     VARCHAR2(100);
  
  BEGIN
  
    dbg('In FN_ENRICH_PRODUCT');
  
    --Get Account details
    BEGIN
      SELECT *
        INTO L_STTB_ACCOUNT
        FROM STTB_ACCOUNT
       WHERE AC_GL_NO = p_ifdbongl.v_iftb_bongluy_pay_master.cust_ac_no;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_STTB_ACCOUNT := NULL;
        DBG('FAILED IN GETTING ACCOUNT DETAILS');
    END;
  
    --Get Account details
    BEGIN
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = p_ifdbongl.v_iftb_bongluy_pay_master.cust_ac_no;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
        DBG('FAILED IN GETTING ACCOUNT DETAILS');
    END;
  
    IF L_STTB_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
      dbg('Account Status is Dormant');
      p_err_code   := 'AC-VAC33';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;
  
    IF L_STTB_ACCOUNT.AC_STAT_NO_DR = 'Y' THEN
      dbg('Account Status is No Debit');
      p_err_code   := 'AC-VAC07';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;
  
    IF L_STTM_CUST_ACCOUNT.RECORD_STAT = 'C' THEN
      dbg('Account is Closed');
      p_err_code   := 'AC-VAC12';
      p_err_params := L_STTM_CUST_ACCOUNT.CUST_AC_NO;
      RETURN FALSE;
    END IF;
  
    IF L_STTB_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
      dbg('Account Status is Frozen');
      p_err_code   := 'AC-VAC04';
      p_err_params := 'Status';
      RETURN FALSE;
    END IF;
  
    IF p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy IS NULL THEN
      dbg('Mandatory Fields Transaction Currency cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Transaction Currency';
      RETURN FALSE;
    END IF;
    IF p_ifdbongl.v_iftb_bongluy_pay_master.txn_amt IS NULL THEN
      dbg('Mandatory Fields Transaction Amount cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Transaction Amount';
      RETURN FALSE;
    END IF;
    IF p_ifdbongl.v_iftb_bongluy_pay_master.cust_ac_no IS NULL THEN
      dbg('Mandatory Fields Remitter Account cannot be null');
      p_err_code   := 'DV-DVRT-01';
      p_err_params := 'Remitter Account';
      RETURN FALSE;
    END IF;
  
    -- reference no
    IF p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(GLOBAL.CURRENT_BRANCH,
                                         'BLOT',
                                         GLOBAL.APPLICATION_DATE,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no := l_trn_ref_no;
      
      END IF;
    END IF;
  
    -- charge pickup
    SELECT x.* INTO l_prod FROM cstm_product x WHERE product_code = 'BLOT';
  
    SELECT cust_no, ccy
      INTO l_rel_customer, l_ac_ccy
      FROM sttm_cust_account
     WHERE cust_ac_no = p_ifdbongl.v_iftb_bongluy_pay_master.cust_ac_no;
  
    If l_prod.rate_code_preferred = 'B' Then
      l_rate_code := Null;
      If (p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy = global.lcy and
         l_ac_ccy != global.lcy) OR
         (p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy != global.lcy and
         l_ac_ccy <> global.lcy and
         p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy <> l_ac_ccy) Then
        l_rate_code := 'B';
      
      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;
    Else
      l_rate_code := l_prod.rate_code_preferred;
    End If;
    dbg('p_ifdbongl.v_iftbs_pgw_master_custom.txn_amt->' ||
        p_ifdbongl.v_iftb_bongluy_pay_master.txn_amt);
  
    dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
  
    If l_ac_ccy <> global.lcy Then
      begin
        select decode(l_rate_code,
                      'B',
                      'S',
                      'S',
                      'B',
                      'M',
                      'M',
                      l_rate_code)
          Into l_rate_code1
          from dual;
      exception
        when others then
          dbg('Exception found l_rate_code-> ' || l_rate_code);
      end;
    End If;
    dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
    dbg('l_txn_amt l_txn_amt l_txn_amt=' || l_txn_amt);
    -- Total Txn amount in remitter currency
    IF p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy <> l_ac_ccy THEN
      l_rate := NULL;
      --l_charge_amt := NULL;
      l_txn_amt1 := p_ifdbongl.v_iftb_bongluy_pay_master.txn_amt;
    
      -- xrate
      IF p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy <> l_ac_ccy THEN
      
        IF p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy = global.lcy THEN
          l_ccy1 := l_ac_ccy;
          l_ccy2 := p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy;
        ELSE
          l_ccy1 := p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy;
          l_ccy2 := l_ac_ccy;
        END IF;
        dbg('l_rate_code->' || l_rate_code || 'l_prod.rate_type_preferred' ||
            l_prod.rate_type_preferred);
        dbg('Before p_ifdbongl.v_iftbs_pgw_master_custom.exch_rate->' ||
            p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate);
      
        If (p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy != global.lcy and
           l_ac_ccy <> global.lcy and
           p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy <> l_ac_ccy) and
           l_prod.rate_code_preferred = 'B' Then
          l_rate_code := 'S';
        End If;
      
        dbg('l_rate_code->' || l_rate_code);
      
        dbg('l_prod.rate_type_preferred=' || l_prod.rate_type_preferred);
      
        IF NOT cypkss.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                 l_ccy2,
                                 l_ccy1, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 l_prod.rate_type_preferred,
                                 l_rate_code, --l_prod.rate_code_preferred,
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate,
                                 l_rate_flag,
                                 p_err_code) THEN
          dbg('Failed in Fn_GetRate');
          RETURN FALSE;
        END IF;
      ELSE
        p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate := 1;
      END IF;
    
      DBG('p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate==' ||
          p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate);
    
      --Using above rate..convert khr to usd amount
      IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy,
                                    l_ac_ccy,
                                    l_txn_amt1,
                                    p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    -- Net DB Amount (Charges + Txn amount)
    If p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy <> l_ac_ccy Then
      dbg('apple');
      p_ifdbongl.v_iftb_bongluy_pay_master.net_txn_amt := nvl(l_txn_amt, 0);
    
    Elsif p_ifdbongl.v_iftb_bongluy_pay_master.txn_ccy = l_ac_ccy Then
      dbg('mango');
      p_ifdbongl.v_iftb_bongluy_pay_master.net_txn_amt := nvl(p_ifdbongl.v_iftb_bongluy_pay_master.txn_amt,
                                                              0);
    
    End If;
  
    dbg('p_ifdbongl.v_iftb_bongluy_pay_master.net_txn_amt->' ||
        p_ifdbongl.v_iftb_bongluy_pay_master.net_txn_amt);
  
    IF p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY <> l_ac_ccy THEN
    
      l_rate := NULL;
    
      l_txn_amt1 := p_ifdbongl.v_iftb_bongluy_pay_master.txn_amt;
    
      -- xrate
      IF p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY <> l_ac_ccy THEN
      
        IF p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY =
           global.lcy THEN
          l_ccy1 := l_ac_ccy;
          l_ccy2 := p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY;
        ELSE
          l_ccy1 := p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY;
          l_ccy2 := l_ac_ccy;
        END IF;
        dbg('l_rate_code->' || l_rate_code || 'l_prod.rate_type_preferred' ||
            l_prod.rate_type_preferred);
        dbg('Before p_ifdbongl.v_iftbs_pgw_master_custom.exch_rate->' ||
            p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate);
      
        If (p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY !=
           global.lcy and l_ac_ccy <> global.lcy and p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY <>
           l_ac_ccy) and l_prod.rate_code_preferred = 'B' Then
          l_rate_code := 'S';
        End If;
      
        dbg('l_rate_code->' || l_rate_code);
      
        dbg('l_prod.rate_type_preferred=' || l_prod.rate_type_preferred);
      
        IF NOT cypkss.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                 l_ccy2,
                                 l_ccy1, --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                 l_prod.rate_type_preferred,
                                 l_rate_code, --l_prod.rate_code_preferred,
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate,
                                 l_rate_flag,
                                 p_err_code) THEN
          dbg('Failed in Fn_GetRate');
          RETURN FALSE;
        END IF;
      ELSE
        p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate := 1;
      END IF;
    
      DBG('p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate==' ||
          p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate);
    
      --Using above rate..convert khr to usd amount
      IF NOT cypkss.FN_AMT1_TO_AMT2(l_ac_ccy,
                                    p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY,
                                    p_ifdbongl.v_iftb_bongluy_pay_master.NET_TXN_AMT,
                                    p_ifdbongl.v_iftb_bongluy_pay_master.exch_rate,
                                    'Y',
                                    l_txn_amt,
                                    p_err_params) THEN
        RETURN FALSE;
      END IF;
    
      DBG('l_txn_amt==' || l_txn_amt);
    
      -- Net DB Amount (Charges + Txn amount)
      If p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY <> l_ac_ccy Then
        dbg('apple');
        p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_CASHIN_AMT := nvl(l_txn_amt,
                                                                       0);
      
      Elsif p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_ACC_CCY = l_ac_ccy Then
        dbg('mango');
        p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_CASHIN_AMT := nvl(p_ifdbongl.v_iftb_bongluy_pay_master.txn_amt,
                                                                       0);
      
      End If;
    
      dbg('p_ifdbongl.v_iftb_bongluy_pay_master.net_txn_amt->' ||
          p_ifdbongl.v_iftb_bongluy_pay_master.net_txn_amt);
    
    ELSE
    
      p_ifdbongl.v_iftb_bongluy_pay_master.BONGLUY_CASHIN_AMT := p_ifdbongl.v_iftb_bongluy_pay_master.net_txn_amt;
    
    END IF;
  
    dbg('Returning Success From FN_ENRICH_PRODUCT..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_enrich_product;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdbongl         IN OUT ifpks_ifdbongl_Main.ty_ifdbongl,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdbongl_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdbongl         IN OUT ifpks_ifdbongl_Main.Ty_ifdbongl,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    l_detb_rtl_teller_rec detb_rtl_teller%ROWTYPE;
    l_out_msg             CLOB;
    L_REQ_TYPE            CHAR(1);
    L_FORMATTED_MSG       CLOB;
    E_UPDATE_ERROR EXCEPTION;
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    dbg('p_Action_Code' || p_action_code);
  
    IF p_action_code = 'PICKUP' THEN
    
      IF NOT fn_enrich_product(p_ifdbongl, p_err_code, p_err_params) THEN
        dbg('Failed in Fn_Enrich_Product');
        RETURN FALSE;
      END IF;
    
      --Get Bongluy Account Enquiry      
      L_FORMATTED_MSG := FN_GET_FMT_BONGLUY_ACC_ENQ(P_IFDBONGL);
    
      DBG('AFTER REPLACEMENT OF BONGLUY ACC ENQUIRY JSON=' ||
          L_FORMATTED_MSG);
    
      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
    
      DBG('CALLING BONGLUY ACCOUNT ENQUIRY WEBSERVICE');
    
      IF NOT FN_MSG_UPLOAD(P_SOURCE,
                           P_FUNCTION_ID,
                           P_IFDBONGL,
                           'I',
                           L_FORMATTED_MSG,
                           'Account Enquiry Call',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      
        DBG('FAILED IN ACCOUNT ENQUIRY CALL');
      
        RETURN FALSE;
      
      ELSE
      
        DBG('SUCCESS IN ACCOUNT ENQUIRY CALL');
      
      END IF;
    
    END IF;
  
    --Save Transaction
    IF p_action_code = cspks_req_global.p_new THEN
      IF NOT fn_save(p_ifdbongl,
                     l_detb_rtl_teller_rec,
                     p_err_code,
                     p_err_params) THEN
        dbg('Failed in FN_SAVE');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Modify Transaction
    IF p_action_code = cspks_req_global.p_modify THEN
      dbg('Voila 2');
    
      IF NOT depks_rtl_teller.fn_delete(p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in modify fn_delete');
        RETURN FALSE;
      END IF;
    
      IF NOT fn_save(p_ifdbongl,
                     l_detb_rtl_teller_rec,
                     p_err_code,
                     p_err_params) THEN
        dbg('Failed in modify fn_save');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Delete Transaction
    IF p_action_code = cspks_req_global.p_delete THEN
      IF NOT depks_rtl_teller.fn_delete(p_ifdbongl.v_iftb_bongluy_pay_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in FN_DELETE');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Auth Transaction
    IF p_action_code = cspks_req_global.p_auth THEN
    
      DBG('p_ifdbongl.v_iftb_bongluy_pay_master.MAKER_ID=' ||
          p_ifdbongl.v_iftb_bongluy_pay_master.MAKER_ID);
    
      DBG('p_ifdbongl.v_iftb_bongluy_pay_master.CHECKER_ID=' ||
          p_ifdbongl.v_iftb_bongluy_pay_master.CHECKER_ID);
    
      DBG('GLOBAL.USER_ID' || GLOBAL.USER_ID);
    
      --Maker Can not authorize
      IF p_ifdbongl.v_iftb_bongluy_pay_master.MAKER_ID = GLOBAL.USER_ID THEN
        pr_log_error(p_function_id, p_source, 'CF-AUT-002', NULL);
        RETURN FALSE;
      END IF;
    
      --Generate Fast Outgoing message
      /*IF NOT fn_fast_out_msg_gen(p_ifdbongl,
                                 l_out_msg,
                                 p_err_code,
                                 p_err_params) THEN
        dbg('Failed in FN_FAST_OUT_MSG_GEN');
        RETURN FALSE;
      END IF;*/
    
      dbg(' Message generation success, going to upload now');
    
      --Get Bongluy Account Enquiry      
      L_FORMATTED_MSG := FN_GET_FMT_BONGLUY_PAYMENT(P_IFDBONGL);
    
      DBG('AFTER REPLACEMENT OF BONGLUY PAYMENT JSON=' || L_FORMATTED_MSG);
    
      DBG('FINAL JSON CONTENT=' || L_FORMATTED_MSG);
    
      DBG('CALLING BONGLUY PAYMENT WEBSERVICE');
    
      IF NOT FN_MSG_UPLOAD(P_SOURCE,
                           P_FUNCTION_ID,
                           P_IFDBONGL,
                           'C',
                           L_FORMATTED_MSG,
                           'Payment Confirmation Call',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      
        DBG('FAILED IN BONGLUY PAYMENT CALL');
      
        RETURN FALSE;
      
      ELSE
      
        DBG('SUCCESS IN BONGLUY PAYMENT CALL');
      
        --Call getOutgoingTransaction API call
        IF NOT fn_process_entries(p_ifdbongl, 'A', p_err_code, p_err_params) THEN
          dbg('Fail in AUTH accounting entries');
          RAISE e_update_error;
        END IF;
      
      END IF;
    
      dbg('fn_msg_upload successful');
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdbongl         IN ifpks_ifdbongl_Main.ty_ifdbongl,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdbongl         IN ifpks_ifdbongl_Main.ty_ifdbongl,
                                       p_Prev_ifdbongl    IN OUT ifpks_ifdbongl_Main.ty_ifdbongl,
                                       p_Wrk_ifdbongl     IN OUT ifpks_ifdbongl_Main.ty_ifdbongl,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdbongl         IN ifpks_ifdbongl_Main.Ty_ifdbongl,
                                        p_Prev_ifdbongl    IN OUT ifpks_ifdbongl_Main.Ty_ifdbongl,
                                        p_Wrk_ifdbongl     IN OUT ifpks_ifdbongl_Main.Ty_ifdbongl,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdbongl         IN ifpks_ifdbongl_Main.Ty_ifdbongl,
                            p_Prev_ifdbongl    IN ifpks_ifdbongl_Main.Ty_ifdbongl,
                            p_Wrk_ifdbongl     IN OUT ifpks_ifdbongl_Main.Ty_ifdbongl,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdbongl         IN ifpks_ifdbongl_Main.Ty_ifdbongl,
                             p_prev_ifdbongl    IN ifpks_ifdbongl_Main.Ty_ifdbongl,
                             p_wrk_ifdbongl     IN OUT ifpks_ifdbongl_Main.Ty_ifdbongl,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdbongl         IN ifpks_ifdbongl_Main.Ty_ifdbongl,
                        p_Wrk_ifdbongl     IN OUT ifpks_ifdbongl_Main.Ty_ifdbongl,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdbongl_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdbongl         IN ifpks_ifdbongl_Main.ty_ifdbongl,
                         p_wrk_ifdbongl     IN OUT ifpks_ifdbongl_Main.ty_ifdbongl,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdbongl_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdbongl_custom;
