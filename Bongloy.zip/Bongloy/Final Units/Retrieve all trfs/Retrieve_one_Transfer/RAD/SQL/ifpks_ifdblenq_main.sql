CREATE OR REPLACE PACKAGE BODY ifpks_ifdblenq_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : ifpks_ifdblenq_main.sql
     **
     ** Module     : Interfaces
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_ifdblenq         ifpks_ifdblenq_Main.ty_ifdblenq;
   g_Ui_Name            VARCHAR2(50) := 'IFDBLENQ';
   g_Req_Key                 VARCHAR2(32767);
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'ifpks_ifdblenq_Main ==>'||p_Msg;
         Debug.Pr_Debug('IF' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'IFDBLENQ';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      ifpks_ifdblenq_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdblenq       IN   OUT ifpks_ifdblenq_Main.ty_ifdblenq,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_TXN_DETAILS' THEN
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD1 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD2 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD3 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.NUM_FIELD1 := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_ifdblenq.v_cstb_ui_columns.DATE_FIELD2 := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_ifdblenq.v_cstb_ui_columns.DATE_FIELD2 := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD4 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD5 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD6 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD7 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD8 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD10 := Cspks_Req_Global.Fn_GetVal;
            p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD11 := Cspks_Req_Global.Fn_GetVal;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
               p_ifdblenq.v_cstb_ui_columns.DATE_FIELD1 := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
            ELSE
               p_ifdblenq.v_cstb_ui_columns.DATE_FIELD1 := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
            END IF;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_ifdblenq.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdblenq_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdblenq       IN   OUT ifpks_ifdblenq_Main.ty_ifdblenq,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_TXN_DETAILS','Txn-Details-Full','Txn-Details-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'CHAR_FIELD1' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD1 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD2' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD2 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD3' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD3 := l_Val;
               ELSIF l_Key = 'NUM_FIELD1' THEN
                  p_ifdblenq.v_cstb_ui_columns.NUM_FIELD1 := l_Val;
               ELSIF l_Key = 'DATE_FIELD2' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_ifdblenq.v_cstb_ui_columns.DATE_FIELD2 := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_ifdblenq.v_cstb_ui_columns.DATE_FIELD2 := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               ELSIF l_Key = 'CHAR_FIELD4' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD4 := l_Val;
               ELSIF l_Key IN( 'TXNSTS','CHAR_FIELD5')  THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD5 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD6' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD6 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD7' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD7 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD8' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD8 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD10' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD10 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD11' THEN
                  p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD11 := l_Val;
               ELSIF l_Key = 'DATE_FIELD1' THEN
                  BEGIN
                     IF Length(l_Val) > Length(Cspks_Req_Global.g_Date_Format) THEN
                        p_ifdblenq.v_cstb_ui_columns.DATE_FIELD1 := TO_DATE(l_val,Cspks_Req_Global.g_Date_Time_Format);
                     ELSE
                        p_ifdblenq.v_cstb_ui_columns.DATE_FIELD1 := TO_DATE(l_val,Cspks_Req_Global.g_Date_Format);
                     END IF;
                  EXCEPTION
                     WHEN OTHERS THEN
                        RAISE Invalid_Date;
                  END;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_ifdblenq.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdblenq_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdblenq          IN ifpks_ifdblenq_Main.ty_ifdblenq,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_TXN_DETAILS',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD1',p_ifdblenq.v_cstb_ui_columns.char_field1);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD2',p_ifdblenq.v_cstb_ui_columns.char_field2);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD3',p_ifdblenq.v_cstb_ui_columns.char_field3);
      Cspks_Req_Global.Pr_Write('V','NUM_FIELD1',p_ifdblenq.v_cstb_ui_columns.num_field1);
      IF trunc(p_ifdblenq.v_cstb_ui_columns.date_field2) <>
            p_ifdblenq.v_cstb_ui_columns.date_field2 THEN
         l_Date_Val :=  TO_CHAR( p_ifdblenq.v_cstb_ui_columns.date_field2,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_ifdblenq.v_cstb_ui_columns.date_field2,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','DATE_FIELD2',l_Date_Val);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD4',p_ifdblenq.v_cstb_ui_columns.char_field4);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD5',p_ifdblenq.v_cstb_ui_columns.char_field5);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD6',p_ifdblenq.v_cstb_ui_columns.char_field6);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD7',p_ifdblenq.v_cstb_ui_columns.char_field7);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD8',p_ifdblenq.v_cstb_ui_columns.char_field8);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD10',p_ifdblenq.v_cstb_ui_columns.char_field10);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD11',p_ifdblenq.v_cstb_ui_columns.char_field11);
      IF trunc(p_ifdblenq.v_cstb_ui_columns.date_field1) <>
            p_ifdblenq.v_cstb_ui_columns.date_field1 THEN
         l_Date_Val :=  TO_CHAR( p_ifdblenq.v_cstb_ui_columns.date_field1,Cspks_Req_Global.g_Ws_Date_Time_Format);
      ELSE
         l_Date_Val :=  TO_CHAR( p_ifdblenq.v_cstb_ui_columns.date_field1,Cspks_Req_Global.g_Ws_Date_Format);
      END IF;
      Cspks_Req_Global.Pr_Write('V','DATE_FIELD1',l_Date_Val);
      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_ifdblenq          IN ifpks_ifdblenq_Main.ty_ifdblenq,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF (  p_ifdblenq.v_cstb_ui_columns.char_field1 IS NOT NULL 
          )
          THEN
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Txn-Details-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD1',p_ifdblenq.v_cstb_ui_columns.char_field1);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD2',p_ifdblenq.v_cstb_ui_columns.char_field2);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD3',p_ifdblenq.v_cstb_ui_columns.char_field3);
            Cspks_Req_Global.Pr_Write('V','NUM_FIELD1',p_ifdblenq.v_cstb_ui_columns.num_field1);
            IF trunc(p_ifdblenq.v_cstb_ui_columns.date_field2) <>
                  p_ifdblenq.v_cstb_ui_columns.date_field2 THEN
               l_Date_Val :=  TO_CHAR( p_ifdblenq.v_cstb_ui_columns.date_field2,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_ifdblenq.v_cstb_ui_columns.date_field2,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','DATE_FIELD2',l_Date_Val);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD4',p_ifdblenq.v_cstb_ui_columns.char_field4);
            Cspks_Req_Global.Pr_Write('V','TXNSTS',p_ifdblenq.v_cstb_ui_columns.char_field5);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD6',p_ifdblenq.v_cstb_ui_columns.char_field6);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD7',p_ifdblenq.v_cstb_ui_columns.char_field7);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD8',p_ifdblenq.v_cstb_ui_columns.char_field8);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD10',p_ifdblenq.v_cstb_ui_columns.char_field10);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD11',p_ifdblenq.v_cstb_ui_columns.char_field11);
            IF trunc(p_ifdblenq.v_cstb_ui_columns.date_field1) <>
                  p_ifdblenq.v_cstb_ui_columns.date_field1 THEN
               l_Date_Val :=  TO_CHAR( p_ifdblenq.v_cstb_ui_columns.date_field1,Cspks_Req_Global.g_Ws_Date_Time_Format);
            ELSE
               l_Date_Val :=  TO_CHAR( p_ifdblenq.v_cstb_ui_columns.date_field1,Cspks_Req_Global.g_Ws_Date_Format);
            END IF;
            Cspks_Req_Global.Pr_Write('V','DATE_FIELD1',l_Date_Val);
         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
         Cspks_Req_Global.pr_Write('P','Txn-Details-PK','1');
         l_Key_Cols := 'CHAR_FIELD1~';
         l_Key_Vals := p_ifdblenq.v_cstb_ui_columns.char_field1||'~';
         Cspks_Req_Global.pr_Write('V',l_Key_Cols,l_Key_Vals);
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_ifdblenq IN  ifpks_ifdblenq_Main.Ty_ifdblenq,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'CSTB_UI_COLUMNS.CHAR_FIELD1';
      IF p_ifdblenq.v_cstb_ui_columns.char_field1 IS Null THEN
         Dbg('Field char_field1 is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'CSTB_UI_COLUMNS';
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_ifdblenq     IN  ifpks_ifdblenq_Main.ty_ifdblenq,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_ifdblenq     IN  OUT ifpks_ifdblenq_Main.ty_ifdblenq,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_ifdblenq  IN   OUT ifpks_ifdblenq_Main.Ty_ifdblenq,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_ifdblenq     IN  ifpks_ifdblenq_Main.Ty_ifdblenq,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_ifdblenq IN  ifpks_ifdblenq_Main.Ty_ifdblenq,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_ifdblenq       IN   OUT ifpks_ifdblenq_Main.Ty_ifdblenq,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Build_Ws_Type..');

      IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
         IF NOT Fn_Sys_Build_Fc_Type(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_IFDBLENQ,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Fc_Type..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT Fn_Sys_Build_Ws_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_IFDBLENQ,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Ws_Type..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTTYPE');
      IF NOT ifpks_ifdblenq_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdblenq_Custom.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_IFDBLENQ,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in ifpks_ifdblenq_Custom.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Build_Type..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdblenq_Main.Fn_Build_Type ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Type;
   FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_exchange_pattern   IN  VARCHAR2,
      p_ifdblenq          IN ifpks_ifdblenq_Main.ty_ifdblenq,
      p_err_code        IN OUT VARCHAR2,
      p_err_params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

   BEGIN

      dbg('In Fn_Build_Ts_List..');

      IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
         IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_ifdblenq,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Fc_Ts');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            p_ifdblenq,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Ws_Ts');
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning from Fn_Build_Ts_List');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of ifpks_ifdblenq_Main.Fn_Build_Ts_List ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Build_Ts_List;
   FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_ifdblenq       IN  OUT ifpks_ifdblenq_Main.Ty_ifdblenq,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Key_Cols        VARCHAR2(32767);
      l_Key_Vals        VARCHAR2(32767);
      l_Func_Type       VARCHAR2(32767);
   BEGIN

      Dbg('In Fn_Get_Key_Information..');
      l_Key_Cols := 'CHAR_FIELD1~';
      l_Key_Vals := p_ifdblenq.v_cstb_ui_columns.char_field1||'~';
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
      IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code ,
         'OTHERS',
         'CSTB_UI_COLUMNS',
         'BLK_TXN_DETAILS',
         'Txn-Details',
         l_Key_Cols,
         l_Key_Vals,
         p_ifdblenq.Addl_Info,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
         RETURN FALSE;
      END IF;
      IF p_ifdblenq.Addl_Info.EXISTS('RECORD_KEY') THEN
         G_Req_Key :=  p_ifdblenq.Addl_Info('RECORD_KEY');
      END IF;
      Dbg('Returning Succsess From Fn_Get_Key_Information..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of ifpks_ifdblenq_Main.Fn_Get_Key_Information..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Key_Information;
   FUNCTION Fn_Rebuild_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
                              p_exchange_pattern  IN     VARCHAR2,
                              p_status            IN OUT VARCHAR2 ,
                              p_err_code          IN OUT VARCHAR2,
                              p_err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;

   BEGIN

      dbg('In Fn_Rebuild_Ts_List ');
      IF NOT  Fn_Build_Ts_List(p_source,
         p_source_operation,
         p_Function_id,
         p_action_code,
         p_exchange_pattern,
         g_ifdblenq,
         p_err_code,
         p_err_params)  THEN
         dbg('Failed in Fn_Build_Ts_List');
         p_status      := 'F';
         RETURN FALSE;
      END IF;
      dbg('Returning from Fn_Rebuild_Ts_List..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List');
         p_status        := 'F';
         dbg('Errors     :'||p_err_code);
         dbg('Parameters :'||p_err_params);
         RETURN TRUE;
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of Fn_Rebuild_Ts_List');
         debug.pr_debug('**',SQLERRM);
         p_status      := 'F';
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := Null;
         RETURN FALSE;
   END Fn_Rebuild_Ts_List;

   FUNCTION Fn_Main   (p_source            IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
                              p_multi_trip_id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_ifdblenq          IN OUT ifpks_ifdblenq_Main.ty_ifdblenq,
                              p_status            IN OUT VARCHAR2 ,
                              p_err_code          IN OUT VARCHAR2,
                              p_err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Post_Upl_Stat         VARCHAR2(1) :='A';
      E_Failure_Exception    EXCEPTION;
      E_Override_Exception    EXCEPTION;

   BEGIN

      dbg('In Fn_Main');

      SAVEPOINT Sp_Main_Ifdblenq;
      p_status := 'S';

      dbg('In fn_Main..');

      g_ifdblenq := p_ifdblenq;
      IF NOT ifpks_ifdblenq_Main.Fn_Skip_custom  THEN
         IF NOT ifpks_ifdblenq_Custom.Fn_Main (p_source,
                                    p_source_operation,
                                    p_Function_id ,
                                    p_action_code ,
                                    p_Function_id ,
                                    p_multi_trip_id ,
                                    p_Request_No ,
            p_ifdblenq,
                                    p_status ,
                                    p_err_code ,
                                    p_err_params) THEN
            dbg('Failed in Fn_Main..');
            RAISE e_Failure_Exception;
         END IF;
      END IF;
      IF p_status ='E' THEN
         Dbg('Raising Error Exception..');
         RAISE E_Failure_Exception;
      ELSIF p_status ='O' THEN
         Dbg('Raising Override Exception..');
         RAISE E_Override_Exception;
      END IF;
      g_ifdblenq := p_ifdblenq;
      dbg('Errors     :'||p_err_code);
      dbg('Parameters :'||p_err_params);

      dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         dbg('From E_Failure_Exception of Fn_Main');
         p_status        := 'E';
         l_Post_Upl_Stat := 'F';
         ROLLBACK TO Sp_Main_Ifdblenq;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_action_code,l_post_upl_stat,p_err_code,p_err_params);
         pr_log_error(p_source,p_err_code,p_err_params);
         dbg('Errors     :'||p_err_code);
         dbg('Parameters :'||p_err_params);
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         dbg('From E_Override_Exception of Fn_Main');
         p_status        := 'O';
         l_Post_Upl_Stat := 'O';
         IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
            Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
         END IF;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,p_action_code,l_post_upl_stat,p_err_code,p_err_params);
         pr_log_error(p_source,p_err_code,p_err_params);
         dbg('Errors     :'||p_err_code);
         dbg('Parameters :'||p_err_params);
         RETURN TRUE;

      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of Fn_Main ..');
         debug.pr_debug('**',SQLERRM);
         p_status      := 'E';
         ROLLBACK TO Sp_Main_Ifdblenq;
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := Null;
         RETURN FALSE;
   END Fn_Main;

   FUNCTION Fn_Process_Request (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
                              p_exchange_pattern  IN     VARCHAR2,
                              p_multi_trip_id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_addl_info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_status            IN OUT VARCHAR2 ,
                              p_err_code          IN OUT VARCHAR2,
                              p_err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_ifdblenq     ifpks_ifdblenq_Main.ty_ifdblenq;

   BEGIN

      dbg('In Fn_Process_Request ');
      IF NOT  Fn_Build_Type(p_source,
         p_source_operation,
         p_Function_id,
         p_action_code,
         p_addl_info,
         l_ifdblenq,
         p_err_code,
         p_err_params)  THEN
         dbg('Failed in Fn_Build_Type');
         p_status      := 'F';
         RETURN FALSE;
      END IF;
      IF NOT  Fn_Main(p_source,
         p_source_operation,
         p_Function_id,
         p_action_code,
         p_multi_trip_id,
         p_Request_No,
         l_ifdblenq,
         p_status,
         p_err_code,
         p_err_params)  THEN
         dbg('Failed in Fn_main');
         RETURN FALSE;
      END IF;

      p_addl_info := l_ifdblenq.Addl_Info;
      IF Cspks_Req_Global.Fn_Build_Resp THEN
         Cspks_Req_Global.Pr_Reset;
         IF NOT  Fn_Build_Ts_List(p_source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            l_ifdblenq,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Build_Ts_List');
            p_status      := 'F';
            RETURN FALSE;
         END IF;
         Cspks_Req_Global.Pr_Close_Ts;
      END IF;
      dbg('Returning from Fn_Process_Request..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of Fn_Process_Request');
         debug.pr_debug('**',SQLERRM);
         p_status      := 'F';
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := Null;
         RETURN FALSE;
   END Fn_Process_Request;

   FUNCTION Fn_Get_Node_Data (
      p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Cntr NUMBER := 0;
   BEGIN

      Dbg('In Fn_Get_Node_Data..');
      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_TXN_DETAILS';
      p_Node_Data(l_Cntr).Xsd_Node := 'Txn-Details';
      p_Node_Data(l_Cntr).Node_Parent := '';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'CHAR_FIELD1~CHAR_FIELD2~CHAR_FIELD3~NUM_FIELD1~DATE_FIELD2~CHAR_FIELD4~CHAR_FIELD5~CHAR_FIELD6~CHAR_FIELD7~CHAR_FIELD8~CHAR_FIELD10~CHAR_FIELD11~DATE_FIELD1~';
      p_Node_Data(l_Cntr).Node_Tags := 'CHAR_FIELD1~CHAR_FIELD2~CHAR_FIELD3~NUM_FIELD1~DATE_FIELD2~CHAR_FIELD4~TXNSTS~CHAR_FIELD6~CHAR_FIELD7~CHAR_FIELD8~CHAR_FIELD10~CHAR_FIELD11~DATE_FIELD1~';

      Dbg('Returning From Fn_Get_Node_Data.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of ifpks_ifdblenq_Main.Fn_Get_Node_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Node_Data;
END ifpks_ifdblenq_main;
/