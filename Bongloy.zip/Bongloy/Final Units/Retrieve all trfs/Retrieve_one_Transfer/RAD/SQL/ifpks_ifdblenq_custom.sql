CREATE OR REPLACE PACKAGE BODY ifpks_ifdblenq_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdblenq_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdblenq_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler');
  END Pr_Skip_Handler;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_RETURN_BONGLOY_TXN_STATUS RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
  
    DBG('SATRT OF FN_RETURN_BONGLOY_TXN_STATUS');
  
    L_FORMATTED_MSG := 'inquiry_no=$L_ENQUIRY_ID';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_BONGLOY_TXN_STATUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_BONGLOY_TXN_STATUS');
      DBG('ERROR CODE IN FN_RETURN_BONGLOY_TXN_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_BONGLOY_TXN_STATUS=' || SQLERRM);
    
  END FN_RETURN_BONGLOY_TXN_STATUS;

  FUNCTION FN_RETURN_FMT_TXN_STATUS(p_ifdblenq IN ifpks_ifdblenq_Main.Ty_ifdblenq)
    RETURN CLOB IS
  
    L_ENQUIRY_ID VARCHAR2(100);
  
    L_FORMATTED_MSG CLOB; --varchar2(4000);
  BEGIN
    DBG('SATRT OF FN_RETURN_FMT_TXN_STATUS');
  
    L_FORMATTED_MSG := FN_RETURN_BONGLOY_TXN_STATUS;
  
    DBG('BEFORE REPLACEMENT OF BONGLOY TXN STATUS JSON=' ||
        L_FORMATTED_MSG);
  
    --Replace tags with actual values  
    L_ENQUIRY_ID := p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD1;
  
    DBG('L_ENQUIRY_ID=' || L_ENQUIRY_ID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_ENQUIRY_ID',
                               L_ENQUIRY_ID);
  
    DBG('AFTER REPLACEMENT OF BONGLOY TXN STATUS JSON=' || L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_FMT_TXN_STATUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FMT_TXN_STATUS');
      DBG('ERROR CODE IN FN_RETURN_FMT_TXN_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FMT_TXN_STATUS=' || SQLERRM);
  END FN_RETURN_FMT_TXN_STATUS;

  PROCEDURE PR_INSERT_BONGLOY_WS_LOG(P_SEQ_NO     IN VARCHAR2,
                                     P_TRN_REF_NO IN VARCHAR2,
                                     P_DATE       IN DATE,
                                     P_REQ_TYPE   IN VARCHAR2,
                                     
                                     P_REQ_MSG   IN CLOB,
                                     P_ADDL_INFO IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_BONGLOY_WS_LOG');
  
    DBG('BEFORE INSERTING INTO PR_INSERT_BONGLOY_WS_LOG');
  
    INSERT INTO STTB_RFT_WS_LOG
      (SEQ_NO, TRN_REF_NO, INVOKE_DATE, REQ_TYPE, REQ_MSG, ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_TRN_REF_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       
       P_ADDL_INFO);
  
    COMMIT;
    DBG('END OF PR_INSERT_BONGLOY_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_BONGLOY_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_BONGLOY_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_BONGLOY_WS_LOG=' || SQLERRM);
    
  END PR_INSERT_BONGLOY_WS_LOG;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_BONGLOY_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  FUNCTION FN_BONGLOY_HTTP_CALL(p_out_msg VARCHAR2, p_in_resp IN OUT CLOB)
    RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob; --varchar2(32767);
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
  
  BEGIN
    dbg('START OF FN_BONGLOY_HTTP_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
  
    L_URL := FN_GET_PARAM_VAL('PGW_BONGLOY_ENQID_ENQ_URL');
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
  
    utl_http.set_authentication(l_http_request,
                                FN_GET_PARAM_VAL('PGW_BONGLOY_AUTH_UID'),
                                FN_GET_PARAM_VAL('PGW_BONGLOY_AUTH_PWD'),
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
    --utl_http.set_header(l_http_request, 'content-type', 'application/json');
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/x-www-form-urlencoded');
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    utl_http.set_transfer_timeout(300);
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('error line number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_BONGLOY_HTTP_CALL;

  FUNCTION FN_GET_TXN_STATUS_BY_ENQID(p_ifdblenq   IN OUT IFPKS_ifdblenq_MAIN.TY_ifdblenq,
                                      P_ERR_CODE   IN OUT VARCHAR2,
                                      P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_FORMATTED_MSG    CLOB;
    L_IN_RESP          CLOB;
    L_COSMETIC_RES_MSG CLOB;
    L_GEN_SEQ_NO       VARCHAR2(100);
    L_COUNT            NUMBER;
  
    P_DOCUMENT_XML  XMLTYPE;
    L_RESP_IN_XML   CLOB;
    L_RESPONSE_CODE IFTBS_RFT_MASTER.TXN_STATUS%TYPE;
    L_RESPONSE_MSG  VARCHAR2(32567);
  
    L_amount               number;
    L_currency             varchar2(3);
    L_status               varchar2(25);
    L_updated_at           varchar2(25);
    L_created_at           varchar2(25);
    L_bongloy_user_name    varchar2(100);
    L_bongloy_user_account varchar2(100);
    L_bongloy_payment_id   varchar2(100);
    L_txn_id               varchar2(100);
    L_others               varchar2(100);
  
  BEGIN
  
    DEBUG.PR_DEBUG('IF', 'START OF FN_GET_OUTGOING_TXN_BY_ID');
  
    --Get Txn Status API Message
    L_FORMATTED_MSG := FN_RETURN_FMT_TXN_STATUS(p_ifdblenq);
  
    DBG('AFTER REPLACEMENT OF TXN STATUS MSG=' || L_FORMATTED_MSG);
  
    --Log TXN STATUS Request of RFT
  
    DBG('LOGGING TXN STATUS REQUEST OF BONGLOU');
  
    L_GEN_SEQ_NO := FN_RETURN_SEQ_NO;
  
    PR_INSERT_BONGLOY_WS_LOG(L_GEN_SEQ_NO,
                             p_ifdblenq.v_cstb_ui_columns.char_field1,
                             SYSDATE,
                             'Get_Enq_ID_Stat',
                             L_FORMATTED_MSG,
                             'Get Enquiry ID Stat');
  
    IF NOT FN_BONGLOY_HTTP_CALL(L_FORMATTED_MSG, L_IN_RESP) THEN
    
      DBG('FAILED IN CALLING THE GET TXN STATUS API');
    
      RETURN FALSE;
    
    ELSE
    
      DBG('RESPONSE OF GET TXN STATUS IN JSON IS ' || L_IN_RESP);
    
      --Get JSON in XML
      L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
      DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
    
      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
      DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
    
      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
      DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
    
      DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
    
      P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
    
      L_RESPONSE_CODE := P_DOCUMENT_XML.EXTRACT('/root/errorCode/text()')
                         .GETSTRINGVAL;
    
      L_RESPONSE_MSG := P_DOCUMENT_XML.EXTRACT('/root/errorMessage/text()')
                        .GETSTRINGVAL;
    
      L_amount := P_DOCUMENT_XML.EXTRACT('/root/data/amount/text()')
                  .GETSTRINGVAL;
      
      dbg('L_amount='||L_amount);
      
      L_currency := P_DOCUMENT_XML.EXTRACT('/root/data/currency/text()')
                    .GETSTRINGVAL;
      
      dbg('L_currency='||L_currency);
      
      L_status := P_DOCUMENT_XML.EXTRACT('/root/data/status/text()')
                  .GETSTRINGVAL;
      
      dbg('L_status='||L_status);
      
      L_updated_at := P_DOCUMENT_XML.EXTRACT('/root/data/updated_at/text()')
                      .GETSTRINGVAL;
      
      dbg('L_updated_at='||L_updated_at);
      
      L_created_at := P_DOCUMENT_XML.EXTRACT('/root/data/created_at/text()')
                      .GETSTRINGVAL;
      
      dbg('L_created_at='||L_created_at);
      
      L_bongloy_user_name := P_DOCUMENT_XML.EXTRACT('/root/data/destination_account_holder_name/text()')
                             .GETSTRINGVAL;
      
      dbg('L_bongloy_user_name='||L_bongloy_user_name);
      
      L_bongloy_user_account := P_DOCUMENT_XML.EXTRACT('/root/data/destination_account_number/text()')
                                .GETSTRINGVAL;
      
      dbg('L_bongloy_user_account='||L_bongloy_user_account);
      
      L_bongloy_payment_id := P_DOCUMENT_XML.EXTRACT('/root/data/id/text()')
                              .GETSTRINGVAL;
      
      dbg('L_bongloy_payment_id='||L_bongloy_payment_id);
      
      L_txn_id := P_DOCUMENT_XML.EXTRACT('/root/data/id/text()')
                  .GETSTRINGVAL;
      
      dbg('L_txn_id='||L_txn_id);
      
      --L_others := P_DOCUMENT_XML.EXTRACT('/root/data/other/text()')
      --            .GETSTRINGVAL;
      
      dbg('L_others='||L_others);
      
      DBG('L_RESPONSE_CODE =' || L_RESPONSE_CODE);
      DBG('L_RESPONSE_MSG =' || L_RESPONSE_MSG);
    
      IF L_RESPONSE_CODE = 'ERROR_500' THEN
      
        dbg('Bongloy system is Down');
      
        p_err_code := 'IF-RFT-017';
      
        pr_log_error('IFDRFTPM', 'FLEXCUBE', p_err_code, NULL);
      
        RETURN FALSE;
      
      END IF;
    
      IF L_RESPONSE_CODE = 'ERROR_104' THEN
      
        dbg('There is no original transaction');
      
        p_err_code := 'IF-RFT-029';
      
        pr_log_error('IFDRFTXN', 'FLEXCUBE', p_err_code, NULL);
      
        RETURN FALSE;
      
      END IF;
    
      IF L_RESPONSE_CODE = 'SUCCESS' THEN
      
        DBG('SUCCESS IN CALLING ENQUIRY ID ENQUIRY API');
      
        --Updating Status in the master table
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD2 := L_RESPONSE_CODE;
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD3 := L_RESPONSE_MSG;
        
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD4 := L_currency;
        
      
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD5 := L_status;
        p_ifdblenq.v_cstb_ui_columns.DATE_FIELD1 := TO_TIMESTAMP (substr(L_updated_at,1,length(L_updated_at)-1), 'YYYY-MM-DD"T"HH:MI:SS');
                                --TO_DATE(L_updated_at, 'YYYY/MM/DD HH:MI:SS');--to_date(L_updated_at);
        p_ifdblenq.v_cstb_ui_columns.DATE_FIELD2 := TO_TIMESTAMP (substr(L_created_at,1,length(L_created_at)-1), 'YYYY-MM-DD"T"HH:MI:SS');
        
        --TO_DATE(L_created_at, 'YYYY/MM/DD HH:MI:SS');--to_date(L_created_at);
      
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD6 := L_bongloy_user_name;
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD7 := L_bongloy_user_account;
      
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD8  := L_bongloy_payment_id;
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD10 := L_txn_id;
      
        p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD11 := L_others;
        
                p_ifdblenq.v_cstb_ui_columns.num_field1  := to_number(L_amount);

      
        RETURN TRUE;
      
      ELSE
      
        RETURN FALSE;
      
      END IF;
    
    END IF;
  
    DBG('SUCCESSFULLY PROCESSED FN_GET_TXN_STATUS_BY_ENQID');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in FN_GET_TXN_STATUS_BY_ENQID' ||
          SQLERRM);
      RETURN FALSE;
    
  END FN_GET_TXN_STATUS_BY_ENQID;

  FUNCTION fn_Post_build_type_structure(p_source           IN VARCHAR2,
                                        p_source_operation IN VARCHAR2,
                                        p_Function_id      IN VARCHAR2,
                                        p_action_code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_addl_info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdblenq         IN OUT ifpks_ifdblenq_Main.ty_ifdblenq,
                                        p_err_code         IN OUT VARCHAR2,
                                        p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_FORMATTED_MSG CLOB;
  
  BEGIN
  
    dbg('In fn_Post_build_type_structure');
  
    dbg('Enquiry ID=' || p_ifdblenq.v_cstb_ui_columns.CHAR_FIELD1);
  
    dbg('p_action_code=' || p_action_code);
  
    IF p_action_code = 'EXECUTEQUERY' THEN
    
      DBG('CALLING GET TXN STATUS API');
      IF NOT
          FN_GET_TXN_STATUS_BY_ENQID(p_ifdblenq, p_err_code, p_err_params) THEN
        dbg('Failed in fn_msg_upload');
        RETURN FALSE;
      END IF;
    END IF;
  
    dbg('Returning Success from fn_Post_build_type_structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In when others of ifpks_ifdblenq_Custom.fn_Post_build_type_structure ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_Post_build_type_structure;

  FUNCTION Fn_main(p_source           IN VARCHAR2,
                   p_source_operation IN VARCHAR2,
                   p_Function_id      IN VARCHAR2,
                   p_action_code      IN VARCHAR2,
                   p_Child_Function   IN VARCHAR2,
                   p_multi_trip_id    IN VARCHAR2,
                   p_Request_No       IN VARCHAR2,
                   p_ifdblenq         IN OUT ifpks_ifdblenq_Main.ty_ifdblenq,
                   p_status           IN OUT VARCHAR2,
                   p_err_code         IN OUT VARCHAR2,
                   p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
    E_Failure_Exception  EXCEPTION;
    E_Override_Exception EXCEPTION;
  
  BEGIN
  
    dbg('In Fn_main');
  
    SAVEPOINT Sp_Main_Ifdblenq_custom;
    dbg('Returning Success From Fn_Main..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN E_Failure_Exception THEN
      dbg('From E_Failure_Exception of Fn_Main');
      ROLLBACK TO Sp_Main_Ifdblenq_custom;
      p_status := 'F';
      dbg('Errors     :' || p_err_code);
      dbg('Parameters :' || p_err_params);
      RETURN FALSE;
    
    WHEN E_Override_Exception THEN
      dbg('From E_Override_Exception of Fn_Main');
      p_status := 'O';
      dbg('Errors     :' || p_err_code);
      dbg('Parameters :' || p_err_params);
      RETURN FALSE;
    
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In when others of ifpks_ifdblenq_Custom.Fn_Main ..');
      debug.pr_debug('**', SQLERRM);
      p_status := 'F';
      ROLLBACK TO Sp_Main_Ifdblenq_custom;
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END Fn_Main;

END ifpks_ifdblenq_custom;
