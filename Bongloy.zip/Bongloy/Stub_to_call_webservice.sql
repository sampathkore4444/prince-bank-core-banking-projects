DECLARE
  req     utl_http.req;
  res     utl_http.resp;
  url     varchar2(4000) := 'http://10.80.80.11:8282/prnc-app/bongloy/api/1.0.0/account-inquiry';
  name    varchar2(4000);
  buffer  varchar2(32767);
  buffer1  clob;
  buffer2  clob;
  content varchar2(4000) :=

    'channel=01&&account_no=002002965&&currency=USD&&amount=10&&transaction_id=20201101PB&&remark=Testing_SIT';

begin
  --req := utl_http.begin_request(url);
  req := utl_http.begin_request(url, 'POST', ' HTTP/1.1');
  utl_http.set_authentication( req, 'prince','qwer!@#$', 'Basic' );
  utl_http.set_header(req, 'user-agent', 'mozilla/4.0');
  utl_http.set_header(req, 'content-type', 'application/x-www-form-urlencoded');
  utl_http.set_header(req, 'Content-Length', length(content));

  --UTL_HTTP.SET_BODY_CHARSET('UTF-8');

  dbms_output.put_line('content='||content);

  utl_http.write_text(req, content);

  UTL_HTTP.WRITE_RAW (req,
                    UTL_RAW.CAST_TO_RAW(content));

  res := utl_http.get_response(req);

  dbms_output.put_line('status code='||res.status_code);

  -- process the response from the HTTP call
  begin
    loop
      utl_http.read_line(res, buffer);
      --dbms_output.put_line(buffer);
      buffer1 := buffer1 || buffer;
    end loop;
    utl_http.end_response(res);
  exception
    when utl_http.end_of_body then
      utl_http.end_response(res);
    when others then
      dbms_output.put_line('ERROR CODE='||SQLCODE);
      dbms_output.put_line('ERROR MESSAGE='||SQLERRM);
  end;

  dbms_output.put_line('buffer1='||buffer1);

  buffer2 := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(buffer1);
  dbms_output.put_line('buffer2='||buffer2);

end;