/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright � 2008 - 2016  Oracle and/or its affiliates.  All rights reserved.
** 												
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
** 
** 
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
**
**  Written by         :
**  Date of creation   :
**  File Name          : CLDACCNTNT_KERNEL.js
**  Purpose            :
**  Called From        :
**
**  CHANGE LOG
**  Last Modified By   :
**  Last modified on   :
**  Full Version       :
**  Reason             : centralisation in 9NT1368
**  Last Modified By   : Anuradha.H
**  Last modified on   : 15-Mar-10
**  Full Version       : FCUBS11.1
**  Reason             : MB0403 Repayment from guarantor a/c
**
**  Last Modified By   : Gokul
**  Last modified on   : 22-Mar-10
**  Full Version       : FCUBS11.1 - 9NT1368
**  Reason             : Addition of CLCSEHIS callform.
**
**  Last Modified By	: Charanya
**  Last modified on	: 08-May-2010
**  SFR					: 1473
**  Reason				: Changes made to open Sub-Screens properly
**	Search String		: SFR#1473
**
**  Last Modified By	: Satyakam Jena
**  Last modified on	: 17-May-2010
**  SFR					: FCUBS11.1 ITR1 SFR#2790
**  Reason				: Changes made to disable fields on copy
**	Search String		: SFR#2790
**
**  Last Modified By	: Sharan Upadhyay
**  Last modified on	: 18-May-2010
**  SFR					: 1959
**	Search String		: SFR#1959
**
**  Last Modified By	: Satyakam Jena
**  Last modified on	: 19-May-2010
**  SFR					: FCUBS11.1 ITR1 SFR#2316
**	Search String		: FCUBS11.1 ITR1 SFR#2316
**
**	Last Modified By	: Satyakam Jena
**  Last modified on	: 19-Jul-2010
**  SFR					: FCUBS11.1 ITR2 SFR#259
**	Search String		: FCUBS11.1 ITR2 SFR#259

**	Last Modified By	: Deepika Purohit
**  Last modified on	: 24-sep-2010
**  SFR					:FCUBS 11.2 changes
**	Search String		:FCUBS 11.2 change
**
**Last Modified by          :Anoop Surendran
**  Last modified on	: 25-oct-2010
**  SFR		           :077
**  Search String		: log#1


Search String 		: RETRO FIX 11-Feb-2011 Aslam
Changed Reason		: In Customer Information Query (ACDSCPQR) we cannot drill down for Loans and CI Contracts
Changed by 			: Aslam Ershath

**     Modified By                 : Abhishek Jain
**     Modified On                : 01-MARCH-2011
**     Modified Reason         : FCUBS 11.2 RETRO CHANGES
**     Retro Reference        : Retrolist.xls/10.5/FC10.5/IMPSUPP/BTNTBL/258
**     Search String            : 01-MARCH-2011

Changed By         :  Sweta Panda
Description        :  360 Degree Customer View Changes
Search String      :  9NT1466 11.3.1 360 Degree Customer View Changes

**Changed By         :  Hemalatha N
**Change Description :  On double click of a row the contract/on-line screens were not populated accordingly
**Changed On         :  09-Sep-2011
**Search Tag         :  FCUBS_11.3.0_P01_FC11.0_IMPSUPP_285

**     Modified By             : Neeraja J
**     Modified On             : 13-sep-2011
**     Modified Reason       : fcub_11.4 retro
**     To pick up joint customers from Other Applicants Subscreen into CustomerID LOV in Linkage Tab
**     Search String           :FC11.1_IMPSUPP_497	

**     Modified By             : Sandhyusha
**     Modified Reason       : 9nt1462:: collections
**     Search String           :Sandhyusha:: collections 	

**     Modified By             : Senthil kumar P
**     Modified On             	: 28-Sep-2011
**     Modified Reason       : 9NT1462 Takeover Asset changes 
**     Search String           :9NT1462 Takeover Asset changes  	

**     Modified By             	: Paranthaman Rajendran
**     Modified On             	: 28-Sep-2011
**     Modified Reason         : 9NT1462-- IUT -- SFR#934, after query  Subsytem buttons should be enabled 
							to view the  details No other details should enabled.
**     Search String              : 9NT1462-- IUT -- SFR#934

**     Modified By             : Arumugam S
**     Modified On             : 11-Oct-2011
**     Modified Reason      : 9NT1462-- ITR1 -- BUG 13075719,To fix the  dbIndexArray is not properly reseted while cancel the sub screen
**     Search String           9NT1462-- ITR1 -- BUG 13075719

**    Changed By         :  Saswat Sahoo
**    Description        : Fcubs 11.4.0 kernel ITR # 13101009 Enabling Disbursal button in components tab  
**   Search String      :  Fcubs 11.4.0 kernel ITR # 13101009

**    Changed By         :  HarinathY
**    Description        : Fcubs 11.4.0 kernel ITR #13248133 opening  payment mode details sub system  
**   Search String      :  Fcubs 11.4.0 kernel ITR # 13248133

**    Changed By         :  HarinathY
**    Description        : Fcubs 11.4.0 kernel ITR #13248229  opening  hamish jiddayah amount sub screen with the entered values in the main screen  
**   Search String      :  Fcubs 11.4.0 kernel ITR # 13248229

**    Changed By         :  HarinathY
**    Changed On         :  12-Nov-11
**    Description        : Launching takeover details screen
**   Search String      :  9nt1462 ITR1 SFR 13358228

**    Changed By         :  Saswat Sahoo
**    Description        : Fcubs 11.4.0 kernel ITR # 13391630 adding code to open the guarantor screen
**   Search String      :  Fcubs 11.4.0 kernel ITR # 13391630

**    Changed By         :  Saswat Sahoo
**    Description        : Fcubs 11.4.0 kernel ITR # 13256716 adding code to defaulting current branch in linkage_branch
**   Search String      :  Fcubs 11.4.0 Kernel ITR 13256716

**    Changed By         :  Sandhyusha 
**    Description        : Fcubs 11.4.0 kernel ITR # 13348297 CREDIT SCORE DEFAULT FOR CI not happening soemtimes
**   Search String      :  Fcubs 11.4.0 kernel ITR # 13348297

**  Modified By             : PeriyathambiM
**  Modified On             : 07/Dec/2011 
**  Modified Reason       : Failing when gAction is null, trying tab change after loading
**  Search String           : 9NT1462 ITR2 SFR 13469863

**  Last Modified By   : AnjaliSi
**  Last modified on   : 25-02-2012
**  Full Version       : FCUBS_12.0.0
**  Reason             : DMS callform changes
**  Search String      : FCUBS_12.0.0 DMS changes

**  Last Modified By   : Dhanya V V
**  Last modified on   : 19-03-2012
**  Reason             : For New Operation Cursor was pointing to Account number, changed to Product code
**  Search String      : 9NT1501 - SFR 265 code changes

**  Last Modified By   : Dhanya V V
**  Last modified on   : 27-03-2012
**  Reason             : For New Operation Cursor was pointing to Account number, changed to Product code for CIDACCNT and MODACCNT
**  Search String      : 9NT1501 - ITR1 - SFR  :13891758  


**  Last Modified By   : Sonali Roy
**  Last modified on   : 23-08-2012
**  Reason             : Udf changed to multiblock
**  Search String      : 14517741:Fix Propagation to 12.0~Retro from 13918923

**  Last Modified By   : Nand Dhakar
**  Last modified on   : 17-09-2012
**  Reason             : Code added for the proper error message on tab out from Tenor Field with the invalid entries. 
**  Search String      : FCUBS12.0-->APACK-->14610806 
 
 **    Modified By         : Reshma R
 **    Modified On         : 11-Oct-2012
 **    Modified Reason     : Code Changes to Enable Payment Mode Button of Charge Tab.
 **    Search String       : 14749226 Fix Propogation to 12.0 Retro from 14737805
 
 **    Modified By         : Reshma R
 **    Modified On         : 19-Oct-2012
 **    Modified Reason     : Summary datasource and block changed 
 **    Search String       : 14783195 Fix Propogation to 12.0 Retro from 13803501
 
 
  **    Modified By         : Saritha Nair
  **    Modified On         : 19-Nov-2012
  **    Modified Reason     : Attached event to fields which are not of type lov so that auto lov will not pop up for text fields
  **    Search String       : 12.0->USDIFAD->15889589
  
**     Modified By             : Rojalin Beura	
**     Modified On             : 26-11-2012
**     Modified Reason       : On querying CL account , Schedule details button is not enabled unless component tab is visited.Fix propgation from 14548319
**     Search String           :9NT1525-12.0-INTERNAL-15911921

**    Modified BY          : Rojalin Beura
  **    Modified On          : 4-dec-2012
  **    Modified Reason     :Authorized account appearing unauthorized in account 
                              screen if its unauthorized in other screen. Fix propagatio from 14598141 
  **    Search Tag           :9NT1525-12.0-INTERNAL-15911202 


**  Last Modified By   : mahalakshmi bhambore
**  Last modified on   : 31-12-2012
**  Reason             : Changed error code for the proper error message on tab out from Tenor Field with invalid entries. 
**  Search String      : 16040116: propagated from 14825982 

**  Last Modified By   : Subramanian Karthik
**  Last modified on   : 22/Mar/2013
**  Reason             : Not able to close the Parent Screen by clicking X Button.
**  Reason             : 16561070: Propogated from 16506746 
**  Search String      : SFR->16561070

**  Last Modified By   : Nibedita Satapathy
**  Last modified on   : 04-04-2013
**  Reason             : Changes Related to Amount Currency Validations in  CLDACCNT.
**  Search String      : 12.0.2 Amount CCY Changes
 
**  Last Modified By   : Pratibha Nair
**  Last modified on   : 12-April-2013
**  Reason             : CLDACCNT_CUSTOM.js is not being called as fnPostUnlock_Kernel() does not return true in CLDACCNT_KERNEL.js.
						Added return true statement in all _KERNEL() functions where it is missing.
**  Search String      : Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758)

**  Last Modified By   : Uddipan Pal
**  Last modified on   : 08-May-2013
**  Reason             : 1. Tenor is not getting populated on 'PRODUCT DEFAULT' in CLDACCNT screen. Mismatch in element name while assigning value 
							to TENOR field is rectified - 12.0.2~USDIFAD~16778704
						 2. Tenor is shown as negative when Maturity date less than System date and value date is backated. This is rectified - bug no 11.4~TFB~16578276.
						 3. setMonth function is appended with date parameter along with month to avoid the date/month getting spilled over when the derived month does not match the number of days - FCUBS11.4->CNSL->IIDRBMI;SFR#15940510
						 4. Modified the fix provided as part of bug 15940510. While summing up the number with undeclared variable , issues were faced. Type casted to number where applicable - 15958357 changes
**  Search String      : 12.0.2~USDIFAD~16778704


**  Last Modified By   : Srithi Baid
**  Last modified on   : 15-July-2013
**  Reason                   : Account number is editable after clicking on product default thus disabling it.
**  Search String       :17163038:Fix Propagation to 12.0.2 ~ Retro from 14126745

   **     Modified By             : Shilpa M B
   **     Modified On             : 24-Sept-2013
   **     Modified Reason         : 1st component name was overwritten to the component name whose reimbursement screen we visit 	.
   **     Search String           : 12.0.2-ISMEMYR-17560674(propagated from 17466270)  


**  Last Modified By   : Girish Chandran M
**  Last modified on   : 8/Oct/2013
**  Reason             : To generate the sequence number in Guarantor Customer and Guarantor Customer Account 
                         multi records in Guarantor details subscreen as it was not generated properly. 
**  Search String      : Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203

**  Last Modified By   : Ashish Semwal
**  Last modified on   : 02-Dec-2013
**  Reason             : Code corrected for TENOR value. TENOR replaced by TENORI. Mismatch in element name while assigning value 
			           to TENOR field is rectified.
                         Fix Propagated from FCUBS12.0.1>INADNED>17780454
**  Search String      : FCUBS12.0.2>IEGPCAE>17879918

**	   Modified By           	: Harinath
**	   Modified On           	: 13-Feb-2014
**	   Modified Reason       	: 1) Disabled the linkage whose type is deposit
								  2) restricted user from manually adding linkage whose type is deposit
**	   Search String         	: FCUBSVER: 12.0.3, KERNEL, Item: Interest rate pickup UT2

**    Modified By       : Sandeepa K
**    Modified On       : 11-June-2014
**    Modified Reason   : Code Changes done to disable the UDE & COMP_SCH blocks after enrich & explode respectively
						  and during TAB changes and traverse of components after these operations
**    Search String     : 18955556:Fix Propagation to 12.0.3 ~ Retro from 15844446 	

**    Modified By       : Reshma R
**    Modified On       : 02-July-2014
**    Modified Reason   : In asset subscreen related currency was going null for fields wholesale retailvalue and totval 
						  Added code to take the value of currency from main block in subscreen assets
**    Search String     : FCUBS_12.0.3_COMMONWEALTH BANK OF AUSTRALIA_19143200

**    Modified By       : Abhishek Jain
**    Modified On       : 17-July-2014
**    Modified Reason   : Added code for liquidation mode in charges tab.
**    Search String     : FCUBS_12.0.3_IRONVBR_19235047

**     Modified By             : Nameirakpam Ibochouba Singh
**     Modified On             : 24-Jul-2014
**     Modified Reason         : CUBE UDF Type is mapped to a CL Product and LOV not fetching any data. Provided solution the same.
**     Search String           : FCUBS12.0.3->IRONVBR->19226624

**     Modified By             : Hari
**     Modified On             : 22-July-2014
**     Modified Reason         : Since the nomenclature of functionID has changed, modified the reference in JS as well
								 and corrected the screen args parameter
**     Search String           : FCUBS12.0.3_Internal_19294312

**     Modified By             : Abhishek jain
**     Modified On             : 20-Aug-2014
**     Modified Reason         : added code to disable linkage type in commitment\linkages detail while deleting row.
**     Search String           : fcubs12.0.3_ZAO UNICREDIT BANK_19472423
 
**  	Modified By   			: Pratibha Nair
**  	Modified on   			: 9-Sep-2014
**  	Reason             		: User is able to query accounts from other branches. Added code to disable the branch code during Query.
**  	Search String      		: FCUBS_12.0.3_COMMONWEALTH_BANK_AUSTRALIA_19579252
**     Modified By             : Nandini Nair
**     Modified On             : 27-Jan-2014
**     Modified Reason         : In payment mode details,if the settlement account belongs to different branch from the CL account branch then not able to query the balance using hot key (F11).

**     Search String           : FCUBS_12.0.3_19558009
**
**     Modified By             : Pratibha Nair
**     Modified On             : 31-Oct-2014
**     Modified Reason         : Unlock Button is disabled for authorized accounts
**     Search String           : 19929827 :Fix Propagation to 12.0.3 ~ Retro from 16209928

**     Modified By             : Arulsukanya K
**     Modified On             : 17-Feb-2015
**     Modified Reason         : PNTFLX01011_12.1.0.0.0_Trade_360View
**     Search String           : FCUBS12.1_Trade_360View Changes

**     Modified By             : Dinesh L
**     Modified On             : 10-Apr-2015
**     Modified Reason         : Code change done for multiple settlement instruction
**     Search String           : [FCUBS->12.1_Multi_Settlement_Instruction]
**    Modified By        : Harinath
**    Modified On        : 21-Nov-2014
**    Modified Reason    : Passing the action as HOLDFLT when user clicks on DefaultHolidayPreference button
**    Search String      : SITECODE: 12.1, KERNEL, Item:Revision Schedules
						   Retroed the fix 19071439 as well

	**    Modified By        : Harinath
	**    Modified On        : 23-Mar-2015
	**    Modified Reason    : Currency fields are not getting disabled based on the Holiday Check selected
	**    Search String      : SITECODE: 12.1, KERNEL, Item:Revision Schedules_UT1_Case_20

**   Modified By             : Priya
**   Modified On             : 23-Apr-2015
**   Modified Reason         : Depending on the sanction check status action buttons are enabled and disabled
**   Search String           : FCUBS->12.1_Sanction_Check_Changes

**    Modified By       : Nandini Nair
**    Modified On       : 29-Apr-2015
**    Modified Reason   :After authorization of account,when takeover button is clicked,UDE subscreen button was also getting enabled.Added code to handle the same.
**     Search String	:20977811:Fix Propagation to 12.1.0 ~ Retro from 20921692					   
**
**    Modified By       : Karthik S
**    Modified On       : 13-Mar-2015
**    Modified Reason   : OVDAUDEF Changes.
**    Search String     : [FCUBS12.1->Forward Port->->20658866->20988303]

**    Modified By             : Surekha T
**    Modified On             : 7-May-2015
**    Modified Reason         : Added code to display Tenor field value on Execute Query operation for a CL account.
**    Search String           : 21047543:Fix Propagation to 12.1.0 ~ Retro from 20803844

**    Modified By       : Suhas S
**    Modified On       : 24-Mar-2015
**    Modified Reason   : Customer Landing Page Changes.
**    Search String     : FCUBS12.1_SCO_Bank_Changes


  **   Modified By        	  : Girish M
  **   Modified On        	  : 26-May-2015
  **   Modified Reason    	  : Metro bank development: Automatic Recovery of AR
  **   Search String      	  : 12.1_METRO_DEV_AR 
  
  **   Modified By        	  : Karthik S
  **   Modified On        	  : 28-May-2015
  **   Modified Reason    	  : Hot Key Changes
  **   Search String      	  : 12.1 Development Joint Holder Hot Key Changes
  
  **   Modified By        	  : Dinesh L
  **   Modified On        	  : 29-May-2015
  **   Modified Reason    	  : Code added to activate Credit Settlement Mode and Debit Settlement Mode tabs at the same time.
  **   Search String      	  : FCUBS->12.1_Multi_Settlement_Instruction_UT2_Case#43
  **
**     Modified By             : Hema B. Kashyap
**     Modified On             : 02-June-2015
**     Modified Reason       :  Code modified to pass UIXML name instead of Function id as for function id created with CLDACCNT as executable name, UIXMl name will also be CLDACCNT.xml. 		 
**     Search String           : Fwd_PortFCUBS12.1_INTERNAL_21182488
**
**     Modified By             : Hema B. Kashyap
**     Modified On             : 02-June-2015
**     Modified Reason       : Added code to pass UIXML in case of screen 'CVS_INVQRY' only and FUNCTION_ID in case of the rest of the screens. 		 
**     Search String           : Fwd_PortFCUBS12.1_INTERNAL_21182476
**
**     Modified By             : Hema B. Kashyap
**     Modified On             : 13-May-2015
**     Modified Reason       :  Added code to disable product code after unlock. 		 
**     Search String           : Fwd_PortFCUBS12.1_INTERNAL_21182492

**     Modified By             : Thambi M
**     Modified On             : 02-Jun-2015
**     Modified Reason         : Commented the code to hide the + and - buttons for check list and advices. Moved the same code into in_tab functions.			 
**     Search String           : [FCUBS12.1.0->RETRO->21186798; Base#20777410]

**     Modified By             : Dinesh L
**     Modified On             : 12-Jun-2015
**     Modified Reason         : Due to 12.1 infra changes, LOV is not getting defaulted to fields in other tab, when the single LOV has to return value to the fields
								 available in the select clause hence made changes to return LOV properly
**     Search String           : [FCUBS12.1-INTERNAL-IQA-21237653] 

**     Modified By             : Thambi M
**     Modified On             : 017-Jun-2015
**     Modified Reason         : Reverted the changes against "FCUBS12.1_Trade_360View Changes" as it is not required
**     Search String           : [FCUBS12.1-INTERNAL-IQA-21246702]

**     Modified By             : Girish M
**     Modified On             : 25-Jun-2015
**     Modified Reason         : CLDACCNT->COMPONENT->SCHEDULE DETAILS->MULTIPLE PAGES ARE NOT DISPLAYED
**     Search String           : FCUBS12.1~Bug~21316998

**     Modified By             : Priya
**     Modified On             : 26-Jun-2015
**     Modified Reason         : Code changes done to disable gross principal posr enrich
**     Search String           : [FCUBS12.1-INTERNAL-IQA-21318773]

**     Modified By             : Priya
**     Modified On             : 07-Aug-2015
**     Modified Reason         : Code changes done to the summary screen CLSENTTY to fetch records on click of detailed button.
**     Search String           : [FCUBS12.1-INTERNAL-ITR1-21557585]

**     Modified By             : Priya
**     Modified On             : 24-Aug-2015
**     Modified Reason         : Code changes done to disable currency fields based on the Holiday Check selected on tab out and re-visiting the tab holiday preferences.
**     Search String           : [FCUBS12.1-INTERNAL-ITR1-21677950]

**     Modified By             : Vimalkumar and Arulsukanya K
**     Modified On             : 22-Dec-2015
**     Modified Reason         : Trade 360 view changes
**     Search String           : PNTFLX01011_12.2.0.0.0_Trade_360View Changes

**     Modified By             : Santosh Sinha
**     Modified On             : 10-Aug-2016
**     Modified Reason         : Issue :- As a part of customer custom code were introduced in postNew.. function of _CUSTOM.js file, 
								 but same was not getting called.
								 Fix   :- Some of the codes which are related to component tab was failing and due to that _custom.js
								 was not getting called. Those statements are commented as those is already handled on Tab in of component tab.
**     Search String           : FCUBS12.2.0->CNSL->NEW ZEALAND ASSOCIATION OF CREDIT UNIONS;SFR#24437525

**    Modified By          	   : Karthikeyan k
**    Modified On              : 23-June-2016
**    Modified Reason          : SYSTEM OPENS THE REVERSE VERSION NO SCREEN BEFORE ACCEPTING.INCLUDED RETURN FALSE IN fnPreReverse_KERNEL()
**    Search String            : [FCUBS12.3->RETRO->17396475; Base#23631949]

  **   Base Bug Num            : 24730357
  **   Modified By             : Karthikeyan k
  **   Modified On             : 22-Sep-2016
  **   Modified Reason         : Manual merger from 12.2 to 12.3
  **   Search String           : [FCUBS12.3->Retro->24702528]
  
  **     Modified By             : Karthikeyan k
  **     Modified On             : 04-Oct-2016
  **     Modified Reason         : In linkages tab if new collateral is selected then linked ref no should be disabled and if its not new collateral then linkage branch, overall amount collateral category,hair cut and commitment product field should be disabled.
  **     Search String           : [FCUBS12.3->RETRO->24613348; Base#21442514]

**     Modified By             : Dinesh L
**     Modified On             : 14-Oct-2016
**     Modified Reason         : Roll backed the fix given for 23631949,since same is failing for CI module
**     Search String           : [FCUBS12.3-INTERNAL-MAT-24846411]
**    Modified By             : chandana
**    Modified On             : 7-Nov-2016
**    Modified Reason         : In account details screen, after defaulting the product, all of the UDFs in the 
								Fields tab are displayed as LOV type UDF despite of the fact that some of the 
								UDFs have validation type as None.
							    Due to wrong relation operator value of LOV type was going wrong and due to that it 
								was showing LOV.
**    Search String           : FCUBS_12.3_RETRO_BUG#25056260

**     Modified By             : chandana
**     Modified On             : 16-Nov-2016
**     Modified Reason         : Authorization is pending from Payment screen. User is trying to authorize the account from Account and failed to show the proper error message. un commented the code to display the error message. 
       Fix: Return false is commented
**     Search String           : FCUBS_12.3_RETRO_BUG#25101778

**     Modified By             : Saurav Jaiswal
**     Modified On             : 24-Nov-2016
**     Modified Reason         : Issue :- On click on details button in loans tab in stdretvw screen, datas were not getting populated.
								 Fix   :- Fix provided to handle the issue.
**     Search String           : NEW_ZEALAND_12.2_25104686

**  Modified By          : Neethu Sreedharan
**  Modified On          : 21-Feb-2017
**  Modified Reason      : Fix given so that custom code will not get break. 
**  Retro Source         : 9NT1606_12_0_3_BARCLAYS_INDIA
**  Search String        : 9NT1606_12_3_RETRO_12_0_3_25402446

**    Modified By            : Supriya
**    Modified On            : 28-Mar-2017
**    Modified Reason        : BEHAVIOUR OF SPECIAL INTEREST COMPONENT IS NOT PROPER.USER SHOULD NOT BE ALLOWED TO ENTER THE AMOUNT IN THE SCHEDULE DETAILS SECTION .REVERTED THE FIX AND MADE THE AMOUNT FIELD DISABLED FOR INTEREST TYPE COMPONENTS. 
**    Search String          : BUG#25589169_1

**     Modified By             : Suresh Babu B
**     Modified On             : 20-Jun-2017
**     Modified Reason         : ACDTRNQY - EMPTY CL ACCOUNT DETAILS SCREEN AFTER DOUBLE CLICK .CODE MOVED
**     Search String           : [FCUBS12.4->RETRO->26232002; Base#23113085]

**    Modified By       : Suresh Babu B
**    Modified On       : 20-Jun-2017
**    Modified Reason   : Loan product is configure Multi level authorized. Loan created and before authorization in Multilevel Authorization Detailed (OVDAUDEF) screen user click on Contract Details during this time Loan account(CLDACCNT) screen should open. Code corrected.
**    Search String     : [FCUBS12.4->RETRO->26233743; Base#23188301]
**
**     Modified By             : Priyanka Vijai
**     Modified On             : 30-Jun-2017
**     Modified Reason         : SUMMARY SCREEN LAUNCH FAILING IN CLSACCNT_KERNEL.JS
**     Search String           :  [FCUBS12.4->RETRO->26233783;Base#25488207]

**     Modified By             : Suresh Babu B
**     Modified On             : 03-Jul-2017
**     Modified Reason         : System was not disabling component liquidation mode. Issue due to disable charge tab button in component tab, hence commented.
**     Search String           : [FCUBS12.4->RETRO->26232985;Base#22919006]

**    Modified By             : Suresh Babu B
**    Modified On             : 03-Jul-2017
**    Modified Reason         : VAMI saved successfully after user trying to do loan authorization from CLDACCNT screen even though system is not throwing proper error message. Code handled to show proper error message "Account is unauthorized because of : VAMI. The same cannot be authorized/deleted from here."
**    Search String           : [FCUBS12.4->RETRO->26231982;Base#24922767]

**    Modified By             : Suresh Babu B
**    Modified On             : 05-Jul-2017
**    Modified Reason         : Users having MultiBranch Access should be allowed to query other branch's accounts in CLDACCNT.
**    Search String           : [FCUBS12.4->RETRO->26231734;Base#21777003]

**     Modified By             : Suresh Babu B
**     Modified On             : 06-Jul-2017
**     Modified Reason         : CUBE ENTITY UDF NOT SHOWING ANY VALUES IN CLDACCNT.Error on click of Cube Entity Lov Unable to get property 'cells' of undefined or null reference.Corrected Row Reference in function fnPreDispLov_LOV_CHAR_FLD_KERNEL
**     Search String           : [FCUBS12.4->RETRO->26233265;Base#22646735]

**     Modified By             : Suresh Babu B
**     Modified On             : 06-Jul-2017
**     Modified Reason         : Tenor value is getting disappeared from CL account screen after moving from 1 tab to another tab.
								 Added fn_ChangeTenor() in fnInTab_TAB_MAIN_KERNEL().
**     Search String           : [FCUBS12.4->RETRO->26231912;Base#21604942]

**     Modified By             : Suresh Babu B
**     Modified On             : 11-Jul-2017
**     Modified Reason         : Authorization is pending from Payment screen. User is trying to authorize the account from Account and failed to show the proper error message. un commented the code to display the error message. 
**     Search String           : [FCUBS12.4->RETRO->26233510;Base#24397607]

**    Modified By             : Priyanka vijai
**    Modified On             : 12-Jul-2017
**    Modified Reason         : CLDMNROL - Response is empty on clicking enrich button
**    Search String           : [FCUBS12.4->RETRO->26232418;Base#25181976]

**     Modified By             : Suresh Babu B
**     Modified On             : 14-Jul-2017
**     Modified Reason         : Corrected code for fnSubScreenMain as this is infra function and infra team added new code in fnSubScreenMain function , 
								 so take the latest fnSubScreenMain function and added cldaccnt related code.
**     Search String           : [FCUBS12.4->RETRO->26234032;Base#21206103]

**    Modified By             : Priyanka vijai
**    Modified On             : 25-Jul-2017
**    Modified Reason         : UDF's description is not displayed when user input data correctly and tab out. Code handled for the same.
**    Search String           : [FCUBS12.4->RETRO->26231817;Base#24801088]

**    Modified By             : Suresh Babu B
**    Modified On             : 28-Jul-2017
**    Modified Reason         : Code handled to retain and assign values to liability percentage and liability amount post calculation based on the respective values enter by user. And also modified the formula to calculate percentage.
**    Search String           : [FCUBS12.4->RETRO->26230849;Base#25828592]

**     Modified By             : Suresh Babu B
**     Modified On             : 08-Aug-2017
**     Modified Reason         : Added cde to disable ude block after copy and unlock.
**     Search String           : [FCUBS12.4->RETRO->26232379;Base#22848623]

**     Modified By             : Vrishti Ghosh
**     Modified On             : 17-Aug-2017
**     Modified Reason         : All the top menu options from main screen will get disappear on click of Cancel button in Reverse Subscreen of CLDACCNT screen.Hence,code added. 
**     Search String           : [FCUBS12.4->RETRO->26233371; Base#23666414]

**    Modified By             : Priyanka vijai
**    Modified On             : 22-aUG-2017
**    Modified Reason         : UDF's description is not displayed when user input data correctly and tab out. Code handled for the same.
**    Search String           : [FCUBS12.4->INTERNAL->26648895]
 
**     Modified By             : Piyush Sharma
**     Modified On             : 23-Aug-2017
**     Modified Reason         : Issue :- CLDACCNT -SCREEN IS HANGING/GRADINGOUT WHILE AUTHORISING CONTRACT
								 Fix   :- Fix provided to handle the issue.
**     Search String           : FCUBS_124_INTERNAL_26624850_RETRO_FROM_26613688	

**    Modified By         : Piyush Sharma
**    Modified On         : 24-Aug-2017
**    Modified Reason     : CL/CI NUMBER/DATE UDF FIELD VALUES DISAPPEARING ON PAGE NAVIGATION.So function fnPreNavigate
							has been added for three blocks and calling appendData function to persist data after navigation.
**    Search String       : FCUBS_124_INTERNAL_26525016_RETRO_FROM_26477432 

**    Modified By       	: Suresh Babu B
**    Modified On       	: 29-Aug-2017
**    Modified Reason   	: Payment save is getting failed with error 'Sum of Amount provided in Schedule Details should not exceed the Special Interest Amount' if special interest component exists in loan account and the corresponding dues/overdues exists or already settled.
							  BEHAVIOR OF SPECIAL INTEREST COMPONENT. WHEN USER PROVIDES SPECIAL INTEREST AMOUNT AND AMOUNT IN COMP_SCH ,SYSTEM SHOULD VALIDATE THE TOTAL SUM OF AMOUNT AND THROW PROPER ERROR IF THE SUM OF AMOUNT AND SPECIAL INTEREST AMOUNT IS NOT EQUAL.
**    Search String     	: [FCUBS12.4->RETRO->26384638; Base#26328954]


**    Modified By            : Priyanka vijai
**    Modified On            : 27-Sep-2017
**    Modified Reason        : 1. Amount due is existing however Amount Waived field not getting enable, Code corrected to enable if charges component tab amount due is available for the Component then Amount waived field should be enable by clicking on Next and previous button.
							   2. When user click on Charges tab User can add new Component either delete existing Component. Code handled to disable +ve and -ve button in charges component tab.
**    Search String          : [FCUBS12.4->RETRO->26861741; Base#26802826]

	**   Modified By            : Priyanka vijai
	**   Modified On            : 07-Nov-2017
	**   Modified Reason        : Converted CLDNOVDT to extensible screen CLDCRASG and handled code for the same.
	**   Search String          : [FCUBS12.4->RETRO->26861672; Base#26660335]
	**
	
	**   Modified By            : Sandeep Badvel
	**   Modified On            : 30-Jan-2018
	**   Modified Reason        : Code added to disable component name in blocks charges and components
	**   Search String          : FCUBS->12.4->SAIGON COMMERCIAL BANK->SFR#27422093 
	**
**    Modified By         : Sandeep Badvel
**    Modified On         : 07-FEB-2018
**    Modified Reason     :Issue :System throwing error "Please enter the value in the related currency field of this Amount Field". 
                                  while filling the details ofResidual amount in Ijarah Account Input (CIDIJAAC)
                           Fix: Code added to assing values for related currency Fields of Residual Value and Residual Amount.
						   2)code added to assign values for related currency Fields of Residual Value and Residual Amount. in fn_ccy();
**    Search String       : FCUBS12.4->CNSL->NRSP MICROFINANCE->SFR#27309407_1
**
**    Modified By         : Sandeep Badvel
**    Modified On         : 27-April-2018
**    Modified Reason     : Issue: LOV is not appearing for second row in linkage details tab for thesecond row.
Fix: function getRowIndex is returning -1 for every row. Rad changes made to pass event during call of linkagetype. changes made in fn_linkage to pass event to getRowIndex.
**    Search String       : FCUBS12.4->CNSL->SAIGON COMMERCIAL BANK->27908992 

**  Modified By       		: Supriya
**  Modified On       		: 9-May-2017
**  Modified Reason  		: Fix given as part of bug 25589169 is reverted and code changes made to enable the amount due field when Special Amount is given 
**  Search String    		: BUG#27976303

**  Modified By       		: Geeta Adhikari
**  Modified On       		: 11-May-2018
**  Modified Reason  		: Issue: After clicking on enrich if the user navigates through the UDE block again the UDE block gets enabled.
                              Fix  : New variables g_enrich is introduced,once enrich is done it should be set to 1, and once this flag is set to 1 the UDE block should be disabled.
**  Search String    		: Fcubs_12.4_KYRGYZ INVESTMENT AND CREDIT BANK_BUG#27983724
**
**    Modified By         : Sandeep Badvel
**    Modified On         : 15-May-2018
**    Modified Reason     : Message Preview Launch form is attached to CLDACCNT.Disabled Message preview button for authorized accounts.
**    Search String       : FCUBS12.4->SAIGON COMMERCIAL BANK->27907516

**    Modified By         : Supriya
**    Modified On         : 11-June-2018
**    Modified Reason     : Issue: User is trying to add new effective dates and UDE IDs . On click of + button in UDE block, the fields are getting disabled and user is not able to add Ude for new dates.
                            Reason : The fix gievn as part of 27983724 bug was setting g_enrich as Y due to which the block is disabled in fnPostAddNewRow_BLK_UDE_VALS_KERNEL.
							Fix : Code handled to set the flag g_enrich as N during Edit UDE operation so that the block is enabled
**    Search String       : BUG#28155759
**
**    Modified By         : Sandeep Badvel
**    Modified On         : 04-July-2018
**    Modified Reason     : In Field TAB, Free text fields are showing as LOV when user visits fields tab and visit any other sub-screen and come back to fields tab.
Fix : Code changes done in fnSubScreenMain to pass true as argument to fnBuildTabHTML to restrict repainting of data in funciton showdata().
**    Search String       : FCUBS12.4->FIMBANK PLC->28259042
**
**    Modified By         : Jayendra Bhaskar
**    Modified On         : 10-Sep-2018
**    Modified Reason     : Code related to column "SANCTION_CHECK_STATUS" under function fnPostExecuteQuery_KERNEL is commented. 
**    Search String       : 124_BANK_OF_SOUTH_PACIFIC_28589467
**
**    Modified By         : Sandeep Badvel
**    Modified On         : 20-Sept-2018
**    Modified Reason     :Issue: system is showing error as "Please enter value in related Currency Field of this Amount Field" when users enter limit amount value under linkage tab in CL account screen. 
                           Fix  : code added in fnInTab_TAB_LINKAGES_KERNEL to call fn_ccy() for currency field assignment
**    Search String       : FCUBS12.4->EPROCESS INTERNATIONAL SA->28661359
**
**    Modified By         : Nameirakpam Ibochouba Singh
**    Modified On         : 03-Oct-2018
**    Modified Reason     :Issue: When click on Enrich button post visit in MIS system throwing error due to in components Tab 1st row of the component details were vanishing. 
                           Fix  : Additional code added to appending HTML's data during  during Enrich button.
**    Search String       : FCUBS12.4->UNICREDIT BULBANK AD->28698565
**
**     Modified By             : Sandeep Badvel
**     Modified On             : 09-OCT-2018
**     Modified Reason         : system opens Reverse version screen and over ride screen at once.Code handled to display over ride screen after selecting version no  and click on ok button in reverse screen.
**     Search String           : FCUBS12.4->UNICREDIT BULBANK->BUG#28760531
**
**     Modified By             : Nameirakpam Ibochouba Singh
**     Modified On             : 07-Nov-2018
**     Modified Reason         : Issue: After product is defaulted in loan account screen user visits in Charges Tab, in components block system enable +ve and -ve button so that user can delete or add new components.
                                 Fix  : Code handled in fnInTab_TAB_CHARGES_KERNEL for disable button (BTN_ADD_BLK_COMPONENTS and BTN_REMOVE_BLK_COMPONENTS ) system failed	due to that immediate code not able execute because of that system failed to disable -ve and +ve button in Charges components block in charges tab. So that code commented.
**     Search String           : FCUBS12.4->UNICREDIT BULBANK->28884200
**
** 	  Modified By      		   : Nameirakpam Ibochouba Singh
**    Modified On      		   : 14-Jan-2018
**    Modified Reason  	 	   : When user clicks on Fields tab, system is building Character/Number Type UDF's base on get-attribute. If system doesn't find get-attribute due to this system doesn't execute next records, Hence system is showing LOV type udf's in the block for non LOV udf's also. Code is added to handle the exception by passed if there is no any finding get-attribute.
**    Search String    		   : FCUBS12.4->UNICREDIT BULBANK AD->29208854
**
**  Modified By              : Sandeep Badvel
**  Modified On              : 07-Mar-2019
**  Modified Reason          : Issue : When user query loan account from linkage tab.value of Currency field mapped to linked amount is coming as NUll. 
							  Fix :1)BLK_ACCOUNT_MASTER__CCY value is unavilable(NULL) when query from linkages tab.Hence Null value is assiging to CCY1 In fn_ccy. Code added to assign value of CCY1 from backend and 
							   code modified in fn_ccy to assing value of ccy1 only when it is null.
							   2) when user visits Linkage tab call to fnccy is not happening if gAction is null. Code modified to call fnccy in fnInTab_TAB_LINKAGES_KERNEL. 
**  Search String            : FCUBS12.4->BANK OF SOUTH PACIFIC LTD->BUG#29445013

**  Modified By          : Partha Sarmah
**  Modified On          : 13-Aug-2019
**  Modified Reason      : Landing page enabling for Micro Finance module. Code try catch handled.Retro from 23272626 is done
**  Search String        : FCUBS_12.4_NRSP MICROFINANCE BANK LIMITED_30132566_RETRO_23272626
****************************************************************************************************************************/
dpndntOnFlds['PRDDFLT'] = "BLK_ACCOUNT_MASTER__PROD~BLK_ACCOUNT_MASTER__CUSTID~BLK_ACCOUNT_MASTER__AMTFINANCED~BLK_ACCOUNT_MASTER__CCY~BLK_ACCOUNT_MASTER__VALDT~BLK_ACCOUNT_MASTER__NOOFINS~BLK_ACCOUNT_MASTER__FREQUNIT~BLK_ACCOUNT_MASTER__FREQ~BLK_ACCOUNT_MASTER__INSSTDT~BLK_ACCOUNT_MASTER__DUEDATESON";

var currRow=0;//SFR#1473
var gCompPayModeIndex = 1;//SFR#1959
var gChgPayModeIndex = 1;//SFR#1959
var acnoFields = "CRPRODAC~DRPRODAC";//fcubs_INTERNAL_12.0.1_14807178
var g_enrich ='N';//Fcubs_12.4_KYRGYZ INVESTMENT AND CREDIT BANK_BUG#27983724 added

 //12.0.2 Amount CCY Changes start.
  function fn_ccy(){
	  if (document.getElementById("BLK_ACCOUNT_MASTER__CCY1").value == ""){ 
 document.getElementById("BLK_ACCOUNT_MASTER__CCY1").value =  document.getElementById("BLK_ACCOUNT_MASTER__CCY").value; 
	  } 
 //FCUBS12.4->CNSL->NRSP MICROFINANCE->SFR#27309407_1 starts
 //document.getElementById("BLK_ACCOUNT_MASTER__CCY4").value = document.getElementById("BLK_ACCOUNT_MASTER__CCY").value; 
//	document.getElementById("BLK_ACCOUNT_MASTER__CCY3").value = document.getElementById("BLK_ACCOUNT_MASTER__CCY").value; 
	document.getElementsByName("CCY3").value = document.getElementById("BLK_ACCOUNT_MASTER__CCY").value; 
	document.getElementsByName("CCY4").value = document.getElementById("BLK_ACCOUNT_MASTER__CCY").value; 
 //FCUBS12.4->CNSL->NRSP MICROFINANCE->SFR#27309407_1 ends
 return true;
}
//12.0.2 Amount CCY Changes end. 
 function fnSetSubsysBlocks(state){
	if (state) {
		fnEnableMEBlock("BLK_HOL_PERIODS",true);
		fnEnableMEBlock("BLK_EFFEC_DATE",true);
		fnEnableMEBlock("BLK_UDE_VALS",true);
		fnEnableMEBlock("BLK_COMP_SCH",true);
	}
	else{
		fnEnableMEBlock("BLK_HOL_PERIODS",false);
		fnEnableMEBlock("BLK_EFFEC_DATE",false);
		fnEnableMEBlock("BLK_UDE_VALS",false);
		fnEnableMEBlock("BLK_COMP_SCH",false);
	}
 }
function fnPreProductPickup_KERNEL(){
	var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
	fnCheckSubSysValues(statusStr);
	return true;
}
//19929827 :Fix Propagation to 12.0.3 ~ Retro from 16209928 Starts
function fnPostFocus_KERNEL() {
if (functionId != 'CLDCRASG'){ //[FCUBS12.4->RETRO->26861672; Base#26660335]added
if (dbDataDOM.selectSingleNode("//BLK_ACCOUNT_MASTER/AUTHSTAT").text == 'A')
disablebutton('Unlock','actions2');
//FCUBS12.4->SAIGON COMMERCIAL BANK->27907516  starts
		if(document.getElementById("BLK_ACCOUNT_MASTER__AUTHSTAT").value != "" && document.getElementById("BLK_ACCOUNT_MASTER__AUTHSTAT").value == 'U')
			fnToggleSubsystemButton('MSDMSPRV', true); 
		else
			fnToggleSubsystemButton('MSDMSPRV', false); 
//FCUBS12.4->SAIGON COMMERCIAL BANK->27907516  ends	
	return true;
}
}
//19929827 :Fix Propagation to 12.0.3 ~ Retro from 16209928 Ends
function fnPostProductPickup_KERNEL(){
	var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
	fnPopulateSubSystemValues(statusStr);
	fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__BRN"));
	fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__PROD"));
	fnEnableElement(document.getElementById("BLK_ACCOUNT_MASTER__SETTLEMENT_SEQ_NUM")); //[FCUBS->12.1_Multi_Settlement_Instruction]
	fnSetSubsysBlocks(false) ;
	fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__ACCNO")); //17163038:Fix Propagation to 12.0.2 ~ Retro from 14126745 added
	return true;
}
//FCUBS_12.0.3_COMMONWEALTH_BANK_AUSTRALIA_19579252 Changes Starts
function fnPostEnterQuery_KERNEL(){
	//[FCUBS12.4->RETRO->26231734;Base#21777003] Starts
	//fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__BRN"));
	if(typeof(multiBrnAccessReq)!= "undefined" && multiBrnAccessReq=="Y" && multiBrnScrOpened == false && mainWin.gActiveWindow.screenType != "WB")
		{}
	else{
		document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = mainWin.CurrentBranch;
		fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__BRN"));
		}
	//[FCUBS12.4->RETRO->26231734;Base#21777003] Ends
	return true;
}
//FCUBS_12.0.3_COMMONWEALTH_BANK_AUSTRALIA_19579252 Changes Ends
function fnPostExecuteQuery_KERNEL(){
	fnSetSubsysBlocks(false); //18955556:Fix Propagation to 12.0.3 ~ Retro from 15844446 added
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_CREDIT_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_REVN"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_DSBR"));
	fnEnableElement(document.getElementById("BLK_CHG_COMP__BTN_CREDIT_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_SCHDTLS"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_GUADTL")); //15-Mar-10 FCUBS11.1 MB0403
	fnEnableElement(document.getElementById("BLK_ACCOUNT_MASTER__BTN_COLLTAKOVR")); //9NT1462 FCUBS 11.4 ITR1 SFR 13358228
	fn_ccy(); //12.0.2 Amount CCY Changes.
	fn_ChangeTenor(); //21047543:Fix Propagation to 12.1.0 ~ Retro from 20803844
	/* 124_BANK_OF_SOUTH_PACIFIC_28589467 Begins
	//FCUBS->12.1_Sanction_Check_Changes starts
	if(document.getElementById("BLK_ACCOUNT_MASTER__SANCTION_CHECK_STATUS").value == 'P' || 
	document.getElementById("BLK_ACCOUNT_MASTER__SANCTION_CHECK_STATUS").value == 'X' ||
	document.getElementById("BLK_ACCOUNT_MASTER__SANCTION_CHECK_STATUS").value == 'R')
		{
		if(document.getElementById("BLK_ACCOUNT_MASTER__SANCTION_CHECK_STATUS").value == 'P' || 
		document.getElementById("BLK_ACCOUNT_MASTER__SANCTION_CHECK_STATUS").value == 'X' )
			{
			document.getElementById("Authorize").disabled = true;
			document.getElementById("Authorize").className = "BTNIconD" ;
			document.getElementById("Authorize").innerHTML = "" ;

			document.getElementById("Unlock").disabled = true;
			document.getElementById("Unlock").className = "BTNIconD" ;
			document.getElementById("Unlock").innerHTML = "" ;
			}
		else 
			{
			document.getElementById("Authorize").disabled = true;
			document.getElementById("Authorize").className = "BTNIconD" ;
			document.getElementById("Authorize").innerHTML = "" ;
			}

		}
	else
		{
		if(document.getElementById("BLK_ACCOUNT_MASTER__SANCTION_CHECK_STATUS").value == 'A')

			{
			if (document.getElementById("BLK_ACCOUNT_MASTER__AUTHSTAT").value == 'A')
				{
				document.getElementById("Authorize").disabled = true;
				document.getElementById("Authorize").className = "BTNIconD" ;
				document.getElementById("Authorize").innerHTML = "" ;

				document.getElementById("Unlock").disabled = true;
				document.getElementById("Unlock").className = "BTNIconD" ;
				document.getElementById("Unlock").innerHTML = "" ;

				document.getElementById("Delete").disabled = true;
				document.getElementById("Delete").className = "BTNIconD" ;
				document.getElementById("Delete").innerHTML = "" ;
				}
			}
		}
	//FCUBS->12.1_Sanction_Check_Changes ends
	 124_BANK_OF_SOUTH_PACIFIC_28589467 Ends */
	return true;
}
function fnPostUnlock_KERNEL() {
	fnToggleSubsystemButton('MSDMSPRV', false);  //FCUBS12.4->SAIGON COMMERCIAL BANK->27907516  
	fnEnableElement(document.getElementById("BLK_ACCOUNT_MASTER__BTN_DEFAULT"));
	fnEnableElement(document.getElementById("BLK_ACCOUNT_MASTER__BTN_ENRICH"));
	fnEnableElement(document.getElementById("BLK_ACCOUNT_MASTER__BTN_EDITUDE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_EDIT"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_EXPLODE"));
	fnEnableElement(document.getElementById("BLK_ACCOUNT_MASTER__BTN_EDITHOL"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_CREDIT_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_REVN"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_DSBR"));
	fnEnableElement(document.getElementById("BLK_CHG_COMP__BTN_CREDIT_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_SCHDTLS"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_GUADTL")); //15-Mar-10 FCUBS11.1 MB0403
	fnEnableElement(document.getElementById("BLK_ACCOUNT_MASTER__BTN_COLLTAKOVR")); //9NT1462 FCUBS 11.4 ITR1 SFR 13358228

	//14517741:Fix Propagation to 12.0~Retro from 13918923 starts
	
	document.getElementById("cmdAddRow_BLK_CLVWS_ACCOUNT_UDF_CHAR").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CLVWS_ACCOUNT_UDF_CHAR").style.visibility="HIDDEN";			
	document.getElementById("cmdAddRow_BLK_CLVWS_ACCOUNT_UDF_NUM").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CLVWS_ACCOUNT_UDF_NUM").style.visibility="HIDDEN";			
	document.getElementById("cmdAddRow_BLK_CLVWS_ACCOUNT_UDF_DATE").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CLVWS_ACCOUNT_UDF_DATE").style.visibility="HIDDEN";
	
	var l = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows.length;
        	
		for (var i=1;i<=l;i++)	{
		
	      if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')
	        if (i<=l)
	           if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='C')
		  {//12.0->USDIFAD->15889589 change
		  
		  document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[2].getElementsByTagName("INPUT")[0].nextSibling.className="hidden";
		  //12.0->USDIFAD->15889589 starts
		  document.getElementsByName('FIELD_CHAR_1')[i-1].setAttribute('onblur',"fnudfval()");
		  }
		  //12.0->USDIFAD->15889589 ends
		}
		
	  var m = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows.length;
         for (var i=1;i<=m;i++)	{
	
		if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')
	      if (i<=m)
	        if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='C')
		
                     document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[2].getElementsByTagName("INPUT")[1].nextSibling.className="hidden";//FBNLGBP_11.3_14134251
		
		}
	
	//14517741:Fix Propagation to 12.0~Retro from 13918923 ENDS
	fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__PROD")); //Fwd_PortFCUBS12.1_INTERNAL_21182492
	fnSetSubsysBlocks(false) ;//[FCUBS12.4->RETRO->26232379;Base#22848623]
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}
function fnEnrichPickup(){
 //[FCUBS12.4->RETRO->26232418;Base#25181976] start
	if (functionId == "CLDMNROL" ||functionId == "CLDEMINT"||functionId == "CLDINANT"||functionId == "CLDSIMNT"||functionId == "MFDACCNT"||functionId == "MODACCNT")
	{
		gAction = "NEW";
	}
	//[FCUBS12.4->RETRO->26232418;Base#25181976] Ends
	g_enrich='Y';//Fcubs_12.4_KYRGYZ INVESTMENT AND CREDIT BANK_BUG#27983724 added
	//FCUBS12.4->UNICREDIT BULBANK AD->28698565 start
	appendTabData(document.getElementById("TBLPage" + strCurrentTabId));
	fnBuildTabHTML(); 
	//FCUBS12.4->UNICREDIT BULBANK AD->28698565 end
   	if (!fnPickUpSubSystem("ENRICH", "", "", "")) {
	 document.getElementById("BLK_ACCOUNT_MASTER__CALCGP").disabled = true;  // [FCUBS12.1-INTERNAL-IQA-21318773]
	 fnSetSubsysBlocks(false) ; //18955556:Fix Propagation to 12.0.3 ~ Retro from 15844446 added
         return;
	}
	fnSetSubsysBlocks(false) ;
	
}
function fnpopcomp(){
   //SFR#1473 Changes Start
   //fnLaunchSubSreens('CVS_CMP_SETT_MODE','CLDACCNT','CLDACCNT');
    var e = mainWin.event || e;
	currRow = getRowIndex(e);
	fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_CMP_SETT_MODE',false);
	//SFR#1473 Changes End
}
function fnpopchg(){
	//SFR#1473 Changes Start
    //fnLaunchSubSreens('CVS_CHG_SETT_MODE','CLDACCNT','CLDACCNT');
    var e = mainWin.event || e;
	currRow = getRowIndex(e);
	fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_CHG_SETT_MODE',false);
	//SFR#1473 Changes End
}
function fnpoprevn(){
	//SFR#1473 Changes Start
	//fnLaunchSubSreens('CVS_REVN','CLDACCNT','CLDACCNT');
	var e = mainWin.event || e;
	currRow = getRowIndex(e);
	fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_REVN',false);
	//SFR#1473 Changes End
}
function fnpopdsbr(){
	//SFR#1473 Changes Start
	//fnLaunchSubSreens('CVS_DSBR','CLDACCNT','CLDACCNT');
	var e = mainWin.event || e;
	currRow = getRowIndex(e);
	fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_DSBR',false);
	//SFR#1473 Changes End
}
function fnpopschdls(){
	//SFR#1473 Changes Start
   //fnLaunchSubSreens('CVS_SCHEDULES','CLDACCNT','CLDACCNT');
   var e = mainWin.event || e;
	currRow = getRowIndex(e);
	fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_SCHEDULES',false);
	//SFR#1473 Changes End
}
function fnpopdetail(){
	if (document.getElementsByName("PROD")[0].value != '')
	{
		//SFR#1473 Changes Start
		//fnLaunchSubSreens('CVS_MAT_DET','CLDACCNT','CLDACCNT');
		var e = mainWin.event || e;
		currRow = getRowIndex(e);
		fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_MAT_DET',false);
		//SFR#1473 Changes End
	}
}
 function fnEditHol(){
	fnEnableMEBlock("BLK_HOL_PERIODS",true);
	var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
	var stat = extractSubSysStat(statusStr, "HOLPERIODS");
	var subsys="HOLPERIODS";
	if (stat == 'S'){
	   statusStr = statusStr.replace(subsys + ':S', subsys + ':U');
	   fnSetDependentServices("HOLPERIODS", statusStr) ;
	   document.getElementsByName('SUBSYSSTAT')[0].value= statusStr;
	}
 }
function fneditude() {
 	fnEnableMEBlock("BLK_EFFEC_DATE",true);
	fnEnableMEBlock("BLK_UDE_VALS",true);
	g_enrich ='N'; //BUG#28155759 included 
	var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
	var stat = extractSubSysStat(statusStr, "UDEVALS");
	var subsys="UDEVALS";
	if (stat == 'S'){
	   statusStr = statusStr.replace(subsys + ':S', subsys + ':U');
	   fnSetDependentServices("UDEVALS", statusStr) ;
	   document.getElementsByName('SUBSYSSTAT')[0].value= statusStr;
	}
 }
 function fneditsch(){
	fnEnableMEBlock("BLK_COMP_SCH",true);
	//BUG#27976303 commented start
	//[FCUBS12.4->RETRO->26384638; Base#26328954] starts
	/* var l_disable = true;
	 try
	 {
		l_disable = fncheckinterestAmount();
	 }
	 catch(e){
		 
	 };
	
	 if (l_disable)
	 {
		////[FCUBS12.4->RETRO->26384638; Base#26328954] ends
	//BUG#25589169_1 STARTS
	var l = document.getElementById("BLK_COMP_SCH").tBodies[0].rows.length;
	if(document.getElementById("BLK_COMPONENTS__COMPTYP").value=='I') 
		
	for (var i=1;i<=l;i++)	{
	
	
	fnDisableElement(document.getElementById("BLK_COMP_SCH").tBodies[0].rows[i-1].cells[10].getElementsByTagName("INPUT")[0]);
	
	}
	//BUG#25589169_1  ENDS
	} ////[FCUBS12.4->RETRO->26384638; Base#26328954] included*/
var l = document.getElementById("BLK_COMP_SCH").tBodies[0].rows.length;
		for (var i=1;i<=l;i++)	{
			if (document.getElementsByName("SPLINT")[0].checked == false &&
			document.getElementsByName("COMPTYP")[0].value !='L')
		  {
            fnDisableElement(document.getElementById("BLK_COMP_SCH").tBodies[0].rows[i-1].cells[10].getElementsByTagName("INPUT")[0]);			  
		  }
	}
	//BUG#27976303 end
	var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
	var stat = extractSubSysStat(statusStr, "COMPSCH");
	var subsys="COMPSCH";
	if (stat == 'S'){
	   statusStr = statusStr.replace(subsys + ':S', subsys + ':U');
	   fnSetDependentServices("COMPSCH", statusStr) ;
	   document.getElementsByName('SUBSYSSTAT')[0].value= statusStr;
	}
}
//Fcubs 11.4.0 Kernel ITR 13256716 starts
function fnPostAddRow_BLK_COLL_LINKAGES_KERNEL() { 
var rowcount = document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows.length; 
document.getElementsByName("LINKAGE_BRANCH")[rowcount-1].value = mainWin.CurrentBranch;
document.getElementsByName("LINKAGE_BRANCH")[0].disabled=true;

/*[FCUBS12.3->RETRO->24613348; Base#21442514] starts*/
//return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
var rowcount = document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows.length; 
for (var i=0;i<rowcount;i++)
{
fn_linkage_1(i); 
}
/*[FCUBS12.3->RETRO->24613348; Base#21442514] ends*/
return true; //9NT1606_12_3_RETRO_12_0_3_25402446 changes 
}
//Fcubs 11.4.0 Kernel ITR 13256716 ends
//FCUBSVER: 12.0.3, KERNEL, Item: Interest rate pickup UT2 start
function fnPostAddRow_BLK_LINKAGES_KERNEL() { 

	var linkagecount = document.getElementById("BLK_LINKAGES").tBodies[0].rows.length;
	document.getElementById("BLK_LINKAGES").tBodies[0].rows[linkagecount-1].cells[2].getElementsByTagName("SELECT")[0].value = "M";
	document.getElementById("BLK_LINKAGES").tBodies[0].rows[linkagecount-1].cells[2].getElementsByTagName("SELECT")[0].disabled = true;
	
return true; 
}
//FCUBSVER: 12.0.3, KERNEL, Item: Interest rate pickup UT2 ends
//fcubs12.0.3_ZAO UNICREDIT BANK_19472423 start
function  fnPostDeleteRow_BLK_LINKAGES_KERNEL()
{
var linkagecount = document.getElementById("BLK_LINKAGES").tBodies[0].rows.length;
	for (var i=1;i<=linkagecount;i++)	{
		document.getElementById("BLK_LINKAGES").tBodies[0].rows[i-1].cells[2].getElementsByTagName("SELECT")[0].disabled = true;
		}
  return true;
}
//fcubs12.0.3_ZAO UNICREDIT BANK_19472423 end
function fnexplodesch(){
	//[FCUBS12.4->RETRO->26232418;Base#25181976] Starts
	if (functionId == "CLDMNROL"||functionId == "CLDEMINT"||functionId == "CLDINANT"||functionId == "CLDSIMNT"||functionId == "MFDACCNT"||functionId == "MODACCNT")
	{
		gAction = "NEW";
	}
	//[FCUBS12.4->RETRO->26232418;Base#25181976] Ends
   	if (!fnPickUpSubSystem("ENRICH", "", "", "")) {
	document.getElementById("BLK_ACCOUNT_MASTER__CALCGP").disabled = true;  // [FCUBS12.1-INTERNAL-IQA-21318773]
	 fnSetSubsysBlocks(false) ; //18955556:Fix Propagation to 12.0.3 ~ Retro from 15844446 added
         return;
	}
}
//SITECODE: 12.1, KERNEL, Item:Revision Schedules starts
function fnredefaultschedules(){
	var prevAction = gAction;
	appendData();
    gAction ="HOLDFLT";
	fcjRequestDOM = buildUBSXml();
    servletURL = "FCClientHandler";
    fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
    var msgStatus = fnProcessResponse();
    gAction=prevAction;
	if(fcjResponseDOM) {
			var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
			if (msgStatus == 'FAILURE') {
					  return false;
				 }
				 }
	return true;
}
//SITECODE: 12.1, KERNEL, Item:Revision Schedules ends

function fnPreReverse_KERNEL() {
	//SFR#1473 Changes Start
	//fnLaunchSubSreens('CVS_REVERSE','CLDACCNT','CLDACCNT');
	//var e = mainWin.event || e;
	//currRow = getRowIndex(e);
	fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_REVERSE',false);
	//SFR#1473 Changes End
	//FCUBS12.4->UNICREDIT BULBANK->BUG#28760531 starts
//	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES [FCUBS12.3->RETRO->17396475; Base#23631949] commented--[FCUBS12.3-INTERNAL-MAT-24846411]_uncommented
	//return false;//[FCUBS12.3->RETRO->17396475; Base#23631949] added--[FCUBS12.3-INTERNAL-MAT-24846411]_commented
	return false;
	//FCUBS12.4->UNICREDIT BULBANK->BUG#ends added
}

//FCUBS11.1 ITR1 SFR#2316 Starts..
function fnPreSave_CVS_REVERSE_KERNEL(){
	mask();
    showAlerts(fnBuildAlertXML("", "I", mainWin.getItemDesc("LBL_REVERSE_DESC")), "C");
    customAlertAction= "REVERSEACTION1";
	return false;
}
function fnCloseAlertWin_REVERSEACTION1() {
	//unmask();
	appendData();
	parent.dbDataDOM = dbDataDOM;
	parent.reverse();
	// SFR->16561070 The Below piece of code is not required and it is commented.
	// parent.fromRemarksReqd = true; //FCUBS11.1 ITR2 SFR#259 ADDED
	parent.fnExitSubScreen(parentScrID, launcherDIVWidth, launcherIFWidth, launcherDIVHeight, launcherIFHeight, launcherResTreeWidth, launcherResTreeHeight, launcherHeaderWidth, launcherLeft);
}

function reverse() {
    processingAction = 'Reverse';
	gAction = "REVERSE";
	appendData();
       fcjRequestDOM = buildUBSXml();
       fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
       var msgStatus = fnProcessResponse();
       fnPostProcessResponse(msgStatus);
}

//FCUBS_12.0.0 DMS changes starts
function fnPreLoad_CVS_UPDOC_KERNEL(screenArgs) {
	
	screenArgs['FLAG_STATUS'] = 'true';
	screenArgs['FUNCT_ID'] = functionId;
	return true;
}
// FCUBS_12.0.0 DMS changes ends

/*function fnPreSave_CVS_REVERSE_KERNEL(){
	fnCallBackEnd('REVERSE');
	if (!fnProcessResponse()) {}
	fnSetExitButton(false);
	fnExitSubScreen();
}
function fnPostReverse_KERNEL() {
	fnCallBackEnd('EXECUTEQUERY');
	if (!fnProcessResponse()) {}
	fnSetExitButton(false);
}*/

//FCUBS11.1 ITR1 SFR#2316 Ends..

 function fnPreAuthorize_KERNEL() {
 
 // 9NT1525-12.0-INTERNAL-15911202 starts
 gAction = 'EXTRACTKEYINFO';
     fcjRequestDOM = buildUBSXml();
     fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	if(fcjResponseDOM) {
		var msgStatus   =getNodeText( selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		if (msgStatus == 'FAILURE') {
                  authFunction   = '';
				  //FCUBS11.4_P04_14615940 starts 
                  //showErrorAlerts('CL-ACNT07');
				  //FCUBS_124_INTERNAL_26624850_RETRO_FROM_26613688  starts
				//  var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
				var messageNode =getXMLString(selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP"));
				//FCUBS_124_INTERNAL_26624850_RETRO_FROM_26613688 ends
			      var returnVal = displayResponse(messageNode,msgStatus,'E',"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
				  //FCUBS11.4_P04_14615940 ends
	  // FCUBS_12.3_RETRO_BUG#25101778 starts
                 //return false;
	  //FCUBS_12.3_RETRO_BUG#25101778  ends
		 //[FCUBS12.4->RETRO->26231982;Base#24922767] start
		 var returnVal = displayResponse(messageNode);
		 mask();
		 displayResponse(messageNode);
		 //[FCUBS12.4->RETRO->26231982;Base#24922767] end
	         }

		if(msgStatus == 'SUCCESS'||msgStatus == 'WARNING') {
 // 9NT1525-12.0-INTERNAL-15911202 ends
	authFunction   = 'CLDACAUT';
	authUixml      = 'CLDACAUT';
	authScreenName = 'CVS_AUTHORIZE';
	gAction = 'EXECUTEQUERY';
	ArrFuncOrigin['CLDACAUT']="KERNEL";
	ArrPrntFunc['CLDACAUT'] = "";
	ArrPrntOrigin['CLDACAUT'] ="";
	return true;
	// 9NT1525-12.0-INTERNAL-15911202 starts
	}
            }
	// 9NT1525-12.0-INTERNAL-15911202 ends
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}

function fnPostAuthorize_KERNEL() {
	fnCallBackEnd('EXECUTEQUERY');
	fnSetExitButton(false);
	debugs("In fnPostAuthorize ", "A");
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}

function fnPostNew_KERNEL() {
    //document.getElementById("BLK_ACCOUNT_MASTER__PROD").focus();
//FCUBS12.1_SCO_Bank_Changes Starts
	if((typeof(mainWin.gCustInfo["AccntNo"])== 'undefined' || mainWin.gCustInfo["AccntNo"]=='') && (typeof(mainWin.gCustInfo["Branch"])== 'undefined' || mainWin.gCustInfo["Branch"]=='') &&(typeof(mainWin.gCustInfo["CustNo"])!='undefined' && mainWin.gCustInfo["CustNo"]!=''))
{
 document.getElementById("BLK_ACCOUNT_MASTER__CUSTID").value = mainWin.gCustInfo["CustNo"];
 }
if (document.getElementById("BLK_ACCOUNT_MASTER__BRN").value == undefined || document.getElementById("BLK_ACCOUNT_MASTER__BRN").value == ''){ 
 document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = mainWin.CurrentBranch;
 }
 
 //FCUBS12.1_SCO_Bank_Changes Ends
 // [FCUBS->12.1_Multi_Settlement_Instruction] starts	
	fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__SETTLEMENT_SEQ_NUM"));
	document.getElementById("BLK_ACCOUNT_MASTER__SETTLEMENT_SEQ_NUM").value = 0;
// [FCUBS->12.1_Multi_Settlement_Instruction] ends	
	//--FCUBS12.2.0->CNSL->NEW ZEALAND ASSOCIATION OF CREDIT UNIONS;SFR#24437525 Start
	/*
	document.getElementsByName("BTN_EDIT")[0].disabled=false;
	document.getElementsByName("BTN_EXPLODE")[0].disabled=false;
	fnEnableElement(document.getElementById("BLK_ACCOUNT_MASTER__BTN_CR_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_CREDIT_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_REVN"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_DSBR"));
	fnEnableElement(document.getElementById("BLK_CHG_COMP__BTN_CREDIT_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_SCHDTLS"));
	*/
	//--FCUBS12.2.0->CNSL->NEW ZEALAND ASSOCIATION OF CREDIT UNIONS;SFR#24437525 End
        //centralisation in 9NT1368  Cluster  starts
         var newAction = true;
	debugs("In fnPreNew", "A");
	if (!fnShowTxnBrnScreen())
	{	//--FCUBS12.2.0->CNSL->NEW ZEALAND ASSOCIATION OF CREDIT UNIONS;SFR#24437525 End
		newAction = false;
	return newAction;
	}	//--FCUBS12.2.0->CNSL->NEW ZEALAND ASSOCIATION OF CREDIT UNIONS;SFR#24437525 End

        //centralisation in 9NT1368  Cluster  ends
        return true;
}
function fnPostLoad_KERNEL(){
	
	try{ //[FCUBS12.4->RETRO->26233743; Base#23188301]
	//[FCUBS12.4->RETRO->26232002; Base#23113085] start
	if((parent.screenArgs['PARENT_FUNC_ID'] == 'ACDTRNQY') ||
		(parent.screenArgs['PARENT_FUNC_ID'] == 'ACDBIRAC'))
	{
	if(parent.screenArgs) {
	var prevgAction = gAction;
		fnEnterQuery();
		document.getElementById('BLK_ACCOUNT_MASTER__ACCNO').value = parent.screenArgs['RELTDACC'];
		document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = parent.screenArgs['BRN'];
		gAction = "EXECUTEQUERY";
		fnExecuteQuery();
		gAction = prevgAction;
		parent.screenArgs['PARENT_FUNC_ID'] = '';
	}
	}
	//[FCUBS12.4->RETRO->26232002; Base#23113085] end
  }catch(e){} //[FCUBS12.4->RETRO->26233743; Base#23188301]
//Sandhyusha:: collections  starts
	try{ //[FCUBS12.4->RETRO->26233743; Base#23188301]
	  var parentWin = fnGetParentWin();
//FCUBS12.1_SCO_Bank_Changes Starts
try{//FCUBS_12.4_NRSP MICROFINANCE BANK LIMITED_30132566_RETRO_23272626 added
if(typeof(mainWin.gCustInfo["AccntNo"])!= 'undefined' && mainWin.gCustInfo["AccntNo"]!='' && typeof(mainWin.gCustInfo["Branch"])!= 'undefined' && mainWin.gCustInfo["Branch"]!='' && mainWin.gCustInfo["FunctionId"]=='CLDACSMR'){//FCUBS12.0.2_SCO_Bank_Changes_20901864 adds function CLDACSMR
fnEnterQuery();
gAction = "EXECUTEQUERY";  
  document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value = mainWin.gCustInfo["AccntNo"];  
  document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = mainWin.gCustInfo["Branch"];
  fnExecuteQuery();
}
//FCUBS_12.4_NRSP MICROFINANCE BANK LIMITED_30132566_RETRO_23272626 starts
}catch(e) {} 
try{
//FCUBS_12.4_NRSP MICROFINANCE BANK LIMITED_30132566_RETRO_23272626 ends
if((typeof(mainWin.gCustInfo["AccntNo"])== 'undefined' || mainWin.gCustInfo["AccntNo"]=='') && (typeof(mainWin.gCustInfo["Branch"])== 'undefined' || mainWin.gCustInfo["Branch"]=='') &&(typeof(mainWin.gCustInfo["CustNo"])!='undefined' && mainWin.gCustInfo["CustNo"]!='') && ShowSummary =='FALSE' && parentWin.functionId != 'undefined' && parentWin.functionId != '' && (parentWin.functionId != 'STDRETVW' && parentWin.functionId != 'STDCUSVW'))
 
{
gAction = "NEW"; 
 fireHTMLEvent(document.getElementById("New").children[0], "onclick");
 document.getElementById("BLK_ACCOUNT_MASTER__CUSTID").value = mainWin.gCustInfo["CustNo"];  
 }
 }catch(e) {} //FCUBS_12.4_NRSP MICROFINANCE BANK LIMITED_30132566_RETRO_23272626 added 
//FCUBS12.1_SCO_Bank_Changes Ends
//[FCUBS12.4->RETRO->26233743; Base#23188301] start
}catch(e){}
try{
//[FCUBS12.4->RETRO->26233743; Base#23188301] end	
	   //if(parentWin.parentWinParams.callingfunc == 'CNDDASH')
            if(parentWin.functionId == 'CNDCADSH'||parentWin.functionId == 'CNDASQRY')
	   {
	   fnEnterQuery();//sandy added
	  document.getElementById("BLK_ACCOUNT_MASTER__BRN").value =  mainWin.CurrentBranch; 
      document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value = parentWin.accno;		
	        var gprev = gAction;
            gAction = "EXECUTEQUERY";
            fnExecuteQuery();
            if(document.getElementsByName("AUTH_STAT")[0].checked == false)
                fnDisableSignButtons();
            else
                fnEnableSignButtons();
            gAction=gprev;
			}
	  }catch(e){} //[FCUBS12.4->RETRO->26233743; Base#23188301]
	 //Sandhyusha:: collections ends
		  	// FCUBS_11.3.0_P01_FC11.0_IMPSUPP_285Starts
		//[FCUBS12.4->RETRO->26232002; Base#23113085] start code moved above
     /*if(parent.screenArgs) {
	var prevgAction = gAction;
	if(parent.screenArgs)
	//FCUBS12.0.3_Internal_19294312 starts
	//if(parent.screenArgs['PARENT_FUNC_ID'] == "ACDBIRAC") {
	if((parent.screenArgs['PARENT_FUNC_ID'] == 'ACDTRNQY') ||
		(parent.screenArgs['PARENT_FUNC_ID'] == 'ACDBIRAC'))
	{
	//FCUBS12.0.3_Internal_19294312 ends
		fnEnterQuery();
		//document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value = parent.screenArgs['ACCNO']; //FCUBS12.0.3_Internal_19294312
		document.getElementById('BLK_ACCOUNT_MASTER__ACCNO').value = parent.screenArgs['RELTDACC']; //FCUBS12.0.3_Internal_19294312
		document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = parent.screenArgs['BRN'];
		gAction = "EXECUTEQUERY";
		fnExecuteQuery();
		gAction = prevgAction;
		parent.screenArgs['PARENT_FUNC_ID'] = '';
	}
	}*/
	// FCUBS_11.3.0_P01_FC11.0_IMPSUPP_285ends
	//[FCUBS12.4->RETRO->26232002; Base#23113085] end
   //PNTFLX01011_12.2.0.0.0_Trade_360View Starts
   try{//[FCUBS12.4->RETRO->26233743; Base#23188301] added
	if (parentWin.parentWinParams.CALLFORM=='LOANDET' ) { 
	 if (parentWin.parentWinParams.PARENT_FUNC_ID== "STDTRDVW")
	  {	
	  fnEnterQuery();
	  document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value = parentWin.parentWinParams.ACCOUNT_NUMBER;
	  gAction= "EXECUTEQUERY";
	   fnExecuteQuery();
	   }
	   }
	   }catch(e){} //[FCUBS12.4->RETRO->26233743; Base#23188301]	
   //PNTFLX01011_12.2.0.0.0_Trade_360View Ends	
	// [FCUBS12.1-INTERNAL-ITR1-21557585] starts
	
	//NEW_ZEALAND_12.2_25104686 starts
	try{//[FCUBS12.4->RETRO->26233743; Base#23188301] added
	if(parent.screenArgs) {
	//NEW_ZEALAND_12.2_25104686 ends
	 if(parent.screenArgs['PARENT_FUNC_ID'] == 'CLDENTTY')
	{
	fnEnterQuery();
	document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value =  parent.screenArgs['ACCNO']; 
	document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = parent.screenArgs['BRN'];		
	gAction = "EXECUTEQUERY";
	fnExecuteQuery();
	}
	} //NEW_ZEALAND_12.2_25104686 added
	}catch(e){} //[FCUBS12.4->RETRO->26233743; Base#23188301]
	
	// [FCUBS12.1-INTERNAL-ITR1-21557585] ends
//9NT1466 11.3.1 360 Degree Customer View Changes starts
	var parentWin = fnGetParentWin();
	try{//[FCUBS12.4->RETRO->26233743; Base#23188301] added
	if (parentWin.parentWinParams.CALLFORM =='LOANDET' ) { 
	 if (parentWin != "") 
	  {	
	  fnEnterQuery();
	  document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = parentWin.parentWinParams.BRANCH; 
	  document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value = parentWin.parentWinParams.ACCOUNT_NUMBER;
	  gAction= "EXECUTEQUERY";
	   fnExecuteQuery();
	   }
	   }
	   }catch(e){} //[FCUBS12.4->RETRO->26233743; Base#23188301]
	   try{//[FCUBS12.4->RETRO->26233743; Base#23188301] added
	 // [FCUBS12.1->Forward Port->->20658866->20988303] Starts
	
    if (parentWin.parentWinParams.PARENT_FUNC_ID=="OVDAUDEF")
	{
		var g_prv_actn = gAction;
     	gAction = "ENTERQUERY";
	  	fnEnterQuery();
	  	document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value = parentWin.parentWinParams.CONTRACT_REF_NO;
		//document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = parentWin.parentWinParams.BRN;
	  	gAction= "EXECUTEQUERY";
	   	fnExecuteQuery();		
		showToolbar('', '', '', '');		
	}
	}catch(e){} //[FCUBS12.4->RETRO->26233743; Base#23188301]
	 // [FCUBS12.1->Forward Port->->20658866->20988303] Ends
	//9NT1466 11.3.1 360 Degree Customer View Changes ends
	/*[FCUBS12.1-INTERNAL-IQA-21246702] commented Starts
//FCUBS12.1_Trade_360View Changes Starts
	if (parentWin.parentWinParams.CALLFORM='LOANDET' ) { 
	 if (parentWin.parentWinParams.PARENT_FUNC_ID== "STDTRDVW")
	  {	
	  fnEnterQuery();
	  document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value = parentWin.parentWinParams.ACCOUNT_NUMBER;
	  gAction= "EXECUTEQUERY";
	   fnExecuteQuery();
	   }

	   }
//FCUBS12.1_Trade_360View Changes Ends
[FCUBS12.1-INTERNAL-IQA-21246702] Ends*/
	/* //FCUBS_11.3.0_P01_FC11.0_IMPSUPP_285 - Commented
	document.getElementById("cmdAddRow_BLK_CHECKLIST").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CHECKLIST").style.visibility="HIDDEN";
	document.getElementById("cmdAddRow_BLK_ADVICES").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_ADVICES").style.visibility="HIDDEN";
	//01-MARCH-2011 CHANGES STARTS
	var parentWin = fnGetParentWin();
	if(parentWin.parentWinParams.PARENT_FUNC_ID == 'ACDBIRAC')
      {
	  var parentWin = fnGetParentWin();
	if (parentWin.parentWinParams['DFLT_QRY'] ==  "Y" ) {
      document.getElementById("BLK_ACCOUNT_MASTER__BRN").value = mainWin.CurrentBranch; 
      document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value = parentWin.parentWinParams.ACC;
      //fnExecuteQuery_sum('Y');
	  			   gFromSummary = false;
			   gAction = "EXECUTEQUERY";			   
			   fnExecuteQuery();
      }
	  }
	*/	  //01-MARCH-2011 CHANGES ENDS

	return true;
}

//SFR#1473 Changes Start
/*function fnLaunchSubSreens(screenName,functionId,uiXml){
	screenArgs = new Array();
	screenArgs['SCREEN_NAME'] = screenName;
	screenArgs['FUNCTION_ID'] = functionId;
	screenArgs['LANG'] = mainWin.LangCode;
	screenArgs['UI_XML'] = uiXml;
	//15-Mar-10 FCUBS11.1 MB0403 : added the scr name in the below if stmt
	if (screenName=='CVS_SETT_MODE'||screenName=='CVS_CMP_SETT_MODE'||screenName=='CVS_CHG_SETT_MODE'||screenName=='CVS_SCHEDULES'||screenName=='CVS_GUA_DTLS'){
		screenArgs['BRNCODE'] =document.getElementById('BLK_ACCOUNT_MASTER__BRN').value;
		screenArgs['ACCNO'] =document.getElementById('BLK_ACCOUNT_MASTER__ACCNO').value;
		screenArgs['COMPNAME']=document.getElementById('BLK_COMPONENTS__COMPNAME').value;
	}
	appendData(document.getElementById('TBLPageALL'));
	screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+mainWin.LangCode+'/'+uiXml+'.xml',screenArgs['SCREEN_NAME']);
	fnShowSubScreen(screenArgs);*/

function fnSubScreenMain(v_functionID, v_UiXml, v_scrName,v_Auth) {
    debugs("FunctionId~xmlFileName~ScreenName=", functionId+"~"+v_UiXml+"~"+v_scrName);
	//[FCUBS12.4->RETRO->26234032;Base#21206103] starts
	mainWin.fnUpdateScreenSaverInterval();
	if (!mainWin.isSessionActive()) {
		return;
	}
	if (v_UiXml == "") {
		v_UiXml = v_functionID;
	}
	var scrChldFnId = "";
	if (v_functionID == functionId) {
		if (typeof(scrChild) != "undefined" && scrChild == "Y") {
			scrChldFnId = v_functionID;
			v_functionID = parentFunction;
		}
	}
	//[FCUBS12.4->RETRO->26234032;Base#21206103] ends
	//FCUBS12.1_CL_MAT_21316998 starts
	if (gAction == '' || gAction == 'EXECUTEQUERY') {
		var prevAction = gAction;
		gAction = "LOADCALLFORMS";
		fnBuildFullDOM();/* Added for MultipleEntry DOM changes */
		gAction = prevAction;
    }
	//FCUBS12.1_CL_MAT_21316998 ends
	//[FCUBS12.4->RETRO->26234032;Base#21206103] starts
	// [FCUBS->12.1_Multi_Settlement_Instruction] STARTS
	/*if (v_functionID == functionId) {
		if (typeof (scrChild) != "undefined" && scrChild == "Y") {
			v_functionID = parentFunction;
		}
    }*/
	// [FCUBS->12.1_Multi_Settlement_Instruction] ENDS
	/*screenArgs = new Array();
    screenArgs['SCREEN_NAME']   = v_scrName;
    screenArgs['FUNCTION_ID']   = v_functionID;
    screenArgs['LANG']          = mainWin.LangCode;
    screenArgs['UIXML']         = v_UiXml;
    screenArgs['FUNC_ORIGIN']   = ArrFuncOrigin[v_functionID];
    screenArgs['PRNT_FUNC']     = ArrPrntFunc[v_functionID];
    screenArgs['PRNT_ORIGIN']   = ArrPrntOrigin[v_functionID];*/
	screenArgs = new Array();
	screenArgs["SCREEN_NAME"] = v_scrName;
	screenArgs["FUNCTION_ID"] = v_functionID;
	screenArgs["LANG"] = mainWin.LangCode;
	screenArgs["UIXML"] = v_UiXml;
	screenArgs["SCR_CHLD_FNID"] = scrChldFnId;
	if (typeof(ArrFuncOrigin[v_functionID]) == "undefined") {
		screenArgs["FUNC_ORIGIN"] = ArrFuncOrigin[functionId];
		screenArgs["PRNT_FUNC"] = ArrPrntFunc[functionId];
		screenArgs["PRNT_ORIGIN"] = ArrPrntOrigin[functionId];
	} else {
		screenArgs["FUNC_ORIGIN"] = ArrFuncOrigin[v_functionID];
		screenArgs["PRNT_FUNC"] = ArrPrntFunc[v_functionID];
		screenArgs["PRNT_ORIGIN"] = ArrPrntOrigin[v_functionID];
	}
	//[FCUBS12.4->RETRO->26234032;Base#21206103] ends
    //[FCUBS12.3->Retro->24702528] Start
	//FCUBS12.2->CNSL->BANK MED SAL;SFR#24730357 Start
	if (typeof(ArrClusterModified[v_functionID]) == "undefined") {
		screenArgs["CLUSTER_MOD"] = ArrClusterModified[functionId];
	} else {
		screenArgs["CLUSTER_MOD"] = ArrClusterModified[v_functionID];
	}
	if (typeof(ArrCustomModified[v_functionID]) == "undefined") {
		screenArgs["CUSTOM_MOD"] = ArrCustomModified[functionId];
	} else {
		screenArgs["CUSTOM_MOD"] = ArrCustomModified[v_functionID];
	}	
	//FCUBS12.2->CNSL->BANK MED SAL;SFR#24730357 End
    //[FCUBS12.3->Retro->24702528] End
	//Fwd_PortFCUBS12.1_INTERNAL_21182488 Starts
    //screenArgs['DESCRIPTION']   = fnGetSubScreenTitle('UIXML/'+screenArgs['LANG']+'/'+screenArgs['FUNCTION_ID']+'.xml', screenArgs['SCREEN_NAME']);
	//Fwd_PortFCUBS12.1_INTERNAL_21182476 starts
	//screenArgs['DESCRIPTION']   = fnGetSubScreenTitle('UIXML/'+screenArgs['LANG']+'/'+screenArgs['UIXML']+'.xml', screenArgs['SCREEN_NAME']);    //Fwd_PortFCUBS12.1_INTERNAL_21182476 commented
	if (screenArgs['SCREEN_NAME'] == 'CVS_INVQRY')
	{
	screenArgs['DESCRIPTION']   = fnGetSubScreenTitle('UIXML/'+screenArgs['LANG']+'/'+screenArgs['UIXML']+'.xml', screenArgs['SCREEN_NAME']);
	}
	else
	{
    screenArgs['DESCRIPTION']   = fnGetSubScreenTitle('UIXML/'+screenArgs['LANG']+'/'+screenArgs['FUNCTION_ID']+'.xml', screenArgs['SCREEN_NAME']);	
	}
	//Fwd_PortFCUBS12.1_INTERNAL_21182476 ends
	//Fwd_PortFCUBS12.1_INTERNAL_21182488 Ends
    if (v_scrName=='CVS_SETT_MODE'||v_scrName=='CVS_CMP_SETT_MODE'||v_scrName=='CVS_CHG_SETT_MODE'||v_scrName=='CVS_SCHEDULES'||v_scrName=='CVS_REIMB_MODE'){//12.0.2-ISMEMYR-17560674(propagated from 17466270)  added CVS_REIMB_MODE in if condition
	screenArgs['BRNCODE'] =document.getElementById('BLK_ACCOUNT_MASTER__BRN').value;
	screenArgs['ACCNO'] =document.getElementById('BLK_ACCOUNT_MASTER__ACCNO').value;
	if (document.getElementById('BLK_COMPONENTS__COMPNAME')) // Fcubs 11.4.0 kernel ITR # 13248133 thilagam
		screenArgs['COMPNAME']=document.getElementById('BLK_COMPONENTS__COMPNAME').value;
	}	
	
	//Fcubs 11.4.0 kernel ITR # 13248229 starts
	if (v_scrName == 'CVS_DPMNT')
	{ 
		screenArgs['DOWNPAYAMT'] = document.getElementById("BLK_ACCOUNT_MASTER__DOWNPAYAMT").value;
		screenArgs['ACCNO'] = document.getElementById("BLK_ACCOUNT_MASTER__ACCNO").value; 	
		screenArgs['FUTURDPRECV'] = document.getElementById("BLK_ACC_NEW__FUTDPRECV").value; 
		screenArgs['CCY'] =  document.getElementById("BLK_ACCOUNT_MASTER__CCY").value; 
	}
	
	//Fcubs 11.4.0 kernel ITR # 13248229 ends
    //[FCUBS12.4->RETRO->26234032;Base#21206103] starts
	/*if (v_Auth) {
        fnGetAuthScreenArgs(screenArgs); // this will populate for Authorization screen Only
    }
    subSysFnid = "";
    if(document.getElementsByName('SUBSYSSTAT') && document.getElementsByName('SUBSYSSTAT').length != 0) {
        var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
        if (statusStr != "" && (statusStr.indexOf(v_functionID) != -1 || statusStr.indexOf(v_scrName) != -1)) {
            if (statusStr.indexOf(v_functionID) != -1)
                subSysFnid = v_functionID;
            else
                subSysFnid = v_scrName;
            fnPickUpSubSystem(subSysFnid, v_scrName, v_functionID, screenArgs);
            return;
        }
    }*/
	if (v_Auth) {
		debugs("Calling fnGetAuthScreenArgs", "");
		fnGetAuthScreenArgs(screenArgs);
	}
	subSysFnid = "";
	if (document.getElementsByName("SUBSYSSTAT") && document.getElementsByName("SUBSYSSTAT").length != 0) {
		var statusStr = document.getElementsByName("SUBSYSSTAT")[0].value;
		if (statusStr != "" && (statusStr.indexOf(v_functionID) != -1 || statusStr.indexOf(v_scrName) != -1)) {
			if (statusStr.indexOf(v_functionID) != -1) {
				subSysFnid = v_functionID;
			} else {
				subSysFnid = v_scrName;
			}
			debugs("caling append data subSysFnid", subSysFnid);
			appendData();
			debugs("caling fnBuildTabHTML", "");
			//FCUBS12.4->FIMBANK PLC->28259042 starts
			//fnBuildTabHTML();
			fnBuildTabHTML(true);//  added TRUE
			//FCUBS12.4->FIMBANK PLC->28259042 ENDS
			if (gAction == "NEW") {
				for (var i = 0; i < tab_arr.length; i++) {
					if (strCurrentTabId != tab_arr[i].id) {
						enableForm(document.getElementById("TBLPage" + tab_arr[i].id));
					}
				}
			}
			debugs("caling fnPickUpSubSystem", "");
			fnPickUpSubSystem(subSysFnid, v_scrName, v_functionID, screenArgs);
			return;
		}
	}
	//[FCUBS12.4->RETRO->26234032;Base#21206103] ends
	//9NT1462-- ITR1 -- BUG 13075719 Starts
	gCompPayModeIndex = dbIndexArray['BLK_COMPONENTS'];
	gChgPayModeIndex =dbIndexArray['BLK_CHG_COMP'];
	//9NT1462-- ITR1 -- BUG 13075719 Ends
    fnPostSubScreenMain(v_scrName, v_functionID);
}
//SFR#1473 Changes End
function fnCallBackEnd(actionCd){
    gAction = actionCd;
	fcjRequestDOM = buildUBSXml();
	fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
	setDataXML(getXMLString(pureXMLDOM));
	showData(dbStrRootTableName, 1);
}
//Fcubs 11.4.0 kernel ITR # 13248229 starts
function fnPostLoad_CVS_DPMNT_KERNEL(screenArgs){
	
	document.getElementById('BLK_OTHR_ACCDTLS__ACCNO').value = screenArgs['ACCNO'];
	document.getElementById('BLK_OTHR_ACCDTLS__DOWNPAYAMT').value = screenArgs['DOWNPAYAMT']; 
	document.getElementById('BLK_OTHR_ACCDTLS__FUTURDPRECV').value = screenArgs['FUTURDPRECV'];
	document.getElementById('BLK_OTHR_ACCDTLS__CCY').value = screenArgs['CCY'];
	return true;
}
//Fcubs 11.4.0 kernel ITR # 13248229 Ends
//9NT1462-- IUT -- SFR#934 --Paranthaman --Start
function fnDisableMultipleEntry(l_obj){
    var objs = document.getElementsByName(l_obj);
   
    for (var i = 0; i < objs.length; i++){
        fnDisableElement(objs[i]);
    }
}
//9NT1462-- IUT -- SFR#934 --Paranthaman --Ends

//14749226 Fix Propogation to 12.0 Retro from 14737805 starts
function fnInTab_TAB_CHARGES_KERNEL(){

fnEnableElement(document.getElementById("BLK_CHG_COMP__BTN_CREDIT_MODE"));
fnDisableElement(document.getElementById("BLK_CHG_COMP__COMPNAME"));//FCUBS->12.4->SAIGON COMMERCIAL BANK->SFR#27422093 
//[FCUBS12.4->RETRO->26861741; Base#26802826] start
   //FCUBS12.4->UNICREDIT BULBANK->28884200 start
	/*document.getElementsByName("BTN_ADD_BLK_COMPONENTS")[0].className="BTNhide";
	document.getElementsByName("BTN_REMOVE_BLK_COMPONENTS")[0].className="BTNhide"; */
	//FCUBS12.4->UNICREDIT BULBANK->28884200 end
	document.getElementsByName("BTN_ADD_BLK_CHG_COMP")[0].className="BTNhide";
	document.getElementsByName("BTN_REMOVE_BLK_CHG_COMP")[0].className="BTNhide";
//[FCUBS12.4->RETRO->26861741; Base#26802826] end	
fnchgLiqnmode();//FCUBS_12.0.3_IRONVBR_19235047
return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}
//14749226 Fix Propogation to 12.0 Retro from 14737805 ends
function fnInTab_TAB_COMPONENTS_KERNEL(){
   //9NT1462-- IUT -- SFR#934 --Paranthaman --Start
	//after query  Subsytem buttons should be enabled to view the  details
	//No other details should enabled.

// FCUBS12.1~Bug~21316998 Starts
//	fnPostExecuteQuery_KERNEL();
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_CREDIT_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_REVN"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_DSBR"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_SCHDTLS"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_GUADTL")); 
	fnDisableElement(document.getElementById("BLK_COMPONENTS__COMPNAME"));//FCUBS->12.4->SAIGON COMMERCIAL BANK->SFR#27422093 
	
// FCUBS12.1~Bug~21316998 Ends	
	
	if(gAction ===  'EXECUTEQUERY' || gAction ===  '' )
	{
	    fnDisableMultipleEntry("DAYSYEAR");
	    fnDisableMultipleEntry("DAYSMTH");
	    fnDisableMultipleEntry("UNIT");
	    fnDisableMultipleEntry("SCHFLG");
	    fnDisableMultipleEntry("SCHTYP");
	}
	//9NT1462-- IUT -- SFR#934 --Paranthaman --Ends
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_SCHDTLS")); //Fcubs 11.4.0 kernel ITR # 13101009	
	document.getElementsByName("BTN_ADD_BLK_COMPONENTS")[0].className="BTNhide";
	document.getElementsByName("BTN_REMOVE_BLK_COMPONENTS")[0].className="BTNhide";
	//[FCUBS12.4->RETRO->26232985;Base#22919006] starts
	//document.getElementsByName("BTN_ADD_BLK_CHG_COMP")[0].className="BTNhide";
	//document.getElementsByName("BTN_REMOVE_BLK_CHG_COMP")[0].className="BTNhide";
	//[FCUBS12.4->RETRO->26232985;Base#22919006] ends
	fnchkLiqnmode(); //log#1
	return true;
}

function fnPostAddNewRow_BLK_COMP_SCH_KERNEL(arg){
	var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
//BUG#27976303 commented start
	//[FCUBS12.4->RETRO->26384638; Base#26328954] starts
/*	 var l_disable = true;
	 try
	 {
		l_disable = fncheckinterestAmount();
	 }
	 catch(e){
		 
	 };
	 
	 if (l_disable)
	 {
	////[FCUBS12.4->RETRO->26384638; Base#26328954] ends
	//BUG#25589169_1 STARTS 
	var l = document.getElementById("BLK_COMP_SCH").tBodies[0].rows.length;
	if(document.getElementById("BLK_COMPONENTS__COMPTYP").value=='I') 
		
	for (var i=1;i<=l;i++)	{
	
	
	fnDisableElement(document.getElementById("BLK_COMP_SCH").tBodies[0].rows[i-1].cells[10].getElementsByTagName("INPUT")[0]);
	}
	//BUG#25589169_1 ENDS
	} ////[FCUBS12.4->RETRO->26384638; Base#26328954] included
*/
   var l = document.getElementById("BLK_COMP_SCH").tBodies[0].rows.length;
		for (var i=1;i<=l;i++)	{
			if (document.getElementsByName("SPLINT")[0].checked == false &&
			document.getElementsByName("COMPTYP")[0].value !='L')
		  {
            fnDisableElement(document.getElementById("BLK_COMP_SCH").tBodies[0].rows[i-1].cells[10].getElementsByTagName("INPUT")[0]);			  
		  }
	}
//BUG#27976303 end	
	var stat = extractSubSysStat(statusStr, "COMPSCH");
	if (stat == 'S'){
		fnEnableMEBlock("BLK_COMP_SCH",false);
	}
	return true;
}
function fnInTab_TAB_DEFAULT_KERNEL(){
	var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
	var stat = extractSubSysStat(statusStr, "HOLPERIODS");
	if (stat == 'S'){
		fnEnableMEBlock("BLK_HOL_PERIODS",false);
	}
	return true;
}
function fnInTab_TAB_UDF_KERNEL(){
//14517741:Fix Propagation to 12.0~Retro from 13918923 starts

	/*
	for (var i=1;i<=40;i++)	{
		if (document.getElementById("BLK_UDF_OTHERS__VALFIELD"+i).value!='V'){
			if (i<=20)
				document.getElementById("BLK_UDF__FLDCHAR"+i).nextSibling.className	="hidden";
			else if (i>20 && i<=40)
				document.getElementById("BLK_UDF__FLDNUM"+(i-20)).nextSibling.nextSibling.className="hidden";
			}
		else if (document.getElementById("BLK_UDF_OTHERS__VALFIELD"+i).value =='V'){
		if (i<=20)
				document.getElementById("BLK_UDF__FLDCHAR"+i).nextSibling.className	="BTNimg";
			else if (i>20 && i<=40)
				document.getElementById("BLK_UDF__FLDNUM"+(i-20)).nextSibling.nextSibling.className="BTNimg";
					}
	}
*/
	
	document.getElementById("cmdAddRow_BLK_CLVWS_ACCOUNT_UDF_CHAR").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CLVWS_ACCOUNT_UDF_CHAR").style.visibility="HIDDEN";			
	document.getElementById("cmdAddRow_BLK_CLVWS_ACCOUNT_UDF_NUM").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CLVWS_ACCOUNT_UDF_NUM").style.visibility="HIDDEN";			
	document.getElementById("cmdAddRow_BLK_CLVWS_ACCOUNT_UDF_DATE").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CLVWS_ACCOUNT_UDF_DATE").style.visibility="HIDDEN";
	
	var l = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows.length;
        	
		for (var i=1;i<=l;i++)	{
		
	      if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')
	        if (i<=l)
	           if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='C')
		  {//12.0->USDIFAD->15889589 change
		  document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[2].getElementsByTagName("INPUT")[0].nextSibling.className="hidden";
		  //12.0->USDIFAD->15889589 change starts
		    document.getElementsByName('FIELD_CHAR_1')[i-1].setAttribute('onblur',"fnudfval()");
			  }
		  //12.0->USDIFAD->15889589 change ends
		  
					  //[FCUBS12.4->RETRO->26231817;Base#24801088] Starts
					          try{//FCUBS12.4->UNICREDIT BULBANK AD->29208854 added
							   var val =  document.getElementsByName('FIELD_CHAR_1')[i-1].getAttribute('onchange');
									var val1 ="fnchar(event);";
									if(val!='undefined'){
										val1 = val1+val;
										
									}
									document.getElementsByName('FIELD_CHAR_1')[i-1].removeAttribute('onchange');
									document.getElementsByName('FIELD_CHAR_1')[i-1].setAttribute('onchange',val1);
								}catch(e) {}; //FCUBS12.4->UNICREDIT BULBANK AD->29208854 end
									
					  //[FCUBS12.4->RETRO->26231817;Base#24801088] Ends
		  
		}
		
	  var m = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows.length;
         for (var i=1;i<=m;i++)	{
	
		if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')
	      if (i<=m)
	        if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='C')
		
                     document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[2].getElementsByTagName("INPUT")[1].nextSibling.className="hidden";//FBNLGBP_11.3_14134251

		        //[FCUBS12.4->RETRO->26231817;Base#24801088] Starts
					  var num = i-1;
					  var id;
					  if(num != 0)
					     id = "BLK_CLVWS_ACCOUNT_UDF_NUM__FIELD_NUMBER_1I"+ num;
				       else
					       id = "BLK_CLVWS_ACCOUNT_UDF_NUM__FIELD_NUMBER_1I";
					         try{//FCUBS12.4->UNICREDIT BULBANK AD->29208854 added
		                        var val =  document.getElementById(id).getAttribute('onchange');
								var val1 ="fnnum(event);";
								if(val!='undefined'&&val!=null){
									val1 = val1+val;
									
								}
								document.getElementById(id).removeAttribute('onchange');
								document.getElementById(id).setAttribute('onchange',val1);
							}catch(e) {}; //FCUBS12.4->UNICREDIT BULBANK AD->29208854 end
			     //[FCUBS12.4->RETRO->26231817;Base#24801088]  Ends			 
					 
		}
	
	//14517741:Fix Propagation to 12.0~Retro from 13918923 ENDS
	return true;
}
//FCUBS12.0.3->IRONVBR->19226624 start
function  fnPreDispLov_LOV_CHAR_FLD_KERNEL(lovSrcElem)
{
 var l = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows.length;
	for (var i=1;i<=l;i++)	{
    if (i<=l)
        if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value == 'C') //FCUBS_12.3_RETRO_BUG#25056260  Changed = to ==
		{
		if (document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[i-1].cells[0].getElementsByTagName('INPUT')[0].checked == true) //[FCUBS12.4->RETRO->26233265;Base#22646735] Changed rows[i]to rows[i-1]
			{
			var lovrequired = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value;
					if (lovrequired =='C')
					  {
					  lovScreenArgs["CUBE_ENTITY"] = true;
					  }
			}
		}
		}
  return true;
}
//[FCUBS12.4->RETRO->26233371; Base#23666414] begin
function fnPreExit_CVS_REVERSE_KERNEL()
{
	parent.gAction = "";
	return true;
}
//[FCUBS12.4->RETRO->26233371; Base#23666414] end
//FCUBS12.0.3->IRONVBR->19226624 End
//[FCUBS12.4->RETRO->26231817;Base#24801088] Starts
function fnchar(event){
	
	var event = window.event || event;
    var elem = getEventSourceElement(event);
	var currRow = getRowIndex(event);
	if((document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[currRow-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')&&(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[currRow-1].cells[6].getElementsByTagName("INPUT")[0].value !='C') ) 
	lovInfoFlds['BLK_CLVWS_ACCOUNT_UDF_CHAR__FIELD_CHAR_1__LOV_CHAR_FLD'][3]='N'; //[FCUBS12.4->INTERNAL->26648895]
				else 
			lovInfoFlds['BLK_CLVWS_ACCOUNT_UDF_CHAR__FIELD_CHAR_1__LOV_CHAR_FLD'][3]='Y'; //[FCUBS12.4->INTERNAL->26648895]
}
 function fnnum(event){
	
	   var event = window.event || event;
       var elem = getEventSourceElement(event);
	   var currRow = getRowIndex(event);
	  	 if((document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[currRow-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')&&(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[currRow-1].cells[6].getElementsByTagName("INPUT")[0].value !='C'))
						lovInfoFlds['BLK_CLVWS_ACCOUNT_UDF_NUM__FIELD_NUMBER_1__LOV_NUM_FLD'][3]='N';	//[FCUBS12.4->INTERNAL->26648895]		
		 else 			
			lovInfoFlds['BLK_CLVWS_ACCOUNT_UDF_NUM__FIELD_NUMBER_1__LOV_NUM_FLD'][3]='Y'; //[FCUBS12.4->INTERNAL->26648895]
}
//[FCUBS12.4->RETRO->26231817;Base#24801088] Ends
function fnPostAddNewRow_BLK_UDE_VALS_KERNEL(arg){
	var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
	var stat = extractSubSysStat(statusStr, "UDEVALS");
	if (stat == 'S' || g_enrich=='Y')       //Fcubs_12.4_KYRGYZ INVESTMENT AND CREDIT BANK_BUG#27983724 added g_enrich='Y'

	{
	fnEnableMEBlock("BLK_EFFEC_DATE",false);
	fnEnableMEBlock("BLK_UDE_VALS",false);
	}
	return true;
}

//OFAC Black List Check FC 11.1 Starts
function fnPreLoad_CVS_OFACT_KERNEL(screenArgs){
	screenArgs['REQXML']='';//Prepare the request xml in the format of OFAC accepeted Requested xml and pass as
	// screen argument to CSCOFACT
	return true;
}
//OFAC Black List Check FC 11.1 Ends

//centralisation in 9NT1368  Cluster starts
function fnPostLoad_Sum_KERNEL(){

	//RETRO FIX 11-Feb-2011 Aslam Startz

	//document.getElementById("BLK_ACCOUNT_SUMMARY__BRN").value = mainWin.CurrentBranch;

	var parentWin = fnGetParentWin();
	
	 if (parentWin.parentWinParams.CALLFORM='LUNCH1' ) { 
	 if (parentWin != "") 
	  {	
     // 14783195 Fix Propogation to 12.0 Retro from 13803501 COMMENT STARTS
	/* document.getElementById('BLK_ACCOUNT_SUMMARY__PRD').value= parentWin.parentWinParams.product_code;
	 document.getElementById('BLK_ACCOUNT_SUMMARY__CUSTID').value= parentWin.parentWinParams.counterparty;
	 document.getElementById('BLK_ACCOUNT_SUMMARY__CCY').value= parentWin.parentWinParams.CURRENCY;
	 document.getElementById('BLK_ACCOUNT_SUMMARY__BRN').value= parentWin.parentWinParams.BRANCH;
	 }
	  else
	{
	document.getElementsByName('CUSTID')[0].value = "";
	document.getElementsByName('PRD')[0].value = "";
	document.getElementsByName('CCY')[0].value = "";
	document.getElementsByName('BRN')[0].value = "";*/
	// 14783195 Fix Propogation to 12.0 Retro from 13803501 COMMENT ENDS
	// 14783195 Fix Propogation to 12.0 Retro from 13803501 STARTS
	
	// [FCUBS12.4->RETRO->26233783;Base#25488207] STARTS
	
	//document.getElementById('BLK_SMRY__PRODUCT_CODE').value= parentWin.parentWinParams.product_code;
	//document.getElementById('BLK_SMRY__CUSTOMER_ID').value= parentWin.parentWinParams.counterparty;
	//document.getElementById('BLK_SMRY__CURRENCY').value= parentWin.parentWinParams.CURRENCY;
	 document.getElementById('BLK_SMRY__PRD').value= parentWin.parentWinParams.product_code;
	 document.getElementById('BLK_SMRY__CUSTID').value= parentWin.parentWinParams.counterparty;
	 document.getElementById('BLK_SMRY__CCY').value= parentWin.parentWinParams.CURRENCY;
	 
	 // [FCUBS12.4->RETRO->26233783;Base#25488207]ENDS
	 document.getElementById('BLK_SMRY__BRN').value= parentWin.parentWinParams.BRANCH;
	 }
	  else
	{
	document.getElementsByName('CUSTOMER_ID')[0].value = "";
	document.getElementsByName('PRODUCT_CODE')[0].value = "";
	document.getElementsByName('CURRENCY')[0].value = "";
	document.getElementsByName('BRN')[0].value = "";
	// 14783195 Fix Propogation to 12.0 Retro from 13803501 ENDS
	}
	fnExecuteQuery_sum('Y');
    showTabData();
	enableForm();
	}
	//RETRO FIX 11-Feb-2011 Aslam Endz
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}

function fnPreShowDetail_Sum_KERNEL() {
	//var iRowIndex=getRowIndex(evnt); --FCUBS11.1 CB changes
	//var brnindex = document.getElementById("BLK_ACCOUNT_SUMMARY__BRN").item(1).cellIndex; 14783195 Fix Propogation to 12.0 Retro from 13803501 COMMENTED  
	var brnindex = document.getElementById("BLK_SMRY__BRN").item(1).cellIndex; // 14783195 Fix Propogation to 12.0 Retro from 13803501 ADDED
	var txnBranch=getInnerText(document.getElementById("TBL_QryRslts").tBodies[0].rows[0].cells[brnindex]);
	//var branchcode=document.getElementById("TBL_QryRslts").tBodies[0].rows[iRowIndex-1].cells[18].innerText;
	sumTxnBranch=txnBranch;
	return true;
}
//centralisation in 9NT1368 Cluster  ends

//15-Mar-10 FCUBS11.1 MB0403 start
function fnpopguadtls(){
	//SFR#1473 Changes Start
	//fnLaunchSubSreens('CVS_GUA_DTLS','CLDACCNT','CLDACCNT');
	var e = mainWin.event || e;
	currRow = getRowIndex(e);
	fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_GUA_DTLS',false);
	//SFR#1473 Changes End
}
function fnPostAddRow_BLK_COMP_GUA_CUST_KERNEL(arg){
//Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203 Starts
	/*var iRowIndex=dbIndexArray['BLK_COMP_GUA_CUST'];
	document.getElementById('BLK_COMP_GUA_CUST').rows[iRowIndex].cells[1].getElementsByTagName('INPUT')[0].value = iRowIndex;*/
	  var length=document.getElementById('BLK_COMP_GUA_CUST').tBodies[0].rows.length;
	  for(var j=0;j<=length;j++){
	  document.getElementById('BLK_COMP_GUA_CUST').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value = j+1;
	}
//Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203 Ends
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}
function fnPostAddRow_BLK_COMP_GUA_CUSTACC_KERNEL(arg){
	//Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203 Starts
	/*var iRowIndex=dbIndexArray['BLK_COMP_GUA_CUSTACC'];
	document.getElementById('BLK_COMP_GUA_CUSTACC').rows[iRowIndex].cells[1].getElementsByTagName('INPUT')[0].value = iRowIndex;*/
 var length=document.getElementById('BLK_COMP_GUA_CUSTACC').tBodies[0].rows.length;
	for(var j=0;j<=length;j++){
		document.getElementById('BLK_COMP_GUA_CUSTACC').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value = j+1;
	}
//Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203 Ends
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}
function fnPostDeleteRow_BLK_COMP_GUA_CUST_KERNEL(arg){
//Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203 Starts
	/*var length=dbIndexArray['BLK_COMP_GUA_CUST'];
	for(var j=0;j<=length;j++){
		document.getElementById('BLK_COMP_GUA_CUST').rows[j].cells[1].getElementsByTagName('INPUT')[0].value = j;
	}*/
	var length=document.getElementById('BLK_COMP_GUA_CUST').tBodies[0].rows.length;
	for(var j=0;j<=length;j++){
		document.getElementById('BLK_COMP_GUA_CUST').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value = j+1;
	}
//Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203 Ends
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}
function fnPostDeleteRow_BLK_COMP_GUA_CUSTACC_KERNEL(arg){
	//Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203 Starts
	/*var length=dbIndexArray['BLK_COMP_GUA_CUSTACC'];
	for(var j=0;j<=length;j++){
		document.getElementById('BLK_COMP_GUA_CUSTACC').rows[j].cells[1].getElementsByTagName('INPUT')[0].value = j;
	}*/
	var length=document.getElementById('BLK_COMP_GUA_CUSTACC').tBodies[0].rows.length;
	for(var j=0;j<=length;j++){
		document.getElementById('BLK_COMP_GUA_CUSTACC').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value = j+1;
	}
//Bug 17259716: Propagated to 12.0.2 from 12.0.1 :Bug~16562203 Ends
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}
//15-Mar-10 FCUBS11.1 MB0403 end
// 22-mar-10 9nt1369 Gokul
function fnPreLoad_CVS_SECHIS_KERNEL(screenArgs){
	screenArgs['ACCOUNT_NUMBER'] = document.getElementById('BLK_ACCOUNT_MASTER__ACCNO').value;
	return true;
}
// gokul end

function fn_get_automated_score(){
	var prevAction = gAction;
	appendData();//Fcubs 11.4.0 kernel ITR # 13348297
	fnCallBackEnd('GETSCORE');
	if (!fnProcessResponse()) {}
	gAction=prevAction;
}

//SFR#1473 Changes Start
function fnBuildScrArgs(screenArgs, scrName, funcId){

    var screenArgName = "";
    var screenArgSource = "";
    var screenArgVals = "";
    if (typeof(scrArgName) != "undefined") {
// FCUBS12.4->SAIGON COMMERCIAL BANK->27907516 starts 
     /*   if(scrArgName[scrName]) {
            screenArgName = scrArgName[scrName].split("~");
            screenArgSource = scrArgSource[scrName].split("~");
            if(scrArgVals[scrName])
                screenArgVals = scrArgVals[scrName].split("~");
        } else if (scrArgName[funcId]) {
            screenArgName = scrArgName[funcId].split("~");
            screenArgSource = scrArgSource[funcId].split("~");
            if(scrArgVals[funcId])
                screenArgVals = scrArgVals[funcId].split("~");
        }*/
//FCUBS12.4->SAIGON COMMERCIAL BANK->27907516   starts moved the funcId condition above
		 if (scrArgName[funcId]) {
            screenArgName = scrArgName[funcId].split("~");
            screenArgSource = scrArgSource[funcId].split("~");
            if(scrArgVals[funcId])
                screenArgVals = scrArgVals[funcId].split("~");
        }	
        else if(scrArgName[scrName]) {
            screenArgName = scrArgName[scrName].split("~");
            screenArgSource = scrArgSource[scrName].split("~");
            if(scrArgVals[scrName])
                screenArgVals = scrArgVals[scrName].split("~");
        } 
	//FCUBS12.4->SAIGON COMMERCIAL BANK->27907516   ends

        for(var i=0; i<screenArgName.length; i++){
            if(screenArgSource[i] == "")
                screenArgs[screenArgName[i]] = screenArgVals[i];
            else
            {
                var block = screenArgSource[i].split("__")[0];
                screenArgs[screenArgName[i]] = document.getElementById(screenArgSource[i]).value;

            }
        }
    }
}
//SFR#1473 Changes End

//SFR#2790 Changes Start
function fnPostCopy_KERNEL(){
	fnToggleSubsystemButton('MSDMSPRV', false); //FCUBS12.4->SAIGON COMMERCIAL BANK->27907516 
	fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__PROD"));
	fnDisableElement(document.getElementById("BLK_ACCOUNT_MASTER__USERDEFSTAT"));
	fnSetSubsysBlocks(false) ;	//[FCUBS12.4->RETRO->26232379;Base#22848623]
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
}
//SFR#2790 Changes End


//SFR#1959<Start>
function fnPreLoad_CVS_CMP_SETT_MODE_KERNEL(){
	gCompPayModeIndex = dbIndexArray['BLK_COMPONENTS'];
	return true;
}
function fnPostClose_CVS_CMP_SETT_MODE_KERNEL(){
	//showTabData(strCurrentTabId);
	dbIndexArray['BLK_COMPONENTS'] = gCompPayModeIndex;
	//gCompPayModeIndex=0;
	return true;
}
function fnPreLoad_CVS_CHG_SETT_MODE_KERNEL(){
	gChgPayModeIndex = dbIndexArray['BLK_CHG_COMP'];
	return true;
}
//[FCUBS->12.1_Multi_Settlement_Instruction_UT2_Case#43]
function fnPostLoad_CVS_CHG_SETT_MODE_KERNEL(){
	fnBuildTabHTML();
        return true;
}

//[FCUBS12.1-INTERNAL-IQA-21237653] start		 
function fnPostLoad_CVS_CMP_SETT_MODE_KERNEL(){
	fnBuildTabHTML();
        return true;
}

function fnPostReturnValToParent_LOV_SETTLEMENT_SEQ_NUM_KERNEL(){
    appendTabData(document.getElementById("TBLPageTAB_CREDIT"));
    appendTabData(document.getElementById("TBLPageTAB_DEBIT"));    
    return true;
}
//[FCUBS12.1-INTERNAL-IQA-21237653] ends

//[FCUBS->12.1_Multi_Settlement_Instruction_UT2_Case#43]
function fnPostClose_CVS_CHG_SETT_MODE_KERNEL(){
	dbIndexArray['BLK_CHG_COMP'] = gChgPayModeIndex;
	//gChgPayModeIndex=0;
	return true;
}
function fnPostResetIndex_KERNEL(){
	dbIndexArray['BLK_COMPONENTS'] = parent.gCompPayModeIndex;
	dbIndexArray['BLK_CHG_COMP'] = parent.gChgPayModeIndex;
	parent.gCompPayModeIndex=1;
	parent.gChgPayModeIndex=1;
	return true;
}
//SFR#1959<Ends>
//FC11.1_IMPSUPP_497
function fnInTab_TAB_LINKAGES_KERNEL(){
//9NT1462 ITR2 SFR 13469863 Starts
fn_ccy();//FCUBS12.4->BANK OF SOUTH PACIFIC LTD->BUG#29445013
if ( gAction == "" || gAction == null )
	   return true;
//9NT1462 ITR2 SFR 13469863 Ends 
	//FCUBSVER: 12.0.3, KERNEL, Item: Interest rate pickup UT2 starts
	//fn_ccy(); //FCUBS12.4->EPROCESS INTERNATIONAL SA->28661359 //FCUBS12.4->BANK OF SOUTH PACIFIC LTD->BUG#29445013 function call moved above 
	var linkagecount = document.getElementById("BLK_LINKAGES").tBodies[0].rows.length;
	var rowRef      = document.getElementById("BLK_LINKAGES").tBodies[0].rows;
	for (var i =0 ; i < linkagecount ; i++) {
	 var l_lntyp = rowRef[i].cells[2].getElementsByTagName("SELECT")[0].value;
	 if(l_lntyp=="D"){
		rowRef[i].cells[0].getElementsByTagName("INPUT")[0].disabled = true; 
		getNextSibling(getNextSibling(rowRef[i].cells[1].getElementsByTagName("INPUT")[0])).disabled = true;
	    getNextSibling(getNextSibling(rowRef[i].cells[1].getElementsByTagName("INPUT")[0])).className = "TextNormal numeric";
		rowRef[i].cells[2].getElementsByTagName("SELECT")[0].disabled = true; 
		rowRef[i].cells[3].getElementsByTagName("INPUT")[0].disabled = true;
		rowRef[i].cells[3].getElementsByTagName("INPUT")[0].nextSibling.disabled = true;
		rowRef[i].cells[4].getElementsByTagName("INPUT")[0].disabled = true;
		rowRef[i].cells[4].getElementsByTagName("INPUT")[0].nextSibling.disabled = true;
		rowRef[i].cells[5].getElementsByTagName("INPUT")[0].disabled = true;
		rowRef[i].cells[5].getElementsByTagName("INPUT")[0].nextSibling.disabled = true;
		rowRef[i].cells[6].getElementsByTagName("INPUT")[0].disabled = true;
		//rowRef[i].cells[7].getElementsByTagName("INPUT")[0].disabled = true;
		//rowRef[i].cells[11].getElementsByTagName("INPUT")[0].nextSibling.disabled = true;
		getNextSibling(getNextSibling(rowRef[i].cells[7].getElementsByTagName("INPUT")[0])).disabled = true;
	    getNextSibling(getNextSibling(rowRef[i].cells[7].getElementsByTagName("INPUT")[0])).className = "TextNormal numeric";	
		getNextSibling(getNextSibling(rowRef[i].cells[8].getElementsByTagName("INPUT")[0])).disabled = true;
	    getNextSibling(getNextSibling(rowRef[i].cells[8].getElementsByTagName("INPUT")[0])).className = "TextNormal numeric";	
		rowRef[i].cells[9].getElementsByTagName("INPUT")[0].disabled = true;
		}
	}
//FCUBSVER: 12.0.3, KERNEL, Item: Interest rate pickup UT2 ends

g_prev_gAction=gAction;
gAction='POPUP';

       fcjRequestDOM = buildUBSXml();
       fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
       

gAction = g_prev_gAction;
/*[FCUBS12.3->RETRO->24613348; Base#21442514] starts */
//return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES
 var rowcount = document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows.length; 
for (var i=0;i<rowcount;i++)
{
fn_linkage_1(i); 
}
  /*[FCUBS12.3->RETRO->24613348; Base#21442514] ends */
}

//FC11.1_IMPSUPP_497 ends 

//FCUBS 11.2 change starts
function fn_ChangeTenor()
{
if ((document.getElementsByName("VALDT")[0].value != '') && (document.getElementsByName("MATDT")[0].value != ''))
{
var myBasedate =document.getElementsByName("VALDT")[0].value;
var myBaseDateArray = new Array();
myBaseDateArray = myBasedate.split("-");
var basDate = getDateObject();
basDate.setYear(myBaseDateArray[0]);
// basDate.setMonth(myBaseDateArray[1] - 1); //12.0.2~USDIFAD~16778704 comments
basDate.setMonth(Number(myBaseDateArray[1]) - 1, myBaseDateArray[2]);	// 12.0.2~USDIFAD~16778704 adds
basDate.setDate(myBaseDateArray[2]) ;
var myMatdate =document.getElementsByName("MATDT")[0].value;
var myMatDateArray = new Array();
myMatDateArray = myMatdate.split("-");
var matDate = getDateObject();
matDate.setYear(myMatDateArray[0]);
// 12.0.2~USDIFAD~16778704 starts
// matDate.setMonth(myMatDateArray[1] - 1);
// matDate.setDate(myMatDateArray[2]) ;
matDate.setMonth(Number(myMatDateArray[1]) - 1, myMatDateArray[2]);
// document.getElementsByName("TENOR")[0].value = Math.round((matDate.valueOf() - basDate.valueOf())/(60 * 60 * 24 * 1000));
document.getElementsByName("TENORI")[0].value = Math.round((matDate.valueOf() - basDate.valueOf())/(60 * 60 * 24 * 1000));
// 12.0.2~USDIFAD~16778704 ends
}
}
// Fcubs 11.4.0 kernel ITR # 13391630 starts 
function fnpopguadtls(){
	var e = mainWin.event || e;
	currRow = getRowIndex(e);
	fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_GUA_DTLS',false);
}
//Fcubs 11.4.0 kernel ITR # 13391630 ends
function fn_ChangeMatDate()
{
    //FCUBS12.0.2>IEGPCAE>17879918 starts, TENOR replaced by TENORI
	//if((document.getElementsByName("TENOR")[0].value != '') && (document.getElementsByName("VALDT")[0].value != ''))
	if((document.getElementsByName("TENORI")[0].value != '') && (document.getElementsByName("VALDT")[0].value != ''))
	//FCUBS12.0.2>IEGPCAE>17879918 ends
{
var Monthly = /M/;
var HalfYearly = /H/;
var Quarterly = /Q/;
var Yearly = /Y/;
var Days = /D/;
var Weeks = /W/;
var TENOR = document.getElementsByName("TENORI")[0].value;
var TENOR = TENOR.toUpperCase();
var Month = TENOR.search(Monthly);
var Half = TENOR.search(HalfYearly);
var Quarter = TENOR.search(Quarterly);
var Year = TENOR.search(Yearly);
var Day = TENOR.search(Days);
var Week = TENOR.search(Weeks);

var tenorMon = 0;
if (Month != -1)
	{
var strLen = TENOR.length;
tenorMon = TENOR.slice(0,strLen-1);
var tenorMon = tenorMon*1;
var tenornum = 0;
}
else if (Half != -1)
	{
var strLen = TENOR.length;
tenorMon = TENOR.slice(0,strLen-1);
var tenorMon = tenorMon*6;
tenorMon = tenorMon*1;
var tenornum = 0;
}
else if (Quarter != -1)
	{
var strLen = TENOR.length;
tenorMon = TENOR.slice(0,strLen-1);
var tenorMon = tenorMon*3;
tenorMon = tenorMon*1;
var tenornum = 0;
}
else if (Year != -1)
	{
	var strLen = TENOR.length;
tenorMon = TENOR.slice(0,strLen-1);
var tenorMon = tenorMon*12;
tenorMon = tenorMon*1;
var tenornum = 0;
}
else if (Day != -1)
	{
var strLen = TENOR.length;
tenornum = TENOR.slice(0,strLen-1);
var tenornum = tenornum*1;
var tenorMon = 0;
}
else if (Week != -1)
	{
var strLen = TENOR.length;
tenornum = TENOR.slice(0,strLen-1);
var tenornum = tenornum*7;
var tenornum = tenornum*1;
var tenorMon = 0;

}
else
	{
	var strLen = TENOR.length;
tenornum = document.getElementsByName("TENORI")[0].value;
var tenornum = tenornum*1;
//FCUBS12.0-->APACK-->14610806 changes starts
if(isNaN(tenornum)){
	
	showErrorAlerts('CL-COM056'); //16040116: propagated from 14825982 (Changed error code from 'COM055' to 'COM056')
	return false;

}
//FCUBS12.0-->APACK-->14610806 changes ends
var tenorMon = 0;
	}

var myBasedate =document.getElementsByName("VALDT")[0].value;
var myBaseDateArray = new Array();
myBaseDateArray = myBasedate.split("-");
var matDate = getDateObject();
matDate.setYear(myBaseDateArray[0]);
// 12.0.2~USDIFAD~16778704 starts
matDate.setMonth( (Number(myBaseDateArray[1]) - 1)  + tenorMon, Number(myBaseDateArray[2])  + tenornum);
// 12.0.2~USDIFAD~16778704 ends

var matmonth = matDate.getMonth() + 1;

document.getElementsByName("MATDT")[0].value = matDate.getFullYear() + '-' + matmonth + '-' + matDate.getDate();
}
}

//FCUBS 11.2 change Ends


// log#1 anoop starts
//  starts
function fnPostMovePrev_BLK_COMPONENTS_KERNEL(arg){
	 fnSetSubsysBlocks(false) ; //18955556:Fix Propagation to 12.0.3 ~ Retro from 15844446 added
	fnchkLiqnmode();
	fn_ccy(); //12.0.2 Amount CCY Changes.
	return true;
}

function fnPostMoveNext_BLK_COMPONENTS_KERNEL(arg){
	 fnSetSubsysBlocks(false) ; //18955556:Fix Propagation to 12.0.3 ~ Retro from 15844446 added
	fnchkLiqnmode();
	fn_ccy(); //12.0.2 Amount CCY Changes.
	return true;
}	
// ends
function fnchkLiqnmode()
{
	//var blk_name = dbDataDOM.getElementsByTagName("BLK_ACCOUNT_MASTER")[0];
	//var y = blk_name.getElementsByTagName("LIQDMODE")[0].text;
	//var y = document.getElementById("BLK_ACCOUNT_MASTER__LIQDMODE").value //9NT1525-12.0-INTERNAL-15911921 commented
	var tempNode=selectNodes(dbDataDOM,"//BLK_ACCOUNT_MASTER")[0]; //9NT1525-12.0-INTERNAL-15911921 added
    var y=getNodeText(selectSingleNode(tempNode,"//LIQDMODE")); //9NT1525-12.0-INTERNAL-15911921 added
	var x=document.getElementById("BLK_COMPONENTS__COMPTYP").value;
	var z=document.getElementById("BLK_COMPONENTS__LIQUIDATION_MODE").value; 
	//9NT1525-12.0-INTERNAL-15911921 starts
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_CREDIT_MODE"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_REVN"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_DSBR"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_SCHDTLS"));
	fnEnableElement(document.getElementById("BLK_COMPONENTS__BTN_GUADTL"));
//9NT1525-12.0-INTERNAL-15911921 ends
	if (functionId == 'CLDACCNT' || functionId == 'CIDACCNT' || functionId == 'MODACCNT')
	{
		if (gAction == "NEW" || gAction == "COPY" || gAction == "MODIFY")
		{
			if ((y=="C") && (x=="I"|| x=="P" || x=="L"))	
			{
				if (z=="")
				{
					//alert('inside z is null ');
					document.getElementById("BLK_COMPONENTS__LIQUIDATION_MODE").value = "A";
					fnEnableElement(document.getElementById('BLK_COMPONENTS__LIQUIDATION_MODE'));
				}
				else
				{
					//alert('in the else');
					fnEnableElement(document.getElementById("BLK_COMPONENTS__LIQUIDATION_MODE"));
				}
			}
			else
			{
				document.getElementById("BLK_COMPONENTS__LIQUIDATION_MODE").value = "";
				fnDisableElement(document.getElementById("BLK_COMPONENTS__LIQUIDATION_MODE"));

			}
		}
	}

	return true;
}

// log#1 anoopends
/*
//9NT1462 Takeover Asset changes Starts
function fnShowSubscreen_CVS_TKOVERDET()
{
var gPrevAction = gAction;
gAction ='NEW';
appendData();
gAction ='TAKOVRDET';
fcjRequestDOM =buildUBSXml(); 
fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
if(!fnProcessResponse()){
gAction=gPrevAction; 
return false; 
}
fnSubScreenMain('CLDACCNT', 'CLDACCNT', 'CVS_TKOVERDET','');
}
//9NT1462 Takeover Asset changes ends
*/
//Surekha for 9nt1462 ITR1 SFR 13358228 STARTS
function fnShowSubscreen_CVS_TKOVERDET()
{
       //20977811:Fix Propagation to 12.1.0 ~ Retro from 20921692 Start
	   var gPrevAction = gAction;
                    // gAction='NEW';
	   //20977811:Fix Propagation to 12.1.0 ~ Retro from 20921692 End
                     appendData();
     gAction='TAKOVRDET';
     fcjRequestDOM = buildUBSXml();
     servletURL = "FCClientHandler";
     fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
	if(fcjResponseDOM) 
	{
		var msgStatus   =getNodeText(selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
		 if (msgStatus == 'FAILURE') {
	             var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
			     var returnVal = displayResponse(messageNode,msgStatus,'E',"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
				 
				 }
	       var pureXMLDOM  = fnGetDataXMLFromFCJXML(fcjResponseDOM,1);
	          setDataXML(getXMLString(pureXMLDOM));
	          showData(dbStrRootTableName, 1);
               if (msgStatus=='SUCCESS')
                  {
                     screenArgs['SCREEN_NAME'] = 'CVS_TKOVERDET';
	 		screenArgs['FUNCTION_ID'] = 'CLDACCNT';
			screenArgs['DESCRIPTION'] = fnGetSubScreenTitle('UIXML/'+mainWin.LangCode+'/CLDACCNT.xml',screenArgs['SCREEN_NAME']);
	              fnShowSubScreen(screenArgs);
                   }
           }
//20977811:Fix Propagation to 12.1.0 ~ Retro from 20921692 Start
	fnEnableMEBlock("BLK_EFFEC_DATE",false);
	fnEnableMEBlock("BLK_UDE_VALS",false);
	gAction=gPrevAction;
	return true;
	//20977811:Fix Propagation to 12.1.0 ~ Retro from 20921692 End
}
//Surekha for 9nt1462 ITR1 SFR 13358228 ends
//FCUBS_12.0.3_COMMONWEALTH BANK OF AUSTRALIA_19143200 starts
function fnPostAddRow_BLK_ASSET_VALUATIONS_KERNEL(){
	var rowcount = document.getElementById("BLK_ASSET_VALUATIONS").tBodies[0].rows.length;
	document.getElementsByName("CCY")[rowcount-1].value = document.getElementById('BLK_CONTROL_1__CCYASSET').value; 
	 	return true;
}
//FCUBS_12.0.3_COMMONWEALTH BANK OF AUSTRALIA_19143200 ends

//9NT1501 - SFR 265 code changes Starts
function fnSetFocusOnMasterPKField() {
	try{
	if(gAction == "NEW" && (functionId == 'CLDACCNT' || functionId == 'CIDACCNT' || functionId == 'MODACCNT') ) //9NT1501 - ITR1 - SFR  :13891758  
		{
		document.getElementById("BLK_ACCOUNT_MASTER__PROD").focus();
		return;
		}
	}catch(e) {};
    if (pkFields && pkFields.length > 0) {
        var l_SortedPkFlds = fnGetPkFieldOrderby_TabIdx();
        for (var l_PkCount = 0; l_PkCount < l_SortedPkFlds.length; l_PkCount++) {
            var l_PkElement = document.getElementById(l_SortedPkFlds[l_PkCount]);
            var l_PkElement_Misc = document.getElementById(l_SortedPkFlds[l_PkCount] + "I");
            if (l_PkElement_Misc != null) 
                l_PkElement = l_PkElement_Misc;
            try {
                if (l_PkElement) {
                    if ((l_PkElement.className && l_PkElement.className.toUpperCase() == "HIDDEN") || l_PkElement.type.toUpperCase() == "HIDDEN" || getCurrentStyle(l_PkElement, "visibility").toUpperCase() == "HIDDEN" || l_PkElement.readOnly == true || l_PkElement.disabled == true) {
                        if ((l_PkCount == l_SortedPkFlds.length - 1) && (document.getElementById("BTN_EXIT"))) {
                            document.getElementById("BTN_EXIT_IMG").focus();
                        }
                        continue;
                    } else { if (l_PkElement.type.toUpperCase() != "RADIO") {
                            l_PkElement.focus();
                            return;
                        }
                        if (l_PkElement.type.toUpperCase() == "RADIO") {
                            fnEnableRadioField(l_PkElement);
                            return;
                        }
                    }
                }
            } catch(e) {}
        }
    }  
} 
//9NT1501 - SFR 265 code changes Ends
//
//14517741:Fix Propagation to 12.0~Retro from 13918923 STARTS
function fnPostNavigate_BLK_CLVWS_ACCOUNT_UDF_CHAR_KERNEL()
{
          var l = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows.length;
        	
		for (var i=1;i<=l;i++)	{
		
	      if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')
	        if (i<=l)
	           if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='C')
		          document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[2].getElementsByTagName("INPUT")[0].nextSibling.className="hidden";
				//[FCUBS12.4->RETRO->26231817;Base#24801088]Starts
				    var val =  document.getElementsByName('FIELD_CHAR_1')[i-1].getAttribute('onchange');
						var val1 ="fnchar(event);";
						if(val!='undefined'){
							val1 = val1+val;
							
						}
						document.getElementsByName('FIELD_CHAR_1')[i-1].removeAttribute('onchange');
						document.getElementsByName('FIELD_CHAR_1')[i-1].setAttribute('onchange',val1);
									
				//[FCUBS12.4->RETRO->26231817;Base#24801088] Ends
		  }
	  var m = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows.length;
         for (var i=1;i<=m;i++)	{
	
		if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')
	      if (i<=m)
	        if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='C')
                     document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[2].getElementsByTagName("INPUT")[1].nextSibling.className="hidden";
						//[FCUBS12.4->RETRO->26231817;Base#24801088] Starts
						  var num = i-1;
						  var id;
						  if(num != 0)
							 id = "BLK_CLVWS_ACCOUNT_UDF_NUM__FIELD_NUMBER_1I"+ num;
						   else
							   id = "BLK_CLVWS_ACCOUNT_UDF_NUM__FIELD_NUMBER_1I";
									var val =  document.getElementById(id).getAttribute('onchange');
									var val1 ="fnnum(event);";
									if(val!='undefined'&&val!=null){
										val1 = val1+val;
										
									}
									document.getElementById(id).removeAttribute('onchange');
									document.getElementById(id).setAttribute('onchange',val1);
						//[FCUBS12.4->RETRO->26231817;Base#24801088] Ends	
		
		}

	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES	
}

function fnPostNavigate_BLK_CLVWS_ACCOUNT_UDF_NUM_KERNEL()
{

  var l = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows.length;
        	
		for (var i=1;i<=l;i++)	{
		
	      if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')
	        if (i<=l)
	           if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='C')
		          document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows[i-1].cells[2].getElementsByTagName("INPUT")[0].nextSibling.className="hidden";
				//[FCUBS12.4->RETRO->26231817;Base#24801088]Starts
				    var val =  document.getElementsByName('FIELD_CHAR_1')[i-1].getAttribute('onchange');
						var val1 ="fnchar(event);";
						if(val!='undefined'){
							val1 = val1+val;
							
						}
						document.getElementsByName('FIELD_CHAR_1')[i-1].removeAttribute('onchange');
						document.getElementsByName('FIELD_CHAR_1')[i-1].setAttribute('onchange',val1);
									
				//[FCUBS12.4->RETRO->26231817;Base#24801088] Ends  
		  
		  }
	  var m = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows.length;
         for (var i=1;i<=m;i++)	{
	
		if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='Y')
	      if (i<=m)
	        if(document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[6].getElementsByTagName("INPUT")[0].value !='C')
                     document.getElementById("BLK_CLVWS_ACCOUNT_UDF_NUM").tBodies[0].rows[i-1].cells[2].getElementsByTagName("INPUT")[1].nextSibling.className="hidden";
					//[FCUBS12.4->RETRO->26231817;Base#24801088]Starts
						  var num = i-1;
						  var id;
						  if(num != 0)
							 id = "BLK_CLVWS_ACCOUNT_UDF_NUM__FIELD_NUMBER_1I"+ num;
						   else
							   id = "BLK_CLVWS_ACCOUNT_UDF_NUM__FIELD_NUMBER_1I";
									var val =  document.getElementById(id).getAttribute('onchange');
									var val1 ="fnnum(event);";
									if(val!='undefined'&&val!=null){
										val1 = val1+val;
										
									}
									document.getElementById(id).removeAttribute('onchange');
									document.getElementById(id).setAttribute('onchange',val1);
						//[FCUBS12.4->RETRO->26231817;Base#24801088] Ends
		}
	return true; //Bug 16730827: Propagated to 12.0.2 from 12.0.1 (Bug 16654758) CHANGES

}
// 14517741:Fix Propagation to 12.0~Retro from 13918923 ENDS
//12.0->USDIFAD->15889589 change starts
function fnudfval(){
return true;
}
//12.0->USDIFAD->15889589 change ends
//FCUBS_12.0.3_19558009 Start
/*function fnSetHotKeyBranch_KERNEL() {
	if(window.event.srcElement.name =="DRPRODAC"){
	hotKeyBrn = document.getElementsByName('DRACCBRN')[0].value;
	}
	if(window.event.srcElement.name =="CRPRODAC"){
	hotKeyBrn = document.getElementsByName('CRACCBRN')[0].value;
	}
    return true;
}*/
function fnSetHotKeyBranch_KERNEL(e) { 
var event = window.event || e; 
if(getEventSourceElement(event).name =="DRPRODAC"){ 
hotKeyBrn = document.getElementsByName('DRACCBRN')[0].value; 
} 
if(getEventSourceElement(event).name =="CRPRODAC"){ 
hotKeyBrn = document.getElementsByName('CRACCBRN')[0].value; 
} 
return true; 
} 

//FCUBS_12.0.3_19558009 End
//18955556:Fix Propagation to 12.0.3 ~ Retro from 15844446 starts
function fnInTab_TAB_MAIN_KERNEL(){
		var statusStr = document.getElementsByName('SUBSYSSTAT')[0].value;
		var udestat = extractSubSysStat(statusStr, "UDEVALS");
       if (gAction == 'EXECUTEQUERY' || gAction == "" || udestat == "U"){
			fnSetSubsysBlocks(false) ;
       }
    fn_ChangeTenor(); //[FCUBS12.4->RETRO->26231912;Base#21604942] Added
	return true;
}
//18955556:Fix Propagation to 12.0.3 ~ Retro from 15844446 ends
//FCUBS_12.0.3_IRONVBR_19235047 Start

function fnPostMovePrev_BLK_CHG_COMP_KERNEL(arg){

	fnchgLiqnmode();
	return true;
}
//[FCUBS->12.1_Multi_Settlement_Instruction] starts
function fnfetch_settlement()
 {
   var rowIndex =getRowIndex(event);
   set_SplitCheck_CellValue(document.getElementById('BLK_CLTBS_SPLIT_STTL_DETAIL').tBodies[0].rows[rowIndex-1]);
    appendData();     
    var prevAction = gAction;
    gAction ="FETCHACC";
    fcjRequestDOM = buildUBSXml();
    servletURL = "FCClientHandler";
    fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
    var msgStatus = fnProcessResponse();
    fnPostProcessResponse(msgStatus);   
    gAction=prevAction;
    return true;
}

function fnredef_settlement() {   
  
    var prevAction = gAction;
	appendData();  
    gAction ="FETCHACCCOMP";
    fcjRequestDOM = buildUBSXml();
    servletURL = "FCClientHandler";
    fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
    var msgStatus = fnProcessResponse();
    fnPostProcessResponse(msgStatus);   
    gAction=prevAction;
    return true;
}
function set_SplitCheck_CellValue(p_Value)
 {
	var l_Value = p_Value;
	var cellLength = p_Value.cells.length;
	for (var i=0;i<=cellLength;i++)	{

	if (p_Value.cells[i].getElementsByTagName("INPUT").length != '0') 
	{
		if (p_Value.cells[i].getElementsByTagName("INPUT")[0].name == 'SPLIT_CHECK') 
		{
			p_Value.cells[i].getElementsByTagName("INPUT")[0].value = 'Y';
			return true; 
		}
		}
	
	}
}
//[FCUBS->12.1_Multi_Settlement_Instruction] ends
function fnPostMoveNext_BLK_CHG_COMP_KERNEL(arg){

	fnchgLiqnmode();
	return true;
}	

function fnchgLiqnmode()
{
	var tempNode=selectNodes(dbDataDOM,"//BLK_ACCOUNT_MASTER")[0]; 
    var y=getNodeText(selectSingleNode(tempNode,"//LIQDMODE")); 
	var z=document.getElementById("BLK_CHG_COMP__LIQUIDATION_MODE").value; 

	if (functionId == 'CLDACCNT' || functionId == 'CIDACCNT' || functionId == 'MODACCNT')
	{
		if (gAction == "NEW" || gAction == "COPY" || gAction == "MODIFY")
		{
			//[FCUBS12.4->RETRO->26861741; Base#26802826] start
			if (document.getElementById("BLK_CHG_SCH__AMOUNTDUE").value > 0) {
			fnEnableElement(document.getElementById("BLK_CHG_SCH__AMTWAIVED"));
			 }
			else
			{
			fnDisableElement(document.getElementById("BLK_CHG_SCH__AMTWAIVED"));
			}	
		//[FCUBS12.4->RETRO->26861741; Base#26802826] end
			if (y=="C")
			{
				if (z=="")
				{
					//alert('inside z is null ');
					document.getElementById("BLK_CHG_COMP__LIQUIDATION_MODE").value = "A";
					fnEnableElement(document.getElementById('BLK_CHG_COMP__LIQUIDATION_MODE'));
				}
				else
				{
					//alert('in the else');
					fnEnableElement(document.getElementById("BLK_CHG_COMP__LIQUIDATION_MODE"));
				}
			}
			else
			{
				document.getElementById("BLK_CHG_COMP__LIQUIDATION_MODE").value = "";
				fnDisableElement(document.getElementById("BLK_CHG_COMP__LIQUIDATION_MODE"));

			}
		}
	}

	return true;
}

//FCUBS_12.0.3_IRONVBR_19235047 End
//[FCUBS12.4->RETRO->26230849;Base#25828592] starts
function roundToTwo(num) {
    return +(Math.round(num + "e+4")  + "e-4");
}
function fnPostAddNewRow_BLK_OTHR_APPLICANTS_KERNEL(arg){
    var event = window.event;
	var tblObj = document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0];
	var rowCnt = tblObj.rows.length;
	for(var i=0;i<rowCnt;i++){
document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[i].cells[5].getElementsByTagName("INPUT")[1].setAttribute("onblur","validateInputAmount('LIABILITYAMT', 'CCY2', event);fnValidateRange(this);fncalcliabpercentage(event)");
document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[i].cells[4].getElementsByTagName("INPUT")[1].setAttribute("onblur","validateInputNumber(this, event);fncalcliabamt(event)");
	}
return true;
}
function fncalcliabpercentage(event)
{
	var rowIndex = getRowIndex(event);
	var liabAmt = document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[5].getElementsByTagName("INPUT")[1].value.replace(gDigitGroupingSymbol,"").replace(gDecimalSymbol, decimalSymbol);
    var liabAmt_2 = document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[5].getElementsByTagName("INPUT")[0].value;
	var amt_fin = getNodeText(selectSingleNode(dbDataDOM, "//BLK_ACCOUNT_MASTER/AMTFINANCED"));
	if ((gAction != 'ENTERQUERY')&&(gAction!=""))
	    {
		  if(amt_fin!="")
			document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[4].getElementsByTagName("INPUT")[0].value = roundToTwo((replaceAll(liabAmt,",","")*100)/amt_fin);
            document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[5].getElementsByTagName("INPUT")[0].value = liabAmt_2;
		}

 	if (document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value == '')
		document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value =getNodeText(selectSingleNode(dbDataDOM, "//BLK_ACCOUNT_MASTER/VALDT"));
       appendData();
	   showTabData(strCurrentTabId);
}
function fncalcliabamt(event)
{
	var rowIndex = getRowIndex(event);
	var percent = document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[4].getElementsByTagName("INPUT")[1].value;
	var amt_fin = getNodeText(selectSingleNode(dbDataDOM, "//BLK_ACCOUNT_MASTER/AMTFINANCED"));
		if ((gAction != 'ENTERQUERY')&&(gAction!=""))
	    {	document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[5].getElementsByTagName("INPUT")[0].value = Math.round((document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[4].getElementsByTagName("INPUT")[1].value*amt_fin)/100);
			document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[4].getElementsByTagName("INPUT")[0].value = percent;
		}

	if (document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value == '')
		document.getElementById("BLK_OTHR_APPLICANTS").tBodies[0].rows[rowIndex-1].cells[6].getElementsByTagName("INPUT")[0].value =getNodeText(selectSingleNode(dbDataDOM, "//BLK_ACCOUNT_MASTER/VALDT"));
        appendData();
		showTabData(strCurrentTabId);
}
//[FCUBS12.4->RETRO->26230849;Base#25828592] END
//SITECODE: 12.1, KERNEL, Item:Revision Schedules_UT1_Case_20 starts
function fncurrency(){
	if (document.getElementsByName("HOLIDAY_CHK_REV")[0].value == 'C' || document.getElementsByName("HOLIDAY_CHK_REV")[0].value == 'B'){
	fnEnableElement(document.getElementsByName("HOLIDAY_CCY_REV")[0]);
	}
	else{
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_REV").disabled = true;
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_REV").nextSibling.disabled = true;
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_REV").value = "";
	}
	if (document.getElementsByName("HOLIDAY_CHECK")[0].value == 'C' || document.getElementsByName("HOLIDAY_CHECK")[0].value == 'B'){
	fnEnableElement(document.getElementsByName("HOLIDAY_CCY_SCH")[0]);
	}
	else{
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_SCH").disabled = true;
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_SCH").nextSibling.disabled = true;
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_SCH").value = "";
	}

	if (document.getElementsByName("HOLIDAY_CHECK_MAT")[0].value == 'C' || document.getElementsByName("HOLIDAY_CHECK_MAT")[0].value == 'B'){
	fnEnableElement(document.getElementsByName("HOLIDAY_CCY_MAT")[0]);
	}
	else{
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_MAT").disabled = true;
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_MAT").nextSibling.disabled = true;
	document.getElementById("BLK_HOL_PREF__HOLIDAY_CCY_MAT").value = "";
	}
	return true;
}
//SITECODE: 12.1, KERNEL, Item:Revision Schedules_UT1_Case_20 ends

//12.1_METRO_DEV_AR STARTS
function fncheckdc() {
if (document.getElementById("BLK_CHG_COMP__FUNDDURINGINIT").checked == true || document.getElementById("BLK_CHG_COMP__FUNDDURINGROLL").checked == true ){
document.getElementById("BLK_CHG_COMP__DEFERRED_CHARGE").checked=false ;
}
}

//12.1_METRO_DEV_AR ENDS
// 12.1 Development Joint Holder Hot Key Changes Starts
function fnSetHotKeyBranch_KERNEL (e)
{
 var event=window.event||e;
 var srcElement=getEventSourceElement(event);
 var srcID=srcElement.id;
 if (srcID =='BLK_ACCOUNT_MASTER__DRPRODAC')
	hotKeyBrn = document.getElementById("BLK_ACCOUNT_MASTER__DRACCBRN").value;
 else if (srcID == 'BLK_ACCOUNT_MASTER__CRPRODAC')
	hotKeyBrn = document.getElementById("BLK_ACCOUNT_MASTER__CRACCBRN").value;
 else if (srcID == 'BLK_COMPONENTS__CRPRODAC')
 hotKeyBrn = document.getElementById("BLK_COMPONENTS__CRACCBRN").value;
 else if (srcID == 'BLK_COMPONENTS__DRPRODAC')
 hotKeyBrn = document.getElementById("BLK_COMPONENTS__DRACCBRN").value;
  else if (srcID == 'BLK_CHGCOMP__DRPRODAC')
 hotKeyBrn = document.getElementById("BLK_CHGCOMP__DRACCBRN").value;
 else if (srcID == 'BLK_CHGCOMP__CRPRODAC')
 hotKeyBrn = document.getElementById("BLK_CHGCOMP__CRACCBRN").value;
 return true;
}
// 12.1 Development Joint Holder Hot Key Changes Ends

//[FCUBS12.1.0->RETRO->21186798; Base#20777410] starts
function fnInTab_TAB_CHECKLIST_KERNEL(){
document.getElementById("cmdAddRow_BLK_CHECKLIST").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_CHECKLIST").style.visibility="HIDDEN";	
	return true;

}
function fnInTab_TAB_ADVICES_KERNEL(){
	document.getElementById("cmdAddRow_BLK_ADVICES").style.visibility="HIDDEN";
	document.getElementById("cmdDelRow_BLK_ADVICES").style.visibility="HIDDEN";
	return true;
}
//[FCUBS12.1.0->RETRO->21186798; Base#20777410] ends
/*[FCUBS12.3->RETRO->24613348; Base#21442514] STARTS */
function fnPostDeleteRow_BLK_COLL_LINKAGES_KERNEL() { 

var rowcount = document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows.length; 
for (var i=0;i<rowcount;i++)
{
fn_linkage_1(i); 
}
}

function fnPostNavigate_BLK_COLL_LINKAGES_KERNEL()
{
fnInTab_TAB_LINKAGES_KERNEL();
}
//FCUBS12.4->CNSL->SAIGON COMMERCIAL BANK->27908992 STARTS
//function fn_linkage(i)
function fn_linkage(evnt)
//FCUBS12.4->CNSL->SAIGON COMMERCIAL BANK->27908992 ENDS
{
	//FCUBS12.4->CNSL->SAIGON COMMERCIAL BANK->27908992 STARTS
/* var 	i = getRowIndex()-1;
//SFR#23023894 start Mozilla browser Index is going for -2 due to this Linkages type values not getting instead it showing "Undefined".
 if (i == -2)
 {
 i = 0;
 }
 //SFR#23023894 end */
 var event = window.event || evnt;
 var i    =  getRowIndex(evnt)-1;
 //FCUBS12.4->CNSL->SAIGON COMMERCIAL BANK->27908992 ENDS
fn_linkage_1(i);
 return true;
}
function fn_linkage_1(i)
{

 	   if(document.getElementById("BLK_COLL_LINKAGES").getElementsByTagName("SELECT")[i].value!='N')
		 {
		 fnEnableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[1].getElementsByTagName("INPUT")[0]);
		fnEnableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[2].getElementsByTagName("INPUT")[0]);
		fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[3].getElementsByTagName("INPUT")[0]);
		fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[4].getElementsByTagName("INPUT")[0]);
		fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[5].getElementsByTagName("INPUT")[0]);
		fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[6].getElementsByTagName("INPUT")[0]);
		fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[7].getElementsByTagName("INPUT")[0]);
		fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[8].getElementsByTagName("INPUT")[0]);		
		fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[15].getElementsByTagName("INPUT")[0]);	
					
		}
	    else 
	    {
			fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[1].getElementsByTagName("INPUT")[0]);
			fnDisableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[2].getElementsByTagName("INPUT")[0]);
			fnEnableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[3].getElementsByTagName("INPUT")[0]);
	        fnEnableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[4].getElementsByTagName("INPUT")[0]);
			fnEnableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[5].getElementsByTagName("INPUT")[0]);
			fnEnableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[6].getElementsByTagName("INPUT")[0]);
			fnEnableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[7].getElementsByTagName("INPUT")[0]);
			fnEnableElement(document.getElementById("BLK_COLL_LINKAGES").tBodies[0].rows[i].cells[8].getElementsByTagName("INPUT")[0]);
	
		
	    }	
	  
		
	 return true;

} 
//BUG#24352123 starts
function fnPreExit_CVS_REVERSE_KERNEL()
{
	parent.gAction = "";
	return true;
}
//BUG#24352123 ends
/*[FCUBS12.3->RETRO->24613348; Base#21442514] ENDS */
// [FCUBS12.1-INTERNAL-ITR1-21677950] starts
function fnInTab_TAB_HOL_PREF_KERNEL()
{
	fncurrency();
	return true;
}
// [FCUBS12.1-INTERNAL-ITR1-21677950] ends
//FCUBS_124_INTERNAL_26525016_RETRO_FROM_26477432 starts
function fnPreNavigate_BLK_CLVWS_ACCOUNT_UDF_CHAR_KERNEL()
{
	appendData();
	return true;
}
function fnPreNavigate_BLK_CLVWS_ACCOUNT_UDF_NUM_KERNEL()
{
	appendData();
	return true;
}
function fnPreNavigate_BLK_CLVWS_ACCOUNT_UDF_DATE_KERNEL()
{
	appendData();
	return true;
}
//FCUBS_124_INTERNAL_26525016_RETRO_FROM_26477432 ends

//sampath starts
function fnPreSave_KERNEL(){

console.log("Inside fnPreSave_KERNEL");   

console.log("g_enrich="+g_enrich);
  
if (g_enrich=='N') {
console.log("Inside IF Condition");
debugs("In Please click on Enrich Button before save", "A");
alert("Please click on Enrich Button before save");
return false;
}		
return true;		
		
}
//sampath ends

