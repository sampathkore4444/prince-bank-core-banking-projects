CREATE OR REPLACE PACKAGE  clpks_cldaccnt_main AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : clpks_cldaccnt_main.spc
  **
  ** Module     : Retail Lending
  ** 
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  ** 
  ** 
  ** No part of this work may be reproduced, stored in a retrieval system, adopted 
  ** or transmitted in any form or by any means, electronic, mechanical, 
  ** photographic, graphic, optic recording or otherwise, translated in any 
  ** language or computer language, without the prior written permission of 
  ** Oracle and/or its affiliates. 
  ** 
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East), 
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :  
  Changed By         :  
  Change Description :  
  
  -------------------------------------------------------------------------------------------------------
  */
  
  
TYPE ty_tb_cltbs_account_promotions IS TABLE OF cltb_account_promotions%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_account_parties IS TABLE OF cltb_account_parties%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__cltbs_account_hol_perds IS TABLE OF cltb_account_hol_perds%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_account_ude_eff_dates IS TABLE OF cltb_account_ude_eff_dates%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_cltbs_account_ude_values IS TABLE OF cltb_account_ude_values%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__cltbs_account_roll_comp IS TABLE OF cltb_account_roll_comp%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_ltbs_rate_plan_eff_dates IS TABLE OF cltb_rate_plan_eff_dates%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_event_check_list IS TABLE OF cltb_event_check_list%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__account_components__cmp IS TABLE OF cltb_account_components%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_account_comp_sch IS TABLE OF cltb_account_comp_sch%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_account_schedules__cmp IS TABLE OF cltb_account_schedules%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_account_linkages IS TABLE OF cltb_account_linkages%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_account_events_advices IS TABLE OF cltb_account_events_advices%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__account_advice_suppress IS TABLE OF cltb_account_advice_suppress%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_account_asset_valuations IS TABLE OF cltb_account_asset_valuations%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_cltbs_account_financials IS TABLE OF cltb_account_financials%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_ltbs_account_liabilities IS TABLE OF cltb_account_liabilities%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_account_other_income IS TABLE OF cltb_account_other_income%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_disbr_schedules IS TABLE OF cltb_disbr_schedules%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_revn_schedules IS TABLE OF cltb_revn_schedules%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__account_components__chg IS TABLE OF cltb_account_components%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_account_schedules__chg IS TABLE OF cltb_account_schedules%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_clvss_account_charge IS TABLE OF clvs_account_charge%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_account_comp_balances IS TABLE OF clvs_account_comp_balances%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_account_irr IS TABLE OF cltb_account_irr%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cstbs_ui_columns__sch IS TABLE OF cstb_ui_columns%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cstbs_ui_columns__chg IS TABLE OF cstb_ui_columns%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_acc_guarantor_customer IS TABLE OF cltb_acc_guarantor_customer%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_acc_guarantor_accounts IS TABLE OF cltb_acc_guarantor_accounts%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_account_emi_chg IS TABLE OF cltb_account_emi_chg%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_intermediary IS TABLE OF cltb_intermediary%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__cltbs_split_sttl_detail IS TABLE OF cltb_split_sttl_detail%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_cltbs_acc_coll_link_dtls IS TABLE OF cltb_acc_coll_link_dtls%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cltbs_acc_multi_fin IS TABLE OF cltb_acc_multi_fin%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__clvw_collateral_tov_det IS TABLE OF clvw_collateral_tov_det%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_clvws_account_udf_char IS TABLE OF clvw_account_udf_char%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_clvws_account_udf_num IS TABLE OF clvw_account_udf_num%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_clvws_account_udf_date IS TABLE OF clvw_account_udf_date%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__cltbs_account_liq_order IS TABLE OF cltb_account_liq_order%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__account_liq_order__comp IS TABLE OF cltb_account_liq_order%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_v_cstbs_ui_columns__ude IS TABLE OF cstb_ui_columns%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb__cstbs_ui_columns__split IS TABLE OF cstb_ui_columns%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE ty_tb_cltbs_dsbr_settl_details IS TABLE OF cltb_dsbr_settl_details%ROWTYPE INDEX BY BINARY_INTEGER;

TYPE ty_cldaccnt IS RECORD (
      v_cltbs_account_master     cltb_account_master%ROWTYPE,
      v_cltbs_account_promotions    ty_tb_cltbs_account_promotions,
      v_cltbs_account_parties    ty_tb_v_cltbs_account_parties,
      v_cltbs_account_hol_perds    ty_tb__cltbs_account_hol_perds,
      v_account_ude_eff_dates    ty_tb_v_account_ude_eff_dates,
      v_cltbs_account_ude_values    ty_tb_cltbs_account_ude_values,
      v_cltbs_account_roll_comp    ty_tb__cltbs_account_roll_comp,
      v_cltbs_rate_plan_eff_dates    ty_tb_ltbs_rate_plan_eff_dates,
      v_cltbs_event_check_list    ty_tb_v_cltbs_event_check_list,
      v_cltbs_event_remarks     cltb_event_remarks%ROWTYPE,
      v_account_components__cmp    ty_tb__account_components__cmp,
      v_cltbs_account_comp_sch    ty_tb_v_cltbs_account_comp_sch,
      v_account_schedules__cmp    ty_tb_v_account_schedules__cmp,
      v_cltbs_account_linkages    ty_tb_v_cltbs_account_linkages,
      v_account_events_advices    ty_tb_v_account_events_advices,
      v_account_advice_suppress    ty_tb__account_advice_suppress,
      v_account_credit_score     cltb_account_credit_score%ROWTYPE,
      v_account_asset_vehicle     cltb_account_asset_vehicle%ROWTYPE,
      v_cltbs_account_asset_home     cltb_account_asset_home%ROWTYPE,
      v_account_asset_others     cltb_account_asset_others%ROWTYPE,
      v_cltbs_account_property     cltb_account_property%ROWTYPE,
      v_account_asset_valuations    ty_tb_account_asset_valuations,
      v_cltbs_account_financials    ty_tb_cltbs_account_financials,
      v_cltbs_account_liabilities    ty_tb_ltbs_account_liabilities,
      v_account_other_income    ty_tb_v_account_other_income,
      v_cltbs_disbr_schedules    ty_tb_v_cltbs_disbr_schedules,
      v_cltbs_revn_schedules    ty_tb_v_cltbs_revn_schedules,
      v_account_components__chg    ty_tb__account_components__chg,
      v_account_schedules__chg    ty_tb_v_account_schedules__chg,
      v_clvss_account_charge    ty_tb_v_clvss_account_charge,
      v_account_comp_balances    ty_tb_v_account_comp_balances,
      v_cltbs_account_irr    ty_tb_v_cltbs_account_irr,
      v_cstbs_ui_columns__main     cstb_ui_columns%ROWTYPE,
      v_cstbs_ui_columns__sch    ty_tb_v_cstbs_ui_columns__sch,
      v_cstbs_ui_columns__chg    ty_tb_v_cstbs_ui_columns__chg,
      v_cstbs_ui_columns__udf     cstb_ui_columns%ROWTYPE,
      v_account_settl_details     cltb_account_settl_details%ROWTYPE,
      v_cstbs_ui_columns__udfdesc     cstb_ui_columns%ROWTYPE,
      v_cstbs_ui_columns__udfval     cstb_ui_columns%ROWTYPE,
      v_acc_guarantor_customer    ty_tb_v_acc_guarantor_customer,
      v_acc_guarantor_accounts    ty_tb_v_acc_guarantor_accounts,
      v_cltbs_account_statement     cltb_account_statement%ROWTYPE,
      v_clvws_account_detail     clvw_account_detail%ROWTYPE,
      v_cltbs_account_emi_chg    ty_tb_v_cltbs_account_emi_chg,
      v_ui_columns__total_prin     cstb_ui_columns%ROWTYPE,
      v_cltbs_intermediary    ty_tb_v_cltbs_intermediary,
      v_cltbs_split_sttl_detail    ty_tb__cltbs_split_sttl_detail,
      v_cltbs_acc_coll_link_dtls    ty_tb_cltbs_acc_coll_link_dtls,
      v_cltbs_acc_multi_fin    ty_tb_v_cltbs_acc_multi_fin,
      v_clvw_collateral_tov_det    ty_tb__clvw_collateral_tov_det,
      v_acc_coll_link_dtls__a     cltb_acc_coll_link_dtls%ROWTYPE,
      v_clvws_account_udf_char    ty_tb_v_clvws_account_udf_char,
      v_clvws_account_udf_num    ty_tb_v_clvws_account_udf_num,
      v_clvws_account_udf_date    ty_tb_v_clvws_account_udf_date,
      v_cltbs_account_master_smry     cltb_account_master_smry%ROWTYPE,
      v_cltbs_account_liq_order    ty_tb__cltbs_account_liq_order,
      v_account_liq_order__comp    ty_tb__account_liq_order__comp,
      v_cstbs_ui_columns__ude    ty_tb_v_cstbs_ui_columns__ude,
      v_cstbs_ui_columns__split    ty_tb__cstbs_ui_columns__split,
      v_cltbs_dsbr_settl_details    ty_tb_cltbs_dsbr_settl_details,
      v_cltbs_account_holiday     cltb_account_holiday%ROWTYPE,
      v_cltbs_account_aprc     cltb_account_aprc%ROWTYPE,
      v_loan_risk_score_custom     cltb_loan_risk_score_custom%ROWTYPE,
      v_columns__tot_collat_pool     cstb_ui_columns%ROWTYPE,
      v_columns__tot_prin_out_lcy     cstb_ui_columns%ROWTYPE,
      v_loan_sector_dtls_custom     cltb_loan_sector_dtls_custom%ROWTYPE,
      v_account_ratetype_custom     cltb_account_ratetype_custom%ROWTYPE,
                  ty_cscofact Cspks_Cscofact_Main.ty_cscofact,
                  ty_clcsehis Clpks_Clcsehis_Main.ty_clcsehis,
                  ty_cicmtast Cipks_Cicmtast_Main.ty_cicmtast,
                  ty_cscdoctr Cspks_Cscdoctr_Main.ty_cscdoctr,
                  ty_micclmis Mipks_Micclmis_Main.ty_micclmis,
                  Txn_Udf_Details Uvpkss_Udf_Upload.ty_upl_cont_udf,
                  Desc_Fields    Cspks_Req_Global.Ty_Tb_Xml_Data,
                  Addl_Info    Cspks_Req_Global.Ty_Addl_info );


PROCEDURE Pr_Set_Skip_Sys;
PROCEDURE Pr_Set_Activate_Sys;
FUNCTION  Fn_Skip_Sys RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Kernel;
PROCEDURE Pr_Set_Activate_Kernel;
FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN;
PROCEDURE Pr_Set_Skip_Custom;
PROCEDURE Pr_Set_Activate_Custom;
FUNCTION  Fn_Skip_Custom RETURN BOOLEAN;
FUNCTION Fn_Get_Original_Action RETURN VARCHAR2;
g_autoauth VARCHAR2(1);

FUNCTION Fn_Process_Request(p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Multi_Trip_Id     IN  VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_Addl_Info      IN OUT Cspks_Req_Global.Ty_Addl_Info,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Exchange_Pattern  IN     VARCHAR2,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Main       (p_Source            IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
                        p_Multi_Trip_Id     IN  VARCHAR2,
                        p_Request_No        IN     VARCHAR2,
                        p_cldaccnt          IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
                        p_Status            IN OUT VARCHAR2 ,
                        p_Err_Code          IN OUT VARCHAR2,
                        p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Build_Ts_List (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Exchange_Pattern   IN  VARCHAR2,
p_cldaccnt          IN clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code        IN OUT VARCHAR2,
p_Err_Params      IN OUT VARCHAR2)
RETURN BOOLEAN;

FUNCTION Fn_Resolve_Ref_Numbers (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldaccnt     IN  OUT clpks_cldaccnt_Main.ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Product_Default         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt      IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Subsys_Pickup         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Prev_cldaccnt IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt      IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Enrich         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Prev_cldaccnt IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt      IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Check_Mandatory (p_Source    IN  VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
p_cldaccnt IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code       IN  OUT VARCHAR2,
p_Err_Params     IN  OUT VARCHAR2)
  RETURN BOOLEAN;
FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN  OUT   VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Prev_cldaccnt IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Upload_Db         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Multi_Trip_Id    IN  VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Prev_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt      IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Process         (p_Source            IN VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Multi_Trip_Id    IN  VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Prev_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt      IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
p_with_lock     IN  VARCHAR2 DEFAULT 'N',
p_QryData_Reqd       IN  VARCHAR2,
p_cldaccnt         IN  clpks_cldaccnt_Main.Ty_cldaccnt, 
p_Wrk_cldaccnt  IN   OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_addl_info       IN Cspks_Req_Global.Ty_Addl_Info,
p_cldaccnt       IN   OUT clpks_cldaccnt_Main.ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
p_cldaccnt       IN   OUT clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldaccnt          IN clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code        IN OUT VARCHAR2,
p_Err_Params      IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Exchange_Pattern IN       VARCHAR2,
p_cldaccnt          IN clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code        IN OUT VARCHAR2,
p_Err_Params      IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN     VARCHAR2,
p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
p_cldaccnt IN  clpks_cldaccnt_Main.ty_cldaccnt,
p_Err_Code       IN  OUT VARCHAR2,
p_Err_Params     IN  OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Basic_Vals        (p_Source    IN     VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Merge_Amendables        (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Prev_cldaccnt IN clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source    IN     VARCHAR2,
p_Wrk_cldaccnt IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Lov_Vals        (p_Source    IN     VARCHAR2,
p_Wrk_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Default_Vals        (p_Source    IN     VARCHAR2,
p_Wrk_cldaccnt     IN  OUT clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Default_and_Validate        (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Prev_cldaccnt IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Upload_Db         (p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Prev_cldaccnt     IN  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Wrk_cldaccnt      IN OUT  clpks_cldaccnt_Main.Ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN ;
FUNCTION Fn_Sys_Query  ( p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
p_QryData_Reqd       IN  VARCHAR2,
p_cldaccnt         IN  clpks_cldaccnt_Main.ty_cldaccnt, 
p_Wrk_cldaccnt  IN   OUT clpks_cldaccnt_Main.ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN     VARCHAR2,
                        p_Source_Operation  IN     VARCHAR2,
                        p_Function_Id       IN     VARCHAR2,
                        p_Action_Code       IN     VARCHAR2,
p_Wrk_cldaccnt  IN   OUT clpks_cldaccnt_Main.ty_cldaccnt,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
FUNCTION Fn_Get_Node_Data ( 
p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
p_Err_Code          IN OUT VARCHAR2,
p_Err_Params        IN OUT VARCHAR2)
RETURN BOOLEAN;
END clpks_cldaccnt_main;
/
CREATE OR REPLACE SYNONYM clpkss_cldaccnt_main FOR clpks_cldaccnt_main
/