prompt Importing table LMTM_TYPE_OF_TYPES...
set feedback off
set define off
insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('LOAN_VAR_DEF', 'Loan Variable Default Rate', 'SAMPATH2', 'SAMPATH1', to_date('16-08-2021 20:59:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('04-09-2021 20:59:50', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

prompt Done.
