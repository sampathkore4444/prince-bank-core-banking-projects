CREATE OR REPLACE PACKAGE BODY clpks_cldaccnt_default_custom

 IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      DEBUG.PR_DEBUG('CL', 'clpks_cldaccnt_default_custom->' || P_MSG);
    END IF;
  END;

  FUNCTION FN_DEFAULT_ACCOUNT(P_ACCOUNT_OBJ    IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                              P_FN_CALL_ID     IN OUT NUMBER,
                              P_TB_CUSTOM_DATA IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAMS     IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  BEGIN
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of function Fn_default_account');
      DBG('Oracle Error code is' || SQLCODE || '--' || SQLERRM);
      RETURN FALSE;
  END FN_DEFAULT_ACCOUNT;

  FUNCTION FN_PRE_DEFAULT_ACCOUNT(P_ACCOUNT_OBJ      IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                  P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                  P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                  P_FN_CALL_ID       IN OUT NUMBER,
                                  P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('CL',
                   'Inside default account master with action_code' ||
                   P_ERR_CODE);
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CL', 'In when others Of Fn_Default_Acc_Master..');
      DEBUG.PR_DEBUG('CL', SQLERRM);
      DEBUG.PR_DEBUG('CL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_ACCOUNT;

  FUNCTION FN_POST_DEFAULT_ACCOUNT(P_ACCOUNT_OBJ      IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                   P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                   P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                   P_FN_CALL_ID       IN OUT NUMBER,
                                   P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  
    --sampath starts for loan variable interest rate
    L_RATE_CODE_INT_VALUE NUMBER := 0;
    --sampath ends for loan variable interest rate
  
  BEGIN
  
    DBG('Fn_post_default_account='||P_ACTION_CODE);
  
    DEBUG.PR_DEBUG('CL',
                   'Inside default account master with action_code' ||
                   P_ERR_CODE);
  
    --sampath starts for loan variable interest rate
    DBG('P_CLDACCNT.v_account_ratetype_custom.INTEREST_RATE_TYPE=' ||
        P_CLDACCNT.v_account_ratetype_custom.INTEREST_RATE_TYPE);
  
    DBG('p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE=' ||
        p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
  
    /*IF P_CLDACCNT.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'V' THEN
      DBG('p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT=' ||
          p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT);
    
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT > 0 THEN
        FOR G IN 1 .. P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT LOOP
        
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
           .UDE_ID = 'INTEREST_RATE' THEN
          
            p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G).RATE_CODE := 'TD_1_YR_RT';
            p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G).CODE_USAGE := 'A';
          
            --Get Int value from rate code
            BEGIN
              SELECT NVL(A.INT_RATE, 0)
                INTO L_RATE_CODE_INT_VALUE
                FROM CFTMS_FLOAT_RATE_DETAIL A
               WHERE RATE_CODE = 'TD_1_YR_RT'
                 AND CCY_CODE = p_Wrk_cldaccnt.v_cltbs_account_master.currency
                 AND TENOR_FROM = '0'
                 AND TENOR_TO = '0'
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
              
                L_RATE_CODE_INT_VALUE := 0;
              
            END;
          
            p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G).RESOLVED_VALUE := p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G)
                                                                           .UDE_VALUE +
                                                                            L_RATE_CODE_INT_VALUE;
          
          END IF;
        
        END LOOP;
      
      END IF;
    
    END IF;*/
  
    /*IF P_CLDACCNT.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'F' THEN
      DBG('p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT=' ||
          p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT);
    
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT > 0 THEN
        FOR G IN 1 .. P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT LOOP
        
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
           .UDE_ID = 'INTEREST_RATE' THEN
          
            p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G).RATE_CODE := NULL;
            p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G).CODE_USAGE := NULL;
          
            p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G).RESOLVED_VALUE := p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G)
                                                                           .UDE_VALUE;
          
          END IF;
        
        END LOOP;
      
      END IF;
    END IF;*/
    --sampath ends for loan variable interest rate
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CL', 'In when others Of Fn_Default_Acc_Master..');
      DEBUG.PR_DEBUG('CL', SQLERRM);
      DEBUG.PR_DEBUG('CL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DEFAULT_ACCOUNT;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_PRE_DEFAULT_TD_LINKAGES(P_REC_ACC    IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                      P_TD_ACC     IN STTMS_CUST_ACCOUNT%ROWTYPE,
                                      P_ERRORCODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                      P_ERRORPARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
  
   RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('CL',
                   'Inside clpks_cldaccnt_default_custom.Fn_pre_default_td_linkages');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CL',
                     'In when others Of clpks_cldaccnt_default_custom.Fn_pre_default_td_linkages..');
      DEBUG.PR_DEBUG('CL', SQLERRM);
      RETURN FALSE;
  END FN_PRE_DEFAULT_TD_LINKAGES;

  FUNCTION FN_POST_DEFAULT_TD_LINKAGES(P_REC_ACC    IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                       P_TD_ACC     IN STTMS_CUST_ACCOUNT%ROWTYPE,
                                       P_ERRORCODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                       P_ERRORPARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
  
   RETURN BOOLEAN IS
  
  BEGIN
    DEBUG.PR_DEBUG('CL',
                   'Inside clpks_cldaccnt_default_custom.Fn_post_default_td_linkages');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CL',
                     'In when others Of clpks_cldaccnt_default_custom.Fn_post_default_td_linkages..');
      DEBUG.PR_DEBUG('CL', SQLERRM);
      RETURN FALSE;
  END FN_POST_DEFAULT_TD_LINKAGES;

  FUNCTION FN_POST_DEFAULT_ACC_MASTER(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                      P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('CL',
                   'Inside clpks_cldaccnt_default_custom.Fn_Post_Default_Acc_Master');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('CL',
                     'In when others Of clpks_cldaccnt_default_custom.Fn_Post_Default_Acc_Master..');
      DEBUG.PR_DEBUG('CL', SQLERRM);
      RETURN FALSE;
  END FN_POST_DEFAULT_ACC_MASTER;

END CLPKS_CLDACCNT_DEFAULT_CUSTOM;
